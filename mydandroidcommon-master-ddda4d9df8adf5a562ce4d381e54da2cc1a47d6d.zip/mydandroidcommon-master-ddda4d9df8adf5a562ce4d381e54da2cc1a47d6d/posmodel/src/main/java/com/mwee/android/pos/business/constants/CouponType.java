package com.mwee.android.pos.business.constants;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 优惠类型
 */
@Retention(RetentionPolicy.SOURCE)
public @interface CouponType {

    /**
     * 正常，无优惠
     */
    String NORMAL = "0";

    /**
     * 特价
     */
    String SPECIAL_PRICE = "2";

    /**
     * 会员价
     */
    String MEMBER_PRICE = "3";

    /**
     * 买减
     */
    String BUY_GIFT = "4";

    /**
     * 赠送
     */
    String GIFT = "5";

    /**
     * 普通折扣
     */
    String DISCOUNT_NORMAL = "6";

    /**
     * 会员折扣
     */
    String DISCOUNT_MEMBER = "7";

    /**
     * 免服务费
     */
    String FREE_SERVICE = "8";

    /**
     * 满减
     */
    String FULL_CUT = "9";

    /**
     * 整单立减
     */
    String ORDER_CUT = "10";

    /**
     * 菜品券
     */
    String MEMBER_COUPON = "11";
}
