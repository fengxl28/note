package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.StringUtil;

/**
 * 秒付退款接口
 * Created by virgil on 2016/11/15.
 */

@HttpParam(httpType = HttpType.POST,
        method = "refundfee",
        response = RapidRefundResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        saveToLog = true)
public class RapidRefundRequest extends BasePosRequest {
    /**
     * 订单号
     */
    public String orderId = "";
    /**
     * 交易流水号
     */
    public String sysPayId = "";

    public RapidRefundRequest() {

    }
}
