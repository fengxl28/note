package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.tools.StringUtil;

/**
 */
@HttpParam(httpType = HttpType.POST,
        method = "binding",
        response = BindResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class BindRequest extends BasePosRequest {
    public String symble = "";

    public BindRequest() {
    }

    /**
     * 输出流加密
     *
     * @param data String | 加密前的报文
     * @return String 密文
     */
    public String encrypt(String data) {
        return symble;
    }

    /**
     * 响应流解密
     *
     * @param data String | 密文
     * @return String | 解密后的报文
     */
    public String decrypt(String data) {
        return data;
    }
}
