package com.mwee.android.cashier.connect.bean.http.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.order.OrderCache;

import java.math.BigDecimal;

/**
 * 美收银的缓存单
 * Created by virgil on 2018/2/1.
 *
 * @author virgil
 */

public class CashierTempOrder extends BusinessBean {
    /**
     * 订单状态
     * <p>
     * see{@link com.mwee.android.pos.db.business.order.OrderStatus}
     */

    @JSONField(name = "billStatus")
    public int orderStauts;
    /**
     * 支付单号
     */
    public int checkBillNo;
    /**
     * 创建时间
     */
    public String createTime;
    /**
     * 顾客数量
     */
    @JSONField(name = "custSum")
    public int person;
    /**
     * 应付金额
     */
    public BigDecimal expAmt;
    /**
     * 订单类型see{@link com.mwee.android.pos.db.business.order.OrderCache#fiSellType}
     */
    public int sellType;
    /**
     * 站点ID
     */
    public String hostId;
    /**
     * 牌号
     */
    public String mealNumber;
    /**
     * 应收金额
     */
    public BigDecimal saleAmt;
    /**
     * 营业日期
     */
    public String sellDate;
    /**
     * 订单号
     */
    @JSONField(name = "sellNo")
    public String orderId;
    /**
     * 结账时间
     */
    public String sellTime;
    /**
     * 门店ID
     */
    public String shopGUID;
    /**
     * 用户ID
     */
    public String userId;
    /**
     * OrderCache的String，需要Zip一下
     */
    public String orderInfo;
    public OrderCache orderCache;
    /**
     * PaySession的String，需要Zip一下
     */
    public String payInfo;

    public CashierTempOrder() {

    }
}
