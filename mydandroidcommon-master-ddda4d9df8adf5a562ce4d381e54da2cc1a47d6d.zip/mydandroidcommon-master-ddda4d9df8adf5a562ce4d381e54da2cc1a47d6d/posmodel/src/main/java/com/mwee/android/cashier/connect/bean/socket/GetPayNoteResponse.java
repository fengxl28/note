package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.List;

/**
 * 获取支付备注的历史记录
 * Created by virgil on 2018/2/1.
 *
 * @author virgil
 */

public class GetPayNoteResponse extends BaseSocketResponse {
    public List<String> noteList = null;

    public GetPayNoteResponse() {

    }
}
