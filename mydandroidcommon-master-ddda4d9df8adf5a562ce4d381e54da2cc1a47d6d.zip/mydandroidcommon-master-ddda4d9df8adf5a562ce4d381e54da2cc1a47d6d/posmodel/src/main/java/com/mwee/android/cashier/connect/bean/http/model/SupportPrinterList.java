package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author changsunhaipeng
 * @date 2018/7/5
 */

public class SupportPrinterList extends BusinessBean {
    public List<SupportPrinter> list = new ArrayList<>();
}
