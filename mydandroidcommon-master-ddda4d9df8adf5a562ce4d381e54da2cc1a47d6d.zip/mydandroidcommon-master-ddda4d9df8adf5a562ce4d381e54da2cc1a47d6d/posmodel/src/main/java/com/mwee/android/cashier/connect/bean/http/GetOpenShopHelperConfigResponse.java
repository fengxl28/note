package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.OpenHelperConfig;


/**
 * @author changsunhaipeng
 */
public class GetOpenShopHelperConfigResponse extends BaseCashierPosResponse {
    public OpenHelperConfig data;

    public GetOpenShopHelperConfigResponse() {

    }
}
