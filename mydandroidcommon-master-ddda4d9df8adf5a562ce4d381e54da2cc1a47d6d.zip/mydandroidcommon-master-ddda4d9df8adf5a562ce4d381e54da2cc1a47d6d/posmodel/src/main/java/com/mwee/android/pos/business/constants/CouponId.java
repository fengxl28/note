package com.mwee.android.pos.business.constants;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 优惠类型ID
 */
@Retention(RetentionPolicy.SOURCE)
public @interface CouponId {


    /**
     * 特价
     */
    String SPECIAL_PRICE = "-2";

    /**
     * 会员价
     */
    String MEMBER_PRICE = "-3";
    /**
     * 赠送
     */
    String GIFT = "-5";

    /**
     * 免服务费
     */
    String FREE_SERVICE = "-8";

    /**
     * 菜品券
     */
    String MEMBER_COUPON = "-9";
}
