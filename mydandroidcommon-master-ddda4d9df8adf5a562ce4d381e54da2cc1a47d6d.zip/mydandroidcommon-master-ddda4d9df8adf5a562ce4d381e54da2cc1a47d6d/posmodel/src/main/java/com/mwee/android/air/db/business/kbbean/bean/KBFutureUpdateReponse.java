package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by zhangmin on 2018/10/16.
 */

public class KBFutureUpdateReponse extends BasePosResponse {

    public KBAfterPayOrder data = new KBAfterPayOrder();

}
