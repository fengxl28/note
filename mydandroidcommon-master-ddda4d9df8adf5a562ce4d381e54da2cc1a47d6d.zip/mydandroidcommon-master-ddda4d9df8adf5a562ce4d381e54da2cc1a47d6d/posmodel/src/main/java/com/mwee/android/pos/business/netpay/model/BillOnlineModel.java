package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/1/11.
 */

public class BillOnlineModel extends BusinessBean {
    public int id;//	订单号

    public String payorderid = "";//支付单号

    public String createDate = "";//	创建时间

    public String LastTime = "";//支付时间

    public String nick;

    public String detail;

    public int type;//

    public String mobile;//	手机号

    public int total;

    public int state;

    public String print;

    public int payBackNum;

    public String orderState;

    public int left;//可退菜品数目

    public double leftTotal;//实际支付金额

    public int Totalall;//订单金额

    public int payType;

    public String tableNo;//桌号


    public String orderFailReason;//	失败原因

    public String orderRemark;//订单备注

    public int bizType;

    public String sysPayId;//支付流水号(退款时使用)

    public String tableName;//ui需要的数据：桌号  load from DB

    public String sellno;//ui需要的数据 支付订单号 load from DB

    public BillOnlineModel() {
    }

    /**
     * 支付类型(1微信，2支付宝，3银联，4百度钱包，5会员卡)
     *
     * @return
     */
    public String getPayTypeName() {
        String payTypeName = "其他";
        switch (payType) {
            case 1:
                payTypeName = "微信";
                break;
            case 2:
                payTypeName = "支付宝";
                break;
            case 3:
                payTypeName = "银联";
                break;
            case 4:
                payTypeName = "百度钱包";
                break;
            case 5:
                payTypeName = "会员卡";
                break;
            case -1:
                payTypeName = "";
                break;
            default:
                break;
        }
        return payTypeName;
    }
}
