package com.mwee.android.air.db.business.wechatorder;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2017/10/17.
 */

public class WechatOrderSettingModel extends BusinessBean {

    public WechatOrderSettingModel() {
    }
}
