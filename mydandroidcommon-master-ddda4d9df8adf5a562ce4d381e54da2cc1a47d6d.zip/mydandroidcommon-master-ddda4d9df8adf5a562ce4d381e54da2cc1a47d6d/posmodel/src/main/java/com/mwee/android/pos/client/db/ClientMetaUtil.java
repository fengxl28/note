package com.mwee.android.pos.client.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * Some business With DB
 */
public class ClientMetaUtil {
    /**
     * 配置是否打开
     *
     * @param key          int | key,see{@link META}
     * @param okValue      String | 开关打开时的value
     * @param defauleValue String | 默认的value
     * @return boolean | 配置是否打开，true：配置打开；false，配置关闭
     */
    public static boolean isConfigOpen(int key, String okValue, String defauleValue) {
        String value = ClientMetaUtil.getConfig(key, defauleValue);
        return TextUtils.equals(okValue, value);
    }

    /**
     * 获取门店配置，如果没有设置，则返回默认值
     *
     * @param key          int | see{@link META}
     * @param defauleValue String |
     * @return String
     */
    public static String getConfig(int key, String defauleValue) {
        String value = ClientMetaUtil.getSettingsValueByKey(key);
        if (TextUtils.isEmpty(value)) {
            value = defauleValue;
            ClientMetaUtil.updateSettingsValueByKey(key, defauleValue);
        }
        return value;
    }

    /**
     * 删除字典表里的数据
     *
     * @param key
     */
    public static void deleteSettingsValueByKey(final Integer key) {
        IDBOperate op = new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                try {
                    if (db != null) {
                        if (LogUtil.SHOW) {
                            LogUtil.log("DB Meta", "updateSettingsValueByKey " + JSON.toJSONString(list));
                        }
                        db.delete("meta", "key = '" + key + "'", null);
                    }
                } catch (Exception e) {
                    LogUtil.logError("", e);
                }
                return null;
            }
        };
        DBManager instance = DBManager.getInstance(APPConfig.DB_CLIENT);
        if (instance == null) {
            return;
        }
        instance.executeInTransactionWithOutThread(op);
    }

    /**
     * 批量更新字典表里的数据
     *
     * @param list List<Pair<String, String>>
     */
    public static void updateSettingsValueByKey(final List<Pair<Integer, String>> list) {
        IDBOperate op = new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                try {
                    if (db != null) {
                        ContentValues s = new ContentValues(2);
                        for (Pair<Integer, String> temp : list) {

                            s.clear();
                            s.put("key", temp.first);
                            s.put("value", temp.second);
                            db.replace("meta", null, s);
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError("", e);
                }
                return null;
            }
        };
        DBManager instance = DBManager.getInstance(APPConfig.DB_CLIENT);
        if (instance == null) {
            return;
        }
        instance.executeInTransactionWithOutThread(op);
    }

    /**
     * 批量更新字典表里的数据
     *
     * @param list List<Pair<String, String>>
     */
    public static void updateSettings(final List<JSONObject> list) {
        if (ListUtil.isEmpty(list)) {
            return;
        }
        IDBOperate op = new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                try {
                    if (db != null) {
                        ContentValues s = new ContentValues(2);
                        for (JSONObject temp : list) {

                            s.clear();
                            s.put("key", temp.getString("key"));
                            s.put("value", temp.getString("value"));
                            db.replace("meta", null, s);
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError("", e);
                }
                return null;
            }
        };
        DBManager instance = DBManager.getInstance(APPConfig.DB_CLIENT);
        if (instance == null) {
            return;
        }
        instance.executeInTransactionWithOutThread(op);

    }

    /**
     * 查询字典表，根据key查value
     *
     * @param key Integer
     * @return String|result
     */
    public static String getSettingsValueByKey(final int key) {
        IDBOperate<String> op = new IDBOperate<String>() {
            @Override
            public String doJob(SQLiteDatabase db) {
                String value = null;
                Cursor cursor = null;
                try {
                    if (db != null) {
                        cursor = db.query("meta", new String[]{"value"}, "key = ?", new String[]{key + ""}, null, null, null);
                        if (cursor != null) {
                            if (cursor.moveToNext()) {
                                value = cursor.getString(0);
                            }
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError("", e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return value;
            }

        };
        DBManager instance = DBManager.getInstance(APPConfig.DB_CLIENT);
        if (instance == null) {
            return null;
        }
        return instance.executeQuery(op);
    }

    /**
     * 更新字典表里的数据
     *
     * @param key   String|key
     * @param value String|value
     */
    public static void updateSettingsValueByKey(final int key, final String value) {
        List<Pair<Integer, String>> list = new ArrayList<Pair<Integer, String>>();
        Pair<Integer, String> pair = new Pair<Integer, String>(key, value);
        list.add(pair);
        updateSettingsValueByKey(list);
    }

    /**
     * 重载，更新字典表里的数据
     *
     * @param key   int｜key
     * @param value int｜value
     */
    public static void updateSettingsValueByKey(int key, int value) {
        updateSettingsValueByKey(key, String.valueOf(value));
    }

    public static List<JSONObject> getAllValue() {
        return DBSimpleUtil.queryJsonList(APPConfig.DB_CLIENT, "select * from meta");
    }

    /**
     * 删除
     */
    public static void deleteAll() {
        DBSimpleUtil.excuteSql(APPConfig.DB_CLIENT, "delete from meta where key<>'1'");
    }

    /**
     * 是否启动美小二服务
     *
     * @return
     */
    public static boolean needStartUpWaiterServer() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.SWITCH_WAITER_SERVICE, "1"), "1");
    }

    /**
     * 是否启动排队服务
     *
     * @return
     */
    public static boolean startQueueServer() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.SWITCH_QUEUE_SERVICE, "1"), "1");
    }

    /**
     * 是否打印美味结束语
     *
     * @return
     */
    public static boolean needPrintMWAD() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_MWBYD_AD, "1"), "1");
    }

    /**
     * 预结单是否显示“可折扣金额”
     *
     * @return
     */
    public static boolean needPrintDiscountInfo() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.PRE_BILL_PRINT_DISCOUNT_INFO, "0"), "1");
    }

    /**
     * 点菜单、预结单、结账单是否显示用餐标准内菜品金额 0：显示 1：不显示，默认1
     *
     * @return
     */
    public static boolean needPrintPrice() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.DINNERSTANDARD_PRINT_CONFIG, "1"), "1");
    }

    /**
     * 点菜单、传菜单、制作总单显示整单等叫 0：不显示 1：显示，默认0
     *
     * @return
     */
    public static boolean needPrintAllWaitCall() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_SHOW_ALL_WAITCALL, "0"), "1");
    }

    /**
     * 点菜单、传菜单、制作总单显示整单备注 0：不显示 1：显示，默认0
     *
     * @return
     */
    public static boolean needPrintBatchNote() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_SHOW_BATCHNOTE, "0"), "1");
    }

    /**
     * 微信外卖订单是否开启“请取餐”
     *
     * @return
     */
    public static boolean mweeNetorderShowQQCBtn() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.MWEE_NETORDER_SHOW_QQCBTN, "0"), "1");
    }

    /**
     * 划菜服务
     *
     * @return
     */
    public static boolean mweePaddleServer() {
        return TextUtils.equals(ClientMetaUtil.getConfig(META.MWEE_PADDLE_SERVER, "0"), "1");
    }

    /**
     * 是否已激活
     *
     * @return boolean | true：已激活；false：未激活
     */
    public static boolean isActived() {
        String shopid = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String token = ClientMetaUtil.getSettingsValueByKey(META.TOKEN);
        String seed = ClientMetaUtil.getSettingsValueByKey(META.SEED);
        return !TextUtils.isEmpty(shopid) && !TextUtils.isEmpty(token) && !TextUtils.isEmpty(seed);
    }

    public static boolean isActived(String shopId) {
        String curShopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String token = ClientMetaUtil.getSettingsValueByKey(META.TOKEN);
        String seed = ClientMetaUtil.getSettingsValueByKey(META.SEED);
        return !TextUtils.isEmpty(curShopId) && TextUtils.equals(shopId, curShopId) && !TextUtils.isEmpty(token) && !TextUtils.isEmpty(seed);
    }

    public static void setCurrentHostAsMain(boolean asMain) {
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, asMain ? 1 : 0);
    }

    /**
     * 当前站点是否是主站点
     *
     * @return boolean | true:是主站点;false:不是主站点
     */
    public static boolean isCurrentHostMain() {
        String isMain = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST);
        return TextUtils.equals("1", isMain);
    }

    /**
     * 判断当前站点是否是副站点
     *
     * @return boolean
     */
    public static boolean isCurrentHostVice() {
        return isActived() && !isCurrentHostMain();
    }
}
