package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.CheckCardTypeBean;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 检查卡类型
 */

public class CheckCardTypeResponse extends BaseMemberResponse {
    /**
     * 检查卡类型结果
     */
    public CheckCardTypeBean data;

    public CheckCardTypeResponse() {
    }
}
