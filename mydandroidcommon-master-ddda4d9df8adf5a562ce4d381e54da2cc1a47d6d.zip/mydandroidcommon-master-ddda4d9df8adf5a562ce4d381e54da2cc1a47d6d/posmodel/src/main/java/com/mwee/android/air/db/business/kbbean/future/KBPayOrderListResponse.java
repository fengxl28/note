package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/12/10 9:41 PM
 * email: qin.wei@mwee.cn
 */

public class KBPayOrderListResponse extends BasePosResponse {
    public KBPayOrderList data = new KBPayOrderList();

    public static class KBAfterPayOrder extends BusinessBean {
        public String payType = "";
        public String payTime = "";
        public String paymentId = "";
        public String thirdOrderId = "";
        public BigDecimal buyerAmount = BigDecimal.ZERO;
        public String posOrderId = "";
        public String status = "";

        public final static class PayType {
            public static final String ALIPAY = "ALIPAY";
        }

        public final static class Status {
            public static final String SUCCESS = "SUCCESS";
            public static final String REFUND = "REFUND";
            public static final String PAY = "PAY";
            public static final String CLOSE = "CLOSE";
        }
    }

    public static class KBPayOrderList extends BusinessBean {
        public int pageSize;
        public int total;
        public int pages;
        public List<KBAfterPayOrder> list = new ArrayList<>();
        public int pageNum;

    }


    public KBPayOrderListResponse() {
    }
}
