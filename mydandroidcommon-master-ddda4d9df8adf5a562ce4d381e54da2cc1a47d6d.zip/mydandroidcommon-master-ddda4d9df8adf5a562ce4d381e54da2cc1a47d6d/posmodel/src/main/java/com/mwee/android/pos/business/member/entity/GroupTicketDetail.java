package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/12/12
 * 美团券详情
 */

public class GroupTicketDetail extends BusinessBean {
    /**
     * 是否代金券 true代表代金券,false代表套餐券
     */
    public boolean isVoucher;

    public GroupTicketDetail() {
    }
}
