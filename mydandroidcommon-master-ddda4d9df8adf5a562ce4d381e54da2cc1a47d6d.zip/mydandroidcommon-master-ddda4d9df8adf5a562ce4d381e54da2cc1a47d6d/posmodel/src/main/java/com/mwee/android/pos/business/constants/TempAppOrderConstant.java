package com.mwee.android.pos.business.constants;

/**
 * Created by liuxiuxiu on 2017/9/6.
 * 外卖菜品
 */

public class TempAppOrderConstant {
    public static final int MENU_TYPE_NORMAL = 1;   //普通菜品
    public static final int MENU_TYPE_MODIFIER_SET = 2;//套餐分类
    public static final int MENU_TYPE_MODIFIER_INGREDIENT = 3;//配料分类
    public static final int MENU_TYPE_MODIFIER_DETAIL = 4;//配料、套餐明细

}
