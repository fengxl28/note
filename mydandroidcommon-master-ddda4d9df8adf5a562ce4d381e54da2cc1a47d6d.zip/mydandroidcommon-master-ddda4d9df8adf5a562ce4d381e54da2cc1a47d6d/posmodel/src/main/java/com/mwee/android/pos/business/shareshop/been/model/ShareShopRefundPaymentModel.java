package com.mwee.android.pos.business.shareshop.been.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/3/29.
 * 共享餐厅退款Model
 */

public class ShareShopRefundPaymentModel extends BusinessBean {

    /**
     * 美易点支付方式Id(
     * 91801-支付宝在线支付,
     * 91802-微信在线支付,
     * 91803-银联在线支付,
     * 91804-百度钱包,
     * 95001-美会员卡,
     * 95002-美积分抵扣,
     * 95003-奖励金,
     * 99918-打赏,
     * 95004-调账抹零,
     * 97201-优惠券,
     * 94001-美味补贴,
     * 94002-支付宝平台优惠,
     * 94003-微信平台优惠,
     * 99001-特权折扣,
     * 99002-支付宝商家补贴金额,
     * 99003-微信商家补贴金额,
     * 99004-美味商家补贴金额)
     */
    public String paymentId = "";
    /**
     * 本次退款金额
     */
    public BigDecimal refundAmount = BigDecimal.ZERO;

    /**
     * 本次退款会员积分抵扣金额
     */
    public BigDecimal refundScore = BigDecimal.ZERO;

    /**
     * 本次退储值卡金额
     */
    public BigDecimal refundCardAmount = BigDecimal.ZERO;

    /**
     * 本次退优惠券金额
     */
    public BigDecimal refundCouponAmount = BigDecimal.ZERO;

    /**
     * 本次退优惠券的券号列表
     */
    public List<String> couponNo = new ArrayList<>();

    public ShareShopRefundPaymentModel() {
    }
}
