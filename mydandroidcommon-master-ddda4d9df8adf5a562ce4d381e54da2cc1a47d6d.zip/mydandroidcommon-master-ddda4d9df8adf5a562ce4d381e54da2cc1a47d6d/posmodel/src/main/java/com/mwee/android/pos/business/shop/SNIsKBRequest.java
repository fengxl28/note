package com.mwee.android.pos.business.shop;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 查询SN是否是口碑售卖
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31605996
 * Created by qinwei on 2018/9/27.
 */
@HttpParam(httpType = HttpType.POST,
        method = "info/snIfExist",
        response = SNIsKBResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 5)
public class SNIsKBRequest extends BasePosRequest {
    public String sn = "";

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrlPrefix();
    }

    public SNIsKBRequest() {

    }
}