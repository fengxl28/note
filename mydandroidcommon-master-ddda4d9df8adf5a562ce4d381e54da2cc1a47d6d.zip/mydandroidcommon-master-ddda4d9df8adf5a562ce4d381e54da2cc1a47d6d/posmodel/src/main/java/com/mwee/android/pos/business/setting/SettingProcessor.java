package com.mwee.android.pos.business.setting;

import android.text.TextUtils;

import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/19.
 */

public class SettingProcessor {

    /**
     * 得到所有的服务员名称
     * @return
     */
    public static List<String> getAllWaiterName() {
        String sql = "select fsUserName from tbuser where fiStatus = '1'";
        List<String> waiterNames = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN,sql);
        if (ListUtil.isEmpty(waiterNames)){
            waiterNames = new ArrayList<>();
        }
        waiterNames.add(0,"无条件");
        return waiterNames;
    }

    /**
     * 得到所有的站点ID
     * @return
     */
    public static List<String> getAllHostId(String currentHostId){
        StringBuilder sb = new StringBuilder("select fsHostId from tbhost ");
        String bizCenterHostId = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);

        if(!TextUtils.equals(bizCenterHostId, currentHostId)){//副站点仅仅可以查看自己的数据
            sb.append("where fsHostId = '"+ currentHostId+"'");
        }else {
            sb.append(" where fiStatus= '1' and fsHostId not in ('cloudsite','localhost','mealorder')");
        }
        List<String> hostIDNames = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN,sb.toString());
        if (ListUtil.isEmpty(hostIDNames)){
            hostIDNames = new ArrayList<>();
        }
        hostIDNames.add(0,"无条件");
        return hostIDNames;

    }

    /**
     * 得到所有的桌台名称
     * @return
     */
    public static List<String> getAllTableName(){
        String sql = "select fsmtablename from tbmtable where fiStatus in (1,2)";
        List<String> tableNames = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN,sql);
        if (ListUtil.isEmpty(tableNames)){
            tableNames = new ArrayList<>();
        }
        tableNames.add(0,"无条件");
        return tableNames;
    }

}
