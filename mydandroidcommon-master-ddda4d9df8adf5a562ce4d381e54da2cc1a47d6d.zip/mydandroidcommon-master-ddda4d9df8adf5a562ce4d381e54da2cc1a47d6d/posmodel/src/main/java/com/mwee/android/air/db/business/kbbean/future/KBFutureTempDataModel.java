package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/10/22.
 */

public class KBFutureTempDataModel extends BusinessBean {


    /**
     * 就餐方式
     */
    public String dinnerType="";
    /**
     * 主键ID
     */
    public String id="";
    /**
     * 下单时间
     */
    public String orderTime="";
    /**
     * 门店id
     */
    public String shopGuid="";
    /**
     * 状态
     */
    public String status="";
    /**
     * 桌台号
     */
    public String tableNo="";
    /**
     * 第三方批次号
     */
    public String thirdBatchNo="";
    /**
     * 第三方订单号
     */
    public String thirdOrderId="";

    /**
     * 接单超时的绝对时间；
     * 超过这个时间，口碑侧将对本次推单做超时自动拒单处理。"
     */
    public String receiptTimeOut = "";

}
