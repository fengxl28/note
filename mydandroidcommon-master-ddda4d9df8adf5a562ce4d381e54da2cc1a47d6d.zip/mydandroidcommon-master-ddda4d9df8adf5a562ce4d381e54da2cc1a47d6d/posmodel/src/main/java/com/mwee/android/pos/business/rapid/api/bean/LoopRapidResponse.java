package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2017/4/5.
 */
public class LoopRapidResponse extends BasePosResponse {
    public List<RapidGetModel> data = new ArrayList<>();

    public LoopRapidResponse() {

    }
}
