package com.mwee.android.pos.business.shift.model;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

import java.math.BigDecimal;

/**
 * Created by virgil on 16/9/27.
 */

@TableInf(name = "order_pay_cache")
public class UnShiftModel extends DBModel {
    @ColumnInf(name = "ordernum")
    public int ordernum = 0;
    @ColumnInf(name = "payednum")
    public int payednum = 0;
    @ColumnInf(name = "totalAmount")
    public BigDecimal totalAmount = BigDecimal.ZERO;
    @ColumnInf(name = "shiftid")
    public String shiftid = "";
    @ColumnInf(name = "waiterid")
    public String waiterid = "";
    @ColumnInf(name = "shiftName")
    public String shiftName = "";
    @ColumnInf(name = "waitername")
    public String waiterName = "";
    @ColumnInf(name = "locked")
    public int locked = 0;  //--状态; 1未交班 / 2已交班

    public UnShiftModel() {

    }
}
