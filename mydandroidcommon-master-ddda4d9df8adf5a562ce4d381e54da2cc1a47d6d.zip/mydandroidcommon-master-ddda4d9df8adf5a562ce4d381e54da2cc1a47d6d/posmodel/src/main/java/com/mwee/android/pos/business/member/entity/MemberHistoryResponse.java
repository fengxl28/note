package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.component.member.net.model.MemberHistoryScoreModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/3/6.
 */

public class MemberHistoryResponse extends BusinessBean {
    public List<MemberHistoryScoreModel> list = new ArrayList<>();
    public int havenext = 0;  //havenext == 0 标识没有下一页数据

    public MemberHistoryResponse() {
    }
}
