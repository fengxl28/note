package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAddResponse;
import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.connect.business.menu.MenuDishAddResponse;
import com.mwee.android.air.connect.business.menu.MenuEditorResponse;
import com.mwee.android.air.connect.business.menu.MenuItemAddResponse;
import com.mwee.android.air.connect.business.menu.MenuItemBeanResponse;
import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageSetSideResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportResponse;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportResultResponse;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemListAllResponse;
import com.mwee.android.pos.connect.business.bean.MenuTemporaryResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public interface CMenuManager {
    @SocketParam(uri = "menuManager/loadMenuClsList", response = AllMenuClsAndMenuItemResponse.class)
    String loadMenuClsList(@SF("isLoadAllMenuItem") boolean isLoadAllMenuItem);

    /**
     * 美小易菜品管理首次加载
     *
     * @param isLoadAllMenuItem
     * @return
     */
    @SocketParam(uri = "menuManager/loadAirMenuManager", response = AllMenuClsAndMenuItemResponse.class)
    String loadAirMenuManager(@SF("isLoadAllMenuItem") boolean isLoadAllMenuItem, @SF("isContainSet") boolean isContainSet);


    /**
     * 美小易根据菜品分类加载菜品列表
     *
     * @param fsMenuClsId
     */
    @SocketParam(uri = "menuManager/loadAirMenuItemByClsId", response = MenuItemsResponse.class)
    void loadAirMenuItemByClsId(@SF("fsMenuClsId") String fsMenuClsId);


    /**
     * 美小易修改菜品信息
     *
     * @param fiItemCd
     * @param menuItemEditorBody
     */
    @SocketParam(uri = "menuManager/loadUpdateMenuItem", response = MenuEditorResponse.class)
    void loadUpdateMenuItem(@SF("fiItemCd") String fiItemCd,
                            @SF("menuItemEditorBody") MenuItemEditorBody menuItemEditorBody);

    /**
     * 美小易新增菜品
     *
     * @param menuItemEditorBody
     */
    @SocketParam(uri = "menuManager/loadAddMenuItem", response = MenuDishAddResponse.class)
    void loadAddMenuItem(@SF("menuItemEditorBody") MenuItemEditorBody menuItemEditorBody);

    /**
     * 获取菜品编辑的数据
     *
     * @param fiItemCd
     */
    @SocketParam(uri = "menuManager/loadMenuItemBean", response = MenuItemBeanResponse.class)
    void loadMenuItemBean(@SF("fiItemCd") String fiItemCd);

    @SocketParam(uri = "menuManager/loadMenuItemByClsId", response = MenuItemsResponse.class)
    void loadMenuItemsByClsId(@SF("fsMenuClsId") String fsMenuClsId);

    @SocketParam(uri = "menuManager/loadMenuClsUpdate", response = SocketResponse.class)
    void loadMenuClsUpdate(@SF("menuClsBean") MenuClsBean menuClsBean);

    @SocketParam(uri = "menuManager/loadMenuClsPrinters", response = MenuClsPrintersResponse.class)
    void loadMenuClsPrinters(@SF("fsMenuClsId") String fsMenuClsId);

    @SocketParam(uri = "menuManager/loadMenuClsAdd", response = MenuClsAddResponse.class)
    void loadMenuClsAdd(@SF("fsMenuClsName") String fsMenuClsName, @SF("printerNames") ArrayList<String> printerNames);

    @SocketParam(uri = "menuManager/loadMenuClsDelete", response = SocketResponse.class)
    void loadMenuClsDelete(@SF("fsMenuClsId") String fsMenuClsId);


    @SocketParam(uri = "menuManager/loadUpdateMenuInfo", response = SocketResponse.class)
    void loadUpdateMenuInfo(@SF("fiItemCd") String fiItemCd,
                            @SF("menuItemEditorBody") MenuItemEditorBody menuItemEditorBody);

    @SocketParam(uri = "menuManager/loadAddMenuInfo", response = MenuItemAddResponse.class)
    void loadAddMenuInfo(@SF("menuItemEditorBody") MenuItemEditorBody menuItemEditorBody);


    @SocketParam(uri = "menuManager/loadBatchDeleteMenuItems", response = SocketResponse.class)
    void loadBatchDeleteMenuItems(@SF("deleteMenuIds") ArrayList<String> deleteMenuIds);


    @SocketParam(uri = "menuManager/loadMenuPackageItems", response = MenuPackageItemsResponse.class)
    void loadMenuPackageItems(@SF("isLoadFirstDetailInfo") boolean isLoadFirstDetailInfo);

    @SocketParam(uri = "menuManager/loadMenuPackageSetSidesByMenuId", response = MenuPackageSetSideResponse.class)
    void loadMenuPackageSetSidesByMenuId(@SF("fiItemCd") String fiItemCd);

    @SocketParam(uri = "menuManager/loadUpdatePackageMenu", response = SocketResponse.class)
    void loadUpdatePackageMenu(@SF("fiItemCd") String fiItemCd,
                               @SF("name") String name,
                               @SF("price") String price,
                               @SF("vipPrice") String vipPrice,
                               @SF("fiIsPrePoint") int fiIsPrePoint,
                               @SF("fdLunchBoxCost") BigDecimal fdLunchBoxCost,
                               @SF("beans") List<MenuPackageSetSideBean> beans);

    @SocketParam(uri = "menuManager/loadAddMenuPackage", response = SocketResponse.class)
    void loadAddMenuPackage(@SF("name") String name,
                            @SF("price") String price,
                            @SF("vipPrice") String vipPrice,
                            @SF("fiIsPrePoint") int fiIsPrePoint,
                            @SF("fdLunchBoxCost") BigDecimal fdLunchBoxCost);

    @SocketParam(uri = "menuManager/loadDeleteMenuItemSetSide", response = SocketResponse.class)
    void loadDeleteMenuItemSetSide(@SF("fiSetFoodCd") String fiSetFoodCd);

    @SocketParam(uri = "menuManager/loadDeletePackageMenuItem", response = SocketResponse.class)
    void loadDeletePackageMenuItem(@SF("fiItemCd") String fiItemCd);

    @SocketParam(uri = "menuManager/loadMenuClsToTop", response = MenuClsToTopResponse.class)
    void loadMenuClsToTop(@SF("fsMenuClsId") String fsMenuClsId);

    /**
     * 菜品置顶
     *
     * @param itemId
     */
    @SocketParam(uri = "menuManager/loadMenuItemToTop", response = SocketResponse.class)
    void loadMenuItemToTop(@SF("fiItemCd") String itemId);

    /**
     * 获取临时菜属性
     *
     * @param fiItemCd
     */
    @SocketParam(uri = "dishes/loadMenuTempporaryModel", response = MenuTemporaryResponse.class)
    void loadMenuTempporaryModel(@SF("fiItemCd") String fiItemCd);

    /**
     * 检测本地菜品是否存在
     *
     * @param items
     */
    @SocketParam(uri = "menuManager/importMenuItem", response = TakeOutMenuImportResponse.class)
    void importMenuItem(@SF("items") List<TakeOutMenuItem> items);

    /**
     * 有已存在菜品时，导入外卖菜品
     */
    @SocketParam(uri = "menuManager/importTakeOutMenu", response = TakeOutMenuImportResponse.class)
    void importTakeOutMenu(@SF("items") List<TakeOutMenuItem> items);


    /**
     * 一键导入菜品是否成功
     */
    @SocketParam(uri = "menuManager/loopMenuImportResult", response = TakeOutMenuImportResultResponse.class)
    void loopMenuImportResult(@SF("takeawaySource") String takeawaySource);

    /**
     * 获取所有外卖平台未关联菜品列表数据(建店优化)
     */
    @SocketParam(uri = "menuManager/getExportMenuList", response = TakeOutMenuItemListAllResponse.class)
    void loadTakeOutMenuListAll();

}
