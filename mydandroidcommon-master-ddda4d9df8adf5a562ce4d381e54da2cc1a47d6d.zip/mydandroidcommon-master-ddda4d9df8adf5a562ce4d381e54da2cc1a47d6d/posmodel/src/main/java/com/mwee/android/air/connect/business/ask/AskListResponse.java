package com.mwee.android.air.connect.business.ask;

import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/1/30.
 */

public class AskListResponse extends BaseSocketResponse {
    public ArrayList<AirAskManageInfo> askList = new ArrayList<>();

    public AskListResponse() {
    }
}
