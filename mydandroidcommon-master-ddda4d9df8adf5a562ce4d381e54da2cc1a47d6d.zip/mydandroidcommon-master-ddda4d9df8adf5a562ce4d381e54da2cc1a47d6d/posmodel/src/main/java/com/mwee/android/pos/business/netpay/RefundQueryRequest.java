package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by lxx on 16/12/26.
 * 退款状态查询
 */
@HttpParam(httpType = HttpType.POST,
        method = "refundQuery",
        response = NetResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 40, saveToLog = true)
public class RefundQueryRequest extends BasePosRequest {
    public String pay_order = "";//支付单号",

    public RefundQueryRequest() {
    }

    @Override
    public RefundQueryRequest clone() {
        RefundQueryRequest cloneObj = null;
        try {
            cloneObj = (RefundQueryRequest) super.clone();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return cloneObj;
    }
}
