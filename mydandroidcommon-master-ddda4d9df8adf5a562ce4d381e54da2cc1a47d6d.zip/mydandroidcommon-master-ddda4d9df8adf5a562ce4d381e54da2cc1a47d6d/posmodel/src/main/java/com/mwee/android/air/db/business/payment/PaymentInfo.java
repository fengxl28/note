package com.mwee.android.air.db.business.payment;

import android.support.annotation.Size;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

import java.math.BigDecimal;

/**
 * @ClassName: PaymentInfo
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午2:53
 */
@TableInf(name = "tbpayment")
public class PaymentInfo extends DBModel {

    @ColumnInf(name = "fiIsForeign")
    public int fiIsForeign = 0;
    @ColumnInf(name = "fsUpdateUserName")
    public String fsUpdateUserName = "";
    @ColumnInf(name = "fiIsCalcPaid")
    public int fiIsCalcPaid = 0;
    @ColumnInf(name = "fiStatus")
    public int fiStatus = 0;
    @ColumnInf(name = "fiSortOrder")
    public int fiSortOrder = 0;
    @ColumnInf(name = "fiIsPremium")
    public int fiIsPremium = 0;
    @ColumnInf(name = "fiDataKind")
    public int fiDataKind = 0;
    @ColumnInf(name = "fsUpdateTime")
    public String fsUpdateTime = "";
    @ColumnInf(name = "fdExchangeRate")
    public BigDecimal fdExchangeRate = BigDecimal.ZERO;
    @ColumnInf(name = "fiIsCalcInvoice")
    public int fiIsCalcInvoice = 0;
    @ColumnInf(name = "fsShopGUID", primaryKey = true)
    public String fsShopGUID = "";
    @ColumnInf(name = "fsPaymentId", primaryKey = true)
    public String fsPaymentId = "";
    @ColumnInf(name = "fdDefaultPrice")
    public BigDecimal fdDefaultPrice = BigDecimal.ZERO;
    @ColumnInf(name = "fsPaymentTypeId")
    public String fsPaymentTypeId = "";
    @ColumnInf(name = "fsPaymentName")
    public String fsPaymentName = "";
    @ColumnInf(name = "fsUpdateUserId")
    public String fsUpdateUserId = "";
    @ColumnInf(name = "fsNote")
    public String fsNote = "";

    @Size(min = 1)
    @ColumnInf(name = "fscolor")
    public String fscolor = "";
    /**
     * 折扣率
     */
    @ColumnInf(name = "fdDiscountRate")
    public BigDecimal fdDiscountRate = BigDecimal.ZERO;
    /**
     * 折扣归属
     */
    @ColumnInf(name = "fsDiscountPaymentId")
    public String fsDiscountPaymentId = "";

    /**
     * 使用范围
     * 0: 所有菜品金额总和
     * 1:可打折菜品金额总和
     */
    @ColumnInf(name = "fiIsPartAmtDiscount")
    public int fiIsPartAmtDiscount = 0;

    @ColumnInf(name = "fsShortcutKey")
    public String fsShortcutKey = "";  //'快捷键',

    @ColumnInf(name = "fsHelpCode")
    public String fsHelpCode = "";   //'助记码',

    @ColumnInf(name = "fiIsEffectiveDate")
    public int fiIsEffectiveDate = 0;//'有效时间:0=无限制/1=固定时间',

    @ColumnInf(name = "fsStarDate")
    public String fsStarDate = "";//'开始时间',

    @ColumnInf(name = "fsEndDate")
    public String fsEndDate = "";//'结束时间',

    @ColumnInf(name = "sync")
    public int sync = 0;

    /**
     * 数据来源. 0, 后台; 1,Pos
     */
    @ColumnInf(name = "fiDataSource")
    public int fiDataSource = 0;

    public PaymentInfo() {
    }

    @Override
    public PaymentInfo clone() {
        PaymentInfo cloneObj = null;
        try {
            cloneObj = (PaymentInfo) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}
