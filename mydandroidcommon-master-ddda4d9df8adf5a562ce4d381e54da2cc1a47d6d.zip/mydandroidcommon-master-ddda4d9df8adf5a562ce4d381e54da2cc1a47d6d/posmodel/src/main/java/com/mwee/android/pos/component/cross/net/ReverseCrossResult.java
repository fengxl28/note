package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/4.
 */

public class ReverseCrossResult extends BusinessBean {
    public BigDecimal debtAmt = BigDecimal.ZERO;
    public String recordNo;
    /**
     * 信用额度
     */
    public BigDecimal creditAmt = BigDecimal.ZERO;
    /**
     * 未销账金额
     */
    public BigDecimal balanceAmt = BigDecimal.ZERO;
    /**
     * 可销额度
     */
    public BigDecimal canCrossAmt = BigDecimal.ZERO;

    public ReverseCrossResult() {

    }
}
