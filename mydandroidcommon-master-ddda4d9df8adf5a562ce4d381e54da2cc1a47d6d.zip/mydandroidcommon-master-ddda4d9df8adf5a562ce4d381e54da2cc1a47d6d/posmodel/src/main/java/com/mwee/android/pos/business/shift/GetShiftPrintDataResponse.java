package com.mwee.android.pos.business.shift;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.HashMap;

/**
 * Created by huangming on 18/8/5.
 *
 */
public class GetShiftPrintDataResponse extends BaseSocketResponse {

    public HashMap<String, Object> shiftPrintData;

    public GetShiftPrintDataResponse() {
    }

    public GetShiftPrintDataResponse(HashMap<String, Object> data) {
        shiftPrintData = data;
    }
}
