package com.mwee.android.pos.business.netpay;

import com.mwee.android.pos.business.netpay.model.BillOnlineModel;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;

/**
 * 在线订单查询接口 server响应数据对应实体
 * Created by qinwei on 2017/1/11.
 */

public class RapidPaySearchResponse extends BasePosResponse {

    public int errno;

    public int nextPage;
    public String data;
    public ArrayList<BillOnlineModel> orders;//用于存储 解析支付信息json的数据集合

    public int ordertype;

    public RapidPaySearchResponse() {
    }
}
