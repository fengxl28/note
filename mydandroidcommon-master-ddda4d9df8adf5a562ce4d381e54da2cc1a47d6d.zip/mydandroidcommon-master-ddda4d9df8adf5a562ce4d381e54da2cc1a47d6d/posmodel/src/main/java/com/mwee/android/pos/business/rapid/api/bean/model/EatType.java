package com.mwee.android.pos.business.rapid.api.bean.model;

/**
 * Created by virgil on 2017/7/24.
 */

public class EatType {
    /**
     * 堂食
     */
    public final static int EAT_IN = 1;

    /**
     * 外带
     */
    public final static int EAT_TAKE_OUT = 2;

}
