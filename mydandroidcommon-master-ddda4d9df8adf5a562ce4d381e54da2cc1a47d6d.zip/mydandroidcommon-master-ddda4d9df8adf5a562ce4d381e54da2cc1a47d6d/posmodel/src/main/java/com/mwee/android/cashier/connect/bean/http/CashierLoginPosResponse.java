package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.CashierLoginInfo;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class CashierLoginPosResponse extends BaseCashierPosResponse {
    public CashierLoginInfo data = new CashierLoginInfo();

    public CashierLoginPosResponse() {

    }
}
