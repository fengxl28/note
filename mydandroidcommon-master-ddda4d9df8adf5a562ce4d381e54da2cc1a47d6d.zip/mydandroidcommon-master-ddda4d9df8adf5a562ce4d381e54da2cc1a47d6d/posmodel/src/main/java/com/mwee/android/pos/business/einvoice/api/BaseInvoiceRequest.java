package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

import java.util.Map;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:票通宝基类
 */

public class BaseInvoiceRequest extends BasePosRequest {
    /**
     * 接口类型
     * queryInfo(查询该门店是否开通电子发票业务接口)
     * getPTBoxStatus（获取票通宝设备的状态）
     * edittaxrate(更新税率)
     * StockAndTaxRate(查询库存税率)
     */
    public String invoiceMethod;
    /**
     * 接口具体业务入参
     */
    public Map<String, String> data;


    @Override
    public String optBaseUrl() {
        return Constant.getInvoiceRequestUrl();
    }

    public BaseInvoiceRequest() {
    }
}
