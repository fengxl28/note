package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2018/5/30.
 */

public class GoodDetailModel extends BusinessBean {

    /**
     * 商品的编号
     */
    public String goods_id;

    /**
     * 商品数量
     */
    public BigDecimal quantity;

    /**
     * 商品名称
     */
    public String goods_name;

    /**
     * 商品单价，单位为 分
     * TODO 罗召欢说传菜品单价 价格要转换成分
     */
    public BigDecimal price;
}
