package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/7/17.
 * 取消挂账接口---还原额度
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18964575
 */
@HttpParam(httpType = HttpType.POST,
        method = "cancelCredit",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 60)
public class CancelHungRequest extends BaseCrossRequest {

    /**
     * 挂账单号
     */
    public String creditOrderId = "";

    public CancelHungRequest() {

    }
}
