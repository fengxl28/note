package com.mwee.android.pos.business.mall.model;

import com.mwee.android.base.net.BusinessBean;

public class UploadToMallModel extends BusinessBean {

    /**
     * 访问方式，0:http,1:https,2:ftp,3:ftps
     */
    public int accessmode;
    /**
     * 上传文件下载地址
     */
    public String fileurl = "";
    /**
     * 商场erp地址（eg, ftp-- 192.168.1.102, httpwebservice-- http://119.39.48.78:8089/TTPOS/sales.asmx）
     */
    public String serveraddress = "";
    public String requestparameter;

    public UploadToMallModel() {
    }
}
