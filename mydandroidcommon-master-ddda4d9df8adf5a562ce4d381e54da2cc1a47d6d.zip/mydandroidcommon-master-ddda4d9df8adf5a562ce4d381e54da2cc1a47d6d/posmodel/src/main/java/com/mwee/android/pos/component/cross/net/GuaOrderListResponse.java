package com.mwee.android.pos.component.cross.net;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2018/1/3.
 */

public class GuaOrderListResponse extends BasePosResponse {
    public Response<GuaOrder> data = new Response<>();

    public GuaOrderListResponse() {
    }
}
