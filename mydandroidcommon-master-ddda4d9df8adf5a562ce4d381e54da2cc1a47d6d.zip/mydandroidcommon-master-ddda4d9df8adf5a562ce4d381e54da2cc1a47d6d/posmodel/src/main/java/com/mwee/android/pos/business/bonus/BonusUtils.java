package com.mwee.android.pos.business.bonus;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.bonus.BonusUserModel;
import com.mwee.android.pos.util.ListUtil;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BonusUtils {

    /**
     * 复制提成信息
     *
     * @param menuItems      原菜品列表
     * @param bonusMenuItems 提成菜品列表
     */
    public static void copyBonusInfo(List<MenuItem> menuItems, List<MenuItem> bonusMenuItems) {
        if (ListUtil.isEmpty(bonusMenuItems) || ListUtil.isEmpty(menuItems)) {
            return;
        }
        for (MenuItem bonusItem : bonusMenuItems) {
            if (bonusItem == null || bonusItem.menuBiz == null) {
                continue;
            }
            for (MenuItem item : menuItems) {
                if (item == null || item.menuBiz == null) {
                    continue;
                }
                if (TextUtils.equals(item.menuBiz.uniq, bonusItem.menuBiz.uniq)) {
                    item.menuBiz.addConfig(128);
                    item.menuBiz.bonusAuthorizerId = bonusItem.menuBiz.bonusAuthorizerId;
                    item.menuBiz.bonusUserId = bonusItem.menuBiz.bonusUserId;
                    if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : item.menuBiz.selectedModifier) {
                            modifier.menuBiz.addConfig(128);
                            modifier.menuBiz.bonusAuthorizerId = bonusItem.menuBiz.bonusAuthorizerId;
                            modifier.menuBiz.bonusUserId = bonusItem.menuBiz.bonusUserId;
                        }
                    }
                }
            }
        }
    }

    /**
     * 给菜品设置提成人，包括其配料
     *
     * @param item        菜品
     * @param bonusUserId 提成人Id
     * @param authUserId  授权人Id
     */
    public static void setMenuItemBonusUser(MenuItem item, String bonusUserId, String authUserId) {
        if (item == null || item.menuBiz == null) {
            return;
        }
        item.menuBiz.addConfig(128);
        item.menuBiz.bonusUserId = bonusUserId;
        item.menuBiz.bonusAuthorizerId = authUserId;
        if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
            for (MenuItem modifier : item.menuBiz.selectedModifier) {
                if (modifier == null || modifier.menuBiz == null) {
                    continue;
                }
                modifier.menuBiz.addConfig(128);
                if (modifier.isBonus()) {
                    modifier.menuBiz.bonusUserId = bonusUserId;
                    modifier.menuBiz.bonusAuthorizerId = authUserId;
                } else {
                    modifier.menuBiz.bonusUserId = "";
                    modifier.menuBiz.bonusAuthorizerId = "";
                }
            }
        }
    }

    /**
     * 过滤出无重复fsUserId的提成人列表（不管BonusUserModel中的菜品信息），并排序
     *
     * @param allBonusUser 过滤前的列表
     * @return 过滤后的列表
     */
    public static List<BonusUserModel> filterBonusUserList(ArrayMap<String, MenuItem> selectMenuItems, ArrayMap<String, List<BonusUserModel>> allBonusUser) {
        List<BonusUserModel> result = new ArrayList<>();
        if (ListUtil.mapIsEmpty(allBonusUser)) {
            return result;
        }

        List<String> pureIds = new ArrayList<>();
        for (String uniq : selectMenuItems.keySet()) {
            MenuItem menuItem = selectMenuItems.get(uniq);
            if (menuItem == null) {
                continue;
            }
            String key = menuItem.currentUnit.fiItemCd + "_" + menuItem.currentUnit.fiOrderUintCd;
            List<BonusUserModel> userList = allBonusUser.get(key);
            if (!ListUtil.isEmpty(userList)) {
                for (BonusUserModel bonusUser : userList) {
                    if (pureIds.contains(bonusUser.fsUserId) || TextUtils.isEmpty(bonusUser.fsUserId)) {
                        continue;
                    }
                    result.add(bonusUser);
                    pureIds.add(bonusUser.fsUserId);
                }
            }
        }

        // 按提成人姓名A-Z排序
        Collator collator = Collator.getInstance();
        Comparator<BonusUserModel> comparator = (o1, o2) -> collator.compare(o1.fsUserName, o2.fsUserName);
        Collections.sort(result, comparator);
        return result;
    }
}
