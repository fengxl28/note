package com.mwee.android.air.db.business.account;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * @ClassName: AccountManageInfo
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午8:03
 */
public class AccountManageInfo extends DBModel {

    @ColumnInf(name = "fsUserId")
    public String fsUserId = "";

    @ColumnInf(name = "fsStaffId")
    public String fsStaffId = "";

    @ColumnInf(name = "fsUserName")
    public String fsUserName = "";

    @ColumnInf(name = "fsPwd")
    public String fsPwd = "";


    @ColumnInf(name = "fsCellphone")
    public String fsCellphone = "";


    /**
     * 允许折扣菜品 0： 不限 1： 指定
     */
    @ColumnInf(name = "fiIsDiscount")
    public int fiIsDiscount = 1;

    /**
     * 权限配置
     * 1. 开钱箱
     * 2. 结账
     * 3. 退款
     * 4. 报表
     * 16. 折扣
     */
    public int config;

    public boolean supportCashBox() {
        return (config & 1) == 1;
    }

    public boolean supportBill() {
        return (config & 2) == 2;
    }

    public boolean supportRefund() {
        return (config & 4) == 4;
    }

    public boolean supportReport() {
        return (config & 8) == 8;
    }

    public boolean supportDiscount() {
        return (config & 16) == 16;
    }
}
