package com.mwee.android.air.connect.business.advertising;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.connect.business.driver.BaseDriverRequest;

/**
 * created by 2018/8/21
 *
 * @author lxd
 * Description:启动页广告
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "loginApi/getStartUpImage",
        response = AirWelcomeAdvertisingResponse.class,
        timeOut = 3000)
public class AirWelcomeAdvertisingRequest extends BaseDriverRequest {

    public String dimension = "4:3";

    public AirWelcomeAdvertisingRequest() {
    }
}
