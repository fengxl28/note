package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.sync.EncryptUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/***
 * 网络支付结果查询
 * Created by lxx on 16/12/23.
 */
@HttpParam(httpType = HttpType.POST,
        method = "orderquery",
        response = NetResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 40, saveToLog = true)
public class PayQueryRequest extends BasePosRequest {

    public String pay_order = "";//支付单号",
    public int sourceid = 0; //业务ID

    public PayQueryRequest() {
    }

    @Override
    public PayQueryRequest clone() {
        PayQueryRequest cloneObj = null;
        try {
            cloneObj = (PayQueryRequest) super.clone();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return cloneObj;
    }
}
