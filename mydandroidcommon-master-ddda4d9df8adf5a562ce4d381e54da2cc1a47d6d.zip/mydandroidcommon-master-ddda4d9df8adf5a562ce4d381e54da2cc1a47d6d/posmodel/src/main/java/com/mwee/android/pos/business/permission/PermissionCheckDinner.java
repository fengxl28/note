package com.mwee.android.pos.business.permission;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 正餐的用户权限判断的工厂类
 * Created by virgil on 2017/2/13.
 */

public class PermissionCheckDinner {
    public static boolean hasPermission(String userId, String permission) {
        return Permission.hasPermissionDinner(userId, permission);
    }

    /*
    * 是否有换桌权限
    * */
    public static boolean canChangeTable(String userId) {
        return hasPermission(userId, Permission.DINNER_bnChangeTable);
    }

    /*
    * 是否有拼桌权限
    * */
    public static boolean canShareTable(String userId) {
        return hasPermission(userId, Permission.DINNER_bnShareTable);
    }

    /*
    * 是否有重打结账单权限
    * */
    public static boolean canRePrnBill(String userId) {
        return hasPermission(userId, Permission.DINNER_bnRePrnBill);
    }


    /*
    * 是否有反结账权限
    * */
    public static boolean canReCheckAuth(String userId) {
        return hasPermission(userId, Permission.DINNER_vReCheckAuth);
    }

    /*
    * 是否菜品沽清权限
    * */
    public static boolean canSetQty(String userId) {
        return hasPermission(userId, Permission.DINNER_bnSetQty);
    }

    /*
    * 是否有账单管理权限
    * */
    public static boolean canBillManage(String userId) {
        return hasPermission(userId, Permission.DINNER_bnBillManage);
    }


    /*
    * 是否有赠送权限
    * */
    public static boolean canGiftAuth(String userId) {
        return hasPermission(userId, Permission.DINNER_vGiftAuth);
    }

    /*
    * 用户是否有对discountId 有打折权限
    * */
    public static boolean canDiscountAuth(String userId, String discountId) {
        return Permission.hasDiscountPermission(userId, discountId);
    }

    public static boolean canDiscountAuth(String userId, String discountId, int rate) {
        return Permission.hasDiscountPermission(userId, discountId, rate);
    }

    /*
    * 是否有打样权限
    * */
    public static boolean canCloseStore(String userId) {
        return hasPermission(userId, Permission.DINNER_bnCloseStore);
    }


    /**
     * 是否有开钱箱的权限
     *
     * @param userId String
     * @return boolean
     */
    public static boolean canOpenMoneyBox(String userId) {
        return hasPermission(userId, Permission.DINNER_bnOpenBox);
    }

    /**
     * 是否有开台的权限
     *
     * @param userId String
     * @return boolean
     */
    public static boolean canOpenTable(String userId) {
        return hasPermission(userId, Permission.DINNER_bnOpenTable);
    }

    /**
     * 是否有结账的权限
     *
     * @param userId String
     * @return boolean
     */
    public static boolean hasPayPermission(String userId) {
        return hasPermission(userId, Permission.DINNER_bnSellCheck);
    }

    /*
    * 是否有打印预结单权限
    * */
    public static boolean canPrnExpBill(String userId) {
        return hasPermission(userId, Permission.DINNER_bnPrnExpBill);
    }

    /*
    * 是否有等叫权限
    * */
    public static boolean canWaitItem(String userId) {
        return hasPermission(userId, Permission.DINNER_bnWaitItem);
    }

    /*
    * 是否有改价授权
    * */
    public static boolean canPriceAuth(String userId) {
        return hasPermission(userId, Permission.DINNER_vPriceAuth);
    }

    /*
    * 是否有催菜权限
    * */
    public static boolean canHurryItem(String userId) {
        return hasPermission(userId, Permission.DINNER_bnHurryItem);
    }

    /*
    * 是否有退菜授权
    * */
    public static boolean canBackAuth(String userId) {
        return hasPermission(userId, Permission.DINNER_vBackAuth);
    }


    /*
   * 是否有转菜授权
   * */
    public static boolean canTurnAuth(String userId) {
        return hasPermission(userId, Permission.DINNER_vTurnAuth);
    }

    /*
    * 是否有起菜权限
    * */
    public static boolean canUpItem(String userId) {
        return hasPermission(userId, Permission.DINNER_bnUpItem);
    }


    /**
     * 是否有会员绑定权限
     * @param userId
     * @return
     */
    public static boolean canBindMember(String userId) {
        return hasPermission(userId, Permission.DINNER_vVIPBind);
    }

    /**
     * 是否有现金充值权限
     * @param userId
     * @return
     */
    public static boolean canMemberCash(String userId) {
        return hasPermission(userId, Permission.DINNER_vTempVIPAuth);
    }


    /**
     * 是否有称重改数授权
     * @return
     */
    public static boolean canQtyAuth(String userId){
        return hasPermission(userId, Permission.DINNER_vQtyAuth);
    }

    /**
     * 在线支付退款权限
     * @param userId
     * @return
     */
    public static boolean canPayRefund(String userId) {
        return hasPermission(userId, Permission.DINNER_vPaymentRefundAuth);
    }

    /**
     * 是否有站点维护的权限
     * @param userId
     * @return
     */
    public static boolean canMaintain(String userId){
        return hasPermission(userId, Permission.DINNER_vMaintain);
    }




    /**
     * 是否对fiItemCd菜品fiOrderUintCd规格有退菜权限
     *
     * @return boolean | true:有退菜权限；false：没有退菜权限
     */
    public static boolean canBackMenuItem(String fsUserId, String fiItemCd, String fiOrderUintCd) {
        String voidAll = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiIsRetreatFood from tbUser where fsUserId = '" + fsUserId + "'");
        if (TextUtils.equals(voidAll, "0") || TextUtils.isEmpty(voidAll)) {
            return true;
        }
        String info = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsUserId from  tbuserMenuItemRole where fsUserId = '" + fsUserId + "' and fiItemCd = '" + fiItemCd + "' and " +
                " fiOrderUintCd = '" + fiOrderUintCd + "' and fiStatus = 1 and fiType = 0");
        if (!TextUtils.isEmpty(info) && TextUtils.equals(voidAll, "1")) {
            return true;
        }
        return false;
    }

    /**
     * 是否对fiItemCd菜品fiOrderUintCd规格有赠送权限
     *
     * @return boolean | true:有赠菜权限；false：没有赠菜权限
     */
    public static boolean canGiftMenuItem(String fsUserId, String fiItemCd, String fiOrderUintCd) {
        String voidGift = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiisgift from tbUser where fsUserId = '" + fsUserId + "'");
        if (TextUtils.equals(voidGift, "0") || TextUtils.isEmpty(voidGift)) {
            return true;
        }
        String info = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsUserId from  tbuserMenuItemRole where fsUserId = '" + fsUserId + "' and fiItemCd = '" + fiItemCd + "' and " +
                " fiOrderUintCd = '" + fiOrderUintCd + "' and fiStatus = 1 and fiType = 1");
        if (!TextUtils.isEmpty(info) && TextUtils.equals(voidGift, "1")) {
            return true;
        }
        return false;
    }

    /**
     * 是否对fiOrderUintCd规格有折扣权限
     *
     * @return boolean | true:有折扣权限；false：没有折扣权限
     */
    public static boolean canUserDiscount(String fsUserId) {
        String voidDiscount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiIsDiscount from tbUser where fsUserId = '" + fsUserId + "'");
        if (TextUtils.equals(voidDiscount, "0") || TextUtils.isEmpty(voidDiscount)) {
            return true;
        }
        return false;
    }


    public static boolean canChangedNumber(String userId) {
        return hasPermission(userId, Permission.DINNER_vQtyAuth);
    }

    /**
     * 电子发票入口是否可见
     *
     * @return boolean | true:入口显示；false：入口隐藏
     */
    public static boolean canEinvoice(String userId){
        return hasPermission(userId, Permission.DINNER_bnEinvoice);
    }
}
