package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.order.BillNetOrderDetailReponse;
import com.mwee.android.air.connect.business.order.OrderDetailResponse;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataResponse;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * Created by liuxixiu on 2018/10/20.
 */

public interface CBiz {

    /**
     * 通知云端上送数据
     *
     * @return
     */
    @SocketParam(uri = "airBizDriver/uploadLocalChangeData", response = BaseSocketResponse.class)
    String uploadLocalChangeData();

    /**
     * 上送基础数据到云端并触发同步数据到C端
     *
     * @return
     */
    @SocketParam(uri = "airBizDriver/synchronousData", response = BaseSocketResponse.class, timeOut = 10 * 60)
    String dataSync();

    @SocketParam(uri = "airBizDriver/loadOrderDetail", response = OrderDetailResponse.class, timeOut = 10 * 60)
    String loadOrderDetail(@SF("orderId") String orderId);

    /**
     * air3.9菜品分类名称,菜品要求 修改后缓存菜品分类id列表,同步修改给口碑;
     *
     * @return
     */
    @SocketParam(uri = "airBizDriver/uploadDishType", response = BaseSocketResponse.class)
    String uploadDishType();

    /**
     * 获取账单管理口碑订单数据
     *
     * @param orderId
     * @return
     */
    @SocketParam(uri = "kb_driver/loadOrderFromCache", response = KPreOrderDataResponse.class)
    String loadOrderFromCache(@SF("orderId") String orderId);


}
