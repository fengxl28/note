package com.mwee.android.air.connect.business.active;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/7/16
 * description:美小易标准版 获取门店激活参数 响应
 */
public class ActiveParamsResponse extends BasePosResponse {
    public ActiveParamsBean data = new ActiveParamsBean();

    public ActiveParamsResponse() {
    }
}
