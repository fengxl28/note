package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by qinwei on 2017/10/22.
 */

public class MenuItemBeanResponse extends BaseSocketResponse {
    public MenuItemBean menuItemBean;

    public MenuItemBeanResponse() {
    }
}
