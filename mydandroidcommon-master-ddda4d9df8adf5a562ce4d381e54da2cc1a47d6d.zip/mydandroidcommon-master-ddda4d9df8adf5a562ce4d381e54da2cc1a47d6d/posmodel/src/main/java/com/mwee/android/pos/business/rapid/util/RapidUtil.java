package com.mwee.android.pos.business.rapid.util;

import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by virgil on 2018/1/18.
 *
 * @author virgil
 */

public class RapidUtil {

    /**
     * 解析秒付的总支付金额
     *
     * @param rapidPayment RapidPayment
     * @return BigDecimal
     */
    public static BigDecimal parseRapidPayTotalAmt(RapidPayment rapidPayment) {
        if (rapidPayment == null || ListUtil.isEmpty(rapidPayment.paymentList)) {
            return BigDecimal.ZERO;
        }
        return parseRapidPayTotalAmt(rapidPayment.paymentList);
    }

    public static BigDecimal parseRapidPayTotalAmt(List<RapidPayModel> paymentList) {
        BigDecimal totalPaied = BigDecimal.ZERO;
        if (ListUtil.isEmpty(paymentList)) {
            return totalPaied;
        }
        if (!ListUtil.isEmpty(paymentList)) {
            for (RapidPayModel temp : paymentList) {
                totalPaied = totalPaied.add(temp.fdReceMoney);
            }
        }
        return totalPaied;
    }

}
