package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:
 */
public class IsInvoiceActiveBean extends BusinessBean {
    /**
     * {"end_date":"2019-11-01",
     * "shop_id":"204018",
     * "start_date":"2018-11-01",
     * "state":"Y",
     * "state_reason":"SUCCESS",
     * "tax_rate_value":"6"}
     */
    /**
     * 商户id
     */
    public String shop_id = "";
    /**
     * 开票状态，N-未开通，Y-已开通
     */
    public String state = "";
    /**
     * 开票状态描述
     */
    public String state_reason = "";
    /**
     * 税率
     */
    public String tax_rate_value = "";
    /**
     * 服务起始日期，格式：yyyy-MM-dd
     */
    public String start_date = "";
    /**
     * 服务截止日期，格式：yyyy-MM-dd
     */
    public String end_date = "";


    public IsInvoiceActiveBean() {

    }
}
