package com.mwee.android.pos.business.member.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by virgil on 2017/3/17.
 */
@HttpParam(httpType = HttpType.POST,
        method = "transferstationtob",
        response = TicketSearchResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class TicketSearchRequest extends BaseMemberRequest {
    /**
     * 9now=>美味、dianping=>大众点评、dphui=>点评闪惠
     * nuomi=>百度糯米、fcp=>饭菜票、xibei=>西贝莜面、ylxl=>耶里夏丽
     */
    public String type = "";
    /**
     * 券号
     */
    public String sn = "";
    /**
     * 设备号
     */
    public String device_id = "";

    public TicketSearchRequest() {
        super("app.coupons.query");
    }
}
