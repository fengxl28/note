package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: RapidPayment
 * @Description: 秒点支付
 * @author: SugarT
 * @date: 16/11/13 下午8:31
 */
public class RapidPayment extends BusinessBean {
    /**
     * 秒点秒付的action
     */
    public String action = null;
    /**
     * 结账时间
     */
    public String paySuccessTime = "";
    /**
     * 餐厅名称
     */
    public String shopName = "";
    /**
     * 餐厅ID
     */
    public int shopId = 0;
    /**
     * 总店商家id
     */
    public int manageShopId = 0;
    /**
     * 桌台ID
     */
    public String tableNo = "";
    /**
     * 外部订单ID(账单号)
     */
    public String outerOrderId = "";
    /**
     * 订单ID(交易号)
     */
    public String orderId = "";
    /**
     * 支付方式列表
     */
    public List<RapidPayModel> paymentList = new ArrayList<>();
    /**
     * 会员卡号
     */
    public String fsMemberNo = "";
    /**
     * 会员卡号---- checkout特有的，在中控设置了非会员价拉单后，仍旧会返回会员卡号
     */
    public String fsWposMemberNo = "";
    /**
     * 会员模板ID
     */
    public String memberId = "";
    /**
     * plus卡ID
     */
    public String plusId = "";
    /**
     * plus卡名称
     */
    public String plusName = "";
    /**
     * 会员等级
     */
    public String memberLevel = "-1";

    /**
     * 是否使用会员价 0 ： 原价； 1：会员价
     */
    public int isVip = 0;

    /**
     * 会员储值余额
     */
    public String fsMemberCardAmount = "";

    /**
     * 会员积分
     */
    public String fsScore = "";

    /**
     * 发票类型
     */
    public int receiptType;//1:个人，2:公司

    /**
     * 发票公司名称
     */
    public String receiptName = "";

    /**
     * 公司税号
     */
    public String taxNo = "";
    /**
     * 业务类型
     * see{@link NetOrderType}
     */
    public int bizType = 0;
    /**
     * 来源类型(0外部第三方应用，1手机APP，2微信，3外卖，4旺POS，5美POS，6全能POS机，7盒子POS，8点菜宝代理，9点菜宝手持，10WIN POS，11拉卡拉，12秒付， 17秒点快餐)
     */
    public int sourceType = 0;

    /**
     * 订单ID(交易号)
     */
    public String rapidMenuOrderIdInner = "";

    /**
     * 用户ID
     */
    public String userId = "";

    /**
     * 付款是否使用会员价支付
     * pro3.4.1 对接中控快关"仅储值全额支付时享受会员价"
     * 默认-1 ：表示开关关闭--->走原有逻辑
     * 0：非会员价支付
     * 1：会员价支付
     */
    public int isVipPrice = -1;

    public RapidPayment() {

    }

//    public BigDecimal calcTotalAmt(){
//        BigDecimal result=BigDecimal.ZERO;
//    }
}
