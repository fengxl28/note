package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 获取当前用户手机号验证码
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11639815</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "loginApi/getUserMobileVerificationCode",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetVerifyCodePosResponse.class)
public class GetVerifyCodePosRequest extends BaseCashierPosRequest {
    public String userMobileNum;

    public GetVerifyCodePosRequest() {

    }

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierLoginUrl();
    }

    @Override
    public String encrypt(String data) {
        return data;
    }

    @Override
    public String decrypt(String data, int httpStatus) {
        return data;
    }
}
