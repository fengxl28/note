package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2017/9/18.
 * 服务员信息
 */

public class RapidEmployee extends BusinessBean {

    public String action = "";  //"开台", //可选， 操作类型：字符串“开台”、“下单”、“加菜”、”退菜“ 四者之一，目前仅需要开台的服务员即可
    public String empName = "";  //服务员姓名
    public String empNo = "";   //服务员工号 （如果有服务员，必传）

    public RapidEmployee() {

    }
}
