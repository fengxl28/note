package com.mwee.android.air.db.business.menu;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;

/**
 * 美收银菜品排序 查询所有分类以及 分类下所有菜品 然后进行排序
 * Created by qinwei on 2018/2/5.
 */

public class MenuClsSortBean extends DBModel {
    @ColumnInf(name = "fsMenuClsId")
    public String fsMenuClsId;
    @ColumnInf(name = "fsMenuClsName")
    public String fsMenuClsName = "";
    @ColumnInf(name = "fiSortOrder")
    public int fiSortOrder;

    /**
     * 分类下所有菜品
     */
    public ArrayList<MenuItemBean> menuItemBeans = new ArrayList<>();

    public MenuClsSortBean() {
    }
}
