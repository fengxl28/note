package com.mwee.android.pos.base;

import android.text.TextUtils;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import java.util.HashMap;
import java.util.Map;

public class CommonCache extends Cache {

    /**
     * 用户ID和用户名缓存
     */
    private Map<String,String> userMap = new HashMap<>();

    private static CommonCache mInstance;

    public static CommonCache getInstance(){
        if(mInstance == null){
            synchronized (CommonCache.class){
                if(mInstance == null){
                    mInstance = new CommonCache();
                }
            }
        }
        return mInstance;
    }

    public String getUserName(String userId){
        if(TextUtils.isEmpty(userId)){
            return "";
        }
        if(userMap == null){
            userMap = new HashMap<>();
        }
        String userName = userMap.get(userId);
        if(!TextUtils.isEmpty(userName)){
            return userName;
        }
        String sql = "select fsUserName from tbUser where fsUserId = '" + userId + "'";
        userName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        userMap.put(userId,userName);
        return userName;
    }

    @Override
    public void refresh() {
        if(userMap != null){
            userMap.clear();
        }
    }

    @Override
    public void clean() {
        if(userMap != null){
            userMap.clear();
        }
    }
}
