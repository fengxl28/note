package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * @author changsunhaipeng
 * @date 2018/7/5
 */

public class SupportPrinter extends BusinessBean {
    public String guid;
    public String shopGUID;
    public int printerId;
    public int printerType;
    public String printerBrand;
    public String printerNum;
    public String imageURL;
    public String suitableProd;
    public int status;
    public int dataKind;
    public int id;
}
