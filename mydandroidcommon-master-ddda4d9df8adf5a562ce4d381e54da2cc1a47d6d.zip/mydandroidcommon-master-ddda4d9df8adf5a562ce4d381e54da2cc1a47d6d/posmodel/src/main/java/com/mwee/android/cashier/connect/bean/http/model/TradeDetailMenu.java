package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.List;

/**
 * 订单详情的菜品
 * Created by virgil on 2018/2/5.
 */

public class TradeDetailMenu extends BusinessBean {
    /**
     * 菜品名称
     */
    public String itemName;
    /**
     * 菜品规格
     */
    public String orderUint;
    /**
     * 菜品的规格ID
     */
    public int orderUintCd;

    /**
     * 数量
     */
    public BigDecimal saleQty = BigDecimal.ZERO;
    /**
     * 菜品的售卖价
     */
    public BigDecimal price;

    /**
     * 是否是套餐
     */
    public boolean groupSale;

    /**
     * 套餐中的菜品
     */
    public List<TradeDetailMenu> itemDetailVOList;

    public TradeDetailMenu() {

    }

}
