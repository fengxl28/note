package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/10/29.
 */

public class ThirdOrderExt extends BusinessBean {
    /**
     * 是否使用口碑优惠
     */
    public String useOnlinePromotionFlag = "";

    /**
     * 回流给口碑桌号
     */
    public String tableNo = "";

    /**
     * 同步口碑订单状态
     */
    public String kbStatus = "";

    /**
     * 口碑商户id
     */
    public String merchantPid = "";

    /**
     * 口碑门店id
     */
    public String alipayShopId = "";
    /**
     * 口碑订单同步版本
     */
    public int orderSyncVersion;
    /**
     * 设备类型DESKTOP_POS   小猫PC_PLUGIN_IN
     */
    public String dvType = "DESKTOP_POS";
    /**
     * 设备sn号
     */
    public String dvSn = "";


    public ThirdOrderExt() {
    }
}
