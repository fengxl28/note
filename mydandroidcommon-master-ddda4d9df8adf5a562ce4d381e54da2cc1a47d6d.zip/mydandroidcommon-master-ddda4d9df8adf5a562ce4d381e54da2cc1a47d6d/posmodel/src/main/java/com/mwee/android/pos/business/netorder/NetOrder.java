package com.mwee.android.pos.business.netorder;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.constants.TempAppOrderConstant;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetailDBModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

/**
 * Created by virgil on 2018/1/18.
 */

public class NetOrder {
    public static void saveTempAppOrder(TempAppOrder tempAppOrder) {
        if (tempAppOrder != null) {
            if (!ListUtil.isEmpty(tempAppOrder.orderDetailList)) {
                DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from tempapporderdetails where orderId = '" + tempAppOrder.orderId + "'");

                for (TempAppOrderDetail tempAppOrderDetail : tempAppOrder.orderDetailList) {
                    if (tempAppOrderDetail != null) {
                        tempAppOrderDetail.uniq = UUIDUtil.optUUID();

                        if (!ListUtil.isEmpty(tempAppOrderDetail.modifiertypes)) {
                            for (TempAppOrderModifier tempAppOrderModifier : tempAppOrderDetail.modifiertypes) {
                                if (tempAppOrderModifier != null) {
                                    tempAppOrderModifier.uniq = UUIDUtil.optUUID();

                                    if (!ListUtil.isEmpty(tempAppOrderModifier.modifiers)) {
                                        for (TempModifierDetail tempModifierDetail : tempAppOrderModifier.modifiers) {
                                            if (tempModifierDetail != null) {
                                                tempModifierDetail.uniq = UUIDUtil.optUUID();
                                                //配料明细、套餐明细
                                                TempAppOrderDetailDBModel modifiersDetail = new TempAppOrderDetailDBModel();
                                                modifiersDetail.orderId = String.valueOf(tempAppOrder.orderId);
                                                modifiersDetail.orderDetailId = tempModifierDetail.uniq;
                                                modifiersDetail.parentID = tempAppOrderModifier.uniq;
                                                modifiersDetail.itemName = tempModifierDetail.modifierName;
                                                modifiersDetail.itemNum = tempModifierDetail.modifierNum;
                                                modifiersDetail.itemPrice = tempModifierDetail.modifierPrice;
                                                modifiersDetail.totalItemPrice = tempModifierDetail.modifierPrice;
                                                modifiersDetail.type = TempAppOrderConstant.MENU_TYPE_MODIFIER_DETAIL;
                                                modifiersDetail.body = JSON.toJSONString(tempModifierDetail);
                                                modifiersDetail.pokeNo = tempAppOrderDetail.pokeNo;
                                                modifiersDetail.replaceNoTrans();
                                            }
                                        }
                                        tempAppOrderModifier.modifiers.clear();
                                    }

                                    //菜品配料类型  0配料，1套餐
                                    TempAppOrderDetailDBModel modifiersType = new TempAppOrderDetailDBModel();
                                    modifiersType.orderId = String.valueOf(tempAppOrder.orderId);
                                    modifiersType.orderDetailId = tempAppOrderModifier.uniq;
                                    modifiersType.parentID = tempAppOrderDetail.uniq;
                                    modifiersType.itemName = tempAppOrderModifier.modifierTypeName;
                                    modifiersType.itemNum = BigDecimal.ONE;
                                    modifiersType.itemPrice = BigDecimal.ZERO;
                                    modifiersType.totalItemPrice = BigDecimal.ZERO;
                                    modifiersType.type = (tempAppOrderModifier.isSet == 0 ? TempAppOrderConstant.MENU_TYPE_MODIFIER_SET : TempAppOrderConstant.MENU_TYPE_MODIFIER_INGREDIENT);
                                    modifiersType.body = JSON.toJSONString(tempAppOrderModifier);
                                    modifiersType.pokeNo = tempAppOrderDetail.pokeNo;
                                    modifiersType.replaceNoTrans();
                                }
                            }
                            tempAppOrderDetail.modifiertypes.clear();
                        }

                        //菜品
                        TempAppOrderDetailDBModel itemDetail = new TempAppOrderDetailDBModel();
                        itemDetail.orderId = String.valueOf(tempAppOrder.orderId);
                        itemDetail.orderDetailId = tempAppOrderDetail.uniq;
                        itemDetail.parentID = "-1";
                        itemDetail.itemName = tempAppOrderDetail.itemName;
                        itemDetail.itemNum = new BigDecimal(tempAppOrderDetail.itemNum);
                        itemDetail.itemPrice = tempAppOrderDetail.itemPrice;
                        itemDetail.totalItemPrice = tempAppOrderDetail.totalItemPrice;
                        itemDetail.type = TempAppOrderConstant.MENU_TYPE_NORMAL;
                        itemDetail.body = JSON.toJSONString(tempAppOrderDetail);
                        itemDetail.pokeNo = tempAppOrderDetail.pokeNo;
                        itemDetail.replaceNoTrans();
                    }
                }
                tempAppOrder.orderDetailList.clear();
            }

            //合计
            if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                tempAppOrder.subTotal = tempAppOrder.total;
            }
            tempAppOrder.body = "";
            if (tempAppOrder.hasDeliveryInfo()) {
                tempAppOrder.deliveryStatus = tempAppOrder.deliveryInfo.mwDeliveryStatus;
            }
            tempAppOrder.body = JSON.toJSONString(tempAppOrder);
            tempAppOrder.replaceNoTrans();
        }
    }

    public static String getTackOutResouseName(String orderTakeawaySource) {
        if (TextUtils.isEmpty(orderTakeawaySource)) {
            return "";
        }
        String title = orderTakeawaySource;
        if (orderTakeawaySource.startsWith(TakeAwaySource.ELEME)) {
            title = "饿了么";
        } else if (orderTakeawaySource.startsWith(TakeAwaySource.BAIDU)) {
            title = "百度糯米";
        } else if (orderTakeawaySource.startsWith(TakeAwaySource.MEITUAN) ||
                TextUtils.equals(orderTakeawaySource, TakeAwaySource.MWMEITUAN)) {
            title = "美团";
        } else if (orderTakeawaySource.startsWith(TakeAwaySource.KOUBEI)) {
            title = "口碑";
        } else if (orderTakeawaySource.startsWith(TakeAwaySource.MWEE)) {
            title = "美味不用等";
        }

        return title;
    }

    /**
     * 外卖菜品的套餐信息
     *
     * @param modifiertypes
     * @return
     */
    public static String formatModifierNotes(List<TempAppOrderModifier> modifiertypes) {
        if (ListUtil.listIsEmpty(modifiertypes)) {
            return "";
        }
        // 套餐、配料
        StringBuilder stringBuilder = new StringBuilder("-");
        for (TempAppOrderModifier tempAppOrderModifier : modifiertypes) {
            if (tempAppOrderModifier == null || ListUtil.isEmpty(tempAppOrderModifier.modifiers)) {
                continue;
            }
            for (TempModifierDetail tempModifierDetail : tempAppOrderModifier.modifiers) {
                stringBuilder.append(tempModifierDetail.modifierName).append("*").append(tempModifierDetail.modifierNum).append(";");
            }
        }
        String notes = stringBuilder.toString();
        if (!TextUtils.isEmpty(notes) && !TextUtils.equals("-", notes)) {
            return notes;
        }
        return "";
    }
}
