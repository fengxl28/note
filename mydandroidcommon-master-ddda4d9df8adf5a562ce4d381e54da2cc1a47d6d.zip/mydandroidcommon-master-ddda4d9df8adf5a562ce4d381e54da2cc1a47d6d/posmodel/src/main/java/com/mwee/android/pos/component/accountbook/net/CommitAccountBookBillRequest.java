package com.mwee.android.pos.component.accountbook.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.MallProtocolResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 提交账套-订单关系
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31608673
 */
@HttpParam(httpType = HttpType.POST,
        method = "ab/insertDetailList",
        response = CommitAccountBookBillResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 300)
public class CommitAccountBookBillRequest extends BasePosRequest {

    public String requestId = UUIDUtil.optUUID();

    /**
     * 账套id
     */
    public String accountBookId = "";
    /**
     * 账套名
     */
    public String accountBookName = "";
    /**
     * 门店id
     */
    public String shopGuid = "";
    /**
     * 营业日期
     */
    public String sellDate = "";
    /**
     * 订单号列表
     */
    public List<String> sellNos = new ArrayList<>();

    public CommitAccountBookBillRequest() {

    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrl();
    }
}
