package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * @Description:
 * @author: Xiaolong
 * @Date: 2018/4/2
 */
public class SyncBaseDataResponse extends BaseSocketResponse {

    public String xmppSession;
}
