package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2017/7/21.
 */
@HttpParam(httpType = HttpType.POST,
        method = "getScanPaymentOrderInfo",
        response = ScanPaymentOrderResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class ScanPaymentOrderRequest extends BasePosRequest {
    public String startTime;//开始时间
    public String endTime;//结束时间

    public int pageNo;//页码，用作分页的页码，第一页为1；不填则表示1
    public int pageSize;//每页显示条数，不填默认每页10条

    public ScanPaymentOrderRequest() {
    }
}
