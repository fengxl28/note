package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by virgil on 2017/5/11.
 *
 */

public class RapidOrderItemBase extends BusinessBean {
    /**
     * 菜品名称
     */
    public String itemName = "";
    /**
     * 菜品名称
     */
    public String name = "";
    /**
     * 菜品规格名称
     */
    public String unit = "";
    /**
     * 菜品唯一码
     */
    public String commitId = "";
    /**
     * 第三方系统菜品ID(后台菜品id)
     */
    public String outerItemId = "";
    /**
     * 菜品数量，可称重菜允许小数
     */
    public BigDecimal itemNum = BigDecimal.ZERO;
    /**
     * 菜品单价
     */
    public BigDecimal itemPrice = BigDecimal.ZERO;
    /**
     * 菜品会员价
     */
    public BigDecimal itemMemPrice = BigDecimal.ZERO;

    public RapidOrderItemBase() {

    }
}
