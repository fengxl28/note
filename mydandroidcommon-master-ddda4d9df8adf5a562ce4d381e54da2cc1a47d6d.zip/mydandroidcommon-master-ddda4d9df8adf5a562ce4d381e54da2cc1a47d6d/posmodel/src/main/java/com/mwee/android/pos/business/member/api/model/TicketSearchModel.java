package com.mwee.android.pos.business.member.api.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * 验券查询的Model
 * Created by virgil on 2017/3/17.
 */

public class TicketSearchModel extends BusinessBean {
    /**
     * 优惠码
     */
    public String sn = "";
    /**
     * 优惠券金额
     */
    public BigDecimal price = BigDecimal.ZERO;
    /**
     * 团购券
     */
    public String deal_title = "";
    /**
     * 团购券id
     */
    public int deal_id = 0;

    public TicketSearchModel() {

    }
}
