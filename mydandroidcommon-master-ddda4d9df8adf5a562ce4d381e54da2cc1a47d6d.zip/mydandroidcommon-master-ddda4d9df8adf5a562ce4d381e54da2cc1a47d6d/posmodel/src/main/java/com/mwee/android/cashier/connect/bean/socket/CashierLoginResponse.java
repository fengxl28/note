package com.mwee.android.cashier.connect.bean.socket;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.discount.CouponBargainModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class CashierLoginResponse extends BaseSocketResponse {
    /**
     * 是否需要跳转到门店注册页面
     */
    public int needRegister = 0;
    /**
     * 登录成功返回的Session
     */
    public String session = "";
    /**
     * 美收银操作的站点
     */
    public String hostID = "";
    /**
     * 云端数据版本
     */
    public String newTimeTag = null;

    /**
     * 当前的餐段
     */
    public String currentSectionId;

    /**
     * 增量的基础配置数据
     */
    public String datas = null;
    public String shiftID;
    /**
     * 餐厅设置（存放在Meta的设置）
     */
    public List<JSONObject> dinnerLocalSettings = null;
    /**
     * 餐厅设置，存放在tbparamValue的设置
     */
    public List<ParamvalueDBModel> dinnerDBSettings = null;
    /**
     * 特价列表
     */
    public List<CouponBargainModel> couponBargainList = new ArrayList<>();

    public UserDBModel userDBModel = null;

    public CashierLoginResponse() {

    }
}
