package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/1/2.
 */
@HttpParam(httpType = HttpType.POST,
        method = "queryAccounts",
        response = CreditAccountListResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 1000)
public class CreditAccountListRequest extends BaseCrossRequest {

    /**
     * 当前页号
     */
    public int currentPage;
    /**
     * 页记录数
     */
    public int pageSize;


    /**
     * 营业日期
     */
    public String sellDate;
    /**
     * 挂账拼音检索
     */
    public String accountName;
    /**
     * 状态 1:正常 13：删除
     */
    public String status = "1";

    public CreditAccountListRequest() {

    }
}
