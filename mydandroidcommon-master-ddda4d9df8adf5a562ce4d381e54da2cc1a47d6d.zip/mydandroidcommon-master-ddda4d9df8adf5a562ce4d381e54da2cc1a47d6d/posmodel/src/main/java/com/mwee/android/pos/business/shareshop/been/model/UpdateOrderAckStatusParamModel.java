package com.mwee.android.pos.business.shareshop.been.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/3/29.
 */

public class UpdateOrderAckStatusParamModel extends BusinessBean {
    /**
     * 1处理成功，-1处理失败
     */
    public int ackStatus = 0;

    /**
     * 网络订单号
     */
    public String orderId = "";

    public UpdateOrderAckStatusParamModel() {
    }
}
