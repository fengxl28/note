package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

public class MenuClsAndMenuPackagesResponse extends BaseSocketResponse {

    public List<MenuClsBean> menuClsBeanList = new ArrayList<>();

    public MenuClsAndMenuPackagesResponse() {

    }
}
