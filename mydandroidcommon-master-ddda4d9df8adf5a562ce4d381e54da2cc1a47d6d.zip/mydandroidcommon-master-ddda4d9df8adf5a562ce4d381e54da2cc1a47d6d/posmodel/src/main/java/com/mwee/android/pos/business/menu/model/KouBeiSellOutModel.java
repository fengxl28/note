package com.mwee.android.pos.business.menu.model;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28649042
 */
public class KouBeiSellOutModel extends DBModel {

    /**
     * 菜品id
     */
    @ColumnInf(name = "fiItemCd")
    public String itemCd = "";

    //库存数量
    @ColumnInf(name = "fdInvQty")
    public BigDecimal invQty;

    @ColumnInf(name = "fiOrderUintCd")
    public int orderUnitCd;

    public KouBeiSellOutModel() {
    }
}
