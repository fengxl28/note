package com.mwee.android.cashier.connect.bean.http;

/**
 * see{@link GetMealNoPosRequest}
 * Created by virgil on 2018/2/3.
 *
 * @author virgil
 */

public class GetMealNoPosResponse extends BaseCashierPosResponse {
    /**
     * 牌号
     */
    public String data;
}
