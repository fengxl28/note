package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.SupportPrinterList;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetSupportPrinterListResponse extends BaseCashierPosResponse {
    public SupportPrinterList data;

    public GetSupportPrinterListResponse() {
    }
}
