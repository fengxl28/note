package com.mwee.android.air.connect.business.menu;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

public class MenuClsAddResponse extends BaseSocketResponse {

    public String menuClsId = "";
    public String name = "";

    public MenuClsAddResponse() {

    }
}
