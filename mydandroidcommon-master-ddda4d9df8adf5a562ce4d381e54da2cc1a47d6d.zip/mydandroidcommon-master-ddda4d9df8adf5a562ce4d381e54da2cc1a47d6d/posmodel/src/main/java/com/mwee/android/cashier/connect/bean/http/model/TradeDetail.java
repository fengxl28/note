package com.mwee.android.cashier.connect.bean.http.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.List;

/**
 * 流水详情
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class TradeDetail extends BusinessBean {
    /**
     * 订单头
     */
    @JSONField(name = "orderPaymentResponseVO")
    public List<TradeDetailHead> orderHead;
    /**
     * 菜品列表
     */
    @JSONField(name = "itemList")
    public List<TradeDetailMenu> itemList;
    /**
     * 是否可以反结账
     */
    @JSONField(name = "settleMent")
    public boolean canRePay = false;
    public int sellType = 0;

    /**
     * 结算时间
     */
    public String checkEndTime;
    /**
     * 收款金额
     */
    public BigDecimal payAmt;
    /**
     * 出售日
     */
    public String sellDate;
    public String sellNo;
    public String shopGUID;
    /**
     * 1、申请中，2、退款成功，3、退款失败，0、未进行退款操作,
     */
    public int paybackStatus;

    public TradeDetail() {

    }
}
