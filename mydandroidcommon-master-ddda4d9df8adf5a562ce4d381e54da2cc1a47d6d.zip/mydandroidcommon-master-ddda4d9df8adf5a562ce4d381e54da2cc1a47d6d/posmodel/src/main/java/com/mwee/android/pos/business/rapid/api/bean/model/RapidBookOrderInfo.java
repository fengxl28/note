package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2017/7/12.
 */

public class RapidBookOrderInfo extends BusinessBean {

    public String orderTime = "";//就餐日期
    public String phone = "";//电话
    public int peopleCount = 1;//就餐人数
    public String name = ""; //顾客姓名
    public BigDecimal deposit = BigDecimal.ZERO;  // 定金

    public RapidBookOrderInfo() {
    }
}
