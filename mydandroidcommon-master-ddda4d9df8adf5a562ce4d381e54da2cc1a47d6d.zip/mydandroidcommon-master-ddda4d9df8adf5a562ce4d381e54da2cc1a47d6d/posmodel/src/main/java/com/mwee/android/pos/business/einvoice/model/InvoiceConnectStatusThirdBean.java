package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/5/8
 * description:票通宝连接状态
 */
public class InvoiceConnectStatusThirdBean extends BusinessBean {
    /**
     * 票通宝连接状态 0 已连接 1 未连接
     */
    public String extensionStatus;
    /**
     * 分机号
     */
    public String extensionNum;

    public InvoiceConnectStatusThirdBean() {

    }
}
