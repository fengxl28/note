package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * 销账记录数据模型
 * Created by qinwei on 2018/1/3.
 */

public class CrossOrder extends BusinessBean {
    /**
     * 授权人Id
     */
    public String authorizedUserId;
    /**
     * 授权人
     */
    public String authorizedUserName;
    /**
     * 销账余额
     */
    public BigDecimal balance = BigDecimal.ZERO;
    /**
     * 1:正常销帐,2:反销账
     */
    public int bussinessStatus;
    /**
     * 总店id
     */
    public String companyGuid;
    /**
     * 创建时间
     */
    public long createTime;
    /**
     * 操作人id
     */
    public String createUserId;
    /**
     * 操作人名称
     */
    public String createUserName;
    /**
     * 挂账人id
     */
    public String creditAccountId;
    /**
     * 挂账人
     */
    public String creditAccountName;
    /**
     * 销账金额
     */
    public BigDecimal crossAccountAmt = BigDecimal.ZERO;
    /**
     * 记录编号
     */
    public int id;
    /**
     * '0:可以反销账,1:不可以反销账'
     */
    public int isReverse;
    /**
     * 备注
     */
    public String note;
    /**
     * 支付方式id
     */
    public String paymentId;
    /**
     * 支付方式
     */
    public String paymentName;
    /**
     * 流水号
     */
    public String recordNo;
    /**
     * 请求id
     */
    public String requestId;
    /**
     * 反销账原记录ID
     */
    public int reverseCrossId;
    /**
     * 门店编号
     */
    public String shopGuid;
    /**
     * '1:正常,13:逻辑删除',
     */
    public int status;
    /**
     * 更新时间
     */
    public long updateTime;

    public CrossOrder() {
    }
}
