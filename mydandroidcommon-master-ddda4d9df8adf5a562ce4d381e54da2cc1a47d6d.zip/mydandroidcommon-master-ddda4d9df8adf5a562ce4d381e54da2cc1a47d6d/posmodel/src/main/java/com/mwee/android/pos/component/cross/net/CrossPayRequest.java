package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by qinwei on 2018/1/2.
 */
@HttpParam(httpType = HttpType.POST,
        method = "crossAccount",
        response = CrossPayResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 1000)
public class CrossPayRequest extends BaseCrossRequest {
    /**
     * 请求编号
     */
    public String requestId;
    /**
     * 挂账对象Id
     */
    public String creditAccoutId;
    /**
     * 挂账对象姓名
     */
    public String creditAccountName;
    /**
     * 销账金额
     */
    public BigDecimal crossAccountAmt = BigDecimal.ZERO;
    /**
     * 操作人Id
     */
    public String createUserId;
    /**
     * 操作人
     */
    public String createUserName;
    /**
     * 授权人Id
     */
    public String authorizedUserId;
    public String authorizedUserName;
    /**
     * 备注
     */
    public String note;
    /**
     * 订单号：指定订单号销账时会给值
     */
    public String sellNo;
    /**
     * 销账列表
     */
    public ArrayList<CrossPayData> accountPaymentList = new ArrayList<>();
    public String sellDate;


    public CrossPayRequest() {

    }
}
