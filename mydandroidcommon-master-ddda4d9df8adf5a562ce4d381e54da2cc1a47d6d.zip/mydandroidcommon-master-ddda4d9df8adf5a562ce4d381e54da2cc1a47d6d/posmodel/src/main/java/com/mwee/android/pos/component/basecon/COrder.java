package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.component.member.newInterface.net.NewMemberQueryEntityCardNumBerResponse;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.bean.CheckCardTypeResponse;
import com.mwee.android.pos.connect.business.bean.NewMemberRechargResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.business.order.GetOrderTokenResponse;
import com.mwee.android.pos.connect.business.order.GetSellOutGroupByMenuClsResponse;
import com.mwee.android.pos.connect.business.order.GetSellOutResponse;
import com.mwee.android.pos.connect.business.order.SetSellOutGroupByMenuClsResponse;
import com.mwee.android.pos.connect.business.order.SetSellOutResponse;
import com.mwee.android.pos.connect.business.order.model.SellOutMenuClsViewModel;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.pay.PreparePaySessionResponse;
import com.mwee.android.pos.connect.business.print.PrintSelloutResponse;
import com.mwee.android.pos.connect.business.print.ReprintBillReceptResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.math.BigDecimal;

/**
 * Created by virgil on 2017/8/11.
 */

public interface COrder extends CBase {
    /**
     * 获取所有支付方式
     *
     * @param orderid String
     * @return String
     */
    @SocketParam(uri = "billDriver/preparePay", response = PreparePaySessionResponse.class)
    String submitFastOrder(@SF("orderid") String orderid);

    /**
     * 获取所有支付方式
     *
     * @param orderid String
     * @return String
     */
    @SocketParam(uri = "billDriver/preparePay", response = PreparePaySessionResponse.class)
    String selectMenu(@SF("orderid") String orderid, @SF("MenuItem menu") MenuItem menu);

    /**
     * 查询会员信息
     *
     * @param number String  卡号或者手机号
     * @return String
     */
    @SocketParam(uri = "ordersync/queryMemberInfo", response = QueryMemberInfoResponse.class, timeOut = 60)
    String queryMemberInfo(@SF("number") String number);

    /**
     * 第三方会员卡号与美味会员卡号绑定---已废弃
     *
     * @param thirdNumber 第三方会员卡号
     * @param mwNumber    美味会员卡号
     */
    @Deprecated
    @SocketParam(uri = "ordersync/thirdMemberBind", response = BaseSocketResponse.class, timeOut = 60)
    String thirdMemberBind(@SF("thirdNumber") String thirdNumber, @SF("mwNumber") String mwNumber);

    /**
     * 会员开卡
     *
     * @param cardType         卡类型 0：虚拟卡； 1：手机号激活； 2：不记名激活
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @param nameValue        姓名
     * @param sex              性别
     * @param birthdayValue    生日
     * @return
     */
    @SocketParam(uri = "ordersync/memberBindCard", response = BaseSocketResponse.class, timeOut = 60)
    String memberBindCard(@SF("cardType") String cardType, @SF("cardNumber") String cardNumber, @SF("phone") String phone,
                          @SF("verificationCode") String verificationCode, @SF("nameValue") String nameValue,
                          @SF("sex") int sex, @SF("birthdayValue") String birthdayValue);

    /**
     * 检查卡类型
     *
     * @param cardNumber 卡号
     * @return
     */
    @SocketParam(uri = "newMemberDriver/checkCardType", response = CheckCardTypeResponse.class, timeOut = 60)
    String checkCardType(@SF("cardNumber") String cardNumber);

    /**
     * 激活不记名卡
     *
     * @param cardNumber 卡号
     * @return
     */
    @SocketParam(uri = "newMemberDriver/activeNoNameCard", response = BaseSocketResponse.class, timeOut = 60)
    String activeNoNameCard(@SF("cardNumber") String cardNumber);

    /**
     * * 查询相关的实体卡号
     *
     * @param cardNo 会员卡号
     * @return
     */
    @SocketParam(uri = "ordersync/queryEntityCardBy", response = NewMemberQueryEntityCardNumBerResponse.class, timeOut = 60)
    String queryEntityCardBy(@SF("cardNo") String cardNo);

    /**
     * 查询并绑定会员信息到订单上
     *
     * @param orderid           String 订单号
     * @param number            String  卡号或者手机号
     * @param isUsedMemberPrice
     * @return String
     */
    @SocketParam(uri = "ordersync/queryAndBindMemberToOrder", response = QueryMemberInfoAndBindToOrderResponse.class, timeOut = 60)
    String queryAndBindMemberToOrder(@SF("orderId") String orderid, @SF("number") String number, @SF("isUsedMemberPrice") boolean isUsedMemberPrice);

    /**
     * 查询并绑定会员信息到订单上
     *
     * @param orderid           String 订单号
     * @param number            String  卡号或者手机号
     * @param isUsedMemberPrice
     * @return String
     */
    @SocketParam(uri = "ordersync/queryAndBindMemberToOrderForCode", response = QueryMemberInfoAndBindToOrderResponse.class, timeOut = 60)
    String queryAndBindMemberToOrder(@SF("orderId") String orderid, @SF("number") String number, @SF("code") String code, @SF("isUsedMemberPrice") boolean isUsedMemberPrice);

    /**
     * 解绑会员信息
     *
     * @param orderid String 订单号
     * @param cardNo  String  会员卡号
     * @return String
     */
    @SocketParam(uri = "ordersync/orderUnBindMenberInfo", response = ChangeOrderWithMemberResponse.class, timeOut = 60)
    String orderUnBindMenberInfo(@SF("orderId") String orderid, @SF("cardNo") String cardNo);


    /**
     * 更新信息沽清
     *
     * @param data SellOutViewModel
     * @return String
     */
    @SocketParam(uri = "ordersync/updateSellOut", response = SetSellOutResponse.class)
    String updateSellOut(@SF("data") SellOutViewModel data);

    /**
     * 更新信息沽清
     *
     * @param data SellOutViewModel
     * @return String
     */
    @SocketParam(uri = "ordersync/updateSellOutUnderMenuCls", response = SetSellOutGroupByMenuClsResponse.class)
    String updateSellOutUnderMenuCls(@SF("data") SellOutViewModel data);

    /**
     * 沽清菜品分类
     */
    @SocketParam(uri = "ordersync/updateSellOutMenuCls", response = SetSellOutGroupByMenuClsResponse.class)
    String updateSellOutMenuCls(@SF("data") SellOutMenuClsViewModel data,
                                @SF("sellOutStatus") int sellOutStatus,
                                @SF("sellOutType") int sellOutType,
                                @SF("fdInvQty") BigDecimal fdInvQty);

    /**
     * 更新信息沽清
     *
     * @param fiOrderUintCd int
     * @param clearAll      boolean | 全部沽清
     * @return String
     */
    @SocketParam(uri = "ordersync/cancelSellOut", response = SetSellOutResponse.class)
    String cancelSellOut(@SF("fiOrderUintCd") String fiOrderUintCd,
                         @SF("clearAll") boolean clearAll);

    /**
     * 按菜品分类沽清
     *
     * @return String
     */
    @SocketParam(uri = "ordersync/cancelSellOutByMenuCls", response = SetSellOutGroupByMenuClsResponse.class)
    String cancelSellOutByMenuCls(@SF("sellOutMenuCls") SellOutMenuClsViewModel sellOutMenuCls);

    /**
     * 得到订单的token
     *
     * @param orderID
     * @return
     */
    @SocketParam(uri = "ordersync/getOrderToken", response = GetOrderTokenResponse.class)
    String GetOrderTokenRequest(@SF("orderID") String orderID);


    /**
     * 获取估清数据
     *
     * @param onlyGetViewModel
     * @return
     */
    @SocketParam(uri = "ordersync/getSellOut", response = GetSellOutResponse.class)
    String GetSellOutRequest(@SF("onlyGetViewModel") boolean onlyGetViewModel);

    /**
     * 获取估清数据
     */
    @SocketParam(uri = "ordersync/getSellOutGroupByMenuCls", response = GetSellOutGroupByMenuClsResponse.class)
    String getSellOutGroupByMenuClsRequest();

    /**
     * 重打结账单小票
     *
     * @param fsSellNo 订单号
     * @return
     */
    @SocketParam(uri = "ordersync/reprinterBillRecept", response = ReprintBillReceptResponse.class)
    String reprinterBillRecept(@SF("fsSellNo") String fsSellNo, @SF("businessDate") String businessDate, @SF("fiSellType") String fiSellType, @SF("orderSource") String orderSource);

    /**
     * 添加账单备注
     *
     * @param orderId String | 订单号
     * @param note    String | 备注
     * @return String
     */
    @SocketParam(uri = "ordersync/addOrderNote", response = ReprintBillReceptResponse.class)
    String addOrderNote(@SF("orderId") String orderId, @SF("note") String note);

    /**
     * 打印沽清报表
     *
     * @return
     */
    @SocketParam(uri = "ordersync/printSellout", response = PrintSelloutResponse.class)
    String printSellout();

    /**
     * 会员充值
     *
     * @return
     */
    @SocketParam(uri = "memberDriver/sendOnlineRechargeRequest", response = NewMemberRechargResponse.class, timeOut = 860)
    String sendOnlineRechargeRequest(@SF("ruleID") int ruleID, @SF("amount") BigDecimal amount,
                                     @SF("pay_code") String pay_code, @SF("payType") int payType,
                                     @SF("micro") String micro, @SF("cardNo") String cardNo);

    /**
     * 查询会员充值结果
     *
     * @return
     */
    @SocketParam(uri = "memberDriver/queryOnlineRechargeRequest", response = NewMemberRechargResponse.class, timeOut = 60)
    String queryOnlineRechargeRequest(@SF("tradeNo") String tradeNo);


}
