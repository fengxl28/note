package com.mwee.android.pos.business.member;

import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;

/**
 * Created by virgil on 2017/4/18.
 */
@Deprecated
public interface IMemberRefund {
    void callBack(boolean result,String msg,MemberOrderRefundRequest request,boolean containsMemberDiscountFinal);
}
