package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/4.
 */

public class CrossPayData extends BusinessBean {
    /**
     * 支付渠道
     */
    public String paymentChannel;
    /**
     * 支付类型Id
     */
    public String paymentTypeId;
    /**
     * 支付方式Id
     */
    public String paymentId;
    /**
     * 支付方式名称
     */
    public String paymentName;
    /**
     * 支付单号
     */
    public String paymentNo;

    /**
     * 支付金额
     */
    public BigDecimal paymentAmt = BigDecimal.ZERO;
    /**
     * 销账金额
     */
    public BigDecimal crossAccountAmt = BigDecimal.ZERO;


    public CrossPayData() {
    }
}
