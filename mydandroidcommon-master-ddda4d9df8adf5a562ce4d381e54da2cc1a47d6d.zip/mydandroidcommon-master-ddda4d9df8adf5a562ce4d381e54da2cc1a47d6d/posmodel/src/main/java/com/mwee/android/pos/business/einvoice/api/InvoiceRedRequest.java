package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;

/**
 * @ClassName: InvoiceRedRequest
 * @Description: <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18962683'>电子发票冲红</a>
 * @author: SugarT
 * @date: 2018/7/11 下午4:42
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "invoiceRed",
        contentType = "application/json",
        response = BasePosResponse.class,
        saveToLog = true)
public class InvoiceRedRequest extends BasePosRequest {

    /**
     * 业务类型ID
     * 166 POS订单开票业务,167 网络订单开票业务,168 美易点线下开票业务,172 小猫线下收银开票业务
     */
    public int sourceId = 0;

    /**
     * 业务流水号
     */
    public String businessNo = "";

    /**
     * 冲红原因
     */
    public String reason = "";

    public InvoiceRedRequest() {
    }

    @Override
    public String optBaseUrl() {
        return Constant.getInvoicePrefix();
    }
}
