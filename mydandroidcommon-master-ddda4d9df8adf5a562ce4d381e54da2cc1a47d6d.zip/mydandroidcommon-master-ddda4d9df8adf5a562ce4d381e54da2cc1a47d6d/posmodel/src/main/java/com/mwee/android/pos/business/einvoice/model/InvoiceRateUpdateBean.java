package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:更新税率
 */
public class InvoiceRateUpdateBean extends BusinessBean {
    public String msg;
    public String code;

    public InvoiceRateUpdateBean(){

    }
}
