package com.mwee.android.pos.business.shop;

import com.mwee.android.base.net.BaseResponse;

/**
 * Created by qinwei on 2018/9/27.
 */
public class KoubeiShopInfoResponse extends BaseResponse {
    public KouBeiShopInfo data = new KouBeiShopInfo();

    public KoubeiShopInfoResponse() {

    }
}