package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:电子发票库存及税率
 */
public class InvoiceRateBean extends BusinessBean {
    /**
     * 税率
     */
    public int taxRate;
    /**
     * 库存数量
     */
    public int stock;

    public InvoiceRateBean() {
    }
}
