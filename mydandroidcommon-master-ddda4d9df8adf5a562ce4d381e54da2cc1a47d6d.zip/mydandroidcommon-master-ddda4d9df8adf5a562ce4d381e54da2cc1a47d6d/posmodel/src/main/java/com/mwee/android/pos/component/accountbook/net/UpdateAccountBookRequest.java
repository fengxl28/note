package com.mwee.android.pos.component.accountbook.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.component.datasync.net.MallProtocolResponse;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.tools.StringUtil;

/**
 * 修改账套配置
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31608640
 */
@HttpParam(httpType = HttpType.POST,
        method = "ab/billSet",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 300)
public class UpdateAccountBookRequest extends BasePosRequest {

    public String requestId = UUIDUtil.optUUID();

    /**
     * 门店guid
     */
    public String shopGUID = "";
    /**
     * 门店名称
     */
    public String shopName = "";
    /**
     * 总店guid
     */
    public String manageShopGUID = "";
    /**
     * 门店类型
     */
    public int shopKind;
    /**
     * 账套
     */
    public AccountBookDBModel billSetVO = null;

    public UpdateAccountBookRequest() {

    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrl();
    }
}
