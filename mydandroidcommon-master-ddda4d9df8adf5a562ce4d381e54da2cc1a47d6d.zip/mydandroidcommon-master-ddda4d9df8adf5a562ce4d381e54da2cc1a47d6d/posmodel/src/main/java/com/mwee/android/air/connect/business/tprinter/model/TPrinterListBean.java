package com.mwee.android.air.connect.business.tprinter.model;

import android.text.TextUtils;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/8/24
 * description:打印机列表响应参数
 */
public class TPrinterListBean extends BusinessBean {
    public int printerType = 0;     //打印机类型 1:云打印机 2:蓝牙打印机
    public String suitableProd = "";   //适用产品  1:美小易 2:美收银
    public String printerNum = "";     //打印机型号
    public String imageURL = "";      //图片url
    public String guid = "";          //主键
    public String printerId = "";     //打印机id
    public String printerBrand = "";  //打印机品牌
    public int status = 0;//状态


    public TPrinterListBean() {
    }

    @Override
    public String toString() {
        if(TextUtils.isEmpty(printerNum)){
            return "通用类型";
        }
        return printerNum;
    }
}
