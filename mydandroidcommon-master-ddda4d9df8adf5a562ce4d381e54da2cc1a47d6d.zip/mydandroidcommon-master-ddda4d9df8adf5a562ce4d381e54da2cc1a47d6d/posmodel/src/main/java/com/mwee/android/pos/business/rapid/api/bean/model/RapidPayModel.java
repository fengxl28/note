package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * @ClassName: RapidPayModel
 * @Description:
 * @author: SugarT
 * @date: 16/11/13 下午8:37
 */
public class RapidPayModel extends BusinessBean {

    /**
     *
     */
    public BigDecimal fdReceMoney = BigDecimal.ZERO;
    /**
     *
     */
    public int fsShopGUID = 0;
    /**
     *
     */
    public String fsPaymentId = "";

    public String fsPaymentName = "";
    /**
     *
     */
    public String fiPaymentType = "";
    /**
     *
     */
    public String fiSeq = "";
    /**
     *
     */
    public String fsMiscno = "";
    /**
     *
     */
    public String fsNote = "";
    /**
     * 会员卡号
     */
    public String fsMemberNo="";
    /**
     * 会员券类型ID
     */
    public String fsCoupon_id="";
    /**
     * 打赏信心
     */
    public String empNo="";

    public RapidPayModel(){

    }

}
