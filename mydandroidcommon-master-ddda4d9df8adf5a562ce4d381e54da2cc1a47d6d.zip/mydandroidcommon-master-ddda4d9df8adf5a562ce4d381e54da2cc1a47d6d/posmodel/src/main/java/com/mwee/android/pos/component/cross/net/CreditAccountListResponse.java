package com.mwee.android.pos.component.cross.net;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CreditAccountListResponse extends BasePosResponse {
    public Response<CreditAccount> data = new Response<>();

    public CreditAccountListResponse() {
    }
}
