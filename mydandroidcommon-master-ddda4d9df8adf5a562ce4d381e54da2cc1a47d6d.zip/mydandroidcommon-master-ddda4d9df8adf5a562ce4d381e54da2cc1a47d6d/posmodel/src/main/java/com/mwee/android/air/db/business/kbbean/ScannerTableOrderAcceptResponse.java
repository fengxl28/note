package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/8/17.
 */

public class ScannerTableOrderAcceptResponse extends BaseSocketResponse {

    /**
     * 本地订单号
     */
    //public String fsSellNo = "";
    /**
     * 口碑订单状态
     */
    public String status = "";

    public ScannerTableOrderAcceptResponse() {
    }
}
