package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.common.Calc;

import java.math.BigDecimal;

/**
 * 全能pos支付订单信息
 * Created by qinwei on 2017/7/28.
 */

public class PosPaymentModel extends BusinessBean {
    /**
     * 订单编号
     */
    public String orderNo;

    /**
     *
     */
    public String deviceEn;
    /**
     * 付款日期
     */
    public String payTime;
    /**
     *
     */
    public String shopName;
    /**
     *
     */
    public int mShopId;
    /**
     *
     */
    public int discountAmount;
    /**
     * 支付方式（1：微信 2:支付宝 3:银联 4:百度钱包 5:会员卡余额 9:0元支付）
     */
    public int payWay;
    /**
     *
     */
    public int sourceNo;
    /**
     *
     */
    public int type;
    /**
     *
     */
    public int refundTag;
    /**
     * 订单总金额(单位为分)
     */
    public int totalAmount;
    /**
     *
     */
    public String orderTime;
    /**
     *
     */
    public int payType;
    /**
     *
     */
    public int payAmount;
    /**
     *
     */
    public int ceilBeforeAmount;
    /**
     *
     */
    public String createTime;
    /**
     * 用户实际付款金额(单位为分)
     */
    public int realPayAmount;
    /**
     *
     */
    public int id;
    /**
     *
     */
    public int shopId;
    /**
     * 支付id
     */
    public String payId;
    /**
     *
     */
    public int retry;
    /**
     *
     */
    public String lastUpdateTime;
    /**
     * 0、待支付1、付款完成 2、付款失败 3、付款确认中 4、退款确认中 5、已经退款 6、退款失败
     */
    public int status;
    /**
     *
     */
    public int ceilAmount;


    public PosPaymentModel() {
    }

    public String getPayStatusLabel() {
        String label = "";
        switch (status) {
            case 0:
                label = "未支付";
                break;
            case 1:
                label = "已付款";
                break;
            case 2:
                label = "付款失败";
                break;
            case 3:
                label = "付款确认中";
                break;
            case 4:
                label = "退款确认中";
                break;
            case 5:
                label = "已退款";
                break;
            case 6:
                label = "退款失败";
                break;
            default:
                break;
        }
        return label;
    }

    public String getPayPrice() {
        return Calc.formatShow(new BigDecimal(realPayAmount / 100.0), 2);
    }

    //（1：微信 2:支付宝 3:银联 4:百度钱包 5:会员卡余额 9:0元支付）
    public String getPayWayLabel() {
        String label = null;
        switch (payWay) {
            case 1:
                label = "微信";
                break;
            case 2:
                label = "支付宝";
                break;
            case 3:
                label = "银联";
                break;
            case 4:
                label = "百度钱包";
                break;
            case 5:
                label = "会员卡余额";
                break;
            case 6:
                label = "0元支付";
                break;
            default:
                break;
        }
        return label;
    }
}
