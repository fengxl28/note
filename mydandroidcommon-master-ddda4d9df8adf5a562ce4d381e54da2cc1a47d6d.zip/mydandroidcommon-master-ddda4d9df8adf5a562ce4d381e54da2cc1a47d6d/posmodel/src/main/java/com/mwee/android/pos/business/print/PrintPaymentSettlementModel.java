package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by Zun on 16/7/12.
 */
public class PrintPaymentSettlementModel extends DBModel {
    @ColumnInf(name = "fsshiftname")
    public String fsshiftname = "";                        // 班别名称

    @ColumnInf(name = "fspaymentname")
    public String fspaymentname = "";                        // 结算方式名称

    @ColumnInf(name = "recemoney")
    public BigDecimal recemoney = BigDecimal.ZERO;      // 结算总额

    @ColumnInf(name = "fdrecemoney")
    public BigDecimal fdrecemoney = BigDecimal.ZERO;      // 结算总额

    @ColumnInf(name = "qty")
    public int qty = 0;      // 总笔数

    @ColumnInf(name = "fiiscalcpaid")   //是否计入收入(实收);0=false/1=true
    public int fiiscalcpaid = 0;

    public PrintPaymentSettlementModel() {

    }

    @Override
    public String toString() {
        return "PrintPaymentSettlementModel{" +
                "fspaymentname='" + fspaymentname + '\'' +
                ", recemoney=" + recemoney +
                ", fdrecemoney=" + fdrecemoney +
                '}';
    }
}
