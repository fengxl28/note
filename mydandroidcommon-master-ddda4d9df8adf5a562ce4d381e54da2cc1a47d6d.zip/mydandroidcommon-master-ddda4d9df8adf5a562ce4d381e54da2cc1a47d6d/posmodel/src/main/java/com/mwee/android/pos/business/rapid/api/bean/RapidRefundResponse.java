package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by virgil on 2016/11/15.
 */

public class RapidRefundResponse extends BasePosResponse {

    public RapidRefundResponse() {

    }
}