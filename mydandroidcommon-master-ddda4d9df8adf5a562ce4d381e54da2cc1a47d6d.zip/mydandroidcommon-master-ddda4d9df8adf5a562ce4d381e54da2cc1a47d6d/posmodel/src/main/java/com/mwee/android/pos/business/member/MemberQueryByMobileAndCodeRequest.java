package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.pos.component.member.net.GetMemberCardResponse;
import com.mwee.android.tools.StringUtil;

/**
 * 通过手机号
 * Created by qinwei on 2017/9/4.
 */
@HttpParam(httpType = HttpType.POST,
        method = "app.membercard.getMemberByMobile",
        response = GetMemberCardResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class MemberQueryByMobileAndCodeRequest extends BaseMemberRequest {
    public String mobile;//手机号
    public String device_id;//设备号
    public String sms_code;//短信验证码

    public MemberQueryByMobileAndCodeRequest() {
        super("app.membercard.getMemberByMobile");
    }
}