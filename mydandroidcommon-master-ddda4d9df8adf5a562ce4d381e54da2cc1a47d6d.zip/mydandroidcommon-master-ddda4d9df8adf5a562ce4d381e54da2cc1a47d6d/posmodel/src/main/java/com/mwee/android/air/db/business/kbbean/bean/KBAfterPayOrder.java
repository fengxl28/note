package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by qinwei on 2018/10/15.
 */

public class KBAfterPayOrder extends BusinessBean {

    /**
     * 唯一标识符
     */
    public String id = "";

    /**
     * POS订单号
     */
    //public String posOrderId = "";

    /**
     * 口碑订单号
     */
    public String order_id = "";

    /**
     * 推单批次号
     * 唯一标识符
     */
    public String batch_no = "";
    /**
     * POS订单号 字段不准
     */
    @Deprecated
    public String out_biz_no = "";
    /**
     * POS订单号
     */
    public String posOrderId = "";

    /**
     * 业务产品
     * (1)KB_ORDER_DISHES 立即就餐
     * (2) KB_RESERVATION 预约点餐
     */
    public String biz_product = "";
    /**
     * 业务类型 DINNER：正餐；SNACK：快餐；
     */
    public String business_type = "";
    /**
     * 就餐类型
     * FOR_HERE：堂食；
     * TAKE_OUT：外卖；
     * TO_GO：外带
     */
    public String dinner_type = "";
    /**
     * "支付类型。
     * ADVANCE_PAYMENT：先付；
     * AFTER_PAYMENT：后付；
     */
    public String pay_style = "";
    /**
     * "可枚举的点餐方式。
     * POS：pos点餐；
     * SCAN：扫码点菜；
     * PLATFORM：平台(外卖类的)"
     */
    public String order_style = "";
    /**
     * 商户ID
     */
    public String partner_id = "";
    /**
     * 口碑门店ID
     */
    public String shop_id = "";
    /**
     * 就餐的餐台号码
     */
    public String table_no = "";
    /**
     * 就餐人数
     */
    public String people_num = "";
    /**
     * 用户ID
     */
    public String user_id = "";
    /**
     * 统计信息，本批次中所有菜品明细金额之和；
     */
    public BigDecimal total_amount = BigDecimal.ZERO;
    /**
     * 统计信息，本批次中所有的菜品明细的笔数之和；
     */
    public int total_size;
    /**
     * 接单超时的绝对时间；
     * 超过这个时间，口碑侧将对本次推单做超时自动拒单处理。"
     */
    public String receipt_timeout = "";
    /**
     * 下单时间 , 用户点餐或者加菜确认的时间
     */
    public String order_time = "";
    /**
     * 扩展信息
     */
    public String ext_infos = "";

    /**
     * 菜品明细列表
     */
    public ArrayList<KBDishMenuItem> dish_list = new ArrayList<>();

    /**
     * 批次备注
     */
    public String memo = "";
    /**
     * <p>
     * 订单操作类型，
     * WAIT_RECEIPT-订单已推送
     * RECEIPT—接单、
     * REJECT—拒单、
     */
    public String status;
}
