package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;

import java.math.BigDecimal;

/**
 * Created by Zun on 16/7/12.
 */
public class PrintCountModel extends DBModel {

    public BigDecimal fdrecemoney = BigDecimal.ZERO;   // 合计金额

    public PrintCountModel() {

    }
}
