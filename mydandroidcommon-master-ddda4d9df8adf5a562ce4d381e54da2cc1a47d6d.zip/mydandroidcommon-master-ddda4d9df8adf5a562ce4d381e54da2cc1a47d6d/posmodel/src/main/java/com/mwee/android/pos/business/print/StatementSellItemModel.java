package com.mwee.android.pos.business.print;

import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/7/14.
 */
public class StatementSellItemModel extends SellOrderItemDBModel {
    @ColumnInf(name = "qty")
    public BigDecimal qty = BigDecimal.ZERO;

    /**
     * 是否为菜品分类
     */
    public boolean isMenuCls = false;

    /**
     * 套餐内容
     */
    public List<StatementSellItemModel> SLIT = new ArrayList<>();

    /**
     * 配料菜
     */
    public List<StatementSellItemModel> ingredientList = new ArrayList<>();

    public boolean isMerge;//是否已合并或已处理

    @Override
    public String toString() {
        super.toString();
        return "StatementSellItemModel{" +
                ", qty='" + qty + '\'' +
                '}';
    }
}
