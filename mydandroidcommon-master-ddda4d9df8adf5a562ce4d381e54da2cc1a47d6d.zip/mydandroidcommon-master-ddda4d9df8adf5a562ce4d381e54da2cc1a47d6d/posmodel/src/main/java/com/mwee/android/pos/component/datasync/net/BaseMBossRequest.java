package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;

/**
 * Created by virgil on 2017/7/21.
 */

public class BaseMBossRequest extends BasePosRequest {
    @Override
    public String optBaseUrl() {
        return "http://pcdc.winpos.9now.net"+"/posapi/shop/" + ClientMetaUtil.getSettingsValueByKey(META.SHOPID)+"-103/" + "shopapi/";
    }
}
