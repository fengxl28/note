package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.connect.business.delivery.CreatedeliveryResponse;
import com.mwee.android.pos.connect.business.delivery.OptAllDeliveryChannelResponse;
import com.mwee.android.pos.connect.business.delivery.OptDeliveryStatusResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * 配送
 * Created by qinwei on 2017/9/3.
 */

public interface CDelivery {

    /**
     * 启动配送
     *
     * @param orderId id
     * @return
     */
    @SocketParam(uri = "delivery/createDelivery", response = CreatedeliveryResponse.class, timeOut = 80)
    String createDelivery(@SF("orderId") String orderId,
                          @SF("time") String time,
                          @SF("areaIds") String areaIds,
                          @SF("deliveryChannel") String deliveryChannel);

    /**
     * 取消配送
     *
     * @param orderId id
     * @return
     */
    @SocketParam(uri = "delivery/cancelDelivery", response = CreatedeliveryResponse.class, timeOut = 80)
    String cancelDelivery(@SF("orderId") String orderId,
                          @SF("time") String time,
                          @SF("areaIds") String areaIds,
                          @SF("expressCompany") String expressCompany);


    /**
     * 获取配送开启状态
     */
    @SocketParam(uri = "delivery/optDeliveryStatus", response = OptDeliveryStatusResponse.class, timeOut = 80)
    String optDeliveryStatus();

    /**
     * 获取所有外卖配送方式
     */
    @SocketParam(uri = "delivery/optAllDeliveryChannel", response = OptAllDeliveryChannelResponse.class, timeOut = 80)
    String optAllDeliveryChannel();

}
