package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by liuxiuxiu on 2018/9/19.
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23022940
 * 激活实体卡+实体卡设置当前卡+通过实体卡保存属性
 */
@HttpParam(httpType = HttpType.POST,
        method = "activateEntityCard",
        response = BindMemberEntityCardResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class BindMemberEntityCardRequest extends BaseMemberRequest {
    /**
     * 手机号
     */
    public String mobile = "";

    /**
     * 卡号
     */
    public String cardNo = "";

    /**
     * 品牌id
     */
    public String brandId = "-1";

    /**
     * 验证码
     */
    public String deviceId = "";

    /**
     * 设备号
     */
    public String verifyCode = "";

    /**
     * 谁操作的卡
     */
    public String whoOptEntityCard = "";

    /**
     * 姓名
     */
    public String realName = "";

    /**
     * 性别 (0保密 1男 2女)
     */
    public int gender = 0;

    /**
     * 生日
     */
    public String birthday = "";

    public BindMemberEntityCardRequest() {
        super("activateEntityCard");
    }
}
