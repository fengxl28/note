package com.mwee.android.cashier.connect.bean.http;

/**
 * see{@link GetBillNoPosRequest}
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetBillNoPosResponse extends BaseCashierPosResponse {
    /**
     * 支付单号
     */
    public String data;

    public GetBillNoPosResponse() {

    }
}
