package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 保存缓存单信息
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11640524</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "login.php",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = SaveOrderPosResponse.class)
public class SaveOrderPosRequset extends BaseCashierPosRequest {
}
