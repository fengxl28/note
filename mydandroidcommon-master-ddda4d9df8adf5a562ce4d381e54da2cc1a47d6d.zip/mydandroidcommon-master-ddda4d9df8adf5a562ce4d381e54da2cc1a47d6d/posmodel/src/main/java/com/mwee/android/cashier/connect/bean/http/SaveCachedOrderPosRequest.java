package com.mwee.android.cashier.connect.bean.http;

import com.alibaba.fastjson.annotation.JSONField;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

import java.math.BigDecimal;

/**
 * 保存缓存单的接口
 * Created by virgil on 2018/2/1.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "openOrder/saveSellCache",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = BaseCashierPosResponse.class)
public class SaveCachedOrderPosRequest extends BaseCashierPosRequest {
    /**
     * 订单号
     */
    @JSONField(name = "sellNo")
    public String orderId;
    /**
     * 支付单号
     */
    public String checkBillNo;
    /**
     * 牌号
     */
    public String mealNumber;
    /**
     * 开单时间
     */
    public String sellTime;
    /**
     * 营业日期
     */
    public String sellDate;
    /**
     * see{@link com.mwee.android.pos.db.business.order.OrderStatus}
     */
    @JSONField(name = "billStatus")
    public int orderStatus;
    public String userId;

    public String hostId;
    /**
     * 应付
     */
    public BigDecimal expAmt;
    /**
     * 应收
     */
    public BigDecimal saleAmt;
    /**
     * 顾客数量
     */
    @JSONField(name = "custSum")
    public int person;
    /**
     * 订单类型see{@link com.mwee.android.pos.db.business.order.OrderCache#fiSellType}
     */
    public int sellType;
    /**
     * OrderCache的String，需要Zip一下
     */
    public String orderInfo;
    /**
     * PaySession的String，需要Zip一下
     */
    public String payInfo;

    public SaveCachedOrderPosRequest() {

    }
}
