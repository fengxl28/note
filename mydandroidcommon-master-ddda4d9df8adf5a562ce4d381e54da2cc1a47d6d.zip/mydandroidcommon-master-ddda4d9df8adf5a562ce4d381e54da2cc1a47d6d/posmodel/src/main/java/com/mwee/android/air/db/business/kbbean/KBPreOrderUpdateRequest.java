package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KBOrderRefund;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * 更新口碑预点单状态
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=17468165
 */
@HttpParam(httpType = HttpType.POST,
        method = "koubeiPreOrder/orderStatusSync",
        response = KBPartRefundReturnResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class KBPreOrderUpdateRequest extends BaseKouBeiRequest {

    /**
     * 口碑端自己的订单号
     */
    public String order_id;

    /**
     * 订单操作类型，RECEIPT—接单、REJECT—拒单、PREPARE—已备餐、DELIVER—已送餐、REFUND—退款、RENEW—反结  TABLE_CHANGE-修改桌号、COOKING-下厨
     */
    public String action;

    /**
     * 口碑商户id
     */
    public String merchantPid;

//    /**
//     * 取餐号  KB0001 递增
//     */
//    public String no = "KB0001";
    /**
     * 取餐号，桌台id
     */
    public String tableNo = "";
    /**
     * 取餐类型DINNER-正餐、SNACK-快餐
     */
    public String businessType = "";

    /**
     * action=RECEIPT 需要传这个参数，LATFORM——线上点，SCAN——扫码点
     */
    public String orderStyle = "";

    /**
     * 美味订单号
     * 备餐完成需要传这个参数
     */
    public String fsSellNo;


    public String reason = "";

    public KBOrderRefund kbOrderRefund = null;

    /**
     * 设备类型字段：dvType，枚举值：PC插件(PC_PLUG_IN)，小黑盒(BLACK_BOX)，手持POS(HAND_POS)，台式POS(DESKTOP_POS)，云打印机(CLOUD_PRINTER)
     * Y(action=RECEIPT)
     */
    public String dvType;

    /**
     * Y(action=RECEIPT) 回传SN号
     */
    public String dvSn;
    /**
     * 制作次序
     * 口碑当前【备餐中】状态的订单数量 + 本地order_cache未结账订单数量；
     */
    public int queueNum = 0;

    /**
     * 来源类型(1美易点,2美小易,3小猫)
     */
    public int sourceType;

    public static class SourceType {
        public static final int MYD = 1;
        public static final int MXY = 2;
    }

    public KBPreOrderUpdateRequest() {

    }


}
