package com.mwee.android.pos.business.constants;

/**
 * Created by liuxiuxiu on 2017/10/12.
 */

public class AirHostConstant {
    public static final int DINNER_MODEL = 0;      //桌台单
    public static final int FASTFOOD_MODEL = 1;     //快餐单
}
