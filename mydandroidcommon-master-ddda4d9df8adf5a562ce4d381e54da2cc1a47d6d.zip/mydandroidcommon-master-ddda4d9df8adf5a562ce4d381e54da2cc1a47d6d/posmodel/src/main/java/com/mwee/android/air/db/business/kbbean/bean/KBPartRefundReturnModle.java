package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * created by 2018/11/13
 *
 * @author lxd
 * Description:口碑部分退款返回Modle
 */
public class KBPartRefundReturnModle extends BusinessBean {
//    /**
//     * 口碑部分退款返回参数信息实体类
//     */
//    public KBPartRefundExtInfo ext_info = new KBPartRefundExtInfo();
    public String ext_info = "";
    public boolean retry = false;

    public KBPartRefundReturnModle() {
    }
}
