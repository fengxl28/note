package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.business.rapid.api.bean.IgnoreRapidOnlyPayOrderResponse;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.message.MessageCenterUnDealResponse;
import com.mwee.android.pos.connect.business.message.MessageFastfoddListResponse;
import com.mwee.android.pos.connect.business.message.MessageOrderListResponse;
import com.mwee.android.pos.connect.business.message.MessagePayListResponse;
import com.mwee.android.pos.connect.business.message.MessageSystemListResponse;
import com.mwee.android.pos.connect.business.message.UpdateMessageOrderResponse;
import com.mwee.android.pos.connect.business.order.PayConfirmResponse;
import com.mwee.android.pos.connect.business.order.RapidOrderConfirmReceiptResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.FastfoodUnDealCountResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.OptWechatFastfoodFromBizResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.UpdateWechatFastfoodResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;

import java.math.BigDecimal;

/**
 * 消息相关
 * Created by qinwei on 2017/9/3.
 */

public interface CMessage {

    /**
     * 更新消息
     *
     * @param msgId          消息id
     * @param businessStatus 业务状态
     * @param tableId        桌台id
     * @param dealStatus
     * @param readStatus
     * @return
     */
    @SocketParam(uri = "message/updateMessageOrder", response = UpdateMessageOrderResponse.class)
    String updateMessageOrder(@SF("msgId") int msgId,
                              @SF("businessStatus") int businessStatus,
                              @SF("tableId") String tableId,
                              @SF("dealStatus") int dealStatus,
                              @SF("readStatus") int readStatus);


    /**
     * 忽略秒付纯收银消息
     *
     * @param msgID  对应的消息ID
     * @param payAmt 支付金额
     * @return
     */
    @SocketParam(uri = "message/ignoreRapid", response = IgnoreRapidOnlyPayOrderResponse.class)
    String ignoreRapidOnlyPayOrderRequest(@SF("msgID") int msgID,
                                          @SF("payAmt") BigDecimal payAmt);

    /**
     * 忽略秒付拉单确认消息
     *
     * @param msgID 对应的消息ID
     * @return
     */
    @SocketParam(uri = "message/updatePayConfirm", response = IgnoreRapidOnlyPayOrderResponse.class)
    String updatePayConfirm(@SF("msgID") int msgID, @SF("businessStatus") int businessStatus);

    /**
     * 所有未处理秒付拉单确认消息
     *
     * @return
     */
    @SocketParam(uri = "message/unDealConfirmMessageList", response = PayConfirmResponse.class)
    String unDealConfirmMessageList();

    /**
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/unDealCount", response = MessageCenterUnDealResponse.class)
    String messageCenterUnDealRequest(@SF("businessDate") String businessDate,
                                      @SF("time") String time,
                                      @SF("areaIds") String areaIds);

    /**
     * 获取所有点菜消息
     *
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/ordersList", response = MessageOrderListResponse.class)
    String messageOrderListRequest(@SF("businessDate") String businessDate,
                                   @SF("time") String time,
                                   @SF("areaIds") String areaIds);


    /**
     * 获取所有支付消息
     *
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/payList", response = MessagePayListResponse.class)
    String messagePayListRequest(@SF("businessDate") String businessDate,
                                 @SF("time") String time,
                                 @SF("areaIds") String areaIds);

    @SocketParam(uri = "message/systemList", response = MessageSystemListResponse.class)
    String loadMessageSystemList(@SF("businessDate") String businessDate,
                                 @SF("time") String time,
                                 @SF("areaIds") String areaIds);


    /**
     * @param tempOrderDishesCache 秒点单信息
     * @param printUser            打印用户
     */
    @SocketParam(uri = "message/rapidConfirmReceipt", response = RapidOrderConfirmReceiptResponse.class)
    void rapidConfirmReceipt(@SF("tempOrderDishesCache") TempOrderDishesCache tempOrderDishesCache,
                             @SF("printUser") String printUser);


    @SocketParam(uri = "message/addXMPPLoginErrorMsg", response = RapidOrderConfirmReceiptResponse.class)
    void addXMPPLoginErrorMsg(@SF("username") String username,
                              @SF("password") String password,
                              @SF("errorMsg") String errorMsg);

    @SocketParam(uri = "message/getUnDealFastFoodMsgCount", response = FastfoodUnDealCountResponse.class)
    void getUnDealFastFoodMsgCount(@SF("businessDate") String businessDate);


    /**
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/fastfoodList", response = MessageFastfoddListResponse.class, timeOut = 80)
    String fastfoodList(@SF("businessDate") String businessDate,
                        @SF("time") String time,
                        @SF("areaIds") String areaIds);


    /**
     * @param fsorderno    订单号
     * @param diningStatus 状态
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @returnMessageFa
     */
    @SocketParam(uri = "message/updateWechatFastfood", response = UpdateWechatFastfoodResponse.class, timeOut = 80)
    String updateWechatFastfood(@SF("outerOrderId") String fsorderno,
                                @SF("diningStatus") String diningStatus,
                                @SF("businessDate") String businessDate,
                                @SF("time") String time,
                                @SF("areaIds") String areaIds);

    /**
     * @param msgId    订单号
     * @returnMessageFa
     */
    @SocketParam(uri = "message/notifiyServerMenuPrepared", response = BaseSocketResponse.class, timeOut = 80)
    String notifiyServerMenuPrepared(@SF("msgId") String msgId);

    /**
     * @param outerOrderId 订单号
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/getWechatFastfood", response = UpdateWechatFastfoodResponse.class, timeOut = 80)
    String getWechatFastfood(@SF("outerOrderId") String outerOrderId,
                             @SF("businessDate") String businessDate,
                             @SF("time") String time,
                             @SF("areaIds") String areaIds);


    /**
     * @param businessDate 营业日期
     * @param time         时间限制
     * @param outerOrderId 订单号
     * @param areaIds      不接受的区域
     * @return
     */
    @SocketParam(uri = "message/optWechatfastfoodById", response = OptWechatFastfoodFromBizResponse.class)
    String optWechatfastfoodById(@SF("businessDate") String businessDate,
                                 @SF("time") String time,
                                 @SF("outerOrderId") String outerOrderId,
                                 @SF("areaIds") String areaIds);

}
