package com.mwee.android.air.connect.business.table;

import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangmin on 2017/11/17.
 */

public class GetAirTableChangeResponse extends BaseSocketResponse {


    /**
     * 所有餐区
     */
    public List<MareaDBModel> mareaDBModelList = new ArrayList<>();

    /**
     * 餐区关联的桌台数据
     * key 餐区  value  该餐区下对应的桌台
     */
    public ArrayMap<String, List<MtableDBModel>> areaTable = new ArrayMap<>();


    /**
     * 所有桌子(本地库的桌台+拼出的桌台)
     */
    public List<MtableDBModel> allTables = new ArrayList<>();


    /**
     * 桌台业务数据
     * key  桌台ID;
     * value 业务对象
     */
    public Map<String, TableStatusBean> tableStatus = new ArrayMap<>();

    public GetAirTableChangeResponse(){

    }
}
