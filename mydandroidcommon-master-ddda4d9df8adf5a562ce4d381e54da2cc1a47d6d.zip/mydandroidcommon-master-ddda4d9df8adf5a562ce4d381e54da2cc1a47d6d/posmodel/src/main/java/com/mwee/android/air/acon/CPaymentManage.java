package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.payment.GetAllPaymentResponse;
import com.mwee.android.air.connect.business.payment.GetPaymentResponse;
import com.mwee.android.air.connect.business.payment.PayTypeListResponse;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * @ClassName: CPaymentManage
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午3:00
 */
public interface CPaymentManage extends CBase {

    /**
     * 获取所有支付方式
     *
     * @return
     */
    @SocketParam(uri = "airPaymentManager/getAllPayment", response = GetAllPaymentResponse.class)
    String getAllPayment();

    /**
     * 新增支付方式
     *
     * @param fsPaymentName
     * @param fiIsCalcPaid
     * @return
     */
    @SocketParam(uri = "airPaymentManager/addPayment", response = GetAllPaymentResponse.class)
    String addPayment(@SF("fsPaymentName") String fsPaymentName, @SF("fiIsCalcPaid") int fiIsCalcPaid,@SF("fiIsPremium") int fiIsPremium);

    /**
     * 修改支付方式
     *
     * @param fsPaymentId
     * @param fsPaymentName
     * @param fiIsCalcPaid
     * @return
     */
    @SocketParam(uri = "airPaymentManager/updatePayment", response = GetAllPaymentResponse.class)
    String updatePayment(@SF("fsPaymentId") String fsPaymentId, @SF("fsPaymentName") String fsPaymentName, @SF("fiIsCalcPaid") int fiIsCalcPaid,@SF("fiIsPremium") int fiIsPremium);

    /**
     * 删除支付方式
     *
     * @param fsPaymentId
     * @return
     */
    @SocketParam(uri = "airPaymentManager/deletePayment", response = GetAllPaymentResponse.class)
    String deletePayment(@SF("fsPaymentId") String fsPaymentId);

    /**
     * 修改支付方式是否计入实收
     *
     * @param fsPaymentId
     * @param fiIsCalcPaid
     * @return
     */
    @SocketParam(uri = "airPaymentManager/updatePaymentFiIsCalcPaid", response = BaseSocketResponse.class)
    String updatePaymentFiIsCalcPaid(@SF("fsPaymentId") String fsPaymentId, @SF("fiIsCalcPaid") int fiIsCalcPaid);


    /**
     * 加载配送费支付方式 如果未查到则创建一个
     *
     * @param paymentId
     * @return
     */
    @SocketParam(uri = "airPaymentManager/loadDistributionFeePaymentById", response = GetPaymentResponse.class)
    String loadDistributionFeePaymentById(@SF("fsPaymentId") String paymentId);

    @SocketParam(uri = "airPaymentManager/loadPayTypeList", response = PayTypeListResponse.class)
    String loadPayTypeList(@SF("orderId") String orderId);
}
