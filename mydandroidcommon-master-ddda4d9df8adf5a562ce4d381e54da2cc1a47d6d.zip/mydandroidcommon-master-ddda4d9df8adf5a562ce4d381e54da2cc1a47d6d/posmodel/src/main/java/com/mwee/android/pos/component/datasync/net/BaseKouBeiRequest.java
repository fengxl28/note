package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.pos.db.sync.Constant;

/**
 * BasePosRequest
 * Created by virgil on 16/6/22.
 * @author virgil
 */
public class BaseKouBeiRequest extends BasePosRequest {

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessKouBeiUrl();
    }


}
