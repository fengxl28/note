package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2018/5/22.
 */

public class PosDiscountDetail extends BusinessBean {

    //优惠类型
    public String discount_type;

    //优惠名称
    public String discount_name;

    //商家出资优惠金额，以元为单位，精确到分
    public BigDecimal mrt_discount;

    //平台出资优惠金额，以元为单位，精确到分
    public BigDecimal rt_discount;

    //扩展信息，存储优惠的详细模型。json对象格式，key和value都为字符串  {"全场折扣": "8折"}
    public String ext_info;

    public PosDiscountDetail(){

    }


}
