package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/9/21.
 * <p>
 * "data": {
 * "m_shopid": "43",
 * "mobile": "15021849283",
 * "entity_card_list": [
 * {
 * "card_no":"6262973700002119",//卡号
 * "m_shopid":"43",
 * "mobile":"15021849283",
 * "type":"2",//0虚拟卡 1实体储值卡 2实体卡(16位)
 * "act_shopid":"47113",//激活门店
 * "act_time":"1484130239",//激活时间
 * "card_parent_no":"015029107996",//父卡号
 * "entity_card_is_main":"1",//是否为当前卡 1是 0否
 * "entity_card_status":"1",//卡状态 0未激活 1激活 2冻结
 * "who_open_entity_card":"",
 * "last_deposit_time":"1484536679",//最后预充值
 * }
 * ]
 * },
 * "errmsg": "请求成功",
 * "errno": 0
 */

public class QueryEntityCardDataBean extends BusinessBean {

    public String m_shopid = "";

    public String mobile = "";

    public String errmsg = "";

    public int errno = 0;

    /**
     * 卡信息
     */
    public List<QueryEntityCardInfoBean> entity_card_list = new ArrayList();

    public QueryEntityCardDataBean() {
    }
}
