package com.mwee.android.pos.business.rapid.api.bean.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * 秒点订单的菜品Item
 * Created by virgil on 2016/11/3.
 */

public class RapidOrderItem extends RapidOrderItemBase {
    /**
     * 菜品ID
     */
    public String itemId = "";

    /**
     * 门店ID
     */
    public String supplierShopId = "";
    /**
     * 菜品数量
     */
    public BigDecimal qty = BigDecimal.ZERO;
    /**
     * 菜品配料
     */
    public List<RapidOrderModifier> modifiers = null;
    /**
     * 配料菜的配料
     */
    public List<RapidOrderItemBase> ingredients = null;
    /**
     * 分类ID
     */
    public String categoryId = "";
    /**
     * 第三方分类Id
     */
    public String outerCatId = "";
    /**
     * 分类名称
     */
    public String catName = "";
    /**
     * 是否时价
     */
    public BigDecimal isMarketPrice = BigDecimal.ZERO;
    /**
     * 起卖数量
     */
    public BigDecimal minChoose = BigDecimal.ZERO;
    /**
     * 配料(套餐)价格
     */
    public BigDecimal modifierPrice = BigDecimal.ZERO;
    /**
     * 实收金额
     */
    public BigDecimal realPrice = BigDecimal.ZERO;
    /**
     *
     */
    public BigDecimal totalItemPrice = BigDecimal.ZERO;
    /**
     * 规格
     */
    public String unit = "";
    /**
     * 订单详情Id
     */
    public String orderDetailId = "0";
    /**
     * 下厨状态(0 待确认，1 已下厨，2已上菜)
     */
    public int kitchen = 0;
    /**
     * 菜品确认状态：1，已确认（已改价或者称重菜已确认分量）；其他，未确认
     * 如果商户开启了"秒付拉单确认"功能并且没有授权拉单，那么该字段返回未确认状态
     */
    public int ficheckpass = 0;

    /**
     * 菜品code
     */
    public String itemCode = "";
    public int isWeigh = 0;
    /**
     * 菜品类型(0菜单模板，1子菜单、2临时菜,3套餐, 4配料菜)
     */
    public int itemType = 0;
    /**
     * 图片
     */
    public String img = "";
    /**
     * 退菜的数量
     */
    public BigDecimal voidItemNum = BigDecimal.ZERO;
    /**
     * 打折金额
     */
    public BigDecimal discountPrice = BigDecimal.ZERO;
    /**
     * 菜品状态（0-有价格，1-价格未确定）
     */
    public int status = 0;
    /**
     * 是否配料(0否，1是)
     */
    public int isIngredient = 0;
    /**
     * 本菜为配料时，上级归属主菜的itemId
     */
    public String parentItemId = "";
    /**
     * 秒点下单时菜品的commitId
     */
    public String commitId = "";

    public RapidOrderItem() {

    }
}
