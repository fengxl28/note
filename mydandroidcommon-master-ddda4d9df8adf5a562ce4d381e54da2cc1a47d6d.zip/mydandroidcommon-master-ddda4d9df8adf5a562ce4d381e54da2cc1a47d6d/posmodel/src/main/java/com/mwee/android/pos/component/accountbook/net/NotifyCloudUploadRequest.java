package com.mwee.android.pos.component.accountbook.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.component.datasync.net.MallProtocolResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.tools.StringUtil;

/**
 * 通知云端上传订单到商场
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31608642
 */
@HttpParam(httpType = HttpType.POST,
        method = "ab/platformReflow",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 300)
public class NotifyCloudUploadRequest extends BasePosRequest {

    public String requestId = UUIDUtil.optUUID();

    /**
     * 账套id，必填
     */
    public String accountBookId = "";
    /**
     * 协议id，必填
     */
    public String interfaceManagerId = "";
    /**
     * 是否可重复上传，非必填，0 不可以，1 可以
     */
    public String uploadRepeat;
    /**
     * 营业日期，必填
     */
    public String sellDate = "";
    /**
     * 门店id
     */
    public String shopGuid = "";
    /**
     * true 表示异步上传   false :同步上传
     */
    public boolean asyncUpload = false;

    public NotifyCloudUploadRequest() {

    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrl();
    }
}
