package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2017/7/12.
 */

public class RapidBookItemSimples extends BusinessBean {
    public String itemName = "";     //菜品名称
    public BigDecimal itemPrice = BigDecimal.ZERO;  //价格
    public BigDecimal itemQty = BigDecimal.ONE;  //数量

    public RapidBookItemSimples() {
    }
}
