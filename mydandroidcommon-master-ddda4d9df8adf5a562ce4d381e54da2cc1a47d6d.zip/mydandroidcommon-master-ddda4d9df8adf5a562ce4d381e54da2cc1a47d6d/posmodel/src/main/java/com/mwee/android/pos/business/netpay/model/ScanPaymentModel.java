package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/7/26.
 */

public class ScanPaymentModel extends BusinessBean {
    /**
     * 支付宝帐户(邮箱)
     */
    public String alipayemail;
    /**
     * 支付宝折扣金额
     */
    public BigDecimal fdaliDiscount = BigDecimal.ZERO;
    /**
     * 支付金额
     */
    public BigDecimal fdamount = BigDecimal.ZERO;
    /**
     * 支付状态  0：待支付，1:支付成功,2:支付失败，20:支付中
     */
    public int fiisactive;
    /**
     * 收款人类型(0美味不用等，1商户)
     */
    public int fipayee;
    /**
     * 支付类型(0默认，1微信，2支付宝，3银联，4百度钱包)
     */
    public int fipaymenttypeid;
    /**
     * 返回状态
     */
    public int fireturnstate;
    /**
     * 结算方(-1商户，0美味不用等，1微信，2支付宝，3银联，4百度钱包)
     */
    public int fisettlementmerchant;
    /**
     * 业务来源编号
     */
    public int fisourceid;
    /**
     * 交易类型(0交易，1服务费，2交易退款，3服务费退款，4（第三方）服务费，5（第三方）服务费退款，6美味补贴，7美味补贴退款，8商户补贴
     */
    public int fitradetype;
    /**
     * 创建时间
     */
    public String fscreatetime;
    /**
     * 销售日期
     */
    public String fsdate;
    /**
     * 微信openid
     */
    public String fsopenid;
    /**
     * 支付账单号
     */
    public String fsorderid;
    /**
     * 支付业务终端设备号
     */
    public String fspayen;
    /**
     * 支付单号
     */
    public String fspayno;
    /**
     * 店号
     */
    public String fsshopguid;
    /**
     * 店名
     */
    public String fsshopname;
    /**
     * 结账批次
     */
    public String fssqe;
    /**
     * 支付方式ID
     */
    public String fssyspayid;
    /**
     * 交易流水号
     */
    public String fstradeno;
    /**
     * 交易时间
     */
    public String fstradetime;
    /**
     * 修改时间
     */
    public String fsupdatetime;

    /**
     * 桌号
     */
    public String fsMTableId;

    /**
     * 牌号
     */
    public String fsMealNumber;

    /**
     * 销售账单号
     */
    public String fssellno;

    public ScanPaymentModel() {
    }

    /**
     * 支付类型(1微信，2支付宝，3银联，4百度钱包，5会员卡)
     *
     * @return
     */
    public String getPayTypeLabel() {
        String payTypeName = "默认";
        switch (fipaymenttypeid) {
            case 1:
                payTypeName = "微信";
                break;
            case 2:
                payTypeName = "支付宝";
                break;
            case 3:
                payTypeName = "银联";
                break;
            case 4:
                payTypeName = "百度钱包";
                break;
            default:
                break;
        }
        return payTypeName;
    }

    public String getPayStatusLabel() {
        switch (fiisactive) {
            case 0:
                return "待支付";
            case 1:
                return "支付成功";
            case 2:
                return "支付失败";
            case 3:
                return "支付中";
            default:
                break;
        }
        return "";
    }
}
