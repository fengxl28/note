package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/7/26.
 */

public class ScanPaymentModelList extends BusinessBean {
    public int pageNo;
    public int total;
    public int totalPageNo;

    public ArrayList<ScanPaymentModel> result = new ArrayList<>();

    public ScanPaymentModelList() {
    }
}
