package com.mwee.android.air.db.business.table;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class AirAreaManagerInfo extends DBModel {

    @ColumnInf(name = "fsMAreaId")
    public String fsMAreaId = "";

    @ColumnInf(name = "fsMAreaName")
    public String fsMAreaName = "";

    @ColumnInf(name = "allTables")
    public int allTables = 0;  //该餐区下所有桌台数

    @ColumnInf(name = "allTableInUse")
    public int allTableInUse = 0;  //该餐区下所有有订单的桌台数

    public AirAreaManagerInfo() {
    }
}
