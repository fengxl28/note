package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 获取流水列表
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11639993</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "orderPayment/getOrderPaymentList",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetTradeListPosResponse.class)
public class GetTradeListPosRequest extends BaseCashierPosRequest {
    /**
     * 当前椰树
     */
    public String currentPage;
    /**
     * 总页数
     */
    public String pageSize;
    /**
     * 门店ID
     */
    public String shopGUID;
    /**
     * 付款方式ID
     */
    public String paymentId;
    /**
     * 交易开始时间
     */
    public String tradeBeginTime;
    /**
     * 交易结束时间
     */
    public String tradeEndTime;

    /**
     * 支付类型
     */
    public String paymentTypeId;

    /**
     * 订单类型
     */
    public String billSourceType;

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierMposmsyUrl();
    }

    public GetTradeListPosRequest() {

    }
}
