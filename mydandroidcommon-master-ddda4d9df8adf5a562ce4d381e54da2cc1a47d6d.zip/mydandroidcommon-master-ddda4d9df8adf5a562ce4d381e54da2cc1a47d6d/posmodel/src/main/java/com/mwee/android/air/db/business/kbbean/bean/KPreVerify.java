package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/6/26.
 */

public class KPreVerify extends BusinessBean {
    public String order_id = "";
    public boolean retry;

    public KPreVerify() {
    }
}
