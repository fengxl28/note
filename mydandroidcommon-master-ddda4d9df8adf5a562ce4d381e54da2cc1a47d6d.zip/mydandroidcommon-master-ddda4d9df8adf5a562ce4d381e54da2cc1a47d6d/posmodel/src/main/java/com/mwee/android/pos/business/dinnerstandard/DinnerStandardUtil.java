package com.mwee.android.pos.business.dinnerstandard;

import android.text.TextUtils;

import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AreaBizDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by huangming on 2018/10/25.
 */
public class DinnerStandardUtil {

    private static final String TAG = "DinnerStandardUtil";

    //餐标服务费菜品内码
    public static final String DS_MENU_ID = "91991";
    //低消服务费菜品内码
    public static final String MS_MENU_ID = "91992";

    public static String ERROR_ON_DINING_STANDARD = "您当前就餐的桌台设置了固定用餐标准，需服务员在客户端确认";
    public static String ERROR_ON_MIN_STANDARD = "您当前就餐的桌台设置了最低消费标准，需服务员在客户端确认";

    /**
     * 删除餐标模式下加上的 餐标服务费/低消服务费 菜品
     */
    public static void clearMenuOfDinnerStandard(OrderCache orderCache) {
        if (orderCache == null) {
            return;
        }
        if (ListUtil.isEmpty(orderCache.originMenuList)) {
            return;
        }
        if (orderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0 || orderCache.minStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            for (int i = orderCache.originMenuList.size() - 1; i >= 0; i--) {
                MenuItem menuItem = orderCache.originMenuList.get(i);
                if (menuItem == null) {
                    continue;
                }
                //餐标服务费/低消服务费
                if (isStandardMenu(menuItem.itemID)) {
                    orderCache.originMenuList.remove(menuItem);
                }
            }
        }
    }

    /**
     * 从ordercache得到某个菜品
     *
     * @param orderCache
     * @param menuItemCd
     * @return
     */
    private static MenuItem getMenuItem(OrderCache orderCache, String menuItemCd) {
        if (orderCache == null) {
            return null;
        }
        return getMenuItem(orderCache.originMenuList, menuItemCd);
    }

    /**
     * 从ordercache得到某个菜品
     */
    private static MenuItem getMenuItem(List<MenuItem> menuItems, String menuItemCd) {
        if (ListUtil.isEmpty(menuItems)) {
            return null;
        }
        for (int i = menuItems.size() - 1; i >= 0; i--) {
            MenuItem menuItem = menuItems.get(i);
            if (menuItem == null) {
                continue;
            }
            if (TextUtils.equals(menuItem.itemID, menuItemCd)) {
                return menuItem;
            }
        }
        return null;
    }

    /**
     * 添加餐标服务费菜品
     *
     * @param orderCache
     * @return
     */
    public static boolean addDinnerStandardServiceMenu(OrderCache orderCache) {
        if (orderCache == null) {
            return false;
        }
        //如果开启了餐标，并且计入餐标的菜品总额 比 餐标金额 小的情况下，添加餐标服务费菜品
        if (orderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0 && orderCache.diningStandardMenusAmt.compareTo(orderCache.diningStandardAmt) < 0) {
            return addDinnerStandardMenu(orderCache, DS_MENU_ID, orderCache.diningStandardAmt);
        }
        return false;
    }

    /**
     * 添加低消服务费菜品
     *
     * @param orderCache
     * @return
     */
    public static boolean addMinStandardServiceMenu(OrderCache orderCache) {
        if (orderCache == null) {
            return false;
        }
        //如果设置了最低消费金额，并且待支付金额 比 最低消费金额 小的情况下，添加低消服务费菜品
        if (orderCache.minStandardAmt.compareTo(BigDecimal.ZERO) > 0 && orderCache.optTotalMenuPrice().compareTo(orderCache.minStandardAmt) < 0) {
            if (orderCache.minStandardAmt.compareTo(orderCache.diningStandardAmt) < 0) {
                return addDinnerStandardMenu(orderCache, MS_MENU_ID, BigDecimal.ZERO);
            }
            return addDinnerStandardMenu(orderCache, MS_MENU_ID, orderCache.minStandardAmt.subtract(orderCache.diningStandardAmt));
        }
        return false;
    }

    /**
     * 订单菜品是否全退
     *
     * @return true则全退
     */
    public static boolean isOrderAllVoid(OrderCache orderCache) {
        if (orderCache != null
                && !ListUtil.isEmpty(orderCache.originMenuList)) {
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (menuItem != null && !menuItem.hasAllVoid() && !isStandardMenu(menuItem.itemID)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * 更新餐标模式下新加的 低消服务费菜品金额 和 餐标服务费菜品金额
     *
     * @param orderCache
     * @return
     */
    public static void updateDinnerStandardMenuPrice(OrderCache orderCache) {
        boolean addDiningStandardMenuResult = false;
        boolean addMinStandardMenuResult = false;
        if (orderCache == null) {
            return;
        }
        LogUtil.logBusiness(TAG, "更新餐标、低消补充菜品金额，订单：" + orderCache.orderID);

        // 临时变量，记录补充的餐标菜品金额变化
        BigDecimal tempDiff = BigDecimal.ZERO;
        // 菜品是否全退，全退则补充菜品金额全部置0
        boolean orderAllVoid = isOrderAllVoid(orderCache);

        //如果开启了餐标
        if (orderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            // 餐标补充菜品
            MenuItem dinnerStandardMenu = getMenuItem(orderCache, DS_MENU_ID);
            if (dinnerStandardMenu != null) {
                // 上一次补充的餐标菜品的金额
                BigDecimal oldDinnerStandardMenuPrice = dinnerStandardMenu.menuBiz.totalPrice;
                // 本次计入餐标的实际菜品（不包括餐标补充菜品金额）的金额 = 本次计入餐标的实际菜品（包括餐标补充菜品金额）的金额 - 上一次补充的餐标菜品的金额
                BigDecimal realAmtWithinStandard = orderCache.diningStandardMenusAmt.subtract(oldDinnerStandardMenuPrice);
                // 计入餐标的菜品总额 < 餐标金额
                if (!orderAllVoid && realAmtWithinStandard.compareTo(orderCache.diningStandardAmt) < 0) {
                    // 要新加的补充餐标菜品金额 = 餐标 - 本次计入餐标的实际菜品（不包括餐标补充菜品金额）的金额
                    BigDecimal newDinnerStandardMenuPrice = orderCache.diningStandardAmt.subtract(realAmtWithinStandard);
                    // 如果新的补充金额和旧的补充金额一样，不再更新补充菜品金额
                    if (oldDinnerStandardMenuPrice.compareTo(newDinnerStandardMenuPrice) == 0) {
                        addDiningStandardMenuResult = false;
                    } else {// 新旧补充金额不一样
                        // 记录差值
                        tempDiff = oldDinnerStandardMenuPrice.subtract(newDinnerStandardMenuPrice);
                        setMenuPrice(dinnerStandardMenu, newDinnerStandardMenuPrice);
                        addDiningStandardMenuResult = true;
                    }
                } else {// 计入餐标的餐品金额 >= 餐标金额，则补充金额为0
                    // 旧的金额已经为0，不再更新，否则直接更新为0
                    if (oldDinnerStandardMenuPrice.compareTo(BigDecimal.ZERO) == 0) {
                        addDiningStandardMenuResult = false;
                    } else {
                        tempDiff = oldDinnerStandardMenuPrice;
                        setMenuPrice(dinnerStandardMenu, BigDecimal.ZERO);
                        addDiningStandardMenuResult = true;
                    }
                }
                LogUtil.logBusiness(TAG, "更新餐标补充菜品金额：餐标金额为[" + orderCache.diningStandardAmt +
                        "], 计入餐标的实际菜品（包括餐标补充菜品金额）的金额为[" + orderCache.diningStandardMenusAmt +
                        "], 上一次补充的餐标菜品的金额[" + oldDinnerStandardMenuPrice +
                        "], 新旧补充餐标菜品金额差值[" + tempDiff + "]");
            }
        }


        //如果设置了最低消费金额，并且待支付金额 比 最低消费金额 小的情况下，更新低消服务费菜品金额
        MenuItem minStandardMenu = getMenuItem(orderCache, MS_MENU_ID);
        if (minStandardMenu != null) {
            // 上一次补充的低消菜品的金额
            BigDecimal oldMinStandardMenuPrice = minStandardMenu.menuBiz.totalPrice;
            // 使用了低消
            if (orderCache.minStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
                // 实际菜品金额（包括餐标补充，不包括低消补充） = 新的菜品总额（包括：真实菜品总金额+上次餐标补充+上次低消补充）- 餐标补充新旧差值 - 上次低消补充金额
                BigDecimal realAmtWithoutMinStandard = orderCache.optTotalMenuPrice().subtract(tempDiff).subtract(oldMinStandardMenuPrice);
                // 开了餐标模式，如果 计入餐标的菜品总和(菜品总额-不计入餐标的菜品总和) > 餐标金额,则实际菜品金额 = 餐标金额 + 不计入餐标的菜品总和
                if (orderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0 && (realAmtWithoutMinStandard.subtract(orderCache.withoutDiningStandardMenusAmt)).compareTo(orderCache.diningStandardAmt) >= 0) {
                    realAmtWithoutMinStandard = orderCache.diningStandardAmt.add(orderCache.withoutDiningStandardMenusAmt);
                }

                // 服务费及圆整
                BigDecimal serviceAndRound = orderCache.optTotalPrice().subtract(orderCache.optTotalMenuPrice());
                realAmtWithoutMinStandard = realAmtWithoutMinStandard.add(serviceAndRound);

                // realAmtWithoutMinStandard < 低消金额
                if (!orderAllVoid && realAmtWithoutMinStandard.compareTo(orderCache.minStandardAmt) < 0) {
                    // 要新加的补充低消菜品金额 = 低消 - realAmtWithoutMinStandard
                    BigDecimal newMinStandardMenuPrice = orderCache.minStandardAmt.subtract(realAmtWithoutMinStandard);
                    // 如果新的补充金额和旧的补充金额一样，不再更新补充菜品金额
                    if (oldMinStandardMenuPrice.compareTo(newMinStandardMenuPrice) == 0) {
                        addMinStandardMenuResult = false;
                    } else {
                        setMenuPrice(minStandardMenu, newMinStandardMenuPrice);
                        addMinStandardMenuResult = true;
                    }
                } else {// realAmtWithoutMinStandard >= 低消金额，则补充金额为0
                    // 旧的金额已经为0，不再更新，否则直接更新为0
                    if (oldMinStandardMenuPrice.compareTo(BigDecimal.ZERO) == 0) {
                        addMinStandardMenuResult = false;
                    } else {
                        setMenuPrice(minStandardMenu, BigDecimal.ZERO);
                        addMinStandardMenuResult = true;
                    }
                }
                LogUtil.logBusiness(TAG, "更新低消补充菜品金额：低消金额为[" + orderCache.minStandardAmt +
                        "], orderCache.optTotalMenuPrice为[" + orderCache.optTotalMenuPrice() +
                        "], 上一次补充的低消菜品的金额[" + oldMinStandardMenuPrice + "]");
            } else {// 未启用低消
                // 旧的金额已经为0，不再更新，否则直接更新为0
                if (oldMinStandardMenuPrice.compareTo(BigDecimal.ZERO) == 0) {
                    addMinStandardMenuResult = false;
                } else {
                    setMenuPrice(minStandardMenu, BigDecimal.ZERO);
                    addMinStandardMenuResult = true;
                }
            }
        }

        // 餐标补充、低消补充有一个更新了，重新计算订单金额
        if (addDiningStandardMenuResult || addMinStandardMenuResult) {
            orderCache.reCalcAllByAll();
        }
    }

    /**
     * 添加某个菜品
     *
     * @param orderCache
     * @param menuItemCd
     * @param amount
     * @return
     */
    private static boolean addDinnerStandardMenu(OrderCache orderCache, String menuItemCd, BigDecimal amount) {
        if (orderCache == null || TextUtils.isEmpty(menuItemCd)) {
            return false;
        }

        MenuItem serviceMenu = getMenuItem(orderCache, menuItemCd);

        if (serviceMenu == null) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelBy(menuItemCd);
            if (itemDB == null) {
                return false;
            }
            //规格id
            MenuItemUnitDBModel unitDBModel = MenuDBUtil.getMenuDefaultUnit(menuItemCd);
            //匹配到本地菜品
            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null, true);
            if (menuItem == null) {
                return false;
            }
            menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
            if (menuItem.currentUnit == null) {
                menuItem.currentUnit = new UnitModel();
            }
            if (menuItem.menuBiz == null) {
                menuItem.menuBiz = new MenuBiz();
            }
            if (TextUtils.equals(menuItemCd, DS_MENU_ID)) {
                menuItem.menuBiz.addConfig(256);
            }
            menuItem.menuBiz.generateUniq();
//            menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
            menuItem.menuBiz.orderSeqID = 0;
            //价格
            setMenuPrice(menuItem, amount);
            orderCache.originMenuList.add(menuItem);
        } else {
            setMenuPrice(serviceMenu, amount);
        }
        return true;
    }

    private static void setMenuPrice(MenuItem menuItem, BigDecimal amount) {
        menuItem.price = amount;
        menuItem.currentUnit.fdOriginPrice = amount;
        menuItem.currentUnit.fdSalePrice = amount;
        menuItem.currentUnit.fdVIPPrice = amount;
        menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
        menuItem.menuBiz.totalPrice = amount;
        if (BigDecimal.ZERO.compareTo(amount) < 0) {
            menuItem.menuBiz.buyNum = BigDecimal.ONE;
        } else {
            menuItem.menuBiz.buyNum = BigDecimal.ZERO;
        }
    }

    /**
     * 得到最低消费金额
     *
     * @param areaId
     * @return
     */
    public static BigDecimal getMinStandardAmt(String areaId) {
        String sql = "select fdMinStandardAmt from areaBiz where fsMAreaId = '" + areaId + "' and fiMinStandardStatus = '1' and fiStatus = '1' ";
        String fdMinStandardAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return TextUtils.isEmpty(fdMinStandardAmt) ? BigDecimal.ZERO : new BigDecimal(fdMinStandardAmt);
    }

    /**
     * 得到最低消费金额
     *
     * @param tableId
     * @return
     */
    public static BigDecimal getMinStandardAmtByTableId(String tableId) {
        String sql = "select fdMinStandardAmt from areaBiz inner join (select fsmareaid from (select * from tbmtable where fsmtableid='" + tableId + "')) as temp on areaBiz.fsmareaid=temp.fsmareaid where areaBiz.fiMinStandardStatus = '1' and areaBiz.fiStatus = '1' ";
        String fdMinStandardAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return TextUtils.isEmpty(fdMinStandardAmt) ? BigDecimal.ZERO : new BigDecimal(fdMinStandardAmt);
    }

    /**
     * 通过区域Id获取区域业务（业务中心调用）
     */
    public static AreaBizDBModel getAreaBizByAreaId(String areaId) {
        if (TextUtils.isEmpty(areaId)) {
            return new AreaBizDBModel();
        }
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM areaBiz " +
                " WHERE fsMAreaId='" + areaId + "' AND fiStatus='1'", AreaBizDBModel.class);
    }

    /**
     * 更新订单OrderCache的最低消费金额为areaBiz中最新设置的低消金额
     *
     * @param orderCache 订单
     * @param fsmareaid  区域Id
     * @return true则orderCache中低消改了，false则没改，这里不重新计算订单金额，如需要，请在外部自行调用
     */
    public static boolean minStandardChanged(OrderCache orderCache, String fsmareaid, UserDBModel user) {
        if (orderCache == null || TextUtils.isEmpty(fsmareaid)) {
            return false;
        }

        // 低消开关关闭
        if (!DBMetaUtil.isConfigOpen(META.OPEN_MIN_STANDARD, "1", "0")) {
            orderCache.minStandardAmt = BizConstant.NEGATIVE;
            return true;
        }

        AreaBizDBModel areaBiz = getAreaBizByAreaId(fsmareaid);
        if (areaBiz == null) {
            return false;
        }

        BigDecimal originMinStandardAmt = orderCache.minStandardAmt;
        int newMinStandardStatus = areaBiz.fiMinStandardStatus;
        BigDecimal newMinStandardAmt = areaBiz.fdMinStandardAmt;
        // 未使用最低消费 || 使用了最低消费且金额与数据库中最新最低消费金额相等 -> 不更新最低消费
        if ((originMinStandardAmt.compareTo(BigDecimal.ZERO) <= 0 && newMinStandardStatus == 0) ||
                (originMinStandardAmt.compareTo(BigDecimal.ZERO) > 0 && newMinStandardStatus == 1 && originMinStandardAmt.compareTo(newMinStandardAmt) == 0)) {
            return false;
        }

        // 更新最低消费金额
        if (newMinStandardStatus == 1) { // 使用最低消费
            orderCache.minStandardAmt = newMinStandardAmt;
        } else {
            orderCache.minStandardAmt = BizConstant.NEGATIVE;
        }

        if (getMenuItem(orderCache, MS_MENU_ID) == null) {// 开关开启，但没有低消服务费菜品，这里加一下
            boolean addResult = addMinStandardServiceMenu(orderCache);
            if(addResult){
                //添加成功，则单序+1,状态为已下单
                orderCache.updateSeqStatus(0, OrderSeqStatus.ORDERED, user, orderCache.currentHostID);
            }
        }
        return true;
    }

    /**
     * 是否餐标、低消服务费
     *
     * @param fiItemCd 菜品id
     * @return true是，false不是
     */
    public static boolean isStandardMenu(String fiItemCd) {
        return TextUtils.equals(fiItemCd, DS_MENU_ID) || TextUtils.equals(fiItemCd, MS_MENU_ID);
    }

    public static BigDecimal optLeftPriceWhenUseStandard(OrderCache orderCache) {
        if (orderCache == null) {
            return BigDecimal.ZERO;
        }
        return optLeftPriceWhenUseStandard(orderCache.diningStandardAmt, orderCache.minStandardAmt, orderCache.withoutDiningStandardMenusAmt, orderCache.optTotalMenuPrice());
    }

    public static BigDecimal optLeftPriceWhenUseStandard(TempOrderDishesCache tempOrder) {
        if (tempOrder == null) {
            return BigDecimal.ZERO;
        }
        return optLeftPriceWhenUseStandard(tempOrder.diningStandardAmt, tempOrder.minStandardAmt, tempOrder.tempTotalMenuPriceWithoutStandard, tempOrder.tempTotalPrice);
    }

    /**
     * 使用了标准时，获取待支付金额
     *
     * @param diningStandardAmt             设置的固定用餐标准金额
     * @param minStandardAmt                设置的最低消费标准金额
     * @param withoutDiningStandardMenusAmt 不计入餐标的菜品金额
     * @param totalPrice                    订单总额
     * @return 与标准对比，矫正后的待支付金额
     */
    private static BigDecimal optLeftPriceWhenUseStandard(BigDecimal diningStandardAmt, BigDecimal minStandardAmt,
                                                          BigDecimal withoutDiningStandardMenusAmt, BigDecimal totalPrice) {
        BigDecimal result = totalPrice;
        //订单总额为0，直接返回（如：全部退菜）
        if (BigDecimal.ZERO.compareTo(result) == 0) {
            return result;
        }
        if (diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            // 餐标 + 不计入餐标菜品金额 <= 低消时；待支付 = 低消
            // 餐标 + 不计入餐标菜品金额 >  低消时；待支付 = 餐标 + 不计入餐标菜品金额
            if (diningStandardAmt.add(withoutDiningStandardMenusAmt).compareTo(minStandardAmt) <= 0) {
                result = minStandardAmt;
            } else {
                result = diningStandardAmt.add(withoutDiningStandardMenusAmt);
            }
        } else if (minStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            // 待支付 < 最低消费标准 -> 待支付 = 最低消费标准
            if (totalPrice.compareTo(minStandardAmt) < 0) {
                result = minStandardAmt;
            }
        }
        return result;
    }

    /**
     * 是否满足了最低消费
     *
     * @param whatId int | 1-则参数id为areaId，2-则参数id为tableId
     * @return true则满足，菜品列表为空时为true
     */
    public static boolean isFillMinStandard(String id, int whatId, List<MenuItem> menuItems, BigDecimal totalPrice) {
        if (TextUtils.isEmpty(id)) {
            return true;
        }
        if (!DBMetaUtil.isConfigOpen(META.OPEN_MIN_STANDARD, "1", "0")) {
            return true;
        }
        // 该区域的最低消费金额
        BigDecimal minStandardAmt = BizConstant.NEGATIVE;
        if (whatId == 1) {
            minStandardAmt = getMinStandardAmt(id);
        } else if (whatId == 2) {
            minStandardAmt = getMinStandardAmtByTableId(id);
        }
        // 未设置最低消费金额 || 订单金额超过最低消费 -> 满足最低消费
        MenuItem minStandardMenu = getMenuItem(menuItems, MS_MENU_ID);
        BigDecimal minStandardMenuPrice = minStandardMenu == null ? BigDecimal.ZERO : minStandardMenu.menuBiz.totalPrice;
        if (minStandardAmt.compareTo(BigDecimal.ZERO) <= 0 || minStandardAmt.compareTo(totalPrice.subtract(minStandardMenuPrice)) <= 0) {
            return true;
        }
        return false;
    }

    /**
     * 校验使用餐标时是否允许结账
     * 当前使用场景：秒付
     *
     * @return 错误信息，若为""表示校验通过
     */
    public static String checkDinnerStandardPayExcludeMinStandard(OrderCache orderCache) {
        if (orderCache == null) {
            return "";
        }
        if (orderCache.isDiningStandard()) {
            return ERROR_ON_DINING_STANDARD;
        }
        return "";
    }

    /**
     * 校验使用餐标时是否允许结账
     * 当前使用场景：秒付
     *
     * @return 错误信息，若为""表示校验通过
     */
    public static String checkDinnerStandardPayExcludeMinStandard(TempOrderDishesCache tempOrder) {
        if (tempOrder == null) {
            return "";
        }
        if (tempOrder.isDiningStandard()) {
            return ERROR_ON_DINING_STANDARD;
        }
        return "";
    }

    /**
     * 校验使用餐标/低消时是否允许结账
     * 当前使用场景：美小二
     *
     * @return 错误信息，若为""表示校验通过
     */
    public static String checkDinnerStandardPay(OrderCache orderCache) {
        if (orderCache == null) {
            return "";
        }
        if (orderCache.isDiningStandard()) {
            return ERROR_ON_DINING_STANDARD;
        }
        if (!isFillMinStandard(orderCache.fsmareaid, 1, orderCache.originMenuList, orderCache.totalPrice)) {
            return ERROR_ON_MIN_STANDARD;
        }
        return "";
    }

    /**
     * 校验使用餐标/低消时是否允许结账
     * 当前使用场景：美小二
     *
     * @return 错误信息，若为""表示校验通过
     */
    public static String checkDinnerStandardPay(TempOrderDishesCache tempOrder) {
        if (tempOrder == null) {
            return "";
        }
        if (tempOrder.isDiningStandard()) {
            return ERROR_ON_DINING_STANDARD;
        }
        if (!isFillMinStandard(tempOrder.fsmareaid, 1, tempOrder.tempSelectedMenuList, tempOrder.tempTotalPrice)) {
            return ERROR_ON_MIN_STANDARD;
        }
        return "";
    }

    /**
     * 设置是否将菜品计入到餐标
     */
    public static void placeMenuIntoStandard(MenuItem item, boolean isAdd) {
        if (item == null) {
            return;
        }

        if (isAdd) {
            item.menuBiz.addConfig(256);
        } else {
            item.menuBiz.decreasConfig(256);
        }
        if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
            for (MenuItem modifier : item.menuBiz.selectedModifier) {
                if (isAdd) {
                    modifier.menuBiz.addConfig(256);
                } else {
                    modifier.menuBiz.decreasConfig(256);
                }
            }
        }
        if (!ListUtil.isEmpty(item.menuBiz.selectedPackageItems)) {
            for (MenuItem packageItem : item.menuBiz.selectedModifier) {
                if (isAdd) {
                    packageItem.menuBiz.addConfig(256);
                } else {
                    packageItem.menuBiz.decreasConfig(256);
                }
            }
        }
    }

    /**
     * 批量设置菜品是否计入餐标
     *
     * @param menuItems 菜品列表
     * @param within    是否计入餐标，true则计入，false则不计入
     */
    public static void batchPlaceMenuIntoStandard(List<MenuItem> menuItems, boolean within) {
        if (ListUtil.isEmpty(menuItems)) {
            return;
        }
        for (MenuItem item : menuItems) {
            if (item == null || item.menuBiz == null) {
                continue;
            }
            DinnerStandardUtil.placeMenuIntoStandard(item, within);
        }
    }
}
