package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2017/5/9.
 * 退菜单信息
 * 套餐只打印套餐明细
 * 配料作为备注打印
 */
public class VoidItemBean extends PrintItemDataBean {

    @ColumnInf(name = "fdBackQty")
    public BigDecimal fdBackQty = BigDecimal.ZERO;  //退菜数量

    public String parentItemName = ""; //套餐头名称
    /**
     * 所有配料： 鱼丸*3;虾球*2；
     */
    public String ingredientNotes = "";
}
