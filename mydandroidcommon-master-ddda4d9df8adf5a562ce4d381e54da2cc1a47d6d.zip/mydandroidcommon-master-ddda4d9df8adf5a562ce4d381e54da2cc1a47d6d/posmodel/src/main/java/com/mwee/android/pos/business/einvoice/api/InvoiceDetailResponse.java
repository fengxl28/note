package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.pos.business.einvoice.model.InvoiceDetailBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;

/**
 * author:luoshenghua
 * create on:2018/5/8
 * description:电子发票详情响应
 */
public class InvoiceDetailResponse extends BasePosResponse {
    public ArrayList<InvoiceDetailBean> data;

    public InvoiceDetailResponse() {

    }
}
