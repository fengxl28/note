package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiFutureRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 更新口碑预点单  后付款状态
 */
@HttpParam(httpType = HttpType.POST,
        method = "kbPushSign",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class KBFuturePushSignRequest extends BaseKouBeiFutureRequest {


    /**
     * 订单id
     */
    public String orderId;

    /**
     * 订单批次号
     */
    public String batchNo;
    /**
     * 接单结果
     * 必传 接单：RECEIPT 拒单：REJECT
     */
    public String receiptCode;
    /**
     * 拒单原因编码
     * <p>
     * 拒单时必传，
     * TABLE_NOT_EXIST 桌号不存在,请联系服务员
     * BUSY 店铺太忙,无法接待
     * DUPLICATE_ORDER 重复订单
     * SHOP_CLOSE 店铺已打烊
     * SELL_OUT 菜品售完
     * OTHER_REASON 其他原因
     */
    public String rejectReasonCode;
    /**
     * 拒单原因描述
     */
    public String rejectReasonDesc;
    /**
     * pos订单号
     * 接单时必传
     */
    public String outBizNo;

    public int sourceType;

    public static class SourceType {
        public static final int MYD = 1;
        public static final int MXY = 2;
    }

    public KBFuturePushSignRequest() {

    }


}
