package com.mwee.android.pos.business.netpay;

import android.support.annotation.IntDef;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @ClassName: OnlinePayType
 * @Description: 在线支付方式类型
 * @author: SugarT
 * @date: 2018/4/25 上午10:54
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@IntDef(value = {OnlinePayType.WeChat, OnlinePayType.Ali})
public @interface OnlinePayType {

    /**
     * 微信
     */
    int WeChat = 1;

    /**
     * 支付宝
     */
    int Ali = 2;
}