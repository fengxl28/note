package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.StringUtil;

/**
 * 在线支付订单查询 请求实体
 * Created by qinwei on 2017/1/11.
 */
@HttpParam(httpType = HttpType.POST,
        method = "gettodayorderall",
        response = RapidPaySearchResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class RapidPaySearchRequest extends BasePosRequest {
    /**
     * 业务类型 [-9999表示查所有业务类型] 业务类型
     * (0点菜，1预点单  2预约，3快餐，4外卖，5纯收银，6取餐盒，
     * 7POS刷卡，8第三方平台点菜，9自助买单，10会员充值，11APP自助买单，
     * 12点菜宝收银，13扫桌号点菜，14点菜宝手持设备点菜，15WIN POS收银，
     * 16热餐配送，17冷餐配送，18扫码枪，19预约到店，20美小二，
     * 21pos拉单，22预付单，23预订转秒点)
     */
    public String bizType;
    public String payStatus;//支付状态 [-9999表示查所有支付状态] (-2支付失败，-1已退款，0，未支付, 1部分支付，2已支付，3已就餐)
    public String mobile;//手机号或交易号
    public String qryDate;//查询日期(格式：2016-09-01 不传默认查当天)
    public String page;//页码
    public String itemsPerPage;//分页值
}
