package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.ActiveNoNameCardBean;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 激活不记名实体卡
 */

public class ActiveNoNameCardResponse extends BaseMemberResponse {
    /**
     * 激活结果
     */
    public ActiveNoNameCardBean data;

    public ActiveNoNameCardResponse() {
    }
}
