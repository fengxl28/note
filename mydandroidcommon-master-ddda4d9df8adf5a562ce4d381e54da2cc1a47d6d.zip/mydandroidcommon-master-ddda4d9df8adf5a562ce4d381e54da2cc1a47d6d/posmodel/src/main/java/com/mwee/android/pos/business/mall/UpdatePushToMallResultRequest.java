package com.mwee.android.pos.business.mall;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.component.datasync.net.BaseWmPosRequest;
import com.mwee.android.tools.StringUtil;

@HttpParam(httpType = HttpType.POST,
        method = "updatePush",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 120)
public class UpdatePushToMallResultRequest extends BaseWmPosRequest {

    public String id = "";
    public JSONObject upLoadMsg;

    public UpdatePushToMallResultRequest() {
    }
}