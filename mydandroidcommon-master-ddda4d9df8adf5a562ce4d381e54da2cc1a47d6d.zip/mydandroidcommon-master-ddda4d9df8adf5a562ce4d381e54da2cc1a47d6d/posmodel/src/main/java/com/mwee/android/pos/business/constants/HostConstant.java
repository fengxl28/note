package com.mwee.android.pos.business.constants;

/**
 * Created by liuxiuxiu on 2017/4/26.
 * 站点相关常量
 */
public class HostConstant {

    public static final int ORDER_DISHES_HOST = 11;  //点菜站点
    public static final int CASHIER_HOST = 12;      //收银站点
    public static final int FASTFOOD_HOST = 13;     //快餐站点
    public static final int SUPER_HOST = 14;        //超级站点
    public static final int KDS_MAKE = 15;        //KDS制作站点
    public static final int KDS_CHEF = 16;        //KDS大屏站点
}
