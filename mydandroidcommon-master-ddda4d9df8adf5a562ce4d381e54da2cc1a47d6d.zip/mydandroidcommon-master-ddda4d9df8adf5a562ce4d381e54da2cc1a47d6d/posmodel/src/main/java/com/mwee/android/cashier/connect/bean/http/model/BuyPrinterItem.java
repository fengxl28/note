package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * @author changsunhaipeng
 * @date 2018/7/5
 */

public class BuyPrinterItem extends BusinessBean {
    public String guid;
    public int printUrlId;
    public String shopGUID;
    public String printerURL;
    public int status;
}
