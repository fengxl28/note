package com.mwee.android.pos.business.rapid.api.bean.model;

/**
 * Created by virgil on 2017/7/24.
 */

public class NetOrderType {
    /**
     * 秒付纯收银
     */
    public final static int RAPID_ONLY_PAY = 11;

    /**
     * 普通秒点
     */
    public final static int RAPID_NORMAL = 14;
    /**
     * 普通秒点
     */
    public final static int RAPID_PAY = 15;
    /**
     * 全能pos拉单
     */
    public final static int PAY_SMART_POS = 21;
    /**
     * 先付款的秒点
     */
    public final static int RAPID_PRE_PAY = 22;
    /**
     * 预点单
     */
    public final static int PRE_ORDER = 23;

    /**
     * 先付款-共享餐厅
     */
    public final static int PRE_PAY_SHARE_SHOP = 66;

    /**
     * 网络订单
     */
    public final static int NET_ORDER = 10000;

    /**
     * 口碑预点单订单
     */
    public final static int KB_ORDER = 88;

    /**
     * 口碑后付款订单
     */
    public final static int KB_AFTER_PAY_ORDER = 89;

    /**
     * 口碑后付--付款信息
     */
    public final static int KB_AFTER_PAY = 90;

    /**
     * 是否是共享餐厅的
     *
     * @param bizType int
     * @return boolean
     */
    public static boolean isShareShopPrePay(int bizType) {
        return bizType == NetOrderType.PRE_PAY_SHARE_SHOP;
    }

    /**
     * 先付款秒点
     *
     * @return boolean
     */
    public static boolean isRapidPrePay(int bizType) {
        return bizType == NetOrderType.RAPID_PRE_PAY;
    }

    /**
     * 是否是纯收银
     *
     * @return boolean
     */
    public static boolean isRapidOnlyPay(int bizType) {
        return bizType == NetOrderType.RAPID_ONLY_PAY;
    }

    /**
     * 常规的秒点、秒付、全能pos的拉桌台支付
     *
     * @return boolean
     */
    public static boolean isRapid(int bizType) {
        return bizType == NetOrderType.RAPID_NORMAL || bizType == NetOrderType.RAPID_PAY || bizType == PAY_SMART_POS;
    }

    /**
     * 是否是全能支付
     *
     * @return boolean
     */
    public static boolean isSmartPayPos(int bizType) {
        return bizType == PAY_SMART_POS;
    }


    /**
     * 是否是口碑后付
     *
     * @return boolean
     */
    public static boolean isKBAfterPay(int bizType) {
        return bizType == KB_AFTER_PAY;
    }

    /**
     * 预点单
     *
     * @return boolean
     */
    public static boolean isPreOrder(int bizType) {
        return bizType == NetOrderType.PRE_ORDER;
    }

    /**
     * 口碑先付款模式的订单
     *
     * @param bizType
     * @return
     */
    public static boolean isKouBeiOrder(int bizType) {
        return bizType == NetOrderType.KB_ORDER;
    }

}
