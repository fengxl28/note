package com.mwee.android.pos.business.shift;

import com.mwee.android.pos.business.shift.model.UnShiftModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.List;

/**
 * 登录到业务中心的Response
 * Created by virgil on 16/9/22.
 */
public class GetUnFinishedShiftResponse extends BaseSocketResponse {

    /**
     * 未交班的列表
     */
    public List<UnShiftModel> unShiftList = null;

    public String printConfig;

    public GetUnFinishedShiftResponse() {
        //code -1 主站点尚未开业
        //code -2 当前站点数据需要更新
        //code -3 主站点数据需要更新
    }
}
