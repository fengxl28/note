package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/25.
 */

public class KPreTempDinnerModelContainer extends BusinessBean {

    public List<KPreTempDinnerModel> koubeiOrder = new ArrayList<>();

}
