package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

public class MenuItemsResponse extends BaseSocketResponse {

    public List<MenuItemBean> menuItemBeanList = new ArrayList<>();

    public MenuItemsResponse() {

    }
}
