package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.tools.StringUtil;

/**
 * Created by virgil on 2016/11/3.
 */

@HttpParam(httpType = HttpType.POST,
        method = "putwl",
        response = RapidActionResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        saveToLog = true,
        timeOut = 10,
        gzip = false)
public class RapidActionRequset extends BasePosRequest {
    public String fsid = "";//uuid
    //    public String fscreatetime = "2016-11-03 14:47:02";
//    public String fsupdatetime = "2016-11-03 14:47:02";
//2成功，4失败
    public int fistate = 2;
    //任务
    public String fsaction = "call";
    public String fstdata = "";
    //返回数据信息
    public String fsrdata = "";
    //错误信息
    public String fserror = "";

    public RapidActionRequset() {

    }

    @Override
    public int chunkLen() {
        return APPConfig.sChunkLen;
    }

}
