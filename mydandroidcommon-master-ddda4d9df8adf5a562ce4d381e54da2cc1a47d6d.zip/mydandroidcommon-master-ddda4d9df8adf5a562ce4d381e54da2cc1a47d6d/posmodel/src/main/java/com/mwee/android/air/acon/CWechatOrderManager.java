package com.mwee.android.air.acon;

import android.support.v4.util.ArrayMap;

import com.mwee.android.air.connect.business.wechatorder.GetWechatSettingResponse;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public interface CWechatOrderManager extends CBase {

    /**
     * 获取外卖设置数据
     *
     * @return String
     */
    @SocketParam(uri = "airWechatOrderManager/loadWechatOrderSetting", response = GetWechatSettingResponse.class)
    String loadWechatOrderSetting();

    /**
     * 更新外卖设置
     *
     * @return String
     */
    @SocketParam(uri = "airWechatOrderManager/updateWechatOrderSetting", response = BaseSocketResponse.class)
    String updateWechatOrderSetting(@SF("settings") ArrayMap<String, String> settings);

}
