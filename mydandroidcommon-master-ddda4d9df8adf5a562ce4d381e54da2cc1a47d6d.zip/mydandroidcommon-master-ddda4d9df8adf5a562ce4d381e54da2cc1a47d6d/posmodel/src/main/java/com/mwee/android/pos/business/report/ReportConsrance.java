package com.mwee.android.pos.business.report;

import android.support.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @ClassName: ReportConsrance
 * @Description:
 * @author: SugarT
 * @date: 2016/12/5 下午4:39
 */
public class ReportConsrance {

    /**
     * 报表固化保存天数
     */
    public static final int SAVE_DAYS = 60;

    /**
     * 所有保存报表的列表
     * 检查当日报表是否已完全保存时用
     */
    public static final String[] ALL_SAVE_REPORTS = new String[] {
            "report/sale",
            "report/num",
            "report/void",
            "report/gift",
            "report/maxSaleQuantity",
            "report/maxSalePrice",
            "report/reportDept",
            "report/reportTime",
            "report/reportAllDiscount"
    };

    /* ================ 报表类别 ================ */
    public static final String REPORT_NONE = "";
    /**
     * 日结表
     */
    public static final String REPORT_DAILY = "report/sale";
    /**
     * 新日结表
     */
    public static final String REPORT_NEW_DAILY = "report/newSale";
    /**
     * 销售数量表
     */
    public static final String REPORT_SALE = "report/num";
    /**
     * 退菜明细表
     */
    public static final String REPORT_VOID = "report/void";
    /**
     * 赠菜明细表
     */
    public static final String REPORT_GIFT = "report/gift";
    /**
     * 折扣报表
     */
    public static final String REPORT_DISCOUNT = "report/discount";
    /**
     * 最高销售数量表
     */
    public static final String REPORT_MAX_SALE_QUANTITY = "report/maxSaleQuantity";
    /**
     * 最高销售金额表
     */
    public static final String REPORT_MAX_SALE_PRICE = "report/maxSalePrice";
    /**
     * 档口统计表
     */
    public static final String REPORT_DEPT = "report/reportDept";
    /**
     * 时段统计表
     */
    public static final String REPORT_TIME = "report/reportTime";

    /**
     * AB账
     */
    public static final String REPORT_AB = "report/ab";

    /**
     * 微信外卖报表
     */
    public static final String WECHAT_ORDE = "report/wechat";
    /**
     * 外卖报表
     */
    public static final String NET_ORDER = "report/netorder";
    /**
     * 美团外卖报表---走虚拟打印机的外卖报表
     */
    public static final String MEITUAN_NET_ORDER = "report/meituanNetOrder";
    /**
     * 微信快餐
     */
    public static final String WECHAT_FAST_FOOD = "report/wechatfastfood";
    /**
     * 收款明细表
     */
    public static final String CHECK_BY_DAY = "report/checkByDay";
    /**
     * 折扣汇总表
     */
    public static final String REPORT_ALL_DISCOUNT = "report/reportAllDiscount";
    /**
     * 会员储值报表
     */
    public static final String REPORT_MEMBER_CHARGE = "report/memberCharge";

    /**
     * 套餐销量汇总表
     */
    public static final String REPORT_BUNDLE_SALE = "report/bundleNum";

    /**
     * 销售分类统计
     */
    public static final String REPORT_SALE_CLS_NUM = "report/saleClsNum";


    /**
     * 收入分类统计
     */
    public static final String REPORT_INCOME_CLS_NUM = "report/incomeClsNum";


    /**
     * 溢收明细
     */
    public static final String REPORT_SURCHARGE_DETAIL = "report/surchargeDetail";


    /* ================ 报表条件过滤 ================ */
    /**
     * 菜品分类
     */
    public static final int FILTER_TYPE_FOOD_CLASS = 0;


    /**
     * 订单来源
     */
    public static final int FILTER_TYPE_ORDER_SOURCE = 1;


    /**
     * 订单类型
     */
    public static final int FILTER_TYPE_ORDER_TYPE = 2;


    /* ================ 报表搜索模式 ================ */

    /**
     * 近七天，热数据
     */

    public static final int QUERY_MODE_LATELY_SEVEN_DAY = 0;

    /**
     * 历史数据，45天内固化数据
     */
    public static final int QUERY_MODE_HISTORY_DATA = 1;



    @StringDef({
            REPORT_NONE,
            REPORT_DAILY,
            REPORT_NEW_DAILY,
            REPORT_SALE,
            REPORT_VOID,
            REPORT_GIFT,
            REPORT_DISCOUNT,
            REPORT_MAX_SALE_QUANTITY,
            REPORT_MAX_SALE_PRICE,
            REPORT_DEPT,
            REPORT_AB,
            WECHAT_ORDE,
            NET_ORDER,
            MEITUAN_NET_ORDER,
            WECHAT_FAST_FOOD,
            CHECK_BY_DAY,
            REPORT_ALL_DISCOUNT,
            REPORT_MEMBER_CHARGE,
            REPORT_BUNDLE_SALE,
            REPORT_SALE_CLS_NUM,
            REPORT_INCOME_CLS_NUM,
            REPORT_SURCHARGE_DETAIL})
    @Retention(RetentionPolicy.SOURCE)
    public @interface ReportCategory {
    }

    /**
     * 根据营业日期存储的报表
     */
    public static final String[] REPORT_BY_BUSINESS_DATE = new String[] {
            REPORT_DAILY,
            REPORT_SALE,
            REPORT_VOID,
            REPORT_GIFT,
            REPORT_DISCOUNT,
            REPORT_MAX_SALE_QUANTITY,
            REPORT_MAX_SALE_PRICE,
            REPORT_DEPT,
            REPORT_TIME,
            REPORT_ALL_DISCOUNT,
            WECHAT_FAST_FOOD,
            REPORT_BUNDLE_SALE
    };

    /**
     * 根据自然日存储的报表
     */
    public static final String[] REPORT_BY_NATURE_DATE = new String[] {
            WECHAT_ORDE,
            NET_ORDER,
            MEITUAN_NET_ORDER,
            CHECK_BY_DAY
    };
}
