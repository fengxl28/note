package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CreditAccount extends BusinessBean {
    /**
     * 信用额度
     */
    public BigDecimal fdCreditAmt = BigDecimal.ZERO;
    /**
     * 挂帐餘額
     */
    public BigDecimal fdDebtAmt = BigDecimal.ZERO;
    /**
     * 可销金额
     */
    public BigDecimal canCrossAmt = BigDecimal.ZERO;
    /**
     * 未销账金额
     */
    public BigDecimal fdBalanceAmt = BigDecimal.ZERO;
    public int fiImgHeight;
    public int fiImgWidth;
    public int fiStatus;
    public String fsCellphoneCt = "";
    public String fsContact = "";
    public String fsCreditAccountId = "";
    public String fsCreditAccountName = "";
    public String fsNote = "";
    public String fsShopGuid = "";
    public String fsTelCt = "";
    public String fsUpdateTime = "";
    public String fsUpdateUserId = "";
    public String fsUpdateUserName = "";


    public CreditAccount() {
    }

    @Override
    public String toString() {
        return "CreditAccount{" +
                "fdCreditAmt=" + fdCreditAmt +
                ", fdDebtAmt=" + fdDebtAmt +
                ", canCrossAmt=" + canCrossAmt +
                ", fdBalanceAmt=" + fdBalanceAmt +
                ", fiImgHeight=" + fiImgHeight +
                ", fiImgWidth=" + fiImgWidth +
                ", fiStatus=" + fiStatus +
                ", fsCellphoneCt='" + fsCellphoneCt + '\'' +
                ", fsContact='" + fsContact + '\'' +
                ", fsCreditAccountId='" + fsCreditAccountId + '\'' +
                ", fsCreditAccountName='" + fsCreditAccountName + '\'' +
                ", fsNote='" + fsNote + '\'' +
                ", fsShopGuid='" + fsShopGuid + '\'' +
                ", fsTelCt='" + fsTelCt + '\'' +
                ", fsUpdateTime='" + fsUpdateTime + '\'' +
                ", fsUpdateUserId='" + fsUpdateUserId + '\'' +
                ", fsUpdateUserName='" + fsUpdateUserName + '\'' +
                '}';
    }
}
