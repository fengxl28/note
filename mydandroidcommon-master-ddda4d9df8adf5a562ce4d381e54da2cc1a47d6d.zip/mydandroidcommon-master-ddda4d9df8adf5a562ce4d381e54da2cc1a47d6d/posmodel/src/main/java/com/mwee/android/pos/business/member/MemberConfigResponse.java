package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * Created by qinwei on 2017/9/8.
 */

public class MemberConfigResponse extends BaseMemberResponse {
    public MemberConfig data = new MemberConfig();

    public MemberConfigResponse() {
    }
}
