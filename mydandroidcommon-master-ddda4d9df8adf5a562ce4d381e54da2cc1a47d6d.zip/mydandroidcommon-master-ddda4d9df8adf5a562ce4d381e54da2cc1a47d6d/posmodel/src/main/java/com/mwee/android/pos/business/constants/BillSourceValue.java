package com.mwee.android.pos.business.constants;

/**
 * fsBillSourceId字段值 订单来源常量
 * Created by qinwei on 2018/8/15.
 */

public class BillSourceValue {
    /**
     * 本店
     */
    public static final String BILL_LOCAL = "1";
    /**
     * 饿了么
     */
    public static final String BILL_TAKE_OUT_ELE = "2";
    /**
     * 美团
     */
    public static final String BILL_TAKE_OUT_MEITUAN = "22";
    /**
     * 微信快餐
     */
    public static final String BILL_WECAHT = "99";
    /**
     * 口碑
     */
    public static final String BILL_KB = "103";

    /**
     * 美小店
     */
    public static final String BILL_MEIXIAODIAN = "910";
}
