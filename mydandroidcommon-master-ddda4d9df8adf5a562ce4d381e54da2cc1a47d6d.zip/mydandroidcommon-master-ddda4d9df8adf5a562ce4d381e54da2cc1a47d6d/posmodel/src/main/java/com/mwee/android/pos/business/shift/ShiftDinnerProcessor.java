package com.mwee.android.pos.business.shift;

import android.content.ContentValues;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.datasync.net.SendCloseMessageRequest;
import com.mwee.android.pos.component.datasync.net.SendSummaryRequest;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.common.ShopServiceUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.BuildConfig;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.HashMap;

/**
 * 正餐的 交班的业务处理类
 * Created by virgil on 2016/11/28.
 */

public class ShiftDinnerProcessor {

    /**
     * 将收银员为"云收银"的所有订单设置为已交班
     *
     * @param businessDate String
     */
    public static void shiftRapidOrder(final String businessDate) {
        String sqlUnlocked = "select order_id from order_pay_cache where  locked='0'  and waiterid='cash' and business_date='" + businessDate + "'";
        final String unfinishOrderID = PaySaveDBUtil.getOrderID(sqlUnlocked);
        if (TextUtils.isEmpty(unfinishOrderID)) {
            return;
        }
        ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
    }

    /**
     * 将外卖单所有订单设置为已交班
     *
     * @param businessDate String
     */
    public static void shiftThirdOrder(final String businessDate) {
        String sqlUnlocked = "select order_id from order_cache where  fiSellType = '2' and business_date='" + businessDate + "'";
        final String unfinishOrderID = PaySaveDBUtil.getOrderID(sqlUnlocked);
        if (TextUtils.isEmpty(unfinishOrderID)) {
            return;
        }
        ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
    }

    /**
     * 更新指定的订单列表为已交班
     *
     * @param unfinishOrderID String
     */
    public static void shiftOrder(final String unfinishOrderID) {
        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            ContentValues values = new ContentValues();

            //将order_pay_cach相关订单设置为已交班
            values.put("locked", "1");
            db.update("order_pay_cache", values, "order_id in (" + unfinishOrderID + ")", null);

            //TODO: 原则上，修改了订单，都可以上报。不开AB账的，就没必要重传了
//                    if (ShopServiceUtil.billOptimize() && AppCache.getInstance().userDBModel.fiBillAuthority == 0) {
//
//                    }

            // winpos后台AB账日结表接口需要判断订单交班状态，所以交班后仍需再一次同步数据(pver 置 0)，否则影响营业报表中的营业收入表使用。详见 <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18940805'>6.10 AB账</a>

            //将tbSellCheck相关订单设置为已交班
            values.clear();
            values.put("fiStatus", "2");
            values.put("pver", "0");
            values.put("locked", "1");
            db.update("tbSellCheck", values, "fsSellNo in (" + unfinishOrderID + ")", null);

            //将tbSell相关订单设置为已交班
            values.clear();
            values.put("pver", "0");
            values.put("locked", "1");
            db.update("tbSell", values, "fsSellNo in (" + unfinishOrderID + ")", null);
            return true;
        });
    }

    /**
     * 店铺打烊推送---通知服务器打烊了
     *
     * @param currentBusinessDate 营业日期
     */
    public static void sendCloseMessageToClud(String currentBusinessDate) {
        SendCloseMessageRequest sendCloseMessageRequest = new SendCloseMessageRequest();
        sendCloseMessageRequest.sellDate = currentBusinessDate;
        sendCloseMessageRequest.overTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        BusinessExecutor.execute(sendCloseMessageRequest, null);
    }

    /**
     * 店铺打烊推送---通知服务器打烊了
     *
     * @param currentBusinessDate 营业日期
     */
    public static void sendSummary(String currentBusinessDate, IResult iResult) {

        String orderItemCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) orderItemCount from tbsellorderItem where fsSellDate = '" + currentBusinessDate + "' ");
        String sellReceiveCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) sellReceiveCount from tbsellreceive where fsSellDate = '" + currentBusinessDate + "' ");
        if (StringUtil.toInt(orderItemCount, 0) <= 0 && StringUtil.toInt(sellReceiveCount, 0) <= 0) {
            if (iResult != null) {
                iResult.callBack(true, "");
            }
            RunTimeLog.addLog(RunTimeLog.SEND_SUMMARY, "上送总结[" + currentBusinessDate + "] -- 中断 原因：当日没有任何营业数据");
            return;
        }

        SendSummaryRequest sendSummaryRequest = new SendSummaryRequest();

        HashMap<String, Object> dailyReport = DailyReportDBUtil.getSellAnalyzeValue(currentBusinessDate, "", 0, "1");
        if (dailyReport == null) {
            dailyReport = new HashMap();
        }
        String orderNumber = "0";
        try {
            Object sellCount = dailyReport.get("SellCount");
            if (sellCount != null) {
                Integer c = (Integer) sellCount;
                orderNumber = String.valueOf(c);
            }
        } catch (Exception e) {
            LogUtil.logError("取值异常：key = 'SellCount' ; dailyReport = " + JSON.toJSONString(dailyReport), e);
        }

        sendSummaryRequest.orderNum = StringUtil.toInt(orderNumber, 0);
        String originalAmtSql = "select sum(fdOriginalAmt) originalAmt from tbSell where fiBillStatus ='3' and fsSellDate = '" + currentBusinessDate + "'";
        String originalAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, originalAmtSql);
        if (TextUtils.isEmpty(originalAmt)) {
            sendSummaryRequest.originalAmt = BigDecimal.ZERO;
        } else {
            sendSummaryRequest.originalAmt = new BigDecimal(originalAmt);
        }
        sendSummaryRequest.couponAmt = optBigDecimalElement("notPaySum", dailyReport);
        sendSummaryRequest.actualAmt = optBigDecimalElement("fdRealAmt", dailyReport);
        sendSummaryRequest.noActualAmt = optBigDecimalElement("notCalcPaidAmt", dailyReport);
        sendSummaryRequest.freeFeeAmt = optBigDecimalElement("fdFreeSveAmt", dailyReport);
        sendSummaryRequest.serviceFeeAmt = optBigDecimalElement("fdServiceAmt", dailyReport);
        sendSummaryRequest.giftAmt = optBigDecimalElement("fdGiftAmt", dailyReport);
        sendSummaryRequest.backAmt = optBigDecimalElement("fdBackAmt", dailyReport);
        sendSummaryRequest.roundAmt = optBigDecimalElement("fdRoundAmt", dailyReport);
        if (sendSummaryRequest.roundAmt != null ){
            sendSummaryRequest.roundAmt = sendSummaryRequest.roundAmt.negate();
        }
        sendSummaryRequest.discountAmt = optBigDecimalElement("discountAmt", dailyReport);
        sendSummaryRequest.payAmt = optBigDecimalElement("fdPayAmt", dailyReport);
        sendSummaryRequest.invoiceAmt = BigDecimal.ZERO;
        sendSummaryRequest.dataSource = 2;
        sendSummaryRequest.companyGuid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbShop");
        sendSummaryRequest.sell_date = currentBusinessDate;
        sendSummaryRequest.giftQty = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sum(fdGiftqty) from tbSellOrderItem where fsselldate = '" + currentBusinessDate + "'");
        sendSummaryRequest.backQty = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sum(fdBackQty) from tbSellOrderItem where fsselldate = '" + currentBusinessDate + "'");
        sendSummaryRequest.saleQty = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sum(fdSaleQty) from tbSellOrderItem where fsselldate = '" + currentBusinessDate + "'");
        sendSummaryRequest.clientVersion = BuildConfig.VERSION_NAME;
        sendSummaryRequest.sellReceiveCount = sellReceiveCount;
        sendSummaryRequest.orderItemCount = orderItemCount;
        String overflowAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sum(fdDiffAmt) from tbsell where fsselldate = '" + currentBusinessDate + "'");
        if (TextUtils.isEmpty(overflowAmt)) {
            overflowAmt = "0";
        }
        sendSummaryRequest.overflowAmt = new BigDecimal(overflowAmt);
        String hasMoreData = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tbsell where fsselldate <> '" + currentBusinessDate + "' limit 1");
        sendSummaryRequest.hasMoreData = TextUtils.isEmpty(hasMoreData) ? 0 : 1;

        BusinessExecutor.execute(sendSummaryRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(true, "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(false, (responseData != null && responseData.responseBean != null) ? responseData.responseBean.errmsg : "");
                }
                return false;
            }
        });
    }

    private static BigDecimal optBigDecimalElement(String key, HashMap<String, Object> dailyReport) {

        BigDecimal originalAmt = BigDecimal.ZERO;
        if (dailyReport != null) {
            try {
                Object fdExpAmt = dailyReport.get(key);
                if (fdExpAmt != null) {
                    originalAmt = (BigDecimal) fdExpAmt;
                }
            } catch (Exception e) {
                LogUtil.logError("取值异常：key = " + key + "; dailyReport = " + JSON.toJSONString(dailyReport), e);
            }
        }
        return originalAmt;
    }
}
