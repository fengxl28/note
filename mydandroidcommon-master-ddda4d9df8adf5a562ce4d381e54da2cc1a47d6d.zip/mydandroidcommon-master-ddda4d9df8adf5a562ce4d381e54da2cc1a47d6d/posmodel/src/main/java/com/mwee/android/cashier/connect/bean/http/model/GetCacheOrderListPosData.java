package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.cashier.connect.bean.http.BaseCashierPosResponse;

import java.util.List;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetCacheOrderListPosData extends BaseCashierPosResponse {
    public int pageNum;
    public int pageSize;
    public int pages;
    public int total;
    public List<CashierTempOrder> list;

    public GetCacheOrderListPosData() {

    }
}
