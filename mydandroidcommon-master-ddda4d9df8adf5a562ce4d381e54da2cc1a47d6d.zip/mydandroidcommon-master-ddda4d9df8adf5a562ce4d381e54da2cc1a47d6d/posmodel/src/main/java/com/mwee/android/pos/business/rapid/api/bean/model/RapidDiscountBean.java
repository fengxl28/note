package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/7/17.
 */

public class RapidDiscountBean extends BusinessBean {
    /**
     * 折扣名称
     */
    public String disName = "";

    /**
     * 折扣金额
     */
    public BigDecimal disMoney = BigDecimal.ZERO;

    public RapidDiscountBean() {
    }

}
