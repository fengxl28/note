package com.mwee.android.pos.business.backup;

import android.content.Context;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by virgil on 2017/6/12.
 */

public class FileBackup {
    private static byte[] buildKey(String originKey)throws NoSuchAlgorithmException,UnsupportedEncodingException{
        byte[] key = (originKey).getBytes("UTF-8");
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        key = sha.digest(key);
        key = Arrays.copyOf(key, 16); // use only first 128 bit
        return key;

    }

    public static void encrypt(String inputFilePath,String outPutPath,String originKey) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        byte[] key = buildKey(originKey);

        // Here you read the cleartext.
        FileInputStream fis = new FileInputStream(inputFilePath);
        // This stream write the encrypted text. This stream will be wrapped by another stream.
        FileOutputStream fos = new FileOutputStream(outPutPath);

        // Length is 16 byte
        // Careful when taking user input!!! https://stackoverflow.com/a/3452620/1188357
        SecretKeySpec sks = new SecretKeySpec(key, "AES");
        // Create cipher
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks);
        // Wrap the output stream
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);
        // Write bytes
        RuntimeException e1=null;

        try {
            int b;
            byte[] d = new byte[8];
            while((b = fis.read(d)) != -1) {
                cos.write(d, 0, b);
            }
        } catch (Exception e) {
            e1=new RuntimeException(e);
        } finally {
            // Flush and close streams.
            cos.flush();
            cos.close();
            fos.close();
            fis.close();
            if(e1!=null){
                throw e1;
            }
        }

    }
    public static void decrypt(String encryptedFilePath,String decryptedFilePath,String originKey) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        byte[] key = buildKey(originKey);
        FileInputStream fis = new FileInputStream(encryptedFilePath);

        FileOutputStream fos = new FileOutputStream(decryptedFilePath);
        SecretKeySpec sks = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, sks);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        RuntimeException e1=null;
        try {
            int b;
            byte[] d = new byte[8];
            while((b = cis.read(d)) != -1) {
                fos.write(d, 0, b);
            }
        } catch (Exception e) {
            e1=new RuntimeException(e);
        } finally {
            fos.flush();
            fos.close();
            cis.close();
            fis.close();
            if(e1!=null){
                throw e1;
            }
        }

    }
}
