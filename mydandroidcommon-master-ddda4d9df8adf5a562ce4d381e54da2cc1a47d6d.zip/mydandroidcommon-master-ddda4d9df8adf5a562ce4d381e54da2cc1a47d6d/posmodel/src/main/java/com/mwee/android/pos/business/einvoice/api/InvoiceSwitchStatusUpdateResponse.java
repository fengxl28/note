package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:
 */
public class InvoiceSwitchStatusUpdateResponse extends BasePosResponse {
    public InvoiceSwitchStatusUpdateResponse(){

    }
}
