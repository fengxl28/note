package com.mwee.android.pos.base;


import android.support.v4.util.ArrayMap;

/**
 * Created by qinwei on 2019/1/15 10:54 AM
 * email: qin.wei@mwee.cn
 */

public class Constants {
    public static final String RECEIVE_TIMEOUT = "超时未接单";
    public static final String BUSY = "店铺太忙，无法接待";
    public static final String DUPLICATE_ORDER = "重复订单";
    public static final String SHOP_CLOSE = "店铺已打烊";
    public static final String SELL_OUT = "菜品售完";
    public static final String TABLE_NOT_EXIST = "桌号不存在";
    public static final String LOW_VERSION = "收银系统版本过低";
    public static final String SHOP_NOT_CONNECTED = "没有门店绑定关系";
    public static final String MERCHANT_NOT_AUTHORIZED = "商户没有授权";
    public static final String POS_UNCONNECTED = "POS关机或未联网";
    public static final String DISH_REASON = "菜品原因";
    public static final String OTHER_REASON = "其他原因";
    private static ArrayMap<String, String> rejectInfoMap;

    static {
        rejectInfoMap = new ArrayMap<>();
        rejectInfoMap.put(RECEIVE_TIMEOUT, "RECEIVE_TIMEOUT");
        rejectInfoMap.put(BUSY, "BUSY");
        rejectInfoMap.put(DUPLICATE_ORDER, "DUPLICATE_ORDER");
        rejectInfoMap.put(SHOP_CLOSE, "SHOP_CLOSE");
        rejectInfoMap.put(SELL_OUT, "SELL_OUT");
        rejectInfoMap.put(TABLE_NOT_EXIST, "TABLE_NOT_EXIST");
        rejectInfoMap.put(LOW_VERSION, "LOW_VERSION");
        rejectInfoMap.put(SHOP_NOT_CONNECTED, "SHOP_NOT_CONNECTED");
        rejectInfoMap.put(MERCHANT_NOT_AUTHORIZED, "MERCHANT_NOT_AUTHORIZED");
        rejectInfoMap.put(POS_UNCONNECTED, "POS_UNCONNECTED");
        rejectInfoMap.put(DISH_REASON, "DISH_REASON");
        rejectInfoMap.put(OTHER_REASON, "OTHER_REASON");
    }

    public static String getRejectCode(String reason) {
        return rejectInfoMap.get(reason);
    }
}
