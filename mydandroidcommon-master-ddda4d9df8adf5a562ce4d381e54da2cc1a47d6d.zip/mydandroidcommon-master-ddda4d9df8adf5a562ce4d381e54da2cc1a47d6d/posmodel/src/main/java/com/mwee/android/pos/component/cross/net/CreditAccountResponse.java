package com.mwee.android.pos.component.cross.net;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CreditAccountResponse extends BasePosResponse {
    public CreditAccount data = new CreditAccount();

    public CreditAccountResponse() {
    }
}
