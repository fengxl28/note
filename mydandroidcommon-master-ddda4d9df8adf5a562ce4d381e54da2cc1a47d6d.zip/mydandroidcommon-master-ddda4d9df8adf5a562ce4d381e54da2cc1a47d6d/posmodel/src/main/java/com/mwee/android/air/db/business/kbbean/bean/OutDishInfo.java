package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/10/27.
 */

public class OutDishInfo extends BusinessBean {
    /**
     * 做法
     */
    public String PRACTICE = "";
    /**
     * 加价
     */
    public BigDecimal PRACTICE_PRICE = BigDecimal.ZERO;
    /**
     * 规格
     */
    public String SPECIFICATION = "";

    /**
     * 销售属性
     */
    public String SALES_PROPERTY = "";

    public OutDishInfo() {
    }
}
