package com.mwee.android.base;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by virgil on 2018/2/28.
 *
 * @author virgil
 */

public class AppEnv extends BusinessBean {
    public int env;
    public int alpPort;
    public int[] socketPorts;
    public String hardwareSymbol;

    /**
     * 业务中心 APK Version Name
     */
    public int versionCode;
    /**
     * 业务中心 APK Version Name
     */
    public String versionName;

    public AppEnv() {

    }
}
