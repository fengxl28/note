package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.QueryOpenStatusData;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class QueryOpenStatusResponse extends BaseCashierPosResponse {
    public QueryOpenStatusData data = new QueryOpenStatusData();

    public QueryOpenStatusResponse() {

    }
}
