package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.account.GetAccountDetailResponse;
import com.mwee.android.air.connect.business.account.GetAllAccountResponse;
import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * @ClassName: CAccountManage
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午8:21
 */
public interface CAccountManage extends CBase {

    /**
     * 获取所有用户
     *
     * @return
     */
    @SocketParam(uri = "airAccountManager/getAllAccount", response = GetAllAccountResponse.class)
    String getAllAccount();

    /**
     * 获取用户详细信息
     *
     * @param fsUserId
     * @return
     */
    @SocketParam(uri = "airAccountManager/getAccountDetail", response = GetAccountDetailResponse.class)
    String getAccountDetail(@SF("fsUserId") String fsUserId);

    /**
     * 新增用户
     *
     * @param mode
     * @return
     */
    @SocketParam(uri = "airAccountManager/addAccount", response = GetAllAccountResponse.class)
    String addAccount(@SF("account") AccountManageInfo mode);

    /**
     * 修改用户
     *
     * @param mode
     * @return
     */
    @SocketParam(uri = "airAccountManager/updateAccount", response = GetAllAccountResponse.class)
    String updateAccount(@SF("account") AccountManageInfo mode);

    /**
     * 删除用户
     *
     * @param fsUserId
     * @return
     */
    @SocketParam(uri = "airAccountManager/deleteAccount", response = GetAllAccountResponse.class)
    String deleteAccount(@SF("fsUserId") String fsUserId);
}
