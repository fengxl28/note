package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.discount.GetAllDiscountManagerInfoResponse;
import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public interface CDiscountManager extends CBase {

    /**
     * 获取所有折扣
     *
     * @return String
     */
    @SocketParam(uri = "airDiscountManagerDriver/optAllDiscount", response = GetAllDiscountManagerInfoResponse.class)
    String optAllDiscount();

    /**
     * 新增折扣
     *
     * @return String
     */
    @SocketParam(uri = "airDiscountManagerDriver/addDiscount", response = GetAllDiscountManagerInfoResponse.class)
    String addDiscount(@SF("discountManagerInfo") DiscountManagerInfo discountManagerInfo);

    /**
     * 修改折扣
     *
     * @param discountManagerInfo
     * @return String
     */
    @SocketParam(uri = "airDiscountManagerDriver/updateDiscount", response = GetAllDiscountManagerInfoResponse.class)
    String updateDiscount(@SF("discountManagerInfo") DiscountManagerInfo discountManagerInfo);

    /**
     * 批量删除折扣
     *
     * @param tableIdList
     * @return String
     */
    @SocketParam(uri = "airDiscountManagerDriver/batchDeleteDiscount", response = GetAllDiscountManagerInfoResponse.class)
    String batchDeleteDiscount(@SF("discountIdList") ArrayList<String> tableIdList);
}
