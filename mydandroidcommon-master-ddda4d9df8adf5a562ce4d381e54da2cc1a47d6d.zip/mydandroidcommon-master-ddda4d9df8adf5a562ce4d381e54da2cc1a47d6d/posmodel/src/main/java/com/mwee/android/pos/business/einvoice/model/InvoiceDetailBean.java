package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/5/8
 * description:电子发票详情
 */
public class InvoiceDetailBean extends BusinessBean {
    /**
     * 开票方业务订单号
     */
    public String business_no = "";
    /**
     * 发票请求流水号
     */
    public String serial_no = "";
    /**
     * 商户号id
     */
    public String shop_id = "";
    /**
     * 开票方业务id号
     */
    public String source_id = "";
    /**
     * 开票状态；SUCCESS 成功，PROCESSING 处理中，FAIL 失败
     */
    public String trade_state = "";

    /**
     * 开票状态描述
     */
    public String trade_state_reason = "";

    /**
     * 发票代码
     */
    public String invoice_code = "";

    /**
     * 发票号码
     */
    public String invoice_no = "";
    /**
     * 开票日期；格式 yyyy-MM-dd HH:mm:ss
     */
    public String invoice_date = "";
    /**
     * 发票下载url；注：只有电票此项不为空
     */
    public String invoice_pdf = "";


    public InvoiceDetailBean() {
    }
}
