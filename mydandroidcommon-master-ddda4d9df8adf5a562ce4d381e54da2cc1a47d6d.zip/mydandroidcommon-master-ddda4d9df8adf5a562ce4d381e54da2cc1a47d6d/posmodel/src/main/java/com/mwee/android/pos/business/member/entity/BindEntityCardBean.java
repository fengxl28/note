package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/9/21.
 * <p>
 * "bindEntityCard": {
 * "errmsg": "成功",
 * "errno": 0,
 * "data":{
 * "card_no": "6262973700000005",
 * "card_parent":{
 * "gender": 2,
 * "birthday": "",
 * "real_name": "李四"
 * }
 * }
 * }
 */

public class BindEntityCardBean extends BusinessBean {

    public String errmsg = "";

    public int errno = 0;

    /**
     * 卡信息
     */
    public List<BindEntityCardDataBean> data = new ArrayList<>();

    public BindEntityCardBean() {
    }
}
