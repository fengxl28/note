package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.BuyPrinterData;

/**
 * @author changsunhaipeng
 */
public class BuyPrinterResponse extends BaseCashierPosResponse {
    public BuyPrinterData data;

    public BuyPrinterResponse() {
    }
}
