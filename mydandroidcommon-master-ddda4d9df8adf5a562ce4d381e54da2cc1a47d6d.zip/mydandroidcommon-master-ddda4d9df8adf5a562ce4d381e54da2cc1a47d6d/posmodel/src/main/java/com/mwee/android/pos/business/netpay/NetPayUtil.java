package com.mwee.android.pos.business.netpay;

import android.text.TextUtils;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.db.business.pay.PayType;

import java.util.Arrays;

/**
 * @ClassName: NetPayUtil
 * @Description:
 * @author: SugarT
 * @date: 2018/4/25 下午2:26
 */
public class NetPayUtil {

    /**
     * 微信的前缀
     */
    public static String[] PREFIX_WECHAT;

    /**
     * 支付宝的前缀
     */
    public static String[] PREFIX_ALI;

    /**
     * 校验码是否支持
     *
     * @param payType
     * @param code
     * @return
     */
    public static String checkSuooprt(String payType, String code) {
        if (TextUtils.isEmpty(code)) {
            return "扫码出错,请重新扫码(条形码为空)！或检查设备的输入法，应使用系统自带的输入法";
        }

        if (code.length() < 3) {
            return "条码不正确，请扫正确的条码。或检查设备的输入法，应使用系统自带的输入法";
        }

        int type = judgePayType(code);
        if (type != OnlinePayType.WeChat && type != OnlinePayType.Ali) {
            return "扫码失败，请扫描(微信或支付宝)付款码";
        }
        if (!TextUtils.isEmpty(payType)) {
            if (TextUtils.equals(payType, PayType.ALI) && type != OnlinePayType.Ali) {
                return "扫码失败，请扫描[支付宝]付款码";
            } else if (TextUtils.equals(payType, PayType.WEIXIN) && type != OnlinePayType.WeChat) {
                return "扫码失败，请扫描[微信]付款码";
            }
        }
        // 和 winpos 沟通，保持一致，去掉位数限制
//        if (code.length() < 18 || code.length() > 24) {
//            return "扫码出错,请重新扫码(位数)！";
//        }
        return "";
    }

    /**
     * 判断码的支付类型
     *
     * @param code
     * @return
     */
    public static int judgePayType(String code) {
        // 如果缓存的前缀全部为空，尝试获取前缀
        if ((PREFIX_WECHAT == null || PREFIX_WECHAT.length == 0)
                && (PREFIX_ALI == null || PREFIX_ALI.length == 0)) {
            DriverBus.call("bizsync/getPayPrefix", new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {

                }

                @Override
                public boolean fail(ResponseData responseData) {
                    return false;
                }
            });
        }
        String prefix = code.substring(0, 2);
        if (PREFIX_WECHAT != null && Arrays.binarySearch(PREFIX_WECHAT, prefix) >= 0) {
            return OnlinePayType.WeChat;
        }
        if (PREFIX_ALI != null && Arrays.binarySearch(PREFIX_ALI, prefix) >= 0) {
            return OnlinePayType.Ali;
        }
        return -1;
    }
}
