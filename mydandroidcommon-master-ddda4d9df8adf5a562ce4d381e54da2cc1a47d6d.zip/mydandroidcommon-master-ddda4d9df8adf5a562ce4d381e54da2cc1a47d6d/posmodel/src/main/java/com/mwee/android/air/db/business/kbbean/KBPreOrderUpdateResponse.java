package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by zhangmin on 2018/5/24.
 */

public class KBPreOrderUpdateResponse extends BaseSocketResponse {

    public KBPreOrderCache data = new KBPreOrderCache();

    //本地OrderCache订单号
    public String local_order_id = "";

}
