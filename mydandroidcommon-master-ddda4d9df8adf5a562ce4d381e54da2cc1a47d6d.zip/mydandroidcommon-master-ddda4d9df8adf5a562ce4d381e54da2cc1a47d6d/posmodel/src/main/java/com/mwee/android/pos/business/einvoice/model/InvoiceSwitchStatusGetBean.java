package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:
 */
public class InvoiceSwitchStatusGetBean extends BusinessBean {
    /**
     * 秒付开具电子发票开关状态
     */
    public ArrayList<InvoiceSwitchStatusGetViceBean> dataList;
    public int page;
    public int pageSize;
    public int total;

    public InvoiceSwitchStatusGetBean(){

    }
}
