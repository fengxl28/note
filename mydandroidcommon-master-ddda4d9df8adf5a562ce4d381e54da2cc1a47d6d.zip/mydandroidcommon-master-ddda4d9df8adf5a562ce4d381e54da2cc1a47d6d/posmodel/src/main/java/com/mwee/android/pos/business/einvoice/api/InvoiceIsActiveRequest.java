package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:门店是否开通电子发票
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "adapter",
        contentType = "application/json",
        response = InvoiceIsActiveResponse.class, saveToLog = true
)
public class InvoiceIsActiveRequest extends BaseInvoiceRequest {
    public InvoiceIsActiveRequest() {

    }
}
