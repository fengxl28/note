package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * 反结账的Response
 * Created by virgil on 2018/2/24.
 *
 * @author virgil
 */

public class CashierAntiPayResponse extends BaseSocketResponse {
}
