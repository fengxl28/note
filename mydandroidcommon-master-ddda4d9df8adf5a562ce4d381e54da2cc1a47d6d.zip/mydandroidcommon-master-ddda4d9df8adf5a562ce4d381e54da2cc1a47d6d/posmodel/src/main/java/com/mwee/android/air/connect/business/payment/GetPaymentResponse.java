package com.mwee.android.air.connect.business.payment;

import com.mwee.android.air.db.business.payment.PaymentManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: GetAllPaymentResponse
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午3:02
 */
public class GetPaymentResponse extends BaseSocketResponse {

    public PaymentManageInfo pay = new PaymentManageInfo();

    public GetPaymentResponse() {
    }
}
