package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.business.netpay.model.GoodDetailModel;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/12/23.
 * winpos支付接口
 */
@HttpParam(httpType = HttpType.POST,
        method = "scanPay",
        response = NetResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 90, saveToLog = true)
public class ScanPayRequest extends BasePosRequest {
    public String pay_class = "";//支付类型:1 微信、2支付宝、3银联、4百度钱包
    public String pay_micro = "";//"条码",
    public String pay_order = "";//"结账号",订单编号
    public String pay_name = "";//"支付门店名",
    public String pay_price = "";//"支付金额",单位为元

    /**
     * OLD
     **/
    public String pay_shopid = "";//"支付门店",
    public String fsshopguid = "";//"门店ID",
    public String fsshopname = "";//"门店名",
    public String fscompanyguid = "";//"总店id",
    public String fssellno = "";//"账单号",
    //public String paysourceid = "";//"业务id"

    /**
     * new
     **/
    public String pay_sourceid = "";    //业务ID
    public String pay_en = ""; //终端设备EN  --- 非必填
    public String pay_ext = ""; //扩展参数  --- 非必填
    public String pay_discountable = ""; //可以打折金额,该订单里面，可以参加第三方打折的金额  --- 非必填

    /**
     * 商品信息 用于扫码支付优惠劵
     * --- 非必填
     */
    public List<GoodDetailModel> goods_detail = new ArrayList<>();

    public ScanPayRequest() {
    }

    @Override
    public ScanPayRequest clone() {
        ScanPayRequest cloneObj = null;
        try {
            cloneObj = (ScanPayRequest) super.clone();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return cloneObj;
    }

}
