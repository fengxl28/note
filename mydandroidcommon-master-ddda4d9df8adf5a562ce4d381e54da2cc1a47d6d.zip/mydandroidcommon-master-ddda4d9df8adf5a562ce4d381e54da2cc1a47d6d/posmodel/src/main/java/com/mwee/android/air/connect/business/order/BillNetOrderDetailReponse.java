package com.mwee.android.air.connect.business.order;

import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by zhangmin on 2018/9/1.
 */

public class BillNetOrderDetailReponse extends BaseSocketResponse {

    public TempAppOrder tempAppOrder;

    public BillNetOrderDetailReponse(){

    }

}
