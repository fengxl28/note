package com.mwee.android.pos.base;

/**
 * Created by lxx on 16/9/13.
 */
public class TableConstans {

    /**
     * 餐桌狀態代號;1空闲 / 2开台 / 3占用 / 8预订 / 9停用
     */
    public static final String TABLE_STATUS_FREE = "1";
    public static final String TABLE_STATUS_OPEN = "2";
    public static final String TABLE_STATUS_BUSY = "3";
    public static final String TABLE_STATUS_RESERVATION = "8";
    public static final String TABLE_STATUS_INVALID = "9";

    /**
     * 桌台相关操作
     *  2、换台 3、拼台(生产新台) 4、拼台(确认拼台) 5、清台
     * 6、查看桌台状态
     * 7. 服务铃
     * 8. 秒点订单
     */
    public static final int TABLE_ACTION_SHARE_PRE = 3;
    public static final int TABLE_ACTION_SHARE_COMMIT = 4;
    public static final int TABLE_ACTION_CLOSE = 5;
    public static final int TABLE_ACTION_STATUS= 6;
}
