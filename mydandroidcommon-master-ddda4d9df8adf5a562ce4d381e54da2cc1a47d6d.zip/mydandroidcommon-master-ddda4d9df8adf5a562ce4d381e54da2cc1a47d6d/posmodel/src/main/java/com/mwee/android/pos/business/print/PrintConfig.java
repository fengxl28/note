package com.mwee.android.pos.business.print;

/**
 * Created by lxx on 16/10/19.
 */

public class PrintConfig {

    /**
     * 预结单表尾餐店说明ø
     */
    public static String PRINT_TAIL_MESSAGE = "";

    /**
     * 结账单打印份数
     */
    public static int STATEMENT_PRINT_COUNT = 1;

    /**
     * 外卖平台自动接单后是否打印  0=false/1=ture
     */
    public static String NET_ORDER_THIRD_PLARM_AUTO_GET_PRINT = "0";
    /**
     * 外卖未映射菜品是否使用临时菜落报表 -- 默认使用
     */
    public static String NET_ORDER_MAPPING_WITH_TEMP_MENU = "1";
    /**
     * 一个订单中需要标签打印机打印的总份数
     */
    public static int TSC_SUBMIT_COUNT = 1;

    /**
     * 快餐是否打印传菜单
     */
    public static boolean FASTFOOD_PRINT_PASSTO = false;

    /**
     * 结账单是否打印实收
     */
    public static boolean BILL_PRINT_REALMONEY = false;

    /**
     * 结账单是否打印退菜信息
     */
    public static boolean BILL_PRINT_VOIDMENU = false;
    /**
     * 是否打印留存单
     */
    public static boolean PRINT_REMAIN_BILL = false;

    /**
     * 是否打印外卖结账单
     */
    public static boolean PRINT_NET_BILL = true;

}
