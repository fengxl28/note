package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/**
 * 网络支付的退款请求
 */
@HttpParam(httpType = HttpType.POST,
        method = "refundScanPayment",
        response = NetResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 30, saveToLog = true)
public class RefundRequest extends BasePosRequest {
    public String pay_order = "";//订单号

    public RefundRequest() {
    }

    @Override
    public RefundRequest clone() {
        RefundRequest cloneObj = null;
        try {
            cloneObj = (RefundRequest) super.clone();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return cloneObj;
    }

}
