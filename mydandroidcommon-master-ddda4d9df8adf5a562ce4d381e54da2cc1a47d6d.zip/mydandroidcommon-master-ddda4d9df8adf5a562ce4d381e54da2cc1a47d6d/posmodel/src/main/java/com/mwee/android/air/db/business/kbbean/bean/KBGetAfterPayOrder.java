package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/10/29.
 */

public class KBGetAfterPayOrder extends BusinessBean {
    public String shop_id;
    public String partner_id;
    public String out_biz_no;
    public String table_no;
    public String koubeiYudianEnable;
    public String mwShopId;

    public KBGetAfterPayOrder() {
    }

    @Override
    public String toString() {
        return "KBGetAfterPayOrder{" +
                "shop_id='" + shop_id + '\'' +
                ", partner_id='" + partner_id + '\'' +
                ", out_biz_no='" + out_biz_no + '\'' +
                ", table_no='" + table_no + '\'' +
                ", koubeiYudianEnable='" + koubeiYudianEnable + '\'' +
                ", mwShopId='" + mwShopId + '\'' +
                '}';
    }
}
