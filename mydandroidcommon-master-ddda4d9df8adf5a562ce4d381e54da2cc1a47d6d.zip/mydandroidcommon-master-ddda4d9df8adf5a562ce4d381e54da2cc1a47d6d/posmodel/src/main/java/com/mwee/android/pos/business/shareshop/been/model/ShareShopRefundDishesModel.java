package com.mwee.android.pos.business.shareshop.been.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/3/29.
 * 共享餐厅退菜明细
 *
 */

public class ShareShopRefundDishesModel extends BusinessBean {

    /**
     * 退菜的外部菜品Id
     */
    public String outerItemId = "";

    /**
     * 唯一码
     */
    public String commitId = "";


    /**
     * 退菜份数
     */
    public BigDecimal voidNum = BigDecimal.ZERO;


    public ShareShopRefundDishesModel() {
    }
}
