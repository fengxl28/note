package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KPreVerify;
import com.mwee.android.pos.connect.framework.SocketResponse;

/**
 * 核销结果数据
 * Created by qinwei on 2018/8/22.
 */

public class KBVerifyPreOrderResponse extends SocketResponse {
    public KPreVerify preVerify = new KPreVerify();

    public KBVerifyPreOrderResponse() {
    }
}
