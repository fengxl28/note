package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/10/22.
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28662712
 */

public class CheckCardTypeBean extends BusinessBean {
    /**
     * 美味实体卡(16位)激活方式
     * 1.手机号激活； 2不记名激活
     */
    public String entity_card_act_mode = "";

    public CheckCardTypeBean() {
    }
}
