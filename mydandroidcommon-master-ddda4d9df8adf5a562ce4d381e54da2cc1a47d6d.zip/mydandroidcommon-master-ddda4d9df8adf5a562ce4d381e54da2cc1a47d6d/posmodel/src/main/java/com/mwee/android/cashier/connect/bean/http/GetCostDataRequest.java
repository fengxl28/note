package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 收入支出汇总
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23007875</herf>
 *
 * @author changsunhaipeng
 */
@HttpParam(httpType = HttpType.POST,
        method = "cost/record/count",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetCostDataResponse.class)
public class GetCostDataRequest extends BaseCashierPosRequest {
    public String startDate;
    public String endDate;
    public String shopGUID;

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierMposmsyUrl();
    }

    public GetCostDataRequest() {

    }
}
