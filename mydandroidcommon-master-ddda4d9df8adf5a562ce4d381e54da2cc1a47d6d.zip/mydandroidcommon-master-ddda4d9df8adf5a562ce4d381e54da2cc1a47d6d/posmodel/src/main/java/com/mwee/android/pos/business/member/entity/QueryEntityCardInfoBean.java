package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/9/21.
 */

public class QueryEntityCardInfoBean extends BusinessBean {

    /**
     * 卡号
     */
    public String card_no = "";

    /**
     * 门店信息
     */
    public String m_shopid = "";

    /**
     * 电话号码
     */
    public String mobile = "";
    /**
     * 0虚拟卡 1实体储值卡 2实体卡(16位)
     */
    public String type = "";
    /**
     * 激活门店
     */
    public String act_shopid = "";
    /**
     * 激活时间
     */
    public String act_time = "";
    /**
     * 父卡号
     */
    public String card_parent_no = "";
    /**
     * 是否为当前卡 1是 0否
     */
    public String entity_card_is_main = "";
    /**
     * 卡状态 0未激活 1激活 2冻结
     */
    public String entity_card_status = "";
    /**
     * 开卡人？
     */
    public String who_open_entity_card = "";
    /**
     * 最后预充值
     */
    public String last_deposit_time = "";

    public QueryEntityCardInfoBean() {
    }
}
