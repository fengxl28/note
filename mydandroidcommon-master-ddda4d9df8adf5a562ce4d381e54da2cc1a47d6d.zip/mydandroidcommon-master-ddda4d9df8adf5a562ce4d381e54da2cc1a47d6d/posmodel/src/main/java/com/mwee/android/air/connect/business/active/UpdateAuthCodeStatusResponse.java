package com.mwee.android.air.connect.business.active;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * @author:luoshenghua create on:2018/12/11
 * description:
 */
public class UpdateAuthCodeStatusResponse extends BasePosResponse {
    public UpdateAuthCodeStatusResponse() {
    }
}