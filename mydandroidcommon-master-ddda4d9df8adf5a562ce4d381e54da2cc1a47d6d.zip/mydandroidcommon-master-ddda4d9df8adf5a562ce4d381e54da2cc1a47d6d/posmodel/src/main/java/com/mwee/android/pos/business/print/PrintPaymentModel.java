package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zun on 16/7/12.
 */
public class PrintPaymentModel extends DBModel {

    public String fsshiftname = "";
    public List<PrintPaymentSettlementModel> MX = new ArrayList<>();
    public PrintCountModel HJ;

    public PrintPaymentModel() {

    }
}
