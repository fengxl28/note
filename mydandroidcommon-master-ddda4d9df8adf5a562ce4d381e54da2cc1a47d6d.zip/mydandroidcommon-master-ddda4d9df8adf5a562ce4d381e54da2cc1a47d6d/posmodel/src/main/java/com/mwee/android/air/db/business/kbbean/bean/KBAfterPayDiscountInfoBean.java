package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/10/25.
 */

public class KBAfterPayDiscountInfoBean extends BusinessBean {

    /**
     * 优惠类型
     */
    public String type = "";

    /**
     * 优惠名称
     */
    public String name  = "";

    /**
     * 优惠金额
     */
    public BigDecimal amount = BigDecimal.ZERO;

    /**
     * 商家优惠金额
     */
    public BigDecimal mdiscount_amount = BigDecimal.ZERO;

    /**
     * 平台补贴的金额
     */
    public BigDecimal platform_discount_amount = BigDecimal.ZERO;

    /**
     * 扩展信息
     */
    public String ext_infos;

    public KBAfterPayDiscountInfoBean() {
    }
}
