package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.cashier.connect.bean.socket.model.CashierPayResultInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.pay.NetPayResult;

import java.util.ArrayList;

/**
 * 美收银的支付结果
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class CashierPayResultResponse extends BaseSocketResponse {
    /**
     * 新的OrderToken
     */
    public String orderTokenNew;
    /**
     * 返回OrderID
     */
    public String orderIDNeedUpdate;
    /**
     * 支付结果
     */
    public boolean payFinished = false;

    /**
     * 第三方支付订单号
     */
    public String thirdPayOrderID = "";
    /**
     * 第三方支付结果
     */
    public int thirdPayStatus = NetPayResult.SUCCESS;

    /**
     * 是否需要会员输入密码
     */
    public boolean needMemberPwd = false;
    public CashierPayResultInfo info=null;


    public CashierPayResultResponse() {

    }
}
