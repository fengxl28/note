package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class Trade extends BusinessBean {
    public String checkEndTime;//"15:57",            //交易时间
    public String paymentTypeId;//"91801",
    public String paymentName;//"支付宝在线支付",
    public String receMoney;//15.75,                 //实际付款
    public String sellDate;//"2017-12-22",
    public String sellNo;//"201712220001
    public String thirdPartyId;//"第三方payno 用于查询
    public int payStatus;//13=已退款
    public int orderSourceId;//1为本店 ，其它为外卖
    public String orderSourceName;
    public String orderSourceNo;


    public Trade() {

    }
}
