package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.discount.DiscountBizModel;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;

/**
 * 开单返回的Response
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GenTempOrderResponse extends BaseSocketResponse {
    public OrderCache temOrder = null;
    /**
     * 订单的折扣方案名称
     */
    public String discountName;

    /**
     * 实收金额
     */
    public BigDecimal realPrice;
    public String orderToken = "";

    public GenTempOrderResponse() {
    }

    public void buildDiscountName() {
        if (temOrder != null) {
            if (temOrder.selectOrderDiscountCut != null) {
                discountName = "减价";
            } else if (!ListUtil.isEmpty(temOrder.originMenuList)) {
                DiscountBizModel discount = temOrder.originMenuList.get(0).menuBiz.selectDiscount;
                if (discount != null) {
                    discountName = getDiscountName(100 - discount.fiDiscountRate);
                }
            }
        }
    }

    public void updateOrderCache(OrderCache orderCache) {
        this.temOrder = orderCache;
        buildDiscountName();
    }

    private String getDiscountName(int fiDiscountRate) {
        if (fiDiscountRate == 100) {
            return "无";
        }
        return new BigDecimal(fiDiscountRate).divide(new BigDecimal(10)).toString() + "折";
    }

    @Override
    public String toString() {
        if (temOrder != null) {
            return temOrder.toString() + "realPrice:" + realPrice;
        }
        return super.toString();
    }
}
