package com.mwee.android.air.util;

/**
 * 小票模版常量类
 * Created by qinwei on 2018/8/29.
 */

public class TicketTempletConstants {

    /**
     * 正餐结账单
     */
    public static final String URI_DINNER_BILL = "air/bill/orderbill";
    /**
     * 正餐预结单
     */
    public static final String URI_DINNER_PRE_BILL = "air/bill/prebill";
    /**
     * 快餐结账单
     */
    public static final String URI_FAST_BILL = "air/fastFoodBill/orderbill";

    /**
     * 口碑制作单
     */
    public static final String URI_KB_ORDER_MAKE = "koubei/makeOrder";
    /**
     * 口碑预点单客户联
     */
    public static final String URI_KB_CUSTOM_BILL = "koubei/preOrderCustomer";

    /**
     * 口碑预点单商家联
     */
    public static final String URI_KB_SHOP_BILL = "koubei/preOrderMerchant";


    /**
     * 外卖客户联
     */
    public static final String URI_TAKE_CUSTOM_BILL = "air/bill/takeawayCustomer";

    /**
     * 外卖商户联
     */
    public static final String URI_TAKE_SHOP_BILL = "air/bill/takeawayMerchant";

    /**
     * air3.7美小店单据调整,原先直接走快餐结账单，现走模版
     * 美小店结账单
     */
    public static final String URI_MEIXIAODIAN_BILL = "air/meixiaodian/orderbill";

    /**
     * 正餐结账单->简洁正常字体
     */
    public static final String ID_DINNER_BILL_SIMPLE_NORMAL = "air/bill/orderbill_simple_1";
    /**
     * 正餐结账单->简洁大字体
     */
    public static final String ID_DINNER_BILL_SIMPLE_BIG_FONT = "air/bill/orderbill_simple_big_font_1";
    /**
     * 正餐结账单->详细
     */
    public static final String ID_DINNER_BILL_DETAIL = "air/bill/orderbill_1";

    /**
     * 正餐预结单->简洁正常字体
     */
    public static final String ID_TAKE_DINNER_PRE_BILL_SIMPLE_NOMRAL = "air/bill/prebill_simple_1";
    /**
     * 正餐预结单->简洁大字体
     */
    public static final String ID_TAKE_DINNER_PRE_BILL_SIMPLE_BIG_FONT = "air/bill/prebill_simple_big_font_1";
    /**
     * 正餐预结单->详细
     */
    public static final String ID_TAKE_DINNER_PRE_BILL_DETAIL = "air/bill/prebill_1";


    /**
     * 快餐结账单->简洁正常字体
     */
    public static final String ID_FAST_BILL_SIMPLE_NORMAL = "air/fastFoodbill/orderbill_simple_1";
    /**
     * 快餐结账单->简洁大字体
     */
    public static final String ID_FAST_BILL_SIMPLE_BIG_FONT = "air/fastFoodbill/orderbill_simple_big_font_1";
    /**
     * 快餐结账单->详细
     */
    public static final String ID_FAST_BILL_DETAIL = "air/fastFoodBill/orderbill_1";


    /**
     * 小易外卖客户联->简洁正常字体
     */
    public static final String ID_TAKE_CUSTOM_SIMPLE_NORMAL = "air/bill/takeawayCustomer_simple_1";
    /**
     * 小易外卖客户联->详细
     */
    public static final String ID_TAKE_CUSTOM_DETAIL = "air/bill/takeawayCustomer_1";


    /**
     * 小易外卖商家联->简洁正常字体
     */
    public static final String ID_TAKE_SHOP_SIMPLE_NORMAL = "air/bill/takeawayMerchant_simple_1";
    /**
     * 小易外卖商家联->简洁大字体
     */
    public static final String ID_TAKE_SHOP_SIMPLE_BIG_FONT = "air/bill/takeawayMerchant_simple_big_font_1";
    /**
     * 小易外卖商家联->详细
     */
    public static final String ID_TAKE_SHOP_DETAIL = "air/bill/takeawayMerchant_1";


    /**
     * 小易口碑客户联->简洁正常字体
     */
    public static final String ID_KB_CUSTOM_SIMPLE_NORMAL = "koubei/preOrder_customer_simple_1";
    /**
     * 小易口碑客户联->详细
     */
    public static final String ID_KB_CUSTOM_DETAIL = "koubei/preOrder_customer_1";


    /**
     * 小易口碑商户联->简洁正常字体
     */
    public static final String ID_KB_SHOP_SIMPLE_NORMAL = "koubei/preOrder_merchant_simple_1";
    /**
     * 小易口碑商户联->简洁大字体
     */
    public static final String ID_KB_SHOP_SIMPLE_BIG_FONT = "koubei/preOrder_merchant_simple_big_font_1";
    /**
     * 小易口碑商户联->详细
     */
    public static final String ID_KB_SHOP_DETAIL = "koubei/preOrder_merchant_1";


    /**
     * 小易口碑制作单->简洁正常字体
     */
    public static final String ID_KB_ORDER_MAKE_SIMPLE_NORMAL = "koubei/makeOrder_simple_1";
    /**
     * 小易口碑制作单->简洁大字体
     */
    public static final String ID_KB_ORDER_MAKE_SIMPLE_BIG_FONT = "koubei/makeOrder_simple_big_font_1";
    /**
     * 小易口碑制作单->详细
     */
    public static final String ID_KB_ORDER_MAKE__DETAIL = "koubei/makeOrder_1";

    /**
     * air3.7美小店单据调整,原先直接走快餐结账单，现走模版
     * 美小店结账单->简洁正常字体
     */
    public static final String ID_MEIXIAODIAN_BILL_NORMAL = "air/meixiaodian/orderbill_simple_1";

}
