package com.mwee.android.air.util;

import android.util.Log;

public class LgUtil {

    public static void Logd(String tag, String info){
        int max_str_length = 2001 - tag.length();
        if(info.length() > max_str_length){
            int pages = (info.length() / max_str_length) + 1;
            for(int i = 0 ; i < pages; i++){
                int end = (i + 1) * max_str_length < info.length() ? (i + 1) * max_str_length : info.length();
                Log.d(tag,info.substring(i*max_str_length, end));
            }
        }else{
            Log.d(tag,info);
        }
    }
}
