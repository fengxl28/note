package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/7/17.
 * 在线挂账接口
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18964509
 */
@HttpParam(httpType = HttpType.POST,
        method = "creditBuilder",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 60)
public class HungOnLineRequest extends BaseCrossRequest {

    /**
     * 挂账对象编号
     */
    public String creditAccountId = "";

    /**
     * 挂账对象名称
     */
    public String creditAccountName = "";

    /**
     * 营业日期
     */
    public String sellDate = "";

    /**
     * 订单号
     */
    public String sellNo = "";

    /**
     * 订单金额
     */
    public BigDecimal saleAmt = BigDecimal.ZERO;
    /**
     * 挂账金额
     */
    public BigDecimal debtAmt = BigDecimal.ZERO;

    /**
     * 收银员编号
     */
    public String cashierId = "";
    /**
     * 收银员姓名
     */
    public String cashierName = "";
    /**
     * 结账单号
     */
    public String checkBillNo = "";
    /**
     * 结算明细序号
     */
    public String receiveSeq = "";

    public HungOnLineRequest() {

    }
}
