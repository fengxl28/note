package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * author:luoshenghua
 * create on:2018/4/28
 * description:电子发票税率更新请求
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "adapter",
        contentType = "application/json",
        response = InvoiceRateUpdateResponse.class, saveToLog = true
)
public class InvoiceRateUpdateRequest extends BaseInvoiceRequest {

    public InvoiceRateUpdateRequest(){

    }
}
