package com.mwee.android.pos.business.netpay;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.netpay.model.GoodDetailModel;
import com.mwee.android.base.task.net.NetJob;
import com.mwee.android.pos.business.netpay.model.NetPayModel;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.pay.NetPayCallback;
import com.mwee.android.pos.db.business.pay.NetPayResult;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 条码支付的业务处理类
 * Created by virgil on 2017/2/4.
 */

public class NetPayProcessor {
    /**
     * 订单号
     */
    private String orderID = null;
    /**
     * 账单号
     */
    private int billNO;
    private ShopDBModel shop;
    private BigDecimal payAmount;
    private BigDecimal discountAmount;
    private NetPayCallback callback;
    private int netPayType;
    private List<GoodDetailModel> goods_detail = new ArrayList<>();


    public NetPayProcessor(String orderID, int billNo, BigDecimal payAmount, BigDecimal discountAmount, NetPayCallback callback) {
        this.orderID = orderID;
        this.billNO = billNo;
        this.payAmount = payAmount;
        this.discountAmount = discountAmount;
        this.callback = callback;
    }

    public NetPayProcessor(String orderID, int billNo, BigDecimal payAmount, BigDecimal discountAmount, List<GoodDetailModel> goods_detail, NetPayCallback callback) {
        this.orderID = orderID;
        this.billNO = billNo;
        this.payAmount = payAmount;
        this.discountAmount = discountAmount;
        this.callback = callback;
        this.goods_detail = goods_detail;
    }


    public NetPayProcessor(NetPayCallback callback) {
        this.callback = callback;
    }

    public void startPay(final String info, String payOrder) {
        final List<BaseRequest> requestList = new ArrayList<>();
        final ScanPayRequest request = new ScanPayRequest();
        String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        shop = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop where fsShopGUID='" + shopID + "'", ShopDBModel.class);
        if (TextUtils.isEmpty(payOrder)) {
            payOrder = OrderUtil.buildNetOrderID(shopID, String.valueOf(billNO));
        }
//        netPayType = info.charAt(0) - 48;
        netPayType = NetPayUtil.judgePayType(info);
        //2,支付宝 1微信
        request.pay_class = netPayType + "";
        //"条码",
        request.pay_micro = info;
        //"结账号"
        request.pay_order = payOrder;
        //"支付门店名",
        request.pay_name = shop.fsShopName + "_AndroidMYD";
        //"支付门店",
        request.pay_shopid = shop.fsShopGUID;
        //"支付金额",
        request.pay_price = payAmount.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString();
        //"门店ID",
        request.fsshopguid = shop.fsShopGUID;
        //"门店名",
        request.fsshopname = shop.fsShopName;
        //"总店id",
        request.fscompanyguid = shop.fsCompanyGUID;
        //"账单号",
        request.fssellno = orderID;

        //商品信息 用于扫码支付优惠劵
        request.goods_detail = goods_detail;

        //"业务id"
        if (APPConfig.isMyd()) {
            request.pay_sourceid = "116";
        } else if (APPConfig.isAir()) {
            request.pay_sourceid = "169";
        } else if (APPConfig.isCasiher()) {
            request.pay_sourceid = "170";
        } else {
            request.pay_sourceid = "116"; //默认美易点
        }
        if (discountAmount != null) {
            //可以参加第三方打折的金额
            request.pay_discountable = discountAmount.toPlainString();
        }
        requestList.add(request);
        PayQueryRequest resultSearchRequest = new PayQueryRequest();
        resultSearchRequest.pay_order = payOrder;
        if (APPConfig.isMyd()) {
            resultSearchRequest.sourceid = 116;
        } else if (APPConfig.isAir()) {
            resultSearchRequest.sourceid = 169;
        } else if (APPConfig.isCasiher()) {
            resultSearchRequest.sourceid = 170;
        } else {
            resultSearchRequest.sourceid = 116;//默认美易点
        }

        //查询31次
        requestList.add(resultSearchRequest);

        for (int i = 0; i < 30; i++) {
            requestList.add(resultSearchRequest.clone());
        }

        String finalPayOrder = payOrder;
//        BusinessExecutor.execute(requestList, null, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                boolean lastRequest = i == (requestList.size() - 1);
//                return parsePayResult(responseData, finalPayOrder, lastRequest);
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                boolean lastRequest = i == (requestList.size() - 1);
//
//                return parsePayResult(responseData, finalPayOrder, lastRequest);
//            }
//        }, true);

        long timePay = System.currentTimeMillis();
        LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#startPay ------查询10次-- 支付业务中心---NetJob---开始=" + timePay);
        NetJob job = new NetJob(requestList);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                boolean lastRequest = i == (requestList.size() - 1);
                long time = System.currentTimeMillis() - timePay;
                LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#startPay ------查询第"
                        + i + "次-- 支付业务中心---parsePayResult----success----成功=" + time);
                return parsePayResult(responseData, finalPayOrder, lastRequest);
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                boolean lastRequest = i == (requestList.size() - 1);
                long time = System.currentTimeMillis() - timePay;
                LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#startPay ------查询第"
                        + i + "次-- 支付业务中心---parsePayResult---fail-----失败=" + time);
                return parsePayResult(responseData, finalPayOrder, lastRequest);
            }
        });
        job.execute();
        long time0 = System.currentTimeMillis() - timePay;
        LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#startPay ------查询10次-- 支付业务中心---NetJob---结束=" + time0);
    }

    private int count = 0;

    /**
     * 解析支付结果，并判断是否继续发下一个服务
     *
     * @param responseData BalanceChangedData
     * @param payOrder     String | 支付单号
     * @param lastRequest  boolean | 是否是最后一个请求
     * @return 是否继续发下一个服务
     */
    private boolean parsePayResult(ResponseData responseData, String payOrder, boolean lastRequest) {
        LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#parsePayResult ---" + count +
                "---解析结果-- 支付业务中心开始=" + System.currentTimeMillis());

//        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_SCAN_PAY_STATUS, responseData.httpStatus == 200 ? "0" : "1");
        if (responseData.responseBean != null) {
            if (responseData.responseBean instanceof NetResponse) {
                NetResponse response = (NetResponse) responseData.responseBean;
                if (!TextUtils.isEmpty(response.data) && responseData.responseBean.errno == 0) {
                    try {
                        JSONObject object = JSON.parseObject(response.data);
                        if (TextUtils.equals("1", object.getString("pay_status"))) {
                            //支付成功
                            netPayType = object.getInteger("pay_class");
                            RunTimeLog.addLog(RunTimeLog.PAY_SUCCESS, ("网络支付 结果：成功 = " + JSON.toJSONString(responseData) + "\norderid=" + orderID + ",billno=" + billNO));
                            callback.call(NetPayResult.SUCCESS, "成功", netPayType, payOrder, JSON.parseObject(response.data, NetPayModel.class));
                            return false;
                        } else if (TextUtils.equals("2", object.getString("pay_status"))) {
                            //支付失败
                            String error = object.getString("reason");
                            if (TextUtils.isEmpty(error)) {
                                error = responseData.resultMessage;
                                if (TextUtils.isEmpty(error)) {
                                    error = "支付失败;请重新扫码(BZD)";
                                }
                            }
                            callback.call(NetPayResult.FAIL, error, netPayType, payOrder, JSON.parseObject(response.data, NetPayModel.class));
                            RunTimeLog.addLog(RunTimeLog.PAY_FAILE, "网络支付 结果：失败 = " + JSON.toJSONString(responseData) + "\norderid=" + orderID + ",billno=" + billNO);

                            return false;
                        } else {   //支付中
                            RunTimeLog.addLog(RunTimeLog.PAY_ING, ("网络支付 结果：支付中 = " + JSON.toJSONString(responseData) + "\norderid=" + orderID + ",billno=" + billNO));
                        }
                    } catch (Exception e) {
                        LogUtil.logError(e);
                        RunTimeLog.addLog(RunTimeLog.NETORDER_PARSE, "支付结果解析异常:" + e.getMessage() + "; 支付responseData: " + JSON.toJSONString(responseData));
                    }
                }
            }
        }

        if (lastRequest) {
            callback.call(NetPayResult.PROCESSING, "支付中,请点击[重试]", netPayType, payOrder, null);
        } else {
            LogUtil.logNET("[" + payOrder + "]支付中，最长等待7秒");
            count++;
//            if (count > 10) {
//                count = 10;
//            }
            try {
                Thread.sleep(count * 400);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        LogUtil.logBusiness("===SCAN=PAY===", "NetPayProcessor#parsePayResult --" +
                count + "----解析结果-- 支付业务中心结束=" + System.currentTimeMillis());
        return true;
    }

    /**
     * 查询支付结果
     *
     * @param payOrder String | 支付单号
     * @param code     String | 条码
     */
    public void startSearch(final String payOrder, final String code) {
        startSearch(payOrder, code.charAt(0) - 48);
    }

    /**
     * 查询支付结果，支付成功会返回pay_class的支付类型，支付失败通常bu xu y默认返回为微信。
     *
     * @param payOrder
     */
    public void startSearch(final String payOrder) {
        startSearch(payOrder, 1);
    }

    /**
     * 查询支付结果
     *
     * @param payOrder   String | 支付单号
     * @param netPayType 支付类型
     */
    public void startSearch(final String payOrder, final int netPayType) {
        this.netPayType = netPayType;
        PayQueryRequest resultSearchRequest = new PayQueryRequest();
        resultSearchRequest.pay_order = payOrder;
        if (APPConfig.isMyd()) {
            resultSearchRequest.sourceid = 116;
        } else if (APPConfig.isAir()) {
            resultSearchRequest.sourceid = 169;
        } else if (APPConfig.isCasiher()) {
            resultSearchRequest.sourceid = 170;
        } else {
            resultSearchRequest.sourceid = 116;//默认美易点
        }

        final List<BaseRequest> requestList = new ArrayList<>();

        requestList.add(resultSearchRequest);
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
        requestList.add(resultSearchRequest.clone());
//        BusinessExecutor.execute(requestList, null, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                boolean lastRequest = i == (requestList.size() - 1);
//                return parsePayResult(responseData, payOrder, lastRequest);
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                boolean lastRequest = i == (requestList.size() - 1);
//                return parsePayResult(responseData, payOrder, lastRequest);
//            }
//        }, true);


        NetJob job = new NetJob(requestList);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                boolean lastRequest = i == (requestList.size() - 1);
                return parsePayResult(responseData, payOrder, lastRequest);
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                boolean lastRequest = i == (requestList.size() - 1);
                return parsePayResult(responseData, payOrder, lastRequest);
            }
        });
        job.execute();
    }
}
