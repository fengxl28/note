package com.mwee.android.pos.component.cross.net;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2018/1/3.
 */

public class CrossOrderListResponse extends BasePosResponse {
    public Response<CrossOrder> data = new Response<>();

    public CrossOrderListResponse() {
    }
}
