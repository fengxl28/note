package com.mwee.android.air.db.business.ask;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class AirAskManageInfo extends DBModel {

    @ColumnInf(name = "fsAskName")
    public String fsAskName = "";

    @ColumnInf(name = "fsAskGpId")
    public String fsAskGpId = "";

    @ColumnInf(name = "fiId", primaryKey = true)
    public String fiId = "0";

    @ColumnInf(name = "fdAddPrice")
    public BigDecimal fdAddPrice = BigDecimal.ZERO;

    /**
     * 排序字段
     */
    public int index;

    public AirAskManageInfo() {
    }
}
