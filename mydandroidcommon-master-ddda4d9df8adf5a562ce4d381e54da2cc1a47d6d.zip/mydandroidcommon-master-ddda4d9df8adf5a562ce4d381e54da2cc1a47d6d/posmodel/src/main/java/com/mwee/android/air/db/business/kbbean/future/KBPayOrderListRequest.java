package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.air.db.business.kbbean.KBPartRefundReturnResponse;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiFutureRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/12/10 9:29 PM
 * email: qin.wei@mwee.cn
 */
@HttpParam(httpType = HttpType.POST,
        method = "queryKbPayListPage",
        response = KBPayOrderListResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KBPayOrderListRequest extends BaseKouBeiFutureRequest {
    public String shopGuid = "";
    public String sellDate = "";
    public int pageNum;
    public int pageSize;


    public KBPayOrderListRequest() {
    }
}
