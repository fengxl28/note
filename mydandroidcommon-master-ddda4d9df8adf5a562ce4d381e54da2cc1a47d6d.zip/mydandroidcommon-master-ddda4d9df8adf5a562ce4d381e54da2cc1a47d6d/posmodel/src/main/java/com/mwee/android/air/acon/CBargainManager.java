package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.bargain.GetBargainListResponse;
import com.mwee.android.air.db.business.bargain.FullReduceBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.db.business.BargainDBModel;
import com.mwee.android.pos.db.business.CutmoneyDBModel;
import java.util.List;

/**
 * author:luoshenghua
 * create on:2018/6/2
 * description:air2.6 满减优惠
 */
public interface CBargainManager {
    /**
     * 添加满减优惠
     * @return String
     */
    @SocketParam(uri = "airBargainManagerDriver/addFullReduce", response = BaseSocketResponse.class)
    String addFullReduce(@SF("fullReduceBean") FullReduceBean fullReduceBean);


    /**
     * 批量删除满减优惠
     * @return String
     */
    @SocketParam(uri = "airBargainManagerDriver/deleteFullReduceBatch", response = GetBargainListResponse.class)
    String deleteFullReduceBatch(@SF("fullReduceIdList") List<String> fullReduceIdList);

    /**
     * 更新满减优惠
     * @return String
     */
    @SocketParam(uri = "airBargainManagerDriver/updateFullReduce", response = BaseSocketResponse.class)
    String updateFullReduce(@SF("fullReduceBean")FullReduceBean fullReduceBean);

    /**
     * 获取满减优惠列表
     * @return String
     */
    @SocketParam(uri = "airBargainManagerDriver/optFullReduceList", response = GetBargainListResponse.class)
    String optFullReduceList();
}
