package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * Created by virgil on 2017/6/16.
 */

public interface CBase {
    /**
     * 更新meta表信息
     *
     * @param key
     * @param value
     */
    @SocketParam(uri = "bizsync/updateMeta", response = BaseSocketResponse.class, timeOut = 80)
    void updateMeta(@SF("key") int key,
                    @SF("value") String value);
}
