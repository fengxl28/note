package com.mwee.android.air.db.business.table;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class AirTableManageInfo extends DBModel {

    @ColumnInf(name = "fsmtableid", primaryKey = true)
    public String fsmtableid = "";  //餐桌代码

    @ColumnInf(name = "fsmtablename")
    public String fsmtablename = ""; //餐桌名称

    @ColumnInf(name = "fsmareaid")
    public String fsmareaid = "";  //餐区代码

    @ColumnInf(name = "fiseats")
    public int fiseats = 0;  //座位数


    @ColumnInf(name = "fisharebills")
    public int fisharebills = 0;  //拼台数

    @ColumnInf(name = "fsmtablesteid")
    public String fsmtablesteid = "1";  //餐桌狀態代號;1空闲 / 2开台 / 3占用 / 8预订 / 9停用


    @ColumnInf(name = "fisharebillsInUse")
    public int fisharebillsInUse = 0;  //拼台中有订单的桌台数量

    @ColumnInf(name = "fisortorder")
    public int fisortorder = 0;  //桌台排序

    public AirTableManageInfo() {
    }
}
