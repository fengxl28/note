package com.mwee.android.pos.component.accountbook.net;


import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.List;

/**
 * 提交账套-订单
 */
public class CommitAccountBookBillResponse extends BasePosResponse {

    public int insertCount = 0;

    public CommitAccountBookBillResponse() {
    }
}
