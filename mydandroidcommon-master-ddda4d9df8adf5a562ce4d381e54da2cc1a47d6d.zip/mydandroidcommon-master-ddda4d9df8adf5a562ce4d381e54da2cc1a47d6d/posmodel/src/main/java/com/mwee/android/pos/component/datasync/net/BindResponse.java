package com.mwee.android.pos.component.datasync.net;


import com.mwee.android.pos.component.datasync.net.model.BindDataModel;

/**
 */
public class BindResponse extends BasePosResponse {
    public String tag = "";

    public BindDataModel data = new BindDataModel();

    public BindResponse() {

    }


}
