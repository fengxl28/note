package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/1/2.
 */

public class Response<T> extends BusinessBean {
    public int currentPage;
    public int pageSize;
    public int totalCount;
    public int totalPages;

    public ArrayList<T> result = new ArrayList<>();

    public Response() {
    }
}
