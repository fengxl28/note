package com.mwee.android.air.db.business.menu;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/10/25.
 */

public class MenuPackageSetSideDtlBean extends DBModel {
    @ColumnInf(name = "fiSetFoodCd")
    public String fiSetFoodCd = "0";
    @ColumnInf(name = "fiItemCd_M")
    public String fiItemCd_M = "0";
    @ColumnInf(name = "fiItemCd")
    public String fiItemCd = "0";
    @ColumnInf(name = "fiOrderUintCd")
    public String fiOrderUintCd = "0";
    @ColumnInf(name = "fsItemName")
    public String fsItemName;
    /**
     * --销售数量/该菜品基数;
     */
    @ColumnInf(name = "fdSaleQty")
    public BigDecimal fdSaleQty = BigDecimal.ZERO;

    public MenuPackageSetSideDtlBean() {
    }
}
