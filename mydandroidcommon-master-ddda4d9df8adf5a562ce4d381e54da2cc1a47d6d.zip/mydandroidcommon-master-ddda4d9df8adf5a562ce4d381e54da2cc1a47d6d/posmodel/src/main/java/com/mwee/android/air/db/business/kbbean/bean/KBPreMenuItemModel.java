package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.sqlite.base.DBModel;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/5/18.
 */


public class KBPreMenuItemModel extends DBModel {
    /**
     * 菜品CD
     */
    public String fiItemCd = "";
    /**
     * 规格CD
     */
    public String fiOrderUintCd = "";


    /**
     * 菜谱ID
     */
    public String cook_id = "";

    /**
     * 菜谱版本号，用时间戳实现（示例：date.getTime()）
     */
    public String cook_version = "";
    /**
     * 菜品ID
     */
    public String dish_id = "";
    /**
     * 菜品名称
     */
    public String dish_name = "";
    /**
     * 菜品skuId
     */
    public String sku_id = "";
    /**
     * 规格中文名，没有规格时不需要填写
     */
    public String spec_name = "";
    /**
     * 做法信息，格式按照：做法=做法加价（单价）。价格以元为单位，精度到分
     */
    public String practice_info = "";
    /**
     * 做法合计加价（单价），以元为单位，精度到分
     */
    public BigDecimal practice_price = BigDecimal.ZERO;
    /**
     * 售价（单价），以元为单位，精度到分
     */
    public BigDecimal sell_price = BigDecimal.ZERO;
    /**
     * 会员价（单价），以元为单位，精度到分
     */
    public BigDecimal member_price = BigDecimal.ZERO;

    /**
     * 菜品总价 方便配料菜处理
     */
    public BigDecimal dish_total_amount = BigDecimal.ZERO;
    /**
     * 是否改价
     */
    public boolean has_change;
    /**
     * 改价（单价），以元为单位，精度到分
     */
    public BigDecimal change_price = BigDecimal.ZERO;
    /**
     * 改价原因
     */
    public String change_reason = "";
    /**
     * 菜品单位
     */
    public String dish_unit = "";
    /**
     * 菜品数量，≥1
     */
    public BigDecimal dish_num = BigDecimal.ZERO;
    /**
     * 菜品点菜序号
     */
    public int sort;
    /**
     * 催菜次数
     */
    public int remind_time;
    /**
     * 是否可以享受优惠
     */
    public boolean discountable;
    /**
     * 制作状态，取值约定：INIT-未制作，MAKE-已制作，SERVE-已上菜，REFUND-已退菜
     */
    public String make_status = "";
    /**
     * 叫起状态，取值约定：WAIT-等待叫起，UP-已叫起
     */
    public String wake_status = "";
    /**
     * 退菜原因
     */
    public String refund_reason = "";
    /**
     * 备注【少放辣椒】
     */
    public String memo = "";
    /**
     * 下单操作员ID
     */
    public String operator = "";
    /**
     * 用户身份标识：手机号码、userId等等。如果是支付宝扫码点菜的，就是用户userId
     */
    public String user_identity = "";

    /**
     * 菜品明细版本号
     */
    public String dish_version = "";


    /**
     * pos本地订单菜明细流水号
     */
    public String out_detail_no = "";


    /**
     * 是否是主明细，默认都是主明细。除了点套餐的时候，套餐本身这个菜作为主明细设置，套餐下的菜明细作为非主明细设置。
     */
    public boolean main_flag;


    /**
     * 主明细id，套餐下的菜品对应的主明细id
     */
    public String main_out_detail_no = "";


    /**
     * 菜明细类型，SINGLE(单品)/SIDE(加料)/COMBO(套餐)/COMBO(套餐内单品)
     */
    public String type = "";

    /**
     * 构建套餐明细数据
     * 1 入库的时候整理数据 套餐明细头作为菜品头  套餐明细需要入这个字段里面  并且从列表从剔除
     */
    public ArrayList<KBPreMenuItemModel> packageMenuItemDetails = new ArrayList<>();


    /**
     * 菜品所属套餐头名称
     */
    public String parentName = "";


    /**
     * 已选的配料
     */
    public ArrayList<KBPreMenuItemModel> selectedModifier = new ArrayList<>();

    /**
     *  配料菜数据拼接吧
     */
    //public String ingredientNotes ="";

    /**
     * 下单时间，格式yyyy-mm-dd hh:mm:ss
     */
    public String order_time = "";

    /**
     * 退菜时间，格式yyyy-mm-dd hh:mm:ss
     */
    public String refund_time = "";

    /**
     * 扩展信息，json对象格式，key和value都为字符串  扩展信息，json对象格式，key和value都为字符串
     */
    public String ext_info = "";


}
