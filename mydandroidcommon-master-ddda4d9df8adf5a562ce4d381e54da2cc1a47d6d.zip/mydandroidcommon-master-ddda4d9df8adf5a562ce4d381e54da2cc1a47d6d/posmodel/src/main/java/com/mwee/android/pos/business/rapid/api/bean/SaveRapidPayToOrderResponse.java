package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by virgil on 2017/7/31.
 */

public class SaveRapidPayToOrderResponse extends BaseSocketResponse {
    /**
     * 0，支付金额匹配：
     * 1，支付金额溢出
     * 2，支付金额不足
     */
    public int payAmountNotRight = 0;

    /**
     * 订单号
     */
    public String orderId = "";

    public SaveRapidPayToOrderResponse() {
    }
}
