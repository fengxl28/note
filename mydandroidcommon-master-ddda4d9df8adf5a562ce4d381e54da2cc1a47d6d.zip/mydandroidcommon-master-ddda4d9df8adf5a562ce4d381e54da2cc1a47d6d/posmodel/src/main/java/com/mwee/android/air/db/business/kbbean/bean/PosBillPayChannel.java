package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/22.
 */

public class PosBillPayChannel extends BusinessBean {

    //支付渠道类型
    public String channel_type;

    //外部支付订单号,唯一标识本次支付的requestID
    public String out_pay_no;

    //支付渠道本身自己的支付订单号
    public String pay_no;

    //支付抵扣金额
    public BigDecimal pay_amount;

    //支付实收金额
    public BigDecimal receipt_amount;

    //用户身份标识：手机号码、userId等
    public String user_identity;

    //收银员ID
    public String operator;

    //扩展信息，json对象格式，key和value都为字符串
    public String ext_info;

    //支付渠道类型
    public List<PosDiscountDetail> discount_details = new ArrayList<>();

    public List<RapidPayModel> rapidPayModels = new ArrayList<>();


    //付款时间
    public String pay_time;

    public PosBillPayChannel(){
        
    }




}
