package com.mwee.android.pos.business.rapid.api.bean.model;

import android.support.annotation.IntDef;

import com.mwee.android.base.net.BusinessBean;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.math.BigDecimal;
import java.util.List;

/**
 * 秒点订单的配料类
 * Created by virgil on 2016/11/3.
 *
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23005576
 *
 */
public class RapidOrderModifier extends BusinessBean {
    /**
     * 是否为套餐(0配料，1套餐)
     * 是否为套餐子菜项(0配料,1套餐),itemType=3时，子菜对应的isSet为1，其他情况均为0
     */
    @IsSet
    public int isSet = INGREDIENTS;
    /**
     *
     */
    public String itemId = "";
    /**
     * 要求（套餐）id
     */
    public String modifierId = "";
    /**
     *
     */
    public String modifierItemCode = "";
    /**
     *
     */
    public String modifierItemId = "";
    /**
     * 要求（套餐）名称
     */
    public String modifierName = "";
    /**
     * 要求（套餐）数量
     */
    public int modifierNum = 0;
    /**
     * 套餐内菜的第三方系统菜单id
     */
    public String modifierOuterItemId = "";
    /**
     *
     */
    public BigDecimal modifierPrice = BigDecimal.ZERO;
    /**
     *配料(套餐)分类ID（选填）
     */
    public String modifierTypeId = "";
    /**
     * 配料(套餐)分类名称（选填）
     */
    public String modifierTypeName = "";
    /**
     *
     */
    public int operateNum = 0;
    /**
     * 要求/套餐总价格
     */
    public BigDecimal totalModifierPrice = BigDecimal.ZERO;

    /**
     * 会员价
     */
    public BigDecimal vipModifierPrice = BigDecimal.ZERO;

    /**
     * 第三方系统配料(套餐)id（端上有就给）
     */
    public String outerModifierId = "";
    /**
     * 第三方系统要求/套餐的父类id
     */
    public String outerModifierTypeId = "";


    /**
     * 配料组的类型(0: 通用， 1：规格，2：口味，3：做法)
     */
    @GroupType
    public int groupType = GENERAL;
    /**
     * 规格ID
     */
    public String spec = "0";
    /**
     * 规格名称
     */
    public String unit = "";
    /**
     * 子项的子项
     */
    public List<RapidOrderModifier> modifiers=null;
    public RapidOrderModifier() {
    }

    /**
     * 配料
     */
    public static final int INGREDIENTS = 0;
    /**
     * 套餐
     */
    public static final int SET_MEAL = 1;

    @IntDef({INGREDIENTS, SET_MEAL})
    @Retention(RetentionPolicy.SOURCE)
    public @interface IsSet {
    }

    /**
     * 通用
     */
    public static final int GENERAL = 0;
    /**
     * 规格
     */
    public static final int SPECIFICATION = 1;
    /**
     * 口味
     */
    public static final int TASTE = 2;
    /**
     * 做法
     */
    public static final int PRACTICE = 3;
    /**
     * 要求、备注
     */
    public static final int ASK = 4;
    /**
     * 用户自定义备注
     */
    public static final int NOTE_CUSTOME = 5;
    @IntDef({GENERAL, SPECIFICATION, TASTE,ASK, PRACTICE,NOTE_CUSTOME})
    @Retention(RetentionPolicy.SOURCE)
    public @interface GroupType {
    }
}
