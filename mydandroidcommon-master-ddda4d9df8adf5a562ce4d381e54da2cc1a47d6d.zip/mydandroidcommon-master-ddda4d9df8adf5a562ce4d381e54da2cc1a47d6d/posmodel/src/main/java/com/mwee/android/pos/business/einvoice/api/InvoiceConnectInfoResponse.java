package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.pos.business.einvoice.model.InvoiceConnectStatusBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:票通宝连接状态请求响应
 */
public class InvoiceConnectInfoResponse extends BasePosResponse {
    public InvoiceConnectStatusBean data;

    public InvoiceConnectInfoResponse() {

    }
}
