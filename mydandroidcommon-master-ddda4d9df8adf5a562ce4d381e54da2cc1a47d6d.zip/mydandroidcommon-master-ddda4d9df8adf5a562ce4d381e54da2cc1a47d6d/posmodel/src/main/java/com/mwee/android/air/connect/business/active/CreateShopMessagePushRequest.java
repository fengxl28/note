package com.mwee.android.air.connect.business.active;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:luoshenghua create on:2018/12/11
 * description:小易建店并激活成功后回传状态告知后台
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28640452
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "createShopMessagePush",
        response = CreateShopMessagePushResponse.class,
        timeOut = 270)
public class CreateShopMessagePushRequest extends BasePosRequest {
    /**
     * 用户id
     */
    public String userId = "";
    /**
     * 用户名
     */
    public String userName = "";
    /**
     * 状态描述
     */
    public Map<String, String> createShopMessageDto = new HashMap<>();

    @Override
    public String optBaseUrl() {
        return Constant.getCreateShopUrlPrefix();
    }

    public CreateShopMessagePushRequest() {
    }
}