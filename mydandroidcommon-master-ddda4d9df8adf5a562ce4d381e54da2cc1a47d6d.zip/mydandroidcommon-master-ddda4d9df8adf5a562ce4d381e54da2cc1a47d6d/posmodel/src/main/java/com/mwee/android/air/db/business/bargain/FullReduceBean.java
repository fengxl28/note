package com.mwee.android.air.db.business.bargain;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * author:luoshenghua
 * create on:2018/6/5
 * description:满减优惠列表显示Bean
 */
public class FullReduceBean extends DBModel {

    @ColumnInf(name = "fsBargainId")
    public String fsBargainId = "";

    @ColumnInf(name = "fsBargainName")
    public String fsBargainName = "";

    @ColumnInf(name = "fiPlanType")
    public int fiPlanType = 0;

    @ColumnInf(name = "fdFullmoney")
    public BigDecimal fdFullmoney = BigDecimal.ZERO;


    @ColumnInf(name = "fdCutmoney")
    public BigDecimal fdCutmoney = BigDecimal.ZERO;


    @ColumnInf(name = "fifullcuttype")
    public int fifullcuttype = 0;


    public FullReduceBean() {
    }
}
