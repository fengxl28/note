package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BaseResponse;

/**
 * Created by qinwei on 2018/1/9.
 */

public class CrossPayResponse extends BaseResponse {
    public CrossPayResult data = new CrossPayResult();

    public CrossPayResponse() {
    }
}
