package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/12/14.
 */

public class RapidOpenParamItem extends BusinessBean {

    /**
     * 第三方菜品ID
     */
    public String outerItemId;

    /**
     * 菜品ID
     */
    public String itemId = "0";
    /**
     * 菜品名称
     */
    public String itemName;
    /**
     * 1,菜品数量（注：如果是按人头收的，这里传实际人数）
     */
    public int itemNum;
    /**
     * 0赠送，1原价
     */
    public int itemPriceType;
    /**
     * 会员价
     */
    public double vipPrice;
    /**
     * 原价
     */
    public double itemPrice;
    /**
     * 原价
     */
    public String unit;

    public RapidOpenParamItem() {
    }
}
