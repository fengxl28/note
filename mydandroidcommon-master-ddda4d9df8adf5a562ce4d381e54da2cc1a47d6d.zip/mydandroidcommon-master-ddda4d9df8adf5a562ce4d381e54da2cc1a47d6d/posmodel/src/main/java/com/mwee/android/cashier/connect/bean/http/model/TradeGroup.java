package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/2/8.
 */

public class TradeGroup extends BusinessBean {
    public BigDecimal amtSum = BigDecimal.ZERO;
    public List<Trade> dataList = new ArrayList<>();
    public String sellDate;
    public int billCount;
}
