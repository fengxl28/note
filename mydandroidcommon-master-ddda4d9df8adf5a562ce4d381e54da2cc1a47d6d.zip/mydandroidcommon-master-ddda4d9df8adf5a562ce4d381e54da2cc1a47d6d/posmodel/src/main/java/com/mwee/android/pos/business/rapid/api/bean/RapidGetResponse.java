package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by virgil on 2016/11/3.
 */

public class RapidGetResponse extends BasePosResponse {
    public RapidGetModel data = null;

    public RapidGetResponse() {

    }
}
