package com.mwee.android.air.connect.business.active;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/7/16
 * description:美小易标准版， 激活门店二维码bean
 */
public class ActiveAirShopQRBean extends BusinessBean {
    /**
     * 激活门店二维码链接
     */
    public String url = "";

    public String code = "";

    public ActiveAirShopQRBean(){}
}
