package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.advertising.AirWelcomeAdvertisingResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * created by 2018/8/21
 *
 * @author lxd
 * Description:启动页广告接口
 */
public interface CAdvertising{
    @SocketParam(uri = "advertising/startUpImage", response = AirWelcomeAdvertisingResponse.class)
    String startUpImage(@SF("dimension") String dimension);
}
