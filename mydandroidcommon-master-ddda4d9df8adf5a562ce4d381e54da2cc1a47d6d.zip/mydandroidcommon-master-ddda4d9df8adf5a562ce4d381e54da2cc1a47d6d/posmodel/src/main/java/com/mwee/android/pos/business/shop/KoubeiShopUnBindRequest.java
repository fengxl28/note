package com.mwee.android.pos.business.shop;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/9/27.
 */
@HttpParam(httpType = HttpType.POST,
        method = "authority/deleteMwAndKouBeiShopMapping",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 5)
public class KoubeiShopUnBindRequest extends BaseKouBeiRequest {

    public KoubeiShopUnBindRequest() {

    }
}