package com.mwee.android.pos.base;

/**
 * Created by lxx on 16/8/9.
 */
public class NetworkConstans {
    public static final String ELEME_BING_URL_TEST = "https://open-api-sandbox.shop.ele.me/authorize?response_type=code&client_id=i51fumWOjN&state=SHOPGUID&redirect_uri=http%3A%2F%2Fwm.dc.test.9now.net%2Fservices%2Fwm%2Fgateway%2Fele%2Fnew%2Fshop%2Fbind&scope=all";
    public static final String MEITUAN_BING_URL_TEST = "https://open-erp.meituan.com/storemap?developerId=100999&businessId=2&ePoiId=SHOPGUID&signKey=as59ji8fa1xn326d&callbackUrl=http%3a%2f%2fwm.dc.test.9now.net%2fservices%2fwm%2fgateway%2fmeituanErp%2fshop%2fbing";
    public static final String ELEME_BING_URL = "https://open-api.shop.ele.me/authorize?response_type=code&client_id=nyDThf9i5I&state=SHOPGUID&redirect_uri=https%3A%2F%2Fwmdc.mwee.cn%2Fservices%2Fwm%2Fgateway%2Fele%2Fnew%2Fshop%2Fbind&scope=all";
    public static final String MEITUAN_BING_URL = "https://open-erp.meituan.com/storemap?developerId=100178&businessId=2&ePoiId=SHOPGUID&signKey=npwm9uvhmk1y1cdk&callbackUrl=http%3a%2f%2fwm.dc.mwee.cn%2fservices%2fwm%2fgateway%2fmeituanErp%2fshop%2fbing";
    /**
     * orderStatus 订单状态(0新单，1已确认，2已下单到厨房，3已完成，-1已删除，-2已取消)
     */
    public static final int ORDER_STATUS_NEW = 0;
    public static final int ORDER_STATUS_CHECK = 1;
    public static final int ORDER_STATUS_KDS = 2;
    public static final int ORDER_STATUS_OVER = 3;
    public static final int ORDER_STATUS_DELETE = -1;
    public static final int ORDER_STATUS_CANCEL = -2;


    /**
     * 微信点餐 订单状态(0新单，1已确认，2已完成，3已取消)
     * 订单状态{0待接单，1：接单，2：完成，3：取消，4：商家取消，5退款中，6：退款成功 ，7：退款失败，11：待支付，12：支付失败}
     */
    public static final int WECHAT_STATUS_NEW = 0;
    public static final int WECHAT_STATUS_GET = 1;
    public static final int WECHAT_STATUS_OVER = 2;
    public static final int WECHAT_STATUS_CANCEL = 3;
    public static final int WECHAT_STATUS_CANCEL_FROM_SHOP = 4;
    public static final int WECHAT_STATUS_BATING = 5;
    public static final int WECHAT_STATUS_BACK_OVER = 6;
    public static final int WECHAT_STATUS_BACK_FAIL = 7;
    public static final int WECHAT_STATUS_UNPAY = 11;
    public static final int WECHAT_STATUS_PAY_FAIL = 12;

    /**
     * 支付状态	payStatus	int	支付状态(-1已退款，0，未支付, 1部分支付，2已支付，3已就餐)
     */
    public static final int PAY_STATUS_VOID = -1;
    public static final int PAY_STATUS_UNPAY = 0;
    public static final int PAY_STATUS_PAY_PART = 1;
    public static final int PAY_STATUS_PAY_ALL = 2;
    public static final int PAY_STATUS_DINING = 3;

    /**
     * payType 支付方式ID(0默认，1微信，2支付宝，3银联，4百度钱包，5会员卡支付)
     */

    public static final int PAY_TYPE_DEFAULT = 0;
    public static final int PAY_TYPE_WX = 1;
    public static final int PAY_TYPE_ALI = 2;
    public static final int PAY_TYPE_YINLIAN = 3;
    public static final int PAY_TYPE_BAIDU = 4;
    public static final int PAY_TYPE_MEMBER = 5;
    public static final String[] PAY_TYPE_ARR = new String[]{"默认", "微信", "支付宝", "银联", "百度钱包", "会员卡"};

    /**
     * 就餐状态 diningStatus  ---> 0未确认,10已确认,20下单到厨房,30饭已做好(已分配取餐柜柜号),35：派送中；40用户已取，45已签收，已签收，-1已退款，-2取消订单
     */
    public static final int DINING_STATUS_NEW = 0;
    public static final int DINING_STATUS_GET = 10;
    public static final int DINING_STATUS_KOT = 20;
    public static final int DINING_STATUS_READ = 30;
    public static final int DINING_STATUS_SANDBLE = 32;  //可派送--自己加的(只用在B端)
    public static final int DINING_STATUS_SANDING = 35;  //派送中
    public static final int DINING_STATUS_USER_GET = 40;
    public static final int DINING_STATUS_USER_SIGN = 45;//暂时没有定义（后台没有）
    public static final int DINING_STATUS_USER_VOID = -1;
    public static final int DINING_STATUS_USER_CANCEL = -2;

    /**
     * 业务类型：
     * 0：点菜，1：预点单  2：预约，3：快餐，4：外卖，6：取餐盒, 8第三方平台点菜，13扫桌号点菜, 14点菜宝手持设备点菜，16热餐配送，17冷餐配送
     * #以下网络订单暂时不接--不入库
     * 5：纯收银，7：POS刷卡， 9自助买单，10会员充值，11APP自助买单，12点菜宝收银， 15WIN POS收银，
     */
    public static final int BIZ_TYPE_DEFAULT = 0;
    public static final int BIZ_TYPE_TAKEOUT = 4;
    public static final int BIZ_TYPE_FOODBOX = 6;
    public static final int BIZ_TYPE_THIRDLY = 8;
    public static final int BIZ_TYPE_TAKEOUT_XIAGAOXIANONG_HOT = 16;
    public static final int BIZ_TYPE_TAKEOUT_XIAGAOXIANONG_COLD = 17;


    /*外卖单送达类型：  1：立即送达；2：预约送达；3：7日内送达*/
    public static final int DISTRIBUTION_TYPE_IMMEDIATELY = 1;
    public static final int DISTRIBUTION_TYPE_SPECIFIED = 2;
    public static final int DISTRIBUTION_TYPE_SEVEN_DAYS = 3;

    /**
     * 备餐方式
     */
    public static final int READY_FOOD_MODE_NOW = 1;
    public static final int READY_FOOD_MODE_LATER = 2;

    /*need_receipt 是否需要发票(0-否, 1-是)*/
    public static final int NEED_RECEIPT_Y = 1;
    public static final int NEED_RECEIPT_N = 0;

    /*receipt_type 发票类型(0-无，1-个人, 2-单位)*/
    public static final String RECEIPT_TYPE_NONE = "0";
    public static final String RECEIPT_TYPE_SINGLE = "1";
    public static final String RECEIPT_TYPE_COMPNEY = "2";

    /**
     * 商户操作行为
     * 1接单、客户已到店、堂食订单马上备餐
     * 3、请取餐
     * 5可派送
     * 10派送
     * 15完成
     * 20取消
     * 25退单
     */
    public static final int OPERATION_TYPE_GET = 1;
    public static final int PLEASE_TAKE_FOOD = 3;
    public static final int OPERATION_TYPE_SENDABLE = 5;
    public static final int OPERATION_TYPE_SEND = 10;
    public static final int OPERATION_TYPE_OVER = 15;
    public static final int OPERATION_TYPE_CANCEL = 20;
    public static final int OPERATION_TYPE_VOID = 25;

}
