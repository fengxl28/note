package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuItemUnitBean;
import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * 菜品编辑数据
 * Created by qinwei on 2018/5/18.
 */

public class MenuItemEditorBody extends BusinessBean {
    public String name;
    public String unitName;
    public String price;
    public String memberPrice;
    public String repertoryNumber;
    public boolean isCanDiscount;
    public boolean isCanGift;
    public boolean isCanTimePrice;
    public boolean isCanWeight;
    public boolean isCanOutTake;
    public boolean isCanPrinter;
    public boolean isCanPreOrder;
    public boolean isCanWeChatOrder = true;
    public String menuClsId;
    public String fiOrderUintCd = "0";
    public int fiStatus = 1;
    public String fsExpClsId = "";
    public String fsRevenueTypeId = "";
    public String fsUserId = "admin";
    public String fsUserName = "管理员";

    /**
     * 是否是临时菜
     */
    public int fiIsTemporaryMenu;
    public String fdLunchBoxCost;


    public ArrayList<MenuItemUnitBean> menuItemUnitBeans = new ArrayList<>();

    public MenuItemEditorBody() {
    }
}
