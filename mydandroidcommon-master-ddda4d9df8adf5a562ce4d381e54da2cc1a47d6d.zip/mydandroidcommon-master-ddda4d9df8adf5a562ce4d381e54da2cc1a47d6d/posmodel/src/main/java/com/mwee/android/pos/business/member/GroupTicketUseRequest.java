package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * 会员验券
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=10490840
 */
@HttpParam(httpType = HttpType.POST,
        method = "memberConsumeCoupons",
        response = GroupTicketUseResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class GroupTicketUseRequest extends BaseMemberRequest {
    /**
     * 券类型
     */
    public String type;
    /**
     * 券号
     */
    public String sn;

    /**
     * 如果该店开通极速验券，则必填
     */
    public int num;

    public GroupTicketUseRequest() {
        super("");
    }

}
