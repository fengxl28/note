package com.mwee.android.air.db.business.menu;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * 规格bean
 * Created by qinwei on 2018/6/4.
 */

public class MenuItemUnitBean extends DBModel {
    /**
     * 菜品id
     */
    @ColumnInf(name = "fiItemCd")
    public String fiItemCd = "0";
    /**
     * 规格id
     */
    @ColumnInf(name = "fiOrderUintCd")
    public String fiOrderUintCd = "0";

    /**
     * 单价
     */
    @ColumnInf(name = "fdSalePrice")
    public BigDecimal fdSalePrice;

    /**
     * 会员价
     */
    @ColumnInf(name = "fdVIPPrice")
    public BigDecimal fdVIPPrice;

    /**
     * 库存
     */
    @ColumnInf(name = "fdInvQty")
    public BigDecimal fdInvQty;

    /**
     * 规格名称
     */
    @ColumnInf(name = "fsOrderUint")
    public String fsOrderUint;


    /**
     * 标记操作类型 规格
     */
    public int editor_mode = MODE_ADD;

    public static final int MODE_ADD = 0;
    public static final int MODE_EDITOR = 1;
    public static final int MODE_DELETE = 2;
    /**
     * 菜品名称
     */
    public String fsItemName;
    /**
     * 库存数量
     */
    public String repertoryNumber;

    public MenuItemUnitBean() {
    }
}