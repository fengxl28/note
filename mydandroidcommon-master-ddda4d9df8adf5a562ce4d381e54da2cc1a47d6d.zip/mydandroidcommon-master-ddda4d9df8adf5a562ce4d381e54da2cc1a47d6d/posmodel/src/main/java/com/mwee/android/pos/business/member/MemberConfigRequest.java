package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBaseRequest;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2017/9/4.
 * 是否开通会员服务及绑定会员的形式
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28644032
 */
@HttpParam(httpType = HttpType.POST,
        method = "getCardOpenService",
        response = MemberConfigResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 5)
public class MemberConfigRequest extends NewMemberBaseRequest {
    /**
     * 总店id
     */
    public int companyGUID;

    /**
     * 会员卡配置Id
     * 不传递默认走总店配置
     */
    public int  csId;

    public MemberConfigRequest() {
    }

}
