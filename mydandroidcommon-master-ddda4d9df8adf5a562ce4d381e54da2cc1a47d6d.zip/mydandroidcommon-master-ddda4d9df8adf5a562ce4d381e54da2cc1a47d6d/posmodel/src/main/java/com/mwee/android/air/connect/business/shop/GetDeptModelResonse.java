package com.mwee.android.air.connect.business.shop;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.DeptDBModel;

/**
 * Created by zhangmin on 2017/10/25.
 */

public class GetDeptModelResonse extends BaseSocketResponse {

    public DeptDBModel deptDBModel = new DeptDBModel();

    public GetDeptModelResonse(){

    }
}
