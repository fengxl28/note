package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.GroupTicketUseResult;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * Created by qinwei on 2017/1/11.
 */

public class GroupTicketUseResponse extends BaseMemberResponse {
    public GroupTicketUseResult data = new GroupTicketUseResult();

    public GroupTicketUseResponse() {
    }
}
