package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 获取口碑预点单正餐模式下 已经预约的桌台信息
 */
@HttpParam(httpType = HttpType.POST,
        method = "kborder/getListDinner",
        response = KPreTempDinnerResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KPreTempDinnerDataRequest extends BaseKouBeiRequest {


    public KPreTempDinnerDataRequest() {

    }
}
