package com.mwee.android.air.connect.business.menu;

import com.alibaba.fastjson.JSONArray;
import com.mwee.android.base.net.BusinessBean;

public class UploadDishTypeBean extends BusinessBean {
    /**
     * @link this.IDishType
     */
    public int type = 0;
    /**
     * 菜品分类id
     */
    public JSONArray targetId = new JSONArray();

    /**
     * @link this.IActionType
     */
//    public String actionType = "";


    public interface IDishType {
        //菜品分类
        int MENU_CLS = 1;
        //要求
        int ASK_GP = 2;
        //要求
        int ASK_DETAIL = 3;
        //配料
        int INGREDIENT = 4;
        //配料明细
        int INGREDIENT_DETAIL = 5;
    }

    public interface IActionType {
        //新增行为
        String ADD = "ADD";
        //修改行为
        String UPDATE = "UPDATE";
        //删除行为
        String DELETE = "DELETE";
    }


    public UploadDishTypeBean() {
    }
}
