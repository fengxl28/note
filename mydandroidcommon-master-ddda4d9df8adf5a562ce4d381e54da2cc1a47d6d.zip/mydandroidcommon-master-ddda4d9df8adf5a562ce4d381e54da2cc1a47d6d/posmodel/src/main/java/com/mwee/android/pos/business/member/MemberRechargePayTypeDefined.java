package com.mwee.android.pos.business.member;

/**
 * 会员支付方式的定义
 * Created by chris on 16/8/30.
 */
public class MemberRechargePayTypeDefined {


    public static String getPayTypeStr(int payType){
        String payTypeStr = "";
        switch (payType) {
            case MemberRechargePayTypeDefined.PayClassDefined.ALIPAY:
                payTypeStr = MemberRechargePayTypeDefined.PayTypeDefined.ALIPAY;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.WECHAT:
                payTypeStr = MemberRechargePayTypeDefined.PayTypeDefined.WEIXIN;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.UP:
                payTypeStr = MemberRechargePayTypeDefined.PayTypeDefined.UNIONPAY;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.BAIDU:
                payTypeStr = MemberRechargePayTypeDefined.PayTypeDefined.BAIFUBAO;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.DEFAULT:
                payTypeStr = MemberRechargePayTypeDefined.PayTypeDefined.CASH;
                break;
        }
        return payTypeStr;
    }

    /**
     * 0默认，1微信，2支付宝，3银联，4百度钱包
     */
    public static class PayClassDefined {
        /**
         * 0默认
         */
        public static final int DEFAULT = 0;
        /**
         * 1微信
         */
        public static final int WECHAT = 1;
        /**
         * 2支付宝
         */
        public static final int ALIPAY = 2;
        /**
         * 3银联
         */
        public static final int UP = 3;
        /**
         * 4百度钱包
         */
        public static final int BAIDU = 4;
    }


    /**
     * alipay=>支付宝 weixin=>微信支付 baifubao=>百度钱包
     * tenpay=>财付通,bank=>银行卡（全能pos收银 刷卡） unionpay=>银联在线支付
     * cash=>现金充值
     */

    public static class PayTypeDefined {
        public static final String ALIPAY = "alipay";
        public static final String WEIXIN = "weixin";
        public static final String BAIFUBAO = "baifubao";
        public static final String TENPAY = "tenpay";
        public static final String BANK = "bank";
        public static final String UNIONPAY = "unionpay";
        public static final String CASH = "cash";
    }
}
