package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/5/30.
 */

public class PayStatusQueryModel extends BusinessBean {

    /**
     * 状态： 1未退款 2有退款请求 3退款失败 4退款成功
     */
    public int status = 0;

    /**
     * 单号
     */
    public String orderno = "";

    public PayStatusQueryModel() {
    }
}
