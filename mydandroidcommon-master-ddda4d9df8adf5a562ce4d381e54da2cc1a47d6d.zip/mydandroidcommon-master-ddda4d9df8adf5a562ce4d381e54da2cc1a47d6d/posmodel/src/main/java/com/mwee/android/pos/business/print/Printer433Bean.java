package com.mwee.android.pos.business.print;

import com.mwee.android.base.net.BusinessBean;

/**
 *
 * Created by huangming on 2018/5/24.
 */
public class Printer433Bean extends BusinessBean {

    public String printerName = "";
    public String printerSN = "";
    public String hostId = "";
    public String stationId = "";
    public byte status;
}
