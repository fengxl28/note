package com.mwee.android.pos.base;

import android.app.Activity;
import android.util.DisplayMetrics;

import java.math.BigDecimal;

/**
 * Created by virgil on 2016/12/23.
 *
 * @author virgil
 */

public class BizConstant {

    /**
     * 一百
     */
    public static final BigDecimal HUNDREND = new BigDecimal(100);
    /**
     * 负1
     */
    public static final BigDecimal NEGATIVE = new BigDecimal(-1);

    /**
     * APP的VersionCode
     */
    public static int VERSION_CODE = 0;
    /**
     * App的VersionName
     */
    public static String VERSION_NAME = "";

    /**
     * 屏幕高
     */
    public static int screenHeight = 0;
    /**
     * 屏幕宽
     */
    public static int screenWidth = 0;
    /**
     * 屏幕密度
     */
    public static float screenDensity = 0;

    public static String DEVICE_ID="";
    public static void initDisplay(Activity context) {
        if (screenDensity == 0 || screenWidth == 0 || screenHeight == 0) {
            DisplayMetrics dm = new DisplayMetrics();
            context.getWindowManager().getDefaultDisplay().getMetrics(dm);
            screenDensity = dm.density;
            screenHeight = dm.heightPixels;
            screenWidth = dm.widthPixels;
        }
    }

    public static int getScreenHeight(Activity context) {
        if (screenWidth == 0 || screenHeight == 0) {
            DisplayMetrics dm = new DisplayMetrics();
            context.getWindowManager().getDefaultDisplay().getMetrics(dm);
            screenDensity = dm.density;
            screenHeight = dm.heightPixels;
            screenWidth = dm.widthPixels;
        }
        return screenHeight;
    }

    public static int getScreenWidth(Activity context) {
        if (screenWidth == 0 || screenHeight == 0) {
            DisplayMetrics dm = new DisplayMetrics();
            context.getWindowManager().getDefaultDisplay().getMetrics(dm);
            screenDensity = dm.density;
            screenHeight = dm.heightPixels;
            screenWidth = dm.widthPixels;
        }
        return screenWidth;
    }
}
