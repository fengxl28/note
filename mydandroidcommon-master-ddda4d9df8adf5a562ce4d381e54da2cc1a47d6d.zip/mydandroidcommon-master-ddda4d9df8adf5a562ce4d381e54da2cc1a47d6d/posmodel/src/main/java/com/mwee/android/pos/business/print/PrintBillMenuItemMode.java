package com.mwee.android.pos.business.print;

import android.text.TextUtils;

import com.mwee.android.pos.business.constants.CouponType;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by hm on 2018/3/20.
 */
public class PrintBillMenuItemMode extends DBModel {

    public BigDecimal qty = BigDecimal.ZERO;

    public boolean isMenuCls = false;

    public String fsItemName = "";

    public BigDecimal fdSettlePrice = BigDecimal.ZERO;

    public BigDecimal fdsaleamt = BigDecimal.ZERO;

    public int fiOrderItemKind = 0;

    public String fsNote = "";

    public String fsItemName2 = "";

    public String fsOrderUint = "";

    public int orderSeq = 0;//单序

    /**
     * vipAmt 字段从2.9起不维护，改为维护 vipAmtNew，以兼容0元会员价
     */
    public BigDecimal vipAmt = BigDecimal.ZERO;//会员价
    public String vipAmtNew = "";//会员价

    /**
     * specialAmt 字段从2.9起不维护，改为维护 specialAmtNew，以兼容0元特价
     */
    public BigDecimal specialAmt = BigDecimal.ZERO;//特价
    public String specialAmtNew = "";//特价

    public BigDecimal giftAmt = BigDecimal.ZERO;//赠送

    public BigDecimal discountAmt = BigDecimal.ZERO;//折扣价
    public String discountName = "";//折扣名

    public BigDecimal buyGiftAmt = BigDecimal.ZERO;//买减价
    public String buyGiftName = "";//买减名

    public BigDecimal originalAmt = BigDecimal.ZERO;//原始金额

    public BigDecimal originPrice = BigDecimal.ZERO;//原始单价

    public String index;//菜品序号

    public int fiWithinDiningStandard;//是否计入用餐标准，1-是，0-否

    public String rootMenuClsName;//一级分类名称

    /**
     * 套餐内容
     */
    public List<PrintBillMenuItemMode> SLIT = new ArrayList<>();

    public static PrintBillMenuItemMode create(StatementSellItemModel item) {
        PrintBillMenuItemMode mode = new PrintBillMenuItemMode();
        if (item == null) {
            return mode;
        }
        mode.fsItemName = item.fsItemName;
        mode.qty = item.qty;
        mode.isMenuCls = item.isMenuCls;
        mode.fdSettlePrice = item.fdSettlePrice;
        mode.fiOrderItemKind = item.fiOrderItemKind;
        mode.fdsaleamt = item.fdSaleAmt;
        mode.fsNote = item.fsNote;
        mode.fsItemName2 = item.fsItemName2;
        mode.fsOrderUint = item.fsOrderUint;
        mode.orderSeq = item.fiOrderSeq;
        mode.originalAmt = mode.originalAmt.add(item.fdOriginalAmt);
        mode.originPrice = mode.originPrice.add(item.fdOriginPrice);
        mode.fiWithinDiningStandard = item.fiWithinDiningStandard;
        mode.rootMenuClsName = item.fsRootMenuClsName;
        // 不统计套餐明细
        if (item.fiOrderItemKind != 3) {
            //vip金额
            if (item.fiOrderMode != 3 && item.fiPriceTag == 3 && item.fdCouponVipAmt.compareTo(BigDecimal.ZERO) >= 0) {
                mode.vipAmtNew = item.fdCouponVipAmt.toPlainString();
            }
            //特价金额
            if (item.fiOrderMode != 3 && item.fiPriceTag == 2 && item.fdCouponSpecialAmt.compareTo(BigDecimal.ZERO) >= 0) {
                mode.specialAmtNew = item.fdCouponSpecialAmt.toPlainString();
            }
            //赠送金额
            if (item.fdGiftAmt.compareTo(BigDecimal.ZERO) > 0) {
                mode.giftAmt = mode.giftAmt.add(item.fdGiftAmt);
            }
            //买减金额
            if (!TextUtils.isEmpty(item.fdBuyGiftName)) {
                mode.buyGiftAmt = mode.buyGiftAmt.add(item.fdBuyGiftAmt);
                mode.buyGiftName = item.fdBuyGiftName;
            }
            if (TextUtils.equals(item.fsDiscountId, CouponType.MEMBER_COUPON)) {
                mode.discountName = item.fsDiscountName;
                mode.discountAmt= item.fdDiscountAmt;
            } else {
                BigDecimal rate = Calc.format(new BigDecimal((100 - item.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    mode.discountName = rate0.toString() + "折";
                } else {
                    mode.discountName = rate.toString() + "折";
                }
            }
        }

        if (!ListUtil.isEmpty(item.SLIT)) {
            for (StatementSellItemModel temp : item.SLIT) {
                mode.SLIT.add(create(temp));
            }
        }
        return mode;
    }

    public static PrintBillMenuItemMode createOtherBillMode(StatementSellItemModel item, String index) {
        PrintBillMenuItemMode mode = create(item);
        mode.index = index;
        if (item.fiOrderMode != 3 &&
                ((item.fiPriceTag == 3 && !TextUtils.isEmpty(mode.vipAmtNew)) ||
                        (item.fiPriceTag == 2 && !TextUtils.isEmpty(mode.specialAmtNew)))) {
            mode.fdSettlePrice = mode.originPrice;
            mode.fdsaleamt = mode.originalAmt;
        }
        if (mode.giftAmt.compareTo(BigDecimal.ZERO) > 0 || !TextUtils.isEmpty(mode.discountName)
                || !TextUtils.isEmpty(mode.buyGiftName)) {
            mode.fdSettlePrice = mode.originPrice;
            mode.fdsaleamt = mode.originalAmt;
        }
        return mode;
    }

    public PrintBillMenuItemMode() {
    }
}
