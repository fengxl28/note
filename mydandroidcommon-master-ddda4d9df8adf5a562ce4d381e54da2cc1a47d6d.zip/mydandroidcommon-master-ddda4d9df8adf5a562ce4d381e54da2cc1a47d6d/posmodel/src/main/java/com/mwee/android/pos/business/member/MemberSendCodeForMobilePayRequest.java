package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2017/9/4.
 * 手机号支付获取验证码
 * wiki:http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23021217
 */
@HttpParam(httpType = HttpType.POST,
        method = "app.cardpay.sendMobilePaySmsCode",
//        method = "sendActiveVerifyCode",
        response = MemberCouponResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class MemberSendCodeForMobilePayRequest extends BaseMemberRequest {
    public String mobile;//手机号
    public int m_shopid;
    //品牌ID
    public int brandId;
    public String device_id;

    public MemberSendCodeForMobilePayRequest() {
        super("app.cardpay.sendMobilePaySmsCode");
    }
}
