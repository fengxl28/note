package com.mwee.android.cashier.connect.bean.http;

/**
 * Created by qinwei on 2018/2/11.
 */

public class RefundScanPaymentResponse extends BaseCashierPosResponse {

}
