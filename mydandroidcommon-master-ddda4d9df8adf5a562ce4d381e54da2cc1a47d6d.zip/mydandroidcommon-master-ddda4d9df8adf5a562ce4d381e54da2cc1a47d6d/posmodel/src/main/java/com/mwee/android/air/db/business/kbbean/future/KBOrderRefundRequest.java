package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiFutureRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 更新口碑预点单  后付款退款
 */
@HttpParam(httpType = HttpType.POST,
        method = "kbOrderRefund",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class KBOrderRefundRequest extends BaseKouBeiFutureRequest {


    /**
     * 口碑订单id
     */
    public String orderId = "";
    /**
     * 退款请求id---唯一码
     */
    public String requestId = "";
    /**
     * pos订单号
     * 非必传
     */
    public String outBizNo;
    /**
     * 订单金额
     * 必传，目前只支持全额退款，传订单总金额
     */
    public BigDecimal amount = BigDecimal.ZERO;

    public KBOrderRefundRequest() {

    }


}
