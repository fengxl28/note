package com.mwee.android.cashier.connect.bean.http;


import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 获取开店小助手配置
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18955635</herf>
 *
 * @author changsunhaipeng
 */
@HttpParam(httpType = HttpType.POST,
        method = "setting/getShopConfigInfo",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetOpenShopHelperConfigResponse.class)
public class GetOpenShopHelperConfigRequest extends BaseCashierPosRequest {
}
