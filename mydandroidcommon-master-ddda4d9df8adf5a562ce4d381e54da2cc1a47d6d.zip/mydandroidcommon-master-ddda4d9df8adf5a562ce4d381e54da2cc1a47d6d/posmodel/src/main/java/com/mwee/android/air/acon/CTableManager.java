package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.table.GetAirTableChangeResponse;
import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public interface CTableManager extends CBase {

    /**
     * 获取所有餐区桌台及其他管理信息
     *
     * @return String
     */
    @SocketParam(uri = "airTableManager/optAllAreaAndTable", response = GetAllAreaAndTableResponse.class)
    String optAllAreaAndTable();

    /**
     * 新增区域
     *
     * @return String
     */
    @SocketParam(uri = "airTableManager/addArea", response = GetAllAreaAndTableResponse.class)
    String addArea(@SF("areaName") String areaName, @SF("batchAddTable") boolean batchAddTable, @SF("tableCount") int tableCount, @SF("person") int person);

    /**
     * 修改区域名称
     *
     * @param areaId   区域ID
     * @param areaName 区域名称
     * @return String
     */
    @SocketParam(uri = "airTableManager/updateAreaName", response = GetAllAreaAndTableResponse.class)
    String updateAreaName(@SF("areaId") String areaId, @SF("areaName") String areaName);

    /**
     * 删除区域
     *
     * @param areaId 区域ID
     * @return String
     */
    @SocketParam(uri = "airTableManager/deleteArea", response = GetAllAreaAndTableResponse.class)
    String deleteArea(@SF("areaId") String areaId);

    /**
     * 新增桌台
     *
     * @param areaId    区域ID
     * @param tableName 桌台名称
     * @param seats     桌位数
     * @return String
     */
    @SocketParam(uri = "airTableManager/addTable", response = GetAllAreaAndTableResponse.class)
    String addTable(@SF("areaId") String areaId, @SF("tableName") String tableName, @SF("seats") int seats);

    /**
     * 修改桌台
     *
     * @param areaId     区域ID
     * @param fsmtableId 桌台ID
     * @param tableName  桌台名称
     * @param seats      桌位数
     * @return String
     */
    @SocketParam(uri = "airTableManager/updateTable", response = GetAllAreaAndTableResponse.class)
    String updateTable(@SF("areaId") String areaId, @SF("fsmtableId") String fsmtableId, @SF("tableName") String tableName, @SF("seats") int seats);

    /**
     * 批量删除桌台
     *
     * @param tableIdList
     * @return String
     */
    @SocketParam(uri = "airTableManager/batchDeleteTable", response = GetAllAreaAndTableResponse.class)
    String batchDeleteTable(@SF("tableIdList") ArrayList<String> tableIdList);


    /**
     * 获取小散换桌的数据
     *
     * @return
     */
    @SocketParam(uri = "airTableManager/loadTableChangeInfo", response = GetAirTableChangeResponse.class)
    String loadTableChangeInfo();
}
