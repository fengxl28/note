package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/12/7.
 */

public class GroupTicket extends BusinessBean {
    public String code;

    /**
     * 团购标题
     */
    public String title;
    /**
     * 可验券数量
     */
    public int verify_count;
    /**
     * 券号
     */
    public String sn;

    /**
     * 价格
     */
    public BigDecimal price;


    /**
     * 团购id
     */
    public String deal_id;

    /**
     * 团购标题
     */
    public String deal_title;

    /**
     * 是否支持极速验券0：否 ， 1：是
     */
    public int has_groupon;

    /**
     * 团购券详细信息
     */
    public GroupTicketDetail meituan_detail = new GroupTicketDetail();

    /**
     * 实付金额
     */
    public BigDecimal pay_amount = BigDecimal.ZERO;

    public GroupTicket() {
    }
}
