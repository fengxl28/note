package com.mwee.android.pos.business.shop;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/12/27 3:40 PM
 * email: qin.wei@mwee.cn
 */

public class KoubeiName extends BusinessBean {
    public String shopName = "";

    public KoubeiName() {
    }
}
