package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.TradeDetail;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetTradeDetailResponse extends BaseCashierPosResponse {
    public TradeDetail data;

    public GetTradeDetailResponse() {
    }
}
