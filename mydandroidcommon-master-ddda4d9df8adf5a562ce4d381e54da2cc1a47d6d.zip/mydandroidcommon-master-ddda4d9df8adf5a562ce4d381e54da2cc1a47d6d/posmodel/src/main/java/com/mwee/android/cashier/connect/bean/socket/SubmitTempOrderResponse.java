package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * 提交临时单
 * Created by virgil on 2018/1/30.
 */

public class SubmitTempOrderResponse extends BaseSocketResponse {
}
