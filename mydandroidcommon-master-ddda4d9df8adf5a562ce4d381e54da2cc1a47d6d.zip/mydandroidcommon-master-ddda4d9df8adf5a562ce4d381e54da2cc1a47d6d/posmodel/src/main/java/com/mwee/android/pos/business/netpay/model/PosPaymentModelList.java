package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/7/28.
 */

public class PosPaymentModelList extends BusinessBean {
    public String msg;
    public String code;
    public String signType;

    public PosPaymentModelList() {
    }

    public ArrayList<PosPaymentModel> content;
}
