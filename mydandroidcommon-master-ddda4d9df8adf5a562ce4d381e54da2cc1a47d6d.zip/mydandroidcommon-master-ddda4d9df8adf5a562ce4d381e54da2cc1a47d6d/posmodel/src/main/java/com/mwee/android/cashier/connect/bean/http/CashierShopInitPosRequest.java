package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 美收银门店初始化的数据
 * Created by virgil on 2018/2/2.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "posapi/business/companyapi/checkmsyshopAndInitParam",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GenOrderIDPosResponse.class)
public class CashierShopInitPosRequest extends BaseCashierPosRequest {
    /**
     * 门店ID
     */
    public String sid;
    /**
     * 总店iD
     */
    public String ManageShopID;
    /**
     * 服务类型
     */
    public String services;
    /**
     * 门店名称
     */
    public String sname;
    /**
     * 门店类型：	msy:美收银门店，mxy:美小易门店（默认）
     */
    public String shopType;
    public String address;
    public String province;
    public String city;
    public String area;
    public String phone;
    public String logo;
    public String userName;
    public String password;

    public String mobile;

    public CashierShopInitPosRequest() {

    }

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierUrlRoot();
    }

    @Override
    public String encrypt(String data) {
        return data;
    }

    @Override
    public String decrypt(String data, int httpStatus) {
        return data;
    }
}
