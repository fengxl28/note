package com.mwee.android.air.util;

import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class DBPrimaryKeyUtil {

    /**
     * 获取主键
     *
     * 菜品主键虽然定义为String类型，但是后台要对此排序需要转成long类型，因此不允许含有非数字类型数据
     *
     * @return yyyyMMddHHmmssSSS
     */
    public static String optPrimaryKey() {
        return DateUtil.getCurrentDate("yyyyMMddHHmmssSSS");
    }
}
