package com.mwee.android.air.connect.business.ask;

import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 */

public class GetAllAskGPAndAskResponse extends BaseSocketResponse {

    public List<AirAskGroupManagerInfo> airAskGroupManagerInfos = new ArrayList<>();
    public List<AirAskManageInfo> airAskManageInfos = new ArrayList<>();

    public GetAllAskGPAndAskResponse() {

    }

}
