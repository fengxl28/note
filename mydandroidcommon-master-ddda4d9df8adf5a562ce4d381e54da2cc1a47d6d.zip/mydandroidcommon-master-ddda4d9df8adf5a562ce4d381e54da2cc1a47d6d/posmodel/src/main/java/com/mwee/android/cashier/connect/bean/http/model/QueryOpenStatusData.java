package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by changsunhaipeng on 2018/7/5.
 */

public class QueryOpenStatusData extends BusinessBean {
    public PayStatusInfo wxpay;
    public PayStatusInfo alipay;
    /**
     * DOING：开通中，DONE：开通成功，FAIL：开通失败，INIT：未申请开通
     */
    public String business;
    /**
     * 口碑版美小易1 普通美小易 0
     */
    public int fiWorkMode;


    public class PayStatusInfo extends BusinessBean{
        public String msg;
        public String channel;
        public String type;
        public String status;
    }
}
