package com.mwee.android.air.db.business.ask;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class AirAskGroupManagerInfo extends DBModel {


    @ColumnInf(name = "fsAskGpId", primaryKey = true)
    public String fsAskGpId = "";


    @ColumnInf(name = "fsAskGpName")
    public String fsAskGpName = "";

//
//    /**
//     * 关系类型1:全部 , 2:菜品分类，3:菜品',
//     */
//    @ColumnInf(name = "fiRelationtype", primaryKey = false)
//    public int fiRelationtype = 3;

    /**
     * 是否适用于所有菜品分类：0:否 1：是'
     */
    @ColumnInf(name = "fiUseAllMenuCls", primaryKey = false)
    public int fiUseAllMenuCls = 0;

    /**
     * 关联的分组Id列表
     */
    public List<String> fsMenuClsIdList = new ArrayList<>();


    public AirAskGroupManagerInfo() {
    }
}
