package com.mwee.android.pos.business.print;

/**
 * Created by liuxiuxiu on 2017/5/9.
 * 转菜单信息
 * 套餐只打印套餐明细
 * 配料作为备注打印
 */
public class TurnItemBean extends PrintItemDataBean {

}
