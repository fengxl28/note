package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 购买打印机
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18959815</herf>
 *
 * @author changsunhaipeng
 */
@HttpParam(httpType = HttpType.POST,
        method = "printer/getPrintBuyUrl",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = BuyPrinterResponse.class)
public class BuyPrinterRequest extends BaseCashierPosRequest {
    public BuyPrinterRequest() {

    }
}
