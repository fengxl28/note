package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 我的订单--已结账订单
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23005833</herf>
 */
@HttpParam(httpType = HttpType.POST,
        method = "order/checked/list",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetPaiedOrderResponse.class)
public class GetPaiedOrderRequest extends BaseCashierPosRequest {

    /**
     * 开始时间
     */
    public String startDate;
    /**
     * 结束时间
     */
    public String endDate;
    /**
     * 门店id
     */
    public String shopGUID;
    /**
     * 来源  0:堂食  1:外卖
     */
    public int sourceType = 0;
    /**
     * 每页显示的个数
     */
    public int pageSize = 10;
    /**
     * 当前 第几页
     */
    public int pageIndex;

    public GetPaiedOrderRequest() {

    }

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierMposmsyUrl();
    }
}
