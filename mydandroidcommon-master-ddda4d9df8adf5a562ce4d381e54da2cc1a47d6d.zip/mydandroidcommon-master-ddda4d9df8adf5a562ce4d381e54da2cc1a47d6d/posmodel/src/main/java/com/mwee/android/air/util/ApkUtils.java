package com.mwee.android.air.util;

import android.content.Context;
import android.content.pm.PackageManager;

/**
 * apk工具类
 * Created by qinwei on 2018/8/27.
 */

public class ApkUtils {
    /**
     * @param context
     * @param uri
     * @return
     */
    public static boolean isAppInstalled(Context context, String uri) {
        PackageManager pm = context.getPackageManager();
        boolean installed = false;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            installed = false;
        }
        return installed;
    }
}
