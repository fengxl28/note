package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetVerifyCodeResponse extends BaseSocketResponse {
    public GetVerifyCodeResponse(){

    }
}
