package com.mwee.android.pos.business.netpay;

import com.mwee.android.pos.business.netpay.model.PayStatusQueryModel;
import com.mwee.android.pos.business.netpay.model.ScanPaymentModelList;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by liuxiuxiu on 2018/5/30.
 */
public class PayStatusQueryResponse extends BasePosResponse {
    public PayStatusQueryModel data = new PayStatusQueryModel();

    public PayStatusQueryResponse() {
    }
}
