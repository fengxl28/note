package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * @Description: http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11639909
 * @author: Xiaolong
 * @Date: 2018/2/28
 */
@HttpParam(httpType = HttpType.POST,
        method = "openOrder/updateShopMealNoStatus",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = BaseCashierPosResponse.class)
public class UpdateShopMealNoStatusRequest extends BaseCashierPosRequest {
    public String userId;
    public int status;
}
