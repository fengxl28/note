package com.mwee.android.pos.business.rapid.api.bean.model;

import android.support.annotation.StringDef;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * 外卖来源
 * Created by virgil on 2017/11/10.
 */

@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Target({METHOD, PARAMETER, FIELD, LOCAL_VARIABLE})
@StringDef({TakeAwaySource.MEITUAN, TakeAwaySource.ELEME, TakeAwaySource.MWEE, TakeAwaySource.BAIDU, TakeAwaySource.KOUBEI,TakeAwaySource.MWMEITUAN})
public @interface TakeAwaySource {
    String MEITUAN = "MEITUAN";
    String ELEME = "ELEME";
    String MWEE = "MWEE";
    String BAIDU = "BAIDU";
    String KOUBEI = "KOUBEI";
    String MWMEITUAN = "MWMEITUAN";//美团外卖虚拟打印机来源
}
