package com.mwee.android.air.db.business.menu;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/22.
 */

public class MenuPackageSetSideBean extends DBModel {
    @ColumnInf(name = "fiSetFoodCd")
    public String fiSetFoodCd = "0";
    @ColumnInf(name = "fsSetFoodName")
    public String fsSetFoodName = "";
    @ColumnInf(name = "fiSetFoodQty")
    public int fiSetFoodQty;
    public List<MenuPackageSetSideDtlBean> choiceMenuItems = new ArrayList<>();//套餐组内菜品id
    @ColumnInf(name = "fiItemCd_M")
    public String fiItemCd_M = "0";
    @ColumnInf(name = "fiSetFoodType")
    public int fiSetFoodType;
    @ColumnInf(name = "fiIsRequired")
    public int fiIsRequired;
    @ColumnInf(name = "fiSortOrder")
    public int fiSortOrder;
    @ColumnInf(name = "fiStatus")
    public int fiStatus;
    public String fsShopGUID;
    //套餐分组 菜品组成名称
    public String fsSetFoodNameMenuItemDtal;

    /**
     * 标记操作类型 套餐组
     */
    public int editor_mode = MODE_ADD;

    public static final int MODE_ADD = 0;
    public static final int MODE_EDITOR = 1;
    public static final int MODE_DELETE = 2;

    public MenuPackageSetSideBean() {
    }
}
