package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 储值交易记录Response
 * Created by qinwei on 2017/1/11.
 */

public class MemberBalanceChangedResponse extends BaseMemberResponse {
    public BalanceOrderList data = new BalanceOrderList();//储值余额流水包装数据

    public MemberBalanceChangedResponse() {
    }

}
