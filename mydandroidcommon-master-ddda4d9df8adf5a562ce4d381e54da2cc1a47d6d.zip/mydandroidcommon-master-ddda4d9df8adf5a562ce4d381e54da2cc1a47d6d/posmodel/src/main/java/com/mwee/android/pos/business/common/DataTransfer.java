package com.mwee.android.pos.business.common;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.constants.TempAppOrderConstant;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Created by virgil on 2018/1/18.
 * @author virgil
 */

public class DataTransfer {

}
