package com.mwee.android.air.connect.business.active;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * @author:luoshenghua create on:2018/12/11
 * description:
 */
public class CreateShopMessagePushResponse extends BasePosResponse {
    public boolean success = true;
    /**
     * "data": {"id":"753b43ea-6846-4e37-b2c2-57eba1b0ba16"}
     */
    public JSONObject data = new JSONObject();

    public CreateShopMessagePushResponse() {
    }
}