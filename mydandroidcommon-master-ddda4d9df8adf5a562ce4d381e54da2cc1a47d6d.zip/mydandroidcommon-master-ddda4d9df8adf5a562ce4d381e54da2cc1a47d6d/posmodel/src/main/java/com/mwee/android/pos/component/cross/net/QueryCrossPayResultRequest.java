package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/1/2.
 */
@HttpParam(httpType = HttpType.POST,
        method = "crossorderquery",
        response = QueryCrossPayResultResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 1000)
public class QueryCrossPayResultRequest extends BaseCrossRequest {
    /**
     * 请求编号
     */
    public String pay_order;
    /**
     * 业务id
     */
    public String sourceid = "116";

    /**
     * 营业日期
     */
    public String sellDate = "";

    public QueryCrossPayResultRequest() {

    }
}
