package com.mwee.android.pos.business.einvoice.api;


import com.mwee.android.pos.business.einvoice.model.InvoiceRateBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:电子发票税率响应
 */
public class InvoiceRateResponse extends BasePosResponse {
    public InvoiceRateBean data;

    public InvoiceRateResponse(){

    }
}
