package com.mwee.android.air.connect.business.active;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/7/16
 * description:美小易标准版 获取激活门店ID二维码 响应
 */
public class ActiveAirShopQRResponse extends BasePosResponse {
    public ActiveAirShopQRBean data = new ActiveAirShopQRBean();

    public ActiveAirShopQRResponse() {
    }
}
