package com.mwee.android.pos.business.menu;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.business.menu.model.KouBeiSellOutModel;
import com.mwee.android.pos.business.menu.model.RapidSellOutModel;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: RapidSellOutRequest
 * @Description: 沽清上传(只要有一个规格沽清就都全规格都沽清)
 * @author: SugarT
 * @date: 16/11/10 下午8:53
 */
@HttpParam(httpType = HttpType.POST,
        method = "mydMenuEstimatedSync",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 120, saveToLog = true)
public class KouBeiSellOutRequest extends BasePosRequest {

    /**
     * 菜品列表
     */
    public List<KouBeiSellOutModel> menuList = new ArrayList<>();

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessBasicMenu();
    }

    public KouBeiSellOutRequest() {
    }
}