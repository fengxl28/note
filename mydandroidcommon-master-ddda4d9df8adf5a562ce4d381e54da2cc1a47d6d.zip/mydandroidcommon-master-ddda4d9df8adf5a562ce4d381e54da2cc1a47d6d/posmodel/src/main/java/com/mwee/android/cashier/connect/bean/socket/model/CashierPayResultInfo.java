package com.mwee.android.cashier.connect.bean.socket.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * 支付结果的信息集合，
 * Created by virgil on 2018/2/8.
 *
 * @author virgil
 */

public class CashierPayResultInfo extends BusinessBean {
    /**
     * 支付结果
     */
    public String orderID;
    public String note;
    /**
     * 牌号
     */
    public String mealno;
    /**
     * 总金额
     */
    public String amountTotal;
    /**
     * 优惠方式名称
     */
    public String couponName;
    /**
     * 总优惠金额
     */
    public String couponAmount;
    /**
     * 总圆整金额
     */
    public String round;
    /**
     * 总应付金额
     */
    public String amtNeedPay;
    /**
     * 是否纯收银：1，是；0，否
     */
    public int isJustPay;

    /**
     * 支付类型
     */
    public String payType;

    public CashierPayResultInfo() {


    }
}
