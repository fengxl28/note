package com.mwee.android.air.connect.business.advertising;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * created by 2018/8/21
 *
 * @author lxd
 * Description:启动页广告
 */
public class AirWelcomeAdvertisingResponse extends BasePosResponse {
    public AirWelcomeAdvertisingImageModle data = new AirWelcomeAdvertisingImageModle();

    public AirWelcomeAdvertisingResponse() {

    }
}
