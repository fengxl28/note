package com.mwee.android.pos.business.rapid.api.bean.model;

/**
 * Created by virgil on 2017/7/24.
 */

public class SourceType {
    /**
     * 微信快餐
     */
    public final static int RAPID_PRE_PAY_FAST = 17;

    /**
     * 是否是纯收银
     *
     * @return boolean
     */
    public static boolean isPrePayFastfoodModel(int sourceType) {
        return sourceType == SourceType.RAPID_PRE_PAY_FAST;
    }

}
