package com.mwee.android.air.connect.business.menu;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

public class MenuItemAddResponse extends BaseSocketResponse {

    public MenuItem menuItem = new MenuItem();

    public MenuItemAddResponse() {

    }
}
