package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * author:luoshenghua
 * create on:2018/4/28
 * description:电子发票税率请求
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "adapter",
        contentType = "application/json",
        response = InvoiceRateResponse.class, saveToLog = true
)
public class InvoiceRateRequest extends BaseInvoiceRequest {

    public InvoiceRateRequest() {

    }
}
