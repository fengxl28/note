package com.mwee.android.pos.business.shop;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/9/27.
 */

public class KouBeiShopInfo extends BusinessBean {
    /**
     * 美味商户ＩＤ
     */
    public int mwShopId;
    /**
     * 口碑门店ＩＤ
     */
    public String alipayShopId = "";
    /**
     * 口碑商户ID
     */
    public String merchantPid = "";

    public KouBeiShopInfo() {
    }
}
