package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/10/22.
 */

public class BindMemberEntityCardBean extends BusinessBean {
    /**
     * 实体卡绑定结果
     */
    public BindEntityCardBean bindEntityCard;

    /**
     * 设置当前卡结果
     */
    public SetCurrentEntityCardBean setCurrentEntityCard;

    /**
     * 设置属性结果
     */
    public SaveAttrEntityCardBean saveAttrEntityCard;

    /**
     * 手机号查询卡结果
     */
    public QueryEntityCardBean queryEntityCard;

    public BindMemberEntityCardBean() {
    }

    @Override
    public String toString() {
        return "BindMemberEntityCardBean{" +
                "bindEntityCard=" + bindEntityCard +
                ", setCurrentEntityCard=" + setCurrentEntityCard +
                ", saveAttrEntityCard=" + saveAttrEntityCard +
                ", queryEntityCard=" + queryEntityCard +
                '}';
    }
}
