package com.mwee.android.air.connect.business.order;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.pay.model.PayViewBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PaySession;

/**
 * Created by qinwei on 2018/9/1.
 */

public class OrderDetailResponse extends BaseSocketResponse {

    public OrderCache orderCache = new OrderCache();
    public PayViewBean payViewBean = new PayViewBean();

    public OrderDetailResponse() {
    }
}
