package com.mwee.android.air.connect.business.menu;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

@HttpParam(httpType = HttpType.POST,
        method = "uploadAllShopDishType",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class UploadAllShopDishTypeRequest extends BasePosRequest {

    public List<UploadDishTypeBean> uploadAllShopDishTypeList = new ArrayList<>();

    @Override
    public String optBaseUrl() {
        return Constant.getKouBeiSyncDishesUrl();
    }

    public UploadAllShopDishTypeRequest() {
    }
}

