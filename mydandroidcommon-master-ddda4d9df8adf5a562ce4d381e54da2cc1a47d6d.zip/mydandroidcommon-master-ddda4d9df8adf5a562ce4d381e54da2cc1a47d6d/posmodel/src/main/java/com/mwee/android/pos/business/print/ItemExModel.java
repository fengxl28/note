package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by lxx on 16/7/20.
 */
public class ItemExModel extends DBModel {
    @ColumnInf(name = "fsSeq_M")
    public String fsSeq_M;

    @ColumnInf(name = "fsItemName")
    public String fsitemname;

    @ColumnInf(name = "qty")
    public BigDecimal qty = BigDecimal.ZERO;

    @ColumnInf(name = "fdSaleQty")
    public BigDecimal fdSaleQty = BigDecimal.ZERO;
}
