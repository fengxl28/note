package com.mwee.android.air.util;

/**
 * Created by qinwei on 2018/8/23.
 */

public class KBConstants {
    /**
     * 口碑心跳apk包名
     */
    public static final String KB_PACKAGE_NAME = "com.koubei.pos";
    /**
     * 点餐方式-线上点
     */
    public static final String ORDER_STYLE_SCAN = "SCAN";
    /**
     * 点餐方式-扫码点
     */
    public static final String ORDER_STYLE_LATFORM = "PLATFORM";


    /**
     * 取餐类型-正餐
     */
    public static final String BUSINESS_TYPE_DINNER = "DINNER";

    /**
     * 取餐类型-快餐
     */
    public static final String BUSINESS_TYPE_SNACK = "SNACK";


    /**
     * 新订单
     */
    public static final String STATUS_PUSH = "PUSH";
    /**
     * 接单完成
     */
    public static final String STATUS_RECEIPT = "RECEIPT";
    /**
     * 拒单完成
     */
    public static final String STATUS_REJECT = "REJECT";
    /**
     * 备餐完成
     */
    public static final String STATUS_PREPARE = "PREPARE";
    /**
     * 已送餐
     */
    public static final String STATUS_DELIVER = "DELIVER";
    /**
     * 已拒单
     */
    public static final String STATUS_CLOSE = "CLOSE";
    /**
     * 用户取消订单
     */
    public static final String STATUS_CANCEL = "CANCEL";
    /**
     * 商家已退款
     */
    public static final String STATUS_REFUND = "REFUND";
    /**
     * 订单已完成
     */
    public static final String STATUS_FINISH = "FINISH";


    public static final String ISV_PID = "2088311069027504";


    /**
     * 先付款
     */
    public static final String PAY_BEFORE = "0";

    /**
     * 后付款
     */
    public static final String PAY_FUTURE = "1";

    /**
     * 堂食
     */
    public static final String DINNER_TYPE_FOR_HERE = "FOR_HERE";
    /**
     * 外卖
     */
    public static final String DINNER_TYPE_TAKE_OUT = "TAKE_OUT";
    /**
     * 外带
     */
    public static final String DINNER_TYPE_TO_GO = "TO_GO";

    /**
     * 支付类型->先付
     */
    public static final String PAY_STYLE_ADVANCE_PAYMENT = "ADVANCE_PAYMENT";
    /**
     * 支付类型->后付
     */
    public static final String PAY_STYLE_AFTER_PAYMENT = "AFTER_PAYMENT";
    /**
     * 业务产品类型->立即就餐
     */
    public static final String BIZ_TYPE_ORDER_DISHES = "KB_ORDER_DISHES";
    /**
     * 业务产品类型->预约点餐
     */
    public static final String BIZ_TYPE_RESERVATION = "KB_RESERVATION";


    /**
     * 加菜
     */
    public static final String KB_MENU_STATUS_INIT = "INIT";
    /**
     * 接单
     */
    public static final String KB_MENU_STATUS_SUCCESS = "SUCCESS";
    /**
     * 退菜
     */
    public static final String KB_MENU_STATUS_REFUND = "REFUND";
    /**
     * 拒单
     */
    public static final String KB_MENU_STATUS_CLOSE = "CLOSE";

    /**
     * 设备类型-android pos
     */
    public static final String DV_TYPE_DESKTOP_POS = "DESKTOP_POS";


    /**
     * 口碑关单
     */
    public static final String KB_ACTION_CLOSE = "CLOSE";
}
