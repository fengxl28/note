package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * 会员优惠券实体类
 * Created by qinwei on 2017/3/1.
 */

public class Coupon extends BusinessBean {
    public String code;//优惠码
    /**
     * 券种类的ID，对应see{@link com.mwee.android.pos.db.business.pay.PayOriginModel#note}
     * 也对应see{@link com.mwee.android.pos.db.business.PaymentDBModel#fsNote}
     */
    public String coupon_id;//优惠券id
    public String title;//标题
    public String sub_title;//子标题
    public String c_type;//类型
    public String union_type;//平台类型
    public String user_id;//用户id
    public String mobile;//手机号
    public String fetch_shopid;//获取店铺
    public int shop_id;//使用分店id
    public String expiry_type;//过期类型
    public String begin_time;//开始时间
    public String end_time;//过期时间
    public String status;//状态 0=>未使用 1=>使用 2=>退款中/申请退款 3=>已退款 4=>作废/过期 5=>微信预分配
    public String use_time;//使用时间
    public String money_max;//订单满多少
    public String discount;//折扣
    public String price;//面额
    public String payed_amount;//支付价格
    public String shop_logo;//商店logo
    public String shop_name;//店铺名
    public String format_code;//格式化卡号
    public String begin_date;//开始时间
    public String end_date;//结束时间
    public String expiry;//时间
    public String expiry_all;//时间区间
    public String tips;//描述
    public String type_name;//类型名

    public Coupon() {
    }

    @Override
    public Coupon clone() {
        Coupon cloneObj = null;
        try {
            cloneObj = (Coupon) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}
