package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/10/25.
 */

public class KBAfterPayBean extends BusinessBean {

    /**
     * 商户实收的金额
     */
    public BigDecimal seller_amount = BigDecimal.ZERO;

    /**
     * 口碑平台补贴的金额
     */
    public BigDecimal platform_discount_amount = BigDecimal.ZERO;

    /**
     * 商家优惠金额
     */
    public BigDecimal mdiscount_amount = BigDecimal.ZERO;

    /**
     * 在线支付流水号
     * 如果线下使用微信或者支付宝支付，则传入微信或者支付宝的交易号
     */
    public String online_payment_no = "";

    /**
     * 用户实付的金额
     */
    public BigDecimal buyer_amount = BigDecimal.ZERO;

    /**
     * POS订单号
     */
    public String out_biz_no = "";

    /**
     *
     */
    public String miaoDianEnable = "";
    /**
     *
     */
    public String koubeiYudianEnable = "";
    /**
     *
     */
    public String mwShopId = "";
    /**
     * 付款时间
     */
    public String pay_time = "";
    /**
     * 门店ID
     */
    public String shop_id = "";
    /**
     * 商户ID
     */
    public String partner_id = "";
    /**
     * 本次支付的订单优惠金额
     */
    public BigDecimal order_discount_amount = BigDecimal.ZERO;

    /**
     * 撤销的超时绝对时间
     * 可冲正的超时绝对时间；
     * 超过这个时间，订单不能做撤销处理；超过这个时间，如果要做资金反向，则走退款接口（退资金不退优惠）
     */
    public String cancel_timeout = "";
    /**
     * 支付单ID
     */
    public String payment_id = "";
    /**
     * 本次应付金额
     * 本次应付的订单金额，一般为本次需支付的菜品金额减去菜品的订单优惠金额(商家订单满减、单品优惠如特价菜)
     */
    public BigDecimal payable_amount = BigDecimal.ZERO;

    /**
     * 口碑订单号
     */
    public String order_id = "";

    /**
     * 支付方式
     */
    public String payment_method = "ALIPAY";

    /**
     * 支付优惠详情
     */
    //public List<KBAfterPayDiscountInfoBean> discount_infos = new ArrayList<>();
    /**
     * 订单摘要信息
     */
    //public List<KBAfterPayOrderDigestBean> order_digest = new ArrayList<>();

    /**
     * 扩展信息
     */
    public String ext_infos;

    /**
     * 支付明细集合
     */
    public List<RapidPayModel> rapidPayModels = new ArrayList<>();

    public KBAfterPayBean() {
    }
}
