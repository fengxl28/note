package com.mwee.android.pos.business.shareshop.been;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 退款通知回执确认
 * <p>
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=12282913
 */
@HttpParam(httpType = HttpType.POST,
        method = "changeTable",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 40)
public class ChangeTableRequest extends BasePosRequest {

    /**
     * 换桌前的（原）账单号
     */
    public String sourceOuterOrderId = "";
    /**
     * 换桌前的(原)桌号
     */
    public String sourceTableNo = "";
    /**
     * 换桌后的（新）账单号
     */
    public String targetOuterOrderId = "";
    /**
     * 换桌后的(新)桌号
     */
    public String targetTableNo = "";

    public ChangeTableRequest() {
    }

    @Override
    public String optBaseUrl() {
        return Constant.getShareShopUrlPrefix();
    }

}
