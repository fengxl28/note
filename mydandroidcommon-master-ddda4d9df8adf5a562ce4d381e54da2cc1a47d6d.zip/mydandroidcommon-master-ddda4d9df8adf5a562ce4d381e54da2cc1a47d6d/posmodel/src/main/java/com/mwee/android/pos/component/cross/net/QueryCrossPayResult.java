package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/4.
 */

public class QueryCrossPayResult extends BusinessBean {
    public String pay_id;
    public String pay_sn;
    public String pay_price;
    public String pay_order;
    /**
     * 0支付中1成功2失败
     */
    public String pay_status;
    /**
     * 当pay_status=2时返回支付失败原因
     */
    public String pay_status_msg;
    public String datetime;
    public BigDecimal debtAmt = BigDecimal.ZERO;
    public String recordNo;

    /**
     * 信用额度
     */
    public BigDecimal creditAmt = BigDecimal.ZERO;
    /**
     * 未销账额度
     */
    public BigDecimal balanceAmt = BigDecimal.ZERO;
    /**
     * 可销金额
     */
    public BigDecimal canCrossAmt = BigDecimal.ZERO;

    public QueryCrossPayResult() {
    }
}
