package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 可支持打印机列表
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18959817</herf>
 *
 * @author changsunhaipeng
 */
@HttpParam(httpType = HttpType.POST,
        method = "printer/getSystemPrintList",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetSupportPrinterListResponse.class)
public class GetSupportPrinterListRequest extends BaseCashierPosRequest {

    public int printType;        //1:云打印机，2:蓝牙
    public int suitableProd = 2;     //2:美收银，1:美小易

    public GetSupportPrinterListRequest() {

    }
}
