package com.mwee.android.pos.component.accountbook.net.model;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.component.datasync.net.model.BillStateModel;

import java.util.ArrayList;
import java.util.List;

public class BillUploadStateModel extends BusinessBean {

    /**
     * 账套id
     */
    public String accountBookId;

    /**
     * 0 全部上传完成 1有部分未上传成功 2 未上传
     */
    public int state;

}
