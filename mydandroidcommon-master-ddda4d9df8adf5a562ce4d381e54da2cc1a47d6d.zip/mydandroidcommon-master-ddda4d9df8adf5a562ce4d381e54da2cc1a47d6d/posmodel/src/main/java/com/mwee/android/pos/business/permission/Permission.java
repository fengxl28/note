package com.mwee.android.pos.business.permission;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;


/**
 * Created by Liming on 16/9/6.
 */
public class Permission {
    //快餐
    public static final String PRD_FAST_FOOD = "fmFastPos";
    //正餐
    public static final String PRD_DINNER = "fmMealPos";
    //报表
    public static final String PRD_PRINT = "fmSmallReport";
    //系统设置
    public static final String PRD_HOST = "HostSet";

    //快餐权限
    public static final String FAST_bnDelivery = "bnDelivery";//外送单
    public static final String FAST_bnHoldBill = "bnHoldBill";//挂单/取单
    public static final String FAST_bnBillManage = "bnBillManage";//账单管理
    public static final String FAST_bnRePrnBill = "bnRePrnBill";//重印结账单
    public static final String FAST_bnOrderProcessing = "bnOrderProcessing";//订单中心
    public static final String FAST_bnOverShift = "bnOverShift";//交班
    public static final String FAST_bnCloseStore = "bnCloseStore";//打烊
    public static final String FAST_bnSmallReport = "bnSmallReport";//小票报表
    public static final String FAST_bnSetQty = "bnSetQty";//沽清
    public static final String FAST_bnOpenBox = "bnOpenBox";//开钱箱
    public static final String FAST_bnPrintTask = "bnPrintTask";//打印任务监控
    public static final String FAST_bnHostSet = "bnHostSet";//站点设置
    public static final String FAST_vVIPPriceAuth = "vVIPPriceAuth";//会员价授权
    public static final String FAST_vBackAuth = "vBackAuth";//退菜授权
    public static final String FAST_vGiftAuth = "vGiftAuth";//赠送授权
    public static final String FAST_vReCheckAuth = "vReCheckAuth";//反结账授权
    public static final String FAST_vTempVIPAuth = "vTempVIPAuth";//会员充值

    //正餐权限
    public final static String DINNER_bnOpenTable = "bnOpenTable";
    public final static String DINNER_bnModiBillHead = "bnModiBillHead";//  改单头
    public final static String DINNER_bnModiSales = "bnModiSales";//  改单头-销售人员
    public final static String DINNER_bnBrowBill = "bnBrowBill";//  查单
    public final static String DINNER_bnSellCheck = "bnSellCheck";//  结账
    public final static String DINNER_bnChangeTable = "bnChangeTable";//  换桌
    public final static String DINNER_bnShareTable = "bnShareTable";//  拼(搭)台
    public final static String DINNER_bnMergeTable = "bnMergeTable";//  合并到
    public final static String DINNER_bnClearTable = "bnClearTable";//  清台
    public final static String DINNER_bnDisTable = "bnDisTable";//  停用/启用餐桌
    public final static String DINNER_bnHurryItem = "bnHurryItem";//  催菜
    public final static String DINNER_bnWaitItem = "bnWaitItem";//  等叫
    public final static String DINNER_bnUpItem = "bnUpItem";//  起菜
    public final static String DINNER_bnPrnExpBill = "bnPrnExpBill";//  打印预结单
    public final static String DINNER_bnSplitBill = "bnSplitBill";//  拆分账单
    public final static String DINNER_bnBillManage = "bnBillManage";//  账单管理
    public final static String DINNER_bnRePrnBill = "bnRePrnBill";//  重印结账单
    public final static String DINNER_vReCheckAuth = "vReCheckAuth";//  反结账授权'
    public final static String DINNER_bnOrderProcessing = "bnOrderProcessing";//  订单中心
    public final static String DINNER_bnOverShift = "bnOverShift";//  交班
    public final static String DINNER_bnCloseStore = "bnCloseStore";//  打烊
    public final static String DINNER_vPriceAuth = "vPriceAuth";//  改价授权
    public final static String DINNER_vQtyAuth = "vQtyAuth";//  改数授权
    public final static String DINNER_vVIPPriceAuth = "vVIPPriceAuth";//  会员价授权
    public final static String DINNER_vTempVIPAuth = "vTempVIPAuth";//  会员充值 -- 手动会员 改成 会员充值
    public final static String DINNER_vVIPBind = "vVIPBind";//  会员账单绑定
    public final static String DINNER_vBackAuth = "vBackAuth";//  退菜授权'
    public final static String DINNER_vGiftAuth = "vGiftAuth";//  赠送授权'
    public final static String DINNER_vTurnAuth = "vTurnAuth";//  转菜授权'
    public final static String DINNER_bnSetQty = "bnSetQty";//  沽清
    public final static String DINNER_bnOpenBox = "bnOpenBox";//  开钱箱
    public final static String DINNER_bnPrintTask = "bnPrintTask";//  打印任务监控
    public final static String DINNER_bnHostSet = "bnHostSet";//  站点设置
    public final static String DINNER_vFreeSve = "vServiceAmtAuth";//  免服务费授权

    public final static String DINNER_vPaymentRefundAuth = "vPaymentRefundAuth";//  退款权限
    public final static String DINNER_vMaintain = "vMaintain";//站点维护权限
    public final static String DINNER_vDiscount = "vDiscount";//折扣权限

    /**
     * 免单权限
     */
    public final static String DINNER_vFREE = "freeSheet";
    /**
     * 挂账权限
     */
    public final static String DINNER_vBill = "bnBill";
    /**
     * 开台点菜
     */
    public final static String DINNER_bnSellOrder = "bnSellOrder";

    /**
     * 销账权限
     */
    public final static String DINNER_bnRemoving = "bnRemoving";
    /**
     * 关账权限
     */
    public final static String DINNER_bnClosing = "bnClosing";
    /**
     * 提成人选择权限
     */
    public final static String DINNER_vBonus = "ExtractPeople";

    /**
     * 修改餐标权限
     */
    public final static String DINNER_mealStandard = "mealStandard";

    /**
     * 电子发票管理权限
     */
    public final static String DINNER_bnEinvoice = "bnEinvoice";

    /**
     * 修改当班厨师权限
     */
    public final static String KDS_CHEF_DUTY="ChefDuty";

    //小票单独权限点
    public final static String PRINT_cbSaleDate = "cbSaleDate";//  选营业日期
    public final static String PRINT_bnPrint = "bnPrint";//  小票打印
    public final static String PRINT_R01 = "R01";//  R01营业收入表
    public final static String PRINT_R02 = "R02";//  R02销售数量表
    public final static String PRINT_R03 = "R03";//  R03销售数量表
    public final static String PRINT_R04 = "R04";//  R04档口统计表
    public final static String PRINT_R05 = "R05";//  R05档口明细表
    public final static String PRINT_R06 = "R06";//  R06最高销售额表
    public final static String PRINT_R07 = "R07";//  R07最高销售数量表
    public final static String PRINT_R08 = "R08";//  R08每小时销售表
    public final static String PRINT_R09 = "R09";//  R09套餐统计表
    public final static String PRINT_R10 = "R10";//  R10退菜明细表
    public final static String PRINT_R11 = "R11";//  R11赠菜明细表
    public final static String PRINT_R15 = "R15";//  R15账单类别统计表
    public final static String PRINT_R16 = "R16";//  R16折扣报表
    public final static String PRINT_R17 = "R17";//  R17营业收入日结报表
    public final static String PRINT_R18 = "R18";//  R18销售分类报表
    public final static String PRINT_R19 = "R19";//  R19收入分类报表
    public final static String PRINT_R20 = "R20";//  R20溢收明细报表
    public final static String PRINT_R21 = "R21";//  R21会员储值报表
    public final static String PRINT_R22 = "R22";//  R22外卖报表
    public final static String PRINT_R23 = "R23";//  R23微信快餐报表
    public final static String PRINT_R24= "R24";//  R24微信外卖报表
    public final static String PRINT_R25 = "R25";//  R25营业收入表*
    public final static String PRINT_R26 = "R26";//  R26美团外卖报表

    public final static String PRINT_CHECKOUTSTATIS = "CheckoutStatis";// 结账统计报表(收款明细表)
    public final static String PRINT_DISCOUNTSUMMARY = "DiscountSummary";// 折扣汇总表
    public final static String PRINT_RECEIVDETAIL = "ReceivDetail";// 收款明细表
    public static final String REPORT_MODULE = "reportModule"; //报表模块权限


    /**
     * 查看今日目标权限
     */
    public final static  String SALES_TARGET = "viewSalesProgress";

    /**
     * 选营业日期
     */
    public final static String REPORT_CHECK_SALE_DATE = "cbSaleDate";

    public static boolean hasPermissionFastFood(String userId, String permission) {
        String sql = "select fsProgDtlId from  tbAuthorityDtl where fsProgDtlId='" + permission + "' and fsRoleId=(select fsRoleId from tbUserRole where fsUserId='" + userId + "' and fistatus = '1' )  and fsProgId='" + PRD_FAST_FOOD + "' and fiusable='1'";
        String per =DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        return !TextUtils.isEmpty(per);
    }

    /**
     * 正餐校验当前用户是否拥有特定的权限
     *
     * @param userId
     * @param permission 权限
     * @return
     */
    public static boolean hasPermissionDinner(String userId, String permission) {
        String sql = "select DISTINCT fsProgDtlId from  tbAuthorityDtl where fsProgDtlId='" + permission + "' and fsRoleId in (select fsRoleId from tbUserRole where fsUserId='" + userId + "' and fiStatus='1')  and fsProgId='" + PRD_DINNER + "' and fiusable='1'";
        String per =DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        return !TextUtils.isEmpty(per);
    }

    public static boolean hasPermissionPrint(String userId, String permission) {
        String sql = "select DISTINCT fsProgDtlId from  tbAuthorityDtl where fsProgDtlId='" + permission + "' and fsRoleId in (select fsRoleId from tbUserRole where fsUserId='" + userId + "' and fistatus = '1')  and fsProgId='" + PRD_PRINT + "' and fiusable='1'";
        String per =DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        return !TextUtils.isEmpty(per);
    }

    /**
     * HostSet校验当前用户是否拥有特定的权限()
     *
     * @param userId
     * @param permission 权限
     * @return
     */
    public static boolean hasPermissionDinnerHost(String userId, String permission) {
        String sql = "select DISTINCT fsProgDtlId from  tbAuthorityDtl where fsProgDtlId='" + permission + "' and fsRoleId in (select fsRoleId from tbUserRole where fsUserId='" + userId + "' and fiStatus='1')  and fsProgId='" + PRD_HOST + "' and fiusable='1'";
        String per =DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        return !TextUtils.isEmpty(per);
    }

    /**
     * 收银员是否有某个折扣的权限
     *
     * @param userId     收银员ID
     * @param discountID 折扣ID
     * @return
     */
    public static boolean hasDiscountPermission(String userId, String discountID) {
        String sql = "select fsDiscountId from tbuserdiscount where fsDiscountId = '" + discountID + "' and fsuserId = '" + userId + "' and fistatus = '1'";
        String per = DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        return !TextUtils.isEmpty(per);
    }

    public static boolean hasDiscountPermission(String userId, String discountID, int rate) {
        if (rate >= 0) {
            String sql = "select fsDiscountId from tbuserdiscount where fsDiscountId = '" + discountID + "' and fsuserId = '" + userId + "' and fistatus = '1' AND fsuserId IN (SELECT fsUserId FROM tbuser WHERE fiUserDiscount >= '" + rate + "')";
            String per = DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
            return !TextUtils.isEmpty(per);
        } else {
            return hasDiscountPermission(userId, discountID);
        }
    }
}
