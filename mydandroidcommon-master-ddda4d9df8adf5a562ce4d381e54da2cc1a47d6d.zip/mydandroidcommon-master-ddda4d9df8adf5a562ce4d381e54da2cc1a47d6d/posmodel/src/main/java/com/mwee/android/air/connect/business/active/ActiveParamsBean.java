package com.mwee.android.air.connect.business.active;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/7/16
 * description:美小易标准版 获取门店激活参数 bean
 */
public class ActiveParamsBean extends BusinessBean {
    /**
     * 美味商户id
     */
    public String shopId = "";
    /**
     * 二维码是否被扫描过
     */
    public int isUsed = 0;

    public ActiveParamsBean() {
    }
}
