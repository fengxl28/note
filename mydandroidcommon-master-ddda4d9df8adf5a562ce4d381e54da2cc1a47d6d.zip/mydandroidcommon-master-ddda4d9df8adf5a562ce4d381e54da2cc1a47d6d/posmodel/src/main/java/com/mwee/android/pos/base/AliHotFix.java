package com.mwee.android.pos.base;

import android.app.ActivityManager;
import android.content.Context;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * 阿里补丁相关的方法
 * Created by virgil on 2017/8/17.
 */

public class AliHotFix {
    /**
     * 存在需要重启的补丁
     */
    public static boolean needRelaunch = false;

    /**
     * HotFix检测更新
     */
    public static void checkAliHotFix() {
//        SophixManager.getInstance().queryAndLoadNewPatch();
    }

    public static void killProcss() {
//        SophixManager.getInstance().killProcessSafely();
        ActivityManager am = (ActivityManager) GlobalCache.getContext().getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) {
            return;
        }
        List<ActivityManager.RunningAppProcessInfo> proList = am.getRunningAppProcesses();
        final String packageName = GlobalCache.getContext().getPackageName();
        for (int i = proList.size() - 1; i >= 0; i--) {
            ActivityManager.RunningAppProcessInfo temp = proList.get(i);
            if (temp.processName.startsWith(packageName)) {
                LogUtil.log("杀进程：" + temp.processName);
                android.os.Process.killProcess(temp.pid);
            }
        }
    }

    public  static void killSelf(){
        LogUtil.log("杀进程：" + android.os.Process.myPid());
        android.os.Process.killProcess(android.os.Process.myPid());
    }
    public static void initLoopAliHotFix() {

//        final int MSG_KEY = 0x791237;
//        //轮询间隔时间，阿里的免费阈值是每天20次
//        //所以这里设置为5小时一次
//        final int DELAY = 1000 * 60 * 60 * 5;
//        Handler handler = new Handler(Looper.getMainLooper()) {
//            @Override
//            public void handleMessage(Message msg) {
//                super.handleMessage(msg);
//                switch (msg.what) {
//                    case 0x791237:
//                        //定时检测补丁
//                        AliHotFix.checkAliHotFix();
//                        this.sendEmptyMessageDelayed(MSG_KEY, DELAY);
//                        break;
//                }
//            }
//        };
//        handler.sendEmptyMessageDelayed(MSG_KEY, 1000 * 60 * 10);
    }
}
