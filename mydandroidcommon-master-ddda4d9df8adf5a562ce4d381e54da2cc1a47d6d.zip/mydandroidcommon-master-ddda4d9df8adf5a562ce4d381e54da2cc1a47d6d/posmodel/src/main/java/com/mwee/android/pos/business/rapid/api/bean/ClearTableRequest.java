package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * 清台之后，需要回调服务端已清台
 * Created by virgil on 2017/3/3.
 */
@HttpParam(httpType = HttpType.POST,
        method = "cleartable",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 30)
public class ClearTableRequest extends BasePosRequest {

    /**
     * 桌台ID
     */
    public String tableNo = "";
    /**
     * 门店ID
     */
    public String shopId = "";

    public ClearTableRequest() {

    }
}