package com.mwee.android.pos.business.keppalive;

import com.mwee.android.pos.business.keppalive.model.KeepAliveInfo;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by liuxiuxiu on 2018/5/11.
 */
public class KeepAliveResponse extends BasePosResponse {
    public KeepAliveInfo data = new KeepAliveInfo();

    public KeepAliveResponse() {

    }
}
