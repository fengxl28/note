package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:更新电子发票开关状态
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "updateShopConfig",
        contentType = "application/json",
        response = InvoiceSwitchStatusUpdateResponse.class, saveToLog = true
)

public class InvoiceSwitchStatusUpdateRequest extends BasePosRequest {
    /**
     * 商户门店id
     */
    public String shopId;
    /**
     * 必填，发票状态，0无发票，1普通发票，2电子发票
     */
    public int fapiaoEnable = 2;


    @Override
    public String optBaseUrl() {
        return Constant.getInvoiceSwitchStatusUrl();
    }

    public InvoiceSwitchStatusUpdateRequest() {
    }
}
