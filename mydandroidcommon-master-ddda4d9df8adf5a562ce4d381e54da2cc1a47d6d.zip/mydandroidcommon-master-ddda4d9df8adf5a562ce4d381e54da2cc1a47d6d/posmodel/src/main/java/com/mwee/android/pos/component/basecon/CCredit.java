package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.component.cross.net.CreditAccountResponse;
import com.mwee.android.pos.component.cross.net.QueryCrossPayResultResponse;
import com.mwee.android.pos.connect.business.pay.CreditAccountListSocketResponse;
import com.mwee.android.pos.connect.business.pay.CreditAccountSocketResponse;
import com.mwee.android.pos.connect.business.pay.CrossPaySocketResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.QueryCrossPayResultSocketResponse;
import com.mwee.android.pos.connect.business.pay.ReverseCrossSocketResponse;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.db.business.PaymentDBModel;

import java.math.BigDecimal;

/**
 * 销账相关
 * Created by qinwei on 2018/1/8.
 */

public interface CCredit {
    /**
     * 销账接口
     *
     * @param account
     * @param crossPrice
     * @param code
     * @param bean
     * @return
     */
    @SocketParam(uri = "ordersync/loadCrossPay", response = CrossPaySocketResponse.class)
    String loadCrossPay(@SF("requestId") String requestId,
                        @SF("account") CreditAccount account,
                        @SF("crossPrice") BigDecimal crossPrice,
                        @SF("code") String code,
                        @SF("bean") PaymentDBModel bean,
                        @SF("sellNo") String sellNo,
                        @SF("sellDate") String sellDate);

    /**
     * 查询销账支付结果
     *
     * @param requestId 查询id
     * @param printInfo 小票打印信息
     * @return
     */
    @SocketParam(uri = "ordersync/queryCrossPayResult", response = QueryCrossPayResultSocketResponse.class, timeOut = 30)
    String loadCrossPayResult(@SF("requestId") String requestId,
                              @SF("printInfo") CrossPayPrintInfo printInfo);


    /**
     * 反销账接口
     *
     * @param recordId
     * @param fsCreditAccountId
     * @return
     */
    @SocketParam(uri = "ordersync/loadReverseCross", response = ReverseCrossSocketResponse.class)
    String loadReverseCross(@SF("recordId") int recordId,
                            @SF("fsCreditAccountId") String fsCreditAccountId, @SF("sellDate") String sellDate);

    /**
     * 查询并更新单个挂账对象
     *
     * @param accountId
     * @param sellDate
     * @return
     */
    @SocketParam(uri = "ordersync/loadAccount", response = CreditAccountSocketResponse.class)
    String loadAccount(@SF("accountId") String accountId,
                       @SF("sellDate") String sellDate);

    /**
     * 在线获取挂账信息列表
     *
     * @param currentPage 当前页数
     * @param size        一页显示条数
     * @return
     */
    @SocketParam(uri = "ordersync/loadCrossAccountList", response = CreditAccountListSocketResponse.class)
    String loadCrossAccountList(@SF("accountName") String accountName, @SF("currentPage") int currentPage,
                                @SF("size") int size);

    /**
     * 根据挂账名称首字母搜索挂账账户信息列表
     *
     * @param accountName 首字母拼音
     * @return
     */
    @SocketParam(uri = "ordersync/loadSearchCreditAccount", response = CreditAccountListSocketResponse.class)
    String loadSearchCreditAccount(@SF("accountName") String accountName,
                                   @SF("currentPage") int currentPage,
                                   @SF("size") int size);

    /**
     * 挂账
     *
     * @param orderid
     * @param accountID
     * @param payAmount
     * @return
     */
    @SocketParam(uri = "billDriver/payHung", response = PayResultResponse.class, timeOut = 80)
    String payHung(@SF("orderid") String orderid, @SF("accountID") String accountID, @SF("payAmount") BigDecimal payAmount);


}
