package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:获取电子发票开关状态请求
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "getShopConfigList",
        contentType = "application/json",
        response = InvoiceSwitchStatusGetResponse.class, saveToLog = true
)

public class InvoiceSwitchStatusGetRequest extends BasePosRequest {
    /**
     * 商户门店id列表
     */
    public String shopIds;

    @Override
    public String optBaseUrl() {
        return Constant.getInvoiceSwitchStatusUrl();
    }


    public InvoiceSwitchStatusGetRequest() {
    }
}

