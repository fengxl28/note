package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;

/**
 * created by 2018/11/13
 *
 * @author lxd
 * Description:口碑部分退款返回参数信息实体类
 */
public class KBPartRefundExtInfo extends BusinessBean {
    /**
     * 商家实际退款金额
     */
    public String refund_real_amount = "";

    /**
     * 入参请求的外部退款单号
     */
    public String out_refund_no = "";

    /**
     * 入参请求的退款金额
     */
    public String refund_amount = "";

    /**
     * 买家实际退金额
     */
    public String buyer_real_amount = "";

    /**
     * 返回信息提示
     */
    public String errmsg = "";

    /**
     * 返回状态：0:成功，9:需要重试，非0和9:失败
     */
    public int errno;

    public KBPartRefundExtInfo() {
    }


    /**
     * 商家实际退款金额
     */
    public BigDecimal getRefund_real_amount() {
        BigDecimal refund_real_amounts = new BigDecimal(refund_real_amount);
        return refund_real_amounts;
    }


    /**
     * 买家实际退金额
     */
    public BigDecimal getBuyer_real_amount() {
        BigDecimal buyer_real_amounts = new BigDecimal(buyer_real_amount);
        return buyer_real_amounts;
    }


    /**
     * 入参请求的退款金额
     */
    public BigDecimal getRefund_amount() {
        LogUtil.log("lxd", "--------入参请求的退款金额=" + refund_amount);
        BigDecimal refund_amounts = new BigDecimal(refund_amount);
        return refund_amounts;
    }

}
