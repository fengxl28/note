package com.mwee.android.air.db.business.payment;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * @ClassName: PaymentManageInfo
 * @Description: 编辑支付方式 model
 * @author: SugarT
 * @date: 2017/10/16 下午2:53
 */
public class PaymentManageInfo extends DBModel {

    @ColumnInf(name = "fsPaymentId", primaryKey = true)
    public String fsPaymentId = "";

    @ColumnInf(name = "fsPaymentName")
    public String fsPaymentName = "";

    @ColumnInf(name = "fiIsCalcPaid")
    public int fiIsCalcPaid = 0;

    @ColumnInf(name = "fiDataKind")
    public int fiDataKind = 0;

    @ColumnInf(name = "fiIsPremium")
    public int fiIsPremium = 0;
}
