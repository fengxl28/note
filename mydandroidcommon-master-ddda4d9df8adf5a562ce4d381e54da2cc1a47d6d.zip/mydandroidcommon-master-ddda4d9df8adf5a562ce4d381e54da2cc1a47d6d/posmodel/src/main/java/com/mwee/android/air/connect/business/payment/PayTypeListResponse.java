package com.mwee.android.air.connect.business.payment;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.pay.PayOriginModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/9/5.
 */

public class PayTypeListResponse extends BaseSocketResponse {

    public List<PayOriginModel> payOriginModels = new ArrayList<>();

    public PayTypeListResponse() {
    }
}
