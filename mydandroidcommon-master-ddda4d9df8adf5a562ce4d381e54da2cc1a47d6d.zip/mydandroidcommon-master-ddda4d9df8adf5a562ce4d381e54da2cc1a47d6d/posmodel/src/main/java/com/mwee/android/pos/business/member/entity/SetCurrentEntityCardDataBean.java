package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/9/26.
 */

public class SetCurrentEntityCardDataBean extends BusinessBean {

    /**
     * 当前卡号
     */
    public String current_card_no = "";

    /**
     * 设置卡属性的卡号
     */
    public String entity_card_no = "";

    public SetCurrentEntityCardDataBean() {
    }
}
