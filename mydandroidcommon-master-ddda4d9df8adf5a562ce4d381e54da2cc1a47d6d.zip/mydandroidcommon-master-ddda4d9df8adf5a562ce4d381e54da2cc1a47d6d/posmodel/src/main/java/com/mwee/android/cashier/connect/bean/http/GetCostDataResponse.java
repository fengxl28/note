package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.CostData;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetCostDataResponse extends BaseCashierPosResponse {
    public CostData data;

    public GetCostDataResponse() {

    }
}
