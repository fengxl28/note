package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.CouponList;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 会员优惠券数据Response
 * Created by qinwei on 2017/1/11.
 */

public class MemberCouponResponse extends BaseMemberResponse {
    public CouponList data = new CouponList();//优惠券列表包装实体内容

    public MemberCouponResponse() {
    }
}
