package com.mwee.android.air.connect.business.menu;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.print.PrinterItem;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/12/22.
 */

public class MenuClsPrintersResponse extends BaseSocketResponse {
    public ArrayList<String> choicePrinters = new ArrayList<>();
    public ArrayList<PrinterItem> allPrinters = new ArrayList<>();

    public MenuClsPrintersResponse() {
    }
}
