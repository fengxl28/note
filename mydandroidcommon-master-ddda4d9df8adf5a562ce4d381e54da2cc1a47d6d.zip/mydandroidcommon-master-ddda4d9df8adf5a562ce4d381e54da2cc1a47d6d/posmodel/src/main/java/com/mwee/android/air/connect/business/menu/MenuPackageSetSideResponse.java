package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/23.
 */

public class MenuPackageSetSideResponse extends BaseSocketResponse {
    public List<MenuPackageSetSideBean> menuPackageSetSideBeanList = new ArrayList<>();

    public MenuPackageSetSideResponse() {
    }
}
