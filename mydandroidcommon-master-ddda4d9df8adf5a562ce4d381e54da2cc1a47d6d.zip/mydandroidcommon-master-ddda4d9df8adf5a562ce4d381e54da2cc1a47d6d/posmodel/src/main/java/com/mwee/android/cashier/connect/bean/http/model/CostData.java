package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * @author changsunhaipeng
 * @date 2018/7/5
 */

public class CostData extends BusinessBean {
    public int canteenIncomeCount;//食堂单数
    public BigDecimal canteenSettlementAmt = BigDecimal.ZERO;//食堂收入
    public int havIncomeCount;//外卖单数
    public BigDecimal havSettlementAmt = BigDecimal.ZERO;//外卖收入
    public int incomeCount;///实收单数
    public BigDecimal settlementAmt = BigDecimal.ZERO;//本月实收
    public BigDecimal sumCostAmount = BigDecimal.ZERO;//本月支出
}
