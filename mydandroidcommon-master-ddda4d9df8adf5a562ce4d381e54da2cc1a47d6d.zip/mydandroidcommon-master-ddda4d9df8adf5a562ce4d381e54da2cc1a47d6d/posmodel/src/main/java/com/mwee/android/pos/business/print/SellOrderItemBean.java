package com.mwee.android.pos.business.print;

import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/10/21.
 */
public class SellOrderItemBean extends SellOrderItemDBModel {
    public int lastTscIndex = 0;
    /**
     * 等叫的中文标示
     */
    @ColumnInf(name = "SfiItemMakeState")
    public String SfiItemMakeState="";

    public String parentItemName = ""; //套餐头名称
    /**
     * 所有配料： 鱼丸*3;虾球*2；
     */
    public String ingredientNotes = "";
    public List<SellOrderItemBean> SLIT = null;
    public String ingredientFatherItemCd="-1";
    public SellOrderItemBean(){

    }

}
