package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/9/26.
 * <p>
 * "data":{
 * "card_no": "6262973700000005",
 * "card_parent":{
 * "gender": 2,
 * "birthday": "",
 * "real_name": "李四"
 * }
 */

public class BindEntityCardDataBean extends BusinessBean {


    /**
     * 卡号
     */
    public String card_no = "";

    /**
     * 卡属性
     */
    public BindEntityCardParentDataBean card_parent;

    public BindEntityCardDataBean() {
    }
}
