package com.mwee.android.pos.business.setting.preorder;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.connect.business.setting.preorder.PreOrderSettingResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * author:luoshenghua
 * create on:2018/5/18
 * description:获取预点单设置相关信
 */
@HttpParam(httpType = HttpType.POST,
        method = "koubeiPreOrder/querySettingUpInfo",
        response = PreOrderSettingResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class QueryPreOrderSettingRequest extends BaseKouBeiRequest {

    public QueryPreOrderSettingRequest() {
    }
}
