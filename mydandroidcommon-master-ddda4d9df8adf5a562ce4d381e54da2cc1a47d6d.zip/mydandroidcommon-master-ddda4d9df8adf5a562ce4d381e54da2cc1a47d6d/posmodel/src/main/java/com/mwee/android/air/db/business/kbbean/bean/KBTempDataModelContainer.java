package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/25.
 */

public class KBTempDataModelContainer extends BusinessBean {
    public List<KBTempDataModel> koubeiOrder = new ArrayList<>();

    public int pageCount;

    public int count;

    /**
     * 是否有用户申请退款的订单
     */
    public boolean ifPayStatus;
}
