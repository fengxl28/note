package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * 储值流水接口数据包装类
 * Created by qinwei on 2017/3/1.
 */

public class BalanceOrderList extends BusinessBean {
    public int havenext = 0;//是否存在下一页 0：无下一页 1：有下一页
    public ArrayList<BalanceOrder> list = new ArrayList<>();//储值流水变动数据

    public BalanceOrderList() {
    }
}
