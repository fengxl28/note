package com.mwee.android.pos.business.netpay;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by lxx on 18/5/29.
 * 查询账单支付状态
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18940985
 */
@HttpParam(httpType = HttpType.POST,
        method = "pay/query",
        response = PayStatusQueryResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 90, saveToLog = true)
public class PayStatusQueryRequest extends BasePosRequest {

    /**
     * 门店ID
     */
    public String shopguid = "";

    /**
     * 单号
     */
    public String orderno = "";

    /**
     * 订单类型 1表示网络订单 2表示扫码支付单号
     */
    public int type = 0;

    public PayStatusQueryRequest() {
    }

}
