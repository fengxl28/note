package com.mwee.android.pos.business.print;

import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * Created by Zun on 16/7/8.
 *
 * @author virgil
 */
public class CustomSellDBModel extends SellDBModel {
    /**
     * 班别
     */
    @ColumnInf(name = "shiftname")
    public String shiftname = "";
    /**
     * 收银员
     */
    @ColumnInf(name = "cashiername")
    public String cashiername = "";
    /**
     * 结账单打印次数
     */
    @ColumnInf(name = "fiPrintTimes")
    public int fiPrintTimes = 0;
    /**
     * 餐段
     */
    public String fsMSectionName = "";
    /**
     * 预约时间
     */
    public String reservationTime = "";

    public CustomSellDBModel() {

    }
}
