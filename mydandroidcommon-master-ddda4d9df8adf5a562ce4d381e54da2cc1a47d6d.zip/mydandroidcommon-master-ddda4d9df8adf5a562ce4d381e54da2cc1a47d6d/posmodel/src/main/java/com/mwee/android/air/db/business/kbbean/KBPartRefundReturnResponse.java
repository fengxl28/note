package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KBPartRefundReturnModle;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * created by 2018/11/13
 *
 * @author lxd
 * Description:口碑部分退款返回Response
 */
public class KBPartRefundReturnResponse extends BasePosResponse {

    public KBPartRefundReturnModle data = new KBPartRefundReturnModle();

    public KBPartRefundReturnResponse() {
    }
}
