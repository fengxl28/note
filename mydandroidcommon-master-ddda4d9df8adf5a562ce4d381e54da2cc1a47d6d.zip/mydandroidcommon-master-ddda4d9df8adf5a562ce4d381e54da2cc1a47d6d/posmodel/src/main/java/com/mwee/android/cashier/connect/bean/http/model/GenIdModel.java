package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by virgil on 2018/2/8.
 */

public class GenIdModel extends BusinessBean {
    public String payNum;
    public String orderNum;
}
