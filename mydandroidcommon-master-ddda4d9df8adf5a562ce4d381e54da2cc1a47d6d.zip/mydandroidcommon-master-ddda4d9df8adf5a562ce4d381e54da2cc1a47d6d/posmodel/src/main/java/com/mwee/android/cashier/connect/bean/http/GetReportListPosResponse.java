package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.CashierReportModel;

import java.util.List;

/**
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class GetReportListPosResponse extends BaseCashierPosResponse {
    public List<CashierReportModel> data;
    public GetReportListPosResponse(){

    }
}
