package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * 准备第三方支付
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class PrepareThirdPayResponse extends BaseSocketResponse {
    public String thirdOrderID;
    /**
     * 新的OrderToken
     */
    public String orderTokenNew;
    /**
     * 返回OrderID
     */
    public String orderIDNeedUpdate;
    public PrepareThirdPayResponse() {

    }
}
