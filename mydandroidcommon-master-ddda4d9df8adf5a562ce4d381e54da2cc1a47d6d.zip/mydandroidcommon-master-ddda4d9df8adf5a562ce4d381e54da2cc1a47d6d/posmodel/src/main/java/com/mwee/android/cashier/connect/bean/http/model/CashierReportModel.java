package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * 美收银报表的Model
 * Created by virgil on 2018/2/5.\
 *
 * @author virgil
 */

public class CashierReportModel extends BusinessBean {
    /**
     * 营业日期
     */
    public String sellDate;
    /**
     * 总金额
     */
    public String total;

    /**
     * 堂食收款总金额
     */
    public String tsTotal;

    /**
     * 外卖收款总金额
     */
    public String wmTotal;

    /**
     * 1 ~ 7 分别代表星期一到星期天
     */
    public int dayOfWeekCN;

    public CashierReportModel() {

    }
}
