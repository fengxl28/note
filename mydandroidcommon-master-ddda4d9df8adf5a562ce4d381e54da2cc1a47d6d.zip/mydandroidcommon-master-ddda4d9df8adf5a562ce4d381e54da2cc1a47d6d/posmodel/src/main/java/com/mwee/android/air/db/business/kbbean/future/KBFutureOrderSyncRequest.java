package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.air.db.business.kbbean.bean.ThirdOrderExt;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.SellcheckDBModel;
import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 更新口碑预点单  后付款退款
 */
@HttpParam(httpType = HttpType.POST,
        method = "posUploadToKb",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class KBFutureOrderSyncRequest extends BasePosRequest {
    public List<SellDBModel> tbsell = new ArrayList<>();
    public List<SellcheckDBModel> tbsellcheck = new ArrayList<>();
    public List<SellOrderItemDBModel> tbsellorderitem = new ArrayList<>();
    public List<SellreceiveDBModel> tbsellreceive = new ArrayList<>();
    public List<SellOrderDBModel> tbsellorder = new ArrayList<>();
    public ThirdOrderExt thirdorderext = new ThirdOrderExt();

    public KBFutureOrderSyncRequest() {

    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessBasicUrl();
    }
}
