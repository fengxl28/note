package com.mwee.android.air.db.business.discount;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * Created by liuxiuxiu on 2017/10/18.
 */

public class DiscountManagerInfo extends DBModel {

    @ColumnInf(name = "fiDiscountRate")
    public int fiDiscountRate = 0;

    @ColumnInf(name = "fsDiscountId", primaryKey = true)
    public String fsDiscountId = "";

    @ColumnInf(name = "fsDiscountName")
    public String fsDiscountName = "";

    @ColumnInf(name = "fiStatus")
    public int fiStatus = 0;


    /**
     * '0=部分菜品打折,1=整单立减,2=整单打折)',
     */
    @ColumnInf(name = "ficouponid")
    public int ficouponid = 0;
//
//    /**
//     * 关联的分组Id列表
//     * key : fsmenuclsId;
//     * key : famenuclsName
//     */
//    public LinkedHashMap<String, String> menuclsMap = new LinkedHashMap<>();
//
    /**
     * 关联的分组Id列表
     */
    public ArrayList<String> menuclsList = new ArrayList<>();
    /**
     * 折扣关联的菜品分类名称集合：a,b,c,
     * 整单折扣：全部
     * 没有关联：无
     */
    public String discountClsNameTag = "";


    public DiscountManagerInfo(String name, int fiDiscountRate, int fiStatus) {
        this.fsDiscountName = name;
        this.fiDiscountRate = fiDiscountRate;
        this.fiStatus = fiStatus;
    }

    public DiscountManagerInfo() {
    }
}
