package com.mwee.android.pos.business.member.api;

import com.mwee.android.pos.business.member.api.model.TicketSearchModel;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 验券查询的Response
 * Created by virgil on 2017/3/17.
 */

public class TicketSearchResponse extends BaseMemberResponse {
    public TicketSearchModel data = new TicketSearchModel();//优惠券列表包装实体内容

    public TicketSearchResponse() {
    }
}