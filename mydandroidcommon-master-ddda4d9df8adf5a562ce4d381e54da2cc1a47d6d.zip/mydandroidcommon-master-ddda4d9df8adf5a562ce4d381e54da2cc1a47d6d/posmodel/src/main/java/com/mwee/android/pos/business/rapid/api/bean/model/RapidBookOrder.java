package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/7/12.
 * 秒点预定单
 */

public class RapidBookOrder extends BusinessBean {
    /**
     * 秒点秒付的action
     */
    public String action = null;
    public RapidBookOrderInfo orderInfo;  //订单头
    public List<RapidBookDishInfo> dishInfo = new ArrayList<>();  //订单菜品明细

    public RapidBookOrder() {
    }
}
