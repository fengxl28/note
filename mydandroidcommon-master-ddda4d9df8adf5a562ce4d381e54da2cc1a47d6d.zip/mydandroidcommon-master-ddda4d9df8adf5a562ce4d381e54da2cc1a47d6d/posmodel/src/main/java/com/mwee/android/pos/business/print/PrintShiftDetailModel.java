package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * @ClassName: PrintShiftDetailModel
 * @Description:
 * @author: SugarT
 * @date: 2017/12/21 上午11:07
 */
public class PrintShiftDetailModel extends DBModel {

    /**
     * 人数
     */
    @ColumnInf(name = "fiCustSum")
    public int fiCustSum = 0;
    /**
     * 单数
     */
    @ColumnInf(name = "qty")
    public int qty = 0;
    /**
     * 销售金额
     */
    @ColumnInf(name = "fdSaleAmt")
    public BigDecimal fdSaleAmt = BigDecimal.ZERO;
    /**
     * 营业金额
     */
    @ColumnInf(name = "fdExpAmt")
    public BigDecimal fdExpAmt = BigDecimal.ZERO;
    /**
     * 折扣金额
     */
    @ColumnInf(name = "fdDiscountAmt")
    public BigDecimal fdDiscountAmt = BigDecimal.ZERO;
    /**
     * 实收金额
     */
    @ColumnInf(name = "fdRealAmt")
    public BigDecimal fdRealAmt = BigDecimal.ZERO;
    /**
     * 人均
     */
    @ColumnInf(name = "RJ")
    public BigDecimal RJ = BigDecimal.ZERO;
    /**
     * 单均
     */
    @ColumnInf(name = "DJ")
    public BigDecimal DJ = BigDecimal.ZERO;

    public PrintShiftDetailModel() {
    }
}
