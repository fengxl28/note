package com.mwee.android.air.connect.business.shop;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.HostexternalDBModel;

/**
 * Created by zhangmin on 2017/10/25.
 */


public class GetHostExteralModelResponse extends BaseSocketResponse {

    public HostexternalDBModel model = new HostexternalDBModel();

    public GetHostExteralModelResponse(){

    }
}
