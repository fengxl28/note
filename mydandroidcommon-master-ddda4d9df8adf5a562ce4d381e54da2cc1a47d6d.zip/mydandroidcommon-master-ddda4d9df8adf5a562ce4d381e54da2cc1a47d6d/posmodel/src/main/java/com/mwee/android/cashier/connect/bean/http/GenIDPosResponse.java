package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.GenIdModel;

/**
 * Created by virgil on 2018/2/8.
 *
 * @author virgil
 */

public class GenIDPosResponse extends BaseCashierPosResponse {
    /**
     * 数据
     */
    public GenIdModel data;

    public GenIDPosResponse() {

    }
}
