package com.mwee.android.pos.business.constants;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 附加费类型
 */
@Retention(RetentionPolicy.SOURCE)
public @interface SurchargeType {

    /**
     * 附加费
     */
    String NORMAL = "0";

    /**
     * 圆整
     */
    String ROUND = "1";

    /**
     * 餐标
     */
    String DINNING_STANDARD = "2";

    /**
     * 最低消费
     */
    String MIN_STANDARD = "3";

    /**
     * 服务费
     */
    String SERVICE_FEE = "4";

    /**
     * 餐盒
     */
    String BOX = "5";

    /**
     * 配送费
     */
    String DELIVERY = "6";
}
