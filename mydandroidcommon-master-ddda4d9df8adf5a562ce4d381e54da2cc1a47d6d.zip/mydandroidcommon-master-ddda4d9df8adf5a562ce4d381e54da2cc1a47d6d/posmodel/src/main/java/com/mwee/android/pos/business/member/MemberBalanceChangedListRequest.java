package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * 储值交易记录Request
 * Created by qinwei on 2017/1/11.
 */
@HttpParam(httpType = HttpType.POST,
        method = "transferstationtoc",
        response = MemberBalanceChangedResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class MemberBalanceChangedListRequest extends BaseMemberRequest {
    public String card_no;//会员卡号009861636336
    public String last_id = "0";//最后的id  0代表第一页 之后的值是每次数组的最后一个id值
    public int limit = 20;//每页记录数

    public MemberBalanceChangedListRequest() {
        super("third.recharge.tradelog");
    }

}
