package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 获取当天营业额
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11642980</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "orderPayment/getStaticMoney",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetReportSingleDayResponse.class)
public class GetReportTodayPosRequest extends BaseCashierPosRequest {
    public GetReportTodayPosRequest() {

    }

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierMposmsyUrl();
    }

}
