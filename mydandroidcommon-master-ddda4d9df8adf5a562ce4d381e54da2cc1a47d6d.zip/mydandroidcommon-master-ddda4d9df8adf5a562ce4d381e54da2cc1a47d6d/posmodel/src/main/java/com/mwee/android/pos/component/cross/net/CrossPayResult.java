package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/4.
 */

public class CrossPayResult extends BusinessBean {
    /**
     * 挂账余额
     */
    public BigDecimal debtAmt = BigDecimal.ZERO;
    /**
     * 待核销金额
     */
    public BigDecimal balanceAmt = BigDecimal.ZERO;
    /**
     * 信用额度
     */
    public BigDecimal creditAmt = BigDecimal.ZERO;

    /**
     * 可销额度
     */
    public BigDecimal canCrossAmt = BigDecimal.ZERO;

    public String recordNo;
    /**
     * errno{0:支付中 1：成功 2：失败}
     */
    public String errno;
    public String errmsg;

    public CrossPayResult() {
    }
}
