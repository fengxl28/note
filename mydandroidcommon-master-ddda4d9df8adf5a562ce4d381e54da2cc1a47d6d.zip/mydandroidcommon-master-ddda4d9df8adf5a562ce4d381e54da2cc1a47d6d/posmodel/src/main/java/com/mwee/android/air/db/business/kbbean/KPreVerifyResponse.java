package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KPreVerify;
import com.mwee.android.base.net.BaseResponse;

/**
 * Created by qinwei on 2018/6/26.
 */

public class KPreVerifyResponse extends BaseResponse {
    public KPreVerify data;

    public KPreVerifyResponse() {
    }
}
