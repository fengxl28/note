package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * 美收银的准备支付
 * Created by virgil on 2018/2/3.
 */

public class PrepareCashierPayResponse extends BaseSocketResponse {
    public String orderToken = "";
}
