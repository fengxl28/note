package com.mwee.android.air.db.business.kbbean.bean;

import android.text.TextUtils;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by qinwei on 2018/10/15.
 */

public class KBDishMenuItem extends BusinessBean {
    /**
     * 单品
     */
    public static final String SINGLE = "SINGLE";
    /**
     * 套餐
     */
    public static final String COMBO = "COMBO";


    /**
     * 菜品在口碑侧基于商品表达的商品ID（非临时菜必填）
     */
    public String dish_id = "";
    /**
     * 商品下细分的sku ID（非临时菜必填）
     */
    public String sku_id = "";
    /**
     * 菜品名称
     */
    public String dish_name = "";
    /**
     * 外部菜品ID；对应ISV侧的菜品ID；可用于ISV匹配本次菜品；（录入菜品时填写了就有）
     * 菜品CD
     */
    public String out_dish_id = "";
    /**
     * 外部菜品SKU ID（录入菜品时填写了就有）
     * 规格ID
     */
    public String out_sku_id = "";
    /**
     * "菜品的其他信息，包括但不限于：sku、规格，做法等信息;
     * 为Map结构的json格式，key的枚举定义：
     * (1)PRACTICE:"红烧"   做法名称
     * (2PRACTICE_PRICE:"10.0" 做法加价
     * (2)SALES_PROPERTY: {"甜度":["五分甜","三分甜"],"冰量":["少冰"]} 一般销售属性
     * (3)SPECIFICATION:"大"  规格"
     */
    public OutDishInfo out_dish_infos = new OutDishInfo();
    /**
     * 单价
     */
    public BigDecimal price = BigDecimal.ZERO;
    /**
     * 单位
     */
    public String unit = "";
    /**
     * 数量
     */
    public BigDecimal num = BigDecimal.ZERO;
    /**
     * "总价；等于：price * num
     * 特殊说明：
     * 在组合套餐加价的场景下，加价口碑通过“套餐调价金额”来进行表达，即时：套餐基础价格+套餐调价金额；在对外集成规范中，将屏蔽这个差异，还原组合套餐的金额。"
     */
    public BigDecimal amount = BigDecimal.ZERO;
    /**
     * 如果当前菜品为组合套餐，则包含用户选择的规格信息
     */
    public ArrayList<SelectedMealInfo> selected_meal_info = new ArrayList<>();
    /**
     * "扩展信息；重点关注如下信息如：
     * MUST_ORDER_DISH:T  开台必点菜,T:是 F：否"
     */
    public String ext_infos = "";
    /**
     * 菜谱类型
     * (1)SINGLE 单品  {@link #SINGLE}
     * (2)COMBO 套餐 {@link #COMBO}
     */
    public String dish_type = "";


    /**
     * 子明细
     */
    public static class SelectedMealInfo extends BusinessBean {
        /**
         * 套餐内子明细
         */
        public static final String COMBO = "COMBO";
        /**
         * 加料明细
         */
        public static final String SIDE = "SIDE";
        /**
         * 菜品在口碑侧基于商品表达的商品ID（非临时菜必填）
         */
        public String dish_id = "";
        /**
         * 商品下细分的sku ID（非临时菜必填）
         */
        public String sku_id = "";
        /**
         * 菜品名称
         */
        public String dish_name = "";
        /**
         * 外部菜品ID
         */
        public String out_dish_id = "";
        /**
         * 外部菜品SKU ID
         */
        public String out_sku_id = "";
        /**
         * 外部菜品信息
         */
        public OutDishInfo out_dish_infos = new OutDishInfo();
        /**
         * 单位
         */
        public String unit = "";
        /**
         * 数量
         */
        public BigDecimal num = BigDecimal.ZERO;
        /**
         * 加料价格
         */
        public BigDecimal side_price = BigDecimal.ZERO;
        /**
         * 套餐加价
         */
        public BigDecimal add_price = BigDecimal.ZERO;
        /**
         * 扩展信息；重点关注如下信息：
         * (1) 组合套餐的套餐明细的选择详情以及份数；
         */
        public String ext_infos = "";
        /**
         * (1)COMBO 套餐内子明细
         * (2)SIDE  加料明细
         */
        public String type = "";

        /**
         * 获取子明细总数量
         *
         * @param mainNum
         * @return
         */
        public BigDecimal getTotalNum(BigDecimal mainNum) {
            return mainNum.multiply(num);
        }

        /**
         * 获取单份菜品子明细数量
         *
         * @return
         */
        public BigDecimal getSingleNum() {
            return num;
        }

        /**
         * 获取配料总价
         *
         * @param mainNum
         * @return
         */
        public BigDecimal getTotalPrice(BigDecimal mainNum) {
            return getTotalNum(mainNum).multiply(side_price);
        }

        /**
         * 获取单个加料价格
         *
         * @return
         */
        public BigDecimal getSinglePrice() {
            return side_price;
        }
    }

    /**
     * 获取单个菜品总价
     *
     * @return
     */
    public BigDecimal getTotalPrice() {
        //计算菜品显示价格 price=price-(selected_meal_info所有加料总价)
        BigDecimal showTotalPrice = amount;
        if (!ListUtil.isEmpty(selected_meal_info)) {
            for (SelectedMealInfo mealInfo : selected_meal_info) {
                if (TextUtils.equals(mealInfo.type, SelectedMealInfo.SIDE)) {
                    showTotalPrice = showTotalPrice.subtract(mealInfo.getTotalPrice(num));
                }
            }
        }
        return showTotalPrice;
    }

    /**
     * 获取单个菜品
     *
     * @return
     */
    public BigDecimal getSinglePrice() {
        //计算菜品显示价格 price=price-(selected_meal_info所有加料总价)
        BigDecimal showSinglePrice = price;
        if (!ListUtil.isEmpty(selected_meal_info)) {
            for (SelectedMealInfo mealInfo : selected_meal_info) {
                if (TextUtils.equals(mealInfo.type, SelectedMealInfo.SIDE)) {
                    showSinglePrice = showSinglePrice.subtract(mealInfo.getSinglePrice().multiply(mealInfo.getSingleNum()));
                }
            }
        }
        return showSinglePrice;
    }
}