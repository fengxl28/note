package com.mwee.android.pos.business.keppalive.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/5/11.
 * 保活接口 -- 云端返回
 */

public class KeepAliveInfo extends BusinessBean {
    /**
     * 间隔时间秒
     */
    public int interval = 30;

    public KeepAliveInfo() {
    }
}
