package com.mwee.android.pos.component.alp;

/**
 * Created by virgil on 2016/12/13.
 * @author virgil
 */

public class ServerAction {
    /**
     * 转发
     */
    public static final String TRANSFER = "1";
    /**
     * 执行
     */
    public static final String EXCUTE = "2";
    /**
     * 进一步解析
     */
    public static final String PARSE = "3";

    /**
     * 转发给指定的目标
     */
    public static final String TRANSFER_TO = "4";

    public static final String SYMBOL_SPLIT="#@%";
}
