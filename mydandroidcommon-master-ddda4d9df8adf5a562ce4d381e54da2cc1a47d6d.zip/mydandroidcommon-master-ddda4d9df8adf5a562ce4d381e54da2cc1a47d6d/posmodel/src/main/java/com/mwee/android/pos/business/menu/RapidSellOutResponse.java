package com.mwee.android.pos.business.menu;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * @ClassName: RapidSellOutResponse
 * @Description:
 * @author: SugarT
 * @date: 16/11/10 下午8:55
 */
public class RapidSellOutResponse extends BasePosResponse {

    public RapidSellOutResponse() {
    }
}
