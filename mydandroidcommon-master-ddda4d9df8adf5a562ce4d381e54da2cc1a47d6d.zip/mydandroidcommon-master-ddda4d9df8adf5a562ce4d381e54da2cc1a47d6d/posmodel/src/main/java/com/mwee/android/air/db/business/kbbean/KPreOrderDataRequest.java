package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 根据订单号请求口碑预点单数据
 */
@HttpParam(httpType = HttpType.POST,
        method = "kborder/getKBOrderInfo",
        response = KPreOrderDataResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KPreOrderDataRequest extends BaseKouBeiRequest {

    /**
     * 口碑端自己的订单号
     */
    public String order_id = "";
    /**
     * 口碑商户id
     */
    public String merchantPid = "";


    public KPreOrderDataRequest() {

    }
}
