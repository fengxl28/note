package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.cashier.connect.bean.http.model.CashierReportModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.List;

/**
 * 美收银报表的Response
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class CashierReportResponse extends BaseSocketResponse {
    public CashierReportModel today;
    public CashierReportModel yesterday;
    public List<CashierReportModel> lastSeven;

    public CashierReportResponse() {

    }
}
