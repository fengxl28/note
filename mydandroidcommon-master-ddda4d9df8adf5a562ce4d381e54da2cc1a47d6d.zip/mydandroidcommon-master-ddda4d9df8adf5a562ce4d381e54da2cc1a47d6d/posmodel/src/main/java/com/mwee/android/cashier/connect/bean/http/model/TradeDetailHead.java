package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.List;

/**
 * 流水详情的订单头
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class TradeDetailHead extends BusinessBean {

    /**
     * 应收金额
     */
    public BigDecimal receiveAmt;
    /**
     * 实收金额
     */
    public BigDecimal calcPaidAmt;
    /**
     * "找零"
     */
    public BigDecimal chargeAmt = BigDecimal.ZERO;

    /**
     * 包含多种优惠方式
     */
    public List<PaymentTypeName> paymentTypeNameList;

    public TradeDetailHead() {

    }

    public class PaymentTypeName extends BusinessBean {

        /**
         * 金额
         */
        public BigDecimal amount;
        /**
         * 名称
         */
        public String paymentTypeName;
    }
}
