package com.mwee.android.cashier.connect.bean.http;

/**
 * @Description: http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11639947
 * @author: Xiaolong
 * @Date: 2018/2/28
 */
public class GetShopMealNoStatusResponse extends BaseCashierPosResponse {
    public int data;
}
