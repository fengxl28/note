package com.mwee.android.pos.business.netpay;


import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.LogUtil;

/**
 *网络支付、退款 请求结果
 *
 * 支付结果
 * 同步响应errno=0,并且errmsg里面的pay_status=1才为成功。
 pay_status ：1 支付成功
 pay_status ： 0  支付中
 pay_status ：2 支付失败
 */

public class NetResponse extends BasePosResponse {
    public String data = "";

    public NetResponse() {
    }

    @Override
    public NetResponse clone() {
        NetResponse cloneObj = null;
        try {
            cloneObj = (NetResponse) super.clone();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return cloneObj;
    }
}
