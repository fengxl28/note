package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;


/**
 * Created by zhangmin on 2018/5/21.
 */

public class KBFutureTempDataResponse extends BasePosResponse {

    public KBFutureTempDataContainer data = new KBFutureTempDataContainer();


    public KBFutureTempDataResponse() {

    }

}
