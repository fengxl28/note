package com.mwee.android.pos.business.shareshop.been.model;

/**
 * Created by liuxiuxiu on 2018/3/29.
 */

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * 共享餐厅退菜退款Model
 */
public class ShareShopRefundPushModel extends BusinessBean {

    /**
     * 店铺名称
     */
    public String shopName = "";

    /**
     * 店铺Id
     */
    public String shopId = "";
    /**
     * 时间戳----用作去重的唯一标识
     */
    public String timestamp = "";
    /**
     * 订单号
     */
    public String orderId = "";
    /**
     * 订单类型
     */
    public int bizType = 0;
    /**
     * 外部账单号
     */
    public String outerOrderId = "";
    /**
     * 订单状态(-10部分退款,-4退款预创建,-3退款中,-2已退款,-1已删除,0新订单,1已确认,2已下厨,3已完成)
     */
    public int orderStatus = 0;
    /**
     * 会员卡号
     */
    public String memberNo = "";

    /**
     * 退菜明细
     */
    public List<ShareShopRefundPaymentModel> refundPaymentList = new ArrayList<>();

    /**
     * 退菜明细
     */
    public List<ShareShopRefundDishesModel> refundDishes = new ArrayList<>();

    /**
     * 操作人员
     */
    public String operator = "";
    /**
     * 退款原因
     */
    public String reason = "";


    public ShareShopRefundPushModel() {
    }
}
