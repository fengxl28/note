package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.GetPaiedOrderData;

public class GetPaiedOrderResponse extends BaseCashierPosResponse {
    public GetPaiedOrderData data;

    public GetPaiedOrderResponse() {

    }
}
