package com.mwee.android.pos.business.netpay;

import com.mwee.android.pos.business.netpay.model.PosPaymentModelList;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2017/7/21.
 */

public class PosPaymentOrderResponse extends BasePosResponse {
    public PosPaymentModelList data;//全能pos支付信息

    public PosPaymentOrderResponse() {
    }
}
