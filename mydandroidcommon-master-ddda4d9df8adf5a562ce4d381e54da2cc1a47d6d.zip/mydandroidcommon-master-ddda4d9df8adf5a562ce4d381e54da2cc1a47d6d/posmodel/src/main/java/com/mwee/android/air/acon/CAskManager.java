package com.mwee.android.air.acon;

import com.mwee.android.air.connect.business.ask.AskListResponse;
import com.mwee.android.air.connect.business.ask.GetAllAskGPAndAskResponse;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.connect.business.bean.NoteListResponse;
import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public interface CAskManager extends CBase {

    /**
     * 获取所有要求组及要求
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/optAllAsk", response = GetAllAskGPAndAskResponse.class)
    String optAllAsk();

    @SocketParam(uri = "airAskManagerDriver/loadAskListByGroupId", response = AskListResponse.class)
    String loadAskListByGroupId(@SF("fsAskGpId") String fsAskGpId);

    /**
     * 删除要求分类
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/doDeleteAskGp", response = GetAllAskGPAndAskResponse.class)
    String doDeleteAskGp(@SF("askgpId") String askgpId);

    /**
     * 更新要求分类
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/doUpdateAskGp", response = GetAllAskGPAndAskResponse.class)
    String doUpdateAskGp(@SF("askgpId") String askgpId, @SF("askGpName") String askGpName, @SF("all") boolean all, @SF("menuClsIdList") List<String> menuClsIdList);

    /**
     * 新增要求分类
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/doAddAskGp", response = GetAllAskGPAndAskResponse.class)
    String doAddAskGp(@SF("askGpName") String askGpName, @SF("all") boolean all, @SF("menuClsIdList") List<String> menuClsIdList);


    /**
     * 更新要求
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/updateAsk", response = GetAllAskGPAndAskResponse.class)
    String updateAsk(@SF("fsaskId") String fsaskId, @SF("fsaskName") String fsaskName, @SF("price") BigDecimal price, @SF("askGpId") String askGpId);

    /**
     * 新增要求
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/addAsk", response = GetAllAskGPAndAskResponse.class)
    String addAsk(@SF("fsaskName") String fsaskName, @SF("price") BigDecimal price, @SF("askGpId") String askGpId);


    /**
     * 批量删除要求
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/batchDeleteAsk", response = GetAllAskGPAndAskResponse.class)
    String batcheDeleteAsk(@SF("askIdLsit") List<String> askIdLsit);


    /**
     * 要求分类置顶
     *
     * @return String
     */
    @SocketParam(uri = "airAskManagerDriver/loadAskGroupToTop", response = GetAllAskGPAndAskResponse.class)
    String loadAskGroupToTop(@SF("fsAskGpId") String askGpId);

    /**
     * 获取菜品的要求
     *
     * @param fiItemCd 菜品ID
     * @return String
     */
    @SocketParam(uri = "dishes/optNoteList", response = NoteListResponse.class)
    String optNoteList(@SF("fiItemCd") String fiItemCd, @SF("fsMenuClsId") String fsMenuClsId);

    /**
     * 根据选中的菜品列表获取要求
     * @param menuList 选中的菜品list
     */
    @SocketParam(uri = "dishes/optNoteListByMenuList", response = NoteListResponse.class)
    String optNoteListByMenuList(@SF("menuList") List<MenuItem> menuList);

    /**
     * 要求排序
     *
     * @param askList
     */
    @SocketParam(uri = "dishes/loadAskSort", response = SocketResponse.class)
    void loadAskSort(@SF("askList") ArrayList<AirAskManageInfo> askList);
}
