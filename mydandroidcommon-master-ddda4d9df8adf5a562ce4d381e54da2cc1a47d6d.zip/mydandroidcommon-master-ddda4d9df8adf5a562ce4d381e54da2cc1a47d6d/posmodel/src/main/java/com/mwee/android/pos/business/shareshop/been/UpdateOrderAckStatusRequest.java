package com.mwee.android.pos.business.shareshop.been;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.business.shareshop.been.model.UpdateOrderAckStatusParamModel;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 退款通知回执确认
 *
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=12274096
 */
@HttpParam(httpType = HttpType.POST,
        method = "updateOrderAckStatus",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 60)

public class UpdateOrderAckStatusRequest extends BasePosRequest {
    public List<UpdateOrderAckStatusParamModel> items = new ArrayList<>();

    public UpdateOrderAckStatusRequest() {
    }

    @Override
    public String optBaseUrl() {
        return Constant.getShareShopUrlPrefix();
    }
    public UpdateOrderAckStatusRequest(String orderId, int ackStatus) {
        if (items == null) {
            items = new ArrayList<>();
        }
        UpdateOrderAckStatusParamModel paramModel = new UpdateOrderAckStatusParamModel();
        paramModel.ackStatus = ackStatus;
        paramModel.orderId = orderId;
        items.add(paramModel);

    }

}
