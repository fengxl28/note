package com.mwee.android.pos.business.member.api.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * 验券的结果Model
 * Created by virgil on 2017/3/17.
 */

public class TicketConsumeModel extends BusinessBean {
    /**
     * 优惠码
     */
    public String sn = "";
    /**
     * 状态
     */
    public String status = "";
    /**
     * 手机号
     */
    public int mobile = 0;
    /**
     * 描述，示例：团购券：0439719600于2015-05-13购买，手机号为13609090909
     */
    public String description = "";
    /**
     * 团购券id
     */
    public int deal_id = 0;

    public TicketConsumeModel() {

    }
}
