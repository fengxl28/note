package com.mwee.android.pos.component.app;

/**
 * Created by liuxiuxiu on 2017/4/7.
 * 站点的点菜类型
 */
public class OrderModel {
    public static final String RELY_HOST = "relyHost";  //取站点属性
    public static final String DINNER = "dinner";    //纯正餐
    public static final String FASTFOOD = "fastFood"; //纯快餐
    public static final String DOUBLE = "double";    //正餐和快餐
}
