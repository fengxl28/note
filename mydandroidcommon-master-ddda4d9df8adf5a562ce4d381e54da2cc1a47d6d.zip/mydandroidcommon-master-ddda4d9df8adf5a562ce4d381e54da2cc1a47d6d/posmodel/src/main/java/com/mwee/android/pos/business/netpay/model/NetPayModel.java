package com.mwee.android.pos.business.netpay.model;

import com.mwee.android.base.net.BusinessBean;


/**
 * Created by qinwei on 2017/3/24.
 */

public class NetPayModel extends BusinessBean {

    public int pay_status=0;

    /**
     * 商家补贴
     */
    public String platform_merchant_discount="";


    /**
     * 除去优惠后的支付金额
     */
    public String pay_price="";


    /**
     * 支付平台优惠
     */
    public String platform_discount="";


    public String ali_discount_fen="";

    public String pay_shopid="";

    public String ali_discount="";

    public String pay_bank="";

    public String user="";

    public String pay_account="";

    public String pay_paytime="";

    public String pay_rname="";

    public String bank_own="";

    public String ext_discount="";

    public String platform_total_discount="";

    public int pay_class;


    public String pay_openid="";

    public String pay_name="";

    public String trade_no="";

    public String pay_order1="";


    public String ext_receipt="";


    public String meiweiFee="";

    public String pay_id="";

    public String thirdpartyFee="";

    public String pay_sn="";

    public String billingCycle="";

    public String pay_price1="";

    public NetPayModel() {
    }
}
