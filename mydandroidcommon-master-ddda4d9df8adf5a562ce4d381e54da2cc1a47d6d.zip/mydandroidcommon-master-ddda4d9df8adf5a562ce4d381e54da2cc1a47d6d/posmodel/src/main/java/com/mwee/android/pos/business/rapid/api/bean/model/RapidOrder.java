package com.mwee.android.pos.business.rapid.api.bean.model;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.component.member.net.model.MemberComments;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2016/11/3.
 * model数据定义  http://wiki.mwbyd.cn/pages/viewpage.action?pageId=6332767
 * <p>
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4928808
 *
 * @author virgil
 */

public class RapidOrder extends RapidfstData {
    /**
     * 门店ID
     */
    public String shopId = "";
    /**
     * 总店ID
     */
    public String manageShopId = "";
    /**
     * 电话号码
     */
    public String mobile = "";
    /**
     * 重复提交事物id
     */
    public String commitId = "";
    /**
     * 门店名称
     */
    public String shopName = "";
    /**
     * 传orderId时，为加菜
     */
    public String orderId = "";
    /**
     * 外部订单ID
     */
    public String outerOrderId = "";
    /**
     * 用餐人数
     */
    public int people = 0;

    public List<RapidDiscountBean> disInfoList = new ArrayList<>();
    /**
     * 来源类型(0外部第三方应用，1手机APP，2微信，3外卖，4旺POS，5美POS，6全能POS机，7盒子POS，8点菜宝代理，9点菜宝手持，10WIN POS，11拉卡拉，12秒付， 17秒点快餐)
     * <p>
     * see{@link SourceType}
     */
    public int sourceType = 10;
    /**
     * ???
     */
    public int devType = 0;
    /**
     * 业务类型
     * 14: 普通秒点单
     * 22: 先付款的秒点单
     * 23: 预定订单
     * see{@link NetOrderType}
     */
    public int bizType = 0;

    /**
     * 就餐类型(1到店堂吃，2自提带走)
     * see{@link EatType}
     */
    public int eatType = EatType.EAT_IN;

    /**
     * 第三方类型（0默认，1 石川  2 天财，3博利，4美易点）
     */
    public int thirdType = 4;
    /**
     * 桌台ID，
     * 有可能会返回桌台名称，此时，需要强制转换为桌台ID
     */
    public String tableNo = "";
    /**
     * 订单总价
     */
    public BigDecimal total = BigDecimal.ZERO;

    /**
     * 订单描述
     */
    public String orderDesc = "";
    /**
     * 订单备注
     */
    public String orderRemark = "";
    /**
     * 菜品列表
     */
    public List<RapidOrderItem> itemList = null;
    /**
     * 开台预点菜品
     */
    public List<RapidOrderItem> openTableItemList = null;
    /**
     * 正餐服务费
     */
    public BigDecimal fdServiceAmt = BigDecimal.ZERO;
    /**
     * 订单详情列表(菜品列表)
     */
    public List<RapidOrderItem> orderDetailList = null;

    /**
     * 退款金额
     */
    public BigDecimal payBackAmount = BigDecimal.ZERO;
    /**
     * 条形码
     */
    public String barCode = "";
    /**
     * 打印码
     */
    public String printNumber = "";
    /**
     * 菜的数量
     */
    public int itemCount = 0;
    /**
     * 订单状态(0新单，1已确认，2已下单到厨房，3已完成，-1已删除，-2已取消)
     */
    public int orderStatus = 0;
    /**
     * 支付状态(-1已退款，0，未支付, 1部分支付，2已支付，3已就餐)
     * (-2支付失败,-1已退款，0，未支付, 1支付中，2已支付，3已就餐 ，4线下支付，-99已结账未清,5待服务员确认)
     */
    public int payStatus = 0;
    /**
     * 订单人数
     */
    public int person = 0;
    /**
     * 下单时间, 时间戳？
     */
    public String placeOrderTime = "";
    /**
     * 就餐状态(0未确认,10已确认,20下单到厨房,30饭已做好(已分配取餐柜柜号),40用户已取)
     */
    public int diningStatus = 0;
    /**
     * 客户端在线状态(0-不在线，1-在线)
     */
    public int clientStatus = 0;

    /**
     * 非会员模式下订单的总价
     */
    public BigDecimal originTotal = BigDecimal.ZERO;

    /**
     * 会员模式下订单总价
     * 若订单是非会员的，则 originMemTotal = originTotal;
     */
    public BigDecimal originMemTotal = BigDecimal.ZERO;

    /**
     * 订单总可折扣金额
     */
    public BigDecimal discountAmount = BigDecimal.ZERO;

    /**
     * 非会员模式下订单待支付的可折扣金额
     */
    public BigDecimal originDiscountAmount = BigDecimal.ZERO;

    /**
     * 非会员模式下订单待支付的不可折扣金额
     */
    public BigDecimal originNonDiscountAmount = BigDecimal.ZERO;

    /**
     * 会员模式下待支付的可折扣金额
     * 若订单是非会员的，则 discountAmountPay = originDiscountAmount；
     */
    public BigDecimal discountAmountPay = BigDecimal.ZERO;

    /**
     * 会员模式下待支付的不可折扣金额
     * 若订单是非会员的，则 nonDiscountAmountPay = originNonDiscountAmount；
     */
    public BigDecimal nonDiscountAmountPay = BigDecimal.ZERO;

    /**
     * 已支付金额
     */
    public BigDecimal paymentAmount = BigDecimal.ZERO;

    /**
     * 订单待支付金额----中控开关"仅全额储值付款时享受会员价"关闭时取用
     * 若订单是非会员的，则 memTotal = subTotal = notPaymentAmount;
     */
    public BigDecimal notPaymentAmount = BigDecimal.ZERO;

    /**
     * 订单待支付金额----中控开关"仅全额储值付款时享受会员价"打开时，会员储值支付时使用
     * 若订单是非会员的，则 memTotal = subTotal = notPaymentAmount;
     */
    public BigDecimal memTotal = BigDecimal.ZERO;

    /**
     *订单待支付金额----中控开关"仅全额储值付款时享受会员价"打开时，非会员储值支付时使用
     */
    public BigDecimal subTotal = BigDecimal.ZERO;

    /**
     *
     */
    public int discountType = 0;
    /**
     *
     */
    public String orderSeq = "";
    /**
     *
     */
    public BigDecimal notOrderAmount = BigDecimal.ZERO;
    /**
     *
     */
    public BigDecimal notOrderQty = BigDecimal.ZERO;

    /**
     * 会员评论
     */
    public String comment;

    public MemberComments commentModel;

    /**
     * 服务员信息
     * “开台”、“下单”、“加菜”、”退菜“ 四者之一，目前仅需要开台的服务员即可
     */
    public List<RapidEmployee> employeeList = new ArrayList<>();

    /**
     * 是否是先付款
     */
    public int payFirst = 0;

    /**
     * 用户ID
     */
    public String userId = "";

    /**
     * 是否显示开台菜  1 显示  0 不显示
     */
    public int showOpenAutoDish = 0;
    /**
     * 是否打印秒付二维码：1打印，0不打印
     */
    public int isShowQRCode = 1;

    /**
     * 秒付二维码内容
     */
    public String qRCodeUrl = "";

    /**
     * 秒付二维码的下面的结账说明
     */
    public String qrCodeTitle = "";

    /**
     * 会员性别
     */
    public String sex = "";

    /**
     * 储值卡余额
     */
    public BigDecimal cardBalance = BigDecimal.ZERO;

    /**
     * 秒付赠送积分规则使用新规则
     */
    public int useNewCheckRule = 1;

    /**
     * 用餐时间
     */
    public String eatTime = "";

    public RapidOrder() {

    }

    public RapidOrder(RapidfstData originData) {
        if (originData != null) {
            this.action = originData.action;
            this.isVip = originData.isVip;
            this.memberCardno = originData.memberCardno;
            this.memberDiscount = originData.memberDiscount;
            this.memberLevel = originData.memberLevel;
            this.memberId = originData.memberId;
            this.plusId = originData.plusId;
            this.plusName = originData.plusName;
            this.isVipPrice = originData.isVipPrice;
        }
    }

    public RapidOrder(RapidPayment payment) {
        if (payment != null) {
            this.isVip = TextUtils.isEmpty(payment.fsMemberNo) ? 1 : 0;
            this.memberCardno = payment.fsMemberNo;
            this.memberLevel = payment.memberLevel;
            this.memberId = payment.memberId;
            this.plusId = payment.plusId;
            this.plusName = payment.plusName;
            this.isVipPrice = payment.isVipPrice;
        }
    }

    public void buildMemberComments() {
        //只有三星以及三星一下 才会显示会员评论的内容
        if (!TextUtils.isEmpty(comment)) {
            try {
                commentModel = JSON.parseObject(comment, MemberComments.class);
            } catch (Exception e) {
                LogUtil.logError("秒点下单时，解析会员评论异常"+JSON.toJSONString(comment), e);
            }
        }

        //强制把会员等级数据和会员评论数据组合
        if (commentModel != null) {
            commentModel.memberLevel = memberLevel;
            commentModel.sex = sex;
            commentModel.cardBalance = cardBalance;
        } else {
            JSONObject jsonObject = new JSONObject();
            if (!TextUtils.isEmpty(memberCardno)) {
                jsonObject.put("card_no", memberCardno);
                jsonObject.put("memberLevel", memberLevel);
                jsonObject.put("sex", sex);
                jsonObject.put("cardBalance", cardBalance);
                try {
                    commentModel = JSON.parseObject(jsonObject.toJSONString(), MemberComments.class);
                } catch (Exception e) {
                    LogUtil.logError("秒点下单时，解析会员评论异常2"+jsonObject.toJSONString(), e);
                }
            }
        }
    }
}
