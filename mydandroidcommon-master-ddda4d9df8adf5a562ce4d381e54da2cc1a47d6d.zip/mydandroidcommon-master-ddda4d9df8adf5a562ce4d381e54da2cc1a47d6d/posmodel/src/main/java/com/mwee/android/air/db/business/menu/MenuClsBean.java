package com.mwee.android.air.db.business.menu;

import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/10/21.
 */
public class MenuClsBean extends DBModel {
    @ColumnInf(name = "fsMenuClsId")
    public String fsMenuClsId;
    @ColumnInf(name = "fsMenuClsName")
    public String fsMenuClsName = "";
    @ColumnInf(name = "fiMenuClsKind")
    public int fiMenuClsKind = 0;//--类型;1单品类、2套餐类
    @ColumnInf(name = "fiSortOrder")
    public int fiSortOrder;
    @ColumnInf(name = "count")
    public int count;

    /**
     * 菜品分类关联的打印机列表
     */
    public ArrayList<String> printerNames = new ArrayList<>();
    /**
     * 选择制作单打印机下标
     */
    public int makingPrinterIndex = -1;
    /**
     * 选择标签打印机下标
     */
    public int labelPrinterIndex = -1;

    public MenuClsBean() {

    }

    public static MenuClsBean copyTo(MenuTypeBean menuTypeBean) {
        MenuClsBean bean = new MenuClsBean();
        bean.fsMenuClsId = menuTypeBean.fsMenuClsId;
        bean.fsMenuClsName = menuTypeBean.fsMenuClsName;
        bean.fiMenuClsKind = menuTypeBean.fiMenuClsKind;
        return bean;
    }
}
