package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:票通宝连接状态相关信息
 */
public class InvoiceConnectStatusViceBean extends BusinessBean {
    /**
     * 企业名称
     */
    public String enterprise_name;
    /**
     * 纳税人识别码
     */
    public String taxpayer_num;
    /**
     * 默认税盘号
     */
    public String tax_tray_no;

    public ArrayList<InvoiceConnectStatusThirdBean> list;

    public InvoiceConnectStatusViceBean() {

    }
}
