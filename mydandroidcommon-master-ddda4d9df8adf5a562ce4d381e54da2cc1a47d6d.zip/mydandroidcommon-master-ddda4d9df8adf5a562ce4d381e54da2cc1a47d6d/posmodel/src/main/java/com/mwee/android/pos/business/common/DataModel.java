package com.mwee.android.pos.business.common;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * 通用model
 * Created by virgil on 2017/12/18.
 *
 * @author virgil
 */

public class DataModel extends DBModel {
    /**
     * id
     */
    @ColumnInf(name = "id")
    public String id;
    /**
     * 名称
     */
    @ColumnInf(name = "name")
    public String name;
    /**
     * 状态
     */
    @ColumnInf(name = "status")
    public String status;
    /**
     * 值
     */
    @ColumnInf(name = "value")
    public String value;

    public DataModel() {

    }
}
