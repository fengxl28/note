package com.mwee.android.pos.business.einvoice.api;

import com.mwee.android.pos.business.einvoice.model.IsInvoiceActiveBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:电子发票是否开通请求
 */
public class InvoiceIsActiveResponse extends BasePosResponse {
    public IsInvoiceActiveBean data;

    public InvoiceIsActiveResponse(){}
}
