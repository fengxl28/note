package com.mwee.android.cashier.connect.bean.http;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetShopInfoPosResponse extends BaseCashierPosResponse {
}
