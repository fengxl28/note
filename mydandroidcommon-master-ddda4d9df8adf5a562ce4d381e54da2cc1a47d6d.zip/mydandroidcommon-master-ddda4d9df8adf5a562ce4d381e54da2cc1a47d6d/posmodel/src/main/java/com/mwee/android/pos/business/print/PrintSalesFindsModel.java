package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by Zun on 16/7/12.
 */
public class PrintSalesFindsModel extends DBModel {

    @ColumnInf(name = "fsexpclsname")
    public String fsexpclsname;                     // 菜品

    @ColumnInf(name = "fdsaleqty")
    public BigDecimal fdsaleqty = BigDecimal.ZERO;  // 数量

    @ColumnInf(name = "fdsaleamt")
    public BigDecimal fdsaleamt = BigDecimal.ZERO;  // 金额

    @ColumnInf(name = "fdOriginalAmt")
    public BigDecimal fdOriginalAmt = BigDecimal.ZERO;  // 原始结算总价

    @ColumnInf(name = "fdSpliteAmt")
    public BigDecimal fdSpliteAmt = BigDecimal.ZERO;  // 菜品实收

    public PrintSalesFindsModel() {

    }
}
