package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.CashierTempOrder;

/**
 * see{@link GetCachedOrderPosRequest}
 * Created by virgil on 2018/2/5.
 *
 * @author virgil
 */

public class GetCachedOrderPosResponse extends BaseCashierPosResponse {
    public CashierTempOrder data;

    public GetCachedOrderPosResponse() {

    }
}
