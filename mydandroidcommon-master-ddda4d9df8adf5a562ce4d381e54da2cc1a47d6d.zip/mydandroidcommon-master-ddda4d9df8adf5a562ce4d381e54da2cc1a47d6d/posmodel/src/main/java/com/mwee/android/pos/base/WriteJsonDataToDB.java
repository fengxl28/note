package com.mwee.android.pos.base;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.SystemClock;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by virgil on 2018/1/18.
 */

public class WriteJsonDataToDB {

    public static boolean writeDataToDB(final String dbName, final String data, final String tag) {
//        LogUtil.logBusiness("DataSync-tag=" + tag, data);
        if (TextUtils.isEmpty(data) || "{}".equals(data) || data.length() < 5) {
            return true;
        }
        return writeDataToDB(dbName, JSON.parseObject(data), tag);
    }

    public static boolean writeDataToDB(final String dbName, final JSONObject ob, final String tag) {

        return DBManager.getInstance(dbName).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                boolean success = false;
                long start = SystemClock.elapsedRealtime();
                long time1 = SystemClock.elapsedRealtime();
                LogUtil.log("FILLDATA", "read cost " + (time1 - start));
                long time2 = SystemClock.elapsedRealtime();
                LogUtil.log("FILLDATA", "json cost " + (time2 - time1));

                Iterator<Map.Entry<String, Object>> ite = ob.entrySet().iterator();
                StringBuilder sb;
                StringBuilder sbK;
                StringBuilder sbV;
                while (ite.hasNext()) {
                    Map.Entry<String, Object> entry = ite.next();
                    String tableName = entry.getKey();
                    JSONArray value = (JSONArray) entry.getValue();
                    for (int i = 0; i < value.size(); i++) {
                        sb = new StringBuilder();
                        sb.append("insert or replace into ").append(tableName).append(" ");
                        JSONObject tableValue = value.getJSONObject(i);
                        Iterator<Map.Entry<String, Object>> iteTableValue = tableValue.entrySet().iterator();
                        sbV = new StringBuilder();
                        sbK = new StringBuilder();
                        List<String> sbValue = new ArrayList<>();
                        List<String> columnList = getColumnList(db, tableName);
                        while (iteTableValue.hasNext()) {
                            Map.Entry<String, Object> entry2 = iteTableValue.next();
                            String key2 = entry2.getKey().toLowerCase();
                            String value2 = entry2.getValue() + "";
                            if (columnList.contains(key2)) {
                                sbK.append(key2).append(",");
                                sbV.append("?").append(",");
                                sbValue.add(value2);
                            } else {
                                continue;
                            }
                        }
                        if (sbK.length() < 1) {
                            RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, tableName + "  " + tableValue.toString());
                            continue;
                        }
                        sbK.deleteCharAt(sbK.length() - 1);
                        sbV.deleteCharAt(sbV.length() - 1);
                        sb.append("(").append(sbK).append(") ").append("values (").append(sbV).append(")");
                        if (LogUtil.SHOW) {
                            LogUtil.log(sb.toString() + tableValue.toJSONString());
                        }
                        db.execSQL(sb.toString(), sbValue.toArray(new String[sbValue.size()]));
                        //todo 此日志为了定位站点库和业务中心库数据不一致问题，待定位到问题后，可以移除此日志
                        if(TextUtils.equals(dbName, APPConfig.DB_CLIENT) && (TextUtils.equals(tableName,"tbmenuitem") || TextUtils.equals(tableName,"tbmenucls") || TextUtils.equals(tableName,"tbmenuitemuint"))){
                            LogUtil.logBusiness("WriteJsonDataToDB-writeDataToDB","sql:"+sb.toString()+",values:"+sbValue.toString());
                        }
                    }
                }
                long time3 = SystemClock.elapsedRealtime();
                LogUtil.log("FILLDATA", "replace cost " + (time3 - time2));
                LogUtil.log("FILLDATA", "final cost " + (time3 - start));
                if (!TextUtils.isEmpty(tag)) {
                    updateSnycTime(db, tag);
                }
                success = true;
                return success;
            }
        });

    }

    /**
     * 更新本地的数据同步时间戳
     *
     * @param db      SQLiteDatabase
     * @param timeTag String | 时间戳
     */
    private static void updateSnycTime(SQLiteDatabase db, String timeTag) {
        if (TextUtils.equals(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST),"1")) {
            Cursor cursor = null;
            try {
                cursor = db.rawQuery("SELECT value FROM meta where key = '" + META.DATA_SYNC_TIME + "'", null);
                if (cursor != null) {
                    int indexValue = cursor.getColumnIndex("value");
                    if(cursor.getCount()>0) {
                        cursor.moveToNext();
                        if (indexValue >= 0 && TextUtils.equals("0", cursor.getString(indexValue))) {
                            db.execSQL("update meta set value='0' where key = '304'");
                        }
                    }
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }
        }

        if (timeTag != null) {
            ContentValues s = new ContentValues(2);
            s.put("key", META.DATA_SYNC_TIME);
            s.put("value", timeTag);
            db.replace("meta", null, s);

            ContentValues clientSync = new ContentValues(2);
            clientSync.put("key", META.DATA_CLIENT_SYNC_TIME);
            clientSync.put("value", timeTag);
            db.replace("meta", null, clientSync);
        }
    }

    /**
     * 获取表名
     *
     * @param db        SQLiteDatabase
     * @param tableName String |
     * @return List<String>
     */
    private static List<String> getColumnList(SQLiteDatabase db, String tableName) {
        String sql = "pragma table_info (?) ";
        List<String> resultList = new ArrayList<>();
        Cursor ct = null;
        try {
            ct = db.rawQuery(sql.replace("?", tableName), null);
            int indexName = ct.getColumnIndex("name");
            while (ct.moveToNext()) {
                resultList.add(ct.getString(indexName).toLowerCase());

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBSimpleUtil.closeCursor(ct);
        }
        return resultList;
    }
}
