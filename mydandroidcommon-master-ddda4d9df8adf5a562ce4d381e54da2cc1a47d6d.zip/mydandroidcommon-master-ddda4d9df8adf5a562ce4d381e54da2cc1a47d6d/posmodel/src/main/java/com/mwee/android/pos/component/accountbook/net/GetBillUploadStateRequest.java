package com.mwee.android.pos.component.accountbook.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.GetABBillStateResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 获取云端上传账单结果
 */
@HttpParam(httpType = HttpType.POST,
        method = "ab/qryAccountBookUploadStatus",
        response = GetBillUploadStateResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 300,
        saveToLog = true)
public class GetBillUploadStateRequest extends BasePosRequest {

    /**
     * 门店编号
     */
    public String shopGuid = "";

    /**
     * 营业日期
     */
    public String sellDate = "";

    public GetBillUploadStateRequest() {
    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrl();
    }
}
