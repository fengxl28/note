package com.mwee.android.air.connect.business.active;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

/**
 * @author:luoshenghua create on:2018/12/11
 * description:小易建店二维码失效状态回传给后台
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28640416
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "updateAuthCodeStatus",
        response = UpdateAuthCodeStatusResponse.class,
        timeOut = 270)
public class UpdateAuthCodeStatusRequest extends BasePosRequest {
    /**
     * 二维码对应的code
     */
    public String code = "";
    /**
     * 状态
     */
    public String status = "";

    @Override
    public String optBaseUrl() {
        return Constant.getCreateShopUrlPrefix();
    }

    /**
     * 这个接口不需要加密 直接返回
     *
     * @param data String | 加密前的报文
     * @return
     */
    @Override
    public String encrypt(String data) {
        return data;
    }

    public UpdateAuthCodeStatusRequest() {
    }
}