package com.mwee.android.air.connect.business.bargain;

import com.mwee.android.air.db.business.bargain.FullReduceBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * author:luoshenghua
 * create on:2018/6/2
 * description:获取满减优惠列表响应
 */
public class GetBargainListResponse extends BaseSocketResponse {
    public List<FullReduceBean> bargainDBModelList = new ArrayList<>();

    public GetBargainListResponse() {
    }

}

