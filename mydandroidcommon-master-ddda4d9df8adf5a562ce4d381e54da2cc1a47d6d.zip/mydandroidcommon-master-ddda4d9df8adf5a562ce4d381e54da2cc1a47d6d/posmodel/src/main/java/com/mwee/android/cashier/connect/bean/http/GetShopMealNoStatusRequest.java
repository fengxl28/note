package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * @Description:
 * @author: Xiaolong
 * @Date: 2018/2/28
 */
@HttpParam(httpType = HttpType.POST,
        method = "openOrder/getShopMealNoStatus",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetShopMealNoStatusResponse.class)
public class GetShopMealNoStatusRequest extends BaseCashierPosRequest {
}
