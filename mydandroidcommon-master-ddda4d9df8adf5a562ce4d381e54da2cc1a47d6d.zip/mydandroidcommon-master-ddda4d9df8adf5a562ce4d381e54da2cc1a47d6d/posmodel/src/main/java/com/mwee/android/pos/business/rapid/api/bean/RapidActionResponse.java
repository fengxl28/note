package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by virgil on 2016/11/3.
 */

public class RapidActionResponse extends BasePosResponse {
    public RapidActionResponse() {

    }
}
