package com.mwee.android.pos.business.rapid.api.bean.model;

import android.text.TextUtils;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.tools.LogUtil;

/**
 * Created by virgil on 2017/5/23.
 */

public class RapidfstData extends BusinessBean {
    /**
     * 秒点秒付的action
     */
    public String action = null;
    /*===================以下字段无需赋值=================*/
    /**
     * 是否是会员
     */
    public int isVip = 0;
    /**
     * 会员卡号
     */
    public String memberCardno = "";
    /**
     * 会员等级
     */
    public String memberLevel = "";
    /**
     * 会员模板ID
     */
    public String memberId = "";

    /**
     * plus卡ID
     */
    public String plusId = "";
    /**
     * plus卡名称
     */
    public String plusName = "";

    /**
     * 会员折扣
     */
    public String memberDiscount = "";

    /**
     * 付款是否使用会员价支付
     * 对接中控快关"仅储值全额支付时享受会员价"
     * 默认-1 ：表示开关关闭--->走原有逻辑
     * 非-1：开关开启
     */
    public int isVipPrice = -1;

    public RapidfstData() {

    }

    /**
     * 是否需要构建会员价.
     * 目前仅判断{@link #isVip}和{@link #memberCardno}是否为空
     *
     * @return boolean | true:需要构建会员价；false：不需要
     */
    public boolean needBuildMemberPrice() {
        LogUtil.logBusiness("RapidfstData.needBuildMemberPrice: isVip:: " + isVip + ", memberCardno:: " + memberCardno);
        return isVip == 1 && !TextUtils.isEmpty(memberCardno);
    }
}
