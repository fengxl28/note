package com.mwee.android.pos.business.member;

import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;

/**
 * 会员处理的结果
 * Created by virgil on 2017/3/21.
 */
public interface MemberProcessResult {
    void callBack(boolean result, String info, boolean onlyGift, NewMemberOrderConsumeRequest requestBuild);
}
