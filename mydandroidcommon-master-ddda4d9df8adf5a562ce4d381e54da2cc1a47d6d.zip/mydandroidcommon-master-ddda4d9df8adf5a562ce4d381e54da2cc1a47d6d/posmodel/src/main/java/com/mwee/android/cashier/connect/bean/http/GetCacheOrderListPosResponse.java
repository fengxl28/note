package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.GetCacheOrderListPosData;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetCacheOrderListPosResponse extends BaseCashierPosResponse {
    public GetCacheOrderListPosData data;

    public GetCacheOrderListPosResponse() {

    }
}
