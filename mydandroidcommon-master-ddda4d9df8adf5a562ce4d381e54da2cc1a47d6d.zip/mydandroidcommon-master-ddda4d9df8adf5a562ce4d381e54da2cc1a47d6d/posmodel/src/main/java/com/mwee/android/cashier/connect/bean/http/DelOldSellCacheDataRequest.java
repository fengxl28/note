package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 删除历史缓存数据
 * <herf>http:http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11642197</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        method = "openOrder/delOldSellCacheData",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = BaseCashierPosResponse.class)
public class DelOldSellCacheDataRequest extends BaseCashierPosRequest {
}
