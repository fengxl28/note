package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by zhangmin on 2018/8/21.
 */

public class KPreTempDinnerResponse extends BasePosResponse {

    public KPreTempDinnerModelContainer data = new KPreTempDinnerModelContainer();

    public KPreTempDinnerResponse() {

    }
}
