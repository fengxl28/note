package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.air.db.business.kbbean.bean.KBFutureUpdateReponse;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiFutureRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 更新口碑预点单  后付款状态
 */
@HttpParam(httpType = HttpType.POST,
        method = "queryOrderDetail",
        response = KBFutureUpdateReponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)

public class KBFuturePushOrderDetailRequest extends BaseKouBeiFutureRequest {


    /**
     * 订单id
     */
    public String id;

    public KBFuturePushOrderDetailRequest() {

    }


}
