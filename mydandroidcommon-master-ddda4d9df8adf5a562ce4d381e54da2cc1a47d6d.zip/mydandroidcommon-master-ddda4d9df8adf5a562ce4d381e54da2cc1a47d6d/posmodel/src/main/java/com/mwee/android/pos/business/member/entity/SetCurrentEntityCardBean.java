package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2018/9/21.
 *
 * "setCurrentEntityCard": {
 "errmsg": "请求成功",
 "errno": 0,
 "data":{
 "current_card_no":"6262973700000005"
 }
 }

 */

public class SetCurrentEntityCardBean extends BusinessBean {

    public String errmsg = "";

    public int errno = 0;

    /**
     * 卡信息
     */
    public SetCurrentEntityCardDataBean data ;


    public SetCurrentEntityCardBean() {
    }
}
