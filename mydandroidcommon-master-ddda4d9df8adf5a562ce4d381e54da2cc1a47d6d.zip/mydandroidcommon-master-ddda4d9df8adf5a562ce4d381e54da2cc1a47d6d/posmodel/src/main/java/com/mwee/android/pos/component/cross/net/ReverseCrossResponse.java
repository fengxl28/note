package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BaseResponse;

/**
 * Created by qinwei on 2018/1/10.
 */

public class ReverseCrossResponse extends BaseResponse {
    public ReverseCrossResult data = new ReverseCrossResult();

    public ReverseCrossResponse() {
    }
}
