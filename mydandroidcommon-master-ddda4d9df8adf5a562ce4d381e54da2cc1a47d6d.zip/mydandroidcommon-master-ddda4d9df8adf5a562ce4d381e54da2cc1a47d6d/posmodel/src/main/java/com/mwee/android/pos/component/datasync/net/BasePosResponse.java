package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.base.net.BaseResponse;

/**
 * BasePosResponse
 * Created by virgil on 16/6/22.
 *
 * @author virgil
 */
public class BasePosResponse extends BaseResponse {

}
