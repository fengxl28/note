package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:电子发票连接状态
 */
public class InvoiceConnectStatusBean extends BusinessBean {
    public InvoiceConnectStatusViceBean data;

    public InvoiceConnectStatusBean() {

    }
}
