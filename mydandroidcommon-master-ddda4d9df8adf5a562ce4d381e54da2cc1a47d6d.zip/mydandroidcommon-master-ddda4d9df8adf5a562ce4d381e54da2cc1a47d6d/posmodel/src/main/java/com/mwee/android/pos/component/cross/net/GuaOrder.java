package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * 挂账记录数据模型
 * Created by qinwei on 2018/1/3.
 */

public class GuaOrder extends BusinessBean {
    /**
     * 未销账金额
     */
    public BigDecimal balanceAmt = BigDecimal.ZERO;

    /**
     * 1:未销帐,2:已销帐,3:部分销帐 默认1
     */
    public String bussinessStatus = "1";
    /**
     * 结账单号
     */
    public String checkBillNo;
    /**
     * 总店id
     */
    public String companyGuid;
    /**
     * 创建时间
     */
    public long createTime;
    /**
     * 挂账对象ID
     */
    public String creditAccountId;
    /**
     * 挂账对象名称
     */
    public String creditAccountName;
    /**
     * 收银员ID
     */
    public String cashierId;
    /**
     * 收银员
     */
    public String cashierName;
    /**
     * 已销账金额
     */
    public BigDecimal crossAccountAmt = BigDecimal.ZERO;
    /**
     * 实际挂账金额
     */
    public BigDecimal debtAmt = BigDecimal.ZERO;
    /**
     *
     */
    public BigDecimal excuseAmt = BigDecimal.ZERO;
    /**
     *
     */
    public int id;
    /**
     *
     */
    public String receiveSeq;
    /**
     * 结账金额
     */
    public BigDecimal saleAmt = BigDecimal.ZERO;
    /**
     * 营业日期
     */
    public String sellDate;
    /**
     * 订单号
     */
    public String sellNo;
    /**
     *
     */
    public String shopGuid;
    /**
     *
     */
    public int status;
    /**
     *
     */
    public long updateTime;

    public GuaOrder() {
    }
}
