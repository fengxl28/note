package com.mwee.android.pos.base;

/**
 * Created by virgil on 16/6/15.
 */
public abstract class Cache {
    public abstract void refresh();

    public abstract void clean();
}
