package com.mwee.android.pos.business.member.api;

import com.mwee.android.pos.business.member.api.model.TicketConsumeModel;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 验券的Response
 * Created by virgil on 2017/3/17.
 */

public class TicketConsumeResponse extends BaseMemberResponse {
    public TicketConsumeModel data = new TicketConsumeModel();//优惠券列表包装实体内容

    public TicketConsumeResponse() {
    }
}