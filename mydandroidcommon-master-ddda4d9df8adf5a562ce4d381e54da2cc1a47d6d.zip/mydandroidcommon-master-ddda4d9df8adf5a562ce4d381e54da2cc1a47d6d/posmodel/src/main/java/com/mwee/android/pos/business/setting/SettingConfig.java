package com.mwee.android.pos.business.setting;

import android.text.TextUtils;

import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBSettingConfig;

/**
 * Created by lxx on 19/04/03.
 */
public class SettingConfig {

    /**
     * 预定服务是否开启
     */
    public static boolean SERVICE_RESERVATION = false;

    public static void initParam() {
        //预定暂不接入
//        SettingConfig.SERVICE_RESERVATION = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBSettingConfig.SERVICE_RESERVATION, "0"), "1");
    }

}
