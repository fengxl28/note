package com.mwee.android.pos.business.print;

import android.text.TextUtils;

import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.tools.StringUtil;

/**
 * Created by lxx on 16/10/19.
 */

public class PrintCache {
    public static void initParam() {
        String fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        PrintConfig.NET_ORDER_THIRD_PLARM_AUTO_GET_PRINT = CommonDBUtil.getConfig(DBPrintConfig.NET_ORDER_THIRD_PLARM_AUTO_GET_PRINT);
        PrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU = CommonDBUtil.getConfigWithDefault(DBPrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU, "1");
        PrintConfig.PRINT_TAIL_MESSAGE = CommonDBUtil.getConfig(DBPrintConfig.TAIL_MESSAGE);
        HostexternalDBModel hostexternalDBModel = CommonDBUtil.getHostExternal(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), fsShopGUID);
        if (hostexternalDBModel != null) {
            PrintConfig.STATEMENT_PRINT_COUNT = StringUtil.toInt((TextUtils.isEmpty(hostexternalDBModel.fsParamValue) ? "1" : hostexternalDBModel.fsParamValue), 1);
            PrintConfig.STATEMENT_PRINT_COUNT = PrintConfig.STATEMENT_PRINT_COUNT > 0 ? PrintConfig.STATEMENT_PRINT_COUNT : 1;
        } else {
            PrintConfig.STATEMENT_PRINT_COUNT = 1;
        }
        PrintConfig.FASTFOOD_PRINT_PASSTO = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.FASTFOOD_PRINT_PASSTO,"0"),"1");
        PrintConfig.BILL_PRINT_REALMONEY = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.BILL_PRINT_REALMONEY,"0"),"1");
        PrintConfig.BILL_PRINT_VOIDMENU = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.BILL_PRINT_VOIDMENU,"0"),"1");
        PrintConfig.PRINT_NET_BILL = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_NET_BILL,"1"),"1");
        PrintConfig.PRINT_REMAIN_BILL = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_REMAIN_BILL,"0"),"1");
    }

}
