package com.mwee.android.pos.business.einvoice;

/**
 * author:luoshenghua
 * create on:2018/5/7
 * description:结账单打印来源
 */
public interface PrintBillFrom {
    //来自结账时
    String FROM_PAY="from_pay";
    //来自账单管理页
    String FROM_BILL_MANAGE="from_bill_manage";
}
