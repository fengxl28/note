package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/9/26.
 * <p>
 * "card_parent":{
 * "gender": 2,
 * "birthday": "",
 * "real_name": "李四"
 * }
 */

public class BindEntityCardParentDataBean extends BusinessBean {

    /**
     * 性别
     */
    public int gender = 0;
    /**
     * 生日
     */
    public String birthday = "";
    /**
     * 姓名
     */
    public String real_name = "";

    public BindEntityCardParentDataBean() {
    }
}
