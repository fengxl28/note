package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.List;

/**
 * Created by virgil on 2018/2/5.
 */

public class TradeListModel extends BusinessBean {
    public List<TradeGroup> result;
    public int currentPage;// 1,
    public int pageSize;// 10,
    public int totalCount;// 1,
    public int totalPages;// 1

    public TradeListModel() {

    }
}
