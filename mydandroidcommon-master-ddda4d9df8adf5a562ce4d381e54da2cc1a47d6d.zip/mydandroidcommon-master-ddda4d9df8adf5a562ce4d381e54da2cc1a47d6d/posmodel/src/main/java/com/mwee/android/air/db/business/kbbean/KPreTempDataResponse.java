package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.air.db.business.kbbean.bean.KBTempDataModelContainer;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;


/**
 * Created by zhangmin on 2018/5/21.
 */

public class KPreTempDataResponse extends BasePosResponse {

    public KBTempDataModelContainer data = new KBTempDataModelContainer();


    public KPreTempDataResponse() {

    }

}
