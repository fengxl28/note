package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/12/7.
 */

public class GroupTicketUseResult extends BusinessBean {
    /**
     * 极速验券个数
     */
    public String count;
    /**
     * 核销券列表
     */
    public ArrayList<GroupTicketUse> list = new ArrayList<>();

    public GroupTicketUseResult() {
    }
}
