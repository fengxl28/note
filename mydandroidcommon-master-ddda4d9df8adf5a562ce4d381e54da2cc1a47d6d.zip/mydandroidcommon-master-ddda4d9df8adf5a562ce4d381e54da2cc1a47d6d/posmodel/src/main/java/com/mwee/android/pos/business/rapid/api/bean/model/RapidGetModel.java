package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * 秒点的数据Model
 * Created by virgil on 2016/11/3.
 */

public class RapidGetModel extends BusinessBean {
    public int fistate = 5;
    /**
     * call服务铃，kt开台，findorderbytableno查询订单实时信息，order下单，checkout结账，qryorderbytable查询订单结账信息
     */
    public String fsaction = "call";
    public String fscreatetime = "2016-11-03 14:14:01";
    public String fsid = "df682d99-57f5-4e91-ab7c-d2eadef40adf";
    public String fsrdata = "";
    /**
     * 店号
     */
    public String fsshopguid = "114488";
    public String fstdata = "";
    public String fsupdatetime = "2016-11-03 14:14:01";

    /**
     * 时间戳(加密签名用)
     */
    public String fiTimestamp = "";

    /**
     * 验证签名
     */
    public String fsSign = "";


    public RapidGetModel() {

    }

}
