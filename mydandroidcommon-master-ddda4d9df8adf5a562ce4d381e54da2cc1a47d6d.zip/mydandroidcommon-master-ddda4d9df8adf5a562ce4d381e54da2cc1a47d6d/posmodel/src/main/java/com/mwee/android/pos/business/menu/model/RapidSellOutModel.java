package com.mwee.android.pos.business.menu.model;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * @ClassName: RapidSellOutModel
 * @Description:
 * @author: SugarT
 * @date: 16/11/10 下午8:57
 *
 *
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23017732
 *
 *
 * "specs":[
{
"specId":"598800000000000001",
"state":1
},
{
"specId":"598800000000000002",
"state":0
}
]

 */
public class RapidSellOutModel extends DBModel {

    /**
     * 菜品id
     */
    @ColumnInf(name = "fiItemCd")
    public String id = "";

    /**
     * 状态(1是沽清，，0是未沽清)
     */
    @ColumnInf(name = "state")
    public String state = "0";

    //数据状态;0未同步到店DB / 1正常 / 2临时沽清 / 3数量沽清 /13删除
    @ColumnInf(name = "fiStatus")
    public int fiStatus = 0;

    //库存数量
    @ColumnInf(name = "fdInvQty")
    public BigDecimal fdInvQty = BigDecimal.ZERO;

    public RapidSellOutModel() {
    }

    @Override
    public boolean equals(Object obj) {
        return this.id.equals(((RapidSellOutModel)obj).id);
    }

    public void decideStatus() {
        if ((fiStatus == 2 || fiStatus ==3) && fdInvQty.compareTo(BigDecimal.ZERO) == 0) {
            state = "1";
        } else {
            state = "0";
        }
    }
}
