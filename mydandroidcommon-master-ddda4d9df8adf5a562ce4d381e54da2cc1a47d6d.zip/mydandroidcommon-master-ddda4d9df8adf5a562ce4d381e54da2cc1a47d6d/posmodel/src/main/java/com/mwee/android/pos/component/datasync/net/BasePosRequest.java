package com.mwee.android.pos.component.datasync.net;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.BaseResponse;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.db.sync.EncryptUtil;
import com.mwee.android.pos.db.sync.ExcryptException;

/**
 * BasePosRequest
 * Created by virgil on 16/6/22.
 *
 * @author virgil
 */
public class BasePosRequest extends BaseRequest {

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrl();
    }


    /**
     * 输出流加密
     *
     * @param data String | 加密前的报文
     * @return String 密文
     */
    @Override
    public String encrypt(String data) {
        String result = data;
        try {
            result = EncryptUtil.MwEncryptaut(ClientMetaUtil.getSettingsValueByKey(META.SHOPID)
                    , ClientMetaUtil.getSettingsValueByKey(META.TOKEN)
                    , ClientMetaUtil.getSettingsValueByKey(META.SEED)
                    , data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 响应流解密
     *
     * @param data String | 密文
     * @return String | 解密后的报文
     */
    @Override
    public String decrypt(String data, int httpStatus) {
        if (httpStatus == 601 || httpStatus == 602 || httpStatus == 603 || httpStatus == 70103) {
            BaseResponse response = new BaseResponse();
            response.status = httpStatus;
            response.errno = httpStatus;
            response.errmsg = httpStatus + "";
            failBackDecrypt(response);
            return JSON.toJSONString(response);
        }
        if (TextUtils.isEmpty(data)) {
            return data;
        }
        String result = data;
        try {
            if (data.startsWith("{")) {
                BaseResponse response = JSON.parseObject(data, BaseResponse.class);
                failBackDecrypt(response);
                if (response.errno == 0) {
                    return data;
                } else {
                    return JSON.toJSONString(response);
                }
            } else {
                result = EncryptUtil.MwDecryptaut(ClientMetaUtil.getSettingsValueByKey(META.SHOPID)
                        , ClientMetaUtil.getSettingsValueByKey(META.TOKEN)
                        , ClientMetaUtil.getSettingsValueByKey(META.SEED)
                        , data);
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                RunTimeLog.addLog(RunTimeLog.NET, "NET exception,origin response is :" + data);
                BaseResponse response = null;
                if (e instanceof ExcryptException) {
                    response = new BaseResponse();
                    response.errno = ((ExcryptException) e).errorNo;
                    response.errmsg = ((ExcryptException) e).errorNo + "";
                } else {
                    response = JSON.parseObject(data, BaseResponse.class);
                }
                failBackDecrypt(response);
                return JSON.toJSONString(response);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return result;
    }

    private void failBackDecrypt(BaseResponse response) {
        if (response != null) {
            if (!TextUtils.isEmpty(response.errmsg)) {
                if (TextUtils.equals("602", response.errmsg) || response.errno == 602) {
                    response.errno = 602;
                    response.errmsg = "门店已被别的设备绑定，请联系客服";
                    if (APPConfig.isCasiher()) {
                        response.errmsg = "此账号已在别处登录，请知悉！";
                    }
                    RunTimeLog.addLog(RunTimeLog.BASE_RESPONSE_ERR_602, response.errmsg);
                } else if (TextUtils.equals("601", response.errmsg) || response.errno == 601) {
                    response.errno = 601;
                    response.errmsg = "服务发生异常，请重试";
                    RunTimeLog.addLog(RunTimeLog.BASE_RESPONSE_ERR_601, response.errmsg);
                } else if (response.errmsg.contains("70103") || response.errno == 70103) {
                    response.errno = 70103;
                    response.errmsg = "门店已被解绑，请重新绑定";
                    RunTimeLog.addLog(RunTimeLog.BASE_RESPONSE_ERR_70103, response.errmsg);
                } else if (TextUtils.equals("603", response.errmsg) || response.errno == 603) {
                    response.errno = 603;
                    response.errmsg = "系统时间不正确，请修改";
                    RunTimeLog.addLog(RunTimeLog.BASE_RESPONSE_ERR_603, response.errmsg);
                }
            }
        }
    }
}
