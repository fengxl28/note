package com.mwee.android.air.connect.business.discount;

import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 */

public class GetAllDiscountManagerInfoResponse extends BaseSocketResponse {

    public List<DiscountManagerInfo> discountManagerInfoArrayList = new ArrayList<>();

    public GetAllDiscountManagerInfoResponse() {

    }

}
