package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * 在线退款
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=12262425
 * Created by qinwei on 2018/2/11.
 */
@HttpParam(httpType = HttpType.POST,
        method = "orderPayment/refundScanPayment",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = RefundScanPaymentResponse.class)
public class RefundScanPaymentRequest extends BaseCashierPosRequest {
    /**
     * 订单号
     */
    public String sellNo;

    public RefundScanPaymentRequest() {
    }
}
