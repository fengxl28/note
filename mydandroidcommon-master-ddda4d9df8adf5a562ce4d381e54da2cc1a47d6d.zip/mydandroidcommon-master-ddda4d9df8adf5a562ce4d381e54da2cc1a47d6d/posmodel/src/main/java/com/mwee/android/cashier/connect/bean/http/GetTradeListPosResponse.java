package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.cashier.connect.bean.http.model.TradeListModel;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class GetTradeListPosResponse extends BaseCashierPosResponse {
    public TradeListModel data = new TradeListModel();

    public GetTradeListPosResponse() {

    }
}
