package com.mwee.android.pos.business.einvoice.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:秒付开具电子发票开关状态
 */
public class InvoiceSwitchStatusGetViceBean extends BusinessBean {
    /**
     * 门店id
     */
    public String shopId;
    /**
     * //发票开关状态，0无发票，1普通发票，2电子发票
     */
    public String fapiaoEnable;

    public InvoiceSwitchStatusGetViceBean() {

    }
}
