package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by changsunhaipeng on 2018/7/5.
 */

public class BuyPrinterData extends BusinessBean {
    public BuyPrinterItem item;
}
