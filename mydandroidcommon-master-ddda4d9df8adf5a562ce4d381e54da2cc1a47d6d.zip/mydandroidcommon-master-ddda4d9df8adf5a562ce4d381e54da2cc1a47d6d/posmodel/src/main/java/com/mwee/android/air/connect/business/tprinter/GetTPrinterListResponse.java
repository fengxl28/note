package com.mwee.android.air.connect.business.tprinter;

import com.mwee.android.air.connect.business.tprinter.model.TPrinterListBean;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;
import java.util.List;


/**
 * author:luoshenghua
 * create on:2018/8/24
 * description:获取打印机列表响应
 */
public class GetTPrinterListResponse extends BasePosResponse {
    public List<TPrinterListBean> data = new ArrayList<>();

    public GetTPrinterListResponse() {
    }
}
