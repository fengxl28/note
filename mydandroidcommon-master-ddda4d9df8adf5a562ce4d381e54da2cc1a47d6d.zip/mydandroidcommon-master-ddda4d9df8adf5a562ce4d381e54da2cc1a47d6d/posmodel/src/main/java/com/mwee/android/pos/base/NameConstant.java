package com.mwee.android.pos.base;

/**
 * Created by virgil on 2017/8/6.
 */

public class NameConstant {
    /**
     * 灾备输出文件的名前缀
     */
    public final static String BACKUP_FILE_PREFIX = "美易点备份";
    /**
     * 灾备还原时的临时db名称
     */
    public final static String RESTORE_DB_NAME = "43sdaq2";
    /**
     * 灾备加密时的密钥
     */
    public final static String BACKUP_PWD = "143LKAS0$sd";
    /**
     * 电视叫号通讯的加密密钥
     */
    public final static String PWD_TV = "jf23Dhf$2";
    /**
     * 向量,16位
     */
    public final static String PWD_IV = "要提高自己1";
    /**
     * 站点间通讯的密钥
     */
    public final static String PWD_HOST_CON = "oahsjJE0973&长者密语";
    /**
     * 美小二通讯的密钥
     */
    public final static String PWD_SMART_WAITER = "nuwezJoqjH$o12&不要想着搞个大事情";
    /**
     * ALP推送的密钥
     */
    public final static String PWD_ALP = "Njcewbjoe&912hG西方的华莱士比你们不知道高明到哪里去了";
    /**
     * UDP推送的密钥
     */
    public final static String PWD_UDP = "qweHBoW981&我和他谈笑风生";
    /**
     * logo上传加密的key
     */
    public final static String AES_FILE = "UIMW25LMMSY436IM";

}
