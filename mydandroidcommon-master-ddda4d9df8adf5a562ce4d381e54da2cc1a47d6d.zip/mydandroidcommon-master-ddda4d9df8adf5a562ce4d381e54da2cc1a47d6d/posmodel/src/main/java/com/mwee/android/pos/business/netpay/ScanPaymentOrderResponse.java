package com.mwee.android.pos.business.netpay;

import com.mwee.android.pos.business.netpay.model.ScanPaymentModelList;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2017/7/21.
 */

public class ScanPaymentOrderResponse extends BasePosResponse {
    public ScanPaymentModelList data = new ScanPaymentModelList();

    public ScanPaymentOrderResponse() {
    }
}
