package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 创建配送信息
 */
@HttpParam(httpType = HttpType.POST,
        method = "submitOrderById",
        response = CreateDeliveryResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 60)

public class CreateDeliveryRequest extends BasePosRequest {
    /**
     * 美味订单Id
     */
    public String orderId = "";
    /**
     * 业务方快递配送单号 默认规则orderId +'_'+时间戳
     * 当没有配送信息时， orderNo=orderId;
     * 当有已取消状态的配送信息时， orderNo = orderId+'_'+取消时间
     */
    public String orderNo = "";

    /**
     * //快递公司(SF-顺丰)
     */
    public String expressCompany = "";

    /**
     * 业务子系统(DC-点餐)
     */
    public String subSys = "DC";

    @Override
    public String optBaseUrl() {
        return Constant.getDeliveryUrlPrefix();
    }

    public CreateDeliveryRequest() {
    }

}
