package com.mwee.android.pos.business.print;

import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * Created by lxx on 16/7/14.
 */
public class StatementSellReceiveModel extends SellreceiveDBModel {
    @ColumnInf(name = "paymentname")
    public String paymentname;

    @ColumnInf(name = "paymentname")
    public String fsrevenuetypename = paymentname;

    @ColumnInf(name = "fdsaleqty")
    public int fdsaleqty;

    @ColumnInf(name = "fdsaleamt")
    public BigDecimal fdsaleamt;

    @Override
    public String toString() {
        return "StatementSellReceiveModel{" +
                "paymentname='" + paymentname + '\'' +
                ", fsrevenuetypename='" + fsrevenuetypename + '\'' +
                ", fdsaleqty=" + fdsaleqty +
                ", fdsaleamt=" + fdsaleamt +
                '}';
    }
}
