package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/8/21.
 */

public class KPreTempDinnerModel extends BusinessBean {

    public String fiPeopleNum="";
    public String fsTableTime="";
    public String fsUserMobile="";
    public String fsTableNO="";

    public KPreTempDinnerModel(){

    }


}
