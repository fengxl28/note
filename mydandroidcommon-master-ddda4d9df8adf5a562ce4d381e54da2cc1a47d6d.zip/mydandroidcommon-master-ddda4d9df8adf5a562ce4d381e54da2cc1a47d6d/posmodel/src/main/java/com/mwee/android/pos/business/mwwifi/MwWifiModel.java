package com.mwee.android.pos.business.mwwifi;

import android.support.annotation.NonNull;

import com.mwee.android.base.net.BusinessBean;

public class MwWifiModel extends BusinessBean implements Comparable<MwWifiModel> {

    public String SSID;
    public String state = "";
    public int level;
    public String capabilities;

    public MwWifiModel() {
    }

    public MwWifiModel(String SSID) {
        this.SSID = SSID;
    }

    public MwWifiModel(String SSID, int level) {
        this.SSID = SSID;
        this.level = level;
    }

    public MwWifiModel(String SSID, int level, String capabilities) {
        this.SSID = SSID;
        this.level = level;
        this.capabilities = capabilities;
    }

    @Override
    public int compareTo(@NonNull MwWifiModel o) {
        return o.level - this.level;
    }

    @Override
    public String toString() {
        return "MwWifiModel{" +
                "SSID='" + SSID + "\'" +
                ",level='" + level + "\'" +
                ",state='" + state + "\'" +
                ",capabilities='" + capabilities + "\'" +
                '}';
    }
}
