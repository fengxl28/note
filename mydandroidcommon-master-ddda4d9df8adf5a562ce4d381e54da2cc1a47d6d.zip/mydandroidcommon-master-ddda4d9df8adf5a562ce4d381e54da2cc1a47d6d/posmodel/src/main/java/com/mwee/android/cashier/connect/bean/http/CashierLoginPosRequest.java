package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 用户登录
 * 此接口不走标准的加解密服务
 * <herf>http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11639884</herf>
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@HttpParam(httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "loginApi/login",
        response = CashierLoginPosResponse.class)
public class CashierLoginPosRequest extends BaseCashierPosRequest {
    public String userMobileNum;
    public String verificationCode;
    public String deviceToken;
    /**
     * 1，美老板；2，美收银
     */
    public String appType;
    /**
     * 登录的Seed
     */
    public String seed;
    public CashierLoginPosRequest() {

    }

    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierLoginUrl();
    }

    @Override
    public String encrypt(String data) {
        return data;
    }

    @Override
    public String decrypt(String data, int httpStatus) {
        return data;
    }
}
