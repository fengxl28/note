package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * 会员优惠券列表接口数据返回包装类
 * Created by qinwei on 2017/3/1.
 */

public class CouponList extends BusinessBean {
    public int page_count;//总页数
    public String total = "";//总记录数
    public ArrayList<Coupon> list = new ArrayList<>();//会员优惠券列表信息

    public CouponList() {
    }
}
