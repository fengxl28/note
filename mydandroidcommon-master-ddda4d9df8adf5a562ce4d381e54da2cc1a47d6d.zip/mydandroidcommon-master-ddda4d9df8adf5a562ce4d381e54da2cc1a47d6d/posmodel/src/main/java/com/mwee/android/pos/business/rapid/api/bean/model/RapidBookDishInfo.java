package com.mwee.android.pos.business.rapid.api.bean.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/7/12.
 */

public class RapidBookDishInfo extends BusinessBean {
    public String orderId = "";
    public int printNumber = 0;
    public List<RapidBookItemSimples> itemSimples = new ArrayList<>();

    public RapidBookDishInfo() {
    }
}
