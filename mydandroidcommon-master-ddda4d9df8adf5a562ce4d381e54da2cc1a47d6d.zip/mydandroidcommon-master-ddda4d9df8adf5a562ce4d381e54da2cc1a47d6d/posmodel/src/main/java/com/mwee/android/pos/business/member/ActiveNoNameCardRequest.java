package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBaseRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by liuxiuxiu on 2018/9/19.
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28665486
 * 激活不记名实体卡
 */
@HttpParam(httpType = HttpType.POST,
        method = "card/entity/active",
        response = ActiveNoNameCardResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class ActiveNoNameCardRequest extends NewMemberBaseRequest {


    /**
     * 卡号
     */
    public String cardNo = "";

    /**
     * 总店ID
     */
    public String brandId = "";
    /**
     * 门店ID
     */
    public String actStoreId = "";
    /**
     * 设备号
     */
    public String deviceId = "";


    public ActiveNoNameCardRequest() {
    }

}
