package com.mwee.android.pos.base;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DeviceUtil;

import java.util.HashMap;
import java.util.Map;

import cn.mwee.android.pay.infocollect.InfoCollect;
import cn.mwee.android.pay.infocollect.RuntimeInfoConfig;
import cn.mwee.android.pay.infocollect.source.remote.RemoteClientProvider;
import cn.mwee.android.pay.infocollect.source.remote.RemoteHttpClientProvider;
import cn.mwee.android.pay.other.CommonKey;
import cn.mwee.android.pay.other.CommonRunInfoConfig;
import timber.log.Timber;


/**
 * Description: 业务中心进程 信息上报到服务端.
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/2/5
 */
public class BizInfoCollect {


    protected static boolean onLineDebug;

    public static ParamvalueDBModel getAccount(String dbName) {
        return DBSimpleUtil.query(dbName, "where fsParamId = '020'", ParamvalueDBModel.class);
    }

    public static void initInfoCollect() {
        RemoteClientProvider clientProvider = new RemoteHttpClientProvider();
        RuntimeInfoConfig.DeviceStateInfo deviceStateInfo = new RuntimeInfoConfig.DeviceStateInfo();
        String account = "";
        String id = "业务中心";
        ParamvalueDBModel paramvalueDBModel = getAccount(APPConfig.DB_MAIN);
        if (paramvalueDBModel != null) {
            account = paramvalueDBModel.fsParamValue;
        }
        deviceStateInfo.id = String.format("%s(%s)", account, id);
        String softType = "43";
        if (APPConfig.isMyd()) {
            softType = "43";
        } else if (APPConfig.isAir()) {
            softType = "57";
        } else if (APPConfig.isCasiher()) {
            softType = "63";
        } else if (APPConfig.isKdsClient()) {
            softType = "98";
        }
        /**
         * 中控上的软件类型
         */
        deviceStateInfo.softType = softType;
        deviceStateInfo.type = CommonKey.Type.SOFT;
        deviceStateInfo.lan = DeviceUtil.getLocalIpAddress();
        RuntimeInfoConfig builder = new RuntimeInfoConfig.Builder()
                .enable(true)
                .setLimit(10)
                .setDeviceStateInfo(deviceStateInfo)
                .setInterval(60 * 3)
                .setRemoteParamProvider(new RuntimeInfoConfig.RemoteParamProvider() {
                    @Override
                    public String getToken() {
                        return DBMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID);
                    }

                    @Override
                    public String getV() {
                        return "V7";
                    }

                    @Override
                    public String getHost() {
                        if (!BaseConfig.isProduct()) {
                            return "http://10.0.18.37:3050/";
                        }
                        return "http://b.mwee.cn/";
                    }
                })
                .setRemoteClientProvider(clientProvider)
                .setLogTree(new BizInfoCollect.TimberTree())
                .build();
        /**
         * 通用运行信息配置
         */
        Map<String, String> remoteHost = new HashMap<>();
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PUSH1, "push.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PUSH2, "push2.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PCDC, "pcdc.winpos.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_B, "b.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_MXR, "mxr.dc.mwee.cn");
        CommonRunInfoConfig.setPingRemoteHostMap(remoteHost);
        CommonRunInfoConfig.setPingInterval(60 * 3);
        InfoCollect.getInstance().init(GlobalCache.getContext(), builder);

    }

    public static void destroy() {
        InfoCollect.destroy();
    }

    public static void setOnlineDebugMode(boolean onLineDebug) {
        CommonRunInfoConfig.enableCpuTrack(onLineDebug);
    }


    ///////////////////////////////////////////////////////////////////////////
    //          美易点监控业务编码
    ///////////////////////////////////////////////////////////////////////////
    public static class BusinessInfoKey {
        /**
         * 微信／支付宝扫码支付接口状态 0正常 1异常
         */
        public final static String MYD_SCAN_PAY_STATUS = "000019";
        /**
         * 网络订单接口状态         0正常 1异常
         */
        public final static String MYD_REMOTE_ORDER_STATUS = "00001a";
        /**
         * 会员余额消费接口         0正常 1异常
         */
        public final static String MYD_MEMBER_S = "10000b";
        /**
         * 拉单接口        0正常 1异常
         */
        public final static String MYD_PULL_ORDER_S = "10000c";
        /**
         * 打印机状态         0正常 1异常
         */
        public final static String MYD_PRINT_S = "10000d";


    }

    ///////////////////////////////////////////////////////////////////////////
    //          infocollect  debug logtree
    ///////////////////////////////////////////////////////////////////////////
    public static class TimberTree extends Timber.Tree {
        @Override
        protected void log(int priority, String tag, String message, Throwable t) {
            if (message != null && message.contains("infocollect")) {
                RunTimeLog.addLog(RunTimeLog.INFO_COLLECT, tag + message);
            }
        }
    }

}
