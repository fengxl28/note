package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.List;

/**
 * Created by virgil on 2018/1/30.
 *
 * @author virgil
 */

public class CashierLoginInfo extends BusinessBean {
    /**
     * 中控Token
     */
    public String controlToken;
    /**
     * 美收银生成的Token
     */
    public String msyToken;
    /**
     * seed
     */
    public String seed;
    /**
     * 用户ID
     */
    public String userId;
    public List<String> shopList;
    /**
     * 符合条件的美收银门店ID
     */
    public String msyShopInfoId;

    public CashierLoginInfo() {

    }
}
