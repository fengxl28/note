package com.mwee.android.cashier.connect;

import com.mwee.android.air.connect.business.menu.MenuClsAndMenuItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAndMenuPackagesResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuClsSortBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/1/31.
 */

public interface CCashierMenuManager {
    @SocketParam(uri = "menuManager/loadAddMenuPackageBean", response = SocketResponse.class)
    void loadAddMenuPackageBean(@SF("menuPackageBean") MenuItemBean menuPackageBean);


    @SocketParam(uri = "cashierMenuItemManager/loadUpdatePackageMenu", response = SocketResponse.class)
    void loadUpdatePackageMenu(@SF("fiItemCd") String fiItemCd,
                               @SF("name") String name,
                               @SF("price") String price,
                               @SF("beans") List<MenuPackageSetSideBean> beans);


    @SocketParam(uri = "menuManager/loadMenuManagerIndex", response = MenuClsAndMenuPackagesResponse.class)
    String loadMenuManagerIndex();

    @SocketParam(uri = "menuManager/loadAllMenuClsAndMenuItems", response = MenuClsAndMenuItemsResponse.class)
    void loadAllMenuClsAndMenuItems();

    /**
     * 菜品排序
     *
     * @param menuClsSortBeans
     */
    @SocketParam(uri = "menuManager/loadMenuItemSort", response = SocketResponse.class)
    void loadMenuItemSort(@SF("menuClsSortBeans") ArrayList<MenuClsSortBean> menuClsSortBeans);

    /**
     * 菜品分类排序
     *
     * @param menuClsBeans
     */
    @SocketParam(uri = "menuManager/loadMenuClsSort", response = SocketResponse.class)
    void loadMenuClsSort(@SF("menuClsBeans") ArrayList<MenuClsBean> menuClsBeans);
}
