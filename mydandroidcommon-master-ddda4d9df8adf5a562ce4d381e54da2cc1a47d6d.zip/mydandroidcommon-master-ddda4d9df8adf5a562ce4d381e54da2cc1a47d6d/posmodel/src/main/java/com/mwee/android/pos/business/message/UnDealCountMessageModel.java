package com.mwee.android.pos.business.message;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by liuxiuxiu on 2017/8/29.
 */

public class UnDealCountMessageModel extends BusinessBean {
    public int orderUndealCount = 0;  //点餐未处理消息数量
    public int payUndealCount = 0;  //支付未处理消息数量
    public int netOrderCount = 0;  //网络订单未处理消息数量
    public int wechatOrderCount = 0;  //微信外卖未处理消息数量
    public int systemCount = 0;  //系统未处理消息数量
    public int fastfood = 0;  //微信快餐未处理消息数量
    public int abnormalOrders = 0;  //异常订单未处理消息数量

    /**
     * 预定订单未处理消息数量
     * -1：未开通预定服务；>-1;已开通服务，未处理订单数
     * ----这里的未处理指的是已预定未取消未就餐的订单
     */
    public int reservationOrders = -1;

    /**
     * 含有未映射菜品的订单数
     */
    public int unMappingOrderCount = 0;

    public UnDealCountMessageModel() {
    }

}
