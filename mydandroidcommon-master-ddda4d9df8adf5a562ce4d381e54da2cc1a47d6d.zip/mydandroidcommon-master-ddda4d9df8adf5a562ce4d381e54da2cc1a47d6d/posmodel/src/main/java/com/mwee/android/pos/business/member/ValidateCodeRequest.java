package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBaseRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberVerifyCodeResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by liuxiuxiu on 2019/2/25.
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31592943
 * 验证码 校验
 */
@HttpParam(httpType = HttpType.POST,
        method = "card/validateCode",
        response = NewMemberVerifyCodeResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class ValidateCodeRequest extends NewMemberBaseRequest {
    /**
     * 手机号
     */
    public String mobile = "";


    /**
     * 品牌id
     */
    public String brandId = "-1";

    /**
     * 验证码
     */
    public String code = "";

    /**
     * 类型
     * 1，实体卡激活（只限实体卡激活验证码使用）；2.普通验证码
     */
    public int type = 0;

    public ValidateCodeRequest() {

    }
}
