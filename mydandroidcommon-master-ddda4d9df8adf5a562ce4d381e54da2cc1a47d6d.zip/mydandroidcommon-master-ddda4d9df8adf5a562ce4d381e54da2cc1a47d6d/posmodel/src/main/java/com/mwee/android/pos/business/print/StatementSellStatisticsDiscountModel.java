package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * 结账单统计折扣方案的model
 * Created by chris on 17/1/6.
 */
public class StatementSellStatisticsDiscountModel extends DBModel {

    @ColumnInf(name = "fsDiscountName")
    public String fsDiscountName = "";
    @ColumnInf(name = "discountamt")
    public BigDecimal discountamt = BigDecimal.ZERO;
}
