package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 取消配送
 */
@HttpParam(httpType = HttpType.POST,
        method = "cancelOrder",
        response = CreateDeliveryResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 60)

public class CancelDeliveryRequest extends BasePosRequest {
    /**
     * 要取消的商家订单号
     */
    public String orderId = "";
    /**
     * 要取消的订单号
     */
    public String orderNo = "";
    /**
     * 取消原因
     */
    public String cancelReason = "商家取消配送";

    /**
     * //快递公司(SF-顺丰)
     */
    public String expressCompany = "";

    /**
     * 扩展信息(可选)
     * "ex_info": [ //扩展信息(可选)
     * {
     * "attrName": "理由",
     * "attrVal": "厨房没菜了，做不了"
     * }
     * ]
     */
    private String ex_info = "[]";

    @Override
    public String optBaseUrl() {
        return Constant.getDeliveryUrlPrefix();
    }

    public CancelDeliveryRequest() {
    }

}
