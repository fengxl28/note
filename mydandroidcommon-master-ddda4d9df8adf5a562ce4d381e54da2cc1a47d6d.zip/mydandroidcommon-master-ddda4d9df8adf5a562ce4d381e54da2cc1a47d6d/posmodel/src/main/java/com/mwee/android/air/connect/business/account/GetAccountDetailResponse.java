package com.mwee.android.air.connect.business.account;

import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * @ClassName: GetAccountDetailResponse
 * @Description:
 * @author: SugarT
 * @date: 2017/10/17 上午10:30
 */
public class GetAccountDetailResponse extends BaseSocketResponse {

    public AccountManageInfo account;

    public GetAccountDetailResponse() {
    }
}
