package com.mwee.android.air.db.business.menu;

import android.support.annotation.NonNull;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.Comparable
 */

public class MenuItemBean extends DBModel{
    @ColumnInf(name = "fsMenuClsId")
    public String fsMenuClsId;
    @ColumnInf(name = "fiItemCd")
    public String fiItemCd = "0";

    @ColumnInf(name = "fsItemName")
    public String fsItemName;
    @ColumnInf(name = "fiItemKind")
    public int fiItemKind;
    @ColumnInf(name = "fsHelpCode")
    /**
     * 助记码
     */
    public String fsHelpCode;

    @ColumnInf(name = "fiOrderUintCd")
    public String fiOrderUintCd = "0";

    @ColumnInf(name = "fdSalePrice")
    public BigDecimal fdSalePrice;

    @ColumnInf(name = "fdVIPPrice")
    public BigDecimal fdVIPPrice;

    @ColumnInf(name = "fdInvQty")
    public BigDecimal fdInvQty;
    @ColumnInf(name = "fiStatus")
    public int fiStatus;
    @ColumnInf(name = "fsOrderUint")
    public String fsOrderUint;

    @ColumnInf(name = "fiIsDiscount")
    public int fiIsDiscount = 1;//----是否可打折；0=false/1=true ; 默认1

    @ColumnInf(name = "fiIsGift")
    public int fiIsGift = 1;//--是否可赠送；0=false/1=true; 默认1


    @ColumnInf(name = "fiIsEditPrice")
    public int fiIsEditPrice = 0;//--是否可改价；0=false/1=true，如时价菜 ; 默认0


    @ColumnInf(name = "fiIsEditQty")
    public int fiIsEditQty = 0;    //--是否可改数；0=false/1=true，如活鱼称重 ; 默认0

    @ColumnInf(name = "fiIsTakeAway")
    public int fiIsTakeAway = 1;//是否外卖  0=false/1=true; 默认0 小散默认为1

    @ColumnInf(name = "fiIsPrn")
    public int fiIsPrn = 1;//是否打印  0=false/1=true; 默认0 小散默认为1

    @ColumnInf(name = "fiIsPrePoint")
    public int fiIsPrePoint = 0; // '是否可预点单 0:不上传,1:上传';
    @ColumnInf(name = "fdLunchBoxCost")
    public BigDecimal fdLunchBoxCost = BigDecimal.ZERO; // 餐盒费

    /**
     * 是否可手机点菜：0，不可以；1，可以
     */
    @ColumnInf(name = "fiIsWechatOrder")
    public int fiIsWechatOrder = 1;

    /**
     * 排序字段
     */
    @ColumnInf(name = "fiSortOrder")
    public int fiSortOrder;
    /**
     * 美收银菜品管理首页用
     */
    public ArrayList<MenuPackageSetSideBean> menuPackageSetSideBeans = new ArrayList<>();
    //手机点菜 可打印属性没有接入

    /**
     * 规格列表
     */
    public List<MenuItemUnitBean> menuItemUnitBeans = new ArrayList<>();

    /**
     * 字符相似度
     */
    public double similarity;

    public MenuItemBean() {
    }


    @Override
    public BusinessBean clone() throws CloneNotSupportedException {
        MenuItemBean menuItemBean = (MenuItemBean) super.clone();
        menuItemBean.menuItemUnitBeans = ListUtil.cloneList(menuItemBean.menuItemUnitBeans);
        return menuItemBean;
    }

    public static MenuItemBean copyTo(MenuItem menuItem, BigDecimal num) {
        MenuItemBean bean = new MenuItemBean();
        bean.fsMenuClsId = menuItem.categoryCode;
        bean.fiItemCd = menuItem.itemID;
        bean.fsItemName = menuItem.name;
        bean.fdSalePrice = menuItem.currentUnit.fdSalePrice;
        bean.fdVIPPrice = menuItem.currentUnit.fdVIPPrice;
        bean.fdInvQty = num;
        bean.fiOrderUintCd = menuItem.currentUnit.fiOrderUintCd;
        bean.fsOrderUint = menuItem.currentUnit.fsOrderUint;

        bean.fiIsDiscount = menuItem.supportDiscount() ? 1 : 0;
        bean.fiIsGift = menuItem.supportGift() ? 1 : 0;
        bean.fiIsEditPrice = menuItem.supportTimes() ? 1 : 0;
        bean.fiIsEditQty = menuItem.supportWeight() ? 1 : 0;
        bean.fiIsTakeAway = menuItem.supportTakeAway() ? 1 : 0;
        bean.fiIsPrn = menuItem.supportPrinter() ? 1 : 0;
        bean.fiIsPrePoint = menuItem.supportPrePoint() ? 1 : 0;
        bean.fdLunchBoxCost = menuItem.fdLunchBoxCost;

        if (num.compareTo(BigDecimal.ZERO) > 0) {
            bean.fiStatus = 2;
        } else {
            bean.fiStatus = 1;
        }
        return bean;
    }
}
