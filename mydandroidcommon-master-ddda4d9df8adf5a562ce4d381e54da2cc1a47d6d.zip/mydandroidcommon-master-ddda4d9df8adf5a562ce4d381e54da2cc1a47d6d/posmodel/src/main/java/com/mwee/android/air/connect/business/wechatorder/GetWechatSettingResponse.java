package com.mwee.android.air.connect.business.wechatorder;

import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by liuxiuxiu on 2017/6/16.
 */

public class GetWechatSettingResponse extends BaseSocketResponse {

    public ArrayMap<String, String> stringList = new ArrayMap<>();

    public GetWechatSettingResponse() {

    }

}
