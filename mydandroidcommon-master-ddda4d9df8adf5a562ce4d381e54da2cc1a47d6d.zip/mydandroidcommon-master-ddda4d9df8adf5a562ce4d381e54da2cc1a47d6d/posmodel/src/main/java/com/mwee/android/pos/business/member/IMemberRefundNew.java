package com.mwee.android.pos.business.member;

import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundRequest;

/**
 * Created by virgil on 2017/4/18.
 */

public interface IMemberRefundNew {
    void callBack(boolean result, String msg, NewMemberOrderRefundRequest request, boolean containsMemberDiscountFinal);
}
