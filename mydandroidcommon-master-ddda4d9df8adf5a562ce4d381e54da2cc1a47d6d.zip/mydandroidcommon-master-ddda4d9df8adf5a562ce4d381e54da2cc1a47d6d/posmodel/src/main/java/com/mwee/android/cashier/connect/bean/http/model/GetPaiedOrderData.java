package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.util.List;

public class GetPaiedOrderData extends BusinessBean {
    public int currentPage;
    public int pageSize;
    public List<GetTsOrderModel> result;
    public int totalCount;
    public int totalPages;

    public GetPaiedOrderData() {

    }
}
