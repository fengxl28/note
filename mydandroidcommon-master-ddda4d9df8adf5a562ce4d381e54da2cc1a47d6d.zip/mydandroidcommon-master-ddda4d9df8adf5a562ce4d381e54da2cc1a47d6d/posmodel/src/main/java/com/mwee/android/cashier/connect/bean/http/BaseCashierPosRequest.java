package com.mwee.android.cashier.connect.bean.http;

import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.ConstantCashier;

/**
 * 美收银Http请求的基类
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */

public class BaseCashierPosRequest extends BasePosRequest {
    @Override
    public String optBaseUrl() {
        return ConstantCashier.getCashierUrl();
    }

}
