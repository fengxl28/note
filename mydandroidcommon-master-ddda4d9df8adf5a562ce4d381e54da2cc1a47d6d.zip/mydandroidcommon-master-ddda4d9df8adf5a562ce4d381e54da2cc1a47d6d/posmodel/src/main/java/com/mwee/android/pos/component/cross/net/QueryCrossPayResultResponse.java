package com.mwee.android.pos.component.cross.net;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by qinwei on 2018/1/3.
 */

public class QueryCrossPayResultResponse extends BasePosResponse {
    public QueryCrossPayResult data = new QueryCrossPayResult();

    public QueryCrossPayResultResponse() {
    }
}
