package com.mwee.android.pos.component.cross.net;

import com.mwee.android.base.net.BaseResponse;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseCrossRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/1/2.
 */
@HttpParam(httpType = HttpType.POST,
        method = "reverseCross",
        response = ReverseCrossResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        timeOut = 1000)
public class ReverseCrossRequest extends BaseCrossRequest {
    /**
     * 请求ID
     */
    public String requestId;
    /**
     * 销账记录ID
     */
    public int recordId;

    /**
     * 操作员ID
     */
    public String createUserId;
    /**
     * 操作员名称
     */
    public String createUserName;
    /**
     * 授权员ID
     */
    public String authorizedUserId;
    /**
     * 授权员名称
     */
    public String authorizedUserName;
    /**
     * 备注
     */
    public String note;
    /**
     * 营业日期
     */
    public String sellDate;

    public ReverseCrossRequest() {

    }
}
