package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/25.
 */

public class KBFutureTempDataContainer extends BusinessBean {


    public List<KBFutureTempDataModel> list = new ArrayList<>();

    /**
     *总记录数
     */
    public int recordCount;
    /**
     *总页数
     */
    public int pageCount;
    /**
     *每页显示多少条记录
     */
    public int pageSize;
    /**
     *当前第几页
     */
    public int pageIndex;


}
