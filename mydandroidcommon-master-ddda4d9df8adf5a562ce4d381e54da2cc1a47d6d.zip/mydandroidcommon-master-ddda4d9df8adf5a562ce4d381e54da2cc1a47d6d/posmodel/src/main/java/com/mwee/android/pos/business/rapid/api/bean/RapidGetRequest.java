package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.sync.EncryptUtil;
import com.mwee.android.tools.StringUtil;

/**
 * 秒点订单查询
 * Created by virgil on 2016/11/3.
 */
@HttpParam(httpType = HttpType.POST,
        method = "getwl",
        response = RapidGetResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8,
        saveToLog = true,timeOut = 10)
public class RapidGetRequest extends BasePosRequest {
    public String commitID = "";

    public RapidGetRequest() {

    }


    /**
     * 输出流加密
     *
     * @param data String | 加密前的报文
     * @return String 密文
     */
    @Override
    public String encrypt(String data) {
        String result = data;
        try {
            result = EncryptUtil.MwEncryptaut(DBMetaUtil.getSettingsValueByKey(META.SHOPID)
                    , DBMetaUtil.getSettingsValueByKey(META.TOKEN)
                    , DBMetaUtil.getSettingsValueByKey(META.SEED)
                    , commitID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}
