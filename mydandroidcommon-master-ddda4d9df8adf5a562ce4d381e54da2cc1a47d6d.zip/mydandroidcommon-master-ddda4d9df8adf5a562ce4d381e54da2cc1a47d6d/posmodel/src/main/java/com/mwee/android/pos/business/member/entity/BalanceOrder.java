package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/2/24.
 */

public class BalanceOrder extends BusinessBean {
    public String id;//id

    /**
     * 会员卡充值类型：
     * deposit=>在线储值
     * cash=>现金储值
     * consume=>会员卡消费
     * refund=>消费退款
     * present_online =>线上充值赠送金额
     * present_offline=>线下充值赠送金额
     */
    public String type;
    public String shopid;//消费店铺id

    public String shopname;//店铺名称

    public String title;//标题

    public String description;//描述

    public String amount;//支付金额

    public String score;

    public String add_time;//添加时间

    public BalanceOrder() {
    }

    @Override
    public BalanceOrder clone() {
        BalanceOrder cloneObj = null;
        try {
            cloneObj = (BalanceOrder) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}
