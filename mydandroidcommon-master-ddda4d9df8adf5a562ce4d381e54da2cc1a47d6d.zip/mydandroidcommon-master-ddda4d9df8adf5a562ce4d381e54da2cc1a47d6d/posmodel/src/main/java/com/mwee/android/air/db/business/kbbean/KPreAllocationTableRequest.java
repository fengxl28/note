package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 根据订单号请求口碑预点单数据
 */
@HttpParam(httpType = HttpType.POST,
        method = "koubeiPreOrder/updateTableNO",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KPreAllocationTableRequest extends BaseKouBeiRequest {

    /**
     * 口碑端自己的订单号
     */
    public String orderId = "";
    /**
     * 桌台名称例如A1
     */
    public String tableNO = "";


    public KPreAllocationTableRequest() {

    }
}
