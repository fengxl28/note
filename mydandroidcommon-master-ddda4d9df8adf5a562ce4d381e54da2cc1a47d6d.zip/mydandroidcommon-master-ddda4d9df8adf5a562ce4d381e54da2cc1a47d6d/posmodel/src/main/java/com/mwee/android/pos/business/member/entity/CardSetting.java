package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * 会员配置
 * Created by qinwei on 2017/9/8.
 */

public class CardSetting extends BusinessBean {
    /**
     * 是否开通了实体卡（16位）
     */
    public String is_open_entity_card;
    /**
     * 是否开通现金收银
     */
    public String is_cash_pay;
    /**
     * POS消费是否开启
     */
    public String is_open_pos_consume;
    /**
     * 是否手动修改
     */
    public String is_hand_score;
    /**
     * 微信储值是否开启
     */
    public String is_score;
    /**
     * 单次储值下限
     */
    public String charge_min_limit;
    public String is_open_wechat_charge;
    /**
     * 是否开通支付
     */
    public String is_pay;
    /**
     * 是否允许充任意金额
     */
    public String can_recharge_any_amount;
    /**
     * POS储值是否开启
     */
    public String is_open_pos_charge;
    /**
     * 0 未开启，1验证消费, 2免密消费
     */
    public String mobile_pay_type;

    public CardSetting() {
    }
}
