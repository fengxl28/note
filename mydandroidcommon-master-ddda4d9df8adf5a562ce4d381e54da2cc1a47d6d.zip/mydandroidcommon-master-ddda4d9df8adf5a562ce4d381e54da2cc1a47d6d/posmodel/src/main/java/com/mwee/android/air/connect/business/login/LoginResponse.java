package com.mwee.android.air.connect.business.login;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.discount.CouponBargainModel;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */
public class LoginResponse extends BaseSocketResponse {
    /**
     * 当前营业日期
     */
    public String businessDate = "";
    /**
     * 登录用户
     */
    public UserDBModel loginUser = null;

    /**
     * 登录用户是否有收银权限
     * true:有
     * false:没有
     */
    public boolean collectMoney = false;

    /**
     * 当前的餐段
     */
    public String currentSectionId = "";
    /**
     * 登录成功返回的Session
     */
    public String session = "";
    /**
     * 餐厅设置（存放在Meta的设置）
     */
    public List<JSONObject> dinnerLocalSettings = null;
    /**
     * 餐厅设置，存放在tbparamValue的设置
     */
    public List<ParamvalueDBModel> dinnerDBSettings = null;

    /**
     * 云端新数据
     */
    public String datas = null;
    /**
     * 云端数据版本
     */
    public String newTimeTag = null;
    /**
     * 新的营业日期
     */
    public int newBusinessDate = 0;
    /**
     * 特价列表
     */
    public List<CouponBargainModel> couponBargainList = new ArrayList<>();

    /**
     * 班别列表的model，
     * id为班别ID
     * name为班别名称
     * status：1，已关账；其他，未关账
     */
    public List<DataModel> shiftList = new ArrayList<>();

    public LoginResponse() {

    }
}
