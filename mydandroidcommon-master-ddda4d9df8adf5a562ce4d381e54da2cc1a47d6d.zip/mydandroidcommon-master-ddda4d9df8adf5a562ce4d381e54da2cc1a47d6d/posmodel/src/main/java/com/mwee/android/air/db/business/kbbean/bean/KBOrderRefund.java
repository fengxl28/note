package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/6/25.
 */

public class KBOrderRefund extends BusinessBean {

    /**
     * 美味订单号
     */
    public String fsSellNo = "";
    /**
     * 退款发起方 0:商户  1:C端用户
     */
    public int fsRefundType = 0;
    /**
     * 操作人
     */
    public String fsOperator = "";
    /**
     * 授权人
     */
    public String fsauthorizer = "";

    /**
     * 退款时间
     */
    public String fsRefundTime = "";

    /**
     * 部分退款调用时，退款单号来保证幂等;(部分退款时，必填，最长32位)
     */
    public String refundNo = "";
    /**
     * 部分退款金额(部分退款时，必填；)
     */
    public String refundAmount = "";
}
