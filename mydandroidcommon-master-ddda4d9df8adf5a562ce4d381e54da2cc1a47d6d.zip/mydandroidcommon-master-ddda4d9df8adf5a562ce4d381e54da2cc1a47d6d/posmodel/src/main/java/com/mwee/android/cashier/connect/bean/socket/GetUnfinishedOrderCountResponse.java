package com.mwee.android.cashier.connect.bean.socket;

import com.mwee.android.cashier.connect.bean.http.model.CashierTempOrder;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.List;

/**
 * 获取未完成结账的订单数量
 * Created by virgil on 2018/2/1.
 *
 * @author virgil
 */

public class GetUnfinishedOrderCountResponse extends BaseSocketResponse {
    public List<CashierTempOrder> data;
    public int pageNum;
    public int pages;

    public GetUnfinishedOrderCountResponse() {

    }
}
