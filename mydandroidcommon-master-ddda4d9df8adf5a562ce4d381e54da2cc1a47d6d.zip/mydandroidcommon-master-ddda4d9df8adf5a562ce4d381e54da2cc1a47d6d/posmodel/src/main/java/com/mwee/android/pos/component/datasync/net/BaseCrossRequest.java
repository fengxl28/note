package com.mwee.android.pos.component.datasync.net;

import com.mwee.android.pos.db.sync.Constant;

/**
 * Created by qinwei on 2018/1/2.
 */

public class BaseCrossRequest extends BasePosRequest {
    @Override
    public String optBaseUrl() {
        return Constant.getCrossUrl();
    }
}
