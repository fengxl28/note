package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by virgil on 2018/2/8.
 */

public class GetTsOrderModel extends BusinessBean {

    public BigDecimal actualTotal;   //实收金额
    public String billId;
    public String billSource;  //来源
    public String billSourceId;
    public String checkNo;  //结账号
    public String checkTime;   //结账时间
    public String id;
    public List<Menu> itemList;   //菜品明细
    public String openTableTime;  //开台时间
    public String optUserId;
    public String optUserName;  //操作人
    public BigDecimal originalAmt;  //原始营业额
    public List<Pay> payList;  //支付明细

    public String sellDate;  //销售日期
    public String sellNo;  //订单号
    public BigDecimal serviceFeeAmt;  //服务费
    public String tableId;  //桌台id
    public String tableName; //桌台名字
    public String mealNumber; //牌号

    public BigDecimal couponAmt; //优惠总额
    public BigDecimal roundAmt; // 抹零
    public int sellType;//订单类型 0：正餐； 1：快餐；2：外卖；3：纯收银  4口碑预点单[快餐类型]


    public class Menu extends BusinessBean {
        public BigDecimal addPrice;  //加价
        public int backQty;  //退菜数量
        public String billId;
        public int giftQty; //赠送数量
        public String itemCode;  //菜品码
        public String itemId;  //菜品id
        public String itemName;  //菜品id
        public String itemSeq;
        public int orderItemKind;   // 1:单品   2:套餐头 3: 套餐明细
        public String orderUnitId;  //规定id
        public String orderUnitName; //规格名词
        public BigDecimal originalAmt; //原始营业额
        public BigDecimal originalPrice;  // 原价
        public int saleQty; //销售数量
        public BigDecimal settlementPrice;  //结算金额
        public int splitStatus;  //分账状态 0:不分账  2:已分账
        public String note;  //菜品备注

    }

    public class Pay extends BusinessBean {
        public String billId;
        public int isActual; //是否是 实收  1:是  0 :不是
        public String note;  //备注
        public String number;
        public String optUserName; //收银人
        public BigDecimal payAmt;  //支付金额
        public String payName;  //支付方式
        public String payTime;  //支付时间
        public String payTypeName;  //支付类型
        public String sellDate;  //
        public String sellNo;
        public BigDecimal settlementAmt;  //结算金额
        public String shiftName;  //班别
    }
}
