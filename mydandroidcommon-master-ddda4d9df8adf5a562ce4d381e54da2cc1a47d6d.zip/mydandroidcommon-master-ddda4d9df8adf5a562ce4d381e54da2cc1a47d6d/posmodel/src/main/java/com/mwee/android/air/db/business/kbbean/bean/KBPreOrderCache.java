package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/18.
 */

@TableInf(name = "kbOrder")
public class KBPreOrderCache extends DBModel {
    /**
     * 口碑订单ID
     */
    @ColumnInf(name = "order_id", primaryKey = true)
    public String order_id = "";

    /**
     * 商户ID
     */
    @ColumnInf(name = "merchant_id")
    public String merchant_id = "";
    /**
     * 产品码
     */
    @ColumnInf(name = "biz_product")
    public String biz_product = "";
    /**
     * 店铺ID
     */
    @ColumnInf(name = "shop_id")
    public String shop_id = "";

    /**
     * 业务类型：DINNER-正餐、SNACK-快餐
     */
    @ColumnInf(name = "business_type")
    public String business_type = "";

    /**
     * FOR_HERE("FOR_HERE", "堂食"),
     * TAKE_OUT("TAKE_OUT", "外卖"),
     * TO_GO("TO_GO", "外带"),
     */
    @ColumnInf(name = "dinner_type")
    public String dinner_type = "";

    /**
     * 点餐方式：PLATFORM——线上点，SCAN——扫码点
     */
    @ColumnInf(name = "order_style")
    public String order_style = "";

    /**
     * KOUBEI-口碑
     */
    @ColumnInf(name = "channel")
    public String channel = "";

    /**
     * 就餐人数，int类型
     */
    @ColumnInf(name = "people_num")
    public String people_num = "";


    /**
     * 取餐类型：TABLE-桌号，NO-取餐号
     */
    @ColumnInf(name = "take_style")
    public String take_style = "";

    /**
     * 取餐号码，示例： 桌号：04，令牌：13，取餐号：5100，配送：2018012912312312321（比如饿了么订单号）
     */
    @ColumnInf(name = "take_no")
    public String take_no = "";

    /**
     * 应收金额，以元为单位，精确到分
     */
    @ColumnInf(name = "bill_amount")
    public BigDecimal bill_amount = BigDecimal.ZERO;

    /**
     * 实收金额，以元为单位，精确到分
     */
    @ColumnInf(name = "receipt_amount")
    public BigDecimal receipt_amount = BigDecimal.ZERO;

    /**
     * 应付金额，以元为单位，精确到分
     */
    @ColumnInf(name = "trade_amount")
    public BigDecimal trade_amount = BigDecimal.ZERO;

    /**
     * 实付金额，以元为单位，精确到分
     */
    @ColumnInf(name = "pay_amount")
    public BigDecimal pay_amount = BigDecimal.ZERO;

    /**
     * 服务费，以元为单位，精确到分
     */
    @ColumnInf(name = "service_amount")
    public BigDecimal service_amount = BigDecimal.ZERO;


    /**
     * 打包费，以元为单位，精确到分
     */
    @ColumnInf(name = "packing_amount")
    public BigDecimal packing_amount = BigDecimal.ZERO;

    /**
     * 其他杂费，以元为单位，精确到分
     */
    @ColumnInf(name = "other_amount")
    public BigDecimal other_amount = BigDecimal.ZERO;


    /**
     * 预订开台时间，格式yyyy-mm-dd hh:mm:ss
     */
    @ColumnInf(name = "table_time")
    public String table_time = "";

    /**
     * 用户下单时间，格式yyyy-mm-dd hh:mm:ss
     */
    @ColumnInf(name = "order_time")
    public String order_time = "";


    /**
     * 用户手机号码，1864234324324
     */
    @ColumnInf(name = "user_mobile")
    public String user_mobile = "";

    /**
     * 备注  [不放味精]
     */
    @ColumnInf(name = "memo")
    public String memo = "";

    /**
     * 扩展信息，使用Map extInfo = JSONObject.parseObject(ext_info,Map.class)转换
     * buyerDefaultRealAmount字段: 违约金
     */
    @ColumnInf(name = "ext_info")
    public String ext_info = "";

    /**
     * 是否享受会员价优惠
     */
    @ColumnInf(name = "member_flag")
    public String member_flag = "";


    /**
     * 菜明细列表，使用 JSONObject.parseArray(dish_details,KbPosOrderDishDetail.class) 获取菜明细模型列表
     */
    public List<KBPreMenuItemModel> dish_details = new ArrayList<>();

    @ColumnInf(name = "dish_details")
    public String menuItemListInfo = "";

    /**
     * 是一个list列表，value参考对象PosBillPayChannel	支付渠道列表信息，目前只会有一个支付渠道。使用 JSONObject.parseArray(pay_channels,PosBillPayChannel.class)获取
     */
    public List<PosBillPayChannel> pay_channels = new ArrayList<>();

    @ColumnInf(name = "pay_channels")
    public String payListInfo = "";

    /**
     * <p>
     * 订单操作类型，
     * PUSH-订单已推送
     * RECEIPT—接单、
     * REJECT—拒单、
     * CANCEL-用户取消订单
     * PREPARE—已备餐、
     * DELIVER—已送餐、
     * CLOSE- 商家长时间不接单 超时
     * RENEW—反结
     * REFUND—退款、
     * COOKING-已下厨
     * PARTIAL_REFUND 部分退款
     * <p>
     * FINISH         —订单已完成（接单后未发生退款，24小时超时自动完成）
     */
    @ColumnInf(name = "status")
    public String status = "";

    /**
     * 支付状态
     * APPLY_REFUND   -用户申请退款
     * <p>
     * REJECT_REFUND  -商家拒绝退款
     * <p>
     * ACCEPT_REFUND  -商家接受退款
     * REFUNDED       -商家同意退款
     */
    @ColumnInf(name = "payStatus")
    public String payStatus = "";

}
