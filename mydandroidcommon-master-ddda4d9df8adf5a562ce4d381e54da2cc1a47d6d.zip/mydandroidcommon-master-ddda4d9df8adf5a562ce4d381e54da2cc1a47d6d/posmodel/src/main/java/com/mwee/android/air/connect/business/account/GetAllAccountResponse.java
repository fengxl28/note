package com.mwee.android.air.connect.business.account;

import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: GetAllAccountResponse
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午8:19
 */
public class GetAllAccountResponse extends BaseSocketResponse {

    public List<AccountManageInfo> accountList = new ArrayList<>();

    public GetAllAccountResponse() {
    }
}
