package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

/**
 * Created by zhangmin on 2018/6/26.
 */
@TableInf(name = "tborderrefundkoubei")
public class KBOrderRefundModel extends DBModel {

    /**
     * 订单号
     */
    @ColumnInf(name = "fsSellNo", primaryKey = true)
    public String fsSellNo = "";

    /**
     * '退款发起方 0:商户1:C端用户',
     */
    @ColumnInf(name = "fsRefundType")
    public int fsRefundType;

    /**
     * '操作人'
     */
    @ColumnInf(name = "fsOperator")
    public String fsOperator= "";

    /**
     * ''授权人''
     */
    @ColumnInf(name = "fsAuthorizer")
    public String fsAuthorizer= "";

    /**
     * ''退款时间''
     */
    @ColumnInf(name = "fsRefundTime")
    public String fsRefundTime= "";


}
