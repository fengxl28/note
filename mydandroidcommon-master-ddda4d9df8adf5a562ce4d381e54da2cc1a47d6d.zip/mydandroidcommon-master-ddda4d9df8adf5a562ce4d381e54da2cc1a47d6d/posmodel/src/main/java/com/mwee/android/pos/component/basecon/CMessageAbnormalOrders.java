package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.message.MessageAbnormalOrderDetailResponse;
import com.mwee.android.pos.connect.business.message.MessageAbnormalOrderListResponse;
import com.mwee.android.pos.connect.business.message.MessageCheckOrderResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * 消息中心--异常订单
 * Created by liuxiuxiu on 2018/5/23.
 */

public interface CMessageAbnormalOrders {

    /**
     * 获取消息---分页
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/optAbnormalOrderList", response = MessageAbnormalOrderListResponse.class, timeOut = 80)
    String optAbnormalOrderList(@SF("pageIndex") int pageIndex,
                                @SF("messageConuntOnePage") int messageConuntOnePage,
                                @SF("businessDate") String businessDate,
                                @SF("time") String time,
                                @SF("areaIds") String areaIds);

    /**
     * 获取异常订单---不支持分页
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/loadAbnormalOrders", response = MessageAbnormalOrderListResponse.class, timeOut = 80)
    String loadAbnormalOrders(@SF("businessDate") String businessDate,
                              @SF("time") String time,
                              @SF("areaIds") String areaIds);

    /**
     * 获取消息详情
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/optAbnormalOrderDetail", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String optAbnormalOrderDetail(@SF("msgId") String msgId,
                                  @SF("time") String time,
                                  @SF("areaIds") String areaIds);

    /**
     * 获取消息：订单头 + 订单明细
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/optAbnormalOrderInfo", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String optAbnormalOrderInfo(@SF("msgId") String msgId,
                                @SF("billNo") String billNo,
                                @SF("time") String time,
                                @SF("areaIds") String areaIds);

    /**
     * 忽略
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/ignoreOrder", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String ignoreOrder(@SF("msgId") String msgId,
                       @SF("time") String time,
                       @SF("areaIds") String areaIds);

    /**
     * 绑定桌台
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/bindOrder", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String bindOrder(@SF("msgId") String msgId,
                     @SF("time") String time,
                     @SF("areaIds") String areaIds);

    /**
     * 绑定口碑后付
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/bindKBAfterPayOrder", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String bindKBAfterPayOrder(@SF("msgId") String msgId,
                               @SF("orderId") String orderId,
                               @SF("time") String time,
                               @SF("areaIds") String areaIds);

    /**
     * 退款
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/voidOrder", response = MessageAbnormalOrderDetailResponse.class, timeOut = 80)
    String voidOrder(@SF("msgId") String msgId,
                     @SF("time") String time,
                     @SF("areaIds") String areaIds);

    /**
     * 检查桌台订单情况
     *
     * @return
     */
    @SocketParam(uri = "messageAbnormalOrders/checkOrderChange", response = MessageCheckOrderResponse.class, timeOut = 80)
    String checkOrderChange(@SF("msgId") String msgId);

//    /**
//     * 获取消息---分页
//     *
//     * @return
//     */
//    @SocketParam(uri = "messageAbnormalOrders/optAbnormalOrderList", response = MessageAbnormalOrderListResponse.class, timeOut = 80)
//    String optAbnormalOrderList(@SF("pageIndex") int pageIndex,
//                                @SF("messageConuntOnePage") int messageConuntOnePage,
//                                @SF("businessDate") String businessDate,
//                                @SF("time") String time,
//                                @SF("areaIds") String areaIds);
}
