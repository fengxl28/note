package com.mwee.android.pos.business.keppalive;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.business.rapid.api.bean.LoopRapidResponse;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.ClientType;
import com.mwee.android.pos.db.sync.Constant;

/**
 * Created by liuxiuxiu on 2018/5/11.
 * <a herf="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=16225648">保活的Response</a>
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "activity",
        response = KeepAliveResponse.class,
        timeOut = 20)
public class KeepAliveRequest extends BasePosRequest {

    /**
     * 中控登录的	token
     */
    public String token = "";
    /**
     * 硬件标示
     */
    public String deviceid = "";
    /**
     * 软件版本
     */
    public String app_version = "";
    /**
     * 客户端类型
     * int | {@link ClientType}
     */
    public int clientType = ClientType.MYD_ANDROID;
    /**
     * 店号
     */
    public int shopid = 0;

    //口碑心跳apk需要的参数 接口文档 https://docs.alipay.com/pre-open/api_pre/koubei.merchant.device.heartbeat.upload

    /**
     * app_id	String	是	32	支付宝分配给开发者的应用ID	2014072300007148
     */
    public String app_id;

    /**
     * method	String	是	128	接口名称	koubei.merchant.device.heartbeat.upload
     */
    public String method = "koubei.merchant.device.heartbeat.upload";


    /**
     * format	String	否	40	仅支持JSON	JSON
     */
    public String format = "JSON";

    /**
     * charset	String	是	10	请求使用的编码格式，如utf-8,gbk,gb2312等	utf-8
     */
    public String charset = "utf-8";

    /**
     * sign_type	String	是	10	商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2	RSA2
     */
    public String sign_type;

    /**
     * sign	String	是	344	商户请求参数的签名串，详见签名	详见示例
     */
    public String sign;
    /**
     * timestamp	String	是	19	发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"	2014-07-24 03:07:50
     */
    public String timestamp;
    /**
     * version	String	是	3	调用的接口版本，固定为：1.0	1.0
     */
    public String version = "1.0";
    /**
     * app_auth_token	String	否	40	详见应用授权概述
     */
    public String app_auth_token;

    /**
     * biz_content	String	是		请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档
     */
    public String biz_content;

    /**
     * product	String	必选	200	发送心跳的设备所依赖的支付宝产品（如 点餐的为 CO）	CO
     */
    public String product = "CO";

    /**
     * 设备类型
     */
    public String type = "BOH";


    /**
     * hardware_version	String	必选	200	设备型号	HP-003
     */
    public String hardware_version;

    public String sn_id;
    /**
     * soft_version	String	可选	200	isv点餐应用的版本信息	10.1.23
     */
    public String soft_version;
    /**
     * time	String	必选	200	心跳发生时间	2018-08-01 22:00:00
     */
    public String time;
    /**
     * sys_type	String	可选	200	软件版本	1.2.44
     */
    public String sys_type;
    /**
     * sys_version	String	可选	200	系统版本	33
     */
    public String sys_version;
    /**
     * network_type	String	可选	200	网络类型	cmcc
     */
    public String network_type;
    /**
     * network_name	String	可选	200	网络名称	中国移动
     */
    public String network_name;
    /**
     * network_ip	String	可选	200	局域网IP	10:98:121:22
     */
    public String network_ip;
    /**
     * lbs	String	可选	200	lbs 经纬度信息	lbs
     */
    public String lbs;
    /**
     * lbs_type	String	可选	200	lbs 经纬度类型	lbs 经纬度类型
     */
    public String lbs_type;
    /**
     * mac	String	可选	200	MAC 地址	35:44:55:66:fc:fy:90
     */
    public String mac;
    /**
     * exception_info	String	可选	200	异常信息类型枚举	exception_info
     */
    public String exception_info;
    /**
     * extend_info	String	可选	4000	扩展信息	json
     */
    public String extend_info;
    /**
     * app_info	String	可选	4000	前台后台app信息	kbdevice
     */
    public String app_info;
    /**
     * isv_app_id	String	可选	200	ISV APP ID	isv_appid
     */
    public String isv_app_id;
    /**
     * isv_server_time	String	可选	200	ISV 心跳服务器时间	2018-08-23 12:02:02
     */
    public String isv_server_time;
    /**
     * manufacturer	String	必选	200	机器制造商	松下
     */
    public String manufacturer;
    /**
     * isv_pid	String	可选	200	isv商户pid	208864647474784
     */
    public String isv_pid;
    /**
     * 不传或传1只同步我们自己的心跳，传2会同步给口碑
     */
    public String enableKouBei = "1";

    @Override
    public String optBaseUrl() {
        return Constant.getKeepAliveUrl();
    }

    public KeepAliveRequest() {
    }
}
