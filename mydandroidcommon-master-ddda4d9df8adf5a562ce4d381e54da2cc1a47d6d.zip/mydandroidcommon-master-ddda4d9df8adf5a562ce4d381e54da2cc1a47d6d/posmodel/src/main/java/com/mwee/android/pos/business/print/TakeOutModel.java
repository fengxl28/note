package com.mwee.android.pos.business.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;

/**
 * 日结表外卖统计
 * Created by qinwei on 2017/12/14.
 */

public class TakeOutModel extends DBModel {
    @ColumnInf(name = "fsBillSourceId")
    public String fsBillSourceId = "";
    @ColumnInf(name = "fsBillSourceName")
    public String fsBillSourceName = "";
    @ColumnInf(name = "count")
    public int count = 0;
    @ColumnInf(name = "total")
    public BigDecimal total = BigDecimal.ZERO;

    public TakeOutModel() {
    }
}
