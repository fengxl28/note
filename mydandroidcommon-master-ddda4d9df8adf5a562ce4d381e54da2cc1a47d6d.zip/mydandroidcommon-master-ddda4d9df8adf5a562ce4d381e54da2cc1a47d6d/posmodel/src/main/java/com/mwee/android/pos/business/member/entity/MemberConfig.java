package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/9/8.
 */

public class MemberConfig extends BusinessBean {
    /**
     * 会员配置信息
     */
    public CardSetting card_setting = new CardSetting();
    /**
     * 1开通，0未开通
     */
    public int is_open;
    /**
     * 消息内容
     */
    public String msg;

    public MemberConfig() {
    }
}
