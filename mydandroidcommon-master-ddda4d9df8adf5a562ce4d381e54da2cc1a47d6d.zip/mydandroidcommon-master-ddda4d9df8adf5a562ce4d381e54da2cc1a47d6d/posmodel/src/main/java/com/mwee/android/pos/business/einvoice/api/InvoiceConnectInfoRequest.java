package com.mwee.android.pos.business.einvoice.api;


import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:票通宝连接状态请求
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "adapter",
        contentType = "application/json",
        response = InvoiceConnectInfoResponse.class, saveToLog = true
)

public class InvoiceConnectInfoRequest extends BaseInvoiceRequest {
    public InvoiceConnectInfoRequest() {

    }
}
