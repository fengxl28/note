package com.mwee.android.pos.component.basecon;

import com.mwee.android.pos.connect.business.data.GetDataFromCenterResponse;
import com.mwee.android.pos.connect.framework.SocketParam;

/**
 * Created by virgil on 2017/7/24.
 */

public interface CPublic extends CBase {
    /**
     * 获取指定表的数据
     */
    @SocketParam(uri = "biz/getAllPrinter", response = String.class)
    String getAllPrinter();

    @SocketParam(uri = "bizsync/getDataFromCenter", response = GetDataFromCenterResponse.class, timeOut = 60)
    String syncData();

    @SocketParam(uri = "bizsync/checkReplication", timeOut = 120)
    String checkReplication();

//    @DrivenMethod(uri = "biz/refreshcacheorder")
//    public void refreshCacheOrder(OrderCache orderCache) ;
//    @DrivenMethod(uri = "biz/loadDataFromCenter")
//    public  String loadDataFromCenter() ;
//
//    @DrivenMethod(uri = "biz/killprocess")
//    public void killingProcess() ;
//    @DrivenMethod(uri = "biz/finishActive")
//    public void finishActiev() ;
//    @DrivenMethod(uri = "biz/refreshCache")
//    public void refreshCache() ;
//    @DrivenMethod(uri = "biz/reActive")
//    public void reActive(String hostID) ;
}
