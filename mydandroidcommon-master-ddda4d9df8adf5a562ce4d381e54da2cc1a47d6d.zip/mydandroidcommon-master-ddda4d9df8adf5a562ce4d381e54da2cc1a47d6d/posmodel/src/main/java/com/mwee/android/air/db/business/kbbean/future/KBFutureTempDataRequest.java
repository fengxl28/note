package com.mwee.android.air.db.business.kbbean.future;

import com.mwee.android.air.db.business.kbbean.KPreTempDinnerResponse;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiFutureRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 获取口碑预点单 后付款模式 获取订单列表
 */
@HttpParam(httpType = HttpType.POST,
        method = "queryOrderList",
        response = KBFutureTempDataResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KBFutureTempDataRequest extends BaseKouBeiFutureRequest {

    /**
     * 页码
     */
    public int pageIndex;
    /**
     * 每页显示数量
     */
    public int pageSize;
    /**
     * 口碑订单号
     */
    public String orderId;

    /**
     * 订单状态筛选 PUSH
     */
    public String status;


    public KBFutureTempDataRequest() {

    }
}
