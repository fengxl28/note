package com.mwee.android.air.connect.business.table;

import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 */

public class GetAllAreaAndTableResponse extends BaseSocketResponse {

    public List<AirAreaManagerInfo> airAreaManagerInfo = new ArrayList<>();
    public List<AirTableManageInfo> airTableManageInfo = new ArrayList<>();
    public MareaDBModel mareaDBModel = new MareaDBModel();
    public ArrayList<MtableDBModel> newTableDBModels = new ArrayList<>();


    /**
     * 编辑的桌台
     */
    public MtableDBModel mtableDBModel;

    /**
     * 新增的桌台
     */
    public MtableDBModel inSertMtableDBModel;


    public GetAllAreaAndTableResponse() {

    }

}
