package com.mwee.android.pos.component.accountbook.net;


import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.business.AccountBookDBModel;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取账套
 */
public class GetAccountBookResponse extends BasePosResponse {

    public List<AccountBookDBModel> data = new ArrayList<>();

    public GetAccountBookResponse() {
    }
}
