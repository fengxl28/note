package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/5/21.
 * <p>
 * 根据订单号请求口碑预点单数据
 */
@HttpParam(httpType = HttpType.POST,
        method = "kborder/getList",
        response = KPreTempDataResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class KPreTempDataRequest extends BaseKouBeiRequest {

    public int pageNo = 1;
    public int pageSize = 20;

    public String searchParam = "";

    /**
     * ACCEPT_REFUND 查询所有的用户发起退款的订单
     * ""            查询所有订单
     */
    public String payStatus;

    /**
     * 0:所有的订单
     * 1:顾客退款的订单（用户已发起退款商家未处理、用户发起退款且商家同意、用户发起退款且商家不同意）。
     * 2:未分配桌台的订单（正餐，关联的桌台是虚拟桌台，且状态不是已退款的
     */
    public Integer queryType;

    /**
     * 订单筛选 PUSH
     */
    public String status;


    public KPreTempDataRequest() {

    }
}
