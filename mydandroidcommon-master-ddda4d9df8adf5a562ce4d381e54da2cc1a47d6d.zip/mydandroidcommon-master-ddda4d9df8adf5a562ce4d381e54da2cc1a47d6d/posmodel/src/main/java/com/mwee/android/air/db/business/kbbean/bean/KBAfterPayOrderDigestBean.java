package com.mwee.android.air.db.business.kbbean.bean;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/10/25.
 */

public class KBAfterPayOrderDigestBean extends BusinessBean {

    /**
     * 订单总金额=菜品总金额+服务费总金额+其他金额
     */
    public BigDecimal total_amount = BigDecimal.ZERO;
    /**
     * 订单总调整金额
     */
    public BigDecimal total_adjust_amount = BigDecimal.ZERO;
    /**
     * 订单总优惠金额
     * 包括但不限于：
     * (1) 菜品单品优惠，比如特价菜；
     * (2) 订单满减优惠；"
     */
    public BigDecimal total_discount_amount = BigDecimal.ZERO;
    /**
     * 累计支付金额
     * 累计订单线上+线下已支付金额之和；注意：包括本次payable_amount
     */
    public BigDecimal total_paymented_amount = BigDecimal.ZERO;
    /**
     * 订单剩余应收金额
     * 在口碑不支持拆单支付的情况下，此金额一般为0
     */
    public BigDecimal receivable_amount = BigDecimal.ZERO;
    /**
     * 扩展信息
     */
    public String ext_infos;

    public KBAfterPayOrderDigestBean() {
    }
}
