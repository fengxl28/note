package com.mwee.android.air.connect.business.menu;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;

import java.util.List;

/**
 * 点菜菜单列表添加菜品信息
 */
public class MenuEditorResponse extends BaseSocketResponse {

    /**
     * 菜品基本信息
     */
    public MenuitemDBModel menuitemDBModel;

    /**
     * 菜品规格信息
     */
    public List<MenuItemUnitDBModel> menuItemUnitDBModels;

    public MenuEditorResponse() {

    }
}
