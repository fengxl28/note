package com.mwee.android.cashier.connect.bean.http.model;

import com.mwee.android.base.net.BusinessBean;


/**
 * @author changsunhaipeng
 */
public class OpenHelperConfig extends BusinessBean {
    public Boolean printStatus;//打印机状态
    public Boolean menuItemStatus;//是否已添加菜品
    public Boolean payStatus;//支付开通状态
    public Boolean bindStatus;//外卖绑定状态

    /**
     * 是否全部完成
     * true 是  false 否
     *
     * @return
     */
    public Boolean isAllFinish() {
        return printStatus && menuItemStatus && payStatus && bindStatus;
    }

    public OpenHelperConfig() {

    }
}
