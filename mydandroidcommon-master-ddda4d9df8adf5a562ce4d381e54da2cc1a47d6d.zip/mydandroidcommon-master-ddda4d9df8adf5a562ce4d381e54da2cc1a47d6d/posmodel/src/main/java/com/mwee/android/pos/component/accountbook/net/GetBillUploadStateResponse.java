package com.mwee.android.pos.component.accountbook.net;

import com.mwee.android.pos.component.accountbook.net.model.BillUploadStateModel;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: GetABBillStateResponse
 * @Description:
 * @author: SugarT
 * @date: 2017/11/9 下午5:44
 */
public class GetBillUploadStateResponse extends BasePosResponse {

    public List<BillUploadStateModel> data = new ArrayList<>();

    public GetBillUploadStateResponse() {
    }
}
