package com.mwee.android.air.db.business.kbbean;

import com.mwee.android.pos.business.shop.KouBeiShopInfo;
import com.mwee.android.pos.connect.framework.SocketResponse;

/**
 * Created by zhangmin on 2018/5/21.
 */

public class KBShopInfoResponse extends SocketResponse<KouBeiShopInfo> {

    public KouBeiShopInfo kouBeiShopInfo = new KouBeiShopInfo();

    public KBShopInfoResponse() {

    }

}
