package com.mwee.android.pos.business.rapid.api.bean;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by liuxiuxiu on 2017/8/1.
 */

public class IgnoreRapidOnlyPayOrderResponse extends BaseSocketResponse {

    public IgnoreRapidOnlyPayOrderResponse() {
    }
}
