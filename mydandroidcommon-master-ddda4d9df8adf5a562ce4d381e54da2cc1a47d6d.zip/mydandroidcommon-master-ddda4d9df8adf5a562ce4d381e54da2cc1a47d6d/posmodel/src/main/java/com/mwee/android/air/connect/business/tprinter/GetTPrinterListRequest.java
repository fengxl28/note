package com.mwee.android.air.connect.business.tprinter;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * author:luoshenghua
 * create on:2018/8/24
 * description:获取打印机列表请求
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23012657
 */
@HttpParam(httpType = HttpType.POST,
        method = "bizapi/queryPrinterList",
        response = GetTPrinterListResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8, timeOut = 120)
public class GetTPrinterListRequest extends BasePosRequest {

    //适用产品   1:美小易 2:美收银 3:美易点Android 4:美易点Windows 必填
    public String suitableProd = "";

    //打印机类型 1:云打印机，2:蓝牙，3:网口，4:USB   非必填
    public String printType = "";

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessUrlPrefix();
    }

    public GetTPrinterListRequest() {
    }
}
