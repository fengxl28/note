package com.mwee.android.pos.component.basecon;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.connect.business.bean.GetPrintTaskResponse;
import com.mwee.android.pos.connect.business.bean.GetUnPrintTaskNoResponse;
import com.mwee.android.pos.connect.business.bean.UpdatePrintTaskResponse;
import com.mwee.android.pos.connect.business.order.PreMenuListResponse;
import com.mwee.android.pos.connect.business.print.GetPrintMonitorDataResponse;
import com.mwee.android.pos.connect.business.print.GetPrintStatusInfoResponse;
import com.mwee.android.pos.connect.business.print.GetPrintTaskDBResponse;
import com.mwee.android.pos.connect.business.print.GetTempletsResponse;
import com.mwee.android.pos.connect.business.print.GetUsedTempletTypeListResponse;
import com.mwee.android.pos.connect.business.print.GetUsedTempletsResponse;
import com.mwee.android.pos.connect.business.print.PrintMonitorVideoStatusResponse;
import com.mwee.android.pos.connect.business.print.PrinterMemberResponse;
import com.mwee.android.pos.connect.business.print.PrinterUpdateStatusResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.util.List;

/**
 * 打印相关的接口类
 * Created by virgil on 2017/7/24.
 */

public interface CPrint extends CBase {
    /**
     * 通知所有站点刷新打印机
     */
    @SocketParam(uri = "monitor/notifyAllPrinterStatus")
    void notifyAllRefreshPrinterStatus();

    @SocketParam(uri = "monitor/unPrintTask", response = GetUnPrintTaskNoResponse.class)
    void getUnPrintTask();

    /**
     * 修改打印任务状态
     *
     * @param printNo              打印id
     * @param contentValuesHashMap 数据
     * @return
     */
    @SocketParam(uri = "monitor/updatePrintTask", response = UpdatePrintTaskResponse.class, timeOut = 30)
    String updatePrintTask(@SF("printNo") int printNo, @SF("contentValuesHashMap") JSONObject contentValuesHashMap);


    /**
     * @param currentPage   当前的页数
     * @param selectTableNO 查询的桌台
     * @param fiStatus      打印任务的状态
     * @param businessDate  查询指定的营业日期
     * @return
     * @
     */
    @SocketParam(uri = "monitor/loadPrinterData", response = GetPrintMonitorDataResponse.class)
    String loadPrinterData(@SF("currentPage") int currentPage,
                           @SF("selectTableNO") String selectTableNO,
                           @SF("fiStatus") int fiStatus,
                           @SF("businessDate") String businessDate,
                           @SF("printerName") String printerName);

    /**
     * @param selectTableNO 查询的桌台
     * @param fiStatus      打印任务的状态
     * @return
     * @
     */
    @SocketParam(uri = "monitor/loadPrintStatusInfo", response = GetPrintStatusInfoResponse.class)
    String loadPrintStatusInfo(@SF("selectTableNO") String selectTableNO,
                               @SF("fiStatus") int fiStatus,
                               @SF("businessDate") String businessDate);


    /**
     * @param fsHostId  提交站点代码
     * @param fiPrintNo 打印流水号;1、2、3、…
     * @param fsSellNo  销售单号
     * @return
     */
    @SocketParam(uri = "monitor/getPrintTaskDB", response = GetPrintTaskDBResponse.class)
    String getPrintTaskDBRequest(@SF("fsHostId") String fsHostId,
                                 @SF("fiPrintNo") int fiPrintNo,
                                 @SF("fsSellNo") String fsSellNo);


    /**
     * 获取打印数据
     *
     * @param noList
     * @param hostId 操作站点
     * @return
     */
    @SocketParam(uri = "monitor/getPrintTask", response = GetPrintTaskResponse.class)
    String getPrintTaskRequest(@SF("noList") List<Integer> noList,
                               @SF("hostId") String hostId);

    /**
     * @param orderModel 会员充值Model
     * @param payType    支付类型
     * @param memberName 会员姓名
     * @return
     */
    @SocketParam(uri = "ordersync/printerMemberCharge", response = PrinterMemberResponse.class)
    String printerMemberCharge(@SF("orderModel") MemberRechargeOrderModel orderModel,
                               @SF("payType") String payType,
                               @SF("memberName") String memberName);


    /**
     * @param cardNo          卡号
     * @param memberPrivilege 会员特权
     * @return
     */
    @SocketParam(uri = "ordersync/printerMemberPrivate", response = PrinterMemberResponse.class)
    void printerMemberPrivate(@SF("cardNo") String cardNo,
                              @SF("memberPrivilege") MemberPrivateModel memberPrivilege);

    /**
     * 点菜预览单
     *
     * @param tempSelectedMenuList 临时单菜品
     * @param originMenuList       已点单菜品
     * @param printUser            打印用户
     * @param hostId               站点ID
     * @param fsSellNo             单号
     * @param fsMTableName         台位
     * @param fiCustSum            人数
     * @param fsSellDate           日期
     * @param currentSectionID     餐段代码
     * @return
     */
    @SocketParam(uri = "ordersync/premenulist", response = PreMenuListResponse.class)
    String preMenuListRequest(@SF("tempSelectedMenuList") List<MenuItem> tempSelectedMenuList,
                              @SF("originMenuList") List<MenuItem> originMenuList,
                              @SF("printUser") String printUser,
                              @SF("hostId") String hostId,
                              @SF("fsSellNo") String fsSellNo,
                              @SF("fsMTableName") String fsMTableName,
                              @SF("fiCustSum") String fiCustSum,
                              @SF("fsSellDate") String fsSellDate,
                              @SF("currentSectionID") String currentSectionID);


    /**
     * @param printerName     打印机名称
     * @param addFailCount    增加打印机异常次数
     * @param isBackUpPrinter 是否是备用打印机
     * @param resetToOrigin   重置打印机为原始打印机
     * @return
     */
    @SocketParam(uri = "monitor/printer_update", response = PrinterUpdateStatusResponse.class)
    String printerUpdateStatusRequest(@SF("printerName") String printerName,
                                      @SF("addFailCount") boolean addFailCount,
                                      @SF("isBackUpPrinter") boolean isBackUpPrinter,
                                      @SF("resetToOrigin") boolean resetToOrigin,
                                      @SF("fiStatus") int fiStatus,
                                      @SF("fiPrintNo") int fiPrintNo,
                                      @SF("fsHostId") String fsHostId);

    /**
     * 更新打印机状态
     *
     * @param printerName 打印机名称
     * @param status      增加打印机异常次数
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/printer_status_update")
    String printerStatusUpdate(@SF("printerName") String printerName,
                               @SF("status") int status);

    /**
     * 获取小票模版的title列表
     *
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/getTempletsTitleList", response = GetTempletsResponse.class)
    String getTempletsTitleList();

    /**
     * 获取指定的小票模版
     *
     * @param templetID String | 模版ID
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/getTargetTemplet", response = GetTempletsResponse.class)
    String getTargetTemplet(@SF("templetID") String templetID);

    /**
     * 选择使用指定的小票模版
     *
     * @param templetID String | 模版ID
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/useTargetTemplet")
    String useTargetTemplet(@SF("templetID") String templetID);

    /**
     * 保存小票模版
     *
     * @param templetID String | 模版ID
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/saveTemplet")
    String saveTemplet(@SF("templetID") String templetID, @SF("templet") String templet);

    /**
     * 保存小票模版
     *
     * @param templetID String | 模版ID
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/resetTempletToOrigin", response = GetTempletsResponse.class)
    String resetTempletToOrigin(@SF("templetID") String templetID);

    /**
     * 获取打印监控的声音提示状态
     *
     * @return String 声音提示状态
     */
    @SocketParam(uri = "monitor/getPrintMonitorVideoHint", response = PrintMonitorVideoStatusResponse.class)
    String getPrintMonitorVideoHint();

    /**
     * 更新打印监控的声音提示状态
     *
     * @return String 声音提示状态
     */
    @SocketParam(uri = "monitor/updatePrintMonitorVideoHint", response = SocketResponse.class)
    String updatePrintMonitorVideoHint(@SF("isOpen") String isOpen);


    @SocketParam(uri = "P433Driver/updatePrinterSN", response = SocketResponse.class)
    void updatePrinterSN(@SF("printerName") String printerName, @SF("printerSN") String printerSN);

    @SocketParam(uri = "P433Driver/registerNeedP433DataList", response = Integer.class)
    void registerNeedP433Data(@SF("hostId") String hostId);

    @SocketParam(uri = "P433Driver/unregisterNeedP433DataList", response = SocketResponse.class)
    void unregisterNeedP433Data(@SF("hostId") String hostId);


    /**
     * 获取当前使用的小票模版
     *
     * @param fsTempletKey String | 打印uri
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/loadCurrentUsedTemplet", response = GetUsedTempletsResponse.class)
    String loadCurrentUsedTemplet(@SF("fsTempletKey") String fsTempletKey);


    /**
     * 获取当前使用的小票模版
     *
     * @param fsTempletId String | 模版id
     */
    @SocketParam(uri = "monitor/loadUpdateUsedTemplets", response = GetUsedTempletsResponse.class)
    String loadUpdateUsedTemplets(@SF("fsTempletId") String fsTempletId);

    /**
     * 获取当前使用的小票模版列表
     */
    @SocketParam(uri = "monitor/loadUsedTempletsList", response = GetUsedTempletTypeListResponse.class)
    String loadUsedTempletsList();

    /**
     * 获取小票模版列表
     *
     * @return String 更新打印机状态
     */
    @SocketParam(uri = "monitor/getTempletsList", response = GetTempletsResponse.class)
    String getTempletsList();

    /**
     * 开启或关闭使用小票
     *
     */
    @SocketParam(uri = "monitor/selectTemplet")
    String selectTemplet(@SF("templetKey") String templetKey);

    /**
     * 获取同一小票的所有模版
     *
     */
    @SocketParam(uri = "monitor/getSameTemplets", response = GetTempletsResponse.class)
    String getSameTemplets(@SF("templetKey") String templetKey);

    /**
     * 获取选中的小票模版数据
     *
     */
    @SocketParam(uri = "monitor/getSelectedTemplet", response = GetTempletsResponse.class)
    String getSelectedTemplet(@SF("templetKey") String templetKey);
}
