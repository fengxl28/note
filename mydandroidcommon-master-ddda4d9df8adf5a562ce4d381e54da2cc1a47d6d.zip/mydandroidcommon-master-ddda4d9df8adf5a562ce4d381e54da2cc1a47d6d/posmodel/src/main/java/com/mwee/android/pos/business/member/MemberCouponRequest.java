package com.mwee.android.pos.business.member;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.tools.StringUtil;

/**
 * 会员优惠券请求request
 * Created by qinwei on 2017/1/11.
 */
@HttpParam(httpType = HttpType.POST,
        method = "transferstationtob",
        response = MemberCouponResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class MemberCouponRequest extends BaseMemberRequest {
    public String card_no;//会员卡号009861636336
    public int m_shopid;//总店id
    public int shopid;//分店id

    public int page;//页码
    public int pageSize = 1000;//一页显示多少条

    public MemberCouponRequest() {
        super("app.membercard.memberCouponList");
    }
}
