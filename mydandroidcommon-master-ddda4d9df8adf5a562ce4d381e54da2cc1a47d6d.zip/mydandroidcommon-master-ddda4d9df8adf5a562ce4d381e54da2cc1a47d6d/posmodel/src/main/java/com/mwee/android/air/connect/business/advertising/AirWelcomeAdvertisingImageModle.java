package com.mwee.android.air.connect.business.advertising;

import com.mwee.android.base.net.BusinessBean;

/**
 * created by 2018/8/21
 *
 * @author lxd
 * Description:启动页广告实体类
 */
public class AirWelcomeAdvertisingImageModle extends BusinessBean {

    public String image = "";//图片地址
    public String linkUrl = "";//跳转链接

    public AirWelcomeAdvertisingImageModle() {
    }

}
