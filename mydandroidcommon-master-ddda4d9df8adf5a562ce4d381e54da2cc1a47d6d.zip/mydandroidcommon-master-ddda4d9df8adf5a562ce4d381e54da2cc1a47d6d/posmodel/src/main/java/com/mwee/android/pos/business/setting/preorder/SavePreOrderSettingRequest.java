package com.mwee.android.pos.business.setting.preorder;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * author:luoshenghua
 * create on:2018/5/18
 * description:获取预点单设置相关信
 */
@HttpParam(httpType = HttpType.POST,
        method = "koubeiPreOrder/saveSettingUpInfo",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class SavePreOrderSettingRequest extends BaseKouBeiRequest {
    /**
     * 接单方式 : 1-手动接单 ; 2-自动接单
     */
    public int orderTakingType;
    /**
     * 预约开始时间
     */
    public String orderTimeBegin;
    /**
     * 预约结束时间
     */
    public String orderTimeEnd;
    /**
     * 备餐时间；单位：分钟
     */
    public int prepareTime;
    /**
     * 营业开始时间
     */
    public String shopHoursBegin;
    /**
     * 营业结束时间
     */
    public String shopHoursEnd;

    public SavePreOrderSettingRequest() {
    }
}