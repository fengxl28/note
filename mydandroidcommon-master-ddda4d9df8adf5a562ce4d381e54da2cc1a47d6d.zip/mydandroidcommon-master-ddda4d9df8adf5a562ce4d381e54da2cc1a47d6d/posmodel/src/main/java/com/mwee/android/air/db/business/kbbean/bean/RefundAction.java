package com.mwee.android.air.db.business.kbbean.bean;

import android.support.annotation.IntDef;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author:luoshenghua create on:2018/11/13
 * description:
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@IntDef(value = {1, 2})
public @interface RefundAction {
    /**
     * 商户主动退款
     */
    int ACTION_BUSSINESS = 1;
    /**
     * C端用户发起退款,商户同意退款
     */
    int ACTION_CUSTOMER = 2;
}
