package com.mwee.android.pos.business.shift;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 16/9/27.
 */

public class ShiftResponse extends BaseSocketResponse {
    public String printValue = "";
    public List<Integer> printNo = new ArrayList<>();

    public ShiftResponse() {
    }
}
