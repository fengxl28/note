package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * 激活不记名实体卡
 */

public class ActiveNoNameCardBean extends BusinessBean {
    /**
     * 卡号
     */
    public String  card_no = "";

    public ActiveNoNameCardBean() {
    }
}
