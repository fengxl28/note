package com.mwee.android.air.connect.business.active;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

/**
 * author:luoshenghua
 * create on:2018/7/16
 * description:美小易标准版 获取激活门店ID二维码
 * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18962809
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "getCodeUrl",
        response = ActiveAirShopQRResponse.class,
        timeOut = 270)
public class ActiveAirShopQRRequest extends BasePosRequest {
    @Override
    public String optBaseUrl() {
        return Constant.getScanToActiveAirShopUrl();
    }

    public ActiveAirShopQRRequest() {
    }
}
