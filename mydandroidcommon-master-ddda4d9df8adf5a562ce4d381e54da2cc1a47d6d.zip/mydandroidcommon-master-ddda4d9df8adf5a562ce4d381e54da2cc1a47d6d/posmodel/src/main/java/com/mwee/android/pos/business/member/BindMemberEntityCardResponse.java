package com.mwee.android.pos.business.member;

import com.mwee.android.pos.business.member.entity.BindMemberEntityCardBean;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 会员开卡
 * Created by liuxiuxiu on 2018/9/19.
 * wiki:http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23021219
 */

public class BindMemberEntityCardResponse extends BaseMemberResponse {

    public String errmsg = "";

    public int errno = 0;

    /**
     * 激活结果
     */
    public BindMemberEntityCardBean data;

    public BindMemberEntityCardResponse() {
    }
}
