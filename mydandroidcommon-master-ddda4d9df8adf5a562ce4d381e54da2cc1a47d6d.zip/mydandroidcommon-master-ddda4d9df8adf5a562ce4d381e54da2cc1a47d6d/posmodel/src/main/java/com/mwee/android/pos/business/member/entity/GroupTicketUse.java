package com.mwee.android.pos.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/12/7.
 */

public class GroupTicketUse extends BusinessBean {
    /**
     * 团购标题
     */
    public String deal_title;

    /**
     * 价格
     */
    public BigDecimal price;

    /**
     * 券号
     */
    public String sn;

    /**
     * 实付
     */
    public BigDecimal payed_amount;

    public GroupTicketUse() {
    }
}
