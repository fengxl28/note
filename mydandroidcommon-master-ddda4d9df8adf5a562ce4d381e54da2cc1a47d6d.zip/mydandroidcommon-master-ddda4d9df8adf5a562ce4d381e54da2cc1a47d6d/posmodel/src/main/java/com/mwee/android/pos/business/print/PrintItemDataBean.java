package com.mwee.android.pos.business.print;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/5/10.
 */

public class PrintItemDataBean extends DBModel {

    @ColumnInf(name = "fsSeq", primaryKey = true)
    public String fsseq = "";  //唯一标识

    @ColumnInf(name = "fsSeq_M")
    public String fsSeq_M = ""; //子菜品所属父菜品id

    @ColumnInf(name = "fiItemCd")
    public String fiItemCd = "0";  //菜品内码

    @ColumnInf(name = "fiOrderItemKind")
    public int fiOrderItemKind = 0;  //1单品；2、套餐头；3、套餐明细； 4、配料

    @ColumnInf(name = "fsItemName")
    public String fsItemName = "";  //菜品名称
    @ColumnInf(name = "fsItemName2")
    public String fsItemName2 = "";  //菜品第二语言

    @ColumnInf(name = "fsNote")
    public String fsNote = "";  //做法+所有要求

    /**
     * 显著要求
     */
    @ColumnInf(name = "fsSpecialNote")
    public String fsSpecialNote = "";

    /**
     * 做法 + 普通要求
     */
    @ColumnInf(name = "fsGeneralNote")
    public String fsGeneralNote = "";

    /**
     * 整单备注（每个单序的整单备注--普通）
     */
    @ColumnInf(name = "fsWholeNote")
    public String fsWholeNote = "";

    /**
     * 整单备注（每个单序的整单备注--显著）
     */
    @ColumnInf(name = "batchSpecialNote")
    public String batchSpecialNote = "";


    @ColumnInf(name = "fsOrderUint")
    public String fsOrderUint = "";  //规格
    /**
     * //规格ID
     */
    @ColumnInf(name = "fiOrderUintCd")
    public String fiOrderUintCd = "0";

    @ColumnInf(name = "fdSaleQty")
    public BigDecimal fdSaleQty = BigDecimal.ZERO;  //销售数量

    @ColumnInf(name = "fdBackQty")
    public BigDecimal fdBackQty = BigDecimal.ZERO;  //退菜数量

    @ColumnInf(name = "fiIsEditQty")
    public int fiIsEditQty = 0;//是否可改数(称重);0/1;为1=ture时,份数为1

    @ColumnInf(name = "fiIsMulDept")
    public int fiIsMulDept = 0;//是否为多制作部门(0=否/1=是)

    @ColumnInf(name = "fsDeptId")
    public String fsDeptId = ""; //打印部门ID

    @ColumnInf(name = "fiHurryTimes")
    public int fiHurryTimes = 0;  //催菜次数

    public String ingredientFatherItemCd = "-1";  //配料菜的头
    public String packageFatherItemCd = "-1";  //套餐的头
    /**
     * 配料菜
     */
    public List<PrintItemDataBean> ingredientList = new ArrayList<>();

    /**
     * 套餐明细
     */
    public List<PrintItemDataBean> packageItemList = new ArrayList<>();


    public List<PrintItemDataBean> SLIT = new ArrayList<>();

    @ColumnInf(name = "parentItemName")
    public String parentItemName = ""; //套餐头名称

    /**
     * 菜品分类id
     */
    @ColumnInf(name = "fsMenuClsId")
    public String fsMenuClsId;

    /**
     * 所有配料： 鱼丸*3;虾球*2；
     */
    public String ingredientNotes = "";

    @ColumnInf(name = "SfiItemMakeState")
    public String SfiItemMakeState = "";

    public long waitTime = 0;//等叫时间

    @ColumnInf(name = "fdSettlePrice")
    public BigDecimal fdSettlePrice = BigDecimal.ZERO;//价格
    @ColumnInf(name = "fsCreateTime")
    public String fsCreateTime = "";//下单时间
    @ColumnInf(name = "fsCreateUserName")
    public String fsCreateUserName = "";//下单人

    @ColumnInf(name = "qty")//显示数量
    public BigDecimal qty = BigDecimal.ZERO;
    @ColumnInf(name = "fdSaleAmt")
    public BigDecimal fdSaleAmt = BigDecimal.ZERO;  //--销售金额(折前金额);=结算单价*销售数量

    /**
     *  是否计入用餐标准，1-是，0-否
     */
    @ColumnInf(name = "fiWithinDiningStandard")
    public int fiWithinDiningStandard;

    /**
     * 一个订单中需要标签打印机打印的总份数
     */
    public int lastTscIndex = 1;

    /**
     * 退菜理由
     */
    @ColumnInf(name = "fsBackReason")
    public String fsBackReason;

    /**
     * 一级分类名称
     */
    @ColumnInf(name = "fsRootMenuClsName")
    public String fsRootMenuClsName;

    @Override
    public PrintItemDataBean clone() {
        PrintItemDataBean cloneObj = null;
        try {
            cloneObj = (PrintItemDataBean) super.clone();

            if (!ListUtil.isEmpty(ingredientList)){
                cloneObj.ingredientList = new ArrayList<>();
                for (PrintItemDataBean itemDataBean : ingredientList){
                    cloneObj.ingredientList.add(itemDataBean.clone());
                }
            }

            if (!ListUtil.isEmpty(SLIT)){
                cloneObj.SLIT = new ArrayList<>();
                for (PrintItemDataBean itemDataBean : SLIT){
                    cloneObj.SLIT.add(itemDataBean.clone());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}
