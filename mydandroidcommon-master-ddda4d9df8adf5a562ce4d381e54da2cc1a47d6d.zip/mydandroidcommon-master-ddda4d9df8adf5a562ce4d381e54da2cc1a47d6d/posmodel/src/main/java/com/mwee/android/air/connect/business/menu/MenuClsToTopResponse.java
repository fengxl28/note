package com.mwee.android.air.connect.business.menu;

import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/22.
 */

public class MenuClsToTopResponse extends BaseSocketResponse {
    public List<MenuClsBean> menuClsBeenList = new ArrayList<>();

    public MenuClsToTopResponse() {
    }
}
