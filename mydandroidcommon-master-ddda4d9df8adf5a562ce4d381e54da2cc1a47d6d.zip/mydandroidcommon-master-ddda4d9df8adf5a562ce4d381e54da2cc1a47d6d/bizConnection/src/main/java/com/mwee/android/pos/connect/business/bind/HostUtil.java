package com.mwee.android.pos.connect.business.bind;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * 站点相关操作的工具类
 * Created by virgil on 16/9/11.
 */
public class HostUtil {


    /**
     * 获取业务中心-当前站点的ID
     *
     * @return String
     */
    public static String getCurrentHost() {
        String sql = "select value from meta where key='802'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    public static String getShiftIDOfCurrentHost() {
        return getShiftIDByHost(DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
    }

    public static boolean isExist(String hostId, String printerName) {
        String sql = "select count(*) from tbhost where fsHostId='" + hostId + "' and fsPrinterName='" + printerName + "' and fiStatus=1";
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(count, 0) > 0;
    }

    public static String getShiftIDByHost(String hostID) {
        return getShiftIDByHost(hostID, "");
    }

    /**
     * 获取当前站点的班别ID ，仅限业务中心调用；
     * 如果当前站点没有班别，则获取默认班别
     *
     * @param hostID 站点ID，当站点ID无效时，随机取一个辨别ID
     * @return String
     */
    public static String getShiftIDByHost(String hostID, String userID) {
        String shiftID = "";

        if (TextUtils.equals(hostID, HostBiz.mealorder) && !TextUtils.isEmpty(userID)) {
            // 美小二 4.9 版本支持选择登录班别, 如果美小二选择班别登录，
            String sqlMxe = "select shiftid from host_status WHERE hostid = '" + HostBiz.mealorder + "' AND current_user_id = '" + userID + "' AND shiftid NOT IN (SELECT key FROM datacache WHERE type='" + IOCache.TYPE_SHIFT_CLOSE + "')";
            String shiftMxe = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMxe);
            if (!TextUtils.isEmpty(shiftMxe)) {
                shiftID = shiftMxe;
            }
        } else {
            //获取业务中心的班别
            if (TextUtils.equals(hostID, HostBiz.cloudsite) || TextUtils.equals(hostID, HostBiz.mealorder)) {
                hostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            }

            //判断是否关账
            if (!TextUtils.isEmpty(hostID)) {
                String sql = "select shiftid from host_status where  hostid='" + hostID + "' and shiftid not in (select key from datacache where type='" + IOCache.TYPE_SHIFT_CLOSE + "') limit 1";
                shiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
            }
        }

        if (TextUtils.isEmpty(shiftID)) {
            //默认取全天
            shiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftId from tbshift where fsShiftId='Z' and fiStatus='1' limit 1");
            //如果没有全天，则取未关账的班别且未禁用的班别
            if (TextUtils.isEmpty(shiftID)) {
                shiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftId from tbshift where fiStatus='1' and fsShiftId not in  (select key from datacache where type='" + IOCache.TYPE_SHIFT_CLOSE + "') limit 1");
            }
            //如果还是获取不到，则取未关账的班别
            if (TextUtils.isEmpty(shiftID)) {
                shiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftId from tbshift where fsShiftId not in  (select key from datacache where type='" + IOCache.TYPE_SHIFT_CLOSE + "') order by fiStatus asc limit 1");
            }
            //如果还是没有，则写死全天
            if (TextUtils.isEmpty(shiftID)) {
                shiftID = "Z";
            }
        }
        return shiftID;
    }

    /**
     * 获取业务中心登录的服务员，仅限业务中心调用
     *
     * @return UserDBModel
     */
    public static UserDBModel getHostUser() {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fsUserId=(select current_user_id from host_status where hostid=(select value from meta where key='802'))", UserDBModel.class);
    }

    /**
     * 获取云收银的账号
     *
     * @return UserDBModel
     * @deprecated use bizServer UserCache to getCloudUser
     */
    public static UserDBModel getCloudUser() {
        String sqlWaiter = "select * from tbUser where fsStaffId = 'cash'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sqlWaiter, UserDBModel.class);
    }

    /**
     * 获取门店的营业状态
     *
     * @return int | see{@link HostStatus}
     */
    public static int getShopBizStatus() {
        String hostStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select biz_status from host_status where hostid=(select value from meta where key='802') ");
        if (TextUtils.isEmpty(hostStatus)) {
            return HostStatus.FINISH;
        } else {
            return StringUtil.toInt(hostStatus, HostStatus.FINISH);
        }
    }

    /**
     * 获取门店的营业状态
     */
    public static void updateShopBizStatus() {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set biz_status='" + HostStatus.CLOSE + "'   where hostid=(select value from meta where key='802') ");
    }

    /**
     * 门店是否处于打烊状态
     *
     * @return boolean
     */
    public static boolean isShopFinished() {
        return getShopBizStatus() == HostStatus.FINISH;
    }

    /**
     * 检查用户是否正在其他站点登录着
     * 登录前要判定该用户是否在其他设备上正在登录着，若正在其他社保上登录着，则推送消息，告知已被剔除
     * 如何判定正在其他设备上登录着：
     * 1、device被其他用户注册了
     * 2、原设备没有被其他服务员占用
     *
     * @param userID
     * @param device
     * @return String 上次登录的站点/设备
     */
    public static String checkUserRelogin(String userID, String device) {
        JSONObject loginJsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select device, hostid from host_status where current_user_id='" + userID + "'");
        if (loginJsonObject != null && !TextUtils.equals(loginJsonObject.getString("device"), device)
                && !TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select current_user_id from host_status where device='" + loginJsonObject.getString("device") + "'"))) {
            String hostId = loginJsonObject.getString("hostid");
            if (!TextUtils.equals(hostId, HostBiz.mealorder)) {
                return hostId;
            } else {
                return loginJsonObject.getString("device");
            }
        }
        return "";
    }

//    /**
//     * 美小二登录；
//     * 目前的登录为相互T掉的模式。
//     * 所以先清除掉userID的session，再生成session插入回去。
//     * 考虑到美小二的站点是一个，但是设备有多个，所以要先删除掉所有已无服务员登录的美小二站点
//     *
//     * @param userID String
//     * @return String
//     */
//    public static String waiterLogin(String userID, String device, int printConfig) {
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='', device = '' where  current_user_id='" + userID + "'");
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from  host_status where  user_session='' and hostid='" + HostBiz.mealorder + "'");
//        HostStatusModel host = new HostStatusModel();
//        host.device = device;
//        host.hostid = HostBiz.mealorder;
//        host.bind_time = "";
//        host.bind_count = 0;
//        host.bind_status = 0;
//        host.biz_status = HostStatus.BIZING;
//        host.current_user_id = userID;
//        host.shiftid = "";
//        host.sectionid = "";
//        String session = generateSession();
//        host.user_session = session;
//        host.printConfig = printConfig;
//        host.replace();
//        return session;
//

    /**
     * 美小二登录；
     * 目前的登录为相互T掉的模式。
     * 所以先清除掉userID的session，再生成session插入回去。
     * 考虑到美小二的站点是一个，但是设备有多个，所以要先删除掉所有已无服务员登录的美小二站点
     *
     * @param userID String
     * @return String
     * <p>
     * 美小易暂时没用到该功能，保留原先登录方式及参数
     */
    public static String waiterLogin(String userID, String device, int printConfig) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='', device = '' where  current_user_id='" + userID + "'");
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from  host_status where  user_session='' and hostid='" + HostBiz.mealorder + "'");
        HostStatusModel host = new HostStatusModel();
        host.device = device;
        host.hostid = HostBiz.mealorder;
        host.bind_time = "";
        host.bind_count = 0;
        host.bind_status = 0;
        host.biz_status = HostStatus.BIZING;
        host.current_user_id = userID;
        host.shiftid = "";
        host.sectionid = "";
        String session = generateSession();
        host.user_session = session;
        host.printConfig = printConfig;
        host.replace();
        return session;
    }

    /**
     * 站点的服务员登录
     *
     * @param userID    String
     * @param hostID    String
     * @param sectionID String
     * @return String
     */
    public static String hostLogin(String userID, String hostID, String sectionID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from  host_status where  current_user_id='" + userID + "' and hostid='" + HostBiz.mealorder + "'");
        String session = generateSession();
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set bind_status = '1',user_session='" + session + "',shiftid='',biz_status='" + HostStatus.BIZING + "',current_user_id='" + userID + "',sectionid='" + sectionID + "' where hostid='" + hostID + "'");
        return session;
    }

    public static String generateSession() {
        return UUIDUtil.optUUID();
    }

    /**
     * 注销指定的服务员登录
     *
     * @param userID String
     */
    public static void logoutUserByUser(String userID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='' where  current_user_id='" + userID + "'");
    }

    /**
     * 注销指定站点的服务员
     *
     * @param hostID String
     */
    public static void logoutUserByHost(String hostID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='' where  hostid='" + hostID + "'");
    }

    public static List<String> getHostIDByShiftID(String shiftID) {
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select hostid from host_status where shiftid='" + shiftID + "'");
    }

    /**
     * 注销已登录到指定班别的服务员
     *
     * @param shiftID String
     */
    public static void logoutUserByShiftId(String shiftID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='' where  shiftid='" + shiftID + "'");
    }

    /**
     * 根据Session获取UserDBModel
     *
     * @param session String
     * @return String
     */
    public static UserDBModel getUserModelBySession(final String session) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fsUserId=(select current_user_id from host_status where  user_session='" + session + "')", UserDBModel.class);
    }

    /**
     * 根据Session获取UserID
     *
     * @param session String
     * @return String
     */
    public static String getUserIDBySession(final String session) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select current_user_id from host_status where  user_session='" + session + "'");
    }

    /**
     * 清除站点的所有用户
     *
     * @param hostID String
     */
    public static void clearHostUser(String hostID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='' where  hostid='" + hostID + "'");
    }

    public static void addUserSession() {

    }

    /**
     * 清除所有用户的登录状态
     */
    public static void clearAllSession() {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid='',current_user_id='',sectionid='' ");
    }

    /**
     * 判断session是否有效
     *
     * @param session String
     * @return boolean | true：token有效；false：token无效
     */
    public static boolean sessionInvalid(String session) {
        String userID = getUserIDBySession(session);
        return !TextUtils.isEmpty(userID);
    }


    public static void updateBusinessDate(String shopID) {
        String date = DateUtil.getCurrentDate("yyyy-MM-dd");
        updateBusinessDate(date, shopID);
    }

    public static void updateBusinessDate(String date, String shopID) {
        String lastBusinessDate = getHistoryBusineeDate(shopID);
        if (!TextUtils.isEmpty(date) && !date.contains("-")) {
            date = DateUtil.formartDateStrToTarget(date, "yyyyMMdd", "yyyy-MM-dd");
        }
        if (TextUtils.equals(lastBusinessDate, date)) {
            return;
        }

        if (TextUtils.isEmpty(shopID)) {
            shopID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        }
        ParamvalueDBModel paramvalueDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsParamId = '001' and fsShopGUID =(select value from meta where key='104')", ParamvalueDBModel.class);

        if (paramvalueDBModel == null) {
            paramvalueDBModel = new ParamvalueDBModel();
            paramvalueDBModel.lver = 0;
            paramvalueDBModel.fsshopguid = shopID;
            paramvalueDBModel.fsparamid = "001";
        }
        if (!date.contains("-")) {
            paramvalueDBModel.fsParamValue = DateUtil.formartDateStrToTarget(date, "yyyyMMdd", "yyyy-MM-dd");
        } else {
            paramvalueDBModel.fsParamValue = date;
        }
        RunTimeLog.addLog(RunTimeLog.BUSINESS_DATE_NEW, "日切：shopId " + shopID + ",当前系统时间： " + DateTimeUtil.getTime(System.currentTimeMillis()));
        RunTimeLog.addLog(RunTimeLog.BUSINESS_DATE_NEW, "日切：shopId " + shopID + ",new date DateUtil.getCurrentDate(\"yyyy-MM-dd\")：" + paramvalueDBModel.fsParamValue);
        paramvalueDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        paramvalueDBModel.lver++;
        paramvalueDBModel.replaceNoTrans();
    }

    public static String getHistoryBusineeDate(String shopID) {
        String lastDate = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbParamValue where fsParamId = '001' and fsShopGUID =(select value from meta where key='104')");
        if (!TextUtils.isEmpty(lastDate) && !lastDate.contains("-")) {
            lastDate = DateUtil.formartDateStrToTarget(lastDate, "yyyyMMdd", "yyyy-MM-dd");
        }
        if (APPConfig.isCasiher()) {
            lastDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        }
        return lastDate;
    }

    /**
     * 获取一个可用于灾备的站点，要求如下：
     * 1，非业务中心
     * 2，已被绑定
     * 3，不是云收银等三个保留站点
     * 4，按照fihostcls降序查询
     *
     * @return String | 可用的站点ID
     */
    public static String getPaySiteForBack() {
        String sqlHostExist = "select fsHostId from tbHost where fsHostId not in ('cloudsite','localhost','mealorder') and fsHostId<>(select value from meta where key='802') and fiStatus='1' and fsShopGuid=(select value from meta where key='104') and fsHostId in(select hostid from host_status where bind_status='1') order by fihostcls desc";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlHostExist);
    }

    /**
     * 解除绑定的站点 仅限业务中心操作
     * 清除绑定信息 设置绑定状态为0
     *
     * @param hostid
     */
    public static void relieveBind(String hostid) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set bind_status = '0'  where  hostid='" + hostid + "'");
    }

    public static ShopDBModel getShopInfo() {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select fsShopGUID,fsShopName,fsCompanyGUID,fiShopKind from tbShop", ShopDBModel.class);
    }

    public static String getShopID() {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGUID from tbShop");
    }

    public static String getCompanyGUID() {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbShop");
    }

    public static int queryWorkMode() {
        return StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiWorkMode from tbShop"), -1);

    }


    /**
     * 将所有站点设置为未绑定
     */
    public static void clearAllHostBindStatus() {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set bind_status='0',biz_status='3'");
    }

    /**
     * 修改站点绑定打印机名称
     *
     * @param hostId      站点id
     * @param name        打印机名称
     * @param userDBModel 操作人
     */
    public static void updatePrinterName(String hostId, String name, UserDBModel userDBModel) {
        HostDBModel hostDBModel = queryById(hostId);
        if (hostDBModel != null) {
            hostDBModel.fsPrinterName = name;
            hostDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            hostDBModel.sync = 1;
            if (userDBModel != null) {
                hostDBModel.fsUpdateUserId = userDBModel.fsUpdateUserId;
                hostDBModel.fsUpdateUserName = userDBModel.fsUserName;
            }
            hostDBModel.replaceNoTrans();
        }

    }

    public static HostDBModel queryById(String fsHostId) {
        String sql = "select * from tbhost where fsHostId='" + fsHostId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, HostDBModel.class);
    }

    public static HostDBModel queryByPrinterName(String fsPrinterName) {
        String sql = "select * from tbhost where fiStatus=1 and fsPrinterName='" + fsPrinterName + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, HostDBModel.class);
    }

    /**
     * 变更站点需要拉取所有数据
     */
    public static void updateHostPullAll() {
        String sql = "UPDATE host_status SET sync_flag = 1";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 变更指定站点只需要拉取增量数据
     *
     * @param fsHostId
     */
    public static void updateHostPullIncrement(String fsHostId) {
        String sql = "UPDATE host_status SET sync_flag = 0 WHERE hostid = '" + fsHostId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 站点是否需要拉取全部数据
     *
     * @param fsHostId
     * @return
     */
    public static boolean needSyncAll(String fsHostId) {
        String sql = "SELECT sync_flag FROM host_status WHERE hostid = '" + fsHostId + "'";
        return TextUtils.equals(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), "1");
    }

    /**
     * 排队登录
     *
     * @param deviceId 设备id
     * @return String | token授权码
     */
    public static String loginQueue(String deviceId) {
        String session = generateSession();
        CacheModel model = new CacheModel();
        model.type = IOCache.TYPE_QUEUE_LOGIN;
        model.key = deviceId;
        model.value = session;
        model.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        model.updatetime = model.createtime;
        model.replaceNoTrans();
        return session;
    }

    public static String getQueueByDeviceId(final String deviceId) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT value FROM datacache WHERE type = '" + IOCache.TYPE_QUEUE_LOGIN + "' AND key = '" + deviceId + "'");

    }

    /**
     * 是否使用 kds 智能算法
     *
     * @param fsHostId String | 站点id
     * @return
     */
    public static boolean useKdsAlgorithm(String fsHostId) {
        if (!DBOrderConfig.useKdsService()) {
            RunTimeLog.addLog(RunTimeLog.KDS_CONFIG, "KDS 服务关闭, 不使用 KDS 智能算法");
            return false;
        }
        HostDBModel model = queryById(fsHostId);
        if (model == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_CONFIG, "站点[" + fsHostId + "]校验失败，不使用 KDS 智能算法");
            return false;
        }
        boolean result = model.fiIsEnableKDS == 1;
        RunTimeLog.addLog(RunTimeLog.KDS_CONFIG, "站点[" + fsHostId + "]" + (result ? "启用" : "关闭") + " KDS 智能算法");
        return result;
    }

    /**
     * 根据站点id获取设备id
     *
     * @param hostId 站点id
     * @return 设备id
     */
    public static String getDeviceIdByHostId(String hostId) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select device from host_status where hostid = '" + hostId + "'");
    }
}
