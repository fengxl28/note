package com.mwee.android.pos.connect.component.udp;

import com.mwee.android.pos.udp.UDPConfig;
import com.mwee.android.pos.udp.UDPReceiver;

/**
 * Created by virgil on 2016/10/31.
 */

public class UDPReceiverServer extends UDPReceiver {
    private final static UDPReceiverServer instance = new UDPReceiverServer();

    private UDPReceiverServer() {
        setPort();
    }

    public static UDPReceiverServer getInstance() {
        return instance;
    }

    @Override
    public void setPort() {
        setPort(UDPConfig.PORT_CENTER);
    }

    @Override
    public void callRetry() {

    }
}