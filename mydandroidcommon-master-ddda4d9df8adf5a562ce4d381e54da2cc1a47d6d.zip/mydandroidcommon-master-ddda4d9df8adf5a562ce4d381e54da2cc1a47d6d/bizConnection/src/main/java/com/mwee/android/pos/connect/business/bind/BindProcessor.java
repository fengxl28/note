package com.mwee.android.pos.connect.business.bind;

import android.text.TextUtils;

import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;

/**
 * 绑定的工具类
 * Created by virgil on 16/9/5.
 *
 * @author virgil
 */
public class BindProcessor {


    /**
     * 是否已激活
     *
     * @return boolean | true：已激活；false：未激活
     */
    public static boolean isActived() {
        String shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        String token = DBMetaUtil.getSettingsValueByKey(META.TOKEN);
        String seed = DBMetaUtil.getSettingsValueByKey(META.SEED);
        return !TextUtils.isEmpty(shopid) && !TextUtils.isEmpty(token) && !TextUtils.isEmpty(seed);
    }

    public static void setCurrentHostAsMain(boolean asMain) {
        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, asMain ? 1 : 0);
    }

    /**
     * 当前站点是否是主站点
     *
     * @return boolean | true:是主站点;false:不是主站点
     */
    public static boolean isCurrentHostMain() {
        String isMain = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST);
        return TextUtils.equals("1", isMain);
    }

}
