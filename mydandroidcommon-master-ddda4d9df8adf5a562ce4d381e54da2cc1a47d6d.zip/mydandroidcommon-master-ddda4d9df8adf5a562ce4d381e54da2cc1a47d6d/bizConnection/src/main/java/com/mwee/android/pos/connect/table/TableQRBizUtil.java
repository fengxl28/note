package com.mwee.android.pos.connect.table;

import android.text.TextUtils;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.datasync.net.GetTableQRShortLinkRequest;
import com.mwee.android.pos.component.datasync.net.GetTableQRShortLinkResponse;
import com.mwee.android.pos.component.datasync.net.TableQRBiznessModel;
import com.mwee.android.pos.component.datasync.net.model.TasbleQRSortLinkMode;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by liuxiuxiu on 2017/8/3.
 */

public class TableQRBizUtil {

    /**
     * 生成桌台码
     *
     * @param tableId 桌台ID
     * @return
     */
    public static TableQRBiznessModel createTableQRBiznessModel(String tableId) {
        if (TextUtils.isEmpty(tableId)) {
            return null;
        }

        String tableName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableName from tbmtable where fsmtableId = '" + tableId + "'");
        String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

        if (TextUtils.isEmpty(shopId) || TextUtils.isEmpty(tableName)) {
            return null;
        }

        TableQRBiznessModel tableQRBiznessModel = new TableQRBiznessModel();
        tableQRBiznessModel.shopId = shopId;
        tableQRBiznessModel.tableId = tableId;
        tableQRBiznessModel.tableName = tableName;
        tableQRBiznessModel.generateNewRapidQR();
        return tableQRBiznessModel;

    }

    /**
     * 获取桌台码对应的短链接
     *
     * @param tableQR 桌台码
     */
    public static void requestTableQRShortLink(String tableQR, final IResponse<String> iResponse) {
        GetTableQRShortLinkRequest getTableQRShortLinkRequest = new GetTableQRShortLinkRequest();
        getTableQRShortLinkRequest.url = tableQR;
        BusinessExecutor.execute(getTableQRShortLinkRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof GetTableQRShortLinkResponse) {
                    GetTableQRShortLinkResponse getDataResponse = (GetTableQRShortLinkResponse) responseData.responseBean;
                    TasbleQRSortLinkMode model = getDataResponse.data;
                    if (model != null && model.result != null && !TextUtils.isEmpty(model.result.url_short)) {
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", model.result.url_short);
                        }
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }


}
