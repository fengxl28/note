package com.mwee.android.pos.connect.business;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.NetResultType;
import com.mwee.android.base.net.component.Result;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.DownloadNetOrderMappingRelationRequest;
import com.mwee.android.pos.component.datasync.net.DownloadNetOrderMappingRelationResponse;
import com.mwee.android.pos.component.datasync.net.DownloadPageRequest;
import com.mwee.android.pos.component.datasync.net.DownloadPageResponse;
import com.mwee.android.pos.component.datasync.net.DownloadTableCountRequest;
import com.mwee.android.pos.component.datasync.net.DownloadTableCountResponse;
import com.mwee.android.pos.component.datasync.net.GetDataRequest;
import com.mwee.android.pos.component.datasync.net.GetDataResponse;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.ICallback;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ProgressCalcUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 同步云端配置的工具类
 * Created by virgil on 16/8/16.
 */
public class DownLoadDataProcessor {

    public static String tag = "DownLoadDataProcessor";

    public static int LIMIT = 500;// 大小表记录数界限
    public static int TABLE_NUM = 5;// 一次性最多下载小表数
    public static int PAGE_SIZE = 1000;// 单表每页下载数
    private static final int ERROR_TIMEOUT = -666;
    private static final int RETRY_COUNT = 3;// 出现{"errmsg":"mpos-api-shop is unavailable: connect timed out","errno":-666}时重试次数
    private static int curRetryCount = 0;// 当前重试次数

    private static int totalDataCount, curDataCount; // 用来计算进度百分比

    public static String sendGetData(IExecutorCallback callback) {

        GetDataRequest getDataRequest = new GetDataRequest();

        getDataRequest.tag = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        if (TextUtils.isEmpty(getDataRequest.tag) || TextUtils.equals("null", getDataRequest.tag)) {
            getDataRequest.tag = "-1";
        }
        return BusinessExecutor.execute(getDataRequest, callback, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    if (responseData.responseBean != null) {
                        if (responseData.responseBean instanceof GetDataResponse) {
                            GetDataResponse getDataResponse = (GetDataResponse) responseData.responseBean;
                            WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, getDataResponse.data, getDataResponse.tag);
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                } catch (Error e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.DOWNLOAD_EXCEPTION, "下载数据接口异常 msg = " + responseData.resultMessage);
                return false;
            }
        }, true);

    }

    private static boolean isSingleTable(String tbName) {
        return !tbName.contains(",");
    }

    public static void downloadTables(String tbName, String updateTime, IExecutorCallback callback, boolean updateSyncTime) {
        if (tbName == null || tbName.isEmpty()) {
            return;
        }
        downloadTablesPage(tbName, updateTime, callback);
    }

    /**
     * 下载表
     *
     * @param isSingleTb    是否为单个表
     * @param tbName        表名，多个表以逗号隔开
     * @param page          要下载的页码
     * @param updateTime    更新时间
     * @param excludeStatus 排除的状态，1:启用,9:禁用,13:删除；（不传则查询所有状态）
     * @param progressCb    进度回调
     */
    private static SocketResponse download(boolean isSingleTb, String tbName, int page, String updateTime, String excludeStatus, IProgressCallback progressCb) {
        long start = System.currentTimeMillis();
        SocketResponse response = new SocketResponse();
        if (TextUtils.isEmpty(tbName)) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.buildMessage();
            return response;
        }
        DownloadPageRequest request = new DownloadPageRequest(tbName);
        request.updatetime = updateTime;
        if (page > 0) {
            request.pageNum = page + "";
        } else {
            request.pageNum = "1";
        }
        request.pageSize = PAGE_SIZE + "";
        if (!TextUtils.isEmpty(excludeStatus)) {
            request.excludeStatus = excludeStatus;
        }
        BusinessCallback businessCallback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    DownloadPageResponse responseBean = (DownloadPageResponse) responseData.responseBean;
                    int totalPage = 0;
                    JSONObject data = responseBean.data;
                    if (isSingleTb) { // 单个表，有分页
                        if (data.containsKey("pages")) {
                            totalPage = data.getInteger("pages");
                        }
                        if (data.containsKey("list")) {
                            JSONObject ob = new JSONObject();
                            ob.put(tbName, data.get("list"));
                            WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, ob, null);
                            onProgress(progressCb, data.getJSONArray("list").size());
                        }
                    } else {// 多个表，无分页
                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, data, null);
                    }
                    response.code = SocketResultCode.SUCCESS;
                    response.data = totalPage;
                    return true;
                } catch (Exception e) {
                    LogUtil.logError(e);
                    response.code = SocketResultCode.EXCEPTION;
                    response.message = "数据解析异常";
                } catch (Error e) {
                    LogUtil.logError(e);
                    response.code = SocketResultCode.EXCEPTION;
                    response.message = "数据解析异常";
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                LogUtil.logNET(tag, "下载[" + tbName + "]失败：" + JSON.toJSONString(responseData));
                response.code = responseData.result;
                response.message = responseData.resultMessage;
                if (responseData.responseBean != null && responseData.responseBean.errno == ERROR_TIMEOUT) {
                    response.code = ERROR_TIMEOUT;
                    response.message = responseData.responseBean.errmsg;
                }
                return false;
            }
        };
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
        response.buildMessage();
        long end = System.currentTimeMillis();
        LogUtil.log("download duration: " + ((end - start) / 1000));
        return response;
    }

    /**
     * 针对 connect timed out 做重试
     */
    private static SocketResponse downloadTables(boolean isSingleTb, String tbName, int page, String updateTime, String excludeStatus, IExecutorCallback callback, IProgressCallback progressCb) {
        SocketResponse response = download(isSingleTb, tbName, page, updateTime, excludeStatus, progressCb);
        if (response.success()) {
            curRetryCount = 0;
        } else {
            // 出现{"errmsg":"mpos-api-shop is unavailable: connect timed out","errno":-666}时重试
            if (response.code == -666) {
                if (curRetryCount < RETRY_COUNT) {
                    curRetryCount++;
                    return downloadTables(isSingleTb, tbName, page, updateTime, excludeStatus, callback, progressCb);
                }
            }
            ResponseData responseData = new ResponseData();
            responseData.result = response.code;
            responseData.resultMessage = response.message;
            onFailed(responseData, callback);
        }
        return response;
    }

    private static boolean downloadTablesPage(String tbName, String updateTime, IExecutorCallback callback) {
        return downloadTablesPage(tbName, updateTime, "", callback, null);
    }

    /**
     * 下载表，多表和单表都走这里
     *
     * @param tbName        表名，多个表以","分隔
     * @param updateTime    更新时间
     * @param callback      回调
     * @param excludeStatus 排除的状态
     * @param progressCb    进度回调
     * @return true则成功
     */
    private static boolean downloadTablesPage(String tbName, String updateTime, String excludeStatus, IExecutorCallback callback, IProgressCallback progressCb) {
        boolean isSingleTable = isSingleTable(tbName);
        // 下载第一页数据
        SocketResponse response = downloadTables(isSingleTable, tbName, 1, updateTime, excludeStatus, callback, progressCb);
        if (response.success()) {
            // 如果是单个表，且不止1页，继续从第2页下载
            if (isSingleTable) {
                int totalPage = (Integer) response.data;
                if (totalPage > 1) {

                    for (int i = 2; i <= totalPage; i++) {
                        SocketResponse res = downloadTables(true, tbName, i, updateTime, excludeStatus, callback, progressCb);
                        if (!res.success()) {

                            return false;
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static String downloadData(IExecutorCallback callback) {
        return downloadData(callback, null, "");
    }

    public static String downloadData(IExecutorCallback callback, IProgressCallback progressCB, String excludeStatus) {
        return downloadData(callback, progressCB, excludeStatus, null);
    }

    /**
     * 下载云端数据
     *
     * @param callback
     * @param excludeStatus 需要排除的状态 针对fistatus字段
     * @return
     */
    public static String downloadData(IExecutorCallback callback, IProgressCallback progressCB, String excludeStatus, ICallback<List<String>> businessCallback) {
        totalDataCount = 0;
        curDataCount = 0;

        DownloadTableCountRequest tbCountRequest = new DownloadTableCountRequest();
        tbCountRequest.updatetime = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        if (!TextUtils.isEmpty(excludeStatus)) {
            tbCountRequest.excludeStatus = excludeStatus;
        }

        BusinessCallback bizCallback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData == null || responseData.responseBean == null) {
                    return false;
                }
                try {
                    DownloadTableCountResponse responseBean = (DownloadTableCountResponse) responseData.responseBean;
                    JSONObject data = responseBean.data;

                    List<String> modifiedTbList = DBMetaUtil.getModifiedTbList();
                    List<String> smallTb = new ArrayList<>();
                    List<String> largeTb = new ArrayList<>();
                    if (data != null && data.size() > 0) {
                        // 区分大小表
                        for (String key : data.keySet()) {
                            int value = Integer.parseInt(data.getString(key));
                            if (TextUtils.isEmpty(key) || value == 0 || modifiedTbList.contains(key)) {
                                continue;
                            }
                            totalDataCount += value;
                            if (value <= LIMIT) {
                                smallTb.add(key);
                            } else {
                                largeTb.add(key);
                            }
                        }
                    }

                    onProgress(progressCB, 0);

                    if (data == null) {
                        return false;
                    }

                    boolean download = true;
                    LogUtil.log(tag, ">>> downloadData smallTb: " + smallTb + "\nlargeTb: " + largeTb);
                    if (smallTb.size() > 0) {
                        // download together
                        StringBuilder sb = new StringBuilder();
                        int circle = 1;
                        int circleDataCount = 0;
                        for (int j = 0; j < smallTb.size(); j++) {
                            String tb = smallTb.get(j);
                            sb.append(tb).append(",");
                            circleDataCount += data.getInteger(tb);
                            if (j == smallTb.size() - 1 || j == TABLE_NUM * circle - 1) {
                                String tbName = sb.substring(0, sb.length() - 1);
                                LogUtil.logBusiness(tag, "downloadData：will download these small tables together: " + tbName);
                                download = downloadTablesPage(tbName, tbCountRequest.updatetime, excludeStatus, callback, progressCB);
                                if (!download) {
                                    break;
                                }
                                onProgress(progressCB, circleDataCount);
                                sb.delete(0, sb.length());
                                circle++;
                                circleDataCount = 0;
                            }
                        }
                    }
                    if (largeTb.size() > 0 && download) {
                        // download one by one
                        for (String tb : largeTb) {
                            LogUtil.logBusiness(tag, "downloadData：will download this large tables: " + tb);
                            download = downloadTablesPage(tb, tbCountRequest.updatetime, excludeStatus, callback, progressCB);
                            if (!download) {
                                break;
                            }
                        }
                    }

                    if (download) {
                        download = forceDownload(modifiedTbList, callback, progressCB);
                    }

                    if (download) {
                        download = forceDownloadNetOrderMappingRelation(tbCountRequest.updatetime, callback, progressCB);
                    }


                    LogUtil.logBusiness(tag, "downloadData 下载数据状态：" + download + " 时间：" + tbCountRequest.updatetime);
                    if (download) {
                        RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, tag + "下载数据成功！");
                        LogUtil.logBusiness(tag, "downloadData 下载数据成功 时间：" + tbCountRequest.updatetime);
                        curDataCount = totalDataCount;
                        onProgress(progressCB, 0);
                        updateSyncTime(responseBean.tag);
                        ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                        if (callback != null) {
                            callback.success(responseData);
                        }
                        if (businessCallback != null) {
                            List<String> modified = new ArrayList<>();
                            if (!ListUtil.isEmpty(modifiedTbList)) {
                                modified.addAll(modifiedTbList);
                            }
                            if (!ListUtil.isEmpty(smallTb)) {
                                modified.addAll(smallTb);
                            }
                            if (!ListUtil.isEmpty(largeTb)) {
                                modified.addAll(largeTb);
                            }
                            businessCallback.onSuccess(modified);
                        }
                    }else {
                        if (businessCallback != null) {
                            businessCallback.onFailure(-1, "下载数据失败，请重试");
                        }
                    }
                    return true;
                } catch (Exception e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                    onFailed(responseData, callback);
                } catch (Error e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                    onFailed(responseData, callback);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                LogUtil.logBusiness(tag, "downloadData 下载数据失败 msg = " + responseData.resultMessage);
                onFailed(responseData, callback);
                return false;
            }
        };

        IExecutorCallback iExecutorCallback = new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        };
        return BusinessExecutor.execute(tbCountRequest, iExecutorCallback, bizCallback, false);
    }

    /**
     * 强制下载美团外卖映射关系表
     */
    private static boolean forceDownloadNetOrderMappingRelation(String timeTag, IExecutorCallback callback, IProgressCallback progressCB) {
        final boolean[] result = {true};

        // 这里无法统计要下载的表的记录数，默认一张表50
        totalDataCount += 50;
        LogUtil.logBusiness(tag, "downloadModifiedTbs：will download this modified tables: tbNetorderItemMappingRelationship");

        DownloadNetOrderMappingRelationRequest downloadNetOrderMappingRelationRequest = new DownloadNetOrderMappingRelationRequest();
        if (TextUtils.isEmpty(timeTag)) {
            downloadNetOrderMappingRelationRequest.searchTime = "0";
        } else {
            downloadNetOrderMappingRelationRequest.searchTime = timeTag;
        }

        BusinessExecutor.execute(downloadNetOrderMappingRelationRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    DownloadNetOrderMappingRelationResponse responseBean = (DownloadNetOrderMappingRelationResponse) responseData.responseBean;
                    JSONObject ob = new JSONObject();
                    ob.put("tbNetorderItemMappingRelationship", responseBean.data.get("tbNetorderItemMappingRelationship"));
                    WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, ob, null);
                } catch (Exception e) {
                    LogUtil.logError("tbNetorderItemMappingRelationship表下载数据异常：", e);
                    result[0] = false;
                    onFailed(responseData, callback);
                }

                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                result[0] = false;
                onFailed(responseData, callback);
                return false;
            }
        }, false);

        if (result[0]) {
            onProgress(progressCB, 50);
        }

        return result[0];

    }

    /**
     * 强制下载某些表
     */
    private static boolean forceDownload(List<String> tbList, IExecutorCallback callback, IProgressCallback progressCB) {
        return downloadModifiedTbs(tbList, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(tag, "downloadModifiedTbs 下载数据失败 msg = " + responseData.resultMessage);
                onFailed(responseData, callback);
                return false;
            }
        }, progressCB);
    }

    private static boolean downloadModifiedTbs(List<String> tbList, IExecutorCallback callback, IProgressCallback progressCB) {
        boolean result = true;
        LogUtil.log("downloadData: getModifiedTbNames: " + tbList);
        if (ListUtil.isEmpty(tbList)) {
            return true;
        }

        // 2. HostStatus 状态变更
        HostUtil.updateHostPullAll();

        // 这里无法统计要下载的表的记录数，默认一张表50
        totalDataCount += tbList.size() * 50;
        for (String tb : tbList) {
            if (tb == null || tb.isEmpty() || tb.toLowerCase().startsWith("tbsell")) {
                continue;
            }
            LogUtil.logBusiness(tag, "downloadModifiedTbs：will download this modified tables: " + tb);
            result = downloadTablesPage(tb, "0", callback);
            if (!result) {
                break;
            }
            onProgress(progressCB, 50);
        }
        // 全部下载成功，清除ModifiedTb
        if (result) {
            DBMetaUtil.clearModifiedTbNames();
        }
        return result;
    }

    private static void onProgress(IProgressCallback progressCB, int step) {
        if (progressCB != null) {
            progressCB.onProgress(calcProgress(step), IProgressCallback.TAG_DOWNLOAD_DATA);
        }
    }

    private static int calcProgress(int step) {
        curDataCount += step;
        return ProgressCalcUtil.calcProgress(totalDataCount, curDataCount);
    }

    private static void onFailed(ResponseData responseData, IExecutorCallback callback) {
        if (callback != null) {
            callback.fail(responseData);
        }
    }

    private static boolean isUpdateTimeValid(String updateTime) {
        return !TextUtils.isEmpty(updateTime) && !TextUtils.equals("0", updateTime);
    }

    public static void updateSyncTime(String syncTime) {
        // 上次更新云端数据时间
        DBMetaUtil.updateSettingsValueByKey(META.DATA_SYNC_TIME, syncTime);
        // 业务中心最后修改时间
        DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, syncTime);
    }
}
