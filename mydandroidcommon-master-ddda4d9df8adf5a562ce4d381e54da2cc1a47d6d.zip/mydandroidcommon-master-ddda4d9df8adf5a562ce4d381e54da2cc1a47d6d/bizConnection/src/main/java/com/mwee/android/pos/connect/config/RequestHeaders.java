package com.mwee.android.pos.connect.config;

/**
 * @ClassName: RequestHeaders
 * @Description: 请求头key
 * @author: SugarT
 * @date: 16/8/16 上午10:46
 */
public class RequestHeaders {

    /**
     * 连接的APP类型
     */
    public static final String HEADER_APPTYPE = "X-mwee-AppType";
    /**
     * 数据库版本号
     */
    public static final String HEADER_DBVERSION = "X-mwee-DBVersion";
    /**
     * 时间戳
     */
    public static final String HEADER_TIMESTAMP = "X-mwee-Timestamp";
    /**
     * api version(客户端API version 低于server,请求将被拒绝)
     */
    public static final String HEADER_APIVERSION = "X-mwee-ApiVersion";
    public static final String HEADER_REQUEST_ID = "X-mwee-RequestID";

}
