package com.mwee.android.posprint.business.device;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintResult;


/**
 * DeviceCommandProcessor
 * Created by virgil on 16/8/11.
 */
@SuppressWarnings("unused")
public class DeviceCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "device";

    @DrivenMethod(uri = DRIVER_TAG + "/openmoneybox")
    public static PrintResult processPreBill(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addKickDrawer();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
