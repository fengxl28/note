package com.mwee.android.posprint.conn;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.MydLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.GetPrintTaskResponse;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.ICallBack;
import com.mwee.android.posmodel.client.ClientConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posprint.IDinnerPrintInterface;
import com.mwee.android.posprint.business.P433Util;
import com.mwee.android.posprint.framework.PrintApplication;
import com.mwee.android.posprint.queue.PrintLock;
import com.mwee.android.posprint.queue.TaskDBUtil;
import com.mwee.android.posprint.task.PrintInfoCollect;
import com.mwee.android.posprint.task.PrintTaskDetailModel;
import com.mwee.android.print.printer.P433Printer.P433SerialManager;
import com.mwee.android.print.printer.P433Printer.components.SearchResultListener;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * PrintStub
 * Created by virgil on 16/7/5.
 */
public class PrintStub extends IDinnerPrintInterface.Stub {

    private HandlerThread sThread;
    private Handler sHandler;
    private static final int PRINT = 10001;
    private static final int SYNC_PRINT = 10002;
    private static final int STOP_EXIT = 10003;
    private static final int GET_PRINT_TASK = 10004;

    public PrintStub() {
        LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_----------");
        initHandler();
    }

    @Override
    public void cleanOrder() throws RemoteException {
        new LowThread(new Runnable() {
            @Override
            public void run() {
                DBManager.getInstance().executeInTransaction(new IDBOperate<Boolean>() {
                    @Override
                    public Boolean doJob(SQLiteDatabase db) {
                        db.execSQL("delete from tbPrintTask");
                        return true;
                    }
                });
            }
        }).start();
    }

    @Override
    public void processTask(final String task) throws RemoteException {
//        LogUtil.logBusiness("-----进入打印服务 processTask ----");
//        TaskDBUtil.receiveNewTask(task);

        LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_------printSyncTask----");
        if (sThread == null) {
            initHandler();
        }

        if (sHandler != null) {
            sHandler.sendMessage(sHandler.obtainMessage(PRINT, task));
        }
    }

    private void initHandler() {
        sThread = new HandlerThread("PrintStubThread_" + SystemClock.elapsedRealtime()) {
            @Override
            protected void onLooperPrepared() {
                super.onLooperPrepared();
                sHandler = new Handler(Looper.myLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        super.handleMessage(msg);

//                        long time = System.currentTimeMillis();

                        switch (msg.what) {
                            case PRINT:
                                if (msg.obj != null) {
                                    String content = (String) msg.obj;
                                    TaskDBUtil.receiveNewTask(content);

//                                    time = System.currentTimeMillis() - time;
//                                    final PrintTaskDBModel taskModel = JSON.parseObject(content, PrintTaskDBModel.class);
//                                    LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_------printSyncTask----PrintNo:" +
//                                            taskModel.fiPrintNo + "--what:" + SYNC_PRINT + "-----结束--receiveNewTask--cost:" + time);
                                }
                                break;
                            case SYNC_PRINT:
                                if (msg.obj != null) {
                                    String content = (String) msg.obj;
                                    PrintTaskDBModel taskModel = JSON.parseObject(content, PrintTaskDBModel.class);
                                    receiveTaskFromCenter(taskModel);

//                                    time = System.currentTimeMillis() - time;
//                                    LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_------printSyncTask----PrintNo:" +
//                                            taskModel.fiPrintNo + "--what:" + SYNC_PRINT + "-----结束--receiveTaskFromCenter--cost:" + time);
                                }
                                break;
                            case GET_PRINT_TASK:
                                HostPrintTask task = (HostPrintTask) msg.obj;
                                List<Integer> printNoList = task.getPrintNoList();
                                String hostID = task.getHostID();

                                getPrintTaskFromCenter(printNoList, hostID, msg.arg1);
                                break;
                            case STOP_EXIT:
                                removeCallbacksAndMessages(null);
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                                    quitSafely();
                                } else {
                                    quit();
                                }
                                break;
                            default:
                                break;
                        }
                    }
                };
            }
        };
        sThread.start();
    }

    /**
     * 处理从业务中心收到的打印任务
     *
     * @param taskModel PrintTaskDBModel
     */
    public void receiveTaskFromCenter(PrintTaskDBModel taskModel) {
        PrintLock.getSingleton().doLock(taskModel.fiPrintNo, taskModel.fsHostId, "开始加锁-处理从业务中心收到的打印任务-receiveTaskFromCenter");
        try {
            String printNo = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select fiPrintNo from tbPrintTask where fiPrintNo='" + taskModel.fiPrintNo + "' and fsHostID='" + taskModel.fsHostId + "'");
            if (TextUtils.isEmpty(printNo)) {
                taskModel.replaceNoTrans();
                LogUtil.logOnlineDebug("----打印任务写入结束----PrintNo:" + printNo);
            }
        } finally {
            PrintLock.getSingleton().unLock(taskModel.fiPrintNo, taskModel.fsHostId, "开始解锁-处理从业务中心收到的打印任务-receiveTaskFromCenter");
        }
        TaskDBUtil.preparePrint(taskModel);
    }

    /**
     * 处理从业务中心收到的打印任务
     *
     * @param task String
     * @throws RemoteException
     */
    @Override
    public void printSyncTask(final String task) throws RemoteException {

//        final PrintTaskDBModel taskModel = JSON.parseObject(task, PrintTaskDBModel.class);
//        LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_------printSyncTask----PrintNo:" +
//                taskModel.fiPrintNo + "--what:" + SYNC_PRINT);


//        final PrintTaskDBModel taskModel = JSON.parseObject(task, PrintTaskDBModel.class);
//        receiveTaskFromCenter(taskModel);
        if (sThread == null) {
            initHandler();
        }

        if (sHandler != null) {
            sHandler.sendMessage(sHandler.obtainMessage(SYNC_PRINT, task));
        }
    }


    @Override
    public void killingProcess() throws RemoteException {
        APPConfig.closeAllDBInstance();
        AliHotFix.killSelf();
        LogUtil.logOnlineDebug("---------PrintStub----PrintStubThread_------killingProcess----");
        if (sHandler != null) {
            sHandler.sendMessage(sHandler.obtainMessage(STOP_EXIT, null));
        }
    }

    @Override
    public void optTask(final String nolist, final String hostID) {
        if (TextUtils.isEmpty(nolist) || TextUtils.isEmpty(hostID)) {
            LogUtil.log("PrintStub optTask nolist=" + nolist + ",hostID=" + hostID);
            return;
        }
        //此处去重
        final List<Integer> printNoList = JSON.parseArray(nolist, Integer.class);
        for (int i = 0; i < printNoList.size(); i++) {
            Integer temp = printNoList.get(i);
            String printNo = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select fiPrintNo from tbPrintTask where fiPrintNo='" + temp + "' and fsHostID='" + hostID + "'");
            if (!TextUtils.isEmpty(printNo)) {
                printNoList.remove(i);
                i--;
            }
        }
        if (ListUtil.isEmpty(printNoList)) {
            return;
        }
        //2秒钟后进行获取
        if (sHandler != null) {
            HostPrintTask hostPrintTask = new HostPrintTask();
            hostPrintTask.setHostID(hostID);
            hostPrintTask.setPrintNoList(printNoList);

            sHandler.sendMessageDelayed(sHandler.obtainMessage(GET_PRINT_TASK, 0, 0, hostPrintTask),
                    2000);
        }
//        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                getPrintTaskFromCenter(printNoList, hostID, 0);
//            }
//        }, 2000);

    }

    private void getPrintTaskFromCenter(final List<Integer> printNoList, final String hostID, final int retry) {
        if (retry > 20) {//为了持续五分钟
            return;
        }
        LogUtil.logBusiness("----getPrintTaskFromCenter----hostID:" + hostID + "--retry--" + retry);

        MCon.c(CPrint.class, null, new SocketThreadCallback<GetPrintTaskResponse>() {
            @Override
            public void callback(SocketResponse<GetPrintTaskResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    if (socketResponse.data != null && !ListUtil.isEmpty(socketResponse.data.printTaskDBModelList)) {
                        for (PrintTaskDBModel task : socketResponse.data.printTaskDBModelList) {
                            receiveTaskFromCenter(task);
                        }
                    }
                } else {
                    PrintApplication.refershConnect();

                    if (sHandler != null) {
                        HostPrintTask hostPrintTask = new HostPrintTask();
                        hostPrintTask.setHostID(hostID);
                        hostPrintTask.setPrintNoList(printNoList);

                        sHandler.sendMessageDelayed(sHandler.obtainMessage(GET_PRINT_TASK, retry + 1,
                                0, hostPrintTask), 3000 * (retry + 1));
                    }

                    //获取失败，则每隔3秒进行重试
//                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            getPrintTaskFromCenter(printNoList, hostID, retry + 1);
//                        }
//                    }, 3000 * (retry + 1));
                }
            }
        }).getPrintTaskRequest(printNoList, hostID);
    }

    @Override
    public void init() throws RemoteException {
        //重新初始化所有打印机实例
        PrintApplication.initAllPrinter();
        //刷新打印里的serverAddress
        PrintApplication.refershConnect();

        //刷新打印的设置
        refreshSetting();
        //刷新日志相关的配置
        MydLog.refreshConfig();
        //打印监控

        PrintInfoCollect.refreshConfig();
    }

    @Override
    public void refreshSetting() {
        String valueBbox = ClientMetaUtil.getSettingsValueByKey(META.XMPP_BBOX);
        LogUtil.setOnlineDebugMode("1".equals(valueBbox));
//        PrinterConfig.tscReservse = DBMetaUtil.isConfigOpen(META.TSC_REVERSE, "1", "0");
    }

    @Override
    public String getAllPrinter() {
        List<PrinterDBModel> printerDBModels = DBSimpleUtil.queryList(APPConfig.DB_CLIENT, "select * from tbPrinter where fiStatus='1'", PrinterDBModel.class);
        List<JSONObject> usbSymbolList = DBSimpleUtil.queryJsonList(APPConfig.DB_CLIENT, "select key,value from datacache where type='" + IOCache.TYPE_PRINTER_USB + "'");
        List<PrinterDBModel> result = new ArrayList<>();
        result.addAll(printerDBModels);
        if (!ListUtil.isEmpty(printerDBModels) && !ListUtil.isEmpty(usbSymbolList)) {
            for (int i = 0; i < printerDBModels.size(); i++) {
                PrinterDBModel temp = printerDBModels.get(i);
                for (int j = 0; j < usbSymbolList.size(); j++) {
                    JSONObject tempJ = usbSymbolList.get(j);
                    if (TextUtils.equals(temp.fsPrinterName, tempJ.getString("key"))) {
                        String value = tempJ.getString("value");
                        if (!TextUtils.isEmpty(value)) {
                            temp.fsStr1 = value;
                        }
                        usbSymbolList.remove(j);
                        printerDBModels.remove(i);
                        i--;
                        j--;

                    }
                }
            }
        }
        return JSON.toJSONString(result);
    }

    @Override
    public void selectUsbDevice(String printerName, String symbol) {
        CacheModel model = new CacheModel();
        model.key = printerName;
        model.value = symbol;
        model.type = IOCache.TYPE_PRINTER_USB;
        model.setDbName(APPConfig.DB_CLIENT);
        model.replaceNoTrans();
        PrintApplication.initAllPrinter();
    }

    @Override
    public void updateTask(final String fsHostId, final int printNo, final String hashMap) {
        final JSONObject value = JSON.parseObject(hashMap);
        DBManager.getInstance(APPConfig.DB_PRINT).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues();
                for (Map.Entry<String, Object> entry : value.entrySet()) {
                    values.put(entry.getKey(), (String) entry.getValue());
                }
                db.update("tbPrintTask", values, " fiPrintNo=" + printNo + " and fsHostId='" + fsHostId + "'", null);
                return null;
            }
        });
    }

    private Timer timer = new Timer();
    private RemoteCallbackList<ICallBack> icallbacks = new RemoteCallbackList<>();
    private ICallBack icallBack;


    /**
     * 发现P433打印机
     *
     * @return
     * @throws RemoteException
     */
    @Override
    public String findP433Printer(ICallBack callBack) throws RemoteException {
        this.icallBack = callBack;
        icallbacks.register(icallBack);
        int len = icallbacks.beginBroadcast();
        List<String> data = new ArrayList<>();
        P433SerialManager.getInstance().setSearchListen(new SearchResultListener() {
            @Override
            public void onSearched(List<String> searchedAddresses) {
                //LogUtil.log("p433", "findP433Printer -->调动--->" + JSON.toJSONString(searchedAddresses));
                if (ListUtil.isEmpty(searchedAddresses)) {
                    return;
                }
                data.clear();
                for (String address : searchedAddresses) {
                    data.add(address);
                }
                try {
                    // 以广播的方式进行客户端回调
                    //LogUtil.log("p433", "icallbacks.beginBroadcast() -->len"+len);
                    for (int i = 0; i < len; i++) {
                        icallbacks.getBroadcastItem(i).callback(JSON.toJSONString(data));
                    }
                } catch (Exception e) {
                    try {
                        cancelfindP433Printer();
                    } catch (RemoteException e1) {
                        e1.printStackTrace();
                    }
                    e.printStackTrace();
                }
            }

        });

        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                P433SerialManager.getInstance().sendSearchMessage();
            }
        }, 0, 1500);
        return null;
    }


    /**
     * 取消P433打印机
     *
     * @throws RemoteException
     */
    @Override
    public void cancelfindP433Printer() throws RemoteException {
        // 记得要关闭广播
        LogUtil.log("美易连", "cancelfindP433Printer()  -->PrintStub");
        //LogUtil.log("p433", "cancelfindP433Printer111 finishBroadcast  icallbacks.getRegisteredCallbackCount()" + icallbacks.getRegisteredCallbackCount());
        if (icallbacks != null && icallBack != null) {
            LogUtil.log("美易连", "cancelfindP433Printer finishBroadcast");
            icallbacks.finishBroadcast();
            icallbacks.unregister(icallBack);
            icallBack = null;

            //LogUtil.log("p433", "cancelfindP433Printer222 finishBroadcast  icallbacks.getRegisteredCallbackCount()" + icallbacks.getRegisteredCallbackCount());
        }
        //LogUtil.log("美易连", "cancelfindP433Printer   printBinder" + printBinder.toString());
        if (timer != null) {
            LogUtil.log("美易连", "cancelfindP433Printer cancel");
            timer.cancel();
            timer = null;
        }
    }

    @Override
    public void testP433Printer(String var, int address) throws RemoteException {
//        P433SerialManager.getInstance().sendTestPrint(var, address);
    }

    @Override
    public void checkP433Printer(String var, String address) throws RemoteException {
        P433SerialManager.getInstance().sendTestPrint(var, address);
    }

    @Override
    public void uploadP433Data(String var, String type) throws RemoteException {
        P433Util.getInstance().uploadP433Data();
    }

    /**
     * 打印任务发送异常，将失败原因上报
     *
     * @param taskDBModel
     * @param type
     * @throws RemoteException
     */
    @Override
    public void printTaskSendError(String taskDBModel, String type) throws RemoteException {
        PrintTaskDBModel taskModel = JSON.parseObject(taskDBModel, PrintTaskDBModel.class);
        if (taskDBModel == null) {
            RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印任务发送异常处理->taskModel=null：", taskDBModel);
            return;
        }
        taskModel.fiStatus = StringUtil.toInt(type, 3);
//        taskModel.fiPrintCount++;
        PrintTaskDetailModel detail = new PrintTaskDetailModel();
        detail.printNumber = taskModel.fiPrintCount;
        detail.status = taskModel.fiStatus;
        detail.time = DateUtil.getCurrentTime();
        detail.errorMsg = "打印失败！站点（" + taskModel.fsHostId + ")已离线，请检查网络或者重启该站点";
        List<PrintTaskDetailModel> array = JSON.parseArray(taskModel.fsTaskDetail, PrintTaskDetailModel.class);
        if (array == null) {
            array = new ArrayList<>();
        }
        array.add(detail);
        taskModel.fsTaskDetail = JSON.toJSONString(array);
        ContentValues values = new ContentValues();
        values.put("fiPrintCount", taskModel.fiPrintCount);
        values.put("fiStatus", taskModel.fiStatus);
        values.put("fsTaskDetail", taskModel.fsTaskDetail);
        TaskDBUtil.updateTask(taskModel, values);

        ClientConnector.getInstance().printError(taskModel.fsPrinterName + ":" + detail.errorMsg, taskModel.fiStatus);
    }

    @Override
    public boolean print433TestMsg(String content, String address) throws RemoteException {
        boolean printTestResult = P433SerialManager.getInstance().printTest(address, content);
        return printTestResult;
    }
}
