package com.mwee.android.posprint.task;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.infocollect.RemoteSocketClientProvider;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;

import cn.mwee.android.pay.infocollect.InfoCollect;
import cn.mwee.android.pay.infocollect.RuntimeInfoConfig;
import cn.mwee.android.pay.infocollect.source.remote.RemoteClientProvider;
import cn.mwee.android.pay.other.CommonKey;
import cn.mwee.android.pay.other.CommonRunInfoConfig;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/4/26
 */
public class PrintInfoCollect {
    private static RuntimeInfoConfig.DeviceStateInfo deviceStateInfo;

    public static void initInfoCollect() {
        RunTimeLog.addLog(RunTimeLog.INFO_COLLECT, "打印监控收集信息init");
        RemoteClientProvider clientProvider = new RemoteSocketClientProvider();
        deviceStateInfo = new RuntimeInfoConfig.DeviceStateInfo();

        refreshConfig();
        /**
         * 中控上的软件类型
         */
        String softType = "43";
        if (APPConfig.isMyd()) {
            softType = "43";
        } else if (APPConfig.isAir()) {
            softType = "57";
        } else if (APPConfig.isCasiher()) {
            softType = "63";
        } else if (APPConfig.isKdsClient()) {
            softType = "98";
        }
        deviceStateInfo.softType = softType;
        deviceStateInfo.type = CommonKey.Type.SOFT;
        deviceStateInfo.lan = DeviceUtil.getLocalIpAddress();
        RuntimeInfoConfig builder = new RuntimeInfoConfig.Builder()
                .enable(true)
                .clientMode(true)
                .setLimit(10)
                .setQueueCapacity(1)
                .setDeviceStateInfo(deviceStateInfo)
                .setInterval(60 * 3)
                .setRemoteParamProvider(new RuntimeInfoConfig.RemoteParamProvider() {
                    @Override
                    public String getToken() {
                        return "token";
                    }

                    @Override
                    public String getV() {
                        return "V7";
                    }

                    @Override
                    public String getHost() {
                        if (!BaseConfig.isProduct()) {
                            return "http://10.0.18.37:3050/";
                        }
                        return "http://b.mwee.cn/";
                    }
                })
                .setRemoteClientProvider(clientProvider)
                .setLogTree(new BizInfoCollect.TimberTree())
                .build();
        CommonRunInfoConfig.ENABLE = false;
        InfoCollect.getInstance().init(GlobalCache.getContext(), builder);
    }


    public static void refreshConfig() {
        String account = "";
        ParamvalueDBModel paramvalueDBModel = BizInfoCollect.getAccount(APPConfig.DB_CLIENT);
        if (paramvalueDBModel != null) {
            account = paramvalueDBModel.fsParamValue;
        }
        String id = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        deviceStateInfo.id = String.format("%s(%s)", account, id);
        LogUtil.log("打印站点ID--》" + deviceStateInfo.id);
    }

    /**
     * 结束上报任务
     */
    public static void destroy() {
        InfoCollect.destroy();
        deviceStateInfo = null;
    }
}
