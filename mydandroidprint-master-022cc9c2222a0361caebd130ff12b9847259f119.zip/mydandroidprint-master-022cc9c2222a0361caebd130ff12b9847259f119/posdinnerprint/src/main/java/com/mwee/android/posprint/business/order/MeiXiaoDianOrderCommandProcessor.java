package com.mwee.android.posprint.business.order;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.connect.business.print.SunMiV1PrinterInfo;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterCommand;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintStringUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.io.UnsupportedEncodingException;

/**
 * @author:luoshenghua create on:2019/1/9
 * description:美小店
 */
@SuppressWarnings("unused")
public class MeiXiaoDianOrderCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "meixiaodianOrder";

    /**
     * 制作单总单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/make")
    public static PrintResult processMake(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addCenterText(JsonUtil.getInfo(ob, "billSourceName", String.class) + "(总单)", 2, 0, "-");
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);

        String phone = JsonUtil.getInfo(sell, "fsCustMobile", String.class);
        if (!TextUtils.isEmpty(phone)) {
            if (phone.length() == 11) {
                phone = phone.substring(7, 11);
            }
            addBlankLine(config, billPrint);
            billPrint.addText("尾号" + phone + "的预订顾客已到店下单\n", 1, PrintDataItem.ALIGN_CENTRE, 0);
        }

        String orderType = "";
        String fillKind = JsonUtil.getInfo(sell, "fiBillKind", String.class);
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }

        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        String eatType = JsonUtil.getString(ob, "eatType");
        billPrint.addLeftBigWithRight("取餐号:",mealNumber,"类型:" + eatType);
        addBlankLine(config, billPrint);

        String eatTime = JsonUtil.getInfo(ob, "eatTime", String.class);
        if (!TextUtils.isEmpty(eatTime) && !(eatTime.contains("立即用餐") || eatTime.contains("尽早用餐"))) {
            billPrint.addText("用餐时间:" + eatTime + "\n", 2);
        }

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
            if (TextUtils.equals("2", fiOrderItemKind)) {  //不打印套餐头
                continue;
            }
            String fsSpecialNote = JsonUtil.getString(item, "fsSpecialNote");
            if (!TextUtils.isEmpty(fsSpecialNote)) {
                fsSpecialNote = "[" + fsSpecialNote + "]";
            }
            String left = fsSpecialNote + JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);
            addBlankLine(config, billPrint);

            if (TextUtils.equals("3", fiOrderItemKind)) {  //套餐明细要打印出所属的套餐头
                String parentItemName = JsonUtil.getString(item, "parentItemName");
                if (!TextUtils.isEmpty(parentItemName)) {
                    billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
                }
            }

            String note = JsonUtil.getInfo(item, "fsGeneralNote", String.class);
            if (!TextUtils.isEmpty(note)) {
                billPrint.addOrderModifier(note, 1);
            }
            String ingredientNote = JsonUtil.getInfo(item, "ingredientNotes", String.class);
            if (!TextUtils.isEmpty(ingredientNote)) {
                billPrint.addOrderModifier(ingredientNote, 1);
            }
            addBlankLine(config, billPrint);

        }
        billPrint.addHortionalLine();
        addBlankLine(config, billPrint);
        billPrint.addLeftWithRight(DateUtil.getCurrentTime(), Util.getString(R.string.print_no, taskModel.fiPrintNo));

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            addBlankLine(config, billPrint);
        }
        billPrint.addCut();

        String beep = JsonUtil.getInfo(ob, "beep", String.class);
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    public static void addBlankLine(PrinterConfig config, PrintBizBuilder billPrint) {
        if (!SunMiV1PrinterInfo.isSunMiV1InnerPrinter(config)) {
            billPrint.addBlankLine(1);
        }
    }

    /**
     * 格式化一行数据
     *
     * @param right
     * @param left
     * @return
     */
    private static String formatLine(String right, String left) {
        String newLeftStr = "";
        //左侧剩余空间可放置字符数
        int leftcount = 25 - getSBCCaseLength(right);
        if (leftcount > 0) {
            newLeftStr = truncation(leftcount, left);
        }

        return newLeftStr + right;
    }

    /**
     * 截断字符
     *
     * @param leftcount
     * @param leftStr
     * @return
     */
    private static String truncation(int leftcount, String leftStr) {
        int i = 0;
        boolean enugth = true;

        StringBuffer sb = new StringBuffer();
        char[] arr = leftStr.toCharArray();
        for (int j = 0; j < arr.length; j++) {
            char a = arr[j];
            i += getSBCCaseLength(String.valueOf(a));
            if (i > leftcount) {
                if (j < arr.length) {
                    enugth = false;
                }
                break;
            }
            sb.append(a);
        }

        if (enugth) {
            int ab = getSBCCaseLength(sb.toString());
            if (leftcount >= ab) {
                for (int x = ab; x < leftcount; x++) {
                    sb.append(" ");
                }
            }
        } else {
            String s = sb.toString().substring(0, sb.length() - 1);
            return s + "...";
        }

        return sb.toString();
    }

    public static int getSBCCaseLength(String text) {
        if (text != null && text.length() != 0) {
            try {
                return text.getBytes("GBK").length;
            } catch (UnsupportedEncodingException var2) {
                var2.printStackTrace();
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * 制作单单品
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/makesingle")
    public static PrintResult processMakeSingle(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        if (TextUtils.equals(PrinterCommand.TSC, config.commandType)) {
            return DinnerPrintProcessor.submitToPrinter(taskModel, OrderCommandProcessor.buildPrintItem(ob), config);
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addCenterText(JsonUtil.getInfo(ob, "billSourceName", String.class) + "(单品)", 2, 0, "-");

        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);

        String phone = JsonUtil.getInfo(sell, "fsCustMobile", String.class);
        if (!TextUtils.isEmpty(phone)) {
            if (phone.length() == 11) {
                phone = phone.substring(7, 11);
            }
            billPrint.addBlankLine();
            billPrint.addText("尾号" + phone + "的预订顾客已到店下单\n", 1, PrintDataItem.ALIGN_CENTRE, 0);
        }
        String orderType = "";
        String fillKind = JsonUtil.getInfo(sell, "fiBillKind", String.class);
        if (fillKind == null) {
            fillKind = "";
        }
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }

        String eatType = JsonUtil.getString(ob, "eatType");
        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        billPrint.addLeftBigWithRight("取餐号:",mealNumber,"类型:" + eatType);
        addBlankLine(config, billPrint);
        String eatTime = JsonUtil.getInfo(ob, "eatTime", String.class);
        if (!TextUtils.isEmpty(eatTime) && !(eatTime.contains("立即用餐") || eatTime.contains("尽早用餐"))) {
            billPrint.addText("用餐时间:" + eatTime + "\n", 2);
        }
        billPrint.addHortionaDoublelLine();

        JSONObject item = JsonUtil.getInfo(ob, "SellOrder", JSONObject.class);


        String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");

        String fsSpecialNote = JsonUtil.getString(item, "fsSpecialNote");
        if (!TextUtils.isEmpty(fsSpecialNote)) {
            fsSpecialNote = "[" + fsSpecialNote + "]";
        }
        String left = fsSpecialNote + JsonUtil.getString(item, "fsItemName");
        String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
        String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
        billPrint.addItemNameWithUnit(left, right, 2);
        billPrint.addBlankLine(1);
        if (TextUtils.equals("3", fiOrderItemKind)) {  //套餐明细要打印出所属的套餐头
            String parentItemName = JsonUtil.getString(item, "parentItemName");
            if (!TextUtils.isEmpty(parentItemName)) {
                billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
            }
        }
        String note = JsonUtil.getInfo(item, "fsGeneralNote", String.class);
        if (!TextUtils.isEmpty(note)) {
            billPrint.addOrderModifier(note, 2);
        }
        String ingredientNote = JsonUtil.getInfo(item, "ingredientNotes", String.class);
        if (!TextUtils.isEmpty(ingredientNote)) {
            billPrint.addOrderModifier(ingredientNote, 2);
        }

        billPrint.addHortionalLine();
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(DateUtil.getCurrentTime(), Util.getString(R.string.print_no, taskModel.fiPrintNo));

        billPrint.addBlankLine(1);

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();

        String beep = JsonUtil.getInfo(ob, "beep", String.class);
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 标签打印
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/makesingleTSC")
    public static PrintResult makesingleTSC(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        ob.put("titleRemind", titleRemind);
        return DinnerPrintProcessor.submitToPrinter(taskModel, OrderCommandProcessor.buildPrintItem(ob), config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/void")
    public static PrintResult processvoid(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("${Dept.fsDeptName}－退菜单".replace("${Dept.fsDeptName}", JsonUtil.getInfo(dept, "fsDeptName", String.class)) + "-" + JsonUtil.getInfo(ob, "billSourceName", String.class) + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        if (TextUtils.isEmpty(mealNumber)) {
            billPrint.addText("单号:" + JsonUtil.getInfo(sell, "fssellno", String.class) + "\n");
        } else {
            billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", "牌号：", mealNumber);
        }
//        billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", JsonUtil.getInfo(sell, "fsMTableName", String.class) + "");
        billPrint.addText("下单时间：" + JsonUtil.getString(ob, "orderTime") + "\n", 1);
        billPrint.addHortionaDoublelLine();

        JSONObject sellOrder = JsonUtil.getInfo(ob, "SellOrder", JSONObject.class);
        String left = "[退]" + JsonUtil.getInfo(sellOrder, "fsItemName", String.class);
        String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(sellOrder, "fdBackQty", String.class), JsonUtil.getInfo(sellOrder, "fsOrderUint", String.class));
        billPrint.addLeftWithRight(left, right, 2);
        String voidReasons = JsonUtil.getString(sellOrder, "fsBackReason");
        if (!TextUtils.isEmpty(voidReasons)) {
            billPrint.addOrderModifier("理由:" + voidReasons, 1);
        }
        String fiOrderItemKind = JsonUtil.getString(sellOrder, "fiOrderItemKind");
        //套餐明细要打印出所属的套餐头
        if (TextUtils.equals("3", fiOrderItemKind)) {
            String parentItemName = JsonUtil.getString(sellOrder, "parentItemName");
            if (!TextUtils.isEmpty(parentItemName)) {
                billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
            }
        }
        StringBuilder sbNote = new StringBuilder();
        String ingredientNote = JsonUtil.getInfo(ob, "ingredientNote", String.class);
        if (!TextUtils.isEmpty(ingredientNote)) {
            sbNote.append(ingredientNote).append("   ");
        }
        String note = JsonUtil.getInfo(sellOrder, "fsNote", String.class);
        if (!TextUtils.isEmpty(note)) {
            sbNote.append(note).append("   ");
        }

//        sbNote.append(JsonUtil.getInfo(sellOrder, "fsBackReason", String.class));
        if (sbNote.length() > 0) {
            billPrint.addText(sbNote.toString() + "\n", 1, PrintDataItem.ALIGN_LEFT, 0);
        }
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("下单:" + JsonUtil.getInfo(sellOrder, "fsCreateUserName", String.class) + "\n");
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/changeIngredient")
    public static PrintResult changeIngredient(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addTitle(JsonUtil.getInfo(dept, "fsDeptName", String.class) + "-" + JsonUtil.getInfo(ob, "title", String.class));
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        if (TextUtils.isEmpty(mealNumber)) {
            billPrint.addText("单号:" + JsonUtil.getInfo(sell, "fssellno", String.class) + "\n");
        } else {
            billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", "牌号:", mealNumber);
        }
//        billPrint.addTableNoWaiterName(JsonUtil.getInfo(sell, "fsMTableName", String.class) + "", JsonUtil.getInfo(sell, "waiterName", String.class) + "");

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "ingredientItems", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = JsonUtil.getInfo(item, "fsItemName", String.class);
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(item, "fdSaleQty", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class));
            billPrint.addLeftWithRight(left, right, 2);
        }
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        String beep = JsonUtil.getInfo(ob, "beep", String.class);
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }


        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 点菜单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/menulist")
    public static PrintResult menulist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("点菜单" + "-" + JsonUtil.getInfo(ob, "billSourceName", String.class) + titleRemind);
        billPrint.addBlankLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getInfo(sell, "fiBillKind", String.class);
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
//        billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fsSellNo", String.class) + "", JsonUtil.getInfo(sell, "fsMTableName", String.class) + "");

        String eatType = JsonUtil.getString(ob, "eatType");
        if (!TextUtils.isEmpty(eatType)) {
            billPrint.addText(eatType + "\n", 2);
        }

        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        if (TextUtils.isEmpty(mealNumber)) {
            billPrint.addText("单号:" + JsonUtil.getInfo(sell, "fssellno", String.class) + "\n");
        } else {
            billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", "牌号：", mealNumber);
        }

        billPrint.addLeftWithRight("点菜:" + JsonUtil.getInfo(ob, "PrintUser", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));

        billPrint.addLeftWithRight("日期:" + JsonUtil.getInfo(sell, "fsSellDate", String.class), "餐段:" + JsonUtil.getInfo(sell, "fsMSectionName", String.class));
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = JsonUtil.getInfo(item, "fsItemName", String.class);
            String waitInfo = JsonUtil.getInfo(item, "SfiItemMakeState", String.class);
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(item, "fdSaleQty", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class)) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);

//            JSONArray slit = JsonUtil.getInfo(item, "SLIT");
            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsItemName", String.class) + "*" + JsonUtil.getInfo(itemS, "fdSaleQty", String.class), 1);
                }
            }

            JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
            if (ingredientList != null && ingredientList.size() > 0) {
                for (int m = 0; m < ingredientList.size(); m++) {
                    JSONObject itemS = ingredientList.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsItemName", String.class) + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(itemS, "fdSaleQty", String.class), JsonUtil.getInfo(itemS, "fsOrderUint", String.class)), 1);
                }
            }

            Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
            if (!(fiOrderItemKind != null && fiOrderItemKind.intValue() == 4)) {
                String note = JsonUtil.getInfo(item, "fsNote", String.class);
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier2(note, 1);
                }
            }
            billPrint.addBlankLine(1);
        }

        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "Sub", String.class) + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 传菜单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/passto")
    public static PrintResult passto(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("传菜单" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        String mealNumber = JsonUtil.getInfo(ob, "mealNumber", String.class);
        if (TextUtils.isEmpty(mealNumber)) {
            billPrint.addText("单号:" + JsonUtil.getInfo(sell, "fssellno", String.class) + "\n");
        } else {
            billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", "牌号：", mealNumber);
        }
        billPrint.addLeftWithRight("人数:" + JsonUtil.getString(sell, "fiCustSum"), "");
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
                if (TextUtils.equals("2", fiOrderItemKind)) {  //不打印套餐头
                    continue;
                }
                String left = JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
                billPrint.addItemNameWithUnit(left, right, 2);
                // 等叫
                if (!TextUtils.isEmpty(waitInfo)) {
                    billPrint.addText("  " + waitInfo + "\n", 2);
                }
                //套餐明细要打印出所属的套餐头
                if (TextUtils.equals("3", fiOrderItemKind)) {
                    String parentItemName = JsonUtil.getString(item, "parentItemName");
                    if (!TextUtils.isEmpty(parentItemName)) {
                        billPrint.addOrderModifier("-(属于)" + parentItemName, 1);
                    }
                }
                //配料菜不打印要求备注等
                if (!TextUtils.equals("4", fiOrderItemKind)) {
                    String note = JsonUtil.getString(item, "fsNote");
                    if (!TextUtils.isEmpty(note)) {
                        billPrint.addOrderModifier2(note, 1);
                    }
                }
                billPrint.addBlankLine(1);
            }
        }

        billPrint.addHortionalLine();

//        billPrint.addText(PrintStringUtil.padLeft("合计:" + JsonUtil.getString(ob, "Sub")+ "\n", 28, 2, billPrint.gbkSize));
        billPrint.addLeftWithRightBig("", "", "合计:" + JsonUtil.getString(ob, "Sub"));

        billPrint.addHortionalLine();

        String serviceScore = JsonUtil.getString(ob, "serviceScore");
        String commentsMessages = JsonUtil.getString(ob, "commentsMessages");
        String tags = JsonUtil.getString(ob, "tags");

        if (!TextUtils.isEmpty(serviceScore) || !TextUtils.isEmpty(commentsMessages) || !TextUtils.isEmpty(tags)) {

            if (!TextUtils.isEmpty(serviceScore)) {
                billPrint.addLeftWithRightBig("", "", "上次消费评分:" + serviceScore);
            }
            if (!TextUtils.isEmpty(commentsMessages)) {
                billPrint.addLeftWithRightBig("", "", "用户留言:" + commentsMessages);
            }
            if (!TextUtils.isEmpty(tags)) {
                billPrint.addLeftWithRightBig("", "", "用户所选标签:" + tags);
            }
            billPrint.addHortionalLine();
        }


        String memberLevel = JsonUtil.getString(ob, "memberLevel");
        String sex = JsonUtil.getString(ob, "sex");
        String cardBalance = JsonUtil.getString(ob, "cardBalance");
        if (!TextUtils.isEmpty(memberLevel) || !TextUtils.isEmpty(sex) || !TextUtils.isEmpty(cardBalance)) {
            billPrint.addLeftWithRight("会员信息", "");
            if (!TextUtils.isEmpty(memberLevel)) {
                billPrint.addLeftWithRight("会员等级: " + memberLevel, "");
            }
            if (!TextUtils.isEmpty(sex)) {
                billPrint.addLeftWithRight("性别: " + sex, "");
            }
            if (!TextUtils.isEmpty(cardBalance)) {
                billPrint.addLeftWithRight("储值余额: " + cardBalance, "");
            }
            billPrint.addHortionalLine();
        }


        billPrint.addLeftWithRight("下单:" + JsonUtil.getString(ob, "fsCreateUserName"), "打印部门:" + JsonUtil.getString(ob, "Dept"));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

}

