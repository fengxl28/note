package com.mwee.android.posprint.business.report;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintBillBuilder;
import com.mwee.android.print.processor.PrintStringUtil;
import com.mwee.android.tools.DateUtil;

/**
 * ReportCommandProcessor
 * Created by virgil on 16/8/9.
 */
@SuppressWarnings("unused")
public class ReportCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "report";

    @DrivenMethod(uri = DRIVER_TAG + "/sale")
    public static void processSale(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("日结表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addLeftWithRight("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class),
                "班别:" + JsonUtil.getInfo(ob, "fsShiftName", String.class));
        billPrint.addHortionaDoublelLine();
        int size1 = billPrint.charSize / 4;
        int size2 = billPrint.charSize / 2 - billPrint.charSize / 4;
        int size3 = size1;
        int size4 = billPrint.charSize - size1 - size2 - size3;
        billPrint.addText(PrintStringUtil.padRight("人数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fiCustSum", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("销售单数:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "SellCount", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("赠送数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdGiftQty", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("赠送金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdGiftAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("退菜数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdBackQty", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("退菜金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdBackAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("折扣单数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "discountCount", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("折扣金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "discountAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("特价优惠:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "bargainAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("会员价优惠:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "vipAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("非实收结算:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "notCalcPaidAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("优惠汇总:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "notPaySum", String.class), size4, billPrint.gbkSize) + "\n");

//        billPrint.addText(PrintStringUtil.padRight("发票数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
//                (JsonUtil.getInfo(ob, "invoiceCount", String.class) + " ", size2, billPrint.gbkSize) +
//                PrintStringUtil.padRight("发票金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
//                .getInfo(ob, "invoiceMoney", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("未结单数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "SellNoCount", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("未结金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdnoPayAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("已结单数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "SellYJCount", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("已结金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdPayAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("服务费:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdServiceAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("免服务费:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdFreeSveAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("原始营业额:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "originalSaleAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("营业额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdExpAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("圆整金额:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdRoundAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("损益:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getInfo
                (ob, "fdRoundAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("人均:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "RJ", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("单均:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getInfo
                (ob, "DJ", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                ("", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("实际收入:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdRealAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addHortionalLine();

        int size = billPrint.charSize / 3;
        JSONArray takeOutModels = JsonUtil.getInfo(ob, "takeOutList", JSONArray.class);
        if (takeOutModels != null) {
            billPrint.addText(PrintStringUtil.padRight("外卖平台", size, billPrint.gbkSize));
            billPrint.addText(PrintStringUtil.padCenter("订单数", size, billPrint.gbkSize));
            billPrint.addText(PrintStringUtil.padLeft("实收金额", size, billPrint.gbkSize) + "\n");
            for (int i = 0; i < takeOutModels.size(); i++) {
                JSONObject item = takeOutModels.getJSONObject(i);
                billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(item, "fsBillSourceName", String.class), size, billPrint.gbkSize));
                billPrint.addText(PrintStringUtil.padCenter(JsonUtil.getInfo(item, "count", String.class), size, billPrint.gbkSize));
                billPrint.addText(PrintStringUtil.padLeft(JsonUtil.getInfo(item, "total", String.class), size, billPrint.gbkSize) + "\n");
            }
        }

        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "ShiftList", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText("【" + JsonUtil.getInfo(item, "fsshiftname", String.class) + "】\n");
                billPrint.addOrderItem("<结算方式>", "", "笔数", "金额", 1);

                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                if (arr != null && arr.size() > 0) {
                    for (int j = 0; j < arr.size(); j++) {
                        JSONObject temp = arr.getJSONObject(j);

                        billPrint.addOrderItem(JsonUtil.getInfo(temp, "fspaymentname", String.class), "", JsonUtil.getInfo(temp, "qty", String.class),
                                JsonUtil.getInfo(temp, "fdrecemoney", String.class), 1);
                    }
                }
                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);

                billPrint.addOrderItem("合计", "", "",
                        JsonUtil.getInfo(hj, "fdrecemoney", String.class), 1);
                billPrint.addHortionalLine();
            }
        }

        JSONArray xsflList = JsonUtil.getInfo(ob, "XSFL", JSONArray.class);

        if (xsflList != null) {
            billPrint.addOrderItem("<销售分类(折前)>", "", "数量", "金额", 1);
            for (int i = 0; i < xsflList.size(); i++) {
                JSONObject item = xsflList.getJSONObject(i);
                String fsexpclsname = JsonUtil.getInfo(item, "fsexpclsname", String.class);
                if (TextUtils.isEmpty(fsexpclsname)) {
                    fsexpclsname = "";
                }
                billPrint.addOrderItem(fsexpclsname, "", JsonUtil.getInfo(item, "fdsaleqty", String.class), JsonUtil.getInfo(item, "fdsaleamt", String.class), 1);
            }
            billPrint.addHortionalLine();
        }

        JSONArray srflList = JsonUtil.getInfo(ob, "SRFL", JSONArray.class);
        if (srflList != null) {
            billPrint.addOrderItem("<收入分类(折前)>", "", "数量", "金额", 1);
            for (int i = 0; i < srflList.size(); i++) {
                JSONObject item = srflList.getJSONObject(i);
                String fsrevenuetypename = JsonUtil.getInfo(item, "fsrevenuetypename", String.class);
                if (TextUtils.isEmpty(fsrevenuetypename)) {
                    fsrevenuetypename = "";
                }
                billPrint.addOrderItem(fsrevenuetypename, "", JsonUtil.getInfo(item, "fdsaleqty", String.class), JsonUtil.getInfo(item, "fdsaleamt", String.class), 1);
            }
            billPrint.addHortionaDoublelLine();
        }
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    //收款明細表
    @DrivenMethod(uri = DRIVER_TAG + "/checkByDay")
    public static void checkByDay(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("收款明细表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();


        JSONArray list = JsonUtil.getInfo(ob, "ShiftList", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);

                billPrint.addText(PrintStringUtil.padRight("<结算方式>", billPrint.charSize / 2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft("金额", billPrint.charSize - billPrint.charSize / 2, billPrint.gbkSize)
                        + "\n");

                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                if (arr != null && arr.size() > 0) {
                    for (int j = 0; j < arr.size(); j++) {
                        JSONObject temp = arr.getJSONObject(j);

                        billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(temp, "fspaymentname", String.class),
                                billPrint.charSize / 2, billPrint.gbkSize) +
                                PrintStringUtil.padLeft(JsonUtil.getInfo(temp, "fdrecemoney", String.class), billPrint
                                        .charSize - billPrint.charSize / 2, billPrint.gbkSize) + "\n");
                    }
                }
                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addText(PrintStringUtil.padRight("合计", billPrint.charSize / 2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(hj, "fdrecemoney", String.class), billPrint.charSize
                                - billPrint.charSize / 2, billPrint.gbkSize) + "\n");
                billPrint.addHortionalLine();
            }
        }

        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();

        billPrint.addText(PrintStringUtil.padCenter("仅统计当前24点前结账的订单", billPrint.charSize, billPrint.gbkSize));
        billPrint.addBlankLine();

        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * AB账
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/ab")
    public static void ab(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("营业收入表* " + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        int size1 = billPrint.charSize / 4;
        int size2 = billPrint.charSize / 2 - billPrint.charSize / 4;
        int size3 = size1;
        int size4 = billPrint.charSize - size1 - size2 - size3;
        billPrint.addText(PrintStringUtil.padRight("人数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fiCustSum", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("销售单数:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "SellCount", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("赠送数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdGiftQty", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("赠送金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdGiftAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("退菜数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdBackQty", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("退菜金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdBackAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("折扣单数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "DisCount", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("折扣金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdDiscountRoundAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("人均:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "RJ", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("单均:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getInfo
                (ob, "DJ", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("发票数:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "Invoice", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("发票金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdInvoiceAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("营业额:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "fdExpAmt", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("销售金额:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdSaleAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addText(PrintStringUtil.padRight("", size1, billPrint.gbkSize) + PrintStringUtil.padLeft(" ",
                size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("实际收入:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                .getInfo(ob, "fdRealAmt", String.class), size4, billPrint.gbkSize) + "\n");

        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "JSMX", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText("【" + JsonUtil.getInfo(item, "fsCreateUserName", String.class) + "】\n");
                billPrint.addText(PrintStringUtil.padRight("<结算方式>", billPrint.charSize / 2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft("金额", billPrint.charSize - billPrint.charSize / 2, billPrint.gbkSize)
                        + "\n");
                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);

                    billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(temp, "fsPaymentName", String.class),
                            billPrint.charSize / 2, billPrint.gbkSize) +
                            PrintStringUtil.padLeft(JsonUtil.getInfo(temp, "fdReceMoney", String.class), billPrint
                                    .charSize - billPrint.charSize / 2, billPrint.gbkSize) + "\n");
                }
                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                if (hj != null) {
                    billPrint.addText(PrintStringUtil.padRight("合计", size2, billPrint.gbkSize) +
                            PrintStringUtil.padLeft(JsonUtil.getInfo(hj, "fdrecemoney", String.class), size2,
                                    billPrint.gbkSize) + "\n");
                }
                billPrint.addHortionalLine();
            }
        }

        JSONArray xsflList = JsonUtil.getInfo(ob, "XSFL", JSONArray.class);
        if (xsflList != null) {
            billPrint.addText(PrintStringUtil.padRight("<销售分类>", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                    ("数量", size1, billPrint.gbkSize) +
                    PrintStringUtil.padLeft("金额", size1, billPrint.gbkSize) + PrintStringUtil.padLeft("折后金额", size1,
                    billPrint.gbkSize) + "\n");
            for (int i = 0; i < xsflList.size(); i++) {
                JSONObject item = xsflList.getJSONObject(i);
                String fsexpclsname = JsonUtil.getInfo(item, "fsExpClsName", String.class);
                if (TextUtils.isEmpty(fsexpclsname)) {
                    fsexpclsname = "";
                }
                billPrint.addText(PrintStringUtil.padRight(fsexpclsname, size1, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdSaleQty", String.class), billPrint.charSize
                                / 4, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdSaleAmt", String.class), size1, billPrint
                                .gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fddisafteramt", String.class), size1,
                                billPrint.gbkSize) +
                        "\n");
            }
            billPrint.addHortionalLine();
        }

        JSONArray srflList = JsonUtil.getInfo(ob, "SRFL", JSONArray.class);
        if (srflList != null) {
            billPrint.addText(PrintStringUtil.padRight("<收入分类>", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                    ("数量", billPrint.charSize / 4, billPrint.gbkSize) +
                    PrintStringUtil.padLeft("金额", size1, billPrint.gbkSize) + PrintStringUtil.padLeft("折后金额", size1,
                    billPrint.gbkSize) + "\n");

            for (int i = 0; i < srflList.size(); i++) {
                JSONObject item = srflList.getJSONObject(i);
                String fsrevenuetypename = JsonUtil.getInfo(item, "fsRevenueTypeName", String.class);
                if (TextUtils.isEmpty(fsrevenuetypename)) {
                    fsrevenuetypename = "";
                }
                billPrint.addText(PrintStringUtil.padRight(fsrevenuetypename, size1, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdSaleQty", String.class), size1, billPrint
                                .gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdSaleAmt", String.class), size1, billPrint
                                .gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fddisafteramt", String.class), size1,
                                billPrint.gbkSize) +
                        "\n");
            }
            billPrint.addHortionaDoublelLine();
        }
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 微信外卖
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/wechat")
    public static void wechat(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("微信外卖");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addText(PrintStringUtil.padRight("品项", billPrint.charSize / 2, billPrint.gbkSize) +
                PrintStringUtil.padLeft("金额", billPrint.charSize - billPrint.charSize / 2, billPrint.gbkSize) + "\n");

        billPrint.addHortionalLine();
        JSONArray list = JsonUtil.getInfo(ob, "WXORDER", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(item, "payName", String.class), billPrint
                        .charSize / 2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "amt", String.class), billPrint.charSize -
                                billPrint.charSize / 2, billPrint.gbkSize) + "\n");
            }
        }

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 外卖报表
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/netorder")
    public static void netorder(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("外卖报表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        int size1 = billPrint.charSize / 4;
        int size2 = billPrint.charSize / 2 - billPrint.charSize / 4;
        int size3 = size1;
        int size4 = billPrint.charSize - size1 - size2 - size3;

        billPrint.addLeftWithRight("订单总数:" + JsonUtil.getInfo(ob, "allQty", String.class), "未处理订单:" + JsonUtil.getInfo(ob, "undeal", String.class));
        billPrint.addLeftWithRight("已取消订单:" + JsonUtil.getInfo(ob, "cancelQty", String.class), "已接单订单:" + JsonUtil.getInfo(ob, "gedQty", String.class));
        billPrint.addLeftWithRight("优惠金额:" + JsonUtil.getInfo(ob, "couponAmount", String.class), "折扣金额:" + JsonUtil.getInfo(ob, "discountAmount", String.class));
        billPrint.addLeftWithRight("外卖平台服务费:" + JsonUtil.getInfo(ob, "fdServiceAmt", String.class), "餐盒费:" + JsonUtil.getInfo(ob, "boxFee", String.class));
        billPrint.addLeftWithRight("配送费:" + JsonUtil.getInfo(ob, "deliveryFee", String.class), "合计金额:" + JsonUtil.getInfo(ob, "subTotal", String.class));

        String earnestMoney = JsonUtil.getInfo(ob, "earnestMoney", String.class);
        if (!TextUtils.isEmpty(earnestMoney)) {
            billPrint.addLeftWithRight("", "实收金额:" + earnestMoney);
        }

        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "DDLY", JSONArray.class);
        if (list != null && list.size() > 0) {
            billPrint.addCenterText("订单来源");
            billPrint.addHortionalLine();
           /* billPrint.addText(
                    PrintStringUtil.padLeft("来源", billPrint.charSize / 3, billPrint.gbkSize) +
                            PrintStringUtil.padLeft("数量", size1, billPrint.gbkSize) +
                            PrintStringUtil.padLeft("金额", size1, billPrint.gbkSize) +
                            "\n");*/

            billPrint.addContentListHeader(
                    "来源",
                    "",
                    "数量",
                    "金额");
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(item, "name", String.class),
                        "",
                        JsonUtil.getInfo(item, "qty", String.class),
                        JsonUtil.getInfo(item, "amt", String.class),
                        1);

            }
        }
        billPrint.addHortionalLine();
        JSONArray listItem = JsonUtil.getInfo(ob, "CPSL", JSONArray.class);
        if (listItem != null && listItem.size() > 0) {
            billPrint.addCenterText("菜品明细");
            billPrint.addHortionalLine();

            billPrint.addContentListHeader(
                    "菜品名称",
                    "",
                    "数量",
                    "金额");

            for (int i = 0; i < listItem.size(); i++) {
                JSONObject item = listItem.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(item, "name", String.class),
                        "",
                        JsonUtil.getInfo(item, "qty", String.class),
                        JsonUtil.getInfo(item, "amt", String.class),
                        1);
            }
        }

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 美团外卖报表
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/meituanNetOrder")
    public static void meituanNetOrder(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("美团外卖订单报表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        int size1 = billPrint.charSize / 4;
        int size2 = billPrint.charSize / 2 - billPrint.charSize / 4;
        int size3 = size1;
        int size4 = billPrint.charSize - size1 - size2 - size3;

        billPrint.addLeftWithRight("订单总数:", JsonUtil.getInfo(ob, "allQty", String.class));
        billPrint.addLeftWithRight("配送费:", JsonUtil.getInfo(ob, "deliveryFee", String.class));
        billPrint.addLeftWithRight("合计金额:", JsonUtil.getInfo(ob, "subTotal", String.class));

        billPrint.addHortionalLine();
        JSONArray listItem = JsonUtil.getInfo(ob, "CPSL", JSONArray.class);
        if (listItem != null && listItem.size() > 0) {
            billPrint.addCenterText("菜品明细");
            billPrint.addHortionalLine();

            billPrint.addContentListHeader(
                    "菜品名称",
                    "",
                    "数量",
                    "金额");

            for (int i = 0; i < listItem.size(); i++) {
                JSONObject item = listItem.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(item, "name", String.class),
                        "",
                        JsonUtil.getInfo(item, "qty", String.class),
                        JsonUtil.getInfo(item, "amt", String.class),
                        1);
            }
        }

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/gift")
    public static void processGift(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("赠菜明细表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "LIST", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String time = JsonUtil.getInfo(item, "fsGifttime", String.class);
            if (TextUtils.isEmpty(time)) {
                time = "";
            }
            billPrint.addText(PrintStringUtil.padRight("单号:" + JsonUtil.getInfo(item, "fssellno", String.class),
                    billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(time, billPrint.charSize /
                    2, billPrint.gbkSize) + "\n");
            billPrint.addOrderItemNoMargin(JsonUtil.getInfo(item, "fsitemname", String.class), "",
                    JsonUtil.getInfo(item, "fdGiftQty", String.class) +
                            JsonUtil.getInfo(item, "fsorderuint", String.class),
                    JsonUtil.getInfo(item, "fdGiftAmt", String.class),
                    1);
            String reason = JsonUtil.getInfo(item, "fsgiftreason", String.class);
            if (!TextUtils.isEmpty(reason)) {
                billPrint.addText(JsonUtil.getInfo(item, "fsgiftreason", String.class) + "\n");
            }
            //"授权:" + JsonUtil.getInfo(item, "fsgiftusername")  ----授权暂时没有
            billPrint.addText(PrintStringUtil.padRight("操作员:" + JsonUtil.getInfo(item, "fsGiftUserName", String
                    .class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("", billPrint
                    .charSize / 2, billPrint.gbkSize));
            billPrint.addLine();
            billPrint.addBlankLine(1);
        }
        billPrint.addHortionalLine();
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("总数", "",
                JsonUtil.getInfo(hj, "fdGiftQty", String.class),
                JsonUtil.getInfo(hj, "fdGiftAmt", String.class),
                1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");

        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/void")
    public static void processVoid(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("退菜明细表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "LIST", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String time = JsonUtil.getInfo(item, "fsBacktime", String.class);
            if (TextUtils.isEmpty(time)) {
                time = "";
            }
            billPrint.addText(PrintStringUtil.padRight("单号:" + JsonUtil.getInfo(item, "fssellno", String.class),
                    billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(time, billPrint.charSize /
                    2, billPrint.gbkSize) + "\n");

            billPrint.addOrderItemNoMargin(JsonUtil.getInfo(item, "fsitemname", String.class), "",
                    JsonUtil.getInfo(item, "fdBackQty", String.class) +
                            JsonUtil.getInfo(item, "fsorderuint", String.class),
                    JsonUtil.getInfo(item, "fdBackAmt", String.class),
                    1);
            String reason = JsonUtil.getInfo(item, "fsbackreason", String.class);
            if (!TextUtils.isEmpty(reason)) {
                billPrint.addText(reason + "\n");
            }
            billPrint.addText(PrintStringUtil.padRight("操作员:" + JsonUtil.getInfo(item, "fsBackUserName", String
                    .class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("", billPrint
                    .charSize / 2, billPrint.gbkSize));
            billPrint.addLine();
            billPrint.addBlankLine(1);
        }
        billPrint.addHortionalLine();
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("总数", "",
                JsonUtil.getInfo(hj, "fdBackQty", String.class),
                JsonUtil.getInfo(hj, "fdBackAmt", String.class),
                1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/num")
    public static void processNum(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {

        //按分类查询打印方式
        if (TextUtils.equals(JsonUtil.getInfo(ob, "newReport", String.class), "1")) {
            processNewSaleNum(ob, taskModel, config);
            return;
        }

        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("销售数量表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        if (APPConfig.isMyd()) {
            String content = JsonUtil.getInfo(ob, "OrderSource", String.class);
            if (!TextUtils.isEmpty(content)) {
                billPrint.addText("订单来源:" + content + "\n");
            }
        }
        billPrint.addHortionaDoublelLine();

        billPrint.addContentListHeader("项目", "数量", "金额", "金额%");
        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText("[" + JsonUtil.getInfo(item, "fsmenuclsname", String.class) + "]" + "\n");
                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            JsonUtil.getInfo(temp, "BF", String.class),
                            1);
                }

                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addOrderItem("合计", JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                        JsonUtil.getInfo(hj, "fdsaleamt", String.class), "",
                        1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("销售合计",
                JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                JsonUtil.getInfo(hj, "fdsaleamt", String.class),
                "",
                1);
        /*billPrint.addText(PrintStringUtil.padRight("-折扣:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "fddiscountamt", String.class), billPrint.charSize / 2));

        billPrint.addText(PrintStringUtil.padRight("=营业合计:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "SJ", String.class), billPrint.charSize / 2));
      */
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        String menuSourceList = JsonUtil.getString(ob, "menuSourceList");
        if (!TextUtils.isEmpty(menuSourceList)) {
            billPrint.addCenterText(menuSourceList + "\n");
        }
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    public static void processNewSaleNum(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {

        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("销售数量表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        if (APPConfig.isMyd()) {
            String content = JsonUtil.getInfo(ob, "OrderSource", String.class);
            if (!TextUtils.isEmpty(content)) {
                billPrint.addText("订单来源:" + content + "\n");
            }
        }
        billPrint.addHortionaDoublelLine();

        billPrint.addContentListHeader("项目", "数量", "金额", "金额%");
        JSONArray list = JsonUtil.getInfo(ob, "XSSLNEW", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                loopTreeNode(billPrint, item, 0);
                billPrint.addHortionalLine();
            }
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("销售合计",
                JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                JsonUtil.getInfo(hj, "fdsaleamt", String.class),
                "",
                1);
        /*billPrint.addText(PrintStringUtil.padRight("-折扣:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "fddiscountamt", String.class), billPrint.charSize / 2));

        billPrint.addText(PrintStringUtil.padRight("=营业合计:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "SJ", String.class), billPrint.charSize / 2));
      */
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        String menuSourceList = JsonUtil.getString(ob, "menuSourceList");
        if (!TextUtils.isEmpty(menuSourceList)) {
            billPrint.addCenterText(menuSourceList + "\n");
        }
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    private static void loopTreeNode(PrintBillBuilder billPrint, JSONObject treeNode, int level) {
        if (treeNode != null) {
            boolean isSelected = treeNode.getBoolean("selected");
            if (isSelected) {
                billPrint.addText(getVoidStr(level) + "[" + JsonUtil.getInfo(treeNode, "fsMenuClsName", String.class) + "]" + "\n");
            }
            JSONArray children = JsonUtil.getInfo(treeNode, "children", JSONArray.class);
            if (children != null) {
                for (int i = 0; i < children.size(); i++) {
                    loopTreeNode(billPrint, children.getJSONObject(i), level + 1);
                }
            }

            if (isSelected) {

                JSONArray salesAmountItem = JsonUtil.getInfo(treeNode, "salesAmountItem", JSONArray.class);
                if (salesAmountItem != null) {
                    for (int j = 0; j < salesAmountItem.size(); j++) {
                        JSONObject temp = salesAmountItem.getJSONObject(j);
                        billPrint.addOrderItem(getVoidStr(level) + JsonUtil.getInfo(temp, "fsitemname", String.class),
                                JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                                JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                                JsonUtil.getInfo(temp, "BF", String.class),
                                1);
                    }
                }
                JSONObject salesAmountClsHJ = JsonUtil.getInfo(treeNode, "salesAmountClsHJ", JSONObject.class);
                billPrint.addOrderItem(getVoidStr(level) + "合计", JsonUtil.getInfo(salesAmountClsHJ, "fdsaleqty", String.class),
                        JsonUtil.getInfo(salesAmountClsHJ, "fdsaleamt", String.class), "",
                        1);
            }
        }
    }

    private static String getVoidStr(int level) {
        StringBuilder voidStr = new StringBuilder("");
        for (int i = 0; i < level; i++) {
            voidStr.append(" ");
        }
        return voidStr.toString();
    }

    /**
     * 档口统计表
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/reportDept")
    public static void processeportDept(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {

        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("档口统计表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addContentListHeader("档口", "数量", "金额", "金额%");
        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject temp = list.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsdeptname", String.class),
                        JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                        JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                        JsonUtil.getInfo(temp, "BF", String.class),
                        1);
            }
        }
        /* 不显示总计
        billPrint.addHortionalLine();

        JSONObject hj = JsonUtil.getInfo(ob, "HJ");
        billPrint.addOrderItem("销售合计", JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                JsonUtil.getInfo(hj, "fdsaleamt", String.class), "",
                1);
        billPrint.addOrderItem("-折扣:", "",
                JsonUtil.getInfo(hj, "fddiscountamt", String.class), "",
                1);
        billPrint.addOrderItem("=营业合计:", "",
                JsonUtil.getInfo(hj, "SJ", String.class), "",
                1);*/
        /*billPrint.addText(PrintStringUtil.padRight("-折扣:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "fddiscountamt", String.class), billPrint.charSize / 2));

        billPrint.addText(PrintStringUtil.padRight("=营业合计:", billPrint.charSize / 2) + PrintStringUtil.padLeft("" +
        JsonUtil.getInfo(hj, "SJ", String.class), billPrint.charSize / 2));
      */

        JSONArray dtl = JsonUtil.getInfo(ob, "dtl", JSONArray.class);
        if (dtl != null) {
            for (int i = 0; i < dtl.size(); i++) {
                JSONObject item = dtl.getJSONObject(i);
                JSONArray detl = JsonUtil.getInfo(item, "detl", JSONArray.class);
                if (detl != null) {
                    billPrint.addHortionaDoublelLine();
                    billPrint.addContentListHeader(JsonUtil.getInfo(item, "fsDeptName", String.class), "数量", "金额", "金额%");
                    for (int j = 0; j < detl.size(); j++) {
                        JSONObject temp = detl.getJSONObject(j);
                        billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsItemName", String.class),
                                JsonUtil.getInfo(temp, "fdSaleQty", String.class),
                                JsonUtil.getInfo(temp, "fdSubTotal", String.class),
                                JsonUtil.getInfo(temp, "percent", String.class),
                                1);
                    }
                }
            }
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    /**
     * 时段统计表
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/reportTime")
    public static void processeportTime(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {

        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("时段统计表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        if (billPrint.charSize != 32 && billPrint.charSize != 33) {
            billPrint.addContentListHeader("时段", "数量", "金额", "金额%");
        } else {
            billPrint.addContentListHeader("时段", "金额%", "数量", "金额");
        }
        JSONArray list = JsonUtil.getInfo(ob, "XSSD", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject temp = list.getJSONObject(i);
                if (billPrint.charSize != 32 && billPrint.charSize != 33) {
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            JsonUtil.getInfo(temp, "BF", String.class),
                            1);
                } else {
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            JsonUtil.getInfo(temp, "BF", String.class),
                            JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            1);
                }
            }
        }
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/maxSaleQuantity")
    public static void processMaxSaleQuantity(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        for (int i = 0; i < 3; i++) {
            billPrint.addBlankLine(1);
        }
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        //标题上显示选择的排名数
        String selectRank = JsonUtil.getInfo(ob, "selectRank", String.class);
        if (TextUtils.isEmpty(selectRank)) {
            selectRank = "";
        }
        billPrint.addTitle("最高销售数量表" + titleRemind + selectRank);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        if (billPrint.charSize != 32 && billPrint.charSize != 33) {
            billPrint.addContentListHeader("项目", "数量", "占比%", "排名");
        } else {
            billPrint.addContentListHeader("项目", "占比%", "数量", "排名");
        }

        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                if (billPrint.charSize != 32 && billPrint.charSize != 33) {
                    billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class), JsonUtil.getInfo(item,
                            "fdsaleqty", String.class)
                            , JsonUtil.getInfo(item, "percent", String.class), JsonUtil.getInfo(item, "serialnumber",
                                    String.class), 1);
                } else {
                    billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class)
                            , JsonUtil.getInfo(item, "percent", String.class),
                            JsonUtil.getInfo(item, "fdsaleqty", String.class),
                            JsonUtil.getInfo(item, "serialnumber",
                                    String.class), 1);
                }
            }
        }
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/maxSalePrice")
    public static void processMaxSalePrice(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        for (int i = 0; i < 3; i++) {
            billPrint.addBlankLine(1);
        }
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("最高销售金额表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        if (billPrint.charSize != 32 && billPrint.charSize != 33) {
            billPrint.addContentListHeader("项目", "金额", "占比%", "排名");
        } else {
            billPrint.addContentListHeader("项目", "占比%", "金额", "排名");
        }

        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                if (billPrint.charSize != 32 && billPrint.charSize != 33) {
                    billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class), JsonUtil.getInfo(item,
                            "fdsaleamt", String.class)
                            , JsonUtil.getInfo(item, "percent", String.class), JsonUtil.getInfo(item, "serialnumber",
                                    String.class), 1);
                } else {
                    billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class),
                            JsonUtil.getInfo(item, "percent", String.class),
                            JsonUtil.getInfo(item, "fdsaleamt", String.class)
                            , JsonUtil.getInfo(item, "serialnumber",
                                    String.class), 1);
                }
            }
        }
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCenterText("包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 交班表
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     */
    @DrivenMethod(uri = DRIVER_TAG + "/shift")
    public static void processShift(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = JsonUtil.getInfo(ob, "titleRemind", String.class);
        billPrint.addTitle("交班表" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addHortionaDoublelLine();
        String leftOne = PrintStringUtil.padRight("营业日期:", billPrint.charSize / 4, billPrint.gbkSize);
        int size1 = PrintStringUtil.getStringLength(leftOne, billPrint.gbkSize, 1);

        String leftTwo = PrintStringUtil.padLeft(JsonUtil.getInfo(ob, "Businessdate", String.class) + " ", billPrint
                .charSize / 2 - size1, billPrint.gbkSize);
        int size2 = PrintStringUtil.getStringLength(leftTwo, billPrint.gbkSize, 1);
        int size3 = size1;
        int size4 = billPrint.charSize - size1 - size2 - size3;
        billPrint.addText(PrintStringUtil.padRight("营业日期:", size1, billPrint.gbkSize) + leftTwo +
                PrintStringUtil.padRight("班别:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getInfo
                (ob, "shiftName", String.class) + "\n", size4, billPrint.gbkSize));

        billPrint.addText(PrintStringUtil.padRight("收银员:", size1, billPrint.gbkSize) + PrintStringUtil.padLeft
                (JsonUtil.getInfo(ob, "SUserName", String.class) + " ", size2, billPrint.gbkSize) +
                PrintStringUtil.padRight("站点:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getInfo
                (ob, "fsHostId", String.class) + "\n", size4, billPrint.gbkSize));

        if (ob.containsKey("isAuthorize") && !TextUtils.isEmpty(JsonUtil.getInfo(ob, "authorizeUsername", String
                .class))) {//打印授权交班信息
            billPrint.addText(PrintStringUtil.padRight("", size1, billPrint.gbkSize) + PrintStringUtil.padLeft(" ",
                    size2, billPrint.gbkSize) +
                    PrintStringUtil.padRight("授权交班:", size3, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil
                    .getInfo(ob, "authorizeUsername", String.class) + "\n", size4, billPrint.gbkSize));
        }
        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "ShiftList", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(JsonUtil.getInfo(item, "fsshiftname", String.class) + "\n");
                billPrint.addOrderItem("<结算方式>", "", "", "金额", 1);

                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fspaymentname", String.class), "", "", JsonUtil.getInfo(temp, "fdrecemoney", String.class), 1);
                }
                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addOrderItem("合计", "", "", JsonUtil.getInfo(hj, "fdrecemoney", String.class), 1);
                billPrint.addHortionalLine();
            }
        }


        billPrint.addText("<明细>\n");

        JSONObject model = JsonUtil.getInfo(ob, "detail", JSONObject.class);
        billPrint.addText(PrintStringUtil.padRight("人数", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "fiCustSum", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft("单数", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "qty", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + "\r\n");

        billPrint.addText(PrintStringUtil.padRight("销售金额", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "fdSaleAmt", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft("营业金额", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "fdExpAmt", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + "\r\n");


        billPrint.addText(PrintStringUtil.padRight("折扣金额", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "fdDiscountAmt", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft("实收金额", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "fdRealAmt", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + "\r\n");


        billPrint.addText(PrintStringUtil.padRight("人均", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "RJ", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft("单均", billPrint.charSize / 4, billPrint.gbkSize)
                + PrintStringUtil.padLeft(JsonUtil.getInfo(model, "DJ", String.class), billPrint.charSize / 4, billPrint.gbkSize)
                + "\r\n");

        if (APPConfig.isMyd()) {
            billPrint.addHortionalLine();
            JSONArray xsflList = JsonUtil.getInfo(ob, "XSFL", JSONArray.class);
            if (xsflList != null) {
                billPrint.addOrderItem("<销售分类(折前)>", "", "数量", "金额", 1);
                for (int i = 0; i < xsflList.size(); i++) {
                    JSONObject item = xsflList.getJSONObject(i);
                    String fsexpclsname = JsonUtil.getInfo(item, "fsexpclsname", String.class);
                    if (TextUtils.isEmpty(fsexpclsname)) {
                        fsexpclsname = "";
                    }
                    billPrint.addOrderItem(fsexpclsname, "", JsonUtil.getInfo(item, "fdsaleqty", String.class), JsonUtil.getInfo(item, "fdsaleamt", String.class), 1);
                }
                billPrint.addHortionalLine();
            }

            JSONArray srflList = JsonUtil.getInfo(ob, "SRFL", JSONArray.class);
            if (srflList != null) {
                billPrint.addOrderItem("<收入分类(折前)>", "", "", "金额", 1);
                for (int i = 0; i < srflList.size(); i++) {
                    JSONObject item = srflList.getJSONObject(i);
                    String fsrevenuetypename = JsonUtil.getInfo(item, "fsrevenuetypename", String.class);
                    if (TextUtils.isEmpty(fsrevenuetypename)) {
                        fsrevenuetypename = "";
                    }
                    billPrint.addOrderItem(fsrevenuetypename, "", "", JsonUtil.getInfo(item, "fdsaleamt", String.class), 1);
                }
            }
        } else {
            //air3.8.0交班表调整,隐藏：销售分类及收入分类
        }

        JSONArray dtl = JsonUtil.getInfo(ob, "DTL", JSONArray.class);
        if (dtl != null) {
            for (int i = 0; i < dtl.size(); i++) {
                JSONObject item = dtl.getJSONObject(i);
                JSONArray detl = JsonUtil.getInfo(item, "detl", JSONArray.class);
                if (detl != null) {
                    billPrint.addHortionalLine();
                    billPrint.addOrderItem(String.format("<%s>", JsonUtil.getInfo(item, "fsDeptName", String.class)), "",
                            "数量", "金额",
                            1);
                    for (int j = 0; j < detl.size(); j++) {
                        JSONObject temp = detl.getJSONObject(j);
                        billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsItemName", String.class), "",
                                JsonUtil.getInfo(temp, "fdSaleQty", String.class),
                                JsonUtil.getInfo(temp, "fdSubTotal", String.class),
                                1);
                    }
                }
            }
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/wechatfastfood")
    public static void processWxFastFood(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("微信快餐");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addText(PrintStringUtil.padRight("品项", billPrint.charSize / 2, billPrint.gbkSize) +
                PrintStringUtil.padLeft("金额", billPrint.charSize - billPrint.charSize / 2, billPrint.gbkSize) + "\n");

        billPrint.addHortionalLine();
        JSONArray list = JsonUtil.getInfo(ob, "SRFL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(item, "fspaymentname", String.class), billPrint
                        .charSize / 2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdrecemoney", String.class), billPrint.charSize -
                                billPrint.charSize / 2, billPrint.gbkSize) + "\n");
            }
        }

        billPrint.addHortionalLine();
        billPrint.addText(PrintStringUtil.padRight("订单合辑", billPrint
                .charSize / 2, billPrint.gbkSize) +
                PrintStringUtil.padLeft(JsonUtil.getInfo(ob, "count", String.class), billPrint.charSize -
                        billPrint.charSize / 2, billPrint.gbkSize) + "\n");

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 折扣报表打印
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/discount")
    public static void discount(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("优惠报表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addText(PrintStringUtil.padRight("订单号", billPrint.charSize / 4, billPrint.gbkSize) +
                PrintStringUtil.padCenter("订单金额", billPrint.charSize / 4, billPrint.gbkSize) +
                PrintStringUtil.padCenter("优惠金额", billPrint.charSize / 4, billPrint.gbkSize) +
                PrintStringUtil.padCenter("操作员", billPrint.charSize / 4, billPrint.gbkSize) + "\n");
        billPrint.addHortionalLine();
        JSONArray list = JsonUtil.getInfo(ob, "dislist", JSONArray.class);
        int size1 = billPrint.charSize / 3;
        int size2 = (billPrint.charSize - size1) / 3;
        size1 = billPrint.charSize - size2 * 3;
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                //TODO:这个办法不靠谱
                String one = JsonUtil.getInfo(item, "fssellno", String.class) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdTotalAmt", String.class), size2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fdDiscountAmt", String.class), size2, billPrint.gbkSize) +
                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fsCheckoutName", String.class), size2, billPrint.gbkSize);
//                        PrintStringUtil.padLeft(JsonUtil.getInfo(item, "fsCheckoutName", String.class), billPrint.charSize / 4, billPrint.gbkSize);
//                if(one.length() > 45 && one.substring(45).startsWith(" ")) {
//                    //由于订单号过长，导致有时候对不齐，最后会多算出空格，本方法仅适用于当前报表，不推荐
//                    one = one.substring(0, 45);
//                }
                billPrint.addText(one + "\n");
            }

            billPrint.addHortionalLine();
        }


        billPrint.addText("优惠订单总额：" + JsonUtil.getInfo(ob, "allSaleAmt", String.class) + "\n");
        billPrint.addText("优惠总数：" + JsonUtil.getInfo(ob, "allCount", String.class) + "\n");
        billPrint.addText("优惠总额：" + JsonUtil.getInfo(ob, "allDiscountAmt", String.class) + "\n");

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();

        billPrint.addText(PrintStringUtil.padCenter("折扣统计包含免服务费、满减、减价、整单立减、会员优惠、特价优惠、折扣、赠送、抹零、免单、优惠支付类型", billPrint.charSize, billPrint.gbkSize));
        billPrint.addBlankLine();

        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 折扣汇总表打印
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/reportAllDiscount")
    public static void reportAllDiscount(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("优惠汇总表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addOrderItem("折扣名称", "", "单数", "折扣金额", 1);
        billPrint.addHortionalLine();
        JSONArray discountContent = JsonUtil.getInfo(ob, "discountContent", JSONArray.class);
        if (discountContent != null && discountContent.size() > 0) {
            for (int i = 0; i < discountContent.size(); i++) {
                JSONObject item = discountContent.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(item, "discountName", String.class),
                        "",
                        JsonUtil.getInfo(item, "discountQty", String.class),
                        JsonUtil.getInfo(item, "discountAmt", String.class),
                        1);
            }
        }
        billPrint.addHortionalLine();

        billPrint.addText(PrintStringUtil.padRight(String.format("总折扣数量:%s", JsonUtil.getInfo(ob, "allCount", String.class)), billPrint.charSize / 2, billPrint.gbkSize) +
                PrintStringUtil.padLeft(String.format("总折扣金额:%s", JsonUtil.getInfo(ob, "allDiscountAmt", String.class)), billPrint.charSize / 2, billPrint.gbkSize));

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();

        billPrint.addText(PrintStringUtil.padCenter("折扣统计包含免服务费、满减、减价、整单立减、会员优惠、特价优惠、折扣、赠送、抹零、免单、优惠支付类型", billPrint.charSize, billPrint.gbkSize));
        billPrint.addBlankLine();

        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 沽清报表打印
     *
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/sellout")
    public static void sellout(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("沽清报表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "sellout", JSONArray.class);
        if (list != null && list.size() > 0) {
            billPrint.addOrderItem("沽清菜品", "", "类型", "数量", 1);
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);

                String sellOutInfo = Integer.valueOf(JsonUtil.getInfo(item, "fiStatus", String.class)) == 2 ? "今日" : "长期";
                billPrint.addOrderItem(String.format("%s(%s)", JsonUtil.getInfo(item, "fsItemName", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class)),
                        "",
                        sellOutInfo,
                        JsonUtil.getInfo(item, "fdInvQty", String.class),
                        1);

            }
            /*for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(PrintStringUtil.padRight(String.format("%s(%s)", JsonUtil.getInfo(item, "fsItemName", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class)), billPrint.charSize * 3 / 4, billPrint.gbkSize) + "\n");
            }*/
        }

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 新日结表打印
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/newSale")
    public static void processNewSale(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("营业收入日结表");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addText("订单来源:" + JsonUtil.getInfo(ob, "OrderSource", String.class) + "\n");
        String billSourceLabel = JsonUtil.getInfo(ob, "menuSourceList", String.class);
        if(!TextUtils.isEmpty(billSourceLabel)){
            billPrint.addText(billSourceLabel + "\n");
        }
        billPrint.addHortionalLine();
        billPrint.addCenterText("运营情况",1);
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("营业额",JsonUtil.getInfo(ob, "originalTotalAmount", String.class),2);
        billPrint.addHortionalLine();
        JSONObject recePay = ob.getJSONObject("recePay");
        JSONObject unRecePay = ob.getJSONObject("unRecePay");
        JSONObject coupon = ob.getJSONObject("coupon");
        JSONObject otherPay = ob.getJSONObject("otherPay");
        billPrint.addOrderItem("非实收金额",
                "",
                JsonUtil.getInfo(unRecePay, "unReceTotalCount", String.class),
                JsonUtil.getInfo(unRecePay, "unReceTotalAmount", String.class),
                1);
        billPrint.addOrderItem("优惠金额",
                "",
                JsonUtil.getInfo(coupon, "couponTotalCount", String.class),
                JsonUtil.getInfo(coupon, "couponTotalAmount", String.class),
                1);
        billPrint.addOrderItem("其它费用",
                "",
                JsonUtil.getInfo(otherPay, "otherPayTotalCount", String.class),
                JsonUtil.getInfo(otherPay, "otherPayTotalAmount", String.class),
                1);
        billPrint.addBlankLine();
        billPrint.addLeftWithRight("实际收入",JsonUtil.getInfo(recePay, "receTotalAmount", String.class),2);
        billPrint.addHortionalLine();
        if(recePay != null){
            JSONArray receList = recePay.getJSONArray("recePayList");
            if(receList != null && receList.size() > 0){
                billPrint.addCenterText("实际收入明细",1);
                billPrint.addHortionalLine();
                billPrint.addOrderItem("名称", "", "数量", "金额", 1);
                for (int i = 0; i < receList.size(); i++) {
                    JSONObject receObj = receList.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(receObj, "fsPaymentName", String.class),
                            "",
                            JsonUtil.getInfo(receObj, "fiPaymentQty", String.class),
                            JsonUtil.getInfo(receObj, "fdReceMoney", String.class),
                            1);
                }
                billPrint.addLeftWithRight("合计",JsonUtil.getInfo(recePay, "receTotalAmount", String.class),1);
                billPrint.addHortionalLine();
            }
        }
        if(unRecePay != null){
            JSONArray unReceList = unRecePay.getJSONArray("unRecePayList");
            if(unReceList != null && unReceList.size() > 0){
                billPrint.addCenterText("非实收明细",1);
                billPrint.addHortionalLine();
                billPrint.addOrderItem("名称", "", "数量", "金额", 1);
                for (int i = 0; i < unReceList.size(); i++) {
                    JSONObject unReceObj = unReceList.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(unReceObj, "fsPaymentName", String.class),
                            "",
                            JsonUtil.getInfo(unReceObj, "fiPaymentQty", String.class),
                            JsonUtil.getInfo(unReceObj, "fdReceMoney", String.class),
                            1);
                }
                billPrint.addLeftWithRight("合计",JsonUtil.getInfo(unRecePay, "unReceTotalAmount", String.class),1);
                billPrint.addHortionalLine();
            }
        }
        if(coupon != null){
            JSONArray couponList = coupon.getJSONArray("couponList");
            if(couponList != null && couponList.size() > 0){
                billPrint.addCenterText("优惠明细",1);
                billPrint.addHortionalLine();
                billPrint.addOrderItem("名称", "", "数量", "金额", 1);
                for (int i = 0; i < couponList.size(); i++) {
                    JSONObject couponObj = couponList.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(couponObj, "name", String.class),
                            "",
                            JsonUtil.getInfo(couponObj, "qty", String.class),
                            JsonUtil.getInfo(couponObj, "amount", String.class),
                            1);
                }
                billPrint.addLeftWithRight("合计",JsonUtil.getInfo(coupon, "couponTotalAmount", String.class),1);
                billPrint.addHortionalLine();
            }
        }
        if(otherPay != null){
            JSONArray otherPayList = otherPay.getJSONArray("otherPayList");
            if(otherPayList != null && otherPayList.size() > 0){
                billPrint.addCenterText("其它费用",1);
                billPrint.addHortionalLine();
                billPrint.addOrderItem("名称", "", "数量", "金额", 1);
                for (int i = 0; i < otherPayList.size(); i++) {
                    JSONObject otherPayObj = otherPayList.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(otherPayObj, "name", String.class),
                            "",
                            JsonUtil.getInfo(otherPayObj, "qty", String.class),
                            JsonUtil.getInfo(otherPayObj, "amount", String.class),
                            1);
                }
                billPrint.addLeftWithRight("合计",JsonUtil.getInfo(otherPay, "otherPayTotalAmount", String.class),1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject billSource = ob.getJSONObject("billSource");
        if(billSource != null){
            JSONArray billSourceList = billSource.getJSONArray("billSourceList");
            if(billSourceList != null && billSourceList.size() > 0){
                billPrint.addCenterText("订单来源",1);
                billPrint.addHortionalLine();
                billPrint.addOrderItem("名称", "数量", "应收", "实收", 1);
                for (int i = 0; i < billSourceList.size(); i++) {
                    JSONObject billSourceObj = billSourceList.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(billSourceObj, "fsBillSourceName", String.class),
                            JsonUtil.getInfo(billSourceObj, "qty", String.class),
                            JsonUtil.getInfo(billSourceObj, "fdOriginalAmt", String.class),
                            JsonUtil.getInfo(billSourceObj, "fdRealAmt", String.class),
                            1);
                }
                billPrint.addOrderItem("合计",
                        " ",
                        JsonUtil.getInfo(billSource, "originalTotalAmount", String.class),
                        JsonUtil.getInfo(billSource, "realTotalAmount", String.class),
                        1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject eatOrder = ob.getJSONObject("eatOrder");
        if(eatOrder != null){
            billPrint.addCenterText("堂食订单统计",1);
            billPrint.addHortionalLine();
            billPrint.addLeftWithRight("堂食订单数",JsonUtil.getInfo(eatOrder, "eatOrderQty", String.class),1);
            billPrint.addLeftWithRight("堂食单均消费(按营业额)",JsonUtil.getInfo(eatOrder, "eatOrderAverageByOriginalAmt", String.class),1);
            billPrint.addLeftWithRight("堂食单均消费(按实收)",JsonUtil.getInfo(eatOrder, "eatOrderAverageByRealAmt", String.class),1);
            billPrint.addLeftWithRight("堂食人数",JsonUtil.getInfo(eatOrder, "eatPersonNum", String.class),1);
            billPrint.addLeftWithRight("堂食人均消费",JsonUtil.getInfo(eatOrder, "eatOrderPersonAverage", String.class),1);
            billPrint.addLeftWithRight("堂食折扣率",JsonUtil.getInfo(eatOrder, "eatOrderDiscountRate", String.class),1);
            billPrint.addLeftWithRight("堂食用餐时长(分钟)",JsonUtil.getInfo(eatOrder, "eatTime", String.class),1);
            billPrint.addLeftWithRight("堂食平均用餐时长(分钟)",JsonUtil.getInfo(eatOrder, "eatTimeAverage", String.class),1);
            billPrint.addLeftWithRight("开台率",JsonUtil.getInfo(eatOrder, "eatOpenTableRate", String.class),1);
            billPrint.addHortionalLine();
        }
        JSONObject takeOutOrder = ob.getJSONObject("takeOutOrder");
        if(takeOutOrder != null){
            billPrint.addCenterText("外卖订单统计",1);
            billPrint.addHortionalLine();
            billPrint.addLeftWithRight("外卖订单数",JsonUtil.getInfo(takeOutOrder, "takeOutOrderQty", String.class),1);
            billPrint.addLeftWithRight("外卖单均消费(按实收)",JsonUtil.getInfo(takeOutOrder, "takeOutAverageByRealAmt", String.class),1);
            billPrint.addHortionalLine();
        }

        billPrint.addBlankLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 会员储值汇总打印
     * @param ob
     * @param taskModel
     * @param config
     */
    @DrivenMethod(uri = DRIVER_TAG + "/memberCharge")
    public static void processMemberChargeData(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("会员储值汇总");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionalLine();
        billPrint.addOrderItem("名称", " ", "数量", "金额", 1);
        billPrint.addHortionalLine();
        JSONObject chargeData = ob.getJSONObject("chargeData");
        if(chargeData != null){
            JSONArray chargeArray = chargeData.getJSONArray("list");
            if(chargeArray != null){
                for (int i = 0; i < chargeArray.size(); i++) {
                    JSONObject chargeItem = chargeArray.getJSONObject(i);
                    billPrint.addOrderItem(JsonUtil.getInfo(chargeItem, "payType", String.class),
                            " ",
                            JsonUtil.getInfo(chargeItem, "rechargeCount", String.class),
                            JsonUtil.getInfo(chargeItem, "rechargeMoney", String.class),
                            1);
                }
            }
            billPrint.addHortionalLine();
            billPrint.addOrderItem("合计", " ",
                    JsonUtil.getInfo(chargeData, "totalCount", String.class),
                    JsonUtil.getInfo(chargeData, "totalMoney", String.class), 1);
        }
        billPrint.addHortionalLine();
        billPrint.addBlankLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/bundleNum")
    public static void processBundleNum(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("套餐销量汇总" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        billPrint.addOrderItem("名称", "", "销量", "金额", 1);
        billPrint.addHortionalLine();
        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(JsonUtil.getInfo(item, "fsmenuclsname", String.class) + "\n");
                billPrint.addHortionalLine();
                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            "", JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            1);
                }

                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addOrderItem("合计", "", "",
                        JsonUtil.getInfo(hj, "fdsaleamt", String.class),
                        1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("合计",
                "", "", JsonUtil.getInfo(hj, "fdsaleamt", String.class), 1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        String menuSourceList = JsonUtil.getString(ob, "menuSourceList");
        if (!TextUtils.isEmpty(menuSourceList)) {
            billPrint.addCenterText(menuSourceList + "\n");
        }
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/saleClsNum")
    public static void processSaleClsNum(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("销售分类汇总" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        billPrint.addContentListHeader("名称", "数量", "金额", "金额%");
        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(JsonUtil.getInfo(item, "fsmenuclsname", String.class) + "\n");
                billPrint.addHortionalLine();
                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            JsonUtil.getInfo(temp, "BF", String.class),
                            1);
                }

                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addOrderItem("合计", JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                        JsonUtil.getInfo(hj, "fdsaleamt", String.class), "",
                        1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("销售合计",
                JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                JsonUtil.getInfo(hj, "fdsaleamt", String.class),
                "",
                1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/incomeClsNum")
    public static void processInComeClsNum(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("收入分类汇总" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        billPrint.addContentListHeader("名称", "数量", "金额", "金额%");
        JSONArray list = JsonUtil.getInfo(ob, "XSSL", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addText(JsonUtil.getInfo(item, "fsmenuclsname", String.class) + "\n");
                billPrint.addHortionalLine();
                JSONArray arr = JsonUtil.getInfo(item, "MX", JSONArray.class);
                for (int j = 0; j < arr.size(); j++) {
                    JSONObject temp = arr.getJSONObject(j);
                    billPrint.addOrderItem(JsonUtil.getInfo(temp, "fsitemname", String.class),
                            JsonUtil.getInfo(temp, "fdsaleqty", String.class),
                            JsonUtil.getInfo(temp, "fdsaleamt", String.class),
                            JsonUtil.getInfo(temp, "BF", String.class),
                            1);
                }

                JSONObject hj = JsonUtil.getInfo(item, "HJ", JSONObject.class);
                billPrint.addOrderItem("合计", JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                        JsonUtil.getInfo(hj, "fdsaleamt", String.class), "",
                        1);
                billPrint.addHortionalLine();
            }
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("销售合计",
                JsonUtil.getInfo(hj, "fdsaleqty", String.class),
                JsonUtil.getInfo(hj, "fdsaleamt", String.class),
                "",
                1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCenterText("数量包含折扣菜品、赠送菜品，不包含退菜；金额为实际销售折后金额。" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/surchargeDetail")
    public static void processSurchargeDetail(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("溢收明细" + titleRemind);
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionaDoublelLine();

        billPrint.addOrderItem("订单号", "", "桌号", "金额", 1);
        billPrint.addHortionalLine();
        JSONArray list = JsonUtil.getInfo(ob, "YSLIST", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addOrderItem(JsonUtil.getInfo(item, "fsSellNo", String.class),
                        "", JsonUtil.getInfo(item, "fsMTableName", String.class),
                        JsonUtil.getInfo(item, "fdPayMoney", String.class),
                        1);
            }
            billPrint.addHortionalLine();
        }
        JSONObject hj = JsonUtil.getInfo(ob, "HJ", JSONObject.class);
        billPrint.addOrderItem("合计:",
                "", "", JsonUtil.getInfo(hj, "surchargeHJ", String.class),
                1);
        billPrint.addHortionaDoublelLine();
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n" + "\n");
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/processSalesTarget")
    public static void processSalesTarget(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addTitle("销售统计");
        billPrint.addBlankLine();
        billPrint.addText("营业日期:" + JsonUtil.getInfo(ob, "Businessdate", String.class) + "\n");
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("今日销售目标", JsonUtil.getInfo(ob, "salesTarget", String.class) + " ", 2);
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("堂食收入", JsonUtil.getInfo(ob, "inStoreInCome", String.class) + " ", 2);
        billPrint.addLeftWithRight("外卖收入", JsonUtil.getInfo(ob, "takeOutInCome", String.class) + " ", 2);
        billPrint.addHortionalLine();
        billPrint.addCenterText("堂食订单统计", 1);
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("已结金额", JsonUtil.getInfo(ob, "sellAccountAmount", String.class) + " ", 1);
        billPrint.addLeftWithRight("已结订单", JsonUtil.getInfo(ob, "sellAccountNum", String.class) + " ", 1);
        billPrint.addLeftWithRight("未结金额", JsonUtil.getInfo(ob, "sellUnAccountAmount", String.class) + " ", 1);
        billPrint.addLeftWithRight("未结订单", JsonUtil.getInfo(ob, "sellNoAccountNum", String.class) + " ", 1);
        billPrint.addLeftWithRight("总订单数", JsonUtil.getInfo(ob, "sellNum", String.class) + " ", 1);
        billPrint.addLeftWithRight("已结订单人数", JsonUtil.getInfo(ob, "sellAccountCustomer", String.class) + " ", 1);
        billPrint.addLeftWithRight("单均价", JsonUtil.getInfo(ob, "averagePriceBySell", String.class) + " ", 1);
        billPrint.addLeftWithRight("人均价", JsonUtil.getInfo(ob, "averagePriceByCustomer", String.class) + " ", 1);
        billPrint.addLeftWithRight("开台率(已结桌台订单数/桌台数)", JsonUtil.getInfo(ob, "openTableRate", String.class) + " ", 1);
        billPrint.addLeftWithRight("上座率(已结桌台订单人数/席位)", JsonUtil.getInfo(ob, "tableAttendanceRate", String.class) + " ", 1);
        billPrint.addLeftWithRight("客品数(已结菜品数/已结订单人数)", JsonUtil.getInfo(ob, "customerOrderItemRate", String.class) + " ", 1);
        billPrint.addBlankLine();
        billPrint.addCut();
        DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

}
