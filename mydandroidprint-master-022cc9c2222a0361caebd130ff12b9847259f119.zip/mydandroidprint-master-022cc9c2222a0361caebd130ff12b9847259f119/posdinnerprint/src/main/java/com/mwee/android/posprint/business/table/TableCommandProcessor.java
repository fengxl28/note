package com.mwee.android.posprint.business.table;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintStringUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by lxx on 16/9/11.
 */
@SuppressWarnings("unused")
public class TableCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "table";

    @DrivenMethod(uri = DRIVER_TAG + "/open")
    public static PrintResult open(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("开台单" + titleRemind);
        String orderID = JsonUtil.getInfo(ob, "fssellno", String.class);
        String mealNO = JsonUtil.getInfo(ob, "mealNO", String.class);
        billPrint.addOrderNoTableNo(orderID, mealNO);
        String type = JsonUtil.getInfo(ob, "type", String.class);
        String count = JsonUtil.getInfo(ob, "count", String.class);
        billPrint.addBlankLine();
        billPrint.addTypeCount(type, count);
        billPrint.addBlankLine();
        billPrint.addText(PrintStringUtil.padRight("日期:" + JsonUtil.getInfo(ob, "date", String.class), billPrint.charSize / 2, billPrint.gbkSize) +
                PrintStringUtil.padLeft("时间:" + JsonUtil.getInfo(ob, "time", String.class) + "\n", billPrint.charSize / 2, billPrint.gbkSize));
        billPrint.addHortionaDoublelLine();
        billPrint.addText(PrintStringUtil.padLeft("开单:" + JsonUtil.getInfo(ob, "fsCreateUserName", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine(1);
        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/change")
    public static PrintResult change(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("换桌单" + titleRemind);
        billPrint.addText("单号：" + JsonUtil.getInfo(ob, "fssellno", String.class) + "\n");
        billPrint.addText("台位：");
        billPrint.addText(JsonUtil.getInfo(ob, "startTableNo", String.class) + "\n", 2);
        billPrint.addText("换到：");
        billPrint.addText(JsonUtil.getInfo(ob, "targetTableNo", String.class) + "\n", 2);

        billPrint.addHortionaDoublelLine();

        billPrint.addLeftWithRight("打印部门:" + JsonUtil.getInfo(ob, "Dept", String.class), "操作:" + JsonUtil.getInfo(ob, "fsCreateUserName", String.class));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);
        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @DrivenMethod(uri = DRIVER_TAG + "/merge")
    public static PrintResult merge(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addTitle("并桌单");
        billPrint.add1212(JsonUtil.getInfo(ob, "startTableNo", String.class) + "", JsonUtil.getInfo(ob, "targetTableNo", String.class) + "", "合并到");
        billPrint.addHortionaDoublelLine();
        billPrint.add1111("原单:", JsonUtil.getInfo(ob, "startBillNo", String.class) + "", JsonUtil.getInfo(ob, "targetBillNo", String.class) + "", "→");
        billPrint.addText(PrintStringUtil.padLeft("操作:" + JsonUtil.getInfo(ob, "fsCreateUserName", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine(1);
        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
