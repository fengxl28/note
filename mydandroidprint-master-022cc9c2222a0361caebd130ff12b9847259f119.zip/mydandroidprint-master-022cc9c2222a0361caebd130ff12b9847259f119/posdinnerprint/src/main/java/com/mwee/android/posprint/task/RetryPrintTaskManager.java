package com.mwee.android.posprint.task;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.print.PrinterUpdateStatusResponse;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 小票重打的计时器
 * Created by virgil on 2016/12/11.
 */
public class RetryPrintTaskManager {
    private static RetryPrintTaskManager instance = new RetryPrintTaskManager();
    private Handler handler;

    private RetryPrintTaskManager() {
        init();
    }

    private ThreadPoolExecutor executor = null;

    private void init() {
        HandlerThread timer = new HandlerThread("MYDPrintRetry") {
            @Override
            protected void onLooperPrepared() {
                super.onLooperPrepared();
                handler = new Handler(Looper.myLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        super.handleMessage(msg);
                    }
                };
            }

        };
        timer.start();

        executor = new ThreadPoolExecutor(4, 20, 6, TimeUnit.MINUTES, new SynchronousQueue<Runnable>(), new ThreadFactory() {
            @Override
            public Thread newThread(@NonNull Runnable runnable) {
                Thread th = new Thread(runnable);
                th.setName("MydPrintTaskRetry_" + SystemClock.elapsedRealtime());
                th.setPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                return th;
            }
        }, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(final Runnable r, ThreadPoolExecutor executor) {
                RunTimeLog.addLog(RunTimeLog.SYS_PRINT_QUEUE, "打印线程队列已满");
                if (r instanceof Worker) {
                    LogUtil.log("PrintLoop 打印队列已满，新起线程重试 PrintNo=[" + ((Worker) r).task.fiPrintNo + "]");
                    new LowThread(r).start();
                }
            }
        });
    }

    public static RetryPrintTaskManager getInstance() {
        return instance;
    }

    /**
     * 任务重试间隔时间
     */
    public static final int RETRY_INTEVAL = 1000 * 20;

    public void pushRetry(final PrintTaskDBModel task) {
        MCon.c(CPrint.class, null, new SocketThreadCallback<PrinterUpdateStatusResponse>() {
            @Override
            public void callback(SocketResponse<PrinterUpdateStatusResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    //判断是否需要切换到备用打印机
                    if (socketResponse.data.failToSwitchBackp && !TextUtils.isEmpty(socketResponse.data.backUpPrinterName)) {
                        task.fsbakprintername = socketResponse.data.backUpPrinterName;
                        task.is_backup_printer = 1;
                        task.fiRetry += task.fiErrCount;
                        DBSimpleUtil.excuteSql(APPConfig.DB_PRINT, "update tbPrintTask set fiRetry='" + task.fiRetry + "',is_backup_printer='1',fsbakprintername='" + task.fsPrinterName + "' where fiPrintNo='" + task.fiPrintNo + "' and fsHostId='" + task.fsHostId + "'");
                    }
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        LogUtil.log("PrintLoop 开始重试[" + task.fiPrintNo + "]");
                        pushNew(task);
                    }
                }, RETRY_INTEVAL);
            }
        }).printerUpdateStatusRequest(task.fsPrinterName, true, task.is_backup_printer == 1, false,task.fiStatus,task.fiPrintNo,task.fsHostId);

    }

    /**
     * 打印失败+1
     *
     * @param task PrintTaskDBModel
     */
    public void addFail(final PrintTaskDBModel task) {
       /* PrinterUpdateStatusRequest re = new PrinterUpdateStatusRequest();
        re.addFailCount = true;
        re.resetToOrigin = false;
        re.isBackUpPrinter = task.is_backup_printer == 1;
        re.printerName = task.fsPrinterName;
        SocketExecutor.executeOnMain(re, null);*/

        MCon.c(CPrint.class).printerUpdateStatusRequest(task.fsPrinterName, true, task.is_backup_printer == 1, false,task.fiStatus,task.fiPrintNo,task.fsHostId);

    }

    /**
     * 接收一个新的打印任务
     *
     * @param task PrintTaskDBModel
     */
    public void pushNew(final PrintTaskDBModel task) {
        executor.execute(new Worker(task));
    }

    class Worker implements Runnable {
        public PrintTaskDBModel task;

        public Worker(PrintTaskDBModel task) {
            this.task = task;
        }

        @Override
        public void run() {
            if (task.is_backup_printer == 1) {
                if (!task.titleRemind.contains("备用")) {
                    task.titleRemind += "(备用打印)";
                }
            }
            DinnerPrintProcessor.processPrint(task);
        }
    }
}
