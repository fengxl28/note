package com.mwee.android.posprint.business.order;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterCommand;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintBillBuilder;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintStringUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * OrderCommandProcessor
 * Created by virgil on 16/8/9.
 */
@SuppressWarnings("unused")
public class OrderCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "order";

    /**
     * 制作单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/make")
    public static PrintResult processMake(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {

        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        String addMenuLabel = JsonUtil.getString(ob, "addMenuLabel");
        if (TextUtils.isEmpty(addMenuLabel)) {
            addMenuLabel = "";
        }
        if (APPConfig.isMyd()) {
            billPrint.addTitle("(总单)" + addMenuLabel + "${Dept.fsDeptName}制作单".replace("${Dept.fsDeptName}", JsonUtil.getString(dept, "fsDeptName")) + titleRemind);
        } else {
            //air3.7普通制作单调整
            billPrint.addCenterText("本店(总单)", 2, 0, "-");
        }
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String phone = JsonUtil.getString(sell, "fsCustMobile");
        if (!TextUtils.isEmpty(phone)) {
            billPrint.addBlankLine();
            billPrint.addText("尾号" + phone + "的预订顾客已到店下单\n", 1, PrintDataItem.ALIGN_CENTRE, 0);
        }
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }

        String eatType = JsonUtil.getString(ob, "eatType");
        if (!TextUtils.isEmpty(eatType)) {
            billPrint.addText(eatType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        billPrint.addBlankLine();
        if (APPConfig.isMyd()) {
            billPrint.addLeftWithRight("人数:" + JsonUtil.getString(sell, "fiCustSum"), "下单:" + JsonUtil.getString(ob, "fsCreateUserName"), 1);
        } else {
            billPrint.addText("人数:" + JsonUtil.getString(sell, "fiCustSum") + "\n", 1);
        }

        String isAllWaitCall = JsonUtil.getString(ob, "isAllWaitCall");
        if (TextUtils.equals(isAllWaitCall, "1")) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单等叫", 2);
        }

        String wholeNote = JsonUtil.getString(ob, "wholeNote");
        if (!TextUtils.isEmpty(wholeNote)) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单备注："+wholeNote, 2);
        }

        billPrint.addHortionaDoublelLine();
        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
                if (TextUtils.equals("2", fiOrderItemKind)) {  //不打印套餐头
                    continue;
                }
                String fsSpecialNote = JsonUtil.getString(item, "fsSpecialNote");
                String left = fsSpecialNote + JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
                billPrint.addItemNameWithUnit(left, right, 2);
                billPrint.addBlankLine(1);

                // 等叫
                if (!TextUtils.isEmpty(waitInfo)) {
                    billPrint.addText("  " + waitInfo + "\n", 2);
                }

                if (TextUtils.equals("3", fiOrderItemKind)) {  //套餐明细要打印出所属的套餐头
                    String parentItemName = JsonUtil.getString(item, "parentItemName");
                    if (!TextUtils.isEmpty(parentItemName)) {
                        billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
                    }
                }

                String note = JsonUtil.getString(item, "fsGeneralNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 2);
                }
                String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
                if (!TextUtils.isEmpty(ingredientNote)) {
                    String[] ingredientArr = ingredientNote.split("\n");
                    for (String ingredient : ingredientArr) {
                        billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                    }
                }
                billPrint.addBlankLine(1);
            }
        }
        billPrint.addHortionalLine();
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_order_user, JsonUtil.getString(ob, "fsCreateUserName")), Util.getString(R.string.print_dept, JsonUtil.getString(dept, "fsDeptName")));
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(DateUtil.getCurrentTime(), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);
        billPrint.addLine();

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @DrivenMethod(uri = DRIVER_TAG + "/printnetworkkdsreceipt")
    public static PrintResult printNetworkKDSReceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        if (APPConfig.isMyd()) {
            return printNetworkKDSReceiptMyd(ob, task, config);
        } else {
            return printNetworkKDSReceiptMxy(ob, task, config);
        }
    }

    /**
     * 美小易打印外卖制作单,外卖退菜单
     *
     * @param ob
     * @param task
     * @param config
     */
    private static PrintResult printNetworkKDSReceiptMxy(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addLine();

        //退菜延时说明
        String voidHint = JsonUtil.getString(ob, "voidHint");
        if (!TextUtils.isEmpty(voidHint)) {
            billPrint.addText(voidHint + "\n");
        }
        String restNum = JsonUtil.getString(ob, "restNum");
        String orderNum = JsonUtil.getString(ob, "orderNum");//本地生产的订单号--一般是堂食订单用
        String eatType = JsonUtil.getString(ob, "eatType");

        if (!TextUtils.isEmpty(restNum)) {
            restNum = "#" + restNum;
        }

        Boolean tempBoolean = JsonUtil.getInfo(ob, "isAdjust", Boolean.class);
        boolean isAdjust = tempBoolean == null ? false : tempBoolean;
        if (isAdjust) {
//            3.7外卖制作单调整
            billPrint.addCenterText(restNum + eatType + JsonUtil.getInfo(ob, "isOneItemCut", String.class), 2, 0, "-");
        } else {
            billPrint.addCenterTextPaddingWithDash(JsonUtil.getInfo(ob, "isOneItemCut", String.class));
            if (TextUtils.isEmpty(orderNum)) {
                billPrint.addText(restNum + eatType + "\n", 2, 0, 0);
            } else {
                billPrint.addText(PrintStringUtil.padRight(JsonUtil.getString(ob, "eatType"), billPrint.charSize / 4, billPrint.gbkSize) + PrintStringUtil.padLeft("订单号:" + JsonUtil.getString(ob, "orderNum"), billPrint.charSize / 4, billPrint.gbkSize), 2, 0, 0);
            }
        }

        String pokeNo = JsonUtil.getString(ob, "pokeNo");
        if (!TextUtils.isEmpty(pokeNo)) {
            billPrint.addCenterText(pokeNo + "\n");
        }
        if (!isAdjust) {
//            air3.7外卖制作单调整
            billPrint.addHortionalLine();
            billPrint.addLeftWithRight("菜名", "数量");
        }
        billPrint.addHortionalLine();
        //其他外卖的菜
        JSONArray list = JsonUtil.getInfo(ob, "orderDetailList", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String left = JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
                billPrint.addItemNameWithUnit(left, right, 2);
                // //add modifier print
                JSONArray modifiertypes = JsonUtil.getInfo(item, "modifiertypes", JSONArray.class);
                if (modifiertypes != null && modifiertypes.size() > 0) {
                    for (int m = 0; m < modifiertypes.size(); m++) {
                        JSONObject itemType = modifiertypes.getJSONObject(m);
                        JSONArray modifiertDetail = JsonUtil.getInfo(itemType, "modifiers", JSONArray.class);
                        if (modifiertDetail != null && modifiertDetail.size() > 0) {
                            for (int s = 0; s < modifiertDetail.size(); s++) {
                                JSONObject itemS = modifiertDetail.getJSONObject(s);
                                billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "modifierName") + "*" + JsonUtil.getString(itemS, "modifierNum"), 2);
                            }
                        }
                    }
                }

                String note = JsonUtil.getString(item, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }
                String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
                if (!TextUtils.isEmpty(ingredientNote)) {
                    String[] ingredientArr = ingredientNote.split("\n");
                    for (String ingredient : ingredientArr) {
                        billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                    }
                }
            }
        }
        billPrint.addHortionalLine();
        String orderDesc = JsonUtil.getInfo(ob, "orderDesc", String.class);
        if (!TextUtils.isEmpty(orderDesc)) {
            billPrint.addText("备注:" + orderDesc + "\n");
            billPrint.addHortionalLine();
        }
        String expectTime = JsonUtil.getInfo(ob, "distributionStartTime", String.class);
        if (!TextUtils.isEmpty(expectTime) && !expectTime.contains("立即送达")) {
//            3.7外卖制作单调整
            billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(ob, "distributionStartTime", String.class), billPrint.charSize, billPrint.gbkSize) + "\n", 2);
        }
        String fsDptrName = JsonUtil.getInfo(ob, "fsDptrName", String.class);
        String fiPrintNo = JsonUtil.getInfo(ob, "fiPrintNo", String.class);
        String printTime = JsonUtil.getInfo(ob, "PrintTime", String.class);
        String orderId = JsonUtil.getInfo(ob, "orderId", String.class);

        if (isAdjust) {
//            3.7外卖制作单调整
            billPrint.addLeftWithRight(printTime, "印号:" + fiPrintNo, 1);
        } else {
            String contact = JsonUtil.getInfo(ob, "contact", String.class);
            if (!TextUtils.isEmpty(contact)) {
                billPrint.addText("联系人信息:" + contact + "\n", 1);
            }
            billPrint.addText("网络订单号:" + orderId + "\n", 1);
            billPrint.addText("打印时间:" + printTime + "\n", 1);
            billPrint.addLeftWithRight(fsDptrName, "印号:" + fiPrintNo, 1);
        }

        billPrint.addBlankLine(1);
        billPrint.addCut();
        String beep = JsonUtil.getInfo(ob, "beep", String.class);
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }
        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }

    /**
     * 美易点打印外卖制作单
     *
     * @param ob
     * @param task
     * @param config
     */
    private static PrintResult printNetworkKDSReceiptMyd(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addLine();

        //退菜延时说明
        String voidHint = JsonUtil.getString(ob, "voidHint");
        if (!TextUtils.isEmpty(voidHint)) {
            billPrint.addText(voidHint + "\n");
        }
        String restNum = JsonUtil.getString(ob, "restNum");
        String orderNum = JsonUtil.getString(ob, "orderNum");//本地生产的订单号--一般是堂食订单用
        String eatType = JsonUtil.getString(ob, "eatType");

        if (!TextUtils.isEmpty(restNum)) {
            restNum = "#" + restNum;
        }
        billPrint.addCenterTextPaddingWithDash(JsonUtil.getInfo(ob, "isOneItemCut", String.class));
        if (TextUtils.isEmpty(orderNum)) {
            billPrint.addText(restNum + eatType + "\n", 2, 0, 0);
        } else {
            billPrint.addText(PrintStringUtil.padRight(JsonUtil.getString(ob, "eatType"), billPrint.charSize / 4, billPrint.gbkSize) + PrintStringUtil.padLeft("订单号:" + JsonUtil.getString(ob, "orderNum"), billPrint.charSize / 4, billPrint.gbkSize), 2, 0, 0);
        }
        String pokeNo = JsonUtil.getString(ob, "pokeNo");
        if (!TextUtils.isEmpty(pokeNo)) {
            billPrint.addCenterText(pokeNo + "\n");
        }
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("菜名", "数量");
        billPrint.addHortionalLine();
        //其他外卖的菜
        JSONArray list = JsonUtil.getInfo(ob, "orderDetailList", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String left = JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
                billPrint.addItemNameWithUnit(left, right, 2);
                // //add modifier print
                JSONArray modifiertypes = JsonUtil.getInfo(item, "modifiertypes", JSONArray.class);
                if (modifiertypes != null && modifiertypes.size() > 0) {
                    for (int m = 0; m < modifiertypes.size(); m++) {
                        JSONObject itemType = modifiertypes.getJSONObject(m);
                        JSONArray modifiertDetail = JsonUtil.getInfo(itemType, "modifiers", JSONArray.class);
                        if (modifiertDetail != null && modifiertDetail.size() > 0) {
                            for (int s = 0; s < modifiertDetail.size(); s++) {
                                JSONObject itemS = modifiertDetail.getJSONObject(s);
                                billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "modifierName") + "*" + JsonUtil.getString(itemS, "modifierNum"), 2);
                            }
                        }
                    }
                }

                String note = JsonUtil.getString(item, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }
                String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
                if (!TextUtils.isEmpty(ingredientNote)) {
                    String[] ingredientArr = ingredientNote.split("\n");
                    for (String ingredient : ingredientArr) {
                        billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                    }
                }
            }
        }
        billPrint.addHortionalLine();
        String orderDesc = JsonUtil.getInfo(ob, "orderDesc", String.class);
        if (!TextUtils.isEmpty(orderDesc)) {
            billPrint.addText("备注:" + orderDesc + "\n");
            billPrint.addHortionalLine();
        }
        String expectTime = JsonUtil.getInfo(ob, "distributionStartTime", String.class);
        if (!TextUtils.isEmpty(expectTime) && !expectTime.contains("立即送达")) {
//            3.7外卖制作单调整
            billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(ob, "distributionStartTime", String.class), billPrint.charSize, billPrint.gbkSize) + "\n", 2);
        }
        String fsDptrName = JsonUtil.getInfo(ob, "fsDptrName", String.class);
        String fiPrintNo = JsonUtil.getInfo(ob, "fiPrintNo", String.class);
        String printTime = JsonUtil.getInfo(ob, "PrintTime", String.class);
        String orderId = JsonUtil.getInfo(ob, "orderId", String.class);

        String contact = JsonUtil.getInfo(ob, "contact", String.class);
        if (!TextUtils.isEmpty(contact)) {
            billPrint.addText("联系人信息:" + contact + "\n", 1);
        }
        billPrint.addText("网络订单号:" + orderId + "\n", 1);
        billPrint.addText("打印时间:" + printTime + "\n", 1);
        billPrint.addLeftWithRight(fsDptrName, "印号:" + fiPrintNo, 1);

        billPrint.addBlankLine(1);
        billPrint.addCut();
        String beep = JsonUtil.getInfo(ob, "beep", String.class);
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }
        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }

    /**
     * 微信外卖厨房制作单小票
     *
     * @param ob
     * @param task
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/printwechatOrderkdsreceipt")
    public static PrintResult printwechatOrderkdsreceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        LogUtil.logBusiness("微信外卖厨房小票数据：" + ob.toString());
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addLine();
        billPrint.addCenterTextPaddingWithDash(JsonUtil.getInfo(ob, "title", String.class));
        String voidTitle = JsonUtil.getInfo(ob, "voidTitle", String.class);
        if (!TextUtils.isEmpty(voidTitle)) {
            billPrint.addCenterText(voidTitle + "\n");
        }
        String restNum = JsonUtil.getInfo(ob, "restNum", String.class);
        String orderNum = JsonUtil.getInfo(ob, "orderNum", String.class);//本地生产的订单号--一般是堂食订单用
        String eatType = JsonUtil.getInfo(ob, "eatType", String.class);

        if (!TextUtils.isEmpty(restNum)) {
            restNum = "#" + restNum;
        }

        if (TextUtils.isEmpty(orderNum)) {
            billPrint.addText(restNum + eatType + "\n", 2, 0, 0);
        } else {
            billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(ob, "eatType", String.class), billPrint.charSize / 4, billPrint.gbkSize) + PrintStringUtil.padLeft("订单号:" + JsonUtil.getInfo(ob, "orderNum", String.class), billPrint.charSize / 4, billPrint.gbkSize), 2, 0, 0);
        }
        billPrint.addLine();
        String pokeNo = JsonUtil.getString(ob, "pokeNo");
        if (!TextUtils.isEmpty(pokeNo)) {
            billPrint.addCenterText(pokeNo + "\n");
        }
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("菜名", "数量");
        billPrint.addHortionalLine();
        //微信外卖的菜
        JSONArray wechatOrderDetailList = JsonUtil.getInfo(ob, "orderDetailList", JSONArray.class);
        //兼容老版本
        if (wechatOrderDetailList == null) {
            wechatOrderDetailList = JsonUtil.getInfo(ob, "orderitem", JSONArray.class);
        }
        if (wechatOrderDetailList != null) {
            for (int i = 0; i < wechatOrderDetailList.size(); i++) {
                JSONObject item = wechatOrderDetailList.getJSONObject(i);
                String left = JsonUtil.getInfo(item, "fsItemName", String.class);
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(item, "fdSaleQty", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class));
                billPrint.addItemNameWithUnit(left, right, 2);

                String note = JsonUtil.getInfo(item, "ingredientNotes", String.class);
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }
            }
        }

        billPrint.addHortionalLine();

        String orderDesc = JsonUtil.getString(ob, "orderDesc");
        if (!TextUtils.isEmpty(orderDesc)) {
            billPrint.addText("备注:" + orderDesc + "\n");
            billPrint.addHortionalLine();
        }

        String fsDptrName = JsonUtil.getString(ob, "fsDptrName");
        String fiPrintNo = JsonUtil.getString(ob, "fiPrintNo");
        String printTime = JsonUtil.getString(ob, "PrintTime");
        String orderId = JsonUtil.getString(ob, "orderId");

        billPrint.addLeftWithRight("网络订单号:" + orderId, printTime, 1);
        billPrint.addLeftWithRight(fsDptrName, "印号:" + fiPrintNo, 1);

        billPrint.addBlankLine(1);
        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }

    /**
     * 构建标签打印格式-----修改模板的时候记得修改PrintManagerFragment(打印管理)里的标签打印模板哦
     *
     * @param ob
     * @return
     */
    public static List<PrintDataItem> buildPrintItem(JSONObject ob) {
        List<PrintDataItem> dataList = new ArrayList<>();

        String titleRemind = ob.getString("titleRemind");
        String shopName = ob.getString("shopname");
        String time = ob.getString("time");

        String tableNo = ob.getString("id");
        String unit = ob.getString("num");
        String seq = ob.getString("sequence");

        String itemName = ob.getString("itemname");
        String takeAway = ob.getString("takeaway");
        if (TextUtils.isEmpty(takeAway) || TextUtils.equals(takeAway, "null") || TextUtils.equals(takeAway, "NULL")) {
            takeAway = "";
        }
        String note = ob.getString("itemnote");
        String price = ob.getString("price");

        String phone = ob.getString("phone");
        if (TextUtils.isEmpty(phone)) {
            phone = "";
        }
        phone = phone.replace("-", "");

        int normalMarginTop = 0;
        if (TextUtils.isEmpty(note) && TextUtils.isEmpty(takeAway)) {
            normalMarginTop = 4;
        }

        PrintDataItem item = new PrintDataItem();
        if (!TextUtils.isEmpty(titleRemind)) {
            item.text = shopName + "(重打)";

        } else {
            item.text = shopName;
        }
        String addMenuLabel = JsonUtil.getString(ob, "addMenuLabel");
        if (TextUtils.isEmpty(addMenuLabel)) {
            addMenuLabel = "";
        }
        item.text = addMenuLabel + item.text;
        item.textAlign = PrintDataItem.ALIGN_LEFT;
        item.fontsize = 1;
        item.marginTop = 0;
        item.tscNextLine = true;
        dataList.add(item);

        PrintDataItem itemLine = new PrintDataItem();
        itemLine.text = "----------------------------";
        itemLine.textAlign = PrintDataItem.ALIGN_LEFT;
        itemLine.fontsize = 1;
        item.tscNextLine = true;
        itemLine.marginTop = -14;
        dataList.add(itemLine);

        String unitAndseq = TextUtils.isEmpty(unit) ? seq : unit + " " + seq;
        item = new PrintDataItem();
        item.text = formatLine(unitAndseq, tableNo);
        item.textAlign = PrintDataItem.ALIGN_LEFT;
        item.fontsize = 2;
        item.marginTop = normalMarginTop;
        item.tscNextLine = true;
        dataList.add(item);

        item = new PrintDataItem();
        item.text = formatLine(takeAway, itemName);
        item.textAlign = PrintDataItem.ALIGN_LEFT;
        item.fontsize = 2;
        item.marginTop = normalMarginTop;
        item.tscNextLine = true;
        dataList.add(item);

        if (TextUtils.isEmpty(note) && TextUtils.isEmpty(takeAway)) {
            item = new PrintDataItem();
            item.text = price;
            item.textAlign = PrintDataItem.ALIGN_RIGHT;
            item.fontsize = 2;
            item.tscNextLine = true;
            item.marginTop = 15;
            dataList.add(item);
        } else {
            if ((note.length() + price.length() + 1) / 12 > 0) {
                String[] result = sub(note, 12, 4);
                for (int i = 0; i < 3; i++) {
                    item = new PrintDataItem();
                    item.text = result[i];
                    item.textAlign = PrintDataItem.ALIGN_LEFT;
                    item.fontsize = 1;
                    item.tscNextLine = true;
                    dataList.add(item);
                }
                item = new PrintDataItem();
                item.text = formatLine(price, result[3]);
                item.textAlign = PrintDataItem.ALIGN_LEFT;
                item.fontsize = 1;
                item.tscNextLine = true;
                dataList.add(item);
            } else {
                item = new PrintDataItem();
                item.text = note;
                item.textAlign = PrintDataItem.ALIGN_LEFT;
                item.fontsize = 2;
                dataList.add(item);

                item = new PrintDataItem();
                item.text = price;
                item.textAlign = PrintDataItem.ALIGN_RIGHT;
                item.fontsize = 2;
                item.marginTop = 15;
                item.tscNextLine = true;
                dataList.add(item);

                item = new PrintDataItem();
                item.text = " ";
                item.textAlign = PrintDataItem.ALIGN_LEFT;
                item.fontsize = 1;
                item.tscNextLine = true;
                dataList.add(item);
            }

//            if ((note.length() + price.length() + 1) > 12) {
//                String fristNote = "";
//                String sencondNote = "";
//                if (note.length() > 12) {
//                    fristNote = note.substring(0, 12);
//                    sencondNote = note.substring(12);
//                } else {
//                    fristNote = note;
//                }
//                item = new PrintDataItem();
//                item.text = fristNote;
//                item.textAlign = PrintDataItem.ALIGN_LEFT;
//                item.fontsize = 2;
//                item.tscNextLine = true;
//                dataList.add(item);
//
//                item = new PrintDataItem();
//                item.text = formatLine(price, sencondNote);
//                item.textAlign = PrintDataItem.ALIGN_LEFT;
//                item.fontsize = 2;
//                item.tscNextLine = true;
//                dataList.add(item);
//            } else {
//                item = new PrintDataItem();
//                item.text = note;
//                item.textAlign = PrintDataItem.ALIGN_LEFT;
//                item.fontsize = 2;
//                dataList.add(item);
//
//                item = new PrintDataItem();
//                item.text = price;
//                item.textAlign = PrintDataItem.ALIGN_RIGHT;
//                item.fontsize = 2;
//                item.marginTop = 15;
//                item.tscNextLine = true;
//                dataList.add(item);
//
//                item = new PrintDataItem();
//                item.text = " ";
//                item.textAlign = PrintDataItem.ALIGN_LEFT;
//                item.fontsize = 1;
//                item.tscNextLine = true;
//                dataList.add(item);
//            }
        }

        item = new PrintDataItem();
        item.text = "----------------------------";
        item.textAlign = PrintDataItem.ALIGN_LEFT;
        item.fontsize = 1;
        item.marginTop = -10;
        item.tscNextLine = true;
        dataList.add(item);

        item = new PrintDataItem();
        item.text = time + " " + phone;
        item.tscNextLine = true;
        item.marginTop = -10;
        item.textAlign = PrintDataItem.ALIGN_LEFT;
        item.fontsize = 1;
        dataList.add(item);

        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            item = new PrintDataItem();
            item.text = "";
            item.dataFormat = PrintDataItem.FORMAT_BEEP;
            dataList.add(item);
        }
        return dataList;
    }

    private static String[] sub(String a, int length, int size) {
        String[] as = new String[size];
        for (int i = 0; i < size; i++) {
            if (a.length() > (i + 1) * length) {
                as[i] = a.substring(i * length, (i + 1) * length);
            } else {
                if (i * length < a.length()) {
                    as[i] = a.substring(i * length);
                } else {
                    as[i] = " ";
                }
            }
        }
        return as;
    }

    /**
     * 格式化一行数据
     *
     * @param right
     * @param left
     * @return
     */
    private static String formatLine(String right, String left) {
        String newLeftStr = "";
        int leftcount = 25;

        if (!TextUtils.isEmpty(right)) {
            leftcount = 25 - getSBCCaseLength(right);
        }
        //左侧剩余空间可放置字符数

        if (leftcount > 0) {
            if (TextUtils.isEmpty(left)) {
                newLeftStr = "";
            } else {
                newLeftStr = truncation(leftcount, left);
            }
        }

        return !TextUtils.isEmpty(right) ? newLeftStr + right : newLeftStr;
    }

    /**
     * 截断字符
     *
     * @param leftcount
     * @param leftStr
     * @return
     */
    private static String truncation(int leftcount, String leftStr) {
        int i = 0;
        boolean enugth = true;

        StringBuffer sb = new StringBuffer();
        char[] arr = leftStr.toCharArray();
        for (int j = 0; j < arr.length; j++) {
            char a = arr[j];
            i += getSBCCaseLength(String.valueOf(a));
            if (i > leftcount) {
                if (j < arr.length) {
                    enugth = false;
                }
                break;
            }
            sb.append(a);
        }

        if (enugth) {
            int ab = getSBCCaseLength(sb.toString());
            if (leftcount >= ab) {
                for (int x = ab; x < leftcount; x++) {
                    sb.append(" ");
                }
            }
        } else {
            String s = sb.toString().substring(0, sb.length() - 1);
            return s + "...";
        }

        return sb.toString();
    }

    public static int getSBCCaseLength(String text) {
        if (text != null && text.length() != 0) {
            try {
                return text.getBytes("GBK").length;
            } catch (UnsupportedEncodingException var2) {
                var2.printStackTrace();
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * 制作单单品打印
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/makesingle")
    public static PrintResult processMakeSingle(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        if (TextUtils.equals(PrinterCommand.TSC, config.commandType)) {
            return DinnerPrintProcessor.submitToPrinter(taskModel, buildPrintItem(ob), config);
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        String addMenuLabel = JsonUtil.getString(ob, "addMenuLabel");
        if (TextUtils.isEmpty(addMenuLabel)) {
            addMenuLabel = "";
        }

        if (APPConfig.isMyd()) {
            billPrint.addTitle(addMenuLabel + "${Dept.fsDeptName}制作单单品".replace("${Dept.fsDeptName}", JsonUtil.getString(dept, "fsDeptName")) + titleRemind);
        } else {
            //air3.7普通制作单调整
            billPrint.addCenterText("本店(单品)", 2, 0, "-");
        }
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String phone = JsonUtil.getString(sell, "fsCustMobile");
        if (!TextUtils.isEmpty(phone)) {
            billPrint.addBlankLine();
            billPrint.addText("尾号" + phone + "的预订顾客已到店下单\n", 1, PrintDataItem.ALIGN_CENTRE, 0);
        }

//        billPrint.addLine();


        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        if (fillKind == null) {
            fillKind = "";
        }
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }

        String eatType = JsonUtil.getString(ob, "eatType");
        if (!TextUtils.isEmpty(eatType)) {
            billPrint.addText(eatType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno"), JsonUtil.getString(sell, "fsMTableName"));
        billPrint.addBlankLine();
        if (APPConfig.isMyd()) {
            billPrint.addLeftWithRight("人数:" + JsonUtil.getString(sell, "fiCustSum"), "下单:" + JsonUtil.getString(ob, "fsCreateUserName"), 1);
        } else {
            billPrint.addText("人数:" + JsonUtil.getString(sell, "fiCustSum") + "\n", 1);
        }
        billPrint.addHortionaDoublelLine();
        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        JSONObject item = null;
        if (list == null || list.size() < 1) {
            item = new JSONObject();
        } else {
            item = list.getJSONObject(0);
        }
        String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
        String fsSpecialNote = JsonUtil.getString(item, "fsSpecialNote");
        String left = fsSpecialNote + JsonUtil.getString(item, "fsItemName");
        String waitInfo = JsonUtil.getString(item, "SfiItemMakeState") + "";
        String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
        billPrint.addItemNameWithUnit(left, right, 2);
        billPrint.addBlankLine(1);
        // 等叫
        if (!TextUtils.isEmpty(waitInfo)) {
            billPrint.addText("  " + waitInfo + "\n", 2);
        }
        if (TextUtils.equals("3", fiOrderItemKind)) {  //套餐明细要打印出所属的套餐头
            String parentItemName = JsonUtil.getString(item, "parentItemName");
            if (!TextUtils.isEmpty(parentItemName)) {
                billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
            }
        }
        String note = JsonUtil.getString(item, "fsGeneralNote");
        if (!TextUtils.isEmpty(note)) {
            billPrint.addOrderModifier(note, 2);
        }
        String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
        if (!TextUtils.isEmpty(ingredientNote)) {
            String[] ingredientArr = ingredientNote.split("\n");
            for (String ingredient : ingredientArr) {
                billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
            }
        }

        billPrint.addHortionalLine();
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight("下单:" + JsonUtil.getString(ob, "fsCreateUserName"), "打印部门:" + JsonUtil.getString(dept, "fsDeptName"));
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(DateUtil.getCurrentTime(), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);
        billPrint.addLine();


        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 标签打印
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/makesingleTSC")
    public static PrintResult makesingleTSC(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        ob.put("titleRemind", titleRemind);

        return DinnerPrintProcessor.submitToPrinter(taskModel, buildPrintItem(ob), config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/void")
    public static PrintResult processvoid(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("${Dept.fsDeptName}－退菜单".replace("${Dept.fsDeptName}", JsonUtil.getString(dept, "fsDeptName")) + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        billPrint.addText("下单时间：" + JsonUtil.getString(ob, "orderTime") + "\n", 1);
        billPrint.addHortionaDoublelLine();

        JSONArray sellOrders = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);
        if (sellOrders != null && sellOrders.size() > 0) {
            for (int i = 0; i < sellOrders.size(); i++) {
                JSONObject sellOrder = sellOrders.getJSONObject(i);
                String left = "[退]" + JsonUtil.getString(sellOrder, "fsItemName");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(sellOrder, "fdBackQty"), JsonUtil.getString(sellOrder, "fsOrderUint"));
                billPrint.addItemNameWithUnit(left, right, 2);
                String voidReasons = JsonUtil.getString(sellOrder, "fsBackReason");
                if (!TextUtils.isEmpty(voidReasons)) {
                    billPrint.addOrderModifier("理由:" + voidReasons, 1);
                }
                String fiOrderItemKind = JsonUtil.getString(sellOrder, "fiOrderItemKind");
                //套餐明细要打印出所属的套餐头
                if (TextUtils.equals("3", fiOrderItemKind)) {
                    String parentItemName = JsonUtil.getString(sellOrder, "parentItemName");
                    if (!TextUtils.isEmpty(parentItemName)) {
                        billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
                    }
                }
                StringBuilder sbNote = new StringBuilder();
                String ingredientNote = JsonUtil.getString(sellOrder, "ingredientNotes");
                if (!TextUtils.isEmpty(ingredientNote)) {
                    sbNote.append(ingredientNote).append("   ");
                }
                String note = JsonUtil.getString(sellOrder, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    sbNote.append(note).append("   ");
                }
                //sbNote.append(JsonUtil.getString(sellOrder, "fsBackReason"));
                if (sbNote.length() > 0) {
                    billPrint.addText(sbNote.toString() + "\n", 1, PrintDataItem.ALIGN_LEFT, 0);
                }
            }
        }

        //兼容老版本
        JSONObject sellOrder = JsonUtil.getInfo(ob, "SellOrder", JSONObject.class);
        if (sellOrder != null) {
            String left = "[退]" + JsonUtil.getString(sellOrder, "fsItemName");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(sellOrder, "fdBackQty"), JsonUtil.getString(sellOrder, "fsOrderUint"));
            billPrint.addItemNameWithUnit(left, right, 2);
            String voidReasons = JsonUtil.getString(sellOrder, "fsBackReason");
            if (!TextUtils.isEmpty(voidReasons)) {
                billPrint.addOrderModifier("理由:" + voidReasons, 1);
            }
            String fiOrderItemKind = JsonUtil.getString(sellOrder, "fiOrderItemKind");
            //套餐明细要打印出所属的套餐头
            if (TextUtils.equals("3", fiOrderItemKind)) {
                String parentItemName = JsonUtil.getString(sellOrder, "parentItemName");
                if (!TextUtils.isEmpty(parentItemName)) {
                    billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
                }
            }
            StringBuilder sbNote = new StringBuilder();
            String ingredientNote = JsonUtil.getString(sellOrder, "ingredientNotes");
            if (!TextUtils.isEmpty(ingredientNote)) {
                sbNote.append(ingredientNote).append("   ");
            }
            String note = JsonUtil.getString(sellOrder, "fsNote");
            if (!TextUtils.isEmpty(note)) {
                sbNote.append(note).append("   ");
            }
            //sbNote.append(JsonUtil.getString(sellOrder, "fsBackReason"));
            if (sbNote.length() > 0) {
                billPrint.addText(sbNote.toString() + "\n", 1, PrintDataItem.ALIGN_LEFT, 0);
            }

        }

        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/voidIngredient")
    public static PrintResult changeIngredient(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addTitle(JsonUtil.getString(dept, "fsDeptName") + "-" + JsonUtil.getString(ob, "title") + taskModel.titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String fiSellType = JsonUtil.getString(sell, "fiSellType");
        if (TextUtils.equals("0", fiSellType)) {
            billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        } else {
            billPrint.addMealNoWaiterName("单号:", JsonUtil.getString(sell, "fssellno") + "", "牌号:", JsonUtil.getString(sell, "fsMTableName") + "");
        }
        billPrint.addText("下单时间：" + JsonUtil.getString(ob, "orderTime") + "\n", 1);

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "ingredientItems", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = "[退]" + JsonUtil.getString(item, "fsItemName");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
            billPrint.addItemNameWithUnit(left, right, 2);
            String voidReasons = JsonUtil.getString(item, "fsBackReason");
            if (!TextUtils.isEmpty(voidReasons)) {
                billPrint.addOrderModifier("理由:" + voidReasons, 1);
            }
        }
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("下单：" + JsonUtil.getString(sell, "waiterName"));
        billPrint.addBlankLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/addIngredient")
    public static PrintResult addIngredient(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addTitle(JsonUtil.getString(dept, "fsDeptName") + "-" + JsonUtil.getString(ob, "title") + taskModel.titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String fiSellType = JsonUtil.getString(sell, "fiSellType");
        if (TextUtils.equals("0", fiSellType)) {
            billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        } else {
            billPrint.addMealNoWaiterName("单号:", JsonUtil.getString(sell, "fssellno") + "", "牌号:", JsonUtil.getString(sell, "fsMTableName") + "");
        }

        billPrint.addHortionaDoublelLine();


        JSONArray list = JsonUtil.getInfo(ob, "ingredientItems", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = "" + JsonUtil.getString(item, "fsItemName");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
            billPrint.addItemNameWithUnit(left, right, 2);
        }
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("下单：" + JsonUtil.getString(sell, "waiterName"));
        billPrint.addBlankLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/voidPackageItems")
    public static PrintResult voidPackageItems(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addTitle(JsonUtil.getString(dept, "fsDeptName") + "-" + JsonUtil.getString(ob, "title") + taskModel.titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String fiSellType = JsonUtil.getString(sell, "fiSellType");
        if (TextUtils.equals("0", fiSellType)) {
            billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        } else {
            billPrint.addMealNoWaiterName("单号:", JsonUtil.getString(sell, "fssellno") + "", "牌号:", JsonUtil.getString(sell, "fsMTableName") + "");
        }
        billPrint.addText("下单时间：" + JsonUtil.getString(ob, "orderTime") + "\n", 1);

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "packageItems", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = "[退]" + JsonUtil.getString(item, "fsItemName");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
            billPrint.addItemNameWithUnit(left, right, 2);
            String voidReasons = JsonUtil.getString(item, "fsBackReason");
            if (!TextUtils.isEmpty(voidReasons)) {
                billPrint.addOrderModifier("理由:" + voidReasons, 1);
            }
            String note = JsonUtil.getInfo(item, "fsNote", String.class);
            if (!TextUtils.isEmpty(note)) {
                billPrint.addText("-" + note);
                billPrint.addBlankLine();
            }
        }
        billPrint.addBlankLine();
        billPrint.addOrderModifier("-(属于)" + JsonUtil.getString(ob, "packageName"), 2);
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("下单：" + JsonUtil.getString(sell, "waiterName"));
        billPrint.addBlankLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    @DrivenMethod(uri = DRIVER_TAG + "/addPackageItems")
    public static PrintResult addPackageItems(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        billPrint.addTitle(JsonUtil.getString(dept, "fsDeptName") + "-" + JsonUtil.getString(ob, "title") + taskModel.titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String fiSellType = JsonUtil.getString(sell, "fiSellType");
        if (TextUtils.equals("0", fiSellType)) {
            billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        } else {
            billPrint.addMealNoWaiterName("单号:", JsonUtil.getString(sell, "fssellno") + "", "牌号:", JsonUtil.getString(sell, "fsMTableName") + "");
        }

        billPrint.addHortionaDoublelLine();


        JSONArray list = JsonUtil.getInfo(ob, "packageItems", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = "" + JsonUtil.getString(item, "fsItemName");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
            billPrint.addItemNameWithUnit(left, right, 2);
            String note = JsonUtil.getInfo(item, "fsNote", String.class);
            if (!TextUtils.isEmpty(note)) {
                billPrint.addText("-" + note);
                billPrint.addBlankLine();
            }
        }
        billPrint.addBlankLine();
        billPrint.addOrderModifier("-(属于)" + JsonUtil.getString(ob, "packageName"), 2);
        billPrint.addBlankLine();
        billPrint.addHortionalLine();
        billPrint.addText("下单：" + JsonUtil.getString(sell, "waiterName"));
        billPrint.addBlankLine();
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    /**
     * 催菜单
     */
    @DrivenMethod(uri = DRIVER_TAG + "/remindDish")
    public static PrintResult processRemindDish(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder printBizBuilder = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        printBizBuilder.addTitle("催菜单" + titleRemind);
        printBizBuilder.addLine();
        printBizBuilder.addOrderNoTableNo(JsonUtil.getString(ob, "fssellno") + "", JsonUtil.getString(ob, "fsMTableName") + "");

        printBizBuilder.addHortionalLine();
        JSONArray sellOrders = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);
        for (int i = 0; i < sellOrders.size(); i++) {
            JSONObject menuItem = sellOrders.getJSONObject(i);

            printBizBuilder.addItemNameWithUnit(JsonUtil.getString(menuItem, "fsItemName"), PrintUtil.optBuyNumAndUnit(JsonUtil.getString(menuItem, "fdSaleQty"), JsonUtil.getString(menuItem, "fsOrderUint")), 2);

            String note = JsonUtil.getString(menuItem, "fsNote");
            if (!TextUtils.isEmpty(note)) {
                printBizBuilder.addOrderModifier(note, 1);
            }

            long waitTime = JsonUtil.getInfo(menuItem, "waitTime", long.class);
            if (waitTime == 0) {
                waitTime = 1;
            }
            printBizBuilder.addText("等待" + waitTime + "分钟,第" + JsonUtil.getString(menuItem, "fiHurryTimes") + "次催菜\n", 1, 0, 1);

            String ingredientNote = JsonUtil.getString(menuItem, "ingredientNotes");
            if (!TextUtils.isEmpty(ingredientNote)) {
                String[] ingredientArr = ingredientNote.split("\n");
                for (String ingredient : ingredientArr) {
                    printBizBuilder.addOrderModifier(ingredient.replace("\n", ""), 1);
                }
            }
        }

        String ingredientNote = JsonUtil.getString(ob, "ingredientNotes");
        if (!TextUtils.isEmpty(ingredientNote)) {
            String[] ingredientArr = ingredientNote.split("\n");
            for (String ingredient : ingredientArr) {
                printBizBuilder.addOrderModifier(ingredient.replace("\n", ""), 1);
            }
        }

        printBizBuilder.addHortionaDoublelLine();
        printBizBuilder.addLeftWithRight("操作:" + JsonUtil.getString(ob, "PrintUser"), "打印部门:" + JsonUtil.getString(ob, "Dept"));
        printBizBuilder.addLeftWithRight("打印时间:" + DateUtil.getCurrentTime(), "印号:" + JsonUtil.getString(ob, "fiPrintNo"));
        printBizBuilder.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, printBizBuilder.data, config);
    }

    /**
     * 转菜单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/transfer")
    public static PrintResult processTransfer(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("转菜单" + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        billPrint.addText("单号：" + JsonUtil.getString(sell, "fssellno") + "\n");
        billPrint.addText("菜品从:");
        billPrint.addText(JsonUtil.getString(ob, "fromtablename") + "\n", 2);
        billPrint.addText("转到:");
        billPrint.addText(JsonUtil.getString(ob, "totablename") + "\n", 2);

        billPrint.addHortionaDoublelLine();

        JSONArray sellOrders = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        for (int i = 0; i < sellOrders.size(); i++) {
            JSONObject item = sellOrders.getJSONObject(i);
            String left = JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");

            BigDecimal fdSaleQty = JsonUtil.getInfo(item, "fdSaleQty", BigDecimal.class);
            BigDecimal fdBackQty = JsonUtil.getInfo(item, "fdBackQty", BigDecimal.class);
            String num = "1";
            if (fdSaleQty != null) {
                if (fdBackQty != null) {
                    fdSaleQty = fdSaleQty.subtract(fdBackQty);
                }
                num = fdSaleQty.toPlainString();
            }

            String right = PrintUtil.optBuyNumAndUnit(num, JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);
            String note = JsonUtil.getString(item, "fsNote");
            if (!TextUtils.isEmpty(note)) {
                billPrint.addOrderModifier(note, 1);
            }

            String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
            if (!TextUtils.isEmpty(ingredientNote)) {
                String[] ingredientArr = ingredientNote.split("\n");
                for (String ingredient : ingredientArr) {
                    billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                }
            }
        }

        String ingredientNote = JsonUtil.getString(ob, "ingredientNote");
        if (!TextUtils.isEmpty(ingredientNote)) {
            String[] ingredientArr = ingredientNote.split("\n");
            for (String ingredient : ingredientArr) {
                billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
            }
        }

        billPrint.addBlankLine(1);

        billPrint.addHortionalLine();

        billPrint.addLeftWithRight("下单:" + JsonUtil.getString(ob, "PrintUser"), "打印部门:" + JsonUtil.getString(ob, "Dept"));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 起菜单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/waitcall")
    public static PrintResult waitCall(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("起菜单" + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fssellno") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        billPrint.addHortionaDoublelLine();

        JSONArray sellOrders = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        for (int i = 0; i < sellOrders.size(); i++) {
            JSONObject item = sellOrders.getJSONObject(i);
            String left = JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");

            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);
            String note = JsonUtil.getString(item, "fsNote");
            if (!TextUtils.isEmpty(note)) {
                billPrint.addOrderModifier(note, 1);
            }

            String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
            if (!TextUtils.isEmpty(ingredientNote)) {
                String[] ingredientArr = ingredientNote.split("\n");
                for (String ingredient : ingredientArr) {
                    billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                }
            }
        }
        String ingredientNote = JsonUtil.getString(ob, "ingredientNote");
        if (!TextUtils.isEmpty(ingredientNote)) {
            String[] ingredientArr = ingredientNote.split("\n");
            for (String ingredient : ingredientArr) {
                billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
            }
        }
        billPrint.addBlankLine(1);

        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("下单:" + JsonUtil.getString(ob, "fsCreateUserName"), "打印部门:" + JsonUtil.getString(ob, "Dept"));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 点菜单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/menulist")
    public static PrintResult menulist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("点菜单" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }

        String eatType = JsonUtil.getString(ob, "eatType");
        if (!TextUtils.isEmpty(eatType)) {
            billPrint.addText(eatType + "\n", 2);
        }

        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fsSellNo") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        billPrint.addBlankLine();
        billPrint.addLeftWithRight("点菜:" + JsonUtil.getString(ob, "PrintUser"), "人数:" + JsonUtil.getString(sell, "fiCustSum"));

        String reservationTime = JsonUtil.getString(sell, "reservationTime");
        String reservationTimeStr = "";
        if(!TextUtils.isEmpty(reservationTime)){
            reservationTimeStr = "预约时间:"+reservationTime;
        }
        billPrint.addLeftWithRight(reservationTimeStr , "餐段:" + JsonUtil.getString(sell, "fsMSectionName"));

        String isAllWaitCall = JsonUtil.getString(ob, "isAllWaitCall");
        if (TextUtils.equals(isAllWaitCall, "1")) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单等叫", 2);
        }

        String wholeNote = JsonUtil.getString(ob, "wholeNote");
        if (!TextUtils.isEmpty(wholeNote)) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单备注："+wholeNote, 2);
        }

        billPrint.addHortionaDoublelLine();
        String needPrice = JsonUtil.getString(ob, "printPrice");


        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        if (list != null) {
            //普通菜品列表
            List<JSONObject> menuList = new ArrayList<>();
            //餐标模式下计入餐标的菜品列表
            List<JSONObject> dinnerStandardMenuList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                if (item != null) {
                    if (TextUtils.equals(item.getString("fiWithinDiningStandard"), "1")) {
                        dinnerStandardMenuList.add(item);
                    } else {
                        menuList.add(item);
                    }
                }
            }
            //餐标模式下，计入餐标的菜品是否打印菜品金额开关
            String showPrice = JsonUtil.getString(ob, "diningStandardPrintConfig");
            String fdDiningStandardAmt = JsonUtil.getString(sell, "fdDiningStandardAmt");
            if (TextUtils.equals("1", needPrice)) {
                billPrint.addOrderItem(
                        GlobalCache.getContext().getString(R.string.print_item),
                        "",
                        GlobalCache.getContext().getResources().getString(R.string.print_qty),
                        GlobalCache.getContext().getResources().getString(R.string.amount), 1);
                billPrint.addHortionalLine();

                //计入餐标的菜品不为空时，先打印，不计入餐标的菜品 后打印
                if (!ListUtil.isEmpty(dinnerStandardMenuList)) {
                    printMenuItem(dinnerStandardMenuList, billPrint, !"1".equals(showPrice));
                    billPrint.addCenterTextPaddingWithDash("以上为用餐标准内菜品(" + fdDiningStandardAmt + ")");
                }
                printMenuItem(menuList, billPrint, true);

                billPrint.addHortionalLine();
                billPrint.addOrderItem("合计:",
                        "",
                        JsonUtil.getString(ob, "Sub"),
                        JsonUtil.getString(ob, "subTotalPrice"),
                        2);
            } else {
                //计入餐标的菜品不为空时，先打印，不计入餐标的菜品 后打印
                if (!ListUtil.isEmpty(dinnerStandardMenuList)) {
                    printMenuItem(dinnerStandardMenuList, billPrint, !"1".equals(showPrice));
                    billPrint.addCenterTextPaddingWithDash("以上为用餐标准内菜品(" + fdDiningStandardAmt + ")");
                }
                for (int i = 0; i < menuList.size(); i++) {
                    JSONObject item = menuList.get(i);
                    String left = JsonUtil.getString(item, "fsItemName");
                    String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                    String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
                    billPrint.addItemNameWithUnit(left, right, 2);

                    JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
                    if (slit != null && slit.size() > 0) {
                        for (int m = 0; m < slit.size(); m++) {
                            JSONObject itemS = slit.getJSONObject(m);
                            billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + JsonUtil.getString(itemS, "fdSaleQty"), 1);

                            //配料不打印要求
                            if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                                String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                                if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                                    billPrint.addOrderModifier2(note.trim(), 1);
                                }
                            }
                        }
                    }

                    JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
                    if (ingredientList != null && ingredientList.size() > 0) {
                        for (int m = 0; m < ingredientList.size(); m++) {
                            JSONObject itemS = ingredientList.getJSONObject(m);
                            billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getString(itemS, "fdSaleQty"), JsonUtil.getString(itemS, "fsOrderUint")), 1);
                        }
                    }

                    Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
                    if (!(fiOrderItemKind != null && fiOrderItemKind == 4)) {
                        // 等叫
                        if (!TextUtils.isEmpty(waitInfo)) {
                            billPrint.addText("  " + waitInfo + "\n", 2);
                        }
                        String note = JsonUtil.getString(item, "fsNote");
                        if (!TextUtils.isEmpty(note)) {
                            billPrint.addOrderModifier2(note, 1);
                        }
                    }
                    billPrint.addBlankLine(1);
                }
                billPrint.addHortionalLine();
                billPrint.addLeftWithRightBig("", "", "合计:" + JsonUtil.getString(ob, "Sub"));
            }

        }
//        billPrint.addText("合计:" + JsonUtil.getString(ob, "Sub") + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);


        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    private static void printMenuItem(List<JSONObject> menuItemList, PrintBizBuilder billPrint, boolean showPrice) {
        for (int i = 0; i < menuItemList.size(); i++) {
            JSONObject item = menuItemList.get(i);
            String unit = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
            String saleAmt = JsonUtil.getInfo(item, "fdsaleamt", String.class);
            if (!showPrice) {
                saleAmt = "";
            }
            billPrint.addOrderItem(JsonUtil.getInfo(item, "fsItemName", String.class),
                    "",
                    unit,
                    "" + saleAmt,
                    1);
            //配料不打印要求
            if (!TextUtils.equals("4", JsonUtil.getInfo(item, "fiOrderItemKind", String.class))) {
                // 等叫
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                if (!TextUtils.isEmpty(waitInfo)) {
                    billPrint.addText("  " + waitInfo + "\n", 2);
                }
                String note = JsonUtil.getInfo(item, "fsNote", String.class);
                if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                    billPrint.addOrderModifier2(note.trim(), 1);
                }
            }
            // //add modifier print
            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                billPrint.addBlankLine(1);
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsitemname", String.class) + "*" + JsonUtil.getInfo(itemS, "qty", String.class), 1);

                    //配料不打印要求
                    if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                        String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                        if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                            billPrint.addOrderModifier2(note.trim(), 1);
                        }
                    }
                }
            }
            JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
            if (ingredientList != null && ingredientList.size() > 0) {
                billPrint.addBlankLine(1);
                for (int m = 0; m < ingredientList.size(); m++) {
                    JSONObject itemS = ingredientList.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getString(itemS, "fdSaleQty"), JsonUtil.getString(itemS, "fsOrderUint")) + "*" + JsonUtil.getString(itemS, "fdsaleamt"), 1);
                }
            }
            billPrint.addBlankLine(1);
        }
    }

    /**
     * 点菜预览单 未下厨
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/temp_pre_menulist")
    public static PrintResult tempPremenulist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("点菜预览单(未下厨)" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fsSellNo") + "", JsonUtil.getString(sell, "fsMTableName") + "");

        billPrint.addLeftWithRight("点菜:" + JsonUtil.getString(ob, "PrintUser"), "人数:" + JsonUtil.getString(sell, "fiCustSum"));

        billPrint.addLeftWithRight("日期:" + JsonUtil.getString(sell, "fsSellDate"), "餐段:" + JsonUtil.getString(sell, "fsMSectionName"));
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);

            Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
            if (!(fiOrderItemKind != null && fiOrderItemKind.intValue() == 4)) {
                String note = JsonUtil.getString(item, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier2(note, 1);
                }
            }

            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + JsonUtil.getString(itemS, "fdSaleQty"), 1);

                    //配料不打印要求
                    if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                        String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                        if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                            billPrint.addOrderModifier2(note.trim(), 1);
                        }
                    }
                }
            }

            JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
            if (ingredientList != null && ingredientList.size() > 0) {
                for (int m = 0; m < ingredientList.size(); m++) {
                    JSONObject itemS = ingredientList.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getString(itemS, "fdSaleQty"), JsonUtil.getString(itemS, "fsOrderUint")), 1);
                }
            }


            billPrint.addBlankLine(1);
        }

        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getString(ob, "Sub") + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    /**
     * 点菜预览单 已下厨
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/pre_menulist")
    public static PrintResult premenulist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("点菜预览单(已下厨)" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fsSellNo") + "", JsonUtil.getString(sell, "fsMTableName") + "");

        billPrint.addLeftWithRight("点菜:" + JsonUtil.getString(ob, "PrintUser"), "人数:" + JsonUtil.getString(sell, "fiCustSum"));

        billPrint.addLeftWithRight("日期:" + JsonUtil.getString(sell, "fsSellDate"), "餐段:" + JsonUtil.getString(sell, "fsMSectionName"));
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);


            Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
            if (!(fiOrderItemKind != null && fiOrderItemKind.intValue() == 4)) {
                String note = JsonUtil.getString(item, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier2(note, 1);
                }
            }

            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + JsonUtil.getString(itemS, "fdSaleQty"), 1);

                    //配料不打印要求
                    if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                        String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                        if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                            billPrint.addOrderModifier2(note.trim(), 1);
                        }
                    }
                }
            }

            JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
            if (ingredientList != null && ingredientList.size() > 0) {
                for (int m = 0; m < ingredientList.size(); m++) {
                    JSONObject itemS = ingredientList.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getString(itemS, "fdSaleQty"), JsonUtil.getString(itemS, "fsOrderUint")), 1);
                }
            }

            billPrint.addBlankLine(1);
        }

        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getString(ob, "Sub") + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }


    /**
     * 秒点确认单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/rapid_menulist")
    public static PrintResult rapidmenuConfirmlist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("秒点确认单" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addBlankLine();
        billPrint.addLeftWithRightBig("打印:" + JsonUtil.getString(ob, "PrintUser"), "台位:", JsonUtil.getString(sell, "fsMTableName") + "");

        billPrint.addLeftWithRight("日期:" + JsonUtil.getString(sell, "fsSellDate"), "人数:" + JsonUtil.getString(sell, "fiCustSum"));

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            String left = JsonUtil.getString(item, "fsItemName");
            String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
            String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint")) + waitInfo;
            billPrint.addItemNameWithUnit(left, right, 2);

            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + JsonUtil.getString(itemS, "fdSaleQty"), 1);

                    //配料不打印要求
                    if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                        String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                        if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                            billPrint.addOrderModifier2(note.trim(), 1);
                        }
                    }
                }
            }

            JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
            if (ingredientList != null && ingredientList.size() > 0) {
                for (int m = 0; m < ingredientList.size(); m++) {
                    JSONObject itemS = ingredientList.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getString(itemS, "fsItemName") + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getString(itemS, "fdSaleQty"), JsonUtil.getString(itemS, "fsOrderUint")), 1);
                }
            }

            Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
            if (!(fiOrderItemKind != null && fiOrderItemKind.intValue() == 4)) {
                String note = JsonUtil.getString(item, "fsNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier2(note, 1);
                }
            }
            billPrint.addBlankLine(1);
        }

        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getString(ob, "Sub") + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 传菜单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/passto")
    public static PrintResult passto(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("传菜单" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        String orderType = "";
        String fillKind = JsonUtil.getString(sell, "fiBillKind");
        switch (fillKind) {
            case "8":
                orderType = "打包";
                break;
            case "9":
                orderType = "外卖";
                break;
            default:
                break;
        }
        if (!TextUtils.isEmpty(orderType)) {
            billPrint.addText(orderType + "\n", 2);
        }
        billPrint.addOrderNoTableNo(JsonUtil.getString(sell, "fsSellNo") + "", JsonUtil.getString(sell, "fsMTableName") + "");
        String reservationTime = JsonUtil.getString(sell, "reservationTime");
        billPrint.addLeftWithRight("人数:" + JsonUtil.getString(sell, "fiCustSum"), TextUtils.isEmpty(reservationTime) ? "" : "预约时间:" + reservationTime);

        String isAllWaitCall = JsonUtil.getString(ob, "isAllWaitCall");
        if (TextUtils.equals(isAllWaitCall, "1")) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单等叫", 2);
        }

        String wholeNote = JsonUtil.getString(ob, "wholeNote");
        if (!TextUtils.isEmpty(wholeNote)) {
            billPrint.addBlankLine();
            billPrint.addCenterText("整单备注："+wholeNote, 2);
        }

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
                if (TextUtils.equals("2", fiOrderItemKind)) {  //不打印套餐头
                    continue;
                }
                String left = JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
                billPrint.addItemNameWithUnit(left, right, 2);
                // 等叫
                if (!TextUtils.isEmpty(waitInfo)) {
                    billPrint.addText("  " + waitInfo + "\n", 2);
                }
                //套餐明细要打印出所属的套餐头
                if (TextUtils.equals("3", fiOrderItemKind)) {
                    String parentItemName = JsonUtil.getString(item, "parentItemName");
                    if (!TextUtils.isEmpty(parentItemName)) {
                        billPrint.addOrderModifier("-(属于)" + parentItemName, 1);
                    }
                }
                //配料菜不打印要求备注等
                if (!TextUtils.equals("4", fiOrderItemKind)) {
                    String note = JsonUtil.getString(item, "fsNote");
                    if (!TextUtils.isEmpty(note)) {
                        billPrint.addOrderModifier2(note, 1);
                    }
                }
                billPrint.addBlankLine(1);
            }
        }

        billPrint.addHortionalLine();

//        billPrint.addText(PrintStringUtil.padLeft("合计:" + JsonUtil.getString(ob, "Sub")+ "\n", 28, 2, billPrint.gbkSize));
        billPrint.addLeftWithRightBig("", "", "合计:" + JsonUtil.getString(ob, "Sub"));

        billPrint.addHortionalLine();

        String serviceScore = JsonUtil.getString(ob, "serviceScore");
        String commentsMessages = JsonUtil.getString(ob, "commentsMessages");
        String tags = JsonUtil.getString(ob, "tags");

        if (!TextUtils.isEmpty(serviceScore) || !TextUtils.isEmpty(commentsMessages) || !TextUtils.isEmpty(tags)) {

            if (!TextUtils.isEmpty(serviceScore)) {
                billPrint.addLeftWithRightBig("", "", "上次消费评分:" + serviceScore);
            }
            if (!TextUtils.isEmpty(commentsMessages)) {
                billPrint.addLeftWithRightBig("", "", "用户留言:" + commentsMessages);
            }
            if (!TextUtils.isEmpty(tags)) {
                billPrint.addLeftWithRightBig("", "", "用户所选标签:" + tags);
            }
            billPrint.addHortionalLine();
        }


        String memberLevel = JsonUtil.getString(ob, "memberLevel");
        String sex = JsonUtil.getString(ob, "sex");
        String cardBalance = JsonUtil.getString(ob, "cardBalance");
        if (!TextUtils.isEmpty(memberLevel) || !TextUtils.isEmpty(sex) || !TextUtils.isEmpty(cardBalance)) {
            billPrint.addLeftWithRight("会员信息", "");
            if (!TextUtils.isEmpty(memberLevel)) {
                billPrint.addLeftWithRight("会员等级: " + memberLevel, "");
            }
            if (!TextUtils.isEmpty(sex)) {
                billPrint.addLeftWithRight("性别: " + sex, "");
            }
            if (!TextUtils.isEmpty(cardBalance)) {
                billPrint.addLeftWithRight("储值余额: " + cardBalance, "");
            }
            billPrint.addHortionalLine();
        }


        billPrint.addLeftWithRight("下单:" + JsonUtil.getString(ob, "fsCreateUserName"), "打印部门:" + JsonUtil.getString(ob, "Dept"));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/crossPay")
    public static PrintResult b(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle("销账单");
        billPrint.addHortionaDoublelLine();
        CrossPayPrintInfo crossPayInfo = ob.getObject("crossPayInfo", CrossPayPrintInfo.class);
        billPrint.addText("店名：" + JsonUtil.getInfo(ob, "shop", String.class) + "\n");
        billPrint.addText("流水号：" + crossPayInfo.recordNo + "\n");
        billPrint.addText("支付类型：" + crossPayInfo.payName + "\n");
        billPrint.addText("支付金额：" + crossPayInfo.payPrice.toPlainString() + "\n");
        billPrint.addText("收款人：" + crossPayInfo.username + "\n");
        billPrint.addText("挂账人：" + crossPayInfo.accountUsername + "\n");
        billPrint.addText("信用额度：" + crossPayInfo.fdCreditAmt.toPlainString() + "\n");
        billPrint.addText("挂账金额：" + crossPayInfo.guaPrice.toPlainString() + "\n");
        billPrint.addHortionaDoublelLine();
        billPrint.addLeftWithRight("打印时间：" + JsonUtil.getInfo(ob, "printTime", String.class), "印号：" + JsonUtil.getInfo(ob, "fiPrintNo", String.class));
        billPrint.addBlankLine();
        billPrint.addCenterText("本系统由“美味不用等”提供，技术支持或合作洽谈请拨打热线电话：4008 166 477\n");
        billPrint.addText("\n");
        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    /**
     * kds制作单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/kdsMake")
    public static PrintResult processKdsMake(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);

        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("${Dept.fsDeptName}制作单".replace("${Dept.fsDeptName}", JsonUtil.getString(dept, "fsDeptName") + titleRemind));
        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrder", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String fiOrderItemKind = JsonUtil.getString(item, "fiOrderItemKind");
                if (TextUtils.equals("2", fiOrderItemKind)) {  //不打印套餐头
                    continue;
                }
                String fsSpecialNote = JsonUtil.getString(item, "fsSpecialNote");
                String left = fsSpecialNote + JsonUtil.getString(item, "fsItemName");
                String waitInfo = JsonUtil.getString(item, "SfiItemMakeState");
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getString(item, "fdSaleQty"), JsonUtil.getString(item, "fsOrderUint"));
                billPrint.addItemNameWithUnit(left, right, 2);
                billPrint.addBlankLine(1);

                // 等叫
                if (!TextUtils.isEmpty(waitInfo)) {
                    billPrint.addText("  " + waitInfo + "\n", 2);
                }

                if (TextUtils.equals("3", fiOrderItemKind)) {  //套餐明细要打印出所属的套餐头
                    String parentItemName = JsonUtil.getString(item, "parentItemName");
                    if (!TextUtils.isEmpty(parentItemName)) {
                        billPrint.addOrderModifier("-(属于)" + parentItemName, 2);
                    }
                }

                String note = JsonUtil.getString(item, "fsGeneralNote");
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }
                String ingredientNote = JsonUtil.getString(item, "ingredientNotes");
                if (!TextUtils.isEmpty(ingredientNote)) {
                    String[] ingredientArr = ingredientNote.split("\n");
                    for (String ingredient : ingredientArr) {
                        billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                    }
                }
                billPrint.addBlankLine(1);
            }
        }
        billPrint.addHortionalLine();
        billPrint.addBlankLine(1);
        billPrint.addText(Util.getString(R.string.print_dept, JsonUtil.getString(dept, "fsDeptName")) + "\n", 1);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * KDS 退菜待分配
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/kdsRetreated")
    public static PrintResult processKdsRetreated(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);

        JSONObject dept = JsonUtil.getInfo(ob, "Dept", JSONObject.class);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("${Dept.fsDeptName}待分配退菜单".replace("${Dept.fsDeptName}", JsonUtil.getString(dept, "fsDeptName") + titleRemind));
        billPrint.addHortionaDoublelLine();

        String retreatedId = JsonUtil.getString(ob, "retreated");
        if (!TextUtils.isEmpty(retreatedId)) {
            billPrint.addTitle("退菜" + retreatedId.replace("retreated_", ""));
            billPrint.addHortionalLine();
        }

        JSONObject dish = ob.getJSONObject("dish");
        if (dish != null) {
            String fsSpecialNote = JsonUtil.getString(dish, "itemSpecialNote");
            String left = fsSpecialNote + JsonUtil.getString(dish, "itemName");
            String right = PrintUtil.optBuyNumAndUnit("1", JsonUtil.getString(dish, "itemUnit"));
            billPrint.addItemNameWithUnit(left, right, 2);
            billPrint.addBlankLine(1);

            String procedure = JsonUtil.getString(dish, "itemProcedure");
            if (!TextUtils.isEmpty(procedure)) {
                billPrint.addOrderModifier(procedure, 1);
            }

            String note = JsonUtil.getString(dish, "itemGeneralNote");
            if (!TextUtils.isEmpty(note)) {
                billPrint.addOrderModifier(note, 1);
            }

            String ingredientNote = JsonUtil.getString(dish, "itemModifier");
            if (!TextUtils.isEmpty(ingredientNote)) {
                String[] ingredientArr = ingredientNote.split("\n");
                for (String ingredient : ingredientArr) {
                    billPrint.addOrderModifier(ingredient.replace("\n", ""), 1);
                }
            }
            billPrint.addBlankLine(1);
        }

        billPrint.addHortionalLine();
        billPrint.addBlankLine(1);
        billPrint.addText(Util.getString(R.string.print_dept, JsonUtil.getString(dept, "fsDeptName")) + "\n", 1);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        String barCode = JsonUtil.getInfo(ob, "barCode", String.class);
        if (!TextUtils.isEmpty(barCode)) {
            billPrint.addBarCod(barCode, PrintDataItem.ALIGN_CENTRE);
            billPrint.addBlankLine(1);
        }

        billPrint.addCut();
        String beep = JsonUtil.getString(ob, "beep");
        if (TextUtils.equals("1", beep)) {
            billPrint.addBeep();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }
}
