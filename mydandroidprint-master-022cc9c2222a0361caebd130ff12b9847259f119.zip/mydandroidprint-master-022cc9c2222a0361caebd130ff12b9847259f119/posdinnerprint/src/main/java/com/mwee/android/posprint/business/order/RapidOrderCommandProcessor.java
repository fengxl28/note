package com.mwee.android.posprint.business.order;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2017/7/12.
 */
@SuppressWarnings("unused")
public class RapidOrderCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "rapidOrder";

    /**
     * 秒点确认单
     *
     * @param ob        JSONObject
     * @param taskModel PrintTaskDBModel
     * @param config    PrinterConfig
     * @return PrintResult
     */
    @DrivenMethod(uri = DRIVER_TAG + "/rapid_menulist")
    public static PrintResult rapidmenuConfirmlist(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("秒点确认单" + titleRemind);
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addBlankLine();
        billPrint.addLeftWithRightBig("打印:" + JsonUtil.getInfo(ob, "PrintUser", String.class), "台位:", JsonUtil.getInfo(sell, "fsMTableName", String.class) + "");

        billPrint.addLeftWithRight("日期:" + JsonUtil.getInfo(sell, "fsSellDate", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));

        billPrint.addHortionaDoublelLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);

        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String left = JsonUtil.getInfo(item, "fsItemName", String.class);
                String waitInfo = JsonUtil.getInfo(item, "SfiItemMakeState", String.class);
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(item, "fdSaleQty", String.class), JsonUtil.getInfo(item, "fsOrderUint", String.class)) + waitInfo;
                billPrint.addItemNameWithUnit(left, right, 2);

                JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
                if (slit != null && slit.size() > 0) {
                    for (int m = 0; m < slit.size(); m++) {
                        JSONObject itemS = slit.getJSONObject(m);
                        billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsItemName", String.class) + "*" + JsonUtil.getInfo(itemS, "fdSaleQty", String.class), 1);
                    }
                }

                JSONArray ingredientList = JsonUtil.getInfo(item, "ingredientList", JSONArray.class);
                if (ingredientList != null && ingredientList.size() > 0) {
                    for (int m = 0; m < ingredientList.size(); m++) {
                        JSONObject itemS = ingredientList.getJSONObject(m);
                        billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsItemName", String.class) + "*" + PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(itemS, "fdSaleQty", String.class), JsonUtil.getInfo(itemS, "fsOrderUint", String.class)), 1);
                    }
                }

                Integer fiOrderItemKind = JsonUtil.getInfo(item, "fiOrderItemKind", Integer.class);  //配料菜不打印要求备注等
                if (!(fiOrderItemKind != null && fiOrderItemKind == 4)) {
                    String note = JsonUtil.getInfo(item, "fsNote", String.class);
                    if (!TextUtils.isEmpty(note)) {
                        billPrint.addOrderModifier2(note, 1);
                    }
                }
                billPrint.addBlankLine(1);
            }
        }
        billPrint.addHortionalLine();
        String phone = JsonUtil.getInfo(ob, "phone", String.class);
        if (!TextUtils.isEmpty(phone)) {
            billPrint.addText("预定顾客手机尾号:" + phone + "\n", 1, PrintDataItem.ALIGN_RIGHT, 0);
        }
        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "Sub", String.class) + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 秒点预定单小票
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/rapidBookOrder")
    public static PrintResult rapidBookOrder(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        if (config == null) {
            return null;
        }
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("预定顾客预点菜提醒" + titleRemind);
        billPrint.addBlankLine(1);
        billPrint.addText("提前通知后厨备料，可以减少顾客到店后等菜时间哦\n", 1, PrintDataItem.ALIGN_CENTRE, 0);
        billPrint.addBlankLine(1);

        billPrint.addLeftWithRightBig("顾客姓名:" + JsonUtil.getInfo(ob, "customName", String.class), "手机尾号:", JsonUtil.getInfo(ob, "phone", String.class) + "");
        billPrint.addText("到店时间：" + JsonUtil.getInfo(ob, "arriveTime", String.class) + "\n");
        billPrint.addLeftWithRight("担保金:" + JsonUtil.getInfo(ob, "deposit", String.class) + "元", "人数:" + JsonUtil.getInfo(ob, "peopleCount", String.class));

        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "SellOrders", JSONArray.class);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                String left = JsonUtil.getInfo(item, "itemName", String.class);
                String right = PrintUtil.optBuyNumAndUnit(JsonUtil.getInfo(item, "itemQty", String.class), "");
                billPrint.addItemNameWithUnit(left, right, 2);
            }

            billPrint.addHortionalLine();
        }

        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "count", String.class) + "\n", 2, PrintDataItem.ALIGN_RIGHT, 0);
        billPrint.addBlankLine(1);
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
