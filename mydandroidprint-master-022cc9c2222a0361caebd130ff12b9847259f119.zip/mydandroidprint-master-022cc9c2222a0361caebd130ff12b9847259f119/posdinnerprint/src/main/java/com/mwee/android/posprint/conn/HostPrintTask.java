package com.mwee.android.posprint.conn;

import java.util.List;

public class HostPrintTask {
    private String hostID;
    private List<Integer> printNoList;

    public String getHostID() {
        return hostID;
    }

    public void setHostID(String hostID) {
        this.hostID = hostID;
    }

    public List<Integer> getPrintNoList() {
        return printNoList;
    }

    public void setPrintNoList(List<Integer> printNoList) {
        this.printNoList = printNoList;
    }
}
