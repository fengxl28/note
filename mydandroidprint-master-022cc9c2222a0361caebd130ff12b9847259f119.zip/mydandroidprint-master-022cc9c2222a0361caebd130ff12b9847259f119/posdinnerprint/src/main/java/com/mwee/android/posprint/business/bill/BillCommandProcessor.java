package com.mwee.android.posprint.business.bill;

import android.graphics.Bitmap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.image.PictureManager;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintBillBuilder;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintStringUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * BillCommandProcessor
 * Created by virgil on 16/8/9.
 */
@SuppressWarnings("unused")
public class BillCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "bill";


    /**
     * 预结单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/prebill")
    public static PrintResult processPreBill(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }
        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));
        billPrint.addLine();

        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("预结单" + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", JsonUtil.getInfo(sell, "fsMTableName", String.class));
        billPrint.addLeftWithRight("开单:" + JsonUtil.getInfo(sell, "fsCreateUserName", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));
        billPrint.addLeftWithRight("日期:" + JsonUtil.getInfo(sell, "fsselldate", String.class), "");
        String memberCardNo = JsonUtil.getInfo(sell, "fsCardNo", String.class);
        if(!TextUtils.isEmpty(memberCardNo)){
            billPrint.addLeftWithRight("会员号:" + memberCardNo, "");
        }
        billPrint.addHortionaDoublelLine();
        billPrint.addOrderItem(
                GlobalCache.getContext().getString(R.string.print_names),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total), 1);// ("Item Name", "QTY");

        //打印菜品明细
        printMenuItem(ob,billPrint);

        String printLanguage = ob.getString("print_language");

        billPrint.addHortionalLine();
        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        String subtotal = "消费合计";
        if(TextUtils.equals("1",printLanguage)){
            subtotal = "Subtotal";
        }
        billPrint.addSub(subtotal, JsonUtil.getInfo(sub, "qty", String.class), JsonUtil.getInfo(sub, "total", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Subtotal", "", "");
        }
        String discount = "折扣";
        if(TextUtils.equals("1",printLanguage)){
            discount = "Discount";
        }
        billPrint.addSub(discount, "", JsonUtil.getInfo(ob, "fddiscountamt", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Discount", "", "");
        }
        //圆整
        String fdRoundAmt = JsonUtil.getInfo(sell, "fdroundamt", String.class);
        if (!TextUtils.isEmpty(fdRoundAmt) && !TextUtils.equals(fdRoundAmt, "0")) {
            String rounding = "圆整";
            if(TextUtils.equals("1",printLanguage)){
                rounding = "Rounding";
            }
            billPrint.addSub(rounding, "", fdRoundAmt);
            //2:第一语言和第二语言合并打印
            if(TextUtils.equals("2",printLanguage)){
                billPrint.addSub("Rounding", "", "");
            }
        }
        //服务费
        String serviceFee = JsonUtil.getInfo(sell, "fdServiceAmt", String.class);

        if (!TextUtils.isEmpty(serviceFee) && !TextUtils.equals(serviceFee, "0")) {
            try {
                BigDecimal serviceAmt = new BigDecimal(serviceFee);
                if (serviceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    String service = "服务费";
                    if(TextUtils.equals("1",printLanguage)){
                        service = "Service charge";
                    }
                    billPrint.addSub(service, "", serviceFee);
                    //2:第一语言和第二语言合并打印
                    if(TextUtils.equals("2",printLanguage)){
                        billPrint.addSub("Service charge", "", "");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        String accountsPayable = "应收";
        if(TextUtils.equals("1",printLanguage)){
            accountsPayable = "Accounts payable";
        }
        billPrint.addSub(accountsPayable, "", JsonUtil.getInfo(sell, "fdExpAmt", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Accounts payable", "", "");
        }
        billPrint.addHortionalLine();

        String nonDisAmt = JsonUtil.getInfo(sub, "NonDisAmt", String.class);
        if (!TextUtils.isEmpty(nonDisAmt)) {
            billPrint.addText(PrintStringUtil.padRight("可折扣金额:" + JsonUtil.getInfo(sell, "fdDisExpAmt", String.class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("不可折扣金额:" + nonDisAmt + "\n", billPrint.charSize / 2, billPrint.gbkSize), 1, 0, 0);
            billPrint.addHortionalLine();
        }

        // 折扣明细
        JSONObject coupon = JsonUtil.getInfo(ob, "Coupon", JSONObject.class);
        if (coupon != null) {
            BigDecimal count = JsonUtil.getInfo(coupon, "fdCutmoney", BigDecimal.class);
            if (count.compareTo(BigDecimal.ZERO) > 0) {
                billPrint.addText(JsonUtil.getInfo(coupon, "fsBargainName", String.class) + "：-" + count.toPlainString() + "\n");
            }
            billPrint.addHortionalLine();
        }

        billPrint.addText("备注:" + JsonUtil.getInfo(sell, "fsnote", String.class) + "\n");

        //是否开发票
        int fiIsInvoice = JsonUtil.getInfo(sell, "fiIsInvoice", Integer.class);
        if (fiIsInvoice != 0) {
            billPrint.addHortionalLine();
            billPrint.addText("客户要求开具发票,信息如下:\n");
            String fsInvoiceTitle = JsonUtil.getInfo(sell, "fsInvoiceTitle", String.class);//抬头
            String fsInvoiceCls = JsonUtil.getInfo(sell, "fsInvoiceCls", String.class);//开票类型
            billPrint.addText("发票类型:" + fsInvoiceCls + "\n");
            billPrint.addText("发票抬头:" + fsInvoiceTitle + "\n");
            String fsdutyparagraph = JsonUtil.getInfo(sell, "fsdutyparagraph", String.class);
            if (!TextUtils.isEmpty(fsdutyparagraph)) {
                billPrint.addText("公司税号:" + fsdutyparagraph + "\n");
            }
            billPrint.addHortionalLine();
            billPrint.addBlankLine();
        }
        billPrint.addLeftWithRight(Util.getString(R.string.print_user, JsonUtil.getString(ob, "printUserName")), Util.getString(R.string.print_times, JsonUtil.getString(sell, "fiPrintTimes_Exp")));

        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        String tableQR = JsonUtil.getInfo(ob, "tableQR", String.class);
        if (!TextUtils.isEmpty(tableQR)) {
            billPrint.addQRcode(tableQR, PrintDataItem.ALIGN_CENTRE);
        }

        String note = JsonUtil.getInfo(ob, "note", String.class);
        if (!TextUtils.isEmpty(note)) {
            billPrint.addCenterText(note + "\n", 1);
            billPrint.addBlankLine();
        }
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 结账单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/orderbill")
    public static PrintResult procssBill(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }
        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));
        billPrint.addLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        String titleSubFix = JsonUtil.getString(ob, "titleSubFix");
        billPrint.addTitle("结账单" + titleSubFix + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", JsonUtil.getInfo(sell, "fsMTableName", String.class));
        billPrint.addLeftWithRight("日期:" + JsonUtil.getInfo(sell, "fsselldate", String.class), "班别:" + JsonUtil.getInfo(sell, "shiftname", String.class));
        billPrint.addLeftWithRight("开单:" + JsonUtil.getInfo(sell, "fsCreateUserName", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));

        billPrint.addLeftWithRight("收银:" + JsonUtil.getInfo(sell, "cashiername", String.class), "结账时间:" + JsonUtil.getInfo(sell, "fscheckendtime", String.class));

        String memberCardNo = JsonUtil.getInfo(sell, "fsCardNo", String.class);
        if(!TextUtils.isEmpty(memberCardNo)){
            billPrint.addLeftWithRight("会员号:" + memberCardNo, "");
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addOrderItem(GlobalCache.getContext().getString(R.string.print_names),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total), 1);// ("Item Name", "QTY");

        String orderSeq = "";

        //打印菜品明细
        printMenuItem(ob,billPrint);

        String printLanguage = ob.getString("print_language");

        billPrint.addHortionalLine();
        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        String subtotal = "消费合计";
        if(TextUtils.equals("1",printLanguage)){
            subtotal = "Subtotal";
        }
        billPrint.addSub(subtotal, JsonUtil.getInfo(sub, "qty", String.class), JsonUtil.getInfo(sub, "total", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Subtotal", "", "");
        }
        String discount = "折扣";
        if(TextUtils.equals("1",printLanguage)){
            discount = "Discount";
        }
        billPrint.addSub(discount, "", JsonUtil.getInfo(ob, "fddiscountamt", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Discount", "", "");
        }
        //圆整
        String fdRoundAmt = JsonUtil.getInfo(sell, "fdroundamt", String.class);
        if (!TextUtils.isEmpty(fdRoundAmt) && !TextUtils.equals(fdRoundAmt, "0")) {
            String rounding = "圆整";
            if(TextUtils.equals("1",printLanguage)){
                rounding = "Rounding";
            }
            billPrint.addSub(rounding, "", fdRoundAmt);
            //2:第一语言和第二语言合并打印
            if(TextUtils.equals("2",printLanguage)){
                billPrint.addSub("Rounding", "", "");
            }
        }
        //服务费
        String serviceFee = JsonUtil.getInfo(sell, "fdServiceAmt", String.class);

        if (!TextUtils.isEmpty(serviceFee) && !TextUtils.equals(serviceFee, "0")) {
            try {
                BigDecimal serviceAmt = new BigDecimal(serviceFee);
                if (serviceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    String service = "服务费";
                    if(TextUtils.equals("1",printLanguage)){
                        service = "Service charge";
                    }
                    billPrint.addSub(service, "", serviceFee);
                    //2:第一语言和第二语言合并打印
                    if(TextUtils.equals("2",printLanguage)){
                        billPrint.addSub("Service charge", "", "");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        String accountsPayable = "应收";
        if(TextUtils.equals("1",printLanguage)){
            accountsPayable = "Accounts payable";
        }
        billPrint.addSub(accountsPayable, "", JsonUtil.getInfo(sell, "fdExpAmt", String.class));
        //2:第一语言和第二语言合并打印
        if(TextUtils.equals("2",printLanguage)){
            billPrint.addSub("Accounts payable", "", "");
        }
        billPrint.addHortionalLine();

        JSONArray statisticsDiscount = JsonUtil.getInfo(ob, "statisticsDiscount", JSONArray.class);
        if (statisticsDiscount != null && statisticsDiscount.size() > 0) {
            billPrint.addText("折扣明细\n");
            billPrint.addBlankLine();
            BigDecimal sumDiscountAmt = BigDecimal.ZERO;
            for (int i = 0; i < statisticsDiscount.size(); i++) {
                JSONObject item = statisticsDiscount.getJSONObject(i);
                BigDecimal discountamt = JsonUtil.getInfo(item, "discountamt", BigDecimal.class);
                sumDiscountAmt = sumDiscountAmt.add(discountamt);
                billPrint.addText(TextUtils.concat(
                        JsonUtil.getInfo(item, "fsDiscountName", String.class), ":", String.format("%s", discountamt.toPlainString()).concat("\n")
                ).toString());
                billPrint.addBlankLine();
            }
            BigDecimal fdDiscountRoundAmt = JsonUtil.getInfo(sell, "fdDiscountRoundAmt", BigDecimal.class);
            if (fdDiscountRoundAmt != null && fdDiscountRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
                billPrint.addText(String.format("合计:%s(圆整:" + fdDiscountRoundAmt.toPlainString() + ")\n", JsonUtil.getInfo(sell, "fddiscountamt", String.class)));
            } else {
                billPrint.addText(String.format("合计:%s\n", JsonUtil.getInfo(sell, "fddiscountamt", String.class)));
            }
            billPrint.addBlankLine();
            billPrint.addHortionalLine();
        }

        JSONArray payList = JsonUtil.getInfo(ob, "SellReceive", JSONArray.class);
        for (int i = 0; i < payList.size(); i++) {
            JSONObject item = payList.getJSONObject(i);
            String payName = JsonUtil.getInfo(item, "paymentname", String.class);
            String note = JsonUtil.getInfo(item, "fsNote", String.class);
            //打印备注
            if (!TextUtils.isEmpty(note)) {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "(" + note + ") \n");
            } else {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "\n");
            }
        }

        //判断是否打印实收
        JSONObject realMoneyData = JsonUtil.getInfo(ob, "realMoneyData", JSONObject.class);
        if (realMoneyData != null) {
            billPrint.addHortionalLine();
            billPrint.addLeftWithRight("实收:" + JsonUtil.getInfo(realMoneyData, "realMoney", String.class), "非实收:" + JsonUtil.getInfo(realMoneyData, "unRealMoney", String.class));
        }

        //添加会员储值，积分信息
        if (ob.containsKey("memberInfo")) {
            billPrint.addHortionalLine();
            JSONObject memberInfo = JsonUtil.getInfo(ob, "memberInfo", JSONObject.class);
            billPrint.addText("会员卡可用余额：" + JsonUtil.getString(memberInfo, "amount") + "\n");
            billPrint.addText("会员积分：" + JsonUtil.getString(memberInfo, "score") + "\n");

        }
        billPrint.addHortionaDoublelLine();
        billPrint.addText("备注:" + JsonUtil.getInfo(sell, "fsnote", String.class) + "；" + JsonUtil.getInfo(sell, "fsrewardinfo", String.class) + "\n");
        //是否开发票
        int fiIsInvoice = JsonUtil.getInfo(sell, "fiIsInvoice", Integer.class);
        if (fiIsInvoice != 0) {
            billPrint.addHortionalLine();
            billPrint.addText("客户要求开具发票,信息如下:\n");
            String fsInvoiceTitle = JsonUtil.getInfo(sell, "fsInvoiceTitle", String.class);//抬头
            String fsInvoiceCls = JsonUtil.getInfo(sell, "fsInvoiceCls", String.class);//开票类型
            billPrint.addText("发票类型:" + fsInvoiceCls + "\n");
            billPrint.addText("发票抬头:" + fsInvoiceTitle + "\n");
            String fsdutyparagraph = JsonUtil.getInfo(sell, "fsdutyparagraph", String.class);
            if (!TextUtils.isEmpty(fsdutyparagraph)) {
                billPrint.addText("公司税号:" + fsdutyparagraph + "\n");
            }
            billPrint.addHortionalLine();
            billPrint.addBlankLine();
        }

        //开具电子发票二维码打印
        String eInvoiceQR = JsonUtil.getInfo(ob, "eInvoiceQR", String.class);
        if (!TextUtils.isEmpty(eInvoiceQR)) {
            String title = JsonUtil.getInfo(ob, "eInvoiceQRTitle", String.class);
            if (!TextUtils.isEmpty(title)) {
                billPrint.addCenterText(title + "\n", 1);
            }
            String description = JsonUtil.getInfo(ob, "eInvoiceQRDescription", String.class);
            if (!TextUtils.isEmpty(description)) {
                billPrint.addCenterText(description + "\n", 1);
            }
            String description1 = JsonUtil.getInfo(ob, "eInvoiceQRDescription1", String.class);
            if (!TextUtils.isEmpty(description1)) {
                billPrint.addCenterText(description1 + "\n", 1);
            }
            billPrint.addQRcode(eInvoiceQR, PrintDataItem.ALIGN_CENTRE);

            String note = JsonUtil.getInfo(ob, "eInvoiceQRNote", String.class);
            if (!TextUtils.isEmpty(note)) {
                billPrint.addCenterText(note + "\n", 1);
            }
            billPrint.addBlankLine();
        }


        billPrint.addLeftWithRight(Util.getString(R.string.print_user, JsonUtil.getString(ob, "printUserName")), Util.getString(R.string.print_times, JsonUtil.getString(sell, "fiPrintTimes")));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }


        if (TextUtils.equals(JsonUtil.getInfo(ob, "printBillCut", String.class), "0")) {//结账单切单设置
            billPrint.addCut();
        }
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    /**
     * 结账单(留存)
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/orderRemainBill")
    public static PrintResult orderRemainBill(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);

        billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
        billPrint.addLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        String titleSubFix = JsonUtil.getString(ob, "titleSubFix");
        billPrint.addTitle("结账单" + titleSubFix + titleRemind + "(留存)");
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);
        billPrint.addLeftWithRight("台号:" + JsonUtil.getInfo(sell, "fsMTableName", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));
        billPrint.addLeftWithRight("站点:" + JsonUtil.getInfo(ob, "hostId", String.class), "班别:" + JsonUtil.getInfo(sell, "shiftname", String.class));
        billPrint.addLeftWithRight("服务员:" + JsonUtil.getInfo(sell, "fsCreateUserName", String.class), "收银员:" + JsonUtil.getInfo(sell, "cashiername", String.class));
        billPrint.addLeftWithRight("订单号:" + JsonUtil.getInfo(sell, "fsSellNo", String.class), "");
        billPrint.addLeftWithRight("开台时间:" + JsonUtil.getInfo(sell, "fsCreateTime", String.class), "");
        billPrint.addLeftWithRight("结账时间:" + JsonUtil.getInfo(sell, "fscheckendtime", String.class), "");

        String memberCardNo = JsonUtil.getInfo(sell, "fsCardNo", String.class);
        if(!TextUtils.isEmpty(memberCardNo)){
            billPrint.addLeftWithRight("会员号:" + memberCardNo, "");
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addOrderItem("分类名称",
                "",
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total), 1);

        billPrint.addHortionalLine();

        JSONArray list = JsonUtil.getInfo(ob, "sellorder", JSONArray.class);
        String orderSeq = "";

        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);

                billPrint.addOrderItem(JsonUtil.getInfo(item, "menuClsName", String.class),
                        "",
                        JsonUtil.getInfo(item, "qty", String.class),
                        JsonUtil.getInfo(item, "amount", String.class),
                        1);
            }
        }
        billPrint.addHortionalLine();
        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        billPrint.addSub("消费合计", "", JsonUtil.getInfo(sub, "total", String.class));

        billPrint.addSub("折扣", "", JsonUtil.getInfo(sell, "fdDiscountAmt", String.class));
        //圆整
        String fdRoundAmt = JsonUtil.getInfo(sell, "fdRoundAmt", String.class);
        if (!TextUtils.isEmpty(fdRoundAmt) && !TextUtils.equals(fdRoundAmt, "0")) {
            billPrint.addSub("圆整", "", fdRoundAmt);
        }
        //服务费
        String serviceFee = JsonUtil.getInfo(sell, "fdServiceAmt", String.class);

        if (!TextUtils.isEmpty(serviceFee) && !TextUtils.equals(serviceFee, "0")) {
            try {
                BigDecimal serviceAmt = new BigDecimal(serviceFee);
                if (serviceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    billPrint.addSub("服务费", "", serviceFee);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        billPrint.addSub("应收", "", JsonUtil.getInfo(sell, "fdExpAmt", String.class));
        billPrint.addHortionalLine();

        JSONArray payList = JsonUtil.getInfo(ob, "SellReceive", JSONArray.class);
        for (int i = 0; i < payList.size(); i++) {
            JSONObject item = payList.getJSONObject(i);
            String payName = JsonUtil.getInfo(item, "paymentname", String.class);
            String note = JsonUtil.getInfo(item, "fsNote", String.class);
            //打印备注
            if (!TextUtils.isEmpty(note)) {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "(" + note + ") \n");
            } else {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "\n");
            }
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addText("备注:" + JsonUtil.getInfo(sell, "fsnote", String.class) + "；" + JsonUtil.getInfo(sell, "fsrewardinfo", String.class) + "\n");

        billPrint.addLeftWithRight(Util.getString(R.string.print_user, JsonUtil.getString(ob, "printUserName")), Util.getString(R.string.print_times, JsonUtil.getString(sell, "fiPrintTimes")));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addBlankLine(1);
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }


        if (TextUtils.equals(JsonUtil.getInfo(ob, "printBillCut", String.class), "0")) {//结账单切单设置
            billPrint.addCut();
        }
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 结账单/预结单 打印菜品明细
     * 适配餐标模式下，计入餐标菜品和不计入餐标菜品分开打印
     * @param originalData
     * @param billPrint
     */
    private static void printMenuItem(JSONObject originalData,PrintBizBuilder billPrint){
        //菜品总列表
        JSONArray menuItemList = JsonUtil.getInfo(originalData, "sellorder", JSONArray.class);
        if(menuItemList == null){
            return;
        }
        //普通菜品列表
        List<JSONObject> menuList = new ArrayList<>();
        //餐标模式下计入餐标的菜品列表
        List<JSONObject> dinnerStandardMenuList = new ArrayList<>();
        for (int i = 0; i < menuItemList.size(); i++) {
            JSONObject item = menuItemList.getJSONObject(i);
            if(item != null){
                if(TextUtils.equals(item.getString("fiWithinDiningStandard"),"1")){
                    dinnerStandardMenuList.add(item);
                }else{
                    menuList.add(item);
                }
            }
        }
        //计入餐标的菜品不为空时，先打印，不计入餐标的菜品 后打印
        if(!ListUtil.isEmpty(dinnerStandardMenuList)){
            JSONObject sell = JsonUtil.getInfo(originalData, "Sell", JSONObject.class);
            //餐标模式下，计入餐标的菜品是否打印菜品金额开关
            String showPrice = JsonUtil.getString(originalData,"diningStandardPrintConfig");
            String fdDiningStandardAmt = JsonUtil.getString(sell,"fdDiningStandardAmt");
            printMenuItem(originalData,dinnerStandardMenuList,billPrint,!"1".equals(showPrice));
            billPrint.addCenterTextPaddingWithDash("以上为用餐标准内菜品("+fdDiningStandardAmt+")");
        }
        printMenuItem(originalData,menuList,billPrint,true);
    }

    /**
     * 打印菜品明细
     * @param menuItemList
     * @param billPrint
     * @param showPrice
     */
    private static void printMenuItem(JSONObject originalData,List<JSONObject> menuItemList,PrintBizBuilder billPrint,boolean showPrice){
        if (menuItemList != null) {
            String printLanguage = originalData.getString("print_language");
            for (int i = 0; i < menuItemList.size(); i++) {
                JSONObject item = menuItemList.get(i);

                String saleAmt = JsonUtil.getInfo(item, "fdsaleamt", String.class);
                String settlePrice = JsonUtil.getInfo(item, "fdsettleprice", String.class);

                if(!showPrice){//是否显示菜品金额
                    saleAmt = " ";
                    settlePrice = " ";
                }

                billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class),
                        settlePrice,
                        JsonUtil.getInfo(item, "qty", String.class),
                        saleAmt, 1);
                //第一语言和第二语言合并打印
                String itemName2 = JsonUtil.getInfo(item, "fsItemName2", String.class);
                if(TextUtils.equals("2",printLanguage) && !TextUtils.isEmpty(itemName2)){
                    billPrint.addOrderItem(itemName2, "", "", "", 1);
                }
                //配料不打印要求
                if (!TextUtils.equals("4", JsonUtil.getInfo(item, "fiOrderItemKind", String.class))) {
                    String note = JsonUtil.getInfo(item, "fsNote", String.class);
                    if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                        billPrint.addOrderModifier2(note.trim(), 1);
                    }
                }
                // //add modifier print
                JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
                if (slit != null && slit.size() > 0) {
                    for (int m = 0; m < slit.size(); m++) {
                        JSONObject itemS = slit.getJSONObject(m);
                        billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsitemname", String.class) + "*" + JsonUtil.getInfo(itemS, "qty", String.class), 1);

                        //配料不打印要求
                        if (!TextUtils.equals("4", JsonUtil.getInfo(itemS, "fiOrderItemKind", String.class))) {
                            String note = JsonUtil.getInfo(itemS, "fsNote", String.class);
                            if (!TextUtils.isEmpty(note) && !TextUtils.isEmpty(note.trim())) {
                                billPrint.addOrderModifier2(note.trim(), 1);
                            }
                        }
                    }
                }
            }
        }
    }

    @DrivenMethod(uri = "bill/doVoidPay")
    public static PrintResult procssVoidPay(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);

        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("退款回执小票" + titleRemind);

        String prefix = JsonUtil.getString(ob, "prefix");
        if (!TextUtils.isEmpty(prefix)) {
            billPrint.addText(prefix + "\n", 2, PrintDataItem.ALIGN_LEFT, 1);
        }

        billPrint.addHortionaDoublelLine();

        billPrint.addText("门店：" + JsonUtil.getInfo(ob, "fsShopName", String.class) + "\n");
        billPrint.addText("退款时间：" + JsonUtil.getInfo(ob, "voidTime", String.class) + "\n");
        billPrint.addText("账单号：" + JsonUtil.getInfo(ob, "fsSellNo", String.class) + "\n");
        billPrint.addText("订单号：" + JsonUtil.getInfo(ob, "extraOrderID", String.class) + "\n");
        String tradeNo = JsonUtil.getInfo(ob, "tradeNo", String.class);
        if (!TextUtils.isEmpty(tradeNo)) {
            billPrint.addText("交易流水号：" + tradeNo + "\n");
        }
        billPrint.addLine();
        billPrint.addText("退款明细：\n");

        JSONArray payList = JsonUtil.getInfo(ob, "SellReceive", JSONArray.class);
        for (int i = 0; i < payList.size(); i++) {
            JSONObject item = payList.getJSONObject(i);
            billPrint.addText(JsonUtil.getInfo(item, "paymentname", String.class) + ": " + JsonUtil.getInfo(item, "fdpaymoney", String.class) + "\n");
        }
        billPrint.addHortionaDoublelLine();

        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));
        billPrint.addLine();
        billPrint.addCenterText("如24小时内未收到账户退款，请联系美味不用等客服热线：400 816 6477\n");

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    /**
     * 外卖结账单
     *
     * @param ob
     * @param task
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/networktackoutreceipt")
    public static PrintResult networkTackOutReceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addLine();
//        billPrint.addCenterTextPaddingWithDash(JsonUtil.getInfo(ob, "title", String.class));
        billPrint.addCenterText(JsonUtil.getInfo(ob, "title", String.class), 2, 0, "-");
        if (!TextUtils.isEmpty(JsonUtil.getInfo(ob, "title_little", String.class))) {
            billPrint.addCenterText(JsonUtil.getInfo(ob, "title_little", String.class));
        }

        String restNum = JsonUtil.getInfo(ob, "restNum", String.class); //第三方每日订单序号
        if (!TextUtils.isEmpty(restNum)) {
            billPrint.addText("#" + restNum + "\n", 2);
        }
        billPrint.addText(JsonUtil.getInfo(ob, "orderId", String.class) + "\n");
        String outerOrderId = JsonUtil.getInfo(ob, "outerOrderId", String.class);
        if (!TextUtils.isEmpty(outerOrderId)) {
            String orderTakeawaySource = JsonUtil.getInfo(ob, "orderTakeawaySource", String.class);
            billPrint.addText(orderTakeawaySource + "单号：" + outerOrderId + "\n");
        }
        billPrint.addText(JsonUtil.getInfo(ob, "fsShopName", String.class) + "\n");
        //billPrint.addText(JsonUtil.getInfo(ob, "fsAddr") + "\n");

        billPrint.addHortionalLine();
        billPrint.addText(JsonUtil.getInfo(ob, "payStatus", String.class) + "\n");
        billPrint.addText("下单时间:" + JsonUtil.getInfo(ob, "data", String.class) + "\n");

        billPrint.addLeftWithRight(JsonUtil.getInfo(ob, "distributionStartTime", String.class), "", 2);
        billPrint.addHortionalLine();
        billPrint.addContentListHeader(
                GlobalCache.getContext().getString(R.string.print_names),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total));

        JSONArray list = JsonUtil.getInfo(ob, "orderDetailList", JSONArray.class);
        optPrintListItem(list, billPrint);

        JSONArray arrayList = JsonUtil.getInfo(ob, "orderDetailSparseArray", JSONArray.class);
        if (arrayList != null && arrayList.size() > 0) {
            for (int i = 0; i < arrayList.size(); i++) {
                if (arrayList.size() > 1) {
                    billPrint.addCenterText("**" + (i + 1) + "号口袋**");
                    billPrint.addHortionalLine();
                }
                JSONArray item = arrayList.getJSONArray(i);
                optPrintListItem(item, billPrint);
                billPrint.addHortionalLine();
            }
        }

        String orderDesc = JsonUtil.getInfo(ob, "orderDesc", String.class);
        String person = JsonUtil.getInfo(ob, "person", String.class);

        if (!TextUtils.isEmpty(orderDesc) || !TextUtils.isEmpty(person)) {
            if (APPConfig.isCasiher()) {
                billPrint.addText(PrintStringUtil.padRight("备注:" + orderDesc, billPrint.charSize, billPrint.gbkSize) + "\n");
            } else {
                billPrint.addText(PrintStringUtil.padRight("备注:" + person + "人; " + orderDesc, billPrint.charSize, billPrint.gbkSize) + "\n");
            }
            billPrint.addHortionalLine();
        }

        //打印优惠信息
        if (ob.containsKey("quan")) {
            JSONArray couponList = JsonUtil.getInfo(ob, "quan", JSONArray.class);
            if (!ListUtil.isEmpty(couponList)) {
                billPrint.addHortionalLine();
                billPrint.addText("活动\n");
                for (int i = 0; i < couponList.size(); i++) {
                    billPrint.addText(couponList.getJSONObject(i).getString("couponTitle") + "\n");
                }
                billPrint.addHortionalLine();
            }
        }

        String receiptName = JsonUtil.getInfo(ob, "receiptName", String.class);
        if (!TextUtils.isEmpty(receiptName)) {
            billPrint.addText(PrintStringUtil.padRight("发票:" + receiptName, billPrint.charSize, billPrint.gbkSize) + "\n");
            billPrint.addHortionalLine();
        }

        billPrint.addText(PrintStringUtil.padRight("配送费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("" + JsonUtil.getInfo(ob, "deliveryFee", String.class), billPrint.charSize / 2, billPrint.gbkSize) + "\n");
        String boxFee = JsonUtil.getInfo(ob, "boxFee", String.class);
        if (!TextUtils.isEmpty(boxFee)) {
            billPrint.addText(PrintStringUtil.padRight("餐盒费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(boxFee, billPrint.charSize / 2, billPrint.gbkSize) + "\n");
        }

        String fdServiceAmt = JsonUtil.getInfo(ob, "fdServiceAmt", String.class);
        if (!TextUtils.isEmpty(fdServiceAmt)) {
            billPrint.addText(PrintStringUtil.padRight("外卖平台服务费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(fdServiceAmt, billPrint.charSize / 2, billPrint.gbkSize) + "\n");
        }

        //其他抵扣方式
        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "subTotal", String.class) + "\n");
        billPrint.addText("优惠:" + JsonUtil.getInfo(ob, "youhui", String.class) + "\n");

        String voidDes = JsonUtil.getInfo(ob, "voidDes", String.class);
        if (TextUtils.isEmpty(voidDes)) {
            billPrint.addText("实付:" + JsonUtil.getInfo(ob, "total", String.class) + "\n");
        } else {
            billPrint.addText(PrintStringUtil.padRight("实付:" + JsonUtil.getInfo(ob, "total", String.class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(voidDes, billPrint.charSize / 2, billPrint.gbkSize));
        }

        String earnestMoney = JsonUtil.getInfo(ob, "earnestMoney", String.class);
        if (!TextUtils.isEmpty(earnestMoney)) {
            billPrint.addText("实收:" + earnestMoney + "\n");
        }

        String bizType = JsonUtil.getInfo(ob, "bizType", String.class);
        if (TextUtils.equals("4", bizType)) {
            billPrint.addLeftWithRight("地址:" + JsonUtil.getInfo(ob, "address", String.class), "");
            billPrint.addText(PrintStringUtil.padRight("电话:" + JsonUtil.getInfo(ob, "distributionPhone", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
            billPrint.addText(PrintStringUtil.padRight("姓名:" + JsonUtil.getInfo(ob, "distributionName", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");

        } else {
            billPrint.addText(PrintStringUtil.padRight("人数:" + JsonUtil.getInfo(ob, "person", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
            billPrint.addText(PrintStringUtil.padRight("备餐模式:" + JsonUtil.getInfo(ob, "readyFoodMode", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
        }

        billPrint.addHortionalLine();

        String printTime = JsonUtil.getInfo(ob, "PrintTime", String.class); //打印时间
        String fiPrintNo = JsonUtil.getInfo(ob, "fiPrintNo", String.class); //印号
        String fsDptrName = JsonUtil.getInfo(ob, "fsDptrName", String.class); //打印站点

        billPrint.addLeftWithRight("打印时间:" + printTime, "印号:" + fiPrintNo);
        billPrint.addText(fsDptrName + "\n");
        billPrint.addHortionalLine();
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine(1);
        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }


    /**
     * 外卖客户联小票
     *
     * @param ob
     * @param task
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/networkcustomreceipt")
    public static PrintResult networkcustomreceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addLine();
        //应客户要求，单头留空白
        billPrint.addText("\n\n\n\n");
        String title = JsonUtil.getInfo(ob, "title", String.class);
        String restNum = JsonUtil.getInfo(ob, "restNum", String.class); //第三方每日订单序号
        if (!TextUtils.isEmpty(restNum)) {
            title = "(#" + restNum + ")" + title;
        }
        billPrint.addCenterText(title, 2, 0, "-");
        if (!TextUtils.isEmpty(JsonUtil.getInfo(ob, "title_little", String.class))) {
            billPrint.addCenterText(JsonUtil.getInfo(ob, "title_little", String.class));
        }

        billPrint.addText(JsonUtil.getInfo(ob, "orderId", String.class) + "\n");
        String outerOrderId = JsonUtil.getInfo(ob, "outerOrderId", String.class);
        if (!TextUtils.isEmpty(outerOrderId)) {
            String orderTakeawaySource = JsonUtil.getInfo(ob, "orderTakeawaySource", String.class);
            billPrint.addText(orderTakeawaySource + "单号：" + outerOrderId + "\n");
        }
        billPrint.addText(JsonUtil.getInfo(ob, "fsShopName", String.class) + "\n");

        billPrint.addHortionalLine();
        billPrint.addText(JsonUtil.getInfo(ob, "payStatus", String.class) + "\n");
        billPrint.addText("下单时间:" + JsonUtil.getInfo(ob, "data", String.class) + "\n");

        //期望送达时间
        billPrint.addLeftWithRight(JsonUtil.getInfo(ob, "distributionStartTime", String.class), "", 2);

        //备注
        String orderDesc = JsonUtil.getInfo(ob, "orderDesc", String.class);
        String person = JsonUtil.getInfo(ob, "person", String.class);

        if (!TextUtils.isEmpty(orderDesc) || !TextUtils.isEmpty(person)) {
            billPrint.addLeftWithRight("备注:" + person + "人; " + orderDesc, "", 2);
        }

        //地址
        billPrint.addLeftWithRight("地址:" + JsonUtil.getInfo(ob, "address", String.class), "", 2);


        billPrint.addHortionalLine();
        billPrint.addContentListHeader(
                GlobalCache.getContext().getString(R.string.print_names),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total));

        JSONArray arrayList = JsonUtil.getInfo(ob, "orderDetailSparseArray", JSONArray.class);
        if (arrayList != null && arrayList.size() > 0) {
            for (int i = 0; i < arrayList.size(); i++) {
                if (arrayList.size() > 1) {
                    billPrint.addCenterText("**" + (i + 1) + "号口袋**");
                    billPrint.addHortionalLine();
                }
                JSONArray item = arrayList.getJSONArray(i);
                optPrintListItem(item, billPrint);
                billPrint.addHortionalLine();
            }
        }

        //打印优惠信息
        if (ob.containsKey("quan")) {
            JSONArray couponList = JsonUtil.getInfo(ob, "quan", JSONArray.class);
            if (!ListUtil.isEmpty(couponList)) {
                billPrint.addHortionalLine();
                billPrint.addText("活动\n");
                for (int i = 0; i < couponList.size(); i++) {
                    billPrint.addText(couponList.getJSONObject(i).getString("couponTitle") + "\n");
                }
                billPrint.addHortionalLine();
            }
        }

        billPrint.addText(PrintStringUtil.padRight("配送费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("" + JsonUtil.getInfo(ob, "deliveryFee", String.class), billPrint.charSize / 2, billPrint.gbkSize) + "\n");
        String boxFee = JsonUtil.getInfo(ob, "boxFee", String.class);
        if (!TextUtils.isEmpty(boxFee)) {
            billPrint.addText(PrintStringUtil.padRight("餐盒费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(boxFee, billPrint.charSize / 2, billPrint.gbkSize) + "\n");
        }
        //发票信息
        String receiptName = JsonUtil.getInfo(ob, "receiptName", String.class);
        if (!TextUtils.isEmpty(receiptName)) {
            billPrint.addText(PrintStringUtil.padRight("发票:" + receiptName, billPrint.charSize, billPrint.gbkSize) + "\n");
        }

        //其他抵扣方式
        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "subTotal", String.class) + "\n");
        billPrint.addText("优惠:" + JsonUtil.getInfo(ob, "youhui", String.class) + "\n");

        String voidDes = JsonUtil.getInfo(ob, "voidDes", String.class);
        if (TextUtils.isEmpty(voidDes)) {
            billPrint.addText("实付:" + JsonUtil.getInfo(ob, "total", String.class) + "\n");
        } else {
            billPrint.addText(PrintStringUtil.padRight("实付:" + JsonUtil.getInfo(ob, "total", String.class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(voidDes, billPrint.charSize / 2, billPrint.gbkSize));
        }

        String earnestMoney = JsonUtil.getInfo(ob, "earnestMoney", String.class);
        if (!TextUtils.isEmpty(earnestMoney)) {
            billPrint.addText("实收:" + earnestMoney + "\n");
        }

        String bizType = JsonUtil.getInfo(ob, "bizType", String.class);
        if (TextUtils.equals("4", bizType)) {
            billPrint.addText(PrintStringUtil.padRight("电话:" + JsonUtil.getInfo(ob, "distributionPhone", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
            billPrint.addText(PrintStringUtil.padRight("姓名:" + JsonUtil.getInfo(ob, "distributionName", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");

        } else {
            billPrint.addText(PrintStringUtil.padRight("人数:" + JsonUtil.getInfo(ob, "person", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
            billPrint.addText(PrintStringUtil.padRight("备餐模式:" + JsonUtil.getInfo(ob, "readyFoodMode", String.class), billPrint.charSize, billPrint.gbkSize) + "\n");
        }

        billPrint.addHortionalLine();

        String fiPrintNo = JsonUtil.getInfo(ob, "fiPrintNo", String.class); //印号

        billPrint.addLeftWithRight("", "印号:" + fiPrintNo);
        billPrint.addHortionalLine();
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine(1);
        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }

    private static void optPrintListItem(JSONArray list, PrintBillBuilder billPrint) {
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                JSONObject item = list.getJSONObject(i);
                billPrint.addOrderItem(JsonUtil.getInfo(item, "itemName", String.class),
                        JsonUtil.getInfo(item, "itemPrice", String.class),
                        JsonUtil.getInfo(item, "itemNum", String.class),
                        JsonUtil.getInfo(item, "totalItemPrice", String.class),
                        2);
                // //add modifier print
                JSONArray modifiertypes = JsonUtil.getInfo(item, "modifiertypes", JSONArray.class);
                if (modifiertypes != null && modifiertypes.size() > 0) {
                    for (int m = 0; m < modifiertypes.size(); m++) {
                        JSONObject itemType = modifiertypes.getJSONObject(m);
                        JSONArray modifiertDetail = JsonUtil.getInfo(itemType, "modifiers", JSONArray.class);
                        if (modifiertDetail != null && modifiertDetail.size() > 0) {
                            for (int s = 0; s < modifiertDetail.size(); s++) {
                                JSONObject itemS = modifiertDetail.getJSONObject(s);
                                billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "modifierName", String.class) + "*" + JsonUtil.getInfo(itemS, "modifierNum", String.class), 1);
                            }
                        }
                    }
                }

                String note = JsonUtil.getInfo(item, "itemProperties", String.class);
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }

            }
        }
    }


    @DrivenMethod(uri = DRIVER_TAG + "/printnetworkeatinreceipt")
    public static PrintResult printNetworkEatInReceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        billPrint.addCenterTextPaddingWithDash("网络订单");
        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));
        billPrint.addBlankLine();
        billPrint.addHortionalLine();

        if (TextUtils.isEmpty(JsonUtil.getInfo(ob, "orderNum", String.class))) {
            billPrint.addText(JsonUtil.getInfo(ob, "eatType", String.class) + "\n");
        } else {
            billPrint.addText(PrintStringUtil.padRight(JsonUtil.getInfo(ob, "eatType", String.class), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("订单号:" + JsonUtil.getInfo(ob, "orderNum", String.class), billPrint.charSize / 2, billPrint.gbkSize));
        }
        billPrint.addLine();
        billPrint.addText("网络订单号:" + JsonUtil.getInfo(ob, "orderId", String.class) + "\n");
        billPrint.addText("收银员:" + JsonUtil.getInfo(ob, "userName", String.class) + "\n");
        billPrint.addText("下单时间:" + JsonUtil.getInfo(ob, "data", String.class) + "\n");


        billPrint.addHortionalLine();

        billPrint.addContentListHeader(GlobalCache.getContext().getString(R.string.print_item),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total));

        JSONArray list = JsonUtil.getInfo(ob, "orderDetailList", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            billPrint.addOrderItem(JsonUtil.getInfo(item, "itemName", String.class),
                    JsonUtil.getInfo(item, "itemPrice", String.class),
                    JsonUtil.getInfo(item, "itemNum", String.class),
                    JsonUtil.getInfo(item, "totalItemPrice", String.class),
                    1);
            JSONArray modifiertypes = JsonUtil.getInfo(item, "modifiertypes", JSONArray.class);
            if (modifiertypes != null && modifiertypes.size() > 0) {
                for (int m = 0; m < modifiertypes.size(); m++) {
                    JSONObject itemType = modifiertypes.getJSONObject(m);
                    JSONArray modifiertDetail = JsonUtil.getInfo(itemType, "modifiers", JSONArray.class);
                    if (modifiertDetail != null && modifiertDetail.size() > 0) {
                        for (int s = 0; s < modifiertDetail.size(); s++) {
                            JSONObject itemS = modifiertDetail.getJSONObject(s);
                            billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "modifierName", String.class) + "*" + JsonUtil.getInfo(itemS, "modifierNum", String.class), 1);
                        }
                    }
                }
            }
        }

        billPrint.addHortionalLine();
        billPrint.addText(PrintStringUtil.padLeft("总计:" + JsonUtil.getInfo(ob, "total", String.class), billPrint.charSize, billPrint.gbkSize));
        billPrint.addText(PrintStringUtil.padLeft("已支付:" + JsonUtil.getInfo(ob, "paidAmt", String.class), billPrint.charSize, billPrint.gbkSize));

        billPrint.addHortionalLine();
        billPrint.addText("备注:" + JsonUtil.getInfo(ob, "orderDesc", String.class) + "\n");
        billPrint.addCenterTextPaddingWithDash("账单结算");
        billPrint.addCenterText(DateUtil.getCurrentTime());
        billPrint.addBlankLine();
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }
        billPrint.addText("\n");
        billPrint.addBlankLine(1);

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);

    }

    /**
     * 预付金小票
     *
     * @param ob
     * @param task
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/printPrePayReceipt")
    public static PrintResult printPrePayReceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        try {

            billPrint.addTitle(JsonUtil.getInfo(ob, "fsShopName", String.class));
            billPrint.addTitle("预付金小票");

            String date = "日期：" + JsonUtil.getInfo(ob, "time", String.class);
            String descTableName = "台号：";
            String tableName = JsonUtil.getInfo(ob, "fsmtablename", String.class);

            billPrint.addText(PrintStringUtil.padRight(date, billPrint.charSize - descTableName.getBytes("GBK").length - tableName.getBytes("GBK").length * 2, billPrint.gbkSize));
            billPrint.addText(descTableName, 1, PrintDataItem.ALIGN_RIGHT, 0);
            billPrint.addText(tableName, 2, PrintDataItem.ALIGN_RIGHT, 0);
            billPrint.addText("\n");
            billPrint.addBlankLine();

            String fssellno = JsonUtil.getInfo(ob, "fssellno", String.class);
            String section = JsonUtil.getInfo(ob, "section", String.class);
            billPrint.addText(PrintStringUtil.padRight("单号：" + fssellno, billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("餐段：" + section, billPrint.charSize / 2, billPrint.gbkSize) + "\n");

            String userName = JsonUtil.getInfo(ob, "fsCreateUserName", String.class);
            String personNum = JsonUtil.getInfo(ob, "count", String.class);
            billPrint.addText(PrintStringUtil.padRight("收款人：" + userName, billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("人数：" + personNum, billPrint.charSize / 2, billPrint.gbkSize) + "\n");

            billPrint.addHortionaDoublelLine();
            billPrint.addText(PrintStringUtil.padRight("支付方式", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("金额", billPrint.charSize / 2, billPrint.gbkSize) + "\n");

            JSONArray list = JsonUtil.getInfo(ob, "paymentArr", JSONArray.class);
            if (list != null && list.size() > 0) {
                for (int m = 0; m < list.size(); m++) {
                    JSONObject item = list.getJSONObject(m);
                    billPrint.addText(PrintStringUtil.padRight(JsonUtil.getString(item, "payName"), billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(JsonUtil.getString(item, "payAmt"), billPrint.charSize / 2, billPrint.gbkSize) + "\n");
                }
            }

            billPrint.addHortionaDoublelLine();

            billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
            billPrint.addBlankLine();
            billPrint.addCut();

        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

/**********************************************************************冷冻室（老微信外卖的打印方法，下单入口已停用）*********************************************************************************/

    /**
     * 微信外卖结账单
     *
     * @param ob
     * @param task
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/wechatOrderReceipt")
    public static PrintResult wechatOrderReceipt(JSONObject ob, PrintTaskDBModel task, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addLine();
        billPrint.addCenterTextPaddingWithDash(JsonUtil.getInfo(ob, "title", String.class));
        if (!TextUtils.isEmpty(JsonUtil.getInfo(ob, "title_little", String.class))) {
            billPrint.addCenterText(JsonUtil.getInfo(ob, "title_little", String.class));
        }

        String restNum = JsonUtil.getInfo(ob, "restNum", String.class); //第三方每日订单序号
        if (!TextUtils.isEmpty(restNum)) {
            billPrint.addText("#" + restNum + "\n", 2);
        }
        billPrint.addText(JsonUtil.getInfo(ob, "orderId", String.class) + "\n");
        billPrint.addText(JsonUtil.getInfo(ob, "fsShopName", String.class) + "\n");
        //billPrint.addText(JsonUtil.getInfo(ob, "fsAddr") + "\n");

        billPrint.addHortionalLine();
        billPrint.addText(JsonUtil.getInfo(ob, "payStatus", String.class) + "\n");
        billPrint.addText("下单时间:" + JsonUtil.getInfo(ob, "data", String.class) + "\n");

        billPrint.addHortionalLine();
        billPrint.addContentListHeader(
                GlobalCache.getContext().getString(R.string.print_item),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total));

        //微信外卖的菜
        JSONArray wechatOrderDetailList = JsonUtil.getInfo(ob, "orderitem", JSONArray.class);
        if (wechatOrderDetailList != null) {
            for (int i = 0; i < wechatOrderDetailList.size(); i++) {
                JSONObject item = wechatOrderDetailList.getJSONObject(i);
                billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class),
                        JsonUtil.getInfo(item, "fdrealamount", String.class),
                        JsonUtil.getInfo(item, "fiitemnum", String.class),
                        JsonUtil.getInfo(item, "fdsubtotal", String.class),
                        1);
                String note = JsonUtil.getInfo(item, "fsremark", String.class);
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier(note, 1);
                }
            }
        }

        billPrint.addHortionalLine();
        billPrint.addText(PrintStringUtil.padRight("配送费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft("" + JsonUtil.getInfo(ob, "deliveryFee", String.class), billPrint.charSize / 2, billPrint.gbkSize));
        String boxFee = JsonUtil.getInfo(ob, "boxFee", String.class);
        if (!TextUtils.isEmpty(boxFee)) {
            billPrint.addText(PrintStringUtil.padRight("餐盒费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(boxFee, billPrint.charSize / 2, billPrint.gbkSize));
        }

        String fdServiceAmt = JsonUtil.getInfo(ob, "fdServiceAmt", String.class);
        if (!TextUtils.isEmpty(fdServiceAmt)) {
            billPrint.addText(PrintStringUtil.padRight("外卖平台服务费", billPrint.charSize / 2, billPrint.gbkSize) + PrintStringUtil.padLeft(fdServiceAmt, billPrint.charSize / 2, billPrint.gbkSize));
        }

        //其他抵扣方式
        billPrint.addHortionalLine();
        billPrint.addText("合计:" + JsonUtil.getInfo(ob, "subTotal", String.class) + "\n");
        billPrint.addText("优惠:" + JsonUtil.getInfo(ob, "youhui", String.class) + "\n");
        billPrint.addText("实付:" + JsonUtil.getInfo(ob, "total", String.class) + "\n");

        String earnestMoney = JsonUtil.getInfo(ob, "earnestMoney", String.class);
        if (!TextUtils.isEmpty(earnestMoney)) {
            billPrint.addText("实收:" + earnestMoney + "\n");
        }

        String bizType = JsonUtil.getInfo(ob, "bizType", String.class);
        billPrint.addText("地址:" + JsonUtil.getInfo(ob, "address", String.class) + "\n");
        billPrint.addText("电话:" + JsonUtil.getInfo(ob, "distributionPhone", String.class) + "\n");
        billPrint.addText("姓名:" + JsonUtil.getInfo(ob, "distributionName", String.class) + "\n");
        billPrint.addText(JsonUtil.getInfo(ob, "distributionStartTime", String.class) + "\n");
        billPrint.addText("人数:" + JsonUtil.getInfo(ob, "person", String.class) + "\n");
//        billPrint.addText("备餐模式:" + JsonUtil.getInfo(ob, "readyFoodMode", String.class) + "\n");

        billPrint.addText("备注:" + JsonUtil.getInfo(ob, "orderDesc", String.class) + "\n");
        String invoice = JsonUtil.getInfo(ob, "invoice", String.class);
        if (!TextUtils.isEmpty(invoice)) {
            billPrint.addText("发票:" + invoice + "\n");
        }
        billPrint.addHortionalLine();

        String printTime = JsonUtil.getInfo(ob, "PrintTime", String.class); //打印时间
        String fiPrintNo = JsonUtil.getInfo(ob, "fiPrintNo", String.class); //印号
        String fsDptrName = JsonUtil.getInfo(ob, "fsDptrName", String.class); //打印站点

        billPrint.addLeftWithRight("打印时间:" + printTime, "印号:" + fiPrintNo);
        billPrint.addText(fsDptrName + "\n");
        billPrint.addHortionalLine();
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);
        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine(1);
        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(task, billPrint.data, config);

    }


}
