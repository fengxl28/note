package com.mwee.android.posprint.device;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Environment;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.posprint.business.P433Util;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.printer.P433Printer.P433PrinterConfig;
import com.mwee.android.print.printer.P433Printer.P433SerialManager;
import com.mwee.android.print.printer.P433Printer.components.P433StatusChangeListener;
import com.mwee.android.print.printer.P433Printer.model.P433PrinterStatus;
import com.mwee.android.print.printer.P433Printer.utils.P433Const;
import com.mwee.android.print.printer.bluetoothPrinter.BluetoothPrinterConfig;
import com.mwee.android.print.printer.cloud.CloudPrinterConfig;
import com.mwee.android.print.printer.cloud.CloudPrinterDevice;
import com.mwee.android.print.printer.ipPrinter.IpPrinterConfig;
import com.mwee.android.print.printer.serialPrinter.SerialPortPrinterConfig;
import com.mwee.android.print.printer.usbPriter.UsbPortPrinterConfig;
import com.mwee.android.print.printer.usbserial.UsbSerialPrinterConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * DeviceManager
 * Created by virgil on 16/7/5.
 */
public class DeviceManager {
    private final static String TAG = "PrintCall";
    private final static String CONGIG_FILE_CHECK_PRINTER_IP = "CheckPrinterIPShopInfo";
    private final static DeviceManager instance = new DeviceManager();

    /**
     * 缓存的打印机map,Key为PrinterName,value为Printer实例
     */
    protected ArrayMap<String, PrinterConfig> printerMap = new ArrayMap<>();
    /**
     * 缓存的打印机map,Key为打印机硬件唯一标示,value为Printer实例
     */
    private ArrayMap<String, PrinterConfig> printerUniq = new ArrayMap<>();

    private DeviceManager() {

    }

    public static DeviceManager getInstance() {
        return instance;
    }

    public static void updateSize(PrinterConfig printerConfig, int size) {
        printerConfig.paperSize = PrintUtil.getSize(printerConfig.commandType, size);
    }

    public boolean openMoneyBox(PrintTaskDBModel printTask) {
        boolean result = false;
        checkPrinter(printTask.fsPrinterName);
//        Printer printer = printerMap.get(printTask.fsPrinterName);
//        if (printer == null) {
//            result = false;
//        } else {
//            synchronized (printer) {
//                try {
//                    printer.openMoneyBox();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
        return result;
    }

    /**
     * 注册打印机
     *
     * @param model PrinterDBModel
     */
    public synchronized void registPrinter(PrinterDBModel model) {
        checkPrinter(model);
    }

    /**
     * 重新构建所有的打印机实例
     */
    public synchronized void rebuildAllPrinter() {
        address433.clear();
        List<PrinterDBModel> printerList = DBSimpleUtil.queryList(APPConfig.DB_CLIENT, "where fiStatus='1'", PrinterDBModel.class);
        //读取usb打印机选择的device配置
        List<JSONObject> usbSymbolList = DBSimpleUtil.queryJsonList(APPConfig.DB_CLIENT, "select key,value from datacache where type='" + IOCache.TYPE_PRINTER_USB + "'");
        DeviceManager.getInstance().clearPrinterCache();
        for (PrinterDBModel temp : printerList) {
            if ((temp.checkIsP433Serial() || temp.checkIsUsb()) && !ListUtil.isEmpty(usbSymbolList)) {
                for (JSONObject tempJ : usbSymbolList) {
                    if (TextUtils.equals(temp.fsPrinterName, tempJ.getString("key"))) {
                        String value = tempJ.getString("value");
                        if (!TextUtils.isEmpty(value)) {
                            //更新USB打印机选择的设备
                            if (temp.checkIsUsb() && !TextUtils.equals(value, temp.fsStr1)) {
                                DBSimpleUtil.excuteSql(APPConfig.DB_CLIENT, "update tbPrinter set fsStr1='" + value + "' where fsPrinterName='" + temp.fsPrinterName + "'");
                                temp.fsStr1 = value;
                            }

                            if (temp.checkIsP433Serial()) {
                                DBSimpleUtil.excuteSql(APPConfig.DB_CLIENT, "update tbPrinter set fsPrinterSN='" + value + "' where fsPrinterName='" + temp.fsPrinterName + "'");
                                temp.fsPrinterSN = value;
                            }
                        }
                    }
                }
            }
            DeviceManager.getInstance().registPrinter(temp);
        }

        if (isSupportP433Printer(printerList)) {
            P433SerialManager.getInstance().initManager(address433, new P433StatusChangeListener() {
                @Override
                public void onConnectStatus(String connectStatus, String stationID) {
                    if (P433Const.CONNECT_CONNECT.equals(connectStatus)) {
                        P433SerialManager.configPrinters(address433);
                        P433Util.getInstance().updateHostIdOfStation(stationID);
                    }
                }
                @Override
                public void onPrintersStatus(Map<String, P433PrinterStatus> map) {
                    P433Util.getInstance().updatePrinterMap(map);
                }
            });
            LogUtil.log("P433", "do init!");
        }
    }


    private boolean isSupportP433Printer(List<PrinterDBModel> printerList) {

        boolean isSupport = false;
        if (ListUtil.isEmpty(printerList)) {
            return isSupport;
        }
        for (int i = 0; i < printerList.size(); i++) {
            PrinterDBModel printerDBModel = printerList.get(i);
            if (printerDBModel.checkIsP433Serial()) {
                isSupport = true;
                break;
            }
        }
        return isSupport;

    }


    public PrinterConfig getPrinterConfig(String printerName) {
        return printerMap.get(printerName);
    }

    /**
     * 检测是否已经有了指定的打印
     *
     * @param model PrinterDBModel
     */
    private void checkPrinter(PrinterDBModel model) {
        if (model != null && !TextUtils.isEmpty(model.fsPrinterName)) {
            buildPrinter(model);

        }
    }

    public synchronized void clearPrinterCache() {
        if (printerMap == null) {
            printerMap = new ArrayMap<>();
        }
        printerMap.clear();
        if (printerUniq == null) {
            printerUniq = new ArrayMap<>();
        }
//        printerUniq.clear();
    }

    private void checkPrinter(String printerName) {
        if (!TextUtils.isEmpty(printerName)) {
            if (printerMap.get(printerName) != null) {
                return;
            } else {
                PrinterDBModel printer = DBSimpleUtil.query(APPConfig.DB_CLIENT, "where fsPrinterName='" + printerName + "'", PrinterDBModel.class);
                if (printer != null) {
                    buildPrinter(printer);
                }
            }
        }
    }

    List<String> address433 = new ArrayList<>();

    Map<String, String> whiteListMap = null;

    private boolean checkIpWhitelist(String shopId) {
        try {
            if (whiteListMap == null) {
                if (GlobalCache.getContext() == null) {
                    return false;
                }
                String path = GlobalCache.getContext().getExternalCacheDir().getPath() + File.separator + "MwConfig" + File.separator + CONGIG_FILE_CHECK_PRINTER_IP;
                if (TextUtils.isEmpty(path)) {
                    LogUtil.logBusiness("checkIpWhitelist 获取配置文件路径异常");
                    return false;
                }
                String config = FileUtil.readFile(path);
                LogUtil.logBusiness(path + "流控配置文件内容：" + config);
                if (TextUtils.isEmpty(config)) {
                    config = "191586,143532,3431,167334,214851,206711,7598,3435,7854,212485,3432,3429,226006,188956";
                    //return false;
                    LogUtil.logBusiness("读到配置是空，手动赋值191586,143532,3431,167334,214851,206711,7598,3435,7854,212485,3432,3429,226006,188956");
                }

                String[] whitelist = config.split(",");
                if (whitelist.length <= 0) {
                    return false;
                }
                whiteListMap = new ArrayMap<>();
                for (String id : whitelist) {
                    whiteListMap.put(id.trim(), "");
                }
            }

            if (whiteListMap.get(shopId.trim()) != null) {
                return true;
            }

        } catch (Exception e) {
            LogUtil.logBusiness("checkIpWhitelist 获取配置文件路径异常 " + JSON.toJSONString(e));
            return false;
        }

        return false;
    }

    /**
     * 构建打印机
     *
     * @param model PrinterDBModel
     */
    private synchronized void buildPrinter(PrinterDBModel model) {
        switch (model.fiPrinterCls) {
            case PrinterType.NET: {
                PrinterConfig config;

                config = new IpPrinterConfig();
                ((IpPrinterConfig) config).ip = model.fsIP;
                //  2018/7/5 待打印部分完成，发布 AAR;AAR版本已修改
//                String mShopID = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.SHOPID + "'");
//                if (checkIpWhitelist(mShopID)) {
//                    ((IpPrinterConfig) config).controlByteAlone = true;
//                    ((IpPrinterConfig) config).setReceiptModel(IpPrinterConts.RECEIPT_MODE_GSRN);
//                }
//                ((IpPrinterConfig) config).setReceiptModel(model.fiPrinterNum,model.fiControlBill);


                ((IpPrinterConfig) config).port = 9100;
                PrinterConfig temp = printerUniq.get(config.getUniq());
                if (temp != null) {
                    config = temp;
                } else {
                    printerUniq.put(config.getUniq(), config);
                }
                ((IpPrinterConfig) config).setReceiptModel(model.fiPrinterNum,model.fiControlBill);
                PrintUtil.buildPrinterInfo(config, model);
                printerMap.put(model.fsPrinterName, config);
            }
            break;
            case PrinterType.SERIAL: {
                SerialPortPrinterConfig config = new SerialPortPrinterConfig();
                config.baudRate = model.fiInt1;
                config.devicePath = "/dev/" + model.fsStr1;
                try {
                    PrinterConfig temp = printerUniq.get(config.getUniq());
                    if (temp != null) {
                        config = (SerialPortPrinterConfig) temp;
                    } else {
                        printerUniq.put(config.getUniq(), config);
                    }
                    PrintUtil.buildPrinterInfo(config, model);
                    printerMap.put(model.fsPrinterName, config);
                } catch (Exception e) {
                    LogUtil.logError(e);
                }
            }
            break;
            case PrinterType.USB: {
                UsbPortPrinterConfig config;

                config = new UsbPortPrinterConfig(GlobalCache.getContext());
                if (!TextUtils.isEmpty(model.fsStr1) && !model.fsStr1.startsWith("BYUSB")) {
                    config.symbol = model.fsStr1;
                }
                PrinterConfig temp = printerUniq.get(config.getUniq());
                if (temp != null) {
                    config = (UsbPortPrinterConfig) temp;
                } else {
                    printerUniq.put(config.getUniq(), config);
                }
                PrintUtil.buildPrinterInfo(config, model);
                //打印库根据型号和票控模式来确定是否开启优化，美小易特殊处理
                config.setReceiptModel(model.fiPrinterNum,PrintUtil.checkUsbPrinterModel(model.fiPrinterNum));
                printerMap.put(model.fsPrinterName, config);
            }
            break;
            case PrinterType.USBSERIAL: {
                UsbSerialPrinterConfig config;

                config = new UsbSerialPrinterConfig(GlobalCache.getContext());
                if (!TextUtils.isEmpty(model.fsStr1) && !model.fsStr1.startsWith("BYUSB")) {
                    config.symbol = model.fsStr1;
                }
                config.baudRate = model.fiInt1;
                PrintUtil.buildPrinterInfo(config, model);

                PrinterConfig temp = printerUniq.get(config.getUniq());
                if (temp != null) {
                    config = (UsbSerialPrinterConfig) temp;
                } else {
                    printerUniq.put(config.getUniq(), config);
                }
                PrintUtil.buildPrinterInfo(config, model);
                printerMap.put(model.fsPrinterName, config);
            }
            break;
            case PrinterType.PARELL:
                break;
            case PrinterType.BLUETOOTH: {
                BluetoothPrinterConfig config;

                config = new BluetoothPrinterConfig(GlobalCache.getContext());
                config.macAddress = model.fsIP;
                PrinterConfig temp = printerUniq.get(config.getUniq());
                if (temp != null) {
                    config = (BluetoothPrinterConfig) temp;
                } else {
                    printerUniq.put(config.getUniq(), config);
                }
                PrintUtil.buildPrinterInfo(config, model);
                printerMap.put(model.fsPrinterName, config);
            }
            break;
            case PrinterType.CLOUD:
                // 云打印机
                CloudPrinterConfig config;
                config = new CloudPrinterConfig(GlobalCache.getContext());
                config.env = BaseConfig.isProduct() ? Environment.PRODUCT : Environment.DEV;
//                config.mShopID = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.SHOPID + "'");
//                config.symbol = model.fsPrinterSN;
                String mShopID = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.SHOPID + "'");
                String symbol = model.fsPrinterSN;
                String mToken = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.TOKEN + "'");
                String mSeed = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.SEED + "'");

                config.setShopInfo(mShopID,mToken,mSeed);
                config.setPrinterInfo(symbol, CloudPrinterDevice.getPrinterDevice(String.valueOf(model.fiPrinterNum)));
                PrinterConfig temp = printerUniq.get(config.getUniq());
                if (temp != null) {
                    config = (CloudPrinterConfig) temp;
                } else {
                    printerUniq.put(config.getUniq(), config);
                }
                PrintUtil.buildPrinterInfo(config, model);
                // 重新绑定后，token, seed 可能改变，需要重新赋值
//                config.mToken = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.TOKEN + "'");
//                config.mSeed = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key = '" + META.SEED + "'");

                config.setShopInfo(mShopID,mToken,mSeed);
                config.setPrinterInfo(symbol, CloudPrinterDevice.getPrinterDevice(String.valueOf(model.fiPrinterNum)));
                printerMap.put(model.fsPrinterName, config);
                break;

            case PrinterType.P433:
//                int address = StringUtil.toInt(model.fsPrinterSN, -1);
//                if (address < 0) {
//                    break;
//                }
                if(!PrintUtil.check433PrinterSNIsRight(model.fsPrinterSN)){
                    break;
                }
                String address = model.fsPrinterSN;

                P433PrinterConfig configP433 = new P433PrinterConfig(address);
                address433.add(address);

                configP433.controlByteAlone = true;
                PrinterConfig tempP433 = printerUniq.get(configP433.getUniq());
                if (tempP433 != null) {
                    configP433 = (P433PrinterConfig) tempP433;
                } else {
                    printerUniq.put(configP433.getUniq(), configP433);
                }
                PrintUtil.buildPrinterInfo(configP433, model);
                printerMap.put(model.fsPrinterName, configP433);
                break;


            default:
                break;
        }
    }


}
