package com.mwee.android.posprint.queue;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.text.TextUtils;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * 定时任务
 * Created by sunkai on 15/11/17.
 * @author virgil
 */
public class DinnerPrintWakeUpReceiver extends BroadcastReceiver {
    public final static int WAKEUP_CYCLE = 60 * 4;
    public static final String ACTION_RE_PRINT = "com.mwee.android.pos.print.reprint";
    public static final String ACTION_LOOP = "com.mwee.android.pos.print.loop";

    public static final Object lock = new Object();
    public static boolean alive = false;
    public static volatile boolean processing = false;

    /**
     * 注册闹钟
     *
     * @param context Context
     */
    public static void registerAlarm(Context context) {
        if (context != null && !alive) {
            LogUtil.log("MB WakeUp registerAlarm");


            Intent intent = new Intent(context, DinnerPrintWakeUpReceiver.class);
            intent.setAction(ACTION_RE_PRINT);
            context.sendBroadcast(intent);
        }
    }

    private static void startLoop(Context context){
        if (context != null && !alive) {
            long firsTime = SystemClock.elapsedRealtime();
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            LogUtil.log("MB WakeUp registerAlarm");
            Intent intent = new Intent(context, DinnerPrintWakeUpReceiver.class);
            intent.setAction(ACTION_LOOP);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            if (am != null) {
                am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firsTime, WAKEUP_CYCLE * 1000, pendingIntent);
            }
            alive = true;
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        //如果是首次唤醒的闹钟，则开始检测任务，如果是两分钟的保活，则跳过
        if(TextUtils.equals(action,ACTION_RE_PRINT)){
            startLoop(context);
            try {
                processWakeUp();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        //清除历史打印数据
        cleanExpiredData();

    }

    private void processWakeUp() {
        if (processing) {
            return;
        }
        DinnerPrintWakeUpReceiver.processing = true;
//        String expiredMinute = CommonDBUtil.getConfig(DBPrintConfig.TASK_LIMIT_TIME);
        //
        String expiredMinute="";
        int tempExpiredSecond = 5 * 60;
        if(!TextUtils.isEmpty(expiredMinute)){
            tempExpiredSecond=StringUtil.toInt(expiredMinute, 5) * 60;
        }
        final int expiredSecond = tempExpiredSecond;
        new LowThread(()->{
                synchronized (DinnerPrintWakeUpReceiver.lock) {
                    String currentHostID = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);

                    //最多同时处理15个任务
                    String currentTime=DateUtil.getCurrentTime();
                    //将已失败且已经超时的任务的状态设置为已超时
                    String sqlUpdateExpried="update tbPrintTask set fiStatus='8',fsFinishTime='"+currentTime+"' where fsHostId='" + currentHostID + "' and fiTaskType='1' and ((JulianDay('"+currentTime+"') - JulianDay(fsCreateTime)) * 24 * 60*60 )>"+expiredSecond+" and fiStatus='3' and fiErrCount<fiRetry";
                    DBSimpleUtil.excuteSql(APPConfig.DB_PRINT,sqlUpdateExpried);

                    String sql = "where fsHostId='" + currentHostID + "' and fiTaskType='1' and fiStatus not in (4,8) ";
                    List<PrintTaskDBModel> taskList = DBSimpleUtil.queryList(APPConfig.DB_PRINT,sql, PrintTaskDBModel.class);

                    if (taskList==null||taskList.size() <= 0) {
                        LogUtil.log("PRINTCALL", "轮询 没有已超时的任务了");
                        processing=false;
                        return;
                    }
                    ContentValues values = new ContentValues();
                    for (PrintTaskDBModel temp : taskList) {
                        if (temp.fiTaskType == 1) {
                            String createTime=temp.fsCreateTime;
                            if(!temp.fsCreateTime.contains("-")){
                                createTime=DateUtil.formartDateStrToTarget(temp.fsCreateTime,DateUtil.DATE_YYYYMMDDHHMMSS,DateUtil.DATE_VISUAL14FORMAT);
                            }
                            long timePast = DateUtil.compareDate(createTime, currentTime, DateUtil.DATE_VISUAL14FORMAT)/1000;
                            LogUtil.log("PRINTCALL", "轮询任务,printTaskNO=" + temp.fiPrintNo + ";printerName=" + temp.fsPrinterName+",timePast="+timePast);

//                            if(timePast<80){
//                                continue;
//                            }
                            if (timePast > expiredSecond) {
                                // 设置为已逾期
                                values.clear();
                                values.put("fiStatus", 8);
                                values.put("fsFinishTime", currentTime);
                                TaskDBUtil.updateTask(temp, values);
                                TaskDBUtil.checkRetry(temp);
                                continue;
                            }
                            DinnerPrintProcessor.processPrint(temp);
                        }
                    }
                    DinnerPrintWakeUpReceiver.processing = false;
                }
        }).start();
    }


    private static long lastCleantime=0;
    /**
     * 删除大于当前日期2天以上打印数据
     */
    public static void cleanExpiredData() {
        if (lastCleantime == 0 || (SystemClock.elapsedRealtime() - lastCleantime) > 2 * 60 * 60 * 1000) {
            lastCleantime = SystemClock.elapsedRealtime();
            DBManager.getInstance(APPConfig.DB_PRINT).executeInTransaction((db) -> {
                String currentBusinessDate = DateUtil.getCurrentTime();
                db.delete("tbPrintTask", " (julianday('" + currentBusinessDate + "')-julianday(fsCreateTime))>2 ", null);
                return true;
            });
        }
    }

}