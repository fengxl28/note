package com.mwee.android.posprint.business.kobei;

import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.image.PictureManager;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;

/**
 * Created by huangming on 2018/9/21.
 */
public class KobeiCommandProcessor implements IDriver {

    private final static String DRIVER_TAG = "koubei";

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    /**
     * 口碑制作单
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/makeOrder")
    public static PrintResult makeOrder(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }
        billPrint.addTitle("口碑点餐制作单");
        JSONObject KBPreOrderCache = JsonUtil.getInfo(ob, "KBPreOrderCache", JSONObject.class);
        String take_no = JsonUtil.getInfo(KBPreOrderCache, "take_no", String.class);
        String receiptType = JsonUtil.getString(ob, "receiptType");
        if (!TextUtils.isEmpty(take_no)) {
            billPrint.addCenterText(receiptType + "#" + take_no, 2);
        }
        billPrint.addLine();
        billPrint.addHortionalLine();
        billPrint.addLeftWithRight("名称", "数量");
        JSONArray dish_details = JsonUtil.getInfo(ob, "dish_details", JSONArray.class);
        if (dish_details != null) {
            for (int i = 0; i < dish_details.size(); i++) {
                JSONObject detail = dish_details.getJSONObject(i);
                billPrint.addLeftWithRight(JsonUtil.getString(detail, "dish_name"), JsonUtil.getString(detail, "dish_num") + "/" + JsonUtil.getString(detail, "dish_unit"), 2);
                //--属于全家桶套餐
                String parentName = JsonUtil.getString(detail, "parentName");
                if (!TextUtils.isEmpty(parentName)) {
                    billPrint.addOrderModifier("-(属于)" + parentName, 2);
                }
                //fsnote
                String memo = JsonUtil.getString(detail, "memo");
                if (!TextUtils.isEmpty(memo)) {
                    billPrint.addOrderModifier(memo, 2);
                }
                String practice_info = JsonUtil.getString(detail, "practice_info");
                if (!TextUtils.isEmpty(practice_info)) {
                    billPrint.addOrderModifier(practice_info, 1);
                }

                JSONArray selectedModifier = JsonUtil.getInfo(detail, "selectedModifier", JSONArray.class);
                for (int k = 0; k < selectedModifier.size(); k++) {
                    JSONObject selectedModifierModel = selectedModifier.getJSONObject(k);
                    StringBuilder sb = new StringBuilder("");
                    sb.append(JsonUtil.getString(selectedModifierModel, "dish_name")).append("*").append(JsonUtil.getString(selectedModifierModel, "dish_num")).append("/").append(JsonUtil.getString(selectedModifierModel, "dish_unit"));
                    billPrint.addOrderModifier(sb.toString(), 1);

                }

            }
        }


        billPrint.addHortionalLine();
        String dinner_type = JsonUtil.getString(KBPreOrderCache, "dinner_type");
        if (!TextUtils.isEmpty(dinner_type)) {
            billPrint.addText("就餐方式：" + dinner_type + "\n");
        }
        String memo = JsonUtil.getString(KBPreOrderCache, "memo");
        if (!TextUtils.isEmpty(memo)) {
            billPrint.addText("备注：" + memo + "\n");
        }
        String table_time = JsonUtil.getString(KBPreOrderCache, "table_time");
        if (!TextUtils.isEmpty(table_time)) {
            billPrint.addText("预约就餐时间：" + table_time + "\n", 2);
        }
        String user_mobile = JsonUtil.getString(KBPreOrderCache, "user_mobile");
        if (!TextUtils.isEmpty(user_mobile)) {
            billPrint.addText("联系人电话：" + user_mobile + "\n");
        }
        String mwOrderId = JsonUtil.getString(KBPreOrderCache, "mwOrderId");
        if (!TextUtils.isEmpty(mwOrderId)) {
            billPrint.addText("订单号：" + mwOrderId + "\n");
        }

        //美易点和美小易模版稍有区别，再次加以区分
        if (APPConfig.isAir()) {
            billPrint.addLeftWithRight(DateUtil.getCurrentTime(), "印号：" + JsonUtil.getString(ob, "fiPrintNo"));
        } else {
            billPrint.addText("打印时间：" + DateUtil.getCurrentTime() + "\n");
            billPrint.addLeftWithRight("打印部门：" + JsonUtil.getString(ob, "Dept"), "印号：" + JsonUtil.getString(ob, "fiPrintNo"));
        }

        billPrint.addBlankLine();

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 口碑预点单-商家联
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/preOrderMerchant")
    public static PrintResult preOrderMerchant(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }

        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));

        billPrint.addTitle("口碑点餐" + JsonUtil.getString(ob, "titleSubFix") + JsonUtil.getString(ob, "titleRemind"));
        billPrint.addBlankLine(2);

        JSONObject KBPreOrderCache = JsonUtil.getInfo(ob, "KBPreOrderCache", JSONObject.class);
        billPrint.addText("口碑订单单号：" + JsonUtil.getString(KBPreOrderCache, "order_id") + "\n");
        String mwOrderId = JsonUtil.getString(KBPreOrderCache, "mwOrderId");
        if (!TextUtils.isEmpty(mwOrderId)) {
            billPrint.addText("美味订单单号：" + mwOrderId + "\n");
        }

        billPrint.addHortionalLine();

        billPrint.addLeftWithRight("就餐方式：" + JsonUtil.getString(KBPreOrderCache, "dinner_type"), "人数：" + JsonUtil.getString(KBPreOrderCache, "people_num"));
        billPrint.addText("桌号/取餐号：" + JsonUtil.getString(KBPreOrderCache, "take_no") + "\n", 2);
        billPrint.addText("下单时间：" + JsonUtil.getString(KBPreOrderCache, "order_time") + "\n");
        billPrint.addText("预约时间：" + JsonUtil.getString(KBPreOrderCache, "table_time") + "\n", 2);
        String user_mobile = JsonUtil.getString(KBPreOrderCache, "user_mobile");
        if (!TextUtils.isEmpty(user_mobile)) {
            billPrint.addText("联系电话：" + user_mobile + "\n");
        }

        billPrint.addHortionaDoublelLine();

        billPrint.addOrderItem("名称", "单价", "数量", "总额", 1);

        JSONArray dish_details = JsonUtil.getInfo(ob, "dish_details", JSONArray.class);
        if (dish_details != null) {
            for (int i = 0; i < dish_details.size(); i++) {
                JSONObject detail = dish_details.getJSONObject(i);
                billPrint.addOrderItem(JsonUtil.getString(detail, "dish_name") + "(" + JsonUtil.getString(detail, "dish_unit") + ")",
                        JsonUtil.getString(detail, "sell_price"),
                        JsonUtil.getString(detail, "dish_num"),
                        JsonUtil.getString(detail, "dish_total_amount"),
                        1);

                //打印套餐明细
                JSONArray slit = JsonUtil.getInfo(detail, "SLIT", JSONArray.class);
                if (slit != null && slit.size() > 0) {
                    for (int m = 0; m < slit.size(); m++) {
                        JSONObject itemS = slit.getJSONObject(m);
                        billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "dish_name", String.class) + "*" + JsonUtil.getInfo(itemS, "dish_num", String.class), 1);
                    }
                }

                //fsnote
                String memo = JsonUtil.getString(detail, "memo");
                if (!TextUtils.isEmpty(memo)) {
                    billPrint.addOrderModifier(memo, 1);
                }
                String practice_info = JsonUtil.getString(detail, "practice_info");
                if (!TextUtils.isEmpty(practice_info)) {
                    billPrint.addOrderModifier(practice_info, 1);
                }
                String member_price = JsonUtil.getString(detail, "member_price");
                if (!TextUtils.isEmpty(member_price)) {
                    billPrint.addLeftWithRight("", member_price);
                }

                JSONArray selectedModifier = JsonUtil.getInfo(detail, "selectedModifier", JSONArray.class);
                for (int k = 0; k < selectedModifier.size(); k++) {
                    JSONObject selectedModifierModel = selectedModifier.getJSONObject(k);
                    billPrint.addOrderItem(JsonUtil.getString(selectedModifierModel, "dish_name") + "(" + JsonUtil.getString(selectedModifierModel, "dish_unit") + ")",
                            JsonUtil.getString(selectedModifierModel, "sell_price"),
                            JsonUtil.getString(selectedModifierModel, "dish_num"),
                            new BigDecimal(JsonUtil.getString(selectedModifierModel, "sell_price")).multiply(new BigDecimal(JsonUtil.getString(selectedModifierModel, "dish_num"))) + "",
                            1);

                }

            }
        }

        billPrint.addHortionalLine();

        String memo = JsonUtil.getString(KBPreOrderCache, "memo");
        if (!TextUtils.isEmpty(memo)) {
            billPrint.addText("备注：" + memo + "\n");
            billPrint.addHortionalLine();
        }

        billPrint.addText("服务费：" + JsonUtil.getString(KBPreOrderCache, "service_amount") + "\n");
        billPrint.addText("打包费：" + JsonUtil.getString(KBPreOrderCache, "packing_amount") + "\n");
        billPrint.addText("其他费用：" + JsonUtil.getString(KBPreOrderCache, "other_amount") + "\n");

        billPrint.addHortionalLine();

        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        billPrint.addSub("消费合计", JsonUtil.getInfo(sub, "qty", String.class), JsonUtil.getInfo(KBPreOrderCache, "bill_amount", String.class));
        billPrint.addSub("优惠合计", "", JsonUtil.getInfo(KBPreOrderCache, "discount_amount", String.class));
        billPrint.addSub("应收", "", JsonUtil.getInfo(KBPreOrderCache, "receipt_amount", String.class));

        billPrint.addHortionalLine();

        JSONArray statisticsDiscount = JsonUtil.getInfo(ob, "statisticsDiscount", JSONArray.class);
        if (statisticsDiscount != null && statisticsDiscount.size() > 0) {
            billPrint.addText("优惠明细" + "\n");
            for (int i = 0; i < statisticsDiscount.size(); i++) {
                JSONObject discountDetail = statisticsDiscount.getJSONObject(i);
                billPrint.addText(JsonUtil.getString(discountDetail, "fsDiscountName") + ":" + JsonUtil.getString(discountDetail, "discountamt") + "\n");
            }
        }
        JSONArray pay_channels = JsonUtil.getInfo(ob, "pay_channels", JSONArray.class);
        if (pay_channels != null && pay_channels.size() > 0) {
            billPrint.addText("支付明细" + "\n");
            for (int i = 0; i < pay_channels.size(); i++) {
                JSONObject payDetail = pay_channels.getJSONObject(i);
                billPrint.addText(JsonUtil.getString(payDetail, "channel_type") + ":" + JsonUtil.getString(payDetail, "pay_amount") + "\n");
            }
        }

        billPrint.addHortionalLine();

        billPrint.addLeftWithRight("打印时间：" + DateUtil.getCurrentTime(), "印号：" + JsonUtil.getString(ob, "fiPrintNo"));

        String printTailMessage = JsonUtil.getString(ob, "printTailMessage");
        if (!TextUtils.isEmpty(printTailMessage)) {
            billPrint.addCenterText(printTailMessage + "\n");
        }

        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine();

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    /**
     * 口碑预点单-客户联
     *
     * @param ob
     * @param taskModel
     * @param config
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/preOrderCustomer")
    public static PrintResult preOrderCustomer(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
        /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }

        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));

        billPrint.addTitle("口碑点餐" + JsonUtil.getString(ob, "titleSubFix") + JsonUtil.getString(ob, "titleRemind"));
        billPrint.addBlankLine(2);

        JSONObject KBPreOrderCache = JsonUtil.getInfo(ob, "KBPreOrderCache", JSONObject.class);
        billPrint.addText("口碑订单单号：" + JsonUtil.getString(KBPreOrderCache, "order_id") + "\n");
        String mwOrderId = JsonUtil.getString(KBPreOrderCache, "mwOrderId");
        if (!TextUtils.isEmpty(mwOrderId)) {
            billPrint.addText("美味订单单号：" + mwOrderId + "\n");
        }

        billPrint.addHortionalLine();

        billPrint.addLeftWithRight("就餐方式：" + JsonUtil.getString(KBPreOrderCache, "dinner_type"), "人数：" + JsonUtil.getString(KBPreOrderCache, "people_num"));
        billPrint.addText("桌号/取餐号：" + JsonUtil.getString(KBPreOrderCache, "take_no") + "\n", 2);
        billPrint.addText("下单时间：" + JsonUtil.getString(KBPreOrderCache, "order_time") + "\n");
        billPrint.addText("预约时间：" + JsonUtil.getString(KBPreOrderCache, "table_time") + "\n", 2);
        String user_mobile = JsonUtil.getString(KBPreOrderCache, "user_mobile");
        if (!TextUtils.isEmpty(user_mobile)) {
            billPrint.addText("联系电话：" + user_mobile + "\n");
        }

        billPrint.addHortionaDoublelLine();

        billPrint.addOrderItem("名称", "单价", "数量", "总额", 1);

        JSONArray dish_details = JsonUtil.getInfo(ob, "dish_details", JSONArray.class);
        if (dish_details != null) {
            for (int i = 0; i < dish_details.size(); i++) {
                JSONObject detail = dish_details.getJSONObject(i);
                billPrint.addOrderItem(JsonUtil.getString(detail, "dish_name") + "(" + JsonUtil.getString(detail, "dish_unit") + ")",
                        JsonUtil.getString(detail, "sell_price"),
                        JsonUtil.getString(detail, "dish_num"),
                        JsonUtil.getString(detail, "dish_total_amount"),
                        1);
                //打印套餐明细
                JSONArray slit = JsonUtil.getInfo(detail, "SLIT", JSONArray.class);
                if (slit != null && slit.size() > 0) {
                    for (int m = 0; m < slit.size(); m++) {
                        JSONObject itemS = slit.getJSONObject(m);
                        billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "dish_name", String.class) + "*" + JsonUtil.getInfo(itemS, "dish_num", String.class), 1);
                    }
                }
                //fsnote
                String memo = JsonUtil.getString(detail, "memo");
                if (!TextUtils.isEmpty(memo)) {
                    billPrint.addOrderModifier(memo, 1);
                }
                String practice_info = JsonUtil.getString(detail, "practice_info");
                if (!TextUtils.isEmpty(practice_info)) {
                    billPrint.addOrderModifier(practice_info, 1);
                }
                String member_price = JsonUtil.getString(detail, "member_price");
                if (!TextUtils.isEmpty(member_price)) {
                    billPrint.addLeftWithRight("", member_price);
                }

                JSONArray selectedModifier = JsonUtil.getInfo(detail, "selectedModifier", JSONArray.class);
                for (int k = 0; k < selectedModifier.size(); k++) {
                    JSONObject selectedModifierModel = selectedModifier.getJSONObject(k);
                    billPrint.addOrderItem(JsonUtil.getString(selectedModifierModel, "dish_name") + "(" + JsonUtil.getString(selectedModifierModel, "dish_unit") + ")",
                            JsonUtil.getString(selectedModifierModel, "sell_price"),
                            JsonUtil.getString(selectedModifierModel, "dish_num"),
                            new BigDecimal(JsonUtil.getString(selectedModifierModel, "sell_price")).multiply(new BigDecimal(JsonUtil.getString(selectedModifierModel, "dish_num"))) + "",
                            1);

                }

            }
        }

        billPrint.addHortionalLine();

        String memo = JsonUtil.getString(KBPreOrderCache, "memo");
        if (!TextUtils.isEmpty(memo)) {
            billPrint.addText("备注：" + memo + "\n");
            billPrint.addHortionalLine();
        }

        billPrint.addText("服务费：" + JsonUtil.getString(KBPreOrderCache, "service_amount") + "\n");
        billPrint.addText("打包费：" + JsonUtil.getString(KBPreOrderCache, "packing_amount") + "\n");
        billPrint.addText("其他费用：" + JsonUtil.getString(KBPreOrderCache, "other_amount") + "\n");

        billPrint.addHortionalLine();

        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        billPrint.addSub("消费合计", JsonUtil.getInfo(sub, "qty", String.class), JsonUtil.getInfo(KBPreOrderCache, "bill_amount", String.class));
        billPrint.addSub("优惠合计", "", JsonUtil.getInfo(KBPreOrderCache, "discount_amount", String.class));
        billPrint.addSub("应收", "", JsonUtil.getInfo(KBPreOrderCache, "receipt_amount", String.class));

        billPrint.addHortionalLine();

        JSONArray statisticsDiscount = JsonUtil.getInfo(ob, "statisticsDiscount", JSONArray.class);
        if (statisticsDiscount != null && statisticsDiscount.size() > 0) {
            billPrint.addText("优惠明细" + "\n");
            for (int i = 0; i < statisticsDiscount.size(); i++) {
                JSONObject discountDetail = statisticsDiscount.getJSONObject(i);
                billPrint.addText(JsonUtil.getString(discountDetail, "fsDiscountName") + ":" + JsonUtil.getString(discountDetail, "discountamt") + "\n");
            }
        }
        JSONArray pay_channels = JsonUtil.getInfo(ob, "pay_channels", JSONArray.class);
        if (pay_channels != null && pay_channels.size() > 0) {
            billPrint.addText("支付明细" + "\n");
            for (int i = 0; i < pay_channels.size(); i++) {
                JSONObject payDetail = pay_channels.getJSONObject(i);
                billPrint.addText(JsonUtil.getString(payDetail, "channel_type") + ":" + JsonUtil.getString(payDetail, "pay_amount") + "\n");
            }
        }

        billPrint.addHortionalLine();

        billPrint.addLeftWithRight("打印时间：" + DateUtil.getCurrentTime(), "印号：" + JsonUtil.getString(ob, "fiPrintNo"));

        String printTailMessage = JsonUtil.getString(ob, "printTailMessage");
        if (!TextUtils.isEmpty(printTailMessage)) {
            billPrint.addCenterText(printTailMessage + "\n");
        }

        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }

        billPrint.addBlankLine();

        billPrint.addCut();

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

}
