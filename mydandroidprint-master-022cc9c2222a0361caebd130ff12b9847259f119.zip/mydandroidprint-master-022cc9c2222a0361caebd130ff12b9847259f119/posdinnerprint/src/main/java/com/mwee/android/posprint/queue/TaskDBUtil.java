package com.mwee.android.posprint.queue;

import android.content.ContentValues;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.print.PrinterUpdateStatusResponse;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.ProcessUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * TaskDBUtil
 * Created by virgil on 16/7/8.
 */
public class TaskDBUtil {



    public static void receiveNewTask(String taskInfo) {
        final PrintTaskDBModel taskModel = JSON.parseObject(taskInfo, PrintTaskDBModel.class);
        taskModel.replaceNoTrans();
        LogUtil.logOnlineDebug("----打印任务写入结束 TaskDBUtil receiveNewTask ----PrintNo:"+taskModel.fiPrintNo);
        if (taskModel.printAtOnce) {

            preparePrint(taskModel);
        }
    }

    public static void preparePrint(PrintTaskDBModel taskModel) {
        LogUtil.logBusiness("TaskDBUtil", "PrintStub receive uri=" + taskModel.uri + "; PrinterName=" + taskModel.fsPrinterName + "; fsReportName=" + taskModel.fsReportName + "； fiPrintNo=" + taskModel.fiPrintNo);
        DinnerPrintProcessor.processPrint(taskModel);
    }

    /**
     * 更新DB里的打印队列,先删除当前PrintNO的任务,然后再更新
     *
     * @param taskDBModel PrintTaskDBModel
     */
    public static void updateTask(final PrintTaskDBModel taskDBModel, ContentValues contentValues) {

        //todo 这里的锁和外面，不能一样


        PrintLock.getSingleton().doLock(taskDBModel.fiPrintNo, taskDBModel.fsHostId, "开始加锁-更新DB里的打印队列,先删除当前PrintNO的任务-updateTask");
        try {
            taskDBModel.update(contentValues, " fiPrintNo=" + taskDBModel.fiPrintNo + " and fsHostId='" + taskDBModel.fsHostId + "'", true);
        } finally {
            PrintLock.getSingleton().unLock(taskDBModel.fiPrintNo, taskDBModel.fsHostId, "开始解除锁-更新DB里的打印队列,先删除当前PrintNO的任务-updateTask");
        }

        if (!ClientBindProcessor.isCurrentHostMain()) {
            try {
                if (contentValues != null) {
                    JSONObject contentValuesHashMap = new JSONObject();
                    for (Map.Entry<String, Object> item : contentValues.valueSet()) {
                        contentValuesHashMap.put(item.getKey(), item.getValue().toString());
                    }
                    LogUtil.logOnlineDebug("--print--打印---PrintReceiptUtil.updatePrintTask--");

                    //todo 改成定时取出未同步的数据
                    PrintReceiptUtil.updatePrintTask(taskDBModel.fiPrintNo, contentValuesHashMap);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        LogUtil.logBusiness("TaskDBUtil", "PrintLoop 打印结果[" + taskDBModel.fiPrintNo + "] " + taskDBModel.fiStatus);
    }

    /**
     * 一定时间内的累计失败次数
     */
    private static int failedTimes = 0;
    /**
     * 上一次失败的时间
     */
    private static long lastFailedTime = 0;

    /**
     * 检查打印任务的重试
     *
     * @param taskDBModel PrintTaskDBModel
     */
    public static void checkRetry(final PrintTaskDBModel taskDBModel) {
//        LogUtil.logBusiness("TaskDBUtil", "PrintLoop 打印进程"+ ProcessUtil.getCurrentProcessName(GlobalCache.getContext()));
        // 云打印机打印中的状态也需要进行重试
        if (taskDBModel.fiStatus == 3 || taskDBModel.fiStatus == 7) {
            //如果距离上次失败时间，已经达到了30分钟，则清零
            if (SystemClock.elapsedRealtime() - lastFailedTime > 1000 * 60 * 30) {
                failedTimes = 0;
            }
            lastFailedTime = SystemClock.elapsedRealtime();
            failedTimes++;
            if (failedTimes > 10) {
                RunTimeLog.addLog(RunTimeLog.SYS_PRINT_FAILED, taskDBModel.fsPrinterName, "", taskDBModel);
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PRINT_S, "1", taskDBModel.fsPrinterName);
                failedTimes = 0;
            }
            checkExpried(taskDBModel);
            //只重试打印任务
            if (taskDBModel.fiTaskType == 1) {
                if (taskDBModel.fiStatus != 8) {
                    pushRetry(taskDBModel);
                } else {
                    addFail(taskDBModel);
                }
            }
        }
    }

    private static void pushRetry(final PrintTaskDBModel task) {
        MCon.c(CPrint.class, null, new SocketThreadCallback<PrinterUpdateStatusResponse>() {
            @Override
            public void callback(SocketResponse<PrinterUpdateStatusResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    //判断是否需要切换到备用打印机
                    if (socketResponse.data.failToSwitchBackp && !TextUtils.isEmpty(socketResponse.data.backUpPrinterName)) {
                        task.fsbakprintername = socketResponse.data.backUpPrinterName;
                        task.is_backup_printer = 1;
                        task.fiRetry += task.fiErrCount;
                        DBSimpleUtil.excuteSql(APPConfig.DB_PRINT, "update tbPrintTask set fiRetry='" + task.fiRetry + "',is_backup_printer='1',fsbakprintername='" + task.fsPrinterName + "' where fiPrintNo='" + task.fiPrintNo + "' and fsHostId='" + task.fsHostId + "'");
                    }
                }
                LogUtil.log("PrintLoop 开始重试[" + task.fiPrintNo + "]");
                DinnerPrintProcessor.processPrint(task, true);
            }
        }).printerUpdateStatusRequest(task.fsPrinterName, true, task.is_backup_printer == 1, false, task.fiStatus, task.fiPrintNo, task.fsHostId);

    }

    /**
     * 打印失败+1
     *
     * @param task PrintTaskDBModel
     */
    private static void addFail(final PrintTaskDBModel task) {
        MCon.c(CPrint.class).printerUpdateStatusRequest(task.fsPrinterName, true, task.is_backup_printer == 1, false, task.fiStatus, task.fiPrintNo, task.fsHostId);
    }

    /**
     * 任务超时时间
     */
    public static final int TIME_OUT_RUNNING = 60 * 12;
    /**
     * 首次打印时，检测的超时时间
     */
    public static final int TIME_OUT_FIRST_RUN = 60 * 40;

    /**
     * 检查打印任务是否已逾期
     *
     * @param temp PrintTaskDBModel
     * @return boolean
     */
    private static boolean checkExpried(PrintTaskDBModel temp) {
        String currentTime = DateUtil.getCurrentTime();

//        String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
//        String expriedMinite = CommonDBUtil.getConfig(DBPrintConfig.TASK_LIMIT_TIME, shopID);
        int tempExpiredSecond = TIME_OUT_RUNNING;
//        if (!TextUtils.isEmpty(expriedMinite)) {
//            tempExpiredSecond = StringUtil.toInt(expriedMinite, 5) * 60;
//        }
        if (BaseConfig.isDEV()) {
            String retry = ClientMetaUtil.getSettingsValueByKey(META.DEV_PRINT_RETRY);
            if (TextUtils.equals("1", retry)) {
                tempExpiredSecond = TIME_OUT_RUNNING;
            } else {
                tempExpiredSecond = 30;
            }
        }
        String createTime = temp.fsCreateTime;
        if (!temp.fsCreateTime.contains("-")) {
            createTime = DateUtil.formartDateStrToTarget(temp.fsCreateTime, DateUtil.DATE_YYYYMMDDHHMMSS, DateUtil.DATE_VISUAL14FORMAT);
        }
        long timePast = DateUtil.compareDate(createTime, currentTime, DateUtil.DATE_VISUAL14FORMAT) / 1000;

        if (timePast > tempExpiredSecond) {
            LogUtil.logBusiness("TaskDBUtil", "PrintLoop 打印结果逾期检测[" + temp.fiPrintNo + "]  已逾期，总耗时" + timePast + "秒");

            temp.fiStatus = 8;
            // 设置为已逾期
            DBSimpleUtil.excuteSql(APPConfig.DB_PRINT, "update tbPrintTask set fiStatus='8',fsFinishTime='" + currentTime + "' where fiPrintNo='" + temp.fiPrintNo + "' and fsHostId='" + temp.fsHostId + "'");
            return true;
        }
        return false;
    }

}
