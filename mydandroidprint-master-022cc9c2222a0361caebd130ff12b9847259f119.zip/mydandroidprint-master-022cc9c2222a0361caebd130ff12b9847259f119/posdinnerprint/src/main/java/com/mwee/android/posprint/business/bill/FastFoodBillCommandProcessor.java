package com.mwee.android.posprint.business.bill;

import android.graphics.Bitmap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.image.PictureManager;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.connect.business.print.SunMiV1PrinterInfo;
import com.mwee.android.pos.util.FormatUtil;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.R;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.business.Util;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;


/**
 * BillCommandProcessor
 * Created by virgil on 16/8/9.
 */
@SuppressWarnings("unused")
public class FastFoodBillCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "fastFoodBill";

    @DrivenMethod(uri = DRIVER_TAG + "/orderbill")
    public static PrintResult procssBill(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        JSONObject shop = JsonUtil.getInfo(ob, "Shop", JSONObject.class);
          /*添加logo*/
        String logoUrl = JsonUtil.getInfo(shop, "fslogourl", String.class);
        if (!TextUtils.isEmpty(logoUrl) && !SunMiV1PrinterInfo.isSunMiV1InnerPrinter(config)) {
            Bitmap bitmap = PictureManager.getBitmapByUrl(logoUrl);
            if (bitmap != null) {
                billPrint.addLogo(bitmap);
            }
        }
        billPrint.addTitle(JsonUtil.getInfo(shop, "fsShopName", String.class));
        billPrint.addLine();
        String titleRemind = taskModel.titleRemind;
        if (TextUtils.isEmpty(titleRemind)) {
            titleRemind = "";
        }
        billPrint.addTitle("结账单" + titleRemind);
        billPrint.addLine();
        JSONObject sell = JsonUtil.getInfo(ob, "Sell", JSONObject.class);

        String mealNumber = JsonUtil.getInfo(ob, "fsMealNumber", String.class);
        if (TextUtils.isEmpty(mealNumber)) {
            billPrint.addText("单号:" + JsonUtil.getInfo(sell, "fssellno", String.class) + "\n");
        } else {
            billPrint.addOrderNoTableNo(JsonUtil.getInfo(sell, "fssellno", String.class) + "", "牌号：", mealNumber);
        }
        billPrint.addLeftWithRight("日期:" + JsonUtil.getInfo(sell, "fsselldate", String.class), "班别:" + JsonUtil.getInfo(sell, "shiftname", String.class));
        billPrint.addLeftWithRight("开单:" + JsonUtil.getInfo(sell, "fsCreateUserName", String.class), "人数:" + JsonUtil.getInfo(sell, "fiCustSum", String.class));

        billPrint.addLeftWithRight("收银:" + JsonUtil.getInfo(sell, "cashiername", String.class), "结账时间:" + JsonUtil.getInfo(sell, "fscheckendtime", String.class));

        String memberCardNo = JsonUtil.getInfo(sell, "fsCardNo", String.class);
        if(!TextUtils.isEmpty(memberCardNo)){
            billPrint.addLeftWithRight("会员号:" + memberCardNo, "");
        }

        billPrint.addHortionaDoublelLine();
        billPrint.addContentListHeader(
                GlobalCache.getContext().getString(R.string.print_names),
                GlobalCache.getContext().getResources().getString(R.string.print_sprice),
                GlobalCache.getContext().getResources().getString(R.string.print_qty),
                GlobalCache.getContext().getResources().getString(R.string.print_total));// ("Item Name", "QTY");
        JSONArray list = JsonUtil.getInfo(ob, "sellorder", JSONArray.class);
        for (int i = 0; i < list.size(); i++) {
            JSONObject item = list.getJSONObject(i);
            Boolean isMenuCls = JsonUtil.getInfo(item, "isMenuCls", Boolean.class);
            if (isMenuCls != null && isMenuCls) {
                billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class),
                        "", "", "", 1);
            } else {
                billPrint.addOrderItem(JsonUtil.getInfo(item, "fsitemname", String.class),
                        JsonUtil.getInfo(item, "fdsettleprice", String.class),
                        JsonUtil.getInfo(item, "qty", String.class),
                        JsonUtil.getInfo(item, "fdsaleamt", String.class),
                        1);
            }
            //配料不打印要求
            if (!TextUtils.equals("4", JsonUtil.getInfo(item, "fiOrderItemKind", String.class))) {
                String note = JsonUtil.getInfo(item, "fsNote", String.class);
                if (!TextUtils.isEmpty(note)) {
                    billPrint.addOrderModifier2(note, 1);
                }
            }
            // //add modifier print
            JSONArray slit = JsonUtil.getInfo(item, "SLIT", JSONArray.class);
            if (slit != null && slit.size() > 0) {
                for (int m = 0; m < slit.size(); m++) {
                    JSONObject itemS = slit.getJSONObject(m);
                    billPrint.addOrderModifier("-" + JsonUtil.getInfo(itemS, "fsitemname", String.class) + "*" + JsonUtil.getInfo(itemS, "qty", String.class), 1);
                }
            }
        }
        billPrint.addHortionalLine();
        JSONObject sub = JsonUtil.getInfo(ob, "Sub", JSONObject.class);
        billPrint.addSub("消费合计", JsonUtil.getInfo(sub, "qty", String.class), JsonUtil.getInfo(sub, "total", String.class));
//        BigDecimal fdSaleRoundAmt=JsonUtil.getInfo(sell,"fdSaleRoundAmt",BigDecimal.class);
//        if (fdSaleRoundAmt != null && fdSaleRoundAmt.compareTo(BigDecimal.ZERO) > 0) {
//            billPrint.addSub("消费合计(圆整)", "", fdSaleRoundAmt.toPlainString());
//        }

        billPrint.addSub("折扣", "", JsonUtil.getInfo(ob, "fddiscountamt", String.class));
        //圆整
        String fdRoundAmt = JsonUtil.getInfo(sell, "fdroundamt", String.class);
        if (!TextUtils.isEmpty(fdRoundAmt) && !TextUtils.equals(fdRoundAmt, "0")) {
            billPrint.addSub("圆整", "",  fdRoundAmt);
        }

//        billPrint.addSub("折扣", "", JsonUtil.getInfo(sell, "fddiscountamt", String.class));
        String serviceFee = JsonUtil.getInfo(sell, "fdServiceAmt", String.class);

        if (!TextUtils.isEmpty(serviceFee) && !serviceFee.startsWith("0")) {
            billPrint.addSub("服务费", "", serviceFee);
        }
        billPrint.addSub("应收", "", JsonUtil.getInfo(sell, "fdExpAmt", String.class));
        billPrint.addHortionalLine();

        JSONArray statisticsDiscount = JsonUtil.getInfo(ob, "statisticsDiscount", JSONArray.class);
        if (statisticsDiscount != null && statisticsDiscount.size() > 0) {
            billPrint.addText("折扣明细");
            billPrint.addBlankLine();
            BigDecimal sumDiscountAmt = BigDecimal.ZERO;
            for (int i = 0; i < statisticsDiscount.size(); i++) {
                JSONObject item = statisticsDiscount.getJSONObject(i);
                BigDecimal discountamt = JsonUtil.getInfo(item, "discountamt", BigDecimal.class);
                sumDiscountAmt = sumDiscountAmt.add(discountamt);
                billPrint.addText(TextUtils.concat(
                        JsonUtil.getInfo(item, "fsDiscountName", String.class), ":", String.format("%s", discountamt.toPlainString())
                ).toString());
                billPrint.addBlankLine();
            }
            BigDecimal fdDiscountRoundAmt = JsonUtil.getInfo(sell, "fdDiscountRoundAmt", BigDecimal.class);
            if (fdDiscountRoundAmt != null && fdDiscountRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
                billPrint.addText(String.format("合计:%s(圆整:" + fdDiscountRoundAmt.toPlainString() + ")", JsonUtil.getInfo(sell, "fddiscountamt", String.class)));
            } else {
                billPrint.addText(String.format("合计:%s", JsonUtil.getInfo(sell, "fddiscountamt", String.class)));
            }
            billPrint.addBlankLine();
            billPrint.addHortionalLine();
        }

        JSONArray payList = JsonUtil.getInfo(ob, "SellReceive", JSONArray.class);
        for (int i = 0; i < payList.size(); i++) {
            JSONObject item = payList.getJSONObject(i);
            String payName = JsonUtil.getInfo(item, "paymentname", String.class);
            String note = JsonUtil.getInfo(item, "fsNote", String.class);
            //打印备注
            if (!TextUtils.isEmpty(note)) {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "(" + note + ") \n");
            } else {
                billPrint.addText(payName + JsonUtil.getString(item, "fdpaymoney") + "\n");
            }
        }
//        for (int i = 0; i < payList.size(); i++) {
//            JSONObject item = payList.getJSONObject(i);
//            String memberCardNo = JsonUtil.getInfo(item, "fsbackup0", String.class);
//            String memberScoreCostStr = JsonUtil.getInfo(item, "fsbackup2", String.class);
//            String payTypeID = JsonUtil.getInfo(item, "fspaymentid", String.class);
//            String payTypeGroupID = JsonUtil.getInfo(item, "fspaymentid", String.class);
//            String payName = JsonUtil.getInfo(item, "paymentname", String.class);
//            String cardInfo = "(卡号:" + FormatUtil.formatMemberCardNo(memberCardNo) + ")";
//            if (!TextUtils.isEmpty(memberCardNo)) {
//                if (TextUtils.equals("95002", payTypeID)) {
//                    if (TextUtils.isEmpty(memberScoreCostStr) || TextUtils.equals("0", memberScoreCostStr)) {
//                        billPrint.addText(payName + ":抵扣" + JsonUtil.getInfo(item, "fdpaymoney", String.class) + "元" + cardInfo + "\n");
//                    } else {
//                        billPrint.addText(payName + ":使用" + memberScoreCostStr + "积分,抵扣" + JsonUtil.getInfo(item, "fdpaymoney", String.class) + "元" + cardInfo + "\n");
//                    }
//                } else if (TextUtils.equals("95001", payTypeID)) {
//                    billPrint.addText(payName + ":" + JsonUtil.getInfo(item, "fdpaymoney", String.class) + cardInfo + "\n");
//                } else {
//                    billPrint.addText(payName + ":" + JsonUtil.getInfo(item, "fdpaymoney", String.class) + cardInfo + "\n");
//                }
//            } else {
//                BigDecimal payAmount = JsonUtil.getInfo(item, "fdpaymoney", BigDecimal.class);
//                BigDecimal fdReceMoney = JsonUtil.getInfo(item, "fdReceMoney", BigDecimal.class);
//                String note = JsonUtil.getInfo(item, "fsNote", String.class);
//                BigDecimal changeAmount = payAmount.subtract(fdReceMoney);
//                //打印备注
//                if (!TextUtils.isEmpty(note)) {
//                    billPrint.addText(payName + ":" + payAmount.toPlainString() + "(" + note + ") \n");
//                } else {
//                    billPrint.addText(payName + ":" + payAmount.toPlainString() + "\n");
//                }
//                if (changeAmount.compareTo(BigDecimal.ZERO) > 0) {
//                    billPrint.addText("找零" + ":" + changeAmount.toPlainString() + "\n");
//                }
//            }
//        }
        //添加会员储值，积分信息
        if (ob.containsKey("memberInfo")) {
            JSONObject memberInfo = JsonUtil.getInfo(ob, "memberInfo", JSONObject.class);
            //储值
            BigDecimal amount = memberInfo.getBigDecimal("amount");
            //积分
            int score = memberInfo.getInteger("score");
            billPrint.addText("会员卡可用余额：" + amount.toPlainString() + "\n");
            billPrint.addText("会员积分：" + score + "\n");

        }
        billPrint.addHortionaDoublelLine();
        billPrint.addText("备注:" + JsonUtil.getInfo(sell, "fsnote", String.class) + "\n");
        //是否开发票
        int fiIsInvoice = JsonUtil.getInfo(sell, "fiIsInvoice", Integer.class);
        if (fiIsInvoice != 0) {
            billPrint.addHortionalLine();
            billPrint.addText("客户要求开具发票,信息如下:\n");
            String fsInvoiceTitle = JsonUtil.getInfo(sell, "fsInvoiceTitle", String.class);//抬头
            String fsInvoiceCls = JsonUtil.getInfo(sell, "fsInvoiceCls", String.class);//开票类型
            billPrint.addText("发票类型:" + fsInvoiceCls + "\n");
            billPrint.addText("发票抬头:" + fsInvoiceTitle + "\n");
            String fsdutyparagraph = JsonUtil.getInfo(sell, "fsdutyparagraph", String.class);
            if (!TextUtils.isEmpty(fsdutyparagraph)) {
                billPrint.addText("公司税号:" + fsdutyparagraph + "\n");
            }
            billPrint.addHortionalLine();
            billPrint.addBlankLine();
        }

        // 开具电子发票二维码打印
        String eInvoiceQR = JsonUtil.getInfo(ob, "eInvoiceQR", String.class);
        if (!TextUtils.isEmpty(eInvoiceQR)) {
            String title = JsonUtil.getInfo(ob, "eInvoiceQRTitle", String.class);
            if (!TextUtils.isEmpty(title)) {
                billPrint.addCenterText(title + "\n", 1);
            }
            billPrint.addQRcode(eInvoiceQR, PrintDataItem.ALIGN_CENTRE);

            String note = JsonUtil.getInfo(ob, "eInvoiceQRNote", String.class);
            if (!TextUtils.isEmpty(note)) {
                billPrint.addCenterText(note + "\n", 1);
            }
            billPrint.addBlankLine();
        }

        billPrint.addLeftWithRight(Util.getString(R.string.print_user, JsonUtil.getString(ob, "printUserName")), Util.getString(R.string.print_times, JsonUtil.getString(sell, "fiPrintTimes")));
        billPrint.addLeftWithRight(Util.getString(R.string.print_time, DateUtil.getCurrentTime()), Util.getString(R.string.print_no, taskModel.fiPrintNo));

        billPrint.addBlankLine(1);
        billPrint.addCenterText(JsonUtil.getInfo(ob, "printTailMessage", String.class) + "" + "\n", 1);

        String tail = JsonUtil.getString(ob, "reportTail");
        if (!TextUtils.isEmpty(tail)) {
            billPrint.addCenterText(tail + "\n");
            billPrint.addCenterText(JsonUtil.getString(ob, "mwPhone") + "\n");
        }


        if (TextUtils.equals(JsonUtil.getInfo(ob, "printBillCut", String.class), "0")) {//结账单切单设置
            billPrint.addCut();
        }

        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

}
