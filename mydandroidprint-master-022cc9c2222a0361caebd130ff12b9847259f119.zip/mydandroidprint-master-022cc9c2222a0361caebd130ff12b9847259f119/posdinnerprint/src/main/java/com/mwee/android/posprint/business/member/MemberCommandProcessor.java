package com.mwee.android.posprint.business.member;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintBillBuilder;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.tools.DateUtil;


/**
 * 会员打印的处理
 * Created by virgil on 16/8/18.
 */
@SuppressWarnings("unused")
public class MemberCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "member";

    @DrivenMethod(uri = DRIVER_TAG + "/privilege")
    public static PrintResult a(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addText("会员卡号:" + JsonUtil.getInfo(ob, "cardno", String.class) + "\n");
        billPrint.addText("特权名称:" + JsonUtil.getInfo(ob, "privilege", String.class) + "\n");
        billPrint.addText("权益内容:" + JsonUtil.getInfo(ob, "privilegedesc", String.class) + "\n");
        billPrint.addText("打印时间:" + DateUtil.getCurrentTime() + "\n");
        billPrint.addBlankLine(1);
        billPrint.addCenterText("本系统由“美味不用等”提供，技术支持或合作洽谈请拨打热线电话：4008 166 477\n");
        billPrint.addText("\n");

        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @DrivenMethod(uri = DRIVER_TAG + "/charge")
    public static PrintResult b(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBillBuilder billPrint = new PrintBillBuilder(config);
        billPrint.addTitle("会员充值小票");
        billPrint.addHortionaDoublelLine();
        billPrint.addText("店名：" + JsonUtil.getInfo(ob, "shop", String.class) + "\n");
        billPrint.addText("会员姓名：" + JsonUtil.getInfo(ob, "memberName", String.class) + "\n");
        billPrint.addText("会员号：" + JsonUtil.getInfo(ob, "cardno", String.class) + "\n");
        billPrint.addBlankLine();
        billPrint.addText("支付方式：" + JsonUtil.getInfo(ob, "payType", String.class) + "\n");
        billPrint.addText("充值详情：" + JsonUtil.getInfo(ob, "content", String.class) + "\n");
        billPrint.addText("订单号：" + JsonUtil.getInfo(ob, "orderno", String.class) + "\n");
        billPrint.addText("充值时间：" + JsonUtil.getInfo(ob, "chargetime", String.class) + "\n");
//        billPrint.addText("充值金额:" + JsonUtil.getInfo(ob, "chargeamount", String.class) + "\n");
        billPrint.addHortionaDoublelLine();
        billPrint.addLeftWithRight("打印时间：" + JsonUtil.getInfo(ob, "printTime", String.class), "印号：" + JsonUtil.getInfo(ob, "fiPrintNo", String.class));
        billPrint.addBlankLine();
        billPrint.addCenterText("本系统由“美味不用等”提供，技术支持或合作洽谈请拨打热线电话：4008 166 477\n");
        billPrint.addText("\n");
        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);

    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
