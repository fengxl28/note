package com.mwee.android.posprint.device;

import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.tools.BaseToastUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * 打印机状态轮询
 * Created by virgil on 2017/4/6.
 */

public class PrinterCheckLoop {
    private static final int MSG_STOP = 9999;
    private static final int MSG_CHECK_THREAD = 9998;

    /**
     * 打印机状态轮询的线程的Handler
     */
    private static Handler handler;
    /**
     * 打印机状态轮询的间隔
     */
    private static long INTERVAL = 1000 * 60 * 5;
    /**
     * 检测打印线程的间隔
     */
    private static long INTERVAL_CHECK_THREAD = 1000 * 60 * 20;

    /**
     * 打印机状态轮询线程的Runnable
     */
    private static Runnable keepAliveRunnable = new Runnable() {
        @Override
        public void run() {
            //只有主站点才需要进行打印机的状态检测，如果还没有激活，则继续轮询
            if (ClientBindProcessor.isActived()) {
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    return;
                }
            } else {
                handler.postDelayed(this, INTERVAL * 2);
                return;
            }
            HashMap<String, PrinterConfig> allPrinter = new HashMap<>(DeviceManager.getInstance().printerMap);
            for (Map.Entry<String, PrinterConfig> temp : allPrinter.entrySet()) {
                //只轮询网口打印机
                if (temp.getValue().type != PrinterType.NET) {
                    continue;
                }
                synchronized (temp.getValue()) {
                    try {
                        temp.getValue().connect();
                    } catch (Exception e) {
                        e.printStackTrace();
                        updatePrinterStatus(temp.getKey(), 10);
                        //将打印机异常消息抛到应用层
                        BaseToastUtil.showToast("打印机[" + temp.getKey() + "] 已断开连接");
                        continue;
                    } finally {
                        temp.getValue().closeConnect();
                    }
                }
                updatePrinterStatus(temp.getKey(), 1);
            }
            MCon.c(CPrint.class).notifyAllRefreshPrinterStatus();
            handler.postDelayed(keepAliveRunnable, INTERVAL);
        }
    };

    private static void updatePrinterStatus(String printerName, int status) {
        MCon.c(CPrint.class).printerStatusUpdate(printerName, status);
    }

    public static void doDelayTask(Runnable runnable, long delay) {
        if (runnable == null) {
            return;
        }
        handler.postDelayed(runnable, delay);
    }

    /**
     * 打印进程的一个轮询器
     */
    public static void initPrinterCheckLoop() {
        //只有主站点才需要进行轮询，如果还没有激活，则继续轮询

        HandlerThread keepHttp = new HandlerThread("MydLoopPrinterStatus") {
            @Override
            protected void onLooperPrepared() {
                super.onLooperPrepared();
                handler = new Handler(Looper.myLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        switch (msg.what) {
                            case MSG_STOP:
                                keepAliveRunnable = null;
                                handler = null;
                                try {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                                        getLooper().quitSafely();
                                    } else {
                                        getLooper().quit();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            case MSG_CHECK_THREAD:
                                DinnerPrintProcessor.checkThread();
                                handler.sendEmptyMessageDelayed(MSG_CHECK_THREAD, INTERVAL_CHECK_THREAD);
                                break;
                            default:
                                break;
                        }
                    }
                };
                handler.sendEmptyMessageDelayed(MSG_CHECK_THREAD, INTERVAL_CHECK_THREAD);
                if (ClientBindProcessor.isActived() && !ClientBindProcessor.isCurrentHostMain()) {
                    return;
                }
                handler.postDelayed(keepAliveRunnable, INTERVAL);

            }
        };
        keepHttp.start();
    }

}
