package com.mwee.android.posprint.task;

import android.content.ContentValues;
import android.content.Intent;
import android.support.annotation.WorkerThread;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.client.ClientConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterCommand;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.posprint.device.DeviceManager;
import com.mwee.android.posprint.queue.PrintLock;
import com.mwee.android.posprint.queue.TaskDBUtil;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.printer.P433Printer.P433PrinterConfig;
import com.mwee.android.print.processor.PrintDataItem;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintResultCode;
import com.mwee.android.print.processor.PrinterManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * PrintdProcessor
 * Created by virgil on 16/7/12.
 */
public class DinnerPrintProcessor {


    /**
     * 打印机的线程Map，key为打印机的Uniq
     */
    private static ArrayMap<String, PrintTaskThread> taskManager = new ArrayMap<>();

    /**
     * 将打印数据提交到打印机
     *
     * @param data   ArrayList<PrintDataItem>
     * @param config PrinterConfig
     * @return PrintResult
     */
    public static PrintResult submitToPrinter(PrintTaskDBModel taskModel, List<PrintDataItem> data, PrinterConfig config) {
        PrintResult result = null;
        boolean isTsc = TextUtils.equals(PrinterCommand.TSC, config.commandType);
        if ((isTsc
                && !TextUtils.equals(taskModel.uri, "order/makesingle")
                && !TextUtils.equals(taskModel.uri, "order/makesingleTSC")
                && !TextUtils.equals(taskModel.uri, "fastFoodorder/makesingle")
                && !TextUtils.equals(taskModel.uri, "fastFoodorder/makesingleTSC")
                && !TextUtils.equals(taskModel.uri, "device/openmoneybox"))
                ||
                (!isTsc &&
                        (TextUtils.equals(taskModel.uri, "fastFoodorder/makesingleTSC") || TextUtils.equals(taskModel
                                .uri, "order/makesingleTSC")))) {
            LogUtil.log("非制作单、开钱箱不使用标签打印机," + taskModel.fsReportName);
            //或者切换到备用打印机，备用打印机并不是标签打印机
            ContentValues values = new ContentValues();
            values.put("fiStatus", 8);
            values.put("fsFinishTime", DateUtil.getCurrentTime());
            values.put("fsRemark", "非制作单不使用标签打印机");
            taskModel.fiStatus = 8;
            TaskDBUtil.updateTask(taskModel, values);
            return result;
        }
        if (data.isEmpty()) {
            ActionLog.addLog("打印数据为空", ActionLog.PR_PRINT_UNLL);
        }
        String currentTime = DateUtil.getCurrentTime();
        long timePast = DateUtil.compareDate(taskModel.fsCreateTime, currentTime, DateUtil.DATE_VISUAL14FORMAT) / 1000;

        //如果不是重打，且已超时，则任务直接设置为超时
        if (taskModel.manaualReprint != 1 && timePast > TaskDBUtil.TIME_OUT_FIRST_RUN) {
            ContentValues values = new ContentValues();
            values.put("fiStatus", 8);
            values.put("fsFinishTime", currentTime);
            TaskDBUtil.updateTask(taskModel, values);
        } else {
            LogUtil.logOnlineDebug("--order--print--submitToPrinter--start--printNo:"+taskModel.fiPrintNo+"----PrinterName:"+taskModel.fsPrinterName);

            config = optPrinterConfig(taskModel);
            if (config == null) {
                result = new PrintResult();
                result.result = PrintResultCode.CONFIG_ERROR;
                processPrintResult(result, taskModel);
            } else {
                if (checkSunMiT1miniError(taskModel)) {
                    result = new PrintResult();
                    result.result = PrintResultCode.CONFIG_ERROR;
                    processPrintResult(result, taskModel);
                } else {
                    String sql = "select fiStatus from tbPrintTask where fiPrintNo='" + taskModel.fiPrintNo + "' and " +
                            "fsHostId='" + taskModel.fsHostId + "'";
                    String status = "";

                    // todo 这个地方还是需要控制的

                    //todo 一个 order--print--submitToPrinter--start 对应了两个 开始加锁---submitToPrinter
                    PrintLock.getSingleton().doLock(taskModel.fiPrintNo, taskModel.fsHostId, "----开始加锁----submitToPrinter--queryStringStatus----printNo:"+ taskModel.fiPrintNo+"----PrinterName:"+taskModel.fsPrinterName);
                    try {
                        status = DBSimpleUtil.queryString(APPConfig.DB_PRINT, sql);
                    } finally {
                        PrintLock.getSingleton().unLock(taskModel.fiPrintNo, taskModel.fsHostId, "开始解锁---submitToPrinter--queryStringStatus----printNo:"+ taskModel.fiPrintNo+"----PrinterName:"+taskModel.fsPrinterName);
                    }

                    if (TextUtils.equals("4", status) || TextUtils.equals("8", status)) {
                        result = new PrintResult();
                        result.result = PrintResultCode.SUCCESS;
                        return result;
                    }

                    PrinterManager printer1 = new PrinterManager(config, isTsc);
                    printer1.setData(data);
                    LogUtil.logOnlineDebug("PrintLoop 发送到打印机[" + taskModel.fiPrintNo + "]");
                    try {
                        // 一般情况下使用印号作为唯一标识
                        StringBuilder seq = new StringBuilder();
                        if (!TextUtils.isEmpty(taskModel.seq)) {
                            seq.append(taskModel.seq);
                        } else {
                            seq.append(taskModel.fiPrintNo);
                            // 如果是手动重打，避免服务端去重,需要额外拼接时间
                            if (taskModel.manaualReprint == 1) {
                                seq.append("_");
                                seq.append(DateUtil.getCurrentDateTime("ssSSS"));
                            }
                        }
                        taskModel.seq = seq.toString();
                        result = printer1.start(seq.toString());
                    } catch (Exception e) {
                        result = new PrintResult();
                        result.result = PrintResultCode.PRINT_EXCEPTION;
                        result.addTrace(e);
                    } catch (Error e) {
                        result = new PrintResult();
                        result.result = PrintResultCode.PRINT_EXCEPTION;
                        result.addTrace(e);
                    }
                    if (result != null && result.trace != null) {
                        LogUtil.logError("打印异常", result.trace);
                        RunTimeLog.addNowLog(RunTimeLog.PRINT_TASK_EXCEP, "", result.trace);
                    }

                    LogUtil.logOnlineDebug("--order--print--submitToPrinter--end--");
                    processPrintResult(result, taskModel);
                }
            }
        }

        if (taskModel.fiPrintCount > 0) {
            //原有433打印的逻辑，暂时保持不动
            if (config instanceof P433PrinterConfig) {
                taskModel.appendRetry();
                LogUtil.logBusiness("DinnerPrintProcessor add reprint sign, fiPrintCount = [" + taskModel.fiPrintCount + "] fiPrintNo = [" + taskModel.fiPrintNo + "]");
            }
        }

        TaskDBUtil.checkRetry(taskModel);

        return result;
    }

    /**
     * 处理打印任务的结果
     *
     * @param result    PrintResult
     * @param taskModel PrintTaskDBModel
     */
    static void processPrintResult(PrintResult result, PrintTaskDBModel taskModel) {
        ContentValues values = new ContentValues();

        taskModel.fiPrintCount++;
        values.put("fiPrintCount", taskModel.fiPrintCount);
        if (result != null && result.result == PrintResultCode.SUCCESS) {
            taskModel.fiStatus = 4;
            taskModel.fsFinishTime = DateUtil.getCurrentTime();
            values.put("fiStatus", 4);
            values.put("fsFinishTime", DateUtil.getCurrentTime());
        } else if (result != null && result.result == PrintResultCode.PRINTED) {
            // 云打印机，打印中和打印失败同样处理
            taskModel.fiErrCount++;
            taskModel.fiStatus = 7;
            values.put("fiStatus", 7);
            values.put("fiErrCount", taskModel.fiErrCount);
            if (taskModel.fiErrCount == taskModel.fiRetry) {
                values.put("fsFinishTime", DateUtil.getCurrentTime());
            }
        } else {
            //加了 GS R n 之后收到反馈错误结果，就增加重打标记，这里添加重打标记会重试逻辑打印出来
            if (result != null && result.result == PrintResultCode.PRINTER_CHECK_TIME_OUT) {
                taskModel.appendRetry();
                LogUtil.logBusiness("DinnerPrintProcessor add reprint sign because PRINTER_CHECK_TIME_OUT, fiPrintCount = [" + taskModel.fiPrintCount + "] fiPrintNo = [" + taskModel.fiPrintNo + "]");
            }

            taskModel.fiErrCount++;
            taskModel.fiStatus = 3;
            values.put("fiStatus", 3);
            values.put("fiErrCount", taskModel.fiErrCount);
            if (taskModel.fiErrCount == taskModel.fiRetry) {
                values.put("fsFinishTime", DateUtil.getCurrentTime());
            }
        }
        //有些打印状态没有错误文案，根据result生成文案
        if (result != null && TextUtils.isEmpty(result.errorMsg)) {
            result.buildMsg();
        }
        try {
            if (taskModel.fiStatus == 4 && APPConfig.isCasiher()) {
                ToastUtil.showToast("打印成功" + "[" + taskModel.fsPrinterName + "]");
            }
            if (result != null && result.result != PrintResultCode.NO_DATA && !TextUtils.isEmpty(result.errorMsg)) {
                if (APPConfig.isCasiher()) {
                    if (result.result == PrintResultCode.PRINTED) {
                        ToastUtil.showToast("[" + taskModel.fsPrinterName + "]:" + "打印成功");
                    } else {
                        ToastUtil.showToast("[" + taskModel.fsPrinterName + "]:" + result.errorMsg);
                    }
                }
                RunTimeLog.addTraceLog(RunTimeLog.PRINT_FAILED, "打印失败" + "[" + taskModel.fsPrinterName + "]:" + result.errorMsg, result, taskModel);
                //不用广播发送数据，采用AIDL
                if (ClientConnector.getInstance().isServerConnected()) {
                    ClientConnector.getInstance().printError(taskModel.fsPrinterName + ":" + result.errorMsg, result.result);
                } else {
                    if (!APPConfig.isCasiher()) {
                        ToastUtil.showToast("[" + taskModel.fsPrinterName + "]:" + result.errorMsg);
                    }
                    Intent intent = new Intent("com.mwee.android.pos.print.fail.receiver");
                    intent.setPackage(GlobalCache.getContext().getPackageName());
                    GlobalCache.getContext().sendBroadcast(intent);
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }

        PrintTaskDetailModel detail = new PrintTaskDetailModel();
        detail.printNumber = taskModel.fiPrintCount;
        detail.status = taskModel.fiStatus;
        detail.time = DateUtil.getCurrentTime();
        detail.errorMsg = result == null ? "" : result.errorMsg;

        //加了 GS R n 之后收到反馈错误结果，就增加重打标记，数据存储到数据库，避免重启后没有这个标记
        if (result != null && result.result == PrintResultCode.PRINTER_CHECK_TIME_OUT) {
            detail.nextNeedReprint = true;
        }
        List<PrintTaskDetailModel> array = JSON.parseArray(taskModel.fsTaskDetail, PrintTaskDetailModel.class);
        if (array == null) {
            array = new ArrayList<>();
        }
        array.add(detail);
        taskModel.fsTaskDetail = JSON.toJSONString(array);
        values.put("fsTaskDetail", taskModel.fsTaskDetail);

        TaskDBUtil.updateTask(taskModel, values);
//        Thread.currentThread().
    }

    /**
     * 根据打印机名称获取打印机
     *
     * @return PrinterDBModel
     */
    private static PrinterDBModel getPrinterByPrinterName(String printerName) {
        String sql = "select * from tbPrinter where fsPrinterName='" + printerName + "' and fiStatus = '1'";
        return DBSimpleUtil.query(APPConfig.DB_CLIENT, sql, PrinterDBModel.class);
    }

    public static PrinterConfig getPrinterConfig(String printerName) {
        PrinterConfig config = null;
        synchronized (DeviceManager.getInstance()) {
            config = DeviceManager.getInstance().getPrinterConfig(printerName);
            if (config == null) {
                PrinterDBModel printer = getPrinterByPrinterName(printerName);
                if (printer == null) {
                    RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "根据打印机名称获取打印机失败", printerName);
                    return null;
                }
                DeviceManager.getInstance().registPrinter(printer);
            }
            config = DeviceManager.getInstance().getPrinterConfig(printerName);
        }
        return config;
    }


    private static PrinterConfig optPrinterConfig(PrintTaskDBModel taskModel) {
        PrinterConfig config = null;
        synchronized (DeviceManager.getInstance()) {
            String printerName = taskModel.fsPrinterName;
            if (taskModel.is_backup_printer == 1 && !TextUtils.isEmpty(taskModel.fsbakprintername)) {
                printerName = taskModel.fsbakprintername;
            }

            config = DeviceManager.getInstance().getPrinterConfig(printerName);
            if (config == null) {
                PrinterDBModel printer = getPrinterByPrinterName(printerName);
                if (printer == null) {
                    RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "根据打印机名称获取打印机失败", printerName);
                    return null;
                }
                DeviceManager.getInstance().registPrinter(printer);
            }
            config = DeviceManager.getInstance().getPrinterConfig(printerName);
        }
        return config;
    }

    @WorkerThread
    public static void processPrint(PrintTaskDBModel taskModel) {
        processPrint(taskModel, false);
    }

    /**
     * 处理打印任务的入口。
     * 首先，会去拿打印任务对应的打印机实例，如果拿取不到，则有可能是打印机的配置被配置的人员进行了修改，此时，打印任务无法继续，直接将任务设置为"配置错误"，并不再继续。
     * 然后，检测打印机对应的线程的工作状态。
     * 最后，打印任务提交给打印机线程的队列。
     *
     * @param taskModel PrintTaskDBModel
     * @param retry     boolean | 是否是自动重试的任务
     */
    @WorkerThread
    public static void processPrint(PrintTaskDBModel taskModel, boolean retry) {
        PrinterConfig config = optPrinterConfig(taskModel);
        if (config == null) {
            PrintResult result = new PrintResult();
            result.result = PrintResultCode.CONFIG_ERROR;
            processPrintResult(result, taskModel);
            return;
        }

        LogUtil.logOnlineDebug("--order--print---processPrint------------printNo:"+taskModel.fiPrintNo);

        //判断是否已经有准备好的线程，如果没有，则新建一个。
        PrintTaskThread worker = taskManager.get(config.getUniq());
        //todo
        if (worker == null || !worker.isAlive() || worker.isInterrupted() || worker.manualFinished()) {
            synchronized (DeviceManager.getInstance()) {
                LogUtil.logOnlineDebug("--order--print---processPrint------------printNo:"+taskModel.fiPrintNo);
                worker = taskManager.get(config.getUniq());
                if (worker == null || !worker.isAlive() || worker.isInterrupted() || worker.manualFinished()) {
                    worker = new PrintTaskThread(config.getUniq());
                    taskManager.put(config.getUniq(), worker);
                    worker.start();
                    worker.setPrinterConfig(config);
                }
            }
        }

        LogUtil.logOnlineDebug("--order--print---processPrint------------printNo:"+taskModel.fiPrintNo);

        try {
            if (retry) {
                worker.pushRetryTask(taskModel);
            } else {
                worker.pushTask(taskModel);
            }
            LogUtil.logOnlineDebug("--order--print---processPrint------------printNo:"+taskModel.fiPrintNo);
        } catch (InterruptedException e) {
            LogUtil.logError(e);
        }

    }


    /**
     * 检测打印机线程池里废弃的线程并移除
     */
    public static void checkThread() {
        ArrayMap<String, PrintTaskThread> tempTaskManager = new ArrayMap<>(taskManager);
        synchronized (DeviceManager.getInstance()) {
            for (Map.Entry<String, PrintTaskThread> temp : tempTaskManager.entrySet()) {
                PrintTaskThread worker = temp.getValue();
                if (worker == null || !worker.isAlive() || worker.isInterrupted() || worker.manualFinished()) {
                    taskManager.remove(temp.getKey());
                }
            }
        }
    }

    /**
     * 兼容SUNMI  T1mini 蓝牙打印机
     * <p>
     * 如果是商米TIMINI蓝牙打印机 并且打印机异常(开盖 缺纸异常 关盖子异常) 那么需要拦截打印任务 走重试流程
     *
     * @param taskModel
     */
    private static boolean checkSunMiT1miniError(PrintTaskDBModel taskModel) {

        String printerName = taskModel.fsPrinterName;
        if (taskModel.is_backup_printer == 1 && !TextUtils.isEmpty(taskModel.fsbakprintername)) {
            printerName = taskModel.fsbakprintername;
        }
        synchronized (DeviceManager.getInstance()) {
            PrinterDBModel printerDBModel = getPrinterByPrinterName(printerName);
            if (printerDBModel == null) {
                return false;
            }
            //String brand = android.os.Build.BRAND;//品牌
            String modelName = android.os.Build.MODEL;//型号
            //LogUtil.log("sunmi -->" + brand);
            //LogUtil.log("innerprinter Bluetooth 蓝牙打印机开盖或者其他异常--innerPrinterException-->" + innerPrinterException + "---->" + taskModel.fiPrintNo);
            if (TextUtils.equals("T1mini", modelName) && printerDBModel.fiPrinterCls == PrinterType.BLUETOOTH &&
                    TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_INNER_SUNMI, "0"), "1")) {//
                //LogUtil.log("innerprinter Bluetooth PrinterType.BLUETOOTH");
                return true;
            }
        }
        return false;
    }


}
