package com.mwee.android.posprint.business.api;

import com.mwee.android.pos.component.basecon.CBase;
import com.mwee.android.pos.connect.business.print.GetAllP433ListResponse;
import com.mwee.android.pos.connect.framework.SF;
import com.mwee.android.pos.connect.framework.SocketParam;
import com.mwee.android.pos.connect.framework.SocketResponse;

/**
 *
 * Created by huangming on 2018/5/24.
 */

public interface C433Printer extends CBase {

    @SocketParam(uri = "P433Driver/updateHostIdOfStation", response = SocketResponse.class)
    void updateHostIdOfStation(@SF("hostId")String hostId, @SF("p433StationId")String stationId);

    /**
     * 更新433打印机数据（站点，基站，打印机状态）
     * @param hostId
     * @param stationId
     */
    @SocketParam(uri = "P433Driver/updatePrinterList", response = Integer.class)
    void updatePrinterList(@SF("hostId")String hostId, @SF("p433StationId")String stationId,@SF("printerList")String printerList);

    @SocketParam(uri = "P433Driver/get433PrinterList", response = GetAllP433ListResponse.class)
    void get433PrinterList();


}
