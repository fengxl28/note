package com.mwee.android.posprint.business.api;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.print.Printer433Bean;
import com.mwee.android.pos.connect.business.print.GetAllP433ListResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import java.util.List;

/**
 *
 * Created by huangming on 2018/5/24.
 */
public class P433Api {

    public static void updateHostIdOfStation(String hostId,String stationId,SocketCallback<SocketResponse> callback){
        MCon.c(C433Printer.class,callback).updateHostIdOfStation(hostId,stationId);
    }

    /**
     * 更新433打印机数据（站点，基站，打印机状态）
     * @param hostId
     * @param stationId
     * @param printers
     * @param callback
     */
    public static void updatePrinterList(String hostId, String stationId, String printers,SocketCallback<Integer> callback){
        MCon.c(C433Printer.class,callback).updatePrinterList(hostId,stationId, printers);
    }

    public static void get433PrinterList(SocketCallback<GetAllP433ListResponse> callback){
        MCon.c(C433Printer.class,callback).get433PrinterList();
    }
}
