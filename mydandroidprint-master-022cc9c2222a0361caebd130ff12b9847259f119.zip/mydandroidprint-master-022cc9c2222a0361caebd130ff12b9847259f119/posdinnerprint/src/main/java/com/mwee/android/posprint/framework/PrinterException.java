package com.mwee.android.posprint.framework;

/**
 * 打印机相关的异常
 * Created by virgil on 2017/8/15.
 */

public class PrinterException extends NullPointerException {
    public PrinterException(String info) {
        super(info);
    }

    public PrinterException() {

    }
}
