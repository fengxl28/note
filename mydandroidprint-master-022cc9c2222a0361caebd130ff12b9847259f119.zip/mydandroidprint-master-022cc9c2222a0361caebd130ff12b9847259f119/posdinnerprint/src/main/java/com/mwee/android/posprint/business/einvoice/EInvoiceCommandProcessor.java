package com.mwee.android.posprint.business.einvoice;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.business.PrintBizBuilder;
import com.mwee.android.posprint.task.DinnerPrintProcessor;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintResult;

/**
 * 电子发票打印相关
 */
public class EInvoiceCommandProcessor implements IDriver {
    private final static String DRIVER_TAG = "einvoice";

    @DrivenMethod(uri = DRIVER_TAG + "/manualEInvoice")
    public static PrintResult a(JSONObject ob, PrintTaskDBModel taskModel, PrinterConfig config) {
        PrintBizBuilder billPrint = new PrintBizBuilder(config);
        billPrint.addTitle(JsonUtil.getInfo(ob, "shopName", String.class));
        billPrint.addBlankLine(1);
        billPrint.addText("订单号:" + JsonUtil.getInfo(ob, "orderId", String.class) + "\n");
        billPrint.addText("消费金额:" + JsonUtil.getInfo(ob, "amt", String.class) + "元\n");
        billPrint.addText("生成开票码时间:" + JsonUtil.getInfo(ob, "time", String.class) + "\n");
        billPrint.addDashLine("-");
        billPrint.addCenterText("请输入“邮箱地址”接收发票");
        billPrint.addCenterText("或者开票成功后添加至“微信卡包”");
        billPrint.addQRcode(JsonUtil.getInfo(ob, "code", String.class));
        billPrint.addCenterText("扫码开票，有效期3天");
        billPrint.addDashLine("-");
        billPrint.addLeftWithRight("打印时间:" + JsonUtil.getInfo(ob, "printTime", String.class)  , "印号"+JsonUtil.getInfo(ob, "fiPrintNo", String.class));
        billPrint.addText("\n");

        billPrint.addCut();
        return DinnerPrintProcessor.submitToPrinter(taskModel, billPrint.data, config);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}