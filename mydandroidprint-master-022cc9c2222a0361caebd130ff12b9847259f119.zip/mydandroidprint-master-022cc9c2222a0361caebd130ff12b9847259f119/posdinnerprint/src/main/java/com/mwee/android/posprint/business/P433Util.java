package com.mwee.android.posprint.business;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.print.Printer433Bean;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posprint.business.api.P433Api;
import com.mwee.android.print.printer.P433Printer.model.P433PrinterStatus;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * Created by huangming on 2018/5/24.
 */

public class P433Util {

    public static final long UPLOAD_TIME = 6*1000;
    private static String TAG = "P433Util";
    private static P433Util mInstance;

    private String mCurrentStationId;
    private String mCurrentHostId;
    private boolean mConnectStatus = false;

    private Map<Integer,Byte> mPrinterSNList = new HashMap<>();
    private List<Map<Integer,Byte>> dataCache = new ArrayList<>();

    private long mStartTime;
    private int mFilterTwoData = 0;

    private boolean mCanUploadData = true;
    private int mRetryUploadCount = 0;
    private Timer mTimeoutTimer;


    public static P433Util getInstance(){
        if(mInstance == null){
            synchronized (P433Util.class){
                if(mInstance == null){
                    mInstance = new P433Util();
                }
            }
        }
        return mInstance;
    }

    public void updateHostIdOfStation(final String stationId){
        if(TextUtils.isEmpty(stationId)){
            return;
        }
        mCurrentStationId = stationId;

        P433Api.updateHostIdOfStation(getHostId(), stationId, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if(response == null || response.code != SocketResultCode.SUCCESS){
                    //延时3s重发
                    addTimeoutTask(new TimerTask() {
                        @Override
                        public void run() {
                            updateHostIdOfStation(stationId);
                        }
                    },3000);
                }
            }
        });
        LogUtil.log(TAG,"上送有基站的站点:"+getHostId()+","+stationId);
    }

    public synchronized void updatePrinterMap(final Map<String, P433PrinterStatus> addressMap){
        LogUtil.log(TAG,"updatePrinterMap---addressMap:"+JSON.toJSONString(addressMap));
        if(addressMap == null){
            return;
        }

        if(mCanUploadData && (System.currentTimeMillis() - mStartTime > UPLOAD_TIME)){
            Map<String, P433PrinterStatus> copyMap = new HashMap<>(addressMap.size());
            for (String key : addressMap.keySet()) {
                if(TextUtils.isEmpty(key) || addressMap.get(key) == null){
                    continue;
                }
                copyMap.put(key.toUpperCase(),addressMap.get(key));
            }
            P433Api.updatePrinterList(getHostId(), mCurrentStationId, JSON.toJSONString(copyMap), new SocketCallback<Integer>() {
                @Override
                public void callback(SocketResponse<Integer> response) {
                    if(response != null && response.code == SocketResultCode.SUCCESS){
                        mRetryUploadCount = 0;
                        //data : 1:需要上送，0表示不需要
                        mCanUploadData = (response.data == 1);
                        LogUtil.log(TAG,"updatePrinterMap--需要上送:"+mCanUploadData);
                    }else{
                        if(mRetryUploadCount < 3){
                            addTimeoutTask(new TimerTask() {
                                @Override
                                public void run() {
                                    mRetryUploadCount ++;
                                    updatePrinterMap(addressMap);
                                    LogUtil.log(TAG,"updatePrinterMap--上送超时重发，count:"+mRetryUploadCount);
                                }
                            },3000);
                        }else{
                            mCanUploadData = false;
                            mRetryUploadCount = 0;
                            LogUtil.log(TAG,"updatePrinterMap--超时3次不在上送");
                        }

                    }
                }
            });
            mStartTime = System.currentTimeMillis();
        }
    }

    private void addTimeoutTask(TimerTask task,long delay){
        if(mTimeoutTimer == null){
            mTimeoutTimer = new Timer();
        }
        mTimeoutTimer.schedule(task,delay);
    }


    public synchronized void updatePrinterList(Map<Integer, Byte> addressMap){
        if(addressMap == null || addressMap.size() == 0){
            return;
        }
        Map<Integer, Byte> originData = new HashMap<>();
        originData.putAll(addressMap);
        if(!mConnectStatus){//断开后将数据清空，等待新数据
            mPrinterSNList.clear();
            return;
        }

        if(mPrinterSNList.size() > 0){

            if(System.currentTimeMillis() - mStartTime >= UPLOAD_TIME){
                Map<Integer, Byte> newData = buildCacheData();
                if(isNewData(mPrinterSNList,newData)){//新数据
                    updatePrinters(newData);
                    mPrinterSNList.clear();
                    mPrinterSNList.putAll(newData);
                }
                mStartTime = System.currentTimeMillis();
                dataCache.clear();
            }else{
                dataCache.add(originData);
            }
        }else{//新数据
            if(mFilterTwoData >= 2){
                mPrinterSNList.putAll(originData);
                updatePrinters(originData);
                mStartTime = System.currentTimeMillis();
            }
            mFilterTwoData ++;
            LogUtil.log(TAG,"FilterPrinterData:"+ JSON.toJSONString(originData));
        }
        originData.clear();
    }

    private Map<Integer, Byte> buildCacheData(){
        Map<Integer, Byte> result = new HashMap<>();
        for (Map<Integer, Byte> map : dataCache) {
            if(map == null || map.size() == 0){
                continue;
            }
            if(result.size() == 0){
                result.putAll(map);
            }else{
                for (Integer integer : map.keySet()) {
                    if(!result.containsKey(integer)){
                        result.put(integer,map.get(integer));
                    }else{
                        if(result.get(integer) > 3){
                            result.put(integer,map.get(integer));
                        }
                    }
                }
            }
        }
        return result;
    }

    private void updatePrinters(Map<Integer, Byte> addressMap){
        LogUtil.log("data:"+ JSON.toJSONString(addressMap));
        List<Printer433Bean> datas = new ArrayList<>();
//        for (Integer integer : mPrinterList.keySet()) {
//            Printer433Bean bean = new Printer433Bean();
//            bean.hostId = getHostId();
//            bean.stationId = mCurrentStationId;
//            bean.printerName = mPrinterList.get(integer);
//            bean.printerSN = ""+integer;
//            if(addressMap.containsKey(integer)){
//                bean.status = addressMap.get(integer);
//            }else{
//                bean.status = 4;
//            }
//            datas.add(bean);
//        }
//        P433Api.updatePrinterList(getHostId(), mCurrentStationId, JSON.toJSONString(datas), new SocketCallback<Integer>() {
//            @Override
//            public void callback(SocketResponse<Integer> response) {
//                if(response == null || response.code != SocketResultCode.SUCCESS){
//                    //上送失败，需要立即重新上送
//                    mPrinterSNList.clear();
//                }
//            }
//        });
        LogUtil.log(TAG,"updatePrinters:"+ JSON.toJSONString(datas));
    }

    private boolean isNewData(Map<Integer, Byte> oldData,Map<Integer, Byte> currentData){
        if(currentData.size() != oldData.size()){//大小不一致，则是新数据
            return true;
        }
        for (Integer integer : oldData.keySet()) {
            if(!currentData.containsKey(integer)){
                return true;
            }
            if(((byte)currentData.get(integer)) > 3 &&  ((byte)oldData.get(integer)) < 3){//数据不一致
                return true;
            }
            if(((byte)currentData.get(integer)) < 3 &&  ((byte)oldData.get(integer)) > 3){//数据不一致
                return true;
            }
        }
        return false;
    }

    private void filterAddress(List<Integer> address, List<Printer433Bean> data){
        if(ListUtil.isEmpty(data)){
            return;
        }
        for (Printer433Bean bean :data) {
            if(bean != null){
                if(!TextUtils.equals(mCurrentStationId,bean.stationId)){//过滤掉自己绑定的以外已经连接的打印机地址
                    address.remove(StringUtil.toInt(bean.printerSN,0));
                }
            }
        }
    }

    private String getHostId(){
        if(TextUtils.isEmpty(mCurrentHostId)){
            mCurrentHostId = DBSimpleUtil.queryString(APPConfig.DB_CLIENT,"select value from meta where key ='"+ META.BIZ_CENTER_CURRENT_HOST_ID+"'");
        }
        return mCurrentHostId;
    }

    public void uploadP433Data(){
        mCanUploadData = true;
        LogUtil.log(TAG,"uploadP433Data:需要基站立即上送数据");
    }

}
