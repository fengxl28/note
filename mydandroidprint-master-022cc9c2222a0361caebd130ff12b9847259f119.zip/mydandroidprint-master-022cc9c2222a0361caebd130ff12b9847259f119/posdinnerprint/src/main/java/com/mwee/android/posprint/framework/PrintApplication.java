package com.mwee.android.posprint.framework;

import android.content.Context;
import android.text.TextUtils;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.client.ClientConnector;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posprint.device.DeviceManager;
import com.mwee.android.posprint.device.PrinterCheckLoop;
import com.mwee.android.posprint.queue.DinnerPrintWakeUpReceiver;
import com.mwee.android.posprint.task.PrintInfoCollect;
import com.mwee.android.print.printer.PrintLog;
import com.mwee.android.print.printer.usbPriter.UsbConnector;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.ProcessUtil;

/**
 * 打印的Aplication
 * Created by virgil on 16/8/25.
 */
public class PrintApplication {
    public static void init(final Context context) {
        if (ProcessUtil.isMainProcess(context)) {
            PrintConnector.getInstance().init(context);
        } else if (ProcessUtil.getCurrentProcessName(context).endsWith(":print")) {
            PrintLog.setShowLog(!BaseConfig.isProduct());
            DinnerPrintWakeUpReceiver.registerAlarm(GlobalCache.getContext());
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(10 * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    UsbConnector.checkAllUsbPrinter(context);
                }
            }).start();
            initAllPrinter();
            DriverBus.setErrorWithException(true);
            PrinterCheckLoop.initPrinterCheckLoop();
            PrintInfoCollect.initInfoCollect();
            ClientConnector.getInstance().init(context);//注册AIDL服务
        }
    }

    public synchronized static void refershConnect() {
        String centerAddress = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_ADDRESS);
        if (!TextUtils.isEmpty(centerAddress)) {
            SocketConfig.ADDRESS = centerAddress;
        }
    }

    public static void initAllPrinter() {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                //初始化配置
//                PrinterConfig.tscReservse = DBMetaUtil.isConfigOpen(META.TSC_REVERSE, "1", "0");
                batchHistoryReverse();
                DBSimpleUtil.excuteSql(APPConfig.DB_CLIENT, "update tbPrinter set fsCommandType='ESC' where fsCommandType=''");
                DeviceManager.getInstance().rebuildAllPrinter();
                return null;
            }
        });
    }

    /**
     * 处理逆向打印的历史数据
     */
    public static void batchHistoryReverse() {
        // 逆向打印」关闭，不处理
        if (TextUtils.equals(ClientMetaUtil.getConfig(META.TSC_REVERSE, "0"), "0")) {
            return;
        }
        // 此操作仅处理一次
        if (TextUtils.equals(ClientMetaUtil.getConfig(META.BATCH_PRINTER_REVERSE, "0"), "1")) {
            return;
        }
        // 「逆向打印」开启，遍历所有打印机，将所有标签打印机置为逆向打印
        DBSimpleUtil.excuteSql(APPConfig.DB_CLIENT, "UPDATE tbPrinter SET fiReverse = '1' WHERE fsCommandType = 'TSC'");
        ClientMetaUtil.updateSettingsValueByKey(META.BATCH_PRINTER_REVERSE, "1");
    }
}
