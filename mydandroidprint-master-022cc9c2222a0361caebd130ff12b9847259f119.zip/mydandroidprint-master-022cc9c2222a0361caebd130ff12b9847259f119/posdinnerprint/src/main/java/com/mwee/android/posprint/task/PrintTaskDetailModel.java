package com.mwee.android.posprint.task;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by Liming on 16/9/7.
 */
public class PrintTaskDetailModel extends BusinessBean {
    public int printNumber;
    public int status;
    public String time;
    public String errorMsg;
    /**
     * 下次打印时是否需要打"重打"标记
     * */
    public boolean nextNeedReprint = false;

    public PrintTaskDetailModel() {

    }
}
