package com.mwee.android.posprint.task;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posprint.device.PrinterCheckLoop;
import com.mwee.android.posprint.framework.PrinterException;
import com.mwee.android.posprint.queue.TaskDBUtil;
import com.mwee.android.print.base.PrinterConfig;
import com.mwee.android.print.processor.PrintBillBuilder;
import com.mwee.android.print.processor.PrintBillBuilderV2;
import com.mwee.android.print.processor.PrintResult;
import com.mwee.android.print.processor.PrintResultCode;
import com.mwee.android.print.templet.MetaReceipt;
import com.mwee.android.print.templet.parser.MetaReceiptBuilder;
import com.mwee.android.print.templet.parser.ReceiptToCommand;
import com.mwee.android.tools.LogUtil;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class PrintTaskThread extends Thread {
    private volatile boolean manualFinished = false;
    private LinkedBlockingQueue<PrintTaskDBModel> queue = new LinkedBlockingQueue<>(100);
    private PrinterConfig config;
    private int noJob = 0;

    public PrintTaskThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        setPriority(MIN_PRIORITY);
        super.run();
        PrintTaskDBModel task = null;
        while (!manualFinished) {
            try {
                task = queue.poll(5, TimeUnit.MINUTES);

            } catch (InterruptedException e) {
                LogUtil.logError(e);
            }
            if (task != null) {
                noJob = 0;
                LogUtil.logOnlineDebug("----PrintTaskThread----" + getName() + "--开始打印----printNo:" + task.fiPrintNo);
                print(task);
            } else {
                noJob++;
                if (runWithNoJobOver1Hours()) {
                    manualFinished = true;
                    return;
                }
            }
        }
    }

    /**
     * 超过1小时的没有小票任务
     *
     * @return boolean
     */
    public boolean runWithNoJobOver1Hours() {
        return noJob >= 12;
    }

    private void print(PrintTaskDBModel taskModel) {
        if (taskModel.is_backup_printer == 1) {
            if (!taskModel.titleRemind.contains("备用")) {
                taskModel.titleRemind += "(备用打印)";
            }
        }
        JSONObject ob = null;
        if (!TextUtils.isEmpty(taskModel.fsPrnData)) {
            try {
                ob = JSONObject.parseObject(taskModel.fsPrnData);
            } catch (JSONException e) {
                e.printStackTrace();
                ToastUtil.showToast("数据异常");
                return;
            }
        }
        try {
            if (config == null) {
                throw new PrinterException(taskModel.fsPrinterName);
            }
            //判断数据库里存的是否需要下一次增加重打标记
            if (!TextUtils.isEmpty(taskModel.fsTaskDetail)) {
                List<PrintTaskDetailModel> array = JSON.parseArray(taskModel.fsTaskDetail, PrintTaskDetailModel.class);
                if (array != null && array.size() > 0) {
                    //取最后一条看看是否需要重打
                    PrintTaskDetailModel lastTaskDetailModel = array.get(array.size() - 1);
                    //如果需要重打，则添加重打标记
                    if (lastTaskDetailModel.nextNeedReprint) {
                        taskModel.appendRetry();
                        LogUtil.logBusiness("DinnerPrintProcessor add reprint sign in processPrint, fiPrintCount = [" + taskModel.fiPrintCount + "] fiPrintNo = [" + taskModel.fiPrintNo + "]");
                    }
                }
            }

            LogUtil.logBusiness("PrintLoop 开始打印[" + taskModel.fiPrintNo + "]" + "--threadName:" + getName());
            if (!TextUtils.isEmpty(taskModel.fsPrnData2)) {
                MetaReceiptBuilder builder = new MetaReceiptBuilder();
                MetaReceipt receipt = JSON.parseObject(taskModel.fsPrnData2, MetaReceipt.class);
                JSONObject taskData = JSON.parseObject(taskModel.fsPrnData);
                taskData.put("titleRemind", taskModel.titleRemind);
                builder.startMapping(receipt, receipt.templets, taskData);
                ReceiptToCommand s = new ReceiptToCommand(config);
                s.billPrint = new PrintBillBuilderV2(config);
                s.start(receipt.lineList);
                DinnerPrintProcessor.submitToPrinter(taskModel, s.billPrint.data, config);
            } else {
                DriverBus.call(taskModel.uri, ob, taskModel, config);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            PrintResult result = new PrintResult();
            result.result = PrintResultCode.PRINT_EXCEPTION;
            DinnerPrintProcessor.processPrintResult(result, taskModel);
            TaskDBUtil.checkRetry(taskModel);
        }
    }

    public void callFinish() {
        manualFinished = true;
    }

    public boolean manualFinished() {
        return manualFinished;
    }

    public void setPrinterConfig(PrinterConfig config) {
        this.config = config;
    }

    public void pushTask(PrintTaskDBModel task) throws InterruptedException {
        boolean ifEnqueue = queue.offer(task, 1, TimeUnit.SECONDS);
        if (ifEnqueue) {
            LogUtil.logOnlineDebug("----PrintTaskThread----" + getName() + "--入队完成----printNo:" + task.fiPrintNo);
        } else {
            LogUtil.logBusiness("----PrintTaskThread----" + getName() + "--入队失败----printNo:" + task.fiPrintNo);
        }
    }

    public void pushRetryTask(PrintTaskDBModel task) {
        PrinterCheckLoop.doDelayTask(() -> {
            try {
                boolean ifEnqueue = queue.offer(task, 5, TimeUnit.SECONDS);
                if (ifEnqueue) {
                    LogUtil.logOnlineDebug("----PrinterCheckLoop----" + getName() + "--入队完成----printNo:" + task.fiPrintNo);
                } else {
                    LogUtil.logBusiness("----PrinterCheckLoop----" + getName() + "--入队失败----printNo:" + task.fiPrintNo);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }, 20000);

    }
}
