package com.mwee.android.posprint.queue;

import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

public class PrintLock {
    private volatile static PrintLock printLock;
    private static final int MAX_LOCK_NUM = 20;
    private Object putLock = null;

    private PrintLock() {
        this.putLock = new Object();
    }

    /**
     * 打印锁池
     * key 桌台ID
     * value ReentrantLock对，由于多个线程使用，特采用ConcurrentHashMap
     */
    private HashMap<String, ReentrantLock> printLockPool = new HashMap<>();

    public static PrintLock getSingleton() {
        if (printLock == null) {
            synchronized (PrintLock.class) {
                if (printLock == null) {
                    printLock = new PrintLock();
                }
            }
        }
        return printLock;
    }

    public String doLock(int fiPrintNo, String fsHostId, String logConstance) {
        String lockId = fiPrintNo % MAX_LOCK_NUM + "-huangchao";
        return doLock(lockId, logConstance);
//        lock.lock();
//        return "";
    }

    /**
     * 锁
     *
     * @param lockId       lockID
     * @param logConstance 操作日志--->用于记录
     */
    public String doLock(String lockId, String logConstance) {

        //todo 上线前去掉
        LogUtil.logBusiness("打印加锁开始[" + lockId + "]", logConstance);
        ReentrantLock reentrantLock = printLockPool.get(lockId);
        if (reentrantLock == null) {
            synchronized (putLock) {
                reentrantLock = printLockPool.get(lockId);
                if (reentrantLock == null) {
                    reentrantLock = new ReentrantLock();
                    printLockPool.put(lockId, reentrantLock);
                }
            }
        }

        reentrantLock.lock();
        LogUtil.logBusiness("打印加锁开始[" + lockId + "]", logConstance);

        String uniq = UUID.randomUUID().toString();
        uniq += ("-" + lockId);

        return uniq;
    }

    public void unLock(int fiPrintNo, String fsHostId, String logConstance) {
        String lockId = fiPrintNo % MAX_LOCK_NUM + "-huangchao";
        unLock(lockId, logConstance);
//        lock.unlock();
    }

    /**
     * 解锁
     *
     * @param lockId       lockId
     * @param logConstance 操作日志--->用于记录
     */
    public void unLock(String lockId, String logConstance) {

        LogUtil.logBusiness("打印解锁开始[" + lockId + "]", logConstance);
        ReentrantLock reentrantLock = printLockPool.get(lockId);
        if (reentrantLock != null) {
            if (reentrantLock.getQueueLength() > 0) {
                reentrantLock.unlock();
                LogUtil.logBusiness("打印解锁结束[" + lockId + "," + "]" + "; 还有线程等待该锁，等待数量：" + reentrantLock.getQueueLength(), logConstance);
            } else {
                reentrantLock.unlock();
//                printLockPool.remove(lockId);
                LogUtil.logBusiness("打印解锁结束[" + lockId + "," + "]" + "; 该锁已经没有等待用户，移除此锁", logConstance);
            }
        }
    }
}
