package com.mwee.android.posprint.conn;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.exception.DrivenException;
import com.mwee.android.posprint.R;

/**
 * ServerService
 * Created by virgil on 16/7/5.
 */
public class PosPrintService extends Service {
    private PrintStub stub;

    @Override
    public void onCreate() {
        super.onCreate();
        new LowThread(new Runnable() {
            @Override
            public void run() {
                try {
                    DriverBus.init(getResources().getStringArray(R.array.print_drive_path));
                } catch (DrivenException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        stub = new PrintStub();
    }

    @Override
    public IBinder onBind(Intent intent) {
        if (stub == null) {
            return null;
        }
        try {
            stub.init();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return stub.asBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }
}
