package com.mwee.android.posprint.business;

import android.support.annotation.StringRes;

import com.mwee.android.base.GlobalCache;

/**
 * Created by virgil on 2017/8/9.
 */

public class Util {
    public static String getString(@StringRes int id, Object... value) {
        return GlobalCache.getContext().getString(id, value);
    }
}
