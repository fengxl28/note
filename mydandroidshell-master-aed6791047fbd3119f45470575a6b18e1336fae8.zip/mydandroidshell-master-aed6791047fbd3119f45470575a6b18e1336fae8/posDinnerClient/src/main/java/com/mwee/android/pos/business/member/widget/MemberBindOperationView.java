package com.mwee.android.pos.business.member.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.TextUtils;

/**
 * Created by qinwei on 2018/3/23.
 */

public class MemberBindOperationView extends LinearLayout {
    private TextView mOperationMemberLabel;
    private TextView mOperationMemberPhoneLabel;

    public MemberBindOperationView(Context context) {
        super(context);
        initView(context);
    }


    public MemberBindOperationView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public MemberBindOperationView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }


    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.widget_member_bind_operation, this);
        mOperationMemberLabel = (TextView) findViewById(R.id.mOperationMemberLabel);
        mOperationMemberPhoneLabel = (TextView) findViewById(R.id.mOperationMemberPhoneLabel);
    }

    public void unBind() {
        mOperationMemberLabel.setText("关联会员");
        mOperationMemberPhoneLabel.setVisibility(View.GONE);
    }

    public void bind(String name, String phone) {
        mOperationMemberLabel.setText(name);
        mOperationMemberPhoneLabel.setVisibility(View.VISIBLE);
        mOperationMemberPhoneLabel.setText(TextUtils.entcyMobile(phone));
    }
}
