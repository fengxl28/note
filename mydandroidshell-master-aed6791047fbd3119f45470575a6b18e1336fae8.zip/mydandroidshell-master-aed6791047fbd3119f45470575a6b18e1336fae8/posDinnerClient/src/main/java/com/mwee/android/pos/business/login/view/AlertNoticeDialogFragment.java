package com.mwee.android.pos.business.login.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.business.login.component.LoginProcess;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.NoticeDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2017/6/27.
 */
public class AlertNoticeDialogFragment extends BaseDialogFragment implements View.OnClickListener {


    public static final String TAG = "AlertNoticeDialogFragment";

    private TextView tv_notice_title;
    private TextView tv_notice_time;
    private TextView tv_notice_content;
    private TextView tv_unalert;
    private TextView tv_action_hnow;
    private TextView tv_action_next;
    private NoticeDBModel noticeDBModel = null;

    /**
     * 不再提醒
     */
    private boolean unAlert = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.notice_dialog, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.content).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        initView(view);
        initData();
    }

    private void initView(View view) {
        tv_notice_title = (TextView) view.findViewById(R.id.tv_notice_title);
        tv_notice_time = (TextView) view.findViewById(R.id.tv_notice_time);
        tv_notice_content = (TextView) view.findViewById(R.id.tv_notice_content);
        tv_unalert = (TextView) view.findViewById(R.id.tv_unalert);
        tv_action_hnow = (TextView) view.findViewById(R.id.tv_action_hnow);
        tv_action_next = (TextView) view.findViewById(R.id.tv_action_next);
        tv_unalert.setOnClickListener(this);
        tv_action_hnow.setOnClickListener(this);
        tv_action_next.setOnClickListener(this);
    }

    private void initData() {
        if (noticeDBModel == null) {
            dismiss();
        } else {
            tv_notice_title.setText(noticeDBModel.fsTitle);
            tv_notice_time.setText(DateUtil.formartDateStrToTarget(noticeDBModel.fsUpdateTime, "yyyy-MM-dd HH:mm:ss", "yyyy年MM月dd日"));
            tv_notice_content.setText(noticeDBModel.fsContent);
            unAlert = false;
            tv_unalert.setSelected(false);
        }
    }

    public void setData(NoticeDBModel noticeDBModel) {
        this.noticeDBModel = noticeDBModel;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_action_next:
                getNotices(noticeDBModel.id, noticeDBModel.fsUpdateTime);
                break;
            case R.id.tv_action_hnow:
                if (unAlert) {
                    LoginProcess.unAlertNotice(noticeDBModel.id, 1);
                }
                dismiss();
                break;
            case R.id.tv_unalert:
                unAlert = !unAlert;
                tv_unalert.setSelected(unAlert);
                break;
            default:
                break;
        }
    }

    /**
     * 获取未读公告
     *
     * @param id
     * @param fsUpdateTime
     */
    private void getNotices(int id, String fsUpdateTime) {
        int alert = unAlert ? 1 : 0;
        ProgressManager.showProgress(AlertNoticeDialogFragment.this, "请稍候...");
        LoginProcess.getLastNotice(AlertNoticeDialogFragment.this, id, alert, fsUpdateTime, new IResponse<NoticeDBModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, NoticeDBModel info) {
                ProgressManager.closeProgress(AlertNoticeDialogFragment.this);
                if (result && code == 0) {
                    noticeDBModel = info;
                    initData();
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }
}

