package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.telecom.Call;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.member.MemberInfoContainerFragment;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.view.widget.MemberCardView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 会员->会员卡列表
 */
public class MemberCardListFragment extends BaseFragment{

    public static final String TAG = "MemberCardListFragment";

    private GridView gv_member_card_list;
    private TextView mTitleTv;
    private List<NewMemberCardListItemModel> mMemberCardList = new ArrayList<>();
    private CommonAdapter<NewMemberCardListItemModel> mAdapter;
    private String selectedCardNo = "";
    private Callback mCallback;
    private String mPhoneNum;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_member_card_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mTitleTv = view.findViewById(R.id.tv_member_list_title);
        gv_member_card_list = view.findViewById(R.id.gv_member_card_list);
        mAdapter = new CommonAdapter<NewMemberCardListItemModel>(getContext(), mMemberCardList, R.layout.item_member_card_choose_in_member) {
            @Override
            public void convert(ViewHolder viewHolder, NewMemberCardListItemModel data, int position) {
                ((MemberCardView) viewHolder.getView(R.id.v_member_card)).setMember(data);
                View selector = viewHolder.getView(R.id.rl_selector);
                if(TextUtils.equals(selectedCardNo,data.cardNo)){
                    selector.setVisibility(View.VISIBLE);
                }else{
                    selector.setVisibility(View.INVISIBLE);
                }
                viewHolder.getConvertView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        selectPosition = position;
//                        refresh();
                        if(position < mMemberCardList.size()){
                            if(!TextUtils.equals(selectedCardNo,mMemberCardList.get(position).cardNo)){
                                if(mCallback != null){
                                    mCallback.onCardSelected(mMemberCardList.get(position).cardNo);
                                }
//                                DriverBus.call("member/refreshMemberInfo",mMemberCardList.get(position).cardNo);
                                dismissSelf();
                            }
                        }
                    }
                });
            }
        };
        gv_member_card_list.setAdapter(mAdapter);
    }

    private void initData(){
        Progress progress = ProgressManager.showProgress(this);
        new MemberProcess().optMemberInfoWithoutVerify(mPhoneNum, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                progress.dismiss();
                if(data != null && !ListUtil.isEmpty(data.cardList) && getContext() != null && isVisible()){
                    mAdapter.setData(data.cardList);
                    mTitleTv.setText(String.format(getContext().getString(R.string.card_num),""+mMemberCardList.size()));
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                LogUtil.logBusiness(TAG, "会员列表查询failure msg=" + msg);
                ToastUtil.showToast(msg);
            }
        });
    }

    public void setParams(String phoneNum,String currentCardNo,Callback callback) {
        mPhoneNum = phoneNum;
        selectedCardNo = currentCardNo;
        mCallback = callback;
    }

    public interface Callback{
        void onCardSelected(String cardNo);
    }
}