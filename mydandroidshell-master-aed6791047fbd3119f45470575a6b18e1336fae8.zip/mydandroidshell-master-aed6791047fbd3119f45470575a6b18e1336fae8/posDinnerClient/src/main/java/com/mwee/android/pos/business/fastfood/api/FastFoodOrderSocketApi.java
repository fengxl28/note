package com.mwee.android.pos.business.fastfood.api;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.fastfood.FastFoodOrderListResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.callback.AbstractCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.connect.business.CFastFoodOrder;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;

/**
 * 快餐单相关操作请求接口
 * Created by qinwei on 2017/5/25.
 */

public class FastFoodOrderSocketApi {

    /**
     * 快餐单开单
     *
     * @param fsBillSourceId 快餐单来源
     * @param callback       异步回调callback
     */
    public static void loadOpenFastFoodOrder(String fsBillSourceId, final AbstractCallback<StartFastFoodOrderResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<StartFastFoodOrderResponse>() {
            @Override
            public void callback(SocketResponse<StartFastFoodOrderResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).startFastFoodOrder(fsBillSourceId);
    }


    /**
     * 下单
     *
     * @param orderId  订单id
     * @param canNew   是否开新单
     * @param callback 异步回调callback
     */
    public static void loadSynOrderCache(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, boolean canNew, final ResultCallback<OnlyOrderMenuItemsResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<OnlyOrderMenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<OnlyOrderMenuItemsResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }, new SocketThreadCallback<OnlyOrderMenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<OnlyOrderMenuItemsResponse> response) {
                if (response.success() && !ListUtil.isEmpty(response.data.printTaskIds)) {
                    //业务中心打印不了的任务 用自己的打印进程打印
                    PrintReceiptUtil.addPrintNo(response.data.printTaskIds, AppCache.getInstance().currentHostId);
                }
            }
        }).onlyOrderMenuItems(orderId, menuItems, mealNumber, canNew);
    }

    /**
     * 获取所有快餐未完成订单
     *
     * @param orderId  订单id
     * @param callback 异步回调callback
     */
    public static void loadOrderCacheById(String orderId, final AbstractCallback<StartFastFoodOrderResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<StartFastFoodOrderResponse>() {
            @Override
            public void callback(SocketResponse<StartFastFoodOrderResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS && socketResponse.data != null && socketResponse.data.fastOrderModel != null) {
                    if (callback != null) {
                        callback.onSuccess(socketResponse.data);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(socketResponse.code, socketResponse.message);
                    }
                }
            }
        }).optOrderCacheById(orderId);
    }

    /**
     * 获取所有快餐未完成订单
     *
     * @param fsBillSourceId 快餐单来源
     * @param businessDate   营业日期
     * @param socketCallback 异步回调callback
     */
    public static void loadAllFastFoodOrder(String fsBillSourceId, String businessDate, SocketCallback<FastFoodOrderListResponse> socketCallback) {
        MCon.c(CFastFoodOrder.class, socketCallback).loadAllFastFoodOrder(businessDate, fsBillSourceId);
    }

    /**
     * 修改牌号
     *
     * @param orderID  订单id
     * @param count    牌号数字
     * @param callback 回调
     */
    public static void loadUpdateMealNumber(String orderID, String count, final ResultCallback<String> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }
            }
        }).loadUpdateMealNumber(orderID, count);
    }

    /**
     * 修改订单来源
     *
     * @param orderId
     * @param billSourceId
     * @param callback
     */
    public static void loadUpdateBillSource(String orderId, String billSourceId, final ResultCallback<String> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }
            }
        }).loadUpdateBillSource(orderId, billSourceId);
    }

    /**
     * 将未下单的菜入库
     *
     * @param orderId    订单id
     * @param menuItems  未下单的菜品
     * @param mealNumber 牌号
     */
    public static void loadMenuItemsInsertToSellDB(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, final ResultCallback<OnlyOrderMenuItemsResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<OnlyOrderMenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<OnlyOrderMenuItemsResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).menuItemsInsertToSellDB(orderId, menuItems, mealNumber);
    }
}
