package com.mwee.android.pos.air.business.menu.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideDtlBean;
import com.mwee.android.pos.air.business.menu.processor.MenuClsProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuProcessor;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/12/19.
 */

public class MenuItemSetSideEditorFragment extends BaseFragment implements View.OnClickListener {

    private TitleBar titleBar;
    private TextView mCancelBtn;
    private TextView mConfirmBtn;

    private RecyclerView mMenuClsRecyclerView;
    private ListView mMenuRecyclerView;

    private MenuClsAdapter menuClsAdapter;
    private MenuAdapter menuAdapter;

    private MenuClsProcessor mMenuClsProcessor;
    private MenuProcessor mMenuProcessor;

    private OnMenuItemSetSideEditorListener listener;

    private List<MenuPackageSetSideDtlBean> choiceMenus = new ArrayList<>();//当前套餐组下面套餐明细

    private MenuPackageSetSideBean menuPackageSetSideBean;
    private TextView tvMenuChoiceNumber;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_menu_package_setside_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {

        titleBar = view.findViewById(R.id.mTitleBar);
        titleBar.setTitle("选择菜品");
        titleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });

        tvMenuChoiceNumber = view.findViewById(R.id.tvMenuChoiceNumber);
        mCancelBtn = view.findViewById(R.id.mCancelBtn);
        mConfirmBtn = view.findViewById(R.id.mConfirmBtn);

        mCancelBtn.setOnClickListener(this);
        mConfirmBtn.setOnClickListener(this);

        mMenuClsRecyclerView = view.findViewById(R.id.mMenuClsRecyclerView);
        mMenuRecyclerView = view.findViewById(R.id.mMenuRecyclerView);


    }

    private void initData() {

        mMenuClsProcessor = new MenuClsProcessor();
        mMenuProcessor = new MenuProcessor();

        mMenuClsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mMenuClsRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL_LIST));
        menuClsAdapter = new MenuClsAdapter();
        mMenuClsRecyclerView.setAdapter(menuClsAdapter);

        //mMenuRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        //mMenuRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL_LIST));
        menuAdapter = new MenuAdapter();
        mMenuRecyclerView.setAdapter(menuAdapter);

        refreshTitle();

        loadDataFromServer(true);
    }

    private void refreshTitle() {
        tvMenuChoiceNumber.setText(String.format("已选择%s个", choiceMenus.size()));
    }


    private void refreshMenusList(List<MenuItemBean> menuItemBeans) {
        menuAdapter.modules.clear();
        menuAdapter.modules.addAll(menuItemBeans);
        menuAdapter.notifyDataSetChanged();
    }

    private void refreshMenuClsList(List<MenuClsBean> menuClsBeanList) {
        menuClsAdapter.modules.clear();
        menuClsAdapter.modules.addAll(menuClsBeanList);
        menuClsAdapter.notifyDataSetChanged();
    }


    private void loadDataFromServer(final boolean isLoadAllMenu) {
        final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuClsProcessor.loadMenuManagerIndexData(isLoadAllMenu, new ResultCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void onSuccess(AllMenuClsAndMenuItemResponse data) {
                refreshMenuClsList(data.menuClsBeanList);
                if (isLoadAllMenu) {
                    refreshMenusList(data.menuItemBeanList);
                }
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }

    public void loadMenuItemsByClsId(String fsMenuClsId) {
        mMenuProcessor.loadMenuItemsByClsId(fsMenuClsId, new ResultCallback<List<MenuItemBean>>() {
            @Override
            public void onSuccess(List<MenuItemBean> data) {
                refreshMenusList(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mCancelBtn:
                dismissSelf();
                break;
            case R.id.mConfirmBtn:
                doConfirm();
                break;
            default:
                break;
        }
    }


    private void doConfirm() {
        if (ListUtil.isEmpty(choiceMenus)) {
            ToastUtil.showToast(R.string.please_choice_menuitem);
            return;
        }
        menuPackageSetSideBean.choiceMenuItems = choiceMenus;
        listener.onOnMenuItemSetSideUpdateSuccess();
        dismissSelf();
    }


    class MenuClsAdapter extends BaseListAdapter<MenuClsBean> {
        int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuClsHolder(LayoutInflater.from(getContext()).inflate(R.layout.menu_class_son_category_item_layout, parent, false));
        }

        public MenuClsBean getCurrentMenuCls() {
            return modules.get(selectPosition);
        }

        class MenuClsHolder extends BaseViewHolder implements View.OnClickListener {

            private int position;

            public MenuClsHolder(View itemView) {
                super(itemView);
                itemView.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                boolean isSelected = position == selectPosition;
                TextView mAskGroupItemLabel = (TextView) itemView;
                mAskGroupItemLabel.setText(modules.get(position).fsMenuClsName);
                if (isSelected) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, R.drawable.bg_category_son_white_item_checked);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, 0);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.color_686868));
                }
            }

            @Override
            public void onClick(View v) {
                if (selectPosition != position) {
                    selectPosition = position;
                    menuClsAdapter.notifyDataSetChanged();
                    loadMenuItemsByClsId(getCurrentMenuCls().fsMenuClsId);
                }
            }
        }
    }

    class MenuAdapter extends BaseMwAdapter<MenuItemBean> {

        private int selectPosition;

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            MenuHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_menu_item, parent, false);
                viewHolder = new MenuHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (MenuHolder) convertView.getTag();
            }
            viewHolder.bindData(position);

            return convertView;
        }


        class MenuHolder implements View.OnClickListener {

            private View itemViewLayout;
            private TextView mMenuItemNameLabel;
            private TextView mMenuItemRepertoryLabel;
            private TextView mMenuItemSellPriceLabel;
            private TextView mMenuItemMemberPriceLabel;
            private ImageView tvItemCheck;

            private MenuItemBean data;
            private int position;

            public MenuHolder(View v) {
                itemViewLayout = v.findViewById(R.id.itemViewLayout);
                mMenuItemNameLabel = v.findViewById(R.id.mMenuItemNameLabel);
                mMenuItemRepertoryLabel = v.findViewById(R.id.mMenuItemRepertoryLabel);
                mMenuItemSellPriceLabel = v.findViewById(R.id.mMenuItemSellPriceLabel);
                mMenuItemMemberPriceLabel = v.findViewById(R.id.mMenuItemMemberPriceLabel);
                tvItemCheck = v.findViewById(R.id.tvItemCheck);
                //tvItemCheck.setOnClickListener(this);
                v.setOnClickListener(this);

            }


            public void bindData(int position) {

                this.position = position;
                data = modules.get(position);

                tvItemCheck.setVisibility(View.VISIBLE);
                tvItemCheck.setSelected(isSelected(data.fiItemCd, data.fiOrderUintCd));
                mMenuItemNameLabel.setText(data.fsItemName);
                if (data.fiStatus == 2) {//临时沽清显示沽清数量
                    if (data.fdInvQty.compareTo(BigDecimal.ZERO) == 0) {
                        mMenuItemRepertoryLabel.setText("售罄");
                    } else {
                        mMenuItemRepertoryLabel.setText(data.fdInvQty.toPlainString());
                    }
                } else {
                    mMenuItemRepertoryLabel.setText("不限");
                }

                String sellPriceLabelContent = Calc.formatShow(data.fdSalePrice, RoundConfig.ROUND_SINGLE_PRICE) + "/" + data.fsOrderUint;
                mMenuItemSellPriceLabel.setText(sellPriceLabelContent);
                if (data.fdVIPPrice.compareTo(BigDecimal.ZERO) > 0) {
                    mMenuItemMemberPriceLabel.setText(Calc.formatShow(data.fdVIPPrice, RoundConfig.ROUND_SINGLE_PRICE)+ "/" + data.fsOrderUint);
                } else {
                    mMenuItemMemberPriceLabel.setText(sellPriceLabelContent);
                }

                if (position == selectPosition) {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FFD2CB));
                } else {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));
                }
            }


            @Override
            public void onClick(View v) {
                selectPosition = position;
                //menuAdapter.notifyDataSetChanged();
                choiceMenu(data);
                refreshTitle();
                menuAdapter.notifyDataSetChanged();

            }
        }

    }

    public void setParam(MenuPackageSetSideBean menuPackageSetSideBean) {
        this.menuPackageSetSideBean = menuPackageSetSideBean;
        this.choiceMenus.addAll(menuPackageSetSideBean.choiceMenuItems);
    }

    public void setOnMenuItemSetSideEditorListener(OnMenuItemSetSideEditorListener listener) {
        this.listener = listener;
    }

    /**
     * 判断当前菜品是否被选中
     *
     * @param fiItemCd
     * @param fiOrderUintCd
     * @return
     */
    private boolean isSelected(String fiItemCd, String fiOrderUintCd) {
        if (ListUtil.isEmpty(choiceMenus)) {
            return false;
        }
        for (int i = 0; i < choiceMenus.size(); i++) {
            if (TextUtils.equals(choiceMenus.get(i).fiItemCd, fiItemCd) && TextUtils.equals(choiceMenus.get(i).fiOrderUintCd, fiOrderUintCd)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 选中菜品
     *
     * @param menuItemBean
     */
    private void choiceMenu(MenuItemBean menuItemBean) {
        MenuPackageSetSideDtlBean bean = null;
        for (int i = 0; i < choiceMenus.size(); i++) {
            if (TextUtils.equals(choiceMenus.get(i).fiItemCd, menuItemBean.fiItemCd) && TextUtils.equals(choiceMenus.get(i).fiOrderUintCd, menuItemBean.fiOrderUintCd)) {
                bean = choiceMenus.get(i);
                break;
            }
        }
        if (bean != null) {
            choiceMenus.remove(bean);
        } else {
            choiceMenus.add(build(menuItemBean));
        }
    }




    private MenuPackageSetSideDtlBean build(MenuItemBean menuItemBean) {
        MenuPackageSetSideDtlBean bean = new MenuPackageSetSideDtlBean();
        bean.fiOrderUintCd = menuItemBean.fiOrderUintCd;
        bean.fiItemCd = menuItemBean.fiItemCd;
        bean.fsItemName = menuItemBean.fsItemName;
        if (menuPackageSetSideBean != null) {
            bean.fiItemCd_M = menuPackageSetSideBean.fiItemCd_M;
            bean.fiSetFoodCd = menuPackageSetSideBean.fiSetFoodCd;
        }
        return bean;
    }


    public interface OnMenuItemSetSideEditorListener {

        void onOnMenuItemSetSideUpdateSuccess();

        void onOnMenuItemSetSideAddSuccess(List<MenuPackageSetSideDtlBean> choiceItems);
    }

}
