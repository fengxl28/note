/*
 Copyright 2013 Tonic Artos

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

package com.mwee.android.pos.air.business.ask.business.adapter;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.gridcategory.CategoryGridHeadersSimpleAdapter;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DisplayUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * 小散要求Adapter
 *
 * @author liuxiuxiu
 * @date 2017/11/14
 */
public class AirNoteAdapter extends BaseAdapter implements CategoryGridHeadersSimpleAdapter {
    protected static final String TAG = AirNoteAdapter.class.getSimpleName();

    /**
     * 虚拟要求ID
     */
    private static final String VIRTUAL_NOTE_ID = "-1000";

    private int mHeaderResId;

    private int mItemResId;

    private List<NoteItemModel> mItems;
    private List<NoteModel> headrCount;
    private Host host;
    private OnNoteItemClickListener mOnItemClickListener;


    private Drawable checkUpdateIcon;

    public void setOnItemClickListener(OnNoteItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public void showAddIcon(TextView view) {
        view.setText("新增要求");
        view.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_add, 0, 0);
        view.setCompoundDrawablePadding(DisplayUtil.dp2px(GlobalCache.getContext(), 4));
    }

    public void hideAddIcon(TextView view) {
        view.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
    }

    public AirNoteAdapter(Host host, List<NoteItemModel> items, List<NoteModel> headrCount, int headerResId, int itemResId) {
        init(host, items, headrCount, headerResId, itemResId);
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    private int getHeaderIndex(String id) {
        for (int i = 0; i < headrCount.size(); i++) {
            if (TextUtils.equals(headrCount.get(i).groupID, id)) {
                return i;
            }
        }
        return -1;
    }

    private String getHeaderName(String id) {
        for (int i = 0; i < headrCount.size(); i++) {
            if (TextUtils.equals(headrCount.get(i).groupID, id)) {
                return headrCount.get(i).name;
            }
        }
        return "自定义";
    }

    @Override
    public long getHeaderId(int position) {
        NoteItemModel item = getItem(position);
        return getHeaderIndex(item.groupIDFather);
    }

    @Override
    @SuppressWarnings("unchecked")
    public View getHeaderView(int position, View convertView, ViewGroup parent) {
        NoteItemModel item = getItem(position);
        ViewHolder holder = ViewHolder.getInstance(host.getContextWithinHost(), convertView, parent, mHeaderResId, position);
        holder.setText(R.id.tv_note_item_header, getHeaderName(item.groupIDFather));
        return holder.getConvertView();
    }

    @Override
    public NoteItemModel getItem(int position) {
        return mItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    @SuppressWarnings("unchecked")
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        NoteItemModel item = getItem(position);
        holder = ViewHolder.getInstance(host.getContextWithinHost(), convertView, parent, mItemResId, position);

        holder.getView(R.id.air_note_root).setTag(R.id.id_note_gp_id, item.groupIDFather);
        holder.getView(R.id.air_note_root).setTag(R.id.id_note_id, item.id);
        holder.getView(R.id.air_note_root).setOnClickListener(click);

        if (TextUtils.equals(item.id, VIRTUAL_NOTE_ID)) {
            showAddIcon((TextView) holder.getView(R.id.nameTv));
            holder.getView(R.id.priceTv).setVisibility(View.GONE);
            holder.getView(R.id.numTv).setVisibility(View.GONE);
        } else {
            holder.setText(R.id.nameTv, item.name);

            holder.setText(R.id.priceTv, Calc.formatShow(item.price, RoundConfig.ROUND_SINGLE_PRICE));

            holder.getView(R.id.nameTv).setSelected(item.selected);

            if (item.num != null && item.num.compareTo(BigDecimal.ZERO) > 0) {
                holder.getView(R.id.numTv).setVisibility(View.VISIBLE);
                ((TextView) holder.getView(R.id.numTv)).setText(Calc.formatShow(item.num, 0, RoundConfig.Decimal_ROUND_Type));
            } else {
                holder.getView(R.id.numTv).setVisibility(View.GONE);
            }
            hideAddIcon((TextView) holder.getView(R.id.nameTv));
            holder.getView(R.id.priceTv).setVisibility(View.VISIBLE);
            holder.getConvertView().setVisibility(TextUtils.equals(item.id, "-1") ? View.GONE : View.VISIBLE);
        }
        return holder.getConvertView();
    }

    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.air_note_root: {
                    String gpId = (String) v.getTag(R.id.id_note_gp_id);
                    String id = (String) v.getTag(R.id.id_note_id);
                    if (TextUtils.isEmpty(id)) {
                        return;
                    }
                    String itemId = id;
                    if (TextUtils.equals(itemId, VIRTUAL_NOTE_ID)) {
                        if (mOnItemClickListener != null) {
                            mOnItemClickListener.onAddNoteItemClick(gpId);
                        }
                        return;
                    }
                    NoteItemModel item = getNoteItem(gpId, itemId);
                    if (item == null) {
                        return;
                    }

                    if (item.num == null) {
                        item.num = BigDecimal.ONE;
                    } else {
                        item.num = item.num.add(BigDecimal.ONE);
                    }
                    item.selected = true;
                    item.calcTotal();
                    AirNoteAdapter.this.notifyDataSetChanged();
                }
                break;
                default:
                    break;
            }
        }
    };

    private void init(Host host, List<NoteItemModel> items, List<NoteModel> headrCount, int headerResId, int itemResId) {
        this.mItems = items;
        this.mHeaderResId = headerResId;
        this.mItemResId = itemResId;
        this.host = host;
        this.headrCount = headrCount;

        checkUpdateIcon = ViewToolsUtil.getDrawable(R.drawable.ic_add);
    }

    public interface OnNoteItemClickListener {
        void onAddNoteItemClick(String groupId);
    }

    public NoteItemModel getNoteItem(String gpId, String id) {
        if (StringUtil.toInt(id, 0) < 0) {
            return null;
        }
        if (!ListUtil.isEmpty(headrCount)) {
            for (NoteModel noteModel : headrCount) {
                if (noteModel != null && TextUtils.equals(gpId, noteModel.groupID) && !ListUtil.isEmpty(noteModel.itemList)) {
                    for (NoteItemModel noteItem : noteModel.itemList) {
                        if (noteItem != null && TextUtils.equals(noteItem.id, id)) {
                            return noteItem;
                        }
                    }
                }
            }
        }
        return null;
    }

}
