package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;

/**
 * 查询会员积分储值规则 和 充值套餐规则
 * Created by zhangmin on 2018/1/30.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "crm.membercard.getScRuleInfo",
        contentType = "application/json",
        response = AirMemberResponse.class,
        saveToLog = true
)
public class AirMemberRuleQueryRequest extends BaseMemberRequest {

    /*public int pkg_id;

    public int getOnlineStoreRule;*/

    public AirMemberRuleQueryRequest() {
        super("crm.membercard.getScRuleInfo");
    }
}
