//package com.mwee.android.pos.air.business.dinner;
//
//import android.content.Context;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.util.AttributeSet;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.pos.air.business.table.processor.AirChangeTableProcessor;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.Host;
//import com.mwee.android.pos.business.orderdishes.view.DishCache;
//import com.mwee.android.pos.business.permission.Permission;
//import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
//import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
//import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
//import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
//import com.mwee.android.pos.business.table.processor.TableBizProcessor;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.connect.callback.IResult;
//import com.mwee.android.pos.db.business.UserDBModel;
//import com.mwee.android.pos.db.business.order.OrderCache;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.ToastUtil;
//
//import java.math.BigDecimal;
//
///**
// * Created by zhangmin on 2017/11/9.
// */
//
//public class DinnerFoodOperationTopLayout extends LinearLayout implements View.OnClickListener {
//
//    private ImageView imgBack;
//    private TextView tvTableNumber;
//    private TextView tvExchangeTable;
//    private TextView tvOrderId;
//    private TextView tvPersonNumber;
//
//
//    private DishCache mDishCache;
//    private Host mHost;
//
//    public DinnerFoodOperationTopLayout(Context context) {
//        super(context);
//        init();
//    }
//
//    public DinnerFoodOperationTopLayout(Context context, @Nullable AttributeSet attrs) {
//        super(context, attrs);
//        init();
//    }
//
//    public DinnerFoodOperationTopLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
//        super(context, attrs, defStyleAttr);
//        init();
//    }
//
//    private void init() {
//        LayoutInflater.from(getContext()).inflate(R.layout.air_dinner_orderdishs_top, this);
//
//        imgBack = findViewById(R.id.imgBack);
//        tvTableNumber = findViewById(R.id.tvTableNumber);
//        tvExchangeTable = findViewById(R.id.tvExchangeTable);
//        tvOrderId = findViewById(R.id.tvOrderId);
//        tvPersonNumber = findViewById(R.id.tvPersonNumber);
//
//        imgBack.setOnClickListener(this);
//        tvTableNumber.setOnClickListener(this);
//        tvExchangeTable.setOnClickListener(this);
//        tvPersonNumber.setOnClickListener(this);
//
//
//    }
//
//    public void setParams(Host mHost, DishCache mDishCache) {
//
//        this.mHost = mHost;
//        this.mDishCache = mDishCache;
//        refreshDinnerFoodTopLayout();
//
//    }
//
//
//    public void refreshDinnerFoodTopLayout() {
//
//        tvOrderId.setText(TextUtils.isEmpty(mDishCache.getOrderId()) ? "" : String.format("订单号: %s", mDishCache.getOrderId()));
//
//        if (mDishCache.order == null) {
//            tvTableNumber.setText(mDishCache.orderDishesCache.fsmtablename);
//            tvPersonNumber.setText(String.format("人数: %s", mDishCache.orderDishesCache.personNum));
//        } else {
//            tvTableNumber.setText(mDishCache.order.fsmtablename);
//            tvPersonNumber.setText(String.format("人数: %s", mDishCache.order.personNum));
//        }
//
//        if (mDishCache.antiPay) {
//            tvExchangeTable.setEnabled(false);
//            tvPersonNumber.setEnabled(false);
//        }
//
//    }
//
//
//    @Override
//    public void onClick(View view) {
//        if (!ButtonClickTimer.canClick()) {
//            return;
//        }
//        switch (view.getId()) {
//            case R.id.imgBack:
//            case R.id.tvTableNumber:
//                listener.backToTable();
//                break;
//            case R.id.tvExchangeTable:
//                ActionLog.addLog("换桌按钮被点击", ActionLog.USER_ACTION_TRACE);
//                PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnChangeTable, new PermissionCallback() {
//                    @Override
//                    public void onCall(int errCode, String msg, UserDBModel userDBModel) {
//                        changeTable();
//                    }
//                });
//                break;
//            case R.id.tvPersonNumber:
//                setPersonCount();
//                break;
//            default:
//                break;
//        }
//    }
//
//    /**
//     * 设置人数
//     */
//    private void setPersonCount() {
//
//        CountKeyboardFragment fragment = new CountKeyboardFragment();
//        fragment.setTitle("设置就餐人数");
//        if (mDishCache.order != null) {
//            fragment.setOriginCount(mDishCache.order.personNum);
//        } else {
//            fragment.setOriginCount(mDishCache.orderDishesCache.personNum);
//        }
//        fragment.setCallback(new CountKeyboardCallback() {
//            @Override
//            public void callback(BigDecimal originNum, BigDecimal newNum) {
//                if (mDishCache.order == null) {
//                    mDishCache.orderDishesCache.personNum = newNum.intValue();
//                    refreshDinnerFoodTopLayout();
//                    ActionLog.addLog("修改成功,人数：" + newNum, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_TABLE_PERSON_CHANGED, "");
//                } else {
//                    notifyServiceChangePersonCount(newNum.intValue());
//                }
//            }
//        });
//        ActionLog.addLog("显示改人数界面", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_TABLE_PERSON_CHANGED, "");
//        DialogManager.showCustomDialog(mHost, fragment, CountKeyboardFragment.FRAGMENT_TAG);
//    }
//
//    /**
//     * 已下单到业务中心的订单修改人数时通知业务中心改人数
//     *
//     * @param count
//     */
//    private void notifyServiceChangePersonCount(final int count) {
//        ProgressManager.showProgressUncancel(mHost, "请稍后");
//        ActionLog.addLog("开始发送改人数请求 人数为:" + count, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_TABLE_PERSON_CHANGED, "");
//        TableBizProcessor.changePersonCount(mDishCache.order.orderID, count, new IResult() {
//            @Override
//            public void callBack(boolean result, String info) {
//                ProgressManager.closeProgress(mHost);
//                if (result) {
//                    mDishCache.order.personNum = count;
//                    ActionLog.addLog("改人数成功 人数为:" + count, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_TABLE_PERSON_CHANGED, "");
//                    refreshDinnerFoodTopLayout();
//                } else {
//                    ToastUtil.showToast(info);
//                    ActionLog.addLog("改人数失败 人数为:" + count, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_TABLE_PERSON_CHANGED, "");
//                }
//            }
//        });
//    }
//
//
//    /**
//     * 换桌
//     */
//    private void changeTable() {
//        if (mDishCache.order != null) {
//            OrderCache orderCache = mDishCache.order;
//            AirChangeTableProcessor airChangeTableProcessor = new AirChangeTableProcessor(mHost, orderCache, new IResponse<OrderCache>() {
//                @Override
//                public void callBack(boolean result, int code, String msg, OrderCache info) {
//                    if (result) {
//                        mDishCache.order = info;
//                        AppCache.getInstance().orderingTableID = mDishCache.order.fsmtableid;
//                        refreshDinnerFoodTopLayout();
//                        //TODO
//                        //DriverBus.call("orderDishesView/notifyall");
//                        DriverBus.broadcast("tableChanged", mDishCache);
//                    }
//                }
//            });
//            airChangeTableProcessor.startAirV3();
//        } else {
//            ToastUtil.showToast("请先下单");
//        }
//    }
//
//
//    public interface CallBack {
//        void backToTable();
//    }
//
//    private CallBack listener;
//
//    public void setOnCallBack(CallBack listener) {
//        this.listener = listener;
//    }
//
//
//}
