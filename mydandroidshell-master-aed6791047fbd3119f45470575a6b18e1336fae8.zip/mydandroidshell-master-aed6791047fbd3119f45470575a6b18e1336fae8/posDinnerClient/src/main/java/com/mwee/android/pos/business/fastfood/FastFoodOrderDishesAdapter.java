package com.mwee.android.pos.business.fastfood;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.component.member.net.model.MemberDishCouponBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.DisplayUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 快餐点菜列表适配器
 */
public class FastFoodOrderDishesAdapter extends BaseAdapter {

    public static final String DRIVER_TAG = "orderDishesAdapter";
    private Context mContext;
    private FastFoodDishCache dishCache;

    private Host mHost;

    private OnFastFoodOrderItemClickListener listener;

    public int selectPosition = -1;
    public ArrayList<MenuItem> modules;
    private int dp10 = DisplayUtil.dp2px(GlobalCache.getContext(), 10);
    private int dp5 = DisplayUtil.dp2px(GlobalCache.getContext(), 5);

    public FastFoodOrderDishesAdapter(Host host, FastFoodDishCache dishCache) {
        super();
        this.mContext = host.getContextWithinHost();
        this.mHost = host;
        this.dishCache = dishCache;
        modules = dishCache.menuItems;

    }

    @Override
    public int getCount() {
        return modules == null ? 0 : modules.size();
    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.view_fast_food_order_dishes_item, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.bindData(position);
        return convertView;
    }

    class ViewHolder implements View.OnClickListener {
        private View itemView;
        private View ingredient_line;
        private MenuItem menuItem;
        private LinearLayout mFastOrderItemInfoLayout;//点菜基本信息layout
        private ImageView mFastOrderItemStatusImg;//订单状态
        private TextView mFastOrderItemNameLabel;//菜品名称
        private TextView mFastOrderItemNoteContentLabel;//备注
        private TextView mFastOrderItemNumLabel;//点菜份数
        private TextView mFastOrderItemNumHintLabel;//沽清数量
        private TextView mFastOrderItemPriceLabel;//菜品金额
        private TextView mFastOrderItemNomalPriceLabel;//菜品原始金额

        private TextView mFastOrderItemTagMemberCoupon; // 菜品券 tag
        private TextView mFastOrderItemTagDiscountLabel;//折扣icon
        private TextView mDinnerOrderItemTagbuygiftTv;//买减
        private ImageView mFastOrderItemTagGiftImg;//赠送icon
        private ImageView mFastOrderItemTagMemberImg;//会员价icon

        private TextView mFastOrderItemDeleteOrReturnLabel;//删除icon
        private UnScollerListView mFastOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mFastOrderItemPackageLsv;//套餐明细列表
        private LinearLayout mFastOrderItemManagerLayout;//菜品管理布局
        private TextView mFastOrderItemNoteLabel;//菜品要求
        private TextView mFastOrderItemEditLabel;//菜品编辑
        private TextView mFastOrderItemDiscountLabel;//菜品优惠折扣


        public ViewHolder(View v) {
            itemView = v;
            mFastOrderItemInfoLayout = (LinearLayout) v.findViewById(R.id.mFastOrderItemInfoLayout);
            mFastOrderItemStatusImg = (ImageView) v.findViewById(R.id.mFastOrderItemStatusImg);
            mFastOrderItemNameLabel = (TextView) v.findViewById(R.id.mFastOrderItemNameLabel);
            mFastOrderItemNoteContentLabel = (TextView) v.findViewById(R.id.mFastOrderItemNoteContentLabel);
            mFastOrderItemNumLabel = (TextView) v.findViewById(R.id.mFastOrderItemNumLabel);
            mFastOrderItemNumHintLabel = (TextView) v.findViewById(R.id.mFastOrderItemNumHintLabel);
            mFastOrderItemPriceLabel = (TextView) v.findViewById(R.id.mFastOrderItemPriceLabel);
            mFastOrderItemNomalPriceLabel = (TextView) v.findViewById(R.id.mFastOrderItemNomalPriceLabel);

            mFastOrderItemTagDiscountLabel = (TextView) v.findViewById(R.id.mFastOrderItemTagDiscountLabel);
            mFastOrderItemTagGiftImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagGiftImg);
            mFastOrderItemTagMemberImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagMemberImg);
            mDinnerOrderItemTagbuygiftTv = (TextView) v.findViewById(R.id.mDinnerOrderItemTagbuygiftTv);
            mFastOrderItemTagMemberCoupon = (TextView) v.findViewById(R.id.mFastOrderItemTagMemberCoupon);

            mFastOrderItemDeleteOrReturnLabel = (TextView) v.findViewById(R.id.mFastOrderItemDeleteOrReturnLabel);
            mFastOrderItemIngredientLsv = (UnScollerListView) v.findViewById(R.id.mFastOrderItemIngredientLsv);
            mFastOrderItemPackageLsv = (CompatibleListView) v.findViewById(R.id.mFastOrderItemPackageLsv);
            ingredient_line = v.findViewById(R.id.ingredient_line);
            mFastOrderItemManagerLayout = (LinearLayout) v.findViewById(R.id.mFastOrderItemManagerLayout);
            mFastOrderItemNoteLabel = (TextView) v.findViewById(R.id.mFastOrderItemNoteLabel);
            mFastOrderItemEditLabel = (TextView) v.findViewById(R.id.mFastOrderItemEditLabel);
            mFastOrderItemDiscountLabel = (TextView) v.findViewById(R.id.mFastOrderItemDiscountLabel);
            mFastOrderItemDeleteOrReturnLabel.setOnClickListener(this);
            mFastOrderItemDiscountLabel.setOnClickListener(this);
            mFastOrderItemInfoLayout.setOnClickListener(this);
            mFastOrderItemEditLabel.setOnClickListener(this);
        }

        /**
         * ui处理
         *
         * @param position
         */
        public void bindData(int position) {
            menuItem = modules.get(position);
            removeAllLine();
            mFastOrderItemNameLabel.setText(menuItem.name);
            //设置备注显示
            String note = getMenuItemNoteContent().trim();
            if (TextUtils.isEmpty(note)) {
                mFastOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mFastOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mFastOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mFastOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint);
            } else {
                mFastOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }
            //时价菜 价格加样式
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid()) {
                mFastOrderItemPriceLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mFastOrderItemPriceLabel.setText("时价");
                mFastOrderItemPriceLabel.setOnClickListener(this);
            } else {
                mFastOrderItemPriceLabel.setBackgroundResource(0);
                mFastOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                mFastOrderItemPriceLabel.setOnClickListener(null);
            }

            if (menuItem.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && (menuItem.menuBiz.checkBuyGift() || menuItem.isGift() || menuItem.useMemberPrice || menuItem.menuBiz.selectDiscount != null || (menuItem.menuBiz.checkSpecialPrice()) && menuItem.menuBiz.bugGiftItem == null)) {
                mFastOrderItemNomalPriceLabel.setVisibility(View.VISIBLE);
                mFastOrderItemNomalPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNomalPriceLabel);
            } else {
                mFastOrderItemNomalPriceLabel.setVisibility(View.GONE);
            }

            //优惠信息tag
            showCouponTag(menuItem, mFastOrderItemTagGiftImg, mFastOrderItemTagDiscountLabel, mFastOrderItemTagMemberImg, mDinnerOrderItemTagbuygiftTv, mFastOrderItemTagMemberCoupon);

            //配料菜列表展示
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                ingredient_line.setVisibility(View.VISIBLE);
                mFastOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<MenuItem> ingredientAdapter = (CommonAdapter<MenuItem>) mFastOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<MenuItem>(mContext, menuItem.menuBiz.selectedModifier, R.layout.item_dinner_food_order_ingredient) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem ingredient, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.tv_ingredient_name);
                            name.setText(ingredient.name);

                            TextView count = (TextView) viewHolder.getView(R.id.tv_ingredient_num);
                            TextView normalPrice = (TextView) viewHolder.getView(R.id.tv_ingredient_normal_price);
                            TextView price = (TextView) viewHolder.getView(R.id.tv_ingredient_price);

                            String voidInfo = "";

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }

                            BigDecimal voidNum = ingredient.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(ingredient.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum + "]";
                            }
                            BigDecimal buyAllNum = ingredient.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString() + voidInfo);
                            } else {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString());
                            }
                            price.setText(Calc.formatShow(ingredient.menuBiz.totalPrice.multiply(tempBuyNum.subtract(tempVoidNum)), RoundConfig.ROUND_SINGLE_PRICE));

                            if (/*item.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && */(ingredient.menuBiz.checkBuyGift() || ingredient.isGift() || ingredient.useMemberPrice || ingredient.menuBiz.selectDiscount != null || (ingredient.menuBiz.checkSpecialPrice()) && ingredient.menuBiz.bugGiftItem == null)) {
                                normalPrice.setVisibility(View.VISIBLE);
                                normalPrice.setText(Calc.formatShow(ingredient.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                                com.mwee.android.pos.util.TextUtils.addLine(normalPrice);
                            } else {
                                normalPrice.setVisibility(View.GONE);
                            }

                            //优惠信息tag
                            showCouponTag(ingredient, viewHolder.getView(R.id.iv_gift_tag), viewHolder.getView(R.id.tv_discount_tag),
                                    viewHolder.getView(R.id.iv_member_tag), viewHolder.getView(R.id.tv_buygift_tag), viewHolder.getView(R.id.mFastOrderItemTagMemberCoupon));
                        }
                    };
                    mFastOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(menuItem.menuBiz.selectedModifier);
                }
            } else {
                ingredient_line.setVisibility(View.GONE);
                mFastOrderItemIngredientLsv.setVisibility(View.GONE);
            }

            //套餐明细显示
            if (menuItem.supportPackage()) {
                mFastOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mFastOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(mContext, allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name + getMenuItemNoteContent(data)));

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }
                            BigDecimal voidNum = data.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(data.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            String voidInfo = "";
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum.stripTrailingZeros().toPlainString() + "]";
                            }
                            BigDecimal buyAllNum = data.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.fastOrderModel != null && dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                viewHolder.setText(R.id.numTv, TextUtils.concat(voidInfo, buyAllNum.stripTrailingZeros().toPlainString(), "份"));
                            } else {
                                viewHolder.setText(R.id.numTv, TextUtils.concat(buyAllNum.stripTrailingZeros().toPlainString(), "份"));
                            }
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                            /*if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mFastOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mFastOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //根据下单状态控制ui显示
            if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                mFastOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_ordered);
                //称重菜未称重 数量加样式
                if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                    mFastOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mFastOrderItemNumLabel.setOnClickListener(this);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                } else {
                    mFastOrderItemNumLabel.setOnClickListener(null);
                    mFastOrderItemNumLabel.setBackgroundResource(0);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }
                //退菜数据展示
                if (menuItem.hasAllVoid()) {
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                    addAllLine();
                } else {
                    mFastOrderItemDeleteOrReturnLabel.setText("退");
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                    mFastOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
                } else {
                    mFastOrderItemNumHintLabel.setVisibility(View.GONE);
                }
                //单个菜品操作控制
                mFastOrderItemNoteLabel.setVisibility(View.GONE);

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_FFEEAA));
            } else {
                //显示删除按钮
                mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                mFastOrderItemDeleteOrReturnLabel.setText("删");
                //新菜
                mFastOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_new);
                mFastOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mFastOrderItemNumLabel.setOnClickListener(this);
                //沽清数量显示
                BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(menuItem.currentUnit.fiOrderUintCd);
                if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                    mFastOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumHintLabel.setText(String.format(Locale.SIMPLIFIED_CHINESE, "剩%s", sellOutCount + menuItem.currentUnit.fsOrderUint));
                } else {
                    mFastOrderItemNumHintLabel.setVisibility(View.GONE);
                }
                //菜品操作菜单事件监听
                mFastOrderItemNoteLabel.setVisibility(View.VISIBLE);
                mFastOrderItemNoteLabel.setOnClickListener(this);

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.white));
            }

            //选中状态处理
            if (selectPosition == position && !menuItem.hasAllVoid()) {
                mFastOrderItemManagerLayout.setVisibility(View.VISIBLE);
                if (isShowEditItem() || menuItem.supportPackage()) {
                    mFastOrderItemEditLabel.setVisibility(View.VISIBLE);
                } else {
                    mFastOrderItemEditLabel.setVisibility(View.GONE);
                }
            } else {
                mFastOrderItemManagerLayout.setVisibility(View.GONE);
            }
        }

        /**
         * 显示优惠信息tag
         *
         * @param item        菜品
         * @param giftTag     赠送tag
         * @param discountTag 折扣tag
         * @param memberTag   会员tag
         * @param bugGiftTag  买减tag
         */
        private void showCouponTag(MenuItem item, View giftTag, TextView discountTag, View memberTag, View bugGiftTag, TextView memberCouponView) {
            giftTag.setVisibility(View.GONE);
            discountTag.setVisibility(View.GONE);
            memberTag.setVisibility(View.GONE);
            bugGiftTag.setVisibility(View.GONE);
            memberCouponView.setVisibility(View.GONE);
            if (item.menuBiz.menuSellType == MenuSellType.GIFT || (item.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && item.menuBiz.giftNum.compareTo(item.menuBiz.buyNum.subtract(item.menuBiz.voidNum)) == 0)) {
                giftTag.setVisibility(View.VISIBLE);
            }
            if (item.useMemberPrice) {
                memberTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.bugGiftItem != null) {
                bugGiftTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.selectDiscount != null) {
                discountTag.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - item.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    discountTag.setText(rate0.toString() + "折");
                } else {
                    discountTag.setText(rate.toString() + "折");
                }
            }
            MemberDishCouponBean couponBean = item.memberDishCouponForDisplay();
            if (couponBean != null) {
                memberCouponView.setVisibility(View.VISIBLE);
                memberCouponView.setText(couponBean.title);
            }
        }

        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (v.getId()) {
                case R.id.mFastOrderItemNumLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vQtyAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    trace("菜品改价格->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_NUMBER);
                                    listener.doChangeOrderedMenuNumber(menuItem, userDBModel);
                                } else {
                                    trace("未下单菜品修改数量->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_NUMBER);
                                    listener.doChangeMenuBuyNum(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemInfoLayout:
                    selectPosition = modules.indexOf(menuItem);
                    notifyDataSetChanged();
                    break;
                case R.id.mFastOrderItemPriceLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                trace("菜品改价格->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_PRICE);
                                if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    listener.doChangeOrderedMenuPrice(menuItem, userDBModel);
                                } else {
                                    listener.doChangeMenuPrice(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemNoteLabel:
                    trace("菜品要求->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_REQUEST);
                    listener.doEditorMenuNoteContent(menuItem);
                    break;
                case R.id.mFastOrderItemEditLabel:
                    trace("菜品编辑->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_EDITOR);
                    doHandlerMenuEdit();
                    break;
                case R.id.mFastOrderItemDeleteOrReturnLabel:
                    if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        PermissionsUtil.requestPermissionBackMenu(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, menuItem, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    trace("菜品退菜-> orderId:" + dishCache.fastOrderModel.orderId + " name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_RETREAT);
                                    listener.doRetreatDish(menuItem, userDBModel, msg);
                                }
                            }
                        });
                    } else {
                        trace("菜品删除->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_REMOVE);
                        listener.doDeleteMenu(menuItem);
                    }
                    break;
                case R.id.mFastOrderItemDiscountLabel:
                    trace("菜品优惠折扣-> orderId:" + dishCache.fastOrderModel.orderId + " name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_DISCOUNT);
                    listener.doChangeMenuPrivilege(menuItem);
                    break;
                default:
                    break;
            }
        }


        /**
         * 是否显示菜品编辑按钮
         *
         * @return
         */
        public boolean isShowEditItem() {
            if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                return menuItem.supportIngredient();
            } else {
                return ((menuItem.config & 2) == 2  //多规格
                        || (/*(menuItem.config & 1) == 1 &&*/ (menuItem.config & 4) == 4) //多做法
                        || (menuItem.config & 1024) == 1024) //有配料
                        || menuItem.supportPackage();
            }
        }

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
           /* if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            if (menuItem.menuBiz.selectedExtraStr != null) {
                demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
            }
            return demand.toString();
        }

        /**
         * 获取下单时间
         *
         * @return
         */
        public String getOrderTime() {
            StringBuilder statusStr = new StringBuilder();
            long time = DateUtil.compareDate(menuItem.menuBiz.createTime, DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT), DateUtil.DATE_VISUAL14FORMAT) / (1000 * 60);
            if (time == 0) {
                time = 1;
            }
            if (time > 60) {
                statusStr.append("  ").append("1小时＋");
            } else {
                statusStr.append("  ").append(time).append("分钟");
            }
            return statusStr.toString();
        }

        /**
         * 处理菜品编辑操作
         */
        private void doHandlerMenuEdit() {
            boolean isOrdered = dishCache.fastOrderModel != null && dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID);
            if (menuItem.supportPackage()) { //套餐
                if (isOrdered) {
                    // 已下单套餐菜品编辑
                    editPackageItems(menuItem);
                } else {
                    OrderDishesBizUtil.processPackage((Host) mContext, menuItem, dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID), dishCache.fastOrderModel.isMember, new IResponse<PackageItemEditViewBean>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, PackageItemEditViewBean info) {
                            if (result) {
                                listener.onPackageMenuChanged(info.menu);
                                notifyDataSetChanged();
                            } else {
                                ToastUtil.showToast(msg);
                            }
                        }
                    });
                }
            } else {  //配料菜-多规格-多做法
                if (isOrdered) {
                    // 已下单的配料菜修改
                    editIngredient(menuItem);
                } else {
                    final UnitModel oldUnit = menuItem.currentUnit;
                    final BigDecimal oldBuyNum = menuItem.menuBiz.buyNum;
                    OrderDishesBizUtil.processIngredient((Host) mContext, menuItem, new IResponse<MenuItem>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, MenuItem info) {
                            if (result) {
                                listener.doEditMenuInfo(oldUnit, oldBuyNum, info);
                            } else {
                                ToastUtil.showToast(msg);
                            }
                        }
                    }, dishCache.fastOrderModel.isMember);
                }
            }
        }

        /**
         * 编辑套餐子项
         *
         * @param menuItem 套餐菜品
         */
        private void editPackageItems(MenuItem menuItem) {
            MenuItem itemClone = menuItem.clone();
            OrderDishesBizUtil.processPackage((Host) mContext, itemClone, true, dishCache.fastOrderModel.isMember, new IResponse<PackageItemEditViewBean>() {
                @Override
                public void callBack(boolean result, int code, String msg, PackageItemEditViewBean info) {
                    listener.doChangePackageItems(menuItem, info.menu, info);
                }
            });
        }

        /**
         * 编辑配料
         *
         * @param menuItem
         */
        private void editIngredient(final MenuItem menuItem) {
            MenuItem itemClone = menuItem.clone();
            OrderDishesBizUtil.processIngredient((Host) mContext, itemClone, true, new IResponse<MenuItem>() {
                @Override
                public void callBack(boolean result, int code, String msg, MenuItem info) {
                    listener.doChangeIngredient(menuItem, info);
                }
            }, dishCache.fastOrderModel.isMember);
        }

        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemPriceLabel);
        }
    }

    /**
     * 菜品列表操作回调接口
     */
    public interface OnFastFoodOrderItemClickListener {
        /**
         * 未下单菜品->修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel);

        /**
         * 删除菜品
         *
         * @param item
         */
        void doDeleteMenu(MenuItem item);

        /**
         * 修改菜品要求
         *
         * @param item
         */
        void doEditorMenuNoteContent(MenuItem item);

        /**
         * 修改菜品折扣
         *
         * @param item
         */
        void doChangeMenuPrivilege(MenuItem item);


        /**
         * 未下单菜品->编辑
         *
         * @param oldUnit
         * @param oldBuyNum
         * @param item
         */
        void doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item);


        /**
         * 已下单菜品—>退菜
         *
         * @param item
         * @param userDBModel
         * @param msg
         */
        void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg);

        /**
         * 已下单菜品—>菜品编辑
         *
         * @param menuItem
         * @param info
         */
        void doChangeIngredient(MenuItem menuItem, MenuItem info);

        /**
         * 未下单菜品->价格
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuPrice(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品->改价格
         *
         * @param menuItem
         * @param userDBModel
         */
        void doChangeOrderedMenuPrice(MenuItem menuItem, UserDBModel userDBModel);

        /**
         * 已下单套餐->菜品编辑
         *
         * @param menuItem
         * @param info
         */
        void doChangePackageItems(MenuItem menuItem, MenuItem info, PackageItemEditViewBean otherData);


        /**
         * 套餐信息改变
         *
         * @param menuItem
         */
        void onPackageMenuChanged(MenuItem menuItem);
    }

    public void setOnFastFoodOrderItemClickListener(OnFastFoodOrderItemClickListener listener) {
        this.listener = listener;
    }


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();

    }

    private void trace(String msg, String action) {
        ActionLog.addLog("点菜页->" + msg, dishCache.fastOrderModel.orderId, dishCache.fastOrderModel.mealNumber, action, "");
    }

}
