package com.mwee.android.pos.air.business.setting.api;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.takeout.TakeOutAutoMappedRequest;
import com.mwee.android.pos.component.takeout.TakeOutAutoMappedResponse;
import com.mwee.android.pos.component.takeout.TakeOutBindStatus;
import com.mwee.android.pos.component.takeout.TakeOutBindStatusRequest;
import com.mwee.android.pos.component.takeout.TakeOutBindStatusResponse;
import com.mwee.android.pos.component.takeout.TakeOutMappedUploadListRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemContainer;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemListRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemListResponse;
import com.mwee.android.pos.db.base.META;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 外卖相关网络请求接口
 * Created by qinwei on 2018/3/13.
 */

public class TakeOutApi {

    /**
     * 获取饿了么外卖绑定链接
     *
     * @return
     */
    public static String getElemeBindUrl() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String url;
        if (!BaseConfig.isProduct()) {
            url = NetworkConstans.ELEME_BING_URL_TEST;
        } else {
            url = NetworkConstans.ELEME_BING_URL;
        }
        url = url.replace("SHOPGUID", shopId);
        return url;
    }

    /**
     * 获取美团外卖绑定链接
     *
     * @return
     */
    public static String getMeituanBindUrl() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String url;
        if (!BaseConfig.isProduct()) {
            url = NetworkConstans.MEITUAN_BING_URL_TEST;
        } else {
            url = NetworkConstans.MEITUAN_BING_URL;
        }
        url = url.replace("SHOPGUID", shopId);
        return url;
    }

    /**
     * 加载外卖绑定状态
     *
     * @param source
     * @param callback
     */
    public static void loadTakeOutBindStatus(String source, ResultCallback<TakeOutBindStatus> callback) {
        TakeOutBindStatusRequest request = new TakeOutBindStatusRequest();
        request.request_id = UUID.randomUUID().toString();
        request.shop_guid = AppCache.getInstance().fsShopGUID;
        request.takeawaySource = source;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutBindStatusResponse) {
                    TakeOutBindStatusResponse response = (TakeOutBindStatusResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 加载菜品映射列表
     *
     * @param source      来源 {@link com.mwee.android.pos.util.Constants}
     * @param map_status  关联状态
     * @param currentPage 当前页数
     * @param callback
     */
    public static void loadTakeOutMenuList(String source, String map_status, int currentPage, ResultCallback<TakeOutMenuItemContainer> callback) {
        TakeOutMenuItemListRequest request = new TakeOutMenuItemListRequest();
        request.request_id = UUID.randomUUID().toString();
        request.map_status = map_status;
        request.shop_guid = AppCache.getInstance().fsShopGUID;
        request.takeawaySource = source;
        request.pageNo = currentPage;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutMenuItemListResponse) {
                    TakeOutMenuItemListResponse response = (TakeOutMenuItemListResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 外卖菜品自动映射
     *
     * @param source
     * @param callback
     */
    public static void loadTakeOutMenuAutoMatch(String source, ResultCallback<String> callback) {
        TakeOutAutoMappedRequest request = new TakeOutAutoMappedRequest();
        request.request_id = UUID.randomUUID().toString();
        request.shop_guid = AppCache.getInstance().fsShopGUID;
        request.takeawaySource = source;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutAutoMappedResponse) {
                    TakeOutAutoMappedResponse response = (TakeOutAutoMappedResponse) responseData.responseBean;
                    callback.onSuccess(response.data.auto_map_count + "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 手动上传映射菜品
     *
     * @param source          外卖渠道来源
     * @param takeOutMenuItem
     * @param callback
     */
    public static void loadMapper(String source, TakeOutMenuItem takeOutMenuItem, ResultCallback<String> callback) {
        TakeOutMappedUploadListRequest request = new TakeOutMappedUploadListRequest();
        request.request_id = UUID.randomUUID().toString();
        request.shop_guid = AppCache.getInstance().fsShopGUID;
        request.takeaway_source = source;
        List<TakeOutMenuItem> items = new ArrayList<>();
        items.add(takeOutMenuItem);
        request.items = items;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess(responseData.responseBean.msg);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }
}
