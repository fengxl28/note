package com.mwee.android.pos.air.business.member.entity;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberScoreGiftRuleUpdateRequest extends BaseMemberParam {
    public int m_shopid;
    public int charge_min_limit = 1;//单次储值下限金额 下限金额 单位：元
    public int can_recharge_any_amount = 1;//是否允许充任意金额 0=>NO, 1=> YES

    public String is_score;//是否开启积分
    public BigDecimal cost_money_unit;//每消费多少
    public int increase_bonus;//赠送积分

    public String cost_bonus_unit;//每使用 积分
    public String reduce_money;   //兑换金额

    public String is_clear;

    public String clear_day;


    public MemberScoreGiftRuleUpdateRequest() {
    }
}
