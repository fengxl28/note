package com.mwee.android.pos.base;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;


import com.mwee.android.pos.dinner.R;

import java.util.ArrayList;

/**
 * Created by qinwei on 2016/4/6 18:21
 * email:qinwei_it@163.com
 */
public abstract class BaseViewPagerFragment<T> extends BaseMwFragment implements ViewPager.OnPageChangeListener {
    protected DataPageAdapter adapter;
    protected ArrayList<T> modules = new ArrayList<>();
    protected ViewPager mViewPager;

    @Override
    protected void initView(View view) {
        mViewPager = (ViewPager) view.findViewById(R.id.mViewPager);
        mViewPager.addOnPageChangeListener(this);
        mViewPager.setOffscreenPageLimit(2);
        adapter = new DataPageAdapter(getChildFragmentManager());
        setAdapter(adapter);
    }

    public void setAdapter(PagerAdapter adapter) {
        mViewPager.setAdapter(adapter);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }

    @Override
    public void onPageSelected(int position) {
    }


    public class DataPageAdapter extends FragmentStatePagerAdapter {

        public DataPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return getFragmentAtPosition(position);
        }


        @Override
        public int getCount() {
            return modules.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return getPageTitleAtPosition(position);
        }
    }

    protected abstract CharSequence getPageTitleAtPosition(int position);

    /**
     * @param position
     * @return
     */
    public abstract Fragment getFragmentAtPosition(int position);
}
