package com.mwee.android.pos.business.bill.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderCoupon;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DisplayUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * 订单详情-订单明细
 */
public class OrderDetailsView extends LinearLayout {

    public List<MenuItem> mMenuItemList = new ArrayList<>();
    public List<TempAppOrderDetail> orderDetailSparseArray = null;
    public List<PayModel> mPayList = new ArrayList<>();
    public List<TempAppOrderCoupon> mCouponList = new ArrayList<>();//优惠明细List
    public OrderCache mOrderCache;

    private View rootView;
    private Host mHost;
    private ListView lv_menu_item_list;
    private ListView lv_pay_list;
    private ListView lv_coupon_list;//优惠明细ListView
    private LinearLayout ll_coupon;//优惠明细Lin
    private CommonAdapter<PayModel> mPayAdapter;
    private CommonAdapter<MenuItem> mMenuItemAdapter;
    private CommonAdapter<TempAppOrderDetail> mNetMenuItemAdapter;
    private CommonAdapter<TempAppOrderCoupon> mCouponAdapter;//优惠明细Adapter
    private TextView tv_menu_item_preferential_way;//优惠方式

    public OrderDetailsView(Context context) {
        super(context);
        initView(context);
    }

    public OrderDetailsView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public OrderDetailsView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context mContext) {
        View.inflate(mContext, R.layout.view_order_details, this);
        orderDetailSparseArray = new ArrayList<TempAppOrderDetail>();
        rootView = findViewById(R.id.rootView);
        tv_menu_item_preferential_way = findViewById(R.id.tv_menu_item_preferential_way);
        ll_coupon = findViewById(R.id.ll_coupon);
        lv_menu_item_list = findViewById(R.id.lv_menu_item_list);
        lv_pay_list = findViewById(R.id.lv_pay_list);
        lv_coupon_list = findViewById(R.id.lv_coupon_list);

        initAdapter();
        if (!ListUtil.isEmpty(mCouponList)) {
            ll_coupon.setVisibility(VISIBLE);
        } else {
            ll_coupon.setVisibility(GONE);
        }
        refreshAdapter();
    }

    private void initAdapter() {
        mMenuItemAdapter = new MenuItemAdapter(getContext(), mMenuItemList, R.layout.layout_dinner_order_details_item);
        mNetMenuItemAdapter = new NetMenuItemAdapter(getContext(), orderDetailSparseArray, R.layout.layout_dinner_order_details_item);
        mPayAdapter = new CommonAdapter<PayModel>(getContext(), mPayList, R.layout.layout_dinner_order_details_pay_item) {
            @Override
            public void convert(ViewHolder viewHolder, PayModel item, int position) {
                if (item == null || item.data == null) {
                    return;
                }
                String price = Calc.formatShow(item.payAmount);
                viewHolder.setText(R.id.select_pay_amount, price);
                if (PayType.isHung(item.data)) {
                    viewHolder.setText(R.id.select_pay_type, item.data.payName + " " + item.showNote);
                } else {
                    viewHolder.setText(R.id.select_pay_type, item.data.payName);
                }

                if (item.isPayPre()) {
                    viewHolder.setVisibility(R.id.tv_select_pay_pre, View.VISIBLE);
                } else {
                    viewHolder.setVisibility(R.id.tv_select_pay_pre, View.INVISIBLE);
                }
            }
        };
        mCouponAdapter = new CommonAdapter<TempAppOrderCoupon>(getContext(), mCouponList, R.layout.layout_dinner_order_details_pay_item) {
            @Override
            public void convert(ViewHolder viewHolder, TempAppOrderCoupon item, int position) {
                String price = Calc.formatShow(item.reducePrice);
                viewHolder.setText(R.id.select_pay_amount, price);
                viewHolder.setText(R.id.select_pay_type, item.couponTitle);
                viewHolder.setVisibility(R.id.tv_select_pay_pre, View.INVISIBLE);
            }
        };
    }

    private void refreshAdapter() {
        if (!ListUtil.isEmpty(mMenuItemList)) {
            tv_menu_item_preferential_way.setVisibility(VISIBLE);
            lv_menu_item_list.setAdapter(mMenuItemAdapter);
        } else {
            tv_menu_item_preferential_way.setVisibility(GONE);
            lv_menu_item_list.setAdapter(mNetMenuItemAdapter);
        }
        lv_pay_list.setAdapter(mPayAdapter);
        lv_coupon_list.setAdapter(mCouponAdapter);

        if (mMenuItemAdapter != null) {
//            mMenuItemAdapter.setData(mMenuItemList);
            mMenuItemAdapter.notifyDataSetChanged();
        }
        if (mNetMenuItemAdapter != null) {
            mNetMenuItemAdapter.setData(orderDetailSparseArray);
        }
        if (mPayAdapter != null) {
            mPayAdapter.setData(mPayList);
        }
        if (mCouponAdapter != null) {
            mCouponAdapter.setData(mCouponList);
        }
    }

    public void setParams(Host mHost, List<MenuItem> menuItemList, List<PayModel> payList, List<TempAppOrderCoupon> couponList) {
        this.mHost = mHost;
        if (!ListUtil.isEmpty(menuItemList)) {
//            this.mMenuItemList = menuItemList;
            for (MenuItem item : menuItemList) {
                // 餐标/低消补充菜品不放进列表
                if (DinnerStandardUtil.isStandardMenu(item.itemID)) {
                    continue;
                }
                this.mMenuItemList.add(item);
            }
        }
        if (!ListUtil.isEmpty(payList)) {
            this.mPayList = payList;
        }
        if (!ListUtil.isEmpty(couponList)) {
            this.mCouponList = couponList;
        }
        refreshAdapter();
    }

    /**
     * 设置外卖数据
     *
     * @param mHost
     * @param menuItemList
     * @param payList
     */
    public void setNetParams(Host mHost, List<TempAppOrderDetail> menuItemList, List<PayModel> payList, List<TempAppOrderCoupon> couponList) {
        this.mHost = mHost;
        if (!ListUtil.isEmpty(menuItemList)) {
            this.orderDetailSparseArray = menuItemList;
        }
        if (!ListUtil.isEmpty(payList)) {
            this.mPayList = payList;
        }
        if (!ListUtil.isEmpty(couponList)) {
            this.mCouponList = couponList;
        }
        refreshAdapter();
    }

    class MenuItemAdapter extends CommonAdapter<MenuItem> {
        private int dp10 = DisplayUtil.dp2px(GlobalCache.getContext(), 10);
        private int dp5 = DisplayUtil.dp2px(GlobalCache.getContext(), 5);

        private View itemView;
        private TextView mDinnerOrderItemNameLabel;//菜品名称
        private TextView mDinnerOrderItemNoteContentLabel;//备注
        private TextView mDinnerOrderItemNumLabel;//点菜份数
        private TextView mDinnerOrderItemNumHintLabel;//沽清数量
        private TextView mDinnerOrderItemNomalPriceLabel;//菜品原始金额
        private TextView mDinnerOrderItemPriceLabel;//菜品金额

        private TextView mDinnerOrderItemTagDiscountLabel;//折扣icon
        private TextView mDinnerOrderItemTagbuygiftTv;//买减
        private ImageView mDinnerOrderItemTagGiftImg;//赠送icon
        private ImageView mDinnerOrderItemTagMemberImg;//会员价icon

        private UnScollerListView mDinnerOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mDinnerOrderItemPackageLsv;//套餐明细列表

        public MenuItemAdapter(Context context, List<MenuItem> dataList, int layoutId) {
            super(context, dataList, layoutId);
        }

        @Override
        public void convert(ViewHolder viewHolder, MenuItem menuItem, int position) {
            initViews(viewHolder, menuItem);
            bindData(menuItem, position);
        }

        private void initViews(ViewHolder holder, MenuItem menuItem) {
            itemView = holder.getConvertView();
            mDinnerOrderItemNameLabel = holder.getView(R.id.mDinnerOrderItemNameLabel);
            mDinnerOrderItemNoteContentLabel = holder.getView(R.id.mDinnerOrderItemNoteContentLabel);
            mDinnerOrderItemNumLabel = holder.getView(R.id.mDinnerOrderItemNumLabel);
            mDinnerOrderItemNumHintLabel = holder.getView(R.id.mDinnerOrderItemNumHintLabel);
            mDinnerOrderItemPriceLabel = holder.getView(R.id.mDinnerOrderItemPriceLabel);
            mDinnerOrderItemNomalPriceLabel = holder.getView(R.id.mDinnerOrderItemNomalPriceLabel);

            mDinnerOrderItemTagDiscountLabel = holder.getView(R.id.mDinnerOrderItemTagDiscountLabel);
            mDinnerOrderItemTagGiftImg = holder.getView(R.id.mDinnerOrderItemTagGiftImg);
            mDinnerOrderItemTagMemberImg = holder.getView(R.id.mDinnerOrderItemTagMemberImg);
            mDinnerOrderItemTagbuygiftTv = holder.getView(R.id.mDinnerOrderItemTagbuygiftTv);

            mDinnerOrderItemIngredientLsv = holder.getView(R.id.mDinnerOrderItemIngredientLsv);
            mDinnerOrderItemPackageLsv = holder.getView(R.id.mDinnerOrderItemPackageLsv);
        }

        public void bindData(MenuItem menuItem, int position) {
            removeAllLine();
            mDinnerOrderItemNameLabel.setText(menuItem.name);
            mDinnerOrderItemNameLabel.setBackgroundResource(0);
            mDinnerOrderItemNameLabel.setPadding(0, 0, 0, 0);
            //设置备注显示
            String note = getMenuItemNoteContent(menuItem).trim();
            if (TextUtils.isEmpty(note)) {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mDinnerOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint);
            } else {
                mDinnerOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }

            mDinnerOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
            mDinnerOrderItemPriceLabel.setOnClickListener(null);

            if (menuItem.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && (menuItem.menuBiz.checkBuyGift() || menuItem.isGift() || menuItem.useMemberPrice || menuItem.menuBiz.selectDiscount != null || (menuItem.menuBiz.checkSpecialPrice()) && menuItem.menuBiz.bugGiftItem == null)) {
                mDinnerOrderItemNomalPriceLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNomalPriceLabel.setText(Tools.getCurrency() + Calc.formatShow(menuItem.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNomalPriceLabel);
            } else {
                mDinnerOrderItemNomalPriceLabel.setVisibility(View.GONE);
            }

            //优惠信息tag
            showCouponTag(menuItem, mDinnerOrderItemTagGiftImg, mDinnerOrderItemTagDiscountLabel, mDinnerOrderItemTagMemberImg, mDinnerOrderItemTagbuygiftTv);

            //配料菜列表展示
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                mDinnerOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<MenuItem> ingredientAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<MenuItem>(getContext(), menuItem.menuBiz.selectedModifier, R.layout.item_dinner_order_details_ingredient) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem item, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.tv_ingredient_name);
                            name.setText(item.name);

                            TextView count = (TextView) viewHolder.getView(R.id.tv_ingredient_num);
                            TextView normalPrice = (TextView) viewHolder.getView(R.id.tv_ingredient_normal_price);
                            TextView price = (TextView) viewHolder.getView(R.id.tv_ingredient_price);

                            String voidInfo = "";

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }

                            BigDecimal voidNum = item.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(item.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum + "]";
                            }
                            BigDecimal buyAllNum = item.menuBiz.buyNum.multiply(tempBuyNum);
                            if (mOrderCache != null && mOrderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString() + voidInfo);
                            } else {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString());
                            }
                            price.setText(Calc.formatShow(item.menuBiz.totalPrice.multiply(tempBuyNum.subtract(tempVoidNum)), RoundConfig.ROUND_SINGLE_PRICE));

                            if (/*item.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && */(item.menuBiz.checkBuyGift() || item.isGift() || item.useMemberPrice || item.menuBiz.selectDiscount != null || (item.menuBiz.checkSpecialPrice()) && item.menuBiz.bugGiftItem == null)) {
                                normalPrice.setVisibility(View.VISIBLE);
                                normalPrice.setText(Calc.formatShow(item.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                                com.mwee.android.pos.util.TextUtils.addLine(normalPrice);
                            } else {
                                normalPrice.setVisibility(View.GONE);
                            }

                            //优惠信息tag
                            showCouponTag(item, viewHolder.getView(R.id.iv_gift_tag), viewHolder.getView(R.id.tv_discount_tag),
                                    viewHolder.getView(R.id.iv_member_tag), viewHolder.getView(R.id.tv_buygift_tag));
                        }
                    };
                    mDinnerOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(menuItem.menuBiz.selectedModifier);
                }
            } else {
                mDinnerOrderItemIngredientLsv.setVisibility(View.GONE);
            }

            //套餐明细显示
            if (menuItem.supportPackage()) {
                mDinnerOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(getContext(), allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name) + getMenuItemNoteContent(data));
                            viewHolder.setText(R.id.numTv, TextUtils.concat(data.menuBiz.buyNum.toPlainString(), "份"));
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                           /* if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mDinnerOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mDinnerOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //退菜数据展示
            if (menuItem.hasAllVoid()) {
                addAllLine();
            } else {
                removeAllLine();
            }

            if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                mDinnerOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
            } else {
                mDinnerOrderItemNumHintLabel.setVisibility(View.GONE);
            }
        }

        /**
         * 显示优惠信息tag
         *
         * @param item        菜品
         * @param giftTag     赠送tag
         * @param discountTag 折扣tag
         * @param memberTag   会员tag
         * @param bugGiftTag  买减tag
         */
        private void showCouponTag(MenuItem item, View giftTag, TextView discountTag, View memberTag, View bugGiftTag) {
            giftTag.setVisibility(View.GONE);
            discountTag.setVisibility(View.GONE);
            memberTag.setVisibility(View.GONE);
            bugGiftTag.setVisibility(View.GONE);
            if (item.menuBiz.menuSellType == MenuSellType.GIFT || (item.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && item.menuBiz.giftNum.compareTo(item.menuBiz.buyNum.subtract(item.menuBiz.voidNum)) == 0)) {
                giftTag.setVisibility(View.VISIBLE);
            }
            if (item.useMemberPrice) {
                memberTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.bugGiftItem != null) {
                bugGiftTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.selectDiscount != null) {
                discountTag.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - item.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    discountTag.setText(rate0.toString() + "折");
                } else {
                    discountTag.setText(rate.toString() + "折");
                }
            }
        }

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent(MenuItem menuItem) {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
           /* if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);

            return demand.toString();
        }

        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemPriceLabel);
        }
    }

    /**
     * 外卖菜品明细Adapter
     */
    class NetMenuItemAdapter extends CommonAdapter<TempAppOrderDetail> {
        private int dp10 = DisplayUtil.dp2px(GlobalCache.getContext(), 10);
        private int dp5 = DisplayUtil.dp2px(GlobalCache.getContext(), 5);

        private View itemView;
        private TextView mDinnerOrderItemNameLabel;//菜品名称
        private TextView mDinnerOrderItemNoteContentLabel;//备注
        private TextView mDinnerOrderItemNumLabel;//点菜份数
        private TextView mDinnerOrderItemNumHintLabel;//沽清数量
        private TextView mDinnerOrderItemNomalPriceLabel;//菜品原始金额
        private TextView mDinnerOrderItemPriceLabel;//菜品金额
        private LinearLayout mDinnerOrderItemPreferentialWay;//优惠方式Lin

        private TextView mDinnerOrderItemTagDiscountLabel;//折扣icon
        private TextView mDinnerOrderItemTagbuygiftTv;//买减
        private ImageView mDinnerOrderItemTagGiftImg;//赠送icon
        private ImageView mDinnerOrderItemTagMemberImg;//会员价icon

        private UnScollerListView mDinnerOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mDinnerOrderItemPackageLsv;//套餐明细列表

        private TextView mDelimit; // 划菜剩余数量

        public NetMenuItemAdapter(Context context, List<TempAppOrderDetail> dataList, int layoutId) {
            super(context, dataList, layoutId);
        }

        @Override
        public void convert(ViewHolder viewHolder, TempAppOrderDetail menuItem, int position) {
            initViews(viewHolder);
            bindData(menuItem, position);
        }

        private void initViews(ViewHolder holder) {
            itemView = holder.getConvertView();
            mDinnerOrderItemNameLabel = holder.getView(R.id.mDinnerOrderItemNameLabel);
            mDinnerOrderItemNoteContentLabel = holder.getView(R.id.mDinnerOrderItemNoteContentLabel);
            mDinnerOrderItemNumLabel = holder.getView(R.id.mDinnerOrderItemNumLabel);
            mDinnerOrderItemNumHintLabel = holder.getView(R.id.mDinnerOrderItemNumHintLabel);
            mDinnerOrderItemPriceLabel = holder.getView(R.id.mDinnerOrderItemPriceLabel);
            mDinnerOrderItemPreferentialWay = holder.getView(R.id.mDinnerOrderItemPreferentialWay);
            mDinnerOrderItemPreferentialWay.setVisibility(GONE);
            mDinnerOrderItemNomalPriceLabel = holder.getView(R.id.mDinnerOrderItemNomalPriceLabel);

            mDinnerOrderItemTagDiscountLabel = holder.getView(R.id.mDinnerOrderItemTagDiscountLabel);
            mDinnerOrderItemTagGiftImg = holder.getView(R.id.mDinnerOrderItemTagGiftImg);
            mDinnerOrderItemTagMemberImg = holder.getView(R.id.mDinnerOrderItemTagMemberImg);
            mDinnerOrderItemTagbuygiftTv = holder.getView(R.id.mDinnerOrderItemTagbuygiftTv);

            mDinnerOrderItemIngredientLsv = holder.getView(R.id.mDinnerOrderItemIngredientLsv);
            mDinnerOrderItemPackageLsv = holder.getView(R.id.mDinnerOrderItemPackageLsv);
            mDelimit = holder.getView(R.id.tv_dinner_food_order_delimit);
        }

        public void bindData(TempAppOrderDetail menuItem, int position) {
            removeAllLine();
            mDinnerOrderItemNameLabel.setText(menuItem.itemName);
            mDinnerOrderItemNameLabel.setBackgroundResource(0);
            mDinnerOrderItemNameLabel.setPadding(0, 0, 0, 0);
            //设置备注显示
            String note = menuItem.itemProperties;
            if (TextUtils.isEmpty(note)) {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteContentLabel.setText(note);
            }
            mDinnerOrderItemNumLabel.setText(menuItem.itemNum + "/" + menuItem.unit);

            mDinnerOrderItemPriceLabel.setText(Tools.getCurrency() + Calc.formatShow(menuItem.totalItemPrice, RoundConfig.ROUND_SINGLE_PRICE));
            mDinnerOrderItemPriceLabel.setOnClickListener(null);

            //优惠信息tag
            mDinnerOrderItemTagGiftImg.setVisibility(View.GONE);
            mDinnerOrderItemTagDiscountLabel.setVisibility(View.GONE);
            mDinnerOrderItemTagMemberImg.setVisibility(View.GONE);
            mDinnerOrderItemTagbuygiftTv.setVisibility(View.GONE);

            mDinnerOrderItemIngredientLsv.setVisibility(View.GONE);
            mDinnerOrderItemNumHintLabel.setVisibility(GONE);

            //配料菜列表展示
            ArrayList<TempModifierDetail> ingredientsList = menuItem.modifierList(0);
            if (!ListUtil.isEmpty(ingredientsList)) {
                mDinnerOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<TempModifierDetail> ingredientAdapter = (CommonAdapter<TempModifierDetail>) mDinnerOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<TempModifierDetail>(getContext(), ingredientsList, R.layout.message_order_menu_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, TempModifierDetail item, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.msg_order_item_name);
                            name.setTextColor(context.getResources().getColor(R.color.line_gray));
                            name.setText(item.modifierName);

                            TextView count = (TextView) viewHolder.getView(R.id.msg_order_item_note);
                            count.setTextColor(context.getResources().getColor(R.color.line_gray));

                            TextView price = (TextView) viewHolder.getView(R.id.msg_order_item_num);
                            price.setTextColor(context.getResources().getColor(R.color.line_gray));


                            count.setText("x" + item.modifierNum.stripTrailingZeros().toPlainString());
                            price.setText(item.modifierPrice.stripTrailingZeros().toPlainString());
                        }
                    };
                    mDinnerOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(ingredientsList);
                }
            } else {
                mDinnerOrderItemIngredientLsv.setVisibility(View.GONE);
            }

            //套餐明细显示
            ArrayList<TempModifierDetail> packageList = menuItem.modifierList(1);
            if (!ListUtil.isEmpty(packageList)) {
                mDinnerOrderItemPackageLsv.setVisibility(View.VISIBLE);
                CommonAdapter<TempModifierDetail> packageAdapter = (CommonAdapter<TempModifierDetail>) mDinnerOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<TempModifierDetail>(getContext(), packageList, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, TempModifierDetail data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.modifierName));
                            viewHolder.setText(R.id.numTv, data.modifierNum + "");
                        }
                    };
                    mDinnerOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(packageList);
                }
            } else {
                mDinnerOrderItemPackageLsv.setVisibility(View.GONE);
            }

        }

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent(MenuItem menuItem) {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
           /* if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);

            return demand.toString();
        }

        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemPriceLabel);
        }
    }
}
