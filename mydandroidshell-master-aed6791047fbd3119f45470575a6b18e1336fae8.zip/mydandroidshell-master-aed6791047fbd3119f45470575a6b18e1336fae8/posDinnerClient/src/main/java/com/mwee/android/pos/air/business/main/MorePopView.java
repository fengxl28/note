package com.mwee.android.pos.air.business.main;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.air.business.member.MemberQueryFragment;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.bill.view.BillFragment;
import com.mwee.android.pos.business.login.component.LoginProcess;
import com.mwee.android.pos.business.print.view.PrintMonitorFragment;
import com.mwee.android.pos.business.reports.view.ReportFragment;
import com.mwee.android.pos.business.shift.ShiftFragment;
import com.mwee.android.pos.business.sync.api.LocalDataProcessorForDinner;
import com.mwee.android.pos.business.table.processor.TableViewProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;

/**
 * Created by zhangmin on 2017/11/7.
 */

public class MorePopView extends PopupWindow implements View.OnClickListener {

    private Host mHost;
    private View conentView;

    public MorePopView(Host mHost) {
        this.mHost = mHost;

        initPopView();
        assignViews();

    }


    private void initPopView() {

        LayoutInflater inflater = (LayoutInflater) mHost.getContextWithinHost().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        conentView = inflater.inflate(R.layout.air_more_fragment, null);
        this.setContentView(conentView);
        this.setWidth(LinearLayout.LayoutParams.WRAP_CONTENT);
        this.setHeight(LinearLayout.LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);
        this.setOutsideTouchable(true);
        this.update();
        ColorDrawable dw = new ColorDrawable(0000000000);
        this.setBackgroundDrawable(dw);


    }

    private void assignViews() {

        TextView tvMemberMore = conentView.findViewById(R.id.tvMemberMore);
        TextView tvPrinterMore = conentView.findViewById(R.id.tvPrinterMore);
        TextView tvBillMore = conentView.findViewById(R.id.tvBillMore);
        TextView tvReportMore = conentView.findViewById(R.id.tvReportMore);
        TextView tvRefreshMore = conentView.findViewById(R.id.tvRefreshMore);
        TextView tvShiftMore = conentView.findViewById(R.id.tvShiftMore);
        TextView tvCloseMore = conentView.findViewById(R.id.tvCloseMore);

        tvMemberMore.setOnClickListener(this);
        tvPrinterMore.setOnClickListener(this);
        tvBillMore.setOnClickListener(this);
        tvReportMore.setOnClickListener(this);
        tvRefreshMore.setOnClickListener(this);
        tvShiftMore.setOnClickListener(this);
        tvCloseMore.setOnClickListener(this);

        ImageView imageView = conentView.findViewById(R.id.img_print_warning);
        if (AppCache.getInstance().isPrintWaring) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }


    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tvMemberMore:
                UIHelp.jumpStartActivity(mHost, "会员", MemberQueryFragment.class);
                break;
            case R.id.tvPrinterMore:
                UIHelp.jumpStartActivity(mHost, "打印监控", PrintMonitorFragment.class);
                AppCache.getInstance().isPrintWaring = false;
                DriverBus.call("mainTitleBar/waring", false);
                break;
            case R.id.tvBillMore:
                UIHelp.jumpStartActivity(mHost, "账单管理", BillFragment.class);
                break;
            case R.id.tvReportMore:
                UIHelp.jumpStartActivity(mHost, "营业报表", ReportFragment.class);
                break;
            case R.id.tvRefreshMore:
                ActionLog.addLog("更多设置->点击了数据同步", "", "", ActionLog.SS_MORE_JOIN, "");
                LocalDataProcessorForDinner.callUploadToCloud(mHost);
                break;
            case R.id.tvShiftMore:
                UIHelp.jumpStartActivity(mHost, "交班打烊", ShiftFragment.class);
                break;
            case R.id.tvCloseMore:
                closeMore();
                break;
            default:
                break;
        }
        this.dismiss();
    }


    private void closeMore() {

        ActionLog.addLog("注销", "", "", ActionLog.LOGOUT, "");
        if (AppCache.getInstance().userDBModel != null) {
            ActionLog.addLog("点击退出登录[" + AppCache.getInstance().userDBModel.fsUserName + "," + AppCache.getInstance().userDBModel.fsUserId + "]", ActionLog.USER_ACTION_TRACE);
        }
        processLogout();

    }

    /**
     * 发起退出登录
     */
    private void processLogout() {

        if (AppCache.getInstance().userDBModel == null) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.Close, "登出" + AppCache.getInstance().userDBModel.fsUserName);
        final Progress progress = ProgressManager.showProgress(mHost, "正在更新站点状态");
        LoginProcess.doLogout(AppCache.getInstance().userDBModel.fsUserId, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse socketResponse) {
                progress.dismiss();
                if (socketResponse.code != SocketResultCode.SUCCESS) {
                    ToastUtil.showToast(socketResponse.message);
                    return;
                }
                LogUtil.log("收银员[--fsUserName--" + AppCache.getInstance().userDBModel.fsUserName + "--fsUserId--" + AppCache.getInstance().userDBModel.fsUserId + " 退出登录]");
                ActionLog.waiterID = "";
                ActionLog.waiterName = "";
                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_STATUS, HostStatus.CLOSE);
                UIHelp.startLoginDinnerActvity(mHost.getActivityWithinHost());
                leave();
                AppCache.getInstance().userDBModel = null;
            }
        });
    }


    private void leave() {
        if (mHost.getActivityWithinHost() != null) {
            mHost.getActivityWithinHost().finish();
        }
        TableViewProcessor.release();
    }


}
