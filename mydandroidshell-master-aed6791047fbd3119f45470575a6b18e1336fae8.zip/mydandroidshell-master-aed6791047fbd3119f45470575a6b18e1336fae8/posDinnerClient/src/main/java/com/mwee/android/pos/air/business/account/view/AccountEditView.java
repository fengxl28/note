package com.mwee.android.pos.air.business.account.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.ToastUtil;

/**
 * @ClassName: AccountEditView
 * @Description: 员工编辑
 * @author: SugarT
 * @date: 2017/10/13 下午2:19
 */
public class AccountEditView extends BaseDialogFragment {

    public static final String TAG = AccountEditView.class.getSimpleName();

    private EditText mUserNameTv; //员工姓名
    private EditText mUserIdTv; //登录账户
    private EditText mPwdTv; //登录密码
    private CheckBox mCashBoxCb, mBillCb, mRefundCb, mReportCb, mDiscountCb;
    private TextView mCashBoxDesc, mBillDesc, mRefundDesc, mReportDesc, mDiscountDesc;
    private Button mCancelBtn;
    private Button mConfirmBtn;

    private AccountManageInfo mOptUser;

    private OnResultListener<AccountManageInfo> listener;

    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (v.getId()) {
                case R.id.btn_account_edit_cancel:
                    // 取消
                    dismiss();
                    break;
                case R.id.btn_account_edit_confirm:
                    // 确定
                    editAccount();
                    break;
                default:
                    break;
            }
        }
    };

    public static AccountEditView newInstance() {
        AccountEditView fragment = new AccountEditView();
        return fragment;
    }

    public AccountEditView setOptUser(AccountManageInfo optUser) {
        mOptUser = optUser;
        return this;
    }

    public AccountEditView setListener(OnResultListener listener) {
        this.listener = listener;
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.view_account_edit, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (mOptUser == null) {
            dismissSelf();
            return;
        }
        assignViews(view);
        loadData();
    }

    private void assignViews(View convertView) {
        convertView.findViewById(R.id.llyt_account_edit_root).setOnClickListener(null);
        mUserNameTv = (EditText) convertView.findViewById(R.id.et_account_edit_user_name);
        mUserIdTv = (EditText) convertView.findViewById(R.id.et_account_edit_login_name);
        mPwdTv = (EditText) convertView.findViewById(R.id.et_account_edit_password);
        mCashBoxCb = (CheckBox) convertView.findViewById(R.id.cb_account_edit_cash_box);
        mCashBoxDesc = (TextView) convertView.findViewById(R.id.tv_account_edit_cash_box);
        mBillCb = (CheckBox) convertView.findViewById(R.id.cb_account_edit_bill);
        mBillDesc = (TextView) convertView.findViewById(R.id.tv_account_edit_bill);
        mRefundCb = (CheckBox) convertView.findViewById(R.id.cb_account_edit_refund);
        mRefundDesc = (TextView) convertView.findViewById(R.id.tv_account_edit_refund);
        mReportCb = (CheckBox) convertView.findViewById(R.id.cb_account_edit_report);
        mReportDesc = (TextView) convertView.findViewById(R.id.tv_account_edit_report);
        mDiscountCb = (CheckBox) convertView.findViewById(R.id.cb_account_edit_discount);
        mDiscountDesc = (TextView) convertView.findViewById(R.id.tv_account_edit_discount);
        mCancelBtn = (Button) convertView.findViewById(R.id.btn_account_edit_cancel);
        mConfirmBtn = (Button) convertView.findViewById(R.id.btn_account_edit_confirm);

        mCancelBtn.setOnClickListener(click);
        mConfirmBtn.setOnClickListener(click);
    }

    private void loadData() {
        if (!TextUtils.isEmpty(mOptUser.fsUserName)) {
            mUserNameTv.setHint(mOptUser.fsUserName);
            mUserIdTv.setHint(mOptUser.fsUserId);
            mPwdTv.setHint(mOptUser.fsPwd);

            // 员工编辑，不可编辑id
            mUserIdTv.setFocusableInTouchMode(false);
            mUserIdTv.setFocusable(false);
            mUserIdTv.setBackgroundResource(R.drawable.bg_cubic_stroke_gray_enable);
        }
        if (mOptUser.supportCashBox()) {
            mCashBoxCb.setChecked(true);
        }
        if (mOptUser.supportBill()) {
            mBillCb.setChecked(true);
        }
        if (mOptUser.supportRefund()) {
            mRefundCb.setChecked(true);
        }
        if (mOptUser.supportReport()) {
            mReportCb.setChecked(true);
        }
        if (mOptUser.supportDiscount()) {
            mDiscountCb.setChecked(true);
        }

        if (TextUtils.equals(mOptUser.fsUserId, "admin") ||
                TextUtils.equals(mOptUser.fsUserId, "99999") ||
                TextUtils.equals(mOptUser.fsUserId, "cash")) {
            // 管理员/云收银 名称不可编辑
            mUserNameTv.setFocusableInTouchMode(false);
            mUserNameTv.setFocusable(false);
            mUserNameTv.setBackgroundResource(R.drawable.bg_cubic_stroke_gray_enable);

            mCashBoxCb.setEnabled(false);
            mCashBoxDesc.setEnabled(false);
            mBillCb.setEnabled(false);
            mBillDesc.setEnabled(false);
            mRefundCb.setEnabled(false);
            mRefundDesc.setEnabled(false);
            mReportCb.setEnabled(false);
            mReportDesc.setEnabled(false);
            mDiscountCb.setEnabled(false);
            mDiscountDesc.setEnabled(false);
        }
    }

    private void editAccount() {
        String errMsg = checkParams();
        if (!TextUtils.isEmpty(errMsg)) {
            ToastUtil.showToast(errMsg);
            return;
        }

        mOptUser.fsUserName = mUserNameTv.getText().toString().trim();
        if (TextUtils.isEmpty(mOptUser.fsUserName)) {
            mOptUser.fsUserName = mUserNameTv.getHint().toString().trim();
        }
        mOptUser.fsUserId = mUserIdTv.getText().toString().trim();
        if (TextUtils.isEmpty(mOptUser.fsUserId)) {
            mOptUser.fsUserId = mUserIdTv.getHint().toString().trim();
        }
        mOptUser.fsPwd = mPwdTv.getText().toString().trim();
        if (TextUtils.isEmpty(mOptUser.fsPwd)) {
            mOptUser.fsPwd = mPwdTv.getHint().toString().trim();
        }
        int author = buildAuthorConfig();
        mOptUser.config = author;

        if (listener != null) {
            listener.callBack(mOptUser);
        }
        dismissSelf();
    }

    private String checkParams() {
        String fsUserName = TextUtils.isEmpty(mUserNameTv.getText()) ? "" : mUserNameTv.getText().toString().trim();
        if (TextUtils.isEmpty(fsUserName)) {
            fsUserName = TextUtils.isEmpty(mUserNameTv.getHint()) ? "" : mUserNameTv.getHint().toString().trim();
        }
        if (TextUtils.isEmpty(fsUserName)) {
            return "请输入员工姓名";
        } else if (!RegexUtil.checkName(fsUserName)) {
            return "员工姓名输入非法";
        }
        if (fsUserName.length() > 50) {
            return "员工姓名最大长度为50位";
        }

        String userId = TextUtils.isEmpty(mUserIdTv.getText()) ? "" : mUserIdTv.getText().toString().trim();
        if (TextUtils.isEmpty(userId)) {
            userId = TextUtils.isEmpty(mUserIdTv.getHint()) ? "" : mUserIdTv.getHint().toString().trim();
        }
        if (TextUtils.isEmpty(userId)) {
            return "请输入登录账号";
        }
        if (!RegexUtil.checkName(userId)) {
            return "登录账号输入非法";
        }
        if (userId.length() < 1 || userId.length() > 20) {
            return "登录账户最大长度为20位";
        }

        String pwd = TextUtils.isEmpty(mPwdTv.getText()) ? "" : mPwdTv.getText().toString().trim();
        if (TextUtils.isEmpty(pwd)) {
            pwd = TextUtils.isEmpty(mPwdTv.getHint()) ? "" : mPwdTv.getHint().toString().trim();
        }
        if (TextUtils.isEmpty(pwd)) {
            return "请输入登录密码";
        } else if (!RegexUtil.checkName(pwd)) {
            return "登录密码输入非法";
        }

        if (pwd.length() < 1 || pwd.length() > 6) {
            return "密码由1-6位数字组成";
        }
        return "";
    }

    private int buildAuthorConfig() {
        int result = 0;
        if (mCashBoxCb.isChecked()) {
            result = result | 1;
        }
        if (mBillCb.isChecked()) {
            result = result | 2;
        }
        if (mRefundCb.isChecked()) {
            result = result | 4;
        }
        if (mReportCb.isChecked()) {
            result = result | 8;
        }
        if (mDiscountCb.isChecked()) {
            result = result | 16;
        }
        return result;
    }
}
