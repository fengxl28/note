//package com.mwee.android.pos.business.member;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.RelativeLayout;
//
//import com.mwee.android.pos.business.member.biz.MemberProcess;
//import com.mwee.android.pos.component.dialog.BaseDialogFragment;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.connect.callback.IResult;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.TextUtils;
//import com.mwee.android.pos.util.ToastUtil;
//
///**
// * Created by lxx on 16/9/08.
// */
//public class BindThirdCardFragment extends BaseDialogFragment {
//    public static final String FRAGMENT_TAG = BindThirdCardFragment.class.getName();
//
//    private RelativeLayout bind_ryt;
//    private EditText thirdNumber;
//    private EditText mwNumber;
//    private Button cancel;
//    private Button bind;
//
//    private BindThirdCardCallback callback;
//    private String thirdCardNumber = "";
//    private String mwCardNumber = "";
//
//    public void setCallback(BindThirdCardCallback callback) {
//        this.callback = callback;
//    }
//
//    private View.OnClickListener onClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View view) {
//            switch (view.getId()) {
//                case R.id.bind:
//                    if (checkFormat()) {
//                        ProgressManager.showProgress(getActivityWithinHost());
//
//                        (new MemberProcess()).thirdMemberBind(thirdCardNumber, mwCardNumber, new IResult() {
//                            @Override
//                            public void callBack(boolean result, String info) {
//                                ProgressManager.closeProgress(getActivityWithinHost());
//                                ToastUtil.showToast(info);
//                                if (result) {
//                                    dismiss();
//                                }
//                            }
//                        });
//                    }
//                    break;
//                case R.id.cancel:
//                    dismiss();
//                    break;
//                default:
//                    break;
//            }
//        }
//    };
//
//    /**
//     * @param inflater
//     * @param container
//     * @param savedInstanceState
//     * @return
//     */
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View contentView = inflater.inflate(R.layout.bind_third_card_fragment_layout, container, false);
//
//        bind_ryt = contentView.findViewById(R.id.bind_ryt);
//        bind_ryt.setOnClickListener(null);
//        cancel = contentView.findViewById(R.id.cancel);
//        cancel.setOnClickListener(onClickListener);
//        bind = contentView.findViewById(R.id.bind);
//        bind.setOnClickListener(onClickListener);
//
//        thirdNumber = (EditText) contentView.findViewById(R.id.thirdNumber);
//        mwNumber = (EditText) contentView.findViewById(R.id.mwNumber);
//        return contentView;
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//    }
//
//    /**
//     * @return 验证通过返回true
//     * @author ：
//     */
//    public boolean checkFormat() {
//        thirdCardNumber = thirdNumber.getText().toString().trim();
//        mwCardNumber = mwNumber.getText().toString().trim();
//
//        if (!TextUtils.validate(thirdCardNumber)) {
//            ToastUtil.showToast("请输入实体卡号");
//            return false;
//        }
//        if (!TextUtils.validate(mwCardNumber)) {
//            ToastUtil.showToast("请输入美味会员卡号");
//            return false;
//        }
//        return true;
//    }
//
//}
