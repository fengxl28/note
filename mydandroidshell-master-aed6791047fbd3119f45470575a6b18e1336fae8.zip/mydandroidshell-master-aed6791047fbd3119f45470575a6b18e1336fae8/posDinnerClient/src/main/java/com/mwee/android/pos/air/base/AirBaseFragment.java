package com.mwee.android.pos.air.base;

import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.base.BaseFragment;

/**
 * @ClassName: AirBaseFragment
 * @Description:
 * @author: SugarT
 * @date: 2017/10/25 下午2:57
 */
public class AirBaseFragment extends BaseFragment {

    @Override
    public boolean onKeyBack() {
        BizcenterApi.uploadLocalChangeData(null);
        return false;
    }
}
