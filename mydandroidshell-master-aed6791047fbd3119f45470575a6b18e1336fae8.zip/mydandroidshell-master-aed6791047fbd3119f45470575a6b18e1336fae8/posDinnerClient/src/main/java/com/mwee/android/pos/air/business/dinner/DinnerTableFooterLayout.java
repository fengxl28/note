package com.mwee.android.pos.air.business.dinner;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.dinner.DishUtils;
import com.mwee.android.pos.business.member.widget.MemberBindOperationView;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2017/11/9.
 */

public class DinnerTableFooterLayout extends LinearLayout implements View.OnClickListener {

    //打印预结单
    private TextView tvPrintPre;
    //加减菜
    private TextView tvOperateMenuItem;
    //总价
    private TextView tvOrderTotalPriceLabel;

    //结账
    private TextView mOperationPayLable;
    //开台
    private TextView mOperationOpenTableLable;


    private LinearLayout layoutDinnerFooterLeft;


    private DishCache mDishCache;
    private MemberBindOperationView mOperationMemberBindOperationView;


    public DinnerTableFooterLayout(Context context) {
        super(context);
        initView();
    }


    public DinnerTableFooterLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public DinnerTableFooterLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.air_dinner_table_bottom_operation, this);

        layoutDinnerFooterLeft = findViewById(R.id.layoutDinnerFooterLeft);

        tvPrintPre = findViewById(R.id.tvPrintPre);
        tvOperateMenuItem = findViewById(R.id.tvOperateMenuItem);

        tvOrderTotalPriceLabel = findViewById(R.id.tvOrderTotalPriceLabel);

        mOperationOpenTableLable = findViewById(R.id.mOperationOpenTableLable);
        mOperationPayLable = findViewById(R.id.mOperationPayLable);
        mOperationMemberBindOperationView = (MemberBindOperationView) findViewById(R.id.mOperationMemberBindOperationView);
        mOperationMemberBindOperationView.unBind();

        tvPrintPre.setOnClickListener(this);
        tvOperateMenuItem.setOnClickListener(this);
        mOperationPayLable.setOnClickListener(this);
        mOperationOpenTableLable.setOnClickListener(this);
        mOperationMemberBindOperationView.setOnClickListener(this);

    }


    /**
     * 刷新笔数与总价
     */
    private void calculateTotalPrice() {
        if (mDishCache.order != null && mDishCache.order.isMember) {
            if (!com.mwee.android.pos.util.TextUtils.validate(mDishCache.order.memberName)) {
                //真实姓名和昵称都为空 取会员等级名称
                mOperationMemberBindOperationView.bind(mDishCache.order.memberInfoS.level_name, mDishCache.order.memberInfoS.mobile);
            } else {
                mOperationMemberBindOperationView.bind(mDishCache.order.memberName, mDishCache.order.memberInfoS.mobile);
            }
        } else {
            mOperationMemberBindOperationView.unBind();
        }
        // FIXME: 2017/6/22 总价格计算方法
        if (mDishCache.order == null) {
            //mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
            tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(mDishCache.orderDishesCache.tempTotalPrice, RoundConfig.ROUND_TOTAL)));
            return;
        }
        refreshOrderInfo();
    }


    private void refreshOrderInfo() {

        if (!ListUtil.listIsEmpty(mDishCache.order.originMenuList)) {
            BigDecimal cut = BigDecimal.ZERO;
            String discountInfo = "";
            if (mDishCache.order.couponCut != null && mDishCache.order.couponCut.fdCutmoney.compareTo(BigDecimal.ZERO) > 0) {
                cut = mDishCache.order.couponCut.fdCutmoney;
                discountInfo = " (" + mDishCache.order.couponCut.fsBargainName + "：-" + cut.toString() + ")";
            }
            if (!DishUtils.isSupportRound(mDishCache.order)) {
                tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(mDishCache.order.optTotalMenuPrice().subtract(cut))).append(discountInfo));

            } else {
                tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(mDishCache.order.optTotalMenuPrice().subtract(cut), RoundConfig.ROUND_TOTAL)).append(discountInfo));
            }

        }
    }


    /**
     * 刷新小散底部bottom
     *
     * @param mDishCache
     */
    public void refreshDinnerFooterLayout(DishCache mDishCache) {

        this.mDishCache = mDishCache;

        if (mDishCache == null || mDishCache.order == null) {// 1 没有选中任何桌台 或者 2选中了一个没有下单的桌台
            layoutDinnerFooterLeft.setVisibility(INVISIBLE);
            mOperationOpenTableLable.setVisibility(VISIBLE);
            if (mDishCache == null) {
                mOperationOpenTableLable.setEnabled(false);
            } else {
                mOperationOpenTableLable.setEnabled(true);
            }
            mOperationPayLable.setVisibility(GONE);
            mOperationMemberBindOperationView.setVisibility(GONE);
        } else {//选中了已经下单的桌台
            mOperationOpenTableLable.setVisibility(GONE);
            mOperationPayLable.setVisibility(VISIBLE);
            layoutDinnerFooterLeft.setVisibility(VISIBLE);
            mOperationMemberBindOperationView.setVisibility(VISIBLE);
            calculateTotalPrice();
        }

    }


    @Override
    public void onClick(View view) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.tvPrintPre:
                listener.onPrinterPreBillClick();
                break;
            case R.id.tvOperateMenuItem:
                listener.onOrderMenuOperateClick();
                break;
            case R.id.mOperationOpenTableLable:
                if (mDishCache == null) {//该桌台没有开台
                    ToastUtil.showToast("请选择桌号");
                    return;
                }
                listener.onOpenTableClick();
                break;
            case R.id.mOperationPayLable:
                listener.onPayClick();
                break;
            case R.id.mOperationMemberBindOperationView:
                listener.onMemberClick();
                break;
            default:
                break;
        }
    }


    private DinnerTableFoodFooterLayoutCallBack listener;

    public void setDinnerTableFooterLayouCallBack(DinnerTableFoodFooterLayoutCallBack listener) {

        this.listener = listener;
    }


    public interface DinnerTableFoodFooterLayoutCallBack {

        /**
         * 打印预结单
         */
        void onPrinterPreBillClick();

        /**
         * 加减菜
         */
        void onOrderMenuOperateClick();

        /**
         * 点击开台
         */
        void onOpenTableClick();

        /**
         * 会员
         */
        void onMemberClick();

        /**
         * 结账
         */
        void onPayClick();

    }


}
