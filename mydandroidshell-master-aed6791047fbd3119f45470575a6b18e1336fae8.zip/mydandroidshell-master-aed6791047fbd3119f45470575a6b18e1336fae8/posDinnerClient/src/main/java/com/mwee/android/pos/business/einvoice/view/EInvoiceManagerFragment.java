package com.mwee.android.pos.business.einvoice.view;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.base.FClazzInfo;
import com.mwee.android.pos.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.business.einvoice.api.InvoiceIsActiveResponse;
import com.mwee.android.pos.business.einvoice.model.IsInvoiceActiveBean;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

/**
 * 电子发票配置相关
 */
public class EInvoiceManagerFragment extends BaseListFragment<FClazzInfo> {
    private int selectPosition;
    //发票开通状态 -1：未知； 1：已开通； 2：未开通
    private int activeStatus = -1;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.koubei_service_container_fragment;
    }

    @Override
    protected void initData() {
        super.initData();
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        ActionLog.addLog("电子发票->请求获取是否开已通电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
        EInvoiceProcess.isInvoiceActive(shopId, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                //发票开通状态 -1：未知； 1：已开通； 2：未开通
                if (responseData.responseBean instanceof InvoiceIsActiveResponse) {
                    InvoiceIsActiveResponse invoiceIsActiveResponse = (InvoiceIsActiveResponse) responseData.responseBean;
                    if (invoiceIsActiveResponse != null) {
                        if (invoiceIsActiveResponse.errno != 0) {
                            activeStatus = -1;
                        } else {
                            IsInvoiceActiveBean isInvoiceActiveBean = invoiceIsActiveResponse.data;
                            if (isInvoiceActiveBean != null) {
                                if (TextUtils.equals("Y", isInvoiceActiveBean.state)) {
                                    activeStatus = 1;
                                } else {
                                    activeStatus = 2;
                                }
                            } else {
                                activeStatus = 2;
                            }
                        }
                    }
                }
                d();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                activeStatus = -1;
                d();
                return false;
            }
        });
    }


    private void d(){
        mPullRecyclerView.setEnablePullToStart(false);
        modules.add(new FClazzInfo("发票设置", EInvoiceFragment.class));
        if (activeStatus != 2) {
            modules.add(new FClazzInfo("手动纯开票", ManualEInvoiceFragment.class));
        }
        adapter.notifyDataSetChanged();
        onMenuItemClick(modules.get(0));
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.koubei_service_container_item_layout, parent, false));
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView label;
        private int position;

        public Holder(View itemView) {
            super(itemView);
            label = (TextView) itemView;
            label.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            this.position = position;
            label.setText(modules.get(position).title);
            if (position == selectPosition) {
                ViewToolsUtil.setBackgroundResourceKeepPadding(label, R.drawable.bg_category_item_checked);
                label.setTextColor(getResources().getColor(R.color.system_red));
            } else {
                label.setBackground(null);
                label.setTextColor(getResources().getColor(R.color.white));
            }
        }

        @Override
        public void onClick(View v) {
            onMenuItemClick(modules.get(position));
            selectPosition = position;
            adapter.notifyDataSetChanged();
        }
    }

    private void onMenuItemClick(FClazzInfo fClazzInfo) {
        try {
            getChildFragmentManager().beginTransaction().replace(R.id.mContainer, fClazzInfo.clazz.newInstance()).commitAllowingStateLoss();
        } catch (java.lang.InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
