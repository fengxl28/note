package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/5/8.
 */

public class AliPayOpenPayModel extends BusinessBean {
    public String authurl;
    public String companyshopname;
    public String koubeishopname;
    public String shopguid;
    public String shopname;

    public AliPayOpenPayModel() {

    }
}
