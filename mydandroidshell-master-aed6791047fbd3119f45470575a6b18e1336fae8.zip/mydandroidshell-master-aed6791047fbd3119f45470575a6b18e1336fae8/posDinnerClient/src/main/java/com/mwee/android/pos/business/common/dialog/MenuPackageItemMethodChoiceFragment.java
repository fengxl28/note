package com.mwee.android.pos.business.common.dialog;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.client.db.ClientMenuDBUtil;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/7/19.
 */

public class MenuPackageItemMethodChoiceFragment extends BaseListFragment<AskDBModel> {
    private List<AskDBModel> askDBModels;
    //private AskDBModel currentAsk;
    private OnMenuPackageItemMethodChoiceListener listener;
    private View mMethodEmptyLayout;
    private TextView tv_multi_method_hint;

    public List<AskDBModel> selectMulProcedure = new ArrayList<>();
    private MenuitemDBModel menuItemDBModel;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_menu_package_item_ask_choice;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mMethodEmptyLayout = view.findViewById(R.id.mMethodEmptyLayout);
        tv_multi_method_hint = view.findViewById(R.id.tv_multi_method_hint);
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        if (!ListUtil.isEmpty(askDBModels)) {
            modules.addAll(askDBModels);
            adapter.notifyDataSetChanged();
            mMethodEmptyLayout.setVisibility(View.GONE);
            tv_multi_method_hint.setVisibility(View.VISIBLE);
            refreshMulMethodTitle();
        } else {
            mMethodEmptyLayout.setVisibility(View.VISIBLE);
            tv_multi_method_hint.setVisibility(View.GONE);
        }
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.fragment_menu_package_item_ask_item, parent, false));
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {

        private TextView mPackageItemAskNameLabel;
        private AskDBModel askDBModel;

        public Holder(View v) {
            super(v);
            mPackageItemAskNameLabel = (TextView) v.findViewById(R.id.mPackageItemAskNameLabel);
            mPackageItemAskNameLabel.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            askDBModel = modules.get(position);
            mPackageItemAskNameLabel.setText(askDBModel.fsAskName + "(" + askDBModel.fdAddPrice + ")");
            if (choiceStates.contains(askDBModel.fiId)) {
                mPackageItemAskNameLabel.setSelected(true);
            } else {
                mPackageItemAskNameLabel.setSelected(false);
            }
        }

        @Override
        public void onClick(View v) {
            //currentAsk = askDBModel;
            choice(askDBModel.fiId);
            adapter.notifyDataSetChanged();

            listener.onMenuPackageItemChoiceChanged(getCheckedMulProcedure());
        }
    }


    /**
     * 当前选择的做法  AskDBModel  fiId
     */
    private ArrayList<String> choiceStates = new ArrayList<>();

    /**
     * 单选一个做法
     */
    private void choice(String fiId) {

        if (choiceStates.contains(fiId)) {
            choiceStates.remove(fiId);
        } else {
            choiceStates.add(fiId);
        }
    }

    /**
     * 获取勾选的做法
     *
     * @return AskDBModel
     */
    public List<AskDBModel> getCheckedMulProcedure() {

        List<AskDBModel> selectMulProcedure = new ArrayList<>();
        if (!ListUtil.isEmpty(askDBModels)) {
            for (AskDBModel askDBModel : askDBModels) {

                if (choiceStates.contains(askDBModel.fiId)) {
                    selectMulProcedure.add(askDBModel);
                }
            }
        }
        return selectMulProcedure;
    }

    private void refreshMulMethodTitle() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("做法：");
        if (menuItemDBModel != null) {
            if (menuItemDBModel.fipracticemax != 0) {
                if (menuItemDBModel.fipracticemin == menuItemDBModel.fipracticemax) {
                    stringBuilder.append(String.format("(选择%s种)", menuItemDBModel.fipracticemin));
                } else {
                    stringBuilder.append(String.format("(选择%s~%s种)", menuItemDBModel.fipracticemin, menuItemDBModel.fipracticemax));
                }
            }
        }
        tv_multi_method_hint.setText(stringBuilder.toString());
    }

   /* public void setParam(List<AskDBModel> askDBModels, AskDBModel currentAsk, OnMenuPackageItemMethodChoiceListener listener) {
        this.askDBModels = askDBModels;
        this.currentAsk = currentAsk;
        this.listener = listener;
    }*/

    public void setParam(String menuItemId, List<AskDBModel> askDBModels, List<AskDBModel> selectMulProcedure, OnMenuPackageItemMethodChoiceListener listener) {
        this.menuItemDBModel = ClientMenuDBUtil.getMenuitemByFiItemCd(AppCache.getInstance().fsShopGUID, menuItemId);
        this.askDBModels = askDBModels;
        this.selectMulProcedure = selectMulProcedure;
        for (AskDBModel askDBModel : selectMulProcedure) {
            choiceStates.add(askDBModel.fiId);
        }

        this.listener = listener;
    }


    public interface OnMenuPackageItemMethodChoiceListener {
        void onMenuPackageItemChoiceChanged(List<AskDBModel> selectMulProcedure);
    }


}
