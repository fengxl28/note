package com.mwee.android.pos.business.message;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.message.processor.abnormalOrders.AbnormalOrderDetailView;
import com.mwee.android.pos.business.message.processor.abnormalOrders.AbnormalOrdersClientUtil;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderDetailBean;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderHeadBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/05/23.
 * 消息中心-异常订单页面
 */
public class MessageAbnormalOrdersFragment extends BaseListFragment<MessageAbnormalOrderHeadBean> implements IDriver {

    public static final String TAG = MessageOrderFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "messageAbnormalOrders";

    private AbnormalOrderDetailView abnormal_order_detail;
//    private ListView lv_msg_net_order;
//    private CommonAdapter<MessageAbnormalOrderHeadBean> adapter;

    private int chosedMsgId = -1;

    private AbnormalOrdersClientUtil abnormalOrdersClientUtil;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        if (abnormalOrdersClientUtil != null) {
            abnormalOrdersClientUtil.resetPage();
        }
//        loadData(AppCache.getInstance().businessDate);
    }

    /**
     * 更新某一条记录
     *
     * @param orderHeadBean
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshAbnormalOrder", UIThread = true)
    public void refreshTempApporder(MessageAbnormalOrderHeadBean orderHeadBean, MessageAbnormalOrderDetailBean detailBean) {
        if (orderHeadBean == null) {
            return;
        }
        updateData(orderHeadBean);

        if (detailBean == null) {
            return;
        }

        if (chosedMsgId == detailBean.msgId && abnormal_order_detail != null) {
            ActionLog.addLog("更新 消息中心 异常订单 条目", "", "", ActionLog.MESSAGE_ABNORMAL_ORDER, orderHeadBean);
            abnormal_order_detail.updateData(orderHeadBean, detailBean);
            abnormal_order_detail.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 更新显示列表
     *
     * @param orderHeadBean
     */
    private void updateData(MessageAbnormalOrderHeadBean orderHeadBean) {
        if (abnormalOrdersClientUtil == null) {
            abnormalOrdersClientUtil = new AbnormalOrdersClientUtil();
        }
        if (abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList == null) {
            abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList = new ArrayList<>();
        }
        int index = -1;
        for (int i = 0; i < abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList.size(); i++) {
            MessageAbnormalOrderHeadBean order = abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList.get(i);
            if (order.msgId == orderHeadBean.msgId) {
                index = i;
                break;
            }
        }

        if (index > -1) {
            abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList.remove(index);
            abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList.add(index, orderHeadBean);
        } else {
            abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList.add(0, orderHeadBean);
        }

        modules.clear();
        modules.addAll(abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList);
        adapter.notifyDataSetChanged();

    }


    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_message_abnormal_order;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.message_abnormal_order_item, parent, false));
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        abnormalOrdersClientUtil = new AbnormalOrdersClientUtil();

        abnormal_order_detail = view.findViewById(R.id.abnormal_order_detail);
        abnormal_order_detail.setUtil(abnormalOrdersClientUtil);
        abnormal_order_detail.setHost(this);
        abnormal_order_detail.setVisibility(View.GONE);

        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    class Holder extends BaseViewHolder implements View.OnClickListener{
        MessageAbnormalOrderHeadBean data;
        public Holder(View v) {
            super(v);
        }

        @Override
        public void bindData(int position) {

            data = modules.get(position);
            String time = DateUtil.formartDateStrToTarget(data.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm:ss");
            //桌台
            setText(R.id.msg_order_item_table, data.optTableName());
            //支付金额
            setText(R.id.msg_order_item_amt, data.optPayAmt());

            //来源
            setText(R.id.msg_order_item_source, data.optSourse());

            //支付状态
            setText(R.id.msg_order_item_status, data.optPayStatus());

            //支付订单号
            setText(R.id.msg_order_item_payid, data.standBy2);

            //时间
            setText(R.id.msg_order_item_time, time);

            //操作状态
            setText(R.id.msg_order_item_operation_status, data.optBizStatus());

            View root = itemView;
            root.setOnClickListener(this);
            int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
            if (data.doUnDeal()) {
                colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
            }
            setTextColor(R.id.msg_order_item_table, colorR);
            setTextColor(R.id.msg_order_item_amt, colorR);
            setTextColor(R.id.msg_order_item_source, colorR);
            setTextColor(R.id.msg_order_item_status, colorR);
            setTextColor(R.id.msg_order_item_payid, colorR);
            setTextColor(R.id.msg_order_item_status, colorR);
            setTextColor(R.id.msg_order_item_time, colorR);
            setTextColor(R.id.msg_order_item_operation_status, colorR);
            if (data.msgId == chosedMsgId) {
                ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
            } else {
                ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
            }
        }

        @Override
        public void onClick(View v) {

                if (abnormal_order_detail != null) {
                ActionLog.addLog("点击了 消息中心 异常订单 条目", "", "", ActionLog.MESSAGE_ABNORMAL_ORDER, data);
                ProgressManager.showProgress(MessageAbnormalOrdersFragment.this);
                abnormalOrdersClientUtil.getOrderDetail(data.msgId, new IResponse<MessageAbnormalOrderDetailBean>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, MessageAbnormalOrderDetailBean info) {
                        if (result) {
                            if (info != null) {
                                chosedMsgId = data.msgId;
                                abnormal_order_detail.updateData(data, info);
                                abnormal_order_detail.setVisibility(View.VISIBLE);
                                adapter.notifyDataSetChanged();
                            } else {
                                ToastUtil.showToast("请重试");
                            }
                        } else {
                            ToastUtil.showToast(msg);
                        }
                        ProgressManager.closeProgress(MessageAbnormalOrdersFragment.this);
                    }
                });
            }
        }
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            abnormalOrdersClientUtil.resetPage();
        } else {
            abnormalOrdersClientUtil.willLoadData();
        }
        loadDataFromServer(mode);
    }

    private void loadDataFromServer(final int mode) {
        ProgressManager.showProgress(getActivityWithinHost(), getStringWithinHost(R.string.message_please_wait));
        abnormalOrdersClientUtil.getOrderList("", new IResponse<List<MessageAbnormalOrderHeadBean>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<MessageAbnormalOrderHeadBean> info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    modules.clear();
                    modules.addAll(abnormalOrdersClientUtil.messageAbnormalOrderHeadBeanList);

                    if (abnormalOrdersClientUtil.lastPage) {
                        //没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }

                    //无数据
                    if (ListUtil.isEmpty(modules)) {
                        mPullRecyclerView.showEmptyView();
                    } else {
                        mPullRecyclerView.showContent();
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    ToastUtil.showToast(msg);
                    ActionLog.addLog("消息中心 异常订单 获取订单列表失败 " + msg, "", "", ActionLog.MESSAGE_ABNORMAL_ORDER, msg);
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        if (modules.size() == 0) {
                            mPullRecyclerView.showEmptyView();
                        }
                        mPullRecyclerView.onRefreshCompleted(mode);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                    }
                }
            }
        });
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
