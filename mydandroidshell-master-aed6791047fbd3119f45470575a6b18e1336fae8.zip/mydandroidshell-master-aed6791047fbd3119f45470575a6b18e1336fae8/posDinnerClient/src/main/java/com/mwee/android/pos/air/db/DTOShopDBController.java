package com.mwee.android.pos.air.db;

import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.tools.DateUtil;

/**
 * Created by zhangmin on 2017/10/16.
 */

public class DTOShopDBController {


    /**
     * 修改门店数据
     * @param shopDBModel
     */
    public static void update(ShopDBModel shopDBModel, UserDBModel opt) {

        shopDBModel.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        shopDBModel.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        shopDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        shopDBModel.sync = 1;
        shopDBModel.replaceNoTrans();

    }


}
