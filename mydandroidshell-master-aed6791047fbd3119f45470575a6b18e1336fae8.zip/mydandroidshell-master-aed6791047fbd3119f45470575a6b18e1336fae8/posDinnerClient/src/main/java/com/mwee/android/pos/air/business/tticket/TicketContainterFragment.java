package com.mwee.android.pos.air.business.tticket;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.ChildPageFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;

import java.io.Serializable;

/**
 * Created by zhangmin on 2017/9/27.
 */

public class TicketContainterFragment extends ChildPageFragment {

    private RecyclerView mRecyclerView;
    private BaseListAdapter<TicketContainterFragment.ClazzInfo> adapter;
    private TitleBar mTitleBar;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_ticket_contain_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mTitleBar = (TitleBar) view.findViewById(R.id.mTitleBar);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.mRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.addItemDecoration(new DividerItemDecoration(getContextWithinHost(), DividerItemDecoration.VERTICAL_LIST));
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
        initData();

    }

    private void initData() {
        mTitleBar.setTitle("收银小票");
        adapter = new BaseListAdapter<TicketContainterFragment.ClazzInfo>() {
            int choicePosition;

            @Override
            protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
                return new Holder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.menu_class_son_category_item_layout, parent, false));
            }

            class Holder extends BaseViewHolder implements View.OnClickListener {

                private TextView label;
                private int position;

                public Holder(View itemView) {
                    super(itemView);
                    label = (TextView) itemView;
                    label.setOnClickListener(this);
                }

                @Override
                public void bindData(int position) {
                    this.position = position;
                    label.setText(modules.get(position).name);
                    this.position = position;
                    if (position == choicePosition) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_category_item_checked);
                        label.setTextColor(getResources().getColor(R.color.system_red));

                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                        label.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                    }
                }

                @Override
                public void onClick(View v) {
                    choicePosition = this.position;
                    notifyDataSetChanged();
                    setCurrentTab(position);
                }
            }
        };
        //adapter.modules.add(new ClazzInfo("收银小票", TCashierTicketFragment.class));
        //adapter.modules.add(new ClazzInfo("厨房制作单", TKitChenTicketFragment.class));
        //adapter.modules.add(new ClazzInfo("标签", TscTicketFragment.class));
        adapter.modules.add(new ClazzInfo("口碑单", KBTicketFragment.class));
        mRecyclerView.setAdapter(adapter);
        setCurrentTab(0);
    }

    public void setCurrentTab(int position) {
        try {
            ClazzInfo clazzInfo = adapter.modules.get(position);
            mTitleBar.setTitle(clazzInfo.name);
            getActivityWithinHost().getSupportFragmentManager().beginTransaction().replace(R.id.flTicketContain, clazzInfo.clazz.newInstance()).commit();
        } catch (java.lang.InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static class ClazzInfo implements Serializable {
        public ClazzInfo(String name, Class<? extends BaseFragment> clazz) {
            this.name = name;
            this.clazz = clazz;
        }

        public String name;
        public Class<? extends BaseFragment> clazz;
    }


}
