package com.mwee.android.pos.air.business.airdinnerorder.view;

import android.content.Context;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/11/9.
 */

public class AirDinnerFoodOrderMenuAdapter extends BaseExpandableListAdapter {

    private Context mContext;
    public DishCache dishCache;

    private Host mHost;

    private OnItemClickListener listener;

    public int selectPosition = -1;


    /**
     * 头部数据
     */
    public List<OrderSeqModel> orderSeqModels = new ArrayList<>();

    /**
     * 子数据
     */
    SparseArray<ArrayList<MenuItem>> menuChildSpare = new SparseArray<>();//key -->seqNo  value 菜品


    public AirDinnerFoodOrderMenuAdapter(BaseActivity host) {
        super();
        this.mContext = host.getContextWithinHost();
        this.mHost = host;

    }


    public void notifyDataSetChanged(DishCache dishCache) {

        if (dishCache == null || dishCache.order == null) {
            //点击了空的桌台
            this.dishCache = null;
            this.orderSeqModels = null;
            menuChildSpare.clear();
            this.notifyDataSetChanged();
            return;
        }


        this.dishCache = dishCache;
        this.orderSeqModels = dishCache.order.seqList;
        menuChildSpare.clear();
        for (MenuItem menuItem : dishCache.order.originMenuList) {

            OrderSeqModel orderSeqModel = dishCache.order.optSeqModel(menuItem.menuBiz.orderSeqID);
            ArrayList<MenuItem> itemArrayList = menuChildSpare.get(orderSeqModel.seqNo);
            if (ListUtil.isEmpty(itemArrayList)) {
                itemArrayList = new ArrayList<>();
            }
            itemArrayList.add(menuItem);
            menuChildSpare.put(orderSeqModel.seqNo, itemArrayList);
        }
        this.notifyDataSetChanged();

    }


    @Override
    public int getGroupCount() {

        return ListUtil.isEmpty(orderSeqModels) ? 0 : orderSeqModels.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return ListUtil.isEmpty(menuChildSpare.get(orderSeqModels.get(groupPosition).seqNo)) ? 0 : menuChildSpare.get(orderSeqModels.get(groupPosition).seqNo).size();
    }

    @Override
    public OrderSeqModel getGroup(int groupPosition) {
        return orderSeqModels.get(groupPosition);
    }

    @Override
    public MenuItem getChild(int groupPosition, int childPosition) {
        return menuChildSpare.get(orderSeqModels.get(groupPosition).seqNo).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean childPosition, View convertView, ViewGroup parent) {

        View headView = LayoutInflater.from(mContext).inflate(R.layout.textview_item, parent, false);
        TextView tvTitle = headView.findViewById(R.id.tvTitle);
        if (getChildrenCount(groupPosition) == 0) {
            tvTitle.setVisibility(View.GONE);
        } else {
            tvTitle.setVisibility(View.VISIBLE);
            tvTitle.setText(DateUtil.formartDateStrToTarget(getGroup(groupPosition).createTime, DateUtil.DATE_VISUAL14FORMAT, "HH:mm"));
        }
        return headView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean b, View convertView, ViewGroup parent) {
        AirDinnerFoodOrderMenuAdapter.ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.view_air_order_dishes_item, parent, false);
            holder = new AirDinnerFoodOrderMenuAdapter.ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (AirDinnerFoodOrderMenuAdapter.ViewHolder) convertView.getTag();
        }
        holder.bindData(groupPosition, childPosition);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }


    class ViewHolder implements View.OnClickListener {
        private View itemView;
        private View ingredient_line;
        private MenuItem menuItem;
        private LinearLayout mFastOrderItemInfoLayout;//点菜基本信息layout
        private TextView mFastOrderItemNameLabel;//菜品名称
        private TextView mFastOrderItemNoteContentLabel;//备注
        private TextView mFastOrderItemNumLabel;//点菜份数
        private TextView mFastOrderItemNumHintLabel;//退菜数量

        private TextView mFastOrderItemPriceLabel;//菜品金额

        private TextView mFastOrderItemTagDiscountLabel;//折扣icon
        private ImageView mFastOrderItemTagGiftImg;//赠送icon
        private ImageView mFastOrderItemTagMemberImg;//会员价icon

        private TextView mFastOrderItemDeleteOrReturnLabel;//删除icon
        private UnScollerListView mFastOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mFastOrderItemPackageLsv;//套餐明细列表


        public ViewHolder(View v) {
            itemView = v;
            mFastOrderItemInfoLayout = (LinearLayout) v.findViewById(R.id.mFastOrderItemInfoLayout);
            mFastOrderItemNameLabel = (TextView) v.findViewById(R.id.mFastOrderItemNameLabel);
            mFastOrderItemNoteContentLabel = (TextView) v.findViewById(R.id.mFastOrderItemNoteContentLabel);
            mFastOrderItemNumLabel = (TextView) v.findViewById(R.id.mFastOrderItemNumLabel);
            mFastOrderItemNumHintLabel = v.findViewById(R.id.mFastOrderItemNumHintLabel);
            mFastOrderItemPriceLabel = (TextView) v.findViewById(R.id.mFastOrderItemPriceLabel);

            mFastOrderItemTagDiscountLabel = (TextView) v.findViewById(R.id.mFastOrderItemTagDiscountLabel);
            mFastOrderItemTagGiftImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagGiftImg);
            mFastOrderItemTagMemberImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagMemberImg);

            mFastOrderItemDeleteOrReturnLabel = (TextView) v.findViewById(R.id.mFastOrderItemDeleteOrReturnLabel);
            mFastOrderItemIngredientLsv = (UnScollerListView) v.findViewById(R.id.mFastOrderItemIngredientLsv);
            mFastOrderItemPackageLsv = (CompatibleListView) v.findViewById(R.id.mFastOrderItemPackageLsv);
            ingredient_line = v.findViewById(R.id.ingredient_line);
            mFastOrderItemDeleteOrReturnLabel.setOnClickListener(this);
            itemView.setOnClickListener(this);
        }

        /**
         * ui处理
         */
        public void bindData(int groupPosition, int childPosition) {
            menuItem = getChild(groupPosition, childPosition);
            removeAllLine();
            mFastOrderItemNameLabel.setText(menuItem.name);
            //设置备注显示
            String note = getMenuItemNoteContent().trim();
            if (TextUtils.isEmpty(note)) {
                mFastOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mFastOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mFastOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mFastOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint);
            } else {
                mFastOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }

            //时价菜 价格加样式
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid()) {
                mFastOrderItemPriceLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mFastOrderItemPriceLabel.setText("时价");
                mFastOrderItemPriceLabel.setOnClickListener(this);
            } else {
                mFastOrderItemPriceLabel.setBackgroundResource(0);
                mFastOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                mFastOrderItemPriceLabel.setOnClickListener(null);
            }


            mFastOrderItemTagGiftImg.setVisibility(View.GONE);
            mFastOrderItemTagMemberImg.setVisibility(View.GONE);
            mFastOrderItemTagDiscountLabel.setVisibility(View.GONE);
            //优惠信息tag
            if (menuItem.menuBiz.menuSellType == MenuSellType.GIFT || (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && menuItem.menuBiz.giftNum.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum)) == 0)) {
                mFastOrderItemTagGiftImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.useMemberPrice) {
                mFastOrderItemTagMemberImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.menuBiz.selectDiscount != null) {
                mFastOrderItemTagDiscountLabel.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - menuItem.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    mFastOrderItemTagDiscountLabel.setText(rate0.toPlainString() + "折");
                } else {
                    mFastOrderItemTagDiscountLabel.setText(rate.toPlainString() + "折");
                }
            }
            //套餐明细显示
            if (menuItem.supportPackage()) {
                mFastOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mFastOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(mContext, allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name + getMenuItemNoteContent(data)));
                            viewHolder.setText(R.id.numTv, TextUtils.concat(data.menuBiz.buyNum.toPlainString(), "份"));
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                           /* if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mFastOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mFastOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //根据下单状态控制ui显示
            if (dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                //称重菜未称重 数量加样式
                if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                    mFastOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mFastOrderItemNumLabel.setOnClickListener(this);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                } else {
                    mFastOrderItemNumLabel.setOnClickListener(null);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumLabel.setBackgroundResource(0);
                }
                //退菜数据展示
                if (menuItem.hasAllVoid()) {
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                    addAllLine();
                } else {
                    mFastOrderItemDeleteOrReturnLabel.setText("退");
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                    mFastOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
                } else {
                    mFastOrderItemNumHintLabel.setVisibility(View.GONE);
                }


                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_f9f9f9));
            }


        }

        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) return;
            switch (v.getId()) {
                case R.id.mFastOrderItemNumLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vQtyAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                trace("已下单菜品修改数量->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_NUMBER);
                                listener.doChangeOrderedMenuNumber(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemPriceLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                trace("菜品改价格->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_PRICE);
                                listener.doChangeOrderedMenuPrice(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemDeleteOrReturnLabel:
                    //取单页面都是已经下单菜品
                    if (dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        PermissionsUtil.requestPermissionBackMenu(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, menuItem, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    trace("菜品退菜-> orderId:" + dishCache.order.orderID + " name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_RETREAT);
                                    listener.doRetreatDish(menuItem, userDBModel, msg);
                                }
                            }
                        });
                    }

                    break;
                default:
                    break;
            }
        }


        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
          /*  if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
            return demand.toString();
        }


        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemPriceLabel);
        }
    }

    /**
     * 菜品列表操作回调接口
     */
    public interface OnItemClickListener {


        /**
         * 已下单菜品—>修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel);


        /**
         * 已下单菜品->改价格
         *
         * @param menuItem
         * @param userDBModel
         */
        void doChangeOrderedMenuPrice(MenuItem menuItem, UserDBModel userDBModel);


        /**
         * 已下单菜品—>退菜
         *
         * @param item
         * @param userDBModel
         * @param msg
         */
        void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg);


    }

    public void setOrderClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    private void trace(String msg, String action) {
        ActionLog.addLog("点菜页->" + msg, dishCache.order.orderID, dishCache.order.mealNumber, action, "");
    }

}
