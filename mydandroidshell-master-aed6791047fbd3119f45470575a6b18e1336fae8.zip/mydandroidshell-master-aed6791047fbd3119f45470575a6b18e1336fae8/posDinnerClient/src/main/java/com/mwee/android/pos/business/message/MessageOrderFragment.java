package com.mwee.android.pos.business.message;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.business.message.processor.order.MessageOrderDetailView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageOrderBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DateUtil;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 17/2/9.
 */

public class MessageOrderFragment extends HomeFragment implements IDriver {

    public static final String TAG = MessageOrderFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "messageOrder";

    private Host host;
    private MessageOrderDetailView msg_order_detail;
    private ListView lv_msg_order;
    private CommonAdapter<MessageOrderBean> adapter;

    private List<MessageOrderBean> messageOrderBeanList = new ArrayList<>();

    private int chosedMsgId = -1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
 	public void onAttach(Context context) {
        super.onAttach(context);
        this.host = getActivityWithinHost();
    }

    @Override
 	public void onDetach() {
        super.onDetach();
        this.host = null;
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!MessageOrderFragment.this.isVisible()) {
            //LogBiz.log("消息中心->点餐Tab>当前页面被隐藏了");
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_message_order, container, false);
        assignViews(rootView);
        registerEvent();
        initAdapter();
        loadData(AppCache.getInstance().businessDate);
        return rootView;
    }

    @Override
 	public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
 	public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    /**
     * 去数据
     *
     * @param businessDate
     */
    public void loadData(final String businessDate) {
        if (host != null) {
            ProgressManager.showProgress(host, R.string.message_please_wait);
            MessageUtil.getOrderList(businessDate, new OrderListCallBack(MessageOrderFragment.this));
        }
    }

    static class OrderListCallBack implements IResponse<List<MessageOrderBean>> {
 	    WeakReference<MessageOrderFragment> weakReference;

 	    public OrderListCallBack(MessageOrderFragment fragment) {
            this.weakReference = new WeakReference<MessageOrderFragment>(fragment);
        }

        @Override
 	    public void callBack(boolean result, int code, String msg, List<MessageOrderBean> info) {
            MessageOrderFragment fragment = weakReference.get();
            if (fragment != null && fragment.isAdded()) {
                ProgressManager.closeProgress(fragment.host);
                if (result) {
                    RunTimeLog.addLog(RunTimeLog.MESSAGE, "获取到" + info.size() + "条点餐消息记录");
                    fragment.messageOrderBeanList.clear();
                    fragment.messageOrderBeanList.addAll(info);
                    fragment.refreshDetail();
                    fragment.adapter.notifyDataSetChanged();
                } else {
                    RunTimeLog.addLog(RunTimeLog.MESSAGE, "获取点餐消息记录异常：" + msg);
                    ToastUtil.showToast(msg);
                }
            }
        }
    }

    private void refreshDetail() {
        MessageOrderBean bean = null;
        //查查当前选中在不在列表中
        for (MessageOrderBean messageOrderBean : messageOrderBeanList) {
            if (messageOrderBean.msgId == chosedMsgId) {
                bean = messageOrderBean;
                break;
            }
        }

        if (bean != null) {
            msg_order_detail.setDate(bean);
            msg_order_detail.setVisibility(View.VISIBLE);
        } else {
            chosedMsgId = -1;
            msg_order_detail.setVisibility(View.INVISIBLE);
        }
    }

    private void initAdapter() {
        adapter = new CommonAdapter<MessageOrderBean>(getContext(), messageOrderBeanList, R.layout.message_order_item) {

            @Override
            public void convert(ViewHolder viewHolder, MessageOrderBean data, int position) {
                String time = DateUtil.formartDateStrToTarget(data.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                viewHolder.setText(R.id.msg_order_item_time, time);
                viewHolder.setText(R.id.msg_order_item_source, data.optSourse());
                if (data.bookOrder()) {
                    viewHolder.setText(R.id.msg_order_item_table, "--");
                } else {
                    viewHolder.setText(R.id.msg_order_item_table, data.tableName);
                }
                viewHolder.setText(R.id.msg_order_item_status, data.optBizStatus());

                View root = viewHolder.getView(R.id.lyt_root);

                if(AppCache.getInstance().isRetailMode()){
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.system_red);
                        setTextColorOfViewGroup((ViewGroup) root, Color.WHITE);
                    }else{
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.color_f9f9f9);
                        setTextColorOfViewGroup((ViewGroup) root, getResources().getColor(R.color.color_404040));
                    }
                }else{
                    int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                    if (data.doUnDeal()) {
                        colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                    }
                    viewHolder.setTextColor(R.id.msg_order_item_time, colorR);
                    viewHolder.setTextColor(R.id.msg_order_item_source, colorR);
                    viewHolder.setTextColor(R.id.msg_order_item_table, colorR);
                    viewHolder.setTextColor(R.id.msg_order_item_status, colorR);
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
                    }
                }
            }
        };
        lv_msg_order.setAdapter(adapter);
    }

    private void assignViews(View rootView) {
        lv_msg_order = (ListView) rootView.findViewById(R.id.lv_msg_order);
        msg_order_detail = (MessageOrderDetailView) rootView.findViewById(R.id.msg_order_detail);
        msg_order_detail.setHost(this.host);
        msg_order_detail.setVisibility(View.GONE);

        if(AppCache.getInstance().isRetailMode()){//小易2.2 修改样式
            ViewGroup root = rootView.findViewById(R.id.lyt_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            lv_msg_order.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root,getResources().getColor(R.color.color_656565));
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup,int color){
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if(view instanceof TextView){
                ((TextView)view).setTextColor(color);
            }
        }
    }

    private void registerEvent() {
        lv_msg_order.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageOrderBean messageOrderBean = adapter.getItem(position);
                ActionLog.waiterID = AppCache.getInstance().userDBModel.fsUserId;
                ActionLog.waiterName = AppCache.getInstance().userDBModel.fsUserName;
                ActionLog.addLog("点击了 消息中心 点餐 条目", "", "", ActionLog.MESSAGE_ORDER, messageOrderBean);
                clickOrder(messageOrderBean);
            }
        });
    }

    private void clickOrder(MessageOrderBean messageOrderBean) {
        if (messageOrderBean.msgType == MessageConstance.TYPE_BOOK
                && messageOrderBean.businessStatus == MessageConstance.MessageOrderBuinessStatus.BOOK.NONE) {
            updateBookOrder(messageOrderBean);
        } else {
            chosedMsgId = messageOrderBean.msgId;
            if (msg_order_detail != null) {
                msg_order_detail.setDate(messageOrderBean);
            }
            if (msg_order_detail != null) {
                msg_order_detail.setVisibility(View.VISIBLE);
            }
            adapter.notifyDataSetChanged();
        }
    }

    private void updateBookOrder(final MessageOrderBean messageOrderBean) {
        ProgressManager.showProgress(host, R.string.message_please_wait);
        MessageUtil.updateOrderMessage(messageOrderBean.msgId, MessageConstance.MessageOrderBuinessStatus.BOOK.DOWN, new IResponse() {
            @Override
            public void callBack(boolean result, int code, String msg, Object info) {
                ProgressManager.closeProgress(host);
                if (!result) {
                    RunTimeLog.addLog(RunTimeLog.MESSAGE, msg);
                }
                messageOrderBean.businessStatus = MessageConstance.MessageOrderBuinessStatus.BOOK.DOWN;
                chosedMsgId = messageOrderBean.msgId;
                if (msg_order_detail != null) {
                    msg_order_detail.setDate(messageOrderBean);
                }
                if (msg_order_detail != null) {
                    msg_order_detail.setVisibility(View.VISIBLE);
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    /**
     * 添加日志
     *
     * @param log
     */
    private void addActionLog(String log) {
        ActionLog.waiterID = AppCache.getInstance().userDBModel.fsUserId;
        ActionLog.waiterName = AppCache.getInstance().userDBModel.fsUserName;
        ActionLog.addLog(log, "", "", ActionLog.MESSAGE_ORDER, "");
    }
}
