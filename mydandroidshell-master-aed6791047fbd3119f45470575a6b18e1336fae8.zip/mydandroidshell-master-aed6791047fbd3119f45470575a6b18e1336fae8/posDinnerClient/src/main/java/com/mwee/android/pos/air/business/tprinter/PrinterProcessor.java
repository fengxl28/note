package com.mwee.android.pos.air.business.tprinter;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.air.business.menu.api.MenuManagerApi;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.setting.process.PrintManagerProcess;
import com.mwee.android.pos.connect.business.print.GetAllPrinterResponse;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CTPrinter;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.print.printer.usbPriter.Device;
import com.mwee.android.print.printer.usbPriter.InitDeviceCallBack;
import com.mwee.android.print.printer.usbPriter.UsbBiz;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by qinwei on 2017/12/21.
 */

public class PrinterProcessor {
    private PrintManagerProcess mPrinterManagerProcessor;
    private Context context;

    public PrinterProcessor(Context context) {
        this.context = context;
        mPrinterManagerProcessor = new PrintManagerProcess(context);
    }

    /**
     * 得到所有的后台预制的打印机
     *
     * @param
     */
    public void loadAllPrinter(final ResultCallback<List<PrinterItem>> callback) {
        MCon.c(CTPrinter.class, new SocketCallback<GetAllPrinterResponse>() {
            @Override
            public void callback(SocketResponse<GetAllPrinterResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess(response.data.printerItems);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadAllPrinter();
    }

    public void loadAddPrinter(PrinterItem printerItem, final ResultCallback<Boolean> callback) {
        MCon.c(CTPrinter.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess(true);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadAddPrinter(printerItem);
    }


    public void loadUpdatePrinter(PrinterItem printerItem, final ResultCallback<Boolean> callback) {
        MCon.c(CTPrinter.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess(true);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadUpdatePrinter(printerItem);
    }

    public void loadDeletePrinter(int id, final ResultCallback<Boolean> callback) {
        MCon.c(CTPrinter.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess(true);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadDeletePrinter(id);
    }

    public static PrinterItem buildPrinterItem(int type) {
        PrinterItem item = new PrinterItem();
        item.fsCommandType = "ESC";
        item.type = type;
        return item;
    }

    /**
     * usb打印机搜索
     */
    public static void loadConnectUsbPrinter(final Activity context, final ResultCallback<ArrayList<PrinterItem>> callback) {
        UsbBiz usbBiz = new UsbBiz(context);
        usbBiz.initRefreshUsbDevice(new InitDeviceCallBack() {
            @Override
            public void finish(final List<Device> list) {
                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!ListUtil.isEmpty(list)) {
                            //搜索的USB打印机
                            ArrayList<PrinterItem> usbPrinters = new ArrayList<>();
                            for (Device device : list) {
                                LogUtil.log("device name--> " + device.name);
                                String matchName = device.name.replaceAll("\\([^)]+\\)", "");
                                LogUtil.log("match name--> " + matchName);
                                LogUtil.log("match symol--> " + device.symbol);
                                PrinterItem tempPrinter = PrinterProcessor.buildPrinterItem(PrinterType.USB);
                                tempPrinter.fsStr1 = device.symbol;
                                tempPrinter.name = matchName;
                                usbPrinters.add(tempPrinter);
                            }
                            callback.onSuccess(usbPrinters);
                        } else {
                            callback.onFailure(-1, "");
                        }
                    }
                });
            }
        });
    }

    /**
     * 蓝牙打印机搜索
     */
    public static void loadBluetoothPrinter(ResultCallback<ArrayList<PrinterItem>> callback) {
        ArrayList<PrinterItem> usbPrinters = new ArrayList<>();
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            Set<BluetoothDevice> bondedDevices = mBluetoothAdapter.getBondedDevices();
            if (bondedDevices != null && !bondedDevices.isEmpty()) {
                for (BluetoothDevice bluetoothDevice : bondedDevices) {
                    LogUtil.log("BluetoothDevice name-->" + bluetoothDevice.getName() + "  address--->" + bluetoothDevice.getAddress());
                    PrinterItem tempPrinter = PrinterProcessor.buildPrinterItem(PrinterType.BLUETOOTH);
                    tempPrinter.name = bluetoothDevice.getName();
                    tempPrinter.ip = bluetoothDevice.getAddress();
                    usbPrinters.add(tempPrinter);
                }
            }
        }
        callback.onSuccess(usbPrinters);
    }

    /**
     * 使用不同的打印机打印测试数据
     *
     * @param data
     */
    public void processDetectionPrinter(PrinterDBModel data) {
        if (data.fiPrinterCls == PrinterType.NET) {
            mPrinterManagerProcessor.processPrintNet(data);
        } else if (data.fiPrinterCls == PrinterType.USB) {
            mPrinterManagerProcessor.processUsbPrint(data);
        } else if (data.fiPrinterCls == PrinterType.USBSERIAL) {
            mPrinterManagerProcessor.processPrintUsbSerial(data);
        } else if (data.fiPrinterCls == PrinterType.SERIAL) {
            mPrinterManagerProcessor.proceePrintSerial(data);
        } else if (data.fiPrinterCls == PrinterType.BLUETOOTH) {
            mPrinterManagerProcessor.processBlueTooth(data);
        }
    }


    public PrinterDBModel copyToPrinterDBModel(PrinterItem printerItem) {
        PrinterDBModel model = new PrinterDBModel();
        model.fiID = 0;
        model.fsPrinterName = printerItem.name;
        model.fsIP = printerItem.ip;
        model.fiIsMakePrn = 1;
        model.fsCommandType = printerItem.fsCommandType;
        //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS  小散项目目前支持网口和USB口
        model.fiPrinterCls = printerItem.type;
        //--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fsStr1 = printerItem.fsStr1;
        model.fiInt1 = 0;
        // 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiPaperSize = printerItem.size;
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = "";
        model.fsUpdateUserId = "";
        model.fsUpdateUserName = DateUtil.getCurrentTime();
        model.fsShopGUID = AppCache.getInstance().fsShopGUID;
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        return model;
    }

    public void loadMenuCls(final ResultCallback<ArrayList<MenuClsBean>> callback) {
        MenuManagerApi.loadMenuManagerIndexData(false, new SocketCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void callback(SocketResponse<AllMenuClsAndMenuItemResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess((ArrayList<MenuClsBean>) response.data.menuClsBeanList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    /**
     * 拼接展示打印机类型
     *
     * @param cls
     * @return
     */
    public String getPrinterType(int cls) {
        StringBuffer sb = new StringBuffer();
        //1网口 / 2串口 / 3并口 / 4=USB口 / 4=KDS
        switch (cls) {
            case PrinterType.NET:
                sb.append("网口");
                break;
            case PrinterType.SERIAL:
                sb.append("串口");
                break;
            case PrinterType.PARELL:
                sb.append("并口");
                break;
            case PrinterType.USB:
                sb.append("USB口");
                break;
            case 5:
                sb.append("KDS");
                break;
            case PrinterType.BLUETOOTH:
                sb.append("蓝牙");
                break;
            case PrinterType.USBSERIAL:
                sb.append("USB(串口转接)");
                break;
            default:
                sb.append("");
                break;
        }
        return sb.toString();
    }


    /**
     * 更新指定的USB打印机
     */
    public static void updatePrinterConfig(String fsPrinterName, String fsStr1) {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                PrintConnector.getInstance().selectUsbDevice(fsPrinterName, fsStr1);
                return null;
            }
        });
    }

}
