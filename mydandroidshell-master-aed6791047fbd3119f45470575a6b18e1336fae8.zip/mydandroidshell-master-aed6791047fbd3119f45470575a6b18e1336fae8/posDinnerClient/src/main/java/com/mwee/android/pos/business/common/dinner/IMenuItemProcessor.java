package com.mwee.android.pos.business.common.dinner;

import android.util.ArrayMap;

import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by qinwei on 2017/9/22.
 */

public interface IMenuItemProcessor {
    /**
     * 菜品改数量处理
     *
     * @param menuItem
     * @param orderCache
     * @param callback
     */
    void doUpdateMenuItemBuyNumber(final MenuItem menuItem, final OrderCache orderCache, final ResultCallback<String> callback);

    /**
     * 改时价菜
     *
     * @param orderId  订单id
     * @param menuItem 菜品
     * @param callback 回调
     */
    void doUpdateDishPrice(final String orderId, final MenuItem menuItem, final ResultCallback<String> callback);

    void doUpdateMenuName(final String orderId, final MenuItem menuItem, final ResultCallback<String> callback);

    /**
     * 退菜业务逻辑
     *
     * @param orderId  订单id
     * @param item     退菜菜品
     * @param reason   退菜理由
     * @param callback
     */
    void doRetreatDish(final String orderId, final MenuItem item, final String reason, final ResultCallback<OrderCache> callback);

    /**
     * 单个菜品优惠处理
     *
     * @param item
     * @param listener
     */
    void doChangeMenuPrivilege(final MenuItem item, final SingleCouponFragment.OnSingleDiscountListener listener);

    /**
     * 单个菜品要求处理
     *
     * @param item
     * @param noteCallback
     */
    void doEditorMenuNoteContent(MenuItem item, NoteCallback noteCallback);

    /**
     * 批量要求
     *
     * @param callback
     */
    void doBatchRequest(List<MenuItem> reqMenuItems, final ResultCallback<String> callback);

    /**
     * 菜品编辑数据处理
     *
     * @param oldUnit
     * @param oldBuyNum
     * @param item
     */
    boolean doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item);

    /**
     * 催菜请求
     *
     * @param orderId
     * @param uniq
     * @param callback
     */
    void loadRemindersDish(String orderId, String uniq, final ResultCallback<String> callback);

    /**
     * 起菜处理
     *
     * @param orderId
     * @param seq      菜品唯一标示
     * @param callback
     */
    void loadDoDish(String orderId, String seq, final ResultCallback<String> callback);

    /**
     * 加退配料菜
     *
     * @param orderId  订单id
     * @param oldItem  修改之前菜品
     * @param newItem  修改之后菜品
     * @param callback call from main Thread
     */
    void doChangeIngredient(String orderId, MenuItem oldItem, MenuItem newItem, final ResultCallback<OrderCache> callback);

    /**
     * 加、退套餐子项
     *
     * @param orderId  订单id
     * @param oldItem  修改前的套餐
     * @param newItem  修改后的套餐
     * @param callback
     */
    void doChangePackageItems(String orderId, MenuItem oldItem, MenuItem newItem, PackageItemEditViewBean otherData, final ResultCallback<OrderCache> callback);

    void doBatchDiscount(final DinnerMultiDiscountCallBack callBack);

    void doUpdateMenuName(MenuItem menuItem, ResultCallback<String> callback);

    void loadPaddleDish(String orderId, List<String> seqList, ResultCallback<String> callback);

    /**
     * 划菜
     *
     * @param orderId       String | 订单号
     * @param menuWithCount ArrayMap | key - 点菜唯一标识, value - 划菜数量
     * @param callback      ResultCallback | callback
     */
    void loadPaddleDishV2(String orderId, ArrayMap<String, BigDecimal> menuWithCount, ResultCallback<String> callback);
}
