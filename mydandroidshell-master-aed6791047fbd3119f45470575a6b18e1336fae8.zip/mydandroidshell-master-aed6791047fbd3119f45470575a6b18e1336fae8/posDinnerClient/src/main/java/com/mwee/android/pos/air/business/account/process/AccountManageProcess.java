package com.mwee.android.pos.air.business.account.process;

import android.text.TextUtils;

import com.mwee.android.air.connect.business.account.GetAccountDetailResponse;
import com.mwee.android.air.connect.business.account.GetAllAccountResponse;
import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.air.business.account.api.AccountManageApi;
import com.mwee.android.pos.air.business.account.view.AccountManageFragment;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.util.ToastUtil;

/**
 * @ClassName: AccountManageProcess
 * @Description:
 * @author: SugarT
 * @date: 2017/10/12 下午2:56
 */
public class AccountManageProcess {

    private AccountManageFragment mView;

    public AccountManageProcess(AccountManageFragment view) {
        mView = view;
        mView.setProcess(this);
    }

    public void start() {
        AccountManageApi.getAllAccount(new IResponse<GetAllAccountResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAccountResponse info) {
                if (!result) {
                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "数据获取失败，请重试" : msg);
                    return;
                }
                mView.refreshAccounts(info.accountList);
            }
        });
    }

    public void queryAccountByID(String fsUserId) {
        AccountManageApi.getAccountDetail(fsUserId, new IResponse<GetAccountDetailResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAccountDetailResponse info) {
                if (!result) {
                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "数据获取失败，请重试" : msg);
                    return;
                }
                mView.editAccount(info.account, false);
            }
        });
    }

    public void add(AccountManageInfo model) {
        if (model == null) {
            return;
        }
        AccountManageApi.addAccount(model, new IResponse<GetAllAccountResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAccountResponse info) {
                if (!result) {
                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "数据获取失败，请重试" : msg);
                    return;
                }
                mView.refreshAccounts(info.accountList);
            }
        });
    }

    public void edit(final AccountManageInfo model) {
        if (model == null) {
            return;
        }
        AccountManageApi.updaetAccount(model, new IResponse<GetAllAccountResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAccountResponse info) {
                if (!result) {
                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "数据获取失败，请重试" : msg);
                    return;
                }
                mView.refreshAccounts(info.accountList);
            }
        });
    }

    /**
     * 删除用户
     *
     * @param fsUserId
     */
    public void delete(String fsUserId) {
        AccountManageApi.deleteAccount(fsUserId, new IResponse<GetAllAccountResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAccountResponse info) {
                if (!result) {
                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "数据获取失败，请重试" : msg);
                    return;
                }
                mView.refreshAccounts(info.accountList);
            }
        });
    }

    /**
     * 构建新用户
     *
     * @return
     */
    public AccountManageInfo buildNewUser() {
        AccountManageInfo result = new AccountManageInfo();
        return result;
    }
}
