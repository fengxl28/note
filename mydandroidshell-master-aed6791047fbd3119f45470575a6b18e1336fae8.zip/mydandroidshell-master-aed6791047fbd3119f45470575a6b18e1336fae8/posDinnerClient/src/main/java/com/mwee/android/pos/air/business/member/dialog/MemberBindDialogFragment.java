package com.mwee.android.pos.air.business.member.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.business.widget.EditorView;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.view.MemberCheckCallBack;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;

import java.lang.reflect.Method;

/**
 * 会员绑定
 * Created by qinwei on 2017/10/17.
 */

public class MemberBindDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mAskEditorTitleLabel;
    private TextView mMemberBindNameLabel;
    private TextView mMemberBindModbileLabel;
    private TextView mMemberBindCardLabel;
    private TextView mMemberBindBirthdayLabel;
    private TextView mMemberBindLevelLabel;
    private TextView mMemberBindBalanceLabel;
    private TextView mMemberBindScoreLabel;
    private Button mMemberBindRechargeBtn;
    private Button mMemberBindDoBindBtn;
    private EditorView mMemberBindAccountLabel;
    private NumberKeyboard mMemberBindNumberKeyboard;
    private MemberProcess mMemberProcess;
    private MemberCardModel member;
    private String bindOrderId;
    private MemberCheckCallBack call;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_bind_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initView(View view) {
        view.findViewById(R.id.mDialogCancelImg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissSelf();
            }
        });
        mAskEditorTitleLabel = (TextView) view.findViewById(R.id.mAskEditorTitleLabel);
        mMemberBindNameLabel = (TextView) view.findViewById(R.id.mMemberBindNameLabel);
        mMemberBindModbileLabel = (TextView) view.findViewById(R.id.mMemberBindModbileLabel);
        mMemberBindCardLabel = (TextView) view.findViewById(R.id.mMemberBindCardLabel);
        mMemberBindBirthdayLabel = (TextView) view.findViewById(R.id.mMemberBindBirthdayLabel);
        mMemberBindLevelLabel = (TextView) view.findViewById(R.id.mMemberBindLevelLabel);
        mMemberBindBalanceLabel = (TextView) view.findViewById(R.id.mMemberBindBalanceLabel);
        mMemberBindScoreLabel = (TextView) view.findViewById(R.id.mMemberBindScoreLabel);
        mMemberBindRechargeBtn = (Button) view.findViewById(R.id.mMemberBindRechargeBtn);
        mMemberBindDoBindBtn = (Button) view.findViewById(R.id.mMemberBindDoBindBtn);
        mMemberBindRechargeBtn.setOnClickListener(this);
        mMemberBindDoBindBtn.setOnClickListener(this);
        mMemberBindAccountLabel = (EditorView) view.findViewById(R.id.mMemberBindAccountLabel);
        disableShowSoftInput();
        mMemberBindNumberKeyboard = (NumberKeyboard) view.findViewById(R.id.mMemberBindNumberKeyboard);
        mMemberBindNumberKeyboard.setItemLayoutId(R.layout.view_key_item);
        mMemberBindNumberKeyboard.initData(KeyHelper.generateBackKeys(), keyEntity -> {
            switch (keyEntity.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    mMemberBindAccountLabel.input(keyEntity.value);
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CONFIRM:
                    loadMemberInfo(mMemberBindAccountLabel.getText().toString());
                    break;
                case NumberKeyboard.KeyEntity.TYPE_BACK:
                    mMemberBindAccountLabel.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL));
                    mMemberBindAccountLabel.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL));
                    break;
                default:
                    break;
            }
        });
        mMemberBindNumberKeyboard.notifyDataChanged();
        KeyboardManager.hideSoftInput(mMemberBindAccountLabel.getEditText());
    }

    public void disableShowSoftInput() {
        Class<EditText> cls = EditText.class;
        Method method;
        try {
            method = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
            method.setAccessible(true);
            method.invoke(mMemberBindAccountLabel.getEditText(), false);
        } catch (Exception e) {
        }

        try {
            method = cls.getMethod("setSoftInputShownOnFocus", boolean.class);
            method.setAccessible(true);
            method.invoke(mMemberBindAccountLabel.getEditText(), false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setMemberInfo(MemberCardModel member) {
        this.member = member;
        mMemberBindNameLabel.setText(member.card_info.real_name);
        mMemberBindModbileLabel.setText(member.card_info.mobile);
        mMemberBindCardLabel.setText(member.card_info.card_no);
        mMemberBindBirthdayLabel.setText(member.card_info.birthday);
        mMemberBindLevelLabel.setText(member.card_info.level_name);
        mMemberBindBalanceLabel.setText(member.card_data.amount.toPlainString());
        mMemberBindScoreLabel.setText(member.card_data.score + "");
        mMemberBindRechargeBtn.setEnabled(true);
        mMemberBindDoBindBtn.setEnabled(true);
    }

    private void loadMemberInfo(String content) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_query_ing);
        mMemberProcess.onlyLoadMemberInfo(content, new IResponse<QueryMemberInfoResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    setMemberInfo(info.memberCardModel);
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }


    private void initData() {
        mMemberProcess = new MemberProcess();
        mMemberBindRechargeBtn.setEnabled(false);
        mMemberBindDoBindBtn.setEnabled(false);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMemberBindRechargeBtn:
                showMemberBalanceRechargeDialog();
                break;
            case R.id.mMemberBindDoBindBtn:
                final Progress progress = ProgressManager.showProgressUncancel(this, "绑定中...");
                mMemberProcess.loadMemberInfoAndBindToOrder(member.card_info.mobile, bindOrderId, SettingHelper.isAutoUsedMemberPrice(), new IResponse<QueryMemberInfoAndBindToOrderResponse>() {

                    @Override
                    public void callBack(boolean result, int code, String msg, QueryMemberInfoAndBindToOrderResponse data) {
                        progress.dismissSelf();
                        if (result) {
                            call.call(data);
                            dismiss();
                        } else {
                            ToastUtil.showToast(msg);
                        }
                    }
                });
                break;
            default:
                break;
        }
    }

    private void showMemberBalanceRechargeDialog() {
        MemberBalanceRechargeDialog dialog = new MemberBalanceRechargeDialog();
        dialog.setParam(member.card_info.card_no, member.card_info.mobile);
        dialog.setOnMemberBalanceRechargeListener(new MemberBalanceRechargeDialog.OnMemberBalanceRechargeListener() {
            @Override
            public void onMemberBalanceRechargeSuccess() {
                loadMemberInfo(member.card_info.card_no);
            }
        });
        DialogManager.showCustomDialog(this, dialog, "MemberBalanceRechargeDialog");
    }

    public void setBindOrderId(String bindOrderId) {
        this.bindOrderId = bindOrderId;
    }

    public void setOnBindOrderListener(MemberCheckCallBack call) {
        this.call = call;
    }
}
