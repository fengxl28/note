package com.mwee.android.pos.business.bill.component;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.future.KBPayOrderListRequest;
import com.mwee.android.air.db.business.kbbean.future.KBPayOrderListResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.netpay.PosPaymentOrderRequest;
import com.mwee.android.pos.business.netpay.PosPaymentOrderResponse;
import com.mwee.android.pos.business.netpay.ScanPaymentOrderRequest;
import com.mwee.android.pos.business.netpay.ScanPaymentOrderResponse;
import com.mwee.android.pos.business.netpay.model.PosPaymentModelList;
import com.mwee.android.pos.business.netpay.model.ScanPaymentModel;
import com.mwee.android.pos.business.netpay.model.ScanPaymentModelList;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundRequest;
import com.mwee.android.pos.connect.business.bill.BillOnlineResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CBill;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 在线支付信息查询
 * Created by qinwei on 2017/1/11.
 */

public class BillOnlineProcess {
    /**
     * 查询秒付支付信息
     *
     * @param qryDate    日期
     * @param pageNumber 页码
     * @param callback   回调
     */
    public static void loadBillOnlineData(String qryDate, String bizType, String pageNumber, final IExecutorCallback callback) {
        MCon.c(CBill.class, new SocketCallback<BillOnlineResponse>() {
            @Override
            public void callback(SocketResponse<BillOnlineResponse> billOnlineResponseSocketResponse) {
                ResponseData responseData = new ResponseData();
                if (billOnlineResponseSocketResponse.code == SocketResultCode.SUCCESS) {
                    responseData.responseBean = billOnlineResponseSocketResponse.data.response;
                    callback.success(responseData);
                } else {
                    responseData.resultMessage = billOnlineResponseSocketResponse.message;
                    callback.fail(responseData);
                }
            }
        }).loadBillOnlineData(bizType, "-9999", qryDate, pageNumber, null);
    }

    public static void loadBillOnlineRefund(String payOrder, IExecutorCallback callback) {
        RapidRefundRequest refundRequest = new RapidRefundRequest();
        refundRequest.orderId = payOrder;
        BusinessExecutor.execute(refundRequest, callback);
    }

    /**
     * 查询扫码支付信息
     *
     * @param date     日期
     * @param pageNo   页码
     * @param callback 回调
     */
    public static void loadBillOnlineScannerData(String date, int pageNo, final ResultCallback<ScanPaymentModelList> callback) {
        ScanPaymentOrderRequest request = new ScanPaymentOrderRequest();
        request.startTime = date + " 00:00:00";
        request.endTime = date + " 23:59:59";
        request.pageSize = 20;
        request.pageNo = pageNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof ScanPaymentOrderResponse) {
                    ScanPaymentOrderResponse response = (ScanPaymentOrderResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof ScanPaymentOrderResponse) {
                    ScanPaymentOrderResponse response = (ScanPaymentOrderResponse) responseData.responseBean;
                    if (!ListUtil.isEmpty(response.data.result)) {
                        for (ScanPaymentModel scanPaymentModel : response.data.result) {
                            scanPaymentModel.fsMTableId = getTableNameById(scanPaymentModel.fsMTableId);
                        }
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        });
    }

    /**
     * 根据桌台ID获取桌台名称
     *
     * @param tableID String 桌台ID
     * @return String  桌台名称
     */
    public static String getTableNameById(String tableID) {
        if (TextUtils.isEmpty(tableID)) {
            return "";
        }
        String sql = "select fsmtablename from tbmtable where fistatus in (1,2) and fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.queryInfo(APPConfig.DB_CLIENT, sql, "fsmtablename", String.class);
    }

    /**
     * 查询全能pos支付信息
     *
     * @param date     日期
     * @param pageNo   页码
     * @param callback 回调
     */
    public static void loadBillOnlinePosData(String date, int pageNo, final ResultCallback<PosPaymentModelList> callback) {
        PosPaymentOrderRequest request = new PosPaymentOrderRequest();
        request.startTime = date + " 00:00:00";
        request.endTime = date + " 23:59:59";
        request.pageSize = 20;
        request.pageNo = pageNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof PosPaymentOrderResponse) {
                    PosPaymentOrderResponse response = (PosPaymentOrderResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 查询口碑后付列表
     *
     * @param date     指定日期
     * @param pageNo   当前加载页数
     * @param callback
     */
    public static void loadBillKBAfterPayList(String date, int pageNo, final ResultCallback<KBPayOrderListResponse.KBPayOrderList> callback) {
        KBPayOrderListRequest request = new KBPayOrderListRequest();
        request.pageNum = pageNo;
        request.shopGuid = AppCache.getInstance().fsShopGUID;
        request.sellDate = date;
        request.pageSize = 20;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof KBPayOrderListResponse) {
                    KBPayOrderListResponse response = (KBPayOrderListResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }
}
