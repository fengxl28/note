package com.mwee.android.pos.air.business.member.dialog;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.MemberInfoContainerFragment;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.SafeUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.DateUtil;

import java.util.Calendar;

/**
 * Created by qinwei on 2017/10/16.
 */

public class MemberEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mAskEditorTitleLabel;
    private EditText mMemberAddNameEdt;
    private EditText mMemberAddPhoneEdt;
    private TextView mMemberAddDateLabel;
    private RadioButton mMemberAddNanRB;
    private RadioButton mMemberAddNvRB;
    private EditText mMemberAddPasswordEdt;
    private EditText mMemberAddRePasswordEdt;
    private TextView mMemberAddCancelLabel;
    private TextView mMemberAddConfirmLabel;
    private MemberCardModel member;
    private MemberEditorProcessor mMemberEditorProcessor;
    private OnMemberEditorListener listener;
    private MemberProcess mMemberProcess;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initData() {
        mMemberEditorProcessor = new MemberEditorProcessor();
        mMemberProcess = new MemberProcess();
        if (isEditorMode()) {
            setMemberInfo();
            mAskEditorTitleLabel.setText("修改会员");
            mMemberAddPhoneEdt.setEnabled(false);
        } else {
            mAskEditorTitleLabel.setText("添加会员");
            mMemberAddPhoneEdt.setEnabled(true);
        }
    }

    private void setMemberInfo() {
        mMemberAddNameEdt.setText(member.card_info.real_name);
        mMemberAddPhoneEdt.setText(member.card_info.mobile);
        mMemberAddDateLabel.setText(member.card_info.birthday);
        if (member.card_info.gender == 1) {
            mMemberAddNanRB.setChecked(true);
        } else {
            mMemberAddNvRB.setChecked(true);
        }
    }


    private void initView(View view) {
        mAskEditorTitleLabel = (TextView) view.findViewById(R.id.mAskEditorTitleLabel);
        mMemberAddNameEdt = (EditText) view.findViewById(R.id.mMemberAddNameEdt);
        mMemberAddPhoneEdt = (EditText) view.findViewById(R.id.mMemberAddPhoneEdt);
        mMemberAddDateLabel = (TextView) view.findViewById(R.id.mMemberAddDateLabel);
        mMemberAddNanRB = (RadioButton) view.findViewById(R.id.mMemberAddNanRB);
        mMemberAddNvRB = (RadioButton) view.findViewById(R.id.mMemberAddNvRB);
        mMemberAddPasswordEdt = (EditText) view.findViewById(R.id.mMemberAddPasswordEdt);
        mMemberAddRePasswordEdt = (EditText) view.findViewById(R.id.mMemberAddRePasswordEdt);
        mMemberAddCancelLabel = (TextView) view.findViewById(R.id.mMemberAddCancelLabel);
        mMemberAddConfirmLabel = (TextView) view.findViewById(R.id.mMemberAddConfirmLabel);
        mMemberAddCancelLabel.setOnClickListener(this);
        mMemberAddConfirmLabel.setOnClickListener(this);
        mMemberAddDateLabel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMemberAddCancelLabel:
                DialogManager.showExecuteDialog(getActivityWithinHost(),
                        "会员信息将不会保存，是否确认取消？",
                        getStringWithinHost(R.string.cacel),
                        getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                            @Override
                            public void response() {
                                dismissSelf();
                            }
                        }, null);
                break;
            case R.id.mMemberAddConfirmLabel:
                String name = mMemberAddNameEdt.getText().toString().trim();
                String phone = mMemberAddPhoneEdt.getText().toString().trim();
                String birthday = mMemberAddDateLabel.getText().toString().trim();
                int sex = mMemberAddNanRB.isChecked() ? 1 : 2;
                String password = mMemberAddPasswordEdt.getText().toString().trim();
                String rePassword = mMemberAddRePasswordEdt.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    ToastUtil.showToast("请输入会员姓名！");
                    return;
                }
                if (TextUtils.isEmpty(phone)) {
                    ToastUtil.showToast("请输入会员手机号！");
                    return;
                }
                if (com.mwee.android.pos.util.TextUtils.validate(password, rePassword)) {
                    if (password.length() != 6) {
                        ToastUtil.showToast("请输入6位数密码");
                        return;
                    }

                    if (!com.mwee.android.pos.util.TextUtils.validatePayPassword(password)) {
                        ToastUtil.showToast("你的密码输入过于简单！");
                        return;
                    }
                    if (!password.equals(rePassword)) {
                        ToastUtil.showToast("两次输入密码不一致！");
                        return;
                    }
                }

                if (!com.mwee.android.pos.util.TextUtils.checkIsPhoneNumber(phone)) {
                    ToastUtil.showToast("请输入正确的手机号！");
                    return;
                }
                if (isEditorMode()) {
                    doUpdate(name, phone, birthday, sex, password);
                } else {
                    doAdd(name, phone, birthday, sex, password);
                }
                break;
            case R.id.mMemberAddDateLabel:
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), DatePickerDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        mMemberAddDateLabel.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                    }
                }, year, month, day);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.getDatePicker().setCalendarViewShown(false);
                datePickerDialog.getDatePicker().setSpinnersShown(true);
                datePickerDialog.show();
                break;
            default:
                break;
        }
    }

    public void showChoiceDate() {
        KeyboardManager.hideKeyboard(getActivity());
        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), getView());
        calendarPopupwindow.setDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                mMemberAddDateLabel.setText(newDate);
            }
        });
    }

    private void doUpdate(String name, String phone, String birthday, int sex, String password) {
        final Progress progress = ProgressManager.showProgress(this);
        mMemberEditorProcessor.loadUpdateMemberInfo(member.card_info.card_no, name, phone, birthday, sex, password, member.card_info.level, new ResultCallback<String>() {

            @Override
            public void onSuccess(String data) {
                ToastUtil.showToast("修改成功");
                if (listener != null) {
                    listener.onMemberEditorSuccess();
                }
                progress.dismissSelf();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void doAdd(String name, final String phone, String birthday, int sex, String password) {
        ProgressManager.showProgress(getActivityWithinHost());
        if (com.mwee.android.pos.util.TextUtils.validate(password)) {
            password = SafeUtil.sha1Encrypt(password + "cardmwee");
        }
        mMemberEditorProcessor.loadMemberAdd(name, phone, birthday, sex, password, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                doQuery(phone);
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                ToastUtil.showToast(msg);
            }
        });
    }

    private void doQuery(String phone) {
        mMemberProcess.onlyLoadMemberInfo(phone, new IResponse<QueryMemberInfoResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    showMemberInfoFragment(data.memberCardModel);
                } else {
                    dismissSelf();
                }
            }
        });
    }

    private void showMemberInfoFragment(MemberCardModel memberCardModel) {
        MemberInfoContainerFragment fragment = MemberInfoContainerFragment.getInstance(memberCardModel);
        FragmentController.addFragmentWithHide(getFragmentManager(), fragment, MemberInfoContainerFragment.TAG, R.id.main_menufragment, false);
        dismissSelf();
    }

    public void setParam(MemberCardModel member) {
        this.member = member;
    }

    public boolean isEditorMode() {
        return member != null;
    }

    public void setOnMemberEditorListener(OnMemberEditorListener listener) {
        this.listener = listener;
    }

    public interface OnMemberEditorListener {
        void onMemberEditorSuccess();
    }
}
