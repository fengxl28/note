package com.mwee.android.pos.air.business.setting;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.backup.ForceSetAsMainHost;
import com.mwee.android.pos.business.setting.view.MessageSettingFragment;
import com.mwee.android.pos.business.sync.api.LocalDataProcessorForDinner;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.UIHelp;

/**
 * Created by zhangmin on 2017/12/13.
 */

public class AirSetLocalFragment extends BaseFragment implements View.OnClickListener {


    private TextView tvDataSycnh;

    private RelativeLayout rlMessageLayout;

    private View rlVersionLayout;
    private TextView tvVersion;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_set_local_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        initData();
    }

    private void assignViews(View container) {


        tvDataSycnh = container.findViewById(R.id.tv_setting_data_synch);
        rlMessageLayout = container.findViewById(R.id.rlMessageLayout);
        rlVersionLayout = container.findViewById(R.id.rlVersionLayout);

        tvVersion = container.findViewById(R.id.tvVersion);
        tvVersion.setText(getString(R.string.setting_local_version_update_subtitle, BuildConfig.VERSION_NAME));


    }


    private void registerEvent() {

        tvDataSycnh.setOnClickListener(this);

        rlMessageLayout.setOnClickListener(this);

        rlVersionLayout.setOnClickListener(this);

    }


    private void initData() {

    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {

            case R.id.tv_setting_data_synch:
                ActionLog.addLog("更多设置->点击了数据同步", "", "", ActionLog.SS_MORE_JOIN, "");
                LocalDataProcessorForDinner.callUploadToCloud(this);
                break;
            /*本机设置*/
            case R.id.rlMessageLayout:
                ActionLog.addLog("更多设置->点击了消息中心设置", "", "", ActionLog.SS_MORE_JOIN, "");
               /* MessageSettingFragment messageSettingFragment = new MessageSettingFragment();
                FragmentController.addFragment(getActivityWithinHost(), messageSettingFragment);*/
                UIHelp.jumpContainerActivity(getActivityWithinHost(),"消息中心设置",MessageSettingFragment.class);
                break;
            case R.id.rlVersionLayout:
                ActionLog.addLog("更多设置->点击了版本检测", "", "", ActionLog.SS_MORE_JOIN, "");
                DriverBus.call("login/checkUpdate", this.getActivityWithinHost());

                if (AliHotFix.needRelaunch) {
                    DialogManager.showExecuteDialog(getActivityWithinHost(), R.string.setting_version_update, new DialogResponseListener() {
                        @Override
                        public void response() {
                            ForceSetAsMainHost.exitAllProcssAfterSeconds(getContext());
                        }
                    });
                }
                break;


            default:
                break;
        }

    }

}
