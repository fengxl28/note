package com.mwee.android.pos.business.member;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.member.adapter.MemberRechargeAdapter;
import com.mwee.android.pos.business.member.adapter.MemberRechargePayTypeAdapter;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.biz.RechargeProcess;
import com.mwee.android.pos.business.member.constant.MemberRechargeChoosePayType;
import com.mwee.android.pos.business.member.entity.RechargePayType;
import com.mwee.android.pos.business.member.view.MemberPrintProcess;
import com.mwee.android.pos.business.member.view.widget.CompatibleGridView;
import com.mwee.android.pos.business.pay.view.netpay.ICutomeNetPay;
import com.mwee.android.pos.business.pay.view.netpay.NetPayJump;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCardInfoModel;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 会员储值充值
 * Created by qinwei on 2017/2/21.
 */

public class BalanceRechargeFragment extends BaseFragment implements /*ICutomeNetPay,*/ View.OnClickListener {
    private static final String KEY_MEMBER_INFO = "key_member_info";
    public static String TAG = BalanceRechargeFragment.class.getName();
    private CompatibleGridView mMemberRechargesPayTypeGv;
    private ListView mMemberRechargeslv;
    private Button mMemberRechargeCommitBtn;
    private MemberRechargeAdapter mMemberRechargeAdapter;
    private MemberRechargePayTypeAdapter mMemberRechargePayTypeAdapter;
    private ArrayList<MemberRechargePackageModel.Rule> memberRechargePackages = new ArrayList<>();
    private ArrayList<RechargePayType> memberRechargePayTypes = new ArrayList<>();
//    private MemberProcess mMemberProcess;
    private NewMemberCardDetailsModel memberCardModel;
    private RechargeProcess rechargeProcess;

    public static BalanceRechargeFragment getInstance(NewMemberCardDetailsModel memberCardModel,List<MemberRechargePackageModel.Rule> rules) {
        BalanceRechargeFragment fragment = new BalanceRechargeFragment();
        fragment.memberRechargePackages.clear();
        fragment.memberRechargePackages.addAll(rules);
        Bundle args = new Bundle();
        args.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getContext()).inflate(R.layout.fragment_member_balance_recharge, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mMemberRechargeslv = (ListView) view.findViewById(R.id.mMemberRechargeslv);
        mMemberRechargesPayTypeGv = (CompatibleGridView) view.findViewById(R.id.mMemberRechargesPayTypeGv);
        mMemberRechargeCommitBtn = (Button) view.findViewById(R.id.mMemberRechargeCommitBtn);
        mMemberRechargeCommitBtn.setOnClickListener(this);
    }

    private void initData() {
//        mMemberProcess = new MemberProcess();
        memberCardModel = (NewMemberCardDetailsModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        rechargeProcess = new RechargeProcess(this,memberCardModel);
        memberRechargePayTypes.addAll(RechargePayType.getPayTypes());//初始化
        mMemberRechargeAdapter = new MemberRechargeAdapter(getActivity(), memberRechargePackages);
        mMemberRechargeslv.setAdapter(mMemberRechargeAdapter);
        mMemberRechargePayTypeAdapter = new MemberRechargePayTypeAdapter(getActivity(), memberRechargePayTypes);
        mMemberRechargesPayTypeGv.setAdapter(mMemberRechargePayTypeAdapter);
//        loadDataFromServer();
    }

    /*private void loadDataFromServer() {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_load_recharge_package_info_ing);
        mMemberProcess.loadMemberRechargePackages(memberCardModel.card_info.cs_id, new ResultCallback<ArrayList<MemberRechargePackageModel>>() {

            @Override
            public void onSuccess(ArrayList<MemberRechargePackageModel> data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (data.size() == 0) {
                    ToastUtil.showToast(R.string.member_load_recharge_package_info_msg);
                    return;
                }
                memberRechargePackages.clear();
                memberRechargePackages.addAll(data);
                mMemberRechargeAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                ToastUtil.showToast(msg);
            }
        });
    }*/


    @Override
    public void onClick(View v) {
        final RechargePayType payType = mMemberRechargePayTypeAdapter.getSelectRechargePayType();
        final MemberRechargePackageModel.Rule selectPackage = mMemberRechargeAdapter.getSelectPackage();
        if (payType == null) {
            ToastUtil.showToast(R.string.member_recharge_choice_pay_type_msg);
            return;
        }
        if (selectPackage == null) {
            ToastUtil.showToast(R.string.member_recharge_choice_package_msg);
            return;
        }
        /*PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance().userDBModel, Permission.DINNER_vTempVIPAuth, new PermissionCallback() {
            @Override
            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                switch (payType.type) {
                    case MemberRechargeChoosePayType.CASH:
                        doCash(selectPackage, payType);
                        break;
                    case MemberRechargeChoosePayType.ALIPAY:
                    case MemberRechargeChoosePayType.WECHAT:
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付" + selectPackage.toString());
                        //ActionLog.addLog("点击网络支付", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, "");
                        NetPayJump.jumpToMemberChargePay(getActivityWithinHost(), new BigDecimal(selectPackage.money), payType.type, BalanceRechargeFragment.this);
                        break;
                    default:
                        break;
                }
            }
        });*/

        rechargeProcess.charge(selectPackage,payType,new BigDecimal(selectPackage.money));

    }

    /*private void doCash(final MemberRechargePackageModel selectPackage, final RechargePayType payType) {
        //RunTimeLog.addLog(RunTimeLog.MEMBER,"现金充值" + selectPackage.toString());
        ActionLog.addLog("现金充值", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, selectPackage);
        if (memberCardModel != null && memberCardModel.cardInfo != null) {
            MemberCardInfoModel memberCardInfoCache = memberCardModel.card_info;
            ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.member_recharge_ing);
            mMemberProcess.loadCashRechargeRequest(StringUtil.toInt(selectPackage.id), new BigDecimal(selectPackage.money), memberCardInfoCache.pay_code, memberCardInfoCache.card_no, new ResultCallback<QueryNewMembeChargeResultModel>() {
                @Override
                public void onSuccess(QueryNewMembeChargeResultModel data) {
                    ProgressManager.closeProgress(getActivityWithinHost());
                    if (data == null) {
                        ToastUtil.showToast("现金充值失败");
                    } else {
                        ActionLog.addLog("现金充值成功", "", "", ActionLog.MEMBER_RECHARGE_PRICE, selectPackage);
                        doMemberRechargeOrderRequest(data.trade_no, "充值" + selectPackage.money + "元 " + selectPackage.present_desc, payType);

                    }

                }

                @Override
                public void onFailure(int code, String msg) {
                    ProgressManager.closeProgress(getActivityWithinHost());
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "现金充值失败" + msg);
                    ToastUtil.showToast(msg);
                }
            });
        }
    }

    private void doMemberRechargeOrderRequest(String trade_no, final String rechargeDesc, final RechargePayType payType) {
        ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.member_recharge_syn_ing);
        RunTimeLog.addLog(RunTimeLog.MEMBER, "同步充值结果ing trade_no:" + trade_no);
        //ActionLog.addLog("同步充值结果ing", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, "trade_no:" + trade_no);
        mMemberProcess.loadMemberRechargeOrderRequest(trade_no, new ResultCallback<MemberRechargeOrderModel>() {
            @Override
            public void onSuccess(MemberRechargeOrderModel data) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "同步充值结果done MemberRechargeOrderModel:", data.toString());
                //ActionLog.addLog("同步充值结果done", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, data);
                ProgressManager.closeProgress(getActivityWithinHost());
                DriverBus.call("member/rechargeSuccess");
                //充值成功后，打印会员充值小票
                data.content = rechargeDesc;
                String printMemberName = TextUtils.isEmpty(memberCardModel.card_info.real_name) ? memberCardModel.card_info.nick : memberCardModel.card_info.real_name;
                MemberPrintProcess.printCharge(getActivityWithinHost(), data, payType.name, printMemberName);
                doBalanceOrderListRefresh();
                RechargeSuccessPageFragment fragment = RechargeSuccessPageFragment.getInstance(data);
                //显示充值成功页面
                FragmentController.addFragmentWithHide(getFragmentManager(), fragment, fragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);
                RunTimeLog.addLog(RunTimeLog.MEMBER, "跳转到支付成功界面");
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                RunTimeLog.addLog(RunTimeLog.MEMBER, "同步充值结果fail", msg);
                // ActionLog.addLog("同步充值结果fail", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, msg);
                ToastUtil.showToast(TextUtils.isEmpty(msg) ? "请手动刷新储值列表页" : msg);
            }
        });
    }

    *//**
     * 刷新会员储值流水界面
     *//*
    private void doBalanceOrderListRefresh() {
        if (getActivityWithinHost() != null) {
            BalanceChangesListFragment fragment = (BalanceChangesListFragment) getActivityWithinHost().getSupportFragmentManager().findFragmentByTag(BalanceChangesListFragment.class.getName());
            if (fragment != null && fragment.isAdded()) {
                fragment.doRefresh();
            }
        }
    }

    *//**
     * 充值
     *
     * @param type
     * @param micro
     * @param callback
     *//*
    @Override
    public void callPay(int type, String micro, final IResponse<QueryNewMembeChargeResultModel> callback) {
        if (memberCardModel != null) {
            final MemberRechargePackageModel selectPackage = mMemberRechargeAdapter.getSelectPackage();
            MemberCardInfoModel memberCardInfoCache = memberCardModel.card_info;
            if (memberCardInfoCache != null) {
                ProgressManager.showProgressUncancel(getActivityWithinHost(), "在线支付充值中...");
                RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付ing,type=" + type + " micro=" + micro);
                //ActionLog.addLog("网络支付ing,type=" + type + " micro=" + micro, "", "", ActionLog.MEMBER_BALANCE_RECHARGE, "");
                mMemberProcess.loadOnlineRechargeRequest(StringUtil.toInt(selectPackage.id), new BigDecimal(selectPackage.money), memberCardInfoCache.pay_code, type, micro, memberCardInfoCache.card_no, new ResultCallback<QueryNewMembeChargeResultModel>() {
                    @Override
                    public void onSuccess(QueryNewMembeChargeResultModel data) {
                        if (Looper.myLooper() != Looper.getMainLooper()) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    onSuccess(data);
                                }
                            });
                            return;
                        }
                        ActionLog.addLog("网络支付成功", "", "", ActionLog.MEMBER_RECHARGE_PRICE, selectPackage);
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (callback != null) {
                            callback.callBack(true, data.pay_status, data.pay_status_msg, data);
                        }

                        if (data.pay_status == 1) {
                            doMemberRechargeOrderRequest(data.trade_no, "充值" + selectPackage.money + "元 " + selectPackage.present_desc, mMemberRechargePayTypeAdapter.getSelectRechargePayType());
                        }
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        if (Looper.myLooper() != Looper.getMainLooper()) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    onFailure(code, msg);
                                }
                            });
                            return;
                        }
                        ProgressManager.closeProgress(getActivityWithinHost());
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付FAIL " + msg);
                        //ActionLog.addLog("网络支付FAIL", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, msg);
                        if (callback != null) {
                            callback.callBack(false, code, msg, null);
                        }
                        ToastUtil.showToast(msg);
                    }
                });
            }
        }
    }

    *//**
     * 查询充值结果
     *
     * @param tradeNo
     * @param callback
     *//*
    @Override
    public void queryPayResult(String tradeNo, IResponse<QueryNewMembeChargeResultModel> callback) {
        if (memberCardModel != null) {
            final MemberRechargePackageModel selectPackage = mMemberRechargeAdapter.getSelectPackage();
            MemberCardInfoModel memberCardInfoCache = memberCardModel.card_info;
            if (memberCardInfoCache != null) {
                ProgressManager.showProgressUncancel(getActivityWithinHost(), "查询中...");
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查询会员充值网络支付结果,tradeNo=" + tradeNo);
                //ActionLog.addLog("网络支付ing,type=" + type + " micro=" + micro, "", "", ActionLog.MEMBER_BALANCE_RECHARGE, "");
                mMemberProcess.queryOnlineRechargeRequest(tradeNo, new ResultCallback<QueryNewMembeChargeResultModel>() {
                    @Override
                    public void onSuccess(QueryNewMembeChargeResultModel data) {
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "查询会员充值网络支付结果done ", data.toString());
                        // ActionLog.addLog("网络支付done", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, data);
                        if (Looper.myLooper() != Looper.getMainLooper()) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    onSuccess(data);
                                }
                            });
                            return;
                        }
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (callback != null) {
                            callback.callBack(true, data.pay_status, data.pay_status_msg, data);
                        }
                        if (data.pay_status == 1) {
                            doMemberRechargeOrderRequest(data.trade_no, "充值" + selectPackage.money + "元 " + selectPackage.present_desc, mMemberRechargePayTypeAdapter.getSelectRechargePayType());
                        }
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        if (Looper.myLooper() != Looper.getMainLooper()) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    onFailure(code, msg);
                                }
                            });
                            return;
                        }
                        ProgressManager.closeProgress(getActivityWithinHost());
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "查询会员充值网络支付结果FAIL " + msg);
                        //ActionLog.addLog("网络支付FAIL", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, msg);
                        if (callback != null) {
                            callback.callBack(false, code, msg, null);
                        }
                        ToastUtil.showToast(msg);
                    }
                });
            }
        }
    }*/
}
