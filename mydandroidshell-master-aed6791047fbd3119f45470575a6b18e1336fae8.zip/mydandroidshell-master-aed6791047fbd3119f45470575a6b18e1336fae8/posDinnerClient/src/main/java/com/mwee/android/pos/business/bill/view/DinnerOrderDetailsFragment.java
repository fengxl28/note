package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.bill.api.BillApi;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.bean.GetOrderDetailsResponse;
import com.mwee.android.pos.connect.business.bean.model.OrderDetailsModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.tools.DateUtil;

/**
 * 订单详情页
 */
public class DinnerOrderDetailsFragment extends BaseFragment {
    public static final String TAG = "DinnerOrderDetailsFragment";

    private String mOrderId;
    private boolean isKoubei;
    private OrderDetailsModel mOrderDetails;
    private View inc_kb_order_head, order_head_1, order_head_2;
    private TextView tv_order_id;
    private TextView tv_date;
    private TextView tv_shift;
    private TextView tv_table;
    private TextView tv_create;
    private TextView tv_pay;
    private TextView tv_person;
    private TextView tv_pay_time;
    private TextView tv_total;
    private TextView tv_discount;
    private TextView tv_round;
    private TextView tv_should_pay;
    private TextView tv_note;
    private OrderDetailsView view_order_details;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dinner_order_details, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        inc_kb_order_head = view.findViewById(R.id.inc_kb_order_head);
        order_head_1 = view.findViewById(R.id.order_head_1);
        order_head_2 = view.findViewById(R.id.order_head_2);

        tv_order_id = view.findViewById(R.id.tv_order_id);
        tv_date = view.findViewById(R.id.tv_date);
        tv_shift = view.findViewById(R.id.tv_shift);
        tv_table = view.findViewById(R.id.tv_table);
        tv_create = view.findViewById(R.id.tv_create);
        tv_pay = view.findViewById(R.id.tv_pay);
        tv_person = view.findViewById(R.id.tv_person);
        tv_pay_time = view.findViewById(R.id.tv_pay_time);

        tv_total = view.findViewById(R.id.tv_total);
        tv_discount = view.findViewById(R.id.tv_discount);
        tv_round = view.findViewById(R.id.tv_round);
        tv_should_pay = view.findViewById(R.id.tv_should_pay);

        tv_note = view.findViewById(R.id.tv_note);

        view_order_details = view.findViewById(R.id.view_order_details);

        TitleBar titleBar = view.findViewById(R.id.mTitleBar);
        titleBar.setTitle("订单详情");
        titleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });

        refreshViews();
    }

    private void initData() {
        ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.bill_loading_order_details);
        BillApi.getOrderDetails(mOrderId, isKoubei, new SocketCallback<GetOrderDetailsResponse>() {
            @Override
            public void callback(SocketResponse<GetOrderDetailsResponse> response) {
                if (response != null) {
                    if (response.code == SocketResultCode.SUCCESS) {
                        if (response.data != null) {
                            mOrderDetails = response.data.orderDetails;
                            refreshViews();
                        }
                    } else {
                        ToastUtil.showToast(response.message);
                    }
                }
                ProgressManager.closeProgress(getActivityWithinHost());
            }
        });
    }

    private void refreshViews() {
        tv_order_id.setText(mOrderId);
        if (mOrderDetails != null) {
            if (mOrderDetails.thirdOrderType == NetOrderType.KB_ORDER) {// 口碑
                inc_kb_order_head.setVisibility(View.VISIBLE);
                order_head_1.setVisibility(View.GONE);
                order_head_2.setVisibility(View.GONE);

                ((TextView) inc_kb_order_head.findViewById(R.id.tv_kb_order_id)).setText(mOrderDetails.thirdOrderId);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_eat_method)).setText(mOrderDetails.dinner_type);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_get_meal_number)).setText(mOrderDetails.mealNumber);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_kb_mw_order_id)).setText(mOrderDetails.orderID);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_order_time)).setText(mOrderDetails.createTimeOrder);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_person)).setText(mOrderDetails.personNum + "");
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_reservation_time)).setText(mOrderDetails.table_time);
                ((TextView) inc_kb_order_head.findViewById(R.id.tv_phone)).setText(mOrderDetails.user_mobile);
                ((TextView) rootView.findViewById(R.id.tv_discount_label)).setText("优惠明细：");
                rootView.findViewById(R.id.tv_round_label).setVisibility(View.GONE);
                rootView.findViewById(R.id.tv_round).setVisibility(View.GONE);
            } else {
                inc_kb_order_head.setVisibility(View.GONE);
                order_head_1.setVisibility(View.VISIBLE);
                order_head_2.setVisibility(View.VISIBLE);

                tv_date.setText(mOrderDetails.businessDate);
                tv_shift.setText(mOrderDetails.payShiftName);
                if (mOrderDetails.fiSellType == 0) {//正餐
                    tv_table.setText(mOrderDetails.fsmtablename);
                } else if (mOrderDetails.fiSellType == 1) {//快餐
                    tv_table.setText(mOrderDetails.mealNumber);
                }
                tv_create.setText(mOrderDetails.orderWaiterName);
                tv_pay.setText(mOrderDetails.orderWaiterName);
                tv_person.setText(mOrderDetails.personNum + "");
                tv_pay_time.setText(DateUtil.formartDateStrToTarget(mOrderDetails.payTime, DateUtil.DATE_VISUAL14FORMAT, "HH:mm"));
            }
            tv_total.setText(Calc.formatShow(mOrderDetails.totalPrice));
            tv_discount.setText(Calc.formatShow(mOrderDetails.totalDiscount));
            tv_round.setText(Calc.formatShow(mOrderDetails.totalRound));
            tv_should_pay.setText(Calc.formatShow(mOrderDetails.priceLeftToPay));
            tv_note.setText(mOrderDetails.orderNote);
            view_order_details.setParams(getActivityWithinHost(), mOrderDetails.menuItemList, mOrderDetails.payList, null);
        }
    }

    public void setParam(String orderId, boolean isKoubei) {
        this.mOrderId = orderId;
        this.isKoubei = isKoubei;
    }
}
