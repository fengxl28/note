package com.mwee.android.pos.business.message;

import android.content.Context;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.mwee.android.pos.business.netorder.NetOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/01/26.
 */

public class NetOrderDetailAdapter extends BaseExpandableListAdapter {

    private Context mContext;

    public int selectPosition = -1;

    /**
     * 头部数据
     */
    public List<Integer> orderSeqModels = new ArrayList<>();

    /**
     * 子数据
     */
    private SparseArray<List<TempAppOrderDetail>> menuChildSpare = new SparseArray<>();


    public NetOrderDetailAdapter(Context context) {
        super();
        this.mContext = context;
    }

    public void notifyDataSetChanged(List<List<TempAppOrderDetail>> orderDetailSparseArray) {

        this.orderSeqModels.clear();
        menuChildSpare.clear();
        if (orderDetailSparseArray != null && orderDetailSparseArray.size() > 0) {
            for (int i = 1; i <= orderDetailSparseArray.size(); i++) {
                orderSeqModels.add(i);
                menuChildSpare.put(i, orderDetailSparseArray.get(i - 1));
            }
        }
        this.notifyDataSetChanged();

    }


    @Override
    public int getGroupCount() {

        return ListUtil.isEmpty(orderSeqModels) ? 0 : orderSeqModels.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return ListUtil.isEmpty(menuChildSpare.get(orderSeqModels.get(groupPosition))) ? 0 : menuChildSpare.get(orderSeqModels.get(groupPosition)).size();
    }

    @Override
    public Integer getGroup(int groupPosition) {
        return orderSeqModels.get(groupPosition);
    }

    @Override
    public TempAppOrderDetail getChild(int groupPosition, int childPosition) {
        return menuChildSpare.get(orderSeqModels.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean childPosition, View convertView, ViewGroup parent) {

        View headView = LayoutInflater.from(mContext).inflate(R.layout.textview_item, parent, false);
        TextView tvTitle = headView.findViewById(R.id.tvTitle);
        if (getChildrenCount(groupPosition) == 0) {
            tvTitle.setVisibility(View.GONE);
        } else {
            tvTitle.setVisibility(View.VISIBLE);
            tvTitle.setText(String.valueOf(getGroup(groupPosition) + "号口袋"));
        }
        return headView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean b, View convertView, ViewGroup parent) {
        NetOrderDetailAdapter.ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.net_order_detail_item, parent, false);
            holder = new NetOrderDetailAdapter.ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (NetOrderDetailAdapter.ViewHolder) convertView.getTag();
        }
        holder.bindData(groupPosition, childPosition);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    class ViewHolder implements View.OnClickListener {
        private View itemView;

        private TempAppOrderDetail menuItem;

        private TextView tv_item_name;//菜品名称
        private TextView tv_item_price;//备注
        private TextView tv_item_qty;//点菜份数
        private TextView tv_item_total;//退菜数量

        private TextView modifier;//菜品金额
        private TextView itemProperties;//菜品金额


        public ViewHolder(View v) {
            itemView = v;
            tv_item_name = (TextView) v.findViewById(R.id.tv_item_name);
            tv_item_price = (TextView) v.findViewById(R.id.tv_item_price);
            tv_item_qty = (TextView) v.findViewById(R.id.tv_item_qty);
            tv_item_total = v.findViewById(R.id.tv_item_total);
            modifier = (TextView) v.findViewById(R.id.modifier);
            itemProperties = (TextView) v.findViewById(R.id.itemProperties);

            itemView.setOnClickListener(this);
        }

        /**
         * ui处理
         */
        public void bindData(int groupPosition, int childPosition) {
            menuItem = getChild(groupPosition, childPosition);
            tv_item_name.setText(menuItem.itemName);
            tv_item_price.setText(Calc.formatShow(menuItem.itemPrice));
            tv_item_total.setText(Calc.formatShow(menuItem.totalItemPrice));
            tv_item_qty.setText("x" + menuItem.itemNum);

            String modifierStr = NetOrder.formatModifierNotes(menuItem.modifiertypes);
            if (TextUtils.isEmpty(modifierStr)) {
                modifier.setVisibility(View.GONE);
            } else {
                modifier.setVisibility(View.VISIBLE);
                modifier.setText(modifierStr);
            }


            if (TextUtils.isEmpty(menuItem.itemProperties)) {
                itemProperties.setVisibility(View.GONE);
            } else {
                itemProperties.setVisibility(View.VISIBLE);
                itemProperties.setText(menuItem.itemProperties);
            }


        }

        @Override
        public void onClick(View v) {
        }


    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }


}
