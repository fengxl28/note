package com.mwee.android.pos.business.boot;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogParamBundle;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.permission.REQUEST;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ChannelUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.log.LogUpload;

import java.lang.ref.WeakReference;


public class WelcomeForBizCenter extends BaseActivity implements WelcomeContract.View {

    private boolean perFinish = false;
    private boolean aniFinish = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    /**
     * 插件是否加载完成
     */
    private boolean mPluginFinished = false;
    private Progress mPluginProgress;

    private void doNext() {
        if (perFinish && aniFinish && mPluginFinished) {
            mPluginProgress.dismiss();
            mPresenter.checkAndLoadData();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        new WelcomePresenter(this);
        super.onCreate(savedInstanceState);
        mPluginProgress = ProgressManager.showProgressUncancel(getNHost(), "正在加载插件");
        new LaunchProcessor().start(ClientMetaUtil.getSettingsValueByKey(META.SHOPID));
        initView();
    }

    protected void initView() {
        mPresenter.requestPermission();

        if (ChannelUtil.isKouBei() || (APPConfig.fiWorkMode == 1 && TextUtils.equals(ClientCommonDBUtil.getConfigWithDefault(DBOrderConfig.KB_LOGIN, "0"), "1"))) {
            setContentView(R.layout.activity_koubei_welcome);
        } else {
            setContentView(R.layout.activity_welcome);
        }
        TextView mSystemVersionNameLabel = (TextView) findViewById(R.id.mSystemVersionNameLabel);
        if (mSystemVersionNameLabel != null) {
            mSystemVersionNameLabel.setText("版本号:" + BuildConfig.VERSION_NAME);
        }
        ObjectAnimator anim = ObjectAnimator.ofFloat(android.R.id.content, "alpha", 0f, 1f).setDuration(2000);
        anim.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                aniFinish = true;

                if (ClientBindProcessor.isCurrentHostMain()) {
                    // 发送空消息，通过回调判断插件加载完成(通过 Messenger 发送的消息，Plugin 未加载完成，将会被阻塞)
                    ServerConnector.getInstance().sendExecute(new WelcomeServerCallback(WelcomeForBizCenter.this),
                            "biz/callUdpBroad");
                } else {
                    mPluginFinished = true;
                    doNext();
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        anim.start();
        LogUpload.callUpload();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 插件加载最多等待30秒
        handler.postDelayed(new DelayRunnable(WelcomeForBizCenter.this),
                30 * 1000);
    }

    private static class DelayRunnable implements Runnable {
        WeakReference<WelcomeForBizCenter> weakReference;

        public DelayRunnable(WelcomeForBizCenter reference) {
            this.weakReference = new WeakReference<WelcomeForBizCenter>(reference);
        }

        @Override
        public void run() {
            WelcomeForBizCenter welcomeForBizCenter = weakReference.get();
            if (welcomeForBizCenter != null && !welcomeForBizCenter.isDestroyed()) {
                if (!welcomeForBizCenter.mPluginFinished) {
                    welcomeForBizCenter.mPluginFinished = true;
                    welcomeForBizCenter.doNext();
                }
            }
        }
    }

    private static class WelcomeServerCallback implements IResult {
        WeakReference<WelcomeForBizCenter> weakReference;

        public WelcomeServerCallback(WelcomeForBizCenter weakReference) {
            this.weakReference = new WeakReference<WelcomeForBizCenter>(weakReference);
        }

        @Override
        public void callBack(boolean result, String info) {
            WelcomeForBizCenter welcomeForBizCenter = weakReference.get();
            if (welcomeForBizCenter != null) {
                if (result) {
                    welcomeForBizCenter.mPluginFinished = true;
                    welcomeForBizCenter.doNext();
                } else {
                    welcomeForBizCenter.doNext();
                }
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void jump() {
        if (!TextUtils.isEmpty(AppCache.getInstance().isAllDataInLaw)) {
            DialogParamBundle.Builder bundle = new DialogParamBundle.Builder();
            bundle.setCancelable(false).setPositiveBtnText("重试").setPositiveClick(new DialogResponseListener() {
                @Override
                public void response() {
                    mPresenter.checkAndLoadData();
                }
            }).setNegativeBtnText("退出").setNegitiveveClick(new DialogResponseListener() {
                @Override
                public void response() {
                    finish();
                }
            }).setContentText(AppCache.getInstance().isAllDataInLaw + ",请在后台进行配置之后点击\"重试\"");
            DialogManager.showExecuteDialog(this, bundle.build());
            AppCache.getInstance().isAllDataInLaw = "";
            return;
        }
        UIHelp.startLoginDinnerActvity(this);
        finish();
        if (!BaseConfig.isProduct()) {
            LogUtil.log("init token=" + AppCache.getInstance().token);
            LogUtil.log("init seed=" + AppCache.getInstance().seed);
        }
    }

    @Override
    public void handlerClickEvent(View v) {
        super.handlerClickEvent(v);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST.PERMISSIONS_SETTING:
                mPresenter.requestPermission();
                break;
            case REQUEST_MANAGE_OVERLAY_PERMISSION:
                perFinish = true;
                doNext();
                break;
            default:
                break;
        }
    }

    private static final int REQUEST_MANAGE_OVERLAY_PERMISSION = 1;

    /**
     * 请求权限
     */
    private void requestAlertWindowPermission() {
        DialogManager.showExecuteDialog(this, "是否开启消息通知", "建议开启，关闭后外卖订单将无法推送提醒", "否", "是（建议开启）", () -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_MANAGE_OVERLAY_PERMISSION);
        }, () -> {
            perFinish = true;
            doNext();
        });
    }

    private WelcomeContract.Presenter mPresenter;

    @Override
    public void setPresenter(WelcomeContract.Presenter presenter) {
        mPresenter = presenter;
    }

    @Override
    public Host getNHost() {
        return this;
    }

    @SuppressLint("NewApi")
    @Override
    public void grantedPermission() {
        // added in API level 23
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (Settings.canDrawOverlays(this)) {
                perFinish = true;
                doNext();
            } else {
                requestAlertWindowPermission();
            }
        } else {
            perFinish = true;
            doNext();
        }
    }

    @Override
    public void initDataCompleted() {
        ProgressManager.closeProgress(this);
        jump();
    }

    @Override
    public void progress(String content) {
    }

    @Override
    public void closeProgress() {
    }
}
