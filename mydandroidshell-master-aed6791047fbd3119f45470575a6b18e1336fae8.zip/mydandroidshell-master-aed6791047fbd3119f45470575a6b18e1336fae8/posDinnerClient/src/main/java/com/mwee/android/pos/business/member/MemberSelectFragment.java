package com.mwee.android.pos.business.member;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.base.ContainerFragmentActivity;
import com.mwee.android.pos.air.business.member.fragment.MemberConsumptionRecordingFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberRechargeRecordingFragment;
import com.mwee.android.pos.air.business.member.utils.MemberUtils;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.member.biz.IMemberProcess;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.business.bean.CheckCardTypeResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.business.setting.GetConfigArrayResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.NetWorkUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 会员识别界面
 * Created by qinwei on 2017/2/20.
 */

public class MemberSelectFragment extends HomeFragment implements View.OnClickListener, TextView.OnEditorActionListener {
    public static final String TAG = MemberSelectFragment.class.getSimpleName();
    private EditText mMemberSelectEdt;
    private Button mMemberSelectCommitBtn;
    private Button bindCard;
    private IMemberProcess mMemberProcess;
    private Button mMemberRechargeListBtn;
    private Button mMemberBalanceUsedListBtn;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_query, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMemberSelectEdt = (EditText) view.findViewById(R.id.mMemberSelectEdt);

        mMemberSelectEdt.postDelayed(new Runnable() {
            @Override
            public void run() {
                mMemberSelectEdt.setText("");
            }
        }, 50);
        mMemberSelectEdt.setOnEditorActionListener(this);
        mMemberSelectCommitBtn = (Button) view.findViewById(R.id.mMemberSelectCommitBtn);
        bindCard = (Button) view.findViewById(R.id.bindCard);
        mMemberRechargeListBtn = (Button) view.findViewById(R.id.mMemberRechargeListBtn);
        mMemberBalanceUsedListBtn = (Button) view.findViewById(R.id.mMemberBalanceUsedListBtn);
        mMemberSelectCommitBtn.setOnClickListener(this);
        mMemberRechargeListBtn.setOnClickListener(this);
        mMemberBalanceUsedListBtn.setOnClickListener(this);
        bindCard.setOnClickListener(MemberSelectFragment.this);

        mMemberProcess = new MemberProcess();
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        if (v.getId() == R.id.bindCard) {
            //开卡
//            BindThirdCardFragment fragment = new BindThirdCardFragment();
            if (NetWorkUtil.isNetworkAvailable(getContextWithinHost())) {

                CheckCardTypeFragment checkCardTypeFragment = new CheckCardTypeFragment();
                checkCardTypeFragment.setCallback(new CheckCardTypeCallback() {
                    @Override
                    public void callback(String cardNumber, String cardType, String msg) {
                        if (android.text.TextUtils.equals("2", cardType)) {
                            //不记名激活卡
                            showNoNameCard(cardNumber, cardType);
                        } else {
                            showBindCard(cardNumber, cardType);
                        }
                    }
                });
                DialogManager.showCustomDialog(MemberSelectFragment.this, checkCardTypeFragment, CountKeyboardFragment.FRAGMENT_TAG);
            } else {
                ToastUtil.showToast("当前无网络，请检查网络");
            }
        } else if (v.getId() == R.id.mMemberSelectCommitBtn) {
            String account = TextUtils.formatSpace(mMemberSelectEdt.getText().toString().trim());
            if (validateInput(account)) {
                doSelectRequest(account);
            }
        } else if (v.getId() == R.id.mMemberRechargeListBtn) {
            String number = TextUtils.formatSpace(mMemberSelectEdt.getText().toString().trim());

            Bundle bundle = new Bundle();
            if (!android.text.TextUtils.isEmpty(number)) {
                if (MemberUtils.checkIsPhoneNumber(number) || MemberUtils.checkIsCardNo(number)) {
                    bundle.putSerializable("key_member_info", number);
                }
            }
            Intent intent = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
            intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("储值记录", MemberRechargeRecordingFragment.class));
            intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle);
            getActivityWithinHost().startActivity(intent);

            //KeyboardManager.hideSoftInput(mMemberSelectEdt);
        } else if (v.getId() == R.id.mMemberBalanceUsedListBtn) {
            String number1 = TextUtils.formatSpace(mMemberSelectEdt.getText().toString().trim());

            Bundle bundle1 = new Bundle();
            if (!android.text.TextUtils.isEmpty(number1)) {
                if (MemberUtils.checkIsPhoneNumber(number1) || MemberUtils.checkIsCardNo(number1)) {
                    bundle1.putSerializable("key_member_info", number1);
                }
            }
            Intent intent1 = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
            intent1.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("消费记录", MemberConsumptionRecordingFragment.class));
            intent1.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle1);
            getActivityWithinHost().startActivity(intent1);

            //KeyboardManager.hideSoftInput(mMemberSelectEdt);
        }
    }


    /**
     * 不记名卡
     */
    private void showNoNameCard(String cardNumber, String cardType) {
        DialogManager.showExecuteDialog(MemberSelectFragment.this, "是否需要绑定手机号?", "直接激活", "绑定手机号", new DialogResponseListener() {
            @Override
            public void response() {
                showBindCard(cardNumber, cardType);
            }
        }, new DialogResponseListener() {
            @Override
            public void response() {
                ProgressManager.showProgress(getActivityWithinHost());
                (new MemberProcess()).activeNoNameCard(cardNumber, new IResult() {

                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (result) {
                            showSuccessDialog("开卡成功!");
                        } else {
                            ToastUtil.showToast(info);
                        }
                    }
                });
            }
        }).setCancelable(true);
    }

    /**
     * 显示成功提示框
     */
    private void showSuccessDialog(String content) {
        DialogManager.showSingleDialog(MemberSelectFragment.this, content, R.drawable.icon_task_done, "好，我知道了");
    }

    /**
     * 开卡页面
     *
     * @param cardNumber 卡号
     * @param cardType   卡类型 0：虚拟卡； 1：手机号激活； 2：不记名激活
     */
    private void showBindCard(String cardNumber, String cardType) {
        BindCardFragment fragment = new BindCardFragment();
        fragment.setCardNumber(cardNumber);
        fragment.setCardType(cardType);
        DialogManager.showCustomDialog(MemberSelectFragment.this, fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }

    private boolean validateInput(String account) {
        if (TextUtils.validate(account)) {
            return true;
        }
        ToastUtil.showToast(R.string.member_query_validate_hint);
        return false;
    }

    private void doSelectRequest(String account) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_query_ing);
        LogUtil.log(TAG, "会员查询ing");
        mMemberProcess.optMemberInfoWithoutVerify(account, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());

                MemberInfoContainerFragment fragment = MemberInfoContainerFragment.getInstance();
                if (data.cardDetails != null) {
                    LogUtil.logBusiness(TAG, "会员查询done cardNo=" + data.cardDetails.cardInfo.card_no);
                    fragment.setMemberCardDetails(data.cardDetails);
                } else {
                    LogUtil.logBusiness(TAG, "会员查询done card list size=" + data.cardList.size());
                    fragment.setPhoneNum(account);
                }
                FragmentController.addFragmentWithHide(getFragmentManager(), fragment, MemberInfoContainerFragment.TAG, R.id.main_menufragment, false);
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                LogUtil.logBusiness(TAG, "会员查询failure msg=" + msg);
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            switch (v.getId()) {
                case R.id.mMemberSelectEdt:
                    String cardNo = TextUtils.formatSpace(mMemberSelectEdt.getText().toString());
                    if (validateInput(cardNo)) {
                        doSelectRequest(cardNo);
                    }
                    break;
                default:
                    break;
            }
        }
        return false;
    }

}
