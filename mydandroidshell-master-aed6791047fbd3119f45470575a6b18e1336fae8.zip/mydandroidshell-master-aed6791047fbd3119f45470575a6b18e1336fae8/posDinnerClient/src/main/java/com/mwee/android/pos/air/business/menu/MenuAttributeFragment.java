package com.mwee.android.pos.air.business.menu;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.air.business.menu.processor.MenuAttributeProcessor;
import com.mwee.android.pos.air.business.widget.CountKeyboard;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by zhangmin on 2017/11/6.
 */

public class MenuAttributeFragment extends BaseDialogFragment implements View.OnClickListener, CountKeyboard.KeyBoardClickListener {


    private TextView tvTitleLabel;

    private TextView tvMenuUnit;
    private TextView tvMenuUnitContent;
    private LinearLayout menuUnitLayout;


    //private TextView tvMenuAsk;
    private TextView tvMenuAskContent;
    private LinearLayout menuAskLayout;


    private Button menuWeighBtn;
    private Button mCancelBtn;
    private Button mConfirmBtn;
    private CountKeyboard countKeyboard;
    private RecyclerView recyclerViewAsk;


    private int maxCount = -1;

    /**
     * 是否第一次更新
     */
    private boolean isFirstUpdate = true;

    private MenuItem menuItem;
    private Host mHost;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_menu_attribute_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        regiterEvent();
        init();

    }

    private void assignViews(View v) {

        tvTitleLabel = v.findViewById(R.id.tvTitleLabel);

        tvMenuUnit = v.findViewById(R.id.tvMenuUnit);
        tvMenuUnitContent = v.findViewById(R.id.tvMenuUnitContent);
        menuUnitLayout = v.findViewById(R.id.menuUnitLayout);


        //tvMenuAsk = v.findViewById(R.id.tvMenuAsk);
        tvMenuAskContent = v.findViewById(R.id.tvMenuAskContent);
        menuAskLayout = v.findViewById(R.id.menuAskLayout);

        menuWeighBtn = v.findViewById(R.id.menuWeighBtn);
        mCancelBtn = v.findViewById(R.id.mCancelBtn);
        mConfirmBtn = v.findViewById(R.id.mConfirmBtn);
        countKeyboard = v.findViewById(R.id.countKeyBoard);

        recyclerViewAsk = v.findViewById(R.id.recyclerViewAsk);


    }

    private void regiterEvent() {

        menuUnitLayout.setOnClickListener(this);

        menuAskLayout.setOnClickListener(this);

        menuWeighBtn.setOnClickListener(this);
        mCancelBtn.setOnClickListener(this);
        mConfirmBtn.setOnClickListener(this);

        countKeyboard.setKeyBoardClickListener(this);
        countKeyboard.setSupportFloat(menuItem.supportWeight());
    }


    private void init() {

        tvTitleLabel.setText(menuItem.name);
        tvMenuUnit.setText(String.format("数量(%s)", menuItem.currentUnit.fsOrderUint));
        tvMenuUnitContent.setText(menuItem.menuBiz.buyNum + "");

        tvMenuAskContent.setText(menuItem.menuBiz.note);

        List<NoteModel> noteList = DinnerMenuUtil.getRequestByMenuItem(menuItem);
        List<NoteItemModel> askList = new ArrayList<>();
        for (NoteModel temp : noteList) {
            if (temp.itemList != null && temp.itemList.size() > 0) {
                for (NoteItemModel tempItem : temp.itemList) {
                    //NoteItemModel tempSelect = selectedInfo.get(tempItem.id);
                    /*if (tempSelect != null) {
                        tempItem.num = tempSelect.num;
                        tempItem.selected = tempSelect.selected;
                        tempItem.calcTotal();
                    }*/
                    askList.add(tempItem);
                }
            }
        }

        recyclerViewAsk.setLayoutManager(new GridLayoutManager(getContext(), 3));
        MenuNoteAdapter menuNoteAdapter = new MenuNoteAdapter();
        menuNoteAdapter.isHeaderShow = true;
        menuNoteAdapter.modules.addAll(askList);
        recyclerViewAsk.setAdapter(menuNoteAdapter);

    }


    public void setParams(Host mHost, MenuItem menuItem) {
        this.mHost = mHost;
        this.menuItem = menuItem;
    }


    @Override
    public void onClick(View view) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }

        switch (view.getId()) {
            case R.id.menuUnitLayout:

                clickMenuUnitLayout();
                break;
            case R.id.menuAskLayout:
                clickmenuAskLayout();

                break;
            case R.id.menuWeighBtn:
                clickmenuWeighBtn();

                break;
            case R.id.mCancelBtn:

                dismissSelf();
                break;
            case R.id.mConfirmBtn:

                save();
                dismissSelf();
                break;
            default:
                break;

        }
    }

    /**
     * 点击了菜品数量栏目
     */
    private void clickMenuUnitLayout() {
        menuUnitLayout.setBackgroundResource(R.color.color_e2e2e2);
        menuAskLayout.setBackgroundResource(R.color.color_f4f4f4);
        countKeyboard.setVisibility(View.VISIBLE);
        recyclerViewAsk.setVisibility(View.GONE);
    }


    /**
     * 点击了菜品要求栏目
     */
    private void clickmenuAskLayout() {
        menuUnitLayout.setBackgroundResource(R.color.color_f4f4f4);
        menuAskLayout.setBackgroundResource(R.color.color_e2e2e2);
        countKeyboard.setVisibility(View.GONE);
        recyclerViewAsk.setVisibility(View.VISIBLE);
    }

    /**
     * 点击了称重按钮栏目
     */
    private void clickmenuWeighBtn() {

        MenuAttributeProcessor.jumpQuantityElectronicFragment(mHost, menuItem, new NormalListener() {
            @Override
            public void callBack() {
                //点击了手动称重
                clickMenuUnitLayout();
            }
        }, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                LogUtil.log("originNum-->" + originNum + "  newNum-->" + newNum);
            }
        });

    }


    private void save() {

        String buyNum = tvMenuUnitContent.getText().toString().trim();
        if (!TextUtils.isEmpty(buyNum)) {
            menuItem.menuBiz.buyNum = new BigDecimal(buyNum);
        }

        String note = tvMenuAskContent.getText().toString().trim();
        if (!TextUtils.isEmpty(note)) {
            menuItem.menuBiz.note = note;
        }

    }


    class MenuNoteAdapter extends BaseListAdapter<NoteItemModel> {


        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuNoteHolder(LayoutInflater.from(getContext()).inflate(R.layout.view_menu_item_note, parent, false));
        }

        @Override
        protected View onCreateHeaderView(ViewGroup parent) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.view_header_note, parent, false);
            //((TextView) view.findViewById(R.id.mHeaderNoteLabel)).setText("清空");
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //ToastUtil.showToast("点击了清空按钮");
                    LogUtil.log("点击了清空按钮");
                }
            });
            return view;
        }


        class MenuNoteHolder extends BaseViewHolder implements View.OnClickListener {

            TextView tvNoteItemName;
            TextView tvNoteItemPrice;
            TextView tvNoteItemBuyNum;

            public MenuNoteHolder(View itemView) {
                super(itemView);
                tvNoteItemName = itemView.findViewById(R.id.tvNoteItemName);
                tvNoteItemPrice = itemView.findViewById(R.id.tvNoteItemPrice);
                tvNoteItemBuyNum = itemView.findViewById(R.id.tvNoteItemBuyNum);
                itemView.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {

                NoteItemModel noteItemModel = modules.get(position);
                tvNoteItemName.setText(noteItemModel.name);
                tvNoteItemPrice.setText(noteItemModel.price + "");
                tvNoteItemBuyNum.setText(noteItemModel.num + "");
            }

            @Override
            public void onClick(View view) {
                LogUtil.log("点击了要求");
            }
        }
    }


    @Override
    public void onKeyBoardClick(String key) {

        String info = tvMenuUnitContent.getText().toString().trim();

        if ("C".equals(key)) {
            if (!TextUtils.isEmpty(info)) {
                info = info.replace(String.valueOf(info.charAt(info.length() - 1)), "");
                tvMenuUnitContent.setText(info);
            }
        } else {

            if (isFirstUpdate) {
                isFirstUpdate = false;
                tvMenuUnitContent.setText("");
                info = "";
            }

            if (info.contains(".")) {
                if (TextUtils.equals(key, ".")) {
                    return;
                }
            }

            String info_key = info + key;
            if (!checkCountInLaw(info_key)) {
                ToastUtil.showToast(R.string.message_input_more);
                return;
            }
            tvMenuUnitContent.setText(info_key);
        }

    }

    public boolean checkCountInLaw(String person) {
        int count = StringUtil.toInt(person, 0);
        return count <= getMAXCount();
    }

    private int getMAXCount() {
        if (maxCount <= 0) {
            return 99;
        }
        return maxCount;
    }


}
