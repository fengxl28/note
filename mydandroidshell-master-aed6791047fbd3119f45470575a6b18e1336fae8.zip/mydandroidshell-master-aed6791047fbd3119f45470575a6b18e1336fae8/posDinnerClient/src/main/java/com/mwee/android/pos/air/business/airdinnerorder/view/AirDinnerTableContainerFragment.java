//package com.mwee.android.pos.air.business.airdinnerorder.view;
//
//import android.content.Context;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ExpandableListView;
//
//import com.mwee.android.base.task.callback.SyncCallback;
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.air.business.dinner.AirDinnerOrderDishsFragment;
//import com.mwee.android.pos.air.business.dinner.DinnerTableFooterLayout;
//import com.mwee.android.pos.air.business.main.MainTitleBar;
//import com.mwee.android.pos.air.business.member.dialog.MemberBindDialogFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.HomeFragment;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.business.dinner.processor.DinnerOrderProcessor;
//import com.mwee.android.pos.business.dinner.processor.MenuItemProcessor;
//import com.mwee.android.pos.business.localpush.NotifyToServer;
//import com.mwee.android.pos.business.member.biz.MemberProcess;
//import com.mwee.android.pos.business.member.view.MemberCheckCallBack;
//import com.mwee.android.pos.business.member.view.MemberOrderUnBindAirDialogFragment;
//import com.mwee.android.pos.business.orderdishes.view.DishCache;
//import com.mwee.android.pos.business.pay.connect.PayDinnerJump;
//import com.mwee.android.pos.business.pay.view.component.IPayCallback;
//import com.mwee.android.pos.business.permission.Permission;
//import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
//import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
//import com.mwee.android.pos.business.viceshow.ViceShowConnector;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.db.business.UserDBModel;
//import com.mwee.android.pos.db.business.menu.bean.MenuItem;
//import com.mwee.android.pos.db.business.order.OrderCache;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.GuideUtil;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.tools.LogUtil;
//
///**
// * Created by 刘秀秀 on 2017/4/27.
// */
//
//public class AirDinnerTableContainerFragment extends HomeFragment implements IDriver, DinnerTableFooterLayout.DinnerTableFoodFooterLayoutCallBack, AirDinnerFoodOrderMenuAdapter.OnItemClickListener, AirDinnerOrderDishsFragment.OnDinnerFoodOrderListener, IPayCallback {
//
//    private final static String DRIVER_TAG = "_AirTableContainer";
//
//    private ExpandableListView air_dinner_order_menu_lv;
//    private AirDinnerFoodOrderMenuAdapter airOrderMenuAdapter;
//    private DinnerTableFooterLayout mDinnerDishFooterLayout;
//    private MainTitleBar mainTitleBar;
//    private AirTableFragment airTableFragment;
//
//    private DinnerOrderProcessor mDinnerOrderProcessor;
//    private MenuItemProcessor mMenuItemProcessor;
//
//    private DishCache mDishCache;
//
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.air_dinner_food_order_fragment, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        DriverBus.registerDriver(this);
//        initView(view);
//        initData();
//        GuideUtil.show((ViewGroup) view, GuideUtil.TYPE_TABLE);
//    }
//
//
//    private void initView(View view) {
//
//        air_dinner_order_menu_lv = view.findViewById(R.id.air_dinner_order_menu_lv);
//
//        mDinnerDishFooterLayout = view.findViewById(R.id.mDinnerTableFooterLayout);
//
//        air_dinner_order_menu_lv.setEmptyView(view.findViewById(R.id.mDinnerFoodOrderEmptyLabel));
//
//        mainTitleBar = view.findViewById(R.id.mainTitleBar);
//
//        airTableFragment = (AirTableFragment) getChildFragmentManager().findFragmentByTag("airTableFragment");
//
//        mDinnerDishFooterLayout.setDinnerTableFooterLayouCallBack(this);
//        mDinnerDishFooterLayout.refreshDinnerFooterLayout(mDishCache);
//
//
//    }
//
//
//    private void initData() {
//
//        mainTitleBar.setParams(getActivityWithinHost());
//
//        airTableFragment.setAirTableClickCallBack(new AirTableFragment.AirTableClickCallBackListener() {
//            @Override
//            public void airTableClickListener(DishCache mDishCache) {
//
//                /**
//                 * 点击了桌台
//                 *   1 给dishCache 赋值
//                 *   2 刷新底部bottom
//                 *   3 构建DinnerOrderProcessor  MenuItemProcessor？ 可以优化
//                 *   4 刷新左边点菜预览列表
//                 *   5 刷新 MainTitle 订单号 和会员信息
//                 */
//                AirDinnerTableContainerFragment.this.mDishCache = mDishCache;
//                mMenuItemProcessor = new MenuItemProcessor(AirDinnerTableContainerFragment.this, mDishCache);
//                mDinnerOrderProcessor = new DinnerOrderProcessor(AirDinnerTableContainerFragment.this, mDishCache);
//
//                refreshViews();
//            }
//
//            @Override
//            public void airMAreaClickListener() {
//                /**
//                 * 点击了餐区切换 如果预览界面有菜品数据   清除预览界面的数据
//                 */
//                if (mDishCache != null && mDishCache.order != null) {
//                    mDishCache.order = null;
//                    refreshViews();
//                }
//            }
//
//            @Override
//            public void airRapidClickConfirmListener(DishCache mDishCache) {
//                AirDinnerTableContainerFragment.this.mDishCache = mDishCache;
//                mDinnerOrderProcessor = new DinnerOrderProcessor(AirDinnerTableContainerFragment.this, mDishCache);
//                mDinnerOrderProcessor.jumpAirDinnerOrderDishsFragment(getActivityWithinHost(), AirDinnerTableContainerFragment.this);
//            }
//        });
//
//        airOrderMenuAdapter = new AirDinnerFoodOrderMenuAdapter(getActivityWithinHost());
//        airOrderMenuAdapter.setOrderClickListener(this);
//        air_dinner_order_menu_lv.setAdapter(airOrderMenuAdapter);
//        air_dinner_order_menu_lv.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
//            @Override
//            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long l) {
//                return true;
//            }
//        });
//
//    }
//
//
//    /**
//     * 刷新UI
//     * 1 点菜预览
//     * 2 底部buttom
//     * 3 顶部会员信息
//     */
//    private void refreshViews() {
//
//        StringBuilder stringBuilder = new StringBuilder();
//        if (mDishCache != null && mDishCache.order != null) {
//            stringBuilder.append(String.format("订单号:%s", mDishCache.order.orderID));
//        }
//        mainTitleBar.setSubContentText(stringBuilder.toString());
//
//        //刷新小散桌台底部数据
//        mDinnerDishFooterLayout.refreshDinnerFooterLayout(mDishCache);
//        //刷新小散桌台左边点菜预览
//        airOrderMenuAdapter.notifyDataSetChanged(mDishCache);
//        for (int i = 0; i < airOrderMenuAdapter.getGroupCount(); i++) {
//            air_dinner_order_menu_lv.expandGroup(i);
//        }
//    }
//
//
//    @Override
//    public String getModuleName() {
//        return DRIVER_TAG;
//    }
//
//    @Override
//    public void onDetach() {
//        NotifyToServer.sendExcuteMsg("table/unlockTableByHost", AppCache.getInstance().currentHostId);
//        AppCache.getInstance().orderingTableID = "";
//        super.onDetach();
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        ViceShowConnector.getInstance().clearOrderInfo();
//    }
//
//
//
//    /*-----------------底部buttom点击事件回调---------------------*/
//
//    /**
//     * 打印预结单
//     */
//    @Override
//    public void onPrinterPreBillClick() {
//
//        PermissionsUtil.requestPermissionCommon(this, AppCache.getInstance().userDBModel, Permission.DINNER_bnPrnExpBill, new PermissionCallback() {
//            @Override
//            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
//                if (errCode == 0) {
//                    ActionLog.addLog("点菜页->点击打印预结单", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_PRINTPREINVOICE, "");
//                    mDinnerOrderProcessor.printDinnerPreBill();
//                }
//            }
//        });
//    }
//
//    /**
//     * 加减菜
//     */
//    @Override
//    public void onOrderMenuOperateClick() {
//
//        mDinnerOrderProcessor.jumpAirDinnerOrderDishsFragment(getActivityWithinHost(), this);
//
//    }
//
//    /**
//     * 点击开台
//     */
//    @Override
//    public void onOpenTableClick() {
//
//        if (!airTableFragment.isChoiceTable()) {
//            ToastUtil.showToast("您未选择桌台 不能开台 ");
//            return;
//        }
//        mDinnerOrderProcessor.onOpenTableClick(getActivityWithinHost(), mDishCache, this);
//
//    }
//
//    /**
//     * 结账
//     */
//    @Override
//    public void onPayClick() {
//
//        if (!AppCache.getInstance().collectMoney) {
//            ToastUtil.showToast(String.format(getString(R.string.waiter_not_has_conllect), AppCache.getInstance().userDBModel.fsUserName));
//            return;
//        }
//        ActionLog.addLog("点菜页->点击结账", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_PAY, mDishCache.order);
//        mDinnerOrderProcessor.doPay(new SyncCallback<Boolean>() {
//            @Override
//            public void callback(Boolean aBoolean) {
//                if (aBoolean) {
//                    doCheckDishOpenParamError();
//                }
//            }
//        });
//
//    }
//
//
//    /**
//     * 点击会员
//     */
//    @Override
//    public void onMemberClick() {
//        if (mDinnerOrderProcessor.mDishCache.order == null) {
//            ToastUtil.showToast(R.string.member_table_not_bind_order);
//            return;
//        }
//        if (mDinnerOrderProcessor.mDishCache.order.memberInfoS != null) {//已经绑定过会员
//            showMemberInfo();
//        } else {//尚未绑定会员
//            PermissionsUtil.requestPermissionCommon(mDinnerOrderProcessor.mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vVIPBind, new PermissionCallback() {
//                @Override
//                public void onCall(int errCode, String msg, UserDBModel userDBModel) {
//                    MemberBindDialogFragment fragment = new MemberBindDialogFragment();
//                    fragment.setBindOrderId(mDinnerOrderProcessor.mDishCache.order.orderID);
//                    fragment.setOnBindOrderListener(memberCheckCallBack);
//                    DialogManager.showCustomDialog(mDinnerOrderProcessor.mHost, fragment, "MemberBindDialogFragment");
//                }
//            });
//        }
//    }
//
//
//
//    /*------------------会员处理------------------*/
//
//    /**
//     * 会员成功登陆的回调
//     */
//    private MemberCheckCallBack memberCheckCallBack = new MemberCheckCallBack() {
//        @Override
//        public void call(final QueryMemberInfoAndBindToOrderResponse member) {
//            if (mDinnerOrderProcessor.mDishCache.order != null) {
//                mDinnerOrderProcessor.mDishCache.order = member.orderCache;
//                if (mDishCache.order == null) {
//                    return;
//                }
//                mDishCache.order = member.orderCache;
//
//                refreshViews();
//            }
//        }
//    };
//
//    /**
//     * 显示关联会员信息
//     */
//    private void showMemberInfo() {
//        Progress progress = ProgressManager.showProgressUncancel(this);
//        new MemberProcess().onlyLoadMemberInfo(mDishCache.order.memberInfoS.card_no, new IResponse<QueryMemberInfoResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse info) {
//                progress.dismissSelf();
//                if (result) {
//                    mDishCache.order.memberInfoS.score = info.memberCardModel.card_data.score;
//                    mDishCache.order.memberInfoS.balance = info.memberCardModel.card_data.amount;
//                }
//                MemberOrderUnBindAirDialogFragment fragment = MemberOrderUnBindAirDialogFragment.getInstance(mDishCache.order.memberInfoS, result);
//                fragment.setParam(new MemberOrderUnBindAirDialogFragment.OnMemberInfoListener() {
//                    @Override
//                    public void onUnbindMember() {
//                        clearBindMemberInfo();
//                    }
//                });
//                DialogManager.showCustomDialog(AirDinnerTableContainerFragment.this, fragment, "");
//            }
//        });
//    }
//
//
//    /**
//     * 清除会员绑定操作
//     */
//    private void clearBindMemberInfo() {
//        if (mDinnerOrderProcessor.mDishCache.isBindMember()) {
//            final Progress progress = ProgressManager.showProgressUncancel(mDinnerOrderProcessor.mHost, "解绑中");
//            mDinnerOrderProcessor.unBindMemberInfoFromOrder(mDinnerOrderProcessor.mDishCache.order.orderID, mDinnerOrderProcessor.mDishCache.order.memberInfoS.card_no, new ResultCallback<ChangeOrderWithMemberResponse>() {
//                @Override
//                public void onSuccess(ChangeOrderWithMemberResponse data) {
//                    mDinnerOrderProcessor.mDishCache.order.clearMember();
//                    if (mDishCache.order == null) {
//                        return;
//                    }
//                    refreshViews();
//                    progress.dismiss();
//                }
//
//                @Override
//                public void onFailure(int code, String msg) {
//                    if (!android.text.TextUtils.isEmpty(msg)) {
//                        ToastUtil.showToast(msg);
//                    }
//                    progress.dismiss();
//                }
//            });
//        }
//    }
//
//
//    /**
//     * 校验开台参数
//     */
//    private void doCheckDishOpenParamError() {
//        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
//        mDinnerOrderProcessor.loadCheckDishOpenParamError(mDishCache.order.orderID, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                progress.dismiss();
//                goPayDinnerFragment();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                progress.dismiss();
//                if (code == -10001) {
//                    //预制菜品匹配没匹配通过
//                    DialogManager.showExecuteDialog(getActivityWithinHost(), msg, new DialogResponseListener() {
//                        @Override
//                        public void response() {
//                            goPayDinnerFragment();
//                        }
//                    });
//                } else {
//                    ToastUtil.showToast(msg);
//                }
//            }
//        });
//    }
//
//
//    /**
//     * 跳转收银界面
//     */
//    private void goPayDinnerFragment() {
//        if (mDishCache.antiPay) {
//            PayDinnerJump.jumpToRePay(getActivityWithinHost(), mDishCache.order.orderID, R.id.main_menufragment, this);
//        } else {
//            PayDinnerJump.jumpToPay(getActivityWithinHost(), mDishCache.order.orderID, R.id.main_menufragment, this);
//        }
//    }
//
//
//    @Override
//    public void payFinish(int result) {
//        switch (result) {
//            case IPayCallback.FINISH:
//                LogUtil.log("支付完成");
//                mDishCache = null;
//                airTableFragment.notifyTableNoSelect();
//                refreshViews();
//                break;
//            default:
//                break;
//        }
//    }
//
//
//    /*-----------------左边点菜预览回调---------------------*/
//    @Override
//    public void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg) {
//
//        mMenuItemProcessor.doRetreatDish(mDishCache.getOrderId(), item, msg, new ResultCallback<OrderCache>() {
//            @Override
//            public void onSuccess(OrderCache data) {
//
//
//                mDishCache.order = data;
//                //mDishCache.initSelectUnitQuantity();
//
//                refreshViews();
//
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//            }
//        });
//
//    }
//
//    @Override
//    public void doChangeOrderedMenuNumber(MenuItem item, UserDBModel userDBModel) {
//
//        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, mDishCache.order, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//
//                if (mDishCache.order != null) {
//                    mDishCache.order.reCalcAllByAll();
//                }
//
//                refreshViews();
//
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//            }
//        });
//
//
//    }
//
//    @Override
//    public void doChangeOrderedMenuPrice(final MenuItem menuItem, UserDBModel userDBModel) {
//        mMenuItemProcessor.doUpdateDishPrice(mDishCache.getOrderId(), menuItem, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                //menuItem.calcTotal(false);
//                if (mDishCache.order != null) {
//                    mDishCache.order.reCalcAllByAll();
//                }
//
//                refreshViews();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//    /**
//     * 换桌完成，刷新页面
//     *
//     * @param dishCache
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/tableChanged", UIThread = true)
//    public void tableChanged(DishCache dishCache) {
//        if (mDishCache != null) {
//            mDishCache = null;
//            airTableFragment.notifyTableNoSelect();
//        }
//        refreshViews();
//    }
//
//    /**
//     * 下单
//     *
//     * @param dishCache
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/onOrderMenuCommit", UIThread = true)
//    public void onOrderMenuCommit(DishCache dishCache) {
//        if (mDishCache != null) {
//            mDishCache = null;
//            airTableFragment.notifyTableNoSelect();
//        }
//        refreshViews();
//    }
//
//
//    /**
//     * 网络监听
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/isConnectNetWork", UIThread = true)
//    public void isConnectNetWork(boolean isConnectNetWork) {
//        if (mainTitleBar != null) {
//            mainTitleBar.setNetDisconnectLaout(isConnectNetWork);
//        }
//    }
//
//    /**
//     * 网络状态
//     */
//    @Override
//    public void onResume() {
//        super.onResume();
//        if (mainTitleBar != null) {
//            mainTitleBar.setNetDisconnectLaout(AppCache.getInstance().isConnectNetWork);
//        }
//    }
//
//    /*-------------------小散点菜界面  DishCache 已点单信息变更 ------------------------*/
//    @Override
//    public void onDinnerOrderListener(DishCache mDishCache) {
//        refreshViews();
//    }
//}
