package com.mwee.android.pos.business.message;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.message.koubei.KBFragmentContainer;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogParamBundle;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.tab.TabLayout;

import java.util.ArrayList;

/**
 * Created by lxx on 17/2/9.
 * 消息中心
 */
public class MessageV2Fragment extends HomeFragment implements IDriver, TabLayout.OnTabClickListener, View.OnClickListener {
    public static final String TAG = MessageV2Fragment.class.getSimpleName();
    public static final String DRIVER_TAG = "messageFragment";
    private TabLayout mTabLayout;
    private int readStep;

    public static int index = 0;
    /**
     * 当前选中的口碑模式
     * 默认选中先付款模式
     */
    public static int koubei_current_index = 0;

    public static boolean isRecvMeituanPhoneDowngrade = false;

    private TextView mOpenOverlay;
    private TextView mOverlayDesc;
    private ImageButton tipsImg;

    private View.OnClickListener mClick = v -> {
        switch (v.getId()) {
            case R.id.tv_message_open_overlay:
                // 开启悬浮穿权限
                requestAlertWindowPermission();
                break;
            default:
                break;
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_message_v2, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mTabLayout = view.findViewById(R.id.mTabLayout);
        tipsImg = view.findViewById(R.id.tips_img);
        tipsImg.setVisibility(View.GONE);
        tipsImg.setOnClickListener(this);
        View tabLayout = view.findViewById(R.id.message_v2_tab_ll);
        if (AppCache.getInstance().isRetailMode()) {//小易2.2 修改样式
            tabLayout.setBackgroundColor(Color.WHITE);
            view.findViewById(R.id.horizontal_line).setVisibility(View.VISIBLE);
        } else {
            tabLayout.setBackgroundColor(Color.parseColor("#3E3E3E"));
            view.findViewById(R.id.horizontal_line).setVisibility(View.GONE);
        }
        mOpenOverlay = view.findViewById(R.id.tv_message_open_overlay);
        mOverlayDesc = view.findViewById(R.id.tv_message_overlay_desc);
        mOpenOverlay.setOnClickListener(mClick);
    }

    private void initData() {
        ArrayList<TabLayout.TabView.Tab> tabs = new ArrayList<>();
        tabs.add(new TabLayout.TabView.Tab("点餐", MessageOrderFragment.class));
        tabs.add(new TabLayout.TabView.Tab("支付", MessagePayFragment.class));
        tabs.add(new TabLayout.TabView.Tab("系统消息", MessageSystemFragment.class));
        tabs.add(new TabLayout.TabView.Tab("外卖", MessageNetOrderFragment.class));
        tabs.add(new TabLayout.TabView.Tab("微信外卖", MessageWechatOrderFragment.class));
        tabs.add(new TabLayout.TabView.Tab("微信快餐", MessageWechatFastFoodFragment.class));
        if (APPConfig.isMydKouBei()) {
            tabs.add(new TabLayout.TabView.Tab("口碑点餐", KBFragmentContainer.class));
        }
        tabs.add(new TabLayout.TabView.Tab("异常订单", MessageAbnormalOrdersFragment.class));
        mTabLayout.initData(tabs, this, AppCache.getInstance().isRetailMode());//小易2.2 修改样式
        mTabLayout.setCurrentTab(index);
        index = 0;
        showAlertMessage();
        refreshOverlayPermission();
        if (isRecvMeituanPhoneDowngrade) {
            isRecvMeituanPhoneDowngrade = false;
            jump(3);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    /**
     * 是否第一次进入消息中心
     */
    private void showAlertMessage() {
        String haveRead = ClientMetaUtil.getSettingsValueByKey(META.MESSAGE_VIEW);
        if (TextUtils.isEmpty(haveRead)) {
            final DialogParamBundle.Builder builder = new DialogParamBundle.Builder();
            DialogResponseListener mSingleOnClickListener = new DialogResponseListener() {

                @Override
                public void response() {
                    if (readStep < 1) {
                        readStep++;
                        builder.setContentText(R.string.message_guide_prompt);
                        DialogManager.showSingleDialog(getActivityWithinHost(), builder.build());
                    } else {
                        ClientMetaUtil.updateSettingsValueByKey(META.MESSAGE_VIEW, "have_read");
                        addActionLog("解锁消息中心");
                    }
                }
            };
            builder.setContentText(R.string.message_onlysave_current_message)
                    .setSingleBtnClick(mSingleOnClickListener)
                    .setSingleBtnText(R.string.message_know)
                    .setCancelable(false);
            DialogManager.showSingleDialog(this, builder.build());
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/jump", UIThread = true)
    public void jump(int index) {
        addActionLog("jump > 切换消息类型：" + (index == 0 ? "点餐" : index == 1 ? "支付" : "" + index));
        mTabLayout.setCurrentTab(index);
        if (isAbnormalTab(index)) {
            //异常订单
            tipsImg.setVisibility(View.VISIBLE);
        } else {
            tipsImg.setVisibility(View.GONE);
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/messageUndealTip", UIThread = true)
    public void undealTip(UnDealCountMessageModel unDealCountMessageModel) {
        if (unDealCountMessageModel != null) {
            mTabLayout.notifyDataChanged(0, unDealCountMessageModel.orderUndealCount);
            mTabLayout.notifyDataChanged(1, unDealCountMessageModel.payUndealCount);
            mTabLayout.notifyDataChanged(2, unDealCountMessageModel.systemCount);
            mTabLayout.notifyDataChanged(3, unDealCountMessageModel.netOrderCount);
            mTabLayout.notifyDataChanged(4, unDealCountMessageModel.wechatOrderCount);
            mTabLayout.notifyDataChanged(5, unDealCountMessageModel.fastfood);
            int index = 6;
            if (APPConfig.isMydKouBei()) {
                index = 7;
            }
            mTabLayout.notifyDataChanged(index, unDealCountMessageModel.abnormalOrders);
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        DriverBus.broadcast("refrehMessageData");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BaseFragment.TARGET_REQUEST) {
            unlockTable();
        } else if (requestCode == REQUEST_MANAGE_OVERLAY_PERMISSION) {
            refreshOverlayPermission();
        }
    }

    /**
     * 解锁所有桌台
     */
    private void unlockTable() {
        NotifyToServer.unlockTableByHost(AppCache.getInstance().currentHostId);
    }

    @Override
    public void onTabItemClick(int currentIndex, TabLayout.TabView.Tab tab) {
        try {
            BaseFragment fragment = (BaseFragment) tab.mFragmentClazz.newInstance();
            if (fragment != null) {
                getChildFragmentManager().beginTransaction().replace(R.id.msg_content, fragment).commitAllowingStateLoss();
            }
            if (isAbnormalTab(currentIndex)) {
                //异常订单
                tipsImg.setVisibility(View.VISIBLE);
            } else {
                tipsImg.setVisibility(View.GONE);
            }
        } catch (java.lang.InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否是异常订单TAB
     *
     * @param currentIndex
     * @return
     */
    private boolean isAbnormalTab(int currentIndex) {
        if (APPConfig.isAir()) {
            return currentIndex == 4;
        } else if (APPConfig.isMydKouBei()) {
            return currentIndex == 7;
        } else {
            return currentIndex == 6;
        }
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    /**
     * 添加日志
     *
     * @param log
     */
    private void addActionLog(String log) {
        ActionLog.waiterID = AppCache.getInstance().userDBModel.fsUserId;
        ActionLog.waiterName = AppCache.getInstance().userDBModel.fsUserName;
        ActionLog.addLog(log, "", "", ActionLog.MESSAGE, "");
    }

    private static final int REQUEST_MANAGE_OVERLAY_PERMISSION = 1;

    /**
     * 请求权限
     */
    private void requestAlertWindowPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        intent.setData(Uri.parse("package:" + this.getContextWithinHost().getPackageName()));
        startActivityForResult(intent, REQUEST_MANAGE_OVERLAY_PERMISSION);
    }

    private void refreshOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (Settings.canDrawOverlays(this.getContextWithinHost())) {
                mOpenOverlay.setVisibility(View.GONE);
                mOverlayDesc.setVisibility(View.GONE);
            } else {
                mOpenOverlay.setVisibility(View.VISIBLE);
                mOverlayDesc.setVisibility(View.VISIBLE);
            }
        } else {
            mOpenOverlay.setVisibility(View.GONE);
            mOverlayDesc.setVisibility(View.GONE);
        }
        DriverBus.call("login/refreshUndealMessage");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tips_img) {
            DialogManager.showTipsDialog(getActivityWithinHost(), null, "当订单明细与支付明细产生出入时，产生异常订单。\n操作\"忽略\"，忽略此异常，稍后处理；\n操作\"退款\"，退款按原路径退回支付账户；\n操作\"关联订单\"，根据提示进行关联操作，处理此异常。");
        }
    }
}
