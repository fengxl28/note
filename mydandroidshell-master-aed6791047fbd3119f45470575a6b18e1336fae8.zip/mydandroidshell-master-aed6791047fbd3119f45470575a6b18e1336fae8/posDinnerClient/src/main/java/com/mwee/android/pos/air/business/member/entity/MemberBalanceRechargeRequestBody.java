package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseAirMemberRequest;

/**
 * Created by qinwei on 2017/10/16.
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "proxy/crm",
        response = MemberBalanceRechargeResonpseBody.class,
        timeOut = 270)
public class MemberBalanceRechargeRequestBody extends BaseAirMemberRequest {
    public MemberBalanceRechargeRequest crm_membercard_updateMemberAmount = new MemberBalanceRechargeRequest();

    public MemberBalanceRechargeRequestBody() {

    }
}
