//package com.mwee.android.pos.air.business.setting;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//import com.mwee.android.pos.air.business.account.view.AccountManageFragment;
//import com.mwee.android.pos.air.business.discount.view.DiscountManagerActivity;
//import com.mwee.android.pos.air.business.member.MemberManagerActivity;
//import com.mwee.android.pos.air.business.payment.view.PaymentManageFragment;
//import com.mwee.android.pos.air.business.table.view.TableManagerActivity;
//import com.mwee.android.pos.air.business.tshop.TShopInfoFragment;
//import com.mwee.android.pos.air.business.tticket.TicketContainterFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.base.FragmentController;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.business.sync.ClientBindProcessor;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.ToastUtil;
//
///**
// * Created by zhangmin on 2017/12/13.
// */
//
//public class AirSetShopFragment extends BaseFragment implements View.OnClickListener{
//
//    private TextView tvUserSet;
//    private TextView tvTableSet;
//    private TextView tvPayWaySet;
//    private TextView tvMemberSet;
//    private TextView tvDiscountSet;
//    private TextView tvTicketSet;
//    private TextView tvShopInfoSet;
//
//
//
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.air_set_shop_fragment_layout, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        assignViews(view);
//        registerEvent();
//        initData();
//    }
//
//    private void assignViews(View container) {
//
//        /*基础配置*/
//        tvUserSet = (TextView) container.findViewById(R.id.tvUserSet);
//        tvTableSet = (TextView) container.findViewById(R.id.tvTableSet);
//        tvPayWaySet = (TextView) container.findViewById(R.id.tvPayWaySet);
//        tvMemberSet = (TextView) container.findViewById(R.id.tvMemberSet);
//        tvDiscountSet = (TextView) container.findViewById(R.id.tvDiscountSet);
//        tvTicketSet = (TextView) container.findViewById(R.id.tvTicketSet);
//        tvShopInfoSet = (TextView) container.findViewById(R.id.tvShopInfoSet);
//
//    }
//
//
//    private void registerEvent() {
//
//
//        /*基础配置*/
//        tvTableSet.setOnClickListener(this);
//        tvPayWaySet.setOnClickListener(this);
//        tvMemberSet.setOnClickListener(this);
//        tvDiscountSet.setOnClickListener(this);
//        tvTicketSet.setOnClickListener(this);
//        tvShopInfoSet.setOnClickListener(this);
//        tvUserSet.setOnClickListener(this);
//
//    }
//
//
//    private void initData() {
//
//        // 员工管理仅管理员登录可见
//        boolean isAdmin = (TextUtils.equals(AppCache.getInstance().userDBModel.fsUserId, "admin") || TextUtils.equals(AppCache.getInstance().userDBModel.fsUserId, "99999"));
//        tvUserSet.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
//    }
//
//    @Override
//    public void onClick(View v) {
//        if (!ButtonClickTimer.canClick()) {
//            return;
//        }
//        switch (v.getId()) {
//
//            case R.id.tvUserSet:
//                if (!ClientBindProcessor.isCurrentHostMain()) {
//                    ToastUtil.showToast("员工账号管理仅主机可以操作");
//                    return;
//                }
//                ActionLog.addLog("更多设置->点击了[员工账号管理]", "", "", ActionLog.SS_MORE_JOIN, "");
//                AccountManageFragment accountManageFragment = AccountManageFragment.newInstance();
//                FragmentController.addFragment(getActivityWithinHost(), accountManageFragment);
//                break;
//
//            case R.id.tvTableSet:  //桌台管理
//                if (!ClientBindProcessor.isCurrentHostMain()) {
//                    ToastUtil.showToast("桌台设置仅仅主机可以操作");
//                    return;
//                }
//                ActionLog.addLog("更多设置->点击了桌台设置", "", "", ActionLog.SS_MORE_JOIN, "");
//                startActivity(new Intent(getContext(), TableManagerActivity.class));
//                break;
//            case R.id.tvPayWaySet:
//                if (!ClientBindProcessor.isCurrentHostMain()) {
//                    ToastUtil.showToast("支付方式设置仅主机可以操作");
//                    return;
//                }
//                ActionLog.addLog("更多设置->点击了[支付方式]", "", "", ActionLog.SS_MORE_JOIN, "");
//                PaymentManageFragment paymentManageFragment = PaymentManageFragment.newInstance();
//                FragmentController.addFragment(getActivityWithinHost(), paymentManageFragment);
//                break;
//            case R.id.tvMemberSet:
//                startActivity(new Intent(getContext(), MemberManagerActivity.class));
//                break;
//            case R.id.tvDiscountSet:
//                if (!ClientBindProcessor.isCurrentHostMain()) {
//                    ToastUtil.showToast("优惠折扣设置仅仅主机可以操作");
//                    return;
//                }
//                ActionLog.addLog("更多设置->点击了优惠折扣设置", "", "", ActionLog.SS_MORE_JOIN, "");
//                startActivity(new Intent(getContext(), DiscountManagerActivity.class));
//
//                break;
//            case R.id.tvTicketSet:
//                if (!ClientBindProcessor.isCurrentHostMain()) {
//                    ToastUtil.showToast("收银小票配置仅仅主机可以操作");
//                    return;
//                }
//                ActionLog.addLog("更多设置->点击了收银小票配置", "", "", ActionLog.SS_MORE_JOIN, "");
//                TicketContainterFragment ticketContainterFragment = new TicketContainterFragment();
//                FragmentController.addFragment(getActivityWithinHost(), ticketContainterFragment);
//                break;
//
//            case R.id.tvShopInfoSet:
//                ActionLog.addLog("更多设置->点击了店铺信息", "", "", ActionLog.SS_MORE_JOIN, "");
//                TShopInfoFragment tShopInfoFragmnet = new TShopInfoFragment();
//                FragmentController.addFragment(getActivityWithinHost(), tShopInfoFragmnet);
//                break;
//
//            default:
//                break;
//        }
//    }
//}
