package com.mwee.android.pos.business.message.koubei;

import android.support.v7.widget.AppCompatSpinner;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDataResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBTempDataModel;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DisplayUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * Created by zhangmin on 2018/5/24.
 * <p>
 * 先付款订单列表
 */

public class KBBeforeOrderFragment extends BaseListFragment<KBTempDataModel> implements IDriver {

    public final static String TAG = "kbOrderFragment";
    private KBBeforeClientProcessor processor;
    private int page = 1;
    private KBBeforeOrderDetailView formerDetailView;
    private EditText etSearchView;
    private TextView tvSearchConfirm;
    private TextView mKbPreOrderVerifyFloatingActionButton;
    private Integer queryType = 0;
    private String status = "";


    public static KBBeforeOrderFragment newInstance() {
        return new KBBeforeOrderFragment();
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_kbbefore_layout;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.fragment_kbbefore_item, parent, false));
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        DriverBus.registerDriver(this);
        formerDetailView = view.findViewById(R.id.formerDetailView);
        etSearchView = view.findViewById(R.id.etSearchView);
        tvSearchConfirm = view.findViewById(R.id.tvSearchConfirm);
        tvSearchConfirm = view.findViewById(R.id.tvSearchConfirm);
        final AppCompatSpinner spinnerSearchView = view.findViewById(R.id.spinnerSearchView);
        mKbPreOrderVerifyFloatingActionButton = view.findViewById(R.id.mKbPreOrderVerifyFloatingActionButton);


        String[] strs = {"全部订单", "顾客申请退款的订单", "未分配桌台的订单", "未接单"};
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), R.layout.view_text_item, strs);
        adapter.setDropDownViewResource(R.layout.simple_spinner_item);
        spinnerSearchView.setDropDownVerticalOffset(DisplayUtil.dp2px(getContext(), 40));
        spinnerSearchView.setAdapter(adapter);
        mKbPreOrderVerifyFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new KBBeforeClientProcessor((Host) getContext()).showVerifyDialog(new ResultCallback<String>() {
                    @Override
                    public void onSuccess(String data) {
                        refresh();
                    }
                });
            }
        });
        tvSearchConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mSellNo = etSearchView.getText().toString().trim();
                if (!android.text.TextUtils.isEmpty(mSellNo) && mSellNo.length() < 11) {
                    ToastUtil.showToast("请输入正确的订单号进行查询");
                    return;
                }
                selectPosition = 0;
                page = 1;
                status = "";
                if (android.text.TextUtils.isEmpty(mSellNo)) {
                    Integer queryType = 0;
                    switch ((String) spinnerSearchView.getSelectedItem()) {
                        case "顾客申请退款的订单":
                            queryType = 1;
                            break;
                        case "未分配桌台的订单":
                            queryType = 2;
                            break;
                        case "未接单":
                            status = "PUSH";
                            break;
                        default:
                            queryType = 0;
                            break;
                    }
                    KBBeforeOrderFragment.this.queryType = queryType;
                    loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START, "");
                } else {
                    spinnerSearchView.setSelection(0);
                    loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START, mSellNo);
                }
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        //显示扫码核销取餐按钮
        processor = new KBBeforeClientProcessor(getActivityWithinHost());
        formerDetailView.setParams(getActivityWithinHost(), processor);
        formerDetailView.setVisibility(View.INVISIBLE);

        formerDetailView.setListener(new OnResultListener<List<String>>() {
            @Override
            public void callBack(List<String> stringList) {
                KBTempDataModel dataModel = modules.get(selectPosition);
                //todo 口碑正餐堂食模式的取餐号 以罗召欢数据为准 不以口碑数据  有可能罗召欢取餐号是A05 口碑是下厨时分配
                dataModel.fsTableNO = stringList.get(0);
                dataModel.fsStatus = stringList.get(1);
                dataModel.fsPayStatus = stringList.get(2);
                adapter.notifyDataSetChanged();
            }
        });

        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    public void refresh() {
        mPullRecyclerView.setRefreshing();
    }


    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            page = 1;
        } else {
            page++;
        }
        loadDataFromServer(mode, "");
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END, "");
    }


    private void refreshAdapter(List<KBTempDataModel> data) {
        modules.addAll(data);
        refreshCurrentChoiceData();
        adapter.notifyDataSetChanged();
    }


    /**
     * 拉取左边列表【订单头】信息
     *
     * @param mode
     */
    private void loadDataFromServer(final int mode, String searchParam) {
        processor.loadOrderList(page, searchParam, queryType, status, new ResultCallback<KPreTempDataResponse>() {
            @Override
            public void onSuccess(KPreTempDataResponse data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                if (page >= data.data.pageCount) {//没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
                if (!TextUtils.validate(data.data.koubeiOrder)) {
                    mPullRecyclerView.showEmptyView();
                    adapter.notifyDataSetChanged();
                } else {
                    mPullRecyclerView.showContent();
                    refreshAdapter(data.data.koubeiOrder);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                ToastUtil.showToast(msg);
                super.onFailure(code, msg);
            }
        });
    }


    private void refreshCurrentChoiceData() {
        if (selectPosition > modules.size()) {
            selectPosition = 0;
        }
        KBTempDataModel model = modules.get(selectPosition);
        loadKBPreOrderCache(model.fsOrderId, model.fsMerchantId, model.fsSellNo);
    }


    public int selectPosition = 0;


    class Holder extends BaseViewHolder implements View.OnClickListener {

        private TextView tvThirdOrderId;
        private TextView tvTakeNo;
        private TextView tvTime;
        private TextView tvMobile;
        private TextView tvAmount;
        private TextView tvOrderStatus;
        private TextView tvOrderStyle;

        private int position;
        public KBTempDataModel model;

        public Holder(View v) {
            super(v);
            tvThirdOrderId = v.findViewById(R.id.tvThirdOrderId);
            tvTakeNo = v.findViewById(R.id.tvTakeNo);
            tvTime = v.findViewById(R.id.tvTime);
            tvMobile = v.findViewById(R.id.tvMobile);
            tvAmount = v.findViewById(R.id.tvAmount);
            tvOrderStatus = v.findViewById(R.id.tvOrderStatus);
            tvOrderStyle = v.findViewById(R.id.tvOrderStyle);
            itemView.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            this.position = position;
            model = modules.get(position);
            tvThirdOrderId.setText(model.fsOrderId);
            tvTakeNo.setText(model.fsTableNO);
            tvTime.setText(model.fsTableTime);
            tvOrderStyle.setText(model.fsDinnerType);

            tvMobile.setText(model.fsUserMobile);

            tvAmount.setText(model.fsPayAmount);


            StringBuilder stringBuilder = new StringBuilder();

            /**
             * 订单的状态
             */
            String orderStatusMsg = processor.buildOrderStatusMsg(model.fsStatus);
            /**
             * 支付的状态
             */
            String payStatusMsg = processor.buildPayStatusMsg(model.fsPayStatus);

            stringBuilder.append(orderStatusMsg);
            //备餐中 请取餐
            if (android.text.TextUtils.equals("RECEIPT", model.fsStatus) || android.text.TextUtils.equals("PREPARE", model.fsStatus)) {
                if (!android.text.TextUtils.isEmpty(payStatusMsg)) {
                    stringBuilder.append("[").append(payStatusMsg).append("]");
                }
            }

            tvOrderStatus.setText(stringBuilder.toString());

            if (this.position == selectPosition) {
                itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FF4D31));
                tvThirdOrderId.setTextColor(getResourcesWithinHost().getColor(R.color.white));
                tvTakeNo.setTextColor(getResourcesWithinHost().getColor(R.color.white));
                tvTime.setTextColor(getResourcesWithinHost().getColor(R.color.white));
                tvMobile.setTextColor(getResourcesWithinHost().getColor(R.color.white));
                tvAmount.setTextColor(getResourcesWithinHost().getColor(R.color.white));
                tvOrderStatus.setTextColor(getResourcesWithinHost().getColor(R.color.white));
            } else {
                itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_f9f9f9));

                tvThirdOrderId.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
                tvTakeNo.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
                tvTime.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
                tvMobile.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
                tvAmount.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
                tvOrderStatus.setTextColor(getResourcesWithinHost().getColor(R.color.color_404040));
            }

        }

        @Override
        public void onClick(View v) {
            selectPosition = position;
            adapter.notifyDataSetChanged();
            loadKBPreOrderCache(model.fsOrderId, model.fsMerchantId, model.fsSellNo);
        }
    }


    /**
     * @param order_id
     * @param merchantPid
     */
    private void loadKBPreOrderCache(String order_id, String merchantPid, String fsSellNo) {
        processor.loadOrder(order_id, merchantPid, new ResultCallback<KPreOrderDataResponse>() {
            @Override
            public void onSuccess(KPreOrderDataResponse data) {
                formerDetailView.refreshUI(data.data, !android.text.TextUtils.isEmpty(data.local_order_id) ? data.local_order_id : fsSellNo);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                super.onFailure(code, msg);
            }
        });
    }


    /**
     * 更新某一条记录
     *
     * @param
     */
    @DrivenMethod(uri = TAG + "/refreshKBOrderItem", UIThread = true)
    public void refreshKBOrderItem(KBPreOrderUpdateResponse data) {
        for (KBTempDataModel dataModel : modules) {
            if (dataModel.fsOrderId.equals(data.data.order_id)) {
                dataModel.fsTableNO = data.data.take_no;
                dataModel.fsStatus = data.data.status;
                dataModel.fsPayStatus = data.data.payStatus;
                adapter.notifyDataSetChanged();
                //todo 有可能在副站点忽略了 那么主站点操作这个口碑订单的时候不该刷新订单详情 需要手动触发
                formerDetailView.refreshUI(data.data, data.local_order_id);
                break;
            }
        }
    }
}
