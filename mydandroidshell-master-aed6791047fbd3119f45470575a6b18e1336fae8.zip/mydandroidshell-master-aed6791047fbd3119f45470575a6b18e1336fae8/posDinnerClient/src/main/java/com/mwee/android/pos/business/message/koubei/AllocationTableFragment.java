package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.connect.business.table.GetAirTableChangeResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.air.business.table.api.TableManagerApi;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.pos.widget.pull.SpacesItemDecoration;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;

/**
 * Created by zhangmin on 2017/11/9.
 */

public class AllocationTableFragment extends BaseDialogFragment {

    private PullRecyclerView mTableAreaPullRecyclerView;
    private PullRecyclerView mTablePullRecyclerView;
    private AreaAdapter areaAdapter;
    private TableAdapter tableAdapter;
    private TextView change_table_label_tv;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_table_changed_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view) {
        //setCancelable(false);
        //view.findViewById(R.id.mTableItemCloseImg).setVisibility(View.GONE);
        view.findViewById(R.id.mTableItemCloseImg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        change_table_label_tv = (TextView) view.findViewById(R.id.change_table_label_tv);
        mTableAreaPullRecyclerView = (PullRecyclerView) view.findViewById(R.id.mTableAreaPullRecyclerView);
        mTableAreaPullRecyclerView.setEnablePullToStart(false);
        mTableAreaPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost(), LinearLayoutManager.HORIZONTAL, false));
        areaAdapter = new AreaAdapter();
        mTableAreaPullRecyclerView.setAdapter(areaAdapter);
        mTablePullRecyclerView = (PullRecyclerView) view.findViewById(R.id.mTablePullRecyclerView);
        mTablePullRecyclerView.setEnablePullToStart(false);
        mTablePullRecyclerView.addItemDecoration(new SpacesItemDecoration(getResources().getDimensionPixelSize(R.dimen.default_gap), 7));
        mTablePullRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 7));
        tableAdapter = new TableAdapter();
        mTablePullRecyclerView.setAdapter(tableAdapter);
        change_table_label_tv.setText(String.format("用户预约【%s】用餐，请为【%s，%s人】分配桌台"
                , DateUtil.formartDateStrToTarget(orderCache.table_time, DateUtil.DATE_VISUAL14FORMAT, "HH:mm")
                , orderCache.user_mobile, orderCache.people_num));
        loadTableChangeInfo();
    }

    class TableAdapter extends BaseListAdapter<MtableDBModel> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new TableHolder(LayoutInflater.from(getActivity()).inflate(R.layout.item_table_dialog, parent, false));
        }
    }

    class TableHolder extends BaseViewHolder implements View.OnClickListener {

        private TextView mTableItemNameLabel;
        private TableStatusBean tableStatusBean;
        private MtableDBModel table;

        public TableHolder(View v) {
            super(v);
            mTableItemNameLabel = (TextView) v.findViewById(R.id.mTableItemNameLabel);
            mTableItemNameLabel.setOnClickListener(this);

        }

        @Override
        public void bindData(int position) {
            table = tableAdapter.modules.get(position);
            mTableItemNameLabel.setText(table.fsmtablename);
            tableStatusBean = getAirTableChangeResponse.tableStatus.get(table.fsmtableid);
            if (tableStatusBean == null) {
                tableStatusBean = new TableStatusBean();
            }
            if (TableConstans.TABLE_STATUS_OPEN.equals(tableStatusBean.fsmtablesteid) || (tableStatusBean.flag & 4) == 4) {//餐桌狀態代號;1空闲 / 2开台 / 3占用 / 8预订 / 9停用
                mTableItemNameLabel.setEnabled(false);
                //mTableItemNameLabel.setSelected(true);
            } else {
                mTableItemNameLabel.setSelected(false);
            }
        }

        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            doAllocationTable(table);
        }
    }

    /**
     * 确认换桌 返回桌台信息
     *
     * @param table
     */
    public void doAllocationTable(MtableDBModel table) {
        onResultListener.callBack(table);
        dismissSelf();
    }

    class AreaAdapter extends BaseListAdapter<MareaDBModel> {
        public int selectPosition = 0;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new AreaHolder(LayoutInflater.from(getActivity()).inflate(R.layout.item_table_area_dailog, parent, false));
        }
    }

    class AreaHolder extends BaseViewHolder implements View.OnClickListener {

        private View mTableItemStatus;
        private TextView mTableAreaItemUnreadCountLabel;
        private TextView mTableAreaItemTitleLabel;
        private int position;

        public AreaHolder(View v) {
            super(v);
            mTableItemStatus = v.findViewById(R.id.mTableItemStatus);
            mTableAreaItemTitleLabel = (TextView) v.findViewById(R.id.mTableAreaItemTitleLabel);
            mTableAreaItemUnreadCountLabel = (TextView) v.findViewById(R.id.mTableAreaItemUnreadCountLabel);
            v.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            this.position = position;
            MareaDBModel area = areaAdapter.modules.get(position);
            mTableAreaItemTitleLabel.setText(area.fsMAreaName);
            if (position == areaAdapter.selectPosition) {
                mTableAreaItemTitleLabel.setSelected(true);
                mTableItemStatus.setVisibility(View.VISIBLE);

            } else {
                mTableAreaItemTitleLabel.setSelected(false);
                mTableItemStatus.setVisibility(View.GONE);
            }
            if (area.wxMsgCount > 0) {
                mTableAreaItemUnreadCountLabel.setVisibility(View.VISIBLE);
                mTableAreaItemUnreadCountLabel.setText(String.valueOf(area.wxMsgCount));
            } else {
                mTableAreaItemUnreadCountLabel.setVisibility(View.GONE);
            }
        }

        @Override
        public void onClick(View v) {
            areaAdapter.selectPosition = position;
            areaAdapter.notifyDataSetChanged();
            ArrayList<MtableDBModel> tables = null;
            if (areaAdapter.selectPosition == 0) {
                tables = (ArrayList<MtableDBModel>) getAirTableChangeResponse.allTables;
            } else {
                tables = (ArrayList<MtableDBModel>) getAirTableChangeResponse.areaTable.get(areaAdapter.modules.get(position).fsMAreaId);
            }
            tableAdapter.modules.clear();
            if (TextUtils.validate(tables)) {
                tableAdapter.modules.addAll(tables);
            }
            tableAdapter.notifyDataSetChanged();

        }
    }


    private GetAirTableChangeResponse getAirTableChangeResponse;

    public void loadTableChangeInfo() {

        Progress progress = ProgressManager.showProgress(getActivityWithinHost());
        TableManagerApi.loadTableChangeInfo(new IResponse<GetAirTableChangeResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAirTableChangeResponse info) {
                progress.dismissSelf();
                if (result) {
                    getAirTableChangeResponse = info;
                    areaAdapter.modules.addAll(getAirTableChangeResponse.mareaDBModelList);
                    areaAdapter.notifyDataSetChanged();
                    tableAdapter.modules.addAll(getAirTableChangeResponse.allTables);
                    tableAdapter.notifyDataSetChanged();
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }


    OnResultListener onResultListener;
    KBPreOrderCache orderCache;

    public void setListener(KBPreOrderCache orderCache, OnResultListener<MtableDBModel> onResultListener) {
        this.orderCache = orderCache;
        this.onResultListener = onResultListener;
    }


}
