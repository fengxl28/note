package com.mwee.android.pos.air.business.airdinnerorder.view;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.table.dialog.EditAreaDialog;
import com.mwee.android.pos.air.business.table.processor.TableManagerProcessor;
import com.mwee.android.pos.air.business.table.view.EditTableFragment;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.business.order.OrderManager;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.table.processor.TableBizHelper;
import com.mwee.android.pos.business.table.processor.TableBizProcessor;
import com.mwee.android.pos.business.table.processor.TableDBProcessor;
import com.mwee.android.pos.business.table.processor.TableViewProcessor;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.table.TableActionRespose;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.db.business.table.TableStatusSimpleBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TimerHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.DateUtil;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 */
public class AirTableFragment extends BaseFragment implements IDriver {

    public static final String TAG = AirTableFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "table";

    private ListView air_area_lv;
    private RecyclerView air_tables_gv;

    private View areaFootView;
    private TextView areaAddTex;

    private TableViewProcessor tableViewProcessor;
    private TableManagerProcessor tableManagerProcessor;

    private TableAdapter tableAdapter;
    private MAreaAdapter mAreaAdapter;

    private TimerHelper mTimerHelper;

    private DelayQueue<Object> refreshDelayQueue;

    public int selectedAreaIndex = 0;

    private int longPressedAreaIndex;

    private int longPressedTableIndex;

    private View mMenuEmptyLabel;

    private IDQWorker refreshWorker = new IDQWorker() {
        @Override
        public void work(Object o) {
            TableBizProcessor.refreshAllData(tableViewProcessor, selectedAreaIndex, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    ProgressManager.closeProgress(getActivityWithinHost());
                    if (selectedAreaIndex >= tableViewProcessor.mareaDBModelList.size()) {
                        selectedAreaIndex = 0;
                    }
                    selectionArea(selectedAreaIndex);
                    refreshDelayQueue.done("requestDatasFromBiz");
                }
            });
        }
    };


    @DrivenMethod(uri = DRIVER_TAG + "/refreshLockState", UIThread = true)
    public void refreshLockState(String data) {
        tableViewProcessor.parseLockData(data);
        tableAdapter.notifyDataSetChanged();
    }


    /**
     * 去业务中心查找所有桌台、餐区信息
     * LoginDriver  refreshTablesFromBiz
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshTablesFromBiz", UIThread = true)
    public void requestDatasFromBiz() {
        refreshDelayQueue.addTask("requestDatasFromBiz");
    }


    /**
     * 收到业务中心修改餐区、桌台的广播---刷新tableViewProcessor
     * LoginDriver  onBizTableChanged
     */
    @DrivenMethod(uri = DRIVER_TAG + "/onBizTableChanged", UIThread = true)
    public void onBizTableChanged() {
        ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.load_new_data);
        loadLocalDatas();
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        tableViewProcessor = new TableViewProcessor();
        tableManagerProcessor = new TableManagerProcessor();
        DriverBus.registerDriver(this);
        return inflater.inflate(R.layout.air_table_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        registEvent();
        init();
        ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.load_new_data);
        loadLocalDatas();

    }

    private void initView(View view) {

        mMenuEmptyLabel = view.findViewById(R.id.mMenuEmptyLabel);

        air_area_lv = view.findViewById(R.id.air_area_lv);
        areaFootView = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_cls_add, air_area_lv, false);
        areaAddTex = areaFootView.findViewById(R.id.mFooterAddLabel);
        areaAddTex.setText("新建餐区");
        air_area_lv.addFooterView(areaFootView);
        mAreaAdapter = new MAreaAdapter();
        mAreaAdapter.modules = (ArrayList<MareaDBModel>) tableViewProcessor.mareaDBModelList;
        air_area_lv.setAdapter(mAreaAdapter);


        air_tables_gv = view.findViewById(R.id.air_tables_gv);
        air_tables_gv.setLayoutManager(new GridLayoutManager(getContext(), 4));
        tableAdapter = new TableAdapter();
        tableAdapter.isFooterShow = true;
        tableAdapter.isHeaderShow = false;
        tableAdapter.modules = tableViewProcessor.matchTableList;
        air_tables_gv.setAdapter(tableAdapter);
    }

    private void registEvent() {
        air_area_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if (selectedAreaIndex == position) {
                    return;
                }
                /**
                 * 点击餐区的时候 取消之前桌台的选中位置
                 */
                tableAdapter.selectPosition = -1;

                airTableClickCallBackListener.airMAreaClickListener();
                selectedAreaIndex = position;
                selectionArea(position);
            }
        });

        air_area_lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                final MareaDBModel mareaDBModel = tableViewProcessor.mareaDBModelList.get(i);
                //全部不可以直接删除
                if (mareaDBModel.fsMAreaId.equalsIgnoreCase("all")) {
                    return true;
                }
                longPressedAreaIndex = i;
                PopupMenu popupMenu = new PopupMenu(getContext(), view);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(android.view.MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_editor:
                                showEditAreaDialog(mareaDBModel);
                                break;
                            case R.id.action_delete:

                                preDeleteArea(mareaDBModel);
                                break;
                            default:
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.getMenuInflater().inflate(R.menu.area_editor_and_delete, popupMenu.getMenu());
                popupMenu.show();
                return false;
            }
        });

        areaAddTex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAreaAddDialog();
            }
        });

    }

    public void init() {
        mTimerHelper = new TimerHelper();
        mTimerHelper.setDelayMillis(120 * 1000);
        mTimerHelper.setOnTimerListener(new TimerHelper.OnTimerListener() {
            @Override
            public void execute() {
                if (tableAdapter != null) {
                    tableAdapter.notifyDataSetChanged();
                }
            }
        });
        //刷新桌台and订单列表
        refreshDelayQueue = new DelayQueue<>("TableRefresh");
        refreshDelayQueue.setWorker(refreshWorker);
        refreshDelayQueue.setDelay(2000);
    }

    /**
     * 加载本地桌台数据
     */
    private void loadLocalDatas() {
        TableBizProcessor.onCreateLoadLocalTables(tableViewProcessor, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (selectedAreaIndex >= tableViewProcessor.mareaDBModelList.size()) {
                    selectedAreaIndex = 0;
                }
                selectionArea(selectedAreaIndex);

                requestDatasFromBiz();
            }
        });
    }


    /**
     * 弹出解锁弹窗
     *
     * @param msg             桌台锁定消息
     * @param fsmtablename    桌台名称
     * @param tableStatusBean 桌台状态
     * @param position        桌台索引id
     */
    private void showUnLockAndShotOffDialog(String msg, final String fsmtablename, final TableStatusSimpleBean tableStatusBean, final int position) {
        DialogManager.showExecuteDialog(getActivityWithinHost(), msg + getActivityWithinHost().getContextWithinHost().getString(R.string.unlock_table_msg), getActivityWithinHost().getContextWithinHost().getString(R.string.cacel), getActivityWithinHost().getContextWithinHost().getString(R.string.confirm), new DialogResponseListener() {
            @Override
            public void response() {
                final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
                TableBizProcessor.loadUnLockTableAndShotOff(tableStatusBean.fsmtableid, new IResponse<TableActionRespose>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, TableActionRespose info) {
                        progress.dismiss();
                        if (!result) {
                            if (code == -1) {
                                showUnLockAndShotOffDialog(msg, fsmtablename, tableStatusBean, position);
                            } else {
                                ToastUtil.showToast(msg);
                            }
                            return;
                        }
                        doTableItemClick(info, fsmtablename, tableStatusBean, position, code);
                    }
                });
            }
        }, null);
    }

    /**
     * 点击桌台---小散点击桌台时需要那会订单token
     *
     * @param fsmtableid
     * @param fsmareaid
     * @param position
     */
    private void checkTableStatus(final String fsmtableid, String fsmareaid, final String fsmtablename, final int position) {
        ActionLog.addLog("桌台->点击桌台：[" + fsmtablename + " (id=" + fsmtableid + ")]", "", fsmtableid, ActionLog.DF_TABLE_ACTION, "");
        if (TextUtils.isEmpty(fsmtableid)) {
            return;
        }
        TableStatusSimpleBean bean = tableViewProcessor.tableStatus.get(fsmtableid);
        if (bean == null) {
            bean = new TableStatusSimpleBean();
            bean.fsmtableid = fsmtableid;
            bean.fsmareaid = fsmareaid;
        }

        final TableStatusSimpleBean tableStatusBeanFinal = bean;
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
        TableBizProcessor.checkTableStatus(bean.fsmtableid, true,  new IResponse<TableActionRespose>() {
            @Override
            public void callBack(boolean result, int code, String msg, TableActionRespose response) {
                progress.dismiss();
                if (!result) {
                    if (code == -1 && PermissionsUtil.canPay()) {
                        showUnLockAndShotOffDialog(msg, fsmtablename, tableStatusBeanFinal, position);
                    } else {
                        ToastUtil.showToast(msg);
                    }
                    return;
                }
                if (response.orderCache != null && !TextUtils.isEmpty(response.orderToken)) {
                    AppCache.getInstance().refreshOrderToken(response.orderToken);
                }
                doTableItemClick(response, fsmtablename, tableStatusBeanFinal, position, code);
            }
        });
    }


    /**
     * 显示秒点订单弹框
     *
     * @param tableStatusBean
     */
    private void showRapidOrder(final TableStatusBean tableStatusBean, final String fsmtablename, final OrderCache originOrder) {
        DialogManager.showExecuteDialog(getActivityWithinHost(),
                String.format(getContextWithinHost().getString(R.string.receiver_order_msg), fsmtablename),
                getContextWithinHost().getString(R.string.not_get_order),
                getContextWithinHost().getString(R.string.get_order),
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        ActionLog.addLog("桌台->取用秒点单", "", tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, tableStatusBean.extra_order);
                        // 取用，进入点菜页，携带秒点菜品信息, 取单后取消通知
                        TempOrderDishesCache extraOrder = JSON.parseObject(tableStatusBean.extra_order,
                                TempOrderDishesCache.class);
                        if (extraOrder != null) {

                            extraOrder.source = -1;

                            DishCache mDishCache = new DishCache();
                            if (originOrder != null) {
                                mDishCache.order = originOrder;
                            }
                            mDishCache.orderDishesCache = extraOrder;
                            airTableClickCallBackListener.airRapidClickConfirmListener(mDishCache);
                            //airTableClickCallBackListener.airTableClickListener(mDishCache);
                        } else {
                            ActionLog.addLog("桌台->未查询到可取用的秒点订单，订单id[" + tableStatusBean.fssellno + "]", tableStatusBean.fssellno, tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");
                        }
                        //readRapidOrder(tableStatusBean);
                        //MessageUtil.updateOrderMessageByTableID(tableStatusBean.fsmtableid, MessageConstance.MessageOrderBuinessStatus.RAPID.IGNORE, AppCache.getInstance().userDBModel, null);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        ActionLog.addLog("桌台->不取用秒点单，操作员【" + AppCache.getInstance().userDBModel.fsUserName + "】桌台【" + fsmtablename + "】秒点单【" + tableStatusBean.extra_order + "】", tableStatusBean.fssellno, tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");
                        // 不取用秒点单
                        readRapidOrder(tableStatusBean);
                        // 更新消息状态
                        MessageUtil.updateOrderMessageByTableID(tableStatusBean.fsmtableid, MessageConstance.MessageOrderBuinessStatus.RAPID.IGNORE, AppCache.getInstance().userDBModel, null);
                    }
                });
    }


    private void readRapidOrder(TableStatusBean tableStatusBean) {
        tableStatusBean.fiwxmsgflag = TableStatusBean.NONE;
        tableStatusBean.flag &= ~4;
        tableStatusBean.extra_order = "";
        readWxMsg(tableStatusBean);
    }

    /**
     * 修改桌台消息
     *
     * @param tableStatusBean
     */
    private void readWxMsg(TableStatusBean tableStatusBean) {
        TableBizProcessor.updateWxMsgFlag(tableStatusBean, new IResponse() {
            @Override
            public void callBack(boolean result, int code, String msg, Object info) {
                requestDatasFromBiz();
            }
        });
    }

    /**
     * 显示服务铃弹框
     *
     * @param tableStatusBean
     */
    private void showServiceBell(final TableStatusBean tableStatusBean, final String fsmtablename) {
        DialogManager.showSingleWithoutCancelable(getActivityWithinHost(),
                String.format(getContextWithinHost().getString(R.string.call_waiter), fsmtablename), null, getContextWithinHost().getString(R.string.i_see),
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        ActionLog.addLog(AppCache.getInstance().userDBModel.fsUserName + "(服务员)将桌台'" + fsmtablename + "'的服务铃置为已读", "", tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");
                        // 标记该服务铃已读
                        tableStatusBean.fiwxmsgflag = TableStatusBean.NONE;
                        tableStatusBean.flag &= ~2;
                        readWxMsg(tableStatusBean);
                    }
                });
    }

    public void doTableItemClick(TableActionRespose response, String fsmtablename, TableStatusSimpleBean tableStatusBean, int position, int code) {
        if (response.tableStatusBean != null && (response.tableStatusBean.flag & 2) == 2) {
            ActionLog.addLog("桌台->展示桌台服务铃信息", "", tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");
                    /* 服务铃 */
            showServiceBell(response.tableStatusBean, fsmtablename);
            clearAnimator(position);
            return;
        }
        if ((response.tableStatusBean != null && (response.tableStatusBean.flag & 4)
                == 4)) {
            ActionLog.addLog("桌台->展示桌台秒点单信息", "", tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");
                    /* 秒点单 */
            showRapidOrder(response.tableStatusBean, fsmtablename, response.orderCache);
            clearAnimator(position);
            return;
        }
        if (code == 1) {   //桌子已开台
            ActionLog.addLog("桌台->桌子已开台，订单状态" + com.mwee.android.pos.util.TextUtils.getOrderStatusName(response.orderCache.orderStatus), response.orderCache.orderID, tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");

            DishCache dishCache = new DishCache();
            dishCache.order = response.orderCache;
            dishCache.orderDishesCache = OrderManager.buildTempOrder();
            dishCache.orderDishesCache.fsmareaid = response.orderCache.fsmareaid;
            dishCache.orderDishesCache.fsmtableid = response.orderCache.fsmtableid;
            dishCache.orderDishesCache.fsmtablename = response.orderCache.fsmtablename;
            if (response.orderCache.orderStatus == OrderStatus.ANTI_PAIED) {
                //TODO  反结账的入口
                dishCache.antiPay = true;
            }
            airTableClickCallBackListener.airTableClickListener(dishCache);
        } else {
            ActionLog.addLog("桌台->新台显示选择就餐人数界面", "", tableStatusBean.fsmtableid, ActionLog.DF_TABLE_ACTION, "");

            TempOrderDishesCache tempOrder = OrderManager.buildTempOrder();
            tempOrder.fsmareaid = tableStatusBean.fsmareaid;
            tempOrder.fsmtableid = tableStatusBean.fsmtableid;
            tempOrder.fsmtablename = fsmtablename;

            DishCache mDishCache = new DishCache();
            mDishCache.orderDishesCache = tempOrder;

            airTableClickCallBackListener.airTableClickListener(mDishCache);
        }
    }

    /**
     * 切换桌台区域
     *
     * @param indexArea
     */
    public void selectionArea(int indexArea) {
        String areaId;
        if (indexArea < 0 || indexArea >= tableViewProcessor.mareaDBModelList.size()) {
            areaId = "all";
        } else {
            areaId = tableViewProcessor.mareaDBModelList.get(indexArea).fsMAreaId;
        }

        tableViewProcessor.matchListByArea(areaId);

        if (tableViewProcessor.mareaDBModelList.isEmpty()) {
            air_tables_gv.setVisibility(View.GONE);
            mMenuEmptyLabel.setVisibility(View.VISIBLE);
        } else {
            air_tables_gv.setVisibility(View.VISIBLE);
            mMenuEmptyLabel.setVisibility(View.GONE);
        }
        // 刷新餐区
        mAreaAdapter.notifyDataSetChanged();
        tableAdapter.notifyDataSetChanged();

    }


    /**
     * 清除桌台动画
     *
     * @param position
     */
    private void clearAnimator(int position) {
        Animator animator = tableViewProcessor.animationForTable.get(position);
        if (animator != null) {
            animator.end();
            tableViewProcessor.animationForTable.remove(position);
        }
    }


    class MAreaAdapter extends BaseMwAdapter<MareaDBModel> {

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            MAreaAdapter.MenuClsHolder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_class_item, parent, false);
                holder = new MAreaAdapter.MenuClsHolder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (MAreaAdapter.MenuClsHolder) convertView.getTag();
            }
            holder.bindData(position);
            return convertView;
        }

        class MenuClsHolder {
            private View itemView;

            public MenuClsHolder(View itemView) {
                this.itemView = itemView;
            }

            public void bindData(int position) {
                TextView mAskGroupItemLabel = (TextView) itemView;
                mAskGroupItemLabel.setText(modules.get(position).fsMAreaName);
                if (position == selectedAreaIndex) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, R.drawable.bg_category_son_white_item_checked);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, 0);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.color_2d2d2d));
                }
            }
        }
    }


    class TableAdapter extends BaseListAdapter<MtableSimpleModel> {

        public int selectPosition = -1;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new TableAdapter.TableHolder(LayoutInflater.from(getContext()).inflate(R.layout.air_table_item, parent, false));
        }

        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_item_footer, parent, false);
            TextView tvName = view.findViewById(R.id.tvName);
            tvName.setText("新建桌台");
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAddTableDialog();
                }
            });
            return view;
        }

        class TableHolder extends BaseViewHolder implements View.OnClickListener, View.OnLongClickListener {

            private LinearLayout tableLayout;
            private LinearLayout tableLayoutBottom;
            private TextView tvTableName;
            private TextView tvTablePersonCount;
            private TextView tvTableMoney;
            private TextView tvTableTime;
            private MtableSimpleModel data;
            private ImageView imgPhoneRapid;
            private int position = 0;

            public TableHolder(View v) {
                super(v);
                tableLayout = v.findViewById(R.id.tableLayout);
                tableLayoutBottom = v.findViewById(R.id.tableLayoutBottom);

                tvTableName = v.findViewById(R.id.tvTableName);
                tvTablePersonCount = v.findViewById(R.id.tvTablePersonCount);
                tvTableTime = v.findViewById(R.id.tvTableTime);
                tvTableMoney = v.findViewById(R.id.tvTableMoney);
                imgPhoneRapid = v.findViewById(R.id.imgPhoneRapid);

                v.setOnClickListener(this);
                v.setOnLongClickListener(this);
            }

            @Override
            public void bindData(int position) {
                data = modules.get(position);
                this.position = position;

                if (TextUtils.isEmpty(data.fsmareaid)) {
                    return;
                }

                tvTableName.setText(data.fsmtablename);

                TableStatusSimpleBean tableStatusBean = tableViewProcessor.tableStatus.get(data.fsmtableid);
                if (tableStatusBean == null) {
                    tableStatusBean = new TableStatusSimpleBean();
                }
                if (TableConstans.TABLE_STATUS_OPEN.equals(tableStatusBean.fsmtablesteid) || (tableStatusBean.flag & 4) == 4) {

                    if (!TextUtils.isEmpty(tableStatusBean.fssellno)) {//考虑 什么时候会没有订单号码呢?

                        tvTableTime.setVisibility(View.VISIBLE);
                        tvTableMoney.setVisibility(View.VISIBLE);

                        tableLayoutBottom.setVisibility(View.VISIBLE);
                        tvTablePersonCount.setText(tableStatusBean.fiCustSum + getContextWithinHost().getString(R.string.see_down));//显示桌台人数
                        tvTablePersonCount.setTextColor(ViewToolsUtil.getColor(R.color.system_red));
                        tvTableTime.setText(getOpenTableTime(tableStatusBean.fsopenhstime));//显示桌台开台时间
                        tvTableMoney.setText(TextUtils.concat(Calc.formatShow(tableStatusBean.fdExpAmt, RoundConfig.ROUND_TOTAL)));//显示桌台金额

                    } else {
                        tvTableMoney.setVisibility(View.GONE);
                        tvTableTime.setVisibility(View.GONE);
                        tableLayoutBottom.setVisibility(View.GONE);

                        tvTablePersonCount.setText("");
                        tvTableMoney.setText("");
                        tvTableTime.setText("");

                        tvTablePersonCount.setTextColor(ViewToolsUtil.getColor(R.color.color_636363));
                    }

                    //tvTableName.setTextColor(ViewToolsUtil.getColor(R.color.system_red));
                    //tableLayout.setBackground(ViewToolsUtil.getDrawable(getContextWithinHost(), R.drawable.bg_cubic_transparent));

                } else { //空台

                    tableLayoutBottom.setVisibility(View.GONE);
                    tvTableMoney.setVisibility(View.GONE);
                    tvTableTime.setVisibility(View.GONE);

                    tvTableMoney.setText("");
                    tvTableTime.setText("");
                    tvTablePersonCount.setText(data.fiseats + "人桌");

                    tvTablePersonCount.setTextColor(ViewToolsUtil.getColor(R.color.color_636363));
                    //tvTableName.setTextColor(ViewToolsUtil.getColor(R.color.color_2b2b2b));
                    //tableLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));

                }

               /*---------选中颜色状态的控制----*/
                if (selectPosition == position) {

                    tvTableName.setTextColor(ViewToolsUtil.getColor(R.color.white));
                    tvTablePersonCount.setTextColor(ViewToolsUtil.getColor(R.color.white));

                    //tableLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.system_red));
                    tableLayout.setSelected(true);
                    tableLayoutBottom.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_a63321));

                } else {

                    tvTableName.setTextColor(ViewToolsUtil.getColor(R.color.color_2b2b2b));
                    //tvTablePersonCount.setTextColor(ViewToolsUtil.getColor(R.color.system_red));

                    //tableLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.selector_white_gray_text));
                    tableLayout.setSelected(false);
                    tableLayoutBottom.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.system_red));

                }

                //秒点动画
                clearAnimator(position);
                imgPhoneRapid.setVisibility(View.GONE);
                if ((tableStatusBean.flag & 2) == 2 || (tableStatusBean.flag & 4) == 4) {
                    Animator animator = ViewToolsUtil.startShake(tableLayout, 5f, 500, ValueAnimator.INFINITE);
                    tableViewProcessor.animationForTable.put(position, animator);
                    imgPhoneRapid.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onClick(View v) {
                //验证桌台是否空闲 -- 空闲---开台; 已开台----OrderCache拿回来
                selectPosition = position;
                tableAdapter.notifyDataSetChanged();

                checkTableStatus(data.fsmtableid, data.fsmareaid, data.fsmtablename, position);
            }

            @Override
            public boolean onLongClick(View view) {
                if (!ButtonClickTimer.canClick()) {
                    return true;
                }
                longPressedTableIndex = position;
                TableStatusSimpleBean tableStatusBean = tableViewProcessor.tableStatus.get(data.fsmtableid);
                if (tableStatusBean == null) {
                    tableStatusBean = new TableStatusSimpleBean();
                }
                //只允许编辑空台
                if (TableConstans.TABLE_STATUS_OPEN.equals(tableStatusBean.fsmtablesteid) || (tableStatusBean.flag & 4) == 4 || (tableStatusBean.flag & 2) == 2) {
                    return true;
                }
                PopupMenu popupMenu = new PopupMenu(getContext(), view);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(android.view.MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_editor:
                                editTableDialog(data);
                                break;
                            case R.id.action_delete:
                                deleteTableDialog(data);
                                break;
                            default:
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.getMenuInflater().inflate(R.menu.area_editor_and_delete, popupMenu.getMenu());
                popupMenu.show();
                return true;
            }
        }

        private String getOpenTableTime(String time) {
            String openLength = "";
            if (!TextUtils.isEmpty(time)) {
                try {
                    int currentTime = DateTimeUtil.getMMBetween(time, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                    if (currentTime <= 0) {
                        currentTime = 1;
                    }
                    if (currentTime <= 999) {
                        openLength = currentTime + getActivityWithinHost().getString(R.string.time_minute);
                    } else {
                        openLength = "999" + getActivityWithinHost().getString(R.string.time_minute) + "+";
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            return openLength;
        }
    }

    /*****************************************************************************************编辑餐区*******************************************************************************************************/

    /**
     * 餐区变动监听回调
     */
    EditAreaDialog.OnAreaEditorListener onAreaEditorListener = new EditAreaDialog.OnAreaEditorListener() {
        @Override
        public void onAddSuccess(MareaDBModel mareaDBModel, ArrayList<MtableSimpleModel> newTableDBModels) {
            //如果初始餐区没有任何数据  那么第一次新加餐区的时候  需要提前构建一个
            if (ListUtil.isEmpty(tableViewProcessor.mareaDBModelList)) {
                MareaDBModel allMareaDBModel = TableDBProcessor.getOwneMareaDBModel();
                tableViewProcessor.mareaDBModelList.add(allMareaDBModel);
            }
            tableViewProcessor.mareaDBModelList.add(mareaDBModel);
            //mAreaAdapter.notifyDataSetChanged();
            //添加区域  刷新界面默认选中全部
            selectedAreaIndex = 0;
            selectionArea(selectedAreaIndex);
            if (!ListUtil.isEmpty(newTableDBModels)) {
                TableBizHelper helper = new TableBizHelper();
                helper.setHintTableList(tableViewProcessor.hintMtableDBModels);
                tableViewProcessor.localMtableDBModels.addAll(newTableDBModels);
                helper.updateAllTablesData(tableViewProcessor.hintMtableDBModels, tableViewProcessor.localMtableDBModels);
                tableViewProcessor.allTables.clear();
                tableViewProcessor.allTables.addAll(TableViewProcessor.getAllTables(tableViewProcessor.localMtableDBModels, tableViewProcessor.hintMtableDBModels));
                tableViewProcessor.areaTable = helper.groupTables(tableViewProcessor.allTables);
                selectionArea(selectedAreaIndex);
            }
        }

        @Override
        public void onUpdateSuccess(String name) {
            tableViewProcessor.mareaDBModelList.get(longPressedAreaIndex).fsMAreaName = name;
            mAreaAdapter.notifyDataSetChanged();
        }

    };

    /**
     * 预删除餐区
     *
     * @param mareaDBModel 餐区Model
     */
    private void preDeleteArea(final MareaDBModel mareaDBModel) {
        DialogManager.showExecuteDialog(getActivityWithinHost(),
                "是否确认删除？",
                getStringWithinHost(R.string.cacel),
                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                    @Override
                    public void response() {
                        doDeleteArea(mareaDBModel);
                    }
                }, null);
    }

    /**
     * 删除餐区
     *
     * @param mareaDBModel 餐区Model
     */
    private void doDeleteArea(final MareaDBModel mareaDBModel) {
        ProgressManager.showProgress(getActivityWithinHost());
        tableManagerProcessor.deleteArea(mareaDBModel.fsMAreaId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {

                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    /**
                     *  1 业务中心删除餐区
                     *  2 本地缓存 餐区移除
                     *  3 移除该餐区对应的桌台
                     *
                     */
                    for (int i = 0; i < tableViewProcessor.mareaDBModelList.size(); i++) {

                        MareaDBModel tempMareaDBModel = tableViewProcessor.mareaDBModelList.get(i);
                        //当前餐区对应的桌台
                        List<MtableSimpleModel> tempLists = tableViewProcessor.areaTable.get(mareaDBModel.fsMAreaId);

                        if (TextUtils.equals(tempMareaDBModel.fsMAreaId, mareaDBModel.fsMAreaId)) {

                            if (!ListUtil.isEmpty(tempLists)) {
                                //从所有桌台中移除删除餐区对应的桌台
                                tableViewProcessor.allTables.removeAll(tempLists);

                                //移除匹配的桌台
                                tableViewProcessor.matchTableList.removeAll(tempLists);

                                tableViewProcessor.localMtableDBModels.removeAll(tempLists);
                            }

                            tableViewProcessor.areaTable.clear();
                            tableViewProcessor.areaTable = groupTables(tableViewProcessor.allTables);


                            tableViewProcessor.mareaDBModelList.remove(i);
                            break;
                        }
                    }
                    if (tableViewProcessor.mareaDBModelList.size() == 1) {//只剩下全部分类
                        tableViewProcessor.mareaDBModelList.clear();
                    }

                    //删除区域  刷新界面默认选中全部
                    selectedAreaIndex = 0;
                    selectionArea(selectedAreaIndex);
                    return;
                }
                ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(info) ? info : "删除区域失败");
            }
        });
    }

    /**
     * 编辑餐区
     *
     * @param mareaDBModel 餐区Model
     */
    private void showEditAreaDialog(MareaDBModel mareaDBModel) {
        AirAreaManagerInfo airAreaManagerInfo = new AirAreaManagerInfo();
        airAreaManagerInfo.fsMAreaId = mareaDBModel.fsMAreaId;
        airAreaManagerInfo.fsMAreaName = mareaDBModel.fsMAreaName;
        EditAreaDialog dialog = new EditAreaDialog();
        dialog.setParam(airAreaManagerInfo, tableManagerProcessor);
        dialog.setOnAreaEditorListener(onAreaEditorListener);
        DialogManager.showCustomDialog(this, dialog, "EditAreaDialog");
    }

    /**
     * 新增区域
     */
    private void showAreaAddDialog() {
        EditAreaDialog dialog = new EditAreaDialog();
        dialog.setParam(null, tableManagerProcessor);
        dialog.setOnAreaEditorListener(onAreaEditorListener);
        DialogManager.showCustomDialog(this, dialog, "EditAreaDialog");
    }

    /*****************************************************************************************编辑桌台*******************************************************************************************************/

    EditTableFragment.OnEditTableListener onEditTableListener = new EditTableFragment.OnEditTableListener() {
        /**
         * 新增桌台
         * @param data
         */
        @Override
        public void onEditorSuccess(MtableSimpleModel data) {

            // MtableDBModel beforeMtableDBModel = tableViewProcessor.tableStatusBeenToShow.get(longPressedTableIndex);

            //tableViewProcessor.localMtableDBModels.remove(beforeMtableDBModel);
            tableViewProcessor.localMtableDBModels.add(data);

            // tableViewProcessor.allTables.remove(beforeMtableDBModel);
            tableViewProcessor.allTables.add(data);

            // tableViewProcessor.tableStatusBeenToShow.remove(beforeMtableDBModel);
            //tableViewProcessor.tableStatusBeenToShow.add(data);


            // tableViewProcessor.matchTableList.remove(beforeMtableDBModel);
            tableViewProcessor.matchTableList.add(data);


            tableViewProcessor.areaTable.clear();
            tableViewProcessor.areaTable = groupTables(tableViewProcessor.allTables);


            selectionArea(selectedAreaIndex);
            //tableAdapter.notifyDataSetChanged();
            //mAreaAdapter.notifyDataSetChanged();
//            refreshUI();
        }

        @Override
        public void onUpdateSuccess(MtableSimpleModel data) {


            MtableSimpleModel beforeMtableDBModel = tableViewProcessor.matchTableList.get(longPressedTableIndex);

            //1 当前展示的桌台 更新当前展示的桌台信息
            //tableViewProcessor.tableStatusBeenToShow.remove(beforeMtableDBModel);
            //tableViewProcessor.tableStatusBeenToShow.add(data);


            //2
            tableViewProcessor.allTables.remove(beforeMtableDBModel);
            tableViewProcessor.allTables.add(data);


            //3
            tableViewProcessor.matchTableList.remove(beforeMtableDBModel);
            tableViewProcessor.matchTableList.add(data);


            //4
            tableViewProcessor.localMtableDBModels.remove(beforeMtableDBModel);
            tableViewProcessor.localMtableDBModels.add(data);

            //5
            tableViewProcessor.areaTable.clear();
            tableViewProcessor.areaTable = groupTables(tableViewProcessor.allTables);


            //tableAdapter.notifyDataSetChanged();
            selectionArea(selectedAreaIndex);
            //mAreaAdapter.notifyDataSetChanged();


        }

        @Override
        public void onDeleteSuccess() {


            MtableSimpleModel beforeMtableDBModel = tableViewProcessor.matchTableList.get(longPressedTableIndex);

            //1 当前展示的桌台 更新当前展示的桌台信息
            //tableViewProcessor.tableStatusBeenToShow.remove(beforeMtableDBModel);
            //tableViewProcessor.tableStatusBeenToShow.add(data);


            //2
            tableViewProcessor.allTables.remove(beforeMtableDBModel);
            // tableViewProcessor.allTables.add(data);


            //3
            tableViewProcessor.matchTableList.remove(beforeMtableDBModel);
            // tableViewProcessor.matchTableList.add(data);


            //4
            tableViewProcessor.localMtableDBModels.remove(beforeMtableDBModel);
            // tableViewProcessor.localMtableDBModels.add(data);

            //5
            tableViewProcessor.areaTable.clear();
            tableViewProcessor.areaTable = groupTables(tableViewProcessor.allTables);


            //tableAdapter.notifyDataSetChanged();
            selectionArea(selectedAreaIndex);
            // mAreaAdapter.notifyDataSetChanged();


        }
    };


    //TODO  临时处理一下  还要优化

    /**
     * 将桌台按照餐区分组 --- 指定桌台集合
     *
     * @param allTables
     * @return Map<餐区ID, List<桌台>>
     */
    public ArrayMap<String, List<MtableSimpleModel>> groupTables(List<MtableSimpleModel> allTables) {
        if (ListUtil.isEmpty(allTables)) {
            return new ArrayMap<>();
        }
        ArrayMap<String, List<MtableSimpleModel>> areaTable = new ArrayMap<>();
        for (MtableSimpleModel temp : allTables) {
            List<MtableSimpleModel> list = areaTable.get(temp.fsmareaid);
            if (list == null) {
                list = new ArrayList<>();
                areaTable.put(temp.fsmareaid, list);
            }
            list.add(temp);
        }
        return areaTable;

    }


    /**
     * 编辑桌台
     */
    private void editTableDialog(final MtableSimpleModel data) {
        AirTableManageInfo airTableManageInfo = new AirTableManageInfo();
        airTableManageInfo.fsmareaid = data.fsmareaid;
        airTableManageInfo.fiseats = data.fiseats;
        airTableManageInfo.fsmtableid = data.fsmtableid;
        airTableManageInfo.fsmtablename = data.fsmtablename;
        airTableManageInfo.fsmtablesteid = data.fsmtablesteid;
        String currentAreaId = data.fsmareaid;
        EditTableFragment dialog = new EditTableFragment();
        dialog.setAreaSouce(tableViewProcessor.mareaDBModelList);
        dialog.setParam(currentAreaId, tableManagerProcessor, airTableManageInfo);
        dialog.setOnEditTableListener(onEditTableListener);
        dialog.show(getFragmentManagerWithinHost(), "EditTableFragment");
    }

    /**
     * 删除桌台
     */
    private void deleteTableDialog(final MtableSimpleModel data) {
        DialogManager.showExecuteDialog(getActivityWithinHost(),
                "是否确认删除？",
                getStringWithinHost(R.string.cacel),
                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                    @Override
                    public void response() {
                        ProgressManager.showProgress(getActivityWithinHost());
                        ArrayList<String> tableIdList = new ArrayList<>();
                        tableIdList.add(data.fsmtableid);
                        tableManagerProcessor.batchDeleteTable(tableIdList, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                ProgressManager.closeProgress(getActivityWithinHost());
                                if (result) {
                                    onEditTableListener.onDeleteSuccess();
                                    ToastUtil.showToast("已删除");
                                } else {
                                    ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(info) ? info : "删除桌台失败");
                                }
                            }
                        });
                    }
                }, null);
    }

    /**
     * 新增桌台
     */
    private void showAddTableDialog() {
        if (ListUtil.isEmpty(tableViewProcessor.mareaDBModelList)) {
            ToastUtil.showToast("请先新增区域");
            return;
        }
        String currentAreaId = "";
        if (selectedAreaIndex > 0 && selectedAreaIndex < tableViewProcessor.mareaDBModelList.size()) {
            currentAreaId = tableViewProcessor.mareaDBModelList.get(selectedAreaIndex).fsMAreaId;
        }

        if (android.text.TextUtils.isEmpty(currentAreaId)) {
            currentAreaId = tableViewProcessor.mareaDBModelList.get(0).fsMAreaId;
        }

        EditTableFragment dialog = new EditTableFragment();
        dialog.setAreaSouce(tableViewProcessor.mareaDBModelList);
        dialog.setParam(currentAreaId, tableManagerProcessor);
        dialog.setOnEditTableListener(onEditTableListener);
        dialog.show(getFragmentManagerWithinHost(), "EditTableFragment");
    }

    /*****************************************************************************************其他*******************************************************************************************************/

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }


    /**
     * 判断是否有桌台选中
     *
     * @return
     */
    public boolean isChoiceTable() {

        return tableAdapter.selectPosition >= 0;
    }


    /**
     * 结完账需要刷新桌台
     * 完成下单需要刷新桌台
     * 让桌台没有任何选中的状态
     */
    public void notifyTableNoSelect() {
        tableAdapter.selectPosition = -1;
        tableAdapter.notifyDataSetChanged();
    }


    /**
     * 点击桌台 切换餐区
     * 的回调
     */
    private AirTableClickCallBackListener airTableClickCallBackListener;

    public void setAirTableClickCallBack(AirTableClickCallBackListener airTableClickCallBackListener) {
        this.airTableClickCallBackListener = airTableClickCallBackListener;



    }

    public interface AirTableClickCallBackListener {

        void airTableClickListener(DishCache mDishCache);

        void airMAreaClickListener();

        void airRapidClickConfirmListener(DishCache mDishCache);

    }


}
