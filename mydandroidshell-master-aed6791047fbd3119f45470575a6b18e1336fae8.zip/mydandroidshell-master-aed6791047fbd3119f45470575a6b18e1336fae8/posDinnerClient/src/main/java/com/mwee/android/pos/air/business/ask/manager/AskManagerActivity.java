package com.mwee.android.pos.air.business.ask.manager;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.ask.manager.dialog.AskEditorDialogFragment;
import com.mwee.android.pos.air.business.ask.manager.dialog.AskGroupEditorDialog;
import com.mwee.android.pos.air.business.ask.manager.processor.AskProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuManagerProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/12/20.
 */

public class AskManagerActivity extends AirBaseActivity implements AskGroupEditorDialog.OnAskGroupEditorListener {

    private TitleBar mTitleBar;
    private ListView mAskRecyclerView;
    private RecyclerView mAskGroupRecyclerView;

    private AskAdapter askAdapter;
    private AskGroupAdapter askGroupAdapter;

    private AskProcessor mAskProcessor;

    private LinearLayout mOperationAddLayout;
    private TextView tvAdd;
    private TextView tvBatchDelete;

    private LinearLayout mOperationDeleteLayout;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchCancelBtn;
    private TextView mAskBatchDeleteBtn;

    private FrameLayout mEmptyLayout;
    private TextView tvEmptyCreateFirst;

    private TextView mClsEmptyLabel;
    private TextView mBatchChoiceValueLabel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_manager);
        initUI();
        initButtomLayut();
        initMenuTypeData();
        getData();
    }


    private void initUI() {

        mAskProcessor = new AskProcessor();

        mTitleBar = findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });

        mEmptyLayout = findViewById(R.id.mEmptyLayout);
        tvEmptyCreateFirst = findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建分组");
        tvEmptyCreateFirst.setOnClickListener(this);

        mAskGroupRecyclerView = findViewById(R.id.mAskGroupRecyclerView);
        mAskRecyclerView = findViewById(R.id.mAskRecyclerView);

        mAskGroupRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAskGroupRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        askGroupAdapter = new AskGroupAdapter();
        mAskGroupRecyclerView.setAdapter(askGroupAdapter);

        askAdapter = new AskAdapter();
        mAskRecyclerView.setAdapter(askAdapter);


        findViewById(R.id.tvAddCategoryLabel).setOnClickListener(this);


    }


    /**
     * 刷新整个视图
     */
    private void refreshView() {
        refreshAskGroupList();
        if (askGroupAdapter != null) {
            refreshAskList(askGroupAdapter.getCurrentAskGpId());
        }
    }

    /**
     * 刷新要求分类
     */
    private void refreshAskGroupList() {
        askGroupAdapter.modules = mAskProcessor.airAskGroupManagerInfoList;
        askGroupAdapter.notifyDataSetChanged();

        mEmptyLayout.setVisibility(ListUtil.isEmpty(mAskProcessor.airAskGroupManagerInfoList) ? View.VISIBLE : View.GONE);

    }

    /**
     * 刷新要求
     *
     * @param fsAskGpId
     */
    private void refreshAskList(String fsAskGpId) {
        mAskProcessor.selectAskGroup(fsAskGpId);
        askAdapter.modules = mAskProcessor.airAskManageInfoToShowList;
        askAdapter.notifyDataSetChanged();

        tvBatchDelete.setVisibility(ListUtil.isEmpty(mAskProcessor.airAskManageInfoToShowList) ? View.GONE : View.VISIBLE);
        mClsEmptyLabel.setVisibility(ListUtil.isEmpty(mAskProcessor.airAskManageInfoToShowList) ? View.VISIBLE : View.GONE);

        if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
            mOperationAddLayout.setVisibility(ListUtil.isEmpty(mAskProcessor.airAskManageInfoToShowList) ? View.VISIBLE : View.GONE);
            mOperationDeleteLayout.setVisibility(ListUtil.isEmpty(mAskProcessor.airAskManageInfoToShowList) ? View.GONE : View.VISIBLE);
        }
        refreshChoiceMenuCount();
    }


    private void getData() {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.optAllAsk(new IResult() {

            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (!result) {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "信息获取失败,请稍后重试" : info);
                    return;
                }
                refreshView();
            }
        });
    }

    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.tvEmptyCreateFirst:
            case R.id.tvAddCategoryLabel:
                ActionLog.addLog("要求管理页面--->点击了新建分组", "", "", ActionLog.SS_MORE_JOIN, "");
                showAskGroupAddDialog();
                break;
            case R.id.tvAdd:
                ActionLog.addLog("要求管理页面--->点击了新建要求", "", "", ActionLog.SS_MORE_JOIN, "");
                showAddAskDialog();
                break;
            case R.id.tvBatchDelete:
                ActionLog.addLog("要求管理页面--->点击了批量删除", "", "", ActionLog.SS_MORE_JOIN, "");
                mOperationAddLayout.setVisibility(View.GONE);
                mOperationDeleteLayout.setVisibility(View.VISIBLE);
                askAdapter.notifyDataSetChanged();
                break;
            case R.id.mAskBatchChoiceAllLabel://全选
                ActionLog.addLog("要求管理页面--->点击了全选", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickAll();
                break;
            case R.id.mAskBatchCancelBtn://取消
                ActionLog.addLog("要求管理页面--->点击了取消", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickCancel();
                break;
            case R.id.mAskBatchDeleteBtn://删除
                ActionLog.addLog("要求管理页面--->点击了删除", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickDelete();
                break;
            default:
                break;
        }
    }


    /**
     * 初始化底部bottom
     */
    private void initButtomLayut() {


        mOperationAddLayout = findViewById(R.id.mOperationAddLayout);
        tvAdd = findViewById(R.id.tvAdd);
        tvAdd.setText("新建要求");
        tvAdd.setOnClickListener(this);
        mClsEmptyLabel = findViewById(R.id.mClsEmptyLabel);

        tvBatchDelete = findViewById(R.id.tvBatchDelete);
        tvBatchDelete.setOnClickListener(this);

        mBatchChoiceValueLabel = findViewById(R.id.mBatchChoiceValueLabel);
        mOperationDeleteLayout = findViewById(R.id.mOperationDeleteLayout);
        mAskBatchChoiceAllLabel = findViewById(R.id.mAskBatchChoiceAllLabel);
        mAskBatchCancelBtn = findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn = findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchDeleteBtn.setOnClickListener(this);

    }


    /*--------------------------要求全选删除的操作---------------------------------*/

    private ArrayList<String> choiceStates = new ArrayList<>();

    /**
     * 单选一个菜品
     *
     * @param value
     */
    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }


    /**
     * 判断是否全选
     *
     * @return
     */
    private boolean isChoiceAll() {
        for (int i = 0; i < askAdapter.modules.size(); i++) {
            if (!choiceStates.contains(askAdapter.modules.get(i).fiId)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选
     */
    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < askAdapter.modules.size(); i++) {
            choiceStates.add(askAdapter.modules.get(i).fiId);
        }
    }

    /**
     * 清除全选
     */
    private void cancelChoiceAll() {
        choiceStates.clear();
    }

    /**
     * 点击全选按钮
     */
    private void doClickAll() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        askAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();

    }

    /**
     * 点击取消按钮
     */
    private void doClickCancel() {
        mOperationAddLayout.setVisibility(View.VISIBLE);
        mOperationDeleteLayout.setVisibility(View.GONE);
        cancelChoiceAll();
        mAskBatchChoiceAllLabel.setSelected(false);
        askAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();
    }


    /**
     * 刷新选中菜品个数显示
     */
    private void refreshChoiceMenuCount() {

        mBatchChoiceValueLabel.setText(String.format("选中%s个", choiceStates.size()));

    }


    /**
     * 批量删除按钮
     */
    private void doClickDelete() {

        if (choiceStates.isEmpty()) {
            ToastUtil.showToast("请先选择要求");
            return;
        }
        String content = "";
        if (choiceStates.size() == 1) {
            content = "确定删除该要求吗?";
        } else {
            content = String.format("确定删除这%s个要求吗?", choiceStates.size());
        }

        DialogManager.showExecuteDialog(getActivityWithinHost(), content, new DialogResponseListener() {
            @Override
            public void response() {

                ProgressManager.showProgress(getActivityWithinHost());
                mAskProcessor.batcheDeleteAsk(choiceStates, new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (result) {
                            //删除完成 释放choice
                            choiceStates.clear();
                            mAskBatchChoiceAllLabel.setSelected(false);

                            refreshView();
                        } else {
                            ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? getResources().getString(R.string.tip_delete_error) : info);
                        }
                    }
                });
            }
        });
    }

    /*---------------操作要求分组---------------*/

    class AskGroupAdapter extends BaseListAdapter<AirAskGroupManagerInfo> {
        private int selectPosition = 0;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new AskGpHolder(LayoutInflater.from(AskManagerActivity.this).inflate(R.layout.air_category_item_layout, parent, false));
        }

        public AirAskGroupManagerInfo getCurrentAskGp() {
            if (modules.size() == 0) {
                return null;
            }
            return modules.get(selectPosition);
        }

        public String getCurrentAskGpId() {
            if (modules.size() > 0) {
                AirAskGroupManagerInfo airAskGroupManagerInfo = modules.get(selectPosition);
                return airAskGroupManagerInfo.fsAskGpId;
            }
            return "";
        }

        class AskGpHolder extends BaseViewHolder implements View.OnClickListener {
            private int position;

            private LinearLayout tvCategoryLayout;
            private TextView tvCategoryName;
            private TextView tvSubContent;

            private ImageView iconDelete;
            private ImageView iconTop;
            private ImageView iconEditor;

            public AskGpHolder(View itemView) {
                super(itemView);
                tvCategoryLayout = itemView.findViewById(R.id.tvCategoryLayout);
                tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
                tvSubContent = itemView.findViewById(R.id.tvSubContent);

                iconDelete = itemView.findViewById(R.id.iconDelete);
                iconTop = itemView.findViewById(R.id.iconTop);
                iconEditor = itemView.findViewById(R.id.iconEditor);

                tvCategoryLayout.setOnClickListener(this);
                iconDelete.setOnClickListener(this);
                iconTop.setOnClickListener(this);
                iconEditor.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                AirAskGroupManagerInfo askgpDBModel = modules.get(position);
                tvCategoryName.setText(askgpDBModel.fsAskGpName);

                if (position == selectPosition) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_air_category_item_checked);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                }

                if (position == selectPosition && !TextUtils.isEmpty(askgpDBModel.fsAskGpId)) {

                    if (modules.indexOf(askgpDBModel) == 1) {
                        iconTop.setVisibility(View.GONE);
                    } else {
                        iconTop.setVisibility(View.VISIBLE);
                    }
                    iconDelete.setVisibility(View.VISIBLE);
                    iconEditor.setVisibility(View.VISIBLE);

                    //得到要求分组下的可用菜品分类
                    String subContent = "";
                    tvSubContent.setVisibility(View.VISIBLE);
                    if (askgpDBModel.fiUseAllMenuCls == 1) {
                        subContent = "全部";
                    } else if(!ListUtil.isEmpty(askgpDBModel.fsMenuClsIdList)){
                        subContent = getUseClsName(askgpDBModel.fsMenuClsIdList);
                    } else {
                        subContent = "无";
                        tvSubContent.setVisibility(View.GONE);
                    }
                    tvSubContent.setText(String.format("可用分类: %s", subContent));
                } else {
                    iconDelete.setVisibility(View.GONE);
                    iconTop.setVisibility(View.GONE);
                    iconEditor.setVisibility(View.GONE);
                    tvSubContent.setVisibility(View.GONE);
                }
            }

            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.tvCategoryLayout:
                        if (selectPosition != position) {
                            mOperationAddLayout.setVisibility(View.VISIBLE);
                            mOperationDeleteLayout.setVisibility(View.GONE);
                            mAskBatchChoiceAllLabel.setSelected(false);
                            cancelChoiceAll();

                            selectPosition = position;
                            refreshAskList(getCurrentAskGp().fsAskGpId);
                            notifyDataSetChanged();
                            //refreshButtonStatus();
                        }
                        break;
                    case R.id.iconDelete:
                        ActionLog.addLog("要求管理页面--->点击了分类删除", "", "", ActionLog.SS_MORE_JOIN, "");
                        LogUtil.log("MenuClsAdapter delete");
                        doAskGroupDelete();
                        break;
                    case R.id.iconTop: ActionLog.addLog("要求管理页面--->点击了分类置顶", "", "", ActionLog.SS_MORE_JOIN, "");
                        LogUtil.log("MenuClsAdapter top");
                        doAskGroupToTop();
                        break;
                    case R.id.iconEditor:
                        ActionLog.addLog("要求管理页面--->点击了分类编辑", "", "", ActionLog.SS_MORE_JOIN, "");
                        LogUtil.log("MenuClsAdapter editor");
                        showAskGroupEditorDialog();
                        break;
                    default:
                        break;
                }
            }
        }
    }


    /**
     * 要求分类置顶
     */
    private void doAskGroupToTop() {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.loadAskGroupToTop(askGroupAdapter.getCurrentAskGpId(), new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (!result) {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "信息获取失败,请稍后重试" : info);
                    return;
                }
                askGroupAdapter.selectPosition = 1;
                refreshView();
            }
        });
    }


    /**
     * 要求分类删除
     */
    private void doAskGroupDelete() {

        DialogManager.showExecuteDialog(getActivityWithinHost(), "确定删除该要求分组吗?", new DialogResponseListener() {
            @Override
            public void response() {

                ProgressManager.showProgress(getActivityWithinHost());
                mAskProcessor.doDeleteAskGp(askGroupAdapter.getCurrentAskGpId(), new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (!result) {
                            ToastUtil.showToast(TextUtils.isEmpty(info) ? "信息获取失败,请稍后重试" : info);
                            return;
                        }
                        ToastUtil.showToast("已删除");
                        askGroupAdapter.selectPosition = 0;
                        refreshView();
                    }
                });
            }
        });


    }


    @Override
    public void onAskGroupAddSuccess() {
        if (askGroupAdapter.modules.size() > 0) {
            askGroupAdapter.selectPosition = askGroupAdapter.modules.size() - 1;
        }
        refreshView();
    }

    @Override
    public void onAskGroupUpdateSuccess() {
        refreshView();
    }

    @Override
    public void onAskGroupDeleteSuccess() {
        askGroupAdapter.selectPosition = 0;
        refreshView();
    }

    /**
     * 新增要求分组
     */
    private void showAskGroupAddDialog() {
        AskGroupEditorDialog dialog = new AskGroupEditorDialog();
        dialog.setParam(null, mAskProcessor);
        dialog.setOnAskGroupEditorListener(this);
        DialogManager.showCustomDialog(this, dialog, "AskGroupEditorDialog");
    }

    /**
     * 编辑要求分组
     */
    private void showAskGroupEditorDialog() {
        AskGroupEditorDialog dialog = new AskGroupEditorDialog();
        dialog.setParam(askGroupAdapter.getCurrentAskGp(), mAskProcessor);
        dialog.setOnAskGroupEditorListener(this);
        DialogManager.showCustomDialog(this, dialog, "AskGroupEditorDialog");
    }

    /**
     * 新增、编辑要求
     */
    private void showAddAskDialog() {
        AskEditorDialogFragment dialog = new AskEditorDialogFragment();
        dialog.setParam(askGroupAdapter.getCurrentAskGpId(), mAskProcessor.airAskGroupManagerInfoWhisOutAllList, mAskProcessor);
        dialog.setOnAskEditorListener(new AskEditorDialogFragment.OnAskEditorListener() {
            @Override
            public void onEditorSuccess() {
                refreshView();
            }
        });
        dialog.show(getFragmentManagerWithinHost(), "AskEditorDialogFragment");
    }

    /*---------------操作要求---------------*/
    class AskAdapter extends BaseMwAdapter<AirAskManageInfo> {

        public int selectPostiton;

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_ask_item, parent, false);
                viewHolder = new ViewHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.bindData(position);

            return convertView;
        }


        class ViewHolder implements View.OnClickListener {

            private View itemViewLayout;
            private TextView mAskNameLabel;
            private TextView mAskPriceLabel;
            private AirAskManageInfo askDBModel;
            private TextView tvItemCheck;

            private int position;

            public ViewHolder(View v) {

                itemViewLayout = v.findViewById(R.id.itemViewLayout);
                mAskNameLabel = v.findViewById(R.id.mAskNameLabel);
                mAskPriceLabel = v.findViewById(R.id.mAskPriceLabel);
                tvItemCheck = v.findViewById(R.id.tvItemCheck);
                //tvItemCheck.setOnClickListener(this);
                v.setOnClickListener(this);
            }


            public void bindData(int position) {

                this.position = position;

                askDBModel = modules.get(position);
                mAskNameLabel.setText(askDBModel.fsAskName);
                if (askDBModel.fdAddPrice.compareTo(BigDecimal.ZERO) >= 0) {
                    mAskPriceLabel.setText(String.format("+%s元", askDBModel.fdAddPrice.toPlainString()));
                } else {
                    mAskPriceLabel.setText(String.format("-%s元", askDBModel.fdAddPrice.toPlainString().replace("-", "")));
                }

                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
                    tvItemCheck.setVisibility(View.VISIBLE);
                    if (choiceStates.contains(askDBModel.fiId)) {
                        tvItemCheck.setSelected(true);
                    } else {
                        tvItemCheck.setSelected(false);
                    }
                } else {
                    tvItemCheck.setVisibility(View.INVISIBLE);
                }

                if (position == selectPostiton) {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FFD2CB));
                } else {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));
                }
            }

            @Override
            public void onClick(View v) {

                selectPostiton = position;
                notifyDataSetChanged();

                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为菜品删除模式 不触发编辑菜品事件
                    choice(askDBModel.fiId);
                    notifyDataSetChanged();
                    refreshChoiceMenuCount();
                    mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
                    return;
                } else {
                    AskEditorDialogFragment dialog = new AskEditorDialogFragment();
                    dialog.setParam(askDBModel.fsAskGpId, askDBModel, mAskProcessor.airAskGroupManagerInfoWhisOutAllList, mAskProcessor);
                    dialog.setOnAskEditorListener(new AskEditorDialogFragment.OnAskEditorListener() {
                        @Override
                        public void onEditorSuccess() {
                            refreshView();
                        }
                    });
                    dialog.show(getFragmentManagerWithinHost(), "AskEditorDialogFragment");
                }
            }
        }


    }


    /**
     * 得到当前要求分组的可用菜品分类
     *
     * @param clsList
     * @return
     */
    private String getUseClsName(List<String> clsList) {

        if (ListUtil.isEmpty(clsList)) {
            return "无";
        }
        if (clsList.size() == allMenuTypeBean.size()) {
            return "全部";
        }
        StringBuilder stringBuilder = new StringBuilder();
        MenuTypeBean menuTypeBean;
        for (String id : clsList) {
            menuTypeBean = AppCache.getInstance().fullDataMap.get(id);
            if (menuTypeBean != null) {
                stringBuilder.append(menuTypeBean.fsMenuClsName).append(",");
            }
        }

        String result = stringBuilder.toString();
        if (com.mwee.android.pos.util.TextUtils.validate(result)) {
            result = result.substring(0, result.length() - 1);
        }

        return result;
    }

    private List<MenuTypeBean> allMenuTypeBean = new ArrayList<>();

    /**
     * 初始化所有的菜品分类
     */
    private void initMenuTypeData() {
        MenuManagerProcessor menuManagerProcessor = new MenuManagerProcessor();
        if (!ListUtil.isEmpty(AppCache.getInstance().firstNodeMap)) {
            for (MenuTypeBean menuTypeBean : AppCache.getInstance().firstNodeMap) {
                if (menuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
                    allMenuTypeBean.add(menuTypeBean);
                }
            }
        }
    }
}
