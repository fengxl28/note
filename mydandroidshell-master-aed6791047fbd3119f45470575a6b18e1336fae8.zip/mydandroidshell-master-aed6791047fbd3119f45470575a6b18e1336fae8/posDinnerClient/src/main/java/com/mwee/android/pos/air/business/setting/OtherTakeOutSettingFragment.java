package com.mwee.android.pos.air.business.setting;

import com.mwee.android.pos.base.BaseFragment;

/**
 * Created by qinwei on 2018/3/12.
 */

public class OtherTakeOutSettingFragment extends BaseFragment {
}
