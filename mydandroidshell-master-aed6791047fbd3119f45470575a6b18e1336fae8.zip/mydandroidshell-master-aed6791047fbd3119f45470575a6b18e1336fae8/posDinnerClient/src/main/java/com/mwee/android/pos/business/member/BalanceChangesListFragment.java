package com.mwee.android.pos.business.member;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.BalanceOrder;
import com.mwee.android.pos.business.member.view.ChangeMemberPasswordDialog;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.AnimatorListenerImpl;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by qinwei on 2017/2/21.
 */

public class BalanceChangesListFragment extends BaseListFragment<MemberTradeDetailModel.TradeData> implements View.OnClickListener {
    private static final String KEY_MEMBER_INFO = "key_member_info";

    private ImageView mBalanceChangesTopImg;
    /**
     * 充值
     */
    private Button mBalanceChangesRechargeBtn;
    /**
     * 修改支付密码
     */
    private Button change_psd;
//    private MemberCardModel memberCardModel;
    private MemberProcess mMemberProcess;
    private String last_id = "0";
    private int mCurrentPage = 1;
    private NewMemberCardDetailsModel memberCardModel;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_balance_changes_list;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mBalanceChangesTopImg = (ImageView) view.findViewById(R.id.mBalanceChangesTopImg);
        change_psd = (Button) view.findViewById(R.id.change_psd);
        mBalanceChangesRechargeBtn = (Button) view.findViewById(R.id.mBalanceChangesRechargeBtn);
        mBalanceChangesTopImg.setOnClickListener(this);
        change_psd.setOnClickListener(this);
        mBalanceChangesRechargeBtn.setOnClickListener(this);
        mPullRecyclerView.setEnablePullToEnd(true);
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mMemberProcess = new MemberProcess();
        memberCardModel = (NewMemberCardDetailsModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setRefreshing();
        if (APPConfig.isAir()) {
            //美小易隐藏会员支付密码修改入口
            change_psd.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        if(!ButtonClickTimer.canClick()){
            return;
        }
        switch (v.getId()) {
            case R.id.mBalanceChangesTopImg:
                mPullRecyclerView.smoothScrollToPosition(0);
                break;
            case R.id.change_psd:
                //修改支付密码
                ChangeMemberPasswordDialog changeMemberPasswordDialog = new ChangeMemberPasswordDialog();
                changeMemberPasswordDialog.setParam(memberCardModel.cardInfo.card_no);
                DialogManager.showCustomDialog(this, changeMemberPasswordDialog, "ChangeMemberPasswordDialog");
                break;
            case R.id.mBalanceChangesRechargeBtn:
                toRechargeFragment();

//                BaseFragment fragment = BalanceRechargeFragment.getInstance(memberCardModel);
//                LogUtil.log("跳转会员储值界面");
//                FragmentController.addFragmentWithHide(getFragmentManager(), fragment, BalanceRechargeFragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);

                /*if (AppCache.getInstance().isRetailMode()) {
                    MemberBalanceRechargeDialog dialog = new MemberBalanceRechargeDialog();
                    dialog.setParam(memberCardModel.card_info.card_no, memberCardModel.card_info.mobile);
                    dialog.setOnMemberBalanceRechargeListener(new MemberBalanceRechargeDialog.OnMemberBalanceRechargeListener() {
                        @Override
                        public void onMemberBalanceRechargeSuccess() {
                            doBalanceOrderListRefresh();
                        }
                    });
                    DialogManager.showCustomDialog(this, dialog, "MemberBalanceRechargeDialog");
                } else {
                    BaseFragment fragment = BalanceRechargeFragment.getInstance(memberCardModel);
                    LogUtil.log("跳转会员储值界面");
                    FragmentController.addFragmentWithHide(getFragmentManager(), fragment, BalanceRechargeFragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);
                }*/
                break;
            default:
                break;
        }
    }

    private void toRechargeFragment(){
        Progress progress = ProgressManager.showProgress(getActivityWithinHost(), R.string.member_load_recharge_package_info_ing);
        ClientMemberApi.queryRechargePackage(memberCardModel.cardInfo.card_no, memberCardModel.cardInfo.level, new SocketCallback<MemberRechargePackageModel>() {
            @Override
            public void callback(SocketResponse<MemberRechargePackageModel> response) {
                progress.dismiss();
                if(getContext() == null || !isAdded() || !isFragmentAlive() || isDetached()){
                    return;
                }
                if(response == null){
                    ToastUtil.showToast(getContext().getResources().getString(R.string.error_failed_get_data));
                    return;
                }
                if(response.success() && response.data != null){
                    MemberRechargePackageModel packageData = response.data;
                    if(packageData.pkg_info == null || packageData.card_config == null || ListUtil.isEmpty(packageData.rule_list)){
                        ToastUtil.showToast(getContext().getResources().getString(R.string.member_load_recharge_package_info_msg));
                        return;
                    }
                    //固定 = (!rewardType && !canRechargeAnyAmount)
                    //区间 = (!rewardType && canRechargeAnyAmount)
                    //每满 = (rewardType && canRechargeAnyAmount)
                    BaseFragment fragment;
                    if(!packageData.pkg_info.rewardType && !packageData.pkg_info.canRechargeAnyAmount){
                        fragment = BalanceRechargeFragment.getInstance(memberCardModel,packageData.rule_list);
                    }else{
                        int chargeType = MemberRechargeFragment.TYPE_BETWEEN;
                        if(packageData.pkg_info.rewardType && packageData.pkg_info.canRechargeAnyAmount){
                            chargeType = MemberRechargeFragment.TYPE_FULL;
                        }
                        fragment = MemberRechargeFragment.getInstance(memberCardModel,packageData.rule_list,packageData.card_config.chargeMinLimit,packageData.pkg_info.amountRechargeLimit,chargeType);
                    }
                    LogUtil.log("跳转会员储值界面");
                    FragmentController.addFragmentWithHide(getFragmentManager(), fragment, BalanceRechargeFragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);
                }else{
                    ToastUtil.showToast(response.message);
                }
            }
        });
    }

    /**
     * 刷新会员储值流水界面
     */
    private void doBalanceOrderListRefresh() {
        DriverBus.call("member/rechargeSuccess");//刷会员余额
        doRefresh();
    }

    /*private void loadDataFromServer(final int mode) {
        mMemberProcess.loadMemberBalanceChangeData(memberCardModel.card_info.card_no, last_id, 20, new ResultCallback<BalanceOrderList>() {
            @Override
            public void onSuccess(BalanceOrderList data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                if (data.havenext == 0) {//没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (last_id.equals("0") && !TextUtils.validate(data.list)) {
                    mPullRecyclerView.showEmptyView();
                } else {
                    mPullRecyclerView.showContent();
                    modules.addAll(data.list);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }*/

    private void loadNewDataFromServer(final int mode) {
        ClientMemberApi.queryTradeDetail(memberCardModel.cardInfo.card_no, mCurrentPage, response -> {
            if(response == null || response.data == null){
                mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                if(mCurrentPage > 1){
                    mCurrentPage --;
                }
                return;
            }
            if(response.success()){
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                MemberTradeDetailModel data = response.data;
                if(mCurrentPage < data.pages){
                    mPullRecyclerView.onRefreshCompleted(mode);
                }else{
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                }
                if (ListUtil.isEmpty(data.rows)) {
                    if(mCurrentPage == 1){
                        mPullRecyclerView.showEmptyView();
                    }
                } else {
                    mPullRecyclerView.showContent();
                    modules.addAll(data.rows);
                    adapter.notifyDataSetChanged();
                }
            }else{
                if(mCurrentPage > 1){
                    mCurrentPage --;
                }
                if (!android.text.TextUtils.isEmpty(response.message)) {
                    ToastUtil.showToast(response.message);
                }
                if (mode == PullRecyclerView.STATE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }


    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
//            last_id = "0";
            mCurrentPage = 1;
        } else {
//            last_id = modules.get(modules.size() - 1).id;
            mCurrentPage ++;
        }
        loadNewDataFromServer(mode);
    }

    @Override
    public void onScrollUp() {
        super.onScrollUp();
        if (!AnimatorListenerImpl.isRunning && mBalanceChangesTopImg.getVisibility() == View.GONE) {
            mBalanceChangesTopImg.setVisibility(View.VISIBLE);
            ObjectAnimator animator = ObjectAnimator.ofFloat(mBalanceChangesTopImg, "alpha", 0f, 1f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mBalanceChangesTopImg.setVisibility(View.VISIBLE);
                }
            });
            animator.start();
        }
    }

    @Override
    public void onScrollDown() {
        super.onScrollDown();
        if (!AnimatorListenerImpl.isRunning && mBalanceChangesTopImg.getVisibility() == View.VISIBLE) {
            ObjectAnimator animator = ObjectAnimator.ofFloat(mBalanceChangesTopImg, "alpha", 1f, 0f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mBalanceChangesTopImg.setVisibility(View.GONE);
                }
            });
            animator.start();
        }
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadNewDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.member_balance_changes_item, parent, false));
    }

    public void doRefresh() {
        mPullRecyclerView.setRefreshing();
    }

    class Holder extends BaseViewHolder {
        private TextView mBalanceChangeItemTitleLabel;
        private TextView mBalanceChangeItemPriceLabel;
        private TextView mBalanceChangeItemContentLabel;
        private TextView mBalanceChangeItemTimeLabel;

        public Holder(View v) {
            super(v);
            mBalanceChangeItemTitleLabel = (TextView) v.findViewById(R.id.mBalanceChangeItemTitleLabel);
            mBalanceChangeItemPriceLabel = (TextView) v.findViewById(R.id.mBalanceChangeItemPriceLabel);
            mBalanceChangeItemContentLabel = (TextView) v.findViewById(R.id.mBalanceChangeItemContentLabel);
            mBalanceChangeItemTimeLabel = (TextView) v.findViewById(R.id.mBalanceChangeItemTimeLabel);
        }

        @Override
        public void bindData(int position) {
            /*BalanceOrder m = modules.get(position);
            mBalanceChangeItemTitleLabel.setText(m.title);
            if (Double.valueOf(m.amount) > 0) {
                mBalanceChangeItemPriceLabel.setTextColor(getResources().getColor(R.color.color_ffa800));
            } else {
                mBalanceChangeItemPriceLabel.setTextColor(getResources().getColor(R.color.color_424242));
            }
            mBalanceChangeItemPriceLabel.setText(m.amount);
            mBalanceChangeItemContentLabel.setText(m.description);
            mBalanceChangeItemTimeLabel.setText(m.add_time);*/

            MemberTradeDetailModel.TradeData data = modules.get(position);
            mBalanceChangeItemTitleLabel.setText(data.title);
            if (data.amount > 0) {
                mBalanceChangeItemPriceLabel.setTextColor(getResources().getColor(R.color.color_ffa800));
            } else {
                mBalanceChangeItemPriceLabel.setTextColor(getResources().getColor(R.color.color_424242));
            }
            mBalanceChangeItemPriceLabel.setText(""+data.amount);
            mBalanceChangeItemContentLabel.setText(data.description);
            if(android.text.TextUtils.isEmpty(data.addTime)){
                mBalanceChangeItemTimeLabel.setVisibility(View.GONE);
            }else{
                mBalanceChangeItemTimeLabel.setText(long2Date(StringUtil.toLong(data.addTime,0)*1000));
            }
        }
    }

    public static String long2Date(long time){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(time);
        return sdf.format(date);
    }

    public static BaseFragment getInstance(NewMemberCardDetailsModel memberCardModel) {
        BaseFragment fragment = new BalanceChangesListFragment();
        Bundle args = new Bundle();
        args.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        fragment.setArguments(args);
        return fragment;
    }
}
