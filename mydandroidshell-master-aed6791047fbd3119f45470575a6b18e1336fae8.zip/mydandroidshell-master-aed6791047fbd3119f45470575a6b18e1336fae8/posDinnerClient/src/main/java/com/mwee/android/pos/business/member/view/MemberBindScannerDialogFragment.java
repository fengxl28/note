package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.DensityUtil;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;
import com.mwee.android.pos.widget.ScannerView;
import com.mwee.android.pos.widget.TimeButton;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;

/**
 * 扫码绑定会员
 * Created by qinwei on 2017/3/21.
 */

public class MemberBindScannerDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private EditText mMemberSelectEdt;
    private MemberProcess mMemberProcess;
    private NewMemberCheckCallBack newCallBack;
    private String orderId;
    private String mMemberCardNoTemp = "";
    private TextView mMemberSelectPhoneLabel;//手机号
    private TextView mMemberSelectPhoneCodeLabel;//验证码
    private TextView mMemberSelectBindCommitLabel;//验证并绑定会员
    private TimeButton mMemberSelectPhoneCodeGetBtn;//获取验证码按钮
    private NumberKeyboard mMemberBindNumberKeyboard;
    private TextView mSelectInput;
    public Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String input = TextUtils.formatSpace(mMemberSelectEdt.getText().toString().trim());
            if (TextUtils.formatSpace(mMemberCardNoTemp).equals(input)) {
                hideKeyboard();
                doSelectRequest(input);
            }
        }
    };

    @Override
    public void onDestroy() {
        if (mMemberSelectPhoneCodeGetBtn != null) {
            mMemberSelectPhoneCodeGetBtn.callDestroy();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_new_member_bind_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.content).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMemberSelectEdt.requestFocus();
                hideKeyboard();
            }
        });
        initView(view);
        initData();
    }

    private void initView(View view) {
        mMemberSelectPhoneLabel = (TextView) view.findViewById(R.id.mMemberSelectPhoneLabel);
        mMemberSelectPhoneCodeLabel = (TextView) view.findViewById(R.id.mMemberSelectPhoneCodeLabel);
        mMemberSelectBindCommitLabel = (TextView) view.findViewById(R.id.mMemberSelectBindCommitLabel);
        mMemberSelectPhoneCodeGetBtn = (TimeButton) view.findViewById(R.id.mMemberSelectPhoneCodeGetBtn);
        mMemberSelectPhoneCodeGetBtn.setOnTimeChangedListener(new TimeButton.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(int ss) {
                mMemberSelectPhoneCodeGetBtn.setText("" + ss);
            }

            @Override
            public void onTimeCompleted() {
                mMemberSelectPhoneCodeGetBtn.setText(R.string.code);
            }
        });

        mMemberBindNumberKeyboard = (NumberKeyboard) view.findViewById(R.id.mMemberBindNumberKeyboard);
        mMemberBindNumberKeyboard.setItemLayoutId(R.layout.view_key_item_small);
        mMemberBindNumberKeyboard.initData(KeyHelper.generateOnlyBackKeys(), keyEntity -> {
            switch (keyEntity.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    mSelectInput.append(keyEntity.value);
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CONFIRM:
                    CharSequence text = mSelectInput.getText();
                    if (text.length() <= 0) {
                        return;
                    }
                    if (text.length() == 1) {
                        mSelectInput.setText("");
                        return;
                    }
                    mSelectInput.setText(text.subSequence(0, text.length() - 1));
                    break;
                case NumberKeyboard.KeyEntity.TYPE_BACK:
                    break;
                default:
                    break;
            }
        });
        mMemberBindNumberKeyboard.notifyDataChanged();

        int width, height;
        switch (SettingHelper.getShopMemberConfig()) {
            case Constants.MOBILE_PAY_TYPE_NOT_OPEN: // 未开通手机号
                view.findViewById(R.id.title).setVisibility(View.GONE);
                view.findViewById(R.id.divider_vertical).setVisibility(View.GONE);
                view.findViewById(R.id.mMemberSelectMobileLayout).setVisibility(View.GONE);
                view.findViewById(R.id.ll_phone_code).setVisibility(View.GONE);
                view.findViewById(R.id.tv_scan_hint).setVisibility(View.VISIBLE);
                view.findViewById(R.id.mConfigTipLabel).setVisibility(View.VISIBLE);
                view.findViewById(R.id.divider_horizontal).setVisibility(View.VISIBLE);
                view.findViewById(R.id.tv_cancel).setVisibility(View.VISIBLE);
                width = DensityUtil.getScreenWidth(getContextWithinHost()) / 3;
                height = DensityUtil.dip2px(getContextWithinHost(), 340);
                break;
            case Constants.MOBILE_PAY_TYPE_CODE_VALIDATE: // 手机号验证
                view.findViewById(R.id.title).setVisibility(View.VISIBLE);
                view.findViewById(R.id.divider_vertical).setVisibility(View.VISIBLE);
                view.findViewById(R.id.mMemberSelectMobileLayout).setVisibility(View.VISIBLE);
                view.findViewById(R.id.ll_phone_code).setVisibility(View.VISIBLE);
                view.findViewById(R.id.tv_scan_hint).setVisibility(View.GONE);
                view.findViewById(R.id.mConfigTipLabel).setVisibility(View.GONE);
                view.findViewById(R.id.divider_horizontal).setVisibility(View.GONE);
                view.findViewById(R.id.tv_cancel).setVisibility(View.GONE);
                width = DensityUtil.dip2px(getContextWithinHost(), 600);
                height = DensityUtil.dip2px(getContextWithinHost(), 480);
                break;
            case Constants.MOBILE_PAY_TYPE_NOT_VALIDATE: // 手机号免密
                view.findViewById(R.id.title).setVisibility(View.VISIBLE);
                view.findViewById(R.id.divider_vertical).setVisibility(View.VISIBLE);
                view.findViewById(R.id.mMemberSelectMobileLayout).setVisibility(View.VISIBLE);
                view.findViewById(R.id.ll_phone_code).setVisibility(View.GONE);
                view.findViewById(R.id.tv_scan_hint).setVisibility(View.GONE);
                view.findViewById(R.id.mConfigTipLabel).setVisibility(View.GONE);
                view.findViewById(R.id.divider_horizontal).setVisibility(View.GONE);
                view.findViewById(R.id.tv_cancel).setVisibility(View.GONE);
                width = DensityUtil.dip2px(getContextWithinHost(), 600);
                height = DensityUtil.dip2px(getContextWithinHost(), 480);
                break;
            default:
                width = DensityUtil.dip2px(getContextWithinHost(), 600);
                height = DensityUtil.dip2px(getContextWithinHost(), 480);
                break;
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, height);
        view.findViewById(R.id.content).setLayoutParams(lp);

        view.findViewById(R.id.tv_cancel).setOnClickListener(this);
        mMemberSelectPhoneLabel.setOnClickListener(this);
        mMemberSelectPhoneCodeLabel.setOnClickListener(this);
        mMemberSelectPhoneCodeGetBtn.setOnClickListener(this);
        mMemberSelectBindCommitLabel.setOnClickListener(this);
        mMemberSelectEdt = (EditText) view.findViewById(R.id.mMemberSelectEdt);
        mMemberSelectEdt.addTextChangedListener(watcher);

        mMemberSelectPhoneLabel.setBackgroundResource(R.drawable.bg_pay_input_red);
        mMemberSelectPhoneCodeLabel.setBackgroundResource(R.drawable.bg_pay_input);
        mSelectInput = mMemberSelectPhoneLabel;

        mMemberSelectEdt.requestFocus();
        hideKeyboard();
    }

    private void hideKeyboard() {
        mMemberSelectEdt.post(new Runnable() {
            @Override
            public void run() {
                KeyboardManager.hideSoftInput(getContext(), mMemberSelectEdt);
            }
        });
    }

    private TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            LogUtil.log(s.toString());
            mMemberCardNoTemp = s.toString();
            mHandler.removeMessages(0);
            mHandler.sendEmptyMessageDelayed(0, 200);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    private void initData() {
        mMemberProcess = new MemberProcess();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_cancel:
                dismissSelf();
                break;
            case R.id.mMemberSelectBindCommitLabel:
                String phone = mMemberSelectPhoneLabel.getText().toString();
                if (SettingHelper.getShopMemberConfig().equals(Constants.MOBILE_PAY_TYPE_CODE_VALIDATE)) {
                    //验证码使用会员
                    String code = mMemberSelectPhoneCodeLabel.getText().toString();
                    if (validate(phone, code)) {
                        doSelectRequest(phone, code);
                    }
                } else {
                    //免密使用会员
                    doSelectRequest(phone);
                }
                break;
            case R.id.mMemberSelectPhoneCodeGetBtn:
                phone = mMemberSelectPhoneLabel.getText().toString();
                if (!TextUtils.validate(phone)) {
                    ToastUtil.showToast(R.string.input_mobile_msg);
                    return;
                }
                RunTimeLog.addLog(RunTimeLog.MEMBER, "获取验证码：phone=" + phone);
                final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
                mMemberProcess.sendVerifyCode(phone, 2, new ResultCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        mMemberSelectPhoneCodeGetBtn.start();
                        progress.dismissSelf();
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        ToastUtil.showToast(msg);
                        progress.dismissSelf();
                    }
                });
                break;
            case R.id.mMemberSelectPhoneLabel:
                mMemberSelectPhoneLabel.setBackgroundResource(R.drawable.bg_pay_input_red);
                mMemberSelectPhoneCodeLabel.setBackgroundResource(R.drawable.bg_pay_input);
                mSelectInput = mMemberSelectPhoneLabel;
//                CountKeyboardFragment phoneFragment = new CountKeyboardFragment();
//                phoneFragment.setMode(CountKeyboardFragment.MODEL_PHONE);
//                phoneFragment.setTitle(getString(R.string.input_mobile_msg));
//                phoneFragment.setIsSupportFloat(false);
//                phoneFragment.setErrorTips(getString(R.string.input_mobile_error));
//                phoneFragment.setCallback(new CountKeyboardCallback() {
//                    @Override
//                    public void callback(BigDecimal originNum, BigDecimal newNum) {
//                        mMemberSelectPhoneLabel.setText(newNum.toPlainString());
//                    }
//                });
//                phoneFragment.show(getFragmentManager(), "");
                break;
            case R.id.mMemberSelectPhoneCodeLabel:
                mMemberSelectPhoneLabel.setBackgroundResource(R.drawable.bg_pay_input);
                mMemberSelectPhoneCodeLabel.setBackgroundResource(R.drawable.bg_pay_input_red);
                mSelectInput = mMemberSelectPhoneCodeLabel;
//                CountKeyboardFragment codeFragment = new CountKeyboardFragment();
//                codeFragment.setMode(0);
//                codeFragment.setMaxCount(999999);
//                codeFragment.setTitle(getString(R.string.input_validate_code));
//                codeFragment.setErrorTips(getString(R.string.input_code_length_not_more_six));
//                codeFragment.setIsSupportFloat(false);
//                codeFragment.setCallback(new CountKeyboardCallback() {
//                    @Override
//                    public void callback(BigDecimal originNum, BigDecimal newNum) {
//                        mMemberSelectPhoneCodeLabel.setText(newNum.toPlainString());
//                    }
//                });
//                codeFragment.show(getFragmentManager(), "");
                break;
            default:
                break;
        }
        mMemberSelectEdt.requestFocus();
        hideKeyboard();
    }

    /**
     * 非空判断
     *
     * @param phone 手机号
     * @param code  验证码
     * @return
     */
    private boolean validate(String phone, String code) {
        if (!TextUtils.validate(phone)) {
            ToastUtil.showToast(R.string.input_mobile_msg);
            return false;
        }
        if (!TextUtils.validate(code)) {
            ToastUtil.showToast(R.string.input_validate_code);
            return false;
        }
        return true;
    }

    /**
     * 手机验证码会员关联请求
     *
     * @param phone
     * @param code
     */
    private void doSelectRequest(String phone, String code) {
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询ing phone:" + phone + ",code:" + code + "，orderId=" + orderId);
        mMemberSelectEdt.removeTextChangedListener(watcher);
        mMemberProcess.optMemberInfoAndBindToOrder(phone, code, 2, orderId, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                mMemberSelectEdt.addTextChangedListener(watcher);
                if (progress != null) {
                    progress.dismissSelf();
                }

                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->card size=" + data.cardList.size() + "，orderId=" + orderId);
                if (data.bindResponse != null) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->card no=" + data.bindResponse.memberCardModel.cardInfo.card_no + "，orderId=" + orderId);
                    newCallBack.call(data.bindResponse);
                    dismiss();
                    return;
                }
                MemberCardListChooseFragment fragment = new MemberCardListChooseFragment();
                fragment.setParams(data.cardList, orderId, newCallBack);
                DialogManager.showCustomDialog(getActivityWithinHost(), fragment, fragment.getTag());
                dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                mMemberSelectEdt.addTextChangedListener(watcher);
                if (progress != null) {
                    progress.dismissSelf();
                }
                ToastUtil.showToast(msg);
                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询failure code=" + code + " msg=" + msg + "，orderId=" + orderId);
            }
        });
    }

    /**
     * 通过会员卡号，或者手机免密查询会员
     *
     * @param account
     */
    private void doSelectRequest(String account) {
        //查询前先移除 EditText监听（防止请求过程中使用扫码枪输入重复请求问题）
        mMemberSelectEdt.removeTextChangedListener(watcher);
        //查询前先把EditText监听内容情况(防止扫码枪录入数据叠加问题)
        mMemberSelectEdt.setText("");
        if (SettingHelper.getShopMemberConfig().equals(Constants.MOBILE_PAY_TYPE_NOT_OPEN) && TextUtils.checkIsPhoneNumber(account)) {
            //门店会员不支持使用手机号验证消费判断
            ToastUtil.showToast(R.string.member_order_bind_error_1);
            mMemberSelectEdt.addTextChangedListener(watcher);
            return;
        } else if (SettingHelper.getShopMemberConfig().equals(Constants.MOBILE_PAY_TYPE_CODE_VALIDATE) && TextUtils.checkIsPhoneNumber(account)) {
            //手机号验证消费
            mMemberSelectEdt.addTextChangedListener(watcher);
            ToastUtil.showToast(R.string.member_order_bind_error_2);
            return;
        }
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询ing 录入内容:" + account + "，orderId=" + orderId);

        mMemberProcess.optMemberInfoWithoutVerifyAndBindToOrder(account, orderId, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                mMemberSelectEdt.addTextChangedListener(watcher);
                if (progress != null) {
                    progress.dismiss();
                }
                if (data.bindResponse != null) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->cardno=" + data.bindResponse.memberCardModel.cardInfo.card_no + "，orderId=" + orderId);
                    newCallBack.call(data.bindResponse);
                    dismiss();
                } else if (!ListUtil.isEmpty(data.cardList)) {
                    MemberCardListChooseFragment fragment = new MemberCardListChooseFragment();
                    fragment.setParams(data.cardList, orderId, newCallBack);
                    DialogManager.showCustomDialog(getActivityWithinHost(), fragment, fragment.getTag());
                    dismiss();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                mMemberSelectEdt.addTextChangedListener(watcher);
                if (progress != null) {
                    progress.dismiss();
                }
                ToastUtil.showToast(msg);
                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询failure code=" + code + " msg=" + msg + "，orderId=" + orderId);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public void setNewCallBack(NewMemberCheckCallBack callBack) {
        this.newCallBack = callBack;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}