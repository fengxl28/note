package com.mwee.android.pos.business.member.view;

import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;

/**
 * Created by lxx on 16/7/5.
 */
public interface MemberCheckCallBack {

    void call(QueryMemberInfoAndBindToOrderResponse member);
}
