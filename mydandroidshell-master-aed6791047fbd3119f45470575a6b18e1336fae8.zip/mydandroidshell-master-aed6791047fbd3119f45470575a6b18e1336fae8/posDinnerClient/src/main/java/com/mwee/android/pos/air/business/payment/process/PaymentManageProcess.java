//package com.mwee.android.pos.air.business.payment.process;
//
//import com.mwee.android.air.connect.business.payment.GetAllPaymentResponse;
//import com.mwee.android.air.db.business.payment.PaymentManageInfo;
//import com.mwee.android.base.net.ResponseData;
//import com.mwee.android.base.task.BusinessExecutor;
//import com.mwee.android.base.task.callback.IExecutorCallback;
//import com.mwee.android.pos.air.business.payment.api.PaymentManageApi;
//import com.mwee.android.pos.air.business.payment.entity.PayOpenStatus;
//import com.mwee.android.pos.air.business.payment.entity.PayOpenStatusRequest;
//import com.mwee.android.pos.air.business.payment.entity.PayOpenStatusResponse;
//import com.mwee.android.pos.air.business.payment.view.PaymentManageFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.util.TextUtils;
//import com.mwee.android.pos.util.ToastUtil;
//
//import java.util.ArrayList;
//
///**
// * @ClassName: PaymentManageProcess
// * @Description:
// * @author: SugarT
// * @date: 2017/10/14 上午11:14
// */
//public class PaymentManageProcess {
//
//    private PaymentManageFragment mView;
//
//    public PaymentManageProcess(PaymentManageFragment view) {
//        mView = view;
//        mView.setProcess(this);
//    }
//
//    public void start() {
//        PaymentManageApi.getAllPayment(new IResponse<GetAllPaymentResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, GetAllPaymentResponse info) {
//                if (!result) {
//                    ToastUtil.showToast(TextUtils.validate(msg) ? msg : "数据获取失败，请重试");
//                    return;
//                }
//                mView.refreshView(info.paymentList);
//            }
//        });
//    }
//
//    public  void loadPayOpenStatus(ResultCallback<ArrayList<PayOpenStatus>> callback) {
//
//        PayOpenStatusRequest request = new PayOpenStatusRequest();
//        request.shopId = AppCache.getInstance().fsShopGUID;
//        BusinessExecutor.execute(request, new IExecutorCallback() {
//            @Override
//            public void success(ResponseData responseData) {
//                if (responseData.responseBean != null && responseData.responseBean instanceof PayOpenStatusResponse) {
//                    PayOpenStatusResponse responseBean = (PayOpenStatusResponse) responseData.responseBean;
//                    callback.onSuccess(responseBean.data);
//                }
//            }
//
//            @Override
//            public boolean fail(ResponseData responseData) {
//                callback.onFailure(responseData.result, responseData.resultMessage);
//                return false;
//            }
//        });
//    }
//
//
//
//    public void delete(PaymentManageInfo model) {
//        if (model == null) {
//            return;
//        }
//        PaymentManageApi.deletePayment(model.fsPaymentId, new IResponse<GetAllPaymentResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, GetAllPaymentResponse info) {
//                if (!result) {
//                    ToastUtil.showToast(TextUtils.validate(msg) ? msg : "数据获取失败，请重试");
//                    return;
//                }
//                mView.refreshView(info.paymentList);
//            }
//        });
//    }
//}
