package com.mwee.android.pos.air.business.tticket;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;

/**
 * Created by zhangmin on 2017/9/28.
 */

public class TscTicketFragment extends BaseFragment {

    private Switch swWhetherPrinter;
    private RadioGroup rgTicketDirection;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_ticket_tsc_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        init();
    }

    private void assignViews(View containView) {

        rgTicketDirection = (RadioGroup) containView.findViewById(R.id.rgTicketDirection);
        swWhetherPrinter = (Switch) containView.findViewById(R.id.swWhetherPrinter);

    }


    private void registerEvent() {
        rgTicketDirection.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                ActionLog.addLog(ActionLog.TICKET_CONFIG, "点击了标签小票 方向");
                if (checkedId == R.id.rbTicketDirectionPositive) {
                    SettingProcessor.refreshSettingStatus(META.TSC_REVERSE, "0");
                } else {
                    SettingProcessor.refreshSettingStatus(META.TSC_REVERSE, "1");
                }
            }
        });
        swWhetherPrinter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ActionLog.addLog(ActionLog.TICKET_CONFIG, "点击了标签小票 是否打印");
                SettingProcessor.refreshSettingStatus(META.T_TSC_PRINTER, isChecked ? "1" : "0");
            }
        });
    }

    private void init() {
        if (TextUtils.equals(ClientMetaUtil.getConfig(META.TSC_REVERSE, "0"), "0")) {
            ((RadioButton) rgTicketDirection.getChildAt(0)).setChecked(true);
        } else {
            ((RadioButton) rgTicketDirection.getChildAt(1)).setChecked(true);
        }
        swWhetherPrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_TSC_PRINTER, "1"), "1"));
    }

}
