package com.mwee.android.pos.business.einvoice;

import com.mwee.android.pos.connect.business.setting.GetAllManualIEnvoiceResponse;
import com.mwee.android.pos.connect.business.setting.PrintManualIEnvoiceResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CManualEInvoice;

public class ManualEInvoiceApi {

    public void optDataFromServer(int page, String date) {

    }

    /**
     * 获取所有的手动开发票数据
     *
     * @param date           //当前自然日
     * @param currentPage    //当前页数
     * @param socketCallback
     */
    public static void optDataFromServer(int currentPage, String date, SocketCallback<GetAllManualIEnvoiceResponse> socketCallback) {
        MCon.c(CManualEInvoice.class, socketCallback).optDataFromServer(currentPage, date);
    }

    /**
     * 获取所有的手动开发票数据
     *
     * @param date           //当前自然日
     * @param amt    //金额
     * @param socketCallback
     */
    public static void addManualEInvoice(String amt, String date, SocketCallback<PrintManualIEnvoiceResponse> socketCallback) {
        MCon.c(CManualEInvoice.class, socketCallback).addManualEInvoice(amt, date);
    }

    /**
     * 重印
     *
     * @param orderId           小票订单号
     * @param socketCallback
     */
    public static void reprintManualEInvoice(String orderId, SocketCallback<PrintManualIEnvoiceResponse> socketCallback) {
        MCon.c(CManualEInvoice.class, socketCallback).reprintManualEInvoice(orderId);
    }


}
