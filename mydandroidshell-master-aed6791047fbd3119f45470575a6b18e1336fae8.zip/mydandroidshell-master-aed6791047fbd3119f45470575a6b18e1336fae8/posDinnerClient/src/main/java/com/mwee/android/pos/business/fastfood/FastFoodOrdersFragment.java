package com.mwee.android.pos.business.fastfood;

import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodOrdersViewProcessor;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodProcessor;
import com.mwee.android.pos.business.common.fastfood.IFastFoodProcessor;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.TimerHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DateUtil;

import java.lang.ref.WeakReference;
import java.text.ParseException;

/**
 * Created by lxx on 17/2/9
 * 快餐订单页
 */
public class FastFoodOrdersFragment implements IDriver, View.OnClickListener {

    public static final String TAG = FastFoodOrdersFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "fastfoodOrders";
    private Host parentHost;
    private GridView fastfood_order_gv;
    private TextView table_remind_tv;  //没有数据提示

    private LinearLayout table_turnpage_lyt;

    private TextView table_pre_page_tv;
    private TextView table_next_page_tv;

    private CommonAdapter<FastFoodSimpInfo> fastfoodAdapter;

    private int totalPages = 1;
    private int currentPage = 0;
    private TimerHelper mTimerHelper;
    private IFastFoodProcessor mFastFoodProcessor;
    private FastFoodOrdersViewProcessor viewProcessor = new FastFoodOrdersViewProcessor();
    private String fsBillSourceId = "-1";
    /**
     * 当前类的View
     */
    private View rootView = null;
    /**
     * 当前View是否是显示状态
     */
    boolean show = false;


    public void setRootView(View view) {
        rootView = view;
        if (parentHost == null) {
            return;
        }
        initUI(rootView);
    }

    public void handleDriverBus(boolean open) {
        if (open) {
            DriverBus.registerDriver(this);
            mTimerHelper.startTimerTask();
        } else {
            DriverBus.unRegisterDriver(this);
            mTimerHelper.stopTimerTask();
        }
    }

    public void init() {
        mTimerHelper = new TimerHelper();
        mTimerHelper.setDelayMillis(120 * 1000);
        mTimerHelper.setOnTimerListener(new TimerHelperListener(FastFoodOrdersFragment.this));
        mFastFoodProcessor = new FastFoodProcessor();
        mFastFoodProcessor.setViewProcessor(viewProcessor);
    }

    static class TimerHelperListener implements TimerHelper.OnTimerListener {
        private WeakReference<FastFoodOrdersFragment> reference;

        public TimerHelperListener(FastFoodOrdersFragment fragment) {
            this.reference = new WeakReference<FastFoodOrdersFragment>(fragment);
        }

        @Override
        public void execute() {
            //TODO 请求业务中心，刷新桌台状态
            FastFoodOrdersFragment fastFoodOrdersFragment = reference.get();
            if (fastFoodOrdersFragment != null) {
                fastFoodOrdersFragment.fastfoodAdapter.notifyDataSetChanged();
            }
        }
    }

    public void setShow(boolean show) {
        this.show = show;
        rootView.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    public void onHiddenChanged(boolean hidden) {
        if (hidden) {
            return;
        }
        NotifyToServer.refreshOrderLock(AppCache.getInstance().currentHostId);
        requestDatasFromBiz();
    }


    @DrivenMethod(uri = DRIVER_TAG + "/onParentHinddenChanged", UIThread = true)
    public void onParentHiddenChanged(boolean hidden) {
        if (hidden) {
            return;
        }
        NotifyToServer.refreshOrderLock(AppCache.getInstance().currentHostId);
        requestDatasFromBiz();
    }

    @DrivenMethod(uri = DRIVER_TAG + "/selectionBillSource", UIThread = true)
    public void selectionBillSource(String fsBillSourceId) {
        ActionLog.addLog("快餐订单页：切换订单来源" + fsBillSourceId, ActionLog.USER_ACTION_TRACE);
        this.fsBillSourceId = fsBillSourceId;
        requestDatasFromBiz();
    }

    public void setParentHost(Host mParentHost) {
        parentHost = mParentHost;
    }


    private void initUI(View view) {
        viewProcessor.updateDatasCount(parentHost);

        table_remind_tv = (TextView) view.findViewById(R.id.table_remind_tv);
        fastfood_order_gv = (GridView) view.findViewById(R.id.fastfood_order_gv);

        table_turnpage_lyt = (LinearLayout) view.findViewById(R.id.table_turnpage_lyt);
        table_pre_page_tv = (TextView) view.findViewById(R.id.table_pre_page_tv);
        table_next_page_tv = (TextView) view.findViewById(R.id.table_next_page_tv);

        initFastFoodOrdersAdapter();//桌台Gridview
        fastfood_order_gv.setAdapter(fastfoodAdapter);

        registEvent();
        ProgressManager.showProgress(parentHost, R.string.progress_loading);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refreshLockState", UIThread = true)
    public void refreshLockState(String data) {
        viewProcessor.parseLockData(data);
        fastfoodAdapter.notifyDataSetChanged();
    }

    public void onResume() {
        NotifyToServer.refreshOrderLock(AppCache.getInstance().currentHostId);
        requestDatasFromBiz();
    }

    public void onPause() {
        mTimerHelper.stopTimerTask();
    }

    /**
     * 去业务中心查找所有未结账快餐单
     */
    @DrivenMethod(uri = DRIVER_TAG + "/requestDataFromBiz", UIThread = true)
    public void requestDatasFromBiz() {
        fastfood_order_gv.setVisibility(View.VISIBLE);
        table_turnpage_lyt.setVisibility(View.GONE);// 暂时不接翻页
        mFastFoodProcessor.refreshAllData(fsBillSourceId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                fastfoodAdapter.notifyDataSetChanged();//刷新桌台状态，添加锁桌标识
                if (result) {//去业务中心获取数据成功 配置数据刷新桌台信息
                    totalPages = viewProcessor.getTotalPages(viewProcessor.allFastFoodOrders);
                    if (currentPage >= totalPages) {
                        currentPage = 0;
                    }
                    viewProcessor.turnPage(currentPage);
                    updateDatasView();
                    fastfood_order_gv.setVisibility(View.VISIBLE);
                    table_remind_tv.setVisibility(View.GONE);
                } else {
//                    fastfood_order_gv.setVisibility(View.GONE);
//                    table_turnpage_lyt.setVisibility(View.GONE);
//                    table_remind_tv.setVisibility(View.VISIBLE);
//                    table_remind_tv.setOnClickListener(FastFoodOrdersFragment.this);
//                    table_remind_tv.setText(R.string.fast_food_order_none);
                }


                ProgressManager.closeProgress(parentHost);
            }
        });
    }

    private void registEvent() {
        fastfood_order_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                ActionLog.addLog("点击快餐订单", viewProcessor.fastFoodOrdersToShow.get(position).order_id, viewProcessor.fastFoodOrdersToShow.get(position).mealNumber, ActionLog.FF_ORDER_ITEM_CLICK, "");
                ProgressManager.showProgress(parentHost, R.string.get_fast_order);
                String order_id = viewProcessor.fastFoodOrdersToShow.get(position).order_id;
                mFastFoodProcessor.loadOrderCacheById(order_id, new ResultCallback<StartFastFoodOrderResponse>() {
                    @Override
                    public void onSuccess(StartFastFoodOrderResponse data) {
                        ProgressManager.closeProgress(parentHost);
                        OrderDishesJump.showFastFoodDish(parentHost, R.id.main_menufragment, data.fastOrderModel, data.menuItems, data.orderStatus);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        ProgressManager.closeProgress(parentHost);
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    private void updateDatasView() {
        fastfoodAdapter.notifyDataSetChanged();
        if (totalPages > 1) {
            table_turnpage_lyt.setVisibility(View.VISIBLE);
            if (currentPage > 0) {
                table_pre_page_tv.setTextColor(ViewToolsUtil.getColor(R.color.table_turn_page_clickable));
                table_pre_page_tv.setOnClickListener(this);
            } else {
                table_pre_page_tv.setTextColor(ViewToolsUtil.getColor(R.color.table_turn_page_unclick));
                table_pre_page_tv.setOnClickListener(null);
            }

            if (currentPage < totalPages - 1) {
                table_next_page_tv.setOnClickListener(this);
                table_next_page_tv.setTextColor(ViewToolsUtil.getColor(R.color.table_turn_page_clickable));
            } else {
                table_next_page_tv.setOnClickListener(null);
                table_next_page_tv.setTextColor(ViewToolsUtil.getColor(R.color.table_turn_page_unclick));
            }
        } else {
            table_turnpage_lyt.setVisibility(View.GONE);
        }
    }

    /**
     * 快餐单
     */
    private void initFastFoodOrdersAdapter() {
        fastfoodAdapter = new CommonAdapter<FastFoodSimpInfo>(parentHost.getContextWithinHost(), viewProcessor
                .fastFoodOrdersToShow, R.layout.fastfood_orders_item) {

            @Override
            public void convert(ViewHolder viewHolder, FastFoodSimpInfo data, int position) {
                viewHolder.getConvertView().setVisibility(View.VISIBLE);
                viewHolder.setVisibility(R.id.order_lock_icon, View.GONE);//释放锁桌图标
                viewHolder.setVisibility(R.id.order_print_img, View.GONE);//释放预结账单图标
                viewHolder.setVisibility(R.id.payed_img, View.GONE);//有支付信息图标
                viewHolder.setText(R.id.order_id_tv, viewProcessor.formatOrderId(data.order_id));
                viewHolder.setText(R.id.source_name, data.fsBillSourceName);
                viewHolder.setText(R.id.meal_number, data.mealNumber);
                if (viewProcessor.isLock(data.order_id)) {
                    viewHolder.setVisibility(R.id.order_lock_icon, View.VISIBLE);
                }

                if (data.hasPayInfo > 0) {
                    viewHolder.setVisibility(R.id.payed_img, View.VISIBLE);
                    viewHolder.getView(R.id.tableItemLayout).setSelected(true);
                    viewHolder.getView(R.id.order_id_tv).setSelected(true);
                    viewHolder.getView(R.id.source_name).setSelected(true);
                    viewHolder.getView(R.id.meal_number).setSelected(true);
                    viewHolder.setTextColor(R.id.open_time, ViewToolsUtil.getColor(R.color.white));

                } else {
                    viewHolder.getView(R.id.tableItemLayout).setSelected(false);
                    viewHolder.getView(R.id.order_id_tv).setSelected(false);
                    viewHolder.getView(R.id.source_name).setSelected(false);
                    viewHolder.getView(R.id.meal_number).setSelected(false);
                    viewHolder.setTextColor(R.id.open_time, ViewToolsUtil.getColor(R.color.system_red));
                }

                String openLength = openLength(data.create_time);//显示桌台开台时间
                if (!TextUtils.isEmpty(openLength)) {
                    viewHolder.setText(R.id.open_time, openLength);
                    viewHolder.setVisibility(R.id.open_time, View.VISIBLE);
                } else {
                    viewHolder.setVisibility(R.id.open_time, View.GONE);
                }
            }
        };
    }

    /**
     * 开台时长
     *
     * @param fsopenhstime
     * @return
     */
    private String openLength(String fsopenhstime) {
        String openLength = "";
        if (!TextUtils.isEmpty(fsopenhstime)) {
            try {
                int currentTime = DateTimeUtil.getMMBetween(fsopenhstime, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (currentTime <= 0) {
                    currentTime = 1;
                }
                if (currentTime <= 999) {
                    openLength = currentTime + parentHost.getContextWithinHost().getString(R.string.time_minute);
                } else {
                    openLength = "999" + parentHost.getContextWithinHost().getString(R.string.time_minute) + "+";
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return openLength;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.table_remind_tv:
                ProgressManager.showProgress(parentHost, R.string.progress_loading);
                requestDatasFromBiz();
                break;
            case R.id.table_pre_page_tv: {
                if (currentPage > 0 && viewProcessor.turnPage(currentPage - 1)) {
                    currentPage--;
                    updateDatasView();
                }
                break;
            }
            case R.id.table_next_page_tv: {
                if (currentPage < totalPages && viewProcessor.turnPage(currentPage + 1)) {
                    currentPage++;
                    updateDatasView();
                }
                break;
            }
        }
    }

}
