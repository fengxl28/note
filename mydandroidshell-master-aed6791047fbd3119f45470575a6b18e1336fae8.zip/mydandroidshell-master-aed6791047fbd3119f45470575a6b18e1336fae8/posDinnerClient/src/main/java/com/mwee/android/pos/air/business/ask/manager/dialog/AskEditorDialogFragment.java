package com.mwee.android.pos.air.business.ask.manager.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.air.business.ask.manager.processor.AskProcessor;
import com.mwee.android.pos.air.business.utils.PriceInputFilter;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by qinwei on 2017/9/30.
 */

public class AskEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mAskEditorTitleLabel;
    private EditText mAskEditorNameEdt;
    private EditText mAskEditorPriceEdt;
    private Button mAskEditorCancelBtn;
    private Button mAskEditorConfirmBtn;
    private OnAskEditorListener listener;
    private String askGpId;
    private AirAskManageInfo askDBModel;
    private Spinner mAskGpSpinner;


    private AskProcessor mProcessor;
    private CommonAdapter<AirAskGroupManagerInfo> askGpAdapter;
    private CommonAdapter<String> askTypeAdapter;
    private ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoWhisOutAllList = new ArrayList<>();
    private Spinner mAskTypeSpinner;
    private ArrayList<String> mAskPriceTypes;
    private int currentAskPriceTypePosition;
    private TextView mAskEditorPriceTypeLabel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ask_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mAskEditorTitleLabel = (TextView) view.findViewById(R.id.mAskEditorTitleLabel);
        mAskEditorPriceTypeLabel = (TextView) view.findViewById(R.id.mAskEditorPriceTypeLabel);
        mAskEditorNameEdt = (EditText) view.findViewById(R.id.mAskEditorNameEdt);
        mAskEditorPriceEdt = (EditText) view.findViewById(R.id.mAskEditorPriceEdt);
        mAskGpSpinner = (Spinner) view.findViewById(R.id.mAskGpSpinner);
        mAskTypeSpinner = (Spinner) view.findViewById(R.id.mAskTypeSpinner);
        mAskEditorCancelBtn = (Button) view.findViewById(R.id.mAskEditorCancelBtn);
        mAskEditorConfirmBtn = (Button) view.findViewById(R.id.mAskEditorConfirmBtn);
        mAskEditorCancelBtn.setOnClickListener(this);
        mAskEditorConfirmBtn.setOnClickListener(this);

        mAskEditorPriceEdt.setFilters(new InputFilter[]{new PriceInputFilter()});
    }

    private void initData() {
        if (isEditor()) {
            mAskEditorTitleLabel.setText("编辑菜品要求");
            mAskEditorNameEdt.setText(askDBModel.fsAskName);
            mAskEditorPriceEdt.setText(askDBModel.fdAddPrice.toPlainString());
        } else {
            mAskEditorTitleLabel.setText("新增菜品要求");
        }

        askGpAdapter = new CommonAdapter<AirAskGroupManagerInfo>(getContext(), airAskGroupManagerInfoWhisOutAllList, R.layout.simple_spinner_item) {
            @Override
            public void convert(ViewHolder viewHolder, AirAskGroupManagerInfo data, int position) {
                ((TextView) viewHolder.getConvertView()).setText(data.fsAskGpName);
            }
        };
        mAskGpSpinner.setAdapter(askGpAdapter);
        int position = 0;
        for (int i = 0; i < airAskGroupManagerInfoWhisOutAllList.size(); i++) {
            if (airAskGroupManagerInfoWhisOutAllList.get(i).fsAskGpId.equals(askGpId)) {
                position = i;
            }
        }
        mAskGpSpinner.setSelection(position);
        mAskPriceTypes = new ArrayList<>();
        mAskPriceTypes.add("加价");
        mAskPriceTypes.add("减价");
        askTypeAdapter = new CommonAdapter<String>(getContext(), mAskPriceTypes, R.layout.simple_spinner_item) {
            @Override
            public void convert(ViewHolder viewHolder, String data, int position) {
                ((TextView) viewHolder.getConvertView()).setText(data);
            }
        };
        mAskTypeSpinner.setAdapter(askTypeAdapter);
        if (askDBModel == null || askDBModel.fdAddPrice.compareTo(BigDecimal.ZERO) >= 0) {
            currentAskPriceTypePosition = 0;
        } else {
            currentAskPriceTypePosition = 1;
        }
        mAskTypeSpinner.setSelection(currentAskPriceTypePosition);
        mAskEditorPriceTypeLabel.setText(mAskPriceTypes.get(currentAskPriceTypePosition));
        mAskTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                currentAskPriceTypePosition = i;
                mAskEditorPriceTypeLabel.setText(mAskPriceTypes.get(currentAskPriceTypePosition));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mAskEditorCancelBtn:
                dismissSelf();
                break;
            case R.id.mAskEditorConfirmBtn:
                /*if (mAskGpSpinner.getSelectedItemPosition() == 0) {
                    ToastUtil.showToast("请选择要求分类");
                    return;
                }*/

                String name = mAskEditorNameEdt.getText().toString().trim();
                String price = mAskEditorPriceEdt.getText().toString().trim();
                if (validate(name, price)) {
                    if(android.text.TextUtils.isEmpty(price)){
                        price = "0";//默认赋值0
                    }
                    BigDecimal askPrice = new BigDecimal(price);
                    if (currentAskPriceTypePosition == 1) {
                        askPrice = askPrice.multiply(BigDecimal.valueOf(-1));
                    }
                    if (isEditor()) {
                        update(name, askPrice);
                    } else {
                        save(name, askPrice);
                    }
                }
                break;
            default:
                break;
        }
    }

    private boolean validate(String name, String price) {
        if (!TextUtils.validate(name)) {
            ToastUtil.showToast("请输入要求名称");
            return false;
        } else if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("要求名称输入非法");
            return false;
        }/* else if (!TextUtils.validate(price)) {
            if (currentAskPriceTypePosition == 1) {
                ToastUtil.showToast("请输入减价");
            } else {
                ToastUtil.showToast("请输入加价");
            }
            return false;
        }*/
        return true;
    }

    private void update(String name, BigDecimal price) {
        AirAskGroupManagerInfo askgpDBModel = (AirAskGroupManagerInfo) mAskGpSpinner.getSelectedItem();

        ProgressManager.showProgress(getActivityWithinHost());
        mProcessor.updateAsk(askDBModel.fiId, name, price, askgpDBModel.fsAskGpId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onEditorSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "更新要求失败" : info);
                }
            }
        });
    }

    private void save(String name, BigDecimal price) {
        AirAskGroupManagerInfo askgpDBModel = (AirAskGroupManagerInfo) mAskGpSpinner.getSelectedItem();

        ProgressManager.showProgress(getActivityWithinHost());
        mProcessor.addAsk(name, price, askgpDBModel.fsAskGpId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onEditorSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "新增要求失败" : info);
                }
            }
        });
    }

    public void setParam(String askGpId, ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoWhisOutAllList, AskProcessor mProcessor) {
        setParam(askGpId, null, airAskGroupManagerInfoWhisOutAllList, mProcessor);
    }

    public void setParam(String askGpId, AirAskManageInfo askDBModel, ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoWhisOutAllList, AskProcessor mProcessor) {
        this.askGpId = askGpId;
        this.askDBModel = askDBModel;
        this.airAskGroupManagerInfoWhisOutAllList.clear();
        this.airAskGroupManagerInfoWhisOutAllList.addAll(airAskGroupManagerInfoWhisOutAllList);
        this.mProcessor = mProcessor;
        //buildChoiceHint();
    }

    /**
     * 构建一组请选择数据
     */
   /* public void buildChoiceHint() {
        AirAskGroupManagerInfo tempAirAsk = new AirAskGroupManagerInfo();
        tempAirAsk.fsAskGpId = "hint";
        tempAirAsk.fsAskGpName = "请选择";
        airAskGroupManagerInfoWhisOutAllList.add(0, tempAirAsk);
    }*/

    private boolean isEditor() {
        return askDBModel != null;
    }

    public interface OnAskEditorListener {
        void onEditorSuccess();
    }

    public void setOnAskEditorListener(OnAskEditorListener listener) {
        this.listener = listener;
    }
}
