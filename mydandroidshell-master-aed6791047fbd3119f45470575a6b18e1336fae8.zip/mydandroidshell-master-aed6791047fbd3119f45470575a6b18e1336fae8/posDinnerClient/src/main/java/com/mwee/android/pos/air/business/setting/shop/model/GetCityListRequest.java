package com.mwee.android.pos.air.business.setting.shop.model;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.cashier.connect.bean.http.BaseCashierPosRequest;

/**
 * @author changsunhaipeng
 * @Description: 获取城市列表接口 wiki: http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11641749
 * @Date: 2018/2/5
 */
@HttpParam(httpType = HttpType.POST,
        method = "setting/getMsyShopCityList",
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        response = GetCityListResponse.class)
public class GetCityListRequest extends BaseCashierPosRequest {
    public int provinceId;
}
