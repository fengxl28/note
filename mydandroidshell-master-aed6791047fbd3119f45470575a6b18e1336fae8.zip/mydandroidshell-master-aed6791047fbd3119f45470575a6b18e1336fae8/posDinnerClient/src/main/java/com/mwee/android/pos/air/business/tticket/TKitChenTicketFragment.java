package com.mwee.android.pos.air.business.tticket;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.mwee.android.pos.air.business.tprinter.TPrinterProcessor;
import com.mwee.android.pos.air.business.tshop.TShopProcessor;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.dinner.R;

/**
 * Created by zhangmin on 2017/9/28.
 */

public class TKitChenTicketFragment extends BaseFragment {

    private Switch swWhetherPrinter;

    private RadioGroup rgTicketCutWay;
    private RadioButton rbTicketAllMenu;//总单
    private RadioButton rbTicketAllOneMenu;//总单一菜一切
    private RadioButton rbTicketOneMenu;//一菜一切
    private RadioButton rbTicketOneCopies;//一份一切


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_ticket_kitchen_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        init();
    }

    private void assignViews(View containView) {

        rgTicketCutWay = (RadioGroup) containView.findViewById(R.id.rgTicketCutWay);

        rbTicketAllMenu = (RadioButton) containView.findViewById(R.id.rbTicketAllMenu);
        rbTicketAllOneMenu = (RadioButton) containView.findViewById(R.id.rbTicketAllOneMenu);
        rbTicketOneMenu = (RadioButton) containView.findViewById(R.id.rbTicketOneMenu);
        rbTicketOneCopies = (RadioButton) containView.findViewById(R.id.rbTicketOneCopies);


        swWhetherPrinter = (Switch) containView.findViewById(R.id.swWhetherPrinter);


    }


    private void init() {

        swWhetherPrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_KITCHEN_PRINTER, "1"), "1"));//默认打印


        TShopProcessor.queryTDeptModel(String.valueOf(2), new TResult<DeptDBModel>() {
            @Override
            public void callBack(DeptDBModel deptDBModel) {

                if (deptDBModel.fiIsOneItemCut == 2) {//总单
                    rbTicketAllMenu.setChecked(true);
                } else if (deptDBModel.fiIsOneItemCut == 3) {//总单一菜一切
                    rbTicketAllOneMenu.setChecked(true);
                } else if (deptDBModel.fiIsOneItemCut == 1) {//一菜一切
                    rbTicketOneMenu.setChecked(true);
                } else if (deptDBModel.fiIsOneItemCut == 4) {//一份一切
                    rbTicketOneCopies.setChecked(true);
                }
                registerEvent(deptDBModel);
            }
        });

    }


    private void registerEvent(final DeptDBModel deptDBModel) {

        rgTicketCutWay.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {

                if (checkedId == R.id.rbTicketAllMenu) {//总单
                    deptDBModel.fiIsOneItemCut = 2;
                } else if (checkedId == R.id.rbTicketAllOneMenu) {//总单一菜一切
                    deptDBModel.fiIsOneItemCut = 3;
                } else if (checkedId == R.id.rbTicketOneMenu) {//一菜一切
                    deptDBModel.fiIsOneItemCut = 1;
                } else if (checkedId == R.id.rbTicketOneCopies) {//一份一切
                    deptDBModel.fiIsOneItemCut = 4;
                }
                TPrinterProcessor.updateTDeptItemCut(deptDBModel.fiIsOneItemCut);

            }
        });
        swWhetherPrinter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ActionLog.addLog(ActionLog.TICKET_CONFIG, "点击了厨房制作单 是否打印");
                SettingProcessor.refreshSettingStatus(META.T_KITCHEN_PRINTER, isChecked ? "1" : "0");
            }
        });
    }


}
