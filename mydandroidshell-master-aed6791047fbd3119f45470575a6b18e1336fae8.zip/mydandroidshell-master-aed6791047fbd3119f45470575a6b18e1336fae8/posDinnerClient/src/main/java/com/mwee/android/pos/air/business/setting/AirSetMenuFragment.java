package com.mwee.android.pos.air.business.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.ask.manager.AskManagerActivity;
import com.mwee.android.pos.air.business.menu.MenuPackageManagerActivity;
import com.mwee.android.pos.air.business.menu.MenuManagerActivity;
import com.mwee.android.pos.air.business.ordermodel.ChangeOrderModelActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by zhangmin on 2017/12/13.
 */

public class AirSetMenuFragment extends BaseFragment implements IDriver, View.OnClickListener, CompoundButton.OnCheckedChangeListener{

    public static final String TAG = "setting";
    /*点菜管理*/
    private TextView tvMenuCheck;
    private TextView tvMenuPackage;
    private TextView tvMenuAsk;
    private TextView tvMenuMode;   //点菜模式


    /*餐厅设置*/
    private Switch swMenuMergeSet;
    private Switch swRapidAutoPaySet;
    private Switch swPrinterBillLocationSet;
    private Switch swRapidMenuAutoSet;
    private View restaurantLayout;


    @Override
    public String getModuleName() {
        return TAG;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_set_menu_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        DriverBus.registerDriver(this);
        assignViews(view);
        registerEvent();
        initData();
    }

    private void assignViews(View container) {

        /*点菜管理*/
        tvMenuCheck = (TextView) container.findViewById(R.id.tvMenuCheck);
        tvMenuPackage = (TextView) container.findViewById(R.id.tvMenuPackage);
        tvMenuAsk = (TextView) container.findViewById(R.id.tvMenuAsk);
        tvMenuMode = (TextView) container.findViewById(R.id.tvMenuMode);

        /*餐厅设置*/
        restaurantLayout = container.findViewById(R.id.restaurantLayout);
        swMenuMergeSet = (Switch) container.findViewById(R.id.swMenuMergeSet);//相同菜品合并
        swRapidAutoPaySet = (Switch) container.findViewById(R.id.swRapidAutoPaySet);//自动结账
        swPrinterBillLocationSet = (Switch) container.findViewById(R.id.swPrinterBillLocationSet);//美小二预结单打印
        swRapidMenuAutoSet = (Switch) container.findViewById(R.id.swRapidMenuAutoSet);//秒点自动下厨


    }


    private void registerEvent() {

        /*点菜设置*/
        tvMenuCheck.setOnClickListener(this);
        tvMenuPackage.setOnClickListener(this);
        tvMenuAsk.setOnClickListener(this);
        tvMenuMode.setOnClickListener(this);

        /*餐厅设置*/
        swMenuMergeSet.setOnCheckedChangeListener(this);
        swRapidAutoPaySet.setOnCheckedChangeListener(this);
        swPrinterBillLocationSet.setOnCheckedChangeListener(this);
        swRapidMenuAutoSet.setOnCheckedChangeListener(this);


    }


    private void initData() {

        if (ClientBindProcessor.isCurrentHostMain()) {
            swMenuMergeSet.setChecked(SettingHelper.isShouldMerge());
            swRapidAutoPaySet.setChecked(TextUtils.equals(SettingHelper.getDinnerSetting(DBPayConfig.AUTO_PAY, "0"), "1"));
            swPrinterBillLocationSet.setChecked(TextUtils.equals(SettingHelper.getDinnerSetting(DBPrintConfig.RAPID_PRINT_BILL, "1"), "1"));
            swRapidMenuAutoSet.setChecked(TextUtils.equals(SettingHelper.getDinnerSetting(DBOrderConfig.AUTOMATIC_ORDER, "0"), "1"));
        } else {
            restaurantLayout.setVisibility(View.GONE);
        }

    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            /*点菜管理*/
            case R.id.tvMenuCheck:
                ActionLog.addLog("小散设置界面->点击了点菜管理", "", "", ActionLog.SS_MORE_JOIN, "");
                startActivity(new Intent(getContext(), MenuManagerActivity.class));
                break;
            case R.id.tvMenuPackage:
                ActionLog.addLog("小散设置界面->点击了套餐管理", "", "", ActionLog.SS_MORE_JOIN, "");
                startActivity(new Intent(getContext(), MenuPackageManagerActivity.class));
                break;
            case R.id.tvMenuAsk:  //菜品要求
                ActionLog.addLog("小散设置界面->点击了菜品要求管理", "", "", ActionLog.SS_MORE_JOIN, "");
                startActivity(new Intent(getContext(), AskManagerActivity.class));
                break;
            case R.id.tvMenuMode:  //点菜模式
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    ToastUtil.showToast("点菜模式配置仅仅主机可以操作");
                    return;
                }
                ActionLog.addLog("小散设置界面->点击了点菜模式配置管理", "", "", ActionLog.SS_MORE_JOIN, "");
                startActivity(new Intent(getContext(), ChangeOrderModelActivity.class));
                break;

            default:
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        /*餐厅设置*/
        switch (buttonView.getId()) {
            case R.id.swMenuMergeSet:
                ActionLog.addLog("更多设置->点击了相同菜品是否合并", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBOrderConfig.MERGE_MENUITEM_EQUALS, isChecked ? "1" : "0");
                break;
            case R.id.swRapidAutoPaySet:
                ActionLog.addLog("更多设置->点击了秒付是否自动结账", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBPayConfig.AUTO_PAY, isChecked ? "1" : "0");
                break;
            case R.id.swPrinterBillLocationSet:
                ActionLog.addLog("更多设置->秒付结账单按区域打印", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBPrintConfig.RAPID_PRINT_BILL, isChecked ? "1" : "0");
                break;
            case R.id.swRapidMenuAutoSet:
                ActionLog.addLog("更多设置->秒点自动下厨", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBOrderConfig.AUTOMATIC_ORDER, isChecked ? "1" : "0");
                break;
            default:
                break;
        }
    }

    @DrivenMethod(uri = TAG + "/refreshDBConfig", UIThread = true)
    public void refreshDBConfig(String type, String value) {
        switch (type) {
            case DBOrderConfig.MERGE_MENUITEM_EQUALS:    //相同菜品合并为一笔
                if (swMenuMergeSet != null) {
                    swMenuMergeSet.setChecked(TextUtils.equals(value, "1"));
                }
                break;

            case DBPayConfig.AUTO_PAY:   //自动结账
                if (swRapidAutoPaySet != null) {
                    swRapidAutoPaySet.setChecked(TextUtils.equals(value, "1"));
                }
                break;
            case DBPrintConfig.RAPID_PRINT_BILL:   //秒付结账单按区域打印
                if (swPrinterBillLocationSet != null) {
                    swPrinterBillLocationSet.setChecked(TextUtils.equals(value, "1"));
                }
                break;
            case DBOrderConfig.AUTOMATIC_ORDER:   //秒点自动下厨
                if (swRapidMenuAutoSet != null) {
                    swRapidMenuAutoSet.setChecked(TextUtils.equals(value, "1"));
                }
                break;
            default:
                break;

        }
    }
}
