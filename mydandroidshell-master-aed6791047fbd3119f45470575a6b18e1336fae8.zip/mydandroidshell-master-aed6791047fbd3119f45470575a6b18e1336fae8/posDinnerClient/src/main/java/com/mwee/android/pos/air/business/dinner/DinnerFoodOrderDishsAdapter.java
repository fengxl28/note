package com.mwee.android.pos.air.business.dinner;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DisplayUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 点菜界面数据适配器
 * Created by zhangmin on 2017/4/27.
 */

public class DinnerFoodOrderDishsAdapter extends BaseAdapter {

    private DishCache dishCache;//点菜cache
    private Context mContext;
    private Host mHost;
    private OnDinnerFoodOrderItemClickListener listener;
    public int selectPosition = 0;
    public ArrayList<MenuItem> modules = new ArrayList<>();
    private int dp10;
    private int dp5;

    public DinnerFoodOrderDishsAdapter(Host mHost, DishCache dishCache) {
        this.dishCache = dishCache;
        if (dishCache.order != null && !ListUtil.isEmpty(dishCache.order.originMenuList)) {
            modules.addAll(dishCache.order.originMenuList);
        }
        if (!ListUtil.isEmpty(dishCache.orderDishesCache.tempSelectedMenuList)) {
            modules.addAll(0, dishCache.orderDishesCache.tempSelectedMenuList);
        }
        this.mContext = mHost.getContextWithinHost();
        this.mHost = mHost;
        dp10 = DisplayUtil.dp2px(mContext, 10);
        dp5 = DisplayUtil.dp2px(mContext, 5);
    }

    /**
     * 更新ui
     *
     * @param dishCache
     */
    public void notifyDataChanged(DishCache dishCache) {
        this.dishCache = dishCache;
        modules.clear();
        if (dishCache.order != null && !ListUtil.isEmpty(dishCache.order.originMenuList)) {
            modules.addAll(dishCache.order.originMenuList);
        }
        if (!ListUtil.isEmpty(dishCache.orderDishesCache.tempSelectedMenuList)) {
            modules.addAll(0, dishCache.orderDishesCache.tempSelectedMenuList);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return modules.size();
    }

    @Override
    public MenuItem getItem(int position) {
        return modules.size() == 0 ? null : modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.air_dinner_food_order_dishes_item, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.bindData(position);
        return convertView;
    }

    class ViewHolder implements View.OnClickListener {
        private View itemView;
        private View ingredient_line;
        private MenuItem menuItem;
        private LinearLayout mDinnerOrderItemInfoLayout;//点菜基本信息layout
        // private ImageView mDinnerOrderItemStatusImg;//订单状态
        private TextView mDinnerOrderItemNameLabel;//菜品名称
        private TextView mDinnerOrderItemNoteContentLabel;//备注
        //private TextView mDinnerOrderItemUsernameLabel;//操作人
        //private TextView mDinnerOrderItemCreateTimeLabel;//创建时间
        //private TextView mDinnerOrderItemReminderCountLabel;//催菜次数
        //private TextView mDinnerOrderItemTheDishesLabel;//起菜
        private TextView mDinnerOrderItemNumLabel;//点菜份数
        private TextView mDinnerOrderItemNumHintLabel;//沽清数量
        private TextView mDinnerOrderItemPriceLabel;//菜品金额

        private TextView mDinnerOrderItemTagDiscountLabel;//折扣icon
        private ImageView mDinnerOrderItemTagGiftImg;//赠送icon
        private ImageView mDinnerOrderItemTagMemberImg;//会员价icon

        private TextView mDinnerOrderItemDeleteOrReturnLabel;//删除icon
        private UnScollerListView mDinnerOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mDinnerOrderItemPackageLsv;//套餐明细列表
      /*  private LinearLayout mDinnerOrderItemManagerLayout;//菜品管理布局
        private TextView mDinnerOrderItemNoteLabel;//菜品要求
        private TextView mDinnerOrderItemDoWaitLabel;//菜品等叫
        private TextView mDinnerOrderItemEditLabel;//菜品编辑
        private TextView mDinnerOrderItemHurryLabel;//菜品催菜
        private TextView mDinnerOrderItemTurnLabel;//菜品转菜*/
        //private TextView mDinnerOrderItemDiscountLabel;//菜品优惠折扣
        //private TextView mDinnerOrderItemWaitLabel;//新菜等叫标签


        public ViewHolder(View v) {
            itemView = v;
            mDinnerOrderItemInfoLayout = (LinearLayout) v.findViewById(R.id.mDinnerOrderItemInfoLayout);
            //mDinnerOrderItemStatusImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemStatusImg);
            mDinnerOrderItemNameLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNameLabel);
            mDinnerOrderItemNoteContentLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNoteContentLabel);
            //mDinnerOrderItemUsernameLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemUsernameLabel);
            //mDinnerOrderItemCreateTimeLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemCreateTimeLabel);
            //mDinnerOrderItemReminderCountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemReminderCountLabel);
            // mDinnerOrderItemTheDishesLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTheDishesLabel);
            mDinnerOrderItemNumLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNumLabel);
            mDinnerOrderItemNumHintLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNumHintLabel);
            mDinnerOrderItemPriceLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemPriceLabel);

            mDinnerOrderItemTagDiscountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTagDiscountLabel);
            mDinnerOrderItemTagGiftImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemTagGiftImg);
            mDinnerOrderItemTagMemberImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemTagMemberImg);

            mDinnerOrderItemDeleteOrReturnLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDeleteOrReturnLabel);
            mDinnerOrderItemIngredientLsv = (UnScollerListView) v.findViewById(R.id.mDinnerOrderItemIngredientLsv);
            mDinnerOrderItemPackageLsv = (CompatibleListView) v.findViewById(R.id.mDinnerOrderItemPackageLsv);
            ingredient_line = v.findViewById(R.id.ingredient_line);
         /*   mDinnerOrderItemManagerLayout = (LinearLayout) v.findViewById(R.id.mDinnerOrderItemManagerLayout);
            mDinnerOrderItemNoteLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNoteLabel);
            mDinnerOrderItemDoWaitLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDoWaitLabel);
            mDinnerOrderItemEditLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemEditLabel);
            mDinnerOrderItemWaitLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemWaitLabel);
            mDinnerOrderItemHurryLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemHurryLabel);
            mDinnerOrderItemTurnLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTurnLabel);
            mDinnerOrderItemDiscountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDiscountLabel);*/
            mDinnerOrderItemDeleteOrReturnLabel.setOnClickListener(this);
            mDinnerOrderItemInfoLayout.setOnClickListener(this);
            mDinnerOrderItemNameLabel.setOnClickListener(this);
          /*  mDinnerOrderItemEditLabel.setOnClickListener(this);*/
        }

        /**
         * ui处理
         *
         * @param position
         */
        public void bindData(int position) {
            menuItem = modules.get(position);
            removeAllLine();
            mDinnerOrderItemNameLabel.setText(menuItem.name);
            mDinnerOrderItemNameLabel.setBackgroundResource(0);
            mDinnerOrderItemNameLabel.setPadding(0, 0, 0, 0);
            //设置备注显示
            String note = getMenuItemNoteContent().trim();
            if (TextUtils.isEmpty(note)) {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mDinnerOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint)
                ;
            } else {
                mDinnerOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }

            //时价菜 价格加样式
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid()) {
                mDinnerOrderItemPriceLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mDinnerOrderItemPriceLabel.setText("时价");
                mDinnerOrderItemPriceLabel.setOnClickListener(this);
            } else {
                mDinnerOrderItemPriceLabel.setBackgroundResource(0);
                mDinnerOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                mDinnerOrderItemPriceLabel.setOnClickListener(null);
            }

            //优惠信息tag
            mDinnerOrderItemTagGiftImg.setVisibility(View.GONE);
            mDinnerOrderItemTagDiscountLabel.setVisibility(View.GONE);
            mDinnerOrderItemTagMemberImg.setVisibility(View.GONE);
            if (menuItem.menuBiz.menuSellType == MenuSellType.GIFT || (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && menuItem.menuBiz.giftNum.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum)) == 0)) {
                mDinnerOrderItemTagGiftImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.useMemberPrice) {
                mDinnerOrderItemTagMemberImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.menuBiz.selectDiscount != null) {
                mDinnerOrderItemTagDiscountLabel.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - menuItem.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    mDinnerOrderItemTagDiscountLabel.setText(rate0.toString() + "折");
                } else {
                    mDinnerOrderItemTagDiscountLabel.setText(rate.toString() + "折");
                }
            }

            //配料菜列表展示
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                ingredient_line.setVisibility(View.VISIBLE);
                mDinnerOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<MenuItem> ingredientAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<MenuItem>(mContext, menuItem.menuBiz.selectedModifier, R.layout.message_order_menu_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem item, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.msg_order_item_name);
                            name.setTextColor(context.getResources().getColor(R.color.line_gray));
                            name.setText(item.name);

                            TextView count = (TextView) viewHolder.getView(R.id.msg_order_item_note);
                            count.setTextColor(context.getResources().getColor(R.color.line_gray));

                            TextView price = (TextView) viewHolder.getView(R.id.msg_order_item_num);
                            price.setTextColor(context.getResources().getColor(R.color.line_gray));

                            String voidInfo = "";

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }

                            BigDecimal voidNum = item.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(item.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum + "]";
                            }
                            BigDecimal buyAllNum = item.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString() + voidInfo);
                            } else {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString());
                            }
                            price.setText(Calc.formatShow(item.menuBiz.totalPrice.multiply(tempBuyNum.subtract(tempVoidNum)), RoundConfig.ROUND_SINGLE_PRICE));
                        }
                    };
                    mDinnerOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(menuItem.menuBiz.selectedModifier);
                }
            } else {
                ingredient_line.setVisibility(View.GONE);
                mDinnerOrderItemIngredientLsv.setVisibility(View.GONE);
            }

            //套餐明细显示
            if (menuItem.supportPackage()) {
                mDinnerOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(mContext, allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name) + getMenuItemNoteContent(data));
                            viewHolder.setText(R.id.numTv, TextUtils.concat(data.menuBiz.buyNum.toPlainString(), "份"));
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                          /*  if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mDinnerOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mDinnerOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //根据下单状态控制ui显示
            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                //已点单
               /* mDinnerOrderItemWaitLabel.setVisibility(View.GONE);//等叫标示隐藏
                mDinnerOrderItemUsernameLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemReminderCountLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemUsernameLabel.setText(getWaiterName());
                mDinnerOrderItemCreateTimeLabel.setText(getOrderTime());*/
                //等叫状态显示
                if (menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT && !menuItem.hasAllVoid()) {
//                    mDinnerOrderItemCreateTimeLabel.setVisibility(View.GONE);
//                    mDinnerOrderItemUsernameLabel.setVisibility(View.GONE);
//                    mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_wait);
//                    mDinnerOrderItemTheDishesLabel.setVisibility(View.VISIBLE);//等叫按钮显示
//                    mDinnerOrderItemTheDishesLabel.setOnClickListener(this);

                    //隐藏退菜按钮
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);

                  /*  mDinnerOrderItemHurryLabel.setVisibility(View.GONE);*/
                } else {
                  /*  mDinnerOrderItemCreateTimeLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemUsernameLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_ordered);
                    mDinnerOrderItemTheDishesLabel.setVisibility(View.GONE);
                    mDinnerOrderItemTheDishesLabel.setOnClickListener(null);
                    mDinnerOrderItemHurryLabel.setVisibility(View.VISIBLE);*/
                }

                //催菜数据ui展示
              /*  if (menuItem.menuBiz.fiHurryTimes > 0) {
                    mDinnerOrderItemReminderCountLabel.setText("催" + menuItem.menuBiz.fiHurryTimes + "次");
                } else {
                    mDinnerOrderItemReminderCountLabel.setVisibility(View.GONE);
                }
*/
                //称重菜未称重 数量加样式
                if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                    mDinnerOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mDinnerOrderItemNumLabel.setOnClickListener(this);
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                } else {
                    mDinnerOrderItemNumLabel.setOnClickListener(null);
                    mDinnerOrderItemNumLabel.setBackgroundResource(0);
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                //退菜数据展示
                if (menuItem.hasAllVoid()) {
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                    addAllLine();
                } else {
                    mDinnerOrderItemDeleteOrReturnLabel.setText("退");
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
                } else {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.GONE);
                }

                //单个菜品操作控制
              /*  mDinnerOrderItemNoteLabel.setVisibility(View.GONE);
                mDinnerOrderItemDoWaitLabel.setVisibility(View.GONE);
                if (dishCache.antiPay) {//反结帐不可催菜，转菜
                    mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                    mDinnerOrderItemTurnLabel.setVisibility(View.GONE);
                } else {
                    if (!(menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT && !menuItem.hasAllVoid())) {
                        mDinnerOrderItemHurryLabel.setVisibility(View.VISIBLE);
                        mDinnerOrderItemHurryLabel.setOnClickListener(this);
                    }
                    mDinnerOrderItemTurnLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemTurnLabel.setOnClickListener(this);
                }
                mDinnerOrderItemDiscountLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemDiscountLabel.setOnClickListener(this);*/

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_EAEAEA));
            } else {
                //显示删除按钮
                mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemDeleteOrReturnLabel.setText("删");
                //新菜
              /*  mDinnerOrderItemUsernameLabel.setVisibility(View.GONE);
                mDinnerOrderItemCreateTimeLabel.setVisibility(View.GONE);
                mDinnerOrderItemReminderCountLabel.setVisibility(View.GONE);
                mDinnerOrderItemTheDishesLabel.setVisibility(View.GONE);//等叫按钮隐藏
                mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_new);*/
                //等叫状态显示
              /*  if (menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT) {
                    mDinnerOrderItemWaitLabel.setVisibility(View.VISIBLE);
                } else {
                    mDinnerOrderItemWaitLabel.setVisibility(View.GONE);
                }*/
                mDinnerOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mDinnerOrderItemNumLabel.setOnClickListener(this);

                //沽清数量显示
                BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(menuItem.currentUnit.fiOrderUintCd);
                if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemNumHintLabel.setText(String.format(Locale.SIMPLIFIED_CHINESE, "剩%s", sellOutCount+menuItem.currentUnit.fsOrderUint));
                } else {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.GONE);
                }
//时价菜可以修改菜品名称
                if (menuItem.supportTimes()) {
                    mDinnerOrderItemNameLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mDinnerOrderItemNameLabel.setPadding(dp10, dp5, dp10, dp5);
                }
                //菜品操作菜单事件监听
               /* mDinnerOrderItemDoWaitLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                mDinnerOrderItemTurnLabel.setVisibility(View.GONE);
                mDinnerOrderItemDiscountLabel.setVisibility(View.GONE);
                mDinnerOrderItemDoWaitLabel.setOnClickListener(this);//设置等叫操作监听
                mDinnerOrderItemNoteLabel.setOnClickListener(this);
*/
                //控制背景
                //itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.white));
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_f9f9f9));
            }

            //选中状态处理
            if (selectPosition == position && !menuItem.hasAllVoid()) {
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_FFD2CB));
            /*    mDinnerOrderItemManagerLayout.setVisibility(View.VISIBLE);
                if (isShowEditItem()) {
                    mDinnerOrderItemEditLabel.setVisibility(View.VISIBLE);
                } else {
                    mDinnerOrderItemEditLabel.setVisibility(View.GONE);
                }*/
            } else {
               /* mDinnerOrderItemManagerLayout.setVisibility(View.GONE);*/
            }
        }

        /**
         * 获取操作人名称
         *
         * @return
         */
      /*  private String getWaiterName() {
            OrderSeqModel seqModel = dishCache.order.optSeqModel(menuItem.menuBiz.orderSeqID);
            String waiterName = "";
            if (seqModel != null) {
                waiterName = seqModel.createWaiterName;
            }
            return waiterName;
        }*/
        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (v.getId()) {
                case R.id.mDinnerOrderItemNumLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vQtyAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    ActionLog.addLog("点菜页->点击已下单菜品修改数量" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                                    listener.doChangeOrderedMenuNumber(menuItem, userDBModel);
                                } else {
                                    ActionLog.addLog("点菜页->点击未下单菜品修改数量" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                                    listener.doChangeMenuBuyNum(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemPriceLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品改价格" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_PRICE, "");
                                listener.doChangeMenuPrice(menuItem, userDBModel);
                            }
                        }
                    });
                    break;

                case R.id.mDinnerOrderItemDeleteOrReturnLabel:
                    if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        PermissionsUtil.requestPermissionBackMenu(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, menuItem, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    ActionLog.addLog("点菜页->点击菜品退菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_RETREAT, "");
                                    listener.doRetreatDish(menuItem, userDBModel, msg);
                                }
                            }
                        });
                    } else {
                        ActionLog.addLog("点菜页->点击菜品删除" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_REMOVE, "");
                        listener.doDeleteMenu(menuItem);
                    }
                    break;

               /* case R.id.mDinnerOrderItemTheDishesLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnUpItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品起菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_THE_DISHES, "");
                                listener.doWaitCallUp(menuItem, userDBModel);
                            }
                        }
                    });
                    break;

                case R.id.mDinnerOrderItemDoWaitLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnWaitItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                //等叫处理
                                ActionLog.addLog("点菜页->点击菜品等叫" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_WAIT, "");
                                menuItem.menuBiz.fiItemMakeState = Constants.MAKE_STATE_WAIT;
                                notifyDataSetChanged();
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemNoteLabel:
                    ActionLog.addLog("点菜页->点击菜品要求" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_REQUEST, "");
                    listener.doEditorMenuNoteContent(menuItem);
                    break;
                case R.id.mDinnerOrderItemEditLabel:
                    ActionLog.addLog("点菜页->点击菜品编辑" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_EDITOR, "");
                    doHandlerMenuEdit();
                    break;*/

                /*case R.id.mDinnerOrderItemHurryLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnHurryItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品催菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_HURRY, "");
                                listener.doRemindersDish(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemTurnLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vTurnAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品转菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_TURN, "");
                                listener.doTurnDish(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemDiscountLabel:
                    ActionLog.addLog("点菜页->点击菜品优惠折扣" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_DISCOUNT, "");
                    listener.doChangeMenuPrivilege(menuItem);
                    break;*/
                case R.id.mDinnerOrderItemNameLabel:

                    if (menuItem.supportTimes() && (dishCache.order == null || !dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID))) {
                        PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    ActionLog.addLog("点菜页->点击菜品改名称" + menuItem.toString(), ActionLog.DF_MENU_NAME);
                                    listener.doChangeMenuName(menuItem, userDBModel);
                                }
                            }
                        });
                        break;
                    }
                default:
                    selectPosition = modules.indexOf(menuItem);
                    notifyDataSetChanged();
                    break;
            }
        }


        /**
         * 是否显示菜品编辑按钮
         *
         * @return
         */
   /*     public boolean isShowEditItem() {
            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                return menuItem.supportIngredient();
            } else {
                return ((menuItem.config & 2) == 2  //多规格
                        || ((menuItem.config & 1) == 1 && (menuItem.config & 4) == 4) //多做法
                        || (menuItem.config & 1024) == 1024) //有配料
                        || menuItem.supportPackage();
            }
        }
*/

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
            /*if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
            return demand.toString();
        }

        /**
         * 获取下单时间
         *
         * @return
         */
    /*    public String getOrderTime() {
            try {
                StringBuilder statusStr = new StringBuilder();
                long time = DateTimeUtil.getMMBetween(menuItem.menuBiz.createTime, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (time <= 0) {
                    time = 1;
                }
                if (time > 60) {
                    statusStr.append("  ").append("1小时＋");
                } else {
                    statusStr.append("  ").append(time).append("分钟");
                }
                return statusStr.toString();
            } catch (ParseException e) {
                return "1分钟";
            }
        }*/

        /**
         * 处理菜品编辑操作
         */
     /*   private void doHandlerMenuEdit() {
            if (menuItem.supportPackage()) { //套餐
                OrderDishesBizUtil.processPackage((Host) mContext, menuItem, dishCache.isBindMember(), new IResponse<MenuItem>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, MenuItem info) {
                        if (result) {
                            info.calcTotal(dishCache.isBindMember());
                            listener.onPackageMenuChanged(info);
                            notifyDataSetChanged();
                        } else {
                            ToastUtil.showToast(msg);
                        }
                    }
                });
            } else {  //配料菜-多规格-多做法
                if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                    //                    已下单的配料菜修改
                    if (dishCache.order != null) {
                        //允许退菜菜品 0： 不限 1： 指定
                        editIngredient(menuItem);
                    }
                } else {
                    final UnitModel oldUnit = menuItem.currentUnit;
                    final BigDecimal oldBuyNum = menuItem.menuBiz.buyNum;
                    OrderDishesBizUtil.processIngredient((Host) mContext, menuItem, new IResponse<MenuItem>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, MenuItem info) {
                            if (result) {
                                listener.doEditMenuInfo(oldUnit, oldBuyNum, info);
                            } else {
                                ToastUtil.showToast(msg);
                            }
                        }
                    }, dishCache.isBindMember());
                }

            }
        }*/

        /**
         * 编辑配料
         *
         * @param menuItem
         */
       /* private void editIngredient(final MenuItem menuItem) {
            MenuItem itemClone = menuItem.clone();
            OrderDishesBizUtil.processIngredient((Host) mContext, itemClone, true, new IResponse<MenuItem>() {
                @Override
                public void callBack(boolean result, int code, String msg, MenuItem info) {
                    listener.doChangeIngredient(menuItem, info);
                }
            }, dishCache.order.isMember);
        }*/

        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNoteContentLabel);
            //com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemUsernameLabel);
            //com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemCreateTimeLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNoteContentLabel);
            //com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemUsernameLabel);
            //com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemCreateTimeLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemPriceLabel);
        }
    }


    /**
     * 菜品列表操作回调接口
     */
    public interface OnDinnerFoodOrderItemClickListener {
        /**
         * 未下单菜品->修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel);


        /**
         * 已下单菜品—>修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel);

        /**
         * 删除菜品
         *
         * @param item
         */
        void doDeleteMenu(MenuItem item);


        /**
         * 已下单菜品—>退菜
         *
         * @param item
         * @param userDBModel
         * @param msg
         */
        void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg);

        /**
         * 修改时价菜价格
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuPrice(MenuItem item, UserDBModel userDBModel);

        /**
         * 时价修改价格
         *
         * @param menuItem
         * @param userDBModel
         */
        void doChangeMenuName(MenuItem menuItem, UserDBModel userDBModel);
        /**
         * 修改菜品要求
         *
         * @param item
         */
        //void doEditorMenuNoteContent(MenuItem item);

        /**
         * 修改菜品折扣
         *
         * @param item
         */
        //void doChangeMenuPrivilege(MenuItem item);

        /**
         * 未下单菜品->编辑
         *
         * @param oldUnit
         * @param oldBuyNum
         * @param item
         */
        //void doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item);


        /**
         * 已下单菜品—>催菜
         *
         * @param item
         * @param userDBModel
         */
        //void doRemindersDish(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>转菜
         *
         * @param item
         * @param userDBModel
         */
        //void doTurnDish(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单等叫菜品—>起菜
         *
         * @param item
         * @param userDBModel
         */
        //void doWaitCallUp(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>菜品编辑
         *
         * @param menuItem
         * @param info
         */
        //void doChangeIngredient(MenuItem menuItem, MenuItem info);


        /**
         * 套餐信息改变
         *
         * @param menuItem
         */
        //void onPackageMenuChanged(MenuItem menuItem);
    }

    public void setOnDinnerFoodOrderItemClickListener(OnDinnerFoodOrderItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
