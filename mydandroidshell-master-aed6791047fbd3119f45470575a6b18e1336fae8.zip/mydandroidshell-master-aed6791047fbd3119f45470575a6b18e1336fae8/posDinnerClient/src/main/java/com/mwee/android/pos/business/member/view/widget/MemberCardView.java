package com.mwee.android.pos.business.member.view.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.dinner.R;

/**
 * 会员卡视图---会员重构对接
 */
public class MemberCardView extends RelativeLayout {

    private NewMemberCardListItemModel mMember;
    private TextView tv_member_super;
    private TextView tv_member_level_name;
    private TextView tv_member_level;
    private TextView tv_member_card_no;
    private ImageView iv_member_card_default_flag;
    private TextView tv_member_left_money;
    private TextView tv_member_score;

    public MemberCardView(Context context) {
        super(context);
        initView(context);
    }


    public MemberCardView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public MemberCardView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }


    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.view_member_card, this);
        tv_member_super = findViewById(R.id.tv_member_super);
        tv_member_level_name = findViewById(R.id.tv_member_level_name);
        tv_member_level = findViewById(R.id.tv_member_level);
        tv_member_level.setVisibility(GONE);
        tv_member_card_no = findViewById(R.id.tv_member_card_no);
        iv_member_card_default_flag = findViewById(R.id.iv_member_card_default_flag);
        tv_member_left_money = findViewById(R.id.tv_member_left_money);
        tv_member_score = findViewById(R.id.tv_member_score);

        refreshView();
    }

    public void setMember(NewMemberCardListItemModel member) {
        this.mMember = member;
        refreshView();
    }

    private void refreshView() {
        if (mMember == null) {
            return;
        }
        // 卡类型,0 品牌卡；1 区域卡
        if (mMember.bindType == 1) {
            tv_member_level_name.setText(mMember.csName);
        } else {
            tv_member_level_name.setText(mMember.levelName);
        }
        tv_member_level.setText("v" + mMember.level);
        tv_member_card_no.setText("No. " + mMember.cardNo);
        tv_member_left_money.setText(mMember.storeAmount.toPlainString());
        tv_member_score.setText("" + mMember.score);
        if (mMember.plusCard) { // 是黑卡
            tv_member_super.setVisibility(View.VISIBLE);
            tv_member_super.setText(mMember.plusName);
        } else {
            tv_member_super.setVisibility(View.INVISIBLE);
        }
        // 默认卡
        iv_member_card_default_flag.setVisibility(mMember.isDefault == 1 ? VISIBLE : GONE);
    }
}
