package com.mwee.android.pos.business.member.biz;


import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.member.constant.MemberRechargeOrderStatus;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.Coupon;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageResponse;
import com.mwee.android.pos.component.member.net.QueryNewMemberChargeResultResponse;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.CheckCardTypeResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.business.setting.GetConfigArrayResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CSetting;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 会员相关业务逻辑处理
 * Created by qinwei on 2017/2/20.
 */

public class MemberProcess implements IMemberProcess {

    @Override
    public void onlyLoadMemberInfo(String number, IResponse<QueryMemberInfoResponse> callback) {
        MemberApi.onlyQuaryMemberInfo(number, callback);
    }

    @Override
    public void loadMemberInfoAndBindToOrder(String number, String orderId, boolean isUsedMemberPrice, IResponse<QueryMemberInfoAndBindToOrderResponse> callback) {
        MemberApi.queryAndBindMemberToOrder(number, orderId, isUsedMemberPrice, callback);
    }

    @Override
    public void loadMemberInfoAndBindToOrder(String number, String code, String orderId, boolean isUsedMemberPrice, IResponse<QueryMemberInfoAndBindToOrderResponse> callback) {
        MemberApi.queryAndBindMemberToOrder(number, code, orderId, isUsedMemberPrice, callback);
    }

    @Override
    public void loadMemberBalanceChangeData(String card_no, String last_id, int limit, final ResultCallback<BalanceOrderList> callback) {
        MemberApi.loadMemberBalanceChangedData(card_no, last_id, limit, response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }

    @Override
    public void loadMemberCoupons(String card_no, int page, int pageSize, final ResultCallback<ArrayList<Coupon>> callback) {
        MemberApi.loadMemberCoupons(card_no, page, pageSize, new SocketCallback<MemberCouponResponse>() {
            @Override
            public void callback(SocketResponse<MemberCouponResponse> response) {
                if (response == null) {
                    return;
                }
                if (response.success()) {
                    MemberCouponResponse memberCouponResponse = response.data;
                    Coupon[] objs = new Coupon[memberCouponResponse.data.list.size()];
                    objs = memberCouponResponse.data.list.toArray(objs);
                    Arrays.sort(objs, new Comparator<Coupon>() {
                        @Override
                        public int compare(Coupon o1, Coupon o2) {
                            return o1.c_type.compareTo(o2.c_type);
                        }
                    });
                    ArrayList<Coupon> coupons = new ArrayList<>(Arrays.asList(objs));
                    callback.onSuccess(coupons);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    @Override
    public void loadMemberRechargePackages(String csID, final ResultCallback<ArrayList<MemberRechargePackageModel>> callback) {
        MemberApi.loadMemberRechargePackage(csID, new SocketCallback<GetMemberRechargePackageResponse>() {
            @Override
            public void callback(SocketResponse<GetMemberRechargePackageResponse> response) {
                if (response == null) {
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.data.data.rule_list);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    @Override
    public void loadCashRechargeRequest(int ruleID, BigDecimal amount, String pay_code, String cardNo, final ResultCallback<QueryNewMembeChargeResultModel> callback) {
        MemberApi.sendCashRechargeRequestV2(ruleID, amount, pay_code, cardNo, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof QueryNewMemberChargeResultResponse) {
                    QueryNewMemberChargeResultResponse queryNewMemberChargeResultResponse = (QueryNewMemberChargeResultResponse) responseData.responseBean;
                    QueryNewMembeChargeResultModel data = queryNewMemberChargeResultResponse.data;
                    if (data != null && !android.text.TextUtils.isEmpty(data.trade_no)) {
                        callback.onSuccess(data);
                    } else {
                        callback.onSuccess(null);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData != null && !android.text.TextUtils.isEmpty(responseData.resultMessage)) {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
                return false;
            }
        });
    }

    @Override
    public void loadMemberRechargeOrderRequest(String tradeNo, final ResultCallback<MemberRechargeOrderModel> callback) {
        MemberApi.loadMemberRechargeOrder(tradeNo, new SocketCallback<MemberRechargeOrderModel>() {
            @Override
            public void callback(SocketResponse<MemberRechargeOrderModel> response) {
                if (response != null && response.success()) {
                    MemberRechargeOrderModel data = response.data;
                    if (data != null && StringUtil.toInt(data.status) == MemberRechargeOrderStatus.FINISH_TRANSACTION) {
                        callback.onSuccess(data);
                    } else {
                        callback.onFailure(response.code, response.message);
                    }
                } else {
                    if (response == null || android.text.TextUtils.isEmpty(response.message)) {
                        callback.onFailure(-1, "请手动刷新储值页面");
                    } else {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }
        });
    }

    @Override
    public void loadOnlineRechargeRequest(int ruleID, BigDecimal amount, String pay_code, int payType, String micro, String cardNo, final ResultCallback<QueryNewMembeChargeResultModel> callback) {
        MemberApi.sendOnlineRechargeRequestV2(ruleID, amount, pay_code, payType, micro, cardNo, callback);
    }

    @Override
    public void queryOnlineRechargeRequest(String tradeNo, final ResultCallback<QueryNewMembeChargeResultModel> callback) {
        MemberApi.queryOnlineRechargeRequest(tradeNo, callback);
    }

    @Override
    public void loadSendMobileCode(String mobile, final ResultCallback<ResponseData> callback) {
        MemberApi.loadSendMobileCode(mobile, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                callback.onSuccess(responseData);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    @Override
    public void loadShopMemberConfig(final ResultCallback<MemberConfig> callback) {
        MemberApi.loadMemberConfig(response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }

    @Deprecated
    @Override
    public void thirdMemberBind(String thirdNumber, String mwNumber, IResult iResult) {
        if (TextUtils.checkIsPhoneNumber(mwNumber)) {
            com.mwee.android.pos.air.business.member.api.MemberApi.loadMemberAdd("1", mwNumber, "", 0, null, 1, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    MemberApi.thirdMemberBind(thirdNumber, mwNumber, iResult);
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    MemberApi.thirdMemberBind(thirdNumber, mwNumber, iResult);
                    return false;
                }
            });
        } else {
            MemberApi.thirdMemberBind(thirdNumber, mwNumber, iResult);
        }
    }

    /**
     * 绑卡---支持第三方卡，绑卡前先做会员注册功能
     *
     * @param cardType         卡类型 0：虚拟卡； 1：手机号激活； 2：不记名激活
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @param nameValue        姓名
     * @param sex              性别
     * @param birthdayValue    生日
     */
    public void bindMembercard(String cardType, String cardNumber, String phone,
                               String verificationCode, String nameValue,
                               int sex, String birthdayValue, IResult iResult) {
        if (TextUtils.checkIsPhoneNumber(phone)) {
            com.mwee.android.pos.air.business.member.api.MemberApi.loadMemberAdd(TextUtils.validate(nameValue) ? nameValue : "1", phone, birthdayValue, sex, null, 1, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    MemberApi.memberBindCard(cardType, cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, iResult);
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    MemberApi.memberBindCard(cardType, cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, iResult);
                    return false;
                }
            });
        } else {
            MemberApi.memberBindCard(cardType, cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, iResult);
        }
    }

    /**
     * 检查卡类型
     *
     * @param cardNumber 卡号
     */
    public void checkCardType(String cardNumber, IResponse<CheckCardTypeResponse> iResult) {
        MCon.c(COrder.class, new SocketCallback<CheckCardTypeResponse>() {
            @Override
            public void callback(SocketResponse<CheckCardTypeResponse> response) {
                if (response != null && response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, 0, "", response.data);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, (response != null && TextUtils.validate(response.message)) ? response.message : "查询失败，请重试", null);
                    }
                }
            }
        }).checkCardType(cardNumber);
    }

    /**
     * 激活不记名卡
     *
     * @param cardNumber 卡号
     */
    public void activeNoNameCard(String cardNumber, IResult iResult) {
        MCon.c(COrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null && response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, "开卡成功");
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, (response != null && TextUtils.validate(response.message)) ? response.message : "激活失败，请重试");
                    }
                }
            }
        }).activeNoNameCard(cardNumber);
    }

    /**
     * 得到配置
     *
     * @param fileName
     */
    @Deprecated
    public static void bindCardShopConfigArray(String fileName, SocketCallback<GetConfigArrayResponse> socketCallback) {
        MCon.c(CSetting.class, socketCallback).bindCardShopConfigArray(fileName);
    }

    // ------------------- 以下为会员重构

    /**
     * 查询会员卡信息，不带验证码---会员重构版本
     *
     * @param account  手机号/会员卡号
     * @param callback
     */
    @Override
    public void optMemberInfoWithoutVerify(String account, ResultCallback<NewQueryMemberListResponse> callback) {
        optMemberInfo(account, "", 0, callback);
    }

    /**
     * 查询会员卡信息，不带验证码，并绑定到订单---会员重构版本
     *
     * @param account  手机号/会员卡号
     * @param orderId  订单号
     * @param callback
     */
    @Override
    public void optMemberInfoWithoutVerifyAndBindToOrder(String account, String orderId, ResultCallback<NewQueryMemberListResponse> callback) {
        optMemberInfoAndBindToOrder(account, "", 0, orderId, callback);
    }

    /**
     * 查询会员卡信息，带验证码---会员重构版本
     *
     * @param account        手机号/会员卡号
     * @param verifyCode     手机验证码
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     * @param callback
     */
    @Override
    public void optMemberInfo(String account, String verifyCode, int verifyCodeType, ResultCallback<NewQueryMemberListResponse> callback) {
        ClientMemberApi.loadMemberInfo(account, verifyCode, verifyCodeType, false, "", response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }

    /**
     * 查询会员卡信息，带验证码，并绑定到订单---会员重构版本
     *
     * @param account        手机号
     * @param verifyCode     手机验证码
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     * @param orderId        订单号
     * @param callback
     */
    @Override
    public void optMemberInfoAndBindToOrder(String account, String verifyCode, int verifyCodeType, String orderId, ResultCallback<NewQueryMemberListResponse> callback) {
        ClientMemberApi.loadMemberInfo(account, verifyCode, verifyCodeType, true, orderId, response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }

    /**
     * 将指定会员卡绑定到订单
     *
     * @param memberCard 会员卡
     * @param orderId    订单Id
     * @param callback
     */
    @Override
    public void bindMemberCardToOrder(NewMemberCardListItemModel memberCard, String orderId, ResultCallback<NewQueryMemberInfoAndBindToOrderResponse> callback) {
        if (memberCard == null) {
            return;
        }
        ClientMemberApi.bindMemberCardToOrder(memberCard, orderId, response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }

    /**
     * 发送手机验证码
     *
     * @param mobile   手机号
     * @param type     验证码使用场景，1:实体卡激活（只限实体卡激活验证码使用）；2:普通验证码
     * @param callback
     */
    @Override
    public void sendVerifyCode(String mobile, int type, ResultCallback<Boolean> callback) {
        ClientMemberApi.sendVerifyCode(mobile, type, response -> {
            if (response == null) {
                return;
            }
            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        });
    }
}
