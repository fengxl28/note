package com.mwee.android.pos.air.business.setting.shop.model;

import com.mwee.android.cashier.connect.bean.http.BaseCashierPosResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by changsunhaipeng on 2018/2/10.
 */

public class GetProvinceListResponse extends BaseCashierPosResponse {
    public List<ProvinceModel> data = new ArrayList<>();
}
