package com.mwee.android.pos.business.einvoice.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.business.einvoice.ManualEInvoiceProcess;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.setting.GetAllManualIEnvoiceResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.ManualInvoicingDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * 手动开发票
 */
public class ManualEInvoiceFragment extends BaseListFragment<ManualInvoicingDBModel> implements View.OnClickListener {
    public static final String TAG = "ManualEInvoiceFragment";

    private PullRecyclerView mPullRecyclerView;

    /**
     * 总开票状态提示：今天共XX条记录，其中XXX条成功开具发票
     */
    private TextView einvoce_status_tips;

    /**
     * 开票金额显示组件
     */
    private TextView tv_amount;

    /**
     * 今日暂无开票记录
     */
    private TextView tv_empty;

    /**
     * 开票金额输入键盘
     */
    private NumberKeyboard board_key_input;

    /**
     * 打印开票码
     */
    private Button btn_print;

    /**
     * 键盘输入的值
     */
    private String price = "";


    private int currentPage = 1;

    private ManualEInvoiceProcess manualEInvoiceProcess = new ManualEInvoiceProcess();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.manual_einvoce_fragment, container, false);
        return view;
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.manual_einvoce_item;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new ManualEinvoiceHolder(LayoutInflater.from(getContext()).inflate(R.layout.manual_einvoce_item, parent, false));
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.btn_print:
                ActionLog.addLog("更多设置->电子发票->手动纯开票->点击了'打印开票码'", "", "", ActionLog.SS_MORE_JOIN, "");

                String amt = tv_amount.getText().toString().trim();
                if (TextUtils.isEmpty(amt)) {
                    ToastUtil.showToast("请输入金额");
                    return;
                }

                try {
                    BigDecimal amount = new BigDecimal(amt);

                    if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                        ToastUtil.showToast("开票金额要大于0");
                        return;
                    }
                } catch (Exception e) {
                    LogUtil.logError("开票金额 转换异常 " + amt, e);
                }

                final Progress progress = ProgressManager.showProgressUncancel(ManualEInvoiceFragment.this, "请稍候...");
                optManualEInvoiceProcessObj().addManualEInvoice(amt, "", new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        if (result) {
                            ToastUtil.showToast("开票成功");
                            price = "";
                            tv_amount.setText("");
                            loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
                        } else {
                            ToastUtil.showToast(info);
                        }
                        progress.dismiss();
                    }
                });

                break;
        }
    }

    /**
     * 某一个发票被点击重印
     *
     * @param position
     */
    private void clickItem(int position) {
        String orderId = modules.get(position).orderId;
        ActionLog.addLog("更多设置->电子发票->手动纯开票->点击了'重新打印开票码'" + orderId, orderId, "", ActionLog.SS_MORE_JOIN, "");
        final Progress progress = ProgressManager.showProgressUncancel(ManualEInvoiceFragment.this, "请稍候...");
        optManualEInvoiceProcessObj().reprintManualEInvoice(orderId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ToastUtil.showToast(info);
                progress.dismiss();
            }
        });
    }

    class ManualEinvoiceHolder extends BaseViewHolder {

        private ManualInvoicingDBModel data;
        private View root;
        private TextView tv_id;
        private TextView tv_status;
        private TextView tv_amt;
        private TextView tv_time;
        private Button btn_reprint;

        public ManualEinvoiceHolder(View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.lyt_root);
            tv_id = itemView.findViewById(R.id.tv_id);
            tv_status = itemView.findViewById(R.id.tv_status);
            tv_amt = itemView.findViewById(R.id.tv_amt);
            tv_time = itemView.findViewById(R.id.tv_time);
            btn_reprint = itemView.findViewById(R.id.btn_reprint);
        }

        @Override
        public void bindData(int position) {
            data = modules.get(position);
            tv_id.setText(data.orderId);
            tv_amt.setText(Calc.format(data.amt, 2) + "元");
            tv_time.setText(data.createTime);

            tv_status.setText(EInvoiceProcess.optManualEInvoiceStatus(data.status));

            int colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
            if (data.status == 20) {
                colorR = getContextWithinHost().getResources().getColor(R.color.color_00C801);
            }
            tv_status.setTextColor(colorR);

            btn_reprint.setOnClickListener(v -> clickItem(position));
        }

    }


    public void refreshAdapter(List<ManualInvoicingDBModel> data) {
        modules.addAll(data);
        adapter.notifyDataSetChanged();
    }

    private void loadDataFromServer(int mode) {
        optManualEInvoiceProcessObj().optDataFromServer(currentPage, "", new ResultCallback<GetAllManualIEnvoiceResponse>() {
            @Override
            public void onSuccess(GetAllManualIEnvoiceResponse data) {
                if (isAdded()) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (data.allCount == 0) {
                        einvoce_status_tips.setVisibility(View.GONE);
                        tv_empty.setVisibility(View.VISIBLE);
                        mPullRecyclerView.setVisibility(View.GONE);
                    } else {

                        einvoce_status_tips.setVisibility(View.VISIBLE);
                        tv_empty.setVisibility(View.GONE);
                        mPullRecyclerView.setVisibility(View.VISIBLE);

                        einvoce_status_tips.setText("今天共" + data.allCount + "条记录，其中" + data.finishedCount + "条成功开具发票");
                        einvoce_status_tips.setVisibility(View.VISIBLE);

                        if (currentPage >= data.pageCount) {//没有下一页数据
                            mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                        } else {
                            mPullRecyclerView.onRefreshCompleted(mode);
                        }

                        if (ListUtil.isEmpty(data.manualInvoicingDBModels)) {
                            mPullRecyclerView.showEmptyView();
                            adapter.notifyDataSetChanged();
                        } else {
                            mPullRecyclerView.showContent();
                            refreshAdapter(data.manualInvoicingDBModels);
                        }
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                BaseToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                super.onFailure(code, msg);
            }
        });
    }


    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    private void assignViews(View convertView) {
        einvoce_status_tips = convertView.findViewById(R.id.einvoce_status_tips);
        einvoce_status_tips.setVisibility(View.GONE);

        btn_print = convertView.findViewById(R.id.btn_print);
        btn_print.setOnClickListener(this);

        tv_empty = convertView.findViewById(R.id.tv_empty);
        tv_amount = convertView.findViewById(R.id.tv_amount);
        board_key_input = convertView.findViewById(R.id.board_key_input);
        board_key_input.setItemLayoutId(R.layout.view_cross_pay_key_item);
        board_key_input.initData(KeyHelper.generateCrossPayKeys(), key -> {
            switch (key.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    if (android.text.TextUtils.equals(price, "0")) {
                        price = "";
                    }
                    if (com.mwee.android.pos.util.TextUtils.isMoneyStr(price + key.value)) {
                        price += key.value;
                    }
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CLEAR:
                    price = "";
                    break;
                case NumberKeyboard.KeyEntity.TYPE_POINT:
                    if (com.mwee.android.pos.util.TextUtils.isMoneyStr(price + key.value)) {
                        price += key.value;
                    }
                    break;
                default:
                    break;
            }
            tv_amount.setText(price);
        });
        board_key_input.notifyDataChanged();

        mPullRecyclerView = convertView.findViewById(R.id.mPullRecyclerView);

        mPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();

    }


    private ManualEInvoiceProcess optManualEInvoiceProcessObj() {
        if (manualEInvoiceProcess == null) {
            manualEInvoiceProcess = new ManualEInvoiceProcess();
        }

        return manualEInvoiceProcess;
    }
}
