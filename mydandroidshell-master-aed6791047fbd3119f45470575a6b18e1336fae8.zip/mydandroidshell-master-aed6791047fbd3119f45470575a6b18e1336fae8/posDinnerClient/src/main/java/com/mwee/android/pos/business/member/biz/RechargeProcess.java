package com.mwee.android.pos.business.member.biz;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.member.BalanceChangesListFragment;
import com.mwee.android.pos.business.member.RechargeSuccessPageFragment;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.business.member.constant.MemberRechargeChoosePayType;
import com.mwee.android.pos.business.member.entity.RechargePayType;
import com.mwee.android.pos.business.member.view.MemberPrintProcess;
import com.mwee.android.pos.business.pay.view.netpay.ICutomeNetPay;
import com.mwee.android.pos.business.pay.view.netpay.NetPayJump;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import java.math.BigDecimal;

/**
 * Created by huangming on 2018/12/11.
 *
 */

public class RechargeProcess implements ICutomeNetPay {

    private BaseFragment mFragment;
    private NewMemberCardDetailsModel cardDetailsModel;
    private MemberRechargePackageModel.Rule mRule;
    private RechargePayType mPayType;
    private BigDecimal mChargeMoney;

    public RechargeProcess(BaseFragment fragment,NewMemberCardDetailsModel cardDetails){
        mFragment = fragment;
        cardDetailsModel = cardDetails;
    }

    public void charge(MemberRechargePackageModel.Rule rule, RechargePayType payType,BigDecimal chargeMoney){
        if (payType == null) {
            ToastUtil.showToast(R.string.member_recharge_choice_pay_type_msg);
            return;
        }
        if (rule == null) {
            ToastUtil.showToast(R.string.member_recharge_choice_package_msg);
            return;
        }
        mRule = rule;
        mPayType = payType;
        mChargeMoney = chargeMoney;

        PermissionsUtil.requestPermissionCommon(mFragment.getActivityWithinHost(), AppCache.getInstance().userDBModel, Permission.DINNER_vTempVIPAuth, new PermissionCallback() {
            @Override
            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                switch (payType.type) {
                    case MemberRechargeChoosePayType.CASH:
                        pay("",rule.id, 0,chargeMoney,payType.name,null);
                        break;
                    case MemberRechargeChoosePayType.ALIPAY:
                    case MemberRechargeChoosePayType.WECHAT:
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付" + rule.toString());
                        NetPayJump.jumpToMemberChargePay(mFragment.getActivityWithinHost(),chargeMoney, payType.type, RechargeProcess.this);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private void pay(String payMicro,String ruleId,int payType,BigDecimal buyAmount,String payTypeName,IResponse<String> callback){
        Progress progress = null;
        if(callback == null){
            progress = ProgressManager.showProgressUncancel(mFragment.getActivityWithinHost(), "充值中...");
        }
        Progress finalProgress = progress;
        ClientMemberApi.memberRecharge(cardDetailsModel.cardInfo.card_no, payMicro, ruleId, buyAmount, payType, new SocketCallback<MemberRechargeResultModel>() {
            @Override
            public void callback(SocketResponse<MemberRechargeResultModel> response) {
                if (Looper.myLooper() != Looper.getMainLooper()) {
                    new Handler(Looper.getMainLooper()).post(() -> callback(response));
                    return;
                }
                if(finalProgress != null){
                    finalProgress.dismiss();
                }
                if(response == null){
                    ToastUtil.showToast("充值失败");
                    if(callback != null){
                        callback.callBack(false, 2, "充值失败", null);
                    }
                    return;
                }
                if(response.success() && response.data != null){
                    queryPayResult(response.data.trade_no,getChargeDesc(),payTypeName,callback);
                } else{
                    ToastUtil.showToast(response.message);
                    if(callback != null){
                        callback.callBack(false, 2, response.message, null);
                    }
                }
            }
        });
    }

    private void queryPayResult(String tradeNo,String rechargeDesc,String payTypeName,IResponse<String> callback){
        Progress progress = null;
        if(callback == null){
            progress = ProgressManager.showProgressUncancel(mFragment.getActivityWithinHost(), R.string.member_recharge_syn_ing);
        }
        Progress finalProgress = progress;
        RunTimeLog.addLog(RunTimeLog.MEMBER, "同步充值结果ing trade_no:" + tradeNo);
        ClientMemberApi.queryPayResult(tradeNo, new SocketCallback<MemberRechargeResultModel>() {
            @Override
            public void callback(SocketResponse<MemberRechargeResultModel> response) {
                if (Looper.myLooper() != Looper.getMainLooper()) {
                    new Handler(Looper.getMainLooper()).post(() -> callback(response));
                    return;
                }
                if(finalProgress != null){
                    finalProgress.dismiss();
                }
                if(response == null || response.data == null){
                    ToastUtil.showToast("充值失败");
                    if(callback != null){
                        callback.callBack(false, 2, "充值失败", null);
                    }
                }else{
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "同步充值结果done MemberRechargeResultModel:", response.data.toString());
                    if(response.data.status == 104){
                        if (callback != null) {
                            callback.callBack(true, 1, "", response.data.trade_no);
                        }
                        DriverBus.call("member/rechargeSuccess");
                        //充值成功后，打印会员充值小票
                        response.data.content = rechargeDesc;
                        String printMemberName = TextUtils.isEmpty(cardDetailsModel.cardInfo.real_name) ? cardDetailsModel.cardInfo.nick : cardDetailsModel.cardInfo.real_name;
                        MemberPrintProcess.printChargeInfo(mFragment.getActivityWithinHost(), response.data,mPayType.name, printMemberName);
                        doBalanceOrderListRefresh();
                        RechargeSuccessPageFragment fragment = RechargeSuccessPageFragment.getInstance(response.data);
                        //显示充值成功页面
                        FragmentController.addFragmentWithHide(mFragment.getFragmentManager(), fragment, fragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "跳转到支付成功界面");
                        mFragment.dismissSelf();
                    }else if (response.data.status == 103 ||  response.data.status == 102 || response.data.status == 101){
                        if(callback != null){
                            callback.callBack(true, 0, response.message, response.data.trade_no);
                        }
                    }else{
                        ToastUtil.showToast(TextUtils.isEmpty(response.message) ? "请手动刷新储值列表页" : response.message);
                        if(callback != null){
                            callback.callBack(false, 2, "充值失败", null);
                        }
                    }
                }
            }
        });
    }

    /**
     * 刷新会员储值流水界面
     */
    private void doBalanceOrderListRefresh() {
        if (mFragment.getActivityWithinHost() != null) {
            BalanceChangesListFragment fragment = (BalanceChangesListFragment) mFragment.getActivityWithinHost().getSupportFragmentManager().findFragmentByTag(BalanceChangesListFragment.class.getName());
            if (fragment != null && fragment.isAdded()) {
                fragment.doRefresh();
            }
        }
    }

    private String getChargeDesc(){
        return "充值" + mChargeMoney.intValue() + "元 " + mRule.presentDesc;
    }

    @Override
    public void callPay(int type, String micro, IResponse<String> callback) {
        if(mRule == null || mPayType == null){
            return;
        }
        pay(micro,mRule.id,type,mChargeMoney,mPayType.name,callback);
    }

    @Override
    public void queryPayResult(String tradeNo, IResponse<String> callback) {
        if(mRule == null || mPayType == null){
            return;
        }
        queryPayResult(tradeNo,getChargeDesc(),mPayType.name,callback);
    }
}
