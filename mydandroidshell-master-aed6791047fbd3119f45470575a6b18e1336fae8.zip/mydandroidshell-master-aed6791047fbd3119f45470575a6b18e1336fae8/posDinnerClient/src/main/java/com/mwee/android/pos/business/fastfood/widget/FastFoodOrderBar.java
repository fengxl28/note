package com.mwee.android.pos.business.fastfood.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.dialog.MemberBindDialogFragment;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.common.fastfood.IFastFoodProcessor;
import com.mwee.android.pos.business.fastfood.dialog.BillSourceChoiceFragmentDialog;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.business.member.view.MemberBindScannerDialogFragment;
import com.mwee.android.pos.business.member.view.MemberCheckCallBack;
import com.mwee.android.pos.business.member.view.MemberOrderUnBindDialogFragment;
import com.mwee.android.pos.business.member.view.NewMemberCheckCallBack;
import com.mwee.android.pos.business.member.view.NewMemberOrderUnBindDialogFragment;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.business.table.processor.TableBizProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.BillSourceDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderMemberInfo;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;

/**
 * 快餐点菜顶部bar
 * Created by qinwei on 2017/4/7.
 */

public class FastFoodOrderBar extends HorizontalScrollView implements View.OnClickListener {
    private Button mBarOrderBatchPrivilegeBtn;//批量优惠
    private Button mBarOrderBillSourceNameBtn;//修改来源按钮
    private Button mBarOrderBatchRequestBtn;//批量要求按钮
    private Button mBarOrderPersonNumberBtn;//修改人数按钮
    private Button mBarOrderBindMemberBtn;//绑定会员按钮
    private Button mBarOrderMealNumberBtn;//修改牌号按钮
    private Button mBarBackOrderBtn;//返回按钮
    private TextView mBarOrderNumberLabel;//订单号
    private OnFastFoodOrderBarClickListener listener;
    private Host host;
    private FastFoodDishCache mDishCache;
    private IFastFoodProcessor mFastFoodProcessor;

    public interface OnFastFoodOrderBarClickListener {
        void onFastFoodBarBackClick();

        void onFastFoodBarOrderRequestClick();

        void onFastFoodBarOrderPrivilegeClick();

        void onFastFoodBarOrderBindMember(QueryMemberInfoAndBindToOrderResponse member);

        void onFastFoodBarOrderBindMember(NewQueryMemberInfoAndBindToOrderResponse member);

        void onFastFoodBarOrderUnBindMember(ChangeOrderWithMemberResponse data);

    }

    public FastFoodOrderBar(Context context) {
        super(context);
        initView();
    }

    public FastFoodOrderBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public FastFoodOrderBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.widget_fast_food_order_bar, this);
        mBarBackOrderBtn = (Button) findViewById(R.id.mBarBackOrderBtn);
        mBarOrderMealNumberBtn = (Button) findViewById(R.id.mBarOrderMealNumberBtn);
        mBarOrderBillSourceNameBtn = (Button) findViewById(R.id.mBarOrderBillSourceNameBtn);
        mBarOrderBatchRequestBtn = (Button) findViewById(R.id.mBarOrderBatchRequestBtn);
        mBarOrderBatchPrivilegeBtn = (Button) findViewById(R.id.mBarOrderBatchPrivilegeBtn);
        mBarOrderPersonNumberBtn = (Button) findViewById(R.id.mBarOrderPersonNumberBtn);
        mBarOrderBindMemberBtn = (Button) findViewById(R.id.mBarOrderBindMemberBtn);
        mBarOrderNumberLabel = (TextView) findViewById(R.id.mBarOrderNumberLabel);
        mBarBackOrderBtn.setOnClickListener(this);
        mBarOrderMealNumberBtn.setOnClickListener(this);
        mBarOrderBillSourceNameBtn.setOnClickListener(this);
        mBarOrderBatchRequestBtn.setOnClickListener(this);
        mBarOrderBatchPrivilegeBtn.setOnClickListener(this);
        mBarOrderPersonNumberBtn.setOnClickListener(this);
        mBarOrderBindMemberBtn.setOnClickListener(this);
    }

    /**
     * 刷新订单操作按钮可用状态
     */
    public void refreshOperationBtnStatus() {
        if (hasNoOrderedMenu()) {
            mBarOrderBatchRequestBtn.setEnabled(true);
        } else {
            mBarOrderBatchRequestBtn.setEnabled(false);
        }
        if (mDishCache.menuItems.size() > 0) {
            mBarOrderBatchPrivilegeBtn.setEnabled(true);
        } else {
            mBarOrderBatchPrivilegeBtn.setEnabled(false);
        }
    }

    /**
     * 判断是否有未下单的菜品
     *
     * @return
     */
    private boolean hasNoOrderedMenu() {
        for (MenuItem menuItem : mDishCache.menuItems) {
            if (menuItem == null) {
                continue;
            }
            if (menuItem.menuBiz == null) {
                continue;
            }
            OrderSeqModel seqModel = mDishCache.fastOrderModel.optSeqModel(menuItem.menuBiz.orderSeqID);
            if (seqModel == null) {
                continue;
            }
            if (seqModel.seqStatus == OrderSeqStatus.NORMAL) {
                return true;
            }
        }
        return false;
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public void initData(FastFoodDishCache dishCache, IFastFoodProcessor mFastFoodProcessor) {
        this.mDishCache = dishCache;
        this.mFastFoodProcessor = mFastFoodProcessor;
    }

    public BillSourceDBModel findById(String billSourceId) {
        if (!ListUtil.isEmpty(AppCache.getInstance().billSourceAll)) {
            for (int i = 0; i < AppCache.getInstance().billSourceAll.size(); i++) {
                if (android.text.TextUtils.equals(billSourceId, AppCache.getInstance().billSourceAll.get(i).fsBillSourceId)) {
                    return AppCache.getInstance().billSourceAll.get(i);
                }
            }
        }
        return null;
    }

    /**
     * 数据变化更新ui
     */
    public void notifyDataChanged() {
        mBarOrderNumberLabel.setText(String.format(getContext().getString(R.string.fast_food_order_number_label), mDishCache.getOrderId()));
        if (mDishCache.fastOrderModel.memberInfoS != null) {
            if (!mDishCache.fastOrderModel.memberInfoS.checkInfoEnough()) {//处理秒付昵称显示问题
                queryAndBindMember();
            } else {
                if (!TextUtils.validate(mDishCache.fastOrderModel.memberInfoS.real_name)) {//真实姓名和昵称都为空 取会员等级名称/区域名
                    OrderMemberInfo memberInfo = mDishCache.fastOrderModel.memberInfoS;
                    mBarOrderBindMemberBtn.setText(memberInfo.bindType == 0 ? memberInfo.level_name : memberInfo.csName);
                    mBarOrderBindMemberBtn.setText(memberInfo.level_name);
                } else {
                    mBarOrderBindMemberBtn.setText(mDishCache.fastOrderModel.memberInfoS.real_name);
                }
            }
        } else {
            mBarOrderBindMemberBtn.setText(R.string.table_bind_member);
        }
        mBarOrderPersonNumberBtn.setText(String.format(getContext().getString(R.string.fast_food_order_person_num_label), mDishCache.fastOrderModel.personNumber));


        String billSourceName = mDishCache.fastOrderModel.billSourceName;
        if (android.text.TextUtils.isEmpty(billSourceName)) {
            BillSourceDBModel billSourceDBModel = findById(mDishCache.fastOrderModel.billSourceId);
            if (billSourceDBModel != null) {
                billSourceName = billSourceDBModel.fsBillSourceName;
            }
        }
        mBarOrderBillSourceNameBtn.setEnabled(!OrderDishesBizUtil.isBillSourceDefault(mDishCache.fastOrderModel.billSourceId));
        mBarOrderBillSourceNameBtn.setText(billSourceName);

        //设置牌号
        if (mDishCache.fastOrderModel != null) {
            if (TextUtils.validate(mDishCache.fastOrderModel.mealNumber)) {
                mBarOrderMealNumberBtn.setText(getContext().getString(R.string.fast_food_order_mealnumber_label) + mDishCache.fastOrderModel.mealNumber);
            } else {
                mBarOrderMealNumberBtn.setText(R.string.fast_food_order_mealnumber_none);
            }
        }
        refreshOperationBtnStatus();
    }

    private void showSetMealNumberFragment(int mealNumber, CountKeyboardCallback callback) {
        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle(getContext().getString(R.string.set_meal_number_title));
        fragment.setErrorTips(getContext().getString(R.string.error_tips_input_number));
        fragment.setOriginCount(mealNumber);
        fragment.setCanBe0(true);
        fragment.setCallback(callback);
        fragment.setMaxCount(999);
        ActionLog.addLog("快餐点单界面->显示输入牌号界面", mDishCache.fastOrderModel.orderId, mDishCache.fastOrderModel.mealNumber, ActionLog.FF_ORDER_PAY, "");
        DialogManager.showCustomDialog(host, fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }

    public void showSetMealNumberFragment(int mealNumber) {
        showSetMealNumberFragment(mealNumber, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                mDishCache.fastOrderModel.mealNumber = newNum.intValue() + "";
                notifyDataChanged();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mBarOrderMealNumberBtn:
                showSetMealNumberFragment(1, new CountKeyboardCallback() {
                    @Override
                    public void callback(BigDecimal originNum, BigDecimal newNum) {
                        doUpdateOrderMealNumber(newNum.intValue());
                    }
                });
                break;
            case R.id.mBarOrderBillSourceNameBtn:
                ActionLog.addLog("快餐单界面->点击了订单来源按钮", "", "", ActionLog.USER_ACTION_TRACE, "");
                showBillSourceChoiceDialog();
                break;
            case R.id.mBarBackOrderBtn:
                ActionLog.addLog("快餐单界面->点击了返回快餐单", "", "", ActionLog.USER_ACTION_TRACE, "");
                listener.onFastFoodBarBackClick();
                break;
            case R.id.mBarOrderBatchRequestBtn:
                ActionLog.addLog("快餐单界面->点击了要求按钮", "", "", ActionLog.USER_ACTION_TRACE, "");
                listener.onFastFoodBarOrderRequestClick();
                break;
            case R.id.mBarOrderBatchPrivilegeBtn:
                ActionLog.addLog("快餐单界面->点击了优惠按钮", "", "", ActionLog.USER_ACTION_TRACE, "");
                listener.onFastFoodBarOrderPrivilegeClick();
                break;
            case R.id.mBarOrderPersonNumberBtn:
                ActionLog.addLog("快餐单界面->点击了人数按钮", "", "", ActionLog.USER_ACTION_TRACE, "");
                CountKeyboardFragment fragment = new CountKeyboardFragment();
                fragment.setTitle("设置就餐人数");
                fragment.setOriginCount(mDishCache.fastOrderModel.personNumber);
                fragment.setCallback(new CountKeyboardCallback() {
                    @Override
                    public void callback(BigDecimal originNum, BigDecimal newNum) {
                        doUpdatePersonNumber(newNum.intValue());
                    }
                });
                DialogManager.showCustomDialog(host, fragment, CountKeyboardFragment.FRAGMENT_TAG);
                break;
            case R.id.mBarOrderBindMemberBtn:
                if (mDishCache.isBindMember()) {//已经绑定过会员
                    showMemberInfo();
                } else {//尚未绑定会员
                    PermissionsUtil.requestPermissionCommon(host, AppCache.getInstance().userDBModel, Permission.DINNER_vVIPBind, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (AppCache.getInstance().isRetailMode()) {
                                MemberBindDialogFragment fragment = new MemberBindDialogFragment();
                                fragment.setBindOrderId(mDishCache.fastOrderModel.orderId);
                                fragment.setOnBindOrderListener(memberCheckCallBack);
                                DialogManager.showCustomDialog(host, fragment, "MemberBindDialogFragment");
                            } else {
                                loadMemberConfigFromServer();
                            }
                        }
                    });
                }
                break;
            default:
                break;
        }
    }

    private void loadMemberConfigFromServer() {
        final Progress progress = ProgressManager.showProgressUncancel(host, R.string.progress_loading);
        new MemberProcess().loadShopMemberConfig(new ResultCallback<MemberConfig>() {
            @Override
            public void onSuccess(MemberConfig data) {
                progress.dismissSelf();
                if (data.is_open == 1) {//门店开通会员配置
                    AppCache.getInstance().shop_member_config = data.card_setting.mobile_pay_type;
                    showBindMember();
                } else {
                    //门店未开通会员配置
                    ToastUtil.showToast(data.msg);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void doUpdateOrderMealNumber(final int count) {
        final Progress progress = ProgressManager.showProgressUncancel(host);
        mFastFoodProcessor.loadUpdateMealNumber(mDishCache.getOrderId(), count + "", new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                mDishCache.fastOrderModel.mealNumber = count + "";
                mBarOrderMealNumberBtn.setText(getContext().getString(R.string.fast_food_order_mealnumber_label) + count);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    private void showBillSourceChoiceDialog() {
        //判断选中的BillSourceID是否是系统内置的，
        if (OrderDishesBizUtil.isBillSourceDefault(mDishCache.fastOrderModel.billSourceId)) {
            return;
        }
        BillSourceChoiceFragmentDialog fragmentDialog = BillSourceChoiceFragmentDialog.getInstance(mDishCache.fastOrderModel.billSourceId);
        fragmentDialog.setOnBillSourceChoiceListener(new BillSourceChoiceFragmentDialog.OnBillSourceChoiceListener() {
            @Override
            public void onBillSourceChoiceItemClick(final BillSourceDBModel billSourceDBModel) {
                doUpdateBillSource(billSourceDBModel);
            }
        });
        DialogManager.showCustomDialog(host, fragmentDialog, "");
    }

    private void doUpdateBillSource(final BillSourceDBModel billSourceDBModel) {
        final Progress progress = ProgressManager.showProgressUncancel((Host) getContext());
        mFastFoodProcessor.loadUpdateBillSource(mDishCache.fastOrderModel.orderId, billSourceDBModel.fsBillSourceId, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                mDishCache.fastOrderModel.billSourceId = billSourceDBModel.fsBillSourceId;
                mDishCache.fastOrderModel.billSourceName = billSourceDBModel.fsBillSourceName;
                mBarOrderBillSourceNameBtn.setText(billSourceDBModel.fsBillSourceName);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 已下单到业务中心的订单修改人数时通知业务中心改人数
     *
     * @param count
     */
    private void doUpdatePersonNumber(final int count) {
        ProgressManager.showProgressUncancel(host);
        ActionLog.addLog("快餐单界面-->" + "用户输入人数为: personNum=" + count + " 开始同步业务中心", "", "", ActionLog.USER_ACTION_TRACE, "");
        TableBizProcessor.changePersonCount(mDishCache.fastOrderModel.orderId, count, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(host);
                if (result) {
                    mDishCache.fastOrderModel.personNumber = count;
                    mBarOrderPersonNumberBtn.setText(String.format(getContext().getString(R.string.fast_food_order_person_num_label), count));
                    RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "改人数: personNum=" + count + " 同步成功");
                } else {
                    ToastUtil.showToast(info);
                    RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "改人数: personNum=" + count + " 同步失败");
                }
            }
        });
    }


    /**
     * 显示绑定会员界面
     */
    private void showBindMember() {
        ActionLog.addLog("显示绑定会员界面", "", "", ActionLog.USER_ACTION_TRACE, "");
        String bindShowType = ClientMetaUtil.getSettingsValueByKey(META.MEMBER_BIND_TYPE);
        if (!TextUtils.validate(bindShowType)) {
            bindShowType = Constants.MEMBER_BIND_TYPE_INPUT;
        }
        MemberBindScannerDialogFragment fragment = new MemberBindScannerDialogFragment();
        fragment.setNewCallBack(newMemberCheckCallBack);
        fragment.setOrderId(mDishCache.fastOrderModel.orderId);
        DialogManager.showCustomDialog(host, fragment, "");
//        if (BaseConfig.isProduct()) {
//            MemberBindScannerDialogFragment fragment = new MemberBindScannerDialogFragment();
//            fragment.setCallBack(memberCheckCallBack);
//            fragment.setOrderId(mDishCache.fastOrderModel.orderId);
//            DialogManager.showCustomDialog(host, fragment, "");
//        } else {
//            //测试环境通过配置进行改变会员绑定模式（方便测试测试会员绑定功能）
//            if (bindShowType.equals(Constants.MEMBER_BIND_TYPE_INPUT)) {
//                MemberOrderBindDialogFragment fragment = new MemberOrderBindDialogFragment();
//                fragment.setCallBack(memberCheckCallBack);
//                fragment.setOrderId(mDishCache.fastOrderModel.orderId);
//                DialogManager.showCustomDialog(host, fragment, "");
//            } else {
//                MemberBindScannerDialogFragment fragment = new MemberBindScannerDialogFragment();
//                fragment.setCallBack(memberCheckCallBack);
//                fragment.setOrderId(mDishCache.fastOrderModel.orderId);
//                DialogManager.showCustomDialog(host, fragment, "");
//            }
//        }
    }

    private MemberCheckCallBack memberCheckCallBack = new MemberCheckCallBack() {
        @Override
        public void call(final QueryMemberInfoAndBindToOrderResponse member) {

            ActionLog.addLog("账单绑定会员成功 会员卡号为:" + member.memberCardModel.card_info.card_no, "", "", ActionLog.USER_ACTION_TRACE, "");
            mDishCache.fastOrderModel.setMember(member.memberCardModel);
            mDishCache.menuItems.clear();
            mDishCache.menuItems.addAll(member.menuItemList);
            if (!TextUtils.validate(mDishCache.fastOrderModel.memberInfoS.real_name)) {//真实姓名和昵称都为空 取会员等级名称
                mBarOrderBindMemberBtn.setText(mDishCache.fastOrderModel.memberInfoS.level_name);
            } else {
                mBarOrderBindMemberBtn.setText(mDishCache.fastOrderModel.memberInfoS.real_name);
            }
            ToastUtil.showToast(getContext().getString(R.string.mMemberBindSuccess));
            listener.onFastFoodBarOrderBindMember(member);
        }
    };

    private NewMemberCheckCallBack newMemberCheckCallBack = new NewMemberCheckCallBack() {
        @Override
        public void call(final NewQueryMemberInfoAndBindToOrderResponse member) {

            ActionLog.addLog("账单绑定会员成功 会员卡号为:" + member.memberCardModel.cardInfo.card_no, "", "", ActionLog.USER_ACTION_TRACE, "");
            mDishCache.fastOrderModel.setMember(member.memberCardModel);
            mDishCache.menuItems.clear();
            mDishCache.menuItems.addAll(member.menuItemList);
            if (!TextUtils.validate(mDishCache.fastOrderModel.memberInfoS.real_name)) {//真实姓名和昵称都为空 取会员等级名称/区域名
                OrderMemberInfo memberInfo = mDishCache.fastOrderModel.memberInfoS;
                mBarOrderBindMemberBtn.setText(memberInfo.bindType == 0 ? memberInfo.level_name : memberInfo.csName);
            } else {
                mBarOrderBindMemberBtn.setText(mDishCache.fastOrderModel.memberInfoS.real_name);
            }
            ToastUtil.showToast(getContext().getString(R.string.mMemberBindSuccess));
            listener.onFastFoodBarOrderBindMember(member);
        }
    };

    /**
     * 显示关联会员信息
     */
    private void showMemberInfo() {
        NewMemberOrderUnBindDialogFragment fragment = NewMemberOrderUnBindDialogFragment.getInstance(mDishCache.fastOrderModel.memberInfoS);
        String orderId = mDishCache.fastOrderModel.orderId;
        fragment.setParams(orderId, newMemberCheckCallBack, new NewMemberOrderUnBindDialogFragment.OnMemberInfoListener() {
            @Override
            public void onUnbindMember() {
                doUnbindMember();
            }
        });
        DialogManager.showCustomDialog(host, fragment, fragment.getTag());
//        MemberOrderUnBindDialogFragment info = MemberOrderUnBindDialogFragment.getInstance(mDishCache.fastOrderModel.memberInfoS);
//        info.setParam(new MemberOrderUnBindDialogFragment.OnMemberInfoListener() {
//            @Override
//            public void onUnbindMember() {
//                doUnbindMember();
//            }
//        });
//        DialogManager.showCustomDialog(host, info, "");
    }

    private void doUnbindMember() {
        if (mDishCache.isBindMember()) {
            final Progress progress = ProgressManager.showProgressUncancel(host, "解绑中");
            mFastFoodProcessor.unBindMemberInfoFromOrder(mDishCache.fastOrderModel.orderId, mDishCache.fastOrderModel.memberInfoS.card_no, new ResultCallback<ChangeOrderWithMemberResponse>() {
                @Override
                public void onSuccess(ChangeOrderWithMemberResponse data) {
                    ActionLog.addLog("快餐点单界面->会员解绑", mDishCache.fastOrderModel.orderId, mDishCache.fastOrderModel.mealNumber, ActionLog.FF_ORDER_MEMBER, "");
                    mDishCache.fastOrderModel.clearMember();
                    mBarOrderBindMemberBtn.setText(R.string.table_bind_member);
                    if (listener != null) {
                        listener.onFastFoodBarOrderUnBindMember(data);
                    }
                    progress.dismiss();
                }

                @Override
                public void onFailure(int code, String msg) {
                    progress.dismiss();
                    if (!android.text.TextUtils.isEmpty(msg)) {
                        ToastUtil.showToast(msg);
                    }
                }
            });
        }
    }

    /**
     * 设置FastFoodOrderBar监听事件
     *
     * @param listener
     */
    public void setOnFastFoodOrderBarClickListener(OnFastFoodOrderBarClickListener listener) {
        this.listener = listener;
    }

    /**
     * 查询并绑定会员信息
     */
    public void queryAndBindMember() {
        mBarOrderBindMemberBtn.setText("");
        MemberProcess process = new MemberProcess();
        final Progress progress = ProgressManager.showProgressUncancel(host);
        process.optMemberInfoWithoutVerifyAndBindToOrder(mDishCache.fastOrderModel.memberInfoS.card_no, mDishCache.fastOrderModel.orderId, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                progress.dismiss();
                if (data.bindResponse != null) {
                    mDishCache.fastOrderModel = data.bindResponse.fastOrderModel;
                    if (!TextUtils.validate(mDishCache.fastOrderModel.memberInfoS.real_name)) {
                        //真实姓名和昵称都为空 取会员等级名称/区域名
                        OrderMemberInfo memberInfo = mDishCache.fastOrderModel.memberInfoS;
                        mBarOrderBindMemberBtn.setText(memberInfo.bindType == 0 ? memberInfo.level_name : memberInfo.csName);
                    } else {
                        mBarOrderBindMemberBtn.setText(mDishCache.fastOrderModel.memberInfoS.real_name);
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                // errorCode=200,卡号解析失败；errorCode=501,会员卡号不存在；errorCode=502,实体卡号不存在
                // 返回该错误时，清除订单会员信息
                if (code == 200 || code == 501 || code == 502) {
                    doUnbindMember();
                }
                if (TextUtils.validate(msg)) {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }
}
