package com.mwee.android.pos.business.login.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.dinner.R;

import java.util.List;

/**
 * Created by Zun on 16/6/3.
 */
public class LoginDinnerUserAdapter extends RecyclerView.Adapter<LoginDinnerUserAdapter.UserViewHolder> {

    private Context context;
    private List<UserDBModel> list;
    private OnItemClickLitener onItemClickLitener;
    public int currentIndex = -1;

    public LoginDinnerUserAdapter(Context context, List<UserDBModel> list) {
        this.context = context;
        this.list = list;
    }

    public void selection(int position) {
        currentIndex = position;
        notifyDataSetChanged();
    }

    public void updateItemView() {
        notifyDataSetChanged();
    }

    public interface OnItemClickLitener {
        void onItemClick(View view, int position);
    }

    public void setOnItemClickLitener(OnItemClickLitener onItemClickLitener) {
        this.onItemClickLitener = onItemClickLitener;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        UserViewHolder userViewHolder = new UserViewHolder(LayoutInflater.from(context).inflate(R.layout
                .login_dinner_user_item, null));
        return userViewHolder;
    }

    @Override
    public void onBindViewHolder(final UserViewHolder userViewHolder, int position) {
        if (null != list || list.size() != 0) {
            userViewHolder.login_user_username.setText(list.get(position).fsUserName);
            // 如果设置了回调，则设置点击事件
            if (onItemClickLitener != null) {
                userViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int pos = userViewHolder.getLayoutPosition();
                        onItemClickLitener.onItemClick(userViewHolder.itemView, pos);
                    }
                });
            }

            if (currentIndex == position) {
                /*ScaleAnimation scaleAnimation = new ScaleAnimation(1, 1.1f, 1, 1.1f, Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f);
                scaleAnimation.setDuration(300);
                scaleAnimation.setFillAfter(false);
                userViewHolder.login_user_rl.startAnimation(scaleAnimation);*/

                userViewHolder.login_user_ll.setSelected(true);
                userViewHolder.login_user_username.setSelected(true);
            } else {
                //userViewHolder.login_user_left.setImageResource(R.drawable.sl_left_normal);
                userViewHolder.login_user_ll.setSelected(false);
                userViewHolder.login_user_username.setSelected(false);
            }
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class UserViewHolder extends ViewHolder {

        TextView login_user_username;
        RelativeLayout login_user_rl;
        LinearLayout login_user_ll;
        //ImageView login_user_left;
        //ImageView ivChose;

        public UserViewHolder(View itemView) {
            super(itemView);
            login_user_username = (TextView) itemView.findViewById(R.id.login_user_username);
            login_user_rl = (RelativeLayout) itemView.findViewById(R.id.login_user_rl);
            login_user_ll = (LinearLayout) itemView.findViewById(R.id.login_user_ll);
            //login_user_left = (ImageView) itemView.findViewById(R.id.iv_login_user_left);
            //ivChose = (ImageView) itemView.findViewById(R.id.iv_login_chose);
        }
    }
}
