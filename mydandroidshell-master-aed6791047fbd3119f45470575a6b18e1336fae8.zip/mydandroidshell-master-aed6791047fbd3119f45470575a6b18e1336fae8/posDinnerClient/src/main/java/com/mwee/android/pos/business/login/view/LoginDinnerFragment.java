package com.mwee.android.pos.business.login.view;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.constants.HostConstant;
import com.mwee.android.pos.business.login.ClientInfoCollect;
import com.mwee.android.pos.business.login.component.LoginProcess;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.business.setting.view.AdminSettingFragment;
import com.mwee.android.pos.business.shift.ShiftPresenter;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.business.sync.DataSyncLoadingDialog;
import com.mwee.android.pos.business.viceshow.ViceShowConnector;
import com.mwee.android.pos.client.db.ClientDBUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.idcard.IDCardListener;
import com.mwee.android.pos.component.idcard.IDCardReader;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.login.LoginToCenterForDinnerResponse;
import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ShopDBUtils;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.mw.LuaConfigProcess;
import com.mwee.android.pos.system.InspectActivity;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.DM;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.PinyinUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.OEM;
import com.mwee.android.tools.ShellUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.android.tools.log.LogUpload;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * 登录页面
 * Created by ZM on 16/9/25.
 *
 * @author ZM
 */
public class LoginDinnerFragment extends BaseFragment implements IDriver {

    public static final String TAG = "logindinnerfragment";
    private LoginDinnerUserAdapter loginUserAdapter;
    private EditText loginAccount, loginPwd;
    private View viewLoginCheck;
    private UserDBModel currentUserDBModel = null;

    private TextView tv_dinner_remind;
    private TextView tv_dinner_business_date;

    private TextView mSynchronize;
    private TextView tv_dinner_login_version_update;

    //用户信息数据
    private List<UserDBModel> userDBModels = new ArrayList<>();
    /**
     * 班别表数据
     */
    private List<DataModel> shiftList = new ArrayList<>();

    private ArrayMap<String, List<UserDBModel>> mSortUsers = new ArrayMap<>();

    private Drawable mUpdate_icon;
    private Drawable checkUpdateIcon;

    private ShiftPresenter mShiftPresenter;

    private DataSyncLoadingDialog mSyncDialog;

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.login_dinner_fragment_layout, container, false);
        initUI(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        checkUpdate();
        checkRisk();
        loadData();
        BusinessExecutor.executeNoWait(() -> {
            getNotices();
            return null;
        });
    }


    /**
     * 获取未读公告
     * ----仅业务中心提示
     */
    private void getNotices() {
        if (ClientBindProcessor.isCurrentHostMain()) {
            LoginProcess.getLastNotice(LoginDinnerFragment.this, -1, 0, "", null);
        }
    }

    /**
     * 检查版本更新
     */
    public void checkUpdate() {
        try {
            boolean isNeedUpdate = DriverBus.call("login/checkUpdate", getActivityWithinHost());
            if (isNeedUpdate) {
                showCheckUpdateIcon();
            } else {
                hideCheckUpdateIcon();
            }

            // 检测lua脚本
            LuaConfigProcess.getInstance().checkCache();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static long lastCheck = 0;

    /**
     * 检查可能存在的风险
     */
    private void checkRisk() {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                checkSunMiOsVersion();
                return null;
            }
        });

    }

    /**
     * 检测商米的版本是否是存在bug的版本
     */
    private void checkSunMiOsVersion() {
        if (lastCheck == 0 || ((SystemClock.elapsedRealtime() - lastCheck) > 1000 * 60 * 60 * 2)) {
            lastCheck = SystemClock.elapsedRealtime();
            try {
                if (OEM.isSunmiT1()) {
                    ShellUtil.CommandResult checkVersionCodeResult = ShellUtil.execCommand("getprop 'ro.version.sunmi_versioncode'", false, true);
                    if (checkVersionCodeResult.result == 0) {
                        int versionCode = StringUtil.toInt(checkVersionCodeResult.responseMsg, 57);
                        if (versionCode < 57) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    DialogManager.showSingleDialog(LoginDinnerFragment.this, R.string.error_sumi_os_version, R.string.tips_all_right);
                                }
                            });
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    BaseDialogFragment changeBusinessDielog;

    /**
     * 检查营业日期是否正确
     */
    private void checkBusinessDate(boolean isFinishedBiz) {
        final String businessDate = AppCache.getInstance().businessDate;
        if (TextUtils.isEmpty(businessDate)) {
            return;
        }
        final String currentDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        boolean wrongDate = false;
        if (DateUtil.compareDate(currentDate, "2017-09-01", "yyyy-MM-dd") > 0) {
            wrongDate = true;
        }
        //已打烊的，或者副站点，就不判断营业日期了
        if (!isFinishedBiz && ClientBindProcessor.isCurrentHostMain()) {
            if (!wrongDate && DateUtil.compareDate(businessDate, "2017-06-15", "yyyy-MM-dd") > 0) {
                wrongDate = true;
            }
            if (!wrongDate && DateUtil.compareDate(businessDate, currentDate, "yyyy-MM-dd") != 0) {
                wrongDate = true;
            }
        }

        if (wrongDate && changeBusinessDielog == null) {
            LogUtil.log("营业日期变了");
            Date dateBusiness = DateUtil.getData(businessDate, "yyyy-MM-dd");
            Date dateCurrent = DateUtil.getData(currentDate, "yyyy-MM-dd");
            String msg = String.format(getString(R.string.error_wring_business_date), dateBusiness, dateBusiness);
            String leftHint = String.format(getString(R.string.login_btnHint), dateBusiness, dateBusiness);
            String rightHint = String.format(getString(R.string.login_btnHint), dateCurrent, dateCurrent);
            View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_login_date_error_hint, null);
            ((TextView) dialogView.findViewById(R.id.tv_dialog_msg)).setText(msg);
            ((TextView) dialogView.findViewById(R.id.tv_left_hint)).setText(leftHint);
            ((TextView) dialogView.findViewById(R.id.tv_right_hint)).setText(rightHint);
            dialogView.findViewById(R.id.ll_dialog_left).setOnClickListener(v -> {
                if (changeBusinessDielog != null) {
                    changeBusinessDielog.dismissSelf();
                }
                changeBusinessDielog = null;
            });
            dialogView.findViewById(R.id.ll_dialog_right).setOnClickListener(v -> {
                if (changeBusinessDielog != null) {
                    changeBusinessDielog.dismissSelf();
                }
                final Progress progress = ProgressManager.showProgressUncancel(LoginDinnerFragment.this, R.string.login_shop_closing);
                mShiftPresenter.doClose(new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        progress.dismiss();
                        changeBusinessDielog = null;
                        if (result) {
                            ToastUtil.showToast(R.string.login_shop_closed);
                        } else {
                            DialogManager.showSingleDialog(LoginDinnerFragment.this, info, getString(R.string.i_see));
                        }
                    }
                });
            });
            changeBusinessDielog = DialogManager.showCustomDialog(this, dialogView, TAG);

//            changeBusinessDielog = DialogManager.showExecuteDialog(this, hint, getString(R.string.login_not_close), getString(R.string.login_close), new DialogResponseListener() {
//                @Override
//                public void response() {
//                    final Progress progress = ProgressManager.showProgressUncancel(LoginDinnerFragment.this, R.string.login_shop_closing);
//                    mShiftPresenter.doClose(new IResult() {
//                        @Override
//                        public void callBack(boolean result, String info) {
//                            progress.dismiss();
//                            changeBusinessDielog = null;
//                            if (result) {
//                                ToastUtil.showToast(R.string.login_shop_closed);
//                            } else {
//                                DialogManager.showSingleDialog(LoginDinnerFragment.this, info, getString(R.string.i_see));
//                            }
//                        }
//                    });
//                }
//            }, new DialogResponseListener() {
//                @Override
//                public void response() {
//                    changeBusinessDielog = null;
//                }
//            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @DrivenMethod(uri = TAG + "/dataSyncProgress", UIThread = true)
    public void dataSyncProgress(String progress, String tag) {
        if (Integer.parseInt(progress) < 0) {
            dataSyncFailed("-1", "同步失败");
            return;
        }
        if (mSyncDialog == null) {
            mSyncDialog = new DataSyncLoadingDialog();
        }
        if (!mSyncDialog.isAdded()) {
            DialogManager.showCustomDialog(getActivityWithinHost(), mSyncDialog, "");
        }
        if (mSyncDialog != null && mSyncDialog.isAdded()) {
            mSyncDialog.setParams(progress, tag);
        }
    }

    @DrivenMethod(uri = TAG + "/dataSyncFailed", UIThread = true)
    public void dataSyncFailed(String code, String message) {
        if (mToast == null) {
            mToast = ToastUtil.showToast(message);
        } else {
            mToast.setText(message);
            mToast.show();
        }
        if (mSyncDialog != null) {
            mSyncDialog.dismiss();
        }
    }

    //显示更新
    @DrivenMethod(uri = TAG + "/showUpdate", UIThread = true)
    public void showUpdate() {
        mUpdate_icon.setBounds(0, 0, mUpdate_icon.getMinimumWidth(), mUpdate_icon.getMinimumHeight());
        mSynchronize.setCompoundDrawables(mUpdate_icon, null, null, null); //设置左图标
        // 自动触发同步云端数据
        ActionLog.addLog("登录页：自动触发同步数据", ActionLog.USER_ACTION_TRACE);
        autoSynData();
    }

    private Toast mToast;

    //隐藏更新
    @DrivenMethod(uri = TAG + "/hideUpdate", UIThread = true)
    public void hideUpdate() {
        mSynchronize.setCompoundDrawables(null, null, null, null);
        if (mSyncDialog != null) {
            mSyncDialog.dismiss();
        }
        if (mToast == null) {
            mToast = ToastUtil.showToast(R.string.tips_sync_data_success);
        } else {
            mToast.setText(R.string.tips_sync_data_success);
            mToast.show();
        }
    }

    public void hideUpdateWithoutToast() {
        mSynchronize.setCompoundDrawables(null, null, null, null);
    }

    //显示升级提示符号
    public void showCheckUpdateIcon() {
        checkUpdateIcon.setBounds(0, 0, checkUpdateIcon.getMinimumWidth(), checkUpdateIcon.getMinimumHeight());
        tv_dinner_login_version_update.setCompoundDrawables(checkUpdateIcon, null, null, null); //设置左图标
    }

    //隐藏升级提示符号
    public void hideCheckUpdateIcon() {
        tv_dinner_login_version_update.setCompoundDrawables(null, null, null, null);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ServerConnector.getInstance().removeCallback("biz/loadDataFromCenterWithHostId");
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
        loginAccount.requestFocus();
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            loginAccount.requestFocus();
            getNotices();
        }
    }

    private void initUI(final View view) {
        LinearLayout loginLayout = (LinearLayout) view.findViewById(R.id.loginLayout);
        mShiftPresenter = new ShiftPresenter();
        TextView tvHost = (TextView) view.findViewById(R.id.tv_current_host);
        showHostInfo(tvHost);

        int widthPixels = DM.getWidthPixels();
        ViewGroup.LayoutParams loginLayoutLayoutParams = loginLayout.getLayoutParams();
        loginLayoutLayoutParams.width = widthPixels / 3;
        loginLayout.setLayoutParams(loginLayoutLayoutParams);

        mUpdate_icon = ViewToolsUtil.getDrawable(R.drawable.bg_circle_update);
        checkUpdateIcon = ViewToolsUtil.getDrawable(R.drawable.undeal);

        loginAccount = (EditText) view.findViewById(R.id.et_loin_account);
        loginPwd = (EditText) view.findViewById(R.id.et_login_pwd);

        //ID卡监听器的默认EditText
        //IDcard的读写监听器
        IDCardReader idCardReader = new IDCardReader();
        idCardReader.readView(loginPwd);
        idCardReader.readView(loginAccount);
        idCardReader.setListener(new IDCardListener() {
            @Override
            public void readValue(String value) {
                if (!TextUtils.isEmpty(value)) {
                    LogUtil.log("idcard value=" + value);
                    doLogin(1, value, "", "", "");
                }
            }
        });

        viewLoginCheck = view.findViewById(R.id.ll_login_check);
        tv_dinner_business_date = (TextView) view.findViewById(R.id.tv_dinner_business_date);

        tv_dinner_remind = (TextView) view.findViewById(R.id.tv_dinner_remind);
        mSynchronize = (TextView) view.findViewById(R.id.tv_dinner_login_syn);
        tv_dinner_login_version_update = (TextView) view.findViewById(R.id.tv_dinner_login_version_update);
        if (!BaseConfig.isProduct()) {
            view.findViewById(R.id.dev).setVisibility(View.VISIBLE);
            view.findViewById(R.id.dev).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    UIHelp.startDevelopActivity(getActivityWithinHost());
                }
            });
            view.findViewById(R.id.systemCheck).setVisibility(View.VISIBLE);
            view.findViewById(R.id.systemCheck).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(getActivityWithinHost(), InspectActivity.class));
                }
            });
        }

        TextView tv_dinner_notice = (TextView) view.findViewById(R.id.tv_dinner_notice);

        if (ClientBindProcessor.isCurrentHostMain()) { //公告只有业务中心可操作
            tv_dinner_notice.setVisibility(View.VISIBLE);
        } else {
            tv_dinner_notice.setVisibility(View.GONE);
        }


        if (TextUtils.equals("1", ClientMetaUtil.getSettingsValueByKey(META.UPDATE_NOTIFY))) {
            showUpdate();
        } else {
            hideUpdateWithoutToast();
        }

        //TextView tv_dinner_login_version_update = (TextView) view.findViewById(R.id.tv_dinner_login_version_update);
        tv_dinner_login_version_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActionLog.addLog("登录页->点击了版本检测", "", "", ActionLog.SS_MORE_JOIN, "");
                checkUpdate();
            }
        });

        RecyclerView mLoginAccount = (RecyclerView) view.findViewById(R.id.login_dinner_recyleview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContextWithinHost());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mLoginAccount.setLayoutManager(linearLayoutManager);
        loginUserAdapter = new LoginDinnerUserAdapter(getContextWithinHost(), userDBModels);
        mLoginAccount.setAdapter(loginUserAdapter);

        LinearLayoutManager indexManager = new LinearLayoutManager(getContextWithinHost());
        indexManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        loginUserAdapter.setOnItemClickLitener(onItemClickLitener);
        loginPwd.addTextChangedListener(textWatcher);
        tv_dinner_notice.setOnClickListener(click);
        tv_dinner_remind.setOnClickListener(click);
        mSynchronize.setOnClickListener(click);
        view.findViewById(R.id.tv_ip_set).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActionLog.addLog("登录界面->点击了管理员设置", ActionLog.LOGIN);
                AdminSettingFragment adminSettingFragment = new AdminSettingFragment();
                FragmentController.addFragmentNoHide(getActivityWithinHost(), adminSettingFragment, R.id.login_fragment_container);
            }
        });
        loginAccount.requestFocus();
    }

    LoginDinnerUserAdapter.OnItemClickLitener onItemClickLitener = new LoginDinnerUserAdapter.OnItemClickLitener() {
        @Override
        public void onItemClick(View view, int position) {
            if (ButtonClickTimer.canClick(view) || loginUserAdapter.currentIndex != position) {
                loginUserAdapter.selection(position);
                UserDBModel userDBModel = userDBModels.get(position);
                currentUserDBModel = userDBModel;
                loginPwd.setText("");
                loginAccount.setText(userDBModel.fsUserName);
                loginPwd.requestFocus();
                KeyboardManager.showSoftInput(loginPwd);
            }
        }
    };

    private void refreshShopStatus(int shopStatus) {
        TextView shopstate = (TextView) rootView.findViewById(R.id.shopstate);
        shopstate.setText(shopStatus == HostStatus.FINISH ? R.string.login_shop_closed : R.string.login_shop_woking);
    }

    /**
     * 密码输入框监听
     */
    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            viewLoginCheck.setVisibility(View.GONE);
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (s.length() == 0) {
                viewLoginCheck.setVisibility(View.INVISIBLE);
                return;
            }
            String loginInputName = loginAccount.getText().toString().trim();
            String loginInputPwd = loginPwd.getText().toString().trim();
            for (UserDBModel userDBModel : userDBModels) {
                if (userDBModel.fsUserName.equals(loginInputName)) {
                    currentUserDBModel = userDBModel;
                    break;
                }
            }
            //登录名或者登录的id
            if (currentUserDBModel != null && (TextUtils.equals(currentUserDBModel.fsUserName.trim(), loginInputName) || TextUtils.equals(currentUserDBModel.fsUserId.trim(), loginInputName))) {
                if (loginInputPwd.length() == currentUserDBModel.fsPwd.length()) {
                    if (currentUserDBModel.fsPwd.equals(loginInputPwd)) {
                        KeyboardManager.hideSoftInput(loginPwd);
                        doLogin(0, "", currentUserDBModel.fsUserId, loginInputPwd, currentUserDBModel.fsUserName);
                    } else {
                        viewLoginCheck.setVisibility(View.VISIBLE);
                    }
                }
                if (loginInputPwd.length() > currentUserDBModel.fsPwd.length()) {
                    viewLoginCheck.setVisibility(View.VISIBLE);
                }

            } else {
                viewLoginCheck.setVisibility(View.VISIBLE);
            }
        }
    };

    private void loadData() {
        final Progress progress = ProgressManager.showProgress(LoginDinnerFragment.this, R.string.tips_loding_data);
        LoginProcess.getAlllLoginData(new SocketCallback<GetLoginDataResponse>() {
            @Override
            public void callback(SocketResponse<GetLoginDataResponse> response) {
                progress.dismiss();
                if (response.code == SocketResultCode.SUCCESS) {
                    AppCache.getInstance().updateBusinessDate(response.data.businessDate);
                    refreshShopStatus(response.data.shopStatus);
                    refreshLoginUserData(response.data.userDBModels);
                    checkBusinessDate(response.data.shopStatus == HostStatus.FINISH);
                } else if (response.code == SocketResultCode.VERSION_LOW) {
                    DialogManager.showExecuteDialog(LoginDinnerFragment.this, response.message, R.string.tips_cancel, R.string.tips_upgrade_now, new DialogResponseListener() {
                        @Override
                        public void response() {
                            checkUpdate();
                        }
                    });
                } else {
                    if (LoginDinnerFragment.this.isFragmentAlive()) {
                        String msg = response.message;
                        if (response.code == SocketResultCode.VERSION_HIGH &&
                                ClientBindProcessor.isCurrentHostMain()) {
                            msg = GlobalCache.getContext().getString(R.string.serr_host_version_low);
                        }

                        DialogManager.showExecuteDialog(LoginDinnerFragment.this, String.format("%1s：%2s", getString(R.string.error_failed_get_data), msg), R.string.tips_cancel, R.string.tips_retry, new DialogResponseListener() {
                            @Override
                            public void response() {
                                loadData();
                            }
                        });
                    }
                }
            }
        });

    }

    private void refreshLoginUserData(List<UserDBModel> userDBModelList) {
        if (ListUtil.isEmpty(userDBModelList)) {
            userDBModelList = new ArrayList<>();
        }
        userDBModels.clear();
        userDBModels.addAll(userDBModelList);

        initGroup();

        if (loginUserAdapter != null) {
            loginUserAdapter.currentIndex = -1;
        }
        if (loginAccount != null) {
            loginAccount.setText("");
            loginPwd.setText("");
            loginAccount.requestFocus();
        }

        refreshLoginDinnerData(SocketResultCode.SUCCESS);
    }


    /**
     * 用户名，拼音首字母分组
     */
    private void initGroup() {
        mSortUsers.clear();
        Collections.sort(userDBModels, new PinyinComparator());
        for (UserDBModel model : userDBModels) {
            String shortName = PinyinUtil.getFirstWordPinyin(model.fsUserName);
            if (!TextUtils.isEmpty(shortName)) {
                String first = shortName.substring(0, 1);
                if (mSortUsers.containsKey(first)) {
                    List<UserDBModel> users = mSortUsers.get(first);
                    users.add(model);
                } else {
                    List<UserDBModel> users = new ArrayList<>();
                    users.add(model);
                    mSortUsers.put(first, users);
                }
            }
        }
    }

    View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if (!ButtonClickTimer.canClick()) {
                return;
            }

            switch (v.getId()) {
                case R.id.tv_dinner_remind:
                    break;
                case R.id.tv_dinner_notice:  //查看公告列表
                    LoginProcess.showAllNotice(LoginDinnerFragment.this);
                    break;
                case R.id.tv_dinner_login_syn: {
                    ActionLog.addLog("登录页：手动点击同步数据", ActionLog.USER_ACTION_TRACE);
                    autoSynData();
                    break;
                }
                default:
                    break;
            }

        }
    };

    /**
     * 同步云端数据
     */
    private void autoSynData() {
//        LocalDataProcessorForDinner.callUploadToCloud(); // 这个逻辑放到了业务中心
        loadDataFromCenter();
    }

    private void loadDataFromCenter() {
        if (mSyncDialog == null) {
            mSyncDialog = new DataSyncLoadingDialog();
        }
        if (!mSyncDialog.isAdded()) {
            DialogManager.showCustomDialog(getActivityWithinHost(), mSyncDialog, "");
        }
        if (!ClientBindProcessor.isCurrentHostMain()) {  //副站点同步业务中心数据
            DriverBus.call("login/sync_data_from_center", LoginDinnerFragment.this, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (mSyncDialog != null) {
                        mSyncDialog.dismiss();
                    }
                    if (TextUtils.isEmpty(info)) {
                        ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
                        dataSyncProgress("100", IProgressCallback.TAG_SYNC_DATA_FROM_CENTER);
                        hideUpdate();
                        loadData();
                        APPConfig.fiWorkMode = ShopDBUtils.queryWorkMode(AppCache.getInstance().fsShopGUID);
                    } else {
                        dataSyncFailed("-1", info);
//                        ToastUtil.showToast(info);
                    }
                }
            });
            return;
        } else {  //业务中心同步后台数据
            ServerConnector.getInstance().sendExecute(new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (mSyncDialog != null) {
                        mSyncDialog.dismiss();
                    }
                    if (TextUtils.isEmpty(info)) {
                        ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
                        hideUpdate();
                        loadData();
                        //更新门店模式
                        LoginProcess.loadWorkMode(new ResultCallback<Integer>() {
                            @Override
                            public void onSuccess(Integer data) {
                                APPConfig.fiWorkMode = data;
                                ShopDBUtils.updateWorkMode(data);
                            }
                        });
                    } else {
                        ToastUtil.showToast(info);
                    }
                }
            }, "biz/loadDataFromCenterWithHostId", AppCache.getInstance().currentHostId);
        }
    }

    private void doLogin(final int loginWay, final String fsiccardcode, final String fsUserId, final String fsPwd, final String fsUserName) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.login_logining);
        LoginProcess.doLogin(fsUserId, fsPwd, fsiccardcode, fsUserName, AppCache.getInstance().currentHostId, loginWay, new ConCallBack<LoginToCenterForDinnerResponse>() {
            @Override
            public void subCall(SocketResponse<LoginToCenterForDinnerResponse> socketResponse) {
                if (socketResponse.success()) {
//                    PrintApplication.initAllPrinter();
                    ClientMetaUtil.updateSettingsValueByKey(META.USER_SESSION, socketResponse.data.session);
                    //餐厅设置部分数据操作放到后台执行
                    SettingProcessor.updateSetting(socketResponse.data.dinnerLocalSettings, socketResponse.data.dinnerDBSettings);
                    if (!TextUtils.isEmpty(socketResponse.data.datas)) {
                        progress.updateText(R.string.login_loading_data);
                        String dbDatas = socketResponse.data.datas;

                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_CLIENT, dbDatas, socketResponse.data.newTimeTag);

                        if (!TextUtils.isEmpty(dbDatas)) {
                            AppCache.getInstance().refresh();
                        }
                    }
                    AppCache.getInstance().updateCouponBargain(socketResponse.data.couponBargainList);

                    //登录后刷新估清状态
                    DriverBus.call("login/refresh_menu_unit");
                    ViceShowConnector.getInstance().init(GlobalCache.getContext());
                    LogUpload.updateSessoin(ClientMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID));
                    LogUpload.setHost(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
                    LogUtil.setOnlineDebugMode("1".equals(ClientMetaUtil.getConfig(META.XMPP_BBOX, "0")));
                    progress.updateText(R.string.login_logining);
                    ClientInfoCollect.initInfoCollect();
                }
            }

            @Override
            public void callback(final SocketResponse<LoginToCenterForDinnerResponse> response) {
                if (response == null) {
                    ToastUtil.showToast(R.string.login_failed);
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    loginPwd.setText("");
                    ViceShowConnector.getInstance().startPlay();

                    if (response.data == null || response.data.loginUser == null) {
                        ToastUtil.showToast(R.string.login_failed);
                        return;
                    }
                    AppCache.getInstance().userDBModel = response.data.loginUser;
                    currentUserDBModel = AppCache.getInstance().userDBModel;

                    if (TextUtils.isEmpty(response.data.currentSectionId)) {
                        ToastUtil.showToast(R.string.error_login_section);
                        return;
                    }
                    shiftList.clear();
                    if (response.data.shiftList != null) {
                        shiftList.addAll(response.data.shiftList);
                    }
                    progress.dismiss();
                    if (!TextUtils.isEmpty(AppCache.getInstance().businessDate)) {
                        if (TextUtils.equals(response.data.businessDate, AppCache.getInstance().businessDate)) {//判断业务中心返回的营业日期是否与本地营业日期相等
                            jumtToNext(response.data.collectMoney, response.data.openOrder);
                        } else {//弹出营业日期校正窗口
                            DialogManager.showSingleWithoutCancelable(getActivityWithinHost(), getString(R.string.login_business_date_fixed, ":" + response.data.businessDate),
                                    new DialogResponseListener() {
                                        @Override
                                        public void response() {
                                            AppCache.getInstance().updateBusinessDate(response.data.businessDate);
                                            jumtToNext(response.data.collectMoney, response.data.openOrder);
                                        }
                                    });
                        }
                    } else {//当前站点的营业日期为空
                        AppCache.getInstance().updateBusinessDate(response.data.businessDate);
                        jumtToNext(response.data.collectMoney, response.data.openOrder);
                    }

                } else {
                    if (response.code == -1) {//主站点没有营业
                        ToastUtil.showToast(response.message);
                    } else if (response.code == 202 || response.code == 203) {  //IC卡错误、账户名称错误、密码错误或者账号被禁用
                        loadData();
                        ToastUtil.showToast(response.message);
                    } else if (response.code == 204
                            && !ClientBindProcessor.isCurrentHostMain()) {  //站点被删除--若当前站点是业务中心则忽略
                        DialogManager.showExecuteDialog(LoginDinnerFragment.this, R.string.error_host_cannot_use, R.string.tips_cancel, R.string.tips_rebind, new DialogResponseListener() {
                            @Override
                            public void response() {
                                // 重新指定站点
                                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, "");
                                UIHelp.reLaunch(getActivityWithinHost());
                                getActivityWithinHost().finish();
                            }
                        });
                    } else if (response.code == SocketResultCode.VERSION_LOW) {
                        DialogManager.showExecuteDialog(LoginDinnerFragment.this, response.message, R.string.tips_cancel, R.string.tips_upgrade_now, new DialogResponseListener() {
                            @Override
                            public void response() {
                                checkUpdate();
                            }
                        });
                    } else if (response.code == SocketResultCode.SHOP_DATA_EXPIRED) {
                        ToastUtil.showToast(response.message);
                        loadData();
                    } else if (response.code == SocketResultCode.VERSION_HIGH &&
                            ClientBindProcessor.isCurrentHostMain()) {
                        response.message = GlobalCache.getContext().getString(R.string.serr_host_version_low);
                        ToastUtil.showToast(response.message);
                    } else {
                        ToastUtil.showToast(response.message);
                    }
                    progress.dismiss();
                }
            }
        });
    }

    private void refreshLoginDinnerData(int isSucess) {
        if (isSucess == SocketResultCode.SUCCESS) {
            tv_dinner_remind.setVisibility(View.GONE);
            refreshBusinessDate();
            loginUserAdapter.notifyDataSetChanged();
        } else {
            tv_dinner_remind.setVisibility(View.VISIBLE);
            tv_dinner_remind.setText(R.string.error_failed_get_data);
        }
    }

    private void jumtToNext(boolean collectMoney, boolean openOrder) {
        AppCache.getInstance().collectMoney = collectMoney;
        AppCache.getInstance().openOrder = openOrder;
        //登录之后，可能会刷新营业日期，所以这里必须刷新MenuCache

        ActionLog.waiterID = AppCache.getInstance().userDBModel.fsUserId;
        ActionLog.waiterName = AppCache.getInstance().userDBModel.fsUserName;
        ActionLog.addLog("登录成功", "", "", ActionLog.LOGIN, ActionLog.waiterID);

        if (collectMoney && !ListUtil.isEmpty(shiftList)) {
            //收银权限
            jumpToShift();
        } else {
            if (getActivityWithinHost() != null && isAdded()) {
                String orderModel = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, "");
                UIHelp.startMainDinnerActvity(getActivityWithinHost());
                getActivityWithinHost().finish();

            }
        }
    }

    private void jumpToShift() {
        if (getActivityWithinHost() != null && isAdded()) {//todo 网络请求返回后，界面没了，挂了
            ChooseShiftFragment shit = ChooseShiftFragment.newInstance(shiftList);
            FragmentController.addFragmentWithHide(getActivityWithinHost(), shit, R.id.login_fragment_container);
        }
    }

    public void refreshBusinessDate() {
        if (getHost() == null || !isAdded()) return;//解决 not attached to Activity 异常
        String businessDate = AppCache.getInstance().businessDate;
        if (TextUtils.isEmpty(businessDate)) {
            businessDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        }
        tv_dinner_business_date.setText(getString(R.string.login_business_date, businessDate));
    }

    /**
     * 显示站点信息
     */
    private void showHostInfo(TextView tvHost) {
        String hostType = "";
        if (ClientBindProcessor.isActived()) {
            if (ClientBindProcessor.isCurrentHostMain()) {
                hostType = getString(R.string.name_main);
            } else {
                hostType = getString(R.string.name_vice);
            }
        }
        HostDBModel hostDBModel = ClientDBUtil.getHostByID(AppCache.getInstance().fsShopGUID, AppCache.getInstance().currentHostId);
        String hostName;
        if (hostDBModel == null) {
            hostName = getString(R.string.name_host);
        } else {
            switch (hostDBModel.fiHostCls) {
                case HostConstant.ORDER_DISHES_HOST:
                    hostName = getString(R.string.name_host_menu);
                    break;
                case HostConstant.CASHIER_HOST:
                    hostName = getString(R.string.name_host_bill);
                    break;
                case HostConstant.FASTFOOD_HOST:
                    hostName = getString(R.string.name_host_fastfood);
                    break;
                case HostConstant.SUPER_HOST:
                    hostName = getString(R.string.name_host_super_bill);
                    break;
                default:
                    hostName = getString(R.string.name_host);
            }
        }
        String hostShow = String.format("%s:[%s][%s]", hostName, AppCache.getInstance().currentHostId, hostType);
        tvHost.setText(hostShow);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (loginPwd != null) {
            loginPwd.removeTextChangedListener(textWatcher);
        }
    }

    /**
     * 拼音排序
     */
    class PinyinComparator implements Comparator<UserDBModel> {
        @Override
        public int compare(UserDBModel o1, UserDBModel o2) {
            String shortName1 = PinyinUtil.getInitial(o1.fsUserName);
            String shortName2 = PinyinUtil.getInitial(o2.fsUserName);

            if (TextUtils.isEmpty(shortName1)) {
                return -1;
            } else {
                shortName1 = TextUtils.substring(shortName1, 0, 1);
            }

            if (TextUtils.isEmpty(shortName2)) {
                return 1;
            } else {
                shortName2 = TextUtils.substring(shortName2, 0, 1);
            }

            return shortName1.compareTo(shortName2);
        }
    }
}
