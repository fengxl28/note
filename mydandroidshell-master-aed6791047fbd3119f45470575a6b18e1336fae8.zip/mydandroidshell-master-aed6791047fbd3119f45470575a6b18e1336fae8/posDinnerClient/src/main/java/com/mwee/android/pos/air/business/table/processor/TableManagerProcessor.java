package com.mwee.android.pos.air.business.table.processor;

import android.text.TextUtils;

import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.air.business.table.api.TableManagerApi;
import com.mwee.android.pos.business.table.processor.TableBizHelper;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class TableManagerProcessor {

    public boolean dataChanged = false;

    /**
     * 所有餐区信息
     */
    public ArrayList<AirAreaManagerInfo> airAreaManagerInfoList = new ArrayList<>();

    /**
     * 餐区---不包含'全部'
     */
    public ArrayList<AirAreaManagerInfo> airAreaManagerInfoWhisoutAllList = new ArrayList<>();

    /**
     * 所有餐桌信息
     */
    public ArrayList<AirTableManageInfo> airTableManageInfoList = new ArrayList<>();
    /**
     * 正在展示的餐桌信息
     */
    public ArrayList<AirTableManageInfo> tableManageInfoToShowList = new ArrayList<>();


    /**
     * 被编辑的桌台
     */
    public MtableSimpleModel mtableDBModel;

    /**
     * 新增的桌台
     */
    public MtableSimpleModel inSertMtableDBModel;


    private IResult iResult;
    /**
     * 新增的区域信息
     */
    public MareaDBModel mareaDBModel;
    /**
     * 新增区域桌台的信息
     */
    public ArrayList<MtableSimpleModel> newTableDBModels;
    private IResponse iResponse = new IResponse<GetAllAreaAndTableResponse>() {
        @Override
        public void callBack(boolean result, int code, String msg, GetAllAreaAndTableResponse info) {

            if (result && info != null) {
                airAreaManagerInfoList.clear();
                airAreaManagerInfoList.addAll(info.airAreaManagerInfo);
                airTableManageInfoList.clear();
                airTableManageInfoList.addAll(info.airTableManageInfo);
                TableManagerProcessor.this.mareaDBModel = info.mareaDBModel;
//                TableManagerProcessor.this.newTableDBModels = info.newTableDBModels;
                TableManagerProcessor.this.newTableDBModels = TableBizHelper.convertMTableToSimple(info.newTableDBModels);

//                mtableDBModel = info.mtableDBModel;
                mtableDBModel = TableBizHelper.convertMTableToSimple(info.mtableDBModel);

                if (info.inSertMtableDBModel != null) {
//                    inSertMtableDBModel = info.inSertMtableDBModel;
                    inSertMtableDBModel = TableBizHelper.convertMTableToSimple(info.inSertMtableDBModel);
                }

                filterTable();
                filterArea();
                dataChanged = true;
            }
            if (iResult != null) {
                iResult.callBack(result, msg);
            }
        }
    };

    /**
     * 餐区下对应餐桌列表
     * key: fsmareaId
     */
    public HashMap<String, List<AirTableManageInfo>> airTableManageInfoMap = new HashMap<>();

    public void optAllAreaAndTable(final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.optAllAreaAndTable(new IResponse<GetAllAreaAndTableResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAreaAndTableResponse info) {

                if (result && info != null) {
                    airAreaManagerInfoList.clear();
                    airAreaManagerInfoList.addAll(info.airAreaManagerInfo);
                    airTableManageInfoList.clear();
                    airTableManageInfoList.addAll(info.airTableManageInfo);
                    filterTable();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });
    }

    /**
     * 更改选中区域
     *
     * @param selectAreaIndex
     */
    public void selectArea(int selectAreaIndex) {

        tableManageInfoToShowList.clear();

        if (ListUtil.isEmpty(airAreaManagerInfoList)) {
            return;
        }
        if (selectAreaIndex >= airAreaManagerInfoList.size() || selectAreaIndex < 0) {
            selectAreaIndex = 0;
        }

        AirAreaManagerInfo areaManagerInfo = airAreaManagerInfoList.get(selectAreaIndex);
        if (areaManagerInfo != null) {
            if (TextUtils.isEmpty(areaManagerInfo.fsMAreaId)) {
                tableManageInfoToShowList.addAll(airTableManageInfoList);
            } else {
                List<AirTableManageInfo> airTableManageInfos = airTableManageInfoMap.get(areaManagerInfo.fsMAreaId);
                if (!ListUtil.isEmpty(airTableManageInfos)) {
                    tableManageInfoToShowList.addAll(airTableManageInfos);
                }
            }
        }

    }


    private void filterArea() {
        airAreaManagerInfoWhisoutAllList.clear();
        airAreaManagerInfoWhisoutAllList.addAll(airAreaManagerInfoList);

        if (airAreaManagerInfoWhisoutAllList.size() > 0) {
            AirAreaManagerInfo airAreaManagerInfo = airAreaManagerInfoWhisoutAllList.get(0);
            if (TextUtils.equals(airAreaManagerInfo.fsMAreaId, "")) {
                airAreaManagerInfoWhisoutAllList.remove(0);
            }
        }


    }

    /**
     * 将桌台分组
     */
    private void filterTable() {
        airTableManageInfoMap.clear();

        for (AirTableManageInfo airTableManageInfo : airTableManageInfoList) {
            List<AirTableManageInfo> airTableManageInfos = airTableManageInfoMap.get(airTableManageInfo.fsmareaid);
            if (airTableManageInfos == null) {
                airTableManageInfos = new ArrayList<>();
                airTableManageInfoMap.put(airTableManageInfo.fsmareaid, airTableManageInfos);
            }
            airTableManageInfos.add(airTableManageInfo);
        }

    }

    /**
     * 新增区域
     *
     * @param areaName 区域名称
     * @param iResult
     */
    public void addArea(String areaName, boolean batchAddTable, int tableCount, int person, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.addArea(areaName, batchAddTable, tableCount, person, iResponse);
    }


    /**
     * 修改区域名称
     *
     * @param areaId   区域ID
     * @param areaName 区域名称
     * @param iResult
     */
    public void updateAreaName(String areaId, String areaName, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.updateAreaName(areaId, areaName, iResponse);
    }


    /**
     * 删除区域
     *
     * @param areaId  区域ID
     * @param iResult
     */
    public void deleteArea(String areaId, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.deleteArea(areaId, iResponse);
    }

    /**
     * 新增桌台
     *
     * @param areaId    区域ID
     * @param tableName 桌台名称
     * @param seats     桌位数
     * @param iResult
     */
    public void addTable(String areaId, String tableName, int seats, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.addTable(areaId, tableName, seats, iResponse);
    }

    /**
     * 修改桌台
     *
     * @param areaId     区域ID
     * @param fsmtableId 桌台ID
     * @param tableName  桌台名称
     * @param seats      桌位数
     * @param iResult
     */
    public void updateTable(String areaId, String fsmtableId, String tableName, int seats, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.updateTable(areaId, fsmtableId, tableName, seats, iResponse);
    }

    /**
     * 批量删除桌台
     *
     * @param tableIdList
     * @param iResult
     */
    public void batchDeleteTable(ArrayList<String> tableIdList, final IResult iResult) {
        this.iResult = iResult;
        TableManagerApi.batchDeleteTable(tableIdList, iResponse);
    }


}
