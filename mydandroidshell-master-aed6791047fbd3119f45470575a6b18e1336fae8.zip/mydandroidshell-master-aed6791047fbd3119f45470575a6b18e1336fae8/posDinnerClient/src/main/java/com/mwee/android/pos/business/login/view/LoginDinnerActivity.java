package com.mwee.android.pos.business.login.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.boot.BootDistribution;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.setting.view.AdminConfigFragment;
import com.mwee.android.pos.business.setting.view.AdminSettingFragment;
import com.mwee.android.pos.business.setting.view.LogSearchFragment;
import com.mwee.android.pos.business.sync.view.BizCenterConfigFragment;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ChannelUtil;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.koubei.KBLoginDinnerFragment;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by Liming on 16/9/13.
 */
public class LoginDinnerActivity extends BaseActivity implements IDriver {
    private long lastClick = 0;
    public static final String TAG = "loginDinner";
    private BaseFragment fragment;

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinner_login);
        DriverBus.registerDriver(this);

        if (!TextUtils.isEmpty(AppCache.getInstance().currentHostId)) {
            NotifyToServer.sendExcuteMsg("bizsync/clearUser", AppCache.getInstance().currentHostId);
        }
       /* if (APPConfig.isMydKouBei()) {
            fragment = new KBLoginDinnerFragment();
        } else {
            fragment = new LoginDinnerFragment();
        }*/
        /**
         * 口碑渠道包 优先走口碑登录激活  普通渠道包 需要走这个按钮配置
         * 0/登录界面仅显示原账号密码登录
         * 1/客户端显示口碑版的开机启动画面，登录界面显示支付宝登录和账号密码登录
         *
         */
        if (ChannelUtil.isKouBei()  || (APPConfig.fiWorkMode == 1 && TextUtils.equals(ClientCommonDBUtil.getConfigWithDefault(DBOrderConfig.KB_LOGIN, "0"), "1"))) {
            fragment = new KBLoginDinnerFragment();
        } else {
            fragment = new LoginDinnerFragment();
        }
        FragmentController.addFragmentWithHide(getFragmentManagerWithinHost(), fragment, TAG, R.id.login_fragment_container, true);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (fragment instanceof LoginDinnerFragment) {
            ((LoginDinnerFragment) fragment).refreshBusinessDate();
        }

    }

    @Override
    public void onBackPressed() {
        if (closeLastSubPage()) {
            if ((SystemClock.elapsedRealtime() - lastClick) < 2000) {
                BootDistribution.exitApp(this);
                finish();
                return;
            }
            lastClick = SystemClock.elapsedRealtime();
            ToastUtil.showToast(R.string.exit_program);
        }
    }

    public boolean closeLastSubPage() {
        BaseFragment tempFragment = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.login_fragment_container);
        if (tempFragment.onKeyBack() || tempFragment instanceof LoginDinnerFragment || tempFragment instanceof KBLoginDinnerFragment) {
            return true;
        }
        if (tempFragment instanceof ChooseShiftFragment || tempFragment instanceof BizCenterConfigFragment
                || tempFragment instanceof AdminSettingFragment || tempFragment instanceof AdminConfigFragment
                || tempFragment instanceof LogSearchFragment) {
            FragmentController.showFragment(fragment);
            FragmentController.removeFragment(getFragmentManagerWithinHost(), tempFragment);
            return false;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
