package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/05/07.
 */

public class PayOpenStatus extends BusinessBean {
    /**
     * 0表示开通，1表示关闭
     */
    public int pay_status;

    /**
     * "weixin" //微信 "alipay"//支付宝
     */
    public String pay_type;

    public String msg = "";


    public PayOpenStatus() {
    }
}
