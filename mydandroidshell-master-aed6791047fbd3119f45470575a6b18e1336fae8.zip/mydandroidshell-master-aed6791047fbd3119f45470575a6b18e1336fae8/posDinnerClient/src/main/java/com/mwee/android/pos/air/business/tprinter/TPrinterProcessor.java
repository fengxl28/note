package com.mwee.android.pos.air.business.tprinter;

import android.text.TextUtils;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CTPrinter;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.tools.DateUtil;

/**
 * Created by zhangmin on 2017/10/12.
 */

public class TPrinterProcessor {


    public static void updateTPrintNameDeptWithHost(PrinterDBModel printerDBModel, boolean editorHostPrintNameRemove
            , boolean editorDept2PrintNameRemove, boolean editorDept3PrintNameRemove, final NormalListener listener) {

        MCon.c(CTPrinter.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {

                if (response.code != SocketResultCode.SUCCESS) {
                    ToastUtil.showToast(response.message);
                } else {
                    listener.callBack();
                }
            }
        }).updateTPrintNameDeptWithHost(printerDBModel, editorHostPrintNameRemove, editorDept2PrintNameRemove, editorDept3PrintNameRemove);

    }


    /**
     * 改变打印部门的切单方式
     *
     * @param fiIsOneItemCut
     */
    public static void updateTDeptItemCut(int fiIsOneItemCut) {

        MCon.c(CTPrinter.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.code != SocketResultCode.SUCCESS) {
                    ToastUtil.showToast(response.message);
                }
            }
        }).updateTDeptItemCut(fiIsOneItemCut);

    }


    /**
     * 构建一个临时Usb的打印机数据
     * 构建临时打印机不给主键  插入DB的时候给主键赋值
     *
     * @param
     * @return
     */
    public static PrinterDBModel buildUsbTempPrintDBModel(String name, String symol) {

        PrinterDBModel model = new PrinterDBModel();
        model.fiID = 0;
        //搜索的打印机 使用时间戳+usb打印机   添加的打印机使用usb打印机
        model.fsPrinterName = name + DateUtil.getCurrentTimeInMills() + "USB打印机";
        model.fsIP = "";
        model.fiIsMakePrn = 1;
        model.fsCommandType = "ESC";
        model.fiPrinterCls = 4;  //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS  小散项目目前支持网口和USB口
        model.fsStr1 = TextUtils.isEmpty(symol) ? "BYUSB-0" : symol; //"BYUSB-0";//--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fiInt1 = 0;
        model.fiPaperSize = 2;// 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = "";
        model.fsUpdateUserId = "";
        model.fsUpdateUserName = DateUtil.getCurrentTime();
        model.fsShopGUID = AppCache.getInstance().fsShopGUID;
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        return model;

    }


    /**
     * 构建一个临时的网络打印机数据
     *
     * @param ip
     * @return
     */
    public static PrinterDBModel buildNetTempPrintDBModel(String ip) {
        PrinterDBModel model = new PrinterDBModel();
        model.fiID = 0;
        model.fsPrinterName = ip + DateUtil.getCurrentTimeInMills() + "网络打印机";
        model.fsIP = ip;
        model.fiIsMakePrn = 1;
        model.fsCommandType = "ESC";
        model.fiPrinterCls = 1;  //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS  小散项目目前支持网口和USB口
        model.fsStr1 = "";//--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fiInt1 = 0;
        model.fiPaperSize = 2;// 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = "";
        model.fsUpdateUserId = "";
        model.fsUpdateUserName = DateUtil.getCurrentTime();
        model.fsShopGUID = AppCache.getInstance().fsShopGUID;
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        return model;

    }


    /**
     * 构建一个临时蓝牙的打印机数据
     *
     * @param name
     * @return
     */
    public static PrinterDBModel buildBootherTempPrintDBModel(String name, String macAddress) {

        PrinterDBModel model = new PrinterDBModel();
        model.fiID = 0;
        model.fsPrinterName = name + DateUtil.getCurrentTimeInMills() + "蓝牙打印机";
        model.fsIP = macAddress;
        model.fiIsMakePrn = 1;
        model.fsCommandType = "ESC";
        model.fiPrinterCls = 7;  //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS 7/蓝牙 小散项目目前支持网口和USB口
        model.fsStr1 = "";//--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fiInt1 = 0;
        model.fiPaperSize = 2;// 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = "";
        model.fsUpdateUserId = "";
        model.fsUpdateUserName = DateUtil.getCurrentTime();
        model.fsShopGUID = AppCache.getInstance().fsShopGUID;
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        return model;

    }


}
