package com.mwee.android.pos.business.dinner.widget;

import android.content.Context;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.mwee.android.pos.business.dinner.DishUtils;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.tools.LogUtil;

/**
 * 正餐点餐订单or菜品操作 布局容器
 * Created by qinwei on 2017/6/1.
 */

public class DinnerFoodOrderOperationLayout extends LinearLayout implements View.OnClickListener {
    public OnDinnerFoodOrderOperationClickListener listener;
    private Button mDinnerFoodOrderWaitBtn;//等叫
    private Button mDinnerFoodOrderDiscountBtn;//折扣优惠
    private Button mDinnerFoodOrderBatchBtn;//批量操作
    private Button mDinnerFoodOrderBatchRequestBtn;//批量要求
    private Button mDinnerFoodOrderReplacementBtn;//补单
    private Button mDinnerFoodOrderMenuCommitBtn;//下单
    private Button mDinnerFoodOrderMenuPrinterBtn;//重打点菜单
    private Button mDinnerFoodOrderPreBillPrinterBtn;//打印预结单
    private Button mDinnerFoodOrderPayBtn;//结帐
    private Button mDinnerFoodOrderNoteBtn;
    private DishCache mDishCache;
    private Button mDinnerFoodOrderRapidAllowBtn;
    private boolean showAgreeRapidButton;


    public DinnerFoodOrderOperationLayout(Context context) {
        super(context);
        initView(context);
    }

    public DinnerFoodOrderOperationLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }


    public DinnerFoodOrderOperationLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.widget_dinner_food_order_operation, this);
        mDinnerFoodOrderWaitBtn = findViewById(R.id.mDinnerFoodOrderWaitBtn);
        mDinnerFoodOrderDiscountBtn = findViewById(R.id.mDinnerFoodOrderDiscountBtn);
        mDinnerFoodOrderBatchBtn = findViewById(R.id.mDinnerFoodOrderBatchBtn);
        mDinnerFoodOrderBatchRequestBtn = findViewById(R.id.mDinnerFoodOrderBatchRequestBtn);
        mDinnerFoodOrderReplacementBtn = findViewById(R.id.mDinnerFoodOrderReplacementBtn);
        mDinnerFoodOrderMenuCommitBtn = findViewById(R.id.mDinnerFoodOrderMenuCommitBtn);
        mDinnerFoodOrderPreBillPrinterBtn = findViewById(R.id.mDinnerFoodOrderPreBillPrinterBtn);
        mDinnerFoodOrderMenuPrinterBtn = findViewById(R.id.mDinnerFoodOrderMenuPrinterBtn);
        mDinnerFoodOrderPayBtn = findViewById(R.id.mDinnerFoodOrderPayBtn);
        mDinnerFoodOrderRapidAllowBtn = findViewById(R.id.mDinnerFoodOrderRapidAllowBtn);
        mDinnerFoodOrderNoteBtn = findViewById(R.id.mDinnerFoodOrderNoteBtn);
        mDinnerFoodOrderRapidAllowBtn.setOnClickListener(this);
        mDinnerFoodOrderReplacementBtn.setOnClickListener(this);
        mDinnerFoodOrderWaitBtn.setOnClickListener(this);
        mDinnerFoodOrderDiscountBtn.setOnClickListener(this);
        mDinnerFoodOrderBatchBtn.setOnClickListener(this);
        mDinnerFoodOrderBatchRequestBtn.setOnClickListener(this);
        mDinnerFoodOrderMenuCommitBtn.setOnClickListener(this);
        mDinnerFoodOrderMenuPrinterBtn.setOnClickListener(this);
        mDinnerFoodOrderPreBillPrinterBtn.setOnClickListener(this);
        mDinnerFoodOrderPayBtn.setOnClickListener(this);
        mDinnerFoodOrderNoteBtn.setOnClickListener(this);
    }

    public void setShowAgreeRapidButton(boolean showAgreeRapidButton) {
        this.showAgreeRapidButton = showAgreeRapidButton;
    }

    public void initData(DishCache dishCache, OnDinnerFoodOrderOperationClickListener listener) {
        this.mDishCache = dishCache;
        this.listener = listener;
        refreshOperationBtnStatus();
    }

    public void refreshOperationBtnStatus() {
        if (mDishCache.antiPay) {//反结帐ui控制
            mDinnerFoodOrderWaitBtn.setEnabled(false);
            mDinnerFoodOrderBatchRequestBtn.setEnabled(false);
            mDinnerFoodOrderMenuCommitBtn.setText("加菜");
        } else {
            mDinnerFoodOrderWaitBtn.setEnabled(true);
            mDinnerFoodOrderBatchRequestBtn.setEnabled(true);
            mDinnerFoodOrderPreBillPrinterBtn.setVisibility(View.VISIBLE);
            mDinnerFoodOrderMenuCommitBtn.setText("下单");
        }

        //要求、等叫、下单按钮控制
        if (mDishCache.orderDishesCache.tempSelectedMenuList.size() > 0) {
            mDinnerFoodOrderWaitBtn.setEnabled(true);
            mDinnerFoodOrderMenuCommitBtn.setEnabled(true);
            mDinnerFoodOrderBatchRequestBtn.setEnabled(true);
        } else {
            mDinnerFoodOrderWaitBtn.setEnabled(false);
            mDinnerFoodOrderMenuCommitBtn.setEnabled(false);
            mDinnerFoodOrderBatchRequestBtn.setEnabled(false);
        }
        //补单按钮控制
        if (mDishCache.orderDishesCache.tempSelectedMenuList.size() > 0) {
            mDinnerFoodOrderReplacementBtn.setEnabled(true);
        } else {
            mDinnerFoodOrderReplacementBtn.setEnabled(false);
        }
        //预结单按钮控制
        if (mDishCache.order != null && mDishCache.order.originMenuList.size() > 0) {
            mDinnerFoodOrderPreBillPrinterBtn.setEnabled(true);
        } else {
            mDinnerFoodOrderPreBillPrinterBtn.setEnabled(false);
        }
        if (mDishCache.order == null && mDishCache.orderDishesCache.tempSelectedMenuList.isEmpty()) {
            mDinnerFoodOrderMenuPrinterBtn.setEnabled(false);
        } else {
            mDinnerFoodOrderMenuPrinterBtn.setEnabled(true);
        }


        //批量操作和优惠折扣按钮控制
        if (mDishCache.order != null) {
//            mDinnerFoodOrderDiscountBtn.setEnabled(true);
            mDinnerFoodOrderBatchBtn.setEnabled(true);
        } else {
//            mDinnerFoodOrderDiscountBtn.setEnabled(false);
            mDinnerFoodOrderBatchBtn.setEnabled(false);
        }
        //结帐按钮控制
        if (mDishCache.order == null) {
            mDinnerFoodOrderPayBtn.setEnabled(false);
        } else {
            mDinnerFoodOrderPayBtn.setEnabled(true);
        }

        //秒付拉单支付按钮控制
        if (showAgreeRapidButton) {
            mDinnerFoodOrderRapidAllowBtn.setVisibility(View.VISIBLE);
        } else {
            mDinnerFoodOrderRapidAllowBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        LogUtil.log("clicktime=" + SystemClock.elapsedRealtime());
        if (!ButtonClickTimer.canClick()) {
            return;
        }

        //不可修改的订单 只有结账按钮可以操作
        if (v.getId() != R.id.mDinnerFoodOrderPayBtn && !DishUtils.isSupportEditor(mDishCache.order)) {
            return;
        }

        switch (v.getId()) {
            case R.id.mDinnerFoodOrderBatchRequestBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onBatchRequestClick();
                }
                break;
            case R.id.mDinnerFoodOrderWaitBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onBatchWaitClick();
                }
                break;
            case R.id.mDinnerFoodOrderDiscountBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onBatchDiscountClick();
                }
                break;
            case R.id.mDinnerFoodOrderBatchBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onBatchOperationClick();
                }
                break;
            case R.id.mDinnerFoodOrderReplacementBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onOrderReplacementClick();
                }
                break;
            case R.id.mDinnerFoodOrderMenuCommitBtn:
                //下单
                listener.onOrderMenuCommitClick();
                break;
            case R.id.mDinnerFoodOrderMenuPrinterBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onPrinterMenuClick();
                }
                break;
            case R.id.mDinnerFoodOrderPreBillPrinterBtn:
                //打印预结账单
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onPrinterPreBillClick();
                }
                break;
            case R.id.mDinnerFoodOrderPayBtn:
                //结账
                listener.onPayClick();
                break;
            case R.id.mDinnerFoodOrderRapidAllowBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    listener.onRapidAllowClick();
                }
                break;
            case R.id.mDinnerFoodOrderNoteBtn:
                if (DishUtils.isSupportEditor(mDishCache.order)) {
                    //备注
                    listener.onOrderNote();
                }
                break;
            default:
                break;
        }
    }

    public interface OnDinnerFoodOrderOperationClickListener {
        /**
         * 批量要求操作
         */
        void onBatchRequestClick();

        /**
         * 批量等叫
         */
        void onBatchWaitClick();

        /**
         * 批量折扣
         */
        void onBatchDiscountClick();

        /**
         * 批量操作
         */
        void onBatchOperationClick();

        /**
         * 下单
         */
        void onOrderMenuCommitClick();

        /**
         * 打印预结单
         */
        void onPrinterPreBillClick();

        /**
         * 结帐
         */
        void onPayClick();

        /**
         * 补单
         */
        void onOrderReplacementClick();

        /**
         * 重打点菜单
         */
        void onPrinterMenuClick();

        /**
         * 允许秒付拉单支付
         */
        void onRapidAllowClick();

        /**
         * 添加备注
         */
        void onOrderNote();
    }
}
