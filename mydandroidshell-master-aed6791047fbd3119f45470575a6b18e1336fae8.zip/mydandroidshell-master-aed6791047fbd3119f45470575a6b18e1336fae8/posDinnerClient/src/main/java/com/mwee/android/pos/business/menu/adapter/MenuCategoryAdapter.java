package com.mwee.android.pos.business.menu.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DM;
import com.mwee.android.pos.util.ViewToolsUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chris on 16/9/19.
 */
public class MenuCategoryAdapter extends BaseAdapter {
    private Context mContext;
    public TextView headerView;
    public TextView lastView;
    public List<MenuTypeBean> categoryList = new ArrayList<>();
    private OnItemClickListener mOnItemClickListener;
    private int lastPosition = 0;


    public MenuCategoryAdapter(Context context, List<MenuTypeBean> firstNodeMap) {
        this.categoryList = firstNodeMap;
        this.mContext = context;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public View getHeaderView() {
        if (headerView == null) {
            headerView = new TextView(mContext);
            headerView.setText(R.string.tip_search);
            Drawable rightDrawable = mContext.getResources().getDrawable(R.drawable.ic_dish_search);
            rightDrawable.setBounds(0, 0, rightDrawable.getMinimumWidth(), rightDrawable.getMinimumHeight());
            headerView.setCompoundDrawablePadding((int) DM.dpToPx(5));
            headerView.setCompoundDrawables(rightDrawable, null, null, null);
            headerView.setPadding((int) DM.dpToPx(20), (int) DM.dpToPx(25), (int) DM.dpToPx(20), (int) DM.dpToPx(25));
            headerView.setGravity(Gravity.CENTER);
            headerView.setId(R.id.search_view);
            headerView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastPosition = -1;
                    setHeaderViewSelected();
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onClickHeader();
                    }
                }
            });
        }
        return headerView;
    }

    private void setHeaderViewSelected() {
        if (lastView != null) {
            ViewToolsUtil.setBackgroundResourceKeepPadding(lastView, 0);
            lastView.setTextColor(mContext.getResources().getColor(R.color.white));
        }
        if (headerView != null) {
            ViewToolsUtil.setBackgroundResourceKeepPadding(headerView, R.drawable.bg_category_item_checked);
            headerView.setTextColor(mContext.getResources().getColor(R.color.system_red));
        }
    }

    @Override
    public int getCount() {
        return categoryList.size();
    }

    @Override
    public Object getItem(int i) {
        return categoryList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        Holder holder;
        if (view == null) {
            view = View.inflate(mContext, R.layout.view_menu_category_item, null);
            holder = new Holder(view);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        holder.initData(position);
        if (lastPosition == position) {
            lastView = (TextView) view;
        }
        return view;
    }


    public class Holder implements View.OnClickListener {
        public TextView nameTv;
        private MenuTypeBean menuClsDBModel;
        private int position;

        public Holder(View convertView) {
            nameTv = (TextView) convertView;
        }

        public void initData(int position) {
            this.position = position;
            menuClsDBModel = categoryList.get(position);
            nameTv.setOnClickListener(this);
            nameTv.setText(menuClsDBModel.fsMenuClsName);
            if (position == lastPosition) {
                if (headerView != null) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(headerView, 0);
                    headerView.setTextColor(mContext.getResources().getColor(R.color.white));
                }
                ViewToolsUtil.setBackgroundResourceKeepPadding(nameTv, R.drawable.bg_category_item_checked);
                nameTv.setTextColor(mContext.getResources().getColor(R.color.system_red));
            } else {
                ViewToolsUtil.setBackgroundResourceKeepPadding(nameTv, 0);
                nameTv.setTextColor(mContext.getResources().getColor(R.color.white));
            }
        }

        @Override
        public void onClick(View v) {
            lastPosition = position;
            notifyDataSetChanged();
            if (mOnItemClickListener != null) {
                mOnItemClickListener.onItemClick(menuClsDBModel);
            }
        }
    }

    public interface OnItemClickListener {
        void onClickHeader();

        void onItemClick(MenuTypeBean model);
    }
}
