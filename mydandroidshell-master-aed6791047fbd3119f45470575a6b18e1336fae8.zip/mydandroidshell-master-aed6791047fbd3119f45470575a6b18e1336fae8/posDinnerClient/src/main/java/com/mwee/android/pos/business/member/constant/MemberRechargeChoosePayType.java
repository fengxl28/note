package com.mwee.android.pos.business.member.constant;

/**
 * 会员充值时用户选择支付方式的定义
 * Created by chris on 16/8/30.
 */
public class MemberRechargeChoosePayType {

    /**
     * 现金
     */
    public static final int CASH = 1;

    /**
     * 银联
     */
    public static final int UP = 2;

    /**
     * 在线支付
     */
    public static final int ALIPAY_OR_WECHAT = 3;

    /**
     * 支付宝
     */
    public static final int ALIPAY = 4;

    /**
     * 微信支付
     */
    public static final int WECHAT = 5;

}
