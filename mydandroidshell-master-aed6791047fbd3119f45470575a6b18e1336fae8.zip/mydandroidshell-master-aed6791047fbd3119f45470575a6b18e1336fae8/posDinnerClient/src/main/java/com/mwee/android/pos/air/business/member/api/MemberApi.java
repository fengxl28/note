package com.mwee.android.pos.air.business.member.api;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.air.business.member.entity.MemberBalanceRechargeRequest;
import com.mwee.android.pos.air.business.member.entity.MemberBalanceRechargeRequestBody;
import com.mwee.android.pos.air.business.member.entity.MemberCreate;
import com.mwee.android.pos.air.business.member.entity.MemberCreateRequestBody;
import com.mwee.android.pos.air.business.member.entity.MemberInfoUpdate;
import com.mwee.android.pos.air.business.member.entity.MemberInfoUpdateRequestBody;
import com.mwee.android.pos.air.business.member.entity.MemberLevelCreateRequest;
import com.mwee.android.pos.air.business.member.entity.MemberLevelCreateRequestBody;
import com.mwee.android.pos.air.business.member.entity.MemberLevelDeleteRequest;
import com.mwee.android.pos.air.business.member.entity.MemberLevelDeleteRequestBody;
import com.mwee.android.pos.air.business.member.entity.MemberPackageUpdateRequest;
import com.mwee.android.pos.air.business.member.entity.MemberPasswordUpdate;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberCardRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberConsumptionRecordingRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberLeverRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberLeverUpdateRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberRechargeRecordingRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberRuleQueryRequest;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberSocreGiftRuleUpdateRequest;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberApi {

    /**
     * 添加会员信息
     *
     * @param name     姓名
     * @param phone    手机号
     * @param birthday 出生日期
     * @param sex      性别
     * @param password 密码
     * @param callback
     */
    public static void loadMemberAdd(String name, String phone, String birthday, int sex, String password, int default_level, IExecutorCallback callback) {
        MemberCreate memberCreate = new MemberCreate();
        memberCreate.shop_id = StringUtil.toInt(AppCache.getInstance().fsShopGUID);
        memberCreate.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        memberCreate.name = name;
        memberCreate.mobile = phone;
        memberCreate.password = password;
        memberCreate.gender = sex;
        memberCreate.birthday = birthday;
        memberCreate.source = 10;
        memberCreate.default_level = default_level;
        MemberCreateRequestBody requestBody = new MemberCreateRequestBody();
        requestBody.platform_membercard_create = memberCreate;
        BusinessExecutor.execute(requestBody, callback);
    }

    public static void loadMemberAdd(String name, String phone, String birthday, int sex, String password, IExecutorCallback callback) {
        loadMemberAdd(name, phone, birthday, sex, password, 3, callback);
    }

    public static void loadBalanceRecharge(String card_no, String mobile, String price, String priceGift, IExecutorCallback callback) {
        MemberBalanceRechargeRequest recharge = new MemberBalanceRechargeRequest();
        recharge.card_no = card_no;
        recharge.change_present = StringUtil.toInt(priceGift);
        recharge.change_real = StringUtil.toInt(price);
        recharge.editor_mobile = mobile;
        recharge.shop_id = StringUtil.toInt(AppCache.getInstance().fsShopGUID);
        recharge.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        recharge.is_add = 1;
        MemberBalanceRechargeRequestBody requestBody = new MemberBalanceRechargeRequestBody();
        requestBody.crm_membercard_updateMemberAmount = recharge;
        BusinessExecutor.execute(requestBody, callback);
    }

    public static void loadUpdateMemberInfo(String card_no, String name, String phone, String birthday, int sex, String password, int level, IExecutorCallback callback) {
        MemberInfoUpdate memberUpdate = new MemberInfoUpdate();
        memberUpdate.shop_id = StringUtil.toInt(AppCache.getInstance().fsShopGUID);
        memberUpdate.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        memberUpdate.name = name;
        memberUpdate.editor_mobile = phone;
        memberUpdate.gender = sex;
        memberUpdate.birthday = birthday;
        memberUpdate.card_no = card_no;
        memberUpdate.level = level;

        MemberPasswordUpdate passwordUpdate = new MemberPasswordUpdate();
        passwordUpdate.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        passwordUpdate.card_no = card_no;
        passwordUpdate.password = password;
        MemberInfoUpdateRequestBody requestBody = new MemberInfoUpdateRequestBody();
        requestBody.crm_membercard_updateMemberBaseInfo = memberUpdate;
        //密码为空时候 不做请求
        if (TextUtils.isEmpty(password.trim())) {
            requestBody.third_membercard_setPassword = null;
        } else {
            requestBody.third_membercard_setPassword = passwordUpdate;
        }
        BusinessExecutor.execute(requestBody, callback);
    }


    /**
     * 获取会员积分规则 和 充值套餐规则
     *
     * @param callback
     */
    public static void loadShopMemberRule(IExecutorCallback callback) {

        AirMemberRuleQueryRequest request = new AirMemberRuleQueryRequest();
        BusinessExecutor.execute(request, callback);
    }

    /**
     * 更新会员积分规则
     *
     * @param is_score
     * @param cost_money_unit
     * @param increase_bonus
     * @param cost_bonus_unit
     * @param reduce_money
     * @param is_clear
     * @param clear_day
     * @param callback
     */
    public static void loadMemberScoreGiftRuleUpdate(String is_score, String cost_money_unit, String increase_bonus, String cost_bonus_unit, String reduce_money, String is_clear, String clear_day, IExecutorCallback callback) {

        AirMemberSocreGiftRuleUpdateRequest request = new AirMemberSocreGiftRuleUpdateRequest();
        request.is_score = is_score;
        request.cost_money_unit = new BigDecimal(cost_money_unit);
        request.increase_bonus = StringUtil.toInt(increase_bonus, 0);
        request.cost_bonus_unit = cost_bonus_unit;
        request.reduce_money = reduce_money;
        request.is_clear = is_clear;
        request.clear_day = clear_day;
        BusinessExecutor.execute(request, callback);
    }

    /**
     * 会员等级列表查询
     *
     * @param callback
     */
    public static void loadShopMemberLevelList(IExecutorCallback callback) {

        AirMemberLeverRequest request = new AirMemberLeverRequest();
        BusinessExecutor.execute(request, callback);
    }

    /**
     * 添加会员等级
     *
     * @param name
     * @param price
     * @param callback
     */
    public static void loadMemberLevelAdd(String name, String price, IExecutorCallback callback) {
        MemberLevelCreateRequest request = new MemberLevelCreateRequest();
        request.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        request.title = name;

        JSONObject upRule = new JSONObject();
        upRule.put("type", "1");//0=>按消费次数  1=>按消费金额  升级类型  2=>一次性充值，多个用,号隔开
        upRule.put("expense_amount", new BigDecimal(price));
        upRule.put("up_day", 730);
        request.up_rule = upRule.toJSONString();

        JSONObject downRule = new JSONObject();
        downRule.put("is_degrade", 0);//0=>不允许降级 1=>降级
        request.down_rule = downRule.toJSONString();

        JSONObject upReward = new JSONObject();//升级奖励
        upReward.put("is_reward", 0);//0=>不奖励 1奖励
        upReward.put("reward_coupon", "");
        upReward.put("reward_point", 0);
        request.up_reward = upReward.toJSONString();

        MemberLevelCreateRequestBody requestBody = new MemberLevelCreateRequestBody();
        requestBody.crm_membercard_addMemberLevel = request;
        BusinessExecutor.execute(requestBody, callback);
    }


    /**
     * 会员等级设置规则
     *
     * @param level_id
     * @param name
     * @param expense_amount
     * @param reward_point
     * @param callback
     */
    public static void loadMemberLevelUpdate(String level_id, String name, String expense_amount, String reward_point, IExecutorCallback callback) {

        AirMemberLeverUpdateRequest request = new AirMemberLeverUpdateRequest();
        request.level_id = StringUtil.toInt(level_id, 0);
        request.title = name;

        JSONObject upRule = new JSONObject();
        upRule.put("expense_amount", new BigDecimal(expense_amount));
        //json 需要转html实体 然后encoder编码
        request.up_rule = upRule;

        JSONObject upReward = new JSONObject();//升级奖励
        //upReward.put("reward_point", reward_point);//升级奖励积分
        if (TextUtils.isEmpty(reward_point)) {
            upReward.put("reward_point", BigDecimal.ZERO);
        } else {
            upReward.put("reward_point", new BigDecimal(reward_point));
        }
        request.up_reward = upReward;
        BusinessExecutor.execute(request, callback);

    }


    /**
     * 删除会员等级
     *
     * @param level_id
     * @param callback
     */
    public static void loadMemberLevelDelete(int level_id, IExecutorCallback callback) {
        MemberLevelDeleteRequest request = new MemberLevelDeleteRequest();
        request.level_id = level_id;
        request.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        MemberLevelDeleteRequestBody requestBody = new MemberLevelDeleteRequestBody();
        requestBody.crm_membercard_delMemberLevel = request;
        BusinessExecutor.execute(requestBody, callback);
    }


    /**
     * 会员套餐
     * 批量操作 新增 编辑 删除
     *
     * @param addRuleData    新增套餐规则
     * @param editorRuleData 编辑套餐规则
     * @param delRuleData    删除套餐规则
     * @param callback
     */
    public static void loadMemberPackageSave(Object addRuleData, Object editorRuleData, Object delRuleData, IExecutorCallback callback) {


        MemberPackageUpdateRequest request = new MemberPackageUpdateRequest();
        request.m_shopid = StringUtil.toInt(AppCache.getInstance().shop.fsCompanyGUID);
        if (!TextUtils.isEmpty(addRuleData.toString())) {
            request.addRuleData = addRuleData;
        }
        if (!TextUtils.isEmpty(editorRuleData.toString())) {
            request.editRuleData = editorRuleData;
        }
        if (!TextUtils.isEmpty(delRuleData.toString())) {
            request.delRuleData = delRuleData;
        }
        BusinessExecutor.execute(request, callback);

    }


    /**
     * 查询会员储值记录
     *
     * @param card_no
     * @param mobile
     * @param start_date
     * @param end_date
     * @param page
     * @param callback
     */
    public static void loadMemberRechaageRecording(String card_no, String mobile, String start_date, String end_date, int page, IExecutorCallback callback) {

        AirMemberRechargeRecordingRequest request = new AirMemberRechargeRecordingRequest();
        if (!TextUtils.isEmpty(card_no)) {
            request.card_no = card_no;
        }
        if (!TextUtils.isEmpty(mobile)) {
            request.mobile = mobile;
        }
        request.start_date = start_date;
        request.end_date = end_date;
        request.page = page;
        request.page_size = 30;

        BusinessExecutor.execute(request, callback);


    }


    /**
     * 查询会员消费记录
     *
     * @param card_no
     * @param mobile
     * @param start_date
     * @param end_date
     * @param page
     * @param callback
     */
    public static void loadMemberConsumptionRecording(String card_no, String mobile, String start_date, String end_date, int page, IExecutorCallback callback) {

        AirMemberConsumptionRecordingRequest request = new AirMemberConsumptionRecordingRequest();
        if (!TextUtils.isEmpty(card_no)) {
            request.card_no = card_no;
        }
        if (!TextUtils.isEmpty(mobile)) {
            request.mobile = mobile;
        }
        request.start_date = start_date;
        request.end_date = end_date;
        request.page = page;
        request.page_size = 30;
        BusinessExecutor.execute(request, callback);
    }


    /**
     * 查询会员列表
     *
     * @param cardNo
     * @param mobile
     * @param pageNo   当前的搜索页
     * @param callback
     */
    public static void loadMemberCardList(String cardNo, String mobile, int pageNo, IExecutorCallback callback) {

        AirMemberCardRequest request = new AirMemberCardRequest();

        if (!TextUtils.isEmpty(cardNo)) {
            request.cardNo = cardNo;
        }
        if (!TextUtils.isEmpty(mobile)) {
            request.mobile = mobile;
        }
        request.pageVo.pageNo = pageNo;

        BusinessExecutor.execute(request, callback);

    }


}
