package com.mwee.android.pos.air.business.netorder;


import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;

/**
 * Created by liuxiuxiu on 2017/10/16.
 */

public class AirNetOrderProcessor {

    public String optElemeUrl() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String url;
        if (!BaseConfig.isProduct()) {
            url = NetworkConstans.ELEME_BING_URL_TEST;
        } else {
            url = NetworkConstans.ELEME_BING_URL;
        }
        url = url.replace("SHOPGUID", shopId);
        return url;
    }

    public String optMeituanUrl() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String url;
        if (!BaseConfig.isProduct()) {
            url = NetworkConstans.MEITUAN_BING_URL_TEST;
        } else {
            url = NetworkConstans.MEITUAN_BING_URL;
        }
        url = url.replace("SHOPGUID", shopId);
        return url;
    }
}
