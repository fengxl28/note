package com.mwee.android.pos.business.dinner.api;

import android.text.TextUtils;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.table.api.TableApi;
import com.mwee.android.pos.connect.business.table.LockTableResponse;
import com.mwee.android.pos.connect.business.table.TableActionRespose;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CTable;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.table.TableUnlockType;

/**
 * Created by virgil on 2016/12/2.
 */

public class LockTableApi {
    /**
     * 锁定桌台
     *
     * @param targetTableID String
     * @param userDBModel   UserDBModel
     * @param hostID        String
     * @param result        IResult
     */
    public static void lockTable(final String orderID, String targetTableID, UserDBModel userDBModel, String hostID, final IResult result) {
        if (userDBModel == null) {
            return;
        }
        TableApi.lockTableRequest(targetTableID, userDBModel.fsUserId, userDBModel.fsUserName, hostID, orderID, new SocketCallback<LockTableResponse>() {
            @Override
            public void callback(SocketResponse<LockTableResponse> socketResponse) {
                if (socketResponse == null) {
                    if (result != null) {
                        result.callBack(false, "业务异常，请重试");
                    }
                    return;
                }

                if (socketResponse.success()) {
                    if (socketResponse.data != null && !TextUtils.isEmpty(socketResponse.data.orderOptToken)) {
                        AppCache.getInstance().currentOrderID = orderID;
                        AppCache.getInstance().refreshOrderToken(socketResponse.data.orderOptToken);
                    }
                    if (result != null) {
                        result.callBack(true, "");
                    }

                } else {
                    if (result != null) {
                        result.callBack(false, socketResponse.message);
                    }
                }
            }
        });
    }

    /**
     * 解除桌台的锁定
     *
     * @param targetTableID String
     * @param hostID        String
     */
    public static void unlockTable(String targetTableID, String hostID) {
        MCon.c(CTable.class).unlockTable(targetTableID, "", TableUnlockType.BY_TABLEID_AND_HOSTID);
    }

    /**
     * 解锁站点相关桌台
     *
     * @param hostID
     */
    public static void releaseHostLock(String hostID) {
        MCon.c(CTable.class).unlockTable("", "", TableUnlockType.BY_HOSTID);
    }

    /**
     * 解锁用户相关桌台
     *
     * @param userID
     */
    public static void unlockTableByUser(String userID) {
        MCon.c(CTable.class).unlockTable("", userID, TableUnlockType.BY_USER);
    }

    public static void loadUnLockTableAndShotOff(String fsmtableid, SocketCallback<TableActionRespose> callback) {
        MCon.c(CTable.class, callback).loadUnLockTableAndShotOff(fsmtableid);
    }
}
