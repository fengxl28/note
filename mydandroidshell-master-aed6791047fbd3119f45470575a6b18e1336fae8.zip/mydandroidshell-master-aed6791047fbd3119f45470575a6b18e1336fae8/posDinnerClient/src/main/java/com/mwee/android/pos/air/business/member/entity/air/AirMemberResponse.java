package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.pos.air.business.member.entity.MemberRuleLevelContainer;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;


/**
 * Created by zhangmin on 2018/1/30.
 */

public class AirMemberResponse extends BaseMemberResponse {

    public MemberRuleLevelContainer data = new MemberRuleLevelContainer();

    public AirMemberResponse(){

    }
}
