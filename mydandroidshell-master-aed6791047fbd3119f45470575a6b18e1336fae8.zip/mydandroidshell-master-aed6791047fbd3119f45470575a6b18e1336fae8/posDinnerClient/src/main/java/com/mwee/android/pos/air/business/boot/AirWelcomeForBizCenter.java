package com.mwee.android.pos.air.business.boot;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.boot.LaunchProcessor;
import com.mwee.android.pos.business.boot.WelcomeContract;
import com.mwee.android.pos.business.boot.WelcomePresenter;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogParamBundle;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.permission.REQUEST;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.log.LogUpload;


public class AirWelcomeForBizCenter extends BaseActivity implements WelcomeContract.View {

    private boolean perFinish = false;
    private boolean aniFinish = false;

    private void doNext() {
        if (perFinish && aniFinish) {
            mPresenter.checkAndLoadData();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        new WelcomePresenter(this);
        super.onCreate(savedInstanceState);
        new LaunchProcessor().start(ClientMetaUtil.getSettingsValueByKey(META.SHOPID));
        initView();
    }

    protected void initView() {
        mPresenter.requestPermission();
        View rootView = View.inflate(this, R.layout.activity_air_welcome, null);
        setContentView(rootView);
        TextView mSystemVersionNameLabel = (TextView) findViewById(R.id.mSystemVersionNameLabel);
        mSystemVersionNameLabel.setText("版本号:" + BuildConfig.VERSION_NAME);
        ObjectAnimator anim = ObjectAnimator.ofFloat(rootView, "alpha", 0f, 1f).setDuration(2000);
        anim.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                aniFinish = true;
                doNext();
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        anim.start();
        LogUpload.callUpload();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void jump() {
        if (!TextUtils.isEmpty(AppCache.getInstance().isAllDataInLaw)) {
            DialogParamBundle.Builder bundle = new DialogParamBundle.Builder();
            bundle.setCancelable(false).setPositiveBtnText("重试").setPositiveClick(new DialogResponseListener() {
                @Override
                public void response() {
                    mPresenter.checkAndLoadData();
                }
            }).setNegativeBtnText("退出").setNegitiveveClick(new DialogResponseListener() {
                @Override
                public void response() {
                    finish();
                }
            }).setContentText(AppCache.getInstance().isAllDataInLaw + ",请在后台进行配置之后点击\"重试\"");
            DialogManager.showExecuteDialog(this, bundle.build());
            AppCache.getInstance().isAllDataInLaw = "";
            return;
        }
        UIHelp.startLoginDinnerActvity(this);
        finish();
        if (!BaseConfig.isProduct()) {
            LogUtil.log("init token=" + AppCache.getInstance().token);
            LogUtil.log("init seed=" + AppCache.getInstance().seed);
        }
    }

    @Override
    public void handlerClickEvent(View v) {
        super.handlerClickEvent(v);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST.PERMISSIONS_SETTING:
                mPresenter.requestPermission();
                break;
            case REQUEST_MANAGE_OVERLAY_PERMISSION:
                perFinish = true;
                doNext();
                break;
            default:
                break;
        }
    }

    private static final int REQUEST_MANAGE_OVERLAY_PERMISSION = 1;

    /**
     * 请求权限
     */
    private  void requestAlertWindowPermission() {
        DialogManager.showExecuteDialog(this, "是否开启消息通知", "建议开启，关闭后外卖订单将无法推送提醒", "否", "是（建议开启）", () -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_MANAGE_OVERLAY_PERMISSION);
        }, () -> {
            perFinish = true;
            doNext();
        });
    }

    private WelcomeContract.Presenter mPresenter;

    @Override
    public void setPresenter(WelcomeContract.Presenter presenter) {
        mPresenter = presenter;
    }

    @Override
    public Host getNHost() {
        return this;
    }

    @SuppressLint("NewApi")
    @Override
    public void grantedPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (Settings.canDrawOverlays(this)) {
                perFinish = true;
                doNext();
            } else {
                requestAlertWindowPermission();
            }
        } else {
            perFinish = true;
            doNext();
        }
    }

    @Override
    public void initDataCompleted() {
        ProgressManager.closeProgress(this);
        jump();
    }

    @Override
    public void progress(String content) {

    }

    @Override
    public void closeProgress() {

    }
}
