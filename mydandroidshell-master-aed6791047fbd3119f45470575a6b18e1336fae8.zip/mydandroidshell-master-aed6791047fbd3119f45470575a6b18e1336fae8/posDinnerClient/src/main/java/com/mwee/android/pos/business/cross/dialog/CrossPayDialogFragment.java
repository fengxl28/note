package com.mwee.android.pos.business.cross.dialog;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.cross.CrossNetPayProcessor;
import com.mwee.android.pos.business.cross.api.CreditApi;
import com.mwee.android.pos.business.member.constant.MemberRechargeChoosePayType;
import com.mwee.android.pos.business.message.RapidPayChooseTableFragment;
import com.mwee.android.pos.business.pay.view.netpay.NetPayJump;
import com.mwee.android.pos.business.pay.view.netpay.NetPayListener;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.pay.CrossPaySocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 销账支付界面
 * Created by qinwei on 2018/1/4.
 */

public class CrossPayDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    //默认销账---从最老的开始
    public static final int DEFAULT = 0;
    //指定订单销账
    public static final int SINGLE = 1;

    private LinearLayout lyt;
    private ImageView mDialogCancelImg;
    private TextView mCrossPayPriceLabel;
    private NumberKeyboard mCrossPayNumberKeyboard;
    private PullRecyclerView mPullRecyclerView;
    private Button mCrossPayCancelBtn;
    private Button mCrossPayConfirmBtn;
    private PayTypeAdapter adapter;
    private OnCrossPayListener listener;
    private CreditAccount account;

    /**
     * 销账模式
     */
    private int crossType = DEFAULT;

    /**
     * 销账金额---指定订单销账 模式下指定的销账金额
     */
    private BigDecimal balanceAmt = BigDecimal.ZERO;
    /**
     * 订单号---指定订单销账 模式下才会有订单号
     */
    private String sellNo = "";

    public LinearLayout input_lyt;
    public View line1;

    /**
     * 存储输入金额
     */
    private String payPrice = "";
    private TextView mCrossGuaLabel;
    private String requestId;
    /**
     * 在线支付业务处理类
     */
    private CrossNetPayProcessor mNetPayProcessor;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cross_pay_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        try {
            WindowManager wm = (WindowManager) CrossPayDialogFragment.this.getContextWithinHost().getSystemService(Context.WINDOW_SERVICE);
            ViewGroup.LayoutParams lp = lyt.getLayoutParams();
            lp.height = wm.getDefaultDisplay().getHeight() * 4 / 5;
            lyt.setLayoutParams(lp);
        } catch (Exception e) {
            LogUtil.logError("重置页面大小", e);
        }
        initData();
    }

    private static CrossPayDialogFragment fragment = new CrossPayDialogFragment();

    public CrossPayDialogFragment() {
    }

    public static CrossPayDialogFragment newInstance() {
        return fragment;
    }

    private void initView(View view) {
        view.setOnClickListener(v -> {

        });
        lyt = view.findViewById(R.id.lyt);
        mDialogCancelImg = (ImageView) view.findViewById(R.id.mDialogCancelImg);
        mCrossGuaLabel = (TextView) view.findViewById(R.id.mCrossGuaLabel);
        mCrossPayPriceLabel = (TextView) view.findViewById(R.id.mCrossPayPriceLabel);
        mCrossPayNumberKeyboard = (NumberKeyboard) view.findViewById(R.id.mCrossPayNumberKeyboard);
        mPullRecyclerView = (PullRecyclerView) view.findViewById(R.id.mPullRecyclerView);
        mCrossPayCancelBtn = (Button) view.findViewById(R.id.mCrossPayCancelBtn);
        mCrossPayConfirmBtn = (Button) view.findViewById(R.id.mCrossPayConfirmBtn);
        input_lyt = view.findViewById(R.id.input_lyt);
        line1 = view.findViewById(R.id.line1);
        mDialogCancelImg.setOnClickListener(v -> {
            dismissSelf();
        });
        mCrossPayCancelBtn.setOnClickListener(this);
        mCrossPayConfirmBtn.setOnClickListener(this);
    }

    private void initData() {

        mCrossPayNumberKeyboard.setItemLayoutId(R.layout.view_cross_pay_key_item);
        mCrossPayNumberKeyboard.initData(KeyHelper.generateCrossPayKeys(), key -> {
            switch (key.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    if (payPrice.equals("0")) {
                        payPrice = "";
                    }
                    if (TextUtils.isMoneyStr(payPrice + key.value)) {
                        payPrice += key.value;
                    }
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CLEAR:
                    payPrice = "";
                    break;
                case NumberKeyboard.KeyEntity.TYPE_POINT:
                    if (TextUtils.isMoneyStr(payPrice + key.value)) {
                        payPrice += key.value;
                    }
                    break;
                default:
                    break;
            }
            mCrossPayPriceLabel.setText(payPrice);
        });

        if (crossType == DEFAULT) {
            mCrossGuaLabel.setText("可销账金额：" + account.canCrossAmt.toPlainString());
            input_lyt.setVisibility(View.VISIBLE);
            line1.setVisibility(View.VISIBLE);
        } else {
            mCrossGuaLabel.setText("本笔销账金额：" + balanceAmt.toPlainString());
            input_lyt.setVisibility(View.GONE);
            line1.setVisibility(View.GONE);
        }
        mPullRecyclerView.setEnablePullToStart(false);
        mPullRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        mCrossPayNumberKeyboard.notifyDataChanged();
        adapter = new PayTypeAdapter();
        adapter.modules.addAll(buildPayTypes());
        mPullRecyclerView.setAdapter(adapter);
        mNetPayProcessor = new CrossNetPayProcessor(this);
        mNetPayProcessor.setNetPayListener(new NetPayListener<BigDecimal>() {

            @Override
            public void onExecutePaySuccess(BigDecimal canCrossAmt) {
                listener.onCrossSuccess(canCrossAmt);
                dismissSelf();
            }

            @Override
            public void onExecutePayError(String errmsg) {
                ToastUtil.showToast(errmsg);
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mCrossPayCancelBtn:
                dismissSelf();
                break;
            case R.id.mCrossPayConfirmBtn:
                doPay();
                break;
            default:
                break;
        }
    }

    private void doPay() {
        PayTypeBean bean = adapter.getSelectPayType();
        if (bean == null) {
            ToastUtil.showToast("请选择支付方式！");
            return;
        }

        BigDecimal crossAmt = BigDecimal.ZERO;

        if (crossType == DEFAULT) {
            if (!TextUtils.validate(payPrice)) {
                ToastUtil.showToast("请输入销账金额！");
                return;
            }
            if (new BigDecimal(payPrice).compareTo(BigDecimal.ZERO) <= 0) {
                ToastUtil.showToast("销账金额不能为0！");
                return;
            }
            crossAmt = new BigDecimal(payPrice);
            if (crossAmt.compareTo(account.canCrossAmt) > 0) {
                ToastUtil.showToast("销账金额不能大于挂账金额！");
                return;
            }
        } else {
            crossAmt = balanceAmt;
        }

        BigDecimal inputPrice = crossAmt;

        this.requestId = System.currentTimeMillis() + "";
        //设置请求id
        mNetPayProcessor.setRequestId(this.requestId);
        //设置支付方式
        mNetPayProcessor.setPayType(bean.paymentDBModel);
        //设置销账账户信息
        mNetPayProcessor.setAccount(account);
        //销账订单号
        mNetPayProcessor.setSellNo(sellNo);
        String message = "本次销账金额:" + bean.paymentDBModel.fsPaymentName + inputPrice.toPlainString();
        ActionLog.addLog("点击销账按钮进行销账[" + message + "]", ActionLog.CROSS_ACCOUNT_CROSS_DO);
        DialogManager.showExecuteDialog(getActivityWithinHost(), message, "取消", "确定", () -> {
            switch (bean.paymentDBModel.fsPaymentId) {
                case PayType.WEIXIN:
                    NetPayJump.jumpToCrossPay(getChildFragmentManager(), inputPrice, MemberRechargeChoosePayType.WECHAT, R.id.root, mNetPayProcessor);
                    break;
                case PayType.ALI:
                    NetPayJump.jumpToCrossPay(getChildFragmentManager(), inputPrice, MemberRechargeChoosePayType.ALIPAY, R.id.root, mNetPayProcessor);
                    break;
                default:
                    loadCrossPay(account, inputPrice, "", bean.paymentDBModel);
                    break;
            }
        }, null);
    }

    public void loadCrossPay(CreditAccount account, BigDecimal crossPrice, String code, PaymentDBModel bean) {
        Progress progress = ProgressManager.showProgressUncancel(this, "销账中...");
        CreditApi.loadCrossPay(requestId, account, sellNo, crossPrice, code, bean, new ResultCallback<CrossPaySocketResponse>() {
            @Override
            public void onSuccess(CrossPaySocketResponse data) {
                //errno{0:支付中 1：成功 2：失败}
                progress.dismissSelf();
                switch (data.crossResult.errno) {
                    case "0":
                        break;
                    case "1":
                        ToastUtil.showToast("销账成功!");
                        listener.onCrossSuccess(data.crossResult.canCrossAmt);
                        dismissSelf();
                        break;
                    case "2":
                        ToastUtil.showToast(data.crossResult.errmsg);
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


    public class PayTypeAdapter extends BaseListAdapter<PayTypeBean> {
        public int selectPosition = -1;


        public PayTypeBean getSelectPayType() {
            if (adapter.modules.size() > 0 && selectPosition >= 0) {
                return modules.get(selectPosition);
            }
            return null;
        }

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_cross_pay_type_item, parent, false));
        }

        class Holder extends BaseViewHolder implements View.OnClickListener {
            private ImageView mCrossPayItemIconImg;
            private TextView mCrossPayItemNameLabel;
            private PayTypeBean payType;
            private int position;

            public Holder(View v) {
                super(v);
                mCrossPayItemIconImg = (ImageView) v.findViewById(R.id.mCrossPayItemIconImg);
                mCrossPayItemNameLabel = (TextView) v.findViewById(R.id.mCrossPayItemNameLabel);
                v.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                payType = modules.get(position);
                mCrossPayItemNameLabel.setText(payType.paymentDBModel.fsPaymentName);
                if (payType.iconId > 0) {
                    mCrossPayItemIconImg.setVisibility(View.VISIBLE);
                    mCrossPayItemIconImg.setImageResource(payType.iconId);
                } else {
                    mCrossPayItemIconImg.setVisibility(View.GONE);
                }
                itemView.setSelected(selectPosition == position);
            }

            @Override
            public void onClick(View view) {
                if (selectPosition != position) {
                    ActionLog.addLog("点击销账支付方式[" + modules.get(position).paymentDBModel.fsPaymentName + "]", ActionLog.CROSS_ACCOUNT_CROSS_PAY_NAME);
                    selectPosition = position;
                    adapter.notifyDataSetChanged();
                }
            }
        }
    }

    public static class PayTypeBean {
        public PaymentDBModel paymentDBModel;
        public int iconId;


        public PayTypeBean(PaymentDBModel paymentDBModel, int iconId) {
            this.paymentDBModel = paymentDBModel;
            this.iconId = iconId;
        }
    }

    public ArrayList<PayTypeBean> buildPayTypes() {
        List<PaymentDBModel> paymentDBModels = queryAll();
        ArrayList<PayTypeBean> payTypes = new ArrayList<>();

        for (PaymentDBModel paymentDBModel : paymentDBModels) {
            payTypes.add(new PayTypeBean(paymentDBModel, getIconId(paymentDBModel.fsPaymentId)));
        }
        return payTypes;
    }

    public int getIconId(String id) {
        int iconId = -1;
        switch (id) {
            case "10001":
                iconId = R.drawable.selector_pay_type_rmb;
                break;
            case "91801":
                iconId = R.drawable.selector_pay_type_alipay;
                break;
            case "91802":
                iconId = R.drawable.selector_pay_type_wechat;
                break;
            case "16001":
                iconId = R.drawable.selector_pay_type_card;
                break;
            default:
                break;

        }
        return iconId;
    }

    public List<PaymentDBModel> queryAll() {
        String sql = "select * from tbpayment where " +
                "fiStatus=1 and fsPaymentId in(" +
                "'10001','91801','91802','16001','12001','18002','18001','99911','99912')";
        return DBSimpleUtil.queryList(APPConfig.DB_CLIENT, sql, PaymentDBModel.class);
    }

    public void setParam(CreditAccount account, OnCrossPayListener listener) {
        this.listener = listener;
        this.account = account;
        this.sellNo = "";
        this.balanceAmt = BigDecimal.ZERO;
        this.crossType = DEFAULT;
    }

    public void setParam(CreditAccount account, int crossType, String sellNo, BigDecimal balanceAmt, OnCrossPayListener listener) {
        if (balanceAmt == null) {
            balanceAmt = BigDecimal.ZERO;
        }
        this.listener = listener;
        this.crossType = crossType;
        this.sellNo = sellNo;
        this.balanceAmt = balanceAmt;
        this.account = account;
        payPrice = balanceAmt.toPlainString();
    }

    public interface OnCrossPayListener {
        void onCrossSuccess(BigDecimal canCrossAmt);
    }
}
