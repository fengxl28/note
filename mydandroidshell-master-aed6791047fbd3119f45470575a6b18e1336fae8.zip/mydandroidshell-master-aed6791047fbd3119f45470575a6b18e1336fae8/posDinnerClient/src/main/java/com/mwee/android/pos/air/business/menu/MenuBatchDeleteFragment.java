package com.mwee.android.pos.air.business.menu;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.menu.processor.MenuProcessor;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/10.
 */

public class MenuBatchDeleteFragment extends BaseListFragment<MenuItemBean> implements View.OnClickListener {
    private TitleBar mTitleBar;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchChoiceValueLabel;
    private Button mAskBatchDeleteBtn;
    private Button mAskBatchCancelBtn;
    private String clsId;
    private MenuProcessor menuProcessor;
    private ArrayList<String> choiceStates = new ArrayList<>();
    private OnMenuBatchDeleteListener listener;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_ask_batch_delete;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mTitleBar = (TitleBar) view.findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
        mTitleBar.setTitle("批量删除菜品");
        mAskBatchChoiceAllLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceAllLabel);
        mAskBatchChoiceValueLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceValueLabel);
        mAskBatchDeleteBtn = (Button) view.findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchCancelBtn = (Button) view.findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        menuProcessor = new MenuProcessor();
        menuProcessor.loadMenuItemsByClsId(clsId, new ResultCallback<List<MenuItemBean>>() {
            @Override
            public void onSuccess(List<MenuItemBean> data) {
                modules.addAll(data);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
        refreshUI();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(getContext(), 7);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_menu_choice_item, parent, false));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mAskBatchDeleteBtn:
                DialogManager.showExecuteDialog(getActivityWithinHost(),
                        "是否确认删除？",
                        getStringWithinHost(R.string.cacel),
                        getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                            @Override
                            public void response() {
                                doBatchDeleteChoice();
                            }
                        }, null);
                break;
            case R.id.mAskBatchCancelBtn:
                dismissSelf();
                break;
            case R.id.mAskBatchChoiceAllLabel:
                doChoiceAllClick();
                break;
            default:
                break;
        }
    }

    private void doChoiceAllClick() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    private void doBatchDeleteChoice() {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        menuProcessor.loadBatchDelete(choiceStates, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast(data);
                listener.onDeleteSuccess(choiceStates);
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void refreshUI() {
        mAskBatchChoiceValueLabel.setText(String.format(getString(R.string.ask_choice_size_label), choiceStates.size()));
        mAskBatchDeleteBtn.setEnabled(choiceStates.size() > 0);
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView mMenuItemNameLabel;
        private TextView mMenuItemRepertoryLabel;
        private TextView mMenuItemSellPriceLabel;
        private TextView mMenuItemMemberPriceLabel;
        private MenuItemBean menuItemBean;

        public Holder(View v) {
            super(v);
            mMenuItemNameLabel = (TextView) v.findViewById(R.id.mMenuItemNameLabel);
            mMenuItemRepertoryLabel = (TextView) v.findViewById(R.id.mMenuItemRepertoryLabel);
            mMenuItemSellPriceLabel = (TextView) v.findViewById(R.id.mMenuItemSellPriceLabel);
            mMenuItemMemberPriceLabel = (TextView) v.findViewById(R.id.mMenuItemMemberPriceLabel);
            v.setOnClickListener(this);

        }

        @Override
        public void bindData(int position) {
            menuItemBean = modules.get(position);
            itemView.setSelected(choiceStates.contains(menuItemBean.fiItemCd));
            mMenuItemNameLabel.setText(menuItemBean.fsItemName);
            if (menuItemBean.fiStatus == 2) {//临时沽清显示沽清数量
                mMenuItemRepertoryLabel.setVisibility(View.VISIBLE);
                mMenuItemRepertoryLabel.setText("剩余" + menuItemBean.fdInvQty.toPlainString());
            } else {
                mMenuItemRepertoryLabel.setVisibility(View.GONE);
            }
            mMenuItemSellPriceLabel.setText(Calc.formatShow(menuItemBean.fdSalePrice, RoundConfig.ROUND_SINGLE_PRICE));
            mMenuItemMemberPriceLabel.setText("会员价 " + Calc.formatShow(menuItemBean.fdVIPPrice, RoundConfig.ROUND_SINGLE_PRICE));
        }

        @Override
        public void onClick(View v) {
            choice(menuItemBean.fiItemCd);
            adapter.notifyDataSetChanged();
            mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
            refreshUI();
        }
    }

    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }


    private boolean isChoiceAll() {
        for (int i = 0; i < modules.size(); i++) {
            if (!choiceStates.contains(modules.get(i).fiItemCd)) {
                return false;
            }
        }
        return true;
    }

    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < modules.size(); i++) {
            choiceStates.add(modules.get(i).fiItemCd);
        }
    }

    private void cancelChoiceAll() {
        choiceStates.clear();
    }

    public void setParam(String clsId, OnMenuBatchDeleteListener listener) {
        this.clsId = clsId;
        this.listener = listener;
    }

    public interface OnMenuBatchDeleteListener {
        void onDeleteSuccess(ArrayList<String> askIds);
    }
}
