package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/5/8.
 */

public class WXOpenPayModel extends BusinessBean {

    public String authurl;

    public WXOpenPayModel(){

    }
}
