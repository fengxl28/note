package com.mwee.android.pos.business.dinner.processor;

import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.SparseArray;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseBizProcessor;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.common.dinner.IMenuItemProcessor;
import com.mwee.android.pos.business.dinner.api.DinnerMenuItemSocketApi;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.order.view.discount.CouponProcessor;
import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.business.order.view.discount.MultiCouponFragment;
import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
import com.mwee.android.pos.business.orderdishes.util.IngredientUtil;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.business.orderdishes.view.fragment.OrderDishesBatchAddRequestFragment;
import com.mwee.android.pos.business.orderdishes.view.jump.NoteJump;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.ChooseNumJump;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.IChooseNumListner;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.text.CallChangeText;
import com.mwee.android.pos.component.text.IChangeText;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * 菜品操作业务处理
 * Created by qinwei on 2017/5/31.
 */

public class MenuItemProcessor extends BaseBizProcessor implements IMenuItemProcessor {
    private Host mHost;
    private DishCache mDishCache;
    private ArrayList<NoteItemModel> systemCustomRequests = new ArrayList<>();//自定义菜品要求

    public MenuItemProcessor(Host host, DishCache dishCache) {
        this.mHost = host;
        this.mDishCache = dishCache;
    }

    public void setDishCache(DishCache dishCache) {
        mDishCache = dishCache;
    }

    @Override
    public void doUpdateMenuName(String orderId, MenuItem menuItem, final ResultCallback<String> callback) {
        CallChangeText.call(mHost, new IChangeText() {
            @Override
            public boolean confirmTxt(String text) {
                if (!TextUtils.isEmpty(text)) {
                    callback.onSuccess(text);
                }
                return true;
            }
        });
    }

    /**
     * 菜品改数量处理
     *
     * @param menuItem
     * @param orderCache
     * @param callback
     */
    @Override
    public void doUpdateMenuItemBuyNumber(final MenuItem menuItem, final OrderCache orderCache, final ResultCallback<String> callback) {
        ModifyQuantityUtils.showModifyQuantitySupportWeight(mHost, menuItem, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, final BigDecimal newNum) {
                if (originNum.compareTo(newNum) == 0) {
                    return;
                }
                final BigDecimal format = Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundingMode.HALF_UP);
                ActionLog.addLog("点菜页->开始改数量 [" + menuItem.name + "],新数量=" + newNum.toString(), mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                DinnerMenuItemSocketApi.loadUpdateMenuItemBuyNumber(orderCache.orderID, menuItem.menuBiz.uniq, format, new ConCallBack<UpdateBuyNumResponse>() {
                    @Override
                    public void subCall(SocketResponse<UpdateBuyNumResponse> response) {
                        if ((response.code == SocketResultCode.SUCCESS && response.data.needRefreshSellOutNum) || response.code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                            OrderDishesBizUtil.updateSellOutUnit(response.data.unitSellOutNew);
                        }
                    }

                    @Override
                    public void callback(SocketResponse<UpdateBuyNumResponse> response) {
                        progress.dismiss();
                        if (response == null) {
                            callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                            return;
                        }

                        if (response.code == SocketResultCode.SUCCESS) {
                            //修改数量成功后同步菜品数量
                            menuItem.updateBuyNum(format);
                            menuItem.calcTotal(mDishCache.isBindMember());
                            mDishCache.initSelectUnitQuantity();
                            ActionLog.addLog("点菜页->修改成功 [" + menuItem.name + "],新数量=" + newNum.toString(), mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                            callback.onSuccess("");
                        } else {
                            callback.onFailure(response.code, response.message);
                        }
                    }
                });
            }
        });
    }

    /**
     * 改时价菜
     *
     * @param orderId  订单id
     * @param menuItem 菜品
     * @param callback 回调
     */
    @Override
    public void doUpdateDishPrice(final String orderId, final MenuItem menuItem, final ResultCallback<String> callback) {

        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle("设置价格(元)");
        fragment.setErrorTips("请输入数值");
        fragment.setOriginCount(menuItem.menuBiz.totalPrice);
        fragment.setCanBe0(true);
        fragment.setCallback(new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, final BigDecimal newNum) {
                if (newNum.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                menuItem.changeTimesPrice(newNum);
                menuItem.calcTotal(mDishCache.isBindMember());
                //已下单改价格需要同步到业务中心
                if (mDishCache.order != null && mDishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                    final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                    DinnerMenuItemSocketApi.loadUpdateDishPrice(orderId, menuItem.menuBiz.uniq, newNum, null, new IResult() {
                        @Override
                        public void callBack(boolean result, String info) {
                            progress.dismiss();
                            if (result) {
                                ActionLog.addLog("点菜页->修改价格成功 price=[" + newNum + "]" + menuItem.menuBiz.uniq, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.FF_MENU_PRICE, "");
                                callback.onSuccess(info);
                            } else {
                                ActionLog.addLog("点菜页->修改价格失败 " + info + menuItem.menuBiz.uniq, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.FF_MENU_PRICE, "");
                                callback.onFailure(-1, info);
                            }
                        }
                    });
                } else {
                    callback.onSuccess(mDishCache.getOrderId());
                }
            }
        });
        fragment.setMaxCount(Integer.MAX_VALUE);
        fragment.setIsSupportFloat(true);
        DialogManager.showCustomDialog(mHost, fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }

    /**
     * 退菜业务逻辑
     *
     * @param orderId  订单id
     * @param item     退菜菜品
     * @param reason   退菜理由
     * @param callback
     */
    @Override
    public void doRetreatDish(final String orderId, final MenuItem item, final String reason, final ResultCallback<OrderCache> callback) {
        BigDecimal maxValue = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
        BigDecimal originValue = new BigDecimal(maxValue.doubleValue());
        ChooseNumJump.showChooseNum(mHost, GlobalCache.getContext().getString(R.string.menu_item_retreat_dish_title), originValue, maxValue, BigDecimal.ONE, (item.config & 32) != 32, true, item.currentUnit.fsOrderUint, new IChooseNumListner() {
            @Override
            public void callback(boolean confirm, final BigDecimal confirmCount) {
                if (!confirm) {
                    return;
                }
                final VoidMenuItemModel voidMenuItem = new VoidMenuItemModel();
                voidMenuItem.fsseq = item.menuBiz.uniq;
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                    item.menuBiz.buyNum = BigDecimal.ONE;
                }
                if (item.supportWeight()) {
                    voidMenuItem.fdbackqty = item.menuBiz.buyNum;
                } else {
                    voidMenuItem.fdbackqty = confirmCount;
                }
                voidMenuItem.fiItemCd = item.itemID;
                voidMenuItem.fiOrderUintCd = item.currentUnit.fiOrderUintCd;
                voidMenuItem.fsbackreason = reason;
                voidMenuItem.fsbackuserid = AppCache.getInstance().userDBModel.fsUserId;
                voidMenuItem.fsbackusername = AppCache.getInstance().userDBModel.fsUserName;
                final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "开始退菜 [" + item.name + "],退菜数量=" + confirmCount.toString() + ",orderID=" + mDishCache.order.orderID);
                DinnerMenuItemSocketApi.loadReturnDish(orderId, voidMenuItem, new ResultCallback<OrderCache>() {
                    @Override
                    public void onSuccess(OrderCache data) {
                        progress.dismiss();
                        //更新ui
                        item.doVoid(voidMenuItem.fdbackqty, voidMenuItem.fsbackuserid, voidMenuItem.fsbackusername, voidMenuItem.fsbackreason);
                        item.calcTotal(mDishCache.isBindMember());
                        ActionLog.addLog("点菜页->退菜成功 [" + item.name + "],退菜数量=" + confirmCount.toString(), mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_MENU_RETREAT, "");
                        callback.onSuccess(data);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        progress.dismiss();
                        callback.onFailure(code, msg);
                    }
                });
            }
        });
    }

    /**
     * 单个菜品优惠处理
     *
     * @param tempItem
     * @param listener
     */
    @Override
    public void doChangeMenuPrivilege(MenuItem tempItem, final SingleCouponFragment.OnSingleDiscountListener listener) {
        List<MenuItem> tempMenuItemList = new ArrayList<>();
        MenuItem item = tempItem.clone();
        tempMenuItemList.add(item);
        final List<MenuItem> menuItemList = ListUtil.cloneList(tempMenuItemList);
        final CouponProcessor processor = new CouponProcessor(mDishCache.order, mDishCache.orderDishesCache, mHost);
        String orderDiscountId = "";
        BigDecimal orderDiscountAmt = BigDecimal.ZERO;
        if (mDishCache.order.selectOrderDiscountCut != null) {
            orderDiscountId = mDishCache.order.selectOrderDiscountCut.fsDiscountId;
            orderDiscountAmt = mDishCache.order.selectOrderDiscountCut.fdddv;
        }
        processor.initData(menuItemList, orderDiscountId, orderDiscountAmt, mDishCache.order.discountCutReason,
                mDishCache.order.orderCutOperUserId, mDishCache.order.orderCutAuthUserId);
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.load_all_discount_ing);
        processor.loadAllDiscounts(mDishCache.order.orderID, menuItemList, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();

                if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) { // 有配料，跳到批量折扣页
                    String orderID = mDishCache.order != null ? mDishCache.order.orderID : "";
                    MultiCouponFragment fragment = new MultiCouponFragment();
                    fragment.setParam(processor, new DinnerMultiDiscountCallBack() {
                        @Override
                        public void call(OrderCache cache, List<MenuItem> tempList) {
                            if (listener != null) {
                                listener.callback(cache, null, tempList);
                            }
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            if (!TextUtils.isEmpty(msg)) {
                                ToastUtil.showToast(msg);
                            }
                        }
                    });
                    ActionLog.addLog("获取有配料的菜品折扣信息，打开批量折扣界面", orderID, mDishCache.order.fsmtableid, ActionLog.DF_BATCH_DISCOUNT, "");
                    fragment.show(mHost.getFragmentManagerWithinHost(), "MultiCouponFragment");
                } else {
                    SingleCouponFragment fragment = new SingleCouponFragment();
//                    processor.giftInfo.put(item.menuBiz.uniq, item.menuBiz.giftNum);
                    fragment.setParam(mDishCache, item);
                    fragment.setOnSingleDiscountListener(listener);
                    fragment.setCouponProcessor(processor);
                    DialogManager.showCustomDialog(mHost, fragment, "SingleCouponFragment");
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 单个菜品要求处理
     *
     * @param item
     * @param noteCallback
     */
    @Override
    public void doEditorMenuNoteContent(MenuItem item, NoteCallback noteCallback) {
        List<NoteModel> noteList = DinnerMenuUtil.getRequestByMenuItem(item);
        NoteJump.showNote(mHost, noteList, systemCustomRequests, item.clone().menuBiz.selectNote, noteCallback);
    }

    /**
     * 批量要求
     *
     * @param callback
     */
    @Override
    public void doBatchRequest(List<MenuItem> reqMenuItems, final ResultCallback<String> callback) {
        OrderDishesJump.showOrderDishesBatchAddRequest(mHost, reqMenuItems, systemCustomRequests, new OrderDishesBatchAddRequestFragment.Callback() {
            @Override
            public void onConfirm(List<MenuItem> menuItemList) {
                for (int i = 0; i < menuItemList.size(); i++) {
                    MenuItem newItem = menuItemList.get(i);
                    for (MenuItem item : mDishCache.orderDishesCache.tempSelectedMenuList) {
                        if (TextUtils.equals(newItem.menuBiz.uniq, item.menuBiz.uniq)) {
                            item.menuBiz.selectNote = ListUtil.cloneList(newItem.menuBiz.selectNote);
                            item.buildNotesString();
                            item.calcTotal(mDishCache.isBindMember());
                            break;
                        }
                    }
                }
                callback.onSuccess("");
            }
        }, mDishCache.isBindMember());
    }

    /**
     * 菜品编辑数据处理
     *
     * @param oldUnit
     * @param oldBuyNum
     * @param item
     */
    @Override
    public boolean doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item) {
        if (!((oldUnit.fiInitCount <= 0 && item.currentUnit.fiInitCount <= 0) ||
                ((oldUnit.fiInitCount > 0 && item.currentUnit.fiInitCount > 0) &&
                        (TextUtils.equals(oldUnit.fiOrderUintCd, item.currentUnit.fiOrderUintCd))))) {
            if (item.currentUnit.fiInitCount > 0) {
                item.menuBiz.buyNum = Calc.format(new BigDecimal(item.currentUnit.fiInitCount), RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type);
            } else {
                item.menuBiz.buyNum = Calc.format(BigDecimal.ONE, RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type);
            }
            if (item.menuBiz.menuSellType == MenuSellType.GIFT) {//如果当前菜品为赠送菜  赠送菜数量要和购买数量保持一致
                item.menuBiz.giftNum = item.menuBiz.buyNum;
            }
            mDishCache.initSelectUnitQuantity();
        }
        item.calcTotal(mDishCache.isBindMember());
        return true;
    }

    /**
     * 催菜请求
     *
     * @param orderId
     * @param uniq
     * @param callback
     */
    @Override
    public void loadRemindersDish(String orderId, String uniq, final ResultCallback<String> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, "数据同步中..");
        DinnerMenuItemSocketApi.loadRemindersDish(orderId, uniq, null, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                progress.dismiss();
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(-1, info);
                }
            }
        });
    }

    /**
     * 划菜请求
     *
     * @param orderId
     * @param seqList
     * @param callback
     */
    @Override
    public void loadPaddleDish(String orderId, List<String> seqList, ResultCallback<String> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, "数据同步中..");
        DinnerMenuItemSocketApi.paddleDoDish(orderId, seqList, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                progress.dismiss();
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(-1, info);
                }
            }
        });
    }

    @Override
    public void loadPaddleDishV2(String orderId, ArrayMap<String, BigDecimal> menuWithCount, ResultCallback<String> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, "数据同步中..");
        DinnerMenuItemSocketApi.paddleDoDishV2(orderId, menuWithCount, (result, info) -> {
            progress.dismiss();
            if (result) {
                callback.onSuccess(info);
            } else {
                callback.onFailure(-1, info);
            }
        });
    }

    /**
     * 起菜处理
     *
     * @param orderId
     * @param seq      菜品唯一标示
     * @param callback
     */
    @Override
    public void loadDoDish(String orderId, String seq, final ResultCallback<String> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
        DinnerMenuItemSocketApi.loadDoDish(orderId, seq, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                progress.dismiss();
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(-1, info);
                }
            }
        });
    }

    /**
     * 加退配料菜
     *
     * @param orderId  订单id
     * @param oldItem  修改之前菜品
     * @param newItem  修改之后菜品
     * @param callback call from main Thread
     */
    @Override
    public void doChangeIngredient(String orderId, MenuItem oldItem, MenuItem newItem, final ResultCallback<OrderCache> callback) {
        SparseArray<List<MenuItem>> changedList = IngredientUtil.updateMenuItem(ListUtil.cloneList(oldItem.menuBiz.selectedModifier), ListUtil.cloneList(newItem.menuBiz.selectedModifier));
        List<MenuItem> addedMenuItem = changedList.get(0);
        List<MenuItem> deletedMenuItem = changedList.get(1);
        if (addedMenuItem.size() > 0 || deletedMenuItem.size() > 0) {
            final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
            DinnerMenuItemSocketApi.loadChangeIngredient(orderId, newItem, addedMenuItem, deletedMenuItem, new IResponse<OrderCache>() {
                @Override
                public void callBack(boolean result, int code, String msg, OrderCache info) {
                    progress.dismiss();
                    if (result) {
                        callback.onSuccess(info);
                    } else {
                        callback.onFailure(code, msg);
                    }
                }
            });
        }
    }

    /**
     * 加、退套餐子项
     *
     * @param orderId  订单号
     * @param oldItem  修改前的菜品
     * @param newItem  修改后的菜品
     * @param callback
     */
    @Override
    public void doChangePackageItems(String orderId, MenuItem oldItem, MenuItem newItem, PackageItemEditViewBean otherData, final ResultCallback<OrderCache> callback) {
        String voidReason = otherData == null ? "" : otherData.voidReason;
        UserDBModel voidUser = otherData == null ? null : otherData.voidUser;
        SparseArray<List<MenuItem>> changedList = IngredientUtil.updateMenuItem(ListUtil.cloneList(oldItem.menuBiz.selectedPackageItems),
                ListUtil.cloneList(newItem.menuBiz.selectedPackageItems), voidReason, voidUser);
        List<MenuItem> addedMenuItem = changedList.get(0);
        List<MenuItem> deletedMenuItem = changedList.get(1);
        List<MenuItem> updatedMenuItem = changedList.get(2);
        if (addedMenuItem.size() > 0 || deletedMenuItem.size() > 0 || updatedMenuItem.size() > 0) {
            final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
            DinnerMenuItemSocketApi.loadChangePackageItems(orderId, newItem, addedMenuItem, deletedMenuItem, updatedMenuItem, new IResponse<OrderCache>() {
                @Override
                public void callBack(boolean result, int code, String msg, OrderCache info) {
                    progress.dismiss();
                    if (result) {
                        callback.onSuccess(info);
                    } else {
                        callback.onFailure(code, msg);
                    }
                }
            });
        }
    }

    @Override
    public void doBatchDiscount(final DinnerMultiDiscountCallBack callBack) {
        if (mDishCache.order != null) {
            ActionLog.addLog("点击批量优惠折扣", mDishCache.order.orderID, mDishCache.getOrderId(), ActionLog.DF_BATCH_DISCOUNT, "");
        }
        if (mDishCache.order == null) {
            ToastUtil.showToast("请先下单");
            return;
        }
        final Progress progress = ProgressManager.showProgress(mHost);
        final CouponProcessor processor = new CouponProcessor(mDishCache.order, mDishCache.orderDishesCache, mHost);
        ActionLog.addLog("获取所有折扣信息", mDishCache.order.orderID, mDishCache.order.fsmtableid, ActionLog.DF_BATCH_DISCOUNT, "");
        processor.loadAllDiscounts(mDishCache.order.orderID, mDishCache.order.originMenuList, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                String orderDiscountId = "";
                BigDecimal orderDiscountAmt = BigDecimal.ZERO;
                if (mDishCache.order.selectOrderDiscountCut != null) {
                    orderDiscountId = mDishCache.order.selectOrderDiscountCut.fsDiscountId;
                    orderDiscountAmt = mDishCache.order.selectOrderDiscountCut.fdddv;
                }
                processor.initData(mDishCache.order.originMenuList, orderDiscountId, orderDiscountAmt,
                        mDishCache.order.discountCutReason, mDishCache.order.orderCutOperUserId, mDishCache.order.orderCutOperUserId);
                // 该Fragment已删除
//                DinnerAirMultiDiscountFragment fragment = new DinnerAirMultiDiscountFragment();
//                fragment.setParam(processor, callBack);
//                ActionLog.addLog("获取所有折扣信息，打开批量折扣界面", mDishCache.order.orderID, mDishCache.order.fsmtableid, ActionLog.DF_BATCH_DISCOUNT, "");
//                fragment.show(mHost.getFragmentManagerWithinHost(), "DinnerAirMultiDiscountFragment");
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismiss();
            }
        });
    }

    /**
     * 删除某个未下单已使用买减优惠菜品，需要联动删除所有相关菜品的买减优惠
     *
     * @param item
     * @param callBack
     */
    public void doCleanGiftBuyInfoByOne(final MenuItem item, final DinnerMultiDiscountCallBack callBack) {
        if (item == null) {
            return;
        }
        String orderId = "";
        if (mDishCache.order != null) {
            orderId = mDishCache.order.orderID;
        }
        DinnerMenuItemSocketApi.doCleanGiftBuyInfoByOne(mDishCache.orderDishesCache.tempSelectedMenuList,
                orderId, item.itemID,
                item.currentUnit.fiOrderUintCd, callBack);
    }

    @Override
    public void doUpdateMenuName(MenuItem menuItem, final ResultCallback<String> callback) {
        CallChangeText.call(mHost, new IChangeText() {
            @Override
            public boolean confirmTxt(String text) {
                if (!TextUtils.isEmpty(text)) {
                    callback.onSuccess(text);
                }
                return true;
            }
        });
    }
}
