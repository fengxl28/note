package com.mwee.android.pos.air.business.tprinter;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.printer.ConnectWatcher;
import com.mwee.android.pos.printer.PrinterConnectManager;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.posmodel.print.PrinterConstants;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/10/12.
 */

public class TPrinterSetFragment extends AirBaseFragment implements View.OnClickListener, PrinterEditorDialogFragment.OnPrinterEditorListener {

    private TitleBar titleBar;
    private TextView tvSearchLoading;
    private TextView tvSelfAdd;
    private TPrinterSearchView tPrinterSearchView;
    private CompatibleListView rvPrinters;
    private CommonAdapter<PrinterItem> printerAdapter;
    private PrinterProcessor mProcessor;
    /**
     * 已经添加到数据库的打印机
     */
    private List<PrinterItem> allPrinters = new ArrayList<>();

    ConnectWatcher watcher = new ConnectWatcher() {
        @Override
        protected void onStartSearch() {
            tvSearchLoading.setText("搜索中...");
            tvSearchLoading.setEnabled(false);
        }

        @Override
        protected void onStopSearch() {
            tvSearchLoading.setText("搜索添加");
            tvSearchLoading.setEnabled(true);
        }

        @Override
        protected void onFindNetPrinterIp(String ip) {//这儿需要构建  网络 usb 蓝牙打印机
            LogUtil.log("testSearchNetPrinter:" + ip);
            PrinterItem item = PrinterProcessor.buildPrinterItem(PrinterType.NET);
            item.ip = ip;
            item.name = ip;
            tPrinterSearchView.addPrinterModel(item);
        }
    };


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_printer_set, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View v) {
        titleBar = (TitleBar) v.findViewById(R.id.titleBar);
        tPrinterSearchView = (TPrinterSearchView) v.findViewById(R.id.tPrinterSearchView);
        tPrinterSearchView.setCallBack(model -> showPrinterEditorDialog(model,false));
        tvSearchLoading = (TextView) v.findViewById(R.id.tvSearchLoading);
        tvSelfAdd = (TextView) v.findViewById(R.id.tvSelfAdd);
        rvPrinters = (CompatibleListView) v.findViewById(R.id.rvPrinters);
        tvSearchLoading.setOnClickListener(this);
        tvSelfAdd.setOnClickListener(this);
        titleBar.setOnBackClickListener(() -> {
            BizcenterApi.uploadLocalChangeData(null);
            dismissSelf();
        });
    }

    private void showPrinterEditorDialog(final PrinterItem item, boolean isManualMode) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mProcessor.loadMenuCls(new ResultCallback<ArrayList<MenuClsBean>>() {
            @Override
            public void onSuccess(ArrayList<MenuClsBean> data) {
                progress.dismiss();
                PrinterEditorDialogFragment fragment = new PrinterEditorDialogFragment();
                fragment.setParam(item, data, TPrinterSetFragment.this);
                fragment.setIsManualMode(isManualMode);
                DialogManager.showCustomDialog(TPrinterSetFragment.this, fragment, "PrinterEditorDialogFragment");
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });

    }

    private View.OnClickListener innerClick = v -> {
        switch (v.getId()) {
            case R.id.tvPrinterRemove:
                PrinterItem model = (PrinterItem) v.getTag(R.id.tvPrinterRemove);
                loadDeletePrinter(model.id);
                break;
            case R.id.tvPrinterEditor:
                model = (PrinterItem) v.getTag(R.id.tvPrinterEditor);
                showPrinterEditorDialog(model, true);

                break;
            default:
                break;
        }
    };


    private void initData() {
        titleBar.setTitle("打印设置");
        mProcessor = new PrinterProcessor(getContext());
        printerAdapter = new CommonAdapter<PrinterItem>(getContext(), allPrinters, R.layout.t_printer_set_item) {
            @Override
            public void convert(ViewHolder holder, PrinterItem model, int position) {
                holder.setText(R.id.tvPrinterNameItem, model.name);
                holder.setText(R.id.tvPrinterCommadType, mProcessor.getPrinterType(model.type));
                holder.setText(R.id.tvPrinterLarge, getCommandTypeString(model.size));
                holder.getView(R.id.tvPrinterRemove).setTag(R.id.tvPrinterRemove, model);
                holder.getView(R.id.tvPrinterEditor).setTag(R.id.tvPrinterEditor, model);
                holder.getView(R.id.tvPrinterRemove).setOnClickListener(innerClick);
                holder.getView(R.id.tvPrinterEditor).setOnClickListener(innerClick);
            }

            public String getCommandTypeString(int fiPaperSize) {
                if (fiPaperSize == PrinterConstants.SIZE_58) {
                    return 58 + "mm";
                } else if (fiPaperSize == PrinterConstants.SIZE_80) {
                    return 80 + "mm";
                }
                return 76 + "mm";
            }
        };
        rvPrinters.setAdapter(printerAdapter);
        loadDataFromServer();
    }

    public void loadDataFromServer() {
        final Progress progress = ProgressManager.showProgress(this);
        mProcessor.loadAllPrinter(new ResultCallback<List<PrinterItem>>() {
            @Override
            public void onSuccess(List<PrinterItem> data) {
                printerAdapter.setData(data);
                progress.dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismiss();
            }
        });
    }

    private void loadDeletePrinter(int id) {
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), "删除中...");
        mProcessor.loadDeletePrinter(id, new ResultCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {
                progress.dismiss();
                ToastUtil.showToast("删除成功");
                loadDataFromServer();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tvSearchLoading:
                dealSearchPrinter();
                break;
            case R.id.tvSelfAdd:
                PrinterItem model = PrinterProcessor.buildPrinterItem(PrinterType.USB);
                model.name = "";
                showPrinterEditorDialog(model, true);
                break;
            default:
                break;
        }
    }

    private void dealSearchPrinter() {
        tPrinterSearchView.setVisibility(View.VISIBLE);
        tPrinterSearchView.modules.clear();
        //usb
        PrinterProcessor.loadConnectUsbPrinter(getActivityWithinHost(), new ResultCallback<ArrayList<PrinterItem>>() {
            @Override
            public void onSuccess(ArrayList<PrinterItem> data) {
                tPrinterSearchView.addAllPrinterModel(data);
            }
        });
        //蓝牙
        PrinterProcessor.loadBluetoothPrinter(new ResultCallback<ArrayList<PrinterItem>>() {
            @Override
            public void onSuccess(ArrayList<PrinterItem> data) {
                tPrinterSearchView.addAllPrinterModel(data);
            }
        });
        /**
         * 网络打印机搜索
         */
        PrinterConnectManager.getInstance().startSearch();
    }


    @Override
    public void onStart() {
        super.onStart();
        PrinterConnectManager.getInstance().addConnectWatcher(watcher);
    }

    @Override
    public void onStop() {
        super.onStop();
        PrinterConnectManager.getInstance().deleteWatcher(watcher);
        PrinterConnectManager.getInstance().stopSearch();//onDestroy不一定会执行
    }

    @Override
    public void onPrinterEditorSuccess() {
        loadDataFromServer();
    }

    @Override
    public void onPrinterAddSuccess() {
        loadDataFromServer();
    }
}
