package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.pos.component.datasync.net.BasePosResponse;

/**
 * Created by zhangmin on 2018/5/8.
 */

public class WXOpenPayResponse extends BasePosResponse {
    public WXOpenPayModel data = new WXOpenPayModel();

    public WXOpenPayResponse() {
    }

}
