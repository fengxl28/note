package com.mwee.android.pos.business.bill.view;

import android.content.Context;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.mwee.android.pos.business.bill.bean.SearchDataItem;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZM
 */

public class SearchNetOrderAdapter extends BaseAdapter implements Filterable {

    private Context context;
    public List<TempAppOrderSimpleInfo> tempAppOrderModels;
    public ArrayList<SearchDataItem> modules = new ArrayList<>();//匹配keyword
    private ArrayFilter mFilter;

    private String inputKeyWord = "";

    public SearchNetOrderAdapter(Context context, List<TempAppOrderSimpleInfo> tempAppOrderModels) {
        this.context = context;
        this.tempAppOrderModels = tempAppOrderModels;
    }


    public void setOrderListModels(List<TempAppOrderSimpleInfo> tempAppOrderModels) {
        this.tempAppOrderModels = tempAppOrderModels;
    }


    @Override
    public int getCount() {
        return modules == null ? 0 : modules.size();

    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.bill_search_hint_item, parent, false);
            holder.tv_item = (TextView) convertView.findViewById(R.id.tv_item);
            holder.tableNoLabel = convertView.findViewById(R.id.searchItem_tableNo_label);
            holder.orderNoLabel = convertView.findViewById(R.id.searchItem_orderNo_label);
            holder.splitLine = convertView.findViewById(R.id.searchItem_splitLine);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if(modules != null && position < modules.size()) {
            SearchDataItem searchData = modules.get(position);
            if(position == modules.size() - 1){
                holder.splitLine.setVisibility(View.GONE);
            }else{
                holder.splitLine.setVisibility(View.VISIBLE);
            }
            if(searchData.isOrderNo){
                holder.orderNoLabel.setVisibility(View.VISIBLE);
                holder.tableNoLabel.setVisibility(View.GONE);
            }else{
                holder.orderNoLabel.setVisibility(View.GONE);
                holder.tableNoLabel.setVisibility(View.VISIBLE);
            }
            String label = searchData.dataContent;
            String tempInputKeyWord = inputKeyWord;
            int index = label.indexOf(tempInputKeyWord);
            String start = "";
            if (index != -1) {
                start = label.substring(0, index);
            }

            if(start.length() + tempInputKeyWord.length() <= label.length()){
                String end = label.substring(start.length() + tempInputKeyWord.length(), label.length());
                holder.tv_item.setText(Html.fromHtml(start + "<u><font color= 'red' >" + tempInputKeyWord + "</font></u>" + end));
            }else{
                holder.tv_item.setText(label);
            }
        }
        return convertView;
    }


    private static class ViewHolder {
        public TextView tv_item;
        public View tableNoLabel;
        public View orderNoLabel;
        public View splitLine;
    }

    @Override
    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ArrayFilter();
        }
        return mFilter;
    }

    private class ArrayFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            if (TextUtils.isEmpty(constraint)) {//若输入为空
                results.values = null;
                results.count = 0;
            } else {//输入不为空
                inputKeyWord = constraint.toString();//将输入内容传出去
                LogUtil.log("inputKeyWord", inputKeyWord);
                ArrayList<SearchDataItem> values = new ArrayList<>();
                for (TempAppOrderSimpleInfo tempAppOrder : tempAppOrderModels) {
                    if (tempAppOrder.orderId.contains(inputKeyWord)) {
                        values.add(new SearchDataItem(true,tempAppOrder.orderId));
                    }
                }
                results.values = values;
                results.count = values.size();
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            modules = (ArrayList<SearchDataItem>) results.values;
            notifyDataSetChanged();
        }
    }


}
