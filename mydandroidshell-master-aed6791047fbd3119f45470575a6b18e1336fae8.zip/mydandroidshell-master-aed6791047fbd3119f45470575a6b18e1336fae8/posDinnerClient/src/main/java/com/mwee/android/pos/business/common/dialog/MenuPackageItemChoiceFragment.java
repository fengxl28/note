package com.mwee.android.pos.business.common.dialog;

import android.graphics.Color;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseSectionListFragment;
import com.mwee.android.pos.business.common.entity.SectionData;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.orderdishes.util.SpannableStringUtils;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuPackageGroup;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.NumberEditorView;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by qinwei on 2017/7/15.
 */

public class MenuPackageItemChoiceFragment extends BaseSectionListFragment<MenuPackageGroup, MenuItem> {
    private List<MenuPackageGroup> extraList;
    private OnMenuPackageItemChoiceListener listener;

    private ArrayList<MenuItem> selectPackageItems = new ArrayList<>();
    private ArrayMap<String, Boolean> selectCache = new ArrayMap<>();

    private boolean isOrdered = false;// 是否已下单
    private boolean isMember = false;// 是否是会员
    private boolean isRequestBackItem = false;//已经下单的配料菜 减去数量是否已经申请过权限
    private String voidReason = "";
    private UserDBModel voidUser;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_menu_package_item_choice;
    }


    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        if (!ListUtil.isEmpty(extraList)) {
            for (int i = 0; i < extraList.size(); i++) {
                MenuPackageGroup menuExtra = extraList.get(i);
                modules.add(new SectionData<MenuPackageGroup, MenuItem>(menuExtra, i));
                for (int j = 0; j < menuExtra.itemList.size(); j++) {
                    if (menuExtra.isSolid) {
                        menuExtra.itemList.get(j).selectedMenuPackageItem();
                        //选中必选套餐
                        selectCache.put(menuExtra.itemList.get(j).getMenuPackageItemId(menuExtra.id), true);
                    }
                    modules.add(new SectionData<MenuPackageGroup, MenuItem>(menuExtra.itemList.get(j)));
                }
            }
            dataChanged();
        }


    }

    private void dataChanged() {
        selectPackageItems.clear();
        if (listener != null) {
            for (SectionData<MenuPackageGroup, MenuItem> module : modules) {
                if (!module.isHeader && getPackageItemSelected(module.t, getHeader(module.t.categoryCode).id)) {
                    module.t.menuBiz.buyNum = module.t.menuBiz.buyNum.stripTrailingZeros();
                    selectPackageItems.add(module.t);
                }
            }
            listener.onMenuPackageItemDataChanged(selectPackageItems, voidReason, voidUser);
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return getGridLayoutManager(3);
    }

    @Override
    protected BaseViewHolder onCreateSectionHeaderView(ViewGroup parent) {
        return new SectionHeaderHolder(LayoutInflater.from(getContext()).inflate(R.layout.layout_menu_package_item_choice_header, parent, false));
    }

    class SectionHeaderHolder extends BaseViewHolder {
        private View mPackageGroupLine;
        private TextView mPackageGroupTitleLabel;
        private TextView mPackageGroupRulesLabel;

        public SectionHeaderHolder(View v) {
            super(v);
            mPackageGroupTitleLabel = (TextView) v.findViewById(R.id.mPackageGroupTitleLabel);
            mPackageGroupRulesLabel = (TextView) v.findViewById(R.id.mPackageGroupRulesLabel);
            mPackageGroupLine = v.findViewById(R.id.mPackageGroupLine);
        }

        @Override
        public void bindData(int position) {
            if (position != 0) {
                mPackageGroupLine.setVisibility(View.VISIBLE);
            } else {
                mPackageGroupLine.setVisibility(View.GONE);
            }
            MenuPackageGroup header = modules.get(position).header;
            mPackageGroupTitleLabel.setText(header.name);
            if (!header.isSolid) {
                mPackageGroupRulesLabel.setVisibility(View.VISIBLE);

                SpannableStringBuilder builder = new SpannableStringBuilder();
                builder.append(getString(R.string.menu_order_package_choice_group_select_label)).append(Calc.formatShow(DinnerMenuUtil.getSelectedMenuExtraCount(header, selectCache), 0));
                builder.append(" - ");
                int len_1 = builder.length();
                builder = SpannableStringUtils.format(builder, Color.BLACK, 16, 0, builder.length());
                builder.append(String.format(getString(R.string.menu_order_package_choice_rule), header.itemList.size(), header.pacFoodNum));
                builder = SpannableStringUtils.format(builder, ViewToolsUtil.getColor(GlobalCache.getContext(), R.color.system_red), 16, len_1, builder.length());

                mPackageGroupRulesLabel.setText(builder);
            } else {
                mPackageGroupRulesLabel.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected BaseViewHolder onCreateSectionItemView(ViewGroup parent, int viewType) {
        return new SectionItemHolder(LayoutInflater.from(getContext()).inflate(R.layout.layout_menu_package_item_choice_item, parent, false));
    }


    class SectionItemHolder extends BaseViewHolder implements View.OnClickListener, NumberEditorView.OnNumberEditorClickListener {
        private NumberEditorView mPackageChoiceItemNumberEditorView;
        private LinearLayout mPackageChoiceItemLayout;
        private TextView mPackageChoiceItemNameLabel;
        private TextView mPackageChoiceItemRemainLabel;
        private TextView mPackageChoiceItemAddPriceLabel;
        private TextView mPackageChoiceItemCountLabel;
        private MenuItem item;
        private MenuPackageGroup header;

        public SectionItemHolder(View v) {
            super(v);
            mPackageChoiceItemLayout = (LinearLayout) v.findViewById(R.id.mPackageChoiceItemLayout);
            mPackageChoiceItemNameLabel = (TextView) v.findViewById(R.id.mPackageChoiceItemNameLabel);
            mPackageChoiceItemRemainLabel = (TextView) v.findViewById(R.id.mPackageChoiceItemRemainLabel);
            mPackageChoiceItemAddPriceLabel = (TextView) v.findViewById(R.id.mPackageChoiceItemAddPriceLabel);
            mPackageChoiceItemNumberEditorView = (NumberEditorView) v.findViewById(R.id.mPackageChoiceItemNumberEditorView);
            mPackageChoiceItemCountLabel = (TextView) v.findViewById(R.id.mPackageChoiceItemCountLabel);
            mPackageChoiceItemNumberEditorView.setOnNumberEditorClick(this);
        }

        @Override
        public void bindData(int position) {
            item = modules.get(position).t;
            mPackageChoiceItemNameLabel.setText(item.name);
            BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(item.currentUnit.fiOrderUintCd);

            if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                mPackageChoiceItemRemainLabel.setVisibility(View.VISIBLE);
                mPackageChoiceItemRemainLabel.setText(String.format("剩余:%s", sellOutCount.toString() + item.currentUnit.fsOrderUint));
            } else {
                mPackageChoiceItemRemainLabel.setText("");
                mPackageChoiceItemRemainLabel.setVisibility(View.GONE);
            }

            header = getHeader(item.categoryCode);
            mPackageChoiceItemLayout.setTag(header);
            if (header.isSolid) {
                mPackageChoiceItemLayout.setSelected(true);
                mPackageChoiceItemLayout.setOnClickListener(null);
                mPackageChoiceItemNumberEditorView.setVisibility(View.GONE);
                mPackageChoiceItemCountLabel.setVisibility(View.VISIBLE);
                mPackageChoiceItemCountLabel.setText(Calc.formatShow(item.menuBiz.buyNum, 0));
            } else {
                mPackageChoiceItemCountLabel.setVisibility(View.GONE);
                mPackageChoiceItemLayout.setSelected(getPackageItemSelected(item, header.id));
                mPackageChoiceItemLayout.setTag(R.id.id_menu_extra_item, item);
                mPackageChoiceItemLayout.setTag(R.id.id_menu_extra, header);
                mPackageChoiceItemLayout.setOnClickListener(this);

                if (getPackageItemSelected(item, header.id)) {
                    mPackageChoiceItemNumberEditorView.setVisibility(View.VISIBLE);
                    mPackageChoiceItemNumberEditorView.notifyDataChanged(item.menuBiz.buyNum.intValue());
                } else {
                    mPackageChoiceItemNumberEditorView.setVisibility(View.INVISIBLE);
                }
            }
            if (item.currentUnit.fdSalePrice.compareTo(BigDecimal.ZERO) > 0) {
                mPackageChoiceItemAddPriceLabel.setVisibility(View.VISIBLE);
                mPackageChoiceItemAddPriceLabel.setText(String.format(getString(R.string.menu_order_item_price_label), Calc.formatShow(item.currentUnit.fdSalePrice)));
            } else {
                mPackageChoiceItemAddPriceLabel.setVisibility(View.GONE);
            }
        }


        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.mPackageChoiceItemLayout:
                    if (AppCache.getInstance().getSelloutNum(item.currentUnit.fiOrderUintCd).compareTo(BigDecimal.ZERO) == 0) {
                        ToastUtil.showToast(item.name + getString(R.string.menu_order_package_item_select_validate_msg));
                        return;
                    }
                    if (getPackageItemSelected(item, header.id)) {
                        item.menuBiz.buyNum = new BigDecimal(item.currentUnit.fiInitCount);
                        selectCache.put(item.getMenuPackageItemId(header.id), false);
                        LogUtil.log(item.itemID + "取消选中：" + item.name);
                    } else {
                        LogUtil.log(item.itemID + "点击菜品：" + item.name);
                        boolean canAddSelected = DinnerMenuUtil.canAddSelected((MenuPackageGroup) mPackageChoiceItemLayout.getTag(), BigDecimal.ONE, selectCache);
                        if (canAddSelected) {
                            if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                                item.menuBiz.buyNum = BigDecimal.ONE;
                            }
                            item.calcTotal(false);
                            item.selectedMenuPackageItem();
                            selectCache.put(item.getMenuPackageItemId(header.id), true);
                        }
                    }
                    dataChanged();
                    break;
                default:
                    break;
            }
        }

        @Override
        public boolean onMinusClick(View view, int before, int after) {
            ActionLog.addLog(item.itemID + "点击减菜按钮：" + item.name, ActionLog.FF_MENU);
            if (isOrdered && !isRequestBackItem) {
                PermissionsUtil.requestPermissionBackMenu(MenuPackageItemChoiceFragment.this, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, item, new PermissionCallback() {
                    @Override
                    public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                        ActionLog.addLog(item.itemID + "点击减菜按钮：" + item.name + "，做退菜操作：" + msg + "[" + errCode + "]", ActionLog.DF_MENU_EDITOR);
                        isRequestBackItem = true;//设置请求过退菜权限 下次不再进行权限的申请
                        if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0) {
                            item.menuBiz.buyNum = item.menuBiz.buyNum.subtract(BigDecimal.ONE);
                            voidReason = msg;
                            voidUser = userDBModel;
                            item.selectedMenuPackageItem();
                            selectCache.put(item.getMenuPackageItemId(header.id), true);
                        }
                        if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                            item.menuBiz.buyNum = new BigDecimal(item.currentUnit.fiInitCount);
                            selectCache.put(item.getMenuPackageItemId(header.id), false);
                        }
                        item.calcTotal(isMember);
                        dataChanged();
                    }
                });
            } else {
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0) {
                    item.menuBiz.buyNum = item.menuBiz.buyNum.subtract(BigDecimal.ONE);
                    item.selectedMenuPackageItem();
                    selectCache.put(item.getMenuPackageItemId(header.id), true);
                }
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                    item.menuBiz.buyNum = new BigDecimal(item.currentUnit.fiInitCount);
                    selectCache.put(item.getMenuPackageItemId(header.id), false);
                }
                dataChanged();
                LogUtil.log(item.itemID + "点击减菜按钮：" + item.name + (getPackageItemSelected(item, header.id) ? "剩余数量：" + item.menuBiz.buyNum : "全部减完"));
            }
            return getPackageItemSelected(item, header.id);
        }

        @Override
        public boolean onAddClick(View view, int before, int after) {
            ActionLog.addLog(item.itemID + "点击加菜按钮：" + item.name, ActionLog.FF_MENU);
            if (DinnerMenuUtil.canAddSelected(header, BigDecimal.ONE, selectCache)) {
                item.menuBiz.buyNum = item.menuBiz.buyNum.add(BigDecimal.ONE);
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0) {
                    item.selectedMenuPackageItem();
                    selectCache.put(item.getMenuPackageItemId(header.id), true);
                } else {
                    item.menuBiz.buyNum = new BigDecimal(item.currentUnit.fiInitCount);
                    selectCache.put(item.getMenuPackageItemId(header.id), false);
                }
                item.calcTotal(isMember);
                // LogBiz.logNoEnv(item.itemID + "菜品数量：" + item.menuBiz.buyNum);
                dataChanged();
                return true;
            }
            return false;
        }

        @Override
        public void onNumberEditorClick() {
            showQuantity(header, item);
        }

        private void showQuantity(final MenuPackageGroup group, final MenuItem item) {
            // LogBiz.logNoEnv("点击直接改数：" + group.name);

            ActionLog.addLog("点击直接改数：" + group.name, ActionLog.FF_MENU);

            CountKeyboardFragment fragment = new CountKeyboardFragment();
            fragment.setTitle(getString(R.string.number_title));
            fragment.setErrorTips(getString(R.string.number_error_tip));
            fragment.setOriginCount(item.menuBiz.buyNum);
            fragment.setIsSupportFloat(false);
            fragment.setCanBe0(false);
            fragment.setCallback(new CountKeyboardCallback() {
                @Override
                public void callback(BigDecimal originNum, BigDecimal newNum) {
                    /**
                     * 如果没有发生变化,则不作处理
                     */
                    if (originNum.compareTo(newNum) == 0) {
                        return;
                    }

                    BigDecimal sellOutNum = AppCache.getInstance().getSelloutNum(item.currentUnit.fiOrderUintCd);
                    if (sellOutNum.compareTo(new BigDecimal(-1)) > 0) {
                        if (item.menuBiz.buyNum.compareTo(sellOutNum) == 0) {//数量大于估清数量
                            ToastUtil.showToast(item.name + getString(R.string.menu_order_package_item_select_validate_msg));
                            return;
                        }
                    }

                    if (newNum.compareTo(BigDecimal.ZERO) < 0) {
                        item.menuBiz.buyNum = new BigDecimal(item.currentUnit.fiInitCount);
                        selectCache.put(item.getMenuPackageItemId(header.id), false);
                        dataChanged();
                    } else {
                        if (DinnerMenuUtil.canModifyNum(group, item, newNum, selectCache)) {
                            item.selectedMenuPackageItem();
                            item.menuBiz.buyNum = newNum;
                            dataChanged();
                        } else {
                            ToastUtil.showToast(String.format(getContextWithinHost().getResources().getString(R.string.the_most_selections), group.pacFoodNum));
                        }
                    }

                }
            });
            fragment.setMaxCount(999);
            DialogManager.showCustomDialog(getActivityWithinHost(), fragment, CountKeyboardFragment.FRAGMENT_TAG);
        }
    }

    public MenuPackageGroup getHeader(String id) {
        for (int i = 0; i < modules.size(); i++) {
            if (modules.get(i).isHeader && TextUtils.equals(modules.get(i).header.id, id)) {
                return modules.get(i).header;
            }
        }
        return null;
    }

    /**
     */
    public void setParam(List<MenuPackageGroup> extraList, ArrayMap<String, Boolean> selectCache, OnMenuPackageItemChoiceListener listener) {
        setParam(extraList, selectCache, listener, false, false);
    }

    public void setParam(List<MenuPackageGroup> extraList, ArrayMap<String, Boolean> selectCache, OnMenuPackageItemChoiceListener listener, boolean isOrdered, boolean isMember) {
        this.listener = listener;
        this.extraList = extraList;
        this.selectCache = selectCache;
        this.isOrdered = isOrdered;
        this.isMember = isMember;
    }

    public interface OnMenuPackageItemChoiceListener {
        void onMenuPackageItemDataChanged(ArrayList<MenuItem> modules, String voidReason, UserDBModel voidUser);
    }

    private boolean getPackageItemSelected(MenuItem item, String id) {
        Boolean flag = selectCache.get(item.getMenuPackageItemId(id));
        if (flag == null) {
            return false;
        }
        return flag;
    }
}
