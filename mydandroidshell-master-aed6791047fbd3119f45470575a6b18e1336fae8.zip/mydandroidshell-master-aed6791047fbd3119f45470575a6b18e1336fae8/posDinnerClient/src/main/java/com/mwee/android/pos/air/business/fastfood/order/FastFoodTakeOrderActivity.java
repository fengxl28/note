package com.mwee.android.pos.air.business.fastfood.order;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.fastfood.api.FastFoodOrderSocketApi;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodMenuItemProcessor;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodProcessor;
import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.pay.connect.PayDinnerJump;
import com.mwee.android.pos.business.pay.view.component.IPayCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/11/8.
 */

public class FastFoodTakeOrderActivity extends BaseActivity implements View.OnClickListener, IPayCallback, AirFastFoodOrderMenuAdapter.OnItemClickListener, AirFastTakeOrderMealNumberAdapter.OnMealNumberItemClick {


    private TitleBar titleBar;
    private RecyclerView mRecyclerView;
    private ExpandableListView mTakeOrderLsv;

    private TextView mMenuAddLabel;
    private TextView mCheckLabel;

    private TextView tvMealNumber;
    private TextView tvMealNumberModify;
    private TextView tvMemberName;
    private TextView tvOrderId;

    private AirFastTakeOrderMealNumberAdapter mealNumberAdapter;
    private AirFastFoodOrderMenuAdapter takeOrderMenuAdapter;

    boolean isFirstLoadAll = true;

    private FastFoodMenuItemProcessor mMenuItemProcessor;
    private FastFoodProcessor mFastFoodProcessor;

    private FastFoodDishCache dishCache;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air_take_order);
        assignViews();
        init();

    }


    private void assignViews() {

        titleBar = findViewById(R.id.titleBar);
        mRecyclerView = findViewById(R.id.mRecyclerView);
        mTakeOrderLsv = findViewById(R.id.mTakeOrderLsv);

        tvMealNumber = findViewById(R.id.tvMealNumber);
        tvMealNumberModify = findViewById(R.id.tvMealNumberModify);
        tvMemberName = findViewById(R.id.tvMemberName);
        tvOrderId = findViewById(R.id.tvOrderId);

        mMenuAddLabel = findViewById(R.id.mMenuAddLabel);
        mCheckLabel = findViewById(R.id.mCheckLabel);

        tvMealNumberModify.setOnClickListener(this);
        mMenuAddLabel.setOnClickListener(this);
        mCheckLabel.setOnClickListener(this);

        mTakeOrderLsv.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long l) {
                return true;
            }
        });

    }


    private void init() {

        mMenuItemProcessor = new FastFoodMenuItemProcessor(this);
        mFastFoodProcessor = new FastFoodProcessor();

        titleBar.setTitle("取单");
        titleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });

        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        mealNumberAdapter = new AirFastTakeOrderMealNumberAdapter(getActivityWithinHost());
        mealNumberAdapter.setOnMealNumberItemClick(this);
        mRecyclerView.setAdapter(mealNumberAdapter);

        takeOrderMenuAdapter = new AirFastFoodOrderMenuAdapter(getActivityWithinHost());
        mTakeOrderLsv.setAdapter(takeOrderMenuAdapter);
        mTakeOrderLsv.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int i, long l) {
                return true;
            }
        });

        takeOrderMenuAdapter.setOrderClickListener(this);

        loadAllFastFoodOrder();

    }

    private void loadAllFastFoodOrder() {
        mFastFoodProcessor.loadAllFastFoodOrder("1", new ResultCallback<List<FastFoodSimpInfo>>() {
            @Override
            public void onSuccess(List<FastFoodSimpInfo> data) {
                refreshMealNumberAdapter(data);
                if (isFirstLoadAll) {
                    isFirstLoadAll = false;
                    loadOrderCacheById(data.get(0).order_id);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });

    }

    private void loadOrderCacheById(String orderId) {
        mFastFoodProcessor.loadOrderCacheById(orderId, new ResultCallback<StartFastFoodOrderResponse>() {
            @Override
            public void onSuccess(StartFastFoodOrderResponse data) {
                dishCache = new FastFoodDishCache();
                dishCache.fastOrderModel = data.fastOrderModel;
                if (!ListUtil.isEmpty(data.menuItems)) {
                    dishCache.menuItems.addAll(data.menuItems);
                }
                refreshOrderMenuAdapter(dishCache);
                refreshOrderTopBottom(dishCache);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }


    private void refreshMealNumberAdapter(List<FastFoodSimpInfo> modules) {
        mealNumberAdapter.modules.clear();
        mealNumberAdapter.modules.addAll(modules);
        mealNumberAdapter.notifyDataSetChanged();
    }


    private void refreshOrderMenuAdapter(FastFoodDishCache dishCache) {
        takeOrderMenuAdapter.refreshView(dishCache);
        for (int i = 0; i < takeOrderMenuAdapter.getGroupCount(); i++) {
            mTakeOrderLsv.expandGroup(i);
        }

    }


    private void refreshOrderTopBottom(FastFoodDishCache dishCache) {

        tvMealNumber.setText(String.format("牌号:%s", dishCache.fastOrderModel.mealNumber));
        tvOrderId.setText(String.format("订单号:%s", dishCache.fastOrderModel.orderId));
        tvMemberName.setText(dishCache.fastOrderModel.isMember ? String.format("会员:%s", dishCache.fastOrderModel.memberInfoS.real_name) : "");


    }


    @Override
    public void onClick(View view) {

        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (view.getId()) {

            case R.id.tvMealNumberModify://修改
                showSetMealNumberFragment(dishCache, new CountKeyboardCallback() {
                    @Override
                    public void callback(BigDecimal originNum, BigDecimal newNum) {
                        doUpdateOrderMealNumber(dishCache, newNum.intValue());
                    }
                });
                break;
            case R.id.mMenuAddLabel: //加菜
                Intent intent = new Intent();
                intent.putExtra(Constants.FAST_ORDER_INFO, dishCache.fastOrderModel);
                intent.putExtra(Constants.FAST_ORDER_MENUS, dishCache.menuItems);
                setResult(RESULT_OK, intent);
                this.finish();

                break;
            case R.id.mCheckLabel: //结账

                if (!mFastFoodProcessor.checkOrder(dishCache)) {
                    return;
                }
                loadMenuItemsInsertToSellDB(false);
                break;
            default:
                break;
        }
    }


    /**
     * 结帐前将未下单的菜品入库
     *
     * @param isOnlinePay
     */
    public void loadMenuItemsInsertToSellDB(final boolean isOnlinePay) {
        ArrayList<MenuItem> menuItems = dishCache.getFastFoodNotOrderMenuItems();
        if (ListUtil.isEmpty(menuItems)) {
            goPayDinnerFragment(isOnlinePay);
        } else {
            final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
            mFastFoodProcessor.loadMenuItemsInsertToSellDB(dishCache.fastOrderModel.orderId, menuItems, dishCache.fastOrderModel.mealNumber, new ResultCallback<OnlyOrderMenuItemsResponse>() {
                @Override
                public void onSuccess(OnlyOrderMenuItemsResponse data) {
                    progress.dismiss();
                    goPayDinnerFragment(isOnlinePay);
                }

                @Override
                public void onFailure(int code, String msg) {
                    progress.dismiss();
                    ToastUtil.showToast(msg);
                }
            });
        }

    }

    /**
     * 跳转收银界面
     *
     * @param isOnlinePay true代表手机支付，false 跳转到收银界面
     */
    public void goPayDinnerFragment(boolean isOnlinePay) {
        if (isOnlinePay) {
            trace("显示手机支付", ActionLog.FF_ORDER_MOBILE_PAY);
            if (dishCache.fastOrderModel.totalPrice.compareTo(BigDecimal.ZERO) == 0) {
                ToastUtil.showToast("待支付金额为0");
                return;
            }
            if (dishCache.antiPay) {
                PayDinnerJump.jumpToOnlineRePayForFastFood(this, dishCache.fastOrderModel.orderId, android.R.id.content, this);
            } else {
                PayDinnerJump.jumpToOnlinePayForFastFood(this, dishCache.fastOrderModel.orderId, android.R.id.content, this);
            }
        } else {
            trace("跳转结帐界面", ActionLog.FF_ORDER_PAY);
            if (dishCache.antiPay) {
                PayDinnerJump.jumpToRePay(getActivityWithinHost(), dishCache.fastOrderModel.orderId, android.R.id.content, this);
            } else {
                PayDinnerJump.jumpToPayForFastFood(getActivityWithinHost(), dishCache.fastOrderModel.orderId, android.R.id.content, false, this);
            }
        }
    }


    private void trace(String msg, String action) {
        trace(msg, action, "");
    }

    private void trace(String msg, String action, Object arg0) {
        ActionLog.addLog("快餐点单界面->" + msg, dishCache.getOrderId(), dishCache.fastOrderModel.mealNumber, action, arg0);
    }


    private void showSetMealNumberFragment(FastFoodDishCache mDishCache, CountKeyboardCallback callback) {
        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle("设置牌号");
        fragment.setErrorTips("请输入牌号");
        if (android.text.TextUtils.isEmpty(mDishCache.fastOrderModel.mealNumber)) {
            fragment.setOriginCount(BigDecimal.ZERO);
        } else {
            fragment.setOriginCount(new BigDecimal(mDishCache.fastOrderModel.mealNumber));

        }
        fragment.setCanBe0(true);
        fragment.setCallback(callback);
        fragment.setMaxCount(999);
        //ActionLog.addLog("快餐点单界面->显示输入牌号界面", mDishCache.fastOrderModel.orderId, mDishCache.fastOrderModel.mealNumber, ActionLog.FF_ORDER_PAY, "");
        DialogManager.showCustomDialog(getActivityWithinHost(), fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }

    private void doUpdateOrderMealNumber(final FastFoodDishCache mDishCache, final int count) {
        //final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost());
        FastFoodOrderSocketApi.loadUpdateMealNumber(mDishCache.getOrderId(), count + "", new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                //progress.dismiss();
                mDishCache.fastOrderModel.mealNumber = count + "";
                tvMealNumber.setText(String.format("牌号:%s", count));
                loadAllFastFoodOrder();
            }

            @Override
            public void onFailure(int code, String msg) {
                //progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    /*----------------支付结果的回调----------------*/
    @Override
    public void payFinish(int result) {
        if (result == IPayCallback.FINISH) {
            finish();
        }
    }


    /*----------------左边点击牌号的回调----------------*/
    @Override
    public void onMealNumberItemClick(String orderId) {
        loadOrderCacheById(orderId);
    }



    /*-----------------右边菜品列表的回调----------------*/

    @Override
    public void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel) {
        trace("已下单称重,显示称重界面", ActionLog.FF_ORDER_PAY);
        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, dishCache.fastOrderModel.orderId, new ResultCallback<UpdateBuyNumResponse>() {
            @Override
            public void onSuccess(UpdateBuyNumResponse data) {
                trace("称重修改成功:" + item.menuBiz.buyNum.toString(), ActionLog.FF_MENU_NUMBER);
                dishCache.replaceMenuItem(item, data.menuItem);

                takeOrderMenuAdapter.refreshView(dishCache);
                //DriverBus.call("menuview/refreshMenu");
                //refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                trace("称重修改失败:" + msg, ActionLog.FF_MENU_NUMBER);

                //TODO
                /*if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    DriverBus.call("menuview/refreshMenu");
                } else {
                    dismissSelf();
                }*/
            }
        });
    }

    @Override
    public void doChangeOrderedMenuPrice(final MenuItem menuItem, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateDishPrice(dishCache.getOrderId(), menuItem, true, new ResultCallback<OperateDishToCenterResponse>() {
            @Override
            public void onSuccess(OperateDishToCenterResponse data) {
                trace("菜品改价成功：" + menuItem.toString(), ActionLog.FF_MENU_PRICE, menuItem);
                //替换server处理后的菜品信息
                dishCache.replaceMenuItem(menuItem, data.menuItem);
                takeOrderMenuAdapter.refreshView(dishCache);

            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                trace("菜品改价失败," + menuItem.toString() + ":" + msg, ActionLog.FF_MENU_PRICE);
            }
        });
    }

    @Override
    public void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg) {

        mMenuItemProcessor.doRetreatDish(dishCache.getOrderId(), item, msg, new ResultCallback<BactchReturnDishesForFastFoodResponse>() {
            @Override
            public void onSuccess(BactchReturnDishesForFastFoodResponse data) {
                //可以优化
                dishCache.replaceAllMenuItems(data.menuItemList);
                takeOrderMenuAdapter.refreshView(dishCache);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void doDeleteMenu(MenuItem item) {
        //adapter.selectPosition = -1;
        dishCache.removeFastFoodMenuItem(item);
        takeOrderMenuAdapter.refreshView(dishCache);
        loadDeleteMenu(item);
    }

    @Override
    public void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel) {
        trace("显示菜品改数弹框", ActionLog.FF_MENU_NUMBER);
        ModifyQuantityUtils.showModifyQuantitySupportWeight(this, item, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                trace("改数结果，修改前:" + originNum.toString() + ",修改后:" + newNum.toString(), ActionLog.FF_MENU_NUMBER);
                if (newNum.compareTo(BigDecimal.ZERO) < 1 || originNum.compareTo(newNum) == 0) {
                    return;
                }
                //沽清判断
                if (OrderDishesBizUtil.isOutOfStock(dishCache.tempUnitQuantity, item, newNum)) {
                    return;
                }
                item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type));
                //重新计算价格
                item.calcTotal(dishCache.isBindMember());
                //更新DishCache缓存信息
                //dishCache.initSelectUnitQuantity();
                takeOrderMenuAdapter.refreshView(dishCache);
                DriverBus.broadcast("notifyall");
                loadUpdateMenuItem(item);
            }
        });
    }



    public void loadDeleteMenu(final MenuItem item) {
        mMenuItemProcessor.doDeleteMenuItem(dishCache.getOrderId(), item.menuBiz.uniq, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                //refreshOrderInfo(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "退出", "重试", new DialogResponseListener() {
                    @Override
                    public void response() {
                        loadDeleteMenu(item);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        logout();
                    }
                });
            }
        });
    }


    private void loadUpdateMenuItem(MenuItem menuItem) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(menuItem);
        loadUpdateMenuItem(menuItems);
    }

    private void loadUpdateMenuItem(final ArrayList<MenuItem> menuItems) {
        mMenuItemProcessor.doUpdateMenuItem(dishCache.getOrderId(), menuItems, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                //refreshOrderInfo(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "取消", "重试", new DialogResponseListener() {
                    @Override
                    public void response() {
                        loadUpdateMenuItem(menuItems);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        logout();
                    }
                });
            }
        });
    }



    private void logout() {
        DriverBus.call(Constants.DRIVER_TAG_LOGOUT);
    }

}



