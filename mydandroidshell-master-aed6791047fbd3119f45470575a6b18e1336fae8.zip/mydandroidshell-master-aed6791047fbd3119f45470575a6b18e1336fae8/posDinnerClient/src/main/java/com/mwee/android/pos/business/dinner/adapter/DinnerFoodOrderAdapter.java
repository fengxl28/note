package com.mwee.android.pos.business.dinner.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.dinner.DishUtils;
import com.mwee.android.pos.business.dinner.processor.DataSortProcessor;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.component.member.net.model.MemberDishCouponBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.DisplayUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 点菜界面数据适配器
 * Created by qinwei on 2017/4/27.
 */

public class DinnerFoodOrderAdapter extends BaseAdapter {
    private DishCache dishCache;//点菜cache
    private Context mContext;
    private Host mHost;
    private OnDinnerFoodOrderItemClickListener listener;
    //    public int selectPosition = -1;
    public String selectItemUniq = "";
    public ArrayList<MenuItem> modules = new ArrayList<>();
    private int dp10 = DisplayUtil.dp2px(GlobalCache.getContext(), 10);
    private int dp5 = DisplayUtil.dp2px(GlobalCache.getContext(), 5);

    public DinnerFoodOrderAdapter(Host mHost, DishCache dishCache) {
        this.dishCache = dishCache;
        if (dishCache.order != null && !ListUtil.isEmpty(dishCache.order.originMenuList)) {
            modules.addAll(dishCache.order.originMenuList);
        }
        if (!ListUtil.isEmpty(dishCache.orderDishesCache.tempSelectedMenuList)) {
            modules.addAll(0, dishCache.orderDishesCache.tempSelectedMenuList);
        }
        DataSortProcessor.handleDataBySetting(modules, dishCache.order);
        this.mContext = mHost.getContextWithinHost();
        this.mHost = mHost;
    }

    /**
     * 更新ui
     *
     * @param dishCache
     */
    public void notifyDataChanged(DishCache dishCache) {
        this.dishCache = dishCache;
        modules.clear();
        if (dishCache.order != null && !ListUtil.isEmpty(dishCache.order.originMenuList)) {
            modules.addAll(dishCache.order.originMenuList);
        }
        if (!ListUtil.isEmpty(dishCache.orderDishesCache.tempSelectedMenuList)) {
            modules.addAll(0, dishCache.orderDishesCache.tempSelectedMenuList);
        }
        DataSortProcessor.handleDataBySetting(modules, dishCache.order);
        notifyDataSetChanged();
    }

    public int getItemPosition() {
        return DataSortProcessor.findItemPosition(modules, selectItemUniq);
    }

    @Override
    public int getCount() {
        return modules.size();
    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.layout_dinner_food_order_dishes_item, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // 餐标/低消补充菜不显示
        AbsListView.LayoutParams lp = null;
        if (DinnerStandardUtil.isStandardMenu(modules.get(position).itemID)) {
            convertView.setVisibility(View.GONE);
            lp = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        } else {
            convertView.setVisibility(View.VISIBLE);
            lp = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        convertView.setLayoutParams(lp);

        holder.bindData(position);
        return convertView;
    }

    class ViewHolder implements View.OnClickListener {
        private View itemView;
        private View ingredient_line;
        private MenuItem menuItem;
        private LinearLayout mDinnerOrderItemTop;//点菜头部信息layout
        private ImageView mDinnerOrderItemStatusImg;//订单状态
        private TextView mDinnerOrderItemNameLabel;//菜品名称
        private TextView mDinnerOrderItemNoteContentLabel;//备注
        private TextView mDinnerOrderItemUsernameLabel;//操作人
        private TextView mDinnerOrderItemCreateTimeLabel;//创建时间
        private TextView mDinnerOrderItemReminderCountLabel;//催菜次数
        private TextView mDinnerOrderItemTheDishesLabel;//起菜
        private TextView mDinnerOrderItemNumLabel;//点菜份数
        private TextView mDinnerOrderItemNumHintLabel;//沽清数量
        private TextView mDinnerOrderItemNomalPriceLabel;//菜品原始金额
        private TextView mDinnerOrderItemPriceLabel;//菜品金额

        private TextView mDinnerOrderItemTagMemberCoupon; // 菜品券tag
        private TextView mDinnerOrderItemTagDiscountLabel;//折扣icon
        private TextView mDinnerOrderItemTagbuygiftTv;//买减
        private ImageView mDinnerOrderItemTagGiftImg;//赠送icon
        private ImageView mDinnerOrderItemTagMemberImg;//会员价icon

        private TextView mDinnerOrderItemDeleteOrReturnLabel;//删除icon
        private UnScollerListView mDinnerOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mDinnerOrderItemPackageLsv;//套餐明细列表
        private LinearLayout mDinnerOrderItemManagerLayout;//菜品管理布局
        private TextView mDinnerOrderItemNoteLabel;//菜品要求
        private TextView mDinnerOrderItemDoWaitLabel;//菜品等叫
        private TextView mDinnerOrderItemEditLabel;//菜品编辑
        private TextView mDinnerOrderItemHurryLabel;//菜品催菜
        private TextView mDinnerOrderItemTurnLabel;//菜品转菜
        private TextView mDinnerOrderItemDiscountLabel;//菜品优惠折扣
        private TextView mDinnerOrderItemWaitLabel;//新菜等叫标签
        private TextView mDinnerOrderItemPaddleLabel;//菜品划菜操作
        private View mDinnerOrderItemSplitLine;//item分隔线
        private View mDinnerOrderItemVirtualLine;//点菜批次分割线
        private TextView mDinnerOrderItemVirtualLineText;//点菜批次分割线上的文字
        private TextView mDinnerOrderItemOriginTable;//点菜批次分割线上的文字

        private TextView mDelimit; // 划菜剩余数量

        public ViewHolder(View v) {
            itemView = v;
            mDinnerOrderItemTop = (LinearLayout) v.findViewById(R.id.mDinnerOrderItemTop);
            mDinnerOrderItemStatusImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemStatusImg);
            mDinnerOrderItemNameLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNameLabel);
            mDinnerOrderItemNoteContentLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNoteContentLabel);
            mDinnerOrderItemUsernameLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemUsernameLabel);
            mDinnerOrderItemCreateTimeLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemCreateTimeLabel);
            mDinnerOrderItemReminderCountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemReminderCountLabel);
            mDinnerOrderItemTheDishesLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTheDishesLabel);
            mDinnerOrderItemNumLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNumLabel);
            mDinnerOrderItemNumHintLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNumHintLabel);
            mDinnerOrderItemPriceLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemPriceLabel);
            mDinnerOrderItemNomalPriceLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNomalPriceLabel);

            mDinnerOrderItemTagDiscountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTagDiscountLabel);
            mDinnerOrderItemTagGiftImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemTagGiftImg);
            mDinnerOrderItemTagMemberImg = (ImageView) v.findViewById(R.id.mDinnerOrderItemTagMemberImg);
            mDinnerOrderItemTagbuygiftTv = (TextView) v.findViewById(R.id.mDinnerOrderItemTagbuygiftTv);
            mDinnerOrderItemTagMemberCoupon = (TextView) v.findViewById(R.id.mDinnerOrderItemTagMemberCoupon);

            mDinnerOrderItemDeleteOrReturnLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDeleteOrReturnLabel);
            mDinnerOrderItemIngredientLsv = (UnScollerListView) v.findViewById(R.id.mDinnerOrderItemIngredientLsv);
            mDinnerOrderItemPackageLsv = (CompatibleListView) v.findViewById(R.id.mDinnerOrderItemPackageLsv);
            ingredient_line = v.findViewById(R.id.ingredient_line);
            mDinnerOrderItemManagerLayout = (LinearLayout) v.findViewById(R.id.mDinnerOrderItemManagerLayout);
            mDinnerOrderItemNoteLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemNoteLabel);
            mDinnerOrderItemDoWaitLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDoWaitLabel);
            mDinnerOrderItemPaddleLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemPaddleLabel);
            mDinnerOrderItemEditLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemEditLabel);
            mDinnerOrderItemWaitLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemWaitLabel);
            mDinnerOrderItemHurryLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemHurryLabel);
            mDinnerOrderItemPaddleLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemPaddleLabel);
            mDinnerOrderItemTurnLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemTurnLabel);
            mDinnerOrderItemDiscountLabel = (TextView) v.findViewById(R.id.mDinnerOrderItemDiscountLabel);
            mDinnerOrderItemSplitLine = v.findViewById(R.id.mDinnerOrderItem_splitLine);
            mDinnerOrderItemVirtualLine = v.findViewById(R.id.mDinnerOrderItem_virtualLine);
            mDinnerOrderItemVirtualLineText = v.findViewById(R.id.mDinnerOrderItem_virtualLine_text);
            mDinnerOrderItemOriginTable = v.findViewById(R.id.mDinnerOrderItemOriginTable);
            mDinnerOrderItemDeleteOrReturnLabel.setOnClickListener(this);
            mDinnerOrderItemTop.setOnClickListener(this);
            mDinnerOrderItemEditLabel.setOnClickListener(this);
            mDinnerOrderItemNameLabel.setOnClickListener(this);

            mDelimit = v.findViewById(R.id.tv_dinner_food_order_delimit);
        }

        /**
         * ui处理
         *
         * @param position
         */
        public void bindData(int position) {
            menuItem = modules.get(position);
            removeAllLine();
            mDinnerOrderItemNameLabel.setText(menuItem.name);
            mDinnerOrderItemNameLabel.setBackgroundResource(0);
            mDinnerOrderItemNameLabel.setPadding(0, 0, 0, 0);
            mDinnerOrderItemSplitLine.setVisibility(View.VISIBLE);
            mDinnerOrderItemVirtualLine.setVisibility(View.GONE);
            //设置备注显示
            String note = getMenuItemNoteContent().trim();
            if (TextUtils.isEmpty(note)) {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mDinnerOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mDinnerOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint);
            } else {
                mDinnerOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }

            //时价菜 价格加样式
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid()) {
                mDinnerOrderItemPriceLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mDinnerOrderItemPriceLabel.setText("时价");
                mDinnerOrderItemPriceLabel.setOnClickListener(this);
            } else {
                mDinnerOrderItemPriceLabel.setBackgroundResource(0);
                mDinnerOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                mDinnerOrderItemPriceLabel.setOnClickListener(null);
            }

            if (menuItem.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && (menuItem.menuBiz.checkBuyGift() || menuItem.isGift() || menuItem.useMemberPrice || menuItem.menuBiz.selectDiscount != null || (menuItem.menuBiz.checkSpecialPrice()) && menuItem.menuBiz.bugGiftItem == null)) {
                mDinnerOrderItemNomalPriceLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNomalPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNomalPriceLabel);
            } else {
                mDinnerOrderItemNomalPriceLabel.setVisibility(View.GONE);
            }

            //优惠信息tag
            showCouponTag(menuItem, mDinnerOrderItemTagGiftImg, mDinnerOrderItemTagDiscountLabel, mDinnerOrderItemTagMemberImg, mDinnerOrderItemTagbuygiftTv, mDinnerOrderItemTagMemberCoupon);

            //配料菜列表展示
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                ingredient_line.setVisibility(View.VISIBLE);
                mDinnerOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<MenuItem> ingredientAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<MenuItem>(mContext, menuItem.menuBiz.selectedModifier, R.layout.item_dinner_food_order_ingredient) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem ingredient, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.tv_ingredient_name);
                            name.setText(ingredient.name);

                            TextView count = (TextView) viewHolder.getView(R.id.tv_ingredient_num);
                            TextView normalPrice = (TextView) viewHolder.getView(R.id.tv_ingredient_normal_price);
                            TextView price = (TextView) viewHolder.getView(R.id.tv_ingredient_price);

                            String voidInfo = "";

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }

                            BigDecimal voidNum = ingredient.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(ingredient.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum + "]";
                            }
                            BigDecimal buyAllNum = ingredient.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString() + voidInfo);
                            } else {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString());
                            }
                            price.setText(Calc.formatShow(ingredient.menuBiz.totalPrice.multiply(tempBuyNum.subtract(tempVoidNum)), RoundConfig.ROUND_SINGLE_PRICE));

                            if (/*item.menuBiz.nomalTotalPrice.compareTo(BigDecimal.ZERO) > 0 && */(ingredient.menuBiz.checkBuyGift() || ingredient.isGift() || ingredient.useMemberPrice || ingredient.menuBiz.selectDiscount != null || (ingredient.menuBiz.checkSpecialPrice()) && ingredient.menuBiz.bugGiftItem == null)) {
                                normalPrice.setVisibility(View.VISIBLE);
                                normalPrice.setText(Calc.formatShow(ingredient.menuBiz.nomalTotalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                                com.mwee.android.pos.util.TextUtils.addLine(normalPrice);
                            } else {
                                normalPrice.setVisibility(View.GONE);
                            }

                            //优惠信息tag
                            showCouponTag(ingredient, viewHolder.getView(R.id.iv_gift_tag), viewHolder.getView(R.id.tv_discount_tag),
                                    viewHolder.getView(R.id.iv_member_tag), viewHolder.getView(R.id.tv_buygift_tag), null);
                        }
                    };
                    mDinnerOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(menuItem.menuBiz.selectedModifier);
                }
            } else {
                ingredient_line.setVisibility(View.GONE);
                mDinnerOrderItemIngredientLsv.setVisibility(View.GONE);
            }

            //套餐明细显示
            if (menuItem.supportPackage()) {
                mDinnerOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mDinnerOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(mContext, allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name) + getMenuItemNoteContent(data));

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }
                            BigDecimal voidNum = data.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(data.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            String voidInfo = "";
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum.stripTrailingZeros().toPlainString() + "]";
                            }
                            BigDecimal buyAllNum = data.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                viewHolder.setText(R.id.numTv, TextUtils.concat(voidInfo, buyAllNum.stripTrailingZeros().toPlainString(), "份"));
                            } else {
                                viewHolder.setText(R.id.numTv, TextUtils.concat(buyAllNum.stripTrailingZeros().toPlainString(), "份"));
                            }
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                           /* if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mDinnerOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mDinnerOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //不显示桌号、时间等
            mDinnerOrderItemVirtualLine.setVisibility(View.GONE);
            mDinnerOrderItemVirtualLineText.setVisibility(View.GONE);
            mDinnerOrderItemOriginTable.setVisibility(View.GONE);

            //根据下单状态控制ui显示
            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                if (!SettingHelper.isShouldMerge() && !SettingHelper.isWesternFoodMode() &&//菜品不合并时才需要此功能
                        !DinnerStandardUtil.isStandardMenu(menuItem.itemID)) {// 餐标/低消补充菜品不显示
                    //不同批次的菜品需要用虚线隔开
                    OrderSeqModel seqModel = dishCache.order.optSeqModel(menuItem.menuBiz.orderSeqID);
                    if (seqModel != null) {
                        MenuItem beforeMenuItem = null;
                        //比较position 和position-1位置的单序是否相同，不同的话则在position位置的item显示虚线，position=0也要显示虚线
                        if (position > 0) {
                            beforeMenuItem = modules.get(position - 1);
                        }
                        if (position == 0 || (beforeMenuItem != null && beforeMenuItem.menuBiz.orderSeqID != menuItem.menuBiz.orderSeqID)) {
                            mDinnerOrderItemVirtualLine.setVisibility(View.VISIBLE);
                            String time = String.format(itemView.getContext().getResources().getString(R.string.add), seqModel.createTime);
                            mDinnerOrderItemVirtualLineText.setVisibility(View.VISIBLE);
                            mDinnerOrderItemVirtualLineText.setText(time);
                        } else {
                            mDinnerOrderItemVirtualLine.setVisibility(View.GONE);
                            mDinnerOrderItemVirtualLineText.setVisibility(View.GONE);
                        }
                    }
                }
                //已点单
                mDinnerOrderItemWaitLabel.setVisibility(View.GONE);//等叫标示隐藏
                mDinnerOrderItemUsernameLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemReminderCountLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemUsernameLabel.setText(getWaiterName());
                mDinnerOrderItemCreateTimeLabel.setText(getOrderTime());
                //等叫状态显示
                if (menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT && !menuItem.hasAllVoid()) {
                    mDinnerOrderItemCreateTimeLabel.setVisibility(View.GONE);
                    mDinnerOrderItemUsernameLabel.setVisibility(View.GONE);
                    mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_wait);
                    mDinnerOrderItemTheDishesLabel.setVisibility(View.VISIBLE);//等叫按钮显示
                    mDinnerOrderItemTheDishesLabel.setOnClickListener(this);

                    //隐藏退菜按钮
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);

                    mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                } else {
                    mDinnerOrderItemCreateTimeLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemUsernameLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_ordered);
                    mDinnerOrderItemTheDishesLabel.setVisibility(View.GONE);
                    mDinnerOrderItemTheDishesLabel.setOnClickListener(null);
                    mDinnerOrderItemHurryLabel.setVisibility(View.VISIBLE);
                }
                //催菜数据ui展示
                if (menuItem.menuBiz.fiHurryTimes > 0) {
                    mDinnerOrderItemReminderCountLabel.setText("催" + menuItem.menuBiz.fiHurryTimes + "次");
                } else {
                    mDinnerOrderItemReminderCountLabel.setVisibility(View.GONE);
                }

                //称重菜未称重 数量加样式
                if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                    mDinnerOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mDinnerOrderItemNumLabel.setOnClickListener(this);
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                } else {
                    mDinnerOrderItemNumLabel.setOnClickListener(null);
                    mDinnerOrderItemNumLabel.setBackgroundResource(0);
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                //退菜数据展示
                if (menuItem.hasAllVoid()) {
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                    addAllLine();
                } else {
                    mDinnerOrderItemDeleteOrReturnLabel.setText("退");
                    mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }

                if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
                } else {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.GONE);
                }

                //单个菜品操作控制
                mDinnerOrderItemNoteLabel.setVisibility(View.GONE);
                mDinnerOrderItemDoWaitLabel.setVisibility(View.GONE);
                if (dishCache.antiPay) {//反结帐不可催菜，转菜
                    mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                    mDinnerOrderItemTurnLabel.setVisibility(View.GONE);
                } else {
                    if (!(menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT && !menuItem.hasAllVoid())) {
                        mDinnerOrderItemHurryLabel.setVisibility(View.VISIBLE);
                        mDinnerOrderItemHurryLabel.setOnClickListener(this);
                    }
                    mDinnerOrderItemTurnLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemTurnLabel.setOnClickListener(this);
                }
                mDinnerOrderItemDiscountLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemDiscountLabel.setOnClickListener(this);

                //划菜UI处理
                mDinnerOrderItemPaddleLabel.setVisibility(isShowPaddle());
                mDinnerOrderItemPaddleLabel.setOnClickListener(this);

                if (menuItem.hasAllVoid()) {
                    // 菜品全退
                    mDelimit.setVisibility(View.GONE);
                } else if (menuItem.menuBiz.delimitNum.compareTo(BigDecimal.ZERO) > 0) {
                    // 只要有划菜的菜品，则显示「已上」
                    mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_done);
                    if (menuItem.menuBiz.delimitNum.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum)) >= 0 ||
                            (menuItem.supportWeight() && menuItem.menuBiz.delimitNum.compareTo(BigDecimal.ONE) >= 0)) {
                        // 全部已划
                        mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                        mDelimit.setVisibility(View.GONE);
                        addAllLine();
                    } else {
                        // 部分已划
                        // 剩余未划菜份数
                        BigDecimal remain = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).subtract(menuItem.menuBiz.delimitNum);
                        if (remain.compareTo(BigDecimal.ZERO) > 0) {
                            mDelimit.setVisibility(View.VISIBLE);
                            mDelimit.setText("余" + remain.intValue() + menuItem.currentUnit.fsOrderUint);
                        } else {
                            mDelimit.setVisibility(View.GONE);
                        }
                        removeAllLine();
                    }
                } else {
                    mDelimit.setVisibility(View.GONE);
                }

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_FFEEAA));
            } else {
                //显示删除按钮
                mDinnerOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemDeleteOrReturnLabel.setText("删");
                //新菜
                mDinnerOrderItemUsernameLabel.setVisibility(View.GONE);
                mDinnerOrderItemCreateTimeLabel.setVisibility(View.GONE);
                mDinnerOrderItemReminderCountLabel.setVisibility(View.GONE);
                mDinnerOrderItemTheDishesLabel.setVisibility(View.GONE);//等叫按钮隐藏
                mDinnerOrderItemStatusImg.setImageResource(R.drawable.icon_menu_item_statu_new);
                //等叫状态显示
                if (menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT) {
                    mDinnerOrderItemWaitLabel.setVisibility(View.VISIBLE);
                } else {
                    mDinnerOrderItemWaitLabel.setVisibility(View.GONE);
                }
                mDinnerOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mDinnerOrderItemNumLabel.setOnClickListener(this);

                if (menuItem.supportTimes()) {
                    mDinnerOrderItemNameLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mDinnerOrderItemNameLabel.setOnClickListener(this);
                    mDinnerOrderItemNameLabel.setPadding(dp10, dp5, dp10, dp5);
                }

                //沽清数量显示
                BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(menuItem.currentUnit.fiOrderUintCd);
                if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mDinnerOrderItemNumHintLabel.setText(String.format(Locale.SIMPLIFIED_CHINESE, "剩%s", sellOutCount + menuItem.currentUnit.fsOrderUint));
                } else {
                    mDinnerOrderItemNumHintLabel.setVisibility(View.GONE);
                }

                //菜品操作菜单事件监听
                mDinnerOrderItemDoWaitLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemNoteLabel.setVisibility(View.VISIBLE);
                mDinnerOrderItemHurryLabel.setVisibility(View.GONE);
                mDinnerOrderItemTurnLabel.setVisibility(View.GONE);
                mDinnerOrderItemPaddleLabel.setVisibility(View.GONE);
                mDelimit.setVisibility(View.GONE);
                mDinnerOrderItemDiscountLabel.setVisibility(View.GONE);
                mDinnerOrderItemDoWaitLabel.setOnClickListener(this);//设置等叫操作监听
                mDinnerOrderItemNoteLabel.setOnClickListener(this);

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.white));
            }

            if (DataSortProcessor.needShowOriginTable(dishCache.order, menuItem)) {// 合桌后保留原桌号
                MenuItem beforeMenuItem = null;
                //比较position 和position-1位置的桌号是否相同，不同的话则在position位置的item显示虚线，position=0也要显示虚线
                if (position > 0) {
                    beforeMenuItem = modules.get(position - 1);
                }
                if (position == 0 || (beforeMenuItem != null && !TextUtils.equals(beforeMenuItem.originTableId, menuItem.originTableId))) {
                    mDinnerOrderItemVirtualLine.setVisibility(View.VISIBLE);
                    mDinnerOrderItemOriginTable.setVisibility(View.VISIBLE);
                    mDinnerOrderItemOriginTable.setText(menuItem.originTableName);
                } else {
                    mDinnerOrderItemOriginTable.setVisibility(View.GONE);
                }
            } else {
                mDinnerOrderItemOriginTable.setVisibility(View.GONE);
            }
            if (SettingHelper.isWesternFoodMode() && !TextUtils.isEmpty(menuItem.rootMenuClsId)) {//西餐模式开启
                MenuItem beforeMenuItem = null;
                //比较position 和position-1位置的一级分类是否相同，不同的话则在position位置的item显示虚线，position=0也要显示虚线
                if (position > 0) {
                    beforeMenuItem = modules.get(position - 1);
                }
                if (position == 0 || (beforeMenuItem != null && (!TextUtils.equals(beforeMenuItem.rootMenuClsId, menuItem.rootMenuClsId)
                        || (DataSortProcessor.needShowOriginTable(dishCache.order) && !TextUtils.equals(beforeMenuItem.originTableId, menuItem.originTableId))))) {
                    mDinnerOrderItemVirtualLine.setVisibility(View.VISIBLE);
                    mDinnerOrderItemVirtualLineText.setVisibility(View.VISIBLE);
                    mDinnerOrderItemVirtualLineText.setText(menuItem.rootMenuClsName);
                } else {
                    mDinnerOrderItemVirtualLine.setVisibility(View.GONE);
                    mDinnerOrderItemVirtualLineText.setVisibility(View.GONE);
                }
            }

            //选中状态处理
//            if (selectPosition == position && !menuItem.hasAllVoid()) {
            if (TextUtils.equals(menuItem.menuBiz.uniq, selectItemUniq) && !menuItem.hasAllVoid()) {
                mDinnerOrderItemManagerLayout.setVisibility(View.VISIBLE);
                if (isShowEditItem() ||
                        // 套餐且未划菜->支持菜品编辑
                        (menuItem.supportPackage() && menuItem.menuBiz.delimitNum.compareTo(BigDecimal.ZERO) == 0)) {
                    mDinnerOrderItemEditLabel.setVisibility(View.VISIBLE);
                } else {
                    mDinnerOrderItemEditLabel.setVisibility(View.GONE);
                }
            } else {
                mDinnerOrderItemManagerLayout.setVisibility(View.GONE);
            }
        }

        /**
         * 显示优惠信息tag
         *
         * @param item        菜品
         * @param giftTag     赠送tag
         * @param discountTag 折扣tag
         * @param memberTag   会员tag
         * @param bugGiftTag  买减tag
         */
        private void showCouponTag(MenuItem item, View giftTag, TextView discountTag, View memberTag, View bugGiftTag, TextView dishCouponView) {
            giftTag.setVisibility(View.GONE);
            discountTag.setVisibility(View.GONE);
            memberTag.setVisibility(View.GONE);
            bugGiftTag.setVisibility(View.GONE);
            if (item.menuBiz.menuSellType == MenuSellType.GIFT || (item.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && item.menuBiz.giftNum.compareTo(item.menuBiz.buyNum.subtract(item.menuBiz.voidNum)) == 0)) {
                giftTag.setVisibility(View.VISIBLE);
            }
            if (item.useMemberPrice) {
                memberTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.bugGiftItem != null) {
                bugGiftTag.setVisibility(View.VISIBLE);
            }
            if (item.menuBiz.selectDiscount != null) {
                discountTag.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - item.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    discountTag.setText(rate0.toString() + "折");
                } else {
                    discountTag.setText(rate.toString() + "折");
                }
            }
            if (dishCouponView == null) {
                return;
            }
            dishCouponView.setVisibility(View.GONE);
            MemberDishCouponBean dishCouponBean = item.memberDishCouponForDisplay();
            if (dishCouponBean != null) {
                // 显示菜品券信息
                dishCouponView.setVisibility(View.VISIBLE);
                dishCouponView.setText(dishCouponBean.title);
            }
        }

        /**
         * 获取操作人名称
         *
         * @return
         */
        private String getWaiterName() {
            OrderSeqModel seqModel = dishCache.order.optSeqModel(menuItem.menuBiz.orderSeqID);
            String waiterName = "";
            if (seqModel != null) {
                waiterName = seqModel.createWaiterName;
            }
            return waiterName;
        }

        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            if (!DishUtils.isSupportEditor(dishCache.order)) {
                return;
            }
            switch (v.getId()) {
                case R.id.mDinnerOrderItemNumLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vQtyAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    ActionLog.addLog("点菜页->点击已下单菜品修改数量" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                                    listener.doChangeOrderedMenuNumber(menuItem, userDBModel);
                                } else {
                                    ActionLog.addLog("点菜页->点击未下单菜品修改数量" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_NUMBER, "");
                                    listener.doChangeMenuBuyNum(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemTheDishesLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnUpItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品起菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_THE_DISHES, "");
                                listener.doWaitCallUp(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemNameLabel:
                    if (menuItem.supportTimes()) {
                        if (!(dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID))) {
                            PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                                @Override
                                public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                    if (errCode == 0) {
                                        ActionLog.addLog("点菜页->点击菜品改名称" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_NAME, "");
                                        listener.doChangeMenuName(menuItem, userDBModel);
                                    }
                                }
                            });
                            break;
                        }
                    }
                case R.id.mDinnerOrderItemTop:
//                    selectPosition = modules.indexOf(menuItem);
                    selectItemUniq = menuItem.menuBiz.uniq;
                    notifyDataSetChanged();
                    break;

                case R.id.mDinnerOrderItemPriceLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品改价格" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_PRICE, "");
                                listener.doChangeMenuPrice(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemDoWaitLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnWaitItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                if (menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT) {
                                    //取消等叫
                                    ActionLog.addLog("点菜页->点击菜品取消等叫" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_WAIT, "");
                                    menuItem.menuBiz.fiItemMakeState = Constants.MAKE_STATE_NORMAL;
                                    mDinnerOrderItemDoWaitLabel.setText(mContext.getResources().getString(R.string.menu_order_item_wait_btn));
                                } else {
                                    //等叫处理
                                    ActionLog.addLog("点菜页->点击菜品等叫" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_WAIT, "");
                                    menuItem.menuBiz.fiItemMakeState = Constants.MAKE_STATE_WAIT;
                                    mDinnerOrderItemDoWaitLabel.setText(mContext.getResources().getString(R.string.menu_order_item_cancel_wait_btn));
                                }

                                notifyDataSetChanged();
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemNoteLabel:
                    ActionLog.addLog("点菜页->点击菜品要求" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_REQUEST, "");
                    listener.doEditorMenuNoteContent(menuItem);
                    break;
                case R.id.mDinnerOrderItemEditLabel:
                    if (dishCache.order != null && dishCache.order.isKBOrderSeqNo(menuItem.menuBiz.orderSeqID)) {
                        ToastUtil.showToast("口碑下单，暂不支持修改");
                        return;
                    }
                    ActionLog.addLog("点菜页->点击菜品编辑" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_EDITOR, "");
                    doHandlerMenuEdit();
                    break;
                case R.id.mDinnerOrderItemDeleteOrReturnLabel:
                    if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        PermissionsUtil.requestPermissionBackMenu(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, menuItem, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    ActionLog.addLog("点菜页->点击菜品退菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_RETREAT, "");
                                    listener.doRetreatDish(menuItem, userDBModel, msg);
                                }
                            }
                        });
                    } else {
                        ActionLog.addLog("点菜页->点击菜品删除" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_REMOVE, "");
                        listener.doDeleteMenu(menuItem);
                    }
                    break;
                case R.id.mDinnerOrderItemHurryLabel:
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_bnHurryItem, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品催菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_HURRY, "");
                                listener.doRemindersDish(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemPaddleLabel:
                    ActionLog.addLog("点菜页->点击菜品划菜操作" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_PADDLE, "");
                    listener.doPaddleDish(menuItem, AppCache.getInstance().userDBModel);
                    break;
                case R.id.mDinnerOrderItemTurnLabel:
                    if (dishCache.order != null && dishCache.order.isKBOrderSeqNo(menuItem.menuBiz.orderSeqID)) {
                        ToastUtil.showToast("口碑下单的菜品暂不支持转菜。");
                        return;
                    }
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vTurnAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                ActionLog.addLog("点菜页->点击菜品转菜" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_TURN, "");
                                listener.doTurnDish(menuItem, userDBModel);
                            }
                        }
                    });
                    break;
                case R.id.mDinnerOrderItemDiscountLabel:
                    ActionLog.addLog("点菜页->点击菜品优惠折扣" + menuItem.toString(), dishCache.getOrderId(), dishCache.getTableId(), ActionLog.DF_MENU_DISCOUNT, "");
                    listener.doChangeMenuPrivilege(menuItem);
                    break;
                default:
                    break;
            }
        }


        /**
         * 是否显示菜品编辑按钮
         *
         * @return
         */
        public boolean isShowEditItem() {
            if (dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                return menuItem.supportIngredient();
            } else {
                return ((menuItem.config & 2) == 2  //多规格
                        || (/*(menuItem.config & 1) == 1 &&*/ (menuItem.config & 4) == 4) //多做法
                        || (menuItem.config & 1024) == 1024) //有配料
                        || menuItem.supportPackage();
            }
        }

        /**
         * 是否显示划菜按钮
         *
         * @return
         */
        public int isShowPaddle() {
            boolean notShow = !ClientMetaUtil.mweePaddleServer() || menuItem.menuBiz.voidNum.compareTo(menuItem.menuBiz.buyNum) >= 0
                    || menuItem.menuBiz.fiItemMakeState == Constants.MAKE_STATE_WAIT
                    || (dishCache.antiPay && dishCache.order.optSeqStatus(menuItem.menuBiz.orderSeqID) == OrderSeqStatus.ANTIPAY)
                    || menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).compareTo(BigDecimal.ZERO) == 0
                    || (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid());
            return notShow ? View.GONE : View.VISIBLE;
        }

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
           /* if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);

            return demand.toString();
        }

        /**
         * 获取下单时间
         *
         * @return
         */
        public String getOrderTime() {
            try {
                StringBuilder statusStr = new StringBuilder();
                long time = DateTimeUtil.getMMBetween(menuItem.menuBiz.createTime, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (time <= 0) {
                    time = 1;
                }
                if (time > 60) {
                    statusStr.append("  ").append("1小时＋");
                } else {
                    statusStr.append("  ").append(time).append("分钟");
                }
                return statusStr.toString();
            } catch (ParseException e) {
                return "1分钟";
            }
        }

        /**
         * 处理菜品编辑操作
         */
        private void doHandlerMenuEdit() {
            boolean isOrdered = dishCache.order != null && dishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID);
            if (menuItem.supportPackage()) { //套餐
                if (isOrdered) {
                    // 已下单套餐菜品编辑
                    editPackageItems(menuItem);
                } else {
                    OrderDishesBizUtil.processPackage((Host) mContext, menuItem, dishCache.isBindMember(), new IResponse<PackageItemEditViewBean>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, PackageItemEditViewBean info) {
                            if (result) {
                                info.menu.calcTotal(dishCache.isBindMember());
                                listener.onPackageMenuChanged(info.menu);
                                notifyDataSetChanged();
                            } else {
                                ToastUtil.showToast(msg);
                            }
                        }
                    });
                }
            } else {  //配料菜-多规格-多做法
                if (isOrdered) {
                    // 已下单的配料菜修改
                    editIngredient(menuItem);
                } else {
                    final UnitModel oldUnit = menuItem.currentUnit;
                    final BigDecimal oldBuyNum = menuItem.menuBiz.buyNum;
                    OrderDishesBizUtil.processIngredient((Host) mContext, menuItem, new IResponse<MenuItem>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, MenuItem info) {
                            if (result) {
                                listener.doEditMenuInfo(oldUnit, oldBuyNum, info);
                            } else {
                                ToastUtil.showToast(msg);
                            }
                        }
                    }, dishCache.isBindMember());
                }
            }
        }

        /**
         * 编辑套餐子项
         *
         * @param menuItem 套餐菜品
         */
        private void editPackageItems(MenuItem menuItem) {
            MenuItem itemClone = menuItem.clone();
            OrderDishesBizUtil.processPackage((Host) mContext, itemClone, true, dishCache.order.isMember, new IResponse<PackageItemEditViewBean>() {
                @Override
                public void callBack(boolean result, int code, String msg, PackageItemEditViewBean info) {
                    listener.doChangePackageItems(menuItem, info.menu, info);
                }
            });
        }

        /**
         * 编辑配料
         *
         * @param menuItem
         */
        private void editIngredient(final MenuItem menuItem) {
            MenuItem itemClone = menuItem.clone();
            OrderDishesBizUtil.processIngredient((Host) mContext, itemClone, true, new IResponse<MenuItem>() {
                @Override
                public void callBack(boolean result, int code, String msg, MenuItem info) {
                    listener.doChangeIngredient(menuItem, info);
                }
            }, dishCache.order.isMember);
        }

        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemUsernameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemCreateTimeLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mDinnerOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemUsernameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemCreateTimeLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mDinnerOrderItemPriceLabel);
        }
    }


    /**
     * 菜品列表操作回调接口
     */
    public interface OnDinnerFoodOrderItemClickListener {
        /**
         * 未下单菜品->修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel);


        /**
         * 已下单菜品—>修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel);

        /**
         * 删除菜品
         *
         * @param item
         */
        void doDeleteMenu(MenuItem item);

        /**
         * 修改菜品要求
         *
         * @param item
         */
        void doEditorMenuNoteContent(MenuItem item);

        /**
         * 修改菜品折扣
         *
         * @param item
         */
        void doChangeMenuPrivilege(MenuItem item);

        /**
         * 修改时价菜价格
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuPrice(MenuItem item, UserDBModel userDBModel);

        /**
         * 修改时价菜名称
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuName(MenuItem item, UserDBModel userDBModel);

        /**
         * 未下单菜品->编辑
         *
         * @param oldUnit
         * @param oldBuyNum
         * @param item
         */
        void doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item);


        /**
         * 已下单菜品—>退菜
         *
         * @param item
         * @param userDBModel
         * @param msg
         */
        void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg);

        /**
         * 已下单菜品—>催菜
         *
         * @param item
         * @param userDBModel
         */
        void doRemindersDish(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>划菜
         *
         * @param item
         * @param userDBModel
         */
        void doPaddleDish(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>转菜
         *
         * @param item
         * @param userDBModel
         */
        void doTurnDish(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单等叫菜品—>起菜
         *
         * @param item
         * @param userDBModel
         */
        void doWaitCallUp(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>菜品编辑
         *
         * @param menuItem
         * @param info
         */
        void doChangeIngredient(MenuItem menuItem, MenuItem info);

        /**
         * 已下单套餐->菜品编辑
         *
         * @param menuItem
         * @param info
         */
        void doChangePackageItems(MenuItem menuItem, MenuItem info, PackageItemEditViewBean otherData);


        /**
         * 套餐信息改变
         *
         * @param menuItem
         */
        void onPackageMenuChanged(MenuItem menuItem);


    }

    public void setOnDinnerFoodOrderItemClickListener(OnDinnerFoodOrderItemClickListener listener) {
        this.listener = listener;
    }

    /**
     * 客显回调
     */
    private NormalListener normalListener;

    public void setRefreshViceCallBack(NormalListener normalListener) {
        this.normalListener = normalListener;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        if (normalListener != null) {
            normalListener.callBack();
        }
    }
}
