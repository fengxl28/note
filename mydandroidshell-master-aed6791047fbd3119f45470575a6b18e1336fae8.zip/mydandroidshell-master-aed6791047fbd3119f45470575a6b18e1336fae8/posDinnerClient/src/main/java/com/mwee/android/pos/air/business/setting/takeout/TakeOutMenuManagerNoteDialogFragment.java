package com.mwee.android.pos.air.business.setting.takeout;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;

/**
 * Created by qinwei on 2018/3/19.
 */

public class TakeOutMenuManagerNoteDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_fragment_take_out_menu_manager_note_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view) {
        view.findViewById(R.id.mTakeOutMenuManagerNoteCloseBtn).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        dismissSelf();
    }
}
