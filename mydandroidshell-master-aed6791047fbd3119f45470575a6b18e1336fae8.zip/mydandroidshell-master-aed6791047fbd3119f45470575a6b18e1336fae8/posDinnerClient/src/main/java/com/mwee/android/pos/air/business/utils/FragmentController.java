package com.mwee.android.pos.air.business.utils;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.orderdishes.view.jump.JumpFlag;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;

/**
 * @author Created by qinwei on
 * @date 2017/11/14.
 */

public class FragmentController {
    public static void showAirOrderDishesContainer(Host mHost, int main_menufragment, OrderCache orderCache, JumpFlag jumpFlag) {
//        todo 正餐反结帐

    }

    public static void showAirFastFoodDish(Host mHost, FastOrderModel fastOrderModel, ArrayList<MenuItem> originMenuList) {
        // 快餐反结帐
        FastFoodDishCache dishCache = new FastFoodDishCache();
        dishCache.fastOrderModel = fastOrderModel;
        if (!ListUtil.isEmpty(originMenuList)) {
            dishCache.menuItems.addAll(originMenuList);
        }
        dishCache.initSelectUnitQuantity();
        dishCache.antiPay = true;
        DriverBus.call("orderDishesView/repay", dishCache);
        if (mHost.getActivityWithinHost() != null) {
            mHost.getActivityWithinHost().finish();
        }
    }
}
