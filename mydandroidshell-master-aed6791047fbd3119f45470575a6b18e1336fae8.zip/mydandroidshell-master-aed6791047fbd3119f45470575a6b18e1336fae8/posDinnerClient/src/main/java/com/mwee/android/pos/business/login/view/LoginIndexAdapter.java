package com.mwee.android.pos.business.login.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: LoginIndexAdapter
 * @Description: 账号索引
 * @author: SugarT
 * @date: 16/10/17 下午7:48
 */
public class LoginIndexAdapter extends RecyclerView.Adapter<LoginIndexAdapter.LoginIndexVH> implements
        View.OnClickListener {

    public Context context;

    public List<String> keys = new ArrayList<>();

    public int lastPosition;

    private OnItemClickListener mOnItemClickListener;

    public LoginIndexAdapter(Context context, List<String> keys) {
        this.context = context;
        this.keys = keys;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        mOnItemClickListener = onItemClickListener;
    }

    public void setSelection(int position) {
        lastPosition = position;
        notifyDataSetChanged();
    }

    @Override
    public LoginIndexVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = View.inflate(context, R.layout.item_login_name_index, null);
        LoginIndexVH holder = new LoginIndexVH(convertView);
        return holder;
    }

    @Override
    public void onBindViewHolder(final LoginIndexVH holder, int position) {
        if (!ListUtil.listIsEmpty(keys)) {
            String keyword = keys.get(position);

            holder.tvName.setText(keyword);
            holder.tvPointName.setText(keyword);

            if (lastPosition == position) {
                holder.rlytPoint.setVisibility(View.VISIBLE);
            } else {
                holder.rlytPoint.setVisibility(View.INVISIBLE);
            }

//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                holder.llytContainer.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        int itemWidth = holder.llytContainer.getWidth();
//                        LogUtil.log("当前控件的宽度[" + itemWidth + "]");
//                        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
//                        if (itemWidth * keys.size() > screenWidth){
//                            itemWidth = screenWidth / keys.size();
//                            LogUtil.log("索引控件过宽，调整为[" + itemWidth + "]");
//                        }
//                        ViewGroup.LayoutParams lp = holder.llytContainer.getLayoutParams();
//                        lp.width = itemWidth;
//                        holder.llytContainer.setPadding(0, 0, 0, 0);
//                        holder.llytContainer.setLayoutParams(lp);
//                    }
//                });
//            }
        }
        holder.llytContainer.setTag(position);
        holder.llytContainer.setOnClickListener(this);
    }

    @Override
    public int getItemCount() {
        return keys.size();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llyt_login_dinner_container:
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.onItemClick(v, (Integer) v.getTag());
                }
                lastPosition = (int) v.getTag();
                notifyDataSetChanged();
                break;
            default:
                break;
        }
    }

    public void refresh(List<String> keys) {
        this.keys = keys;
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public class LoginIndexVH extends RecyclerView.ViewHolder {

        public LinearLayout llytContainer;
        public RelativeLayout rlytPoint;
        public TextView tvPointName;
        public TextView tvName;

        public LoginIndexVH(View convertView) {
            super(convertView);
            llytContainer = (LinearLayout) convertView.findViewById(R.id.llyt_login_dinner_container);
            rlytPoint = (RelativeLayout) convertView.findViewById(R.id.rlyt_login_dinner_index);
            tvPointName = (TextView) convertView.findViewById(R.id.tv_login_index_sort);
            tvName = (TextView) convertView.findViewById(R.id.tv_login_dinner_index_name);

            /* 调整控件宽度 */
            int itemWidth = ViewToolsUtil.getPixelFromDip(108);
            int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            if (itemWidth * keys.size() > screenWidth){
                itemWidth = screenWidth / keys.size();
                LogUtil.log("索引控件过宽，调整为[" + itemWidth + "]");

                ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(itemWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
                llytContainer.setPadding(0, 0, 0, 0);
                llytContainer.setLayoutParams(lp);
            }
        }
    }
}
