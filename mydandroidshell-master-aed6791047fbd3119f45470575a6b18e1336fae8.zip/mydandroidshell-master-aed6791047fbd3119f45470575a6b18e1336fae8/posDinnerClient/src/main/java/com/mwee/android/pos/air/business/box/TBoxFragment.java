package com.mwee.android.pos.air.business.box;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.pay.component.CPay;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bean.GetUnPrintTaskNoResponse;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.widget.TitleBar;

/**
 * Created by zhangmin on 2017/10/16.
 */

public class TBoxFragment extends BaseFragment {


    private TextView tvOpenBox;
    private TitleBar titleBar;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_box_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignView(view);
        registerEvent();
        init();
    }

    private void assignView(View v) {
        tvOpenBox = (TextView) v.findViewById(R.id.tvOpenBox);
        titleBar = (TitleBar) v.findViewById(R.id.titleBar);

    }

    private void registerEvent() {
        tvOpenBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActionLog.addLog("更多设置->点击了开钱箱快捷入口", "", "", ActionLog.SS_MORE_JOIN, "");
                PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance().userDBModel, Permission.DINNER_bnOpenBox, new PermissionCallback() {
                    @Override
                    public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                        if (userDBModel != null) {
                            MCon.c(CPay.class, new SocketCallback<GetUnPrintTaskNoResponse>() {
                                @Override
                                public void callback(SocketResponse<GetUnPrintTaskNoResponse> socketResponse) {
                                    if (socketResponse != null && socketResponse.data != null &&
                                            !ListUtil.isEmpty(socketResponse.data.printTaskNoList)) {
                                        PrintReceiptUtil.addPrintNo(socketResponse.data.printTaskNoList, AppCache.getInstance().currentHostId);
                                    }
                                }
                            }).openMoneybox();
                        }
                    }
                });

            }
        });

    }

    private void init() {

        titleBar.setTitle("钱箱");
        titleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });

    }

}
