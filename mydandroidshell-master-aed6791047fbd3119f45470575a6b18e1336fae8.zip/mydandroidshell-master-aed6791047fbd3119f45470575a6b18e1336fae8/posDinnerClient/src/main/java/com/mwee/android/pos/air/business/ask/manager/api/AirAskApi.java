package com.mwee.android.pos.air.business.ask.manager.api;

import com.mwee.android.air.acon.CAskManager;
import com.mwee.android.air.connect.business.ask.AskListResponse;
import com.mwee.android.air.connect.business.ask.GetAllAskGPAndAskResponse;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.business.bean.NoteListResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenlong on 2017/10/22.
 */

public class AirAskApi {

    public static void optAllAsk(final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).optAllAsk();
    }

    public static void doDeleteAskGp(String fsaskgpId, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).doDeleteAskGp(fsaskgpId);
    }

    public static void doUpdateAskGp(String fsaskgpId, String askGpName, boolean all, List<String> menuClsIdList, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).doUpdateAskGp(fsaskgpId, askGpName, all, menuClsIdList);
    }

    public static void doAddAskGp(String askGpName, boolean all, List<String> menuClsIdList, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).doAddAskGp(askGpName, all, menuClsIdList);
    }

    /**
     * 更新要求
     *
     * @param fsaskId
     * @param fsaskName
     * @param price
     * @param iResult
     */
    public static void updateAsk(String fsaskId, String fsaskName, BigDecimal price, String askGpId, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updateAsk(fsaskId, fsaskName, price, askGpId);
    }

    /**
     * 新增要求
     *
     * @param fsaskName
     * @param price
     * @param iResult
     */
    public static void addAsk(String fsaskName, BigDecimal price, String askGpId, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addAsk(fsaskName, price, askGpId);
    }

    /**
     * 批量删除要求
     *
     * @param iResult
     */
    public static void batcheDeleteAsk(List<String> askIdLsit, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).batcheDeleteAsk(askIdLsit);
    }

    public static void loadAskGroupToTop(String currentAskGpId, final IResponse<GetAllAskGPAndAskResponse> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<GetAllAskGPAndAskResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAskGPAndAskResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadAskGroupToTop(currentAskGpId);
    }

    /**
     * 获取菜品的要求
     *
     * @param fiItemCd
     * @param iResult
     */
    public static void optNoteList(String fiItemCd, String fsMenuClsId, final IResponse<List<NoteModel>> iResult) {
        MCon.c(CAskManager.class, new SocketCallback<NoteListResponse>() {
            @Override
            public void callback(SocketResponse<NoteListResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data.noteModels);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).optNoteList(fiItemCd, fsMenuClsId);
    }


    /**
     * 获取指定分组下要求列表
     *
     * @param fsAskGpId
     * @param callback
     */
    public static void loadAskListByGroupId(String fsAskGpId, ResultCallback<ArrayList<AirAskManageInfo>> callback) {
        MCon.c(CAskManager.class, new SocketCallback<AskListResponse>() {
            @Override
            public void callback(SocketResponse<AskListResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data.askList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }

        }).loadAskListByGroupId(fsAskGpId);
    }

    public static void loadAskSort(ArrayList<AirAskManageInfo> airAskManageInfos, SocketCallback<SocketResponse> socketCallback) {
        MCon.c(CAskManager.class, socketCallback).loadAskSort(airAskManageInfos);
    }
}
