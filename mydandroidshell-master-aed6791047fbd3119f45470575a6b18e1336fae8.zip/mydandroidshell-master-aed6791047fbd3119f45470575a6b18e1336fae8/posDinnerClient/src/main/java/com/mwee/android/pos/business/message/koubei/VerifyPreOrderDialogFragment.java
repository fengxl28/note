package com.mwee.android.pos.business.message.koubei;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;
import com.mwee.android.tools.LogUtil;

import java.lang.reflect.Method;

/**
 * 扫码支付code获取
 */
public class VerifyPreOrderDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mVerifyMessageLabel;
    private TextView mScannerStatusLabel;

    private TextView couponIdLabel;
    private NumberKeyboard numberKeyboard;

    private Button mVerifyCancelBtn;
    private Button submitBtn;
//    private Button mVerifyRetryBtn;

    private EditText mNetPayCodeEdt;
    private String tempCode;
    /**
     * 待支付金额
     */
    private Handler handler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            ing();
            tempCode = mNetPayCodeEdt.getText().toString().trim();
            loadNetPay(tempCode);
            //接收扫码edt置空
            mNetPayCodeEdt.setText("");
        }
    };
    private KBBeforeClientProcessor mKBBeforeClientProcessor;
    private OnVerifyPreOrderListener listener;
//    private View space;

    /**
     * 核销取餐
     *
     * @param tempCode
     */
    private void loadNetPay(String tempCode) {
        ing();
        mKBBeforeClientProcessor.verifyOrder(tempCode, new ResultCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void onSuccess(KBPreOrderUpdateResponse data) {
                done(data);
            }

            @Override
            public void onFailure(int code, String msg) {
//                error(msg);
                addWatcher();
                mVerifyCancelBtn.setVisibility(View.VISIBLE);
                mScannerStatusLabel.setText("等待扫码...");
                ToastUtil.showToast(TextUtils.isEmpty(msg) ? "核销失败" : msg);
            }
        });
    }

    public TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            handler.removeMessages(0);
            LogUtil.log("VerifyPreOrderDialogFragment ----" + charSequence.toString().trim());
            handler.sendEmptyMessageDelayed(0, 300);
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    private void removeWatcher() {
        mNetPayCodeEdt.removeTextChangedListener(textWatcher);
    }

    private void addWatcher() {
        mNetPayCodeEdt.requestFocus();
        mNetPayCodeEdt.addTextChangedListener(textWatcher);
        hideKeyboard();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_net_verify_pre_order_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
        addWatcher();
    }

    private void hideKeyboard() {
        mNetPayCodeEdt.post(new Runnable() {
            @Override
            public void run() {
                KeyboardManager.hideSoftInput(getContext(), mNetPayCodeEdt);
            }
        });
    }


    private void initView(View view) {
//        space = view.findViewById(R.id.space);
        mNetPayCodeEdt = (EditText) view.findViewById(R.id.mNetPayCodeEdt);
        mVerifyMessageLabel = (TextView) view.findViewById(R.id.mVerifyMessageLabel);
        mScannerStatusLabel = (TextView) view.findViewById(R.id.mScannerStatusLabel);
        mNetPayCodeEdt = (EditText) view.findViewById(R.id.mNetPayCodeEdt);
        mVerifyCancelBtn = (Button) view.findViewById(R.id.mVerifyCancelBtn);
        submitBtn = (Button) view.findViewById(R.id.submitBtn);
//        mVerifyRetryBtn = (Button) view.findViewById(R.id.mVerifyRetryBtn);

        couponIdLabel = (TextView) view.findViewById(R.id.couponIdLabel);


        mVerifyCancelBtn.setOnClickListener(this);
        submitBtn.setOnClickListener(this);
//        mVerifyRetryBtn.setOnClickListener(this);

        numberKeyboard = view.findViewById(R.id.numberKeyboard);
        numberKeyboard.setItemLayoutId(R.layout.view_key_item_small);
        numberKeyboard.initData(KeyHelper.generateOnlyBackKeys(), keyEntity -> {
            switch (keyEntity.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    couponIdLabel.append(keyEntity.value);
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CONFIRM:
                    CharSequence text = couponIdLabel.getText();
                    if (text.length() <= 0) {
                        return;
                    }
                    if (text.length() == 1) {
                        couponIdLabel.setText("");
                        return;
                    }
                    couponIdLabel.setText(text.subSequence(0, text.length() - 1));
                    break;
                case NumberKeyboard.KeyEntity.TYPE_BACK:
                    break;
                default:
                    break;
            }
        });
        numberKeyboard.notifyDataChanged();
    }

    private void initData() {
        mKBBeforeClientProcessor = new KBBeforeClientProcessor(this);
        //显示
        payWait();
    }

    public void payWait() {
        addWatcher();
//        mVerifyMessageLabel.setText("请扫码核销用户预点餐订单");
        mScannerStatusLabel.setText("等待扫码...");
        mVerifyCancelBtn.setVisibility(View.VISIBLE);
//        mVerifyRetryBtn.setVisibility(View.GONE);
    }

    public void ing() {
        removeWatcher();
        //扣款中...
        mScannerStatusLabel.setText("核销中，请稍候...");
        mVerifyCancelBtn.setVisibility(View.GONE);
//        mVerifyRetryBtn.setVisibility(View.GONE);
//        space.setVisibility(View.GONE);
    }

    /*public void error(String msg) {
        addWatcher();
        //支付失败...
        mVerifyMessageLabel.setText(msg);
        mScannerStatusLabel.setText("等待扫码...");
        mVerifyRetryBtn.setVisibility(View.VISIBLE);
        mVerifyCancelBtn.setVisibility(View.VISIBLE);
        space.setVisibility(View.VISIBLE);
    }*/

    public void done(KBPreOrderUpdateResponse response) {
        listener.onVerifyPreOrderSuccess(response);
        dismissSelf();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeMessages(0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mVerifyCancelBtn:
                dismissSelf();
                break;
            case R.id.submitBtn:
                tempCode = couponIdLabel.getText().toString().trim();
                if (TextUtils.isEmpty(tempCode)) {
                    ToastUtil.showToast("请输入核销码");
                    return;
                }
                loadNetPay(tempCode);
                break;
            default:
                break;
        }
        addWatcher();
    }

    public void setOnVerifyPreOrderListener(OnVerifyPreOrderListener listener) {
        this.listener = listener;
    }

    public interface OnVerifyPreOrderListener {
        void onVerifyPreOrderSuccess(KBPreOrderUpdateResponse response);
    }

    public void disableShowSoftInput() {
        Class<EditText> cls = EditText.class;
        Method method;
        try {
            method = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
            method.setAccessible(true);
            method.invoke(mNetPayCodeEdt, false);
        } catch (Exception e) {
        }

        try {
            method = cls.getMethod("setSoftInputShownOnFocus", boolean.class);
            method.setAccessible(true);
            method.invoke(mNetPayCodeEdt, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
