package com.mwee.android.pos.business.fastfood.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.db.business.BillSourceDBModel;
import com.mwee.android.pos.dinner.R;

import java.util.ArrayList;

/**
 * 快餐单来源选择
 * Created by qinwei on 2017/5/22.
 */

public class BillSourceChoiceFragmentDialog extends BaseDialogFragment {
    private RecyclerView mRecyclerView;
    private ChannelAdapter adapter;
    private ArrayList<BillSourceDBModel> billSourceDBModels = new ArrayList<>();
    private OnBillSourceChoiceListener billSourceChoiceListener;
    public static final String KEY_BILL_SOURCE_ID = "key_bill_source_id";
    public String billSourceId = "";

    public static BillSourceChoiceFragmentDialog getInstance(String billSourceId) {
        BillSourceChoiceFragmentDialog fragment = new BillSourceChoiceFragmentDialog();
        Bundle args = new Bundle();
        args.putString(KEY_BILL_SOURCE_ID, billSourceId);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        billSourceId = getArguments().getString(KEY_BILL_SOURCE_ID);
        return inflater.inflate(R.layout.fragment_fast_food_billsource_choice_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.mRecyclerView);
        mRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        adapter = new ChannelAdapter();
        billSourceDBModels.addAll(AppCache.getInstance().billSourceDBModelMap);
        mRecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


    class ChannelAdapter extends RecyclerView.Adapter<ChannelHolder> {

        @Override
        public ChannelHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ChannelHolder(LayoutInflater.from(getContext()).inflate(R.layout.fastfood_billsource_choice_item, parent, false));
        }

        @Override
        public void onBindViewHolder(ChannelHolder holder, int position) {
            holder.initData(position);
        }

        @Override
        public int getItemCount() {
            return billSourceDBModels.size();
        }
    }

    class ChannelHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mBillSourceItemNameLabel;
        private BillSourceDBModel ds;

        public ChannelHolder(View itemView) {
            super(itemView);
            mBillSourceItemNameLabel = (TextView) itemView.findViewById(R.id.mBillSourceItemNameLabel);
            itemView.setOnClickListener(this);
        }

        public void initData(int position) {
            ds = billSourceDBModels.get(position);
            mBillSourceItemNameLabel.setText(ds.fsBillSourceName);
            itemView.setSelected(TextUtils.equals(billSourceId, ds.fsBillSourceId));
        }

        @Override
        public void onClick(View v) {
            if (billSourceChoiceListener != null) {
                billSourceId = ds.fsBillSourceId;
                adapter.notifyDataSetChanged();
                billSourceChoiceListener.onBillSourceChoiceItemClick(ds);
                dismissSelf();
            }
        }
    }

    public interface OnBillSourceChoiceListener {
        void onBillSourceChoiceItemClick(BillSourceDBModel billSourceDBModel);
    }

    public void setOnBillSourceChoiceListener(OnBillSourceChoiceListener billSourceChoiceListener) {
        this.billSourceChoiceListener = billSourceChoiceListener;
    }

}
