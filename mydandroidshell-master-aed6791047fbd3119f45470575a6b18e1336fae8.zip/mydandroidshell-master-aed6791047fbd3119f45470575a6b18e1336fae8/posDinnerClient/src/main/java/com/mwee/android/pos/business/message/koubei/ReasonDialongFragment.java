package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.business.permissions.view.NiceSpinner;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/5/16.
 */

public class ReasonDialongFragment extends BaseDialogFragment implements View.OnClickListener {

    private Button leftBtn;
    private Button rightBtn;

    private TextView tvRemindContent;
    private TResult<String> tResult;

    private List<String> listReasons = new ArrayList<>();
    private String reasonTitle = "";
    private String selectReason = "";
    private String remindContent = "";
    private TextView tvRefundAmount;
    private TextView tvRefundViolateAmount;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_reason_dialog_layout, container, false);
        rootView.findViewById(R.id.layoutContainer).setOnClickListener(null);
        setCancelable(false);

        NiceSpinner niceSpinner = (NiceSpinner) rootView.findViewById(R.id.nine_spinner);
        niceSpinner.attachDataSource(listReasons);
        niceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectReason = (String) parent.getItemAtPosition(position);
                enableTrue();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        TextView tv_title = (TextView) rootView.findViewById(R.id.tv_title);
        leftBtn = (Button) rootView.findViewById(R.id.leftBtn);
        rightBtn = (Button) rootView.findViewById(R.id.rightBtn);
        tvRemindContent = rootView.findViewById(R.id.tvRemindContent);

        tv_title.setText(reasonTitle);
        tvRemindContent.setText(remindContent);

        tvRemindContent.setVisibility(android.text.TextUtils.isEmpty(remindContent) ? View.GONE : View.VISIBLE);
        enableFalse();
        leftBtn.setOnClickListener(this);
        rightBtn.setOnClickListener(this);


        //退款金额和违约金默认不显示
        tvRefundAmount = rootView.findViewById(R.id.tvRefundAmount);
        tvRefundViolateAmount = rootView.findViewById(R.id.tvRefundViolateAmount);


        //商家同意退款 退款金额大于0的时候显示
        if (refundAmount.compareTo(BigDecimal.ZERO) > 0) {

            tvRefundAmount.setVisibility(View.VISIBLE);
            tvRefundViolateAmount.setVisibility(View.VISIBLE);

            tvRefundAmount.setText(String.format("退款金额: %s元", refundAmount));
            tvRefundViolateAmount.setText(String.format("扣除违约金: %s元", refundViolateAmount));

        } else {
            tvRefundAmount.setVisibility(View.GONE);
            tvRefundViolateAmount.setVisibility(View.GONE);
        }

        return rootView;
    }

    private void enableTrue() {
        rightBtn.setEnabled(true);
        rightBtn.setTextColor(ContextCompat.getColor(getContext(), R.color.system_red));
        rightBtn.setBackgroundResource(R.drawable.bg_cubic_gray_red_selector);
    }

    private void enableFalse() {
        rightBtn.setEnabled(false);
        rightBtn.setTextColor(ContextCompat.getColor(getContext(), R.color.dark_gray));
        rightBtn.setBackgroundResource(R.drawable.bg_cubic_gray);
    }

    public void setParams(List<String> listReasons, String reasonTitle, String remindContent, TResult<String> tResult) {
        this.listReasons = listReasons;
        this.reasonTitle = reasonTitle;
        this.remindContent = remindContent;
        this.tResult = tResult;
    }


    //退款金额 = 订单金额 - 违约
    private BigDecimal refundAmount = BigDecimal.ZERO;

    private BigDecimal refundViolateAmount = BigDecimal.ZERO;
    public void setRefundAmount(BigDecimal refundAmount, BigDecimal refundViolateAmount) {
        this.refundAmount = refundAmount;
        this.refundViolateAmount = refundViolateAmount;
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.leftBtn:
                dismissSelf();
                break;
            case R.id.rightBtn:
                tResult.callBack(selectReason);
                dismissSelf();
                break;
        }
    }
}
