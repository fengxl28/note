package com.mwee.android.pos.business.bill.view;

import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.db.business.order.Order;

/**
 * Created by lxx on 16/9/18.
 */
public interface BillOperationInterface {
    void printStatement(Order order);

    void rePay(OrderListModel orderListModel, Order order, String msg);
}
