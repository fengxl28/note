package com.mwee.android.pos.air.business.member.utils;

import android.text.TextUtils;

/**
 * Created by zhangmin on 2018/2/1.
 */

public class MemberUtils {

    /**
     * 检查是否是手机号
     *
     * @param number
     * @return
     */
    public static boolean checkIsPhoneNumber(String number) {
        if (!TextUtils.isEmpty(number)) {
            if (number.startsWith("1") && number.length() == 11) {
                return true;
            }
        }
        return false;
    }


    /**
     * 校验是否是会员卡号
     * @param number
     * @return
     */
    public static boolean checkIsCardNo(String number){
        if (!TextUtils.isEmpty(number)) {
            if (number.length() == 12) {
                return true;
            }
        }
        return false;
    }
}
