package com.mwee.android.pos.air.business.setting.api;

import com.mwee.android.air.db.business.kbbean.KBShopInfoResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.air.business.payment.entity.PayOpenStatus;
import com.mwee.android.pos.air.business.setting.api.entity.AliPayOpenPayModel;
import com.mwee.android.pos.air.business.setting.api.entity.AliPayOpenPayRequest;
import com.mwee.android.pos.air.business.setting.api.entity.AliPayOpenPayResponse;
import com.mwee.android.pos.air.business.setting.api.entity.PayOpenStatusRequest;
import com.mwee.android.pos.air.business.setting.api.entity.PayOpenStatusResponse;
import com.mwee.android.pos.air.business.setting.api.entity.WXOpenPayModel;
import com.mwee.android.pos.air.business.setting.api.entity.WXOpenPayRequest;
import com.mwee.android.pos.air.business.setting.api.entity.WXOpenPayResponse;
import com.mwee.android.pos.air.business.setting.shop.model.GetCityListRequest;
import com.mwee.android.pos.air.business.setting.shop.model.GetCityListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.GetDistrictListRequest;
import com.mwee.android.pos.air.business.setting.shop.model.GetDistrictListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.GetProvinceListRequest;
import com.mwee.android.pos.air.business.setting.shop.model.GetProvinceListResponse;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.shop.KouBeiShopInfo;
import com.mwee.android.pos.business.shop.KoubeiShopNameRequest;
import com.mwee.android.pos.business.shop.KoubeiShopNameResponse;
import com.mwee.android.pos.business.shop.KoubeiShopUnBindRequest;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CKouBei;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.Constants;

import java.util.HashMap;

/**
 * Created by qinwei on 2018/3/26.
 */

public class ShopApi {

    public static void getDistrictList(int cityId, ResultCallback<GetDistrictListResponse> callback) {
        GetDistrictListRequest request = new GetDistrictListRequest();
        request.cityId = cityId;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetDistrictListResponse) {
                    GetDistrictListResponse posResponse = (GetDistrictListResponse) responseData.responseBean;
                    callback.onSuccess(posResponse);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public static void getCityList(int id, ResultCallback<GetCityListResponse> callback) {
        GetCityListRequest request = new GetCityListRequest();
        request.provinceId = id;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetCityListResponse) {
                    GetCityListResponse posResponse = (GetCityListResponse) responseData.responseBean;
                    callback.onSuccess(posResponse);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    public static void getProvinceList(ResultCallback<GetProvinceListResponse> callback) {
        GetProvinceListRequest request = new GetProvinceListRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetProvinceListResponse) {
                    GetProvinceListResponse posResponse = (GetProvinceListResponse) responseData.responseBean;
                    callback.onSuccess(posResponse);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public static void loadKouBeiShopInfo(ResultCallback<KouBeiShopInfo> callback) {
        MCon.c(CKouBei.class, new SocketCallback<KBShopInfoResponse>() {
            @Override
            public void callback(SocketResponse<KBShopInfoResponse> response) {
                if (response == null) {
                    ActionLog.addLog("获取口碑门店信息异常", ActionLog.USER_ACTION_TRACE);
                    callback.onFailure(-1, "");
                    return;
                }
                if (response.success() && response.data != null) {
                    AppCache.getInstance().refreshKouBeiShopId(response.data.kouBeiShopInfo.alipayShopId);
                    callback.onSuccess(response.data.kouBeiShopInfo);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadKoubeiShopInfo();
    }

    public static void loadKoubeiShopName(ResultCallback<String> callback) {
        KoubeiShopNameRequest request = new KoubeiShopNameRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean instanceof KoubeiShopNameResponse) {
                    KoubeiShopNameResponse response = (KoubeiShopNameResponse) responseData.responseBean;
                    callback.onSuccess(response.data.shopName);
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public static void unBindKbShop(ResultCallback<String> callback) {
        KoubeiShopUnBindRequest request = new KoubeiShopUnBindRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                callback.onSuccess("");
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 查询支付宝微信开通状态
     *
     * @param callback
     */
    public static void loadPayOpenStatus(ResultCallback<HashMap<String, Boolean>> callback) {
        PayOpenStatusRequest request = new PayOpenStatusRequest();
        if (APPConfig.isMydKouBei()) {
            request.type = 2;
        } else {
            request.type = 1;
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof PayOpenStatusResponse) {
                    PayOpenStatusResponse responseBean = (PayOpenStatusResponse) responseData.responseBean;
                    HashMap<String, Boolean> statusMap = new HashMap<>();
                    statusMap.put(Constants.PAY_TYPE_WECHAT, false);
                    statusMap.put(Constants.PAY_TYPE_ALIPAY, false);
                    for (PayOpenStatus datum : responseBean.data) {
                        if (android.text.TextUtils.equals(Constants.PAY_TYPE_WECHAT, datum.pay_type)) {
                            if (datum.pay_status == 0) {
                                statusMap.put(Constants.PAY_TYPE_WECHAT, true);
                            } else {
                                statusMap.put(Constants.PAY_TYPE_WECHAT, false);
                            }
                        }
                        if (android.text.TextUtils.equals(Constants.PAY_TYPE_ALIPAY, datum.pay_type)) {
                            if (datum.pay_status == 0) {
                                statusMap.put(Constants.PAY_TYPE_ALIPAY, true);
                            } else {
                                statusMap.put(Constants.PAY_TYPE_ALIPAY, false);
                            }
                        }
                    }
                    callback.onSuccess(statusMap);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 开通支付宝支付
     *
     * @param callback
     */
    public static void loadAliPayOpenRequest(ResultCallback<AliPayOpenPayModel> callback) {

        AliPayOpenPayRequest request = new AliPayOpenPayRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof AliPayOpenPayResponse) {
                    AliPayOpenPayResponse responseBean = (AliPayOpenPayResponse) responseData.responseBean;
                    callback.onSuccess(responseBean.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    /**
     * 开通微信支付
     *
     * @param callback
     */
    public static void loadWXPayOpenRequest(ResultCallback<WXOpenPayModel> callback) {

        WXOpenPayRequest request = new WXOpenPayRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof WXOpenPayResponse) {
                    WXOpenPayResponse responseBean = (WXOpenPayResponse) responseData.responseBean;
                    callback.onSuccess(responseBean.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }
}
