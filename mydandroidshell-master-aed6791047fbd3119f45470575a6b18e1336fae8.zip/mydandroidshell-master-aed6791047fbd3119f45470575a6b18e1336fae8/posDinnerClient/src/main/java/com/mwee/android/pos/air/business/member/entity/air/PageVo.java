package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/1/31.
 */

public class PageVo extends BusinessBean {

    public int pageNo = 1;
    public int pageSize = 30;
}
