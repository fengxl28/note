package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/10/18.
 */

public class CardSettingModel extends BusinessBean {
    public String id = "";

    public String shopid = "";

    public String m_shopid = "";

    public String shop_name = "";

    public String third_shopid = "";

    public String title = "";

    public String is_pay = "";

    public String is_discount_public = "";

    public String is_cost_bonus = "";

    public String first_cost_limit = "";

    public String first_cost_percent = "";

    public String is_increase_bonus = "";

    public String is_score = "";

    public String cost_money_unit = "";

    public String increase_bonus = "";

    public String max_increase_bonus = "";

    public String init_bonus = "";

    //每使用 积分
    public String cost_bonus_unit = "";

    //兑换金额
    public String reduce_money = "";

    public String least_money_to_use_bonus = "";

    public String max_reduce_bonus = "";

    public String increase_limit = "";

    public String increase_bonus_num = "";

    public String is_discount = "";

    public String discount = "";

    public String is_sync = "";

    /**
     * 积分清零规则
     * 是否清空 0否1是
     */
    public String is_clear = "";

    /**
     * 积分清零规则
     * 多少天以内？
     */
    public String clear_day = "";

    public String clear_notiy_day = "";

    public String tel = "";

    public String directions = "";

    public String prompt = "";

    public String img_thumb = "";

    public String img_list = "";

    public String fetched_num = "";

    public String add_time = "";

    public String last_time = "";

    public String props = "";

    public String status = "";

    public String score_reward_rule = "";

    public String preferential_score_open = "";

    public String preferential_coupon_open = "";

    public String preferential_discount_open = "";

    public String preferential_share_rule = "";

    public String wx_card_id = "";

    public String is_hand_score = "";

    public String is_sync_wx_card = "";

    public String wx_desc = "";

    public String shop_note_text = "";

    public CardSettingModel() {
    }
}
