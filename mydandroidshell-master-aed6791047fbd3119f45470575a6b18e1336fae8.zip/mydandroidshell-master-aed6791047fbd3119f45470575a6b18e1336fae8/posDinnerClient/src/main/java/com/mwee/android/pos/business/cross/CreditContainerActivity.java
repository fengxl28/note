package com.mwee.android.pos.business.cross;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.cross.api.CreditApi;
import com.mwee.android.pos.business.cross.dialog.CrossPayDialogFragment;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.component.cross.net.Response;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.FooterStateView;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CreditContainerActivity extends BaseActivity implements PullRecyclerView.OnPullRecyclerViewListener, FooterStateView.OnFooterViewListener, IDriver {
    public final String TAG = "CreditContainerActivity";
    private TitleBar mTitleBar;
    private PullRecyclerView mRecyclerView;
    private TextView mCreditAccountLabel;
    private TextView mCreditContactLabel;
    private TextView mCreditCellphoneLabel;
    private TextView mCreditTelCtLabel;
    private TextView mCreditGuaPriceLabel;
    private TextView mCreditTotalPriceLabel;
    private TextView mCreditCanUsePriceLabel;
    private Button mCreditDestroyBtn;
    private TextView mCreditTabGuaLabel;
    private TextView mCreditTabDestoryLabel;
    private EditText searchInputEdt;
    private TextView mCreditCanCrossPriceLabel;
    private CreditAdapter adapter;
    private int currentPage;
    private String accountName;
    public int currentTabIndex = -1;
    private final int RC_SEARCH = 1;
    private final int INTERVAL = 300; //输入时间间隔为300毫秒
    private Handler searchHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == RC_SEARCH) {
                currentPage = 1;
                accountName = searchInputEdt.getText().toString().trim();
                resetView();
                loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
            }
        }
    };

    private BigDecimal canCrossAmt = BigDecimal.ZERO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_credit_container);
        super.onCreate(savedInstanceState);
        DriverBus.registerDriver(this);
        initView();
        initData();
    }

    protected void initView() {
        searchInputEdt = (EditText) findViewById(R.id.et_SearchDebt);
        mTitleBar = (TitleBar) findViewById(R.id.mTitleBar);
        mRecyclerView = (PullRecyclerView) findViewById(R.id.mPullRecyclerView);
        mCreditAccountLabel = (TextView) findViewById(R.id.mCreditAccountLabel);
        mCreditContactLabel = (TextView) findViewById(R.id.mCreditContactLabel);
        mCreditCellphoneLabel = (TextView) findViewById(R.id.mCreditCellphoneLabel);
        mCreditTelCtLabel = (TextView) findViewById(R.id.mCreditTelCtLabel);
        mCreditGuaPriceLabel = (TextView) findViewById(R.id.mCreditGuaPriceLabel);
        mCreditTotalPriceLabel = (TextView) findViewById(R.id.mCreditTotalPriceLabel);
        mCreditCanUsePriceLabel = (TextView) findViewById(R.id.mCreditCanUsePriceLabel);
        mCreditCanCrossPriceLabel = (TextView) findViewById(R.id.mCreditCanCrossPriceLabel);
        mCreditDestroyBtn = (Button) findViewById(R.id.mCreditDestroyBtn);
        mCreditTabGuaLabel = (TextView) findViewById(R.id.mCreditTabGuaLabel);
        mCreditTabDestoryLabel = (TextView) findViewById(R.id.mCreditTabDestoryLabel);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                KeyboardManager.hideKeyboard(CreditContainerActivity.this);
                finish();
            }
        });
        mTitleBar.setTitle("");
        mCreditTabGuaLabel.setOnClickListener(this);
        mCreditTabDestoryLabel.setOnClickListener(this);
        mCreditDestroyBtn.setOnClickListener(this);
        //默认第一个tab选中
        mCreditTabGuaLabel.setSelected(true);
        mCreditDestroyBtn.setEnabled(false);

    }

    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.mCreditTabGuaLabel:
                showTab(0);
                break;
            case R.id.mCreditTabDestoryLabel:
                showTab(1);
                break;
            case R.id.mCreditDestroyBtn:
                PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance()
                        .userDBModel, Permission.DINNER_bnRemoving, (errCode, msg, userDBModel) -> {
                    if (userDBModel != null) {
                        showCrossPayDialogFragment("", BigDecimal.ZERO, CrossPayDialogFragment.DEFAULT);
                    } else {
                        ToastUtil.showToast(msg);
                    }
                });
                break;
            default:
                break;
        }
    }


    /**
     * 单笔销账
     *
     * @param sellNo 订单号
     * @param amt    金额
     */
    @DrivenMethod(uri = TAG + "/singleOperation")
    public void singleOperation(String sellNo, String amt) {
        if (!TextUtils.isEmpty(amt) && !TextUtils.isEmpty(sellNo)) {
            PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance()
                    .userDBModel, Permission.DINNER_bnRemoving, (errCode, msg, userDBModel) -> {
                if (userDBModel != null) {
                    showCrossPayDialogFragment(sellNo, new BigDecimal(amt), CrossPayDialogFragment.SINGLE);
                } else {
                    ActionLog.addLog("点击'销账'按钮 操作单笔销账被终止 原因：" + (TextUtils.isEmpty(msg) ? "权限校验失败" : msg), ActionLog.CROSS_ACCOUNT_CROSS_DO);
                    ToastUtil.showToast(msg);
                }
            });
        }
    }

    private void showCrossPayDialogFragment(String sellno, BigDecimal amt, int crossType) {
        CrossPayDialogFragment fragment = CrossPayDialogFragment.newInstance();
        CreditAccount account = adapter.modules.get(adapter.selectPosition);
        account.canCrossAmt = canCrossAmt;
        fragment.setParam(account, crossType, sellno, amt, new CrossPayDialogFragment.OnCrossPayListener() {
            @Override
            public void onCrossSuccess(BigDecimal canCrossAmt) {
                refreshAllList();
//                CreditContainerActivity.this.canCrossAmt = canCrossAmt;
//                mCreditCanCrossPriceLabel.setText("可销金额:" + canCrossAmt.toPlainString());
                showCrossDetail(account, false);
            }
        });
        ActionLog.addLog("点击销账按钮[" + adapter.modules.get(adapter.selectPosition).toString() + "]", ActionLog.CROSS_ACCOUNT_CROSS_BTN_CLICK);
        DialogManager.showCustomDialog(this, fragment, "CrossPayDialogFragment");
    }

    public void refreshAllList() {
        GuaOrderListFragment fragment = (GuaOrderListFragment) getSupportFragmentManager().findFragmentByTag("GuaOrderListFragment");
        if (fragment != null && fragment.isAdded()) {
            fragment.refresh();
        }
        mRecyclerView.setRefreshing();
    }

    private void showTab(int i) {
        if (adapter.selectPosition < 0) {
            return;
        }
        String fsCreditAccountId = "";
        if (adapter.modules.size() > 0 && adapter.selectPosition >= 0) {
            fsCreditAccountId = adapter.modules.get(adapter.selectPosition).fsCreditAccountId;
        }
        switch (i) {
            case 0:
                ActionLog.addLog("点击挂账历史数据[" + adapter.modules.get(adapter.selectPosition).fsCreditAccountId + "]", ActionLog.CROSS_ACCOUNT_GUA_LIST);
                mCreditTabGuaLabel.setSelected(true);
                mCreditTabDestoryLabel.setSelected(false);
                GuaOrderListFragment guaOrderListFragment = GuaOrderListFragment.newInstance(fsCreditAccountId);
                getSupportFragmentManager().beginTransaction().replace(R.id.mCrossDetailContainer, guaOrderListFragment, "GuaOrderListFragment").commit();
                break;
            case 1:
                ActionLog.addLog("点击销账历史数据[" + adapter.modules.get(adapter.selectPosition).fsCreditAccountId + "]", ActionLog.CROSS_ACCOUNT_CROSS_LIST);
                mCreditTabGuaLabel.setSelected(false);
                mCreditTabDestoryLabel.setSelected(true);
                CrossOrderListFragment fragment = CrossOrderListFragment.newInstance(fsCreditAccountId);
                fragment.setParam(debtAmt -> {
                    CreditAccount account = adapter.modules.get(adapter.selectPosition);
                    account.fdDebtAmt = debtAmt;
                    adapter.notifyDataSetChanged();
                    showCrossDetail(account, false);
                });
                getSupportFragmentManager().beginTransaction().replace(R.id.mCrossDetailContainer, fragment, "CrossOrderListFragment").commit();
                break;
            default:
                break;
        }
        currentTabIndex = i;
    }

    private void initData() {
        mRecyclerView.setEnablePullToEnd(true);
        mRecyclerView.setEnablePullToStart(true);
        mRecyclerView.setLayoutManager(getGridLayoutManager(3));
        mRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        adapter = new CreditAdapter();
        adapter.isFooterShow = true;
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setOnPullRecyclerViewListener(this);
        mRecyclerView.setRefreshing();
        searchInputEdt.addTextChangedListener(searchTextWatcher);
    }


    private void loadDataFromServer(int mode) {
        CreditApi.loadCrossAccountList(accountName, currentPage, 30, new ResultCallback<Response<CreditAccount>>() {
            @Override
            public void onSuccess(Response<CreditAccount> data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    adapter.modules.clear();
                }
                if (currentPage >= data.totalPages) {
                    //没有下一页数据
                    mRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (currentPage <= 1 && ListUtil.isEmpty(data.result)) {
                    mRecyclerView.showEmptyView();
                } else {
                    mRecyclerView.showContent();
                    adapter.modules.addAll(data.result);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (adapter.modules.size() == 0) {
                        mRecyclerView.showEmptyView();
                    }
                    mRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    /**
     * 搜索框更新监听
     */
    TextWatcher searchTextWatcher = new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (searchHandler.hasMessages(RC_SEARCH)) {
                searchHandler.removeMessages(RC_SEARCH);
            }
            searchHandler.sendEmptyMessageDelayed(RC_SEARCH, INTERVAL);
        }
    };


    @Override
    public void onRefresh(int mode) {
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onScrollUp() {

    }

    @Override
    public void onScrollDown() {

    }

    @Override
    public void onLoadMoreRetry() {
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    public String getModuleName() {
        return TAG;
    }


    class CreditAdapter extends BaseListAdapter<CreditAccount> {
        public int selectPosition = -1;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(CreditContainerActivity.this).inflate(R.layout.view_credit_account_item, parent, false));
        }


        class Holder extends BaseViewHolder implements View.OnClickListener {
            private TextView mCreditAccountItemAccountLabel;
            private TextView mCreditAccountItemGuaPriceLabel;
            private TextView mCreditAccountItemCanUsePriceLabel;
            private CreditAccount module;
            private int position;

            public Holder(View v) {
                super(v);
                v.setOnClickListener(this);
                mCreditAccountItemAccountLabel = (TextView) v.findViewById(R.id.mCreditAccountItemAccountLabel);
                mCreditAccountItemGuaPriceLabel = (TextView) v.findViewById(R.id.mCreditAccountItemGuaPriceLabel);
                mCreditAccountItemCanUsePriceLabel = (TextView) v.findViewById(R.id.mCreditAccountItemCanUsePriceLabel);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                module = modules.get(position);
                mCreditAccountItemAccountLabel.setText(module.fsCreditAccountName);

                BigDecimal fdBalanceAmt = module.fdCreditAmt.subtract(module.fdDebtAmt);
                if (fdBalanceAmt.compareTo(BigDecimal.ZERO) < 0) {
                    fdBalanceAmt = BigDecimal.ZERO;
                }
                mCreditAccountItemGuaPriceLabel.setText("挂 " + fdBalanceAmt.toPlainString());
                mCreditAccountItemCanUsePriceLabel.setText("余 " + module.fdDebtAmt.toPlainString());

                itemView.setSelected(selectPosition == position);
            }

            @Override
            public void onClick(View view) {
                if (ButtonClickTimer.canClick()) {
                    ActionLog.addLog("点击挂账账户[" + module.fsCreditAccountName + "]", ActionLog.CROSS_ACCOUNT_ITEM_CLICK);
                    if (position != selectPosition) {
                        showCrossDetail(module, true);
                    }
                }
            }
        }

        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            FooterStateView footerView = new FooterStateView(CreditContainerActivity.this);
            footerView.setOnFooterViewListener(CreditContainerActivity.this);
            ViewGroup.LayoutParams layoutParams = null;
            if (mRecyclerView.getLayoutManager() instanceof StaggeredGridLayoutManager) {
                layoutParams = mRecyclerView.getLayoutManager().generateDefaultLayoutParams();
            } else {
                layoutParams = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT);
            }
            footerView.setLayoutParams(layoutParams);
            return footerView;
        }
    }

    private void showCrossDetail(CreditAccount module, boolean isClickTab) {
        int position = adapter.modules.indexOf(module);
        findViewById(R.id.mCrossDetailContainer).setVisibility(View.VISIBLE);
        Progress progress = ProgressManager.showProgressUncancel(this, "");
        CreditApi.loadAccount(module.fsCreditAccountId, new ResultCallback<CreditAccount>() {
            @Override
            public void onSuccess(CreditAccount data) {
                progress.dismissSelf();
                mCreditAccountLabel.setText(data.fsCreditAccountName);
                mCreditContactLabel.setText(getString(R.string.account_contact) + data.fsContact);
                mCreditCellphoneLabel.setText(getString(R.string.account_mobile) + data.fsCellphoneCt);
                mCreditTelCtLabel.setText(getString(R.string.account_tel) + data.fsTelCt);
                mCreditGuaPriceLabel.setText(getString(R.string.account_gua_price) + data.fdBalanceAmt.toPlainString());
                mCreditTotalPriceLabel.setText(getString(R.string.account_balance) + data.fdCreditAmt.toPlainString());
                mCreditCanUsePriceLabel.setText(getString(R.string.account_can_use_balance) + data.fdDebtAmt.toPlainString());
                mCreditCanCrossPriceLabel.setText("可销金额:" + data.canCrossAmt.toPlainString());
                mCreditDestroyBtn.setEnabled(data.canCrossAmt.compareTo(BigDecimal.ZERO) > 0);
                canCrossAmt = data.canCrossAmt;
                adapter.selectPosition = position;
                adapter.notifyDataSetChanged();
                if (isClickTab) {
                    showTab(0);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
            }
        });
    }

    private void resetView() {
        findViewById(R.id.mCrossDetailContainer).setVisibility(View.GONE);
        adapter.selectPosition = -1;
        mCreditAccountLabel.setText("-");
        mCreditContactLabel.setText(getString(R.string.account_contact) + "-");
        mCreditCellphoneLabel.setText(getString(R.string.account_mobile) + "-");
        mCreditTelCtLabel.setText(getString(R.string.account_tel) + "-");
        mCreditGuaPriceLabel.setText(getString(R.string.account_gua_price) + "-");
        mCreditTotalPriceLabel.setText(getString(R.string.account_balance) + "-");
        mCreditCanUsePriceLabel.setText(getString(R.string.account_can_use_balance) + "-");
        mCreditCanCrossPriceLabel.setText("可销金额:-");
        mCreditDestroyBtn.setEnabled(false);
    }

    public GridLayoutManager getGridLayoutManager(int spanCount) {
        final GridLayoutManager manager = new GridLayoutManager(this, spanCount);
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (adapter.isHeaderShow(position) || adapter.isFooterShow(position)) {
                    return manager.getSpanCount();
                }
                return 1;
            }
        });
        return manager;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DriverBus.unRegisterDriver(this);
        searchHandler.removeCallbacksAndMessages(null);
    }


}
