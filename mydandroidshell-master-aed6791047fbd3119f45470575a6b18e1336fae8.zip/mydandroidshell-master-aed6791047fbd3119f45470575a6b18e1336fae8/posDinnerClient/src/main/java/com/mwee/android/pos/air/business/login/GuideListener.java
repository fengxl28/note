package com.mwee.android.pos.air.business.login;

/**
 * Created by hm on 2018/1/15.
 *
 */
public interface GuideListener{
    void currentPage(int pageIndex);
}
