package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * 消费储值记录
 * Created by zhangmin on 2018/1/30.
 */

public class MemberCardContainer extends BusinessBean {

    public int pageNo;

    public int size;

    public int count;

    public int pages;

    public int todayIncreaseMember;

    public List<AirMemberCardModel> rows = new ArrayList<>();


}
