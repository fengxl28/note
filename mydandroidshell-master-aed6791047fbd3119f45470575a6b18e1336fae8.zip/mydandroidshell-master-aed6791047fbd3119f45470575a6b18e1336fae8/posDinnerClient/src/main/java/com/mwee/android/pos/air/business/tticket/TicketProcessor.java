package com.mwee.android.pos.air.business.tticket;

import com.mwee.android.pos.base.Host;

/**
 * Created by zhangmin on 2017/9/29.
 */

public class TicketProcessor {

    private Host mHost;

    public TicketProcessor(Host mHost) {
        this.mHost = mHost;
    }




}
