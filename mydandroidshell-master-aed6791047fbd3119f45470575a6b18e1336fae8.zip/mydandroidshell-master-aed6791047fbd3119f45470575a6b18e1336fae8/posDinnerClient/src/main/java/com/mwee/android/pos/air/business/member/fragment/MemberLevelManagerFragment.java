package com.mwee.android.pos.air.business.member.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.dialog.MemberLevelAddDialogFragment;
import com.mwee.android.pos.air.business.member.dialog.MemberLevelEditorDialogFragment;
import com.mwee.android.pos.air.business.member.entity.MemberLevelModel;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberLeverResponse;
import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/01/26.
 */

public class MemberLevelManagerFragment extends BaseListFragment<MemberLevelModel> {
    private MemberEditorProcessor mMemberEditorProcessor;
    private Button mMemberLevelAddBtn;
    private LinearLayout mLevelAddLayout;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_air_member_level_manager;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);

        mLevelAddLayout = view.findViewById(R.id.mLevelAddLayout);
        mMemberLevelAddBtn = view.findViewById(R.id.mMemberLevelAddBtn);
        mMemberLevelAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doAddMemberLevel();
            }
        });
    }

    @Override
    protected void initData() {
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mPullRecyclerView.setEnablePullToStart(false);
        mMemberEditorProcessor = new MemberEditorProcessor();
        loadDataFromServer();
    }

    private void loadDataFromServer() {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        mMemberEditorProcessor.loadShopMemberLevelList(new ResultCallback<AirMemberLeverResponse>() {
            @Override
            public void onSuccess(AirMemberLeverResponse data) {
                ArrayList<MemberLevelModel> memberLevelModels = data.data;
                refreshLevelAdapter(memberLevelModels);
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


    private void refreshLevelAdapter(ArrayList<MemberLevelModel> memberLevelModels) {
        if (!ListUtil.isEmpty(memberLevelModels)) {
            adapter.modules.clear();
            adapter.modules.addAll(memberLevelModels);
            adapter.notifyDataSetChanged();
        }
        if (modules.size() >= 3) {
            mLevelAddLayout.setVisibility(View.GONE);
        } else {
            mLevelAddLayout.setVisibility(View.VISIBLE);
        }

    }

    /**
     * 新增会员等级 处理历史数据问题
     */
    private void doAddMemberLevel() {
        MemberLevelAddDialogFragment dialog = new MemberLevelAddDialogFragment();
        dialog.setOnMemberLevelAddListener(new MemberLevelAddDialogFragment.OnMemberLevelAddListener() {
            @Override
            public void onMemberLevelAddSuccess() {
                loadDataFromServer();
            }
        });

        DialogManager.showCustomDialog(MemberLevelManagerFragment.this, dialog, "MemberLevelEditorDialogFragment");
    }


    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_member_level_item, parent, false));
    }


    class Holder extends BaseViewHolder implements View.OnClickListener {

        private TextView mMemberLevelItemLabel;
        private TextView mMemberLevelItemRuleLevel;
        private TextView mMemberLevelItemRuleCost;
        private TextView mMemberLevelItemGift;
        private ImageView icon_editor;

        private MemberLevelModel model;
        private MemberLevelModel preModel;

        private ImageView icon_delete;

        public Holder(View v) {
            super(v);
            mMemberLevelItemLabel = v.findViewById(R.id.mMemberLevelItemLabel);
            mMemberLevelItemRuleLevel = v.findViewById(R.id.mMemberLevelItemRuleLevel);
            mMemberLevelItemRuleCost = v.findViewById(R.id.mMemberLevelItemRuleCost);
            mMemberLevelItemGift = v.findViewById(R.id.mMemberLevelItemGift);
            icon_editor = v.findViewById(R.id.icon_editor);
            icon_editor.setOnClickListener(this);
            icon_delete = v.findViewById(R.id.icon_delete);
            icon_delete.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);
            mMemberLevelItemLabel.setText(model.title);
            //后台下发的数据 是从等级3以后所有级别
            if (Integer.valueOf(model.level) == 3) {//黄金会员
                mMemberLevelItemRuleCost.setText("录入即为会员");
                mMemberLevelItemGift.setText("无");
                mMemberLevelItemRuleLevel.setVisibility(View.GONE);
                icon_editor.setVisibility(View.INVISIBLE);
            } else {
                LogUtil.log("preModel-->"+position);
                preModel = position - 1 >= 0 ? modules.get(position - 1) : null;
                mMemberLevelItemRuleLevel.setVisibility(View.VISIBLE);
                icon_editor.setVisibility(View.VISIBLE);
                //preTitle = modules.get(position - 1).title;
                if (new BigDecimal(model.expense_amount).intValue() == 0) {
                    mMemberLevelItemRuleLevel.setText(String.format("-需先成为%s-", preModel == null ? "" : preModel.title));
                    mMemberLevelItemRuleCost.setText(String.format("未启用，请设置升级规则"));
                    mMemberLevelItemGift.setText(String.format("未设置"));
                } else {
                    mMemberLevelItemRuleLevel.setText(String.format("-需先成为%s-", preModel == null ? "" : preModel.title));
                    mMemberLevelItemRuleCost.setText(String.format("累计消费%s元", model.expense_amount));
                    mMemberLevelItemGift.setText(String.format("赠送%s积分", model.reward_point));
                    icon_editor.setVisibility(View.VISIBLE);
                }
            }

        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.icon_editor:
                    if (preModel != null && Integer.valueOf(preModel.level) > 3) {
                        /**
                         * 铂金会员未设置时，不可设置钻石会员。点击钻石会员的“编辑”，toast提示：请先启用铂金会员。
                         */
                        if (new BigDecimal(preModel.expense_amount).intValue() == 0) {
                            ToastUtil.showToast(String.format("请先启用%s", preModel.title));
                            icon_editor.setEnabled(false);
                            return;
                        }
                    }

                    MemberLevelEditorDialogFragment dialog = new MemberLevelEditorDialogFragment();
                    dialog.setParam(model, preModel == null ? "" : preModel.title);
                    dialog.setOnMemberLevelEditorListener(new MemberLevelEditorDialogFragment.OnMemberLevelEditorListener() {
                        @Override
                        public void onMemberLevelEditorSuccess() {
                            loadDataFromServer();
                        }
                    });
                    DialogManager.showCustomDialog(MemberLevelManagerFragment.this, dialog, "MemberLevelEditorDialogFragment");
                    break;
                case R.id.icon_delete:
                    Progress progress = ProgressManager.showProgress(getActivityWithinHost());
                    mMemberEditorProcessor.doLevelDelete(model, new ResultCallback<String>() {
                        @Override
                        public void onSuccess(String data) {
                            loadDataFromServer();
                            progress.dismissSelf();
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            ToastUtil.showToast(msg);
                            super.onFailure(code, msg);
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    }

}
