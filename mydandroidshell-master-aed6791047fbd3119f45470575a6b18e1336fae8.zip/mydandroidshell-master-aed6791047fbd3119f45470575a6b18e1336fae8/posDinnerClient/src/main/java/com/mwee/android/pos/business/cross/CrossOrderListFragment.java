package com.mwee.android.pos.business.cross;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.cross.api.CreditApi;
import com.mwee.android.pos.component.cross.net.CrossOrder;
import com.mwee.android.pos.component.cross.net.Response;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CrossOrderListFragment extends BaseListFragment<CrossOrder> {
    private String accountId;
    private int currentPage;
    private OnReverseCrossListener listener;

    public static CrossOrderListFragment newInstance(String accountId) {
        CrossOrderListFragment fragment = new CrossOrderListFragment();
        Bundle args = new Bundle();
        args.putString("accountId", accountId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_cross_order_list;
    }

    @Override
    protected void initData() {
        super.initData();
        if (getArguments() != null) {
            accountId = getArguments().getString("accountId");
        }
        adapter.isFooterShow = true;
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    private void loadDataFromServer(int mode) {
        CreditApi.loadCrossOrderList(accountId, currentPage, 30, new ResultCallback<Response<CrossOrder>>() {
            @Override
            public void onSuccess(Response<CrossOrder> data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    adapter.modules.clear();
                }
                if (currentPage >= data.totalPages) {
                    //没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (currentPage == 1 && !TextUtils.validate(data.result)) {
                    mPullRecyclerView.showEmptyView();
                } else {
                    mPullRecyclerView.showContent();
                    adapter.modules.addAll(data.result);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (adapter.modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_cross_item, parent, false));
    }

    public void setParam(OnReverseCrossListener listener) {
        this.listener = listener;
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private ImageView mCrossItemReverseImg;
        private TextView mCrossItemReverseTagLabel;
        private TextView mCrossItemCreateTimeLabel;
        private TextView mCrossItemOrderNumberLabel;
        private TextView mCrossItemPriceLabel;
        private TextView mCrossItemUsernameLabel;
        private TextView mCrossItemTypeLabel;
        private CrossOrder order;

        public Holder(View v) {
            super(v);
            mCrossItemCreateTimeLabel = (TextView) v.findViewById(R.id.mCrossItemCreateTimeLabel);
            mCrossItemOrderNumberLabel = (TextView) v.findViewById(R.id.mCrossItemOrderNumberLabel);
            mCrossItemPriceLabel = (TextView) v.findViewById(R.id.mCrossItemPriceLabel);
            mCrossItemUsernameLabel = (TextView) v.findViewById(R.id.mCrossItemUsernameLabel);
            mCrossItemTypeLabel = (TextView) v.findViewById(R.id.mCrossItemTypeLabel);
            mCrossItemReverseTagLabel = (TextView) v.findViewById(R.id.mCrossItemReverseTagLabel);
            mCrossItemReverseImg = (ImageView) v.findViewById(R.id.mCrossItemReverseImg);
            mCrossItemReverseImg.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            order = modules.get(position);
            mCrossItemCreateTimeLabel.setText(DateTimeUtil.getTime(order.createTime));
            mCrossItemOrderNumberLabel.setText(order.recordNo);
            mCrossItemPriceLabel.setText(order.crossAccountAmt.toPlainString());
            mCrossItemUsernameLabel.setText(order.createUserName);
            mCrossItemTypeLabel.setText(order.paymentName);
            if (order.isReverse == 0) {
                mCrossItemReverseImg.setVisibility(View.VISIBLE);
                mCrossItemReverseTagLabel.setVisibility(View.GONE);
            } else {
                mCrossItemReverseTagLabel.setVisibility(View.VISIBLE);
                mCrossItemReverseImg.setVisibility(View.GONE);
                if (TextUtils.validate(order.note)) {
                    mCrossItemReverseTagLabel.setText("已撤销\n" + order.note);
                } else {
                    mCrossItemReverseTagLabel.setText("已撤销");
                }
            }
        }

        @Override
        public void onClick(View view) {
            String title = "是否撤回该笔销账记录？";
            String message = "撤回后，线上支付将自动退款，该笔销账金额从挂账可用余额中扣除";
            DialogManager.showExecuteDialog(getActivityWithinHost(), title, message, "取消", "确定", new DialogResponseListener() {
                @Override
                public void response() {
                    loadReverseCross(order.id);
                }
            }, null);
        }
    }

    public void loadReverseCross(int recordId) {
        Progress progress = ProgressManager.showProgressUncancel(this, "反销账中...");
        CreditApi.loadReverseCross(recordId, accountId, new ResultCallback<BigDecimal>() {
            @Override
            public void onSuccess(BigDecimal data) {
                listener.onReverseCrossSuccess(data);
                progress.dismissSelf();
                ToastUtil.showToast("反销账成功！");
                mPullRecyclerView.setRefreshing();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    public interface OnReverseCrossListener {
        void onReverseCrossSuccess(BigDecimal debtAmt);
    }
}
