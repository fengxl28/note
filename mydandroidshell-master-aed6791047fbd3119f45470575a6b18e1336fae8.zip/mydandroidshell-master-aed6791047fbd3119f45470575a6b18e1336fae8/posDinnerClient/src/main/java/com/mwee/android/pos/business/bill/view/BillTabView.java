package com.mwee.android.pos.business.bill.view;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.bill.bean.SearchDataItem;
import com.mwee.android.pos.business.constants.HostConstant;
import com.mwee.android.pos.business.message.UnDealCountMessageModel;
import com.mwee.android.pos.business.permissions.view.NiceSpinner;
import com.mwee.android.pos.client.db.BillSourceDBUtil;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bean.GetOrderFromCenterRespone;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.business.monitor.report.LoadAccountBookResponse;
import com.mwee.android.pos.connect.business.netorder.GetNetOrderSimpleInfoResponse;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.BillSourceDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by zhangmin on 2017/8/9.
 */

public class BillTabView extends LinearLayout implements View.OnClickListener {

    private LinearLayout mBillModeLayout;
    private TextView tvBillDinner;
    private TextView tvBillFastFood;
    private TextView tvBillAll;
    private View redBottom1;
    private TextView tvBillPayNo;
    private View redBottom2;
    private TextView tvBillPay;
    private View redBottom3;
    private NiceSpinner nineSpinnerBillResouce;
    private TextView tvBillFilterTime;
    private AutoCompleteTextView autoTVCheck;
    private Button btBillSearch;
    private TextView mExpAmtTv;
    private TextView mCashTimeTv;

    private String businessDate = AppCache.getInstance().businessDate;

    /**
     * 展示的数据源
     */
    public List<OrderListModel> billList = new ArrayList<>();
    private SearchAdapter searchAdapter;//正餐快餐的根据桌号或者账单后四位查询
    private SearchNetOrderAdapter searchNetOrderAdapter;//外卖单根据账单后四位查询

    private View rootBillView;
    private Host mHost;
    private BillDataProcess billDataProcess;


    /**
     * 筛选条件
     */
    public static final String DINNER = "dinner";  //正餐
    public static final String FAST_FOOD = "fastFood";  //快餐
    public static final String NET_ORDER = "netorder";  //外卖

    public static final String ALL = "all";
    public static final String PAYED = "payed";
    public static final String UNPAY = "unpay";


    public String fatherType = DINNER;
    public String dataTypeTag = ALL;
    private String fsBillSourceId = "-1";  //订单来源，默认取全部

    private TextView tvTitleTableName;
    private TextView tvTitleBrand;
    private TextView tvRefreshTime;
    private TextView tvBillNetOrder;
    private LinearLayout llBillLayout;
    private View viewNetOrderLayout;
    private View llDinnerTabLayout;
    private BillSourceAdapter billSourceAdapter;

    private TextView mTvEInvoiceStatus;

    /**
     * 快餐的订单来源筛选
     */
    private List<BillSourceDBModel> billSourceDBModelMap = new ArrayList<>();

    /**
     * 外卖单的订单来源筛选
     */
    private List<BillSourceDBModel> billSourceNetOrderMap = new ArrayList<>();

    private TextView tvRefreshTimeNetOrder;//外卖单的刷新时间

    private ImageView bill_netorder_warning;

    private ImageView mSwitchBill; //AB账切换
    public int mBillClass; //0, A账；1: B账
    public List<AccountBookDBModel> mAccountBookList = new ArrayList<>(); // 账套列表
    public String mAccountBookId; //1, A账；2: B账

    public int currentPage = 1;
    private String searchContent;
    private int searchType = 1;// 1：搜订单号，2：搜桌台名；3：搜输入内容
    private boolean isExpAmtSortUp = true; // true: 升序false：降序
    private boolean isCashTimeSortUp = true; // true: 升序false：降序

    public BillTabView(Context context) {
        super(context);
        initView(context);
    }

    public BillTabView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public BillTabView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public void updateNoticeImg(UnDealCountMessageModel unDealCountMessageModel) {
        if (unDealCountMessageModel.unMappingOrderCount > 0) {
            bill_netorder_warning.setVisibility(View.VISIBLE);
        } else {
            bill_netorder_warning.setVisibility(View.GONE);
        }
    }

    private void initView(Context mContext) {
        View.inflate(mContext, R.layout.bill_tab_view, this);

        rootBillView = findViewById(R.id.rootBillView);
        mBillModeLayout = (LinearLayout) findViewById(R.id.mBillModeLayout);
        tvBillDinner = (TextView) findViewById(R.id.tvBillDinner);
        tvBillFastFood = (TextView) findViewById(R.id.tvBillFastFood);
        tvBillNetOrder = (TextView) findViewById(R.id.tvBillNetOrder);
        tvRefreshTimeNetOrder = (TextView) findViewById(R.id.tvRefreshTimeNetOrder);
        bill_netorder_warning = findViewById(R.id.bill_netorder_warning);

        llBillLayout = (LinearLayout) findViewById(R.id.llBillLayout);
        tvBillAll = (TextView) findViewById(R.id.tvBillAll);
        redBottom1 = findViewById(R.id.redBottom1);
        tvBillPayNo = (TextView) findViewById(R.id.tvBillPayNo);
        redBottom2 = findViewById(R.id.redBottom2);
        tvBillPay = (TextView) findViewById(R.id.tvBillPay);
        redBottom3 = findViewById(R.id.redBottom3);

        nineSpinnerBillResouce = (NiceSpinner) findViewById(R.id.nineSpinnerBillResouce);
        tvBillFilterTime = (TextView) findViewById(R.id.tvBillFilterTime);
        autoTVCheck = (AutoCompleteTextView) findViewById(R.id.autoTVCheck);
        btBillSearch = (Button) findViewById(R.id.btBillSearch);

        viewNetOrderLayout = findViewById(R.id.viewNetOrderLayout);
        llDinnerTabLayout = findViewById(R.id.llDinnerTabLayout);
        tvTitleTableName = (TextView) findViewById(R.id.tv_title_table_name);
        tvTitleBrand = (TextView) findViewById(R.id.tv_title_brand);
        tvRefreshTime = (TextView) findViewById(R.id.tv_billrefresh_time);
        mExpAmtTv = (TextView) findViewById(R.id.tv_head_expamt_label);
        mCashTimeTv = (TextView) findViewById(R.id.tv_head_cashTime_label);

        mTvEInvoiceStatus = findViewById(R.id.tv_einvoice_status);

        tvBillDinner.setOnClickListener(this);
        tvBillFastFood.setOnClickListener(this);
        tvBillNetOrder.setOnClickListener(this);
        tvBillAll.setOnClickListener(this);
        tvBillPayNo.setOnClickListener(this);
        tvBillPay.setOnClickListener(this);
        tvBillFilterTime.setOnClickListener(this);
        btBillSearch.setOnClickListener(this);
        mExpAmtTv.setOnClickListener(this);
        mCashTimeTv.setOnClickListener(this);

        /*初始化的时候默认开启桌台单,*/
        if (TextUtils.equals(fatherType, DINNER)) {
            tvBillDinner.setSelected(true);
            mTvEInvoiceStatus.setVisibility(View.VISIBLE);
        } else if (TextUtils.equals(fatherType, FAST_FOOD)) {
            tvBillFastFood.setSelected(true);
            mTvEInvoiceStatus.setVisibility(View.VISIBLE);
        } else if (TextUtils.equals(fatherType, NET_ORDER)) {
            tvBillNetOrder.setSelected(true);
            mTvEInvoiceStatus.setVisibility(View.GONE);
        }
        autoTVCheck.postDelayed(new Runnable() {
            @Override
            public void run() {
                autoTVCheck.setText("");
            }
        }, 50);

        mSwitchBill = findViewById(R.id.iv_bill_tab_change);
        mSwitchBill.setOnClickListener(this);
        refreshBillSwitch();

        if (AppCache.getInstance().isRetailMode()) {//小易2.2样式更改
            findViewById(R.id.ll_option_container).setBackgroundColor(Color.WHITE);
            tvBillDinner.setTextColor(getResources().getColorStateList(R.color.air_selector_color_white_black_text));
            tvBillDinner.setBackgroundResource(R.drawable.air_selector_left_half_black_red);
            tvBillFastFood.setTextColor(getResources().getColorStateList(R.color.air_selector_color_white_black_text));
            tvBillFastFood.setBackgroundResource(R.drawable.air_selector_middle_black_red);
            tvBillNetOrder.setTextColor(getResources().getColorStateList(R.color.air_selector_color_white_black_text));
            tvBillNetOrder.setBackgroundResource(R.drawable.air_selector_right_half_black_red);
            mBillModeLayout.setPadding(1, 1, 1, 1);
            mBillModeLayout.setBackgroundResource(R.drawable.air_bg_cubic_whole_black);

            tvBillAll.setTextColor(getResources().getColor(R.color.air_selector_color_white_red_text));
            tvBillPayNo.setTextColor(getResources().getColor(R.color.air_selector_color_white_red_text));
            tvBillPay.setTextColor(getResources().getColor(R.color.air_selector_color_white_red_text));

            nineSpinnerBillResouce.setBackgroundResource(R.drawable.air_bg_cubic_whole_black);
            nineSpinnerBillResouce.setTextColor(Color.BLACK);
            findViewById(R.id.ll_businessDate_container).setBackgroundResource(R.drawable.air_bg_cubic_whole_black);
            ((TextView) findViewById(R.id.tv_businessDate)).setTextColor(Color.BLACK);
            tvBillFilterTime.setTextColor(Color.BLACK);
            autoTVCheck.setBackgroundResource(R.drawable.air_bg_cubic_whole_black);

            llDinnerTabLayout.setBackgroundColor(getResources().getColor(R.color.color_f0f0f0));
            viewNetOrderLayout.setBackgroundColor(getResources().getColor(R.color.color_f0f0f0));
            setTextColorOfViewGroup((ViewGroup) llDinnerTabLayout, getResources().getColor(R.color.color_656565));
            setTextColorOfViewGroup((ViewGroup) viewNetOrderLayout, getResources().getColor(R.color.color_656565));
        }
    }

    private void refreshBillSwitch() {
        mSwitchBill.setVisibility(GONE);
        mBillClass = 0;
        mAccountBookId = "1";
        if (!ListUtil.isEmpty(mAccountBookList)) {
            // 目前UI没有兼容多账套选择，只支持切换A/B，产品吴丽丽说后期提优化再改。。
            if (mAccountBookList.size() != 2) {
                mSwitchBill.setVisibility(GONE);
            } else {
                boolean show = true;
                for (AccountBookDBModel temp : mAccountBookList) {
                    if (temp == null || (!TextUtils.equals("1", temp.accountBookId) && !TextUtils.equals("2", temp.accountBookId))) {
                        show = false;
                    }
                }
                mSwitchBill.setVisibility(show ? VISIBLE : GONE);
            }
            mAccountBookId = mAccountBookList.get(0).accountBookId;
        }
        if (TextUtils.equals("2", mAccountBookId)) {
            mSwitchBill.setImageResource(R.drawable.ic_bill_b);
        } else {
            mSwitchBill.setImageResource(R.drawable.ic_bill_a);
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup, int color) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof TextView) {
                ((TextView) view).setTextColor(color);
            }
        }
    }

    private void initNetOrderSourceModelList() {
        billSourceNetOrderMap.add(BillSourceDBUtil.optDefaultBillSourceModel());
        BillSourceDBModel meituan = new BillSourceDBModel();
        meituan.fsBillSourceName = "美团";
        meituan.fsBillSourceId = "MEITUAN";
        billSourceNetOrderMap.add(meituan);
        BillSourceDBModel mwee = new BillSourceDBModel();
        mwee.fsBillSourceName = "美味不用等";
        mwee.fsBillSourceId = "MWEE";
        billSourceNetOrderMap.add(mwee);
        BillSourceDBModel eleme = new BillSourceDBModel();
        eleme.fsBillSourceName = "饿了么";
        eleme.fsBillSourceId = "ELEME";
        billSourceNetOrderMap.add(eleme);
    }

    private void initData() {
        currentPage = 1;
        mAccountBookId = "1";

        /*初始化订单来源*/
        billSourceDBModelMap.addAll(AppCache.getInstance().billSourceDBModelMap);
        billSourceDBModelMap.add(0, BillSourceDBUtil.optDefaultBillSourceModel());

        initNetOrderSourceModelList();

        billSourceAdapter = new BillSourceAdapter(this.getContext());
        billSourceAdapter.setData(billSourceDBModelMap);
        nineSpinnerBillResouce.setAdapter(billSourceAdapter);
        nineSpinnerBillResouce.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                BillSourceDBModel billSourceDBModel = (BillSourceDBModel) parent.getAdapter().getItem(position);
                ActionLog.addLog("账单管理页面-->快餐单-->选择了订单来源[" + billSourceDBModel.fsBillSourceName + "]", "", "", ActionLog.BILL_FRAGMENT, "");
                fsBillSourceId = billSourceDBModel.fsBillSourceId;
                currentPage = 1;
                DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        /*设置营业日期数据*/
        tvBillFilterTime.setText(businessDate);

        /*设置桌号或者账单号搜索条件*/
        autoTVCheck.setThreshold(1);
        searchAdapter = new SearchAdapter(this.getContext(), billList);
        autoTVCheck.setAdapter(searchAdapter);

        autoTVCheck.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //单号查询的条目点击事件
                SearchDataItem dataItem;
                if (!TextUtils.equals(fatherType, NET_ORDER)) {  //操作正餐快餐
                    dataItem = searchAdapter.modules.get(position);
                } else { //操作外卖单
                    dataItem = searchNetOrderAdapter.modules.get(position);
                }
                searchContent = dataItem == null ? "" : dataItem.dataContent;
                searchType = dataItem == null ? 1 : (dataItem.isOrderNo ? 1 : 2);
                autoTVCheck.setText("");
                currentPage = 1;
                setSortIcon(mExpAmtTv, true);
                setSortIcon(mCashTimeTv, true);
                DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
            }
        });

        autoTVCheck.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                long time = DateUtil.getCurrentTimeInMills();
                //输入的字符间隔时间 小于700毫秒 移除以前的handler 延时600毫秒执行
                if (autoTVCheck.getTag() != null && time - (Long) autoTVCheck.getTag() < 700) {
                    searchHandler.removeMessages(1);
                }
                searchHandler.sendEmptyMessageDelayed(1, 600);
                autoTVCheck.setTag(time);
            }
        });

        searchNetOrderAdapter = new SearchNetOrderAdapter(this.getContext(), billDataProcess.NetOrderBillList);

        /*根据站点配置桌台单和快餐单*/
        switch (AppCache.getInstance().currentHostType) {
            case HostConstant.FASTFOOD_HOST:
                fatherType = FAST_FOOD;
                tvBillDinner.setVisibility(View.GONE);
                tvBillFastFood.setSelected(true);
                if (AppCache.getInstance().isRetailMode()) {
                    tvBillFastFood.setBackgroundResource(R.drawable.air_selector_left_half_black_red);
                } else {
                    tvBillFastFood.setBackgroundResource(R.drawable.selector_left_half_black_red);
                }
                tvTitleBrand.setVisibility(View.VISIBLE);
                break;
            case HostConstant.SUPER_HOST:
                fatherType = DINNER;
                tvBillAll.setSelected(true);
                tvTitleBrand.setVisibility(View.GONE);
                mBillModeLayout.setVisibility(View.VISIBLE);
                break;
            case HostConstant.ORDER_DISHES_HOST:
            case HostConstant.CASHIER_HOST:
                fatherType = DINNER;
                tvBillAll.setSelected(true);
                tvBillFastFood.setVisibility(View.GONE);
                tvTitleBrand.setVisibility(View.GONE);
                break;
            default:
                break;
        }

        billDataProcess.loadAccountBook(new ResultCallback<LoadAccountBookResponse>() {
            @Override
            public void onSuccess(LoadAccountBookResponse data) {
                mAccountBookList.clear();
                if (!ListUtil.isEmpty(data.accountBookList)) {
                    mAccountBookList.addAll(data.accountBookList);
                }
                refreshBillSwitch();
                DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
            }

            @Override
            public void onFailure(int code, String msg) {
                if (!TextUtils.isEmpty(msg)) {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    private Handler searchHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            dealSearchHint();
        }
    };

    /**
     * 根据用户输入的字符去业务中心查询符合的订单或桌台名
     */
    private void dealSearchHint() {
        String searchContent = autoTVCheck.getText().toString();

        if (searchContent.isEmpty()) {
            return;
        }

        if (!TextUtils.equals(fatherType, NET_ORDER)) {
            String searchType = "";
            if (searchContent.length() < 4) {
                searchType = "0";
            }
            final String type = searchType;
            //接口-模糊查询符合的订单或桌台名
            billDataProcess.getSearchDropList(businessDate, TextUtils.equals(fatherType, FAST_FOOD) ? 1 : 0, fsBillSourceId, mBillClass, mAccountBookId, getPayStatusByTag(), searchType, searchContent, new ResultCallback<GetOrderFromCenterRespone>() {
                @Override
                public void onSuccess(GetOrderFromCenterRespone data) {
                    if (data != null && !ListUtil.isEmpty(data.orderList2)) {
                        searchAdapter.setSearchType(type);
                        searchAdapter.setOrderListModels(data.orderList2);
                        refreshDropList();
                    }
                }
            });
        }
    }

    Method doBeforeTextChanged;
    Method doAfterTextChanged;

    /**
     * 下拉提示框数据获取到后刷新此框
     * 通过反射调用AutoCompleteTextView的doBeforeTextChanged和doAfterTextChanged方法来实现刷新下拉提示框
     */
    private void refreshDropList() {
        try {
            if (doAfterTextChanged == null) {
                Class autoCompleteTextView = Class.forName("android.widget.AutoCompleteTextView");
                doBeforeTextChanged = autoCompleteTextView.getDeclaredMethod("doBeforeTextChanged");
                doBeforeTextChanged.setAccessible(true);
                doAfterTextChanged = autoCompleteTextView.getDeclaredMethod("doAfterTextChanged");
                doAfterTextChanged.setAccessible(true);
            }
            autoTVCheck.showDropDown();
            doBeforeTextChanged.invoke(autoTVCheck);
            doAfterTextChanged.invoke(autoTVCheck);
        } catch (Exception e) {
        }
    }

    /**
     * 接收数据
     * 1 订单来源
     * 2 所有的订单信息
     */
    public void setParams(Host mHost, List<BusinessBean> billList, BillDataProcess billDataProcess) {
        this.mHost = mHost;
        if (!isNetOrderTag()) {
            for (BusinessBean bizBean : billList) {
                this.billList.add((OrderListModel) bizBean);
            }
        }
        this.billDataProcess = billDataProcess;
        initData();
    }

    public void setParams(Host mHost, BillDataProcess billDataProcess) {
        this.mHost = mHost;
        this.billDataProcess = billDataProcess;
        initData();
    }

    /**
     * 刷新界面
     */
    public void refresh(boolean netOrderTag, List<BusinessBean> list) {
        boolean refreshTime = !ListUtil.isEmpty(list);
        if (!netOrderTag) {
            if (refreshTime) {
                tvRefreshTime.setText(String.format("数据统计时间:%s", DateUtil.getCurrentDateTime("HH:mm:ss")));
            }
            autoTVCheck.setAdapter(searchAdapter);
            List<OrderListModel> modelList = new ArrayList<>();
            for (BusinessBean bizBean : list) {
                if (bizBean instanceof OrderListModel) {
                    modelList.add((OrderListModel) bizBean);
                } else {
                    LogUtil.logError("BillTabView refresh bizBean 类型不正确 " + bizBean.getClass().getName());
                }
            }
            searchAdapter.setOrderListModels(modelList);
        } else {
            if (refreshTime) {
                tvRefreshTimeNetOrder.setText(String.format("数据统计时间:%s", DateUtil.getCurrentDateTime("HH:mm:ss")));
            }
            autoTVCheck.setAdapter(searchNetOrderAdapter);
            List<TempAppOrderSimpleInfo> modelList = new ArrayList<>();
            for (BusinessBean bizBean : list) {
                if (bizBean instanceof TempAppOrderSimpleInfo) {
                    modelList.add((TempAppOrderSimpleInfo) bizBean);
                } else {
                    LogUtil.logError("BillTabView refresh bizBean 类型不正确 " + bizBean.getClass().getName());
                }
            }
            searchNetOrderAdapter.setOrderListModels(modelList);
        }
    }

    public boolean isNetOrderTag() {
        return TextUtils.equals(fatherType, NET_ORDER);
    }

    /**
     * 取数据
     */
    public void assData(ResultCallback<GetOrderFromCenterRespone> callback) {
        LogUtil.log("assData() dataTypeTag = " + dataTypeTag);
        String orderId = "";
        String tableName = "";
        if (searchType == 1) {
            orderId = searchContent;
        } else if (searchType == 2) {
            tableName = searchContent;
        } else {
            orderId = searchContent;
            tableName = searchContent;
        }
        billDataProcess.getAllData(mHost, currentPage, businessDate, TextUtils.equals(fatherType, FAST_FOOD) ? 1 : 0,
                fsBillSourceId, mBillClass, mAccountBookId, getPayStatusByTag(), orderId, tableName, callback);
    }

    public void assNetOrderData(ResultCallback<GetNetOrderSimpleInfoResponse> callback) {
        billDataProcess.optTempappordersList(mHost, currentPage, businessDate, fsBillSourceId, searchContent, callback);
    }

    private int getPayStatusByTag() {
        // 0全部，1未结账，2已结账
        int payStatus = 0;
        if (TextUtils.equals(UNPAY, dataTypeTag)) {
            payStatus = 1;
        } else if (TextUtils.equals(PAYED, dataTypeTag)) {
            payStatus = 2;
        }
        return payStatus;
    }

    /**
     * 点击全部
     */
    private void clickAllLocal() {
        //全部账单
        tvBillAll.setSelected(true);
        tvBillPay.setSelected(false);
        tvBillPayNo.setSelected(false);
        redBottom1.setVisibility(View.VISIBLE);
        redBottom2.setVisibility(View.INVISIBLE);
        redBottom3.setVisibility(View.INVISIBLE);

        dataTypeTag = ALL;
        currentPage = 1;
        searchContent = "";
        hideSortIcon();
        DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
    }

    /**
     * 点击未结账
     */
    private void clickPayNOLocal() {

        ActionLog.addLog("账单管理页面-->点击了未结账按钮", "", "", ActionLog.BILL_FRAGMENT, "");
        autoTVCheck.setText("");
        searchContent = "";
        hideSortIcon();

        tvBillAll.setSelected(false);
        tvBillPayNo.setSelected(true);
        tvBillPay.setSelected(false);
        redBottom1.setVisibility(View.INVISIBLE);
        redBottom2.setVisibility(View.VISIBLE);
        redBottom3.setVisibility(View.INVISIBLE);

        dataTypeTag = UNPAY;
        currentPage = 1;
        DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
    }


    /**
     * 点击已结账
     */
    private void clickPayLocal() {
        //全部账单
        ActionLog.addLog("账单管理页面-->点击了已结账按钮", "", "", ActionLog.BILL_FRAGMENT, "");
        autoTVCheck.setText("");
        searchContent = "";
        hideSortIcon();

        tvBillAll.setSelected(false);
        tvBillPayNo.setSelected(false);
        tvBillPay.setSelected(true);

        redBottom1.setVisibility(View.INVISIBLE);
        redBottom2.setVisibility(View.INVISIBLE);
        redBottom3.setVisibility(View.VISIBLE);

        dataTypeTag = PAYED;
        currentPage = 1;
        DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
    }


    /**
     * 点击正餐
     */
    public void clickBillDinner() {

        if (!TextUtils.equals(fatherType, DINNER)) {
            ActionLog.addLog("账单管理页面-->点击了桌台单按钮", "", "", ActionLog.BILL_FRAGMENT, "");
            fatherType = DINNER;
            autoTVCheck.setText("");
            hideSortIcon();
            searchContent = "";
            tvBillDinner.setSelected(true);
            tvBillFastFood.setSelected(false);
            tvBillNetOrder.setSelected(false);

            llBillLayout.setVisibility(View.VISIBLE);
            llDinnerTabLayout.setVisibility(VISIBLE);
            viewNetOrderLayout.setVisibility(View.GONE);

            nineSpinnerBillResouce.setVisibility(View.INVISIBLE);
            tvTitleTableName.setText(R.string.bill_tableNo);
            tvTitleBrand.setVisibility(View.GONE);
            mTvEInvoiceStatus.setVisibility(View.VISIBLE);

            clickAllLocal();
        }
    }


    /**
     * 点击快餐
     */
    public void clickBillFastFood() {

        if (!TextUtils.equals(fatherType, FAST_FOOD)) {
            ActionLog.addLog("账单管理页面-->点击快餐单按钮", "", "", ActionLog.BILL_FRAGMENT, "");
            fsBillSourceId = "-1";
            fatherType = FAST_FOOD;
            autoTVCheck.setText("");
            searchContent = "";
            hideSortIcon();
            tvBillDinner.setSelected(false);
            tvBillFastFood.setSelected(true);
            tvBillNetOrder.setSelected(false);

            llDinnerTabLayout.setVisibility(VISIBLE);
            viewNetOrderLayout.setVisibility(View.GONE);
            llBillLayout.setVisibility(View.VISIBLE);

            nineSpinnerBillResouce.setVisibility(View.VISIBLE);
            tvTitleTableName.setText(R.string.bill_source);
            tvTitleBrand.setVisibility(View.VISIBLE);

            billSourceAdapter.setData(billSourceDBModelMap);
            nineSpinnerBillResouce.setSelectedIndex(0);

            mTvEInvoiceStatus.setVisibility(View.VISIBLE);

            clickAllLocal();
        }
    }

    /**
     * 点击外卖单u
     */
    public void clickBillNetOrder() {

        ActionLog.addLog("账单管理页面-->点击外卖单按钮", "", "", ActionLog.BILL_FRAGMENT, "");
        fsBillSourceId = "-1";
        fatherType = NET_ORDER;
        autoTVCheck.setText("");
        searchContent = "";
        hideSortIcon();
        tvBillDinner.setSelected(false);
        tvBillFastFood.setSelected(false);
        tvBillNetOrder.setSelected(true);

        llDinnerTabLayout.setVisibility(View.GONE);
        viewNetOrderLayout.setVisibility(View.VISIBLE);
        llBillLayout.setVisibility(View.INVISIBLE);

        nineSpinnerBillResouce.setVisibility(View.VISIBLE);

        billSourceAdapter.setData(billSourceNetOrderMap);
        nineSpinnerBillResouce.setSelectedIndex(0);

        mTvEInvoiceStatus.setVisibility(View.GONE);

        currentPage = 1;
        /*设置桌号或者账单号搜索条件*/
        DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvBillDinner:
                clickBillDinner();
                break;
            case R.id.tvBillFastFood:
                clickBillFastFood();
                break;
            case R.id.tvBillNetOrder:
                clickBillNetOrder();
                break;
            case R.id.tvBillAll:
                clickAllLocal();
                break;
            case R.id.tvBillPayNo:
                clickPayNOLocal();
                break;
            case R.id.tvBillPay:
                clickPayLocal();
                break;
            case R.id.tvBillFilterTime:
                CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(mHost.getActivityWithinHost(), rootBillView);
                calendarPopupwindow.setDate(businessDate);
                calendarPopupwindow.show();
                calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
                    @Override
                    public void onConfirm(String newDate) {
                        businessDate = newDate;
                        tvBillFilterTime.setText(businessDate);

                        autoTVCheck.setText("");
                        searchContent = "";
                        hideSortIcon();
                        currentPage = 1;
                        DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
                    }
                });
                break;
            case R.id.btBillSearch:
                searchContent = autoTVCheck.getText().toString();
                searchType = 3;
                if (TextUtils.isEmpty(searchContent)) {
                    ToastUtil.showToast("请输入桌号或账单号进行搜索");
                    return;
                }
                ActionLog.addLog("账单管理页面-->点击了搜索按钮", "", "", ActionLog.BILL_FRAGMENT, "");

                autoTVCheck.setText("");
                currentPage = 1;
                setSortIcon(mExpAmtTv, true);
                setSortIcon(mCashTimeTv, true);
                DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
                break;
            case R.id.iv_bill_tab_change:
                // 切换AB账
                mBillClass = mBillClass == 0 ? 1 : 0;
                mAccountBookId = TextUtils.equals("1", mAccountBookId) ? "2" : "1";
                if (TextUtils.equals("2", mAccountBookId)) {
                    mSwitchBill.setImageResource(R.drawable.ic_bill_b);
                } else {
                    mSwitchBill.setImageResource(R.drawable.ic_bill_a);
                }

                // 外卖单不在 tbSell, 单独操作, 仅记录AB账切换状态
                if (TextUtils.equals(fatherType, NET_ORDER)) {
                    return;
                }

                currentPage = 1;
                searchContent = "";
                hideSortIcon();
                DriverBus.call("billFagment/loadData", PullRecyclerView.MODE_PULL_TO_START);
                break;
            case R.id.tv_head_expamt_label:
                if (TextUtils.isEmpty(searchContent)) {
                    return;
                }
                sortData(SortType.Type_ExpAmt);
                break;
            case R.id.tv_head_cashTime_label:
                if (TextUtils.isEmpty(searchContent)) {
                    return;
                }
                sortData(SortType.Type_CashTime);
                break;
            default:
                break;
        }
    }

    private void sortData(int sortType) {
        if (ListUtil.isEmpty(searchAdapter.orderListModels)) {
            return;
        }
        List<OrderListModel> tempData = new ArrayList<>();
        List<OrderListModel> cashTimeVoidData = null;
        for (int i = 0; i < searchAdapter.orderListModels.size(); i++) {
            OrderListModel orderModel = searchAdapter.orderListModels.get(i);
            if (orderModel == null) {
                continue;
            }
            if (sortType == SortType.Type_CashTime) {
                if (TextUtils.isEmpty(orderModel.payTime)) {
                    if (cashTimeVoidData == null) {
                        cashTimeVoidData = new ArrayList<>();
                    }
                    cashTimeVoidData.add(orderModel);
                } else {
                    tempData.add(orderModel);
                }
            } else {
                tempData.add(orderModel);
            }
        }

        if (sortType == SortType.Type_ExpAmt) {
            isExpAmtSortUp = !isExpAmtSortUp;
            setSortIcon(mExpAmtTv, isExpAmtSortUp);
            Collections.sort(tempData, new MyCompare(sortType, isExpAmtSortUp));
        } else {
            isCashTimeSortUp = !isCashTimeSortUp;
            setSortIcon(mCashTimeTv, isCashTimeSortUp);
            Collections.sort(tempData, new MyCompare(sortType, isCashTimeSortUp));
            if (!ListUtil.isEmpty(cashTimeVoidData)) {
                tempData.addAll(cashTimeVoidData);
            }
        }
        DriverBus.call("billFagment/refreshOrderList", tempData);
    }

    private void hideSortIcon() {
        mExpAmtTv.setCompoundDrawables(null, null, null, null);
        mCashTimeTv.setCompoundDrawables(null, null, null, null);
    }

    private void setSortIcon(TextView textView, boolean isSortUp) {
        Drawable drawable;
        if (isSortUp) {
            drawable = getResources().getDrawable(R.drawable.icon_sort_up);
        } else {
            drawable = getResources().getDrawable(R.drawable.icon_sort_down);
        }
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        textView.setCompoundDrawables(null, null, drawable, null);
    }

    public String getBusinessDate() {
        return businessDate;
    }

    class MyCompare implements Comparator<OrderListModel> {
        int sortType;
        boolean isSortUp;

        public MyCompare(int sortType, boolean isSortUp) {
            this.sortType = sortType;
            this.isSortUp = isSortUp;
        }

        @Override
        public int compare(OrderListModel data1, OrderListModel data2) {
            int result = 0;
            if (data1 != null && data2 != null) {
                if (sortType == SortType.Type_ExpAmt) {
                    result = data1.totalPrice.compareTo(data2.totalPrice);
                } else {
                    result = (int) DateUtil.compareDate(data2.payTime, data1.payTime, "yyyy-MM-dd HH:mm");
                }
                if (isSortUp) {
                    if (result > 0) {
                        result = -1;
                    } else {
                        result = 1;
                    }
                }
            }
            return result;
        }
    }

    public class SortType {
        public static final int Type_ExpAmt = 1;
        public static final int Type_CashTime = 2;
    }
}
