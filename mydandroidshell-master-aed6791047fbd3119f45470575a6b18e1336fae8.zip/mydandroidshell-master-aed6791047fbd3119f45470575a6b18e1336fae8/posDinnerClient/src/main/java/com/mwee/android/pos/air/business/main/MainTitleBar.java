//package com.mwee.android.pos.air.business.main;
//
//import android.content.Context;
//import android.content.Intent;
//import android.support.annotation.Nullable;
//import android.support.v7.widget.CardView;
//import android.util.AttributeSet;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.air.business.setting.AirSettingActivity;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseActivity;
//import com.mwee.android.pos.business.message.MessageV2Fragment;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.TextUtils;
//import com.mwee.android.pos.util.UIHelp;
//
///**
// * Created by qinwei on 2017/11/6.
// */
//
//public class MainTitleBar extends CardView implements View.OnClickListener, IDriver {
//    public final static String TAG = "mainTitleBar";
//
//    private ImageView mMainTitleLogoImg;
//    private ImageView mMainTitleTakeOutImg;
//    private ImageView mMainTitleSettingImg;
//    private ImageView mMainTitleMoreImg;
//    private TextView mTitleSubContentLabel;
//    private ImageView img_print_warning;
//    private View mNetDisconnectLaout;
//
//    @DrivenMethod(uri = TAG + "/waring", UIThread = true)
//    public void waring(boolean isPrintWaring) {
//        img_print_warning.setVisibility(isPrintWaring ? VISIBLE : GONE);
//    }
//
//    public MainTitleBar(Context context) {
//        super(context);
//        initView();
//    }
//
//    public MainTitleBar(Context context, @Nullable AttributeSet attrs) {
//        super(context, attrs);
//        initView();
//    }
//
//    public MainTitleBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
//        super(context, attrs, defStyleAttr);
//        initView();
//    }
//
//    private void initView() {
//        DriverBus.registerDriver(this);
//        LayoutInflater.from(getContext()).inflate(R.layout.widget_air_main_title_bar, this);
//        mMainTitleLogoImg = findViewById(R.id.mMainTitleLogoImg);
//        mMainTitleTakeOutImg = findViewById(R.id.mMainTitleTakeOutImg);
//        mMainTitleSettingImg = findViewById(R.id.mMainTitleSettingImg);
//        mMainTitleMoreImg = findViewById(R.id.mMainTitleMoreImg);
//        mTitleSubContentLabel = findViewById(R.id.mTitleSubContentLabel);
//        img_print_warning = findViewById(R.id.img_print_warning);
//        img_print_warning.setVisibility(AppCache.getInstance().isPrintWaring ? VISIBLE : GONE);
//        mMainTitleLogoImg.setOnClickListener(this);
//        mMainTitleTakeOutImg.setOnClickListener(this);
//        mMainTitleSettingImg.setOnClickListener(this);
//        mMainTitleMoreImg.setOnClickListener(this);
//        mNetDisconnectLaout = findViewById(R.id.mNetDisconnectLaout);
//        setRadius(0);
//    }
//
//
//    private BaseActivity mHost;
//
//    public void setParams(BaseActivity mHost) {
//        this.mHost = mHost;
//    }
//
//    @Override
//    public void onClick(View view) {
//        if (!ButtonClickTimer.canClick()) {
//            return;
//        }
//        switch (view.getId()) {
//            case R.id.mMainTitleLogoImg:
//
//                break;
//            case R.id.mMainTitleTakeOutImg:
//                UIHelp.jumpStartActivity(mHost, "消息中心", MessageV2Fragment.class);
//                break;
//            case R.id.mMainTitleSettingImg:
//                mHost.startActivity(new Intent(mHost, AirSettingActivity.class));
//                break;
//            case R.id.mMainTitleMoreImg:
//                clickTitleMore();
//                break;
//            default:
//                break;
//        }
//    }
//
//    public void setSubContentText(String text) {
//        if (TextUtils.validate(text)) {
//            mTitleSubContentLabel.setVisibility(View.VISIBLE);
//            mTitleSubContentLabel.setText(text);
//        } else {
//            mTitleSubContentLabel.setVisibility(View.GONE);
//        }
//    }
//
//    private void clickTitleMore() {
//        MorePopView morePopFragment = new MorePopView(mHost);
//        morePopFragment.showAsDropDown(mMainTitleMoreImg);
//
//    }
//
//
//    /**
//     * 控制网络显示状态
//     *
//     * @param isConnectNetWork false表示网络失败  true表示网络正常
//     */
//    public void setNetDisconnectLaout(boolean isConnectNetWork) {
//        mNetDisconnectLaout.setVisibility(isConnectNetWork ? GONE : VISIBLE);
//    }
//
//
//    @Override
//    public String getModuleName() {
//        return TAG;
//    }
//    public void callDestroy(){
//        DriverBus.unRegisterDriver(this);
//    }
//}
