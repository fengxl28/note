package com.mwee.android.pos.air.business.table.api;

import com.mwee.android.air.connect.business.table.GetAirTableChangeResponse;
import com.mwee.android.air.acon.CTableManager;
import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;

import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class TableManagerApi {

    public static void optAllAreaAndTable(final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).optAllAreaAndTable();
    }

    /**
     * 新增区域
     *
     * @param areaName
     * @param iResult
     */
    public static void addArea(String areaName, boolean batchAddTable, int tableCount, int person, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addArea(areaName, batchAddTable, tableCount, person);
    }

    /**
     * 修改区域名称
     *
     * @param areaId   区域ID
     * @param areaName 区域名称
     * @param iResult
     */
    public static void updateAreaName(String areaId, String areaName, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updateAreaName(areaId, areaName);
    }

    /**
     * 删除区域
     *
     * @param areaId  区域ID
     * @param iResult
     */
    public static void deleteArea(String areaId, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).deleteArea(areaId);
    }

    /**
     * 新增
     *
     * @param areaId    区域ID
     * @param tableName 桌台名称
     * @param seats     桌位数
     * @param iResult
     */
    public static void addTable(String areaId, String tableName, int seats, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addTable(areaId, tableName, seats);
    }

    /**
     * 修改
     *
     * @param areaId     区域ID
     * @param fsmtableId 桌台ID
     * @param tableName  桌台名称
     * @param seats      桌位数
     * @param iResult
     */
    public static void updateTable(String areaId, String fsmtableId, String tableName, int seats, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updateTable(areaId, fsmtableId, tableName, seats);
    }

    /**
     * 批量删除桌台
     *
     * @param tableIdList
     * @param iResult
     */
    public static void batchDeleteTable(ArrayList<String> tableIdList, final IResponse<GetAllAreaAndTableResponse> iResult) {

        MCon.c(CTableManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).batchDeleteTable(tableIdList);
    }


    /**
     * 获取小散换桌的数据
     */
    public static void loadTableChangeInfo(final IResponse<GetAirTableChangeResponse> iResult){
        MCon.c(CTableManager.class, new SocketCallback<GetAirTableChangeResponse>() {
            @Override
            public void callback(SocketResponse<GetAirTableChangeResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadTableChangeInfo();
    }

}
