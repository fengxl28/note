package com.mwee.android.pos.air.business.fastfood;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.UnScollerListView;
import com.mwee.android.tools.DisplayUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 快餐点菜列表适配器
 */
public class FastFoodOrderAdapter extends BaseAdapter {
    private static final int TYPE_NORMAL = 0;
    private static final int TYPE_GUA = 1;
    private static final int TYPE_MENU_ADD = 2;
    public boolean isShowGua;
    public boolean isShowMenuAdd;
    public static final String DRIVER_TAG = "orderDishesAdapter";
    private Context mContext;
    private FastFoodDishCache dishCache;
    private Host mHost;
    private OnFastFoodOrderItemClickListener listener;
    public int selectPosition = -1;
    public ArrayList<MenuItem> modules = new ArrayList<>();
    private int dp10;
    private int dp5;

    public FastFoodOrderAdapter(Host host) {
        super();
        this.mContext = host.getContextWithinHost();
        this.mHost = host;
        dp10 = DisplayUtil.dp2px(mContext, 10);
        dp5 = DisplayUtil.dp2px(mContext, 5);
    }

    public void setDishCache(FastFoodDishCache dishCache) {
        this.dishCache = dishCache;
        modules = dishCache.menuItems;
    }

    @Override
    public int getCount() {
        int count = modules == null ? 0 : modules.size();
        count += isShowGua ? 1 : 0;
        count += isShowMenuAdd ? 1 : 0;
        return count;
    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return 3;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == getCount() - 1) {
            if (isShowGua) {
                return TYPE_GUA;
            } else if (isShowMenuAdd) {
                return TYPE_MENU_ADD;
            }
        }
        return TYPE_NORMAL;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder = null;
        if (convertView == null) {
            switch (getItemViewType(position)) {
                case TYPE_NORMAL:
                    holder = new ViewHolder();
                    convertView = LayoutInflater.from(mContext).inflate(R.layout.view_air_order_dishes_item, parent, false);
                    break;
                case TYPE_GUA:
                    convertView = LayoutInflater.from(mContext).inflate(R.layout.view_air_fast_food_order_gua, parent, false);
                    holder = new GuaHolder();
                    break;
                case TYPE_MENU_ADD:
                    convertView = LayoutInflater.from(mContext).inflate(R.layout.view_air_fast_food_order_menu_add, parent, false);
                    holder = new MenuAddHolder();
                    break;
                default:
                    break;
            }
            holder.initView(convertView);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.initData(position);
        return convertView;
    }

    public MenuItem getSelectMenuItem() {
        if (selectPosition < 0 || modules.size() <= 0) {
            return null;
        }
        return modules.get(selectPosition);
    }

    interface Holder {
        void initView(View view);

        void initData(int position);
    }

    class GuaHolder implements Holder, View.OnClickListener {

        @Override
        public void onClick(View view) {
            if (SettingHelper.isShouldSetMealNumber() && TextUtils.isEmpty(dishCache.fastOrderModel.mealNumber)) {
                //需要牌号并且牌号不为空
                CountKeyboardFragment fragment = new CountKeyboardFragment();
                fragment.setTitle("设置牌号");
                fragment.setErrorTips("请输入牌号");
                fragment.setOriginCount(BigDecimal.ZERO);
                fragment.setCanBe0(true);
                fragment.setCallback(new CountKeyboardCallback() {
                    @Override
                    public void callback(BigDecimal originNum, BigDecimal newNum) {
                        listener.doOrderCommit(newNum.toPlainString());
                    }
                });
                fragment.setMaxCount(999);
                DialogManager.showCustomDialog(mHost, fragment, CountKeyboardFragment.FRAGMENT_TAG);
            } else {
                listener.doOrderCommit(dishCache.fastOrderModel.mealNumber);
            }
        }

        @Override
        public void initView(View view) {
            view.findViewById(R.id.mFastFoodOrderGuaBtn).setOnClickListener(this);
        }

        @Override
        public void initData(int position) {

        }
    }

    class MenuAddHolder implements Holder, View.OnClickListener {

        @Override
        public void onClick(View view) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (view.getId()) {
                case R.id.mMenuAddCancelBtn:
                    listener.doMenuAddCancel();
                    break;
                case R.id.mMenuAddCommitBtn:
                    listener.doMenuAddCommit();
                    break;
                default:
                    break;
            }
        }

        @Override
        public void initView(View view) {
            view.findViewById(R.id.mMenuAddCancelBtn).setOnClickListener(this);
            view.findViewById(R.id.mMenuAddCommitBtn).setOnClickListener(this);
        }

        @Override
        public void initData(int position) {

        }
    }

    class ViewHolder implements Holder, View.OnClickListener {
        private View itemView;
        private View ingredient_line;
        private MenuItem menuItem;
        private LinearLayout mFastOrderItemInfoLayout;//点菜基本信息layout
        private TextView mFastOrderItemNameLabel;//菜品名称
        private TextView mFastOrderItemNoteContentLabel;//备注
        private TextView mFastOrderItemNumLabel;//点菜份数
        private TextView mFastOrderItemPriceLabel;//菜品金额

        private TextView mFastOrderItemTagDiscountLabel;//折扣icon
        private ImageView mFastOrderItemTagGiftImg;//赠送icon
        private ImageView mFastOrderItemTagMemberImg;//会员价icon

        private TextView mFastOrderItemDeleteOrReturnLabel;//删除icon
        private UnScollerListView mFastOrderItemIngredientLsv;//配料菜列表
        private CompatibleListView mFastOrderItemPackageLsv;//套餐明细列表
        private TextView mFastOrderItemNumHintLabel;

        @Override
        public void initView(View v) {
            itemView = v;
            mFastOrderItemInfoLayout = (LinearLayout) v.findViewById(R.id.mFastOrderItemInfoLayout);
            mFastOrderItemNameLabel = (TextView) v.findViewById(R.id.mFastOrderItemNameLabel);
            mFastOrderItemNoteContentLabel = (TextView) v.findViewById(R.id.mFastOrderItemNoteContentLabel);
            mFastOrderItemNumLabel = (TextView) v.findViewById(R.id.mFastOrderItemNumLabel);
            mFastOrderItemNumHintLabel = (TextView) v.findViewById(R.id.mFastOrderItemNumHintLabel);
            mFastOrderItemPriceLabel = (TextView) v.findViewById(R.id.mFastOrderItemPriceLabel);

            mFastOrderItemTagDiscountLabel = (TextView) v.findViewById(R.id.mFastOrderItemTagDiscountLabel);
            mFastOrderItemTagGiftImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagGiftImg);
            mFastOrderItemTagMemberImg = (ImageView) v.findViewById(R.id.mFastOrderItemTagMemberImg);

            mFastOrderItemDeleteOrReturnLabel = (TextView) v.findViewById(R.id.mFastOrderItemDeleteOrReturnLabel);
            mFastOrderItemIngredientLsv = (UnScollerListView) v.findViewById(R.id.mFastOrderItemIngredientLsv);
            mFastOrderItemPackageLsv = (CompatibleListView) v.findViewById(R.id.mFastOrderItemPackageLsv);
            ingredient_line = v.findViewById(R.id.ingredient_line);
            mFastOrderItemDeleteOrReturnLabel.setOnClickListener(this);
            itemView.setOnClickListener(this);
            mFastOrderItemNameLabel.setOnClickListener(this);
        }

        @Override
        public void initData(int position) {
            menuItem = modules.get(position);
            removeAllLine();
            mFastOrderItemNameLabel.setText(menuItem.name);
            mFastOrderItemNameLabel.setBackgroundResource(0);
            mFastOrderItemNameLabel.setPadding(0, 0, 0, 0);
            //设置备注显示
            String note = getMenuItemNoteContent().trim();
            if (TextUtils.isEmpty(note)) {
                mFastOrderItemNoteContentLabel.setVisibility(View.GONE);
            } else {
                mFastOrderItemNoteContentLabel.setVisibility(View.VISIBLE);
                mFastOrderItemNoteContentLabel.setText(note);
            }
            if (menuItem.supportWeight()) {
                mFastOrderItemNumLabel.setText(NumberUtils.subZeroAndDot(menuItem.menuBiz.buyNum) + "/" + menuItem.currentUnit.fsOrderUint);
            } else {
                mFastOrderItemNumLabel.setText(Calc.formatShow(menuItem.menuBiz.buyNum, 0) + "/" + menuItem.currentUnit.fsOrderUint);
            }

            //时价菜 价格加样式
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0 && !menuItem.hasAllVoid()) {
                mFastOrderItemPriceLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                mFastOrderItemPriceLabel.setText("时价");
                mFastOrderItemPriceLabel.setOnClickListener(this);
            } else {
                mFastOrderItemPriceLabel.setBackgroundResource(0);
                mFastOrderItemPriceLabel.setText(Calc.formatShow(menuItem.menuBiz.totalPrice, RoundConfig.ROUND_SINGLE_PRICE));
                mFastOrderItemPriceLabel.setOnClickListener(null);
            }

            mFastOrderItemTagGiftImg.setVisibility(View.GONE);
            mFastOrderItemTagMemberImg.setVisibility(View.GONE);
            mFastOrderItemTagDiscountLabel.setVisibility(View.GONE);
            //优惠信息tag
            if (menuItem.menuBiz.menuSellType == MenuSellType.GIFT || (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0 && menuItem.menuBiz.giftNum.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum)) == 0)) {
                mFastOrderItemTagGiftImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.useMemberPrice) {
                mFastOrderItemTagMemberImg.setVisibility(View.VISIBLE);
            }
            if (menuItem.menuBiz.selectDiscount != null) {
                mFastOrderItemTagDiscountLabel.setVisibility(View.VISIBLE);
                BigDecimal rate = Calc.format(new BigDecimal((100 - menuItem.menuBiz.selectDiscount.fiDiscountRate) / 10f), 1, RoundingMode.HALF_UP);
                BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
                if (rate.compareTo(rate0) == 0) {
                    mFastOrderItemTagDiscountLabel.setText(rate0.toPlainString() + "折");
                } else {
                    mFastOrderItemTagDiscountLabel.setText(rate.toPlainString() + "折");
                }
            }
            //配料菜列表展示
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                ingredient_line.setVisibility(View.VISIBLE);
                mFastOrderItemIngredientLsv.setVisibility(View.VISIBLE);
                CommonAdapter<MenuItem> ingredientAdapter = (CommonAdapter<MenuItem>) mFastOrderItemIngredientLsv.getAdapter();
                if (ingredientAdapter == null) {
                    ingredientAdapter = new CommonAdapter<MenuItem>(mContext, menuItem.menuBiz.selectedModifier, R.layout.message_order_menu_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem item, int position) {
                            TextView name = (TextView) viewHolder.getView(R.id.msg_order_item_name);
                            name.setTextColor(context.getResources().getColor(R.color.line_gray));
                            name.setText(item.name);

                            TextView count = (TextView) viewHolder.getView(R.id.msg_order_item_note);
                            count.setTextColor(context.getResources().getColor(R.color.line_gray));

                            TextView price = (TextView) viewHolder.getView(R.id.msg_order_item_num);
                            price.setTextColor(context.getResources().getColor(R.color.line_gray));

                            String voidInfo = "";

                            BigDecimal tempVoidNum = menuItem.menuBiz.voidNum;
                            BigDecimal tempBuyNum = menuItem.menuBiz.buyNum;
                            if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                                tempBuyNum = BigDecimal.ONE;
                                if (tempVoidNum.compareTo(BigDecimal.ZERO) > 0) {
                                    tempVoidNum = BigDecimal.ONE;
                                }
                            }

                            BigDecimal voidNum = item.menuBiz.buyNum.multiply(tempVoidNum);
                            voidNum = voidNum.add(item.menuBiz.voidNum.multiply(tempBuyNum.subtract(tempVoidNum)));
                            if (voidNum.compareTo(BigDecimal.ZERO) > 0) {
                                voidInfo = "[退" + voidNum + "]";
                            }
                            BigDecimal buyAllNum = item.menuBiz.buyNum.multiply(tempBuyNum);
                            if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString() + voidInfo);
                            } else {
                                count.setText("x" + buyAllNum.stripTrailingZeros().toPlainString());
                            }
                            price.setText(Calc.formatShow(item.menuBiz.totalPrice.multiply(tempBuyNum.subtract(tempVoidNum)), RoundConfig.ROUND_SINGLE_PRICE));
                        }
                    };
                    mFastOrderItemIngredientLsv.setAdapter(ingredientAdapter);
                } else {
                    ingredientAdapter.setDataList(menuItem.menuBiz.selectedModifier);
                }
            } else {
                ingredient_line.setVisibility(View.GONE);
                mFastOrderItemIngredientLsv.setVisibility(View.GONE);
            }
            //套餐明细显示
            if (menuItem.supportPackage()) {
                mFastOrderItemPackageLsv.setVisibility(View.VISIBLE);
                List<MenuItem> allSelectedMenuExtraItems = menuItem.menuBiz.selectedPackageItems;
                CommonAdapter<MenuItem> packageAdapter = (CommonAdapter<MenuItem>) mFastOrderItemPackageLsv.getAdapter();
                if (packageAdapter == null) {
                    packageAdapter = new CommonAdapter<MenuItem>(mContext, allSelectedMenuExtraItems, R.layout.view_orderdishes_order_package_item) {
                        @Override
                        public void convert(com.mwee.android.pos.component.adapter.ViewHolder viewHolder, MenuItem data, int position) {
                            viewHolder.setText(R.id.nameTv, TextUtils.concat("- -", data.name + getMenuItemNoteContent(data)));
                            viewHolder.setText(R.id.numTv, TextUtils.concat(data.menuBiz.buyNum.toPlainString(), "份"));
                        }

                        public String getMenuItemNoteContent(MenuItem menuItem) {
                            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
                           /* if (menuItem.currentPractice != null) {
                                demand.append(" ").append(menuItem.currentPractice.fsAskName);
                            }*/
                            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
                            if (TextUtils.isEmpty(demand.toString().trim())) {
                                return "";
                            } else {
                                return "(" + demand.toString() + ")";
                            }
                        }
                    };
                    mFastOrderItemPackageLsv.setAdapter(packageAdapter);
                } else {
                    packageAdapter.setDataList(allSelectedMenuExtraItems);
                }
            } else {
                mFastOrderItemPackageLsv.setVisibility(View.GONE);
            }

            //根据下单状态控制ui显示
            if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                //称重菜未称重 数量加样式
                if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                    mFastOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mFastOrderItemNumLabel.setOnClickListener(this);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                } else {
                    mFastOrderItemNumLabel.setOnClickListener(null);
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumLabel.setBackgroundResource(0);
                }
                //退菜数据展示
                if (menuItem.hasAllVoid()) {
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.INVISIBLE);
                    addAllLine();
                } else {
                    mFastOrderItemDeleteOrReturnLabel.setText("退");
                    mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                }
                if (menuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
                    mFastOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumHintLabel.setText("退" + NumberUtils.subZeroAndDot(menuItem.menuBiz.voidNum) + menuItem.currentUnit.fsOrderUint);
                } else {
                    mFastOrderItemNumHintLabel.setVisibility(View.GONE);
                }

                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_EAEAEA));
            } else {
                //显示删除按钮
                mFastOrderItemDeleteOrReturnLabel.setVisibility(View.VISIBLE);
                mFastOrderItemDeleteOrReturnLabel.setText("删");
                //新菜
                mFastOrderItemNumLabel.setOnClickListener(this);
                mFastOrderItemNumLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                //沽清数量显示
                BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(menuItem.currentUnit.fiOrderUintCd);
                if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                    mFastOrderItemNumHintLabel.setVisibility(View.VISIBLE);
                    mFastOrderItemNumHintLabel.setText(String.format(Locale.SIMPLIFIED_CHINESE, "剩%s", sellOutCount+menuItem.currentUnit.fsOrderUint));
                } else {
                    mFastOrderItemNumHintLabel.setVisibility(View.GONE);
                }
                //时价菜可以修改菜品名称
                if (menuItem.supportTimes()) {
                    mFastOrderItemNameLabel.setBackgroundResource(R.drawable.bg_cubic_gray_selector);
                    mFastOrderItemNameLabel.setPadding(dp10, dp5, dp10, dp5);
                }
                //控制背景
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_f9f9f9));
            }

            //选中状态处理
            if (selectPosition == position && !menuItem.hasAllVoid()) {
                itemView.setBackgroundColor(ViewToolsUtil.getColor(mContext, R.color.color_FFD2CB));
            }
        }


        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.mFastOrderItemDeleteOrReturnLabel:
                    if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        if (!ButtonClickTimer.canClick()) {
                            return;
                        }
                        PermissionsUtil.requestPermissionBackMenu(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vBackAuth, menuItem, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    trace("菜品退菜-> orderId:" + dishCache.fastOrderModel.orderId + " name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_RETREAT);
                                    listener.doRetreatDish(menuItem, userDBModel, msg);
                                }
                            }
                        });
                    } else {
                        trace("菜品删除->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_REMOVE);
                        listener.doDeleteMenu(menuItem);
                    }
                    break;
                case R.id.mFastOrderItemNumLabel:
                    if (!ButtonClickTimer.canClick()) {
                        return;
                    }
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vQtyAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    trace("菜品改价格->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_NUMBER);
                                    listener.doChangeOrderedMenuNumber(menuItem, userDBModel);
                                } else {
                                    trace("未下单菜品修改数量->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_NUMBER);
                                    listener.doChangeMenuBuyNum(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemPriceLabel:
                    if (!ButtonClickTimer.canClick()) {
                        return;
                    }
                    PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            if (errCode == 0) {
                                trace("菜品改价格->name:" + menuItem.name + " uniq:" + menuItem.menuBiz.uniq, ActionLog.DF_MENU_PRICE);
                                if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    listener.doChangeOrderedMenuPrice(menuItem, userDBModel);
                                } else {
                                    listener.doChangeMenuPrice(menuItem, userDBModel);
                                }
                            }
                        }
                    });
                    break;
                case R.id.mFastOrderItemNameLabel:
                    if (!ButtonClickTimer.canClick()) {
                        return;
                    }
                    if (menuItem.supportTimes() && !dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        PermissionsUtil.requestPermissionCommon(mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vPriceAuth, new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                                if (errCode == 0) {
                                    trace("点菜页->点击菜品改名称" + menuItem.toString(), ActionLog.DF_MENU_NAME);
                                    listener.doChangeMenuName(menuItem, userDBModel);
                                }
                            }
                        });
                        break;
                    }
                default:
                    selectPosition = modules.indexOf(menuItem);
                    notifyDataSetChanged();
                    break;
            }
        }


        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(menuItem.menuBiz.note);
           /* if (menuItem.currentPractice != null) {
                demand.append(" ").append(menuItem.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(menuItem.menuBiz.selectedExtraStr);
            return demand.toString();
        }


        /**
         * 加中划线
         */
        private void addAllLine() {
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.addLine(mFastOrderItemPriceLabel);
        }

        /**
         * 移除中划线
         */
        private void removeAllLine() {
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNameLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNoteContentLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemNumLabel);
            com.mwee.android.pos.util.TextUtils.removeLine(mFastOrderItemPriceLabel);
        }


    }

    /**
     * 菜品列表操作回调接口
     */
    public interface OnFastFoodOrderItemClickListener {

        /**
         * 未下单菜品->修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品—>修改点菜数量
         *
         * @param item
         * @param userDBModel
         */
        void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel);

        /**
         * 删除菜品
         *
         * @param item
         */
        void doDeleteMenu(MenuItem item);

        /**
         * 已下单菜品—>退菜
         *
         * @param item
         * @param userDBModel
         * @param msg
         */
        void doRetreatDish(MenuItem item, UserDBModel userDBModel, String msg);


        /**
         * 未下单菜品->价格
         *
         * @param item
         * @param userDBModel
         */
        void doChangeMenuPrice(MenuItem item, UserDBModel userDBModel);

        /**
         * 已下单菜品->改价格
         *
         * @param menuItem
         * @param userDBModel
         */
        void doChangeOrderedMenuPrice(MenuItem menuItem, UserDBModel userDBModel);

        /**
         * 挂单
         *
         * @param mealNumber 牌号
         */
        void doOrderCommit(String mealNumber);

        /**
         * 取消加菜
         */
        void doMenuAddCancel();

        /**
         * 完成加菜
         */
        void doMenuAddCommit();

        /**
         * 显示空view
         */
        void doShowEmptyView();

        /**
         * 显示点菜信息
         */
        void doShowOrderContent();

        /**
         * 时价修改价格
         *
         * @param menuItem
         * @param userDBModel
         */
        void doChangeMenuName(MenuItem menuItem, UserDBModel userDBModel);
    }

    public void setOnFastFoodOrderItemClickListener(OnFastFoodOrderItemClickListener listener) {
        this.listener = listener;
    }


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        if (modules.size() == 0) {
            listener.doShowEmptyView();
        } else {
            listener.doShowOrderContent();
        }
    }

    private void trace(String msg, String action) {
        ActionLog.addLog("点菜页->" + msg, dishCache.fastOrderModel.orderId, dishCache.fastOrderModel.mealNumber, action, "");
    }

}
