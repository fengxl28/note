package com.mwee.android.pos.business.fastfood.proccessor;

import android.text.TextUtils;
import android.util.SparseArray;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseBizProcessor;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.order.view.discount.CouponProcessor;
import com.mwee.android.pos.business.order.view.discount.MultiCouponFragment;
import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.common.fastfood.IFastFoodMenuItemProcessor;
import com.mwee.android.pos.business.fastfood.api.FastMenuItemSocketApi;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.order.view.discount.FastMultiDiscountCallBack;
import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
import com.mwee.android.pos.business.orderdishes.util.IngredientUtil;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.business.orderdishes.view.fragment.OrderDishesBatchAddRequestFragment;
import com.mwee.android.pos.business.orderdishes.view.jump.NoteJump;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.ChooseNumJump;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.IChooseNumListner;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.text.CallChangeText;
import com.mwee.android.pos.component.text.IChangeText;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.FastFoodOperationConstant;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderynamicDMode;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/7/6.
 */

public class FastFoodMenuItemProcessor extends BaseBizProcessor implements IFastFoodMenuItemProcessor {
    protected Host mHost;
    private ArrayList<NoteItemModel> customRequests = new ArrayList<>();//自定义菜品要求

    public FastFoodMenuItemProcessor(Host host) {
        this.mHost = host;
    }

    /**
     * 添加
     *
     * @param orderId  订单id
     * @param menuItem
     * @param callback
     */
    @Override
    public void doAddMenuItem(String orderId, MenuItem menuItem, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(menuItem);
        FastMenuItemSocketApi.loadChangeFastFoodMenuItems(orderId, menuItems, menuItem.menuBiz.uniq, FastFoodOperationConstant.ADD, callback);
    }

    /**
     * 更新单个菜品
     *
     * @param orderId  订单id
     * @param menuItem
     * @param callback
     */
    @Override
    public void doUpdateMenuItem(String orderId, MenuItem menuItem, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(menuItem);
        doUpdateMenuItem(orderId, menuItems, callback);
    }

    /**
     * 批量更新菜品
     *
     * @param orderId   订单id
     * @param menuItems
     * @param callback
     */
    @Override
    public void doUpdateMenuItem(String orderId, ArrayList<MenuItem> menuItems, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        FastMenuItemSocketApi.loadChangeFastFoodMenuItems(orderId, menuItems, null, FastFoodOperationConstant.CHANGE, callback);
    }

    /**
     * 删除
     *
     * @param orderId  订单id
     * @param uniq
     * @param callback
     */
    @Override
    public void doDeleteMenuItem(String orderId, String uniq, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        FastMenuItemSocketApi.loadChangeFastFoodMenuItems(orderId, null, uniq, FastFoodOperationConstant.DELETE, callback);
    }

    /**
     * 通知业务中删除未下单到菜品
     *
     * @param orderId  订单id
     * @param callback
     */
    @Override
    public void doClearOrderMenuItems(String orderId, ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        FastMenuItemSocketApi.loadChangeFastFoodMenuItems(orderId, null, null, FastFoodOperationConstant.CLEAN_TABLE, callback);
    }

    /**
     * 菜品改数量处理
     *
     * @param menuItem
     * @param orderId
     * @param callback
     */
    @Override
    public void doUpdateMenuItemBuyNumber(final MenuItem menuItem, final String orderId, final ResultCallback<UpdateBuyNumResponse> callback) {
        ModifyQuantityUtils.showModifyQuantitySupportWeight(mHost, menuItem, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, final BigDecimal newNum) {
                if (originNum.compareTo(newNum) == 0) {
                    return;
                }
                final BigDecimal format = Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundingMode.HALF_UP);
                final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                FastMenuItemSocketApi.loadUpdateMenuItemBuyNumber(orderId, menuItem.menuBiz.uniq, format, new ConCallBack<UpdateBuyNumResponse>() {
                    @Override
                    public void subCall(SocketResponse<UpdateBuyNumResponse> response) {
                        if ((response.code == SocketResultCode.SUCCESS && response.data.needRefreshSellOutNum) || response.code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                            OrderDishesBizUtil.updateSellOutUnit(response.data.unitSellOutNew);
                        }
                    }

                    @Override
                    public void callback(SocketResponse<UpdateBuyNumResponse> response) {
                        progress.dismiss();
                        if (response.code == SocketResultCode.SUCCESS) {
                            //修改数量成功后同步菜品数量
                            menuItem.updateBuyNum(format);
                            callback.onSuccess(response.data);
                        } else {
                            callback.onFailure(response.code, response.message);
                        }
                    }
                });
            }
        });
    }

    /**
     * 改时价菜
     *
     * @param orderId  订单id
     * @param menuItem 菜品
     * @param callback 回调
     */
    @Override
    public void doUpdateDishPrice(final String orderId, final MenuItem menuItem, final boolean isUpdateBizCenter, final ResultCallback<OperateDishToCenterResponse> callback) {
        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle("设置价格(元)");
        fragment.setErrorTips("请输入数值");
        fragment.setOriginCount(menuItem.menuBiz.totalPrice);
        fragment.setCanBe0(true);
        fragment.setCallback(new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, final BigDecimal newNum) {
                if (newNum.compareTo(BigDecimal.ZERO) <= 0) {
                    return;
                }
                //已下单改价格需要同步到业务中心
                if (isUpdateBizCenter) {
                    final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                    FastMenuItemSocketApi.loadUpdateDishPrice(orderId, menuItem.menuBiz.uniq, newNum, new ResultCallback<OperateDishToCenterResponse>() {
                        @Override
                        public void onSuccess(OperateDishToCenterResponse data) {
                            progress.dismiss();
                            menuItem.changeTimesPrice(newNum);
                            callback.onSuccess(data);
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            progress.dismiss();
                            callback.onFailure(code, msg);
                        }
                    });
                } else {
                    menuItem.changeTimesPrice(newNum);
                    callback.onSuccess(null);
                }
            }
        });
        fragment.setMaxCount(Integer.MAX_VALUE);
        fragment.setIsSupportFloat(true);
        DialogManager.showCustomDialog(mHost, fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }

    /**
     * 退菜业务逻辑
     *
     * @param orderId  订单id
     * @param item     退菜菜品
     * @param reason   退菜理由
     * @param callback
     */
    @Override
    public void doRetreatDish(final String orderId, final MenuItem item, final String reason, final ResultCallback<BactchReturnDishesForFastFoodResponse> callback) {
        BigDecimal maxValue = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
        BigDecimal originValue = new BigDecimal(maxValue.doubleValue());
        ChooseNumJump.showChooseNum(mHost, GlobalCache.getContext().getString(R.string.menu_item_retreat_dish_title), originValue, maxValue, BigDecimal.ONE, (item.config & 32) != 32, true, item.currentUnit.fsOrderUint, new IChooseNumListner() {
            @Override
            public void callback(boolean confirm, final BigDecimal confirmCount) {
                if (!confirm) {
                    return;
                }
                final VoidMenuItemModel voidMenuItem = new VoidMenuItemModel();
                voidMenuItem.fsseq = item.menuBiz.uniq;
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                    item.menuBiz.buyNum = BigDecimal.ONE;
                }
                if (item.supportWeight()) {
                    voidMenuItem.fdbackqty = item.menuBiz.buyNum;
                } else {
                    voidMenuItem.fdbackqty = confirmCount;
                }
                voidMenuItem.fiItemCd = item.itemID;
                voidMenuItem.fiOrderUintCd = item.currentUnit.fiOrderUintCd;
                voidMenuItem.fsbackreason = reason;
                voidMenuItem.fsbackuserid = AppCache.getInstance().userDBModel.fsUserId;
                voidMenuItem.fsbackusername = AppCache.getInstance().userDBModel.fsUserName;
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "开始退菜 [" + item.name + "],退菜数量=" + confirmCount.toString());
                final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
                FastMenuItemSocketApi.loadReturnDish(orderId, voidMenuItem, new ResultCallback<BactchReturnDishesForFastFoodResponse>() {
                    @Override
                    public void onSuccess(BactchReturnDishesForFastFoodResponse data) {
                        progress.dismiss();
                        callback.onSuccess(data);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        progress.dismiss();
                        callback.onFailure(code, msg);
                    }
                });
            }
        });
    }

    /**
     * 单个菜品优惠处理
     *
     * @param item
     * @param listener
     */
    @Override
    public void doChangeMenuPrivilege(MenuItem tempItem, final FastFoodDishCache dishCache, final SingleCouponFragment.OnSingleDiscountListener listener) {
        List<MenuItem> tempMenuItemList = new ArrayList<>();
        MenuItem item = tempItem.clone();
        tempMenuItemList.add(item);
        final List<MenuItem> menuItemList = ListUtil.cloneList(tempMenuItemList);
        final CouponProcessor processor = new CouponProcessor(dishCache, mHost);
        processor.initData(menuItemList, dishCache.fastOrderModel.fsDiscountCutId, dishCache.fastOrderModel.fdDiscountCutAmt,
                dishCache.fastOrderModel.orderCutReason, dishCache.fastOrderModel.orderCutOperUserId, dishCache.fastOrderModel.orderCutAuthUserId);
        final Progress progress = ProgressManager.showProgressUncancel(mHost, "获取折扣信息..");
        processor.loadAllDiscounts(dishCache.fastOrderModel.orderId, menuItemList, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();

                if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) { // 有配料，跳到批量折扣页
                    String orderID = dishCache.fastOrderModel.orderId;
                    MultiCouponFragment fragment = new MultiCouponFragment();
                    fragment.setParam(processor, new FastMultiDiscountCallBack() {
                        @Override
                        public void call(FastOrderynamicDMode fastOrder, List<MenuItem> menuItemList) {
                            if (listener != null) {
                                listener.callback(null, fastOrder, menuItemList);
                            }
                        }
                    });
                    ActionLog.addLog("获取有配料的菜品折扣信息，打开批量折扣界面(快餐)", orderID, dishCache.fastOrderModel.mealNumber, ActionLog.DF_BATCH_DISCOUNT, "");
                    fragment.show(mHost.getFragmentManagerWithinHost(), "FastMultiDiscountFragment");
                } else {
                    SingleCouponFragment fragment = new SingleCouponFragment();
                    fragment.setParam(dishCache, item);
                    fragment.setOnSingleDiscountListener(listener);
                    fragment.setCouponProcessor(processor);
                    DialogManager.showCustomDialog(mHost, fragment, "SingleDiscountFragment");
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 单个菜品要求处理
     *
     * @param item
     * @param noteCallback
     */
    @Override
    public void doEditorMenuNoteContent(MenuItem item, NoteCallback noteCallback) {
        List<NoteModel> noteList = DinnerMenuUtil.getRequestByMenuItem(item);
        NoteJump.showNote(mHost, noteList, customRequests, item.clone().menuBiz.selectNote, noteCallback);
    }

    /**
     * 批量要求
     *
     * @param callback
     */
    @Override
    public void doBatchRequest(List<MenuItem> reqMenuItems, final FastFoodDishCache mDishCache, final ResultCallback<String> callback) {
        OrderDishesJump.showOrderDishesBatchAddRequest(mHost, reqMenuItems, customRequests, new OrderDishesBatchAddRequestFragment.Callback() {
            @Override
            public void onConfirm(List<MenuItem> menuItemList) {
                MenuItem oldItem = null;
                ArrayList<MenuItem> notOrderMenuItems = mDishCache.getFastFoodNotOrderMenuItems();
                for (int i = 0; i < notOrderMenuItems.size(); i++) {
                    oldItem = notOrderMenuItems.get(i);
                    for (MenuItem item : menuItemList) {
                        if (TextUtils.equals(oldItem.menuBiz.uniq, item.menuBiz.uniq)) {
                            oldItem.menuBiz.selectNote = ListUtil.cloneList(item.menuBiz.selectNote);
                            oldItem.menuBiz.note = item.menuBiz.note.trim();
                            oldItem.calcTotal(mDishCache.isBindMember());
                            break;
                        }
                    }
                }
                callback.onSuccess("");
            }
        }, mDishCache.isBindMember());
    }

    /**
     * 菜品编辑数据处理
     *
     * @param oldUnit
     * @param item
     */
    @Override
    public boolean doEditMenuInfo(UnitModel oldUnit, MenuItem item, FastFoodDishCache mDishCache) {
        if (!((oldUnit.fiInitCount <= 0 && item.currentUnit.fiInitCount <= 0) ||
                ((oldUnit.fiInitCount > 0 && item.currentUnit.fiInitCount > 0) &&
                        (TextUtils.equals(oldUnit.fiOrderUintCd, item.currentUnit.fiOrderUintCd))))) {
            if (item.currentUnit.fiInitCount > 0) {
                item.menuBiz.buyNum = Calc.format(new BigDecimal(item.currentUnit.fiInitCount), RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type);
            } else {
                item.menuBiz.buyNum = Calc.format(BigDecimal.ONE, RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type);
            }
            if (item.menuBiz.menuSellType == MenuSellType.GIFT) {//如果当前菜品为赠送菜  赠送菜数量要和购买数量保持一致
                item.menuBiz.giftNum = item.menuBiz.buyNum;
            }
            mDishCache.initSelectUnitQuantity();
        }
        item.calcTotal(mDishCache.isBindMember());
        return true;
    }


    /**
     * 加退配料菜
     *
     * @param orderId  订单id
     * @param oldItem  修改之前菜品
     * @param newItem  修改之后菜品
     * @param callback call from main Thread
     */
    @Override
    public void doChangeIngredient(String orderId, MenuItem oldItem, MenuItem newItem, final ResultCallback<ChangeIngredientResponse> callback) {
        SparseArray<List<MenuItem>> changedList = IngredientUtil.updateMenuItem(ListUtil.cloneList(oldItem.menuBiz.selectedModifier), ListUtil.cloneList(newItem.menuBiz.selectedModifier));
        List<MenuItem> addedMenuItem = changedList.get(0);
        List<MenuItem> deletedMenuItem = changedList.get(1);
        if (addedMenuItem.size() > 0 || deletedMenuItem.size() > 0) {
            final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
            FastMenuItemSocketApi.loadChangeIngredient(orderId, newItem, addedMenuItem, deletedMenuItem, new ResultCallback<ChangeIngredientResponse>() {
                @Override
                public void onSuccess(ChangeIngredientResponse data) {
                    progress.dismiss();
                    callback.onSuccess(data);
                }

                @Override
                public void onFailure(int code, String msg) {
                    progress.dismiss();
                    callback.onFailure(code, msg);
                }
            });
        }
    }

    /**
     * 加、退套餐子项
     *
     * @param orderId  订单号
     * @param oldItem  修改前的菜品
     * @param newItem  修改后的菜品
     * @param callback
     */
    @Override
    public void doChangePackageItems(String orderId, MenuItem oldItem, MenuItem newItem, PackageItemEditViewBean otherData, final ResultCallback<ChangePackageItemsResponse> callback) {
        String voidReason = otherData == null ? "" : otherData.voidReason;
        UserDBModel voidUser = otherData == null ? null : otherData.voidUser;
        SparseArray<List<MenuItem>> changedList = IngredientUtil.updateMenuItem(ListUtil.cloneList(oldItem.menuBiz.selectedPackageItems),
                ListUtil.cloneList(newItem.menuBiz.selectedPackageItems), voidReason, voidUser);
        List<MenuItem> addedMenuItem = changedList.get(0);
        List<MenuItem> deletedMenuItem = changedList.get(1);
        List<MenuItem> updatedMenuItem = changedList.get(2);
        if (addedMenuItem.size() > 0 || deletedMenuItem.size() > 0 || updatedMenuItem.size() > 0) {
            final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
            FastMenuItemSocketApi.loadChangePackageItems(orderId, newItem, addedMenuItem, deletedMenuItem, updatedMenuItem, new IResponse<ChangePackageItemsResponse>() {
                @Override
                public void callBack(boolean result, int code, String msg, ChangePackageItemsResponse info) {
                    progress.dismiss();
                    if (result) {
                        callback.onSuccess(info);
                    } else {
                        callback.onFailure(code, msg);
                    }
                }
            });
        }
    }

    @Override
    public void doUpdateMenuName(MenuItem menuItem, final ResultCallback<String> callback) {
        CallChangeText.call(mHost, new IChangeText() {
            @Override
            public boolean confirmTxt(String text) {
                if (!TextUtils.isEmpty(text)) {
                    callback.onSuccess(text);
                }
                return true;
            }
        });
    }

    @Override
    public void doMenuItemDiscount() {

    }

    @Override
    public void doMenuItemsDiscount(final FastFoodDishCache dishCache, final FastMultiDiscountCallBack callBack) {

    }


}
