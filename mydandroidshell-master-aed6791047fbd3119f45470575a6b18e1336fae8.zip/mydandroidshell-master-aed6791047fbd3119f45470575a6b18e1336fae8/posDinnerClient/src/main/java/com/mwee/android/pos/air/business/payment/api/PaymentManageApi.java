package com.mwee.android.pos.air.business.payment.api;

import com.mwee.android.air.acon.CPaymentManage;
import com.mwee.android.air.connect.business.payment.GetAllPaymentResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.air.business.payment.entity.PayOpenStatus;
import com.mwee.android.pos.air.business.payment.entity.PayOpenStatusRequest;
import com.mwee.android.pos.air.business.payment.entity.PayOpenStatusResponse;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.Constants;

import java.util.HashMap;

/**
 * @ClassName: PaymentManageApi
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午2:59
 */
public class PaymentManageApi {

    /**
     * 获取所有支付方式
     *
     * @param iResult
     */
    public static void getAllPayment(final IResponse<GetAllPaymentResponse> iResult) {
        MCon.c(CPaymentManage.class, new SocketCallback<GetAllPaymentResponse>() {
            @Override
            public void callback(SocketResponse<GetAllPaymentResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).getAllPayment();
    }

   /* public static void addPayment(String fsPaymentName, int fiIsCalcPaid, final IResponse<GetAllPaymentResponse> iResult) {
        MCon.c(CPaymentManage.class, new SocketCallback<GetAllPaymentResponse>() {
            @Override
            public void callback(SocketResponse<GetAllPaymentResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addPayment(fsPaymentName, fiIsCalcPaid);
    }*/

    /*public static void updaetPayment(String fsPaymentId, String fsPaymentName, int fiIsCalcPaid, final IResponse<GetAllPaymentResponse> iResult) {
        MCon.c(CPaymentManage.class, new SocketCallback<GetAllPaymentResponse>() {
            @Override
            public void callback(SocketResponse<GetAllPaymentResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updatePayment(fsPaymentId, fsPaymentName, fiIsCalcPaid);
    }*/

    public static void deletePayment(String fsPaymentId, final IResponse<GetAllPaymentResponse> iResult) {
        MCon.c(CPaymentManage.class, new SocketCallback<GetAllPaymentResponse>() {
            @Override
            public void callback(SocketResponse<GetAllPaymentResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).deletePayment(fsPaymentId);
    }

    public static void loadPayOpenStatus(ResultCallback<HashMap<String, Boolean>> callback) {
        PayOpenStatusRequest request = new PayOpenStatusRequest();
        if (APPConfig.isAirKouBei()) {
            request.type = 2;
        } else {
            request.type = 1;
        }
        request.shopId = AppCache.getInstance().fsShopGUID;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof PayOpenStatusResponse) {
                    PayOpenStatusResponse responseBean = (PayOpenStatusResponse) responseData.responseBean;
                    HashMap<String, Boolean> statusMap = new HashMap<>();
                    statusMap.put(Constants.PAY_TYPE_ALIPAY, false);
                    statusMap.put(Constants.PAY_TYPE_WECHAT, false);
                    for (PayOpenStatus datum : responseBean.data) {
                        if (android.text.TextUtils.equals(Constants.PAY_TYPE_WECHAT, datum.pay_type)) {
                            if (datum.pay_status == 0) {
                                statusMap.put(Constants.PAY_TYPE_WECHAT, true);
                                //刷新缓存
                            } else {
                                statusMap.put(Constants.PAY_TYPE_WECHAT, false);
                            }
                        }
                        if (android.text.TextUtils.equals(Constants.PAY_TYPE_ALIPAY, datum.pay_type)) {
                            if (datum.pay_status == 0) {
                                statusMap.put(Constants.PAY_TYPE_ALIPAY, true);
                            } else {
                                statusMap.put(Constants.PAY_TYPE_ALIPAY, false);
                            }
                        }
                    }
                    callback.onSuccess(statusMap);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

}
