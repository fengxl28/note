package com.mwee.android.pos.business.common.dialog.pay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.MainThread;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.notify.NotifyDispatchService;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.tools.DisplayUtil;

/**
 * Created by qinwei on 2017/9/15.
 */

public class KBNewFutureOrderNotice {

    private WindowManager mWindowManager = null;
    private View view;
    public boolean isShow = false;
    private static KBNewFutureOrderNotice mInstance;

    /**
     * 当前选中的口碑模式
     * <p>
     * 0先付款模式
     * 1后付款模式
     */
    private int current_index = 1;


    public static KBNewFutureOrderNotice getInstance() {
        if (mInstance == null) {
            mInstance = new KBNewFutureOrderNotice();
        }
        return mInstance;
    }

    @MainThread
    public void showFloatWindow(String content) {

        if (isShow) {
            updateFloatWindow(content);
            return;
        }
        view = LayoutInflater.from(GlobalCache.getContext()).inflate(R.layout.layout_kborder_apply_refund, null);
        initFloatView();
        WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) GlobalCache.getContext().getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (!Settings.canDrawOverlays(GlobalCache.getContext())) {
                RunTimeLog.addLog(RunTimeLog.OVERLAY_WINDOW, "NetOrderMessageNotice -> showFloatWindow() 无权限返回");
                return;
            }
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.gravity = Gravity.RIGHT | Gravity.TOP;
        wmParams.width = DisplayUtil.dp2px(GlobalCache.getContext(), 360);
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.windowAnimations = android.R.style.Animation_Translucent;
        mWindowManager.addView(view, wmParams);
        isShow = true;
        updateFloatWindow(content);
    }

    @MainThread
    public void updateFloatWindow(String content) {
        TextView tvKBLabel = view.findViewById(R.id.tvKBLabel);
        tvKBLabel.setText(content);
        tvKBLabel.setTextColor(Color.RED);
    }


    private void initFloatView() {
        Button mMessageGoCenterBtn = (Button) view.findViewById(R.id.mMessageGoCenterBtn);
        mMessageGoCenterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NotifyDispatchService.notifyOrderList = 0;
                NotifyDispatchService.notifyKBOrderCount = 0;
                if (BaseActivity.topActivity != null) {
                    MessageV2Fragment.index = 6;
                    MessageV2Fragment.koubei_current_index = current_index;
//                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                }
                release();
            }
        });
        Button mMessageCloseBtn = (Button) view.findViewById(R.id.mMessageCloseBtn);
        mMessageCloseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                release();
            }
        });
    }


    private void release() {
        if (mWindowManager != null) {
            mWindowManager.removeView(view);
        }
        mWindowManager = null;
        mInstance = null;
    }
}
