package com.mwee.android.pos.business.member.constant;

/**
 * 会员充值后充值结果状态
 * Created by chris on 16/8/29.
 */
public class MemberRechargeOrderStatus {

    //101=>发起交易   102=>等待确认   103=>等待付款    104=>交易/支付完成

    /**
     * 发起交易
     */
    public static final int START_TRANSACTION = 101;
    /**
     * 等待确认
     */
    public static final int WAIT_CONFIRM = 102;
    /**
     * 等待付款
     */
    public static final int WAIT_PAY = 103;
    /**
     * 交易/支付完成
     */
    public static final int FINISH_TRANSACTION = 104;
}
