package com.mwee.android.pos.business.menu.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.mwee.android.pos.air.business.utils.PriceInputFilter;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.connect.business.dish.MenuTemporaryModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.EditFilterUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2018/3/8.
 */

public class MenuTemporaryEditorFragment extends BaseDialogFragment implements View.OnClickListener {

    private EditText mMenuNameEdt;
    private EditText mMenuPriceEdt;
    private TextView tvMenuUnit;
    private TextView tvReportPrint;
    private TextView tvReportCheck;
    private TextView tvReportSell;

    private Button mCancelBtn;
    private Button mConfirmBtn;

    private MenuItem menuItem;
    private MenuTemporaryModel menuTemporaryModel;
    private IResponse<MenuItem> iResponse;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_menu_temp_editor_dialog, container, false);
        initView(v);
        initData();
        return v;
    }

    private void initView(View v) {

        mMenuNameEdt = v.findViewById(R.id.mMenuNameEdt);
        mMenuPriceEdt = v.findViewById(R.id.mMenuPriceEdt);
        tvMenuUnit = v.findViewById(R.id.tvMenuUnit);
        tvReportPrint = v.findViewById(R.id.tvReportPrint);
        tvReportSell = v.findViewById(R.id.tvReportSell);
        tvReportCheck = v.findViewById(R.id.tvReportCheck);
        mCancelBtn = v.findViewById(R.id.mCancelBtn);
        mConfirmBtn = v.findViewById(R.id.mConfirmBtn);

        mMenuPriceEdt.setFilters(new InputFilter[]{new PriceInputFilter()});
        mCancelBtn.setOnClickListener(this);
        mConfirmBtn.setOnClickListener(this);

        EditFilterUtil.setEtFilter(mMenuNameEdt);
    }


    private void initData() {

        mMenuNameEdt.setText(menuItem.name);
        mMenuPriceEdt.setText(menuItem.price + "");
        tvMenuUnit.setText(String.format("规格:%s", menuItem.currentUnit.fsOrderUint));
        tvReportPrint.setText(String.format("打印档口:%s", menuTemporaryModel.fsDeptName));
        tvReportSell.setText(String.format("销售归属:%s", menuTemporaryModel.fsExpClsName));
        tvReportCheck.setText(String.format("收入归属:%s", menuTemporaryModel.fsRevenueTypeName));
    }

    public void setParams(MenuItem menuItem, MenuTemporaryModel menuTemporaryModel, IResponse<MenuItem> iResponse) {
        this.menuItem = menuItem;
        this.menuTemporaryModel = menuTemporaryModel;
        this.iResponse = iResponse;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mCancelBtn:
                dismissSelf();
                break;
            case R.id.mConfirmBtn:
                String name = mMenuNameEdt.getText().toString().trim();
                String price = mMenuPriceEdt.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    ToastUtil.showToast("请输入菜品名称");
                    return;
                }

                if (TextUtils.isEmpty(price)) {
                    ToastUtil.showToast("请输入菜品价格");
                    return;
                }
                menuItem.name = name;
//                menuItem.name2 = name;
                menuItem.price = new BigDecimal(price);
                menuItem.currentUnit.fdSalePrice = new BigDecimal(price);
                menuItem.currentUnit.fdVIPPrice = new BigDecimal(price);

                iResponse.callBack(true, 0, "", menuItem);
                dismissSelf();
                break;
            default:
                break;
        }
    }


}
