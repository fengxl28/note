package com.mwee.android.pos.business.cross;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.drivenbus.Driver;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.cross.api.CreditApi;
import com.mwee.android.pos.component.cross.net.GuaOrder;
import com.mwee.android.pos.component.cross.net.Response;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/2.
 */

public class GuaOrderListFragment extends BaseListFragment<GuaOrder> {

    private String accountId;
    public int currentPage;

    public static GuaOrderListFragment newInstance(String accountId) {
        GuaOrderListFragment fragment = new GuaOrderListFragment();
        Bundle args = new Bundle();
        args.putString("accountId", accountId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_gua_order_list;
    }

    @Override
    protected void initData() {
        super.initData();
        if (getArguments() != null) {
            accountId = getArguments().getString("accountId");
        }
        adapter.isFooterShow = true;
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        refresh();
    }

    public void refresh() {
        mPullRecyclerView.setRefreshing();
    }

    private void loadDataFromServer(int mode) {
        CreditApi.loadGuaOrderList(accountId, currentPage, 30, new ResultCallback<Response<GuaOrder>>() {
            @Override
            public void onSuccess(Response<GuaOrder> data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    adapter.modules.clear();
                }
                if (currentPage >= data.totalPages) {
                    //没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (currentPage == 1 && !TextUtils.validate(data.result)) {
                    mPullRecyclerView.showEmptyView();
                } else {
                    mPullRecyclerView.showContent();
                    adapter.modules.addAll(data.result);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (adapter.modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_gua_item, parent, false));
    }

    class Holder extends BaseViewHolder {
        private TextView mGuaItemCreateTimeLabel;
        private TextView mGuaItemOrderNumberLabel;
        private TextView mGuaItemPriceLabel;
        private TextView mGuaItemUsernameLabel;
        private TextView mGuaItemStatusLabel;
        private Button mSingleOperatLabel;

        public Holder(View v) {
            super(v);
            mGuaItemCreateTimeLabel = (TextView) v.findViewById(R.id.mGuaItemCreateTimeLabel);
            mGuaItemOrderNumberLabel = (TextView) v.findViewById(R.id.mGuaItemOrderNumberLabel);
            mGuaItemPriceLabel = (TextView) v.findViewById(R.id.mGuaItemPriceLabel);
            mGuaItemUsernameLabel = (TextView) v.findViewById(R.id.mGuaItemUsernameLabel);
            mGuaItemStatusLabel = (TextView) v.findViewById(R.id.mGuaItemStatusLabel);
            mSingleOperatLabel = v.findViewById(R.id.mSingleOperatButton);
        }

        @Override
        public void bindData(int position) {
            GuaOrder order = modules.get(position);
            mGuaItemCreateTimeLabel.setText(DateTimeUtil.getTime(order.createTime));
            mGuaItemOrderNumberLabel.setText(order.sellNo);
            mGuaItemPriceLabel.setText(order.debtAmt.toPlainString());
            mGuaItemUsernameLabel.setText(order.cashierName);
            mGuaItemStatusLabel.setText(getOrderStatus(order));

            if (!android.text.TextUtils.equals(AppCache.getInstance().businessDate, order.sellDate)
                    && order.balanceAmt.compareTo(BigDecimal.ZERO) > 0) {
                mSingleOperatLabel.setBackground(getResourcesWithinHost().getDrawable(R.drawable.bg_cubic_red));
                mSingleOperatLabel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (ButtonClickTimer.canClick()) {
                            ActionLog.addLog("点击'销账'按钮 操作单笔销账", ActionLog.CROSS_ACCOUNT_CROSS_DO);
                            DriverBus.call("CreditContainerActivity/singleOperation", order.sellNo, order.balanceAmt.toPlainString());
                        }
                    }
                });
            } else {
                mSingleOperatLabel.setBackground(getResourcesWithinHost().getDrawable(R.drawable.bg_cubic_gray));
                mSingleOperatLabel.setOnClickListener(null);
            }

        }

        private String getOrderStatus(GuaOrder order) {
            switch (order.bussinessStatus) {
                case "1":
                    itemView.setSelected(false);
                    return "未销账";
                case "2":
                    itemView.setSelected(true);
                    return "已销账";
                case "3":
                    itemView.setSelected(false);
                    return "部分销账";
                default:
                    break;
            }
            return "";
        }
    }
}
