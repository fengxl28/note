package com.mwee.android.pos.business.einvoice;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.einvoice.api.BaseInvoiceRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceConnectInfoRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceIsActiveRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceRateRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceRateUpdateRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceSwitchStatusGetRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceSwitchStatusUpdateRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * author:luoshenghua
 * create on:2018/4/27
 * description:电子发票
 */
public class EInvoiceProcess {

    /**
     * 票通宝相关信息操作
     *
     * @param invoiceMethod queryInfo（查询该门店是否开通电子发票业务接口）
     *                      getPTBoxStatus（获取票通宝设备的状态）
     *                      edittaxrate(更新税率)
     *                      StockAndTaxRate(查询库存税率)
     * @param paramsMap     参数列表
     * @param callback      响应回调
     */
    private static void electronicInvoiceProcess(BaseInvoiceRequest baseInvoiceRequest, String invoiceMethod, Map<String, String> paramsMap, IExecutorCallback callback) {
        baseInvoiceRequest.invoiceMethod = invoiceMethod;
        baseInvoiceRequest.data = paramsMap;
        BusinessExecutor.execute(baseInvoiceRequest, callback);
    }

    /**
     * 根据参数列表组装成jsonString
     *
     * @param shopId 门店id
     * @return jsonString
     */

    public static void isInvoiceActive(String shopId, IExecutorCallback callback) {
        InvoiceIsActiveRequest invoiceIsActiveRequest = new InvoiceIsActiveRequest();
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("shopId", shopId);
        electronicInvoiceProcess(invoiceIsActiveRequest, "queryInfo", paramsMap, callback);
    }

    public static void invoiceConnectInfo(String shopId, IExecutorCallback callback) {
        InvoiceConnectInfoRequest invoiceConnectInfoRequest = new InvoiceConnectInfoRequest();
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("shopId", shopId);
        electronicInvoiceProcess(invoiceConnectInfoRequest, "getPTBoxStatus", paramsMap, callback);
    }


    public static void getInvoiceNumAndRate(String shopId, IExecutorCallback callback) {
        InvoiceRateRequest invoiceRateRequest = new InvoiceRateRequest();
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("shopId", shopId);
        electronicInvoiceProcess(invoiceRateRequest, "stockAndTaxRate", paramsMap, callback);
    }

    public static void updateInvoiceRate(String shopId,int taxRateValue,IExecutorCallback callback) {
        InvoiceRateUpdateRequest invoiceRateUpdateRequest = new InvoiceRateUpdateRequest();
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("shopId", shopId);
        paramsMap.put("taxRateValue", String.valueOf(taxRateValue));
        electronicInvoiceProcess(invoiceRateUpdateRequest, "edittaxrate", paramsMap, callback);
    }

    public static void getInvoiceSwitchStatus(String[] shopIds, IExecutorCallback callback) {
        InvoiceSwitchStatusGetRequest invoiceSwitchStatusGetRequest = new InvoiceSwitchStatusGetRequest();
        invoiceSwitchStatusGetRequest.shopIds = arrayToString(shopIds);
        BusinessExecutor.execute(invoiceSwitchStatusGetRequest, callback);
    }

    public static void updateInvoiceSwitchStatus(String shopId, boolean invoiceEnable, IExecutorCallback callback) {
        InvoiceSwitchStatusUpdateRequest invoiceSwitchStatusGetRequest = new InvoiceSwitchStatusUpdateRequest();
        invoiceSwitchStatusGetRequest.shopId = shopId;
        invoiceSwitchStatusGetRequest.fapiaoEnable = invoiceEnable ? 2 : 0;
        BusinessExecutor.execute(invoiceSwitchStatusGetRequest, callback);
    }


    /**
     * 将String[]转化为"a,b,c"形式
     *
     * @param vargs
     * @return String
     */
    private static String arrayToString(String[] vargs) {
        if (vargs != null) {
            int length = vargs.length;
            int count = -1;
            StringBuilder stringBuilder = new StringBuilder();
            for (String value : vargs) {
                stringBuilder.append(value);
                count = count + 1;
                if (count < length - 1) {
                    stringBuilder.append(",");
                }
            }

            return stringBuilder.toString();
        }
        return "";
    }


    public static String optManualEInvoiceStatus(int status){
        if (status == 10){
            return "开票中";
        }else if (status == 20){
            return "已开票";
        }else if (status == 30){
            return "开票失败";
        }
        return "未开票";

    }

}
