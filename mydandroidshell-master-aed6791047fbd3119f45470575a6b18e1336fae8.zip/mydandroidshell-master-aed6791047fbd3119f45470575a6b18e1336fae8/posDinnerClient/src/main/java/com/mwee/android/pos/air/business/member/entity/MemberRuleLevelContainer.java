package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberRuleLevelContainer extends BusinessBean {

    public CardSettingModel card_setting = new CardSettingModel();

    public ArrayList<MemberLevelModel> member_level = new ArrayList<>();

    public ArrayList<MemberPackageContainer> rechargepkg_list = new ArrayList<>();

   /* public AirMemberBean<MemberScoreGiftRuleResult> crm_membercard_getScRuleInfo = new AirMemberBean<>();

    public AirMemberBean<ArrayList<MemberLevelModel>> crm_membercard_listMemberLevel = new AirMemberBean<>();

    */
    /**
     * 充值套餐列表
     *//*
    public AirMemberBean<ArrayList<MemberPackageModel>> crm_membercard_listRechargepkg = new AirMemberBean();*/





    public MemberRuleLevelContainer() {
    }
}
