package com.mwee.android.pos.air.business.menu.processor;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAddResponse;
import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.pos.air.business.menu.api.MenuManagerApi;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/11.
 */

public class MenuClsProcessor {

    public void loadMenuManagerIndexData(boolean isLoadAllMenu, final ResultCallback<AllMenuClsAndMenuItemResponse> callback) {
        loadMenuManagerIndexData(isLoadAllMenu, callback, true);

    }

    public void loadMenuManagerIndexData(boolean isLoadAllMenu, final ResultCallback<AllMenuClsAndMenuItemResponse> callback, boolean hasAllCls) {
        MenuManagerApi.loadMenuManagerIndexData(isLoadAllMenu, new SocketCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void callback(SocketResponse<AllMenuClsAndMenuItemResponse> response) {
                if (response.success()) {
                    if (hasAllCls) {
                        buildTopMenu(response.data.menuClsBeanList);
                    }
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadMenuClsPrinters(String fsMenuClsId, final ResultCallback<MenuClsPrintersResponse> callback) {
        MenuManagerApi.loadMenuClsPrinters(fsMenuClsId, new SocketCallback<MenuClsPrintersResponse>() {
            @Override
            public void callback(SocketResponse<MenuClsPrintersResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    /**
     * 构建全部虚拟分类
     *
     * @param menuClsBeanList
     */
    private void buildTopMenu(List<MenuClsBean> menuClsBeanList) {
        MenuClsBean menuClsBean = new MenuClsBean();
        menuClsBean.fsMenuClsName = "全部分类";
        if (ListUtil.isEmpty(menuClsBeanList)) {
            menuClsBeanList = new ArrayList<>();
        }
        menuClsBeanList.add(0, menuClsBean);
    }

    public void loadMenuClsUpdate(MenuClsBean menuClsBean, final ResultCallback<String> callback) {
        MenuManagerApi.loadMenuClsUpdate(menuClsBean, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadMenuClsAdd(String name, ArrayList<String> printerNames, final ResultCallback<MenuClsAddResponse> callback) {
        MenuManagerApi.loadMenuClsAdd(name, printerNames, new SocketCallback<MenuClsAddResponse>() {
            @Override
            public void callback(SocketResponse<MenuClsAddResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }


    /**
     * 分类删除
     *
     * @param fsMenuClsId
     * @param callback
     */
    public void loadMenuClsDelete(String fsMenuClsId, final ResultCallback<String> callback) {
        MenuManagerApi.loadMenuClsDelete(fsMenuClsId, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }


    /**
     * 分类置顶
     *
     * @param fsMenuClsId
     * @param callback
     */
    public void loadMenuClsToTop(String fsMenuClsId, final ResultCallback<MenuClsToTopResponse> callback) {
        MenuManagerApi.loadMenuClsToTop(fsMenuClsId, new SocketCallback<MenuClsToTopResponse>() {
            @Override
            public void callback(SocketResponse<MenuClsToTopResponse> response) {
                if (response.success()) {
                    buildTopMenu(response.data.menuClsBeenList);
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void addMenuCls(MenuTypeBean bean) {
        //无分类添加一个虚拟的全部分类
        if (AppCache.getInstance().firstNodeMap.size() == 0) {
            MenuTypeBean typeAll = new MenuTypeBean();
            typeAll.menuList = new ArrayList<>();
            typeAll.fsMenuClsName = "全部";
            typeAll.fsMenuClsId = "-1localAll";
            typeAll.typeIndex = true;
            AppCache.getInstance().firstNodeMap.add(typeAll);
        }
        AppCache.getInstance().firstNodeMap.add(bean);
        AppCache.getInstance().fullDataMap.put(bean.fsMenuClsId, bean);
    }

    public void deleteMenuCls(MenuTypeBean bean) {
        //如果只用两个分类则删除所有
        if (AppCache.getInstance().firstNodeMap.size() == 2) {
            AppCache.getInstance().firstNodeMap.clear();
        } else {
            AppCache.getInstance().firstNodeMap.remove(bean);
        }
        AppCache.getInstance().fullDataMap.remove(bean.fsMenuClsId);
    }

    public void initMenuCls() {
        boolean hasAllType = false;
        for (int i = 0; i < AppCache.getInstance().firstNodeMap.size(); i++) {
            if (AppCache.getInstance().firstNodeMap.get(i).fsMenuClsId.equals("-1localAll")) {
                hasAllType = true;
                break;
            }
        }
        if (!hasAllType && AppCache.getInstance().firstNodeMap.size() > 0) {
            MenuTypeBean typeAll = new MenuTypeBean();
            typeAll.menuList = new ArrayList<>();
            typeAll.fsMenuClsName = "全部";
            typeAll.fsMenuClsId = "-1localAll";
            typeAll.typeIndex = true;
            AppCache.getInstance().firstNodeMap.add(0, typeAll);
        }
    }

    public MenuClsBean copyTo(MenuTypeBean bean) {
        MenuClsBean menuClsBean = new MenuClsBean();
        menuClsBean.fsMenuClsId = bean.fsMenuClsId;
        menuClsBean.fsMenuClsName = bean.fsMenuClsName;
        return menuClsBean;
    }
}
