package com.mwee.android.pos.air.business.discount.view;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.discount.processor.DiscountManagerProcessor;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;

import java.util.ArrayList;


/**
 * Created by lxx on 2017/10/13.
 * 优惠与折扣管理界面
 */

public class DiscountManagerActivity extends AirBaseActivity {

    private TitleBar mTitleBar;

    private RecyclerView discount_RecyclerView;

    private DiscountAdapter discountAdapter = null;

    private DiscountManagerProcessor discountManagerProcessor;

    private LinearLayout mOperationAddLayout;
    private LinearLayout mOperationDeleteLayout;
    private TextView tvAdd;
    private TextView tvBatchDelete;
    private TextView mAskBatchChoiceAllLabel;//全选
    private TextView mBatchChoiceValueLabel; //选中的个数
    private TextView mAskBatchCancelBtn;   //取消
    private TextView mAskBatchDeleteBtn;   //删除

    private FrameLayout mEmptyLayout;
    private TextView tvEmptyCreateFirst;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air_discount_manager_activity);
        discountManagerProcessor = new DiscountManagerProcessor();
        initUI();
        initButtomLayut();
        initData();
    }


    private void initUI() {
        mEmptyLayout = findViewById(R.id.mEmptyLayout);
        tvEmptyCreateFirst = findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建折扣");
        tvEmptyCreateFirst.setOnClickListener(this);

        mTitleBar = findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });
        mTitleBar.setTitle("优惠折扣");

        discount_RecyclerView = findViewById(R.id.discount_RecyclerView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        discount_RecyclerView.setLayoutManager(linearLayoutManager);
        discount_RecyclerView.addItemDecoration(new DividerItemDecoration(getContextWithinHost(), DividerItemDecoration.VERTICAL_LIST));
        discountAdapter = new DiscountAdapter();
        discount_RecyclerView.setAdapter(discountAdapter);

    }


    /**
     * 初始化底部bottom
     */
    private void initButtomLayut() {

        mOperationAddLayout = findViewById(R.id.mOperationAddLayout);
        tvAdd = findViewById(R.id.tvAdd);
        tvAdd.setText("新建折扣");
        tvBatchDelete = findViewById(R.id.tvBatchDelete);
        tvAdd.setOnClickListener(this);
        tvBatchDelete.setOnClickListener(this);

        mOperationDeleteLayout = findViewById(R.id.mOperationDeleteLayout);
        mAskBatchChoiceAllLabel = findViewById(R.id.mAskBatchChoiceAllLabel);
        mBatchChoiceValueLabel = findViewById(R.id.mBatchChoiceValueLabel);
        mAskBatchCancelBtn = findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn = findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchDeleteBtn.setOnClickListener(this);

    }


    /**
     * 去业务中心获取数据
     */
    public void initData() {
        ProgressManager.closeProgress(this);
        discountManagerProcessor.optAllDiscount(new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(DiscountManagerActivity.this);
                if (!result) {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "数据获取失败，请重试");
                    return;
                }
                refreshUI();
            }
        });
    }


    /**
     * 刷新UI
     */
    public void refreshUI() {

        discountAdapter.modules = discountManagerProcessor.discountManagerInfoArrayList;
        discountAdapter.notifyDataSetChanged();

        if (ListUtil.isEmpty(discountManagerProcessor.discountManagerInfoArrayList)) {
            mEmptyLayout.setVisibility(View.VISIBLE);
            mOperationAddLayout.setVisibility(View.GONE);
            mOperationDeleteLayout.setVisibility(View.VISIBLE);
        } else {
            mEmptyLayout.setVisibility(View.GONE);
            mOperationAddLayout.setVisibility(View.VISIBLE);
            mOperationDeleteLayout.setVisibility(View.GONE);

        }
    }


    class DiscountAdapter extends BaseListAdapter<DiscountManagerInfo> {

        private int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.air_discount_manager_item, parent, false));
        }

        class ViewHolder extends BaseViewHolder implements View.OnClickListener {

            private ImageView tvItemCheck;

            private TextView mItemNameLabel;
            private TextView mItemRatebel;
            private TextView mItemGroupLabel;

            private DiscountManagerInfo model;
            private int position;

            public ViewHolder(View v) {
                super(v);
                tvItemCheck = v.findViewById(R.id.tvItemCheck);
                mItemNameLabel = v.findViewById(R.id.mItemNameLabel);
                mItemRatebel = v.findViewById(R.id.mItemRatebel);
                mItemGroupLabel = v.findViewById(R.id.mItemGroupLabel);

                tvItemCheck.setOnClickListener(this);
                v.setOnClickListener(this);

            }

            @Override
            public void bindData(int position) {

                this.position = position;
                model = modules.get(position);

                mItemNameLabel.setText(model.fsDiscountName);
                mItemRatebel.setText(model.fiDiscountRate + "%");
                mItemGroupLabel.setText(model.discountClsNameTag);


                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
                    tvItemCheck.setVisibility(View.VISIBLE);
                    if (choiceStates.contains(model.fsDiscountId)) {
                        tvItemCheck.setSelected(true);
                    } else {
                        tvItemCheck.setSelected(false);
                    }
                } else {
                    tvItemCheck.setVisibility(View.INVISIBLE);
                }


                if (position == selectPosition) {
                    itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FFD2CB));
                } else {
                    itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));
                }
            }

            @Override
            public void onClick(View view) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                selectPosition = position;
                if (view.getId() == R.id.tvItemCheck) {
                    choice(model.fsDiscountId);
                    discountAdapter.notifyDataSetChanged();
                    refreshChoiceMenuCount();
                    mAskBatchChoiceAllLabel.setSelected(isChoiceAll());

                } else {
                    discountAdapter.notifyDataSetChanged();
                    if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为菜品删除模式 不触发编辑菜品事件
                        return;
                    }
                    showDiscountEditorDialog(model);
                }


            }
        }


    }


    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.tvEmptyCreateFirst:
            case R.id.tvAdd:
                ActionLog.addLog("折扣管理页面--->点击了新建分组", "", "", ActionLog.SS_MORE_JOIN, "");
                showDiscountEditorDialog(null);
                break;
            case R.id.tvBatchDelete:
                ActionLog.addLog("折扣管理页面--->点击了批量删除", "", "", ActionLog.SS_MORE_JOIN, "");
                mOperationAddLayout.setVisibility(View.GONE);
                mOperationDeleteLayout.setVisibility(View.VISIBLE);
                discountAdapter.notifyDataSetChanged();
                //menuAdapter.notifyDataSetChanged();
                break;
            case R.id.mAskBatchChoiceAllLabel://全选
                ActionLog.addLog("折扣管理页面--->点击了全选", "", "", ActionLog.SS_MORE_JOIN, "");
                doChoiceAll();
                break;
            case R.id.mAskBatchCancelBtn://取消
                ActionLog.addLog("折扣管理页面--->点击了取消", "", "", ActionLog.SS_MORE_JOIN, "");
                doCancelChoiceAll();
                break;
            case R.id.mAskBatchDeleteBtn://删除
                ActionLog.addLog("折扣管理页面--->点击了删除", "", "", ActionLog.SS_MORE_JOIN, "");
                doBatchDeleteChoice();
                break;


            default:
                break;
        }
    }


    private void doChoiceAll() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        discountAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();
    }

    private void doCancelChoiceAll() {

        mOperationAddLayout.setVisibility(View.VISIBLE);
        mOperationDeleteLayout.setVisibility(View.GONE);
        cancelChoiceAll();
        mAskBatchChoiceAllLabel.setSelected(false);
        discountAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();

    }

    private void doBatchDeleteChoice() {

        if (choiceStates.isEmpty()) {
            ToastUtil.showToast("请先选择折扣");
            return;
        }
        String content = "";
        if (choiceStates.size() == 1) {
            content = "确定删除该折扣吗?";
        } else {
            content = String.format("确定删除这%s个折扣吗?", choiceStates.size());
        }

        DialogManager.showExecuteDialog(getActivityWithinHost(), content, new DialogResponseListener() {
            @Override
            public void response() {

                final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost());
                discountManagerProcessor.batchDeleteTable(choiceStates, new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        progress.dismissSelf();
                        if (result) {
                            ToastUtil.showToast("已删除");
                            progress.dismissSelf();
                            //删除完成 释放choice
                            choiceStates.clear();
                            mAskBatchChoiceAllLabel.setSelected(false);
                            refreshChoiceMenuCount();
                            refreshUI();

                        } else {
                            ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(info) ? info : "删除折扣失败");
                        }
                    }
                });

            }
        });

    }

    /**
     * 刷新选中菜品个数显示
     */
    private void refreshChoiceMenuCount() {

        mBatchChoiceValueLabel.setText(String.format("选中%s个", choiceStates.size()));

    }


    /**
     * 餐区变动监听回调
     */
    EditDiscountFragment.OnEditDiscountListener onAreaEditorListener = new EditDiscountFragment.OnEditDiscountListener() {
        @Override
        public void onEditorSuccess() {
            refreshUI();
        }
    };

    /**
     * 编辑区域--修改餐区名称、删除餐区
     */
    private void showDiscountEditorDialog(DiscountManagerInfo discountManagerInfo) {
        EditDiscountFragment dialog = new EditDiscountFragment();
        dialog.setParam(discountManagerProcessor, discountManagerInfo);
        dialog.setOnEditDiscountListener(onAreaEditorListener);
        DialogManager.showCustomDialog(this, dialog, "EditDicountDialog");
    }


    /*--------------------------折扣选删除的操作---------------------------------*/
    private ArrayList<String> choiceStates = new ArrayList<>();

    /**
     * 单选一个菜品
     *
     * @param value
     */
    private void choice(String value) {
        if (choiceStates.contains(value + "")) {
            choiceStates.remove(value + "");
        } else {
            choiceStates.add(value + "");
        }
    }


    /**
     * 判断是否全选
     *
     * @return
     */
    private boolean isChoiceAll() {
        for (int i = 0; i < discountAdapter.modules.size(); i++) {
            if (!choiceStates.contains(discountAdapter.modules.get(i).fsDiscountId)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选
     */
    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < discountAdapter.modules.size(); i++) {
            choiceStates.add(discountAdapter.modules.get(i).fsDiscountId + "");
        }
    }

    /**
     * 清除全选
     */
    private void cancelChoiceAll() {
        choiceStates.clear();
    }
}
