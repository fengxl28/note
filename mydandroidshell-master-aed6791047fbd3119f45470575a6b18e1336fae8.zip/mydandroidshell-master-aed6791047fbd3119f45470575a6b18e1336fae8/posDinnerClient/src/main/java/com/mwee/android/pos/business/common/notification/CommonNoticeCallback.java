package com.mwee.android.pos.business.common.notification;

/**
 * @ClassName: CommonNoticeCallback
 * @Description:
 * @author: SugarT
 * @date: 2018/7/9 下午3:55
 */
public interface CommonNoticeCallback {

    void callback();
}
