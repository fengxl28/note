//package com.mwee.android.pos.air.business.main;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.os.Bundle;
//import android.text.TextUtils;
//
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.air.business.airdinnerorder.view.AirDinnerTableContainerFragment;
//import com.mwee.android.pos.air.business.fastfood.FastFoodOrderFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseActivity;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.base.FragmentController;
//import com.mwee.android.pos.base.HomeFragment;
//import com.mwee.android.pos.base.OnKeyBackListener;
//import com.mwee.android.pos.business.login.component.LoginProcess;
//import com.mwee.android.pos.business.sync.ClientBindProcessor;
//import com.mwee.android.pos.client.db.ClientMetaUtil;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.component.log.RunTimeLog;
//import com.mwee.android.pos.connect.bean.BaseSocketResponse;
//import com.mwee.android.pos.connect.config.SocketResultCode;
//import com.mwee.android.pos.connect.callback.SocketCallback;
//import com.mwee.android.pos.connect.framework.SocketResponse;
//import com.mwee.android.pos.db.base.META;
//import com.mwee.android.pos.db.business.bind.HostStatus;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.Constants;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.util.UIHelp;
//import com.mwee.android.tools.LogUtil;
//
///**
// * Created by qinwei on 2017/11/6.
// */
//
//public class HomeActivity extends BaseActivity implements IDriver {
//    private final static String DRIVER_TAG = "main";
//    private String orderModel;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_air_main);
//        DriverBus.registerDriver(this);
//        getActivityWithinHost().registerReceiver(this.printFailReceiver, new IntentFilter(Constants.ACTION_Fail_PRINT));
//        orderModel = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, "");
//        initOrderMode();
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        String air_order_mode = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, "");
//        if (!TextUtils.equals(air_order_mode, orderModel)) {
//            this.orderModel = air_order_mode;
//            initOrderMode();
//        }
//    }
//
//    private void initOrderMode() {
//        if (TextUtils.equals(this.orderModel, "0")) {
//            showDinnerFoodOrderFragment();
//        } else {
//            showFastFoodOrderFragment();
//        }
//    }
//
//    private void showFastFoodOrderFragment() {
//        getSupportFragmentManager().beginTransaction().replace(R.id.main_menufragment, new FastFoodOrderFragment()).commit();
//    }
//
//    private void showDinnerFoodOrderFragment() {
//        getSupportFragmentManager().beginTransaction().replace(R.id.main_menufragment, new AirDinnerTableContainerFragment()).commit();
//    }
//
//    @Override
//    public void onBackPressed() {
//        BaseFragment temp = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.main_menufragment);
//        if (temp != null && !(temp instanceof HomeFragment)) {
//            boolean handled = false;
//            if (temp instanceof OnKeyBackListener) {
//                handled = temp.onKeyBack();
//            }
//            if (handled) {
//                return;
//            }
//            FragmentController.removeFragment(getSupportFragmentManager(), temp);
//            return;
//        }
//
//        BaseFragment tempFragment = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.main_menufragment);
//        if (tempFragment != null && tempFragment.onKeyBack()) {
//            return;
//        }
//
//        if (tempFragment instanceof HomeFragment) {
//            return;
//        }
//        FragmentController.removeFragment(getSupportFragmentManager(), tempFragment);
//    }
//
//    /**
//     * 发起退出登录
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/logout", UIThread = true)
//    public void processLogout() {
//        if (AppCache.getInstance().userDBModel == null) {
//            return;
//        }
//        RunTimeLog.addLog(RunTimeLog.Close, "登出" + AppCache.getInstance().userDBModel.fsUserName);
//        final Progress progress = ProgressManager.showProgress(this, "正在更新站点状态");
//        LoginProcess.doLogout(AppCache.getInstance().userDBModel.fsUserId, new SocketCallback<BaseSocketResponse>() {
//            @Override
//            public void callback(SocketResponse socketResponse) {
//                progress.dismiss();
//                if (socketResponse.code != SocketResultCode.SUCCESS) {
//                    ToastUtil.showToast(socketResponse.message);
//                    return;
//                }
//                LogUtil.log("收银员[--fsUserName--" + AppCache.getInstance().userDBModel.fsUserName + "--fsUserId--" + AppCache.getInstance().userDBModel.fsUserId + " 退出登录]");
//                ActionLog.waiterID = "";
//                ActionLog.waiterName = "";
//                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_STATUS, HostStatus.CLOSE);
//                UIHelp.startLoginDinnerActvity(getActivityWithinHost());
//                leave(false);
//                AppCache.getInstance().userDBModel = null;
//            }
//        });
//    }
//
//    /**
//     * 离开页面
//     *
//     * @param isClose boolean | 是否是打烊登出页面
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/leave", UIThread = true)
//    public void leave(boolean isClose) {
//        if (isClose && ClientBindProcessor.isCurrentHostMain()) {
//            return;
//        }
//        if (getActivityWithinHost() != null) {
//            getActivityWithinHost().finish();
//        }
//    }
//
//
//    @Override
//    public String getModuleName() {
//        return DRIVER_TAG;
//    }
//
//
//    @Override
//    protected void onDestroy() {
//        getActivityWithinHost().unregisterReceiver(this.printFailReceiver);
////        getActivityWithinHost().unregisterReceiver(this.updateReceiver);
//        super.onDestroy();
//    }
//
//    /**
//     * 打印失败的Receiver
//     */
//    private final BroadcastReceiver printFailReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            if (intent.getAction().equals(Constants.ACTION_Fail_PRINT)) {
//                AppCache.getInstance().isPrintWaring = true;
//                DriverBus.call("mainTitleBar/waring", true);
//            }
//        }
//    };
//}
