package com.mwee.android.pos.business.message;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListHomeFragment;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.message.processor.netOrder.DeliveryUtil;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderClientUtil;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderDetailView;
import com.mwee.android.pos.business.netorder.NetOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/3/22.
 * 消息中心-网络订单页
 */
public class MessageNetOrderFragment extends BaseListHomeFragment<TempAppOrder> implements IDriver {

    public static final String TAG = MessageOrderFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "messageNetOrder";

    private NetOrderDetailView net_order_detail;
    private String chosedMsgId = "-1";
    private int currentPage = 1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!MessageNetOrderFragment.this.isVisible()) {
            return;
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    /**
     * 更新某一条记录
     *
     * @param tempAppOrder
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshTempApporder", UIThread = true)
    public void refreshTempApporder(TempAppOrder tempAppOrder) {
        if (tempAppOrder == null) {
            return;
        }
        updateData(tempAppOrder);
    }

    /**
     * 更新显示列表
     */
    private void updateData(TempAppOrder tempAppOrder) {
        if (!ListUtil.isEmpty(modules)) {
            int index = -1;
            for (int i = 0; i < modules.size(); i++) {
                TempAppOrder order = modules.get(i);
                if (TextUtils.equals(order.orderId, tempAppOrder.orderId)) {
                    index = i;
                    break;
                }
            }

            if (index > -1) {
                modules.remove(index);
                modules.add(index, tempAppOrder);
            } else {
                modules.add(0, tempAppOrder);
            }
            adapter.notifyItemChanged(index);
//            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_message_net_order;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new NetOrderMsgHolder(LayoutInflater.from(getContext()).inflate(R.layout.message_net_order_item, parent, false));
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        net_order_detail = view.findViewById(R.id.net_order_detail);
        net_order_detail.setHost(this);
        net_order_detail.setVisibility(View.GONE);

        if (AppCache.getInstance().isRetailMode()) {//小易2.2 修改样式
            ViewGroup root = view.findViewById(R.id.lyt_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            mPullRecyclerView.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root, getResources().getColor(R.color.color_656565));
        }
    }

    @Override
    protected void initData() {
        super.initData();

        refreshPhoneDowngradeStatus();

        mPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    private void refreshPhoneDowngradeStatus() {
        NetOrderClientUtil.updateMessageMeituanDowngradeDealStatus();
    }

    private void loadDataFromServer(int mode) {
        NetOrderClientUtil.getOrderList(currentPage, new ResultCallback<GetAllNetOrderResponse>() {
            @Override
            public void onSuccess(GetAllNetOrderResponse data) {
                if (isAdded()) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.tempAppOrderList)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshAdapter(data.tempAppOrderList);
                        refreshDetail();
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                BaseToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                super.onFailure(code, msg);
            }
        });
    }

    public void refreshAdapter(List<TempAppOrder> data) {
        modules.addAll(data);
        adapter.notifyDataSetChanged();
    }

    private void refreshDetail() {
//        TempAppOrder bean = null;
//        //查查当前选中在不在列表中
//        for (TempAppOrder messageOrderBean : modules) {
//            if (TextUtils.equals(messageOrderBean.orderId, chosedMsgId)) {
//                bean = messageOrderBean;
//                break;
//            }
//        }

        int pos = -1;
        for (int i = 0; i < modules.size(); i++) {
            if (TextUtils.equals(modules.get(i).orderId, chosedMsgId)) {
                pos = i;
                break;
            }
        }

//        if (bean != null) {
        if (pos >= 0) {
            clickItem(pos);
//            net_order_detail.updateData(bean);
//            net_order_detail.setVisibility(View.VISIBLE);
        } else {
            chosedMsgId = "-1";
            net_order_detail.setVisibility(View.INVISIBLE);
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup, int color) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof TextView) {
                ((TextView) view).setTextColor(color);
            }
        }
    }

    public void updateReadStatus(String orderId, int position) {
        ProgressManager.showProgress(getActivityWithinHost());
        NetOrderClientUtil.updateNetOrderTurnErrInfo(orderId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {

                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    if (TextUtils.equals(orderId, String.valueOf(modules.get(position).orderId))) {
                        modules.get(position).turnToReportErrStatus = 0;
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    ToastUtil.showToast(TextUtils.isEmpty(info) ? "修改已读状态失败" : info);
                }
            }
        });
    }

    class NetOrderMsgHolder extends BaseViewHolder {

        private TempAppOrder data;
        private View root;
        private TextView msg_order_item_no;
        private TextView msg_order_item_time;
        private TextView msg_order_item_source;
        private TextView msg_order_item_mobile;
        private TextView msg_order_item_amt;
        private TextView msg_order_item_status;
        private TextView msg_order_item_delivery_status;

        public NetOrderMsgHolder(View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.lyt_root);
            msg_order_item_no = itemView.findViewById(R.id.msg_order_item_no);
            msg_order_item_time = itemView.findViewById(R.id.msg_order_item_time);
            msg_order_item_source = itemView.findViewById(R.id.msg_order_item_source);
            msg_order_item_mobile = itemView.findViewById(R.id.msg_order_item_mobile);
            msg_order_item_amt = itemView.findViewById(R.id.msg_order_item_amt);
            msg_order_item_status = itemView.findViewById(R.id.msg_order_item_status);
            msg_order_item_delivery_status = itemView.findViewById(R.id.msg_order_item_delivery_status);
        }

        @Override
        public void bindData(int position) {
            data = modules.get(position);
            String time = DateUtil.formartDateStrToTarget(data.date, "yyyy-MM-dd HH:mm:ss", "HH:mm");
            msg_order_item_no.setText(data.orderId + "");
            msg_order_item_time.setText(time);
            msg_order_item_source.setText(NetOrder.getTackOutResouseName(data.orderTakeawaySource));
            msg_order_item_mobile.setText(data.distributionPhone);
            if ((TextUtils.equals(TakeAwaySource.MEITUAN, data.orderTakeawaySource) || TextUtils.equals("MEITUAN2", data.orderTakeawaySource))
                    && data.hasGetStatus()
                    && !data.distributionPhone.contains("_") && !data.distributionPhone.contains("*")) { // real phone number in MEITUAN
                msg_order_item_mobile.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_mobile, 0, 0, 0);
                msg_order_item_mobile.setCompoundDrawablePadding(24);
            }
            msg_order_item_amt.setText(Calc.formatShow(data.total));
            msg_order_item_status.setText(data.optOrderStatus());
            msg_order_item_delivery_status.setText(data.optDeliveryStatus());

            if (AppCache.getInstance().isRetailMode()) {
                if (TextUtils.equals(data.orderId, chosedMsgId)) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.system_red);
                    setTextColorOfViewGroup((ViewGroup) root, Color.WHITE);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.color_f9f9f9);
                    setTextColorOfViewGroup((ViewGroup) root, getResources().getColor(R.color.color_404040));
                }
            } else {
                int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                if (data.undealStatus() || (data.turnToReportErrStatus == -1) || ((data.orderStatus != -2) && (data.hasDeliveryInfo() && data.deliveryInfo.mwDeliveryStatus == -2) && DeliveryUtil.supportDeliveryCheck(data.orderTakeawaySource, "SF"))) {
                    colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                }
                msg_order_item_no.setTextColor(colorR);
                msg_order_item_time.setTextColor(colorR);
                msg_order_item_source.setTextColor(colorR);
                msg_order_item_mobile.setTextColor(colorR);
                msg_order_item_amt.setTextColor(colorR);
                msg_order_item_status.setTextColor(colorR);
                msg_order_item_delivery_status.setTextColor(colorR);
                if (TextUtils.equals(data.orderId, chosedMsgId)) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
                }
            }

            itemView.setOnClickListener(v -> clickItem(position));
        }
    }

    private void clickItem(int position) {
        chosedMsgId = modules.get(position).orderId;
        NetOrderClientUtil.optTempAppOrderFromBizById(chosedMsgId, new ResultCallback<OptNetOrderFromBizResponse>() {
            @Override
            public void onSuccess(OptNetOrderFromBizResponse data) {
                if (net_order_detail != null) {
                    net_order_detail.setVisibility(View.VISIBLE);
                    net_order_detail.updateData(data.tempAppOrder);
                    ActionLog.addLog("点击了 消息中心 外卖 条目", "", "", ActionLog.MESSAGE_TAKEAWAY, modules.get(position));
                }
                if (modules.get(position).turnToReportErrStatus != 0) {
                    //更新已读
                    updateReadStatus(String.valueOf(modules.get(position).orderId), position);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                BaseToastUtil.showToast(msg + "[" + code + "]");
                super.onFailure(code, msg);
            }
        });
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
