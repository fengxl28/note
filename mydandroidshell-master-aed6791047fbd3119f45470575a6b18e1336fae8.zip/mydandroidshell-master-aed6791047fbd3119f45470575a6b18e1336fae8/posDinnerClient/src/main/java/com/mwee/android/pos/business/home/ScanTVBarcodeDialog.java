package com.mwee.android.pos.business.home;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.tv.ScanBarcodeProcess;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by liuxiuxiu on 2017/8/9.
 * @author virgil
 */

public class ScanTVBarcodeDialog extends Dialog implements View.OnClickListener {

    public String shopName = "";
    private EditText edt_bar_code;
    private TextView tv_shopName;
    private Context context;

    public ScanTVBarcodeDialog(Context context) {
        super(context, R.style.scan_tv_barcode_theme);
        this.context = context;
    }

    public ScanTVBarcodeDialog(Context context, int themeResId) {
        super(context, themeResId);
        this.context = context;
    }

    protected ScanTVBarcodeDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        this.context = context;
    }

    public void setParam(String shopName) {
        this.shopName = shopName;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View contentView = View.inflate(context, R.layout.scan_tv_barcode_fragment, null);
        setContentView(contentView);

        tv_shopName = (TextView) findViewById(R.id.tv_shopName);
        tv_shopName.setText(shopName);

        edt_bar_code = (EditText) findViewById(R.id.edt_bar_code);
        edt_bar_code.addTextChangedListener(textWatcher);
        edt_bar_code.requestFocus();

        findViewById(R.id.btn_send_to_tv).setOnClickListener(this);
        findViewById(R.id.img_close).setOnClickListener(this);

        setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                KeyboardManager.closeSoftInput(BaseActivity.topActivity);
            }
        });
    }

    private String lastBarCode = "";
    private Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            dealNum();
        }
    };

    private void dealNum() {
        if (edt_bar_code == null) {
            return;
        }
        String barcode = edt_bar_code.getText().toString().trim();
        if (TextUtils.equals(barcode, lastBarCode) && barcode.length() > 5) {
            edt_bar_code.removeTextChangedListener(textWatcher);
            edt_bar_code.setText("");
            edt_bar_code.addTextChangedListener(textWatcher);
            barcode = barcode.replaceAll("＊", "*");
            ActionLog.addLog("电视叫号  扫码读取到：" + barcode, ActionLog.TV);

            if (barcode.contains("*")) {
                scanBar(barcode);
                KeyboardManager.hideSoftInput(edt_bar_code);
            } else {
                inputBar(barcode);
            }
        }
        edt_bar_code.requestFocus();
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            handler.removeMessages(0);
            lastBarCode = s.toString().trim();
            handler.sendEmptyMessageDelayed(0, 600);
        }
    };

    private String checkFormat(String barcode) {
        if (TextUtils.isEmpty(barcode)) {
            return "请输入或扫描电视叫号条形码";
        }
        return "";
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_send_to_tv: //叫号
                handler.removeMessages(0);
                ActionLog.addLog("电视叫号  用户点击'呼叫'按钮", ActionLog.TV);
                //RunTimeLog.addLog(RunTimeLog.TV,"电视叫号  用户点击'呼叫'按钮");
                String barcode = edt_bar_code.getText().toString().trim();
                inputBar(barcode);
                edt_bar_code.removeTextChangedListener(textWatcher);
                edt_bar_code.setText("");
                edt_bar_code.addTextChangedListener(textWatcher);
                break;
            case R.id.img_close:
                RunTimeLog.addLog(RunTimeLog.TV, "电视叫号  用户点击'关闭'按钮，关闭页面", ActionLog.TV);
                KeyboardManager.hideSoftInput(edt_bar_code);
                dismiss();
                break;
            default:
                break;
        }
    }

    private void inputBar(String barcode) {
        String errMsg = checkFormat(barcode);
        if (TextUtils.isEmpty(errMsg)) {
            if (RegexUtil.checkNumber(barcode)){
                barcode = RegexUtil.formatNumber(StringUtil.toInt(barcode), 3);
            }
            if (!barcode.contains("*1")) {
                barcode = barcode + "*1" + AppCache.getInstance().fsShopGUID;
            }
            barcode = barcode.replaceAll("＊", "*");
            RunTimeLog.addLog(RunTimeLog.TV, "条码：" + barcode);
            ScanBarcodeProcess.getInstance().senCall(shopName, barcode);

        } else {
            ToastUtil.showToast(errMsg);
        }
    }

    private void scanBar(String barCode) {
        String errMsg = checkFormat(barCode);
        if (TextUtils.isEmpty(errMsg)) {
            barCode = barCode.replaceAll("＊", "*");
            RunTimeLog.addLog(RunTimeLog.TV, "条码：" + barCode);
            ScanBarcodeProcess.getInstance().senCall(shopName, barCode);
        } else {
            ToastUtil.showToast(errMsg);
        }
    }


}

