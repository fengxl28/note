package com.mwee.android.pos.base;

/**
 * @ClassName: OverHomeFragment
 * @Description:
 * @author: SugarT
 * @date: 2018/1/12 下午2:06
 */
public class OverHomeFragment extends BaseFragment {
}
