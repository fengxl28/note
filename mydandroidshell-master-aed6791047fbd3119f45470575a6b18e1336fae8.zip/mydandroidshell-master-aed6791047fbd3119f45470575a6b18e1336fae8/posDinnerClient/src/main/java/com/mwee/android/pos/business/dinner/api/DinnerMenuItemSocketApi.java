package com.mwee.android.pos.business.dinner.api;


import android.os.Handler;
import android.os.Looper;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.BatchCopyDishesResponse;
import com.mwee.android.pos.connect.business.bean.BatchReturnDishesResponse;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.MenuItemOperateAction;
import com.mwee.android.pos.connect.business.bean.OperateDishParameter;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.bean.model.CopyDiffModel;
import com.mwee.android.pos.connect.business.discount.DoDiscountResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CDinnerFoodMenu;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.NumberUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 菜品操作同步业务中心相关接口
 * Created by qinwei on 2017/5/31.
 */

public class DinnerMenuItemSocketApi {

    /**
     * 称重菜称重改数量请求
     *
     * @param orderId  订单id
     * @param uniq     点菜唯一标示
     * @param buyNum   点菜数量
     * @param callback 回调
     */
    public static void loadUpdateMenuItemBuyNumber(String orderId, String uniq, BigDecimal buyNum, ConCallBack<UpdateBuyNumResponse> callback) {
        MCon.c(CDinnerFoodMenu.class, callback).loadUpdateMenuItemBuyNumber(orderId, uniq, buyNum);
    }


    /**
     * 批量退菜
     *
     * @param orderId  订单id
     * @param callback sendResponse in main thread
     */
    public static void loadReturnDishes(String orderId, List<VoidMenuItemModel> voidMenuItemModels, final ResultCallback<OrderCache> callback) {
        MCon.c(CDinnerFoodMenu.class, new ConCallBack<BatchReturnDishesResponse>() {
            @Override
            public void subCall(SocketResponse<BatchReturnDishesResponse> response) {
                if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }

            @Override
            public void callback(SocketResponse<BatchReturnDishesResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (callback != null) {
                        callback.onSuccess(response.data.orderCache);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }
        }).loadReturnDishes(orderId, voidMenuItemModels);
    }

    /**
     * 退单个菜品
     *
     * @param orderId           退菜订单
     * @param voidMenuItemModel 退菜信息
     * @param callback          异步监听
     */
    public static void loadReturnDish(String orderId, VoidMenuItemModel voidMenuItemModel, final ResultCallback<OrderCache> callback) {
        List<VoidMenuItemModel> voidMenuItemModels = new ArrayList<>();
        voidMenuItemModels.add(voidMenuItemModel);
        loadReturnDishes(orderId, voidMenuItemModels, callback);
    }

    /**
     * 催菜请求
     *
     * @param orderId          订单id
     * @param seq              菜品唯一标示
     * @param businessCallBack sendResponse in subThread
     * @param iResult          sendResponse in main thread
     */
    public static void loadRemindersDish(String orderId, String seq, SocketThreadCallback<OperateDishToCenterResponse> businessCallBack, final IResult iResult) {
        List<String> seqList = new ArrayList<>();
        seqList.add(seq);
        loadRemindersDish(orderId, seqList, iResult, businessCallBack);
    }

    /**
     * 催菜请求--批量
     */
    public static void loadRemindersDish(String orderId, List<String> seqList, final IResult iResult, SocketThreadCallback<OperateDishToCenterResponse> businessCallBack) {
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_HURRY);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, iResult);
    }

    /**
     * 更改时价菜请求
     *
     * @param orderId          销售单id
     * @param seq              消费菜品明细id
     * @param fdSalePrice      修改价格
     * @param iResult          sendResponse in main thread
     * @param businessCallBack 异步任务监听处理 sendResponse in subThread
     */
    public static void loadUpdateDishPrice(String orderId, String seq, BigDecimal fdSalePrice, SocketThreadCallback<OperateDishToCenterResponse> businessCallBack, IResult iResult) {
        List<String> seqList = new ArrayList<>();
        seqList.add(seq);
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_CHANGE_PRICE);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.changePrice = fdSalePrice;//时价菜价格
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, iResult);
    }


    /**
     * 起菜请求
     *
     * @param orderId 订单id
     * @param seq     点菜菜品唯一标示
     * @param iResult sendResponse in main thread
     */
    public static void loadDoDish(String orderId, String seq, IResult iResult) {
        List<String> uniqList = new ArrayList<>();
        uniqList.add(seq);
        loadDoDish(orderId, uniqList, iResult);
    }

    /**
     * 起菜请求---支持批量操作
     *
     * @param orderId 订单id
     * @param seqList 批量操作菜品唯一标示集合
     * @param iResult sendResponse in main thread
     */
    public static void loadDoDish(String orderId, List<String> seqList, IResult iResult) {
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_DO_DISHES);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, iResult);
    }

    /**
     * 划菜请求---支持批量操作
     *
     * @param orderId 订单id
     * @param seqList 批量操作菜品唯一标示集合
     * @param iResult sendResponse in main thread
     */
    public static void paddleDoDish(String orderId, List<String> seqList, IResult iResult) {
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_PADDLE);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, iResult);
    }

    /**
     * 划菜
     *
     * @param orderId       String | 订单号
     * @param menuWithCount ArrayMap |
     * @param iResult
     */
    public static void paddleDoDishV2(String orderId, android.util.ArrayMap<String, BigDecimal> menuWithCount, IResult iResult) {
        MCon.c(CDinnerFoodMenu.class, new ConCallBack<OperateDishToCenterResponse>() {
            @Override
            public void callback(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.message);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.message);
                    }
                }
            }

            @Override
            public void subCall(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }
        }).delimit(orderId, menuWithCount);
    }

    /**
     * 复制菜品
     *
     * @param orderId        订单Id
     * @param targetTableIds
     * @param iResult
     */
    public static void copyDishes(String orderId, List<String> targetTableIds, IResult iResult) {
        MCon.c(CDinnerFoodMenu.class, new ConCallBack<BatchCopyDishesResponse>() {
            @Override
            public void callback(SocketResponse<BatchCopyDishesResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, "业务异常，请重试");
                    }
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.message);
                    }
                    DriverBus.call("main/jump", MAIN_TAB.TABLE);

                    String text = buildCopyDiffText(response.data.copyDiffMap, response.data.occupiedTableNameList);
                    if (!TextUtils.isEmpty(text)) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Host host = BaseActivity.topActivity;
                                if (host != null) {
                                    DialogManager.showSingleDialog(host, text, "提示", "确定", null);
                                }
                            }
                        }, 1000);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.message);
                    }
                }
            }

            @Override
            public void subCall(SocketResponse<BatchCopyDishesResponse> response) {
                if (response != null && response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }
        }).batchCopyDishes(orderId, targetTableIds);
    }

    /**
     * 构建复制导致的数量差额文字提示
     */
    private static String buildCopyDiffText(ArrayMap<String, List<CopyDiffModel>> copyDiffMap, List<String> occupiedTableNameList) {
        StringBuilder textBuilder = new StringBuilder();

        if (copyDiffMap != null && copyDiffMap.size() > 0) {
            for (String key : copyDiffMap.keySet()) {
                if (TextUtils.isEmpty(key) || ListUtil.isEmpty(copyDiffMap.get(key))) {
                    continue;
                }
                textBuilder.append(key).append("桌沽清菜品：");
                for (CopyDiffModel copyDiff : copyDiffMap.get(key)) {
                    if (copyDiff == null || copyDiff.diffNum.compareTo(BigDecimal.ZERO) <= 0) {
                        continue;
                    }
                    textBuilder.append(String.format("%s(%s%s)、", copyDiff.itemName, NumberUtils.subZeroAndDot(copyDiff.diffNum), copyDiff.fsOrderUint));
                }
                textBuilder.deleteCharAt(textBuilder.length() - 1);
                textBuilder.append(";\n\n");
            }
        }

        if (!ListUtil.isEmpty(occupiedTableNameList)) {
            if (textBuilder.length() > 0) {
                textBuilder.append("\n\n");
            }
            textBuilder.append("因桌台已被占用，");
            for (String tableName : occupiedTableNameList) {
                if (TextUtils.isEmpty(tableName)) {
                    continue;
                }
                textBuilder.append(tableName).append("、");
            }
            textBuilder.deleteCharAt(textBuilder.length() - 1);
            textBuilder.append("未复制成功");
        }

        return textBuilder.toString();
    }

    /**
     * 菜品操作封装
     *
     * @param parameter 请求参数封装
     * @param iResult   sendResponse in main thread
     */
    private static void loadOperateDish(OperateDishParameter parameter, final IResult iResult) {
        MCon.c(CDinnerFoodMenu.class, new ConCallBack<OperateDishToCenterResponse>() {
            @Override
            public void callback(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.message);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.message);
                    }
                }
            }

            @Override
            public void subCall(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    //业务中心打印不了的打印任务id 交给本地打印进程打印
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }
        }).loadOperateDish(parameter.orderID, parameter.menuUniq, parameter.operateType, parameter.privllegeUser, parameter.changeNum, parameter.changePrice);
    }

    /**
     * 加减配料菜请求
     *
     * @param orderId 订单id
     * @param newItem 修改后菜品信息
     * @param iResult call in main thread
     */
    public static void loadChangeIngredient(String orderId, MenuItem newItem, List<MenuItem> addedMenuItem, List<MenuItem> deletedMenuItem, final IResponse<OrderCache> iResult) {
        MCon.c(CDinnerFoodMenu.class, new SocketCallback<ChangeIngredientResponse>() {
            @Override
            public void callback(SocketResponse<ChangeIngredientResponse> response) {

                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.code, "", response.data.orderCache);
                    }
                    if (response.data != null && !ListUtil.isEmpty(response.data.printTaskIds)) {
                        //业务中心打印不了的打印任务id 交给本地打印进程打印
                        PrintReceiptUtil.addPrintNo(response.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadChangeIngredient(orderId, newItem, addedMenuItem, deletedMenuItem);
    }

    /**
     * 加、退套餐子项
     *
     * @param orderId         订单id
     * @param newItem         修改后套餐
     * @param addedMenuItem   加菜列表
     * @param deletedMenuItem 退菜列表
     * @param updatedMenuItem 更新的菜品列表（要求/做法更新）
     * @param iResult
     */
    public static void loadChangePackageItems(String orderId, MenuItem newItem, List<MenuItem> addedMenuItem, List<MenuItem> deletedMenuItem, List<MenuItem> updatedMenuItem, final IResponse<OrderCache> iResult) {
        MCon.c(CDinnerFoodMenu.class, new SocketCallback<ChangePackageItemsResponse>() {
            @Override
            public void callback(SocketResponse<ChangePackageItemsResponse> response) {

                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.code, "", response.data.orderCache);
                    }
                    if (response.data != null && !ListUtil.isEmpty(response.data.printTaskIds)) {
                        //业务中心打印不了的打印任务id 交给本地打印进程打印
                        PrintReceiptUtil.addPrintNo(response.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadChangePackageItems(orderId, newItem, addedMenuItem, deletedMenuItem, updatedMenuItem);
    }

    /**
     * 处理菜品折扣
     *
     * @param orderID            订单id
     * @param ids                菜品id集合
     * @param isUseMember        是否使用会员价格
     * @param isUseGift          是否赠送
     * @param menuItemDiscountId 菜品折扣id
     * @param orderDiscountId    订单折扣id
     * @param callback           回调
     */
    public static void loadUpdateMenuItemDiscount(List<MenuItem> menuList, String tableID, String orderID, ArrayList<String> ids, boolean isUseMember,
                                                  boolean isForceMemPrice, boolean isUseGift, boolean cleanAllDiscount, String menuItemDiscountId,
                                                  String orderDiscountId, String reason, ArrayMap<String, BigDecimal> giftInfo, final DinnerMultiDiscountCallBack callback) {
        MCon.c(CDinnerFoodMenu.class, (SocketCallback<DoDiscountResponse>) response -> {
            if (response == null) {
                callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                return;
            }
            if (response.code == SocketResultCode.SUCCESS) {
                callback.call(response.data.orderCache, response.data.tempMenu);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadUpdateMenuItemDiscount(menuList, tableID, orderID, orderDiscountId, menuItemDiscountId, cleanAllDiscount, ids, reason, isUseGift, isUseMember, isForceMemPrice, giftInfo);
    }

    /**
     * 处理菜品折扣
     *
     * @param menuList           List<MenuItem> | 临时订单的菜品集合
     * @param tableID            String | 桌台ID
     * @param orderID            String | 订单号   已下单订单才有
     * @param ids                List<String> | 本次要操作的菜品uniq值集合
     * @param isUseMember        boolean|是否使用会员价
     * @param isForceMemPrice
     * @param isUseGift          boolean | 是否赠送
     * @param cleanAllDiscount   boolean | 是否清空所有优惠与折扣
     * @param menuItemDiscountId String | 被选中折扣的ID
     * @param orderDiscountId    String | 整单立减折扣的ID
     * @param reason             String | 赠送、折扣理由
     * @param customRate         BigDecimal | 自定义折扣率
     * @param customAmt          BigDecimal | 自定义折扣金额
     * @param callback
     */
    public static void loadUpdateMenuItemDiscount(List<MenuItem> menuList, String tableID, String orderID, ArrayList<String> ids,
                                                  boolean isUseMember, boolean isForceMemPrice, boolean isUseGift,
                                                  boolean cleanAllDiscount, String menuItemDiscountId, String orderDiscountId,
                                                  String reason, BigDecimal customRate, BigDecimal customAmt, final DinnerMultiDiscountCallBack callback) {
        MCon.c(CDinnerFoodMenu.class, (SocketCallback<DoDiscountResponse>) response -> {
            if (response == null) {
                callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                return;
            }

            if (response.code == SocketResultCode.SUCCESS) {
                callback.call(response.data.orderCache, response.data.tempMenu);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadUpdateMenuItemDiscount(menuList, tableID, orderID, orderDiscountId, menuItemDiscountId, cleanAllDiscount,
                ids, reason, isUseGift, isUseMember, isForceMemPrice, customRate, customAmt, null, null, null);
    }

    /**
     * 处理菜品折扣
     *
     * @param menuList           List<MenuItem> | 临时订单的菜品集合
     * @param tableID            String | 桌台ID
     * @param orderID            String | 订单号   已下单订单才有
     * @param ids                List<String> | 本次要操作的菜品uniq值集合
     * @param isUseMember        boolean|是否使用会员价
     * @param isForceMemPrice
     * @param isUseGift          boolean | 是否赠送
     * @param cleanAllDiscount   boolean | 是否清空所有优惠与折扣
     * @param menuItemDiscountId String | 被选中折扣的ID
     * @param orderDiscountId    String | 整单立减折扣的ID
     * @param reason             String | 赠送、折扣理由
     * @param customRate         BigDecimal | 自定义折扣率
     * @param customAmt          BigDecimal | 自定义折扣金额
     * @param callback
     */
    public static void loadUpdateMenuItemDiscount(List<MenuItem> menuList, String tableID, String orderID, ArrayList<String> ids,
                                                  boolean isUseMember, boolean isForceMemPrice, boolean isUseGift,
                                                  boolean cleanAllDiscount, String menuItemDiscountId, String orderDiscountId,
                                                  String reason, BigDecimal customRate, BigDecimal customAmt,
                                                  Map<String, Map<String, List<String>>> buygiftRelation,
                                                  Map<String, List<String>> ingredientsMapping,
                                                  Map<String, List<String>> cleanCouponMapping,
                                                  final DinnerMultiDiscountCallBack callback) {
        MCon.c(CDinnerFoodMenu.class, (SocketCallback<DoDiscountResponse>) response -> {
            if (response.code == SocketResultCode.SUCCESS) {
                callback.call(response.data.orderCache, response.data.tempMenu);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadUpdateMenuItemDiscount(menuList, tableID, orderID, orderDiscountId, menuItemDiscountId,
                cleanAllDiscount, ids, reason, isUseGift, isUseMember, isForceMemPrice, customRate, customAmt,
                buygiftRelation, ingredientsMapping, cleanCouponMapping);
    }


    /**
     * @param menuList      未下单菜品集合
     * @param orderId       订单ID
     * @param fiitemCd      菜品ID
     * @param fiOrderUintCd 规格ID
     * @param callback
     */
    public static void doCleanGiftBuyInfoByOne(List<MenuItem> menuList, String orderId, String fiitemCd, String fiOrderUintCd, final DinnerMultiDiscountCallBack callback) {
        MCon.c(CDinnerFoodMenu.class, (SocketCallback<DoDiscountResponse>) response -> {
            if (response.code == SocketResultCode.SUCCESS) {
                callback.call(response.data.orderCache, response.data.tempMenu);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).doCleanGiftBuyInfoByOne(menuList, orderId, fiitemCd, fiOrderUintCd);
    }
}
