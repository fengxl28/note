package com.mwee.android.pos.business.fastfood.proccessor;

import android.text.TextUtils;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 17/2/24.
 */

public class FastFoodOrdersViewProcessor {

    /**
     * 一页显示的桌台数
     */
    public static int TABLE_COUNT_ONE_PAGE = 35;


    private int gridViewColNum = 7;

    public FastFoodOrdersViewProcessor() {
    }

    /**
     * 所有快餐未结账订单
     */
    public List<FastFoodSimpInfo> allFastFoodOrders = new ArrayList<>();

    /**
     * 当前展示的桌台
     */
    public List<FastFoodSimpInfo> fastFoodOrdersToShow = new ArrayList<>(15);

    /**
     * 更新所有桌台数据
     * 更新页面UI
     *
     * @param allDatas
     */
    public void updateAllOrderssData(List<FastFoodSimpInfo> allDatas) {
        //4
        allFastFoodOrders.clear();
        if (!ListUtil.listIsEmpty(allDatas)) {
            allFastFoodOrders.addAll(allDatas);
        }
        calculatePageMaxCount();
        //5
//        turnPage(0);
    }


    /**
     * 翻页
     *
     * @param curruntPage
     * @return false : 没有可翻页数据
     */
    public boolean turnPage(int curruntPage) {
        fastFoodOrdersToShow.clear();
        if (curruntPage * TABLE_COUNT_ONE_PAGE >= allFastFoodOrders.size()) {
            return false;
        }
        for (int i = curruntPage * TABLE_COUNT_ONE_PAGE; i < curruntPage * TABLE_COUNT_ONE_PAGE + TABLE_COUNT_ONE_PAGE; i++) {
            if (i < allFastFoodOrders.size()) {
                fastFoodOrdersToShow.add(allFastFoodOrders.get(i));
            } else {
                break;
            }
        }
        return true;
    }

    /**
     * 获取总页数
     *
     * @param fastFoodSimpInfos
     * @return
     */
    public int getTotalPages(List<FastFoodSimpInfo> fastFoodSimpInfos) {
        if (TABLE_COUNT_ONE_PAGE == 0) {
            TABLE_COUNT_ONE_PAGE = 1;
        }
        if (fastFoodSimpInfos != null && !fastFoodSimpInfos.isEmpty() && fastFoodSimpInfos.size() > 0) {
            int integer = fastFoodSimpInfos.size() / TABLE_COUNT_ONE_PAGE;
            int remainder = fastFoodSimpInfos.size() % TABLE_COUNT_ONE_PAGE;
            if (remainder > 0) {
                integer++;
            }
            return integer;
        } else {
            return 0;
        }
    }

    public void updateDatasCount(Host host) {
        gridViewColNum = host.getResourcesWithinHost().getInteger(R.integer.menu_grid_col_num);
        TABLE_COUNT_ONE_PAGE = 4 * gridViewColNum;
    }

    /**
     * 计算一页显示的桌台数
     */
    public void calculatePageMaxCount() {
        if (SettingHelper.habitGestureIsUD()) {
            TABLE_COUNT_ONE_PAGE = allFastFoodOrders.size() > 0 ? allFastFoodOrders.size() : 1;
        } else {
            TABLE_COUNT_ONE_PAGE = 5 * gridViewColNum;
        }
    }


    public List<String> lockOrderIds = new ArrayList<>();

    public void parseLockData(String data) {
        LogUtil.log("parseLockData 更改锁单状态，锁单id列表:" + data);
        lockOrderIds.clear();
        if (!data.equals("[]")) {
            String[] strs = data.substring(1, data.length() - 1).split(",");
            for (int i = 0; i < strs.length; i++) {
                lockOrderIds.add(strs[i]);
            }
        }
    }

    public boolean isLock(String orderId) {
        if (TextUtils.isEmpty(orderId)) {
            return false;
        }
        if (lockOrderIds.contains(orderId)) {
            LogUtil.log("parseLockData get orderId=" + orderId + ",已锁单");
        }
        return lockOrderIds.contains(orderId);
    }

    /**
     * 截取订单号后四位
     * @param orderId
     * @return
     */
    public String formatOrderId(String orderId){
        try {
            return orderId.substring(8);
        }catch (Exception e){
            RunTimeLog.addLog(RunTimeLog.FAST_ORDER,e.getMessage());
        }
        return "";
    }


}
