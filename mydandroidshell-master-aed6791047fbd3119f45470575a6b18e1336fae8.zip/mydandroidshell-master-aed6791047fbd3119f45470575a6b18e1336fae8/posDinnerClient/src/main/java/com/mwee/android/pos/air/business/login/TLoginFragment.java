//package com.mwee.android.pos.air.business.login;
//
//import android.content.Intent;
//import android.graphics.drawable.Drawable;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Looper;
//import android.os.SystemClock;
//import android.support.annotation.Nullable;
//import android.text.Editable;
//import android.text.TextUtils;
//import android.text.TextWatcher;
//import android.view.KeyEvent;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.inputmethod.EditorInfo;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//
//import com.mwee.android.base.GlobalCache;
//import com.mwee.android.base.task.ASyncExecute;
//import com.mwee.android.base.task.BusinessExecutor;
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseConfig;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.base.FragmentController;
//import com.mwee.android.pos.base.WriteJsonDataToDB;
//import com.mwee.android.pos.business.common.DataModel;
//import com.mwee.android.pos.business.login.component.LoginProcess;
//import com.mwee.android.pos.business.login.view.ChooseShiftFragment;
//import com.mwee.android.pos.business.setting.process.SettingProcessor;
//import com.mwee.android.pos.business.shift.ShiftPresenter;
//import com.mwee.android.pos.business.sync.ClientBindProcessor;
//import com.mwee.android.pos.business.sync.api.LocalDataProcessorForDinner;
//import com.mwee.android.pos.business.viceshow.ViceShowConnector;
//import com.mwee.android.pos.client.db.ClientMetaUtil;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.keyboard.KeyboardManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.connect.business.login.LoginToCenterForDinnerResponse;
//import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;
//import com.mwee.android.pos.connect.callback.ConCallBack;
//import com.mwee.android.pos.connect.callback.IResult;
//import com.mwee.android.pos.connect.callback.SocketCallback;
//import com.mwee.android.pos.connect.center.ServerConnector;
//import com.mwee.android.pos.connect.config.SocketResultCode;
//import com.mwee.android.pos.connect.framework.SocketResponse;
//import com.mwee.android.pos.db.APPConfig;
//import com.mwee.android.pos.db.ShopDBUtils;
//import com.mwee.android.pos.db.base.META;
//import com.mwee.android.pos.db.business.UserDBModel;
//import com.mwee.android.pos.db.business.bind.HostStatus;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.system.InspectActivity;
//import com.mwee.android.pos.util.ListUtil;
//import com.mwee.android.pos.util.SharedPreferencesUtil;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.util.UIHelp;
//import com.mwee.android.pos.util.ViewToolsUtil;
//import com.mwee.android.tools.DateUtil;
//import com.mwee.android.tools.LogUtil;
//import com.mwee.android.tools.OEM;
//import com.mwee.android.tools.ShellUtil;
//import com.mwee.android.tools.StringUtil;
//import com.mwee.android.tools.log.LogUpload;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * 登录页面
// * Created by zhangmin
// */
//public class TLoginFragment extends BaseFragment implements IDriver {
//
//    public static final String TAG = "logindinnerfragment";
//    private EditText loginAccount, loginPwd;
//    private View viewLoginCheck;
//    private UserDBModel currentUserDBModel = null;
//
//    private TextView mSynchronize;
//    private TextView tv_dinner_login_version_update;
//
//    /**
//     * 班别表数据
//     */
//
//    private List<DataModel> shiftList = new ArrayList<>();
//    private TextView tv_dinner_remind;
//
//    private Drawable mUpdate_icon;
//    private Drawable checkUpdateIcon;
//
//    private ShiftPresenter mShiftPresenter;
//
//    //用户信息数据
//    private List<UserDBModel> userDBModels = new ArrayList<>();
//    private Button btLogin;
//
//    @Override
//    public String getModuleName() {
//        return TAG;
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
//            savedInstanceState) {
//        View view = inflater.inflate(R.layout.t_login_fragment, container, false);
//        initUI(view);
//        return view;
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        checkUpdate();
//        checkRisk();
//        loadData();
//    }
//
//    @Override
//    public void onStart() {
//        super.onStart();
//        DriverBus.registerDriver(this);
//    }
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        DriverBus.unRegisterDriver(this);
//    }
//
//    /**
//     * 检查版本更新
//     */
//    public void checkUpdate() {
//        try {
//            boolean isNeedUpdate = DriverBus.call("login/checkUpdate", getActivityWithinHost());
//            if (isNeedUpdate) {
//                showCheckUpdateIcon();
//            } else {
//                hideCheckUpdateIcon();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public static long lastCheck = 0;
//
//    /**
//     * 检查可能存在的风险
//     */
//    private void checkRisk() {
//        BusinessExecutor.executeNoWait(new ASyncExecute() {
//            @Override
//            public Object execute() {
//                checkSunMiOsVersion();
//                return null;
//            }
//        });
//
//    }
//
//    /**
//     * 检测商米的版本是否是存在bug的版本
//     */
//    private void checkSunMiOsVersion() {
//        if (lastCheck == 0 || ((SystemClock.elapsedRealtime() - lastCheck) > 1000 * 60 * 60 * 2)) {
//            lastCheck = SystemClock.elapsedRealtime();
//            try {
//                if (OEM.isSunmiT1()) {
//                    ShellUtil.CommandResult checkVersionCodeResult = ShellUtil.execCommand("getprop 'ro.version.sunmi_versioncode'", false, true);
//                    if (checkVersionCodeResult.result == 0) {
//                        int versionCode = StringUtil.toInt(checkVersionCodeResult.responseMsg, 57);
//                        if (versionCode < 57) {
//                            new Handler(Looper.getMainLooper()).post(new Runnable() {
//                                @Override
//                                public void run() {
//                                    DialogManager.showSingleDialog(TLoginFragment.this, R.string.error_sumi_os_version, R.string.tips_all_right);
//                                }
//                            });
//                        }
//                    }
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    /**
//     * 检查营业日期是否正确
//     */
//    private void checkBusinessDate(boolean isFinishedBiz) {
//        final String businessDate = AppCache.getInstance().businessDate;
//        if (TextUtils.isEmpty(businessDate)) {
//            return;
//        }
//        final String currentDate = DateUtil.getCurrentDate("yyyy-MM-dd");
//        boolean wrongDate = false;
//        if (DateUtil.compareDate(currentDate, "2017-09-01", "yyyy-MM-dd") > 0) {
//            wrongDate = true;
//        }
//        //已打烊的，或者副站点，就不判断营业日期了
//        if (!isFinishedBiz && ClientBindProcessor.isCurrentHostMain()) {
//            if (!wrongDate && DateUtil.compareDate(businessDate, "2017-06-15", "yyyy-MM-dd") > 0) {
//                wrongDate = true;
//            }
//            if (!wrongDate && DateUtil.compareDate(businessDate, currentDate, "yyyy-MM-dd") != 0) {
//                wrongDate = true;
//            }
//        }
//        if (wrongDate) {
//            DialogManager.showExecuteDialog(this, R.string.error_wring_business_date, businessDate, currentDate, new DialogResponseListener() {
//                @Override
//                public void response() {
//                    final Progress progress = ProgressManager.showProgressUncancel(TLoginFragment.this, R.string.login_shop_closing);
//                    mShiftPresenter.doClose(new IResult() {
//                        @Override
//                        public void callBack(boolean result, String info) {
//                            progress.dismiss();
//                            if (result) {
//                                ToastUtil.showToast(R.string.login_shop_closed);
//                            } else {
//                                DialogManager.showSingleDialog(TLoginFragment.this, info, getString(R.string.i_see));
//                            }
//                        }
//                    });
//                }
//            }, null);
//        }
//    }
//
//    //显示更新
//    @DrivenMethod(uri = TAG + "/showUpdate", UIThread = true)
//    public void showUpdate() {
//        mUpdate_icon.setBounds(0, 0, mUpdate_icon.getMinimumWidth(), mUpdate_icon.getMinimumHeight());
//        mSynchronize.setCompoundDrawables(mUpdate_icon, null, null, null); //设置左图标
//    }
//
//    //隐藏更新
//    @DrivenMethod(uri = TAG + "/hideUpdate", UIThread = true)
//    public void hideUpdate() {
//        mSynchronize.setCompoundDrawables(null, null, null, null);
//
//    }
//
//
//    //显示升级提示符号
//    public void showCheckUpdateIcon() {
//        checkUpdateIcon.setBounds(0, 0, checkUpdateIcon.getMinimumWidth(), checkUpdateIcon.getMinimumHeight());
//        tv_dinner_login_version_update.setCompoundDrawables(checkUpdateIcon, null, null, null); //设置左图标
//    }
//
//    //隐藏升级提示符号
//    public void hideCheckUpdateIcon() {
//        tv_dinner_login_version_update.setCompoundDrawables(null, null, null, null);
//
//    }
//
//    private void initUI(final View view) {
//        mShiftPresenter = new ShiftPresenter();
//
//
//        mUpdate_icon = ViewToolsUtil.getDrawable(R.drawable.bg_circle_update);
//        checkUpdateIcon = ViewToolsUtil.getDrawable(R.drawable.undeal);
//
//        loginAccount = (EditText) view.findViewById(R.id.et_loin_account);
//        loginPwd = (EditText) view.findViewById(R.id.et_login_pwd);
//        btLogin = (Button) view.findViewById(R.id.btLogin);
//        btLogin.setOnClickListener(click);
//        loginPwd.addTextChangedListener(textWatcher);
//        loginPwd.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
//                if (actionId == EditorInfo.IME_ACTION_GO) {
//                    loginClick();
//                }
//                return true;
//            }
//        });
//
//        String fsUserId = SharedPreferencesUtil.readObj(getContext(), TAG, String.class);
//        if (!TextUtils.isEmpty(fsUserId)) {
//            loginAccount.setText(fsUserId);
//        }
//
//        viewLoginCheck = view.findViewById(R.id.ll_login_check);
//
//        tv_dinner_remind = (TextView) view.findViewById(R.id.tv_dinner_remind);
//        mSynchronize = (TextView) view.findViewById(R.id.tv_dinner_login_syn);
//
//        tv_dinner_login_version_update = (TextView) view.findViewById(R.id.tv_dinner_login_version_update);
//        if (!BaseConfig.isProduct()) {
//            view.findViewById(R.id.dev).setVisibility(View.VISIBLE);
//            view.findViewById(R.id.dev).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    UIHelp.startDevelopActivity(getActivityWithinHost());
//                }
//            });
//            view.findViewById(R.id.systemCheck).setVisibility(View.VISIBLE);
//            view.findViewById(R.id.systemCheck).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    startActivity(new Intent(getActivityWithinHost(), InspectActivity.class));
//                }
//            });
//        }
//
//        if (TextUtils.equals("1", ClientMetaUtil.getSettingsValueByKey(META.UPDATE_NOTIFY))) {
//            showUpdate();
//        } else {
//            hideUpdate();
//        }
//
//        tv_dinner_login_version_update.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ActionLog.addLog("更多设置->点击了版本检测", "", "", ActionLog.SS_MORE_JOIN, "");
//                checkUpdate();
//            }
//        });
//
//        mSynchronize.setOnClickListener(click);
//    }
//
//
//    private void loadData() {
//        final Progress progress = ProgressManager.showProgress(TLoginFragment.this, R.string.tips_loding_data);
//        LoginProcess.getAlllLoginData(new SocketCallback<GetLoginDataResponse>() {
//            @Override
//            public void callback(SocketResponse<GetLoginDataResponse> response) {
//                progress.dismiss();
//                if (response.code == SocketResultCode.SUCCESS) {
//                    AppCache.getInstance().updateBusinessDate(response.data.businessDate);
//                    refreshLoginUserData(response.data.userDBModels);
//                    checkBusinessDate(response.data.shopStatus == HostStatus.FINISH);
//                } else if (response.code == SocketResultCode.VERSION_LOW) {
//                    DialogManager.showExecuteDialog(TLoginFragment.this, response.message, R.string.tips_cancel, R.string.tips_upgrade_now, new DialogResponseListener() {
//                        @Override
//                        public void response() {
//                            checkUpdate();
//                        }
//                    });
//                } else {
//                    DialogManager.showExecuteDialog(TLoginFragment.this, String.format("%1s：%2s", getString(R.string.error_failed_get_data), response.message), R.string.tips_cancel, R.string.tips_retry, new DialogResponseListener() {
//                        @Override
//                        public void response() {
//                            loadData();
//                        }
//                    });
//                }
//            }
//        });
//
//    }
//
//
//    /**
//     * 密码输入框监听
//     */
//    TextWatcher textWatcher = new TextWatcher() {
//        @Override
//        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//            viewLoginCheck.setVisibility(View.INVISIBLE);
//        }
//
//        @Override
//        public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//        }
//
//        @Override
//        public void afterTextChanged(Editable s) {
//            if (s.length() == 0) {
//                viewLoginCheck.setVisibility(View.INVISIBLE);
//                return;
//            }
//        }
//    };
//
//    private void refreshLoginUserData(List<UserDBModel> userDBModelList) {
//        if (ListUtil.isEmpty(userDBModelList)) {
//            userDBModelList = new ArrayList<>();
//            tv_dinner_remind.setVisibility(View.VISIBLE);
//        } else {
//            tv_dinner_remind.setVisibility(View.GONE);
//        }
//        userDBModels.clear();
//        userDBModels.addAll(userDBModelList);
//    }
//
//
//    View.OnClickListener click = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//
//            switch (v.getId()) {
//                case R.id.btLogin:
//
//                    loginClick();
//                    break;
//                case R.id.tv_dinner_login_syn: {
//                    /* 同步云端数据 */
//                    ActionLog.addLog("登录页：手动点击同步数据", ActionLog.USER_ACTION_TRACE);
//                    final Progress progress = ProgressManager.showProgress(TLoginFragment.this, R.string.login_sync_dataing, true);
//                    LocalDataProcessorForDinner.callUploadToCloud();
//                    if (!ClientBindProcessor.isCurrentHostMain()) {  //副站点同步业务中心数据
//                        DriverBus.call("login/sync_data_from_center", TLoginFragment.this, new IResult() {
//                            @Override
//                            public void callBack(boolean result, String info) {
//                                progress.dismiss();
//                                if (TextUtils.isEmpty(info)) {
//                                    ToastUtil.showToast(R.string.tips_sync_data_success);
//
//                                    ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
//                                    hideUpdate();
//                                    loadData();
//                                    APPConfig.fiWorkMode = ShopDBUtils.queryWorkMode(AppCache.getInstance().fsShopGUID);
//                                } else {
//                                    ToastUtil.showToast(info);
//                                }
//                            }
//                        });
//                        return;
//                    } else {  //业务中心同步后台数据
//                        ServerConnector.getInstance().sendExecute(new IResult() {
//                            @Override
//                            public void callBack(boolean result, String info) {
//                                progress.dismiss();
//                                if (TextUtils.isEmpty(info)) {
//                                    ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
//                                    hideUpdate();
//                                    loadData();
//                                    ToastUtil.showToast(R.string.tips_sync_data_success);
//                                    //更新门店模式
//                                    LoginProcess.loadWorkMode(new ResultCallback<Integer>() {
//                                        @Override
//                                        public void onSuccess(Integer data) {
//                                            APPConfig.fiWorkMode = data;
//                                        }
//                                    });
//                                } else {
//                                    ToastUtil.showToast(info);
//                                }
//                            }
//                        }, "biz/loadDataFromCenterForAir");
//                    }
//                    break;
//                }
//                default:
//                    break;
//            }
//        }
//    };
//
//
//    /**
//     * 点击了登录
//     */
//    private void loginClick() {
//        String loginInputName = loginAccount.getText().toString().trim();
//        if (TextUtils.isEmpty(loginInputName)) {
//            ToastUtil.showToast("请输入登录账号");
//            return;
//        }
//        String loginInputPwd = loginPwd.getText().toString().trim();
//        if (TextUtils.isEmpty(loginInputPwd)) {
//            ToastUtil.showToast("请输入登录密码");
//            return;
//        }
//
//        for (UserDBModel userDBModel : userDBModels) {
//            if (userDBModel.fsUserId.equalsIgnoreCase(loginInputName)) {
//                currentUserDBModel = userDBModel;
//                break;
//            }
//        }
//
//        if (currentUserDBModel != null && currentUserDBModel.fsUserId.trim().equalsIgnoreCase(loginInputName)) {
//            if (loginInputPwd.length() == currentUserDBModel.fsPwd.length()) {
//                if (currentUserDBModel.fsPwd.equalsIgnoreCase(loginInputPwd)) {
//                    KeyboardManager.hideSoftInput(loginPwd);
//                    doLogin(0, "", currentUserDBModel.fsUserId, loginInputPwd, currentUserDBModel.fsUserName);
//                } else {
//                    viewLoginCheck.setVisibility(View.VISIBLE);
//                }
//            } else {
//                viewLoginCheck.setVisibility(View.VISIBLE);
//            }
//
//        } else {
//            viewLoginCheck.setVisibility(View.VISIBLE);
//        }
//
//    }
//
//
//    private void doLogin(final int loginWay, final String fsiccardcode, final String fsUserId, final String fsPwd, final String fsUserName) {
//        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.login_logining);
//        LoginProcess.doLogin(fsUserId, fsPwd, fsiccardcode, fsUserName, AppCache.getInstance().currentHostId, loginWay, new ConCallBack<LoginToCenterForDinnerResponse>() {
//            @Override
//            public void subCall(SocketResponse<LoginToCenterForDinnerResponse> socketResponse) {
//                if (socketResponse.success()) {
//                    ClientMetaUtil.updateSettingsValueByKey(META.USER_SESSION, socketResponse.data.session);
//                    //餐厅设置部分数据操作放到后台执行
//                    SettingProcessor.updateSetting(socketResponse.data.dinnerLocalSettings, socketResponse.data.dinnerDBSettings);
//                    if (!TextUtils.isEmpty(socketResponse.data.datas)) {
//                        progress.updateText(R.string.login_loading_data);
//                        String dbDatas = socketResponse.data.datas;
//
//                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_CLIENT, dbDatas, socketResponse.data.newTimeTag);
//
//                        if (!TextUtils.isEmpty(dbDatas)) {
//                            AppCache.getInstance().refresh();
//                        }
//                    }
//                    AppCache.getInstance().updateCouponBargain(socketResponse.data.couponBargainList);
//                    //登录的时候初始化客显
//                    ViceShowConnector.getInstance().init(GlobalCache.getContext());
//                    LogUpload.updateSessoin(ClientMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID));
//                    LogUpload.setHost(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
//                    LogUtil.setOnlineDebugMode("1".equals(ClientMetaUtil.getConfig(META.XMPP_BBOX, "0")));
//                    progress.updateText(R.string.login_logining);
//                }
//            }
//
//            @Override
//            public void callback(final SocketResponse<LoginToCenterForDinnerResponse> response) {
//                if (response.code == SocketResultCode.SUCCESS) {
//                    loginPwd.setText("");
//                    ViceShowConnector.getInstance().startPlay();
//
//                    if (response.data.loginUser == null) {
//                        ToastUtil.showToast(R.string.login_failed);
//                        return;
//                    }
//                    AppCache.getInstance().userDBModel = response.data.loginUser;
//                    currentUserDBModel = AppCache.getInstance().userDBModel;
//
//                    if (TextUtils.isEmpty(response.data.currentSectionId)) {
//                        ToastUtil.showToast(R.string.error_login_section);
//                        return;
//                    }
//                    progress.dismiss();
//                    shiftList.clear();
//                    if (response.data.shiftList != null) {
//                        shiftList.addAll(response.data.shiftList);
//                    }
//                    if (!TextUtils.isEmpty(AppCache.getInstance().businessDate)) {
//                        if (TextUtils.equals(response.data.businessDate, AppCache.getInstance().businessDate)) {//判断业务中心返回的营业日期是否与本地营业日期相等
//                            jumtToNext(response.data.collectMoney);
//                        } else {//弹出营业日期校正窗口
//                            DialogManager.showSingleWithoutCancelable(getActivityWithinHost(), getString(R.string.login_business_date_fixed, ":" + response.data.businessDate),
//                                    new DialogResponseListener() {
//                                        @Override
//                                        public void response() {
//                                            AppCache.getInstance().updateBusinessDate(response.data.businessDate);
//                                            jumtToNext(response.data.collectMoney);
//                                        }
//                                    });
//                        }
//                    } else {//当前站点的营业日期为空
//                        AppCache.getInstance().updateBusinessDate(response.data.businessDate);
//                        jumtToNext(response.data.collectMoney);
//                    }
//
//                } else {
//                    if (response.code == -1) {//主站点没有营业
//                        ToastUtil.showToast(response.message);
//                    } else if (response.code == 202 || response.code == 203) {  //IC卡错误、账户名称错误、密码错误或者账号被禁用
//                        loadData();
//                        ToastUtil.showToast(response.message);
//                    } else if (response.code == 204
//                            && !ClientBindProcessor.isCurrentHostMain()) {  //站点被删除--若当前站点是业务中心则忽略
//                        DialogManager.showExecuteDialog(TLoginFragment.this, R.string.error_host_cannot_use, R.string.tips_cancel, R.string.tips_rebind, new DialogResponseListener() {
//                            @Override
//                            public void response() {
//                                // 重新指定站点
//                                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, "");
//                                UIHelp.reLaunch(getActivityWithinHost());
//                                getActivityWithinHost().finish();
//                            }
//                        });
//
//
//                    } else if (response.code == SocketResultCode.VERSION_LOW) {
//                        DialogManager.showExecuteDialog(TLoginFragment.this, response.message, R.string.tips_cancel, R.string.tips_upgrade_now, new DialogResponseListener() {
//                            @Override
//                            public void response() {
//                                checkUpdate();
//                            }
//                        });
//                    } else if (response.code == SocketResultCode.SHOP_DATA_EXPIRED) {
//                        ToastUtil.showToast(response.message);
//                        loadData();
//                    } else {
//                        ToastUtil.showToast(response.message);
//                    }
//                    progress.dismiss();
//                }
//            }
//        });
//    }
//
//    private void jumtToNext(boolean collectMoney) {
//        AppCache.getInstance().collectMoney = collectMoney;
//        //登录之后，可能会刷新营业日期，所以这里必须刷新MenuCache
//
//        ActionLog.waiterID = AppCache.getInstance().userDBModel.fsUserId;
//        ActionLog.waiterName = AppCache.getInstance().userDBModel.fsUserName;
//        ActionLog.addLog("登录成功", "", "", ActionLog.LOGIN, ActionLog.waiterID);
//
//        SharedPreferencesUtil.saveObj(getContext(), currentUserDBModel.fsUserId, TAG);//存储上次登录的用户名和密码
//        if (collectMoney) {//收银权限
//            jumpToShift();
//        } else {
//            String orderModel = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, "");
//            if (AppCache.getInstance().isRetailMode() && TextUtils.isEmpty(orderModel)) {
//                UIHelp.startAirOrderModelActivity(getActivityWithinHost());
//                getActivityWithinHost().finish();
//            } else {
//                UIHelp.startAirHomeActivity(getActivityWithinHost());
//                getActivityWithinHost().finish();
//            }
//        }
//    }
//
//    private void jumpToShift() {
//        ChooseShiftFragment shit = ChooseShiftFragment.newInstance(shiftList);
//        FragmentController.addFragmentWithHide(getActivityWithinHost(), shit, R.id.login_fragment_container);
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        ServerConnector.getInstance().removeCallback("biz/loadDataFromCenterForAir");
//    }
//}
