package com.mwee.android.pos.air.business.menu.processor;

import com.mwee.android.air.connect.business.menu.MenuItemAddResponse;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.menu.api.MenuManagerApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/11.
 */

public class MenuProcessor {
    public void loadMenuItemsByClsId(String fsMenuClsId, final ResultCallback<List<MenuItemBean>> callback) {
        MenuManagerApi.loadMenuItemsByClsId(fsMenuClsId, new SocketCallback<MenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<MenuItemsResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    callback.onSuccess(response.data.menuItemBeanList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadUpdateMenuInfo(String fiItemCd, String menuClsId, String fiOrderUintCd, String name, String unitName, String price, String memberPrice, String repertoryNumber
            , boolean isCanDiscount, boolean isCanGift, boolean isCanTimePrice, boolean isCanWeight, boolean isCanOutTake,boolean isCanPrinter
            , final ResultCallback<String> callback) {
        MenuManagerApi.loadUpdateMenuInfo(fiItemCd, menuClsId, fiOrderUintCd, name, unitName, price, memberPrice, repertoryNumber
                ,isCanDiscount,isCanGift,isCanTimePrice,isCanWeight,isCanOutTake, isCanPrinter
                , new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadAddMenuInfo(String fsMenuClsId, String name, String unitName, String price, String memberPrice, String repertoryNumber
            , boolean isCanDiscount, boolean isCanGift, boolean isCanTimePrice, boolean isCanWeight, boolean isCanOutTake,boolean isCanPrinter
            , final ResultCallback<MenuItemAddResponse> callback) {
        MenuManagerApi.loadAddMenuInfo(fsMenuClsId, name, unitName, price, memberPrice, repertoryNumber
                ,isCanDiscount,isCanGift,isCanTimePrice,isCanWeight,isCanOutTake,isCanPrinter,0
                , new SocketCallback<MenuItemAddResponse>() {
            @Override
            public void callback(SocketResponse<MenuItemAddResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadBatchDelete(ArrayList<String> choiceStates, final ResultCallback<String> callback) {
        MenuManagerApi.loadBatchDeleteMenuItems(choiceStates, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

}
