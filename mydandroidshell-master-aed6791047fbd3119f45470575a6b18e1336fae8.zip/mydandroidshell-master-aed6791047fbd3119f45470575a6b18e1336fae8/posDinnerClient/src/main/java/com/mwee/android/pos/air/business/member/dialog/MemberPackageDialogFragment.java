package com.mwee.android.pos.air.business.member.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.entity.MemberPackageModel;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/19.
 */

public class MemberPackageDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private EditText etPackageRechargeMondy;
    private EditText etPackageGiftMondy;
    private EditText etPackageGiftScore;

    private Button mMemberCancelBtn;
    private Button mMemberConfirmBtn;

    private MemberPackageModel model;

    private OnMemberLevelEditorListener listener;
    private TextView tvPackageTitle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_package_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }


    private void initView(View view) {

        tvPackageTitle = view.findViewById(R.id.tvPackageTitle);
        etPackageRechargeMondy = view.findViewById(R.id.etPackageRechargeMondy);
        etPackageGiftMondy = view.findViewById(R.id.etPackageGiftMondy);
        etPackageGiftScore = view.findViewById(R.id.etPackageGiftScore);

        mMemberCancelBtn = (Button) view.findViewById(R.id.mMemberCancelBtn);
        mMemberConfirmBtn = (Button) view.findViewById(R.id.mMemberConfirmBtn);

        mMemberCancelBtn.setOnClickListener(this);
        mMemberConfirmBtn.setOnClickListener(this);
    }

    private void initData() {

        if (isEditorModel()) {
            tvPackageTitle.setText("编辑充值套餐");
        } else {
            tvPackageTitle.setText("新建充值套餐");
        }
        if (isEditorModel()) {
            etPackageRechargeMondy.setText(new BigDecimal(model.money).intValue() + "");
            etPackageGiftMondy.setText(android.text.TextUtils.isEmpty(model.present_price) ? "" : new BigDecimal(model.present_price).intValue() + "");
            etPackageGiftScore.setText(android.text.TextUtils.isEmpty(model.present_score) ? "" : new BigDecimal(model.present_score).intValue() + "");
        }
    }

    private List<Integer> costMoneyCache = new ArrayList<>();

    public void setParam(MemberPackageModel model) {
        this.model = model;
    }

    public void setCostMoneyCache(List<Integer> costMoneyCache) {
        this.costMoneyCache = costMoneyCache;
    }


    public boolean isEditorModel() {
        return model != null;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMemberConfirmBtn:
                String money = etPackageRechargeMondy.getText().toString().trim();
                String present_price = etPackageGiftMondy.getText().toString().trim();
                String present_score = etPackageGiftScore.getText().toString().trim();

                if (!check(money)) {
                    return;
                }
                if (!isEditorModel()) {//添加模式 只需要比较充值金额和原有数据是否重复
                    if (costMoneyCache.contains(new BigDecimal(money).intValue())) {
                        ToastUtil.showToast(String.format("已存在%s元充值套餐，请配置其他金额", money));
                        return;
                    }
                } else {//编辑模式  比较编辑金额是否改变 并且 充值金额是否和原有数据是否重复
                    if (!android.text.TextUtils.equals(new BigDecimal(model.money).intValue() + "", money) && costMoneyCache.contains(new BigDecimal(money).intValue())) {
                        ToastUtil.showToast(String.format("已存在%s元充值套餐，请配置其他金额", money));
                        return;
                    }
                }

                if (isEditorModel()) {
                    doEditor(money, present_price, present_score);
                } else {
                    doAdd(money, present_price, present_score);
                }
                dismissSelf();
                break;
            case R.id.mMemberCancelBtn:
                dismissSelf();
                break;
            default:
                break;
        }
    }

    private void doAdd(String money, String present_price, String present_score) {

        MemberPackageModel modelAdd = new MemberPackageModel();
        modelAdd.money = money;
        modelAdd.present_price = present_price;
        modelAdd.present_score = present_score;
        listener.onMemberPackageAddSuccess(modelAdd);
    }


    private void doEditor(String money, String present_price, String present_score) {

        model.money = money;
        model.present_price = present_price;
        model.present_score = present_score;
        listener.onMemberPackageEditorSuccess(model);

    }


    private boolean check(String name) {
        if (!TextUtils.validate(name)) {
            ToastUtil.showToast("请输入充值金额!");
            return false;
        }
        if (new BigDecimal(name).intValue() == 0) {
            ToastUtil.showToast("充值金额必须大于0!");
            return false;
        }

        return true;
    }

    public void setOnMemberLevelEditorListener(OnMemberLevelEditorListener listener) {

        this.listener = listener;
    }

    public interface OnMemberLevelEditorListener {

        void onMemberPackageEditorSuccess(MemberPackageModel model);

        void onMemberPackageAddSuccess(MemberPackageModel model);
    }
}
