package com.mwee.android.pos.business.dinner.api;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.GetPrintDinnerPreBillResponse;
import com.mwee.android.pos.connect.business.order.PreMenuListResponse;
import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CDinnerFoodOrder;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * Created by qinwei on 2017/6/15.
 */
public class DinnerFoodOrderApi {

    /**
     * 下单并和桌台绑定
     *
     * @param orderDishesCache 点菜内容缓存
     * @param callback         异步回调
     */
    public static void orderAndOpenTable(TempOrderDishesCache orderDishesCache, boolean isPrinter, final ResultCallback<OrderCache> callback) {
        MCon.c(CDinnerFoodOrder.class, new SocketCallback<OpenTableAndCheckToOrderRespose>() {
            @Override
            public void callback(final SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse) {

                if (socketResponse == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                LogUtil.logOnlineDebug("--order--下单结束--MCon.c(CDinnerFoodOrder--orderAndOpenTable--code:"+socketResponse.code);

                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    //成功下单 更新菜品规格数据库 及 内存
                    if (!ListUtil.isEmpty(socketResponse.data.printTaskIds)) {//打印业务中心无法打印单小票任务
                        PrintReceiptUtil.addPrintNo(socketResponse.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                    callback.onSuccess(socketResponse.data.orderCache);
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }
            }
        }).orderAndOpenTable(orderDishesCache, AppCache.getInstance().fsShopGUID,
                AppCache.getInstance().currentHostId,
                AppCache.getInstance().userDBModel.fsUserId, isPrinter);
    }

    /**
     * 下单操作
     *
     * @param tempCache 临时订单缓存
     * @param orderID   订单id
     * @param isPrinter 是否打印相关小票
     * @param callback  异步回调
     */
    public static void orderToCenter(TempOrderDishesCache tempCache, String orderID, boolean isPrinter, final ResultCallback<OrderCache> callback) {
        tempCache.waiterID = AppCache.getInstance().userDBModel.fsUserId;
        tempCache.waiterName = AppCache.getInstance().userDBModel.fsUserName;
        MCon.c(CDinnerFoodOrder.class, new SocketCallback<OpenTableAndCheckToOrderRespose>() {
            @Override
            public void callback(SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse) {

                if (socketResponse == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                LogUtil.logOnlineDebug("--order--下单成功--orderToCenter--83--code:"+socketResponse.code);

                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    if (!ListUtil.isEmpty(socketResponse.data.printTaskIds)) {
                        PrintReceiptUtil.addPrintNo(socketResponse.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                    callback.onSuccess(socketResponse.data.orderCache);
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }

            }

        }).orderToCenter(tempCache, orderID, isPrinter);
    }

    /**
     * 预结账单
     */
    public static void printDinnerPreBill(String orderId, final String printerName, final ResultCallback<String> callback) {
        MCon.c(CDinnerFoodOrder.class, new ConCallBack<GetPrintDinnerPreBillResponse>() {
            @Override
            public void subCall(SocketResponse<GetPrintDinnerPreBillResponse> response) {
                if (response != null && response.data != null && !ListUtil.isEmpty(response.data.printNo)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNo, AppCache.getInstance().currentHostId);
                }
            }

            @Override
            public void callback(SocketResponse<GetPrintDinnerPreBillResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).printDinnerPreBill(orderId, printerName);
    }

    /**
     * 结帐前检查预点菜品
     *
     * @param orderID  订单id
     * @param callback 异步回调
     */
    public static void loadCheckDishOpenParamError(String orderID, final ResultCallback<String> callback) {
        MCon.c(CDinnerFoodOrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadCheckDishOpenParamError(orderID);
    }


    /**
     * 点菜预览单
     *
     * @param tempSelectedMenuList 临时单菜品
     * @param originMenuList       已点单菜品
     * @param printUser            打印用户
     * @param hostId               站点ID
     * @param fsSellNo             单号
     * @param fsMTableName         台位
     * @param fiCustSum            人数
     * @param fsSellDate           日期
     * @param currentSectionID     餐段代码
     * @return
     */
    public static void printPreMenuList(List<MenuItem> tempSelectedMenuList,
                                        List<MenuItem> originMenuList,
                                        String printUser,
                                        String hostId,
                                        String fsSellNo,
                                        String fsMTableName,
                                        String fiCustSum,
                                        String fsSellDate,
                                        String currentSectionID,
                                        SocketCallback<PreMenuListResponse> socketCallback) {
        MCon.c(CPrint.class, socketCallback).preMenuListRequest(tempSelectedMenuList, originMenuList, printUser, hostId, fsSellNo, fsMTableName, fiCustSum, fsSellDate, currentSectionID);
    }

}
