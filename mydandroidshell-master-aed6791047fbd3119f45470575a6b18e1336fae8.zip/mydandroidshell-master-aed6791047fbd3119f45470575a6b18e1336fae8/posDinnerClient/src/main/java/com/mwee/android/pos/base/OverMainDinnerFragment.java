package com.mwee.android.pos.base;

/**
 * 覆盖在主界面之上的页面
 *
 * Created by huangming on 2018/6/5.
 */

public class OverMainDinnerFragment extends BaseFragment {
}
