package com.mwee.android.pos.business.boot;

import android.Manifest;
import android.content.pm.PackageManager;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.ClientApplication;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.business.sync.view.BindSyncFragment;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.callback.ResultListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.permission.PermissionProcessor;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.syntherizer.SyntherizerHelper;
import com.mwee.android.pos.util.ClientHardwareUtil;
import com.mwee.android.pos.util.PlaySound;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.SdcardUtil;

import java.util.List;

/**
 * @ClassName: WelcomePresenter
 * @Description:
 * @author: SugarT
 * @date: 2017/11/21 下午6:11
 */
public class WelcomePresenter implements WelcomeContract.Presenter {

    private WelcomeContract.View mView;

    public WelcomePresenter(WelcomeContract.View view) {
        mView = view;
        mView.setPresenter(this);
    }

    @Override
    public void requestPermission() {
        final boolean[] noSdcardPermission = {false};
        if (!SdcardUtil.hasExternalStoragePermission(GlobalCache.getContext())) {
            noSdcardPermission[0] = true;
        }
        PermissionProcessor.applyPermission(mView.getNHost().getActivityWithinHost(), new ResultListener() {
            @Override
            public void callBack(int value) {
                if (value == PackageManager.PERMISSION_GRANTED) {
                    mView.grantedPermission();
                    if (noSdcardPermission[0]) {
                        ClientHardwareUtil.writeHardwareToSdcard();
                        noSdcardPermission[0] = false;
                    }
                    if(!SdcardUtil.isSDCardHasEnoughFreeSpace()){
                        ToastUtil.showToast(R.string.error_sdcard_space);
                    }
                } else {
                    String content = "";
                    content = mView.getNHost().getStringWithinHost(R.string.lack_permission);
                    if (!TextUtils.isEmpty(content)) {
                        PermissionProcessor.showMissingPermissionDialog(mView.getNHost(), content, new NormalListener() {
                            @Override
                            public void callBack() {
                                BootDistribution.exitApp(mView.getNHost());
                            }
                        }, "退出应用");
                    }
                }
            }
        }, Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
    }

    @Override
    public void startUgradeTransfer() {
        final Progress progress = ProgressManager.showProgressUncancel(mView.getNHost(), "正在升级数据");
        BusinessExecutor.executeAsyncExcuteOnMain(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                List<JSONObject> list = DBMetaUtil.getAllValue();
                ClientMetaUtil.updateSettings(list);
                ClientMetaUtil.deleteSettingsValueByKey(META.DATA_SYNC_TIME);
                ClientMetaUtil.deleteSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);

                ClientApplication.initBiz();
                return null;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                DriverBus.call("login/sync_data_from_center", mView.getNHost(), new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        progress.dismiss();
                        // LogBiz.log("餐厅正在营业-->直接开始营业");
                        ActionLog.addLog("餐厅正在营业-->直接开始营业", ActionLog.USER_ACTION_TRACE);
                        checkAndLoadData();
                    }
                });
            }
        });
    }

    @Override
    public void checkAndLoadData() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String token = ClientMetaUtil.getSettingsValueByKey(META.TOKEN);
        String seed = ClientMetaUtil.getSettingsValueByKey(META.SEED);
        String lastUpdateTime = ClientMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        String hostId = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
//        String serverToken = DBMetaUtil.getSettingsValueByKey(META.TOKEN);
//        String serverUpdateTime = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        String fromForceMain = ClientMetaUtil.getSettingsValueByKey(META.FORCE_SET_MAIN);

        boolean isActiveAndDownload = true;
        if (ClientBindProcessor.isCurrentHostMain()) {
            isActiveAndDownload = TextUtils.equals("1", ClientMetaUtil.getConfig(META.ACTIVE_AND_DOWNLOAD_FINISHED, "1"));
        }

//        if (!TextUtils.isEmpty(serverToken) && (TextUtils.isEmpty(token))) {
//            startUgradeTransfer();
//        } else
        if (TextUtils.isEmpty(token) || TextUtils.isEmpty(seed) || TextUtils.isEmpty(shopId) || !isActiveAndDownload) {
            //如果没有门店三要素,则跳转激活页面
            UIHelp.startBindShopActivity(mView.getNHost().getActivityWithinHost());
        } else if (TextUtils.isEmpty(hostId)) {
            //如果没有站点信息,则跳转到绑定站点页面
            UIHelp.startBindHostActivity(mView.getNHost().getActivityWithinHost());
        } else if (TextUtils.isEmpty(lastUpdateTime)) {
            //如果没有更新数据,则跳转到数据同步页面
            BindSyncFragment syncFragment = new BindSyncFragment();
            FragmentController.initFragment(mView.getNHost().getActivityWithinHost(), syncFragment, syncFragment.TAG);
        }
//        else if (TextUtils.equals(serverUpdateTime, "0") && TextUtils.equals("1", fromForceMain)) {
//            final Progress progress = ProgressManager.showProgressUncancel(mView.getNHost(), "正在为迁移而更新数据");
//
//            ServerConnector.getInstance().sendExecute(new IResult() {
//                @Override
//                public void callBack(boolean result, String info) {
//                    if (TextUtils.isEmpty(info)) {
//                        progress.updateText("正在更新订单数据");
//                        BusinessExecutor.executeNoWait(new ASyncExecute() {
//                            @Override
//                            public Object execute() {
//                                ForceSetAsMainHost.transferOrder();
//                                progress.dismiss();
//                                checkAndLoadData();
//                                return null;
//                            }
//                        });
//                    } else {
//                        progress.dismiss();
//                        ToastUtil.showToast(info);
//                        BootDistribution.exitApp(mView.getNHost());
//                    }
//                }
//            }, "biz/loadDataFromCenter");
//        }
        else {
            //正常启动流程
            //主站点且已打烊才可以更新菜品
//            if (ClientBindProcessor.isCurrentHostMain() && ClientHostUtil.getHostStatus(hostId) == HostStatus.FINISH) {
//                LogBiz.log("餐厅未开业-->检查是否需要同步网络数据");
//                updateData();
//            } else {
            final Progress progress = ProgressManager.showProgressUncancel(mView.getNHost(), "正在更新当前站点的数据");
            DriverBus.call("login/sync_data_from_center", mView.getNHost(), new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    progress.dismiss();
                    // LogBiz.log("餐厅正在营业-->直接开始营业");
                    ActionLog.addLog("餐厅正在营业-->直接开始营业", ActionLog.USER_ACTION_TRACE);
                    initDataAndToLogin();
                }
            });

//            }
            checkPrint(hostId);
            //启动电视叫号悬浮框
            DriverBus.call("login/showScanFloatView");
            //美团商家悬浮框
            DriverBus.call("login/showMeituanOverlay");
        }
        BusinessExecutor.executeNoWait(new ASyncExecute<Object>() {
            @Override
            public Object execute() {
                ActionLog.addLog(ActionLog.LOGIN, "应用启动：初始化百度语音合成");
//                SyntherizerHelper.init();
                PlaySound.newInstance();//不在这里启动，第一次回不播报
                return null;
            }
        });
    }

    @Override
    public void checkPrint(String hostId) {
        if (!ClientBindProcessor.isCurrentHostMain() && !TextUtils.isEmpty(hostId)) {
            PrintReceiptUtil.getUnPrintTaskNo(hostId);
        }
    }

    @Override
    public void initDataAndToLogin() {
        ProgressManager.showProgressUncancel(mView.getNHost(), "正在准备营业数据");
        BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                AppCache.getInstance().init();
                AppCache.getInstance().refresh();
                return true;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                mView.initDataCompleted();
            }
        });
    }
}
