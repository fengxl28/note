package com.mwee.android.pos.business.fastfood.domain;

import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/8/12.
 */

public class FastFoodDishCache extends Cache {
    public FastOrderModel fastOrderModel = new FastOrderModel();
    public ArrayList<MenuItem> menuItems = new ArrayList<>();
    public boolean antiPay;//是否反结帐
    /**
     * 临时的菜品选择数量
     */
    public ArrayMap<String, BigDecimal> tempSelectQuantity = new ArrayMap<>();

    /**
     * 点菜用,相关规格的选择数量
     */
    public ArrayMap<String, BigDecimal> tempUnitQuantity = new ArrayMap<>();

    /**
     * 快餐和正餐计算已点规格数量与已点菜品数量
     * 1.规格数量只计算未下单的菜品(用于菜品沽清判断)
     * 2.已点菜品数量计算未下单和已下单(用于菜单选择数量展示)
     */
    public void initSelectUnitQuantity() {
        tempSelectQuantity.clear();
        tempUnitQuantity.clear();
        List<MenuItem> temps = getFastFoodNotOrderMenuItems();//未下单的菜
        List<MenuItem> originMenus = getFastFoodOrderMenuItems();//已下单的菜
        //计算临时单已选菜品数量和规格数量
        if (temps != null && temps.size() > 0) {
            for (MenuItem menuItem : temps) {
                addTempSelectQuantity(menuItem.itemID, menuItem.supportWeight(), menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum));
                addTempUnitQuantity(menuItem.currentUnit.fiOrderUintCd, menuItem.menuBiz.buyNum);
                if (menuItem.supportPackage()) {//处理套餐已选数量
                    for (MenuItem selectedPackageItem : menuItem.menuBiz.selectedPackageItems) {
                        BigDecimal selectedPackageNum = selectedPackageItem.menuBiz.buyNum.multiply(menuItem.menuBiz.buyNum);
                        addTempSelectQuantity(selectedPackageItem.itemID, false, selectedPackageNum);//计算已点菜品数量
                        addTempUnitQuantity(selectedPackageItem.currentUnit.fiOrderUintCd, selectedPackageNum);//计算已选规格数量
                    }
                } else if (menuItem.supportIngredient()) {
                    for (MenuItem itemModifier : menuItem.menuBiz.selectedModifier) {
                        BigDecimal selectedModifierNum = menuItem.menuBiz.buyNum;
                        if (!menuItem.supportWeight()) {//称重菜配料点菜数量数量计算方法
                            selectedModifierNum = itemModifier.menuBiz.buyNum.multiply(menuItem.menuBiz.buyNum);
                        }
                        addTempSelectQuantity(itemModifier.itemID, false, selectedModifierNum);
                        addTempUnitQuantity(itemModifier.currentUnit.fiOrderUintCd, selectedModifierNum);
                    }
                }
            }
        }

        if (originMenus != null && originMenus.size() > 0) {
            //计算已点单已选菜品数量和规格数量
            for (MenuItem menuItem : originMenus) {
                addTempSelectQuantity(menuItem.itemID, menuItem.supportWeight(), menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum));
                if (menuItem.supportPackage()) {//处理套餐已选数量
                    for (MenuItem itemModifier : menuItem.menuBiz.selectedPackageItems) {
                        BigDecimal selectedPackageNum = itemModifier.menuBiz.buyNum.multiply(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum));
                        addTempSelectQuantity(itemModifier.itemID, false, selectedPackageNum);//计算已点菜品数量
                    }
                } else if (menuItem.supportIngredient()) {
                    for (MenuItem itemModifier : menuItem.menuBiz.selectedModifier) {
                        BigDecimal selectedModifierNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                        if (!menuItem.supportWeight()) {//称重菜配料点菜数量数量计算方法
                            selectedModifierNum = itemModifier.menuBiz.buyNum.multiply(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum));
                        }
                        addTempSelectQuantity(itemModifier.itemID, false, selectedModifierNum);
                    }
                }
            }
        }
    }

    /**
     * 添加菜品已选规格数量
     */
    public void addTempSelectQuantity(String itemId, boolean supportWeight, BigDecimal buyNum) {
        BigDecimal result = tempSelectQuantity.get(itemId);
        if (result == null) {
            result = BigDecimal.ZERO;
        }
        if (supportWeight) {
            if (buyNum.compareTo(BigDecimal.ZERO) > 0) {
                tempSelectQuantity.put(itemId, result.add(BigDecimal.ONE));
            }
        } else {
            tempSelectQuantity.put(itemId, result.add(buyNum));
        }
    }

    /**
     * 添加规格已选数量
     */
    public void addTempUnitQuantity(String uintId, BigDecimal buyNum) {
        if (tempUnitQuantity.containsKey(uintId)) {
            tempUnitQuantity.put(uintId, tempUnitQuantity.get(uintId).add(buyNum));
        } else {
            tempUnitQuantity.put(uintId, buyNum);
        }
    }


    /**
     * 删除快餐点菜条目
     *
     * @param menuItem
     */
    public void removeFastFoodMenuItem(MenuItem menuItem) {
        menuItems.remove(menuItem);
        initSelectUnitQuantity();
    }


    public void addFastFoodMenuItem(MenuItem menuItem) {
        addFastFoodMenuItem(menuItem, false);
    }

    /**
     * 快餐添加菜品
     *
     * @param menuItem
     * @param isLast   是否添加到末尾
     */
    public void addFastFoodMenuItem(MenuItem menuItem, boolean isLast) {
        if (isLast) {
            menuItems.add(menuItem);
        } else {
            menuItems.add(0, menuItem);
        }
        initSelectUnitQuantity();
    }

    /**
     * 快餐点菜界面 获取未下单菜品列表
     *
     * @return
     */
    public ArrayList<MenuItem> getFastFoodNotOrderMenuItems() {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        MenuItem item = null;
        for (int i = 0; i < this.menuItems.size(); i++) {
            item = this.menuItems.get(i);
            if (!fastOrderModel.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                menuItems.add(item);
            }
        }
        return menuItems;
    }

    /**
     * 快餐点菜界面 获取未下单菜品列表
     *
     * @return
     */
    public ArrayList<MenuItem> getFastFoodOrderMenuItems() {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        MenuItem item = null;
        for (int i = 0; i < this.menuItems.size(); i++) {
            item = this.menuItems.get(i);
            if (fastOrderModel.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                menuItems.add(item);
            }
        }
        return menuItems;
    }

    @Override
    public void refresh() {

    }

    @Override
    public void clean() {
        menuItems.clear();
        tempSelectQuantity.clear();
        tempUnitQuantity.clear();
    }

    public boolean isBindMember() {
        return fastOrderModel.isMember;
    }

    public String getOrderId() {
        if (fastOrderModel != null) {
            return fastOrderModel.orderId;
        }
        return "";
    }

    /**
     * 获取第三方外卖订单号
     *
     * @return
     */
    public String getThirdOrderId() {
        if (fastOrderModel != null) {
            return fastOrderModel.thirdOrderId;
        }
        return "";
    }


    public void mergeOrderMenuItem(MenuItem mergeMenuItem, MenuItem addMenuItem) {
        BigDecimal num = BigDecimal.ONE;
        //选择菜品有预点数量 则使用预点菜品数量
        if (addMenuItem.currentUnit.fiInitCount > 0) {
            num = new BigDecimal(addMenuItem.currentUnit.fiInitCount);
        }
        BigDecimal newBuyNumber = mergeMenuItem.menuBiz.buyNum.add(num);
        mergeMenuItem.menuBiz.buyNum = newBuyNumber;
        mergeMenuItem.calcTotal(isBindMember());
        initSelectUnitQuantity();
    }

    /**
     * 更新单个菜品信息
     *
     * @param old
     * @param news
     */
    public void replaceMenuItem(MenuItem old, MenuItem news) {
        int index = menuItems.indexOf(old);
        menuItems.remove(old);
        menuItems.add(index, news);
    }

    /**
     * 替换所有菜品信息
     *
     * @param menuItemList
     */
    public void replaceAllMenuItems(List<MenuItem> menuItemList) {
        menuItems.clear();
        menuItems.addAll(menuItemList);
    }
}
