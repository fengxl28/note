//package com.mwee.android.pos.air.business.setting;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.mwee.android.pos.base.BaseConfig;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.base.HomeFragment;
//import com.mwee.android.pos.business.setting.jump.JumpToFragment;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.UIHelp;
//import com.mwee.android.pos.util.ViewToolsUtil;
//import com.mwee.android.pos.widget.TitleBar;
//import com.mwee.android.pos.widget.pull.BaseListAdapter;
//import com.mwee.android.pos.widget.pull.BaseViewHolder;
//import com.mwee.android.pos.widget.pull.DividerItemDecoration;
//
//import java.io.Serializable;
//
///**
// * Created by zhangmin on 2017/12/13.
// */
//
//public class AirSetContainerFragment extends HomeFragment {
//
//    private TitleBar mTitleBar;
//    private RecyclerView mRecyclerViewSet;
//
//    private BaseListAdapter<ClazzInfo> adapter;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.air_set_container_fragment, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        assignViews(view);
//        initData();
//        initAdapter();
//    }
//
//    private void assignViews(View v) {
//
//        mTitleBar = v.findViewById(R.id.mTitleBar);
//
//        mRecyclerViewSet = v.findViewById(R.id.mRecyclerViewSet);
//        mRecyclerViewSet.setLayoutManager(new LinearLayoutManager(getContext()));
//        mRecyclerViewSet.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
//
//        TextView dev = v.findViewById(R.id.t_dev);
//        dev.setVisibility(BaseConfig.isProduct() ? View.GONE : View.VISIBLE);
//
//        dev.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                UIHelp.startDevelopActivity(getActivityWithinHost());
//            }
//        });
//
//    }
//
//    private void initData() {
//
//        mTitleBar.setTitle("设置");
//        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
//            @Override
//            public void onBackClick() {
//                getActivityWithinHost().finish();
//            }
//        });
//
//        mTitleBar.setRightContent("意见反馈");
//        mTitleBar.setRightIcon(R.drawable.ic_fan_kui);
//        mTitleBar.setRightClickListener(new TitleBar.OnBackClickListener() {
//            @Override
//            public void onBackClick() {
//                ActionLog.addLog("更多设置->点击了意见反馈", "", "", ActionLog.SS_MORE_JOIN, "");
//                JumpToFragment.jumpFeedBackFragment(getActivityWithinHost());
//            }
//        });
//
//    }
//
//    private void initAdapter() {
//
//        adapter = new BaseListAdapter<ClazzInfo>() {
//            int choicePosition;
//
//            @Override
//            protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
//                return new Holder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.menu_class_son_category_item_layout, parent, false));
//            }
//
//            class Holder extends BaseViewHolder implements View.OnClickListener {
//
//                private TextView label;
//                private int position;
//
//                public Holder(View itemView) {
//                    super(itemView);
//                    label = (TextView) itemView;
//                    label.setOnClickListener(this);
//                }
//
//                @Override
//                public void bindData(int position) {
//                    this.position = position;
//                    label.setText(modules.get(position).name);
//                    this.position = position;
//                    if (position == choicePosition) {
//                        ViewToolsUtil.setBackgroundResourceKeepPadding(label, R.drawable.bg_air_category_item_checked);
//                        label.setTextColor(getResources().getColor(R.color.system_red));
//                    } else {
//                        ViewToolsUtil.setBackgroundResourceKeepPadding(label, R.color.white);
//                        label.setTextColor(getResources().getColor(R.color.color_3a3a3a));
//                    }
//                }
//
//                @Override
//                public void onClick(View v) {
//                    choicePosition = this.position;
//                    notifyDataSetChanged();
//                    setCurrentTab(position);
//                }
//            }
//        };
//        adapter.modules.add(new ClazzInfo("点菜", AirSetMenuFragment.class));
//        adapter.modules.add(new ClazzInfo("店铺设置", AirSetShopFragment.class));
//        adapter.modules.add(new ClazzInfo("打印与外接", AirSetExternalFragment.class));
//        adapter.modules.add(new ClazzInfo("网络订单", AirSetNetOrderFragment.class));
//        adapter.modules.add(new ClazzInfo("本机设置", AirSetLocalFragment.class));
//        adapter.modules.add(new ClazzInfo("帮助中心", AirSetHelpFragment.class));
//        mRecyclerViewSet.setAdapter(adapter);
//        setCurrentTab(0);
//
//    }
//
//    private void setCurrentTab(int position) {
//        try {
//            ClazzInfo clazzInfo = adapter.modules.get(position);
//            getActivityWithinHost().getSupportFragmentManager().beginTransaction().replace(R.id.flLayoutSet, clazzInfo.clazz.newInstance()).commit();
//        } catch (java.lang.InstantiationException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//    }
//
//    class ClazzInfo implements Serializable {
//        public ClazzInfo(String name, Class<? extends BaseFragment> clazz) {
//            this.name = name;
//            this.clazz = clazz;
//        }
//
//        public String name;
//        public Class<? extends BaseFragment> clazz;
//    }
//
//}
