package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * Created by zhangmin on 2018/02/01.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "crm.membercard.setOnlineStoreRule",
        contentType = "application/json",
        response = BaseMemberResponse.class,
        saveToLog = true
)
public class MemberPackageUpdateRequest extends BaseMemberRequest {
    public int m_shopid;
    //public String title;
    public Object addRuleData;//会员套餐新建
    public Object editRuleData;//会员套餐编辑
    public Object delRuleData;//会员套餐删除

    public MemberPackageUpdateRequest() {
        super("crm.membercard.setOnlineStoreRule");
    }
}
