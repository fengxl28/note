package com.mwee.android.pos.business.cross.api;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.pay.component.CPay;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.basecon.CCredit;
import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.component.cross.net.CrossOrder;
import com.mwee.android.pos.component.cross.net.CrossOrderListRequest;
import com.mwee.android.pos.component.cross.net.CrossOrderListResponse;
import com.mwee.android.pos.component.cross.net.GuaOrder;
import com.mwee.android.pos.component.cross.net.GuaOrderListRequest;
import com.mwee.android.pos.component.cross.net.GuaOrderListResponse;
import com.mwee.android.pos.component.cross.net.Response;
import com.mwee.android.pos.connect.business.pay.CreditAccountListSocketResponse;
import com.mwee.android.pos.connect.business.pay.CreditAccountSocketResponse;
import com.mwee.android.pos.connect.business.pay.CrossPaySocketResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.QueryCrossPayResultSocketResponse;
import com.mwee.android.pos.connect.business.pay.ReverseCrossSocketResponse;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.UserDBModel;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/2.
 */

public class CreditApi {
    /**
     * 加载挂账对象列表
     *
     * @param accountName 挂账拼音检索
     * @param currentPage 当前页数
     * @param size        页数量
     * @param callback    回调
     */
    public static void loadCrossAccountList(String accountName, int currentPage, int size, ResultCallback<Response<CreditAccount>> callback) {
        MCon.c(CCredit.class, (SocketCallback<CreditAccountListSocketResponse>) response -> {
            if (response.success()) {
                callback.onSuccess(response.data.data);
            } else {
                callback.onFailure(response.code, response.message);
            }

        }).loadCrossAccountList(accountName, currentPage, size);
    }

    /**
     * 挂账
     *
     * @param callback    回调
     */
    public static void payHung(String orderId, String fsCreditAccountId, String accountName, BigDecimal payAmount, UserDBModel certigierUser, SocketCallback<PayResultResponse> callback) {
        MCon.c(CPay.class, callback).payHung(orderId, fsCreditAccountId, accountName, payAmount, certigierUser);

    }

    /**
     * 查看对应挂账账户id的详细信息
     *
     * @param accountId
     * @param callback
     */
    public static void loadAccount(String accountId, ResultCallback<CreditAccount> callback) {
        MCon.c(CCredit.class, new SocketCallback<CreditAccountSocketResponse>() {
            @Override
            public void callback(SocketResponse<CreditAccountSocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data.account);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadAccount(accountId, AppCache.getInstance().businessDate);
    }


    /**
     * 搜索挂账对象
     *
     * @param accountName
     * @param callback
     */
    public static void loadSearchCreditAccount(String accountName, int currentPage, int size, ResultCallback<Response<CreditAccount>> callback) {
        MCon.c(CCredit.class, new SocketCallback<CreditAccountListSocketResponse>() {
            @Override
            public void callback(SocketResponse<CreditAccountListSocketResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.data.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadSearchCreditAccount(accountName, currentPage, size);
    }

    /**
     * 加载挂账列表
     *
     * @param accountId   挂账对象id
     * @param currentPage 当前页数
     * @param size        页数量
     * @param callback    回调
     */
    public static void loadGuaOrderList(String accountId, int currentPage, int size, ResultCallback<Response<GuaOrder>> callback) {
        GuaOrderListRequest request = new GuaOrderListRequest();
        request.currentPage = currentPage;
        request.accountId = accountId;
        request.pageSize = size;
        request.status = 1;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GuaOrderListResponse) {
                    GuaOrderListResponse response = (GuaOrderListResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 加载销账记录
     *
     * @param accountId
     * @param currentPage
     * @param size
     * @param callback
     */
    public static void loadCrossOrderList(String accountId, int currentPage, int size, ResultCallback<Response<CrossOrder>> callback) {
        CrossOrderListRequest request = new CrossOrderListRequest();
        request.accountId = accountId;
        request.currentPage = currentPage;
        request.pageSize = size;
        request.status = 1;
        request.bussinessStatus = "1";
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CrossOrderListResponse) {
                    CrossOrderListResponse response = (CrossOrderListResponse) responseData.responseBean;
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 销账
     *
     * @param account    销账账户
     * @param crossPrice 销账金额
     * @param code       支付马
     * @param bean       支付方式
     * @param callback   回调
     */
    public static void loadCrossPay(String requestId, CreditAccount account, String sellNo, BigDecimal crossPrice, String code, PaymentDBModel bean, ResultCallback<CrossPaySocketResponse> callback) {
        MCon.c(CCredit.class, (SocketCallback<CrossPaySocketResponse>) response -> {
            if (response == null) {
                callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                return;
            }

            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadCrossPay(requestId, account, crossPrice, code, bean, sellNo, AppCache.getInstance().businessDate);
    }

    /**
     * 反销账
     *
     * @param recordId
     * @param fsCreditAccountId
     * @param callback
     */
    public static void loadReverseCross(int recordId, String fsCreditAccountId, ResultCallback<BigDecimal> callback) {
        MCon.c(CCredit.class, (SocketCallback<ReverseCrossSocketResponse>) response -> {
            if (response.success()) {
                callback.onSuccess(response.data.debtAmt);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadReverseCross(recordId, fsCreditAccountId, AppCache.getInstance().businessDate);
    }

    /**
     * 查询销账支付结果
     *
     * @param requestId
     * @param printInfo
     * @param callback
     */
    public static void loadQueryCrossPayResult(String requestId, CrossPayPrintInfo printInfo, ResultCallback<QueryCrossPayResultSocketResponse> callback) {
        MCon.c(CCredit.class, (SocketCallback<QueryCrossPayResultSocketResponse>) response -> {
            if (response == null) {
                callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                return;
            }

            if (response.success()) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).loadCrossPayResult(requestId, printInfo);
    }
}
