package com.mwee.android.pos.air.business.dinner;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.dinner.DishUtils;
import com.mwee.android.pos.business.member.widget.MemberBindOperationView;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.Tools;

import java.math.BigDecimal;

/**
 * 小散桌台模式使用
 * Created by zhangmin on 2017/11/9.
 */

public class DinnerOrderFooterLayout extends LinearLayout implements View.OnClickListener {


    //要求
    private TextView tvMenuAsk;
    //优惠与折扣
    private TextView tvDiscount;
    //总价
    private TextView tvOrderTotalPriceLabel;
    //会员
    //下单
    private TextView mOperationCheckLabel;


    private DishCache mDishCache;
    private MemberBindOperationView mOperationMemberBindOperationView;


    public DinnerOrderFooterLayout(Context context) {
        super(context);
        initView();
    }


    public DinnerOrderFooterLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public DinnerOrderFooterLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.air_dinner_order_bottom_operation, this);

        tvMenuAsk = findViewById(R.id.tvMenuAsk);
        tvDiscount = findViewById(R.id.tvDiscount);
        tvOrderTotalPriceLabel = findViewById(R.id.tvOrderTotalPriceLabel);
        mOperationMemberBindOperationView = (MemberBindOperationView) findViewById(R.id.mOperationMemberBindOperationView);
        mOperationCheckLabel = findViewById(R.id.mOperationCheckLabel);

        tvMenuAsk.setOnClickListener(this);
        tvDiscount.setOnClickListener(this);
        mOperationMemberBindOperationView.setOnClickListener(this);
        mOperationCheckLabel.setOnClickListener(this);

    }


    public void initData(DishCache mDishCache) {

        this.mDishCache = mDishCache;
        refreshDinnerFoodFooterLayout();

    }

    public void refreshDinnerFoodFooterLayout() {

        if (mDishCache.order != null && mDishCache.order.isMember) {
            mOperationMemberBindOperationView.bind(mDishCache.order.memberName, mDishCache.order.memberInfoS.mobile);
        } else {
            mOperationMemberBindOperationView.unBind();
        }
        calculateTotalPrice();

    }


    /**
     * 刷新笔数与总价
     */
    public void calculateTotalPrice() {
        // FIXME: 2017/6/22 总价格计算方法
        if (mDishCache.order == null) {
            //mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
            tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(mDishCache.orderDishesCache.tempTotalPrice, RoundConfig.ROUND_TOTAL)));
            return;
        }
        refreshOrderInfo();
    }


    public void refreshOrderInfo() {
        if (!ListUtil.listIsEmpty(mDishCache.order.originMenuList)) {
            BigDecimal cut = BigDecimal.ZERO;
            String discountInfo = "";
            if (mDishCache.order.couponCut != null && mDishCache.order.couponCut.fdCutmoney.compareTo(BigDecimal.ZERO) > 0) {
                cut = mDishCache.order.couponCut.fdCutmoney;
                discountInfo = " (" + mDishCache.order.couponCut.fsBargainName + "：-" + cut.toString() + ")";
            }
            //已有下单数据 ：总金额=已有订单金额+为下单金额
            BigDecimal totalPrice = mDishCache.order.optTotalMenuPrice().add(mDishCache.orderDishesCache.tempTotalPrice);
            if (!DishUtils.isSupportRound(mDishCache.order)) {
                tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(totalPrice.subtract(cut))).append(discountInfo));
            } else {
                tvOrderTotalPriceLabel.setText(new StringBuilder().append(Calc.formatShow(totalPrice.subtract(cut), RoundConfig.ROUND_TOTAL)).append(discountInfo));
            }
        }
    }


    @Override
    public void onClick(View view) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (view.getId()) {

            case R.id.tvMenuAsk:
                listener.onMenuItemRequestClick();
                break;
            case R.id.tvDiscount:
                listener.onDiscountClick();
                break;
            case R.id.mOperationMemberBindOperationView:
                listener.onMemberClick();
                break;
            case R.id.mOperationCheckLabel:
                listener.onOrderMenuCommitClick();
                break;

            default:
                break;
        }
    }


    private DinnerOrderFooterLayouCallBack listener;

    public void setDinnerOrderFooterLayouCallBack(DinnerOrderFooterLayouCallBack listener) {

        this.listener = listener;
    }

    public void unBindMember() {
        mOperationMemberBindOperationView.unBind();
    }

    public void bindMember(String name, String phone) {
        mOperationMemberBindOperationView.bind(name, phone);
    }

    public interface DinnerOrderFooterLayouCallBack {


        /**
         * 要求
         */
        void onMenuItemRequestClick();

        /**
         * 优惠与折扣
         */
        void onDiscountClick();

        /**
         * 会员
         */
        void onMemberClick();

        /**
         * 完成下单
         */
        void onOrderMenuCommitClick();


    }


}
