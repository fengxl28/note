package com.mwee.android.pos.business.message;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessageSystemBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.util.List;

/**
 * Created by qinwei on 2017/9/18.
 */

public class MessageSystemFragment extends BaseListFragment<MessageSystemBean> implements IDriver, View.OnClickListener {
    public static final String DRIVER_TAG = "messageSystem";
    private TextView mMessageDetailLabel;
    private Button mMessagePDLoginRetryBtn;
    private int chosedMsgId;
    private View mMessageDetailLayout;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_message_system;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mMessageDetailLabel = (TextView) view.findViewById(R.id.mMessageDetailLabel);
        mMessageDetailLayout = view.findViewById(R.id.mMessageDetailLayout);
        mMessagePDLoginRetryBtn = (Button) view.findViewById(R.id.mMessagePDLoginRetryBtn);
        mMessagePDLoginRetryBtn.setOnClickListener(this);

        if(AppCache.getInstance().isRetailMode()){//小易2.2 修改样式
            ViewGroup root = rootView.findViewById(R.id.lyt_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            mPullRecyclerView.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root,getResources().getColor(R.color.color_656565));
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup,int color){
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if(view instanceof TextView){
                ((TextView)view).setTextColor(color);
            }
        }
    }

    @Override
    protected void initData() {
        super.initData();
        mMessageDetailLayout.setVisibility(View.INVISIBLE);
        mPullRecyclerView.setEnablePullToStart(false);
        loadDataFromServer();
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    public void onClick(View v) {
        NotifyToServer.doPDLogin();
    }


    private void loadDataFromServer() {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        MessageUtil.getSystemType(AppCache.getInstance().businessDate, new IResponse<List<MessageSystemBean>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<MessageSystemBean> info) {
                progress.dismissSelf();
                if (result) {
                    modules.clear();
                    if (!ListUtil.isEmpty(info)) {
                        modules.addAll(info);
                    } else {
                        mMessageDetailLayout.setVisibility(View.INVISIBLE);
                    }
                    adapter.notifyDataSetChanged();
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!this.isVisible()) {
            return;
        }
        loadDataFromServer();
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.message_system_item, parent, false));
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }


    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView msgSystemItemTime;
        private TextView msgSystemItemSource;
        private TextView msgSystemItemStatus;
        private MessageSystemBean bean;

        public Holder(View v) {
            super(v);
            msgSystemItemTime = (TextView) v.findViewById(R.id.msg_system_item_time);
            msgSystemItemSource = (TextView) v.findViewById(R.id.msg_system_item_source);
            msgSystemItemStatus = (TextView) v.findViewById(R.id.msg_system_item_status);
            v.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            bean = modules.get(position);
            msgSystemItemTime.setText(bean.createTime);
            msgSystemItemSource.setText(bean.getSourse());
            msgSystemItemStatus.setText(bean.msgBody);

            if(AppCache.getInstance().isRetailMode()){
                if (bean.msgId == chosedMsgId) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.system_red);
                    setTextColorOfViewGroup((ViewGroup) itemView, Color.WHITE);
                }else{
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.color_f9f9f9);
                    setTextColorOfViewGroup((ViewGroup) itemView, getResources().getColor(R.color.color_404040));
                }
            }else{
                int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                if (bean.isUnDeal()) {
                    colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                }
                msgSystemItemTime.setTextColor(colorR);
                msgSystemItemSource.setTextColor(colorR);
                msgSystemItemStatus.setTextColor(colorR);
                if (bean.msgId == chosedMsgId) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.item_selected_bg);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.menu_bg);
                }
            }
        }

        @Override
        public void onClick(View v) {
            doChoice(bean);
        }
    }

    private void doChoice(MessageSystemBean bean) {
        chosedMsgId = bean.msgId;
        mMessageDetailLayout.setVisibility(View.VISIBLE);
        mMessageDetailLabel.setText(bean.msgBody);
        adapter.notifyDataSetChanged();
    }
}
