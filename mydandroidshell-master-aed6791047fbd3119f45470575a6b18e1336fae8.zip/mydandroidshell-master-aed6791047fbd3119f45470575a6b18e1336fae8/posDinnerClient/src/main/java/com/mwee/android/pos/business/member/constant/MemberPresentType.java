package com.mwee.android.pos.business.member.constant;

/**
 * 赠送类型
 * Created by chris on 16/8/18.
 */
public class MemberPresentType {

    // 0、不赠送1、赠送金额 2、赠送积分

    /**
     * 不赠送
     */
    public static final int NO_PRESENT = 0;
    /**
     * 赠送金额
     */
    public static final int PRESENT_PRICE = 1;
    /**
     * 赠送积分
     */
    public static final int PRESENT_SCORE = 2;
}
