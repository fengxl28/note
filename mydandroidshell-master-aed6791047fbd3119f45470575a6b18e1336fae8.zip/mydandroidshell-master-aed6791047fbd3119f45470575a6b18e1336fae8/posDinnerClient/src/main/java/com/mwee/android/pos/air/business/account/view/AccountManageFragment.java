package com.mwee.android.pos.air.business.account.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.air.business.account.process.AccountManageProcess;
import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.recycler.CommonRecycleAdapter;
import com.mwee.android.pos.component.recycler.ViewHolder;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.widget.TitleBar;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: AccountManageFragment
 * @Description: 员工管理
 * @author: SugarT
 * @date: 2017/10/12 下午2:08
 */
public class AccountManageFragment extends AirBaseFragment {

    public static final String TAG = AccountManageFragment.class.getSimpleName();

    public static final String EMPTY_USER_ID = "ForAddAccount";

    private TitleBar mTitleBar;
    private RecyclerView mAccountRv;

    private CommonRecycleAdapter<AccountManageInfo> mAdapter;

    private List<AccountManageInfo> mAllAccount = new ArrayList<>();

    private AccountManageProcess mProcess;

    public static AccountManageFragment newInstance() {
        AccountManageFragment fragment = new AccountManageFragment();
        new AccountManageProcess(fragment);
        return fragment;
    }

    public void setProcess(AccountManageProcess process) {
        mProcess = process;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account_manage, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        initTitle();
        initAdapter();
        mProcess.start();
    }

    private void assignViews(View convertView) {
        mTitleBar = (TitleBar) convertView.findViewById(R.id.tb_fragment_account_manage_title);
        mAccountRv = (RecyclerView) convertView.findViewById(R.id.rv_fragment_account_manage_content);
    }

    private void initTitle() {
        mTitleBar.setTitle(getString(R.string.account_manger));
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                BizcenterApi.uploadLocalChangeData(null);
                dismissSelf();
            }
        });
    }

    private void initAdapter() {
        mAdapter = new CommonRecycleAdapter<AccountManageInfo>(getContextWithinHost(), R.layout.item_account_manage) {
            @Override
            public boolean onItemClick(View view, AccountManageInfo data, int position) {
                if (!ButtonClickTimer.canClick()) {
                    return false;
                }
                if (data == null) {
                    return false;
                }
                if (TextUtils.equals(data.fsUserId, EMPTY_USER_ID)) {
                    // 新增账号
                    editAccount(mProcess.buildNewUser(), true);
                } else {
                    // 编辑账号
                    mProcess.queryAccountByID(data.fsUserId);
                }
                return false;
            }

            @Override
            public void onBind(ViewHolder holder, AccountManageInfo userDBModel, int position) {
                if (userDBModel == null) {
                    return;
                }

                holder.getView(R.id.iv_item_account_manage_del).setOnClickListener(innerClick);
                holder.getView(R.id.iv_item_account_manage_del).setTag(userDBModel);

                if (TextUtils.equals(userDBModel.fsUserId, EMPTY_USER_ID)) {
                    holder.getView(R.id.tv_item_account_manage_name).setVisibility(View.GONE);
                    holder.getView(R.id.tv_item_account_manage_id).setVisibility(View.GONE);
                    holder.getView(R.id.iv_item_account_manage_del).setVisibility(View.GONE);
                    holder.getView(R.id.tv_item_account_manage_add).setVisibility(View.VISIBLE);
                    return;
                }

                holder.getView(R.id.tv_item_account_manage_name).setVisibility(View.VISIBLE);
                holder.getView(R.id.tv_item_account_manage_id).setVisibility(View.VISIBLE);
                holder.getView(R.id.iv_item_account_manage_del).setVisibility(View.VISIBLE);
                holder.getView(R.id.tv_item_account_manage_add).setVisibility(View.GONE);

                holder.setText(R.id.tv_item_account_manage_name, userDBModel.fsUserName);
                holder.setText(R.id.tv_item_account_manage_id, userDBModel.fsUserId);

                // 管理账号判断
                if (TextUtils.equals(userDBModel.fsUserId, "admin") ||
                        TextUtils.equals(userDBModel.fsUserId, "99999") ||
                        TextUtils.equals(userDBModel.fsUserId, "cash")) {
                    holder.getView(R.id.iv_item_account_manage_del).setVisibility(View.GONE);
                } else {
                    holder.getView(R.id.iv_item_account_manage_del).setVisibility(View.VISIBLE);
                }
            }

            View.OnClickListener innerClick = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!ButtonClickTimer.canClick()) {
                        return;
                    }
                    Object tag = v.getTag();
                    if (tag != null && tag instanceof AccountManageInfo) {
                        final AccountManageInfo model = (AccountManageInfo) tag;
                        DialogManager.showExecuteDialog(AccountManageFragment.this, getString(R.string.account_manage_del), new DialogResponseListener() {
                            @Override
                            public void response() {
                                mProcess.delete(model.fsUserId);
                            }
                        });
                    }
                }
            };
        };
        mAccountRv.setLayoutManager(new GridLayoutManager(getContextWithinHost(), 5));
        mAccountRv.setAdapter(mAdapter);
        mAdapter.setData(mAllAccount);
    }

    /**
     * 刷新显示
     *
     * @param data
     */
    public void refreshAccounts(List<AccountManageInfo> data) {
        mAllAccount.clear();
        mAllAccount.addAll(data);
        mAllAccount.add(buildEmpty());
        if (mAdapter != null) {
            mAdapter.setData(mAllAccount);
        }
    }

    public void editAccount(AccountManageInfo user, final boolean isAdd) {
        AccountEditView accountEditView = AccountEditView.newInstance();
        accountEditView.setOptUser(user)
                .setListener(new OnResultListener<AccountManageInfo>() {
                    @Override
                    public void callBack(AccountManageInfo var1) {
                        if (isAdd) {
                            mProcess.add(var1);
                        } else {
                            mProcess.edit(var1);
                        }
                    }
                });
        DialogManager.showCustomDialog(AccountManageFragment.this, accountEditView, AccountEditView.TAG);
    }

    private AccountManageInfo buildEmpty() {
        AccountManageInfo result = new AccountManageInfo();
        result.fsUserId = EMPTY_USER_ID;
        return result;
    }
}
