package com.mwee.android.pos.business.message.koubei.future;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBFutureUpdateReponse;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataResponse;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;

/**
 * Created by zhangmin on 2018/5/24.
 *
 *
 * 口碑后付款订单接口
 */

public interface IKBFutureClientListener {

    /**
     * 根据订单号拉取订单
     *
     * @param id
     * @param
     */
    void loadFutureOrder(String id,  ResultCallback<KBFutureUpdateReponse> resultCallback);



    /**
     * 拉取订单头信息
     */
    void loadFutureTempOrderHeader(int pageIndex, String orderId, String status,ResultCallback<KBFutureTempDataResponse> resultCallback);


    /**
     * 打印
     *
     * @param order_id
     * @param resultCallback
     */
    //void doFuturePrinter(String order_id, ResultCallback<BaseSocketResponse> resultCallback);


    /**
     * 接单
     *
     * @param kbAfterPayOrder
     * @param resultCallback
     */
    void acceptFutureOrder(KBAfterPayOrder kbAfterPayOrder, ResultCallback<ScannerTableOrderAcceptResponse> resultCallback);


    /**
     * 拒单
     *
     * @param order_id
     * @param reason
     * @param resultCallback
     */
    void rejectFutureOrder(String orderId, String batchNo, String rejectReason,String id, ResultCallback<ScannerTableOrderAcceptResponse> resultCallback);


}
