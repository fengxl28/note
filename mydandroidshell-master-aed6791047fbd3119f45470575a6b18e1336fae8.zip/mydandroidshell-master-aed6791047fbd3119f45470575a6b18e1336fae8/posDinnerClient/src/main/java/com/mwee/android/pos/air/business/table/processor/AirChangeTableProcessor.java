//package com.mwee.android.pos.air.business.table.processor;
//
//import android.text.TextUtils;
//
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.Host;
//import com.mwee.android.pos.base.TableConstans;
//import com.mwee.android.pos.business.table.processor.TableBizProcessor;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.component.log.RunTimeLog;
//import com.mwee.android.pos.connect.business.table.ChangeTableResponse;
//import com.mwee.android.pos.connect.config.SocketResultCode;
//import com.mwee.android.pos.connect.callback.SocketCallback;
//import com.mwee.android.pos.connect.framework.SocketResponse;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.connect.callback.IResult;
//import com.mwee.android.pos.db.business.MtableDBModel;
//import com.mwee.android.pos.db.business.order.OrderCache;
//import com.mwee.android.pos.db.business.table.TableStatusBean;
//import com.mwee.android.pos.util.ToastUtil;
//
//import java.util.Map;
//
///**
// * Created by virgil on 2016/10/25.
// */
//
//public class AirChangeTableProcessor implements AirTableChangeDialogFragment.AirIChangeTableCallBack {
//    private Host host;
//    private OrderCache orderCache;
//    private IResponse<OrderCache> outCallBack;
//
//    public AirChangeTableProcessor(Host host, OrderCache orderCache, IResponse<OrderCache> result) {
//        this.host = host;
//        this.orderCache = orderCache;
//        this.outCallBack = result;
//    }
//
//    /**
//     * 小散 换桌
//     * 开始转菜的流程，首先需要选择数量.
//     * 可称重菜或者菜品数量为1的菜，都直接转桌，不需要再选择数量
//     */
//    public void startAirV3() {
//        AirTableChangeDialogFragment fragment = new AirTableChangeDialogFragment();
//        fragment.setParam(this, orderCache.fsmtableid, "换桌");
//        ActionLog.addLog("显示换桌界面", orderCache.orderID, orderCache.fsmtableid, ActionLog.DF_TABLE_CHANGED, "");
//        fragment.show(host.getFragmentManagerWithinHost(), fragment.getClass().getName());
//    }
//
//
//    /**
//     * 发起换桌
//     *
//     * @param targetTable  TableStatusBean| 目标桌台
//     * @param viewCallBack IResult | 转菜结果的监听
//     */
//    @Override
//    public void doAirTransfer(final MtableDBModel targetTable, Map<String, TableStatusBean> tableStatus, final IResult viewCallBack) {
//        if (targetTable == null) {
//            return;
//        }
//        if (targetTable.fsmtableid.equals(orderCache.fsmtableid)) {
//            viewCallBack.callBack(true, "");
//            return;
//        }
//        //先判断是否是合桌的操作
//        boolean hasOrder = false;
//
//        for (TableStatusBean temp : tableStatus.values()) {
//            if (TextUtils.equals(temp.fsmtableid, targetTable.fsmtableid)) {
//                if (TableConstans.TABLE_STATUS_OPEN.equals(temp.fsmtablesteid) && !TextUtils.isEmpty(temp.fssellno)) {
//                    hasOrder = true;
//                }
//                break;
//            }
//        }
//        /**
//         * 如果是合桌，则弹出确认操作
//         */
//        if (hasOrder) {
//            DialogManager.showExecuteDialog(host, "桌台[" + targetTable.fsmtablename + "]已被占用，确认后将合桌", new DialogResponseListener() {
//                @Override
//                public void response() {
//                    RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "桌台[" + targetTable.fsmtablename + "]已被占用，服务员确认合桌");
//                    submitChange(targetTable, viewCallBack);
//                }
//            });
//        } else {
//            RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "开始执行换桌：目标桌台[" + targetTable.fsmareaid + "，" + targetTable.fsmtablename + "]");
//            //ActionLog.addLog("开始执行换桌：目标桌台[" + targetTable.fsmareaid + "，" + targetTable.fsmtablename + "]", orderCache.orderID, orderCache.fsmtableid, ActionLog.DF_TABLE_CHANGED, "");
//            submitChange(targetTable, viewCallBack);
//        }
//    }
//
//    private void submitChange(final MtableDBModel targetTable, final IResult viewCallBack) {
//        final Progress progress = ProgressManager.showProgressUncancel(host, "请稍后");
//        TableBizProcessor.changeOpenedTable(orderCache.orderID, orderCache.fsmtablename, orderCache.fsmtableid, targetTable.fsmtablename, targetTable.fsmtableid, new SocketCallback<ChangeTableResponse>() {
//            @Override
//            public void callback(SocketResponse<ChangeTableResponse> socketResponse) {
//                if (socketResponse.code == SocketResultCode.SUCCESS) {
//                    ToastUtil.showToast("已成功换到桌台[" + targetTable.fsmtablename + "]");
//                    orderCache = socketResponse.data.newOrderCache;
//                    AppCache.getInstance().currentOrderID = orderCache.orderID;
//                    ActionLog.addLog("已成功换到桌台[" + targetTable.fsmtablename + "]", orderCache.orderID, orderCache.fsmtableid, ActionLog.DF_TABLE_CHANGED, "");
//                    viewCallBack.callBack(true, "");
//                    outCallBack.callBack(true, 0, "", socketResponse.data.newOrderCache);
//                } else {
//                    viewCallBack.callBack(false, socketResponse.message);
//                    ToastUtil.showToast(socketResponse.message);
//                    RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "换桌失败：" + socketResponse.message);
//                    //ActionLog.addLog("换桌失败：" + socketResponse.message, orderCache.orderID, orderCache.fsmtableid, ActionLog.DF_TABLE_CHANGED, "");
//                }
//                progress.dismiss();
//            }
//        });
//    }
//
//}
