package com.mwee.android.pos.air.business.member.entity;


import com.mwee.android.base.net.BaseResponse;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberScoreGiftRuleQueryResponseBody extends BaseResponse {
    public MemberRuleLevelContainer data=new MemberRuleLevelContainer();

    public MemberScoreGiftRuleQueryResponseBody() {
    }
}
