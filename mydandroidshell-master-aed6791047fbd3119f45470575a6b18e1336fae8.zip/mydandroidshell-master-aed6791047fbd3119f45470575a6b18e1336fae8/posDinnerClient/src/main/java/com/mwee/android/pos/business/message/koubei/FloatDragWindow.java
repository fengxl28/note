package com.mwee.android.pos.business.message.koubei;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.util.DensityUtil;


/**
 * 悬浮窗显示
 * Created by qinwei on 2018/6/23.
 */

public class FloatDragWindow {
    private static FloatDragWindow mInstance;
    private WindowManager.LayoutParams wmParams;
    private WindowManager mWindowManager = null;
    private View view;
    private int top;
    public boolean isShow;
    private int mCanMoveWidth;
    private int mCanMoveHeight;


    private FloatDragWindow() {
        init();
    }

    private void init() {
        Context context = GlobalCache.getContext();
        wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT > 24) {
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        mCanMoveWidth = DensityUtil.getScreenWidth(context) / 2 - DensityUtil.dip2px(context, 26);
        mCanMoveHeight = (DensityUtil.getRealScreen(context).y - top) / 2 - DensityUtil.dip2px(context, 26);

        wmParams.x = mCanMoveWidth - DensityUtil.dip2px(context, 32);
        wmParams.y = mCanMoveHeight - DensityUtil.dip2px(context, 32);
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.windowAnimations = android.R.style.Animation_Translucent;
    }


    public static FloatDragWindow getInstance() {
        if (mInstance == null) {
            mInstance = new FloatDragWindow();
        }
        return mInstance;
    }

    /**
     * 设置视图
     *
     * @param view
     * @return
     */
    public FloatDragWindow setView(View view) {
        this.view = view;
        view.setOnTouchListener(new View.OnTouchListener() {
            public float x;
            public float y;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x = event.getRawX();
                        y = event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        wmParams.x += event.getRawX() - x;
                        wmParams.y += event.getRawY() - y;
                        if (wmParams.y < -mCanMoveHeight) {
                            wmParams.y = -mCanMoveHeight;
                        }
                        if (wmParams.y > mCanMoveHeight) {
                            wmParams.y = mCanMoveHeight;
                        }
                        mWindowManager.updateViewLayout(FloatDragWindow.this.view, wmParams);
                        x = event.getRawX();
                        y = event.getRawY();
                        break;
                    case MotionEvent.ACTION_UP:
                        if (x != event.getX() || y != event.getY()) {
                            //消耗事件传递 解决拖拽后松手触发
                            return true;
                        }
                        break;
                }
                return false;
            }
        });
        return this;
    }

    /**
     * 设置距离顶部边界距离
     *
     * @param top
     * @return
     */
    public FloatDragWindow setTop(int top) {
        this.top = top;
        return this;
    }

    /**
     * 设置布局参数
     *
     * @param layoutParams
     * @return
     */
    public FloatDragWindow setLayoutParams(WindowManager.LayoutParams layoutParams) {
        this.wmParams = layoutParams;
        return this;
    }

    /**
     * 显示悬浮框
     */
    public void show() {
        if (view != null && wmParams != null) {
            isShow = true;
            mWindowManager.addView(view, wmParams);
        }
    }

    /**
     * 销毁悬浮框
     */
    public void onDestroy() {
        if (view != null) {
            mWindowManager.removeView(view);
            mWindowManager = null;
            wmParams = null;
            mInstance = null;
        }
    }

    public FloatDragWindow setGravity(int gravity) {
        if (wmParams != null) {
            wmParams.gravity = gravity;
        }
        return this;
    }
}