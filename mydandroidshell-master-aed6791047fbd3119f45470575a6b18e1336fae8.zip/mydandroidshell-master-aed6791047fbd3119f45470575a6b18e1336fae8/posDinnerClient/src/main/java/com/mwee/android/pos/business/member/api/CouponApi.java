package com.mwee.android.pos.business.member.api;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.GroupTicketQueryRequest;
import com.mwee.android.pos.business.member.GroupTicketQueryResponse;
import com.mwee.android.pos.business.member.GroupTicketUseRequest;
import com.mwee.android.pos.business.member.GroupTicketUseResponse;
import com.mwee.android.pos.business.member.entity.GroupTicket;
import com.mwee.android.pos.business.member.entity.GroupTicketUse;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/12/7.
 */

public class CouponApi {
    public static void loadQueryGroupTicket(String type, String couponNum, final ResultCallback<GroupTicket> callback) {
        GroupTicketQueryRequest request = new GroupTicketQueryRequest();
        request.type = type;
        request.sn = couponNum;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof GroupTicketQueryResponse) {
                    GroupTicketQueryResponse response = ((GroupTicketQueryResponse) responseData.responseBean);
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(-1, "数据错误");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public static void loadUseCoupon(String type, String sn, int num, final ResultCallback<ArrayList<GroupTicketUse>> callback) {
        GroupTicketUseRequest request = new GroupTicketUseRequest();
        request.num = num;
        request.type = type;
        request.sn = sn;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof GroupTicketUseResponse) {
                    GroupTicketUseResponse response = ((GroupTicketUseResponse) responseData.responseBean);
                    callback.onSuccess(response.data.list);
                } else {
                    callback.onFailure(-1, "数据错误");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }
}
