package com.mwee.android.pos.business.batchorder;

import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.business.menu.MenuCache;

//import com.puscene.posclient.R;


/**
 * Created by lxx on 17/1/6.
 * 批量下单
 */
public class BatchOrderFragment extends BaseFragment implements IDriver {
//    public static final String DRIVER_TAG = "batchOrder";
//
//    private TextView tv_batch_log;  //下单
//    private EditText edt_order_count;  //下单数量
//    private EditText edt_item_count_little;
//    private EditText edt_item_count_max;
//
//    private int orderCount = 10;
//    private int itemCountLittle = 1;
//    private int itemCountMax = 10;
//
//    private BatchOrderProcess batchOrderProcess = new BatchOrderProcess();
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//    }
//
//    @DrivenMethod(uri = DRIVER_TAG + "/putLog", UIThread = true)
//    public void putLogs(String log) {
//        tv_batch_log.append(log);
//        tv_batch_log.append("\n");
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.batch_order_fragment, container, false);
//        view.findViewById(R.id.btn_order).setOnClickListener(click);
//        tv_batch_log = (TextView) view.findViewById(R.id.tv_batch_log);
//        tv_batch_log.setMovementMethod(ScrollingMovementMethod.getInstance());
//        DriverBus.registerDriver(this);
//        initUI(view);
//        return view;
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//    }
//
//    private View.OnClickListener click = new View.OnClickListener() {
//        @Override
//        public void onClick(View view) {
//            switch (view.getId()) {
//                case R.id.btn_order:
//                    if (check()) {
//                        tv_batch_log.setText("");
//                        orders();
//                    }
//                    break;
//            }
//        }
//    };
//
//    /**
//     * 下单
//     */
//    private void orders() {
//        final Progress progress = ProgressManager.showProgress(this, "正在下第1单");
//        BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
//            @Override
//            public Boolean sendResponse() {
//                /**
//                 * 准备数据
//                 */
//                batchOrderProcess.addLog("正在准备数据...");
//                BatchOrderProcess.prepareData();
//                batchOrderProcess.addLog("数据准备完毕");
//                for (int i = 1; i <= orderCount; i++) {
//                    batchOrderProcess.addLog("正在下第" + i + "单   " + DateUtil.getCurrentDate("HH:mm:ss"));
//                    try {
//                        if (i > 1) {
//                            progress.updateText("正在下第" + i + "单");
//                        }
//                        batchOrderProcess.getNextOrderCache(BatchOrderFragment.this, itemCountLittle, itemCountMax);
//                        Thread.sleep(4000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                        batchOrderProcess.addLog("下第" + i + "单异常:" + e.getMessage());
//                    }
//                }
//                batchOrderProcess.addLog("-----下单任务完成 " + DateUtil.getCurrentDate("HH:mm:ss") + "-----");
//                return true;
//            }
//        }, new SyncCallback<Boolean>() {
//
//            @Override
//            public void callback(Boolean aBoolean) {
//                progress.dismiss();
//            }
//        });
//    }
//
//    /**
//     * 下单前检查参数设置是否合格
//     *
//     * @return
//     */
//    private boolean check() {
//        String orderCountStr = edt_order_count.getText().toString().trim();
//        String itemCountLittleStr = edt_item_count_little.getText().toString().trim();
//        String itemCountMaxStr = edt_item_count_max.getText().toString().trim();
//        orderCount = TextUtils.isEmpty(orderCountStr) ? 10 : StringUtil.toInt(orderCountStr, -1);
//        if (orderCount <= 0) {
//            ToastUtil.showToast("下单数量不正确");
//            return false;
//        }
//
//        itemCountLittle = TextUtils.isEmpty(itemCountLittleStr) ? 1 : StringUtil.toInt(itemCountLittleStr, -1);
//        if (itemCountLittle <= 0) {
//            ToastUtil.showToast("每单菜品数量最少不得小于1");
//            return false;
//        }
//
//        itemCountMax = TextUtils.isEmpty(itemCountMaxStr) ? 10 : StringUtil.toInt(itemCountMaxStr, -1);
//        if (itemCountMax < itemCountLittle) {
//            ToastUtil.showToast("每单菜品数量最大值不得小于最小值");
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * findView
//     *
//     * @param view
//     */
//    private void initUI(View view) {
//        edt_order_count = (EditText) view.findViewById(R.id.edt_order_count);
//        edt_item_count_little = (EditText) view.findViewById(R.id.edt_item_count_little);
//        edt_item_count_max = (EditText) view.findViewById(R.id.edt_item_count_max);
//    }


    @Override
    public String getModuleName() {
        return "";
    }
}
