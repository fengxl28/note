package com.mwee.android.pos.business.common.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.client.db.ClientMenuDBUtil;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuPackageGroup;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/7/15.
 */

public class MenuPackageEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    public static final String TAG = "MenuPackageEditorDialogFragment";
    private TextView mPackageTitleLabel;//套餐头
    private TextView mPackageEditorCancelLabel;//取消
    private TextView mPackageEditorCommitLabel;//确定
    private ListView mPackageEditorMenuLsv;//选择的套餐明细

    private MenuExtraItemAdapter adapter;//适配器
    private IResponse<PackageItemEditViewBean> callback;
    private MenuItem menuItem;//套餐菜品
    private List<MenuPackageGroup> menuPackageGroups;//套餐内容
    private ArrayList<MenuItem> selectedPackageItems = new ArrayList<>();//当前选择套餐明细
    private ArrayMap<String, Boolean> selectCache = new ArrayMap<>();
    private List<NoteItemModel> systemCustomRequests = new ArrayList<>();//自定义要求

    private MenuItem operationCache;//套餐内单个菜品操作引用
    private TextView mPackageEditLabel;

    private boolean isOrdered = false;// 是否是已下单
    private boolean isMember = false;// 是否是会员

    private String itemVoidReason = "";// 套餐子项退菜原因
    private UserDBModel itemVoidUser;// 套餐子项退菜人

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        setCancelable(false);
        return inflater.inflate(R.layout.fragment_menu_package_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }


    private void initView(View view) {
        mPackageTitleLabel = (TextView) view.findViewById(R.id.mPackageTitleLabel);
        mPackageEditLabel = (TextView) view.findViewById(R.id.mPackageEditLabel);
        mPackageEditorMenuLsv = (ListView) view.findViewById(R.id.mPackageEditorMenuLsv);
        mPackageEditorCancelLabel = (TextView) view.findViewById(R.id.mPackageEditorCancelLabel);
        mPackageEditorCommitLabel = (TextView) view.findViewById(R.id.mPackageEditorCommitLabel);
        mPackageEditorCancelLabel.setOnClickListener(this);
        mPackageEditorCommitLabel.setOnClickListener(this);
        mPackageTitleLabel.setOnClickListener(this);
        mPackageEditLabel.setOnClickListener(this);
        adapter = new MenuExtraItemAdapter();
        mPackageEditorMenuLsv.setAdapter(adapter);
    }

    private void initData() {
        //非空处理
        if(menuItem == null){
            dismiss();
            return;
        }

        //获取套餐明细
        menuPackageGroups = ListUtil.cloneList(DinnerMenuUtil.getAllPackageByMenu(menuItem));
        //数据回显
        selectCache.clear();
        if (menuItem.menuBiz.selectedPackageItems.size() > 0) {
            for (int i = 0; i < menuPackageGroups.size(); i++) {
                for (int j = 0; j < menuPackageGroups.get(i).itemList.size(); j++) {
                    MenuPackageGroup menuPackageGroup = menuPackageGroups.get(i);
                    MenuItem item = menuPackageGroup.itemList.get(j);
                    for (int k = 0; k < menuItem.menuBiz.selectedPackageItems.size(); k++) {
                        //匹配已选择的套餐菜品子项
                        MenuItem choiceItem = menuItem.menuBiz.selectedPackageItems.get(k);
                        if (TextUtils.equals(item.currentUnit.fiOrderUintCd, choiceItem.currentUnit.fiOrderUintCd) &&
                                TextUtils.equals(menuPackageGroup.id, choiceItem.packSubID)) {
                            //设置选中数量，已买-已退
                            item.menuBiz.buyNum = choiceItem.menuBiz.buyNum.subtract(choiceItem.menuBiz.voidNum);
                            item.menuBiz.note = choiceItem.menuBiz.note.trim();
                            item.menuBiz.fsGeneralNote = choiceItem.menuBiz.fsGeneralNote;
                            item.menuBiz.fsSpecialNote = choiceItem.menuBiz.fsSpecialNote;
                            item.menuBiz.batchGeneralNote = choiceItem.menuBiz.batchGeneralNote;
                            item.menuBiz.batchSpecialNote = choiceItem.menuBiz.batchSpecialNote;
                            item.menuBiz.selectNote = choiceItem.menuBiz.selectNote;
                            //item.currentPractice = choiceItem.currentPractice;
                            item.menuBiz.updateSelectMulPractice(choiceItem.menuBiz.selectMulProcedure);
                            //选中操作
                            if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0) {
                                selectCache.put(item.getMenuPackageItemId(menuPackageGroups.get(i).id), true);
                            }
                            break;
                        }
                    }
                }
            }
            selectedPackageItems.clear();
            selectedPackageItems.addAll(menuItem.menuBiz.selectedPackageItems);
        }
        mPackageTitleLabel.setText(menuItem.name);
        showMenuPackageItemChoiceFragment();
    }

    /**
     * 显示套餐子项要求编辑
     */
    public void showMenuPackageItemRequestEditorFragment() {
        MenuPackageItemRequestFragment fragment = new MenuPackageItemRequestFragment();
        fragment.setParam(systemCustomRequests, DinnerMenuUtil.getRequestByMenuItem(operationCache), operationCache.menuBiz.selectNote, new MenuPackageItemRequestFragment.OnMenuPackageItemRequestListener() {
            @Override
            public void onMenuPackageItemRequestDataChanged(List<NoteItemModel> noteItemModels) {
                operationCache.menuBiz.selectNote = noteItemModels;
                operationCache.menuBiz.buildNotesString();
                adapter.notifyDataSetChanged();
            }
        });
        getChildFragmentManager().beginTransaction().replace(R.id.mPackageEditorContentLayout, fragment, "choiceFragment").commitAllowingStateLoss();
    }

    /**
     * 显示套餐编辑
     */
    public void showMenuPackageItemChoiceFragment() {
        MenuPackageItemChoiceFragment choiceFragment = new MenuPackageItemChoiceFragment();
        choiceFragment.setParam(menuPackageGroups, selectCache, new MenuPackageItemChoiceFragment.OnMenuPackageItemChoiceListener() {

            @Override
            public void onMenuPackageItemDataChanged(ArrayList<MenuItem> modules, String voidReason, UserDBModel voidUser) {
                itemVoidReason = voidReason;
                itemVoidUser = voidUser;
                refreshPackageItemList(modules);
            }
        }, isOrdered, isMember);
        getChildFragmentManager().beginTransaction().replace(R.id.mPackageEditorContentLayout, choiceFragment, "choiceFragment").commitAllowingStateLoss();
    }

    /**
     * 显示做法编辑
     */
    public void showMenuPackageItemMethodFragment() {
        MenuPackageItemMethodChoiceFragment methodFragment = new MenuPackageItemMethodChoiceFragment();
        methodFragment.setParam(operationCache.itemID, ClientMenuDBUtil.getMenuProcedureList(operationCache.itemID), operationCache.menuBiz.selectMulProcedure,
                new MenuPackageItemMethodChoiceFragment.OnMenuPackageItemMethodChoiceListener() {
                    @Override
                    public void onMenuPackageItemChoiceChanged(List<AskDBModel> selectMulProcedure) {
                        //operationCache.currentPractice = currentAsk;
                        operationCache.menuBiz.updateSelectMulPractice(selectMulProcedure);
                        adapter.notifyDataSetChanged();
                    }
                });
        getChildFragmentManager().beginTransaction().replace(R.id.mPackageEditorContentLayout, methodFragment, "mehtodFragment").commitAllowingStateLoss();
    }

    private void refreshPackageItemList(ArrayList<MenuItem> modules) {
        selectedPackageItems.clear();
        selectedPackageItems.addAll(modules);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mPackageEditorCommitLabel:
                if (commonCheck(v)) {
                    return;
                }
                Fragment fragment = getChildFragmentManager().findFragmentById(R.id.mPackageEditorContentLayout);
                if (fragment instanceof MenuPackageItemRequestFragment) {
                    ((MenuPackageItemRequestFragment) fragment).hideSoftInput();
                }
                if (fragment instanceof MenuPackageItemRequestFragment || fragment instanceof MenuPackageItemMethodChoiceFragment) {
                    showMenuPackageItemChoiceFragment();
                    return;
                }
                menuItem.menuBiz.selectedPackageItems.clear();
                menuItem.menuBiz.selectedPackageItems.addAll(selectedPackageItems);
                PackageItemEditViewBean data = new PackageItemEditViewBean();
                data.menu = menuItem;
                data.voidReason = itemVoidReason;
                data.voidUser = itemVoidUser;
                callback.callBack(true, 0, "", data);
                dismiss();
                break;
            case R.id.mPackageEditorCancelLabel:
                dismiss();
                break;
            case R.id.mPackageEditLabel:
            case R.id.mPackageTitleLabel:
                showMenuPackageItemChoiceFragment();
                break;
            default:
                break;
        }
    }

    private boolean commonCheck(View v) {
        if (!ButtonClickTimer.canClick()) {
            return true;
        }
        String errorInfo = DinnerMenuUtil.checkSelectMustSelectedV2(menuItem, menuPackageGroups, selectCache);
        if (!TextUtils.isEmpty(errorInfo)) {
            RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, errorInfo);
            ToastUtil.showToast(errorInfo);
            return true;
        }
        for (MenuItem item : selectedPackageItems) {
            errorInfo = DinnerMenuUtil.checkMultiPracticeInPackage(item);
            if (!TextUtils.isEmpty(errorInfo)) {
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, errorInfo);
                ToastUtil.showToast(errorInfo);
                return true;
            }
        }
        return false;
    }

    class MenuExtraItemAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return selectedPackageItems.size();
        }

        @Override
        public Object getItem(int position) {
            return selectedPackageItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder holder;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_menu_package_select_item, parent, false);
                holder = new Holder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }
            holder.initData(position);
            return convertView;
        }
    }

    class Holder implements View.OnClickListener {
        private TextView mPackageEditorItemNoteLabel;
        private TextView mPackageEditorItemNameLabel;
        private TextView mPackageEditorItemRequestLabel;
        private TextView mPackageEditorItemMethodLabel;
        private MenuItem item;

        public Holder(View v) {
            mPackageEditorItemNameLabel = (TextView) v.findViewById(R.id.mPackageEditorItemNameLabel);
            mPackageEditorItemNoteLabel = (TextView) v.findViewById(R.id.mPackageEditorItemNoteLabel);
            mPackageEditorItemRequestLabel = (TextView) v.findViewById(R.id.mPackageEditorItemRequestLabel);
            mPackageEditorItemMethodLabel = (TextView) v.findViewById(R.id.mPackageEditorItemMethodLabel);
            // 已下单套餐不能编辑要求和做法，按钮直接置灰
            if (isOrdered) {
                mPackageEditorItemRequestLabel.setEnabled(false);
                mPackageEditorItemMethodLabel.setEnabled(false);
                mPackageEditorItemRequestLabel.setOnClickListener(null);
                mPackageEditorItemMethodLabel.setOnClickListener(null);
            } else {
                mPackageEditorItemRequestLabel.setEnabled(true);
                mPackageEditorItemMethodLabel.setEnabled(true);
                mPackageEditorItemRequestLabel.setOnClickListener(this);
                mPackageEditorItemMethodLabel.setOnClickListener(this);
            }
            if (AppCache.getInstance().isRetailMode()) {
                mPackageEditorItemMethodLabel.setVisibility(View.GONE);
            } else {
                mPackageEditorItemMethodLabel.setVisibility(View.VISIBLE);
            }
        }

        public void initData(int position) {
            item = selectedPackageItems.get(position);
            mPackageEditorItemNameLabel.setText(item.name + " x " + item.menuBiz.buyNum.toPlainString());
            /*if (TextUtils.isEmpty(item.menuBiz.note) && item.currentPractice == null) {
                mPackageEditorItemNoteLabel.setVisibility(View.GONE);
            } else {
                mPackageEditorItemNoteLabel.setText(getMenuItemNoteContent());
                mPackageEditorItemNoteLabel.setVisibility(View.VISIBLE);
            }*/
            if (TextUtils.isEmpty(item.menuBiz.note) && item.menuBiz.selectMulProcedure.size() == 0) {
                mPackageEditorItemNoteLabel.setVisibility(View.GONE);
            } else {
                mPackageEditorItemNoteLabel.setText(getMenuItemNoteContent());
                mPackageEditorItemNoteLabel.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.mPackageEditorItemRequestLabel:
                    operationCache = item;
                    showMenuPackageItemRequestEditorFragment();
                    break;
                case R.id.mPackageEditorItemMethodLabel:
                    operationCache = item;
                    showMenuPackageItemMethodFragment();
                    break;
                default:
                    break;
            }
        }

        /**
         * 获取备注信息
         *
         * @return
         */
        public String getMenuItemNoteContent() {
            StringBuilder demand = new StringBuilder(item.menuBiz.note);
           /* if (item.currentPractice != null) {
                demand.append(" ").append(item.currentPractice.fsAskName);
            }*/
            demand.append(" ").append(item.menuBiz.selectedExtraStr);
            return demand.toString();
        }
    }

    public void setParam(MenuItem menuItem, IResponse<PackageItemEditViewBean> iResponse) {
        setParam(menuItem, iResponse, false, false);
    }

    public void setParam(MenuItem menuItem, IResponse<PackageItemEditViewBean> iResponse, boolean isOrdered, boolean isMember) {
        this.menuItem = menuItem;
        this.callback = iResponse;
        this.isOrdered = isOrdered;
        this.isMember = isMember;
    }
}
