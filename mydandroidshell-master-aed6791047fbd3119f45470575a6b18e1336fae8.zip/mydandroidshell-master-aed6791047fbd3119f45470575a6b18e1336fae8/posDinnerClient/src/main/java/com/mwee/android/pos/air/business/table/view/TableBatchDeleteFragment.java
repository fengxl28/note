package com.mwee.android.pos.air.business.table.view;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.air.business.table.processor.TableManagerProcessor;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2017/10/15.
 * 批量删除桌台界面
 */

public class TableBatchDeleteFragment extends BaseListFragment<AirTableManageInfo> implements View.OnClickListener {
    private TitleBar mTitleBar;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchChoiceValueLabel;
    private Button mAskBatchDeleteBtn;
    private Button mAskBatchCancelBtn;
    private TableManagerProcessor mProcessor;
    private ArrayList<String> choiceStates = new ArrayList<>();
    private OnTableBatchDeleteListener listener;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_ask_batch_delete;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mTitleBar = (TitleBar) view.findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
        mTitleBar.setTitle(R.string.table_batch_delete_title);
        ((TextView) view.findViewById(R.id.title_tips)).setText("请选择需要删除的桌台");
        mAskBatchChoiceAllLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceAllLabel);
        mAskBatchChoiceValueLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceValueLabel);
        mAskBatchDeleteBtn = (Button) view.findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchCancelBtn = (Button) view.findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        modules.addAll(mProcessor.tableManageInfoToShowList);
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(getContext(), 7);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.air_table_manager_item, parent, false));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mAskBatchDeleteBtn:
                doBatchDeleteChoice();
                break;
            case R.id.mAskBatchCancelBtn:
                dismissSelf();
                break;
            case R.id.mAskBatchChoiceAllLabel:
                doChoiceAllClick();
                break;
            default:
                break;
        }
    }

    private void doChoiceAllClick() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    private void doBatchDeleteChoice() {

        DialogManager.showExecuteDialog(getActivityWithinHost(),
                "是否确认删除？",
                getStringWithinHost(R.string.cacel),
                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                    @Override
                    public void response() {
                        ProgressManager.showProgress(TableBatchDeleteFragment.this);
                        mProcessor.batchDeleteTable(choiceStates, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                ProgressManager.closeProgress(TableBatchDeleteFragment.this);
                                if (result) {
                                    listener.onDeleteSuccess();
                                    dismissSelf();
                                } else {
                                    ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(info) ? info : "删除桌台失败");
                                }
                            }
                        });
                    }
                }, null);


    }

    private void refreshUI() {
        mAskBatchChoiceValueLabel.setText(String.format(getString(R.string.ask_choice_size_label), choiceStates.size()));
        mAskBatchDeleteBtn.setEnabled(choiceStates.size() > 0);
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView table_name_tv;
        private TextView table_free_person_count_tv;
        private TextView staus_tv;
        private TextView select_tv;
        private AirTableManageInfo tableManageInfo;

        public Holder(View v) {
            super(v);
            v.setOnClickListener(this);
            table_name_tv = (TextView) v.findViewById(R.id.table_name_tv);
            table_free_person_count_tv = (TextView) v.findViewById(R.id.table_free_person_count_tv);
            staus_tv = (TextView) v.findViewById(R.id.staus_tv);
            select_tv = (TextView) v.findViewById(R.id.select_tv);
        }

        @Override
        public void bindData(int position) {
            tableManageInfo = modules.get(position);
            table_name_tv.setText(tableManageInfo.fsmtablename);
            table_free_person_count_tv.setText(String.format("%s人桌", tableManageInfo.fiseats));
            if (tableManageInfo.fisharebillsInUse > 0 || android.text.TextUtils.equals(tableManageInfo.fsmtablesteid, "2")) {
                staus_tv.setVisibility(View.VISIBLE);
            } else {
                staus_tv.setVisibility(View.GONE);
            }
            select_tv.setVisibility(View.VISIBLE);
            select_tv.setSelected(choiceStates.contains(tableManageInfo.fsmtableid + ""));
        }

        @Override
        public void onClick(View v) {
            if (TextUtils.equals(tableManageInfo.fsmtablesteid, "2") || tableManageInfo.fisharebillsInUse > 0) {
                ToastUtil.showToast(tableManageInfo.fsmtablename + " 桌台正在被占用");
                return;
            }
            choice(tableManageInfo.fsmtableid);
            adapter.notifyItemChanged(modules.indexOf(tableManageInfo));
            mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
            refreshUI();

        }
    }

    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }

    private boolean isChoiceAll() {
        for (int i = 0; i < modules.size(); i++) {
            if (!TextUtils.equals(modules.get(i).fsmtablesteid, "2") && modules.get(i).fisharebillsInUse <= 0 && !choiceStates.contains(modules.get(i).fsmtableid)) {
                return false;
            }
        }
        return true;
    }

    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < modules.size(); i++) {
            if (TextUtils.equals(modules.get(i).fsmtablesteid, "2") || modules.get(i).fisharebillsInUse > 0) {
                continue;
            }
            choiceStates.add(modules.get(i).fsmtableid + "");
        }
    }

    private void cancelChoiceAll() {
        choiceStates.clear();
    }

    public void setParam(TableManagerProcessor mProcessor, OnTableBatchDeleteListener listener) {
        this.mProcessor = mProcessor;
        this.listener = listener;
    }

    public interface OnTableBatchDeleteListener {
        void onDeleteSuccess();
    }
}
