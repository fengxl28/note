package com.mwee.android.pos.air.business.setting;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.io.Serializable;

/**
 * Created by qinwei on 2018/3/12.
 */

public class TakeOutSettingContainerFragment extends BaseListFragment<TakeOutSettingContainerFragment.ClazzInfo> {

    private int choicePosition;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.air_set_takeout_fragment;
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        adapter.modules.add(new ClazzInfo("美团", MeiTuanTakeOutSettingFragment.class));
        adapter.modules.add(new ClazzInfo("饿了么", ElemeTakeOutSettingFragment.class));
        adapter.modules.add(new ClazzInfo("其他", OtherTakeOutSettingFragment.class));
        adapter.notifyDataSetChanged();
        setCurrentTab(0);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.menu_class_son_category_item_layout, parent, false));
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView label;
        private int position;

        public Holder(View itemView) {
            super(itemView);
            label = (TextView) itemView;
            label.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            this.position = position;
            label.setText(modules.get(position).name);
            this.position = position;
            if (position == choicePosition) {
                ViewToolsUtil.setBackgroundResourceKeepPadding(label, R.drawable.bg_air_category_item_checked);
                label.setTextColor(getResources().getColor(R.color.system_red));
            } else {
                ViewToolsUtil.setBackgroundResourceKeepPadding(label, R.color.white);
                label.setTextColor(getResources().getColor(R.color.color_3a3a3a));
            }
        }

        @Override
        public void onClick(View v) {
            choicePosition = this.position;
            adapter.notifyDataSetChanged();
            setCurrentTab(position);
        }
    }

    private void setCurrentTab(int position) {
        try {
            ClazzInfo clazzInfo = adapter.modules.get(position);
            getActivityWithinHost().getSupportFragmentManager().beginTransaction().replace(R.id.take_out_set_container, clazzInfo.clazz.newInstance()).commit();
        } catch (java.lang.InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    class ClazzInfo implements Serializable {
        public ClazzInfo(String name, Class<? extends BaseFragment> clazz) {
            this.name = name;
            this.clazz = clazz;
        }

        public String name;
        public Class<? extends BaseFragment> clazz;
    }
}
