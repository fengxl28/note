package com.mwee.android.pos.air.business.member.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.SettingHelper;

/**
 * Created by qinwei on 2017/10/19.
 */

public class MemberDiscountSettingFragment extends BaseFragment implements CompoundButton.OnCheckedChangeListener {
    private Switch mMemberRuleSettingSwitch;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_discount_settings, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mMemberRuleSettingSwitch = (Switch) view.findViewById(R.id.mMemberRuleSettingSwitch);
    }

    private void initData() {
        mMemberRuleSettingSwitch.setChecked(SettingHelper.isAutoUsedMemberPrice());
        mMemberRuleSettingSwitch.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        ActionLog.addLog("更多设置->点击了默认使用会员价", "", "", ActionLog.SS_MORE_JOIN, "");
        SettingProcessor.refreshSettingStatus(META.AUTO_USE_MEMBER_PRICE, isChecked ? "1" : "0");
    }
}
