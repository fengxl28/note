package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberPasswordUpdate extends BaseMemberParam {
    public String card_no;//卡号
    public String password;//密码
    public int m_shopid;
    public MemberPasswordUpdate() {
    }
}
