package com.mwee.android.pos.air.business.member;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.base.ContainerFragmentActivity;
import com.mwee.android.pos.air.business.member.dialog.MemberEditorDialogFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberConsumptionRecordingFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberRechargeRecordingFragment;
import com.mwee.android.pos.air.business.member.utils.MemberUtils;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.member.MemberInfoContainerFragment;
import com.mwee.android.pos.business.member.biz.IMemberProcess;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.LogUtil;

/**
 * 会员识别界面
 * Created by qinwei on 2017/2/20.
 */

public class MemberQueryFragment extends HomeFragment implements View.OnClickListener, TextView.OnEditorActionListener {
    public static final String TAG = MemberQueryFragment.class.getSimpleName();
    private EditText mMemberSelectEdt;
    private Button mMemberSelectCommitBtn;
    private Button mMemberAddBtn;
    private IMemberProcess mMemberProcess;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_select, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMemberSelectEdt = (EditText) view.findViewById(R.id.mMemberSelectEdt);
        mMemberSelectEdt.postDelayed(new Runnable() {
            @Override
            public void run() {
                mMemberSelectEdt.setText("");
            }
        }, 50);
        mMemberSelectEdt.setOnEditorActionListener(this);
        mMemberSelectCommitBtn = (Button) view.findViewById(R.id.mMemberSelectCommitBtn);
        mMemberAddBtn = (Button) view.findViewById(R.id.mMemberAddBtn);
        mMemberSelectCommitBtn.setOnClickListener(this);
        mMemberAddBtn.setOnClickListener(this);
        mMemberProcess = new MemberProcess();

        if (APPConfig.isAir()) {
            view.findViewById(R.id.mRecordingLayout).setVisibility(View.VISIBLE);
            view.findViewById(R.id.tvRechargeRecording).setOnClickListener(this);
            view.findViewById(R.id.tvConsumRecording).setOnClickListener(this);
        }


    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mMemberAddBtn:
                showMemberAddDialog();
                break;
            case R.id.mMemberSelectCommitBtn:
                if (validateInput(mMemberSelectEdt.getText().toString().trim())) {
                    doSelectRequest(mMemberSelectEdt.getText().toString().trim());
                }
                break;
            case R.id.tvRechargeRecording://储值记录

                String number = mMemberSelectEdt.getText().toString().trim();

                Bundle bundle = new Bundle();
                if (!android.text.TextUtils.isEmpty(number)) {
                    if (MemberUtils.checkIsPhoneNumber(number) || MemberUtils.checkIsCardNo(number)) {
                        bundle.putSerializable("key_member_info", number);
                    }
                }
                Intent intent = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
                intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("储值记录", MemberRechargeRecordingFragment.class));
                intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle);
                getActivityWithinHost().startActivity(intent);
                //KeyboardManager.hideSoftInput(mMemberSelectEdt);

                break;
            case R.id.tvConsumRecording://消费记录

                String number1 = mMemberSelectEdt.getText().toString().trim();

                Bundle bundle1 = new Bundle();
                if (!android.text.TextUtils.isEmpty(number1)) {
                    if (MemberUtils.checkIsPhoneNumber(number1) || MemberUtils.checkIsCardNo(number1)) {
                        bundle1.putSerializable("key_member_info", number1);
                    }
                }
                Intent intent1 = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
                intent1.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("消费记录", MemberConsumptionRecordingFragment.class));
                intent1.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle1);
                getActivityWithinHost().startActivity(intent1);

                //KeyboardManager.hideSoftInput(mMemberSelectEdt);

                break;
            default:
                break;
        }
    }

    private void showMemberAddDialog() {
        MemberEditorDialogFragment dialog = new MemberEditorDialogFragment();
        DialogManager.showCustomDialog(this, dialog, "MemberEditorDialogFragment");
    }

    private boolean validateInput(String account) {
        if (TextUtils.validate(account)) {
            return true;
        }
        ToastUtil.showToast(R.string.member_query_validate_hint);
        return false;
    }

    private void doSelectRequest(String account) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_query_ing);
        LogUtil.log(TAG, "会员查询ing");
        mMemberProcess.onlyLoadMemberInfo(account, new IResponse<QueryMemberInfoResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse data) {

                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    mMemberSelectEdt.setText(null);
                    LogUtil.log(TAG, "会员查询done cardNo=" + data.memberCardModel.card_info.card_no);
                    showMemberInfoFragment(data.memberCardModel);
                } else {
                    LogUtil.log(TAG, "会员查询failure msg=" + msg);
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    private void showMemberInfoFragment(MemberCardModel memberCardModel) {
        LogUtil.log(TAG, "显示会员详情界面 cardNo=" + memberCardModel.card_info.card_no);
        MemberInfoContainerFragment fragment = MemberInfoContainerFragment.getInstance(memberCardModel);
        FragmentController.addFragmentWithHide(getFragmentManager(), fragment, MemberInfoContainerFragment.TAG, R.id.main_menufragment, false);
        dismissSelf();
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            switch (v.getId()) {
                case R.id.mMemberSelectEdt:
                    String cardNo = mMemberSelectEdt.getText().toString();
                    if (validateInput(cardNo)) {
                        doSelectRequest(cardNo);
                    }
                    break;
                default:
                    break;
            }
        }
        return false;
    }

}
