package com.mwee.android.pos.business.member.view;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.member.BalanceChangesListFragment;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.member.entity.MemberHistoryResponse;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.net.model.MemberHistoryScoreModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.AnimatorListenerImpl;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/**
 * MemberScoreFragment
 *
 * @author ZM
 * @date 17/2/20
 */
public class MemberScoreFragment extends BaseListFragment<MemberScoreDetailModel.ScoreData> {
    private static final String KEY_MEMBER_INFO = "key_score_member_info";
    private static final String KEY_CARD_ID = "key_card_id";

    private ImageView mBalanceChangesTopBtn;

//    private MemberCardModel memberCardModel;//会员

//    private int last_id = 0;

    private int mCurrentPage = 1;
    private String mCardNo;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_member_score_layout;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new MemberSocreViewHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.fragment_member_score_item, parent, false));
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mBalanceChangesTopBtn = (ImageView) view.findViewById(R.id.mBalanceChangesTopImg);
        mBalanceChangesTopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPullRecyclerView.smoothScrollToPosition(0);
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        mCardNo = getArguments().getString(KEY_CARD_ID);
//        memberCardModel = (MemberCardModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mPullRecyclerView.setRefreshing();
    }

    /*private void loadDataFromServer(final int mode) {
        MemberApi.loadMemberHistoryScore(memberCardModel.card_info.card_no, last_id, new SocketCallback<MemberHistoryResponse>() {
            @Override
            public void callback(SocketResponse<MemberHistoryResponse> response) {
                if (response == null) {
                    return;
                }
                if (response.success()) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    MemberHistoryResponse data = response.data;
                    if (data.havenext == 0) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (last_id == 0 && ListUtil.isEmpty(data.list)) {
                        mPullRecyclerView.showEmptyView();
                    } else {
                        mPullRecyclerView.showContent();
                        modules.addAll(data.list);
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    if (!android.text.TextUtils.isEmpty(response.message)) {
                        ToastUtil.showToast(response.message);
                    }
                    if (mode == PullRecyclerView.STATE_PULL_TO_START) {
                        if (modules.size() == 0) {
                            mPullRecyclerView.showEmptyView();
                        }
                        mPullRecyclerView.onRefreshCompleted(mode);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                    }
                }
            }
        });
    }*/

    private void loadNewDataFromServer(final int mode) {
        ClientMemberApi.queryMemberScore(mCardNo, mCurrentPage, response -> {
            if(response == null || response.data == null){
                mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                if(mCurrentPage > 1){
                    mCurrentPage --;
                }
                return;
            }
            if(response.success()){
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                MemberScoreDetailModel data = response.data;
                if(mCurrentPage < data.pages){
                    mPullRecyclerView.onRefreshCompleted(mode);
                }else{
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                }
                if (ListUtil.isEmpty(data.rows)) {
                    if(mCurrentPage == 1){
                        mPullRecyclerView.showEmptyView();
                    }
                } else {
                    mPullRecyclerView.showContent();
                    modules.addAll(data.rows);
                    adapter.notifyDataSetChanged();
                }
            }else{
                if(mCurrentPage > 1){
                    mCurrentPage --;
                }
                if (!TextUtils.isEmpty(response.message)) {
                    ToastUtil.showToast(response.message);
                }
                if (mode == PullRecyclerView.STATE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    /**
     * 下拉刷新数据
     *
     * @param mode
     */
    @Override
    public void onRefresh(int mode) {

        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
//            last_id = 0;
            mCurrentPage = 1;
        } else {
//            if (!modules.isEmpty()) {
//                last_id = modules.get(modules.size() - 1).id;
//            }
            mCurrentPage ++;
        }
        loadNewDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadNewDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    public void onScrollUp() {
        super.onScrollUp();
        if (!AnimatorListenerImpl.isRunning && mBalanceChangesTopBtn.getVisibility() == View.GONE) {
            mBalanceChangesTopBtn.setVisibility(View.VISIBLE);
            ObjectAnimator animator = ObjectAnimator.ofFloat(mBalanceChangesTopBtn, "alpha", 0f, 1f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mBalanceChangesTopBtn.setVisibility(View.VISIBLE);
                }
            });
            animator.start();
        }
    }

    @Override
    public void onScrollDown() {
        super.onScrollDown();
        if (!AnimatorListenerImpl.isRunning && mBalanceChangesTopBtn.getVisibility() == View.VISIBLE) {
            ObjectAnimator animator = ObjectAnimator.ofFloat(mBalanceChangesTopBtn, "alpha", 1f, 0f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mBalanceChangesTopBtn.setVisibility(View.GONE);
                }
            });
            animator.start();
        }
    }


    private class MemberSocreViewHolder extends BaseViewHolder {
        public TextView tv_member_score_title;
        public TextView tv_member_score_num;
        public TextView tv_member_score_directions;
        public TextView tv_member_score_time;
//        private MemberHistoryScoreModel historyScoreModel;
        private MemberScoreDetailModel.ScoreData scoreData;

        public MemberSocreViewHolder(View itemView) {
            super(itemView);
            tv_member_score_title = (TextView) itemView.findViewById(R.id.tv_member_score_title);
            tv_member_score_num = (TextView) itemView.findViewById(R.id.tv_member_score_num);
            tv_member_score_directions = (TextView) itemView.findViewById(R.id.tv_member_score_directions);
            tv_member_score_time = (TextView) itemView.findViewById(R.id.tv_member_score_time);
        }

        @Override
        public void bindData(int position) {
            /*historyScoreModel = modules.get(position);
            tv_member_score_title.setText(historyScoreModel.title);
            if (historyScoreModel.score > 0) {
                tv_member_score_num.setTextColor(getResources().getColor(R.color.color_ffa800));
            } else {
                tv_member_score_num.setTextColor(getResources().getColor(R.color.color_424242));
            }
            tv_member_score_num.setText(historyScoreModel.score + "");
            tv_member_score_directions.setText(historyScoreModel.description);
            tv_member_score_time.setText(historyScoreModel.add_time);*/

            scoreData = modules.get(position);
            tv_member_score_title.setText(scoreData.title);
            if (scoreData.score > 0) {
                tv_member_score_num.setTextColor(getResources().getColor(R.color.color_ffa800));
            } else {
                tv_member_score_num.setTextColor(getResources().getColor(R.color.color_424242));
            }
            tv_member_score_num.setText(scoreData.score + "");
            tv_member_score_directions.setText(scoreData.description);
            if(TextUtils.isEmpty(scoreData.addTime)){
                tv_member_score_time.setVisibility(View.GONE);
            }else{
                tv_member_score_time.setText(BalanceChangesListFragment.long2Date(StringUtil.toLong(scoreData.addTime,0)*1000));
            }
        }
    }

    public static MemberScoreFragment getInstance(MemberCardModel memberCardModel) {
        MemberScoreFragment memberScoreFragment = new MemberScoreFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        memberScoreFragment.setArguments(bundle);
        return memberScoreFragment;
    }

    public static MemberScoreFragment getInstance(String cardNo) {
        MemberScoreFragment memberScoreFragment = new MemberScoreFragment();
        Bundle bundle = new Bundle();
        bundle.putString(KEY_CARD_ID, cardNo);
        memberScoreFragment.setArguments(bundle);
        return memberScoreFragment;
    }
}
