package com.mwee.android.pos.business.common.notification;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.MainThread;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.tools.DisplayUtil;
import com.mwee.android.tools.LogUtil;

import java.util.concurrent.LinkedBlockingDeque;

/**
 * @ClassName: CommonNotice
 * @Description:
 * @author: SugarT
 * @date: 2018/7/9 下午3:44
 */
public class CommonNotice {

    public final static String TAG = CommonNotice.class.getSimpleName();

    private WindowManager mWindowManager = null;

    private View mView;
    private TextView mTvTitle;
    private TextView mTvContent;
    private Button mBtnPositive;
    private Button mBtnNegative;

    private WindowManager.LayoutParams mParams;

    private CommonNoticeCallback mPositiveCallback;
    private CommonNoticeCallback mNegativeCallback;

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick(v)) {
                return;
            }
            switch (v.getId()) {
                case R.id.mMessageGoCenterBtn:
                    // 确认
                    if (mPositiveCallback != null) {
                        mPositiveCallback.callback();
                    }
                    break;
                case R.id.mMessageCloseBtn:
                    // 取消
                    if (mNegativeCallback != null) {
                        mNegativeCallback.callback();
                    }
                    break;
                default:
                    break;
            }
            release();
        }
    };

    private boolean isShow = false;

    private LinkedBlockingDeque<Builder> mDeque = new LinkedBlockingDeque<>();

    private volatile static CommonNotice instance;

    public static CommonNotice getInstance() {
        if (instance == null) {
            synchronized (CommonNotice.class) {
                if (instance == null)
                    instance = new CommonNotice();
            }
        }
        return instance;
    }

    private void build(Builder builder) {
        synchronized (mDeque) {
            if (mDeque == null) {
                mDeque = new LinkedBlockingDeque<>();
            }
            if (mDeque.contains(builder)) {
                mDeque.remove(builder);
            }
            mDeque.add(builder);
        }
    }

    public void show() {
        if (mDeque == null || mDeque.isEmpty()) {
            return;
        }
        Builder builder = mDeque.peekLast();
        if (builder == null) {
            return;
        }
        if (mView == null) {
            initView();
        }
        if (mParams == null) {
            initParams();
        }
        show(builder);
    }

    @MainThread
    private void show(Builder builder) {
        if (builder == null) {
            return;
        }

        if (Looper.myLooper() != Looper.getMainLooper()) {
            new Handler(Looper.getMainLooper()).post(() -> show(builder));
            return;
        }

        if (TextUtils.isEmpty(builder.mTitle)) {
            mTvTitle.setVisibility(View.GONE);
        } else {
            mTvTitle.setVisibility(View.VISIBLE);
            mTvTitle.setText(builder.mTitle);
        }
        mTvContent.setText(builder.mContent);
        mBtnPositive.setText(builder.mPisitive);
        mBtnNegative.setText(builder.mNegative);

        mPositiveCallback = builder.mPositiveCallback;
        mNegativeCallback = builder.mNegativeCallback;

        if (!isShow) {
            mWindowManager.addView(mView, mParams);
            isShow = true;
        }
    }

    private void initView() {
        mView = LayoutInflater.from(GlobalCache.getContext()).inflate(R.layout.layout_message_print_error, null);
        if (mView == null) {
            return;
        }
        mTvTitle = mView.findViewById(R.id.mMessageTitle);
        mTvContent = mView.findViewById(R.id.mMessageReason);
        mBtnPositive = mView.findViewById(R.id.mMessageGoCenterBtn);
        mBtnNegative = mView.findViewById(R.id.mMessageCloseBtn);
        mBtnPositive.setOnClickListener(mOnClickListener);
        mBtnNegative.setOnClickListener(mOnClickListener);
    }

    private void initParams() {
        mParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) GlobalCache.getContext().getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (Settings.canDrawOverlays(GlobalCache.getContext())) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                } else {
                    mParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                }
            } else {
                if (BaseActivity.topActivity != null) {
                    mParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;
                    // 添加窗口机制验证
                    IBinder windowToken = BaseActivity.topActivity.getWindow().getDecorView().getWindowToken();
                    mParams.token = windowToken;
                }
            }
        } else {
            mParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }
        mParams.format = PixelFormat.RGBA_8888;
        mParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        mParams.gravity = Gravity.RIGHT | Gravity.TOP;
        mParams.width = DisplayUtil.dp2px(GlobalCache.getContext(), 430);
        mParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        mParams.windowAnimations = android.R.style.Animation_Translucent;
    }

    public void release() {
        if (mDeque != null) {
            try {
                mDeque.removeLast();
            } catch (Exception e) {
            }

            if (mDeque.isEmpty()) {
                if (mWindowManager != null) {
                    mWindowManager.removeView(mView);
                }

                isShow = false;

                mParams = null;

                mPositiveCallback = null;
                mNegativeCallback = null;

                mWindowManager = null;

                instance = null;
                return;
            }
        }
        Builder builder = mDeque.peekLast();
        if (builder == null) {
            release();
        }
        show(builder);
    }

    public static class Builder {

        @NoticeType
        private int mType = NoticeType.UnKnow;

        /**
         * 标题
         */
        private String mTitle = "";

        /**
         * 内容太
         */
        private String mContent = "";

        /**
         * 确认文案
         */
        private String mPisitive = "";

        /**
         * 取消文案
         */
        private String mNegative = "";

        /**
         * 确认回调
         */
        private CommonNoticeCallback mPositiveCallback = null;

        /**
         * 取消回调
         */
        private CommonNoticeCallback mNegativeCallback = null;

        public Builder setType(@NoticeType int type) {
            mType = type;
            return this;
        }

        public Builder setTitle(String title) {
            mTitle = title;
            return this;
        }

        public Builder setContent(String content) {
            mContent = content;
            return this;
        }

        public Builder setPisitive(String pisitive) {
            mPisitive = pisitive;
            return this;
        }

        public Builder setNegative(String negative) {
            mNegative = negative;
            return this;
        }

        public Builder setPositiveCallback(CommonNoticeCallback positiveCallback) {
            mPositiveCallback = positiveCallback;
            return this;
        }

        public Builder setNegativeCallback(CommonNoticeCallback negativeCallback) {
            mNegativeCallback = negativeCallback;
            return this;
        }

        public CommonNotice create() {
            if (mType == NoticeType.UnKnow) {
                LogUtil.log("CommonNotice.Builder#create 需要设置悬浮窗类型");
            }
            CommonNotice notice = CommonNotice.getInstance();
            notice.build(this);
            return notice;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return this.mType == ((Builder) obj).mType;
        }
    }
}
