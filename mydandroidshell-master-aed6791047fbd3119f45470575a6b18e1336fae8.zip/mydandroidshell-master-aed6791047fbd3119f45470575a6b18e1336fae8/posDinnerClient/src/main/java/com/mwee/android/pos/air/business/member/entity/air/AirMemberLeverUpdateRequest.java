package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * 更新会员等级列表
 * Created by zhangmin on 2018/1/30.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "crm.membercard.saveMemberLevel",
        contentType = "application/json",
        response = BaseMemberResponse.class,
        saveToLog = true
)
public class AirMemberLeverUpdateRequest extends BaseMemberRequest {

    public Integer level_id;
    public String title;
    public Object up_rule;//会员升级规则
    public Object up_reward;//升级奖励

    public AirMemberLeverUpdateRequest() {
        super("crm.membercard.saveMemberLevel");
    }
}
