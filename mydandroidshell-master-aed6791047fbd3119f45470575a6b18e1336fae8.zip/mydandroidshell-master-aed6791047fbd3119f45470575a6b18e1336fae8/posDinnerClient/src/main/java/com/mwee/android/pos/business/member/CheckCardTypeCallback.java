package com.mwee.android.pos.business.member;


/**
 * Created by lxx on 16/9/8.
 */
public interface CheckCardTypeCallback {
    void callback(String cardNumber, String cardType, String msg);
}
