package com.mwee.android.pos.business.login;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.infocollect.RemoteSocketClientProvider;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.tools.DeviceUtil;

import java.util.HashMap;
import java.util.Map;

import cn.mwee.android.pay.infocollect.InfoCollect;
import cn.mwee.android.pay.infocollect.RuntimeInfoConfig;
import cn.mwee.android.pay.infocollect.source.remote.RemoteClientProvider;
import cn.mwee.android.pay.other.CommonKey;
import cn.mwee.android.pay.other.CommonRunInfoConfig;

/**
 * Description: clien进程 信息收集先上报到业务中心.
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/2/4
 */
public class ClientInfoCollect {
    /**
     * 客户端启动时间
     */
    public static Long sClientLaunch;


    public static void initInfoCollect() {
        RemoteClientProvider clientProvider = new RemoteSocketClientProvider();
        RuntimeInfoConfig.DeviceStateInfo deviceStateInfo = new RuntimeInfoConfig.DeviceStateInfo();

        String account = "";
        ParamvalueDBModel paramvalueDBModel = BizInfoCollect.getAccount(APPConfig.DB_CLIENT);
        if (paramvalueDBModel != null) {
            account = paramvalueDBModel.fsParamValue;
        }
        String id = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        deviceStateInfo.id = String.format("%s(%s)", account, id);
        /**
         * 中控上的软件类型
         */
        deviceStateInfo.softType = BuildConfig.APPID + "";
        deviceStateInfo.type = CommonKey.Type.SOFT;
        deviceStateInfo.lan = DeviceUtil.getLocalIpAddress();
        RuntimeInfoConfig builder = new RuntimeInfoConfig.Builder()
                .enable(true)
                .setLimit(10)
                .clientMode(ClientBindProcessor.isCurrentHostMain())
                .setDeviceStateInfo(deviceStateInfo)
                .setInterval(60 * 3)
                .setRemoteParamProvider(new RuntimeInfoConfig.RemoteParamProvider() {
                    @Override
                    public String getToken() {
                        return "token";
                    }

                    @Override
                    public String getV() {
                        return "V7";
                    }

                    @Override
                    public String getHost() {
                        if (!BaseConfig.isProduct()) {
                            return "http://10.0.18.37:3050/";
                        }
                        return "http://b.mwee.cn/";
                    }
                })
                .setRemoteClientProvider(clientProvider)
                .setLogTree(new BizInfoCollect.TimberTree())
                .build();
        /**
         * 通用运行信息配置
         */
        Map<String, String> remoteHost = new HashMap<>();
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PUSH1, "push.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PUSH2, "push2.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_PCDC, "pcdc.winpos.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_B, "b.mwee.cn");
        remoteHost.put(CommonKey.HostKey.NET_DELAY_MW_MXR, "mxr.dc.mwee.cn");
        CommonRunInfoConfig.setPingRemoteHostMap(remoteHost);
        CommonRunInfoConfig.setPingInterval(60 * 3);
        CommonRunInfoConfig.setMemProcessPackageName(
                "com.mwee.android.pos.dinner",
                "com.mwee.android.pos.dinner:bizcenter",
                "com.mwee.android.pos.dinner:monitor",
                "com.mwee.android.pos.dinner:print"
        );

        InfoCollect.getInstance().init(GlobalCache.getContext(), builder);
        InfoCollect.collectDeviceStateInfo();
    }

    /**
     * 结束上报任务
     */
    public static void destroy() {
        InfoCollect.destroy();
    }


}
