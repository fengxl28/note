package com.mwee.android.pos.business.bill.view;

import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListHomeFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.constants.BillSourceValue;
import com.mwee.android.pos.business.fastfood.api.FastFoodOrderSocketApi;
import com.mwee.android.pos.business.message.UnDealCountMessageModel;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderClientUtil;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderMappingInfo;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bean.GetOrderFromCenterRespone;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.business.netorder.GetNetOrderSimpleInfoResponse;
import com.mwee.android.pos.connect.callback.AbstractCallback;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.order.Order;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by lxx on 16/9/18.
 * 账单管理页面
 */
public class BillFragment extends BaseListHomeFragment<BusinessBean> implements IDriver, View.OnClickListener {
    public static final String TAG = "billFagment";
    public final String NAME = BillFragment.class.getSimpleName();

    /**
     * 没有数据时候的提示
     */
    private TextView bill_fragment_norecord_tv;

    LinkedHashMap<String, TempAppOrderMappingInfo> tempAppOrderMappingInfoMap = new LinkedHashMap<>();

    private BillDataProcess billDataProcess;

    private BillTabView billTabView;

    public static int index = 0;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.bill_fragment;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new BillViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.bill_fragment_item, parent, false));
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        billTabView = view.findViewById(R.id.billTabView);
        bill_fragment_norecord_tv = view.findViewById(R.id.bill_fragment_norecord_tv);

        mPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();

        if (AppCache.getInstance().isRetailMode()) {
            mPullRecyclerView.setBackgroundColor(getResources().getColor(R.color.color_f0f0f0));
        }
    }

    @Override
    protected void initData() {
        super.initData();
        billDataProcess = new BillDataProcess();
        billTabView.setParams(getActivityWithinHost(), billDataProcess);
    }

    @DrivenMethod(uri = TAG + "/messageUndealTip", UIThread = true)
    public void messageUndealTip(UnDealCountMessageModel unDealCountMessageModel) {
        LogUtil.log("账单管理页收到未处理消息通知");
        if (unDealCountMessageModel != null && billTabView != null) {
            LogUtil.log("账单管理页收到未处理消息通知 unMappingOrderCount = " + unDealCountMessageModel.unMappingOrderCount);
            billTabView.updateNoticeImg(unDealCountMessageModel);
        }
    }

    /**
     * 有外卖订单更新了
     */
    @DrivenMethod(uri = TAG + "/refrehMessageData", UIThread = true)
    public void refrehMessageData() {
        LogUtil.log("账单管理页收到有外卖订单更新了通知");
        if (billTabView != null && TextUtils.equals(billTabView.fatherType, BillTabView.NET_ORDER)) {
            billTabView.clickBillNetOrder();
        }
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            billTabView.currentPage = 1;
        } else {
            billTabView.currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @DrivenMethod(uri = TAG + "/loadData")
    public void loadDataFromServer(int mode) {
        if (billTabView.isNetOrderTag()) {
            billTabView.assNetOrderData(new ResultCallback<GetNetOrderSimpleInfoResponse>() {
                @Override
                public void onSuccess(GetNetOrderSimpleInfoResponse data) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (billTabView.currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.tempAppOrderList)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshAdapter(data.tempAppOrderList);
                    }
                    if (data.tempAppOrderMappingInfoMap != null) {
                        tempAppOrderMappingInfoMap.clear();
                        tempAppOrderMappingInfoMap.putAll(data.tempAppOrderMappingInfoMap);
                    }
                    billTabView.refresh(true, modules);
                }

                @Override
                public void onFailure(int code, String msg) {
                    loadDataFailed(mode, code, msg);
                    super.onFailure(code, msg);
                }
            });
        } else {
            billTabView.assData(new ResultCallback<GetOrderFromCenterRespone>() {
                @Override
                public void onSuccess(GetOrderFromCenterRespone data) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (billTabView.currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.orderList2)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshAdapter(data.orderList2);
                    }
                    billTabView.refresh(false, modules);
                }

                @Override
                public void onFailure(int code, String msg) {
                    loadDataFailed(mode, code, msg);
                    super.onFailure(code, msg);
                }
            });
        }
    }

    public void refreshAdapter(List data) {
        modules.addAll(data);
        if (ListUtil.isEmpty(modules)) {
            mPullRecyclerView.setVisibility(View.GONE);
            bill_fragment_norecord_tv.setVisibility(View.VISIBLE);
        } else {
            mPullRecyclerView.setVisibility(View.VISIBLE);
            bill_fragment_norecord_tv.setVisibility(View.GONE);
        }
        adapter.notifyDataSetChanged();
    }

    private void loadDataFailed(int mode, int code, String msg) {
        BaseToastUtil.showToast(msg);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            if (modules.size() == 0) {
                mPullRecyclerView.showEmptyView();
            }
            mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
        } else {
            mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
        }
    }

    @DrivenMethod(uri = TAG + "/refreshNetOrder")
    public void refreshNetOrder() {
        MessageUtil.getUndealMessageCount(AppCache.getInstance().businessDate);
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    @DrivenMethod(uri = TAG + "/refreshOrderList")
    public void refreshOrderList(List data) {
        modules.clear();
        refreshAdapter(data);
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Override
    public void onClick(final View view) {
        switch (view.getId()) {
            // 订单详情
            case R.id.bill_fragment_order_details:
                if (billTabView.isNetOrderTag()) {//外卖
                    BillNetOrderDetailFragment orderDetailFragment = new BillNetOrderDetailFragment();
                    TempAppOrderSimpleInfo orderModel = (TempAppOrderSimpleInfo) view.getTag(R.integer.tv_bill_netorder_print);
                    orderDetailFragment.setParam(orderModel.orderId);
                    FragmentController.addFragmentWithHide(getFragmentManager(), orderDetailFragment,
                            "BillNetOrderDetailFragment", R.id.main_menufragment, false);
                } else {
                    DinnerOrderDetailsFragment fragment = new DinnerOrderDetailsFragment();
                    OrderListModel orderModel = (OrderListModel) view.getTag(R.integer.bill_order_details_tag);
                    fragment.setParam(orderModel.orderID, orderModel.thirdOrderType == NetOrderType.KB_ORDER);
                    FragmentController.addFragmentWithHide(getFragmentManager(), fragment,
                            DinnerOrderDetailsFragment.TAG, R.id.main_menufragment, false);
                }

                break;
            //重打结账单
            case R.id.bill_fragment_netorder_print: {
                PermissionsUtil.requestPermissio(getActivityWithinHost(), AppCache.getInstance().userDBModel, Permission.DINNER_bnRePrnBill, "", new PermissionCallback() {
                    @Override
                    public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                        DialogManager.showExecuteDialog(getActivityWithinHost(), R.string.printer_bill_sure, new DialogResponseListener() {
                            @Override
                            public void response() {
                                TempAppOrderSimpleInfo tempAppOrder = (TempAppOrderSimpleInfo) view.getTag(R.integer.tv_bill_netorder_print);
                                // 外卖单--重新打印
                                NetOrderClientUtil.printNetworkOrder(tempAppOrder.orderId, 1, AppCache.getInstance().currentHostId, AppCache.getInstance().userDBModel.fsUserName);

                                ProgressManager.showProgress(BillFragment.this, BillFragment.this.getStringWithinHost(R.string.loading_printer), true);
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        ProgressManager.closeProgress(BillFragment.this);
                                    }
                                }, 1000);

                                ActionLog.addLog("点击了 账单管理 外卖单 外卖单重新打印小票按钮", tempAppOrder.orderId + "", "", ActionLog.BILL_FRAGMENT, tempAppOrder);
                            }
                        });
                    }
                });
                break;
            }
            //去匹配支付
            case R.id.bill_fragment_netorder_pay: {
                final TempAppOrderSimpleInfo tempAppOrder = (TempAppOrderSimpleInfo) view.getTag(R.integer.tv_bill_netorder_print);
                if (tempAppOrder == null) {
                    return;
                }
                if (TextUtils.isEmpty(tempAppOrder.fssellno)) {
                    return;
                }
                ActionLog.addLog("账单管理页面-->用户点了击外卖结账", tempAppOrder.fssellno, "", ActionLog.PR_PRINT, tempAppOrder);
                billDataProcess.getOrderAndProcessor(BillFragment.this, tempAppOrder.fssellno, new IGetOrder() {
                    @Override
                    public void getOrder(Order order) {
                        if (order != null) {
                            //获取token
                            final Progress progress = ProgressManager.showProgress(BillFragment.this, R.string.bill_loading_order_details);
                            FastFoodOrderSocketApi.loadOrderCacheById(order.orderCache.orderID, new AbstractCallback<StartFastFoodOrderResponse>() {
                                @Override
                                public void onSuccess(StartFastFoodOrderResponse response) {
                                    progress.dismiss();
                                    AppCache.getInstance().currentOrderID = response.fastOrderModel.orderId;
                                    AppCache.getInstance().refreshOrderToken(response.orderOptToken);
                                    OrderDishesJump.showFastFoodDish(BillFragment.this, R.id.main_menufragment, response.fastOrderModel, response.menuItems, response.orderStatus);
                                }

                                @Override
                                public void onFailure(int code, String msg) {
                                    progress.dismiss();
                                    ToastUtil.showToast(TextUtils.isEmpty(msg) ? "操作失败，请稍后重试" : msg);
                                }
                            });
                        }
                    }
                });
            }
            break;
            //重打结账单
            case R.id.bill_fragment_item_print: {
                OrderListModel order = (OrderListModel) view.getTag(R.integer.bill_print_tag);
                billDataProcess.getOrderPrintData(getActivityWithinHost(), order.orderID, billTabView.getBusinessDate(), "" + order.fiSellType, "" + order.orderSource);
                break;
            }
            //反结账
            case R.id.bill_fragment_item_repay: {
                final OrderListModel orderListModel = (OrderListModel) view.getTag(R.integer.bill_repay_tag);
                PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance()
                        .userDBModel, Permission.DINNER_vReCheckAuth, new PermissionCallback() {
                    @Override
                    public void onCall(int errCode, final String msg, UserDBModel userDBModel) {
                        if (orderListModel != null) {
                            // 用户点击反结账;
                            ActionLog.addLog("账单管理页面-->用户点了击反结账", "", "", ActionLog.PAY_REPAY, "");
                            billDataProcess.getOrderAndProcessor(BillFragment.this, orderListModel.orderID, new IGetOrder() {
                                @Override
                                public void getOrder(Order order) {
                                    if (order != null) {
                                        //反结账原因
                                        order.orderCache.antiPayReason = msg;
                                        billOperation.rePay(orderListModel, order, msg);
                                    }
                                }
                            });
                        }
                    }
                });
                break;
            }
            case R.id.bill_fragment_item_pay: {
                final OrderListModel orderListModel = (OrderListModel) view.getTag(R.integer.bill_pay_tag);
                if (orderListModel == null) return;
                if (orderListModel.errorOrderStatus == 2) {//2：已绑定桌台，但此桌台绑定了另外一个订单
                    DialogManager.showSingleDialog(getActivityWithinHost(), orderListModel.fsmtablename +
                            "桌台已被占用，请将该桌台清台后进行订单的重新结账");
                } else {
                    String sellType = orderListModel.fiSellType == 0 ? "正餐" : "快餐";
                    billDataProcess.dealErrorOrder(getActivityWithinHost(), orderListModel, new
                            ResultCallback<Boolean>() {
                                @Override
                                public void onSuccess(Boolean data) {
                                    loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
                                    DialogManager.showSingleDialog(getActivityWithinHost(), "已将此订单与" + orderListModel
                                            .fsmtablename + "桌台重新绑定，请去桌台" + sellType + "单页面重新结账");
                                }
                            });
                    ActionLog.addLog("点击了 账单管理的" + sellType + "异常订单，重新结账", orderListModel.orderID + "", "",
                            ActionLog.BILL_FRAGMENT, orderListModel);
                }
            }
            default:
                break;
        }
    }

    /**
     * 结账单 反结账的回调
     */
    BillOperationInterface billOperation = new BillOperationInterface() {
        @Override
        public void printStatement(Order order) {
            if (order.orderCache != null) {
                ActionLog.addLog("账单管理页面-->点击了打印结账单", "", "", ActionLog.PR_PRINT, "");
            }
        }

        @Override
        public void rePay(final OrderListModel orderListModel, Order order, String reason) {
            billDataProcess.rePay(BillFragment.this, order, reason, new ResultCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    if (orderListModel != null) {
                        orderListModel.payed = 0;
                        adapter.notifyDataSetChanged();
                    }
                }
            });
        }
    };

    class BillViewHolder extends BaseViewHolder {

        private TextView bill_fragment_item_tableName;
        private TextView bill_fragment_item_total;
        private TextView bill_fragment_item_billNO;
        private ImageView bill_fragment_item_invoice_status;
        private TextView tv_fragment_item_brand;
        private TextView bill_fragment_item_status;
        private TextView bill_fragment_item_ordertime;
        private TextView bill_fragment_item_orderusername;
        private TextView bill_fragment_item_paytime;
        private TextView bill_fragment_item_payusername;
        private TextView bill_fragment_netorder_print;
        private TextView bill_fragment_netorder_pay;
        private TextView bill_fragment_item_print;
        private TextView bill_fragment_item_repay;
        private TextView bill_fragment_item_pay;
        private TextView bill_fragment_netorder_tip;
        private TextView bill_fragment_order_details;

        public BillViewHolder(View itemView) {
            super(itemView);
            bill_fragment_item_tableName = itemView.findViewById(R.id.bill_fragment_item_tableName);
            bill_fragment_item_total = itemView.findViewById(R.id.bill_fragment_item_total);
            bill_fragment_item_billNO = itemView.findViewById(R.id.bill_fragment_item_billNO);
            bill_fragment_item_invoice_status = itemView.findViewById(R.id.bill_fragment_item_invoice_status);
            tv_fragment_item_brand = itemView.findViewById(R.id.tv_fragment_item_brand);
            bill_fragment_item_status = itemView.findViewById(R.id.bill_fragment_item_status);
            bill_fragment_item_ordertime = itemView.findViewById(R.id.bill_fragment_item_ordertime);
            bill_fragment_item_orderusername = itemView.findViewById(R.id.bill_fragment_item_orderusername);
            bill_fragment_item_paytime = itemView.findViewById(R.id.bill_fragment_item_paytime);
            bill_fragment_item_payusername = itemView.findViewById(R.id.bill_fragment_item_payusername);
            bill_fragment_netorder_print = itemView.findViewById(R.id.bill_fragment_netorder_print);
            bill_fragment_netorder_pay = itemView.findViewById(R.id.bill_fragment_netorder_pay);
            bill_fragment_item_print = itemView.findViewById(R.id.bill_fragment_item_print);
            bill_fragment_item_repay = itemView.findViewById(R.id.bill_fragment_item_repay);
            bill_fragment_item_pay = itemView.findViewById(R.id.bill_fragment_item_pay);
            bill_fragment_netorder_tip = itemView.findViewById(R.id.bill_fragment_netorder_tip);
            bill_fragment_order_details = itemView.findViewById(R.id.bill_fragment_order_details);
        }

        @Override
        public void bindData(int position) {
//            if (TextUtils.equals(billTabView.fatherType, BillTabView.NET_ORDER)) {
            BusinessBean temp = modules.get(position);
            if (temp instanceof TempAppOrderSimpleInfo) {
                bindNetOrderData(temp);
            } else if (temp instanceof OrderListModel) {
                bindLocalData(temp);
            }
        }

        private void bindNetOrderData(BusinessBean source) {
            TempAppOrderSimpleInfo data = (TempAppOrderSimpleInfo) source;
            //订单来源
            bill_fragment_item_tableName.setText(BillDataProcess.getOrderTakeawaySource(data.orderTakeawaySource));
            if (data.subTotal == null || data.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                //订单金额
                bill_fragment_item_total.setText("0.00");
            } else {
                bill_fragment_item_total.setText(Calc.formatShow(data.subTotal));
            }

            //订单号
            bill_fragment_item_billNO.setText(data.orderId);
            //订单号--本地单号
            tv_fragment_item_brand.setVisibility(View.VISIBLE);
            tv_fragment_item_brand.setText(data.optSellNo());
            //状态
            bill_fragment_item_ordertime.setText(data.optOrderStatus());
            //下单时间
            bill_fragment_item_orderusername.setText(DateUtil.formartDateStrToTarget(data.date,
                    DateUtil.DATE_VISUAL14FORMAT, "HH:mm:ss"));

            //应收金额
            bill_fragment_item_paytime.setText(Calc.formatShow(data.subTotal));
            bill_fragment_item_paytime.setVisibility(View.GONE);

            //优惠金额
            bill_fragment_item_payusername.setText(Calc.formatShow(data.optYouhuiAmt()));

            bill_fragment_netorder_print.setOnClickListener(BillFragment.this);
            bill_fragment_netorder_print.setTag(R.integer.tv_bill_netorder_print, data);
            bill_fragment_netorder_print.setVisibility(View.VISIBLE);
            if (APPConfig.isMydKouBei()) {
                bill_fragment_order_details.setOnClickListener(BillFragment.this);
                bill_fragment_order_details.setTag(R.integer.tv_bill_netorder_print, data);
            } else {
                bill_fragment_order_details.setVisibility(View.GONE);
                bill_fragment_order_details.setOnClickListener(null);
            }

            TempAppOrderMappingInfo mappingInfo = tempAppOrderMappingInfoMap.get(data.orderId);
            if (mappingInfo != null) {
                //映射信息
                if (mappingInfo.mappingStatus == 1) {
                    //订单已映射到本地
                    if (mappingInfo.orderStatus != OrderStatus.PAIED) {
                        bill_fragment_netorder_pay.setOnClickListener(BillFragment.this);
                        bill_fragment_netorder_pay.setTag(R.integer.tv_bill_netorder_print, data);
                        bill_fragment_netorder_pay.setText("支付");
                        bill_fragment_netorder_tip.setText("有菜品未关联，结账失败");
                        bill_fragment_netorder_pay.setVisibility(View.VISIBLE);
                        bill_fragment_netorder_tip.setVisibility(View.VISIBLE);
                    } else if (mappingInfo.unMappingCount > 0) {
                        bill_fragment_netorder_pay.setOnClickListener(BillFragment.this);
                        bill_fragment_netorder_pay.setTag(R.integer.tv_bill_netorder_print, data);
                        bill_fragment_netorder_pay.setText("关联菜品");
                        bill_fragment_netorder_tip.setText("手动更改菜品关联关系");
                        bill_fragment_netorder_pay.setVisibility(View.VISIBLE);
                        bill_fragment_netorder_tip.setVisibility(View.VISIBLE);
                    } else {
                        bill_fragment_netorder_pay.setVisibility(View.INVISIBLE);
                        bill_fragment_netorder_tip.setVisibility(View.GONE);
                    }
                } else {
                    //订单未成功映射到本地
                    bill_fragment_netorder_pay.setVisibility(View.INVISIBLE);
                    bill_fragment_netorder_tip.setVisibility(View.VISIBLE);
                    bill_fragment_netorder_tip.setText("订单金额异常，无法落入报表");
                }
            } else {
                bill_fragment_netorder_pay.setVisibility(View.INVISIBLE);
                bill_fragment_netorder_tip.setVisibility(View.GONE);
            }

            bill_fragment_item_invoice_status.setVisibility(View.GONE);
            bill_fragment_item_status.setVisibility(View.GONE);
            bill_fragment_item_pay.setVisibility(View.GONE);
            bill_fragment_item_repay.setVisibility(View.GONE);
            bill_fragment_item_print.setVisibility(View.GONE);

            if (AppCache.getInstance().isRetailMode()) {
                itemView.setBackgroundColor(getResources().getColor(R.color.color_f9f9f9));
            }
        }

        private void bindLocalData(BusinessBean source) {
            OrderListModel data = (OrderListModel) source;
            if (data.fiSellType == Constants.SELL_TYPE_FAST_FOOD ||
                    (data.fiSellType == Constants.SELL_TYPE_KB && TextUtils.equals(billTabView.fatherType, BillTabView.FAST_FOOD))) {
                bill_fragment_item_tableName.setText(data.fsBillSourceName);
                tv_fragment_item_brand.setText(data.mealNumber);
                tv_fragment_item_brand.setVisibility(View.VISIBLE);
                if (data.fiInvoiceState == 2) {
                    bill_fragment_item_invoice_status.setVisibility(View.VISIBLE);
                } else {
                    bill_fragment_item_invoice_status.setVisibility(View.INVISIBLE);
                }
            } else {
                if (TextUtils.equals(billTabView.fatherType, BillTabView.DINNER)) {
                    if (data.fiInvoiceState == 2) {
                        bill_fragment_item_invoice_status.setVisibility(View.VISIBLE);
                    } else {
                        bill_fragment_item_invoice_status.setVisibility(View.INVISIBLE);
                    }
                } else {
                    //外卖
                    bill_fragment_item_invoice_status.setVisibility(View.GONE);
                }
                bill_fragment_item_tableName.setText(data.fsmtablename);
                tv_fragment_item_brand.setVisibility(View.GONE);
            }
            bill_fragment_item_total.setText(Calc.formatShow(data.totalPrice));
            bill_fragment_item_billNO.setText(data.orderID);
            bill_fragment_item_ordertime.setText(data.createTimeOrder);
            bill_fragment_item_orderusername.setText(data.orderWaiterName);
            bill_fragment_item_paytime.setVisibility(View.VISIBLE);
            bill_fragment_item_paytime.setText(BillDataProcess.getPayTime(data.payTime));
            bill_fragment_item_payusername.setText(data.payWaiterName);

            bill_fragment_item_pay.setVisibility(View.GONE);

            bill_fragment_item_print.setOnClickListener(BillFragment.this);
            bill_fragment_item_print.setTag(R.integer.bill_print_tag, data);

            bill_fragment_item_repay.setOnClickListener(BillFragment.this);
            bill_fragment_item_repay.setTag(R.integer.bill_repay_tag, data);

            bill_fragment_item_pay.setOnClickListener(BillFragment.this);
            bill_fragment_item_pay.setTag(R.integer.bill_pay_tag, data);

            bill_fragment_order_details.setOnClickListener(BillFragment.this);
            bill_fragment_order_details.setTag(R.integer.bill_order_details_tag, data);

            bill_fragment_netorder_print.setVisibility(View.GONE);
            bill_fragment_netorder_pay.setVisibility(View.GONE);
            bill_fragment_netorder_tip.setVisibility(View.GONE);
            bill_fragment_order_details.setVisibility(View.INVISIBLE);

            // 是否显示反结账、退菜
            if (!TextUtils.isEmpty(data.mergedOrderID) || data.orderStatus == OrderStatus.CANCEL ||
                    data.payed != 1 || !TextUtils.equals(data.businessDate, AppCache.getInstance().businessDate)) {
                bill_fragment_item_repay.setVisibility(View.INVISIBLE);
                if (!TextUtils.isEmpty(data.mergedOrderID) || data.orderStatus == OrderStatus.CANCEL || data.payed != 1) {
                    bill_fragment_item_print.setVisibility(View.INVISIBLE);
                } else {
                    bill_fragment_item_print.setVisibility(View.VISIBLE);
                    bill_fragment_item_print.setText(R.string.bill_please_checkout);
                }
                if (data.errorOrderStatus != 0) {
                    bill_fragment_item_repay.setVisibility(View.GONE);
                    bill_fragment_item_pay.setVisibility(View.VISIBLE);
                    bill_fragment_item_print.setVisibility(View.INVISIBLE);
                } else {
                    bill_fragment_item_pay.setVisibility(View.GONE);
                }
            } else if (data.locked == 1) {
                bill_fragment_item_repay.setVisibility(View.INVISIBLE);
                bill_fragment_item_print.setVisibility(View.VISIBLE);
                bill_fragment_item_print.setText(R.string.bill_please_checkout);
            } else if (data.orderStatus == OrderStatus.PAIED || data.orderStatus == OrderStatus.ANTI_PAIED) {
                if (data.thirdOrderType == NetOrderType.NET_ORDER) {
                    bill_fragment_item_repay.setVisibility(View.INVISIBLE);
                } else {
                    bill_fragment_item_repay.setVisibility(View.VISIBLE);
                }
                bill_fragment_item_print.setVisibility(View.VISIBLE);
                bill_fragment_item_print.setText(R.string.bill_please_checkout);
            }

            if (data.payed == 1) {
                bill_fragment_order_details.setVisibility(View.VISIBLE);
                if (data.errorOrderStatus != 0) {
                    bill_fragment_item_repay.setVisibility(View.GONE);
                    bill_fragment_item_pay.setVisibility(View.VISIBLE);
                    bill_fragment_item_print.setVisibility(View.INVISIBLE);
                }
            } else {
                bill_fragment_order_details.setVisibility(View.INVISIBLE);
            }

            // 口碑预点单不能反结账
            if (data.thirdOrderType == NetOrderType.KB_ORDER) {
                bill_fragment_item_repay.setVisibility(View.INVISIBLE);
            }

            if (!APPConfig.isMydKouBei()) {
                bill_fragment_order_details.setVisibility(View.GONE);
                bill_fragment_order_details.setOnClickListener(null);
            }

            String orderStatus = "";
            if (data.payed == 1) {
                if (data.locked == 1) {
                    orderStatus = getString(R.string.bill_shift_already);
                } else {
                    orderStatus = getString(R.string.bill_shift_uncheckout_already);
                }
            } else if (data.orderStatus == OrderStatus.CANCEL) {
                orderStatus = getString(R.string.bill_cancel_already);
            } else {
                orderStatus = getString(R.string.bill_uncheckout);
            }
            bill_fragment_item_status.setVisibility(View.VISIBLE);
            bill_fragment_item_status.setText(orderStatus);

            if (AppCache.getInstance().isRetailMode()) {
                bill_fragment_item_print.setBackgroundResource(R.drawable.air_bg_cubic_whole_black);
                bill_fragment_item_print.setTextColor(getResources().getColor(R.color.system_red));
                itemView.setBackgroundColor(getResources().getColor(R.color.color_f9f9f9));
            }
        }
    }
}
