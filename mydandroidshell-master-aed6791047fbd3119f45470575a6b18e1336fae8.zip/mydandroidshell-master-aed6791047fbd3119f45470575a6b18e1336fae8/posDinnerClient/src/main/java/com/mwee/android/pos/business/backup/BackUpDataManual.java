package com.mwee.android.pos.business.backup;

import android.os.SystemClock;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.base.NameConstant;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by virgil on 2017/6/29.
 */

public class BackUpDataManual {
    /**
     * 手动备份DB数据
     *
     * @param context Host
     */
    public static String startManualDoBackUp(final Host context) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss_SSS", Locale.SIMPLIFIED_CHINESE);
        String filePath = context.getContextWithinHost().getCacheDir() + "/"+NameConstant.BACKUP_FILE_PREFIX+"_" + format.format(new Date());
        try {
            long start = SystemClock.elapsedRealtime();
            FileUtil.deleteAllFile(filePath);

            FileBackup.encrypt(context.getContextWithinHost().getDatabasePath(APPConfig.DB_MAIN).getAbsolutePath(), filePath, NameConstant.BACKUP_PWD);
            LogUtil.log("FileBackup encrypt end,total cost=" + (SystemClock.elapsedRealtime() - start));
        } catch (Exception e) {
            LogUtil.logError(e);
            return "";
        }
        return filePath;

    }

    public static String startManualRestore(final Host context, final String filePath) {
        String dbName = NameConstant.RESTORE_DB_NAME;
        try {
            String targetSavedPath = context.getContextWithinHost().getDatabasePath(dbName).toString();
            FileUtil.deleteAllFile(targetSavedPath);
            LogUtil.log("mwbackup start decrypt");
            long destart = SystemClock.elapsedRealtime();
            FileBackup.decrypt(filePath, targetSavedPath, NameConstant.BACKUP_PWD);
            LogUtil.log("mwbackup decrypt end,total cost=" + (SystemClock.elapsedRealtime() - destart));

        } catch (Exception e) {
            LogUtil.logError(e);
            return "";
        }
        return dbName;
    }
}
