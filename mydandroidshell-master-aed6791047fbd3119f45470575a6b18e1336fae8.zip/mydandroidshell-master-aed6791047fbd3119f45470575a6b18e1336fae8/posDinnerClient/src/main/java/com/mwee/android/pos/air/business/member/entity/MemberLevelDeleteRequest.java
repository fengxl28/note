package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberLevelDeleteRequest extends BaseMemberParam {
    public int m_shopid;
    public int level_id;

    public MemberLevelDeleteRequest() {
    }
}
