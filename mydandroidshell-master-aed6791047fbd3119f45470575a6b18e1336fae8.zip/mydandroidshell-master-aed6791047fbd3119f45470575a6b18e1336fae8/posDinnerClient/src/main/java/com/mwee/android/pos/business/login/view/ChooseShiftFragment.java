package com.mwee.android.pos.business.login.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.recycler.CommonRecycleAdapter;
import com.mwee.android.pos.component.recycler.ViewHolder;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CLogin;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.pos.util.WightAnimUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * 班别
 * Created by Liming on 16/9/18.
 *
 * @author virgil
 */
public class ChooseShiftFragment extends BaseFragment {

    public List<DataModel> shitList = new ArrayList<>();
    private View rootView;
    private CommonRecycleAdapter<DataModel> commonRecycleAdapter;

    private int selectIndex = -1;

    public static ChooseShiftFragment newInstance(List<DataModel> shitList) {
        ChooseShiftFragment chooseShiftFragment = new ChooseShiftFragment();
        chooseShiftFragment.shitList = shitList;//本来应该是用setArguments传递的
        return chooseShiftFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.classes_layout, container, false);
        init(view);
        WightAnimUtil.showEnterAnim(rootView);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        initData();
    }

    private void initData() {
        commonRecycleAdapter.setData(shitList);
    }

    private void init(View view) {
        rootView = view.findViewById(R.id.rl_rootview);

        ImageView logo = view.findViewById(R.id.logo);
        if (AppCache.getInstance().isRetailMode()) {
            logo.setImageResource(R.drawable.air_splash_logo);
        }
        initAdapter(view);
    }

    private void initAdapter(View view) {
        commonRecycleAdapter = new CommonRecycleAdapter<DataModel>(getContext(), R.layout.shift_item) {
            @Override
            public boolean onItemClick(View view, final DataModel model, int position) {
                if (TextUtils.equals(model.status, "1")) {
                    return false;
                }
                selectIndex = position;
                commonRecycleAdapter.notifyDataSetChanged();
                final Progress progress = ProgressManager.showProgress(ChooseShiftFragment.this, "请稍后");
                MCon.c(CLogin.class, new SocketCallback<BaseSocketResponse>() {
                    @Override
                    public void callback(SocketResponse<BaseSocketResponse> socketResponse) {
                        if (isAdded()) {
                            progress.dismissSelf();
                            if (socketResponse.success()) {
                                AppCache.getInstance().currentShiftID = model.id;
                                RunTimeLog.addLog(RunTimeLog.Shift, "选择班别成功：" + model.id, "", model);
                                String orderModel = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, "");
                                UIHelp.startMainDinnerActvity(getActivityWithinHost());
                                getActivityWithinHost().finish();
                            } else if (socketResponse.code == SocketResultCode.SHOP_DATA_EXPIRED) {
                                //如果数据已过期，则返回重新获取
                                ToastUtil.showToast(socketResponse.message);
                                RunTimeLog.addLog(RunTimeLog.Shift, "选择班别失败：" + socketResponse.message, "", model);
                                // 2018/3/1 班别选择页通过 addFragmentWithHide 添加，直接 dismissSelf 会出现空白页面
//                            dismissSelf();
                                getActivityWithinHost().onBackPressed();
                            } else {
                                ToastUtil.showToast(socketResponse.message);
                            }
                        }
                    }
                }).chooseShift(model.id);

                return false;
            }

            @Override
            public void onBind(ViewHolder holder, DataModel shiftDBModel, int position) {
                boolean click = !TextUtils.equals(shiftDBModel.status, "1");
                holder.getView(R.id.login_user_ll).setEnabled(click);
                holder.getConvertView().setActivated(true);
                holder.getConvertView().setEnabled(click);
                holder.setText(R.id.login_user_username, shiftDBModel.name);
                holder.getView(R.id.login_user_hint).setVisibility(TextUtils.equals(shiftDBModel.status, "1") ? View.VISIBLE : View.GONE);
                holder.setText(R.id.login_user_hint, TextUtils.equals(shiftDBModel.status, "1") ? "(已关账)" : "");
                holder.getView(R.id.login_user_ll).setSelected(selectIndex == position);
                holder.getView(R.id.login_user_username).setSelected(selectIndex == position);
            }
        };
        RecyclerView loginRecylerView = (RecyclerView) view.findViewById(R.id.classes_choose_recyleview);
        loginRecylerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost(), LinearLayoutManager.HORIZONTAL, false));
        loginRecylerView.setAdapter(commonRecycleAdapter);
    }

}
