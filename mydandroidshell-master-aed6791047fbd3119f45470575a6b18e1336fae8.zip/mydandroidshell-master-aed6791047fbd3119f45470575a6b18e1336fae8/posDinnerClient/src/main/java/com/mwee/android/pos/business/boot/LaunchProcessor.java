package com.mwee.android.pos.business.boot;

import android.os.Handler;
import android.os.Looper;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.connect.search.UDPSearch;
import com.mwee.android.print.printer.usbPriter.UsbConnector;

/**
 * Created by lxx on 17/1/9.
 */

public class LaunchProcessor {

    public void start(final String shopID) {
        BusinessExecutor.executeNoWait(() -> {
            doInit(shopID);
            return null;
        });
    }

    private void doInit(final String shopID) {
        try {
            UsbConnector.checkAllUsbPrinter(GlobalCache.getContext());
        } catch (Exception e) {
            e.getMessage();
        }

        broadAllHostToRefresh(shopID);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            BusinessExecutor.executeNoWait(() -> {
                if (ClientBindProcessor.isActived() && ClientBindProcessor.isCurrentHostMain()) {
                    NotifyToServer.sendExcuteMsg("biz/refreshFromView");
                }
                return null;
            });
        }, 5 * 1000);
    }

    /**
     * 通知所有站点刷新业务中心的IP
     */
    public void broadAllHostToRefresh(final String shopID) {
        if (ClientBindProcessor.isCurrentHostMain()) {
            ServerConnector.getInstance().sendExecute("biz/callUdpBroad");
        } else {
            UDPSearch.searchIP(shopID);
        }
    }


}
