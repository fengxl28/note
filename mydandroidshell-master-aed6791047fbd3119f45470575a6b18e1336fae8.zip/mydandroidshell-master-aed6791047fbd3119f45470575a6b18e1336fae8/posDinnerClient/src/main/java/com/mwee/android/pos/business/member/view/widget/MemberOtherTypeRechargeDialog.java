package com.mwee.android.pos.business.member.view.widget;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.member.net.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;

/**
 * Created by chris on 16/8/21.
 */
public class MemberOtherTypeRechargeDialog extends BaseDialogFragment implements View.OnClickListener {

    private RelativeLayout root_layout;
    private TextView store_value_money_txt;
    private EditText author_code_edt;
    private TextView error_txt;
    private Button cancel_btn;
    private Button confirm_btn;

    private MemberRechargePackageModel memberRechargePackageModel;
    private String cardNumber;
    private String realCard;
    private Callback callback;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_member_recharge_auth, container, false);
        root_layout = (RelativeLayout) view.findViewById(R.id.root_layout);
        root_layout.setOnClickListener(this);
        store_value_money_txt = (TextView) view.findViewById(R.id.store_value_money_txt);
        author_code_edt = (EditText) view.findViewById(R.id.author_code_edt);
        error_txt = (TextView) view.findViewById(R.id.error_txt);
        cancel_btn = (Button) view.findViewById(R.id.cancel_btn);
        cancel_btn.setOnClickListener(this);
        confirm_btn = (Button) view.findViewById(R.id.confirm_btn);
        confirm_btn.setOnClickListener(this);
        author_code_edt.setInputType(InputType.TYPE_NULL);
        initUi();
        return view;
    }

    public void initUi() {
        if (memberRechargePackageModel != null) {
            store_value_money_txt.setText(memberRechargePackageModel.money);

        }
    }

    public void setParams(MemberRechargePackageModel memberRechargePackageModel, String cardNumber, String realCard, Callback callback) {
        this.memberRechargePackageModel = memberRechargePackageModel;
        this.cardNumber = cardNumber;
        this.realCard = realCard;
        this.callback = callback;
    }

    private void otherCharge() {
        String authorCode = this.author_code_edt.getText().toString().trim();
        if (TextUtils.isEmpty(authorCode)) {
            this.error_txt.setText("请输入授权码");
            this.error_txt.setVisibility(View.VISIBLE);
        } else if (authorCode.length() != 6) {
            this.error_txt.setText("请输入六位授权码");
            this.error_txt.setVisibility(View.VISIBLE);
        } else {
            this.error_txt.setVisibility(View.INVISIBLE);
            this.confirm_btn.setEnabled(false);
            ProgressManager.showProgress((Host) getActivity());
//            this.memberRechargeModel.recharge(this.cardNumber, this.realCard, 10, "", this.rechargePackage.getId(), authorCode, this.sessionId, this.cashRemoteService);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.root_layout:
                dismiss();
                break;
            case R.id.cancel_btn:
                dismiss();
                break;
            case R.id.confirm_btn:

                break;
        }
    }

    public interface Callback {
        void call();
    }
}
