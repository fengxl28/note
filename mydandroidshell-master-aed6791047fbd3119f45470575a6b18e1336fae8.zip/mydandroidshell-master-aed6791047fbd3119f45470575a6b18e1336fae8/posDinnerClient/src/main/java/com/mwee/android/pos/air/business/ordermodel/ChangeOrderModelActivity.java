package com.mwee.android.pos.air.business.ordermodel;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.constants.AirHostConstant;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.tools.StringUtil;

/**
 * Created by lxx on 2017/10/12.
 * 修改点餐模式
 */

public class ChangeOrderModelActivity extends AirBaseActivity implements CompoundButton.OnCheckedChangeListener, IDriver {
    public static final String TAG = "changeOrderModelActivity";
    private TitleBar mTitleBar;

    private ImageView air_dinner_ryt;
    private ImageView air_fastfood_ryt;

    /**
     * 自动牌号
     */
    private RelativeLayout auto_open_ryt;
    private Switch switch_setting_fastmealno_auto;
    private View auto_open_line;

    /**
     * 快餐连续开单
     */
    private RelativeLayout auto_meal_ryt;
    private Switch switch_setting_fastpos_open;
    private View auto_meal_line;


    //圆整UI设置
    private RadioGroup round_price_rg;
    //进位
    private RadioGroup number_deal_rg;


    private int currentOrderModel = AirHostConstant.DINNER_MODEL;
    private RelativeLayout fast_pos_num_layout;
    private Switch switch_setting_fastpos_num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air_change_order_model_activity);
        initUI();

        DriverBus.registerDriver(this);
    }

    private void initUI() {
        air_dinner_ryt = findViewById(R.id.air_dinner_ryt);
        air_fastfood_ryt = findViewById(R.id.air_fastfood_ryt);
        air_dinner_ryt.setOnClickListener(this);
        air_fastfood_ryt.setOnClickListener(this);

        auto_open_ryt = (RelativeLayout) findViewById(R.id.auto_open_ryt);
        fast_pos_num_layout = (RelativeLayout) findViewById(R.id.fast_pos_num_layout);
        auto_meal_ryt = (RelativeLayout) findViewById(R.id.auto_meal_ryt);
        switch_setting_fastmealno_auto = (Switch) findViewById(R.id.switch_setting_fastmealno_auto);
        switch_setting_fastpos_open = (Switch) findViewById(R.id.switch_setting_fastpos_open);
        switch_setting_fastpos_num = (Switch) findViewById(R.id.switch_setting_fastpos_num);
        auto_open_line = findViewById(R.id.auto_open_line);
        auto_meal_line = findViewById(R.id.auto_meal_line);


        mTitleBar = (TitleBar) findViewById(R.id.mTitleBar);
        mTitleBar.setTitle("点菜模式");
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });

        switch_setting_fastmealno_auto.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.FASTFOOD_MEAL_NO_AUTO, "0"), "1"));
        switch_setting_fastpos_open.setChecked(SettingHelper.isShouldContinueOpen());
        switch_setting_fastpos_num.setChecked(SettingHelper.isShouldSetMealNumber());

        switch_setting_fastpos_open.setOnCheckedChangeListener(this);
        switch_setting_fastmealno_auto.setOnCheckedChangeListener(this);
        switch_setting_fastpos_num.setOnCheckedChangeListener(this);

        //圆整UI设置
        round_price_rg = (RadioGroup) findViewById(R.id.round_price_rg);
        //进位
        number_deal_rg = (RadioGroup) findViewById(R.id.number_deal_rg);

        round_price_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.yuan_rb:
                        ActionLog.addLog("点菜模式管理页面--->价格圆整 选中了元", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_SUB_TOTAL, "0");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_TOTAL, "0");
                        break;
                    case R.id.angle_rb:
                        ActionLog.addLog("点菜模式管理页面--->价格圆整 选中了角", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_SUB_TOTAL, "1");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_TOTAL, "1");
                        break;
                    case R.id.subdivision_rb:
                        ActionLog.addLog("点菜模式管理页面--->价格圆整 选中了分", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_SUB_TOTAL, "2");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_TOTAL, "2");
                        break;
                    default:
                        break;
                }
            }
        });

        number_deal_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.round_rb:
                        ActionLog.addLog("点菜模式管理页面--->小位数处理 选中了四舍五入", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_COUNT, "1");
                        break;
                    case R.id.give_rb:
                        ActionLog.addLog("点菜模式管理页面--->小位数处理 选中了舍入", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_COUNT, "2");
                        break;
                    case R.id.carry_rb:
                        ActionLog.addLog("点菜模式管理页面--->小位数处理 选中了进位", "", "", ActionLog.SS_MORE_JOIN, "");
                        SettingProcessor.updateDBSetting(DBOrderConfig.ROUND_COUNT, "3");
                        break;
                    default:
                        break;
                }
            }
        });

        refreshRoundUI();
        refreshRoundSubTotalUI();

        currentOrderModel = AppCache.getInstance().currentHostType;
        if (currentOrderModel == AirHostConstant.FASTFOOD_MODEL) {
            air_dinner_ryt.setSelected(false);
            air_fastfood_ryt.setSelected(true);
            auto_open_ryt.setVisibility(View.GONE);
            auto_meal_ryt.setVisibility(View.VISIBLE);
            auto_open_line.setVisibility(View.VISIBLE);
            auto_meal_line.setVisibility(View.VISIBLE);
            fast_pos_num_layout.setVisibility(View.VISIBLE);
        } else {
            air_dinner_ryt.setSelected(true);
            air_fastfood_ryt.setSelected(false);
            auto_open_ryt.setVisibility(View.GONE);
            auto_meal_ryt.setVisibility(View.GONE);
            auto_open_line.setVisibility(View.GONE);
            auto_meal_line.setVisibility(View.GONE);
            fast_pos_num_layout.setVisibility(View.GONE);
        }
    }

    @DrivenMethod(uri = TAG + "/refreshSetting", UIThread = true)
    public void refreshSetting(String type, String value) {
        switch (Integer.valueOf(type)) {
            case META.FASTFOOD_MEAL_NO_AUTO:   //自动牌号
                if (switch_setting_fastmealno_auto != null) {
                    switch_setting_fastmealno_auto.setChecked(TextUtils.equals(value, "1"));
                }
                break;

            default:
                break;
        }
    }

    @DrivenMethod(uri = TAG + "/refreshDBConfig", UIThread = true)
    public void refreshDBConfig(String type, String value) {
        switch (type) {
            case DBOrderConfig.ROUND_SUB_TOTAL:    //圆整方式
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    refreshRoundSubTotalUI();
                }
                break;
            case DBOrderConfig.ROUND_COUNT:   //小数位处理方式
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    refreshRoundUI();
                }
                break;
        }
    }

    private void refreshRoundUI() {
        int roundMode = StringUtil.toInt(ClientCommonDBUtil.getConfigWithDefault(DBOrderConfig.ROUND_COUNT, AppCache.getInstance().fsShopGUID), 1);
        if (roundMode < 1 || roundMode > 3) {
            roundMode = 1;
        }
        ((RadioButton) number_deal_rg.getChildAt(roundMode - 1)).setChecked(true);
    }

    private void refreshRoundSubTotalUI() {
        int roundMode = StringUtil.toInt(ClientCommonDBUtil.getConfigWithDefault(DBOrderConfig.ROUND_TOTAL, AppCache.getInstance().fsShopGUID), 1);
        ((RadioButton) round_price_rg.getChildAt(roundMode)).setChecked(true);
    }

    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.air_dinner_ryt:
                ActionLog.addLog("点菜模式管理页面--->选中了桌台模式", "", "", ActionLog.SS_MORE_JOIN, "");
                air_dinner_ryt.setSelected(true);
                air_fastfood_ryt.setSelected(false);
                auto_open_ryt.setVisibility(View.GONE);
                auto_meal_ryt.setVisibility(View.GONE);
                auto_open_line.setVisibility(View.GONE);
                auto_meal_line.setVisibility(View.GONE);
                fast_pos_num_layout.setVisibility(View.GONE);
                currentOrderModel = AirHostConstant.DINNER_MODEL;
                ClientMetaUtil.updateSettingsValueByKey(META.AIR_ORDER_MODE, AirHostConstant.DINNER_MODEL);
                AppCache.getInstance().currentHostType = AirHostConstant.DINNER_MODEL;
                break;
            case R.id.air_fastfood_ryt:
                ActionLog.addLog("点菜模式管理页面--->选中了快餐模式", "", "", ActionLog.SS_MORE_JOIN, "");
                air_dinner_ryt.setSelected(false);
                air_fastfood_ryt.setSelected(true);
                auto_open_ryt.setVisibility(View.GONE);
                auto_meal_ryt.setVisibility(View.VISIBLE);
                auto_open_line.setVisibility(View.VISIBLE);
                auto_meal_line.setVisibility(View.VISIBLE);
                fast_pos_num_layout.setVisibility(View.VISIBLE);
                currentOrderModel = AirHostConstant.FASTFOOD_MODEL;
                ClientMetaUtil.updateSettingsValueByKey(META.AIR_ORDER_MODE, AirHostConstant.FASTFOOD_MODEL);
                AppCache.getInstance().currentHostType = AirHostConstant.FASTFOOD_MODEL;
                break;

            default:
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (buttonView.getId()) {
            case R.id.switch_setting_fastmealno_auto://自动牌号
                ActionLog.addLog("点菜模式管理页面->点击了自动牌号", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.refreshSettingStatus(META.FASTFOOD_MEAL_NO_AUTO, isChecked ? "1" : "0");
                break;
            case R.id.switch_setting_fastpos_open://快餐连续点单
                ActionLog.addLog("点菜模式管理页面->点击了快餐连续点单", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingHelper.putLocalSetting(META.FASTPOS_CONTINUOUS_OPEN, isChecked ? "1" : "0");
                break;
            case R.id.switch_setting_fastpos_num://快餐牌号
                ActionLog.addLog("点菜模式管理页面->点击了快餐牌号", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingHelper.putLocalSetting(META.FASTPOS_TABLE_NUM, isChecked ? "1" : "0");
                break;
        }
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
