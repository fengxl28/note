package com.mwee.android.pos.business.boot;

import com.mwee.android.pos.base.BasePresenter;
import com.mwee.android.pos.base.BaseView;

/**
 * @ClassName: WelcomeContract
 * @Description:
 * @author: SugarT
 * @date: 2017/11/21 下午6:02
 */
public interface WelcomeContract {

    interface View extends BaseView<Presenter> {

        /**
         * 权限授予
         */
        void grantedPermission();

        /**
         * 初始化数据完成
         */
        void initDataCompleted();
    }

    interface Presenter extends BasePresenter {

        /**
         * 请求权限
         */
        void requestPermission();

        /**
         * 处理升级的数据迁移
         */
        void startUgradeTransfer();

        /**
         *
         */
        void checkAndLoadData();

        /**
         * 检查漏打小票
         * @param hostId 站点id
         */
        void checkPrint(String hostId);

        /**
         * 初始化数据并登录
         */
        void initDataAndToLogin();
    }
}
