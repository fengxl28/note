//package com.mwee.android.pos.air.business.payment.view;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.RadioButton;
//import android.widget.TextView;
//
//import com.mwee.android.air.connect.business.payment.GetAllPaymentResponse;
//import com.mwee.android.air.db.business.payment.PaymentManageInfo;
//import com.mwee.android.pos.air.business.payment.api.PaymentManageApi;
//import com.mwee.android.pos.component.callback.OnResultListener;
//import com.mwee.android.pos.component.dialog.BaseDialogFragment;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.ToastUtil;
//
//import java.util.List;
//
///**
// * @ClassName: PaymentEditView
// * @Description: 支付方式编辑
// * @author: SugarT
// * @date: 2017/10/14 上午11:15
// */
//public class PaymentEditView extends BaseDialogFragment {
//
//    public static final String TAG = PaymentEditView.class.getSimpleName();
//    public static final int TYPE_ADD = 1;
//    public static final int TYPE_EDIT = 2;
//
//    private TextView mTitleTv;
//    private EditText mPaymentNameEt;
//    private Button mCancelBtn;
//    private Button mConfirmBtn;
//    private int editType;
//
//    /**
//     * 待编辑的支付方式
//     */
//    private PaymentManageInfo mOptPayment;
//
//    private OnResultListener<List<PaymentManageInfo>> listener;
//
//    private View.OnClickListener click = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            if (!ButtonClickTimer.canClick()) {
//                return;
//            }
//            switch (v.getId()) {
//                case R.id.btn_payment_edit_cancel:
//                    // 取消
//                    dismiss();
//                    break;
//                case R.id.btn_payment_edit_confirm:
//                    // 确定
//                    editPayment();
//                    break;
//                default:
//                    break;
//            }
//        }
//    };
//    private RadioButton mPaymentRevenueRb;
//    private RadioButton mPaymentRevenueNoRb;
//
//    public static PaymentEditView newInstance() {
//        PaymentEditView fragment = new PaymentEditView();
//        return fragment;
//    }
//
//    public PaymentEditView setOptPayment(PaymentManageInfo optPayment, int editType) {
//        mOptPayment = optPayment;
//        this.editType = editType;
//        return this;
//    }
//
//    public PaymentEditView setListener(OnResultListener<List<PaymentManageInfo>> listener) {
//        this.listener = listener;
//        return this;
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.view_payment_edit, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        if (mOptPayment == null) {
//            dismissSelf();
//            return;
//        }
//        assignViews(view);
//        start();
//    }
//
//    private void assignViews(View convertView) {
//        mTitleTv = convertView.findViewById(R.id.tv_payment_edit_title);
//        mPaymentNameEt = convertView.findViewById(R.id.et_payment_edit_name);
//        mPaymentRevenueRb = convertView.findViewById(R.id.rb_payment_revenue);
//        mPaymentRevenueNoRb = convertView.findViewById(R.id.rb_payment_revenue_no);
//
//        mCancelBtn = convertView.findViewById(R.id.btn_payment_edit_cancel);
//        mConfirmBtn = convertView.findViewById(R.id.btn_payment_edit_confirm);
//
//        convertView.findViewById(R.id.llyt_account_edit_root).setOnClickListener(null);
//        mCancelBtn.setOnClickListener(click);
//        mConfirmBtn.setOnClickListener(click);
//    }
//
//    private void start() {
//        if (editType == TYPE_ADD) {
//            mTitleTv.setText("新增支付方式");
//        } else {
//            mTitleTv.setText("修改支付方式");
//            mPaymentNameEt.setHint(mOptPayment.fsPaymentName);
//            if (mOptPayment.fiIsCalcPaid == 1) {
//                mPaymentRevenueRb.setChecked(true);
//            } else {
//                mPaymentRevenueNoRb.setChecked(true);
//            }
//
//        }
//    }
//
//    private void editPayment() {
//        String errMsg = checkParams();
//        if (!TextUtils.isEmpty(errMsg)) {
//            ToastUtil.showToast(errMsg);
//            return;
//        }
//
//        String paymentName = mPaymentNameEt.getText().toString().trim();
//        if (TextUtils.isEmpty(paymentName)) {
//            paymentName = mPaymentNameEt.getHint().toString().trim();
//        }
//        mOptPayment.fsPaymentName = paymentName;
//
//        mOptPayment.fiIsCalcPaid = mPaymentRevenueRb.isChecked() ? 1 : 0;
//
//        if (editType == TYPE_ADD) {
//            addPayType(mOptPayment);
//        } else if (editType == TYPE_EDIT) {
//            editPayType(mOptPayment);
//        }
//    }
//
//    private String checkParams() {
//        String fsPaymentName = TextUtils.isEmpty(mPaymentNameEt.getText()) ? "" : mPaymentNameEt.getText().toString().trim();
//        if (TextUtils.isEmpty(fsPaymentName)) {
//            fsPaymentName = TextUtils.isEmpty(mPaymentNameEt.getHint()) ? "" : mPaymentNameEt.getHint().toString().trim();
//        }
//        if (TextUtils.isEmpty(fsPaymentName)) {
//            return "请输入付款方式名称";
//        }
//        if (fsPaymentName.length() > 20) {
//            return "付款方式名称最大长度为20位";
//        }
//        return "";
//    }
//
//    public void addPayType(PaymentManageInfo model) {
//        if (model == null) {
//            return;
//        }
//        PaymentManageApi.addPayment(model.fsPaymentName, model.fiIsCalcPaid, new IResponse<GetAllPaymentResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, GetAllPaymentResponse info) {
//                if (!result) {
//                    ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(msg) ? msg : "数据获取失败，请重试");
//                    return;
//                }
//                refreshData(info.paymentList);
//            }
//        });
//    }
//
//    public void editPayType(PaymentManageInfo model) {
//        if (model == null) {
//            return;
//        }
//        PaymentManageApi.updaetPayment(model.fsPaymentId, model.fsPaymentName, model.fiIsCalcPaid, new IResponse<GetAllPaymentResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, GetAllPaymentResponse info) {
//                if (!result) {
//                    ToastUtil.showToast(com.mwee.android.pos.util.TextUtils.validate(msg) ? msg : "数据获取失败，请重试");
//                    return;
//                }
//                refreshData(info.paymentList);
//            }
//        });
//    }
//
//    private void refreshData(List<PaymentManageInfo> list) {
//        if (listener != null) {
//            listener.callBack(list);
//        }
//        dismissSelf();
//    }
//
//}
