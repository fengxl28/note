package com.mwee.android.pos.business.member;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TimeButton;
import com.mwee.android.tools.DateUtil;

/**
 * Created by lxx on 16/9/08.
 */
public class BindCardFragment extends BaseDialogFragment {
    public static final String FRAGMENT_TAG = BindCardFragment.class.getName();

    private RelativeLayout bind_ryt;

    /**
     * 会员卡号
     */
    private EditText thirdNumber;

    /**
     * 手机号
     */
    private EditText mwNumber;

    /**
     * 获取手机验证码按钮
     */
    private TimeButton verificationCodeBtn;

    /**
     * 手机验证码
     */
    private EditText verificationCodeEdt;

    /**
     * 姓名
     */
    private EditText name;

    /**
     * 性别
     */
    private RadioGroup rgSex;

    /**
     * 生日
     */
    private TextView birthday;

    /**
     * 取消
     */
    private Button cancel;

    /**
     * 绑定
     */
    private Button bind;

    private BindThirdCardCallback callback;

    private String cardNumber = "";

    //卡类型  0：虚拟卡； 1：手机号激活； 2：不记名激活
    private String cardType = "1";

    private String phone = "";

    private String verificationCode = "";

    private String nameValue = "";

    private String birthdayValue = "";

    /**
     * 性别 0 ：先生； 1 ： 女士
     */
    private int sex = 0;

    public void setCallback(BindThirdCardCallback callback) {
        this.callback = callback;
    }

    /**
     * 设置卡号
     *
     * @param cardNumber
     */
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * 设置卡类型
     *
     * @param cardType String | 0：虚拟卡； 1：手机号激活； 2：不记名激活
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.verificationCodeBtn:
                    //获取手机验证码
                    if (checkPhoneFormat()) {
                        final Progress progress = ProgressManager.showProgressUncancel(BindCardFragment.this, R.string.progress_loading);
                        MemberApi.loadSendMobileForMobilePayCode(phone, new IExecutorCallback() {
                            @Override
                            public void success(ResponseData responseData) {
                                verificationCodeBtn.start();
                                progress.dismissSelf();
                            }

                            @Override
                            public boolean fail(ResponseData responseData) {
                                if (responseData != null && TextUtils.validate(responseData.resultMessage)) {
                                    ToastUtil.showToast(responseData.resultMessage);
                                } else {
                                    ToastUtil.showToast("验证码获取失败,请稍后重试");
                                }
                                progress.dismissSelf();
                                return false;
                            }
                        });
                    }
                    break;
                case R.id.birthday:
                    showCalendar();
                    break;
                case R.id.bind:
                    if (checkPhoneFormat() && checkFormat()) {
                        ProgressManager.showProgress(getActivityWithinHost());
                        /*MemberApi.memberBindCard(cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                ProgressManager.closeProgress(getActivityWithinHost());
                                ToastUtil.showToast(info);
                                if (result) {
                                    dismiss();
                                }
                            }
                        });*/
                        (new MemberProcess()).bindMembercard(cardType, cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                ProgressManager.closeProgress(getActivityWithinHost());
                                ToastUtil.showToast(info);
                                if (result) {
                                    dismiss();
                                }
                            }
                        });
                    }
                    break;
                case R.id.cancel:
                    dismiss();
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.bind_card_fragment_layout, container, false);
        setCancelable(false);
        initUI(contentView);
        registEvent();
        return contentView;
    }

    private void initUI(View contentView) {
        bind_ryt = contentView.findViewById(R.id.bind_ryt);
        cancel = contentView.findViewById(R.id.cancel);
        bind = contentView.findViewById(R.id.bind);
        verificationCodeBtn = contentView.findViewById(R.id.verificationCodeBtn);
        thirdNumber = contentView.findViewById(R.id.thirdNumber);
        mwNumber = contentView.findViewById(R.id.mwNumber);
        verificationCodeEdt = contentView.findViewById(R.id.verificationCodeEdt);
        name = contentView.findViewById(R.id.name);
        birthday = contentView.findViewById(R.id.birthday);
        rgSex = contentView.findViewById(R.id.rgSex);

        if (TextUtils.validate(cardNumber)) {
            thirdNumber.setText(cardNumber);
        }
    }

    /**
     * 是否是虚拟卡
     *
     * @return
     */
    private boolean virtualCard() {
        if (android.text.TextUtils.equals(cardType, "0")) {
            return true;
        }
        return false;
    }

    private void registEvent() {
        bind_ryt.setOnClickListener(null);
        verificationCodeBtn.setOnClickListener(onClickListener);
        cancel.setOnClickListener(onClickListener);
        bind.setOnClickListener(onClickListener);
        birthday.setOnClickListener(onClickListener);

        verificationCodeBtn.setOnTimeChangedListener(new TimeButton.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(int ss) {
                verificationCodeBtn.setText("" + ss);
            }

            @Override
            public void onTimeCompleted() {
                verificationCodeBtn.setText(R.string.code);
            }
        });

        rgSex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (R.id.rbMan == checkedId) {//男
                    sex = 0;
                } else if (R.id.rbMale == checkedId) {//女
                    sex = 1;
                }
            }
        });
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    /**
     * @return 验证通过返回true
     * @author ：
     */
    public boolean checkFormat() {

        cardNumber = TextUtils.formatSpace(thirdNumber.getText().toString().trim());
        if (!TextUtils.validate(cardNumber)) {
            ToastUtil.showToast("请输入会员卡号");
            return false;
        }
        if (!RegexUtil.checkNumberLetter(cardNumber)) {
            ToastUtil.showToast("请输入正确的会员卡号");
            return false;
        }

        verificationCode = verificationCodeEdt.getText().toString().trim();
        //虚拟卡可以不需要输入验证码
        if (!virtualCard()) {
            if (!TextUtils.validate(verificationCode)) {
                ToastUtil.showToast("请输入验证码");
                return false;
            }
        }

        //虚拟卡如果输入了验证码，验证码要符合规则
        if (TextUtils.validate(verificationCode)) {
            if (!RegexUtil.checkNumber(verificationCode) || verificationCode.length() != 6) {
                ToastUtil.showToast("请输入6位纯数字验证码");
                return false;
            }
        }

        nameValue = name.getText().toString().trim();
        if (TextUtils.validate(verificationCode) && (!RegexUtil.checkLetterChinese(nameValue) || nameValue.length() > 12)) {
            ToastUtil.showToast("姓名规则：12位以内的中文和英文");
            return false;
        }

        birthdayValue = birthday.getText().toString().trim();

        return true;
    }

    /**
     * 手机号校验
     *
     * @return
     */
    public boolean checkPhoneFormat() {
        phone = mwNumber.getText().toString().trim();
        if (!TextUtils.validate(phone)) {
            ToastUtil.showToast("请输入手机号");
            return false;
        }
        if (!RegexUtil.checkIsPhoneNumber(phone)) {
            ToastUtil.showToast("请输入正确的手机号");
            return false;
        }
        return true;
    }

    private void showCalendar() {
        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), getView());
        calendarPopupwindow.setDate("1988-01-01");
        calendarPopupwindow.setCancelable(true);
        calendarPopupwindow.setSupportStartDate("1970-01-01");
        calendarPopupwindow.setSupportEndDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                birthday.setText(newDate);
            }
        });
    }

    @Override
    public void onDestroy() {
        if (verificationCodeBtn != null) {
            verificationCodeBtn.callDestroy();
        }
        super.onDestroy();
    }
}