package com.mwee.android.pos.air.business.biz;

import com.mwee.android.air.acon.CBiz;
import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResult;

/**
 * Created by liuxiuxiu on 2017/10/20.
 */

public class BizcenterApi {

    public static void uploadLocalChangeData(final IResult iResult) {

        MCon.c(CBiz.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.message);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.message);
                    }
                }
            }
        }).uploadLocalChangeData();
    }

    public static void syncData2C(final IResult iResult) {
        MCon.c(CBiz.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.message);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.message);
                    }
                }
            }
        }).dataSync();
    }
}
