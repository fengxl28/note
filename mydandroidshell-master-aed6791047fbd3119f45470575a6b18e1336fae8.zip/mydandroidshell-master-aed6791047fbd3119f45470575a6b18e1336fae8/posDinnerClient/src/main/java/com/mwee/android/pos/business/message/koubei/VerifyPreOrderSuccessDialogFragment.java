package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;

/**
 * Created by qinwei on 2018/6/25.
 */

public class VerifyPreOrderSuccessDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mScannerStatusLabel;
    private Button mVerifyCancelBtn;
    private Button mVerifyConfirmBtn;
    private String orderId = "";
    private OnVerifyPreOrderConfirmClickListener listener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_net_verify_pre_order_success_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData(savedInstanceState);
    }

    private void initView(View view) {
        mScannerStatusLabel = (TextView) view.findViewById(R.id.mScannerStatusLabel);
        mVerifyCancelBtn = (Button) view.findViewById(R.id.mVerifyCancelBtn);
        mVerifyConfirmBtn = (Button) view.findViewById(R.id.mVerifyConfirmBtn);
        mVerifyCancelBtn.setOnClickListener(this);
        mVerifyConfirmBtn.setOnClickListener(this);
    }


    private void initData(Bundle savedInstanceState) {
        mScannerStatusLabel.setText("口碑点餐订单【" + orderId + "】\n" +
                "核销成功，是否继续核销？");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mVerifyCancelBtn:
                listener.onVerifyPreOrderCancelClick();
                dismissSelf();
                break;
            case R.id.mVerifyConfirmBtn:
                listener.onVerifyPreOrderConfirmClick();
                dismissSelf();
                break;
            default:
                break;
        }
    }

    public void setParam(String orderId, OnVerifyPreOrderConfirmClickListener listener) {
        this.listener = listener;
        this.orderId = orderId;
    }

    public interface OnVerifyPreOrderConfirmClickListener {
        void onVerifyPreOrderConfirmClick();

        void onVerifyPreOrderCancelClick();
    }


}
