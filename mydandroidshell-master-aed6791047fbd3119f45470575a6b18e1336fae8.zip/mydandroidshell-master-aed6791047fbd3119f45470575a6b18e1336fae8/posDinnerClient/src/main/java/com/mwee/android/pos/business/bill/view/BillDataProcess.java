package com.mwee.android.pos.business.bill.view;


import android.content.Context;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.bill.api.BillApi;
import com.mwee.android.pos.business.bill.api.CNetOrderApi;
import com.mwee.android.pos.business.dinner.DinnerOrderDishesJump;
import com.mwee.android.pos.business.einvoice.PrintBillFrom;
import com.mwee.android.pos.business.orderdishes.constant.OrderDishesJumpFlagDefined;
import com.mwee.android.pos.business.orderdishes.view.jump.JumpFlag;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.business.pay.component.PayViewUtil;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.print.view.PrintTaskMakeSingleFragment;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.GetOrderFromCenterRespone;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.business.bill.OrderPrintDataResponse;
import com.mwee.android.pos.connect.business.monitor.report.LoadAccountBookResponse;
import com.mwee.android.pos.connect.business.netorder.GetNetOrderSimpleInfoResponse;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.connect.business.pay.GetPaySessionResponse;
import com.mwee.android.pos.connect.business.pay.StartRepayResponse;
import com.mwee.android.pos.connect.business.print.ReprintBillReceptResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CBill;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.ShopServiceUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.Order;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.InputUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/9/18.
 */
public class BillDataProcess {

    public ArrayMap<String, Order> cacheOrder = new ArrayMap<>();

    public void getOrderAndProcessor(Host host, final String orderiD, final IGetOrder iGetOrder) {
        Order order = cacheOrder.get(orderiD);
        if (order == null) {
            final Progress progress = ProgressManager.showProgress(host, R.string.bill_loading_order_details);
            BillConnectServiceUtil.sendGetPaySession(orderiD, new SocketCallback<GetPaySessionResponse>() {
                @Override
                public void callback(final SocketResponse<GetPaySessionResponse> socketResponse) {
                    progress.dismiss();
                    if (socketResponse.code != SocketResultCode.SUCCESS) {
                        ToastUtil.showToast(socketResponse.message);
                        return;
                    }
                    Order order = new Order();
                    order.paySession = socketResponse.data.paySession;
                    order.orderCache = socketResponse.data.order;
                    order.fastOrderModel = socketResponse.data.fastOrderModel;
//                    cacheOrder.put(orderiD, order);
                    if (iGetOrder != null) {
                        iGetOrder.getOrder(order);
                    }
                }
            });
        } else {
            if (iGetOrder != null) {
                iGetOrder.getOrder(order);
            }
        }
    }

    public void getOrderPrintData(Host host, final String orderId, final String businessDate, final String fiSellType, final String orderSource) {
        ProgressManager.showProgressUncancel(host, R.string.message_please_wait);

        BillApi.getOrderPrintData(orderId, businessDate, fiSellType, orderSource, new SocketCallback<OrderPrintDataResponse>() {
            @Override
            public void callback(SocketResponse<OrderPrintDataResponse> response) {
                ProgressManager.closeProgress(host);
                if (response.code == SocketResultCode.SUCCESS) {

                    if (TextUtils.isEmpty(response.data.htmlData)) {
                        detailData(host, response.data.printerDBModel, orderId, businessDate, fiSellType, orderSource);
                    } else {
                        PrintTaskMakeSingleFragment printTaskMakeSingleFragment = new PrintTaskMakeSingleFragment();
                        printTaskMakeSingleFragment.setIsNeedParseData(false);//不需要解析数据，直接用webview加载
                        printTaskMakeSingleFragment.setParams(host.getStringWithinHost(R.string.setting_reappear) + response.data.printerDBModel.fsReportName, response.data.printerDBModel, response.data.htmlData);
                        DialogManager.showCustomDialog(host, printTaskMakeSingleFragment, null);
                    }
                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        });
    }


    private void detailData(final Host host, final PrintTaskDBModel printerDBModel, final String orderId, final String businessDate, final String fiSellType, final String orderSource) {

        BusinessExecutor.executeAsyncExcute(new ASyncExecute<JSONObject>() {
            @Override
            public JSONObject execute() {
                return getDatasCheckType(host.getContextWithinHost(), printerDBModel);
            }
        }, new SyncCallback<JSONObject>() {
            @Override
            public void callback(JSONObject parseJson) {
                if (parseJson == null || parseJson.isEmpty()) {
                    ToastUtil.showToast(R.string.printer_not_support_restart_print);
                    return;
                }
                final PrintTaskMakeSingleFragment printTaskMakeSingleFragment = new PrintTaskMakeSingleFragment();
                printTaskMakeSingleFragment.setParams(host.getStringWithinHost(R.string.setting_reappear) + printerDBModel.fsReportName, printerDBModel, parseJson.toJSONString());
                printTaskMakeSingleFragment.setRightBtnClickListener(new PrintTaskMakeSingleFragment.OnRightBtnClickListener() {
                    @Override
                    public void onRightBtnClicked() {
                        ActionLog.addLog("账单管理页面-->重新打印结账单", "", "", ActionLog.PR_PRINT, printerDBModel.fsPrnData);
                        //标志打印结账单来源

                        PermissionsUtil.requestPermissio(host, AppCache.getInstance().userDBModel, Permission.DINNER_bnRePrnBill, "", new PermissionCallback() {
                            @Override
                            public void onCall(int errCode, String msg, UserDBModel userDBModel) {

                                ClientMetaUtil.updateSettingsValueByKey(META.PRINT_BILL_FROM, PrintBillFrom.FROM_BILL_MANAGE);
                                printRecept(host, orderId, businessDate, fiSellType, orderSource);
                                printTaskMakeSingleFragment.dismissSelf();
                            }
                        });

                    }
                });
                DialogManager.showCustomDialog(host, printTaskMakeSingleFragment, null);
            }
        });
    }

    //检查需要展示的数据类型
    private JSONObject getDatasCheckType(Context context, PrintTaskDBModel printTaskDB) {
        String url = String.format("%s.html", printTaskDB.uri.replace("/", "_"));
        String html = InputUtil.readFromAssets(context, url);
        if (TextUtils.isEmpty(html)) {
            return null;
        }
        JSONObject map = JSON.parseObject(printTaskDB.fsPrnData);
        map.put("uri", url);
        map.put("fsReportName", printTaskDB.fsReportName);//下单部门
        map.put("print_type", String.format(context.getString(R.string.printer_reappear_sub), printTaskDB.fsReportName));
        map.put("fsCreateUserName", printTaskDB.fsCreateUserName);
        map.put("fsCreateTime", printTaskDB.fsCreateTime);
        return map;
    }

    /**
     * 同步业务中心的账单数据
     *
     * @param date       营业日期
     * @param fiSellType 订单类型 0：正餐； 1：快餐
     */
    public void getAllData(final Host host, int currentPage, final String date, final int fiSellType,
                           final String fsBillSourceId, int billType, String accountBookId,
                           int payStatus, String orderId,String tableName,  ResultCallback<GetOrderFromCenterRespone> callback) {
        ProgressManager.showProgressUncancel(host, R.string.bill_loading_order_details);

//        String tableName = "", sellNo = "";
//        if (!TextUtils.isEmpty(searchContent)) {
//            String[] split = searchContent.split("_");
//            if (split.length >= 2) {
//                tableName = split[0];
//                sellNo = split[1];
//            }
//        }

        BillApi.GetOrderFromCenterRequest(currentPage, date, fiSellType, fsBillSourceId, billType, accountBookId, payStatus, "", orderId,
                true, false, false,tableName, new SocketCallback<GetOrderFromCenterRespone>() {
                    @Override
                    public void callback(SocketResponse<GetOrderFromCenterRespone> socketResponse) {
                        if (socketResponse.code == SocketResultCode.SUCCESS) {
                            callback.onSuccess(socketResponse.data);
                        } else {
                            callback.onFailure(socketResponse.code, socketResponse.message);
                            ToastUtil.showToast(socketResponse.message);
                        }
                        cacheOrder.clear();
                        ProgressManager.closeProgress(host);
                    }
                });
    }

    /**
     * 打印结账单
     *
     * @param mHost
     * @param fsSellNo
     */
    public void printRecept(final Host mHost, String fsSellNo, String businessDate, String fiSellType, String orderSource) {
        ProgressManager.showProgress(mHost, R.string.loading_printer);
        MCon.c(COrder.class, new SocketCallback<ReprintBillReceptResponse>() {
            @Override
            public void callback(SocketResponse<ReprintBillReceptResponse> response) {
                ProgressManager.closeProgress(mHost);
                if (response == null) {
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }

                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).reprinterBillRecept(fsSellNo, businessDate, fiSellType, orderSource);
    }

    /**
     * 反结账
     */
    public void rePay(final Host mHost, final Order order, final String reason, final ResultCallback<Boolean> callback) {
        String checkError = PayViewUtil.canPay(AppCache.getInstance().userDBModel.fsUserId);
        if (!TextUtils.isEmpty(checkError)) {
            ToastUtil.showToast(checkError);
            return;
        }
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.bill_loading_lock_table);
        MCon.c(CBill.class, new SocketCallback<StartRepayResponse>() {
            @Override
            public void callback(SocketResponse<StartRepayResponse> response) {
                progress.dismiss();
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(true);
                    order.orderCache.orderStatus = OrderStatus.ANTI_PAIED;
                    order.orderCache.updateAllSeqStatus(OrderSeqStatus.ANTIPAY);
                    //记录当前点菜操作
                    AppCache.getInstance().currentOrderID = order.orderCache.orderID;
                    AppCache.getInstance().refreshOrderToken(response.data.orderToken);
                    if (AppCache.getInstance().isRetailMode()) {

                        if (order.orderCache.fiSellType == Constants.SELL_TYPE_MAIN_DINNER) {
                            ToastUtil.showToast("反结账成功，请前往桌台操作!");
                           /* JumpFlag jumpFlag = new JumpFlag();
                            jumpFlag.jumpToIndex = OrderDishesJumpFlagDefined.JumpIndex.ORDER;
                            jumpFlag.jumpFrom = OrderDishesJumpFlagDefined.JumpFrom.ANTI_PAY;
                            FragmentController.showAirOrderDishesContainer(mHost, R.id.main_menufragment, order.orderCache, jumpFlag);*/
                        } else {
                            ToastUtil.showToast("反结账成功，请前往快餐取单页操作!");
                            /* FragmentController.showAirFastFoodDish(mHost, FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(order.orderCache), (ArrayList<MenuItem>) order.orderCache.originMenuList);*/
                        }
                    } else {
                        if (order.orderCache.fiSellType == Constants.SELL_TYPE_MAIN_DINNER) {
                            JumpFlag jumpFlag = new JumpFlag();
                            jumpFlag.jumpToIndex = OrderDishesJumpFlagDefined.JumpIndex.ORDER;
                            jumpFlag.jumpFrom = OrderDishesJumpFlagDefined.JumpFrom.ANTI_PAY;
                            DinnerOrderDishesJump.showOrderDishesContainer(mHost, R.id.main_menufragment, order.orderCache, response.data.amtPrePay, jumpFlag);
                        } else {
                            OrderDishesJump.showFastFoodDish(mHost, R.id.main_menufragment, order.fastOrderModel, (ArrayList<MenuItem>) order.orderCache.originMenuList, order.orderCache.orderStatus);
                        }
                    }
                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).startRePay(order.orderCache.fiSellType, order.orderCache.orderID, order.orderCache.fsmtableid, reason);
    }

    //处理异常订单，正餐：将订单重新绑定桌台，快餐：将fastfood_order_biz表中订单状态改为未结账
    public void dealErrorOrder(final Host mHost, OrderListModel order, final ResultCallback<Boolean> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.bill_loading_lock_table);
        MCon.c(CBill.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                progress.dismiss();
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(true);
                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).dealErrorOrder(order.fiSellType, order.orderID, order.fsmtableid);
    }


    public List<TempAppOrderSimpleInfo> NetOrderBillList = new ArrayList<>();

//    public LinkedHashMap<String, String> unMappingOrdersMap = new LinkedHashMap<>();
//    public List<String> unTurnedOrdersList = new ArrayList<>();

    /**
     * 账单管理页面的  外卖订单数据源
     */
    public void optTempappordersList(final Host mHost, int currentPage, String businessDate, String source, String searchContent, ResultCallback<GetNetOrderSimpleInfoResponse> callback) {
        ProgressManager.showProgress(mHost, mHost.getStringWithinHost(R.string.message_please_wait));

        CNetOrderApi.optTempappordersList(currentPage, businessDate, source, searchContent, new SocketCallback<GetNetOrderSimpleInfoResponse>() {
            @Override
            public void callback(SocketResponse<GetNetOrderSimpleInfoResponse> response) {
                ProgressManager.closeProgress(mHost);
                if (response.code == SocketResultCode.SUCCESS) {
                    NetOrderBillList.clear();
                    NetOrderBillList.addAll(response.data.tempAppOrderList);

//                    if (response.data.unMappingOrdersMap != null) {
//                        unMappingOrdersMap.clear();
//                        unMappingOrdersMap.putAll(response.data.unMappingOrdersMap);
//                    }
//
//                    if (response.data.unTurnedOrdersList != null) {
//                        unTurnedOrdersList.clear();
//                        unTurnedOrdersList.addAll(response.data.unTurnedOrdersList);
//                    }

//                    DriverBus.call("billFagment/refreshNetOrderBillList");
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                    ToastUtil.showToast(response.message);
                    ActionLog.addLog("外卖 获取订单列表失败 " + response.message, "", "", ActionLog.MESSAGE_TAKEAWAY, response.message);
                }

            }
        });

    }

    public static String getOrderTakeawaySource(String orderTakeawaySource) {

        if (TextUtils.isEmpty(orderTakeawaySource)) {
            return "";
        }
        if (orderTakeawaySource.contains(TakeAwaySource.MEITUAN)) {
            return "美团";
        }
        if (orderTakeawaySource.contains(TakeAwaySource.ELEME)) {
            return "饿了么";
        }
        if (orderTakeawaySource.contains(TakeAwaySource.MWEE)) {
            return "微信外卖";
        }
        return orderTakeawaySource;
    }

    public static String getPayTime(String time) {
        if (TextUtils.isEmpty(time)) {
            return time;
        } else if ("-----".equals(time)) {
            return time;
        } else {
            return DateUtil.formartDateStrToTarget(time, "yyyy-MM-dd HH:mm:ss", "HH:mm");
        }
    }

    /**
     * 获取外卖订单详细数据
     *
     * @param orderId
     */
    public void optTempAppOrderFromBizById(String orderId, ResultCallback<OptNetOrderFromBizResponse> callback) {
        CNetOrderApi.optNetOrderFromBizRequest(orderId, "", "", "", "", new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null && response.code == SocketResultCode.SUCCESS) {
                    if (response.data instanceof OptNetOrderFromBizResponse) {
                        OptNetOrderFromBizResponse messageOrderListResponse = (OptNetOrderFromBizResponse) response.data;
//                        TempAppOrder appOrder = ((OptNetOrderFromBizResponse) response.data).tempAppOrder;
                        callback.onSuccess(messageOrderListResponse);
                    } else {
                        callback.onFailure(response.code, response.message);
                    }
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void getSearchDropList(String businessDate, int fiSellType, String fsBillSourceId, int billType, String accountBookId,
                                  int payStatus,String searchType,String searchContent,
                                  ResultCallback<GetOrderFromCenterRespone> callback){
        BillApi.getOrderPrintData(businessDate,fiSellType,fsBillSourceId,billType, accountBookId,payStatus,searchType,searchContent,(response)->{
            if (response.code == SocketResultCode.SUCCESS) {
                callback.onSuccess(response.data);
            }
        });
    }

    public void loadAccountBook(ResultCallback<LoadAccountBookResponse> callback) {
        if (!ShopServiceUtil.abOrderService()) {
            return;
        }
        BillApi.loadAccountBook(true, new SocketCallback<LoadAccountBookResponse>() {
            @Override
            public void callback(SocketResponse<LoadAccountBookResponse> response) {
                if (response == null) {
                    callback.onFailure(-1, "业务失败");
                    return;
                }
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }
}
