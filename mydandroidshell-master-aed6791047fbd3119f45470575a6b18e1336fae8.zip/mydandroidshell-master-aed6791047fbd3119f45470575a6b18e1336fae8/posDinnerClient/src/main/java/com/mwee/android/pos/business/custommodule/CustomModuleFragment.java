package com.mwee.android.pos.business.custommodule;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;

public class CustomModuleFragment extends HomeFragment {

    private WebView mWebView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.custom_module_layout, container, false);
        initView(view);
        initData();
        return view;
    }

    private void initView(View view) {
        mWebView = view.findViewById(R.id.web_view);
        view.findViewById(R.id.tv_refresh).setOnClickListener(click);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initData() {
        mWebView.getSettings().setBuiltInZoomControls(false);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.loadUrl(AppCache.getInstance().customModuleUrl);

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                ProgressManager.showProgress(CustomModuleFragment.this, getResources().getString(R.string.load_html));
                mWebView.setEnabled(false);// 当加载网页的时候将网页进行隐藏
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                ProgressManager.closeProgress(CustomModuleFragment.this);
                mWebView.setEnabled(true);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

        });
    }

    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (view.getId()) {
                case R.id.tv_refresh:
                    initData();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void onPause() {
        super.onPause();
        if (mWebView != null) {
            mWebView.onPause();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mWebView != null) {
            mWebView.onResume();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mWebView != null) {
            ViewGroup parent = (ViewGroup) mWebView.getParent();
            if (parent != null) {
                parent.removeView(mWebView);
            }
            mWebView.removeAllViews();
            mWebView.destroy();
        }
    }
}
