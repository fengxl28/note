package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;

/**
 * Created by zhangmin on 2018/5/8.
 */

@HttpParam(httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "shoppayopen/openWeixinpayMode",
        response = WXOpenPayResponse.class)
public class WXOpenPayRequest extends BaseKouBeiRequest {
}
