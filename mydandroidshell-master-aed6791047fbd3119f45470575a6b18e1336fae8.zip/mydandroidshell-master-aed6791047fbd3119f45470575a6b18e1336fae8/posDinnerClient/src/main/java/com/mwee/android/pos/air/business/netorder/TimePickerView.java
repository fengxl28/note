package com.mwee.android.pos.air.business.netorder;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.Calendar;

/**
 * @ClassName: TimePickerView
 * @Description: 选择时间
 * @author: 刘秀秀
 */
public class TimePickerView extends BaseDialogFragment {

    public static final String TAG = TimePickerView.class.getSimpleName();

    private ImageView mCloseIv;
    private TextView submit_tv;
    private TimePicker timepicker;

    private String time = "";

    private OnTimeCheckListener onTimeCheckListener;

    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }

            switch (v.getId()) {
                case R.id.iv_bind_payment_close:
                    dismissSelf();
                    break;
                case R.id.submit_tv:
                    if (onTimeCheckListener != null) {
                        LogUtil.log("time==" + time);
                        onTimeCheckListener.onSave(time);
                    }
                    dismissSelf();
                    break;
            }
        }
    };

    public static TimePickerView newInstance() {
        TimePickerView fragment = new TimePickerView();
        return fragment;
    }

    public TimePickerView setTime(String time) {
        this.time = time;
        return this;
    }

    public void setOnTimeCheckListener(OnTimeCheckListener onTimeCheckListener) {
        this.onTimeCheckListener = onTimeCheckListener;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.view_time_picker, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (TextUtils.isEmpty(time)) {
            time = DateUtil.getCurrentDateTime("HH:mm");
        }
        assignViews(view);
        start();
    }

    private void assignViews(View convertView) {
        mCloseIv = (ImageView) convertView.findViewById(R.id.iv_bind_payment_close);
        submit_tv = (TextView) convertView.findViewById(R.id.submit_tv);
        timepicker = (TimePicker) convertView.findViewById(R.id.timepicker);
        timepicker.setIs24HourView(true);
        timepicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                String hourStr = hourOfDay <= 9 ? "0" + hourOfDay : hourOfDay + "";
                String minuteStr = minute <= 9 ? "0" + minute : minute + "";
                time = hourStr + ":" + minuteStr;
            }
        });
        mCloseIv.setOnClickListener(click);
        submit_tv.setOnClickListener(click);
    }

    private void start() {
        int currentHour = 1;
        int currentMinute = 0;
        try {
            currentHour = StringUtil.toInt(time.split(":")[0]);
            currentMinute = StringUtil.toInt(time.split(":")[1]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.set(2017, 10, 24, currentHour,
                currentMinute);
        timepicker.setCurrentHour(calendar.get(Calendar.HOUR_OF_DAY));
        timepicker.setCurrentMinute(calendar.get(Calendar.MINUTE));
    }

    public interface OnTimeCheckListener {
        void onSave(String time);
    }


}
