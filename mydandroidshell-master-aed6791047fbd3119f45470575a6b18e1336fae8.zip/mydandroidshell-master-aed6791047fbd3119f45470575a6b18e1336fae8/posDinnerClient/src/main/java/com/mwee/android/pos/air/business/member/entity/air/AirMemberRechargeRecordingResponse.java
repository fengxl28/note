package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.pos.air.business.member.entity.MemberRechargeRecordingContainer;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class AirMemberRechargeRecordingResponse extends BaseMemberResponse {

    public MemberRechargeRecordingContainer data = new MemberRechargeRecordingContainer();

    public AirMemberRechargeRecordingResponse(){

    }

}
