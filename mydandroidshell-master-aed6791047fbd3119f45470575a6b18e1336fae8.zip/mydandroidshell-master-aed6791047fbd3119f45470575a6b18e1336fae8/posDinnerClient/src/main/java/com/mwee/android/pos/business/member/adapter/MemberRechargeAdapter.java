package com.mwee.android.pos.business.member.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.dinner.R;

import java.util.ArrayList;

/**
 * 会员管理   会员充值数据适配器
 * Created by chris on 16/8/18.
 */
public class MemberRechargeAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<MemberRechargePackageModel.Rule> mData;
    private int selectPosition = -1;

    public MemberRechargeAdapter(Context context, ArrayList<MemberRechargePackageModel.Rule> data) {
        this.mContext = context;
        this.mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Holder holder;
        if (view == null) {
            view = View.inflate(mContext, R.layout.member_recharge_item, null);
            holder = new Holder();
            holder.initView(view);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        holder.initData(i);
        return view;
    }

    public class Holder implements View.OnClickListener {

        public TextView tv_recharge_money;
        public TextView tv_recharge_present;
        public LinearLayout contentLayout;
        public int position;

        public void initView(View v) {
            tv_recharge_money = (TextView) v.findViewById(R.id.tv_recharge_money);
            tv_recharge_present = (TextView) v.findViewById(R.id.tv_recharge_present);
            contentLayout = (LinearLayout) v.findViewById(R.id.contentLayout);
            v.setOnClickListener(this);
        }

        public void initData(int position) {
            this.position = position;
            MemberRechargePackageModel.Rule model = mData.get(position);
            contentLayout.setSelected(selectPosition == position);
            tv_recharge_money.setText(String.format("%s", model.money));

            tv_recharge_present.setVisibility(View.VISIBLE);
            tv_recharge_present.setText(String.format("(奖励: %s )", (TextUtils.isEmpty(model.presentDesc)) ? "无" : model.presentDesc));
        }

        @Override
        public void onClick(View v) {
            selectPosition = position;
            notifyDataSetChanged();
        }
    }

    public MemberRechargePackageModel.Rule getSelectPackage() {
        if (selectPosition == -1) {
            return null;
        }
        return mData.get(selectPosition);
    }
}
