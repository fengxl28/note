package com.mwee.android.pos.business.dinner.processor;

import android.text.TextUtils;

import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class DataSortProcessor {

    /**
     * 确定Item在列表中的位置
     *
     * @param modules 数据列表
     * @param uniq    MenuItem.MenuBiz.uniq
     * @return 参数格式不对或没找到则返回-1
     */
    public static int findItemPosition(List<MenuItem> modules, String uniq) {
        int position = -1;
        if (ListUtil.isEmpty(modules) || TextUtils.isEmpty(uniq)) {
            return position;
        }
        for (int i = 0; i < modules.size(); i++) {
            MenuItem item = modules.get(i);
            if (item == null || item.menuBiz == null) {
                return position;
            }
            if (TextUtils.equals(uniq, item.menuBiz.uniq)) {
                position = i;
                break;
            }
        }
        return position;
    }

    public static boolean needShowOriginTable(OrderCache order) {
        // 合桌保留原桌号打开，且有合桌信息
        return SettingHelper.isKeepOriginTable()
                && order != null && !TextUtils.isEmpty(order.mergedOrderInfo);
    }

    public static boolean needShowOriginTable(OrderCache order, MenuItem item) {
        // 合桌保留原桌号打开，且有合桌信息，且菜品不是当前桌台下
        return needShowOriginTable(order)
                && item != null && !TextUtils.equals(order.fsmtableid, item.originTableId);
    }

    /**
     * 根据更多中的设置项（合桌保留原桌号、西餐模式）处理数据
     *
     * @param modules 原数据列表
     * @param order   订单信息
     */
    public static void handleDataBySetting(List<MenuItem> modules, OrderCache order) {
        // 是否保留原桌台信息
        boolean isKeepOriginTable = SettingHelper.isKeepOriginTable();
        // 是否开启西餐模式
        boolean isWesternFoodMode = SettingHelper.isWesternFoodMode();
        if (isKeepOriginTable &&
                order != null && !TextUtils.isEmpty(order.mergedOrderInfo)) {// 只在有合桌信息时显示原桌台
            // 按桌台显示
            groupByOriginTable(modules, order, isWesternFoodMode);
        } else if (isWesternFoodMode) {
            // 按分类显示
            sortByRootMenuCls(modules);
        } else {
            // 按时间降序显示
            sortByTimeDesc(modules, order);
        }
    }

    /**
     * 按原桌台将数据分组
     *
     * @param modules           原数据列表
     * @param order             订单信息
     * @param isWesternFoodMode 是否开启西餐模式
     */
    public static void groupByOriginTable(List<MenuItem> modules, OrderCache order, boolean isWesternFoodMode) {
        if (order == null) {
            return;
        }
        LinkedHashMap<String, List<MenuItem>> group = new LinkedHashMap<>();// <originTableId,menuItemList>
        for (MenuItem menu : modules) {
            if (TextUtils.isEmpty(menu.originTableId)) {
                menu.originTableId = order.fsmtableid;
                menu.originTableName = order.fsmtablename;
            }
            String key = menu.originTableId;
            if (!group.containsKey(key)) {
                group.put(key, new ArrayList<>());
            }
            group.get(key).add(menu);
        }
        List<MenuItem> data = new ArrayList<>();
        for (String key : group.keySet()) {
            List<MenuItem> list = group.get(key);
            if (isWesternFoodMode) {
                sortByRootMenuCls(list);
            } else {
                sortByTimeDesc(list, order);
            }
            // 当前桌台下的菜放在最上面
            if (TextUtils.equals(order.fsmtableid, key)) {
                data.addAll(0, list);
            } else {
                data.addAll(list);
            }
        }
        modules.clear();
        modules.addAll(data);
    }

    /**
     * 按时间降序排列数据
     *
     * @param list  原数据列表
     * @param order 订单信息，用来获取单序
     */
    public static void sortByTimeDesc(List<MenuItem> list, OrderCache order) {
        if (ListUtil.isEmpty(list) || order == null) {
            return;
        }
        int size = list.size();
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                MenuItem item1 = list.get(j);
                MenuItem item2 = list.get(j + 1);
                if (item1 == null || item2 == null) {
                    continue;
                }
                OrderSeqModel seqModel1 = order.optSeqModel(item1.menuBiz.orderSeqID);
                OrderSeqModel seqModel2 = order.optSeqModel(item2.menuBiz.orderSeqID);
                if (seqModel1 == null || seqModel2 == null) {
                    continue;
                }
                if (seqModel1.seqNo < seqModel2.seqNo) {
                    list.set(j, item2);
                    list.set(j + 1, item1);
                }
            }
        }
    }

    /**
     * 按一级分类顺序排列数据
     *
     * @param list 原数据列表
     */
    public static void sortByRootMenuCls(List<MenuItem> list) {
        if (ListUtil.isEmpty(list)) {
            return;
        }
        int size = list.size();
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                MenuItem item1 = list.get(j);
                MenuItem item2 = list.get(j + 1);
                if (item1.rootMenuClsSortOrder > item2.rootMenuClsSortOrder) {
                    list.set(j, item2);
                    list.set(j + 1, item1);
                } else if (item1.rootMenuClsSortOrder == item2.rootMenuClsSortOrder) {
                    if (!TextUtils.isEmpty(item1.rootMenuClsId) && !TextUtils.isEmpty(item2.rootMenuClsId) &&
                            item1.rootMenuClsId.compareTo(item2.rootMenuClsId) > 0) {
                        list.set(j, item2);
                        list.set(j + 1, item1);
                    }
                }
            }
        }
    }
}
