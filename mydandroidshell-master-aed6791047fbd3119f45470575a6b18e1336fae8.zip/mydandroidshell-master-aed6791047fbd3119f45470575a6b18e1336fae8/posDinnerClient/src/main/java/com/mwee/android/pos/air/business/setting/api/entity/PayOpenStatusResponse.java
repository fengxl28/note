package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.pos.air.business.payment.entity.PayOpenStatus;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;

import java.util.ArrayList;


/**
 * Created by qinwei on 2018/2/6.
 */

public class PayOpenStatusResponse extends BasePosResponse {
    public ArrayList<PayOpenStatus> data = new ArrayList<>();

    public PayOpenStatusResponse() {
    }
}