package com.mwee.android.pos.business.dinner;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.List;

public class DinnerStandardUIUtil {

    /**
     * 显示是否计入餐标弹框，加菜下单时显示
     *
     * @param addMenuPrice 加菜的总金额
     */
    public static void showWithinDiningStandard(Host host, BigDecimal addMenuPrice, IResult callback) {
        DialogManager.showExecuteDialogWithClose(host, String.format("本次加菜总金额%s元，是否计入标准？", addMenuPrice.toPlainString()), "否，单独计算", "是",
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        // 菜品计入餐标
                        if (callback != null) {
                            callback.callBack(true, "加菜计入餐标");
                        }
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        // 菜品不计入餐标
                        if (callback != null) {
                            callback.callBack(false, "加菜不计入餐标");
                        }
                    }
                });
    }

    /**
     * 显示称重菜、时价菜确认弹框
     */
    public static void showConfirmWeightOrAmt(Host host, IResult callback) {
        DialogManager.showExecuteDialog(host, "您有未称重称重菜或未改价时价菜，将0元计入标准，是否确认下单？", "不，去称重/改价", "确认下单",
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        // 计入标准并下单
                        if (callback != null) {
                            callback.callBack(true, "");
                        }
                    }
                });
    }

    /**
     * 显示超标弹框
     */
    public static void showOutDiningStandard(Host host, IResult callback) {
        DialogManager.showExecuteDialog(host, "所点菜品将超出餐标，是否算作标准内？", "不，重新选择", "是的",
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        // 菜品计入餐标
                        if (callback != null) {
                            callback.callBack(true, "计入餐标");
                        }
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        // 菜品不计入餐标
                        if (callback != null) {
                            callback.callBack(false, "重新点菜");
                        }
                    }
                });
    }

    /**
     * 菜品列表中是否有称重菜/时价菜未改重量/价格
     */
    public static boolean hasEmptyWeightOrAmt(List<MenuItem> menuItemList) {
        if (ListUtil.isEmpty(menuItemList)) {
            return false;
        }
        for (MenuItem item : menuItemList) {
            if (item.supportWeight() && item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                return true;
            }
            if (item.supportTimes() && item.menuBiz.totalPrice.compareTo(BigDecimal.ZERO) == 0) {
                return true;
            }
        }
        return false;
    }
}
