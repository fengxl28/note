package com.mwee.android.pos.air.business.tshop;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.air.business.setting.api.ShopApi;
import com.mwee.android.pos.air.business.setting.shop.SelectAreaPopUpWindow;
import com.mwee.android.pos.air.business.setting.shop.model.CityModel;
import com.mwee.android.pos.air.business.setting.shop.model.DistrictModel;
import com.mwee.android.pos.air.business.setting.shop.model.GetProvinceListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.ProvinceModel;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;

/**
 * Created by zhangmin on 2017/10/9.
 */

public class TShopInfoFragment extends AirBaseFragment implements View.OnClickListener {
    private ShopDBModel shop;
    private TitleBar tb_fragment_account_manage_title;
    private TextView mShopNameLabel;
    private TextView mShopTypeNameLabel;
    private TextView mShopIdLabel;
    private TextView mShopPhoneLabel;
    private EditText mShopAddressEdt;
    private EditText mShopPersonNameEdt;
    private EditText mShopCellPhoneEdt;
    private TextView mShopInfoCancelLabel;
    private TextView mShopInfoConfirmLabel;
    private TextView mShopSimpleAddressLabel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_shopinfo_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View v) {
        tb_fragment_account_manage_title = (TitleBar) v.findViewById(R.id.tb_fragment_account_manage_title);
        mShopNameLabel = (TextView) v.findViewById(R.id.mShopNameLabel);
        mShopTypeNameLabel = (TextView) v.findViewById(R.id.mShopTypeNameLabel);
        mShopIdLabel = (TextView) v.findViewById(R.id.mShopIdLabel);
        mShopPhoneLabel = (TextView) v.findViewById(R.id.mShopPhoneLabel);
        mShopAddressEdt = (EditText) v.findViewById(R.id.mShopAddressEdt);
        mShopPersonNameEdt = (EditText) v.findViewById(R.id.mShopPersonNameEdt);
        mShopCellPhoneEdt = (EditText) v.findViewById(R.id.mShopCellPhoneEdt);
        mShopInfoCancelLabel = (TextView) v.findViewById(R.id.mShopInfoCancelLabel);
        mShopInfoConfirmLabel = (TextView) v.findViewById(R.id.mShopInfoConfirmLabel);
        mShopSimpleAddressLabel = (TextView) v.findViewById(R.id.mShopSimpleAddressLabel);
        mShopSimpleAddressLabel.setOnClickListener(this);
        mShopInfoCancelLabel.setOnClickListener(this);
        mShopInfoConfirmLabel.setOnClickListener(this);
        tb_fragment_account_manage_title.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                BizcenterApi.uploadLocalChangeData(null);
                dismissSelf();
            }
        });
    }

    private void initData() {
        shop = AppCache.getInstance().shop;
        tb_fragment_account_manage_title.setTitle("店铺信息");
        mShopNameLabel.setText(shop.fsShopName);
        mShopAddressEdt.setText(shop.fsAddr);
        mShopPersonNameEdt.setText(shop.fsContact);
        mShopPhoneLabel.setText(shop.fsCellphoneCt);
        mShopCellPhoneEdt.setText(shop.fsTel);
        mShopTypeNameLabel.setText(queryFoodTradeName(shop.fsFoodTradeId));
        mShopIdLabel.setText(shop.fsShopId);
    }


    private String queryFoodTradeName(String fsFoodTradeId) {

        String fsFoodTradeName = "";
        if (TextUtils.equals("1", fsFoodTradeId)) {
            fsFoodTradeName = "中式快餐";
        } else if (TextUtils.equals("2", fsFoodTradeId)) {
            fsFoodTradeName = "中式正餐";
        } else {
            fsFoodTradeName = "中式轻正餐";
        }
        return fsFoodTradeName;
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mShopSimpleAddressLabel:
                showAddressChoice();
                break;
            case R.id.mShopInfoCancelLabel:
                dismissSelf();
                break;
            case R.id.mShopInfoConfirmLabel:
                String shopAddress = mShopAddressEdt.getText().toString().trim();
                String personName = mShopPersonNameEdt.getText().toString().trim();
                String cellPhone = mShopCellPhoneEdt.getText().toString().trim();
                if (TextUtils.isEmpty(shopAddress)) {
                    ToastUtil.showToast("门店地址不能为空！");
                    return;
                }
                if (TextUtils.isEmpty(personName)) {
                    ToastUtil.showToast("联系人不能为空！");
                    return;
                }
                if (TextUtils.isEmpty(cellPhone)) {
                    ToastUtil.showToast("联系电话不能为空！");
                    return;
                }

                if (!com.mwee.android.pos.util.TextUtils.checkIsPhoneNumber(cellPhone)) {
                    ToastUtil.showToast("联系电话输入有误！");
                    return;
                }
                shop.fsAddr = shopAddress;
                shop.fsContact = personName;
                shop.fsTel = cellPhone;
                TShopProcessor.replaceTShopInfo(shop);
                dismissSelf();
                break;
            default:
                break;

        }

    }

    public void showAddressChoice() {
        ProgressManager.showProgress(getActivityWithinHost());
        ShopApi.getProvinceList(new ResultCallback<GetProvinceListResponse>() {
            @Override
            public void onSuccess(GetProvinceListResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                SelectAreaPopUpWindow selectAreaPopUpWindow = new SelectAreaPopUpWindow(TShopInfoFragment.this, rootView, data);
                selectAreaPopUpWindow.setSubCallback(new SelectAreaPopUpWindow.AreaCallback() {
                    @Override
                    public void updateinfo(ProvinceModel provinceModel, CityModel cityModel, DistrictModel districtModel) {
                        shop.fsProvinceId = provinceModel.id + "";
                        shop.fsCityId = cityModel.cityId + "";
                        shop.fsDistrictId = districtModel.id + "";
                        mShopSimpleAddressLabel.setText(provinceModel.name + " " + cityModel.cityName + " " + districtModel.name);
                    }
                });
                selectAreaPopUpWindow.show();
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                ToastUtil.showToast(msg);
            }
        });
    }

}
