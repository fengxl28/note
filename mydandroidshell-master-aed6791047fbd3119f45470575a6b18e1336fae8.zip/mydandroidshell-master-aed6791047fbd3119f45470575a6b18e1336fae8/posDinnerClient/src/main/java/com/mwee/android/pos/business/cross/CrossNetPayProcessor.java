package com.mwee.android.pos.business.cross;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.cross.api.CreditApi;
import com.mwee.android.pos.business.pay.view.netpay.AbstractNetPayProcessor;
import com.mwee.android.pos.business.pay.view.netpay.NetPayListener;
import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.connect.business.pay.CrossPaySocketResponse;
import com.mwee.android.pos.connect.business.pay.QueryCrossPayResultSocketResponse;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/19.
 */

public class CrossNetPayProcessor extends AbstractNetPayProcessor {
    private Host mHost;
    private NetPayListener<BigDecimal> netPayListener;
    /**
     * 请求唯一标示
     */
    private String requestId;
    /**
     * 销账账户
     */
    private CreditAccount account;
    /**
     * 销账订单
     */
    private String sellNo;
    /**
     * 支付类型
     */
    private PaymentDBModel payType;
    /**
     * 扫码信息
     */
    private String code;
    private CrossPayPrintInfo printInfo;

    public CrossNetPayProcessor(Host host) {
        this.mHost = host;
    }

    @Override
    public void loadQueryPayResult(NetPayProcessorListener listener) {
        CreditApi.loadQueryCrossPayResult(requestId, printInfo, new ResultCallback<QueryCrossPayResultSocketResponse>() {

            @Override
            public void onSuccess(QueryCrossPayResultSocketResponse data) {
                //0支付中1成功2失败
                switch (data.payResult.pay_status) {
                    case "0":
                        listener.onNetPayIng(data.payResult.pay_status_msg);
                        break;
                    case "1":
                        ToastUtil.showToast("销账成功");
                        netPayListener.onExecutePaySuccess(data.payResult.canCrossAmt);
                        break;
                    case "2":
                        listener.onExecuteNetPayError(data.payResult.pay_status_msg);
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                listener.onExecuteNetPayError(msg);
            }
        });
    }

    @Override
    public void onExecuteNetPay(String code, BigDecimal payAmount, NetPayProcessorListener netPayProcessorListener) {
        this.code = code;
        CreditApi.loadCrossPay(requestId, account,sellNo, payAmount, code, payType, new ResultCallback<CrossPaySocketResponse>() {
            @Override
            public void onSuccess(CrossPaySocketResponse data) {
                //errno{0:支付中 1：成功 2：失败}
                printInfo = data.printInfo;
                payStatus = 1;
                switch (data.crossResult.errno) {
                    case "0":
                        loadQueryPayResult(netPayProcessorListener);
                        break;
                    case "1":
                        ToastUtil.showToast("销账成功!");
                        netPayProcessorListener.onNetPaySuccess();
                        netPayListener.onExecutePaySuccess(data.crossResult.canCrossAmt);
                        break;
                    default:
                        netPayListener.onExecutePayError(data.crossResult.errmsg);
                        break;
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                payStatus = 0;
                netPayProcessorListener.onExecuteNetPayError(msg);
            }
        });
    }


    public void setNetPayListener(NetPayListener netPayListener) {
        this.netPayListener = netPayListener;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public void setAccount(CreditAccount account) {
        this.account = account;
    }
    public void setSellNo(String sellNo) {
        this.sellNo = sellNo;
    }

    public void setPayType(PaymentDBModel payType) {
        this.payType = payType;
    }
}
