package com.mwee.android.pos.air.business.tshop;

import com.mwee.android.air.connect.business.shop.GetDeptModelResonse;
import com.mwee.android.air.connect.business.shop.GetHostExteralModelResponse;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CTShop;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by zhangmin on 2017/10/25.
 */

public class TShopProcessor {

    /**
     * 修改外接设备配置
     *
     * @param tHostexternal 2/客显   5/电子秤 4/结账单打印份数
     * @param
     */
    public static void replaceTHostexternal(HostexternalDBModel tHostexternal) {

        MCon.c(CTShop.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null) {
                    if (response.code != SocketResultCode.SUCCESS) {
                        ToastUtil.showToast(response.message);
                    }
                } else {
                    ToastUtil.showToast("业务异常，请重试");
                }
            }
        }).replaceTPrinter(tHostexternal);
    }


    /**
     * 获取站点关联的外接设备
     *
     * @param fiCls 2/客显   5/电子秤  4/结账单打印份数
     * @return
     */
    public static void queryTHostexternal(int fiCls, final TResult<HostexternalDBModel> listener) {

        MCon.c(CTShop.class, new SocketCallback<GetHostExteralModelResponse>() {
            @Override
            public void callback(SocketResponse<GetHostExteralModelResponse> response) {
                if (response != null) {
                    if (response.code == SocketResultCode.SUCCESS) {
                        listener.callBack(response.data.model);
                    } else {
                        ToastUtil.showToast(response.message);
                    }
                } else {
                    ToastUtil.showToast("业务异常，请重试");
                }
            }
        }).queryTHostexternal(fiCls);
    }


    /**
     * 查询部门信息
     *
     * @param fsDeptId
     * @param listener
     */
    public static void queryTDeptModel(String fsDeptId, final TResult<DeptDBModel> listener) {
        MCon.c(CTShop.class, new SocketCallback<GetDeptModelResonse>() {
            @Override
            public void callback(SocketResponse<GetDeptModelResonse> response) {
                if (response != null) {
                    if (response.code == SocketResultCode.SUCCESS) {
                        listener.callBack(response.data.deptDBModel);
                    } else {
                        ToastUtil.showToast(response.message);
                    }
                } else {
                    ToastUtil.showToast("业务异常，请重试");
                }
            }
        }).queryTDeptModel(fsDeptId);
    }


    public static void replaceTShopInfo(ShopDBModel shopDBModel) {
        MCon.c(CTShop.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null) {
                    if (response.code != SocketResultCode.SUCCESS) {
                        ToastUtil.showToast(response.message);
                    }
                } else {
                    ToastUtil.showToast("业务异常，请重试");
                }
            }
        }).replaceTShopInfo(shopDBModel);
    }

}
