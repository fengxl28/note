package com.mwee.android.pos.air.business.tticket;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;

/**
 * Created by zhangmin on 2017/9/28.
 */

public class KBTicketFragment extends BaseFragment {

    private Switch swShopPrinter;
    private Switch swCustomerPrinter;
    private Switch swMakePrinter;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_ticket_kb_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View v) {

        swShopPrinter = v.findViewById(R.id.swShopPrinter);
        swCustomerPrinter = v.findViewById(R.id.swCustomerPrinter);
        swMakePrinter = v.findViewById(R.id.swMakePrinter);


        swShopPrinter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SettingProcessor.refreshSettingStatus(META.T_KB_SHOP_PRINT, isChecked ? "1" : "0");
            }
        });


        swCustomerPrinter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SettingProcessor.refreshSettingStatus(META.T_KB_CUSTOMER_PRINT, isChecked ? "1" : "0");
            }
        });

        swMakePrinter.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SettingProcessor.refreshSettingStatus(META.T_KB_MAKE_PRINT, isChecked ? "1" : "0");
            }
        });

        swShopPrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_SHOP_PRINT, "0"), "1"));
        swCustomerPrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_CUSTOMER_PRINT, "1"), "1"));
        swMakePrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_MAKE_PRINT, "1"), "1"));

    }

}
