package com.mwee.android.pos.base;

/**
 * Created by virgil on 16/9/26.
 */

public class HomeFragment extends BaseFragment{
}
