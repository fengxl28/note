package com.mwee.android.pos.air.business.member.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.mwee.android.pos.air.business.member.processor.MemberLevelEditorProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by zhangmin on 2018/1/02.
 */

public class MemberLevelAddDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private EditText etLevelName;
    private EditText etLevelCostMomey;

    private Button mMemberCancelBtn;
    private Button mMemberConfirmBtn;

    private OnMemberLevelAddListener listener;

    private MemberLevelEditorProcessor mMemberLevelEditorProcessor;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_level_add_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
    }


    private void initView(View view) {

        etLevelName = view.findViewById(R.id.etLevelName);
        etLevelCostMomey = view.findViewById(R.id.etLevelCostMomey);

        mMemberCancelBtn = view.findViewById(R.id.mMemberCancelBtn);
        mMemberConfirmBtn = view.findViewById(R.id.mMemberConfirmBtn);
        mMemberCancelBtn.setOnClickListener(this);
        mMemberConfirmBtn.setOnClickListener(this);

        mMemberLevelEditorProcessor = new MemberLevelEditorProcessor();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMemberConfirmBtn:
                String name = etLevelName.getText().toString().trim();
                String price = etLevelCostMomey.getText().toString().trim();

                if (!check(name, price)) {
                    return;
                }
                doAdd(name, price);

                break;
            case R.id.mMemberCancelBtn:
                dismissSelf();
                break;
            default:
                break;
        }
    }


    private void doAdd(String name, String price) {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        mMemberLevelEditorProcessor.loadMemberLevelAdd(name, price, new ResultCallback<String>() {

            @Override
            public void onSuccess(String data) {
                listener.onMemberLevelAddSuccess();
                progress.dismissSelf();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


    private boolean check(String name, String expense_amount) {

        if (android.text.TextUtils.isEmpty(name)) {
            ToastUtil.showToast("等级名称不可为空!");
            return false;
        }

        if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("等级名称不可以含有特殊字符!");
            return false;
        }

        if (!TextUtils.validate(expense_amount)) {
            ToastUtil.showToast("消费金额不可为空!");
            return false;
        }
        if (Integer.valueOf(expense_amount) == 0) {
            ToastUtil.showToast("消费金额必须大于0!");
            return false;
        }
        return true;
    }

    public void setOnMemberLevelAddListener(OnMemberLevelAddListener listener) {
        this.listener = listener;
    }

    public interface OnMemberLevelAddListener {
        void onMemberLevelAddSuccess();
    }
}
