package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class MemberPackageContainer extends BusinessBean {

    public String id;

    public String cs_id;

    public String m_shopid;

    public String begin_time;

    public String end_time;

    public String status;

    public String add_time;

    public String buy_num;

    public String pay_amount;

    public String reward_type;

    public List<MemberPackageModel> recharge_rules = new ArrayList();


}
