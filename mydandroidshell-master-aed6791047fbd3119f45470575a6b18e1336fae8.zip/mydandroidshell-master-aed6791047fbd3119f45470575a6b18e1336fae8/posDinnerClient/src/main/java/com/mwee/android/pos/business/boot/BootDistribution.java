package com.mwee.android.pos.business.boot;

import android.content.Intent;
import android.os.Bundle;

import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.backup.ForceSetAsMainHost;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.util.UIHelp;

/**
 * @ClassName: BootDistribution
 * @Description:
 * @author: SugarT
 * @date: 2017/10/19 下午2:35
 */
public class BootDistribution extends BaseActivity {

    public final static String KEY_EXIT = "KEY_EXIT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        homeCreated = true;
        super.onCreate(savedInstanceState);
        initView();
    }

    protected void initView() {
        Intent intent = getIntent();
        if (intent != null) {
            int exitSignal = intent.getIntExtra(KEY_EXIT, 0);
            if (exitSignal == 1) {
                finish();
                ForceSetAsMainHost.exitAllProcssAfterSeconds(this);
                return;
            }
        }

        //根据ui进程应用包名进行跳转
        if (APPConfig.isMyd()) {
            UIHelp.startDinnerWelcome(this);
        } else {
            UIHelp.startAirWelcome(this);
        }
        RunTimeLog.addLog(RunTimeLog.SYS_VERSION, "应用软件版本：" + BuildConfig.VERSION_NAME + ", 操作系统版本：" + android.os.Build.VERSION.RELEASE);
        finish();
    }

    /**
     * 发送退出APP的指令
     *
     * @param host Host
     */
    public static void exitApp(Host host) {
        Intent intent = new Intent(host.getContextWithinHost(), BootDistribution.class);
        intent.putExtra(KEY_EXIT, 1);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        host.startActivityWithinHost(intent);
    }
}
