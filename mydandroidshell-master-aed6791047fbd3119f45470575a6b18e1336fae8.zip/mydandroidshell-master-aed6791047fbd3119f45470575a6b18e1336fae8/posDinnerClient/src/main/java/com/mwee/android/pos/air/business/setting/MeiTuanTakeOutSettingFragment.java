package com.mwee.android.pos.air.business.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.pos.air.business.setting.api.TakeOutApi;
import com.mwee.android.pos.air.business.setting.takeout.TakeOutMenuManagerFragment;
import com.mwee.android.pos.air.business.tshop.THelpActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.takeout.TakeOutBindStatus;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by qinwei on 2018/3/12.
 */

public class MeiTuanTakeOutSettingFragment extends BaseFragment implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    private LinearLayout mMeiTuanOpenStatusLayout;
    private LinearLayout mMeiTuanMenuManagerLayout;
    private TextView mMeiTuanOpenStatusLabel;
    private TextView mMeituanMenuTagLabel;
    private Switch mMeituanTakeOutAutoOrderSwitch;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_take_out_set_meituan_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mMeiTuanOpenStatusLayout = (LinearLayout) view.findViewById(R.id.mMeiTuanOpenStatusLayout);
        mMeiTuanOpenStatusLabel = (TextView) view.findViewById(R.id.mMeiTuanOpenStatusLabel);
        mMeiTuanMenuManagerLayout = (LinearLayout) view.findViewById(R.id.mMeiTuanMenuManagerLayout);
        mMeituanMenuTagLabel = (TextView) view.findViewById(R.id.mMeituanMenuTagLabel);
        mMeituanTakeOutAutoOrderSwitch = (Switch) view.findViewById(R.id.mMeituanTakeOutAutoOrderSwitch);
        mMeituanTakeOutAutoOrderSwitch.setOnCheckedChangeListener(this);

        mMeiTuanOpenStatusLayout.setOnClickListener(this);
        mMeiTuanMenuManagerLayout.setOnClickListener(this);
    }

    private void initData() {
        mMeituanTakeOutAutoOrderSwitch.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_MEITUAN, "0"),
                "1"));
        mMeituanMenuTagLabel.setVisibility(View.GONE);
        mMeiTuanOpenStatusLabel.setVisibility(View.GONE);
        TakeOutApi.loadTakeOutBindStatus(Constants.TAKE_AWAY_SOURCE_MEITUAN, new ResultCallback<TakeOutBindStatus>() {
            @Override
            public void onSuccess(TakeOutBindStatus data) {
                switch (data.status) {
                    case 1:
                        setMeituanTakeOutBindStatus(true);
                        //data.mappingStatus == 0 代表外卖菜品未映射
                        mMeituanMenuTagLabel.setText("点击完成菜品管理");
                        setMeituanMenuTagVisibility(data.mappingStatus == 0);
                        mMeiTuanMenuManagerLayout.setEnabled(true);
                        mMeituanTakeOutAutoOrderSwitch.setEnabled(true);
                        break;
                    case -1:
                        setMeituanTakeOutBindStatus(false);
                        mMeituanMenuTagLabel.setText("请先绑定外卖平台账号");
                        setMeituanMenuTagVisibility(true);
                        mMeiTuanMenuManagerLayout.setEnabled(false);
                        mMeituanTakeOutAutoOrderSwitch.setEnabled(false);
                        break;
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_MEITUAN, "1");
        } else {
            ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_MEITUAN, "0");
        }
    }

    private void setMeituanMenuTagVisibility(boolean isShow) {
        mMeituanMenuTagLabel.setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void setMeituanTakeOutBindStatus(boolean isBind) {
        mMeiTuanOpenStatusLabel.setVisibility(View.VISIBLE);
        if (isBind) {
            mMeiTuanOpenStatusLabel.setText("已绑定");
        } else {
            mMeiTuanOpenStatusLabel.setText("未绑定");
        }
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mMeiTuanOpenStatusLayout:
                Intent intent = new Intent(getActivityWithinHost(), THelpActivity.class);
                intent.putExtra(THelpActivity.KEY_WEB_URI, TakeOutApi.getMeituanBindUrl());
                intent.putExtra(THelpActivity.KEY_TITLE_CONTENT, "美团外卖");
                startActivity(intent);
                break;
            case R.id.mMeiTuanMenuManagerLayout:
                FragmentController.addFragment(getActivityWithinHost(), TakeOutMenuManagerFragment.newInstance(Constants.TAKE_AWAY_SOURCE_MEITUAN));
                break;
            default:
                break;
        }
    }
}
