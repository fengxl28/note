package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberCreateResult extends BusinessBean {
    public String m_shopid;
    public String mobile;
    public String source;
    public String cs_id;
    public String real_name;
    public int level;
    public String card_no;
    public int add_time;

    public MemberCreateResult() {
    }
}
