package com.mwee.android.pos.business.message;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.message.processor.rapidOrder.IBindRapidOnlyPayToTableCallback;
import com.mwee.android.pos.business.message.processor.rapidOrder.RapidOnlyPayClientUtil;
import com.mwee.android.pos.business.rapid.api.bean.SaveRapidPayToOrderResponse;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.util.RapidUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.table.TableBizSimpInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: RapidPayChooseTableFragment
 * @Description:秒付纯收益选择桌台
 * @author: liuxiuxiu
 * @date: 17/07/28 下午17:50
 */
public class RapidPayChooseTableFragment extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = RapidPayChooseTableFragment.class.getSimpleName();

    private RelativeLayout mContainer;

    private GridView tables_gv;
    private TextView tv_pay_amt;
    private TextView tv_table_no;

    private CommonAdapter<TableBizSimpInfo> tableAdapter;
    public List<TableBizSimpInfo> tableBizSimpInfoList = new ArrayList<>();

    private int msgId = -1;
    private String tableName = "";

    private RapidPayment rapidPayment = null;
    private IBindRapidOnlyPayToTableCallback callback = null;

    public RapidPayChooseTableFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        setCancelable(false);
        View convertView = inflater.inflate(R.layout.rapid_pay_choose_table, container, false);
        mContainer = (RelativeLayout) convertView.findViewById(R.id.ryt_chooset_table_container);

        tables_gv = (GridView) convertView.findViewById(R.id.tables_gv);
        tv_pay_amt = (TextView) convertView.findViewById(R.id.tv_pay_amt);
        tv_table_no = (TextView) convertView.findViewById(R.id.tv_table_no);

        initTableAdapter();
        tables_gv.setAdapter(tableAdapter);
        registEvent();

        WindowManager wm = (WindowManager) RapidPayChooseTableFragment.this.getContextWithinHost().getSystemService(Context.WINDOW_SERVICE);
        ViewGroup.LayoutParams lp = mContainer.getLayoutParams();
        lp.width = wm.getDefaultDisplay().getWidth() * 3 / 5;
        lp.height = wm.getDefaultDisplay().getHeight() * 4 / 5;
        mContainer.setLayoutParams(lp);

        convertView.findViewById(R.id.tv_chooset_table_cancel).setOnClickListener(this);
        assData();
        return convertView;
    }

    public void setParam(List<TableBizSimpInfo> tableBizSimpInfoList, RapidPayment rapidPayment, String tableName, int msgId, IBindRapidOnlyPayToTableCallback callback) {
        this.rapidPayment = rapidPayment;
        this.tableBizSimpInfoList.clear();
        this.tableBizSimpInfoList.addAll(tableBizSimpInfoList);
        this.callback = callback;
        this.msgId = msgId;
        this.tableName = tableName;
    }

    public void assData() {
        if (rapidPayment == null) {
            return;
        }

        if (tableAdapter != null) {
            tableAdapter.notifyDataSetChanged();
        }

        if (tv_pay_amt != null) {
            BigDecimal payAmt = RapidUtil.parseRapidPayTotalAmt(rapidPayment);
            assText("支付金额", Calc.formatShow(payAmt), tv_pay_amt);
        }

        if (tv_table_no != null) {
            if (TextUtils.isEmpty(tableName)) {
                assText("桌台号", "无", tv_table_no);
            } else {
                assText("桌台号", tableName, tv_table_no);
            }
        }
    }

    private void assText(String labelText, String valueText, TextView textView) {
        SpannableString msp = new SpannableString(labelText + ":" + valueText);

        //设置字体大小（绝对值,单位：像素）  第二个参数boolean dip，如果为true，表示前面的字体大小单位为dip，否则为像素，同上。
        msp.setSpan(new AbsoluteSizeSpan(20, true), labelText.length() + 1, labelText.length() + 1 + valueText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        //设置字体前景色
        msp.setSpan(new ForegroundColorSpan(Color.parseColor("#ff553a")), labelText.length() + 1, labelText.length() + 1 + valueText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(msp);
    }

    private void bindToOrder(final RapidPayment rapidPayment, final String tableId, final int confirmBind) {
        ActionLog.addLog("纯收银   选桌台  发起绑定桌台请求", "", tableId, ActionLog.MESSAGE_RAPID_ONLY_PAY, rapidPayment);
        ProgressManager.showProgressUncancel(RapidPayChooseTableFragment.this, "请稍候...");
        RapidOnlyPayClientUtil.saveRapidPayToOrderRequest(tableId, msgId, confirmBind, new SocketCallback<SaveRapidPayToOrderResponse>() {
            @Override
            public void callback(SocketResponse<SaveRapidPayToOrderResponse> response) {
                ProgressManager.closeProgress(RapidPayChooseTableFragment.this);
                if (response == null || response.code != SocketResultCode.SUCCESS || response.data == null) {
                    ToastUtil.showToast(response == null ? "绑定失败" : response.message);
                    ActionLog.addLog("纯收银   选桌台  发起绑定桌台请求失败 异常消息：" + response == null ? "绑定失败" : response.message, ActionLog.MESSAGE_RAPID_ONLY_PAY);
                } else {
                    /**
                     * 0，支付金额匹配：
                     * 1，支付金额溢出
                     * 2，支付金额不足
                     */
                    if (confirmBind != 1 && response.data.payAmountNotRight != 0) {
                        ActionLog.addLog("纯收银   选桌台  发起绑定桌台请求中断 并弹框提醒用户：当前选择的桌台金额" + (response.data.payAmountNotRight == 1 ? "大于" : "小于") + "实付金额", ActionLog.MESSAGE_RAPID_ONLY_PAY);
                        DialogManager.showExecuteDialog(RapidPayChooseTableFragment.this, "您当前选择的桌台金额" + (response.data.payAmountNotRight == 1 ? "大于实付金额，继续选择会造成当前桌台溢收" : "小于实付金额") + "。 请问是否继续。", "取消", "确认", new DialogResponseListener() {
                            @Override
                            public void response() {
                                ActionLog.addLog("纯收银   选桌台  发起绑定桌台请求中断 用户选择'确认', 强制绑定", ActionLog.MESSAGE_RAPID_ONLY_PAY);
                                bindToOrder(rapidPayment, tableId, 1);
                            }
                        }, null);
                    } else {
                        ActionLog.addLog("纯收银   选桌台  发起绑定桌台请求成功 ", response.data.orderId, tableId, ActionLog.MESSAGE_RAPID_ONLY_PAY, rapidPayment);
                        if (callback != null) {
                            callback.bindResult(response.data.payAmountNotRight, response.data.orderId);
                        }
                        dismiss();
                    }
                }

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_chooset_table_cancel:
                ActionLog.addLog("纯收银  选桌台 用户点击'取消'按钮，关闭选择桌台弹窗", ActionLog.MESSAGE_RAPID_ONLY_PAY);
                /* 取消 */
                dismiss();
                break;
            default:
                break;
        }
    }

    /**
     * 注册点击事件
     */
    private void registEvent() {
        tables_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int position, long id) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                if (tableAdapter == null) {
                    return;
                }
                if (rapidPayment == null) {
                    return;
                }

                TableBizSimpInfo data = tableAdapter.getItem(position);
                if (data == null) {
                    return;
                }
                ActionLog.addLog("纯收银  选桌台  点击桌台 " + data.fsmtablename, ActionLog.MESSAGE_RAPID_ONLY_PAY);
                bindToOrder(rapidPayment, data.fsmtableid, 0);
            }
        });
    }

    /**
     * 初始化桌台Adapter
     */
    private void initTableAdapter() {
        tableAdapter = new CommonAdapter<TableBizSimpInfo>(this.getContextWithinHost(), tableBizSimpInfoList, R.layout.item_rapid_order_choose_table) {
            @Override
            public void convert(ViewHolder viewHolder, TableBizSimpInfo data, int position) {
                ((TextView) viewHolder.getView(R.id.table_name_tv)).setText(data.fsmtablename);
                ((TextView) viewHolder.getView(R.id.amt_tv)).setText(Calc.formatShow(data.fdExpAmt) + "");
            }
        };
    }

}
