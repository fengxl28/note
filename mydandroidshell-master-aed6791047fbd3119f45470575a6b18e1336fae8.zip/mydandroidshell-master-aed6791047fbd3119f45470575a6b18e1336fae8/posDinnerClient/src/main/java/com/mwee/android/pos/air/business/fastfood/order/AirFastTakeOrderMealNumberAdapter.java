package com.mwee.android.pos.air.business.fastfood.order;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.DateUtil;

import java.text.ParseException;

/**
 * Created by zhangmin on 2017/11/13.
 */

public class AirFastTakeOrderMealNumberAdapter extends BaseListAdapter<FastFoodSimpInfo> {


    int selectPosition = 0;
    private Host mHost;


    public AirFastTakeOrderMealNumberAdapter(Host mHost) {

        this.mHost = mHost;
    }


    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new AirFastTakeOrderMealNumberAdapter.MealNumberViewHolder(LayoutInflater.from(mHost.getContextWithinHost()).inflate(R.layout.air_takeorder_mealnumber_item, parent, false));
    }

    public FastFoodSimpInfo getCurrentFastFoodSimpInfo() {
        return modules.get(selectPosition);
    }


    class MealNumberViewHolder extends BaseViewHolder implements View.OnClickListener {

        int position = 0;
        TextView tvMealNumber;
        TextView tvMealTime;
        RelativeLayout layoutContainer;


        public MealNumberViewHolder(View itemView) {
            super(itemView);
            tvMealNumber = itemView.findViewById(R.id.tvMealNumber);
            tvMealTime = itemView.findViewById(R.id.tvMealTime);
            layoutContainer = itemView.findViewById(R.id.layoutContainer);
            itemView.setOnClickListener(this);

        }

        @Override
        public void bindData(int position) {
            this.position = position;
            FastFoodSimpInfo foodSimpInfo = modules.get(position);
            tvMealNumber.setText(String.format("牌号%s", foodSimpInfo.mealNumber));
            tvMealTime.setText(showOrderTime(foodSimpInfo.create_time));
            layoutContainer.setSelected(position == selectPosition);
            tvMealNumber.setSelected(position == selectPosition);
            tvMealTime.setSelected(position == selectPosition);
            if (position == selectPosition) {
                ViewToolsUtil.setBackground(tvMealTime, R.color.system_red);
                tvMealTime.setTextColor(mHost.getContextWithinHost().getResources().getColor(R.color.white));
            } else {
                ViewToolsUtil.setBackground(tvMealTime, R.color.color_gray_transparency89);
                tvMealTime.setTextColor(mHost.getContextWithinHost().getResources().getColor(R.color.gray_text));
            }



        }

        @Override
        public void onClick(View view) {
            if (selectPosition != position) {
                selectPosition = position;
                AirFastTakeOrderMealNumberAdapter.this.notifyDataSetChanged();
                itemClick.onMealNumberItemClick(getCurrentFastFoodSimpInfo().order_id);
            }
        }


        private String showOrderTime(String fsCreateTime) {

            String time = "";
            try {
                int currentTime = DateTimeUtil.getMMBetween(fsCreateTime, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (currentTime <= 0) {
                    currentTime = 1;
                }
                if (currentTime <= 999) {
                    time = currentTime + "分钟";
                } else {
                    time = "999分钟+";
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return time;
        }

    }


    private OnMealNumberItemClick itemClick;

    public void setOnMealNumberItemClick(OnMealNumberItemClick itemClick) {
        this.itemClick = itemClick;
    }

    public interface OnMealNumberItemClick {

        /**
         * 点击了牌号
         */
        void onMealNumberItemClick(String orderId);
    }


}
