package com.mwee.android.pos.air.business.netorder;

import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;

/**
 * Created by liuxiuxiu on 2017/10/17.
 */

public class AirWechatOrderProcessor {

    public void loadWechatOrderSetting(IResponse<ArrayMap<String,String>> iResponse) {
        AirWechatOrderApi.loadWechatOrderSetting(iResponse);
    }


    public void updateWechatOrderSetting(ArrayMap<String,String> settingList, IResult iResult) {
        AirWechatOrderApi.updateWechatOrderSetting(settingList, iResult);
    }
}
