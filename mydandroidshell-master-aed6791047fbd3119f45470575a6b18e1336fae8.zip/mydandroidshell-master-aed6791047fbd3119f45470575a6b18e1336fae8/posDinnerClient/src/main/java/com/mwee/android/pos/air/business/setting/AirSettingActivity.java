//package com.mwee.android.pos.air.business.setting;
//
//import android.os.Bundle;
//
//import com.mwee.android.pos.base.BaseActivity;
//import com.mwee.android.pos.dinner.R;
//
///**
// * Created by zhangmin on 2017/11/13.
// */
//
//public class AirSettingActivity extends BaseActivity {
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        setContentView(R.layout.activity_air_set);
//        getSupportFragmentManager().beginTransaction().replace(R.id.main_set, new AirSetContainerFragment()).commit();
//    }
//
//}
