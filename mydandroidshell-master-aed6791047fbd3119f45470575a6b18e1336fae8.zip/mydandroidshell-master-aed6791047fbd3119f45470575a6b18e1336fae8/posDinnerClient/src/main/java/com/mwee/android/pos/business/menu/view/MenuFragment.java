package com.mwee.android.pos.business.menu.view;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.Pair;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.menu.adapter.ItemDetailModelAdapter;
import com.mwee.android.pos.business.menu.adapter.MenuCategoryAdapter;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.recycler.CommonRecycleAdapter;
import com.mwee.android.pos.component.recycler.ViewHolder;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DM;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.KEditView;
import com.mwee.android.pos.widget.SKeyboardView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.ReentrantLock;

/**
 * MenuFragment
 * Created by virgil on 16/6/16.
 */
public class MenuFragment extends BaseFragment implements IDriver, View.OnClickListener {
    //一级子分类的和二级子分类的Adapter
    private final static String DRIVER_TAG = "menuview";
    public static final String FRAGMENT_TAG = MenuFragment.class.getName();
    private int selectViewId;
    private int selectViewIdTemp;

    private static final int searchViewId = 1001;  //搜索事件
    private GridView gv_menu_detail;
    private CommonRecycleAdapter<MenuTypeBean> sonCategoryAdapterL1, sonCategoryAdapterL2;
    //搜索

    private KEditView searchInputEdt;
    /* 翻页 */
    private TextView mPagePre;
    private TextView mPageNext;

    private LinearLayout mPageLayout;

    private SKeyboardView keyboardView;//自定义键盘
    private LinearLayout ll_keyboard;


    private ItemDetailModelAdapter itemAdp;
    private LinearLayout mMenusLayout;

    private RecyclerView menu_category_level1, menu_category_level2;
    private View line;
    private ListView orderDishesCategoryLsv;
    private MenuCategoryAdapter menuCategoryAdapter;
    private String sectionID = "";
    private ArrayMap<String, BigDecimal> selectCache;

    //search()执行完毕后再执行onKey
    private CountDownLatch mCountDownLatch = null;

    public static final String ALLOWED_INPUT_METHOD = "com.android.inputmethod.latin";

    /**
     * 控制字符 - 本文结束(对应回车键)
     */
    private static final int ETX = 3;

    /**
     * 缓存所有硬件设备输入的字符
     */
    private LinkedBlockingQueue<Character> mKeyCache = new LinkedBlockingQueue<>();

    /**
     * 线程锁-保证多线程从缓存字符中获取字符安全
     */
    private ReentrantLock mTakeLock = new ReentrantLock();

    /**
     * 同步锁-同步回车选定和从缓存字符输出的操作
     */
    private CountDownLatch mEnterLock = null;

    /**
     * 是否正从缓存中读取数据
     */
    private static volatile boolean isReadingCache = false;

    private Handler mInputHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            inputFromCache();
        }
    };

    StringBuilder inputConten = new StringBuilder();

    /**
     * 从键盘键入的字符缓存中获取并输出处理
     */
    private void inputFromCache() {
        if (isReadingCache) {
            return;
        }
        BusinessExecutor.executeNoWait(() -> {
            try {
                mTakeLock.lockInterruptibly();
                isReadingCache = true;
                while (!mKeyCache.isEmpty()) {
                    Character c = mKeyCache.take();

                    if (((char) ETX) == c) {
                        LogUtil.log("EVENT", Thread.currentThread().getName() + " 输入结束，选择第一个菜品：" + searchInputEdt.getText().toString() + ";");
                        // 如果是回车键，则处理选择第一个的逻辑
                        mEnterLock = new CountDownLatch(1);

                        LogUtil.log("EVENT", Thread.currentThread().getName() + " 设置目标搜索编号：" + inputConten.toString() + ";");
                        searchInputEdt.setTag(R.id.menu_search_tag, inputConten.toString());
                        inputConten.delete(0, inputConten.length());

                        choseTop();
                        if (mEnterLock != null && mEnterLock.getCount() > 0) {
                            mEnterLock.await();
                        }
                    } else {
                        LogUtil.log("EVENT", Thread.currentThread().getName() + " 继续输入 " + c.toString());
                        // 其他允许键入的字符，直接输出到 EditText
                        inputConten.append(c.toString());
                        searchInputEdt.post(() -> searchInputEdt.append(c.toString()));
                        mCountDownLatch = new CountDownLatch(1);
                    }
                }
                isReadingCache = false;
            } catch (InterruptedException e) {
                LogUtil.logError(e);
            } finally {
                mTakeLock.unlock();
            }
            return null;
        });
    }

    public void setParam(ArrayMap<String, BigDecimal> selectCache, String currentSectionID) {
        sectionID = currentSectionID;
        this.selectCache = selectCache;
    }


    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/notifyall", UIThread = true)
    public void refreshAll() {
        itemAdp.notifyDataSetChanged();
        searchInputEdt.hide();
    }

    @DrivenMethod(uri = DRIVER_TAG + "/notifyone", UIThread = true)
    public void refreshSingle(MenuItem menuItem) {
        int position = gv_menu_detail.getFirstVisiblePosition();
        List<MenuItem> itemDetailModels = itemAdp.getDatas();
        int viewPostion = 0;
        for (int i = 0; i < itemDetailModels.size(); i++) {
            MenuItem temp = itemDetailModels.get(i);
            if (TextUtils.equals(temp.itemID, menuItem.itemID)) {
                viewPostion = i;
                break;
            }
        }
        //TODO:
        itemAdp.getView(viewPostion, gv_menu_detail.getChildAt(viewPostion - position), gv_menu_detail);

    }

    @DrivenMethod(uri = DRIVER_TAG + "/refreshMenu", UIThread = true)
    public void refreshMenu() {
        /* 下单后更新 */
        MenuTypeBean type = null;
        if (!TextUtils.isEmpty(DinnerMenuUtil.currentTypeId)) {
            for (MenuTypeBean menuTypeBean : AppCache.getInstance().firstNodeMap) {
                if (DinnerMenuUtil.currentTypeId.equals(menuTypeBean.fsMenuClsId)) {
                    type = menuTypeBean;
                    break;
                }
            }
        }
        refreshMenuList(type);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.main_page_menu_fragment, container, false);
        if (selectCache == null) {
            return view;
        }
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        refreshView();
    }

    @Override
    public void onStart() {
        super.onStart();
        moveFocusToOtherView();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    /**
     * 移走点菜页初始化时在菜品上的焦点或搜索框内的焦点,
     * 解决在点菜页及结账页使用扫码枪扫条码时点菜页自动点菜问题
     */
    public void moveFocusToOtherView() {
        View view = getView();
        if (view != null) {
            view.setFocusable(true);
            view.setFocusableInTouchMode(true);
            view.requestFocus();
        }
    }

    public void refreshView() {
        if (selectCache == null) {
            return;
        }
        if (ListUtil.isEmpty(AppCache.getInstance().firstNodeMap)) {
            return;
        }
        initView(rootView);
        clickMainCategory(AppCache.getInstance().firstNodeMap.get(0));
        searchInputEdt.setEditView(ll_keyboard, keyboardView, false);
        // 每次页面重新创建，标志位重置
        isReadingCache = false;
    }

    public void setSelectCache(ArrayMap<String, BigDecimal> selectCache){
        this.selectCache = selectCache;
        if(itemAdp != null){
            itemAdp.setSelectCache(selectCache);
            itemAdp.notifyDataSetChanged();
        }
    }

    private void initView(View view) {
        orderDishesCategoryLsv = (ListView) view.findViewById(R.id.orderDishesCategoryLsv);
        ll_keyboard = (LinearLayout) view.findViewById(R.id.ll_keyboard);
        keyboardView = (SKeyboardView) view.findViewById(R.id.keyboard_view);
        searchInputEdt = (KEditView) view.findViewById(R.id.main_menu_fragment_search_input_edt);

        searchInputEdt.addTextChangedListener(new SearchTextWatcher());
        searchInputEdt.setVisibility(View.GONE);
        searchInputEdt.setOnKeyListener(new View.OnKeyListener() {

            /**
             * 扫码允许键入的 Key 值
             */
            List<Integer> allowKey = Arrays.asList(
                    KeyEvent.KEYCODE_0,
                    KeyEvent.KEYCODE_1,
                    KeyEvent.KEYCODE_2,
                    KeyEvent.KEYCODE_3,
                    KeyEvent.KEYCODE_4,
                    KeyEvent.KEYCODE_5,
                    KeyEvent.KEYCODE_6,
                    KeyEvent.KEYCODE_7,
                    KeyEvent.KEYCODE_8,
                    KeyEvent.KEYCODE_9,
                    KeyEvent.KEYCODE_A,
                    KeyEvent.KEYCODE_B,
                    KeyEvent.KEYCODE_C,
                    KeyEvent.KEYCODE_D,
                    KeyEvent.KEYCODE_E,
                    KeyEvent.KEYCODE_F,
                    KeyEvent.KEYCODE_G,
                    KeyEvent.KEYCODE_H,
                    KeyEvent.KEYCODE_I,
                    KeyEvent.KEYCODE_J,
                    KeyEvent.KEYCODE_K,
                    KeyEvent.KEYCODE_L,
                    KeyEvent.KEYCODE_M,
                    KeyEvent.KEYCODE_N,
                    KeyEvent.KEYCODE_O,
                    KeyEvent.KEYCODE_P,
                    KeyEvent.KEYCODE_Q,
                    KeyEvent.KEYCODE_R,
                    KeyEvent.KEYCODE_S,
                    KeyEvent.KEYCODE_T,
                    KeyEvent.KEYCODE_U,
                    KeyEvent.KEYCODE_V,
                    KeyEvent.KEYCODE_W,
                    KeyEvent.KEYCODE_X,
                    KeyEvent.KEYCODE_Y,
                    KeyEvent.KEYCODE_Z,
                    KeyEvent.KEYCODE_ENTER
            );

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // fix 重复的响应。过滤谷歌拼音输入法，中文输入下，扫码出现的 source=0x0 的事件。
                if (event.getSource() == 0) {
                    return false;
                }
                LogUtil.log("EVENT", event.toString());
                if (Settings.Secure.getString(getActivityWithinHost().getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD).startsWith(ALLOWED_INPUT_METHOD)) {
                    LogUtil.log("EVENT", "输入法匹配，收束处理");
                    // 当触发 ACTION_DOWN 时，TextWatcher 就会监听到 EditText 变化，所以这里拦截所有的 ACTION_DOWN 事件
                    if (allowKey.contains(event.getKeyCode()) && event.getAction() == KeyEvent.ACTION_DOWN) {
                        // 所有键盘事件加入队列，由 mInputHandler 统一处理
                        try {
                            if (KeyEvent.KEYCODE_ENTER == event.getKeyCode()) {
                                mKeyCache.put((char) ETX);
                            } else {
                                mKeyCache.put((char) event.getUnicodeChar());
                            }
                        } catch (InterruptedException e) {
                            LogUtil.logError("扫码搜索异常", e);
                        }
                        mInputHandler.sendEmptyMessageDelayed(1, 100);
                        return true;
                    }
                } else {
                    LogUtil.log("EVENT", "输入法不匹配，交由系统处理");
                    if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                        //fix两次触发问题，只在行为是up才真正执行，反之直接消费掉
                        if (event.getAction() != KeyEvent.ACTION_UP) {
                            return true;
                        }
                        BusinessExecutor.executeNoWait(new ASyncExecute() {
                            @Override
                            public Object execute() {
                                LogUtil.log("EVENT", Thread.currentThread().getName() + " 设置目标搜索编号：" + searchInputEdt.getText().toString() + ";");
                                searchInputEdt.setTag(R.id.menu_search_tag, searchInputEdt.getText().toString().trim());
                                choseTop();
                                return true;
                            }
                        });
                    }
                }
                return false;
            }
        });
        searchInputEdt.setOnKeyboardListener(new KEditView.OnKeyboardListener() {
            @Override
            public void onHide(boolean isCompleted) {
                calculatePage();
            }

            @Override
            public void onShow() {
                calculatePage();
            }

            @Override
            public void onPress(int primaryCode) {
            }
        });
        menuCategoryAdapter = new MenuCategoryAdapter(getContext(), AppCache.getInstance().firstNodeMap);
        menuCategoryAdapter.setOnItemClickListener(categoryClick);
        orderDishesCategoryLsv.addHeaderView(menuCategoryAdapter.getHeaderView());
        orderDishesCategoryLsv.setAdapter(menuCategoryAdapter);
        gv_menu_detail = (GridView) view.findViewById(R.id.gv_menu_detail);
        gv_menu_detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int arg2, long arg3) {
                if (!AppCache.getInstance().openOrder){
                    ToastUtil.showToast("您没有该操作权限,请管理员在后台配置权限.");
                    return;
                }
                if (itemAdp != null) {
                    MenuItem menuItem = itemAdp.getDatas().get(arg2);
                    //获取缓存中菜品时效信息
                    MenuEffectiveInfo menuEffectiveInfo = AppCache.getInstance().menuEffectiveInfoMap.get(menuItem.itemID);
                    //未设置时效菜品或者菜品时效时间生效中
                    if (menuEffectiveInfo == null || menuEffectiveInfo.dataIsEffectiveDate()) {
                        OrderDishesBizUtil.startProcessClickedMenu(getActivityWithinHost(), menuItem, false, sectionID);
                        if (searchInputEdt.getVisibility() == View.VISIBLE && !TextUtils.isEmpty(searchInputEdt.getText().toString())) {
                            searchInputEdt.setText("");
                        }
//                        searchInputEdt.hide();//搜索完点击菜品后不用隐藏键盘
                    }
                }
            }
        });
        itemAdp = new ItemDetailModelAdapter(getActivityWithinHost());
        itemAdp.setSelectCache(selectCache);
        gv_menu_detail.setAdapter(itemAdp);
        menu_category_level1 = (RecyclerView) view.findViewById(R.id.menu_category_level1);
        menu_category_level2 = (RecyclerView) view.findViewById(R.id.menu_category_level2);
        line = view.findViewById(R.id.line);
        initSonCateGory();

        mMenusLayout = (LinearLayout) view.findViewById(R.id.llyt_menu_detail);

        mPagePre = (TextView) view.findViewById(R.id.tv_menu_page_up);
        mPagePre.setOnClickListener(this);
        mPageNext = (TextView) view.findViewById(R.id.tv_menu_page_down);
        mPageNext.setOnClickListener(this);
        mPageLayout = (LinearLayout) view.findViewById(R.id.llyt_menu_turn_page);
        calculatePage();
        mMenusLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (searchInputEdt.isShow()) {
                    searchInputEdt.hide();
                }
            }
        });
    }

    public class SearchTextWatcher implements TextWatcher {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {

            LogUtil.log("EVENT", "afterTextChanged:" + s.toString());

            if (searchInputEdt.getVisibility() != View.VISIBLE || searchInputEdt.getText().toString().trim().isEmpty()) {

                LogUtil.log("EVENT", "afterTextChanged:" + s.toString() + "; return");
                return;
            }
            long time = DateUtil.getCurrentTimeInMills();
            //                    每次lock,解决点菜不对问题
            if (mCountDownLatch == null || mCountDownLatch.getCount() == 0) {
                mCountDownLatch = new CountDownLatch(1);
            }
            if (searchInputEdt.getTag() == null) {
                searchHandler.sendEmptyMessageDelayed(1, 300);
                LogUtil.log("EVENT", "afterTextChanged:" + s.toString() + "; 发送延迟命令1");
            } else {
                if (time - (Long) searchInputEdt.getTag() < 350) {//输入的字符间隔时间 小于700毫秒 移除以前的handler 延时600毫秒执行
                    searchHandler.removeMessages(1);
                    searchHandler.sendEmptyMessageDelayed(1, 300);
                    LogUtil.log("EVENT", "afterTextChanged:" + s.toString() + "; 发送延迟命令2");
                } else {
                    LogUtil.log("EVENT", "afterTextChanged:" + s.toString() + "; 发送非延迟命令");
                    searchHandler.sendEmptyMessage(1);
                }
            }
            searchInputEdt.setTag(time);
        }
    }

    /**
     * 分页相关设置
     */
    private void calculatePage() {
        /**
         * 计算一页显示的菜品数量
         */
        if (SettingHelper.habitGestureIsUD()) {
            int onePageCount = DinnerMenuUtil.allMenu2Show.size();
            if (onePageCount < 1) {
                onePageCount = 1;
            }
            DinnerMenuUtil.countPerPage = onePageCount;
            mPageLayout.setVisibility(View.GONE);
            DinnerMenuUtil.currentPage = 1;
            DinnerMenuUtil.maxPage = DinnerMenuUtil.allMenu2Show.size() / DinnerMenuUtil.countPerPage;
            if (DinnerMenuUtil.allMenu2Show.size() % DinnerMenuUtil.countPerPage > 0) {
                DinnerMenuUtil.maxPage++;
            }
            refreshMenuShow();
        } else {
            // 先使用翻页的布局占位，再计算菜品明细所展示的高度，解决无翻页布局占位，在显示翻页布局后，计算的菜品明细显示高度，大于实际可显示的高度
            mPageLayout.setVisibility(View.VISIBLE);

            if (gv_menu_detail.getMeasuredHeight() > 0) {
                if (isVisible()) {
                    refreshGridHeight();
                }
            } else {
                gv_menu_detail.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                            gv_menu_detail.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        } else {
                            gv_menu_detail.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                        }
                        if (isVisible()) {

                            refreshGridHeight();
                        }
                    }
                });

            }
        }
    }

    private void refreshGridHeight() {
        refreshGridHeight(false);
    }

    private void refreshGridHeight(boolean onlyCalc) {
        if (View.VISIBLE == mMenusLayout.getVisibility()) {
            /* 菜品明细显示的情况下才会计算, 收起时不计算，避免获取展示高度为0 */
            int contentHeight = getContentHeight();
            int itemHeight = (int) DM.dpToPx(100) + (int) DM.dpToPx(18);
            int maxLines = contentHeight / itemHeight;
            if (maxLines < 1) {
                maxLines = 1;
            }
            try {
                /**
                 * 计算一页显示的菜品数量
                 */
                DinnerMenuUtil.countPerPage = 4 * maxLines;
                DinnerMenuUtil.currentPage = 1;
                DinnerMenuUtil.maxPage = DinnerMenuUtil.allMenu2Show.size() / DinnerMenuUtil.countPerPage;
                if (DinnerMenuUtil.allMenu2Show.size() % DinnerMenuUtil.countPerPage > 0) {
                    DinnerMenuUtil.maxPage++;
                }

                if (!onlyCalc) {
                    refreshMenuShow();
                }
            } catch (Exception e) {
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "菜品显示区域高度[" + contentHeight + "], 当前菜品item高度[" + itemHeight +
                        "], 做多可显示[" + maxLines + "]行");
                e.printStackTrace();
            }
        }
    }

    private int getContentHeight() {
        int contentHeight = 0;
        int allHeight = mMenusLayout.getHeight();//整个右边的高度
        if (searchInputEdt.getVisibility() == View.VISIBLE) {//减去输入框的高度
            contentHeight = allHeight - (searchInputEdt.getHeight() + (int) DM.dpToPx(8));
        }
        if (menu_category_level1.getVisibility() == View.VISIBLE) {//减去一级菜单的高度
            contentHeight = allHeight - menu_category_level1.getHeight();
        }
        if (menu_category_level2.getVisibility() == View.VISIBLE) {//减去二级菜单的高度
            contentHeight = allHeight - (menu_category_level2.getHeight() + 1);
        }
        if (mPageLayout.getVisibility() == View.VISIBLE) {//减去翻页按钮的高度
            contentHeight = allHeight - ((int) DM.dpToPx(40) + (int) DM.dpToPx(24));
        }
        if (ll_keyboard.getVisibility() == View.VISIBLE) {//减去键盘的高度
            contentHeight = allHeight - ll_keyboard.getHeight();
        }
        contentHeight = contentHeight - (int) DM.dpToPx(20);//减去自身的margin的高度
        if (contentHeight <= 0) {
            contentHeight = gv_menu_detail.getHeight();
        }
        return contentHeight;
    }

    private void initSonCateGory() {
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        menu_category_level1.setLayoutManager(manager);
        sonCategoryAdapterL1 = new CommonRecycleAdapter<MenuTypeBean>(getActivity(), R.layout
                .menu_son_category_item_layout) {
            String selectMenuClsIdSon1 = "";
            int lastClickPostion = -1;

            @Override
            public void onBind(ViewHolder holder, MenuTypeBean data, int position) {
                boolean selected = TextUtils.equals(data.fsMenuClsId, selectMenuClsIdSon1);
                holder.setText(R.id.tv_category_name, data.fsMenuClsName);
                holder.getView(R.id.tv_category_name).setSelected(selected);

                if (selected) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(holder.getConvertView(),
                            R.drawable.bg_category_son_item_checked);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(holder.getConvertView(), 0);
                }
            }

            @Override
            public boolean onItemClick(View view, MenuTypeBean data, int position) {
                selectMenuClsIdSon1 = data.fsMenuClsId;
                if (lastClickPostion > -1) {
                    notifyItemChanged(lastClickPostion);
                    notifyItemChanged(position);
                } else {
                    notifyDataSetChanged();
                }
                lastClickPostion = position;

                if (!ListUtil.isEmpty(data.sonTypeList)) {
                    MenuTypeBean sonType = data.sonTypeList.get(0);
                    sonCategoryAdapterL2.setData(data.sonTypeList);//todo 这个地方需要再看看???
                    sonCategoryAdapterL2.onItemClick(null, sonType, 0);
                    menu_category_level2.setVisibility(View.VISIBLE);
                    line.setVisibility(View.VISIBLE);
                } else {
                    menu_category_level2.setVisibility(View.GONE);
                    line.setVisibility(View.GONE);
                }
                refreshMenuList(data);
                gv_menu_detail.smoothScrollToPosition(0);
                return false;
            }
        };
        menu_category_level1.setAdapter(sonCategoryAdapterL1);

        LinearLayoutManager manager2 = new LinearLayoutManager(getActivity());
        manager2.setOrientation(LinearLayoutManager.HORIZONTAL);
        sonCategoryAdapterL2 = new CommonRecycleAdapter<MenuTypeBean>(getActivity(), R.layout
                .menu_son_category_item_layout) {
            String selectMenuClsIdSon2 = "";
            int lastClickPostion = -1;

            @Override
            public void onBind(ViewHolder holder, MenuTypeBean data, int position) {
                boolean selected = TextUtils.equals(data.fsMenuClsId, selectMenuClsIdSon2);
                holder.setText(R.id.tv_category_name, data.fsMenuClsName);
                holder.getView(R.id.tv_category_name).setSelected(selected);

                if (selected) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(holder.getConvertView(),
                            R.drawable.bg_category_son_item_checked);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(holder.getConvertView(), 0);
                }
            }

            @Override
            public boolean onItemClick(View view, MenuTypeBean data, int position) {
                selectMenuClsIdSon2 = data.fsMenuClsId;

                if (lastClickPostion > -1) {
                    notifyItemChanged(lastClickPostion);
                }
                notifyItemChanged(position);

                lastClickPostion = position;
                refreshMenuList(data);
                gv_menu_detail.smoothScrollToPosition(0);
                return false;
            }

        };
        menu_category_level2.setAdapter(sonCategoryAdapterL2);
        menu_category_level2.setLayoutManager(manager2);
    }

    /**
     * 菜单分类的itemClick
     */
    public MenuCategoryAdapter.OnItemClickListener categoryClick = new MenuCategoryAdapter.OnItemClickListener() {
        @Override
        public void onClickHeader() {
            if (searchInputEdt.getVisibility() != View.VISIBLE) {
                searchInputEdt.setVisibility(View.VISIBLE);
                calculatePage();
            }
            selectViewIdTemp = selectViewId;
            selectViewId = searchViewId;
            itemAdp.setHelpCodeShow(false);
            clickMainCategory(null);

            searchInputEdt.show();

        }

        @Override
        public void onItemClick(final MenuTypeBean model) {
            ActionLog.addLog("菜单界面 点击分类item:" + model.fsMenuClsName, ActionLog.USER_ACTION_TRACE);
            itemAdp.setHelpCodeShow(false);
            searchInputEdt.hide();
            closeSearch();
            gv_menu_detail.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        gv_menu_detail.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    } else {
                        gv_menu_detail.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    }
                    clickMainCategory(model);
                }
            });
        }
    };
    private Handler searchHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            search();
        }
    };

    private void clickMainCategory(MenuTypeBean type) {
        if (type != null) {
            if (!ListUtil.isEmpty(type.sonTypeList)) {
                MenuTypeBean sonType = type.sonTypeList.get(0);
                sonCategoryAdapterL1.setData(type.sonTypeList);

                sonCategoryAdapterL1.onItemClick(null, sonType, 0);
                menu_category_level1.setVisibility(View.VISIBLE);
            } else {
                menu_category_level1.setVisibility(View.GONE);
                menu_category_level2.setVisibility(View.GONE);
                line.setVisibility(View.GONE);
            }
        } else {
            menu_category_level1.setVisibility(View.GONE);
            menu_category_level2.setVisibility(View.GONE);
            line.setVisibility(View.GONE);
        }
        refreshMenuList(type);
    }

    public void refreshMenuList(MenuTypeBean type) {
        if (type != null) {
            DinnerMenuUtil.currentTypeId = type.fsMenuClsId;
            DinnerMenuUtil.allMenu2Show = type.menuList;
        } else {
            DinnerMenuUtil.currentTypeId = "";
            DinnerMenuUtil.allMenu2Show = AppCache.getInstance().firstNodeMap.get(0).menuList;
        }

        calculatePage();
    }

    private void search() {
        if (searchInputEdt.getText().toString().isEmpty()) {
            return;
        }

        BusinessExecutor.executeAsyncExcute(new ASyncExecute<Pair<String, List<MenuItem>>>() {
            @Override
            public Pair<String, List<MenuItem>> execute() {

                LogUtil.log("EVENT", Thread.currentThread().getName() + " 搜索关键词：" + searchInputEdt.getText().toString() + ";");

                String tag = searchInputEdt.getText().toString().trim();
                List<MenuItem> menuItems = getMethcingData(tag);
                Pair<String, List<MenuItem>> searchResult = new Pair<>(tag, menuItems);
                return searchResult;
            }
        }, new SyncCallback<Pair<String, List<MenuItem>>>() {
            @Override
            public void callback(Pair<String, List<MenuItem>> pair) {
                DinnerMenuUtil.allMenu2Show = pair.second;
                itemAdp.setHelpCodeShow(true);
                calculatePage();
                LogUtil.log("EVENT", Thread.currentThread().getName() + " 搜索结果编号：" + pair.first + ";");
                LogUtil.log("EVENT", Thread.currentThread().getName() + " 目标搜索编号：" + String.valueOf(searchInputEdt.getTag(R.id.menu_search_tag)) + ";");
                if (!TextUtils.isEmpty(pair.first) && pair.first.endsWith(String.valueOf(searchInputEdt.getTag(R.id.menu_search_tag)))) {
//                if (TextUtils.equals(pair.first, String.valueOf(searchInputEdt.getTag(R.id.menu_search_tag)))) {
                    if (mCountDownLatch != null) {
                        mCountDownLatch.countDown();
                    }
                }
            }
        });
    }

    public void closeSearch() {
        if (searchInputEdt.getVisibility() == View.VISIBLE) {
            searchInputEdt.setVisibility(View.GONE);
            searchInputEdt.hide();

            searchInputEdt.setText("");
            selectViewId = selectViewIdTemp;
//            clickMainCategory(AppCache.getInstance().firstNodeMap.get(0));
        }
    }

    private List<MenuItem> getMethcingData(String et_result) {
        List<MenuItem> menuListAll = AppCache.getInstance().firstNodeMap.get(0).menuList;
        List<MenuItem> mathcingItemList = new ArrayList<>();
        if (!TextUtils.isEmpty(et_result)) {
            et_result = et_result.trim().replaceAll("\\s+", "").replaceAll(" ", "").toUpperCase();
            for (int i = 0; i < menuListAll.size(); i++) {
                MenuItem itemDtail = menuListAll.get(i);
                if (itemDtail.isCategory) {
                    continue;
                }
                if (TextUtils.isEmpty(itemDtail.fsHelpCode)) {
                    continue;
                }
                /*助记码匹配*/
                String nameAll = itemDtail.fsHelpCode.toUpperCase();
                String nameFrist = String.valueOf(itemDtail.fsHelpCode.charAt(0)).toUpperCase();

                if (itemDtail.fsHelpCode.contains(et_result)
                        || nameAll.contains(et_result.toUpperCase())
                        || nameFrist.contains(et_result.toUpperCase())
                        || itemDtail.fsItemId.contains(et_result)) {
                    mathcingItemList.add(itemDtail);
                }

                /* 匹配菜品条码 */
                if ((!TextUtils.isEmpty(itemDtail.fsBarCode)) && itemDtail.fsBarCode.toUpperCase().contains(et_result.toUpperCase())) {
                    // 如果菜品条码完全匹配，则添加到最前
                    if (TextUtils.equals(itemDtail.fsBarCode.toUpperCase(), et_result.toUpperCase())) {
                        mathcingItemList.add(0, itemDtail);
                    } else {
                        mathcingItemList.add(itemDtail);
                    }
                }
            }
        }
        return mathcingItemList;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case BaseFragment.TARGET_REQUEST:
                FragmentTransaction trx = getFragmentManager()
                        .beginTransaction();
                trx.show(this).commitAllowingStateLoss();
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_menu_page_up:
                /* 上一页 */
                if (DinnerMenuUtil.currentPage > 1) {
                    DinnerMenuUtil.currentPage--;
                    mPageNext.setEnabled(true);
                }
                refreshMenuShow();
                break;
            case R.id.tv_menu_page_down:
                /* 下一页 */
                if (DinnerMenuUtil.currentPage < DinnerMenuUtil.maxPage) {
                    DinnerMenuUtil.currentPage++;
                    mPagePre.setEnabled(true);
                }
                refreshMenuShow();
                break;
            default:
                break;
        }
    }


    private void refreshMenuShow() {

        if (DinnerMenuUtil.allMenu2Show.size() <= DinnerMenuUtil.countPerPage) {
            mPageLayout.setVisibility(View.GONE);
        } else {
            mPageLayout.setVisibility(View.VISIBLE);
        }

        itemAdp.setItemDetails(DinnerMenuUtil.getMenuOfPage());
        itemAdp.notifyDataSetChanged();
        if (DinnerMenuUtil.currentPage <= 1) {
            mPagePre.setEnabled(false);
        } else {
            mPagePre.setEnabled(true);
        }
        if (DinnerMenuUtil.currentPage >= DinnerMenuUtil.maxPage) {
            mPageNext.setEnabled(false);
        } else {
            mPageNext.setEnabled(true);
        }
    }

    private void choseTop() {
        if (mCountDownLatch != null && mCountDownLatch.getCount() > 0) {
            try {
                mCountDownLatch.await();
            } catch (InterruptedException e) {
                LogUtil.logBusiness("Menufragment-->searchInputEdt-->onKey()," + e.getMessage());
            }


        }
        searchInputEdt.post(() -> {
            //获取缓存中菜品时效信息
            List<MenuItem> menuOfPage = DinnerMenuUtil.getMenuOfPage();
            //不存在数据直接跳过
            if (null == menuOfPage || menuOfPage.size() == 0) {
                searchInputEdt.setText("");
                if (mEnterLock != null) {
                    mEnterLock.countDown();
                }
                return;
            }

            if (!AppCache.getInstance().openOrder){
                ToastUtil.showToast("您没有该操作权限,请管理员在后台配置权限.");
                return;
            }

            MenuEffectiveInfo menuEffectiveInfo = AppCache.getInstance().menuEffectiveInfoMap.get(menuOfPage.get(0).itemID);
            //未设置时效菜品或者菜品时效时间生效中
            if (menuEffectiveInfo == null || menuEffectiveInfo.dataIsEffectiveDate()) {
                OrderDishesBizUtil.startProcessClickedMenu(getActivityWithinHost(), menuOfPage.get(0), false, sectionID);
            }

            if (searchInputEdt.getVisibility() == View.VISIBLE && !TextUtils.isEmpty(searchInputEdt.getText().toString())) {
                searchInputEdt.setText("");
            }

            if (mEnterLock != null) {
                mEnterLock.countDown();
            }
        });
    }
}
