package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.db.business.kbbean.KPreTempDinnerModel;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.util.List;


/**
 * Created by zhangmin on 2018/8/21.
 */

public class TableReminderFragment extends BaseDialogFragment {

    private PullRecyclerView mTablePullRecyclerView;
    private TableAdapter tableAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_table_reminder_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(false);
        mTablePullRecyclerView = view.findViewById(R.id.mTablePullRecyclerView);
        mTablePullRecyclerView.setEnablePullToStart(false);
        mTablePullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mTablePullRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        tableAdapter = new TableAdapter();
        mTablePullRecyclerView.setAdapter(tableAdapter);

        view.findViewById(R.id.bt_dialog_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissSelf();
            }
        });

        view.findViewById(R.id.bt_dialog_right).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.callBack();
                dismissSelf();
            }
        });

        tableAdapter.modules.clear();
        tableAdapter.modules.addAll(koubeiOrder);
        tableAdapter.notifyDataSetChanged();
    }

    class TableAdapter extends BaseListAdapter<KPreTempDinnerModel> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new TableHolder(LayoutInflater.from(getActivity()).inflate(R.layout.fragment_table_reminder_item, parent, false));
        }
    }

    class TableHolder extends BaseViewHolder {

        private TextView tvNo;
        private TextView tvTime;
        private TextView tvPersonSum;
        private TextView tvMobile;
        private TextView tvTableStatus;
        private KPreTempDinnerModel model;

        public TableHolder(View v) {
            super(v);
            tvNo = v.findViewById(R.id.tvNo);
            tvTime = v.findViewById(R.id.tvTime);
            tvPersonSum = v.findViewById(R.id.tvPersonSum);
            tvMobile = v.findViewById(R.id.tvMobile);
            tvTableStatus = v.findViewById(R.id.tvTableStatus);

        }

        @Override
        public void bindData(int position) {
            model = tableAdapter.modules.get(position);
            tvNo.setText(String.valueOf(position + 1));
            tvTime.setText(model.fsTableTime);
            tvPersonSum.setText(model.fiPeopleNum);
            tvMobile.setText(model.fsUserMobile);
            tvTableStatus.setText(model.fsTableNO);
            if ("下厨时分配".equals(model.fsTableNO)) {
                tvTableStatus.setTextColor(getResources().getColor(R.color.system_red));
            } else {
                tvTableStatus.setTextColor(getResources().getColor(R.color.color_404040));
            }
        }

    }


    NormalListener listener;
    List<KPreTempDinnerModel> koubeiOrder;

    public void setListener(List<KPreTempDinnerModel> koubeiOrder, NormalListener listener) {
        this.koubeiOrder = koubeiOrder;
        this.listener = listener;
    }

}
