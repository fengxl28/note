package com.mwee.android.pos.business.bill.view;


import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.bill.api.CNetOrderApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.business.wechatorder.CWechat;
import com.mwee.android.pos.connect.business.wechatorder.GetAllWechatOrderResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 17/03/24.
 * 账单管理页外卖数据处理
 */
public class BillNetOrderDataProcess {

    /**
     * 账单列表页展示的数据源
     */
    public List<TempAppOrder> datasToShow = new ArrayList<>();

    public List<WechatOrderModel> wechatOrderModelList = new ArrayList<>();

    /**
     * 同步业务中心的账单数据
     *
     * @param date 营业日期
     * @param type 账单类型
     */
    public void getAllData(int currentPage, final String date, final String type, ResultCallback<GetAllNetOrderResponse> callback) {
        CNetOrderApi.getAllNetOrderRequest(currentPage, date, "", type, "", true, new SocketCallback<GetAllNetOrderResponse>() {
            @Override
            public void callback(SocketResponse<GetAllNetOrderResponse> socketResponse) {
                datasToShow.clear();
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    LogUtil.log("result.toString" + datasToShow.size());
                    callback.onSuccess(socketResponse.data);
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }
            }
        });
    }

    /**
     * 同步业务中心的微信外卖
     *
     * @param date 营业日期
     */
    public void getAllWechatOrderData(int currentPage, final String date, ResultCallback<GetAllWechatOrderResponse> callback) {
        MCon.c(CWechat.class, new SocketCallback<GetAllWechatOrderResponse>() {
            @Override
            public void callback(final SocketResponse<GetAllWechatOrderResponse> socketResponse) {
                wechatOrderModelList.clear();
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(socketResponse.data);
                } else {
                    callback.onFailure(socketResponse.code, socketResponse.message);
                }
            }
        }).getAllWechatOrderData(currentPage, date, "", true, "");
    }


}
