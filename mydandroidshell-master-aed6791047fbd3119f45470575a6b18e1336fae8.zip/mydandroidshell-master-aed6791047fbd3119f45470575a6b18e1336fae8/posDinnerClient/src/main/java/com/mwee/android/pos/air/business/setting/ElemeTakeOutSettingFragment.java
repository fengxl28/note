package com.mwee.android.pos.air.business.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.pos.air.business.setting.api.TakeOutApi;
import com.mwee.android.pos.air.business.setting.takeout.TakeOutMenuManagerFragment;
import com.mwee.android.pos.air.business.tshop.THelpActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.takeout.TakeOutBindStatus;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by qinwei on 2018/3/12.
 */

public class ElemeTakeOutSettingFragment extends BaseFragment implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    private LinearLayout mElemeOpenStatusLayout;
    private LinearLayout mElemeMenuManagerLayout;
    private TextView mElemeOpenStatusLabel;
    private TextView mElemeMenuTagLabel;
    private Switch mElemeTakeOutAutoOrderSwitch;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_take_out_set_eleme_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mElemeOpenStatusLayout = (LinearLayout) view.findViewById(R.id.mElemeOpenStatusLayout);
        mElemeOpenStatusLabel = (TextView) view.findViewById(R.id.mElemeOpenStatusLabel);
        mElemeMenuManagerLayout = (LinearLayout) view.findViewById(R.id.mElemeMenuManagerLayout);
        mElemeMenuTagLabel = (TextView) view.findViewById(R.id.mElemeMenuTagLabel);
        mElemeTakeOutAutoOrderSwitch = (Switch) view.findViewById(R.id.mElemeTakeOutAutoOrderSwitch);
        mElemeTakeOutAutoOrderSwitch.setOnCheckedChangeListener(this);

        mElemeOpenStatusLayout.setOnClickListener(this);
        mElemeMenuManagerLayout.setOnClickListener(this);
    }

    private void initData() {
        mElemeTakeOutAutoOrderSwitch.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_ELEME, "0"),
                "1"));
        mElemeMenuTagLabel.setVisibility(View.GONE);
        mElemeOpenStatusLabel.setVisibility(View.GONE);
        TakeOutApi.loadTakeOutBindStatus(Constants.TAKE_AWAY_SOURCE_ELEME, new ResultCallback<TakeOutBindStatus>() {
            @Override
            public void onSuccess(TakeOutBindStatus data) {
                switch (data.status) {
                    case 1:
                        setElemeTakeOutBindStatus(true);
                        //data.mappingStatus == 0 代表外卖菜品未映射
                        mElemeMenuTagLabel.setText("点击完成菜品管理");
                        setElemeMenuTagVisibility(data.mappingStatus == 0);
                        mElemeMenuManagerLayout.setEnabled(true);
                        mElemeTakeOutAutoOrderSwitch.setEnabled(true);
                        break;
                    case -1:
                        setElemeTakeOutBindStatus(false);
                        mElemeMenuTagLabel.setText("请先绑定外卖平台账号");
                        setElemeMenuTagVisibility(true);
                        mElemeMenuManagerLayout.setEnabled(false);
                        mElemeTakeOutAutoOrderSwitch.setEnabled(false);
                        break;
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }


    private void setElemeMenuTagVisibility(boolean isShow) {
        mElemeMenuTagLabel.setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void setElemeTakeOutBindStatus(boolean isBind) {
        mElemeOpenStatusLabel.setVisibility(View.VISIBLE);
        if (isBind) {
            mElemeOpenStatusLabel.setText("已绑定");
        } else {
            mElemeOpenStatusLabel.setText("未绑定");
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_ELEME, "1");
        } else {
            ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_ELEME, "0");
        }
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mElemeOpenStatusLayout:
                Intent intent = new Intent(getActivityWithinHost(), THelpActivity.class);
                intent.putExtra(THelpActivity.KEY_WEB_URI, TakeOutApi.getElemeBindUrl());
                intent.putExtra(THelpActivity.KEY_TITLE_CONTENT, "饿了么外卖");
                startActivity(intent);
                break;
            case R.id.mElemeMenuManagerLayout:
                FragmentController.addFragment(getActivityWithinHost(), TakeOutMenuManagerFragment.newInstance(Constants.TAKE_AWAY_SOURCE_ELEME));
                break;
            default:
                break;
        }
    }
}
