package com.mwee.android.pos.air.business.setting.api.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BaseKouBeiRequest;


/**
 * Created by qinwei on 2018/2/6.
 */
@HttpParam(httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "shoppayopen/getShopPayIsOpen",
        contentType = "application/json",
        response = PayOpenStatusResponse.class)
public class PayOpenStatusRequest extends BaseKouBeiRequest {
    public int type;

    public PayOpenStatusRequest() {
    }
}
