package com.mwee.android.pos.business.message.koubei;

import android.text.TextUtils;

import com.mwee.android.air.connect.business.order.OrderDetailResponse;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDataRequest;
import com.mwee.android.air.db.business.kbbean.KPreTempDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDinnerDataRequest;
import com.mwee.android.air.db.business.kbbean.KPreTempDinnerResponse;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CKouBei;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/5/24.
 */

public class KBBeforeClientProcessor implements IKBBeforeClientListener {

    private Host mHost;

    public KBBeforeClientProcessor(Host mHost) {
        this.mHost = mHost;
    }


    @Override
    public void loadOrderList(int pageNo, String searchParam, int queryType, String status, ResultCallback<KPreTempDataResponse> resultCallback) {

        MCon.c(CKouBei.class, new SocketCallback<KPreTempDataResponse>() {
            @Override
            public void callback(SocketResponse<KPreTempDataResponse> response) {
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).loadOrderList(pageNo, searchParam, queryType, status);

    }

    @Override
    public void loadOrder(String order_Id, String merchantPid, ResultCallback<KPreOrderDataResponse> resultCallback) {
        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KPreOrderDataResponse>() {
            @Override
            public void callback(SocketResponse<KPreOrderDataResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).loadOrder(order_Id, merchantPid);
    }

    @Override
    public void loadTempDinnerReminder(ResultCallback<KPreTempDinnerResponse> resultCallback) {
        KPreTempDinnerDataRequest request = new KPreTempDinnerDataRequest();
        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KPreTempDinnerResponse) {
                    KPreTempDinnerResponse response = (KPreTempDinnerResponse) responseData.responseBean;
                    resultCallback.onSuccess(response);
                } else {
                    resultCallback.onFailure(responseData.result, responseData.resultMessage);
                }
                progress.dismissSelf();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                resultCallback.onFailure(responseData.result, responseData.resultMessage);
                progress.dismissSelf();
                return false;
            }
        });
    }

    /*@Override
    public void loadTempOrderHeader(int pageNo, String searchParam, Integer queryType, ResultCallback<KPreTempDataResponse> resultCallback) {

        KPreTempDataRequest request = new KPreTempDataRequest();
        request.pageNo = pageNo;
        request.searchParam = searchParam;
        //request.payStatus = payStatus;
        request.queryType = queryType;
        //Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KPreTempDataResponse) {
                    KPreTempDataResponse response = (KPreTempDataResponse) responseData.responseBean;
                    resultCallback.onSuccess(response);
                } else {
                    resultCallback.onFailure(responseData.result, responseData.resultMessage);
                }
                //progress.dismissSelf();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                resultCallback.onFailure(responseData.result, responseData.resultMessage);
                //progress.dismissSelf();
                return false;
            }
        });
    }*/

    @Override
    public void doPrinter(String order_id, ResultCallback<BaseSocketResponse> resultCallback) {
        MCon.c(CKouBei.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {

            }
        }).doPrinter(order_id);

    }

    @Override
    public void acceptOrder(String order_id, String merchant_id, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {

        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {

                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }


            }
        }).acceptOrder(order_id, merchant_id);

    }

    @Override
    public void rejectOrder(String order_id, String merchant_id, String reason, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {

        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).rejectOrder(order_id, merchant_id, reason);
    }

    @Override
    public void prepareOrder(String order_id, String merchant_id, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {
        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).prepareOrder(order_id, merchant_id);
    }


    @Override
    public void verifyOrder(String verify_order_id, ResultCallback<KBPreOrderUpdateResponse> callback) {
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadVerifyOrder(verify_order_id);
    }

    @Override
    public void showVerifyDialog(ResultCallback<String> callback) {
        VerifyPreOrderDialogFragment fragment = new VerifyPreOrderDialogFragment();
        fragment.setOnVerifyPreOrderListener(new VerifyPreOrderDialogFragment.OnVerifyPreOrderListener() {
            @Override
            public void onVerifyPreOrderSuccess(KBPreOrderUpdateResponse response) {

                /**
                 * 控制分配桌台的按钮显示
                 */
                KBPreOrderCache orderCache = response.data;
                //TODO 先核销 ---> 分配桌台
                if (TextUtils.equals("DINNER", orderCache.business_type)
                        && TextUtils.equals("堂食", orderCache.dinner_type)
                        && TextUtils.equals("PLATFORM", orderCache.order_style)
                        && TextUtils.isEmpty(response.local_order_id)) {
                    allocationTable(orderCache, true, new ResultCallback<KBPreOrderUpdateResponse>() {
                        @Override
                        public void onSuccess(KBPreOrderUpdateResponse data) {
                            if (callback != null) {
                                callback.onSuccess(response.data.order_id);
                            }
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            super.onFailure(code, msg);
                            if (callback != null) {
                                callback.onSuccess(response.data.order_id);
                            }
                            ToastUtil.showToast(msg);
                        }
                    });
                    //todo 直接返回不走下一步处理
                    return;
                }

                //todo 先分配桌台--->再核销
                if (TextUtils.equals("DINNER", orderCache.business_type)
                        && TextUtils.equals("堂食", orderCache.dinner_type)
                        && TextUtils.equals("PLATFORM", orderCache.order_style)) {
                    verificationDoPrinter(orderCache.order_id, null);//打印小票
                }
                ToastUtil.showToast(GlobalCache.getContext().getString(R.string.verify_complete));//预点单核销完
//                VerifyPreOrderSuccessDialogFragment verifyPreOrderSuccessDialogFragment = new VerifyPreOrderSuccessDialogFragment();
//                //传核销成功后的订单号
//                verifyPreOrderSuccessDialogFragment.setParam(response.data.order_id, new VerifyPreOrderSuccessDialogFragment.OnVerifyPreOrderConfirmClickListener() {
//
//                    @Override
//                    public void onVerifyPreOrderConfirmClick() {
//                        if (callback != null) {
//                            callback.onSuccess(response.data.order_id);
//                        }
//                        showVerifyDialog(callback);
//                    }
//
//                    @Override
//                    public void onVerifyPreOrderCancelClick() {
//                        if (callback != null) {
//                            callback.onSuccess(response.data.order_id);
//                        }
//                    }
//                });
//                DialogManager.showCustomDialog(mHost, verifyPreOrderSuccessDialogFragment, "");
            }
        });
        DialogManager.showCustomDialog(mHost, fragment, "");
    }


    /**
     * 核销打印制作单
     *
     * @param order_id
     * @param resultCallback
     */
    private void verificationDoPrinter(String order_id, ResultCallback<BaseSocketResponse> resultCallback) {
        MCon.c(CKouBei.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {

            }
        }).verificationDoPrinter(order_id);
    }

    @Override
    public void refundOrder(String order_id, String merchant_id, String fsSellNo, String reason, String refundAmount, ArrayList<MenuItem> choiceRefundMenuList, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {
        Progress progress = ProgressManager.showProgressUncancel(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).refundOrder(order_id, merchant_id, fsSellNo, reason, refundAmount, choiceRefundMenuList);

    }

    @Override
    public void rejectRefundOrder(String order_id, String merchant_id, String fsSellNo, String rejectReason, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {
        Progress progress = ProgressManager.showProgressUncancel(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).rejectRefundOrder(order_id, merchant_id, fsSellNo, rejectReason);
    }

    @Override
    public void agreenRefundOrder(String order_id, String merchant_id, String fsSellNo, String agreeRefundReason, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {
        Progress progress = ProgressManager.showProgressUncancel(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                progress.dismissSelf();
                if (response.data != null && response.data.data != null && response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).agreenRefundOrder(order_id, merchant_id, fsSellNo, agreeRefundReason);
    }


    /**
     * 口碑预点单 正餐堂食模式下 分配桌台
     *
     * @param orderCache
     * @param resultCallback
     */
    @Override
    public void allocationTable(KBPreOrderCache orderCache, boolean printMake, ResultCallback<KBPreOrderUpdateResponse> resultCallback) {
        AllocationTableFragment allocationTableFragment = new AllocationTableFragment();
        allocationTableFragment.setListener(orderCache, new OnResultListener<MtableDBModel>() {
            @Override
            public void callBack(MtableDBModel var1) {
                Progress progress = ProgressManager.showProgressUncancel(mHost.getActivityWithinHost());
                MCon.c(CKouBei.class, new SocketCallback<KBPreOrderUpdateResponse>() {
                    @Override
                    public void callback(SocketResponse<KBPreOrderUpdateResponse> response) {
                        progress.dismissSelf();
                        if (response.data != null && response.data.data != null && response.success()) {
                            resultCallback.onSuccess(response.data);
                        } else {
                            resultCallback.onFailure(response.code, response.message);
                        }
                    }
                }).allocationTable(orderCache.order_id, var1.fsmtableid, printMake);
            }
        });
        allocationTableFragment.setCancelable(false);
        allocationTableFragment.show(mHost.getFragmentManagerWithinHost(), allocationTableFragment.getClass().getName());
    }


    public String buildOrderStatusMsg(String status) {

        String orderStatusMsg = "";
        switch (status) {
            case "PUSH"://todo 推过来新订单
                orderStatusMsg = "待接单";
                break;
            case "RECEIPT"://todo 接单完成
                orderStatusMsg = "备餐中";
                break;
            case "COOKING":
                orderStatusMsg = "已下厨";
                break;
            case "REJECT"://todo  拒单完成
                orderStatusMsg = "已拒单";
                break;
            case "PREPARE"://todo 点击了备餐完成按钮
                orderStatusMsg = "请取餐";
                break;
            case "DELIVER"://todo 点击了送餐完成按钮
                orderStatusMsg = "已送餐";
                break;
            case "CLOSE"://todo  商家长时间不接单 超时
                orderStatusMsg = "已拒单";
                break;
            case "CANCEL"://todo  用户取消订单
                orderStatusMsg = "已取消";
                break;
            case "REFUND"://todo  商家已退款
                orderStatusMsg = "已退款";
                break;
            case "PARTIAL_REFUND"://todo  商家部分退款
                orderStatusMsg = "商家部分退款";
                break;
            case "FINISH"://todo  订单已完成
                orderStatusMsg = "订单已完成";
                break;

            default:
                break;
        }
        return orderStatusMsg;
    }


    /**
     * 口碑预点单的订单支付状态
     *
     * @return
     */
    public String buildPayStatusMsg(String fsPayStatus) {
        String payStatusMsg = "";
        if (TextUtils.isEmpty(fsPayStatus)) {
            return "";
        }
        switch (fsPayStatus) {
            case "APPLY_REFUND"://todo  用户申请退款
                payStatusMsg = "用户申请退款";
                break;
            case "ACCEPT_REFUND"://todo  商家接受退款
                payStatusMsg = "商家接受退款";
                break;

            //产品需求 这两种状态不需要再界面展示
           /* case "REJECT_REFUND"://todo  商家拒绝退款
                payStatusMsg = "商家拒绝退款";
                break;*/

            /*case "REFUNDED"://todo  商家同意退款
                payStatusMsg = "商家同意退款";
                break;*/
            default:
                break;
        }
        return payStatusMsg;
    }

    public void kbRefundGetOrder(String kb_order_id, ResultCallback<OrderCache> resultCallback) {
        MCon.c(CKouBei.class, new SocketCallback<OrderDetailResponse>() {
            @Override
            public void callback(SocketResponse<OrderDetailResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data.orderCache != null) {
                        resultCallback.onSuccess(response.data.orderCache);
                    } else {
                        resultCallback.onFailure(SocketResultCode.EXCEPTION, response.message);
                    }
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).kbRefundGetOrder(kb_order_id);

    }

}
