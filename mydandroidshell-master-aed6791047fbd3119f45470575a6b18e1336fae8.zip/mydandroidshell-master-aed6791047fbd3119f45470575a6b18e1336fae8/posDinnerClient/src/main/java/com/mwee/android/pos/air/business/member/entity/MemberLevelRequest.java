package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberLevelRequest extends BaseMemberParam {
    public int m_shopid;
    public int is_all;

    public MemberLevelRequest() {
    }
}