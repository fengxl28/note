package com.mwee.android.pos.business.common.dialog.pay;

import android.text.TextUtils;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.message.processor.rapidOrder.RapidPayConformUtil;
import com.mwee.android.pos.business.rapid.api.bean.IgnoreRapidOnlyPayOrderResponse;
import com.mwee.android.pos.connect.business.table.TableActionRespose;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.order.OrderCache;

/**
 * Created by qinwei on 2017/9/7.
 */

public class RapidPayMessageProcessor {

    /**
     * 忽略消息
     *
     * @param msgId          消息id
     * @param socketCallback
     */
    public void ignoreRapidConfirmMessage(int msgId, SocketCallback<IgnoreRapidOnlyPayOrderResponse> socketCallback) {
        RapidPayConformUtil.ingnorRapidConfirmMessage(msgId, socketCallback);
    }

    /**
     * 允许秒付拉单支付
     *
     * @param msgId          消息id
     * @param socketCallback
     */
    public void allowRapidConfirmMessage(int msgId, SocketCallback<IgnoreRapidOnlyPayOrderResponse> socketCallback) {
        RapidPayConformUtil.allowRapidConfirmMessage(msgId, socketCallback);
    }

    /**
     * 根据桌台id 获取桌台对应订单信息
     *
     * @param tableId
     * @param callback
     */
    public void loadTableOrderInfo(String tableId, final ResultCallback<OrderCache> callback) {
        RapidPayConformUtil.loadTableOrderInfo(tableId, AppCache.getInstance().userDBModel.fsUserId, new SocketCallback<TableActionRespose>() {
            @Override
            public void callback(SocketResponse<TableActionRespose> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    if (TextUtils.equals(TableConstans.TABLE_STATUS_FREE, response.data.tableStatusBean.fsmtablesteid)) {
                        callback.onFailure(response.code, "桌台未开台");
                    } else {
                        if ((response.data.tableStatusBean.flag & 2) == 2) {
                            //服务铃信息
                            callback.onFailure(-1, response.data.orderCache.fsmtablename + "桌台存在服务铃信息,请先处理！");
                        } else if ((response.data.tableStatusBean.flag & 4) == 4) {
                            //秒点信息
                            callback.onFailure(-2, response.data.orderCache.fsmtablename + "桌台有未处理的秒点订单！");
                        } else {
                            callback.onSuccess(response.data.orderCache);
                        }
                    }
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }
}
