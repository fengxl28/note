package com.mwee.android.pos.base;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.support.multidex.MultiDexApplication;

import com.mwee.android.alp.AlpLog;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.AppLog;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.search.WakeUpBizCenter;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.mw.MwApplication;
import com.mwee.android.pos.util.eloscanner.ScannerManager;
import com.mwee.android.posprint.framework.PrintApplication;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.OEM;
import com.mwee.android.tools.ProcessUtil;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.android.tools.timesync.TimeSyncUtil;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.BuglyStrategy;
import com.tencent.bugly.crashreport.CrashReport;

import java.util.LinkedHashMap;
import java.util.Map;

import cn.mwee.android.pay.other.util.DeviceStateInfoUtil;
import cn.mwee.android.skynet.appruninfo.util.Utils;

/**
 * gradle 插件升级 3.0 后的产生分包问题，修改继承 MultiDexApplication
 *
 * @author virgil
 */
public class DinnerApplication extends MultiDexApplication { // 将父类换成 BaseApplication
    public static DinnerApplication instance;

    /**
     * 初始化开发环境的一些设置
     */
    public static void initDevConfig() {
        if (!BaseConfig.isProduct()) {
//            String url = DBMetaUtil.getSettingsValueByKey(META.DEV_URL);
//            if (!TextUtils.isEmpty(url)) {
//                MwLog.setTest(TextUtils.equals(url, Constant.URL_ROOT_PRODUCT));
//
//                Constant.setUrlRootTest(url);
//            }
//
//            String urlLogin = DBMetaUtil.getSettingsValueByKey(META.DEV_URL_LOGIN);
//            if (!TextUtils.isEmpty(urlLogin)) {
//                LoginConstant.setUrlRootTest(urlLogin);
//            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
//        if (BuildConfig.DEBUG) {
//            InitDebugTools.initBlockCanary(this);
//        }
        APPConfig.PUSH_PORT = getResources().getInteger(R.integer.push_port);
        APPConfig.PD_APPID = BuildConfig.APPID;
        BizConstant.VERSION_CODE = BuildConfig.VERSION_CODE;
        BizConstant.VERSION_NAME = BuildConfig.VERSION_NAME;
        BaseConfig.ENV = getResources().getInteger(R.integer.meta_env);
        GlobalCache.getInstance().registerContext(this);

        instance = this;
        //加载阿里的hotfix模块
        loadAliHotFix();
        //环境设置库的初始化

        GlobalCache.getInstance().setLogOpen(BaseConfig.ENV != Environment.PRODUCT);
        LogUtil.setWriteLog(true);
        LogUpload.setTest(!BaseConfig.isProduct());
        if (ProcessUtil.isMainProcess(this) && !BaseConfig.isProduct()) {
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    DeviceUtil.printSystemInfo(DinnerApplication.this);
                }
            }).start();
        }
        DriverBus.setErrorWithException(false);
        AlpLog.setRelease(BaseConfig.isProduct());
        //时间同步
        new TimeSyncUtil().syncTime();
        //Bugly初始化
        initBugly();

        SocketConfig.API_VERSION = 103;
        SocketConfig.PORT_LIST = getResources().getIntArray(R.array.port_list);
        SocketConfig.PORT = getResources().getInteger(R.integer.port);

        //初始化DB,重要,需要放在业务初始化之前
        BaseDBInit.initDB(this);
        initDevConfig();

        //需要阻塞
        //由于classLoader不同 业务中心有两份MwLog
        if (!ProcessUtil.getCurrentProcessName(this).endsWith(":bizcenter")) {
            AppLog.initConfig(this);
        }
        //启动业务中心
        if (ProcessUtil.isMainProcess(this)) {
            if (!(ClientBindProcessor.isActived() && !ClientBindProcessor.isCurrentHostMain())) {
                WakeUpBizCenter.callServerProcess(this);
                ServerConnector.getInstance().initConnection(this);
            }
        }

        ClientApplication.init(this);
        PrintApplication.init(this);

        if (ProcessUtil.isMainProcess(this) && OEM.isElo()) {//初始化elo扫码器
            ScannerManager.init(this);
        }


        //TODO:为了不阻塞测试
        if (ProcessUtil.isMainProcess(this)) {
            LogUtil.logBusiness(MwApplication.TAG, "----------------服务启动-----------");
            MwApplication.newInstance().init(this);
        }

        // 20181225 修复在华为平板无法登录问题
        Utils.init(this);
    }

    /**
     * 初始化阿里的HotFix模组
     */
    public void loadAliHotFix() {
        AliHotFix.checkAliHotFix();
    }

    public int getAppVersionCode() {
        return BuildConfig.VERSION_CODE;
    }

    public void initBugly() {
        BuglyStrategy strategy = new BuglyStrategy();
        String channel = "";
        try {
            ApplicationInfo info = this.getPackageManager().getApplicationInfo(getPackageName(),
                    PackageManager.GET_META_DATA);
            channel = info.metaData.getString("MWEE_POS_CHANNEL");
            strategy.setAppChannel(channel);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        strategy.setUploadProcess(ProcessUtil.isMainProcess(this));
        //Bugly初始化
        String metaiD = getString(R.string.meta_bugly_id);
//        Log.d("TestBugly",metaiD);
        strategy.setCrashHandleCallback(new CrashReport.CrashHandleCallback() {
            /**
             * Crash处理.
             *
             * @param crashType 错误类型：CRASHTYPE_JAVA，CRASHTYPE_NATIVE，CRASHTYPE_U3D ,CRASHTYPE_ANR
             * @param errorType 错误的类型名
             * @param errorMessage 错误的消息
             * @param errorStack 错误的堆栈
             * @return 返回额外的自定义信息上报
             */
            @Override
            public Map<String, String> onCrashHandleStart(int crashType, String errorType,
                                                          String errorMessage, String errorStack) {
                LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
                ParamvalueDBModel paramvalueDBModel = BizInfoCollect.getAccount(APPConfig.DB_CLIENT);
                if (paramvalueDBModel != null) {
                    map.put("中控账号", paramvalueDBModel.fsParamValue);
                }
                map.put("站点ID", ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
                map.put("设备序列号", DeviceStateInfoUtil.getDeviceSerial());
                map.put("门店ID", ClientMetaUtil.getSettingsValueByKey(META.SHOPID));
                map.put("cpu使用率", DeviceStateInfoUtil.provideTotalCpuPercent());
                return map;
            }

            @Override
            public byte[] onCrashHandleStart2GetExtraDatas(int crashType, String errorType, String errorMessage, String errorStack) {
                return null;
            }

        });

        Bugly.init(getApplicationContext(), metaiD, com.mwee.android.tools.LogUtil.SHOW, strategy);
    }
}
