//package com.mwee.android.pos.air.business.payment.view;
//
//import android.graphics.Bitmap;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//
//import com.google.zxing.WriterException;
//import com.mwee.android.pos.component.dialog.BaseDialogFragment;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.print.processor.BarcodeUtil;
//
///**
// * @ClassName: PaymentBindView
// * @Description: 绑定支付方式申请，二维码展示页
// * @author: SugarT
// * @date: 2017/10/14 下午5:25
// */
//public class PaymentBindView extends BaseDialogFragment {
//
//    public static final String TAG = PaymentBindView.class.getSimpleName();
//
//    private ImageView mCloseIv;
//    private ImageView mQRCodeIv;
//
//    private String originUri = "";
//
//    private View.OnClickListener click = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            if (!ButtonClickTimer.canClick()) {
//                return;
//            }
//        }
//    };
//
//    public static PaymentBindView newInstance() {
//        PaymentBindView fragment = new PaymentBindView();
//        return fragment;
//    }
//
//    public PaymentBindView setOriginUri(String originUri) {
//        this.originUri = originUri;
//        return this;
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
//            savedInstanceState) {
//        return inflater.inflate(R.layout.view_bind_payment, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        if (TextUtils.isEmpty(originUri)) {
//            dismissSelf();
//            return;
//        }
//        assignViews(view);
//        start();
//    }
//
//    private void assignViews(View convertView) {
//        mCloseIv = (ImageView) convertView.findViewById(R.id.iv_bind_payment_close);
//        mQRCodeIv = (ImageView) convertView.findViewById(R.id.iv_bind_payment_code);
//
//        mCloseIv.setOnClickListener(click);
//    }
//
//    private void start() {
//        Bitmap bmp = createQRImage(originUri, 420, 420);
//        if (bmp == null) {
//            ToastUtil.showToast("二维码生成失败");
//            return;
//        }
//        mQRCodeIv.setImageBitmap(bmp);
//    }
//
//    private Bitmap createQRImage(String str, final int width, final int height) {
//        try {
//            return BarcodeUtil.createQRImage(str, width, height);
//        } catch (Exception e) {
//            e.printStackTrace();
//        } catch (Error e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//}
