package com.mwee.android.pos.business.common.dialog;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.MainThread;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.print.api.PrintApi;
import com.mwee.android.pos.business.print.view.PrintMonitorFragment;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.print.PrintMonitorVideoStatusResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.DisplayUtil;
import com.mwee.android.tools.LogUtil;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by huangming on 2017/5/21.
 * TODO 打印异常悬浮穿业务过重，需要整理清楚修改
 */
public class PrintErrorMessageNotice {

    private static final long VIDEO_HINT_SPACE = 10 * 60 * 1000;//音频播放间隔 提示一次间隔十分钟

    private boolean mCanAudioHint = true;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private AtomicBoolean mIsAudioPlaying = new AtomicBoolean(false);
    private MediaPlayer mMediaPlayer;

    private WindowManager mWindowManager = null;
    private View view;
    public boolean isShow;
    private static PrintErrorMessageNotice mInstance;//todo 有内存泄漏

    public static PrintErrorMessageNotice getInstance() {
        if (mInstance == null) {
            synchronized (PrintErrorMessageNotice.class) {
                if (mInstance == null) {
                    mInstance = new PrintErrorMessageNotice();
                }
            }
        }
        return mInstance;
    }

    @MainThread
    public void showFloatWindow(String notify_Content) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mHandler.post(() -> show(notify_Content));
        } else {
            show(notify_Content);
        }
    }

    @MainThread
    private void show(String notify_Content) {
        if (TextUtils.isEmpty(notify_Content)) {
            return;
        }
        view = LayoutInflater.from(GlobalCache.getContext()).inflate(R.layout.layout_message_print_error_v2, null);
        initFloatView();
        WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) GlobalCache.getContext().getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (Settings.canDrawOverlays(GlobalCache.getContext())) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                } else {
                    wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                }
            } else {
                wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;
            }
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.gravity = Gravity.END | Gravity.TOP;
        wmParams.width = DisplayUtil.dp2px(GlobalCache.getContext(), 330);
        wmParams.height = DisplayUtil.dp2px(GlobalCache.getContext(), 40);
        wmParams.windowAnimations = android.R.style.Animation_Translucent;
        if (mWindowManager != null) {
            mWindowManager.addView(view, wmParams);
            isShow = true;
            updateFloatWindow(notify_Content);
        }
    }

    @MainThread
    public void updateFloatWindow(String notify_Content) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mHandler.post(() -> updateDialog(notify_Content));
        } else {
            updateDialog(notify_Content);
        }
    }

    @MainThread
    public void updateDialog(String notify_Content) {
        if (TextUtils.isEmpty(notify_Content)) {
            return;
        }
        TextView message = view.findViewById(R.id.message);
        /*String text = "";
        if (notify_Content.contains(":")) {
            String data[] = notify_Content.split(":");
            text = data[0] + "打印失败  失败原因：" + data[1];
        } else {
            text = notify_Content;
        }
        SpannableString spannableString = new SpannableString(text);
        spannableString.setSpan(new ForegroundColorSpan(0xFFFF553A), 0, text.indexOf(" "), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);*/
        message.setText(notify_Content);

        if (mCanAudioHint) {
            PrintApi.getPrintMonitorVideoHint(new SocketCallback<PrintMonitorVideoStatusResponse>() {
                @Override
                public void callback(SocketResponse<PrintMonitorVideoStatusResponse> socketResponse) {
                    if (socketResponse != null && socketResponse.code == SocketResultCode.SUCCESS) {
                        if (socketResponse.data != null) {
                            if (socketResponse.data.isVideoHintOpen) {
                                playVideoHint();
                                LogUtil.log("语音提示开关是打开状态");
                            }
                        }
                    }
                }
            });
        }
    }

    /**
     * 语音提示，提示一次间隔十分钟
     */
    private void playVideoHint() {
        if (mCanAudioHint) {
            BusinessExecutor.executeNoWait(() -> {
                play("print_error.ogg");
                return null;
            });
        }
    }

    private void play(String videoName) {
        if (mIsAudioPlaying.get()) {
            return;
        }
        mIsAudioPlaying.set(true);
        mMediaPlayer = new MediaPlayer();
        try {
            final AssetFileDescriptor afd = GlobalCache.getContext().getAssets().openFd(videoName);
            mMediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mMediaPlayer.setOnCompletionListener((mediaPlayer) -> {
                try {
                    afd.close();
                } catch (Exception e) {
                }
                mIsAudioPlaying.set(false);
                if (mMediaPlayer != null) {
                    mMediaPlayer.release();
                }
                LogUtil.log("语音提示播放完成");
            });
            mMediaPlayer.prepare();
            mMediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initFloatView() {
        ImageView message_close = view.findViewById(R.id.message_close);
        message_close.setOnClickListener((view) -> release());
        view.findViewById(R.id.message).setOnClickListener((view) -> {
            DriverBus.call("main/closesub");
            DriverBus.call("main/jump", MAIN_TAB.PRINT);
            release();
        });
    }

    private void release() {
        isShow = false;
        if (mWindowManager != null) {
            mWindowManager.removeView(view);
        }
        mWindowManager = null;

        if (mCanAudioHint) {
            mCanAudioHint = false;
            mHandler.postDelayed(() -> {
                mCanAudioHint = true;
                LogUtil.log("已过十分钟，可以语音提示");
            }, VIDEO_HINT_SPACE);
        }

        if (mMediaPlayer != null && mIsAudioPlaying.get()) {
            BusinessExecutor.executeNoWait(() -> {
                if (mMediaPlayer != null && mIsAudioPlaying.get()) {
                    mMediaPlayer.stop();
                    mMediaPlayer.release();
                    mIsAudioPlaying.set(false);
                    mMediaPlayer = null;
                }
                return null;
            });
            LogUtil.log("停止播放语音提示");
        } else {
            mMediaPlayer = null;
        }
    }

    public void setCanVideoHint(boolean canVideoHint) {
        mCanAudioHint = canVideoHint;
    }
}
