package com.mwee.android.pos.air.business.member.processor;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.air.business.member.api.MemberApi;
import com.mwee.android.pos.component.callback.ResultCallback;

/**
 * Created by qinwei on 2017/10/19.
 */

public class MemberLevelEditorProcessor {

    public void loadMemberLevelUpdate(String level_id, String name, String expense_amount, String reward_point, final ResultCallback<String> callback) {
        MemberApi.loadMemberLevelUpdate(level_id, name, expense_amount, reward_point, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 添加会员等级
     *
     * @param name
     * @param price
     * @param callback
     */
    public void loadMemberLevelAdd(String name, String price, final ResultCallback<String> callback) {
        MemberApi.loadMemberLevelAdd(name, price, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }
}
