//package com.mwee.android.pos.air.business.fastfood;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ListView;
//
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.air.business.ask.business.jump.AirNoteJump;
//import com.mwee.android.pos.air.business.fastfood.order.FastFoodTakeOrderActivity;
//import com.mwee.android.pos.air.business.fastfood.processor.FastFoodMenuItemAirProcessor;
//import com.mwee.android.pos.air.business.member.dialog.MemberBindDialogFragment;
//import com.mwee.android.pos.air.business.menu.MenuFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.HomeFragment;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.business.common.fastfood.IFastFoodMenuItemProcessor;
//import com.mwee.android.pos.business.common.fastfood.IFastFoodProcessor;
//import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
//import com.mwee.android.pos.business.fastfood.proccessor.FastFoodProcessor;
//import com.mwee.android.pos.business.localpush.NotifyToServer;
//import com.mwee.android.pos.business.member.biz.MemberProcess;
//import com.mwee.android.pos.business.member.view.MemberCheckCallBack;
//import com.mwee.android.pos.business.member.view.MemberOrderUnBindAirDialogFragment;
//import com.mwee.android.pos.business.order.view.discount.FastMultiDiscountCallBack;
//import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
//import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
//import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
//import com.mwee.android.pos.business.pay.connect.PayDinnerJump;
//import com.mwee.android.pos.business.pay.view.component.IPayCallback;
//import com.mwee.android.pos.business.permission.Permission;
//import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
//import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
//import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
//import com.mwee.android.pos.business.viceshow.ViceShowConnector;
//import com.mwee.android.pos.component.delayqueue.DelayQueue;
//import com.mwee.android.pos.component.delayqueue.IDQWorker;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
//import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
//import com.mwee.android.pos.connect.business.discount.FastFoodDoDiscountResponse;
//import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
//import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
//import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
//import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
//import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
//import com.mwee.android.pos.connect.business.fastfood.model.FastOrderModel;
//import com.mwee.android.pos.connect.business.fastfood.model.FastOrderynamicDMode;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.connect.config.SocketResultCode;
//import com.mwee.android.pos.db.MenuTerminal;
//import com.mwee.android.pos.db.business.UserDBModel;
//import com.mwee.android.pos.db.business.common.Calc;
//import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
//import com.mwee.android.pos.db.business.menu.bean.MenuItem;
//import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
//import com.mwee.android.pos.db.business.pay.RoundConfig;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.Constants;
//import com.mwee.android.pos.util.GuideUtil;
//import com.mwee.android.pos.util.ListUtil;
//import com.mwee.android.pos.util.SettingHelper;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.util.Tools;
//
//import java.lang.ref.WeakReference;
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @author qinwei
// *         Created by qinwei on 2017/11/6.
// */
//
//public class FastFoodOrderFragment extends HomeFragment implements IDriver, FastFoodOrderAdapter.OnFastFoodOrderItemClickListener, FastFoodOperationLayout.OnFastFoodOperationClickListener, IPayCallback {
//    private final static String DRIVER_TAG = "orderDishesView";
//    /**
//     * 取单code
//     */
//    private static final int CODE_TAKE_ORDER = 100;
//    private FastFoodDishCache dishCache;
//    private ListView mFastFoodOrderLsv;
//    private FastFoodOrderAdapter adapter;
//    private IFastFoodMenuItemProcessor mMenuItemProcessor;
//    private IFastFoodProcessor mFastFoodProcessor;
//    private FastFoodOperationLayout mFastDishFooterLayout;
//    private View mFastFoodOrderEmptyLabel;
//    private MenuFragment mMenuFragment;
//
//    private DelayQueue<Object> refreshDelayQueue;
//
//    private MainTitleBar mainTitleBar;
//
//    private static class DelayQueueWorker implements IDQWorker {
//        private WeakReference<FastFoodOrderFragment> reference;
//
//        public DelayQueueWorker(FastFoodOrderFragment fragment) {
//            this.reference = new WeakReference<FastFoodOrderFragment>(fragment);
//        }
//
//        @Override
//        public void work(Object o) {
//            FastFoodOrderFragment fastFoodOrderFragment = reference.get();
//            if (fastFoodOrderFragment != null) {
//                ViceShowConnector.getInstance().sendFastMsg(fastFoodOrderFragment.dishCache);
//                fastFoodOrderFragment.refreshDelayQueue.done("fastRefresh");
//            }
//        }
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_air_fast_food_order, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        initView(view);
//        initTitle(view);
//        GuideUtil.show((ViewGroup) view, GuideUtil.TYPE_NEWMENU, new GuideUtil.OnDissmissListener() {
//            @Override
//            public void onDissmiss() {
//                GuideUtil.show((ViewGroup) view, GuideUtil.TYPE_MENU_LONGCLICK);
//            }
//        });
//    }
//
//    @Override
//    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
//        super.onActivityCreated(savedInstanceState);
//        initData();
//    }
//
//    @Override
//    public void onStart() {
//        super.onStart();
//        DriverBus.registerDriver(this);
//    }
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        DriverBus.unRegisterDriver(this);
//    }
//
//    private void initView(View view) {
//        mMenuFragment = (MenuFragment) getChildFragmentManager().findFragmentById(R.id.menuLayout);
//        mFastDishFooterLayout = (FastFoodOperationLayout) view.findViewById(R.id.mFastDishFooterLayout);
//        mFastFoodOrderLsv = view.findViewById(R.id.mFastFoodOrderLsv);
//        mFastFoodOrderEmptyLabel = view.findViewById(R.id.mFastFoodOrderEmptyLabel);
//        adapter = new FastFoodOrderAdapter(this);
//        adapter.setOnFastFoodOrderItemClickListener(this);
//        mFastFoodOrderLsv.setAdapter(adapter);
//        configGua();
//
//        //计算显示总价格总数量
//        refreshDelayQueue = new DelayQueue<>("fastFoodViceShow");
//        refreshDelayQueue.setWorker(new DelayQueueWorker(FastFoodOrderFragment.this));
//        refreshDelayQueue.setDelay(500);
//        adapter.notifyDataSetChanged();
//    }
//
//    /**
//     * 配置可以挂单
//     */
//    private void configGua() {
//        adapter.isShowGua = true;
//        adapter.isShowMenuAdd = false;
//    }
//
//    /**
//     * 配置可以加菜
//     */
//    private void configMenuAdd() {
//        adapter.isShowGua = false;
//        adapter.isShowMenuAdd = true;
//    }
//
//    private void initTitle(View view) {
//        mainTitleBar = view.findViewById(R.id.orderDishesTableView);
//        mainTitleBar.setParams(getActivityWithinHost());
//    }
//
//    private void initData() {
//        mMenuItemProcessor = new FastFoodMenuItemAirProcessor(this);
//        mFastFoodProcessor = new FastFoodProcessor();
//        //初始化cache
//        dishCache = new FastFoodDishCache();
//        adapter.setDishCache(dishCache);
//        mFastDishFooterLayout.setOnFastFoodOperationClickListener(this);
//        refreshOrders();
//        loadOpenOrder();
//    }
//
//    private void loadOpenOrder() {
//        trace("执行开单", ActionLog.FF_ORDER_NEW);
//        mFastFoodProcessor.loadOpenOrder("1", new ResultCallback<StartFastFoodOrderResponse>() {
//            @Override
//            public void onSuccess(StartFastFoodOrderResponse data) {
//                trace("开单成功 orderId=" + data.fastOrderModel.orderId, ActionLog.FF_ORDER_NEW);
//                refresh(data.fastOrderModel, data.menuItems);
//                refreshOrders();
//
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                trace("开单失败 code=" + code + " msg=" + msg, ActionLog.FF_ORDER_NEW);
//                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "退出", "重试", new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        loadOpenOrder();
//                    }
//                }, new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        logout();
//                    }
//                });
//            }
//        });
//    }
//
//    public void refresh(FastOrderModel fastOrderModel, ArrayList<MenuItem> menuItems) {
//        dishCache.clean();
//        dishCache.fastOrderModel = fastOrderModel;
//        dishCache.menuItems.addAll(menuItems);
//        adapter.selectPosition = 0;
//        adapter.notifyDataSetChanged();
//        mFastDishFooterLayout.setTotalPrice("" + fastOrderModel.totalPrice);
//        if (dishCache.isBindMember()) {
//            //真实姓名和昵称都为空 取会员等级名称
//            mFastDishFooterLayout.bindMember(dishCache.fastOrderModel.memberInfoS.real_name, dishCache.fastOrderModel.memberInfoS.mobile);
//        } else {
//            mFastDishFooterLayout.unBindMember();
//        }
//        refreshOrderInfo(null);
//    }
//
//    private void refreshOrderInfo(FastOrderynamicDMode data) {
//        if (data != null) {
//            dishCache.fastOrderModel.totalPrice = data.totalAmt;
//            dishCache.fastOrderModel.discountMsg = data.CouponCutMoneyInfo;
//            dishCache.fastOrderModel.fsDiscountCutId = data.fsDiscountCutId;
//            dishCache.fastOrderModel.couponCut = data.couponCut;
//            dishCache.fastOrderModel.discountAmt = data.discountAmt;
//
//        }
//        StringBuilder builder = new StringBuilder();
//        builder.append(Calc.formatShow(dishCache.fastOrderModel.totalPrice, RoundConfig.ROUND_TOTAL));
//        if (!TextUtils.isEmpty(dishCache.fastOrderModel.discountMsg)) {
//            builder.append(" (" + dishCache.fastOrderModel.discountMsg + ")");
//        }
//        mFastDishFooterLayout.setTotalPrice(builder.toString());
//
//        /**
//         * 调用客显
//         */
//        refreshDelayQueue.addTask("fastRefresh");
//
//
//    }
//
//    @DrivenMethod(uri = DRIVER_TAG + "/clickone", UIThread = true)
//    public void clickone(MenuItem item) {
//        trace("点击菜品" + item.toString(), ActionLog.FF_MENU, item);
//        // 菜品沽清判断
//        if (item.isCategory || OrderDishesBizUtil.isOutOfStock(dishCache.tempUnitQuantity, item)) {
//            return;
//        }
//        //设置点菜单序
//        item.init(dishCache.fastOrderModel.orderSeqId, dishCache.isBindMember());
//        //菜品合并处理
//        MenuItem mergeMenuItem = OrderDishesBizUtil.findMergeMenuItem(dishCache.menuItems, item);
//        if (mergeMenuItem != null) {
//            mergeMenuItem.terminal_id = MenuTerminal.DINNER;
//            //查询到有合并到菜品则进行合并操作
//            dishCache.mergeOrderMenuItem(mergeMenuItem, item);
//            //合并后的菜品选中
//            adapter.selectPosition = adapter.modules.indexOf(mergeMenuItem);
//        } else {
//            //第0个位置选中
//            //绑定会员并设置为自动使用会员价，则给新增加菜品使用会员价
//            if (dishCache.isBindMember() && SettingHelper.isAutoUsedMemberPrice()) {
//                item.useVipPrice(AppCache.getInstance().userDBModel.fsUserId, "");
//            }
//            item.terminal_id = MenuTerminal.DINNER;
//            //添加到点菜列表
//            dishCache.addFastFoodMenuItem(item, true);
//            adapter.selectPosition = adapter.modules.size() - 1;
//        }
//        //滚动到新增菜品的位置
//        adapter.notifyDataSetChanged();
//
//        mFastFoodOrderLsv.smoothScrollToPosition(adapter.getCount() - 1);
//
//        if (mergeMenuItem != null) {
//            loadUpdateMenuItem(mergeMenuItem);
//        } else {
//            //同步数据到业务中心
//            loadAddMenuItem(item);
//        }
//    }
//
//    public void loadAddMenuItem(final MenuItem item) {
//        mMenuItemProcessor.doAddMenuItem(dishCache.getOrderId(), item, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
//            @Override
//            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "退出", "重试", new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        loadAddMenuItem(item);
//                    }
//                }, new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        logout();
//                    }
//                });
//            }
//        });
//    }
//
//    private void loadUpdateMenuItem(MenuItem menuItem) {
//        ArrayList<MenuItem> menuItems = new ArrayList<>();
//        menuItems.add(menuItem);
//        loadUpdateMenuItem(menuItems);
//    }
//
//    private void loadUpdateMenuItem(final ArrayList<MenuItem> menuItems) {
//        mMenuItemProcessor.doUpdateMenuItem(dishCache.getOrderId(), menuItems, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
//            @Override
//            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "取消", "重试", new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        loadUpdateMenuItem(menuItems);
//                    }
//                }, new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        logout();
//                    }
//                });
//            }
//        });
//    }
//
//
//    @Override
//    public void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel) {
//        trace("显示菜品改数弹框", ActionLog.FF_MENU_NUMBER);
//        ModifyQuantityUtils.showModifyQuantitySupportWeight(this, item, new CountKeyboardCallback() {
//            @Override
//            public void callback(BigDecimal originNum, BigDecimal newNum) {
//                trace("改数结果，修改前:" + originNum.toString() + ",修改后:" + newNum.toString(), ActionLog.FF_MENU_NUMBER);
//                if (newNum.compareTo(BigDecimal.ZERO) < 1 || originNum.compareTo(newNum) == 0) {
//                    return;
//                }
//                //沽清判断
//                if (OrderDishesBizUtil.isOutOfStock(dishCache.tempUnitQuantity, item, newNum)) {
//                    return;
//                }
//                item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type));
//                //重新计算价格
//                item.calcTotal(dishCache.isBindMember());
//                //更新DishCache缓存信息
//                dishCache.initSelectUnitQuantity();
//                adapter.notifyDataSetChanged();
//                DriverBus.broadcast("notifyall");
//                loadUpdateMenuItem(item);
//            }
//        });
//    }
//
//    @Override
//    public void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel) {
//        trace("已下单称重,显示称重界面", ActionLog.FF_ORDER_PAY);
//        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, dishCache.fastOrderModel.orderId, new ResultCallback<UpdateBuyNumResponse>() {
//            @Override
//            public void onSuccess(UpdateBuyNumResponse data) {
//                trace("称重修改成功:" + item.menuBiz.buyNum.toString(), ActionLog.FF_MENU_NUMBER);
//                dishCache.replaceMenuItem(item, data.menuItem);
//                adapter.notifyDataSetChanged();
//                DriverBus.call("menuview/refreshMenu");
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                trace("称重修改失败:" + msg, ActionLog.FF_MENU_NUMBER);
//                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
//                    DriverBus.call("menuview/refreshMenu");
//                } else {
//                    dismissSelf();
//                }
//            }
//        });
//    }
//
//    @Override
//    public void doDeleteMenu(MenuItem item) {
//        adapter.selectPosition = -1;
//        dishCache.removeFastFoodMenuItem(item);
//        adapter.notifyDataSetChanged();
//        loadDeleteMenu(item);
//    }
//
//    public void loadDeleteMenu(final MenuItem item) {
//        mMenuItemProcessor.doDeleteMenuItem(dishCache.getOrderId(), item.menuBiz.uniq, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
//            @Override
//            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "退出", "重试", new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        loadDeleteMenu(item);
//                    }
//                }, new DialogResponseListener() {
//                    @Override
//                    public void response() {
//                        logout();
//                    }
//                });
//            }
//        });
//    }
//
//    @Override
//    public void doRetreatDish(final MenuItem item, UserDBModel userDBModel, String msg) {
//        mMenuItemProcessor.doRetreatDish(dishCache.getOrderId(), item, msg, new ResultCallback<BactchReturnDishesForFastFoodResponse>() {
//            @Override
//            public void onSuccess(BactchReturnDishesForFastFoodResponse data) {
//                trace("退菜成功:" + item.toString(), ActionLog.FF_MENU_RETREAT);
//                //可以优化
//                dishCache.replaceAllMenuItems(data.menuItemList);
//                adapter.notifyDataSetChanged();
//                dishCache.initSelectUnitQuantity();
//                DriverBus.call("menuview/notifyone", item);
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                trace("退菜失败:" + item.toString(), ActionLog.FF_MENU_RETREAT);
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//    @Override
//    public void doChangeMenuPrice(final MenuItem item, UserDBModel userDBModel) {
//        mMenuItemProcessor.doUpdateDishPrice(dishCache.getOrderId(), item, false, new ResultCallback<OperateDishToCenterResponse>() {
//            @Override
//            public void onSuccess(OperateDishToCenterResponse data) {
//                trace("菜品改价成功：" + item.toString(), ActionLog.FF_MENU_PRICE, item);
//                item.calcTotal(dishCache.isBindMember());
//                adapter.notifyDataSetChanged();
//                DriverBus.broadcast("notifyall");
//                loadUpdateMenuItem(item);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                trace("菜品改价失败," + item.toString() + ":" + msg, ActionLog.FF_MENU_PRICE);
//            }
//        });
//    }
//
//    @Override
//    public void doChangeOrderedMenuPrice(final MenuItem menuItem, UserDBModel userDBModel) {
//        mMenuItemProcessor.doUpdateDishPrice(dishCache.getOrderId(), menuItem, true, new ResultCallback<OperateDishToCenterResponse>() {
//            @Override
//            public void onSuccess(OperateDishToCenterResponse data) {
//                trace("菜品改价成功：" + menuItem.toString(), ActionLog.FF_MENU_PRICE, menuItem);
//                //替换server处理后的菜品信息
//                dishCache.replaceMenuItem(menuItem, data.menuItem);
//                adapter.notifyDataSetChanged();
//                DriverBus.broadcast("notifyall");
//                //刷新订单相关信息
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                trace("菜品改价失败," + menuItem.toString() + ":" + msg, ActionLog.FF_MENU_PRICE);
//                dismissSelf();
//            }
//        });
//    }
//
//    @Override
//    public void doOrderCommit(String mealNumber) {
//        trace("下单操作", ActionLog.FF_ORDER_COMMIT, dishCache.fastOrderModel);
//        dishCache.fastOrderModel.mealNumber = mealNumber;
//        final Progress progress = ProgressManager.showProgressUncancel(this, "下单中...");
//        mFastFoodProcessor.loadOrderToCenter(dishCache.fastOrderModel.orderId, dishCache.getFastFoodNotOrderMenuItems(), dishCache.fastOrderModel.mealNumber, new ResultCallback<OnlyOrderMenuItemsResponse>() {
//            @Override
//            public void onSuccess(OnlyOrderMenuItemsResponse data) {
//                progress.dismiss();
//                mMenuFragment.refreshMenuItems();
//                ToastUtil.showToast("挂单成功");
//                if (data.fastOrderModel != null) {
//                    trace("下单成功,重新开单", ActionLog.FF_ORDER_COMMIT, data);
//                    configGua();
//                    refresh(data.fastOrderModel, (ArrayList<MenuItem>) data.menuItemList);
//                } else {
//                    trace("下单成功,关闭当前点单界面", ActionLog.FF_ORDER_COMMIT, data);
////                    dismissSelf();
//                }
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                trace("下单失败:" + msg, ActionLog.FF_ORDER_COMMIT);
//                progress.dismiss();
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//    @Override
//    public void doMenuAddCancel() {
////        取消加菜就是1.清空未下单的菜品2.重新开个空单3.修改成挂单模式
//        trace("取消加菜", ActionLog.FF_ORDER_CANCEL_GUA);
//        configGua();
//        clearOrderMenuItems();
//        loadOpenOrder();
//    }
//
//    @Override
//    public void doMenuAddCommit() {
//        trace("挂单", ActionLog.FF_ORDER_DO_GUA);
//        doOrderCommit(dishCache.fastOrderModel.mealNumber);
//    }
//
//    @Override
//    public void doShowEmptyView() {
//        mFastFoodOrderLsv.setVisibility(View.GONE);
//        mFastFoodOrderEmptyLabel.setVisibility(View.VISIBLE);
//    }
//
//    @Override
//    public void doShowOrderContent() {
//        mFastFoodOrderLsv.setVisibility(View.VISIBLE);
//        mFastFoodOrderEmptyLabel.setVisibility(View.GONE);
//    }
//
//    @Override
//    public void doChangeMenuName(final MenuItem menuItem, UserDBModel userDBModel) {
//        mMenuItemProcessor.doUpdateMenuName(menuItem, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                menuItem.name = data;
//                menuItem.name2 = data;
//                adapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                dismissSelf();
//            }
//        });
//    }
//
//    @Override
//    public void onOrderCheckClick() {
//        trace("点击结帐", ActionLog.USER_ACTION_TRACE);
//        if (!mFastFoodProcessor.checkOrder(dishCache)) {
//            return;
//        }
//        loadMenuItemsInsertToSellDB(false);
//    }
//
//
//    @Override
//    public void onMenuItemRequestClick() {
//        final MenuItem menuItem = adapter.getSelectMenuItem();
//        if (menuItem == null) {
//            ToastUtil.showToast(R.string.please_choice_menuitem);
//            return;
//        }
//        if (dishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
//            ToastUtil.showToast("已下单菜品不可修改要求");
//            return;
//        }
//        AirNoteJump.showNote(getActivityWithinHost(), menuItem, new NoteCallback() {
//            @Override
//            public void callBack(List<NoteItemModel> selectedInfo) {
//                trace("选择要求回调：", ActionLog.FF_MENU_REQUEST, selectedInfo);
//                menuItem.menuBiz.selectNote = selectedInfo;
//                menuItem.buildNotesString();
//                menuItem.calcTotal(dishCache.isBindMember());
//                adapter.notifyDataSetChanged();
//                DriverBus.broadcast("notifyone", menuItem);
//                loadUpdateMenuItem(menuItem);
//            }
//        });
//    }
//
//    @Override
//    public void onOperationDiscountClick() {
//        if (ListUtil.isEmpty(dishCache.menuItems)) {
//            ToastUtil.showToast("请先添加菜品");
//            return;
//        }
//        mMenuItemProcessor.doMenuItemsDiscount(dishCache, new FastMultiDiscountCallBack() {
//            @Override
//            public void call(FastOrderynamicDMode fastOrder, List<MenuItem> menuItemList) {
//                trace("菜品批量优惠成功", ActionLog.FF_BATCH_DISCOUNT);
//                dishCache.replaceAllMenuItems(menuItemList);
//                adapter.notifyDataSetChanged();
//                refreshOrderInfo(fastOrder);
//            }
//        });
//    }
//
//    @Override
//    public void onOperationGetOrderClick() {
//        if (mFastDishFooterLayout.getOrderNumber() <= 0) {
//            ToastUtil.showToast("请先挂单");
//            return;
//        }
//        if (!ListUtil.isEmpty(dishCache.getFastFoodNotOrderMenuItems())) {
//            DialogManager.showExecuteDialog(getActivityWithinHost(), "你有菜品未下单，确定清空退出吗？", "取消", "确定", new DialogResponseListener() {
//                @Override
//                public void response() {
//                    clearOrderMenuItems();
//                    goTakeOrder();
//                }
//            }, null);
//        } else {
//            goTakeOrder();
//        }
//    }
//
//    private void clearOrderMenuItems() {
//        trace("点击清台", ActionLog.USER_ACTION_TRACE);
//        //重新计算点菜数量相关缓存
//        mMenuItemProcessor.doClearOrderMenuItems(dishCache.fastOrderModel.orderId, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
//            @Override
//            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
//                trace("成功删除未下单的菜", ActionLog.USER_ACTION_TRACE);
//                mFastFoodProcessor.clearNewMenuItemList(dishCache);
//                adapter.notifyDataSetChanged();
//                refreshOrderInfo(data.fastOrderynamicDMode);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                // FIXME: 2017/11/13 清空为下单的菜失败处理
//                trace("删除未下单的菜失败,code=" + code + ",msg=" + msg, ActionLog.USER_ACTION_TRACE);
//            }
//        });
//    }
//
//    private void goTakeOrder() {
//        Intent intent = new Intent(getContext(), FastFoodTakeOrderActivity.class);
//        startActivityForResult(intent, CODE_TAKE_ORDER);
//    }
//
//    @Override
//    public void onOperationMemberBindClick() {
//        //已经绑定过会员
//        if (dishCache.isBindMember()) {
//            showMemberInfo();
//        } else {
//            //尚未绑定会员
//            PermissionsUtil.requestPermissionCommon(this, AppCache.getInstance().userDBModel, Permission.DINNER_vVIPBind, new PermissionCallback() {
//                @Override
//                public void onCall(int errCode, String msg, UserDBModel userDBModel) {
//                    MemberBindDialogFragment fragment = new MemberBindDialogFragment();
//                    fragment.setBindOrderId(dishCache.fastOrderModel.orderId);
//                    fragment.setOnBindOrderListener(memberCheckCallBack);
//                    DialogManager.showCustomDialog(FastFoodOrderFragment.this, fragment, "MemberBindDialogFragment");
//                }
//            });
//        }
//    }
//
//    /**
//     * 显示关联会员信息
//     */
//    private void showMemberInfo() {
//        Progress progress = ProgressManager.showProgressUncancel(this);
//        new MemberProcess().onlyLoadMemberInfo(dishCache.fastOrderModel.memberInfoS.card_no, new IResponse<QueryMemberInfoResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse info) {
//                progress.dismissSelf();
//                if (result) {
//                    dishCache.fastOrderModel.memberInfoS.score = info.memberCardModel.card_data.score;
//                    dishCache.fastOrderModel.memberInfoS.balance = info.memberCardModel.card_data.amount;
//                }
//                MemberOrderUnBindAirDialogFragment fragment = MemberOrderUnBindAirDialogFragment.getInstance(dishCache.fastOrderModel.memberInfoS, result);
//                fragment.setParam(new MemberOrderUnBindAirDialogFragment.OnMemberInfoListener() {
//                    @Override
//                    public void onUnbindMember() {
//                        doUnbindMember();
//                    }
//                });
//                DialogManager.showCustomDialog(FastFoodOrderFragment.this, fragment, "");
//            }
//        });
//    }
//
//    private void doUnbindMember() {
//        final Progress progress = ProgressManager.showProgressUncancel(this, "解绑中");
//        mFastFoodProcessor.unBindMemberInfoFromOrder(dishCache.getOrderId(), dishCache.fastOrderModel.memberInfoS.card_no, new ResultCallback<ChangeOrderWithMemberResponse>() {
//            @Override
//            public void onSuccess(ChangeOrderWithMemberResponse data) {
//                trace("快餐点单界面->会员解绑", ActionLog.FF_ORDER_MEMBER, "");
//                dishCache.fastOrderModel.clearMember();
//                dishCache.replaceAllMenuItems(data.menuItemList);
//                adapter.notifyDataSetChanged();
//                mFastDishFooterLayout.unBindMember();
//                refreshOrderInfo(data.fastOrderynamicDMode);
//                progress.dismiss();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                progress.dismiss();
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//    private MemberCheckCallBack memberCheckCallBack = new MemberCheckCallBack() {
//        @Override
//        public void call(final QueryMemberInfoAndBindToOrderResponse member) {
//            trace("账单绑定会员成功 会员卡号为:" + member.memberCardModel.card_info.card_no, ActionLog.USER_ACTION_TRACE, "");
//            ToastUtil.showToast(R.string.mMemberBindSuccess);
//            dishCache.fastOrderModel.setMember(member.memberCardModel);
//            dishCache.menuItems.clear();
//            dishCache.menuItems.addAll(member.menuItemList);
//            mFastDishFooterLayout.bindMember(dishCache.fastOrderModel.memberInfoS.real_name, dishCache.fastOrderModel.memberInfoS.mobile);
//            dishCache.replaceAllMenuItems(member.menuItemList);
//            adapter.notifyDataSetChanged();
//            refreshOrderInfo(member.fastOrderynamicDMode);
//        }
//    };
//
//    /**
//     * 结帐前将未下单的菜品入库
//     *
//     * @param isOnlinePay
//     */
//    public void loadMenuItemsInsertToSellDB(final boolean isOnlinePay) {
//        ArrayList<MenuItem> menuItems = dishCache.getFastFoodNotOrderMenuItems();
//        if (ListUtil.isEmpty(menuItems)) {
//            goPayDinnerFragment(isOnlinePay);
//        } else {
//            final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
//            mFastFoodProcessor.loadMenuItemsInsertToSellDB(dishCache.fastOrderModel.orderId, menuItems, dishCache.fastOrderModel.mealNumber, new ResultCallback<OnlyOrderMenuItemsResponse>() {
//                @Override
//                public void onSuccess(OnlyOrderMenuItemsResponse data) {
//                    progress.dismiss();
//                    goPayDinnerFragment(isOnlinePay);
//                }
//
//                @Override
//                public void onFailure(int code, String msg) {
//                    progress.dismiss();
//                    ToastUtil.showToast(msg);
//                }
//            });
//        }
//
//    }
//
//    /**
//     * 跳转收银界面
//     *
//     * @param isOnlinePay true代表手机支付，false 跳转到收银界面
//     */
//    public void goPayDinnerFragment(boolean isOnlinePay) {
//        if (isOnlinePay) {
//            trace("显示手机支付", ActionLog.FF_ORDER_MOBILE_PAY);
//            if (dishCache.fastOrderModel.totalPrice.compareTo(BigDecimal.ZERO) == 0) {
//                ToastUtil.showToast("待支付金额为0");
//                return;
//            }
//            if (dishCache.antiPay) {
//                PayDinnerJump.jumpToOnlineRePayForFastFood(this, dishCache.fastOrderModel.orderId, R.id.main_menufragment, this);
//            } else {
//                PayDinnerJump.jumpToOnlinePayForFastFood(this, dishCache.fastOrderModel.orderId, R.id.main_menufragment, this);
//            }
//        } else {
//            trace("跳转结帐界面", ActionLog.FF_ORDER_PAY);
//            if (dishCache.antiPay) {
//                PayDinnerJump.jumpToRePay(getActivityWithinHost(), dishCache.fastOrderModel.orderId, R.id.main_menufragment, this);
//            } else {
//                PayDinnerJump.jumpToPayForFastFood(getActivityWithinHost(), dishCache.fastOrderModel.orderId, R.id.main_menufragment, false, this);
//            }
//        }
//    }
//
//    @Override
//    public String getModuleName() {
//        return DRIVER_TAG;
//    }
//
//    @Override
//    public void payFinish(int result) {
//        if (result == IPayCallback.FINISH) {
//            configGua();
//            loadOpenOrder();
//            //结账完成 需要清除客显
//            ViceShowConnector.getInstance().clearOrderInfo();
//        }
//    }
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == Activity.RESULT_OK) {
//            if (requestCode == CODE_TAKE_ORDER) {
//                configMenuAdd();
//                FastOrderModel orderModel = (FastOrderModel) data.getSerializableExtra(Constants.FAST_ORDER_INFO);
//                ArrayList<MenuItem> menuItems = (ArrayList<MenuItem>) data.getSerializableExtra(Constants.FAST_ORDER_MENUS);
//                refresh(orderModel, menuItems);
//            }
//        } else {
//            if (requestCode == CODE_TAKE_ORDER) {
//                //取单界面点击返回 重新开单（解决点菜token失效问题）
//                configGua();
//                loadOpenOrder();
//            }
//        }
//    }
//
//    private void trace(String msg, String action) {
//        trace(msg, action, "");
//    }
//
//    private void trace(String msg, String action, Object arg0) {
//        ActionLog.addLog("快餐点单界面->" + msg, dishCache.getOrderId(), dishCache.fastOrderModel.mealNumber, action, arg0);
//    }
//
//
//    @DrivenMethod(uri = DRIVER_TAG + "/refreshTablesFromBiz", UIThread = true)
//    public void refreshOrders() {
//        trace("收到订单变化通知 刷新可取单数量", ActionLog.FF_ORDER_REFRESH);
//        mFastFoodProcessor.loadAllFastFoodOrder("1", new ResultCallback<List<FastFoodSimpInfo>>() {
//            @Override
//            public void onSuccess(List<FastFoodSimpInfo> data) {
//                trace("可取单数量" + data.size(), ActionLog.FF_ORDER_REFRESH);
//                int orderNum = data.size();
//                for (int i = 0; i < data.size(); i++) {
//                    if (TextUtils.equals(data.get(i).order_id, dishCache.getOrderId())) {
//                        orderNum--;
//                        break;
//                    }
//                }
//                mFastDishFooterLayout.setOrderNumber(orderNum);
//            }
//        });
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mainTitleBar.callDestroy();
//        refreshDelayQueue.callDestroy();
//        NotifyToServer.unlockOrderByHost(AppCache.getInstance().currentHostId);
//        ViceShowConnector.getInstance().clearOrderInfo();
//    }
//
//    @DrivenMethod(uri = DRIVER_TAG + "/repay", UIThread = true)
//    public void repay(FastFoodDishCache dishCache) {
//        //反结账
//        refresh(dishCache.fastOrderModel, dishCache.menuItems);
//    }
//
//    @DrivenMethod(uri = DRIVER_TAG + "/updateMealNumber", UIThread = true)
//    public void updateMealNumber(String mealNumber) {
//        dishCache.fastOrderModel.mealNumber = mealNumber;
//    }
//
//    /**
//     * 网络监听
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/isConnectNetWork", UIThread = true)
//    public void isConnectNetWork(boolean isConnectNetWork) {
//        if (mainTitleBar != null) {
//            mainTitleBar.setNetDisconnectLaout(isConnectNetWork);
//        }
//    }
//
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        if (mainTitleBar != null) {
//            mainTitleBar.setNetDisconnectLaout(AppCache.getInstance().isConnectNetWork);
//        }
//        refreshOrders();
//    }
//
//
//    private void logout() {
//        DriverBus.call(Constants.DRIVER_TAG_LOGOUT);
//    }
//
//}
