package com.mwee.android.pos.business.common.dialog;

import android.support.v4.util.ArrayMap;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseSectionListFragment;
import com.mwee.android.pos.business.common.entity.SectionData;
import com.mwee.android.pos.business.orderdishes.view.widget.OrderDishesCustomRequestView;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by qinwei on 2017/7/15.
 */

public class MenuPackageItemRequestFragment extends BaseSectionListFragment<NoteModel, NoteItemModel> {
    private OrderDishesCustomRequestView mMenuPackageItemCustomRequestView;//自定要求操作view
    private List<NoteItemModel> systemCustomRequests = new ArrayList<>();//自定义要求
    private LinkedHashMap<String, NoteItemModel> selectedInfo = new LinkedHashMap<>();//保存选择的要求信息
    private OnMenuPackageItemRequestListener listener;
    private List<NoteModel> noteModels;
    private View mRequestEmptyLayout;
    //    private SparseIntArray selectCustomRequest = new SparseIntArray();
    private ArrayMap<String, Integer> selectCustomRequest = new ArrayMap<>();

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_menu_package_item_request;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mRequestEmptyLayout = view.findViewById(R.id.mRequestEmptyLayout);
        mMenuPackageItemCustomRequestView = (OrderDishesCustomRequestView) view.findViewById(R.id.mMenuPackageItemCustomRequestView);
        mMenuPackageItemCustomRequestView.setParams(systemCustomRequests, selectCustomRequest, new OrderDishesCustomRequestView.Callback() {
            @Override
            public void onClickRequestItem(NoteItemModel menuExtraItem) {
                dataChanged();
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        if (!ListUtil.isEmpty(noteModels)) {//数据回显
            for (int i = 0; i < noteModels.size(); i++) {
                NoteModel noteModel = noteModels.get(i);
                modules.add(new SectionData<NoteModel, NoteItemModel>(noteModel, i));
                for (int k = 0; k < noteModel.itemList.size(); k++) {
                    NoteItemModel itemModel = noteModel.itemList.get(k);
                    if (selectedInfo.containsKey(itemModel.id)) {
                        itemModel.selected = true;
                    }
                    modules.add(new SectionData<NoteModel, NoteItemModel>(itemModel));
                }
            }
            adapter.notifyDataSetChanged();
            mRequestEmptyLayout.setVisibility(View.GONE);
        } else {
            mRequestEmptyLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return getGridLayoutManager(4);
    }

    @Override
    protected BaseViewHolder onCreateSectionHeaderView(ViewGroup parent) {
        return new SectionHeaderHolder(LayoutInflater.from(getContext()).inflate(R.layout.layout_menu_package_item_request_header, parent, false));
    }

    @Override
    protected BaseViewHolder onCreateSectionItemView(ViewGroup parent, int viewType) {
        return new SectionItemHolder(LayoutInflater.from(getContext()).inflate(R.layout.layout_menu_package_item_request_item, parent, false));
    }

    private void dataChanged() {
        List<NoteItemModel> selectList = new ArrayList<>();
        Iterator<Map.Entry<String, NoteItemModel>> ite = selectedInfo.entrySet().iterator();
        while (ite.hasNext()) {
            selectList.add(ite.next().getValue());
        }
        for (NoteItemModel item : systemCustomRequests) {
            if (selectCustomRequest.get(item.id) != null && selectCustomRequest.get(item.id) > 0) {
                item = item.clone();
                item.selected = true;
                item.num = BigDecimal.ONE;
                item.calcTotal();
                selectList.add(item);

            }
        }
        listener.onMenuPackageItemRequestDataChanged(selectList);
        adapter.notifyDataSetChanged();
    }

    public void hideSoftInput() {
        mMenuPackageItemCustomRequestView.hideSoftInput();
    }

    /**
     * @param noteModels     所有要求
     * @param noteItemModels 选中要求
     * @param listener
     */
    public void setParam(List<NoteItemModel> systemCustomRequests, List<NoteModel> noteModels, List<NoteItemModel> noteItemModels, OnMenuPackageItemRequestListener listener) {
        this.systemCustomRequests.addAll(systemCustomRequests);
        this.listener = listener;
        this.noteModels = noteModels;
        if (!ListUtil.isEmpty(noteItemModels)) {
            for (int i = 0; i < noteItemModels.size(); i++) {
                NoteItemModel noteItemModel = noteItemModels.get(i);
                if (!containsNote(this.systemCustomRequests, noteItemModel)) {
                    this.systemCustomRequests.add(noteItemModel);
                }
                if (StringUtil.toInt(noteItemModel.id, 0) < 0) {
                    selectCustomRequest.put(noteItemModel.id, 1);
                } else {
                    selectedInfo.put(noteItemModel.id, noteItemModel);
                }
            }
        }
        if (mMenuPackageItemCustomRequestView != null) {
            mMenuPackageItemCustomRequestView.refreshAdapter();
        }
    }

    private boolean containsNote(List<NoteItemModel> list, NoteItemModel item) {
        if (ListUtil.isEmpty(list) || item == null) {
            return false;
        }
        for (NoteItemModel noteItem : list) {
            if (noteItem == null) {
                continue;
            }
            if (TextUtils.equals(noteItem.id, item.id)) {
                return true;
            }
        }
        return false;
    }

    public interface OnMenuPackageItemRequestListener {
        void onMenuPackageItemRequestDataChanged(List<NoteItemModel> noteItemModels);
    }

    class SectionHeaderHolder extends BaseViewHolder {
        private TextView mRequestGroupItemNameLabel;

        public SectionHeaderHolder(View v) {
            super(v);
            mRequestGroupItemNameLabel = (TextView) v.findViewById(R.id.mRequestGroupItemNameLabel);
        }

        @Override
        public void bindData(int position) {
            NoteModel header = modules.get(position).header;
            mRequestGroupItemNameLabel.setText(header.name);
        }
    }

    class SectionItemHolder extends BaseViewHolder implements View.OnClickListener {
        private TextView mRequestItemNoteNameLabel;
        private TextView mRequestItemNotePriceLabel;
        private NoteItemModel item;

        public SectionItemHolder(View v) {
            super(v);
            mRequestItemNoteNameLabel = (TextView) v.findViewById(R.id.mRequestItemNoteNameLabel);
            mRequestItemNotePriceLabel = (TextView) v.findViewById(R.id.mRequestItemNotePriceLabel);
        }

        @Override
        public void bindData(int position) {
            item = modules.get(position).t;
            mRequestItemNoteNameLabel.setText(item.name);
            if (item.selected) {
                mRequestItemNotePriceLabel.setVisibility(View.VISIBLE);
                mRequestItemNotePriceLabel.setText(Calc.formatShow(item.price, RoundConfig.ROUND_SINGLE_PRICE));
            } else {
                mRequestItemNotePriceLabel.setVisibility(View.INVISIBLE);
            }
            mRequestItemNoteNameLabel.setSelected(item.selected);
            mRequestItemNoteNameLabel.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (v.isSelected()) {
                if (item.num.compareTo(BigDecimal.ZERO) > 0) {
                    item.num = item.num.subtract(BigDecimal.ONE);
                    item.selected = true;
                    item.calcTotal();
                    selectedInfo.put(item.id, item);
                }
                if (item.num.compareTo(BigDecimal.ZERO) <= 0) {
                    item.num = BigDecimal.ZERO;
                    item.selected = false;
                    selectedInfo.remove(item.id);
                }
            } else {
                item.num = item.num.add(BigDecimal.ONE);
                item.calcTotal();
                if (item.num.compareTo(BigDecimal.ZERO) > 0) {
                    selectedInfo.put(item.id, item);
                    item.selected = true;
                } else {
                    item.selected = false;
                    selectedInfo.remove(item.id);
                }
            }
            dataChanged();
        }
    }
}
