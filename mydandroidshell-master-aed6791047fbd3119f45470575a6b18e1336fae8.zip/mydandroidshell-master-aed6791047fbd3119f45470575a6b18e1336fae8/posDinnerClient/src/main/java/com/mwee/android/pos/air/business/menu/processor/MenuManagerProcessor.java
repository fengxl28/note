package com.mwee.android.pos.air.business.menu.processor;

import android.text.TextUtils;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.menu.api.MenuManagerApi;
import com.mwee.android.pos.air.db.DTOMenuItemDBController;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.db.ClientMenuDBUtil;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.menu.DishesUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */
public class MenuManagerProcessor {


    public void loadMenuManagerIndexData(boolean isLoadAllMenu, final ResultCallback<AllMenuClsAndMenuItemResponse> callback) {
        loadMenuManagerIndexData(isLoadAllMenu, callback, true);

    }

    public void loadMenuManagerIndexData(boolean isLoadAllMenu, final ResultCallback<AllMenuClsAndMenuItemResponse> callback, boolean hasAllCls) {
        MenuManagerApi.loadMenuManagerIndexData(isLoadAllMenu, new SocketCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void callback(SocketResponse<AllMenuClsAndMenuItemResponse> response) {
                if (response.success()) {
                    if (hasAllCls) {
                        buildTopMenu(response.data.menuClsBeanList);
                    }
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadBatchDelete(ArrayList<String> choiceStates, final ResultCallback<String> callback) {
        MenuManagerApi.loadBatchDeleteMenuItems(choiceStates, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    /**
     * 构建全部虚拟分类
     *
     * @param menuClsBeanList
     */
    private void buildTopMenu(List<MenuClsBean> menuClsBeanList) {
        MenuClsBean menuClsBean = new MenuClsBean();
        menuClsBean.fsMenuClsName = "全部菜品";
        menuClsBean.fsMenuClsId = "-1localAll";
        if (ListUtil.isEmpty(menuClsBeanList)) {
            menuClsBeanList = new ArrayList<>();
        }
        menuClsBeanList.add(0, menuClsBean);
    }

    public void loadMenuItemsByClsId(String fsMenuClsId, final ResultCallback<List<MenuItemBean>> callback) {
        MenuManagerApi.loadMenuItemsByClsId(fsMenuClsId, new SocketCallback<MenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<MenuItemsResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data.menuItemBeanList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }


    public void refreshMenuItem(MenuItem data, MenuItemBean bean) {
        if (!TextUtils.equals(data.categoryCode, bean.fsMenuClsId)) {
            MenuTypeBean oldType = null;
            MenuTypeBean newType = null;
            for (int i = 1; i < AppCache.getInstance().firstNodeMap.size(); i++) {
                MenuTypeBean type = AppCache.getInstance().firstNodeMap.get(i);
                if (TextUtils.equals(data.categoryCode, type.fsMenuClsId)) {
                    oldType = type;
                }
                if (TextUtils.equals(bean.fsMenuClsId, type.fsMenuClsId)) {
                    newType = type;
                }
            }
            if (oldType != null && newType != null && oldType != newType) {
                //旧分类移除，新分类添加
                oldType.menuList.remove(data);
                newType.menuList.add(data);
            }
        }
        //同步菜品信息
        sync(data, bean);
    }

    public void sync(MenuItem data, MenuItemBean bean) {
        data.name = bean.fsItemName;
        data.name2 = bean.fsItemName;
        MenuitemDBModel tempMenu = buildMenuitemDBModel(data, bean);
        data.config = 0;
        DishesUtil.buildMenuConfig(data, tempMenu, ClientMenuDBUtil.getMenuProcedureSize(tempMenu.fiItemCd)
                , ClientMenuDBUtil.getMenuUnitSize(tempMenu.fiItemCd)
                , ClientMenuDBUtil.optIngredientGPCount(tempMenu.fiItemCd));

        data.currentUnit.fdInvQty = bean.fdInvQty;
        data.currentUnit.fdSalePrice = bean.fdSalePrice;
        data.currentUnit.fdVIPPrice = bean.fdVIPPrice;
        data.currentUnit.fdInvQty = bean.fdInvQty;
        data.currentUnit.fsOrderUint = bean.fsOrderUint;
        data.categoryCode = bean.fsMenuClsId;
        data.fsHelpCode = bean.fsHelpCode;
        DTOMenuItemDBController.update(bean);

    }


    /**
     * 构建临时的菜品数据 赋值折扣 赠送 时价 称重 外卖 打印属性
     * 用来重置 config
     *
     * @param data
     * @param bean
     * @return
     */
    private MenuitemDBModel buildMenuitemDBModel(MenuItem data, MenuItemBean bean) {


        MenuitemDBModel dbModel = new MenuitemDBModel();
        //dbModel.fiItemCd = 0;
        //dbModel.fsItemId = DBPrimaryKeyUtil.optPrimaryKey();
        dbModel.fsItemName = data.name;
        //dbModel.fsHelpCode = HelpCodeUtil.createHelpCode(name);
        dbModel.fsItemName2 = "";
        //dbModel.fsMenuClsId = fsMenuClsId;
        dbModel.fiIsEditPrice = 0;

        //属性
        dbModel.fiIsDiscount = bean.fiIsDiscount;
        dbModel.fiIsGift = bean.fiIsGift;
        dbModel.fiIsEditPrice = bean.fiIsEditPrice;
        dbModel.fiIsEditQty = bean.fiIsEditQty;
        dbModel.fiIsTakeAway = bean.fiIsTakeAway;
        dbModel.fiIsPrn = bean.fiIsPrn;

        dbModel.fiIsServiceFee = 0;
        dbModel.fsDeptId = "";
        dbModel.fiIsSet = 0;
        dbModel.fiIsSetDtlPrn = 1;
        dbModel.fiIsOut = 0;
        dbModel.fiIsNew = 0;
        dbModel.fiIsSpecialty = 0;
        dbModel.fiIsCuisine = 0;

        dbModel.fiIsBonus = 0;
        dbModel.fiItemKind = 1;
        dbModel.fsItemDesc = "";
        dbModel.fiImgWidth = 0;
        dbModel.fiImgHeight = 0;
        dbModel.fsImageURL = "";
        dbModel.fsImagePath = "0";
        dbModel.fsNote = "";
        //dbModel.fiSortOrder = generateSortOrder();
        dbModel.fsColor = "0";
        dbModel.fiIsHot = 0;
        dbModel.fiStatus = 1;
        dbModel.fsCreateTime = DateUtil.getCurrentTime();
        dbModel.fsCreateUserId = "admin";
        dbModel.fsCreateUserName = "管理员";
        dbModel.fsUpdateTime = DateUtil.getCurrentTime();
        dbModel.fsUpdateUserId = "admin";
        dbModel.fsUpdateUserName = "管理员";
        //dbModel.fsShopGUID = shopId;
        dbModel.fiIsMulDept = 1;
        dbModel.fiItemSetCalc = 0;
        dbModel.fiIsEffectiveDate = 0;
        dbModel.fsStarDate = "";
        dbModel.fsEndDate = "";
        dbModel.fiMax = 0;
        dbModel.fiDataSource = 1;
        dbModel.sync = 1;


        return dbModel;

    }

    public void refreshMenuItem(MenuItem menuItem) {
        MenuTypeBean bean = null;
        for (int i = 1; i < AppCache.getInstance().firstNodeMap.size(); i++) {
            MenuTypeBean type = AppCache.getInstance().firstNodeMap.get(i);
            if (TextUtils.equals(menuItem.categoryCode, type.fsMenuClsId)) {
                bean = type;
                break;
            }
        }
        bean.menuList.add(menuItem);
    }

    public void loadMenuItemToTop(String itemId, final ResultCallback<String> callback) {
        MenuManagerApi.loadMenuItemToTop(itemId, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    /**
     * 是否是真实分类
     *
     * @param fsMenuClsId 分类id
     * @return
     */
    public boolean isNormalMenuCls(String fsMenuClsId) {
        if (TextUtils.isEmpty(fsMenuClsId) || TextUtils.equals("-1localAll", fsMenuClsId)) {
            //全部
            return false;
        }
        if (TextUtils.equals("" + ClientMenuDBUtil.SYSTEM_CLSID_NEW, fsMenuClsId)) {
            //新菜
            return false;
        }
        if (TextUtils.equals("" + ClientMenuDBUtil.SYSTEM_CLSID_SPECAIL, fsMenuClsId)) {
            //招牌菜
            return false;
        }
        return true;
    }

    /**
     * 是否显示置顶选项，条件：前一个元素为真实分类才显示
     *
     * @param fsMenuClsId
     * @return
     */
    public boolean isShowTop(String fsMenuClsId) {
        if (isNormalMenuCls(fsMenuClsId)) {
            return true;
        }
        return false;
    }

    /**
     * 获取非真实分类数量
     *
     * @param menuTypeList
     * @return
     */
    public int getNotNormalMenuNum(List<MenuTypeBean> menuTypeList) {
        int tempNum = 0;
        for (MenuTypeBean menuTypeBean : menuTypeList) {
            if (!isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
                tempNum++;
            }
        }
        return tempNum;
    }

}
