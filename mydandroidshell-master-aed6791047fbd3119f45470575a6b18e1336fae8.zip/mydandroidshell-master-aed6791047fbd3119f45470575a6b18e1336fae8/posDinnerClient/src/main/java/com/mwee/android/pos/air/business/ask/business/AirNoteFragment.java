package com.mwee.android.pos.air.business.ask.business;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.air.business.ask.business.adapter.AirNoteAdapter;
import com.mwee.android.pos.air.business.ask.manager.dialog.AskEditorDialogFragment;
import com.mwee.android.pos.air.business.ask.manager.dialog.AskGroupEditorDialog;
import com.mwee.android.pos.air.business.ask.manager.processor.AskProcessor;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.gridcategory.CategoryGridHeadersGridView;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * NoteFragment
 * Created by virgil on 16/7/27.
 * 单个菜品要求页
 */
public class AirNoteFragment extends BaseDialogFragment implements AdapterView.OnItemClickListener,
        CategoryGridHeadersGridView.OnHeaderClickListener, CategoryGridHeadersGridView.OnHeaderLongClickListener, AirNoteAdapter.OnNoteItemClickListener {

    public static final String TAG = AirNoteFragment.class.getSimpleName();
    private static final String KEY_LIST_POSITION = "key_list_position";

    private List<NoteModel> askGroupList = new ArrayList<>();
    private List<NoteItemModel> askList = new ArrayList<>();
    private NoteCallback callback;

    private AskProcessor mAskProcessor;

    /**
     * The serialization (saved instance state) Bundle key representing the
     * activated item position. Only used on tablets.
     */
    private static final String STATE_ACTIVATED_POSITION = "activated_position";
    /**
     * The current activated item position. Only used on tablets.
     */
    private int mActivatedPosition = ListView.INVALID_POSITION;
    /**
     * The fragment's current callback object, which is notified of list item
     * clicks.
     */

    private int mFirstVisible;
    private MenuItem item;

    private CategoryGridHeadersGridView request_item_list;
    private AirNoteAdapter adapterl;

    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.request_confirm:
                    if (callback != null) {
                        List<NoteItemModel> selecList = filterSelectedNoteItem();
                        callback.callBack(selecList);
                        dismiss();
                    }
                    break;
                case R.id.request_cancel:
                case R.id.air_note_title_back_tv:
                    dismiss();
                    break;
                case R.id.request_clean:
                    cleanSelectedNoteItem();
                    break;
                case R.id.add_note_gp_tv:
                    // 新增要求组
                    showAskGroupEditorDialog();
                    break;
                default:
                    break;
            }
        }
    };

    public void setNoteCallback(NoteCallback callback) {
        this.callback = callback;
    }

    public void setMenuItem(MenuItem menuItem) {
        this.item = menuItem;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        setCancelable(true);
        isCloseKeyboard = true;
        View view = inflater.inflate(R.layout.air_note_layout, container, false);
//        if (item == null) {
//            dismiss();
//        }
        mAskProcessor = new AskProcessor();
        initUI(savedInstanceState, view);

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        refreshData();
    }

    @Override
    public void onHeaderClick(AdapterView<?> parent, View view, long id) {
    }

    @Override
    public boolean onHeaderLongClick(AdapterView<?> parent, View view, long id) {
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> gridView, View view, int position, long id) {
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mActivatedPosition != ListView.INVALID_POSITION) {
            outState.putInt(STATE_ACTIVATED_POSITION, mActivatedPosition);
        }
    }

    private void initUI(Bundle savedInstanceState, View view) {
        request_item_list = view.findViewById(R.id.request_item_list);
        request_item_list.setOnItemClickListener(null);

        request_item_list.setOnHeaderClickListener(null);
        request_item_list.setOnHeaderLongClickListener(null);

        request_item_list.setAreHeadersSticky(false);

        view.findViewById(R.id.request_confirm).setOnClickListener(click);
        view.findViewById(R.id.request_cancel).setOnClickListener(click);
        view.findViewById(R.id.request_clean).setOnClickListener(click);

        view.findViewById(R.id.air_note_title_back_tv).setOnClickListener(click);
        view.findViewById(R.id.add_note_gp_tv).setOnClickListener(click);

        if (savedInstanceState != null) {
            mFirstVisible = savedInstanceState.getInt(KEY_LIST_POSITION);
        }

        if (savedInstanceState != null && savedInstanceState.containsKey(STATE_ACTIVATED_POSITION)) {
            setActivatedPosition(savedInstanceState.getInt(STATE_ACTIVATED_POSITION));
        }
    }

    public void refresh() {
        adapterl.notifyDataSetChanged();
        request_item_list.setSelection(mFirstVisible);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void setActivateOnItemClick(boolean activateOnItemClick) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            request_item_list.setChoiceMode(activateOnItemClick ? ListView.CHOICE_MODE_SINGLE
                    : ListView.CHOICE_MODE_NONE);
        }
    }

    /**
     * 新增要求分组
     */
    private void showAskGroupEditorDialog() {
        AskGroupEditorDialog dialog = new AskGroupEditorDialog();
        dialog.setParam(null, mAskProcessor);
        dialog.setOnAskGroupEditorListener(new AskGroupEditorDialog.OnAskGroupEditorListener() {
            @Override
            public void onAskGroupAddSuccess() {
                refreshData();
            }

            @Override
            public void onAskGroupUpdateSuccess() {

            }

            @Override
            public void onAskGroupDeleteSuccess() {

            }
        });
        DialogManager.showCustomDialog(this, dialog, "AskGroupEditorDialog");
    }

    @SuppressLint("NewApi")
    private void setActivatedPosition(int position) {
        if (position == ListView.INVALID_POSITION) {
            request_item_list.setItemChecked(mActivatedPosition, false);
        } else {
            request_item_list.setItemChecked(position, true);
        }
        mActivatedPosition = position;
    }

    /**
     * 去业务中心获取所有要求数据，并刷新页面
     */
    private void refreshData() {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.optNoteList(item.itemID, item.categoryCode, new IResponse<List<NoteModel>>() {
            @Override
            public void callBack(boolean result, int code, String msg, final List<NoteModel> noteList) {
                BusinessExecutor.executeAsyncExcuteOnMain(new ASyncExecute<List<NoteModel>>() {
                    @Override
                    public List<NoteModel> execute() {

                        List<NoteItemModel> selectedNoteItemList = item.menuBiz.selectNote;

                        if (!ListUtil.isEmpty(noteList)) {
                            for (NoteModel noteModel : noteList) {
                                if (noteModel == null) {
                                    continue;
                                }

                                if (ListUtil.isEmpty(noteModel.itemList)) {
                                    noteModel.itemList = new ArrayList<>();
                                }
                                if (!ListUtil.isEmpty(selectedNoteItemList)) {
                                    for (NoteItemModel noteItemModel : noteModel.itemList) {
                                        for (NoteItemModel selectedItem : selectedNoteItemList) {
                                            if (TextUtils.equals(noteItemModel.id, selectedItem.id)) {
                                                noteItemModel.num = selectedItem.num;
                                                noteItemModel.selected = selectedItem.selected;
                                                noteItemModel.calcTotal();
                                                break;
                                            }
                                        }
                                    }
                                }

                                noteModel.itemList.add(mAskProcessor.optDefaultNoteItemModel(noteModel.groupID));
                            }
                        }

                        return noteList;
                    }
                }, new SyncCallback<List<NoteModel>>() {
                    @Override
                    public void callback(List<NoteModel> noteModels) {
                        ProgressManager.closeProgress(getActivityWithinHost());

                        setParam(noteModels);
                        if (adapterl == null) {
                            adapterl = new AirNoteAdapter(AirNoteFragment.this, askList, askGroupList, R.layout.note_header, R.layout.air_view_note_item);
                            adapterl.setOnItemClickListener(AirNoteFragment.this);
                            request_item_list.setAdapter(adapterl);
                        }

                        refresh();

                    }
                });
            }
        });

    }

    public void setParam(List<NoteModel> askGpList) {
        askGroupList.clear();
        askGroupList.addAll(askGpList);
        askList.clear();
        for (NoteModel temp : askGroupList) {
            if (temp.itemList != null && temp.itemList.size() > 0) {
                askList.addAll(temp.itemList);
            }
        }
    }

    /**
     * 过滤出所有已选中的要求
     *
     * @return
     */
    private List<NoteItemModel> filterSelectedNoteItem() {
        List<NoteItemModel> result = new ArrayList<>();
        for (NoteModel noteModel : askGroupList) {
            if (noteModel.itemList != null && noteModel.itemList.size() > 0) {
                for (NoteItemModel noteItemModel : noteModel.itemList) {
                    if (noteItemModel != null && noteItemModel.num != null && noteItemModel.num.compareTo(BigDecimal.ZERO) > 0) {
                        result.add(noteItemModel);
                    }
                }
            }
        }
        return result;
    }

    /**
     * 清空所有要求
     */
    private void cleanSelectedNoteItem() {
        for (NoteModel noteModel : askGroupList) {
            if (noteModel.itemList != null && noteModel.itemList.size() > 0) {
                for (NoteItemModel noteItemModel : noteModel.itemList) {
                    if (noteItemModel != null && noteItemModel.num != null && noteItemModel.num.compareTo(BigDecimal.ZERO) > 0) {
                        noteItemModel.num = BigDecimal.ZERO;
                        noteItemModel.selected = false;
                        noteItemModel.calcTotal();
                    }
                }
            }
        }
        refresh();
    }

    @Override
    public void onAddNoteItemClick(String groupId) {
        showAddAskDialog(groupId);
    }

    /**
     * 新增要求
     */
    private void showAddAskDialog(String groupId) {
        ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoWhisOutAllList = new ArrayList<>();
        for (NoteModel noteModel : askGroupList) {
            AirAskGroupManagerInfo airAskGroupManagerInfo = new AirAskGroupManagerInfo();
            airAskGroupManagerInfo.fsAskGpId = noteModel.groupID;
            airAskGroupManagerInfo.fsAskGpName = noteModel.name;
            airAskGroupManagerInfoWhisOutAllList.add(airAskGroupManagerInfo);
        }
        AskEditorDialogFragment dialog = new AskEditorDialogFragment();
        dialog.setParam(groupId, airAskGroupManagerInfoWhisOutAllList, mAskProcessor);
        dialog.setOnAskEditorListener(new AskEditorDialogFragment.OnAskEditorListener() {
            @Override
            public void onEditorSuccess() {
                refreshData();
            }
        });
        dialog.show(getFragmentManagerWithinHost(), "AskEditorDialogFragment");
    }
}
