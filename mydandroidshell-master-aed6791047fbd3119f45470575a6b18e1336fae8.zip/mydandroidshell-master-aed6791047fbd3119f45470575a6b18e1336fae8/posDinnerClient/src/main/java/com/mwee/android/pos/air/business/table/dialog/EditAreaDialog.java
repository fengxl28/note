package com.mwee.android.pos.air.business.table.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.pos.air.business.table.processor.TableManagerProcessor;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class EditAreaDialog extends BaseDialogFragment implements View.OnClickListener {


    private TextView title_tv;
    private EditText area_name_edt;

    private TextView batch_add_table_label;
    private ImageButton batch_add_table_btn;
    private View add_area_line2;

    private RelativeLayout batch_table_ryt;
    private EditText table_count_edt;
    private EditText table_person_edt;

    private Button delete_btn, submit_btn;

    private AirAreaManagerInfo airAreaManagerInfo;


    private TableManagerProcessor tableManagerProcessor;
    private OnAreaEditorListener listener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_edit_area_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI(view);
        initData();
    }

    private void initUI(View view) {
        title_tv = view.findViewById(R.id.title_tv);
        area_name_edt = view.findViewById(R.id.area_name_edt);
        delete_btn = view.findViewById(R.id.delete_btn);
        submit_btn = view.findViewById(R.id.submit_btn);
        batch_add_table_label = view.findViewById(R.id.batch_add_table_label);
        batch_add_table_btn = view.findViewById(R.id.batch_add_table_btn);
        add_area_line2 = view.findViewById(R.id.add_area_line2);

        batch_table_ryt = view.findViewById(R.id.batch_table_ryt);
        table_count_edt = view.findViewById(R.id.table_count_edt);
        table_person_edt = view.findViewById(R.id.table_person_edt);

        batch_table_ryt.setVisibility(View.GONE);

        batch_add_table_btn.setSelected(false);
        delete_btn.setOnClickListener(this);
        submit_btn.setOnClickListener(this);
        batch_add_table_btn.setOnClickListener(this);
    }

    private void initData() {
        if (isEditorMode()) {
            title_tv.setText("编辑区域");
            area_name_edt.setText(airAreaManagerInfo.fsMAreaName);
            batch_add_table_label.setVisibility(View.GONE);
            batch_add_table_btn.setVisibility(View.GONE);
            add_area_line2.setVisibility(View.GONE);
        } else {
            batch_add_table_label.setVisibility(View.VISIBLE);
            batch_add_table_btn.setVisibility(View.VISIBLE);
            add_area_line2.setVisibility(View.VISIBLE);
            title_tv.setText("新建区域");

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.batch_add_table_btn:
                batch_add_table_btn.setSelected(!batch_add_table_btn.isSelected());
                batch_table_ryt.setVisibility(batch_add_table_btn.isSelected() ? View.VISIBLE : View.GONE);
                break;
            case R.id.delete_btn:
                dismissSelf();
                break;
            case R.id.submit_btn:
                String name = area_name_edt.getText().toString().trim();
                if (!TextUtils.validate(name)) {
                    ToastUtil.showToast("请输入区域名称");
                    return;
                }
                if (!RegexUtil.checkName(name)) {
                    ToastUtil.showToast("输入的字符非法");
                    return;
                }

                if (isEditorMode()) {
                    if (android.text.TextUtils.equals(name, airAreaManagerInfo.fsMAreaName)) {
                        ToastUtil.showToast("餐区名称没有变化");
                        return;
                    } else {
                        doUpdate(name);
                    }
                } else {
                    boolean batchAddTable = batch_add_table_btn.isSelected();
                    int count = 0;
                    int person = 0;
                    if (batchAddTable) {
                        String tableCount = table_count_edt.getText().toString().trim();
                        if (!TextUtils.validate(tableCount)) {
                            ToastUtil.showToast("请输入桌号数量");
                            return;
                        }
                        count = StringUtil.toInt(tableCount);
                        if (count < 1) {
                            ToastUtil.showToast("桌号数量必须大于1");
                            return;
                        }

                        String tablePerson = table_person_edt.getText().toString().trim();
                        if (!TextUtils.validate(tablePerson)) {
                            ToastUtil.showToast("请输入人数");
                            return;
                        }
                        person = StringUtil.toInt(tablePerson);
                        if (person < 1) {
                            ToastUtil.showToast("人数必须大于1");
                            return;
                        }
                        person = StringUtil.toInt(tablePerson);


                    }
                    doSave(name, batchAddTable, count, person);
                }
                break;
            default:
                break;
        }
    }


    /**
     * 新增区域
     *
     * @param name
     */
    private void doSave(String name, boolean batchAddTable, int tableCount, int person) {
        ProgressManager.showProgress(getActivityWithinHost());
        tableManagerProcessor.addArea(name, batchAddTable, tableCount, person, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    dismissSelf();
                    listener.onAddSuccess(tableManagerProcessor.mareaDBModel, tableManagerProcessor.newTableDBModels);
                    return;
                }
                ToastUtil.showToast(TextUtils.validate(info) ? info : "添加区域失败");
            }
        });
    }

    private void doUpdate(final String name) {
        ProgressManager.showProgress(getActivityWithinHost());
        tableManagerProcessor.updateAreaName(airAreaManagerInfo.fsMAreaId, name, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    dismissSelf();
                    listener.onUpdateSuccess(name);
                    return;
                }
                ToastUtil.showToast(TextUtils.validate(info) ? info : "修改区域名称失败");
            }
        });
    }

    public void setParam(AirAreaManagerInfo airAreaManagerInfo, TableManagerProcessor tableManagerProcessor) {
        this.tableManagerProcessor = tableManagerProcessor;
        this.airAreaManagerInfo = airAreaManagerInfo;
    }

    /**
     * 编辑模式
     *
     * @return
     */
    public boolean isEditorMode() {
        return this.airAreaManagerInfo != null;
    }

    public void setOnAreaEditorListener(OnAreaEditorListener listener) {
        this.listener = listener;
    }

    public interface OnAreaEditorListener {

        void onAddSuccess(MareaDBModel mareaDBModel, ArrayList<MtableSimpleModel> newTableDBModels);

        void onUpdateSuccess(String name);

        //void onDeleteSuccess(String fsMAreaId);
    }

}
