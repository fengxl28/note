package com.mwee.android.pos.air.business.menu.processor;

import com.mwee.android.air.connect.business.menu.MenuPackageItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageSetSideResponse;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.air.business.menu.api.MenuManagerApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.List;

/**
 * Created by qinwei on 2017/10/12.
 */

public class MenuPackageProcessor {


    public void loadUpdatePackageMenu(String fiItemCd, String name, String price, List<MenuPackageSetSideBean> beans, final ResultCallback<String> callback) {
        MenuManagerApi.loadUpdatePackageMenu(fiItemCd, name, price, beans, new SocketCallback<SocketResponse>() {

            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }


    public void loadAddMenuPackage(String name, String price, final ResultCallback<String> callback) {
        MenuManagerApi.loadAddMenuPackage(name, price, new SocketCallback<SocketResponse>() {

            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadDeleteMenuItemSetSide(String fiSetFoodCd, final ResultCallback<String> callback) {
        MenuManagerApi.loadDeleteMenuItemSetSide(fiSetFoodCd, new SocketCallback<SocketResponse>() {

            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadMenuPackageItems(boolean isLoadFirstDetailInfo, final ResultCallback<MenuPackageItemsResponse> callback) {
        MenuManagerApi.loadMenuPackageItems(isLoadFirstDetailInfo, new SocketCallback<MenuPackageItemsResponse>() {
            @Override
            public void callback(SocketResponse<MenuPackageItemsResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadMenuPackageSetSidesByMenuId(String fiItemCd, final ResultCallback<List<MenuPackageSetSideBean>> callback) {
        MenuManagerApi.loadMenuPackageSetSidesByMenuId(fiItemCd, new SocketCallback<MenuPackageSetSideResponse>() {
            @Override
            public void callback(SocketResponse<MenuPackageSetSideResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data.menuPackageSetSideBeanList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    public void loadDeletePackageMenuItem(String fiItemCd, final ResultCallback<String> callback) {
        MenuManagerApi.loadDeletePackageMenuItem(fiItemCd, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.message);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }
}
