//package com.mwee.android.pos.air.business.dinner;
//
//import android.content.Context;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ListView;
//
//import com.mwee.android.drivenbus.DriverBus;
//import com.mwee.android.drivenbus.IDriver;
//import com.mwee.android.drivenbus.component.DrivenMethod;
//import com.mwee.android.pos.air.business.ask.business.jump.AirNoteJump;
//import com.mwee.android.pos.air.business.member.dialog.MemberBindDialogFragment;
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.business.dinner.api.LockTableApi;
//import com.mwee.android.pos.business.dinner.processor.DinnerOrderProcessor;
//import com.mwee.android.pos.business.dinner.processor.MenuItemProcessor;
//import com.mwee.android.pos.business.localpush.NotifyToServer;
//import com.mwee.android.pos.business.member.biz.MemberProcess;
//import com.mwee.android.pos.business.member.view.MemberCheckCallBack;
//import com.mwee.android.pos.business.member.view.MemberOrderUnBindAirDialogFragment;
//import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
//import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
//import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
//import com.mwee.android.pos.business.orderdishes.view.DishCache;
//import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
//import com.mwee.android.pos.business.permission.Permission;
//import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
//import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
//import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
//import com.mwee.android.pos.business.table.processor.TableBizProcessor;
//import com.mwee.android.pos.business.viceshow.ViceShowConnector;
//import com.mwee.android.pos.component.delayqueue.DelayQueue;
//import com.mwee.android.pos.component.delayqueue.IDQWorker;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.component.log.ActionLog;
//import com.mwee.android.pos.component.log.RunTimeLog;
//import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
//import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
//import com.mwee.android.pos.connect.config.SocketResultCode;
//import com.mwee.android.pos.connect.callback.IResponse;
//import com.mwee.android.pos.connect.callback.IResult;
//import com.mwee.android.pos.db.MenuTerminal;
//import com.mwee.android.pos.db.business.UserDBModel;
//import com.mwee.android.pos.db.business.common.Calc;
//import com.mwee.android.pos.db.business.menu.bean.MenuItem;
//import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
//import com.mwee.android.pos.db.business.order.OrderCache;
//import com.mwee.android.pos.db.business.order.OrderStatus;
//import com.mwee.android.pos.db.business.pay.RoundConfig;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.GuideUtil;
//import com.mwee.android.pos.util.ListUtil;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.util.UIHelp;
//import com.mwee.android.tools.LogUtil;
//
//import java.math.BigDecimal;
//import java.math.RoundingMode;
//import java.util.List;
//
///**
// * Created by zhangmin on 2017/11/9.
// */
//
//public class AirDinnerOrderDishsFragment extends BaseFragment implements IDriver, DinnerFoodOrderDishsAdapter.OnDinnerFoodOrderItemClickListener, DinnerOrderFooterLayout.DinnerOrderFooterLayouCallBack {
//
//    private final static String DRIVER_TAG = "orderDishesView";
//
//    private ListView mDinnerFoodOrderLsv;
//
//    private DinnerFoodOrderDishsAdapter adapter;
//    private DishCache mDishCache;
//
//    private DelayQueue<Object> refreshDelayQueue;
//
//    private DinnerOrderProcessor mDinnerOrderProcessor;
//    private MenuItemProcessor mMenuItemProcessor;
//    private DinnerFoodOperationTopLayout dinnerFoodTopLayout;
//    private DinnerOrderFooterLayout dinnerFoodFooterLayout;
//
//
//    @DrivenMethod(uri = DRIVER_TAG + "/clickone", UIThread = true)
//    public void clickone(MenuItem item) {
//        if (item.isCategory || OrderDishesBizUtil.isOutOfStock(mDishCache.tempUnitQuantity, item)) {//         菜品沽清判断
//            return;
//        }
//        int currentSeq = -1;
//        if (mDishCache.order != null) {
//            currentSeq = mDishCache.order.currentSeq;
//        }
//        item.init(currentSeq, mDishCache.isBindMember());//设置点菜单序
//        MenuItem mergeMenuItem = OrderDishesBizUtil.findMergeMenuItem(mDishCache.orderDishesCache.tempSelectedMenuList, item);
//        if (mergeMenuItem != null) {
//            mergeMenuItem.terminal_id = MenuTerminal.DINNER;
//            mDishCache.mergeOrderMenuItem(mergeMenuItem, item);//更新dishCache里面缓存数据
//        } else {
//            item.terminal_id = MenuTerminal.DINNER;
//            adapter.selectPosition = 0;
//            mDishCache.addDinnerMenuItem(item);
//        }
//        calculateTotalPrice();
//        adapter.notifyDataChanged(mDishCache);
//
//    }
//
//    /**
//     * 点菜需要的数据
//     *
//     * @param dishCache 点菜缓存
//     */
//    public void setParam(DishCache dishCache) {
//        this.mDishCache = dishCache;
//    }
//
//
//    @Override
//    public String getModuleName() {
//        return DRIVER_TAG;
//    }
//
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (mDishCache != null && mDishCache.orderDishesCache != null) {
//            AppCache.getInstance().orderingTableID = mDishCache.orderDishesCache.fsmtableid;
//            LockTableApi.lockTable(mDishCache.getOrderId(), mDishCache.orderDishesCache.fsmtableid, AppCache.getInstance().userDBModel, AppCache.getInstance().currentHostId, new IResult() {
//                @Override
//                public void callBack(boolean result, String info) {
//                    if (!result) {
//                        ToastUtil.showToast(info);
//                        dismissSelf();
//                    }
//                }
//            });
//        }
//    }
//
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_air_dinner_food_order_dishs, container, false);
//    }
//
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        if (mDishCache == null) {
//            UIHelp.startAirHomeActivity(getActivityWithinHost());
//            return;
//        }
//        DriverBus.registerDriver(this);
//        initView(view);
//        initData();
//        GuideUtil.show((ViewGroup) view, GuideUtil.TYPE_NEWMENU, new GuideUtil.OnDissmissListener() {
//            @Override
//            public void onDissmiss() {
//                GuideUtil.show((ViewGroup) view, GuideUtil.TYPE_MENU_LONGCLICK);
//            }
//        });
//    }
//
//    private void initView(View view) {
//
//        mDinnerFoodOrderLsv = view.findViewById(R.id.mDinnerFoodOrderLsv);
//
//        dinnerFoodTopLayout = view.findViewById(R.id.mDinnerFoodTopLayout);
//        dinnerFoodFooterLayout = view.findViewById(R.id.mDinnerOrderFooterLayout);
//        dinnerFoodFooterLayout.setDinnerOrderFooterLayouCallBack(this);
//
//
//        adapter = new DinnerFoodOrderDishsAdapter(this, mDishCache);
//        adapter.setOnDinnerFoodOrderItemClickListener(this);
//
//        mDinnerFoodOrderLsv.setEmptyView(view.findViewById(R.id.mDinnerFoodOrderEmptyLabel));
//        mDinnerFoodOrderLsv.setAdapter(adapter);
//
//
//    }
//
//
//    private void initData() {
//
//
//        //客显
//        refreshDelayQueue = new DelayQueue<>("dinnerFoodViceShow");
//        refreshDelayQueue.setWorker(refreshWorker);
//        refreshDelayQueue.setDelay(500);
//
//        mDinnerOrderProcessor = new DinnerOrderProcessor(this, mDishCache);
//        mMenuItemProcessor = new MenuItemProcessor(this, mDishCache);
//
//        dinnerFoodTopLayout.setParams(getActivityWithinHost(), mDishCache);
//        dinnerFoodTopLayout.setOnCallBack(new DinnerFoodOperationTopLayout.CallBack() {
//            @Override
//            public void backToTable() {
//                onKeyBack();
//            }
//        });
//
//        dinnerFoodFooterLayout.initData(mDishCache);
//
//        adapter.notifyDataSetChanged();
//        if (mDishCache.order == null) {
//            loadDataFromCenterBiz();
//        } else {
//            calculateTotalPrice();
//        }
//
//    }
//
//
//    private void loadDataFromCenterBiz() {
//        //初次开台 加入开台预置数据
//        RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品中...");
//        TableBizProcessor.loadOpenParamMenus(mDishCache.orderDishesCache.fsmareaid, mDishCache.orderDishesCache.personNum, new ResultCallback<List<MenuItem>>() {
//            @Override
//            public void onSuccess(List<MenuItem> data) {
//                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品成功", "", data);
////                progress.dismiss();
//                if (!ListUtil.isEmpty(data)) {
//                    mDishCache.orderDishesCache.tempSelectedMenuList.addAll(data);
//                    //mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
//                    calculateTotalPrice();
//                    //mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
//                    //mDishCache.initSelectUnitQuantity();
//                    adapter.notifyDataChanged(mDishCache);
//                }
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品失败", "code=" + code + ",msg=" + msg);
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//
//    /**
//     * 刷新笔数与总价
//     */
//    public void calculateTotalPrice() {
//        // FIXME: 2017/6/22 总价格计算方法
//        mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
//        dinnerFoodFooterLayout.refreshDinnerFoodFooterLayout();
//
//        //客显
//        refreshDelayQueue.addTask("dinnerRefresh");
//    }
//
//
//    private IDQWorker refreshWorker = new IDQWorker() {
//        @Override
//        public void work(Object o) {
//            ViceShowConnector.getInstance().sendDinnerMsg(mDishCache);
//            refreshDelayQueue.done("dinnerRefresh");
//        }
//    };
//
//
//
//    /*------------------------------------小散正餐点菜页面 菜品点菜回调-------------------------------------*/
//
//    /**
//     * 未下单菜品->修改点菜数量
//     *
//     * @param item
//     * @param userDBModel
//     */
//    @Override
//    public void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel) {
//
//        ModifyQuantityUtils.showModifyQuantitySupportWeight(this, item, new CountKeyboardCallback() {
//            @Override
//            public void callback(BigDecimal originNum, BigDecimal newNum) {
//                if (newNum.compareTo(BigDecimal.ZERO) < 1 || originNum.compareTo(newNum) == 0) {
//                    return;
//                }
//                //沽清判断
//                if (OrderDishesBizUtil.isOutOfStock(mDishCache.tempUnitQuantity, item, newNum)) {
//                    return;
//                }
//                item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundingMode.HALF_UP));
//                //重新计算价格
//                item.calcTotal(mDishCache.orderDishesCache.isMember);
//                //更新DishCache缓存信息
//                mDishCache.initSelectUnitQuantity();
//                adapter.notifyDataSetChanged();
//
//                //TODO notifyall
//                //DriverBus.broadcast("notifyall");
//                calculateTotalPrice();
//            }
//        });
//
//    }
//
//
//    /**
//     * 已下单菜品—>修改点菜数量
//     *
//     * @param item
//     * @param userDBModel
//     */
//    @Override
//    public void doChangeOrderedMenuNumber(MenuItem item, UserDBModel userDBModel) {
//
//        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, mDishCache.order, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                adapter.notifyDataSetChanged();
//                mDishCache.order.reCalcAllByAll();
//                calculateTotalPrice();
//
//                //TODO
//                //DriverBus.call("menuview/refreshMenu");
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
//
//                    //TODO
//                    // DriverBus.call("menuview/refreshMenu");
//                } else {
//                    dismissSelf();
//                }
//            }
//        });
//
//    }
//
//    /**
//     * 删除菜品
//     *
//     * @param item
//     */
//    @Override
//    public void doDeleteMenu(MenuItem item) {
//
//        adapter.selectPosition = 0;
//        mDishCache.removeDinnerMenuItem(item);
//        adapter.notifyDataChanged(mDishCache);
//
//        //TODO
//        //DriverBus.broadcast("notifyall");
//        //mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
//        calculateTotalPrice();
//
//    }
//
//    /**
//     * 已下单菜品—>退菜
//     *
//     * @param item
//     * @param userDBModel
//     * @param msg
//     */
//    @Override
//    public void doRetreatDish(final MenuItem item, UserDBModel userDBModel, String msg) {
//
//        mMenuItemProcessor.doRetreatDish(mDishCache.getOrderId(), item, msg, new ResultCallback<OrderCache>() {
//            @Override
//            public void onSuccess(OrderCache data) {
//                adapter.notifyDataSetChanged();
//                mDishCache.order = data;
//                mDishCache.initSelectUnitQuantity();
//
//                //TODO
//                //DriverBus.call("menuview/notifyone", item);
//                calculateTotalPrice();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//            }
//        });
//
//    }
//
//    @Override
//    public void doChangeMenuPrice(final MenuItem item, UserDBModel userDBModel) {
//
//        mMenuItemProcessor.doUpdateDishPrice(mDishCache.getOrderId(), item, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                item.calcTotal(false);
//                adapter.notifyDataSetChanged();
//                if (mDishCache.order != null) {
//                    mDishCache.order.reCalcAllByAll();
//                }
//                calculateTotalPrice();//刷新总价
//
//                //TODO
//                //DriverBus.broadcast("notifyall");
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                dismissSelf();
//            }
//        });
//    }
//
//    @Override
//    public void doChangeMenuName(final MenuItem menuItem, UserDBModel userDBModel) {
//        mMenuItemProcessor.doUpdateMenuName(menuItem, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                menuItem.name = data;
//                menuItem.name2 = data;
//                adapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                dismissSelf();
//            }
//        });
//    }
//
//
//    /*------------------------------------小散正餐点菜页面 底部buttom点击事件回调-------------------------------------*/
//    @Override
//    public void onMenuItemRequestClick() {
//
//        final MenuItem menuItem = adapter.getItem(adapter.selectPosition);
//        if (menuItem == null) {
//            ToastUtil.showToast(R.string.please_choice_menuitem);
//            return;
//        }
//
//        if (mDishCache.order != null && mDishCache.order.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
//            ToastUtil.showToast("已下单菜品不可修改要求");
//            return;
//        }
//        AirNoteJump.showNote(getActivityWithinHost(), menuItem, new NoteCallback() {
//            @Override
//            public void callBack(List<NoteItemModel> selectedInfo) {
//                menuItem.menuBiz.selectNote = selectedInfo;
//                menuItem.buildNotesString();
//                menuItem.calcTotal(mDishCache.orderDishesCache.isMember);
//                adapter.notifyDataSetChanged();
//                calculateTotalPrice();
//            }
//        });
//
//
//    }
//
//    @Override
//    public void onDiscountClick() {
//        if (mDishCache.order == null) {
//            ToastUtil.showToast("请先下单");
//            return;
//        }
//        mMenuItemProcessor.doBatchDiscount(new DinnerMultiDiscountCallBack() {
//            @Override
//            public void call(OrderCache cache, List<MenuItem> tempList) {
//                mDishCache.order = cache;
//                adapter.notifyDataChanged(mDishCache);
//                calculateTotalPrice();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//
//            }
//        });
//    }
//
//    @Override
//    public void onMemberClick() {
//        if (mDinnerOrderProcessor.mDishCache.order == null) {
//            ToastUtil.showToast(R.string.member_table_not_bind_order);
//            return;
//        }
//        if (mDinnerOrderProcessor.mDishCache.order.memberInfoS != null) {//已经绑定过会员
//            showMemberInfo();
//        } else {//尚未绑定会员
//            PermissionsUtil.requestPermissionCommon(mDinnerOrderProcessor.mHost, AppCache.getInstance().userDBModel, Permission.DINNER_vVIPBind, new PermissionCallback() {
//                @Override
//                public void onCall(int errCode, String msg, UserDBModel userDBModel) {
//                    MemberBindDialogFragment fragment = new MemberBindDialogFragment();
//                    fragment.setBindOrderId(mDinnerOrderProcessor.mDishCache.order.orderID);
//                    fragment.setOnBindOrderListener(memberCheckCallBack);
//                    DialogManager.showCustomDialog(mDinnerOrderProcessor.mHost, fragment, "MemberBindDialogFragment");
//                }
//            });
//        }
//    }
//
//    /**
//     * 显示关联会员信息
//     */
//    private void showMemberInfo() {
//        Progress progress = ProgressManager.showProgressUncancel(this);
//        new MemberProcess().onlyLoadMemberInfo(mDishCache.order.memberInfoS.card_no, new IResponse<QueryMemberInfoResponse>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse info) {
//                progress.dismissSelf();
//                if (result) {
//                    mDishCache.order.memberInfoS.score = info.memberCardModel.card_data.score;
//                    mDishCache.order.memberInfoS.balance = info.memberCardModel.card_data.amount;
//                }
//                MemberOrderUnBindAirDialogFragment fragment = MemberOrderUnBindAirDialogFragment.getInstance(mDishCache.order.memberInfoS, result);
//                fragment.setParam(new MemberOrderUnBindAirDialogFragment.OnMemberInfoListener() {
//                    @Override
//                    public void onUnbindMember() {
//                        clearBindMemberInfo();
//                    }
//                });
//                DialogManager.showCustomDialog(AirDinnerOrderDishsFragment.this, fragment, "");
//            }
//        });
//    }
//
//
//    /**
//     * 会员成功登陆的回调
//     */
//    private MemberCheckCallBack memberCheckCallBack = new MemberCheckCallBack() {
//        @Override
//        public void call(final QueryMemberInfoAndBindToOrderResponse member) {
//            if (mDinnerOrderProcessor.mDishCache.order != null) {
//                mDinnerOrderProcessor.mDishCache.order = member.orderCache;
//                if (!com.mwee.android.pos.util.TextUtils.validate(mDinnerOrderProcessor.mDishCache.order.memberName)) {
//                    //真实姓名和昵称都为空 取会员等级名称
//                    dinnerFoodFooterLayout.bindMember(mDinnerOrderProcessor.mDishCache.order.memberInfoS.level_name, mDinnerOrderProcessor.mDishCache.order.memberInfoS.mobile);
//                } else {
//                    dinnerFoodFooterLayout.bindMember(mDinnerOrderProcessor.mDishCache.order.memberName, mDinnerOrderProcessor.mDishCache.order.memberInfoS.mobile);
//                }
//                if (mDishCache.order == null) {
//                    return;
//                }
//                mDishCache.order = member.orderCache;
//                calculateTotalPrice();
//                adapter.notifyDataChanged(mDishCache);
//            }
//        }
//    };
//
//    /**
//     * 清除会员绑定操作
//     */
//    private void clearBindMemberInfo() {
//        if (mDinnerOrderProcessor.mDishCache.isBindMember()) {
//            final Progress progress = ProgressManager.showProgressUncancel(mDinnerOrderProcessor.mHost, "解绑中");
//            mDinnerOrderProcessor.unBindMemberInfoFromOrder(mDinnerOrderProcessor.mDishCache.order.orderID, mDinnerOrderProcessor.mDishCache.order.memberInfoS.card_no, new ResultCallback<ChangeOrderWithMemberResponse>() {
//                @Override
//                public void onSuccess(ChangeOrderWithMemberResponse data) {
//                    mDinnerOrderProcessor.mDishCache.order.clearMember();
//                    dinnerFoodFooterLayout.unBindMember();
//                    if (mDishCache.order == null) {
//                        return;
//                    }
//                    calculateTotalPrice();
//                    adapter.notifyDataSetChanged();
//                    progress.dismiss();
//                }
//
//                @Override
//                public void onFailure(int code, String msg) {
//                    if (!android.text.TextUtils.isEmpty(msg)) {
//                        ToastUtil.showToast(msg);
//                    }
//                    progress.dismiss();
//                }
//            });
//        }
//    }
//
//    @Override
//    public void onOrderMenuCommitClick() {
//
//        if (ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList) && mDishCache.order == null) {
//            ToastUtil.showToast("该订单信息为空!");
//            return;
//        }
//        if (ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList) && mDishCache.order != null) {
//            if (onDinnerFoodOrderListener != null) {
//                onDinnerFoodOrderListener.onDinnerOrderListener(mDishCache);
//            }
//            dismissSelf();
//            return;
//        }
//        ActionLog.addLog("点菜页->点击下单", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
//        if (mDishCache.order == null || mDishCache.order.orderStatus == OrderStatus.CREATED) {
//            orderAndOpenTable();
//        } else {
//            orderToBizCenter(true);
//        }
//
//    }
//
//
//    private void orderToBizCenter(boolean isPrinter) {
//        mDinnerOrderProcessor.orderToCenter(isPrinter, new ResultCallback<OrderCache>() {
//            @Override
//            public void onSuccess(OrderCache orderCache) {
//                ActionLog.addLog("点菜页->下单成功", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
//                if (mDishCache.antiPay) {
//                    mDishCache.order = orderCache;
//                    mDishCache.clearTempOrderDishesCache();
//                    //mDishCache.initSelectUnitQuantity();
//
//                    //TODO 刷新底部
//                    //mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
//                    //adapter.notifyDataChanged(mDishCache);
//                    //processSaveOrderSuccess();
//                    nextStep();
//                } else {
//                    mDishCache.order = orderCache;
//                    mDishCache.clearTempOrderDishesCache();
//                    nextStep();
//                }
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ActionLog.addLog("点菜页->下单失败", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//
//    private void orderAndOpenTable() {
//        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), "正在下单...");
//        mDinnerOrderProcessor.orderAndOpenTable(true, new ResultCallback<OrderCache>() {
//            @Override
//            public void onSuccess(OrderCache data) {
//                progress.dismiss();
//                ActionLog.addLog("点菜页->下单成功", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
//                LogUtil.logOnlineDebug("--order--点菜页->下单成功--orderAndOpenTable--callback--");
//                mDishCache.order = data;
//                mDishCache.clearTempOrderDishesCache();
//                nextStep();
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                LogUtil.logOnlineDebug("--order--点菜页->下单失败--orderAndOpenTable--callback--msg:"+msg);
//                progress.dismiss();
//                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
//                    mDinnerOrderProcessor.showOrderErrMsg(msg);
//                } else {
//                    ToastUtil.showToast(!TextUtils.isEmpty(msg) ? msg : getString(R.string.dinner_food_order_failure));
//                }
//                ActionLog.addLog("点菜页->下单失败:" + msg, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
//            }
//        });
//    }
//
//    /**
//     * 下单是否自动登出 是本机设置
//     *
//     * @param
//     */
//    private void nextStep() {
//
//        DriverBus.call("_AirTableContainer/onOrderMenuCommit", mDishCache);
//        dismissSelf();
//     /*  onDinnerFoodOrderListener.onDinnerOrderListener(mDishCache);
//        dismissSelf();*/
//        //onKeyBack();
//       /* if (SettingHelper.isOpenActionExist()) {
//            mDishCache.clearTempOrderDishesCache();
//            DriverBus.call(Constants.DRIVER_TAG_LOGOUT);
//        } else { //桌台页
//            mDishCache.clearTempOrderDishesCache();
//
//            //跳转到桌台页面
//            DriverBus.call("main/jump", MAIN_TAB.TABLE);
//        }*/
//
//    }
//
//
//    @Override
//    public boolean onKeyBack() {
//        onDinnerFoodOrderListener.onDinnerOrderListener(mDishCache);
//        //刷新小散桌台界面 桌台点菜预览界面
//        if (mDishCache.orderDishesCache.tempSelectedMenuList.size() > 0) {
//            DialogManager.showExecuteDialog(getActivityWithinHost(), R.string.dinner_food_order_back_msg, getString(R.string.cacel), getString(R.string.confirm), new DialogResponseListener() {
//                @Override
//                public void response() {
//                    //清除未下单的菜品
//                    mDishCache.clearTempOrderDishesCache();
//                    dismissSelf();
//                }
//            }, null);
//        } else {
//            dismissSelf();
//        }
//        return true;
//    }
//
//
//    /**
//     * dishCach 已下单菜品信息 改变 需要刷新桌台点菜预览页面
//     */
//    private OnDinnerFoodOrderListener onDinnerFoodOrderListener;
//
//    public void setAirTableClickCallBack(OnDinnerFoodOrderListener onDinnerFoodOrderListener) {
//        this.onDinnerFoodOrderListener = onDinnerFoodOrderListener;
//    }
//
//    public interface OnDinnerFoodOrderListener {
//
//        void onDinnerOrderListener(DishCache mDishCache);
//
//    }
//
//
//    /*-----------------------------------------*/
//    @DrivenMethod(uri = DRIVER_TAG + "/loginInMember", UIThread = true)
//    public void loginMember(OrderCache orderCache) {
//        if (mDishCache.order == null) {
//            return;
//        }
//        mDishCache.order = orderCache;
//        calculateTotalPrice();
//        adapter.notifyDataChanged(mDishCache);
//    }
//
//    /**
//     * 当会员退出时,清空菜品中会员相关的设置
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/loginOutMember", UIThread = true)
//    public void clearMemberInfo() {
//        if (mDishCache.order == null) {
//            return;
//        }
//        calculateTotalPrice();
//        adapter.notifyDataSetChanged();
//    }
//
//    /**
//     * 换桌完成，刷新页面
//     *
//     * @param dishCache
//     */
//    @DrivenMethod(uri = DRIVER_TAG + "/tableChanged")
//    public void tableChanged(DishCache dishCache) {
//        if (adapter == null) {
//            return;
//        }
//        if (dishCache == null) {
//            return;
//        }
//        calculateTotalPrice();
//        adapter.notifyDataChanged(dishCache);
//    }
//
//    @Override
//    public void onDetach() {
//        NotifyToServer.sendExcuteMsg("table/unlockTableByHost", AppCache.getInstance().currentHostId);
//        AppCache.getInstance().orderingTableID = "";
//        super.onDetach();
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        ViceShowConnector.getInstance().clearOrderInfo();
//    }
//
//
//}
