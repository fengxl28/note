package com.mwee.android.pos.business.member;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.dinner.R;

/**
 * Created by qinwei on 2017/2/22.
 */

public class RechargeSuccessPageFragment extends BaseFragment {
    private static final String KEY_RECHARGE_ORDER_INFO = "key_recharge_order_info";
    private TextView mRechargeSuccessContentLabel;

    public static RechargeSuccessPageFragment getInstance(MemberRechargeResultModel rechargeOrderModel) {
        RechargeSuccessPageFragment fragment = new RechargeSuccessPageFragment();
        Bundle args = new Bundle();
        args.putSerializable(KEY_RECHARGE_ORDER_INFO, rechargeOrderModel);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_balance_recharge_success, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRechargeSuccessContentLabel = (TextView) view.findViewById(R.id.mRechargeSuccessContentLabel);
        MemberRechargeResultModel rechargeOrderModel = (MemberRechargeResultModel) getArguments().getSerializable(KEY_RECHARGE_ORDER_INFO);
        mRechargeSuccessContentLabel.setText("充值成功！充值" + rechargeOrderModel.amount + "元。");
        back = new BackThread();
        mRechargeSuccessContentLabel.postDelayed(back, 3000);
    }

    private BackThread back;

    class BackThread implements Runnable {

        @Override
        public void run() {
            dismissSelf();
        }
    }

    @Override
    public void onDestroyView() {
        mRechargeSuccessContentLabel.removeCallbacks(back);
        super.onDestroyView();
    }
}
