package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberBalanceRechargeRequest extends BaseMemberParam {
    public int m_shopid;
    public int shop_id;
    public String card_no = "";
    public String remark = "";
    public int is_add = 0;//0 no 1 yes
    public int change_real;//is_add==1 加 实收
    public int change_present;//is_add==1 加 奖励
    public int change_amount;//is_add==0 总额减
    public String editor_mobile;

    public MemberBalanceRechargeRequest() {

    }
}
