package com.mwee.android.pos.business.home;

import android.content.pm.PermissionInfo;

import com.mwee.android.pos.business.permission.Permission;

import java.util.HashMap;
import java.util.Map;

/**
 * 首页的Tab
 * Created by virgil on 16/9/26.
 */
public class MAIN_TAB {
    public final static int DEFAULT = 0;
    public final static int TABLE = 0;
    public final static int BILL = 1;
    public final static int PRINT = 2;
    public final static int SHIFT = 3;
    public final static int SET = 4;
    public static final int MEMBER = 5;
    public final static int REPORT = 6;
    public final static int MESSAGE = 7;
    public final static int CUSTOM = 8;

    public static final Map<Integer, PermisionInfo> MODULE_PERMISSION_MAP = new HashMap<>();
    static {
        MODULE_PERMISSION_MAP.put(REPORT, new PermisionInfo(Permission.REPORT_MODULE, "report"));
    }

    public static class PermisionInfo {
        public String permision;
        public String permisionType;

        public PermisionInfo (String permision, String permisionType) {
            this.permision = permision;
            this.permisionType = permisionType;
        }
    }
}
