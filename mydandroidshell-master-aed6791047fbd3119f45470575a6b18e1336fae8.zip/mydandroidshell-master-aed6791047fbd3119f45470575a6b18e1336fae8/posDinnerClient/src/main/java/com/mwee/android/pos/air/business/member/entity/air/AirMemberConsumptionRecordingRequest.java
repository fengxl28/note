package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;

/**
 * 查询会员等级列表
 * Created by zhangmin on 2018/1/30.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "app.membercard.consumeList",
        contentType = "application/json",
        response = AirMemberConsumptionRecordingResponse.class,
        saveToLog = true
)
public class AirMemberConsumptionRecordingRequest extends BaseMemberRequest {

    public String card_no;
    public String mobile;
    public String start_date;
    public String end_date;
    public Integer page;
    public Integer page_size;

    public AirMemberConsumptionRecordingRequest() {
        super("app.membercard.consumeList");
    }
}
