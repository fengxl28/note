package com.mwee.android.pos.business.common.dialog.pay;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.MainThread;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.notify.NotifyDispatchService;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.DisplayUtil;

public class AbnormalMessageNotice {
    private WindowManager mWindowManager = null;
    private View view;
    public boolean isShow;
    private static AbnormalMessageNotice mInstance;

    public static AbnormalMessageNotice getInstance() {
        if (mInstance == null) {
            mInstance = new AbnormalMessageNotice();
        }
        return mInstance;
    }

    @MainThread
    public void showFloatWindow(String billNo) {
        view = LayoutInflater.from(GlobalCache.getContext()).inflate(R.layout.layout_message_fast_food_rapid, null);
        initFloatView();
        WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) GlobalCache.getContext().getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (!Settings.canDrawOverlays(GlobalCache.getContext())) {
                RunTimeLog.addLog(RunTimeLog.OVERLAY_WINDOW, "NetOrderMessageNotice -> showFloatWindow() 无权限返回");
                return;
            }
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.gravity = Gravity.RIGHT | Gravity.TOP;
        wmParams.width = DisplayUtil.dp2px(GlobalCache.getContext(), 430);
        wmParams.height = DisplayUtil.dp2px(GlobalCache.getContext(), 150);
        wmParams.windowAnimations = android.R.style.Animation_Translucent;
        mWindowManager.addView(view, wmParams);
        isShow = true;
        updateFloatWindow();
    }

    @MainThread
    public void updateFloatWindow() {
        TextView mMessageContentLabel = (TextView) view.findViewById(R.id.mMessageContentLabel);
        String notify_Content = "您有一条异常订单，请及时处理！";
        mMessageContentLabel.setText(notify_Content);
    }

    private void initFloatView() {
        Button mMessageGoCenterBtn = (Button) view.findViewById(R.id.mMessageGoCenterBtn);
        mMessageGoCenterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (BaseActivity.topActivity != null) {
                    MessageV2Fragment.index = 6;
                    if (APPConfig.isAir()) {
                        UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                    } else {
                        DriverBus.call("main/closesub");
                        DriverBus.call("main/closesub");
//                        DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                        DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                    }
                }
                release();
            }
        });
        Button mMessageCloseBtn = (Button) view.findViewById(R.id.mMessageCloseBtn);
        mMessageCloseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                release();
            }
        });
    }

    private void release() {
        if (mWindowManager != null) {
            mWindowManager.removeView(view);
        }
        mWindowManager = null;
        mInstance = null;
    }
}
