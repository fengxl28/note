package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberScoreGiftRuleQueryRequest extends BaseMemberParam {
    /**
     * 总店ID
     */
    public int m_shopid;

    /**
     * 门店ID 非必填
     */
    public int shop_id;

    /**
     * 活动ID 非必填
     */
    public int pkg_id;

    /**
     * 是否获得网上充值规则
     */
    public int getOnlineStoreRule;

    public MemberScoreGiftRuleQueryRequest() {
    }
}
