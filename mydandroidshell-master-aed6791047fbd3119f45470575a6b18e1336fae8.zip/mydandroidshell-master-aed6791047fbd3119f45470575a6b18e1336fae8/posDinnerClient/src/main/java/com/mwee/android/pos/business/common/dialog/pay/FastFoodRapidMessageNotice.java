package com.mwee.android.pos.business.common.dialog.pay;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.dinner.R;

/**
 * Created by qinwei on 2017/9/15.
 */

public class FastFoodRapidMessageNotice {
    private WindowManager mWindowManager = null;
    private View view;
    public boolean isShow;
    private static FastFoodRapidMessageNotice mInstance;

    public static FastFoodRapidMessageNotice getInstance() {
        if (mInstance == null) {
            mInstance = new FastFoodRapidMessageNotice();
        }
        return mInstance;
    }

    public void showFloatWindow(String number) {
        view = LayoutInflater.from(GlobalCache.getContext()).inflate(R.layout.layout_message_fast_food_rapid, null);
        initFloatView();
        WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams();
        mWindowManager = (WindowManager) GlobalCache.getContext().getSystemService(Context.WINDOW_SERVICE);
        // <a>https://android.googlesource.com/platform/frameworks/base/+/dc24f93</a>
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (!Settings.canDrawOverlays(GlobalCache.getContext())) {
                RunTimeLog.addLog(RunTimeLog.OVERLAY_WINDOW, "FastFoodRapidMessageNotice -> showFloatWindow() 无权限返回");
                return;
            }
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_TOAST;
        }

        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.gravity = Gravity.RIGHT | Gravity.TOP;
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.windowAnimations = android.R.style.Animation_Translucent;
        mWindowManager.addView(view, wmParams);
        isShow = true;
        updateFloatWindow(number);
    }

    public void updateFloatWindow(String number) {
        TextView mMessageContentLabel = (TextView) view.findViewById(R.id.mMessageContentLabel);
        mMessageContentLabel.setText("有" + number + "个微信快餐订单，请前往消息中心处理！");
    }

    private void initFloatView() {
        Button mMessageGoCenterBtn = (Button) view.findViewById(R.id.mMessageGoCenterBtn);
        mMessageGoCenterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (BaseActivity.topActivity != null) {
                    MessageV2Fragment.index=5;
                    DriverBus.call("main/closesub");
                    DriverBus.call("main/closesub");
//                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                }
                release();
            }
        });
        Button mMessageCloseBtn = (Button) view.findViewById(R.id.mMessageCloseBtn);
        mMessageCloseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                release();
            }
        });
    }

    private void release() {
        mWindowManager.removeView(view);
        mWindowManager = null;
        mInstance = null;
    }
}
