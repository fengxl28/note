package com.mwee.android.pos.air.business.discount.view;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.air.business.ask.manager.dialog.ChooseMenuClsView;
import com.mwee.android.pos.air.business.discount.processor.DiscountManagerProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuManagerProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/15.
 */

public class EditDiscountFragment extends BaseDialogFragment implements View.OnClickListener {

    private TextView title_tv;

    private EditText dicount_name_edt;
    private EditText rate_edt;

    private TextView menucls_tv;

    private Button cancel_btn;
    private Button submit_btn;

    private OnEditDiscountListener listener;
    private DiscountManagerProcessor mProcessor;

    private DiscountManagerInfo discountManagerInfo;

    private List<String> selectenuClsId = new ArrayList<>();
    private List<MenuTypeBean> allMenuTypeBean = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.edit_dicount_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initUI(view);
        initData();
        initMenuClsView();
    }

    private void initMenuClsView() {
        if (isEditor()) {
            if (discountManagerInfo.ficouponid == 2) {
                selectAllMenuCls();
            } else if (!ListUtil.isEmpty(discountManagerInfo.menuclsList)) {
                selectenuClsId.clear();
                selectenuClsId.addAll(discountManagerInfo.menuclsList);
            } else {
                selectenuClsId.clear();
            }
        } else {
            selectAllMenuCls();
        }
    }

    private void selectAllMenuCls() {
        selectenuClsId.clear();
        if (!ListUtil.isEmpty(allMenuTypeBean)) {
            for (MenuTypeBean menuTypeBean : allMenuTypeBean) {
                selectenuClsId.add(menuTypeBean.fsMenuClsId);
            }

        }
    }

    private void initUI(View view) {
        title_tv = (TextView) view.findViewById(R.id.title_tv);

        dicount_name_edt = (EditText) view.findViewById(R.id.dicount_name_edt);
        rate_edt = (EditText) view.findViewById(R.id.rate_edt);
        menucls_tv = view.findViewById(R.id.menucls_tv);

        cancel_btn = (Button) view.findViewById(R.id.cancel_btn);
        submit_btn = (Button) view.findViewById(R.id.submit_btn);
        cancel_btn.setOnClickListener(this);
        submit_btn.setOnClickListener(this);
        menucls_tv.setOnClickListener(this);
    }

    private void initData() {
        if (isEditor()) {
            title_tv.setText("编辑折扣");
            dicount_name_edt.setText(discountManagerInfo.fsDiscountName);
            rate_edt.setText(String.valueOf(discountManagerInfo.fiDiscountRate));
            menucls_tv.setText(discountManagerInfo.discountClsNameTag);
        } else {
            title_tv.setText("新增折扣");
            menucls_tv.setText("全部");
        }
        initMenuData();
    }


    private void initMenuData() {
        MenuManagerProcessor menuManagerProcessor = new MenuManagerProcessor();
        if (!ListUtil.isEmpty(AppCache.getInstance().firstNodeMap)) {
            for (MenuTypeBean menuTypeBean : AppCache.getInstance().firstNodeMap) {
                if (menuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
                    allMenuTypeBean.add(menuTypeBean);
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cancel_btn:
                dismissSelf();
                break;
            case R.id.submit_btn:
                String name = dicount_name_edt.getText().toString().trim();
                int rate = StringUtil.toInt(rate_edt.getText().toString().trim(), 0);
                int fistatus = 1;
                if (validate(name, rate)) {
                    if (isEditor()) {
                        discountManagerInfo.fsDiscountName = name;
                        discountManagerInfo.fiDiscountRate = rate;
                        discountManagerInfo.fiStatus = fistatus;
                        update(refreshInfo(discountManagerInfo));
                    } else {
                        save(refreshInfo(new DiscountManagerInfo(name, rate, fistatus)));
                    }
                }
                break;
            case R.id.menucls_tv:
                //菜品分类
                ChooseMenuClsView dialog = new ChooseMenuClsView();
                dialog.setParams(allMenuTypeBean, selectenuClsId, onChoosedMenuClsListener);
                dialog.show(getFragmentManagerWithinHost(), "ChooseMenuClsView");
                break;
            default:
                break;
        }
    }

    public DiscountManagerInfo refreshInfo(DiscountManagerInfo info) {
        if (selectedAll()) {
            info.ficouponid = 2;
        } else {
            info.ficouponid = 0;
            info.menuclsList.clear();
            info.menuclsList.addAll(selectenuClsId);
        }
        return info;
    }


    private ChooseMenuClsView.OnChoosedMenuClsListener onChoosedMenuClsListener = new ChooseMenuClsView.OnChoosedMenuClsListener() {

        @Override
        public void onConfirm(final List<String> choosedMenuClsIdList) {
            if (Looper.getMainLooper() != Looper.myLooper()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        onConfirm(choosedMenuClsIdList);
                    }
                });
                return;
            }
            menucls_tv.setText(optClsName(choosedMenuClsIdList));
        }
    };

    /**
     * 表单校验
     *
     * @param name
     * @param rate
     * @return
     */
    private boolean validate(String name, int rate) {
        if (android.text.TextUtils.isEmpty(name)) {
            ToastUtil.showToast("请输入折扣名称");
            return false;
        } else if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("折扣名称输入非法");
            return false;
        }
        if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("折扣名称输入字符非法");
            return false;
        }
        if (rate <= 0) {
            ToastUtil.showToast("请输入折扣率");
            return false;
        }

        return true;
    }

    private void update(DiscountManagerInfo discountManagerInfo) {
        ProgressManager.showProgress(this);
        mProcessor.updateDiscount(discountManagerInfo, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(EditDiscountFragment.this);
                if (result) {
                    listener.onEditorSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "修改折扣失败");
                }
            }
        });
    }

    /**
     * 新增桌台
     */
    private void save(DiscountManagerInfo discountManagerInfo) {
        ProgressManager.showProgress(this);
        mProcessor.addDiscount(discountManagerInfo, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(EditDiscountFragment.this);
                if (result) {
                    listener.onEditorSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "新增折扣失败");
                }
            }
        });
    }

    private String optClsName(List<String> clsList) {
        selectenuClsId.clear();
        if (ListUtil.isEmpty(clsList)) {
            return "无";
        }
        selectenuClsId.addAll(clsList);
        if (selectedAll()) {
            return "全部";
        }
        StringBuilder stringBuilder = new StringBuilder();
        MenuTypeBean menuTypeBean;
        for (String id : clsList) {
            menuTypeBean = AppCache.getInstance().fullDataMap.get(id);
            if (menuTypeBean != null) {
                stringBuilder.append(menuTypeBean.fsMenuClsName).append(",");
            }
        }

        String result = stringBuilder.toString();
        if (TextUtils.validate(result)) {
            result = result.substring(0, result.length() - 1);
        }

        return result;
    }

    private boolean selectedAll() {
        return selectenuClsId.size() == allMenuTypeBean.size();
    }

    public void setParam(DiscountManagerProcessor mProcessor) {
        setParam(mProcessor, null);
    }

    public void setParam(DiscountManagerProcessor mProcessor, DiscountManagerInfo discountManagerInfo) {
        this.mProcessor = mProcessor;
        this.discountManagerInfo = discountManagerInfo;
    }

    private boolean isEditor() {
        return discountManagerInfo != null;
    }

    public interface OnEditDiscountListener {
        void onEditorSuccess();
    }

    public void setOnEditDiscountListener(OnEditDiscountListener listener) {
        this.listener = listener;
    }
}
