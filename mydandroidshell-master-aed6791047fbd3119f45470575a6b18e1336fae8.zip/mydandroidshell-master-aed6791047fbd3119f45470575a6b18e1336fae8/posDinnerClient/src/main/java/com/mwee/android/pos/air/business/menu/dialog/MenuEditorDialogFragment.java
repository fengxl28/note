package com.mwee.android.pos.air.business.menu.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.mwee.android.air.connect.business.menu.MenuItemAddResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.menu.processor.MenuProcessor;
import com.mwee.android.pos.air.business.utils.PriceInputFilter;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.HelpCodeUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * 菜品编辑dialog
 * 1.新增菜品
 * 2.修改菜品
 * Created by qinwei on 2017/10/11.
 */
public class MenuEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mAskEditorTitleLabel;
    private EditText mMenuEditorNameEdt;
    private EditText mMenuEditorUnitNameEdt;
    private EditText mMenuEditorPriceEdt;
    private EditText mMenuEditorMemberPriceEdt;
    private EditText mMenuEditorRepertoryNumberEdt;
    //private CheckBox mMenuSupportWeightCB;
    private Button mAskEditorCancelBtn;
    private Button mAskEditorConfirmBtn;
    private String menuClsId;

    private MenuItemBean menuItemBean;

    private MenuProcessor menuProcessor;
    private OnMenuEditorListener listener;
    private Spinner mMenuClsSpinner;
    private CommonAdapter<MenuClsBean> menuClsAdapter;
    private List<MenuClsBean> menuClsBeanList = new ArrayList<>();

    private CheckBox tvCanDiscount;
    private CheckBox tvCanGift;
    private CheckBox tvCanTimePrice;
    private CheckBox tvCanWeight;
    private CheckBox tvCanOutTake;
    private CheckBox tvCanPrinter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        isCloseKeyboard = true;
        return inflater.inflate(R.layout.fragment_menu_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.mRoot).setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mAskEditorTitleLabel = (TextView) view.findViewById(R.id.mAskEditorTitleLabel);
        mMenuEditorNameEdt = (EditText) view.findViewById(R.id.mMenuEditorNameEdt);
        mMenuEditorUnitNameEdt = (EditText) view.findViewById(R.id.mMenuEditorUnitNameEdt);
        mMenuEditorPriceEdt = (EditText) view.findViewById(R.id.mMenuEditorPriceEdt);
        mMenuEditorMemberPriceEdt = (EditText) view.findViewById(R.id.mMenuEditorMemberPriceEdt);
        mMenuEditorRepertoryNumberEdt = (EditText) view.findViewById(R.id.mMenuEditorRepertoryNumberEdt);

        mAskEditorCancelBtn = (Button) view.findViewById(R.id.mAskEditorCancelBtn);
        mAskEditorConfirmBtn = (Button) view.findViewById(R.id.mAskEditorConfirmBtn);
        mMenuClsSpinner = (Spinner) view.findViewById(R.id.mMenuClsSpinner);

        //属性
        tvCanDiscount = view.findViewById(R.id.tvCanDiscount);
        tvCanGift = view.findViewById(R.id.tvCanGift);
        tvCanTimePrice = view.findViewById(R.id.tvCanTimePrice);
        tvCanWeight = view.findViewById(R.id.tvCanWeight);
        tvCanOutTake = view.findViewById(R.id.tvCanOutTake);
        tvCanPrinter = view.findViewById(R.id.tvCanPrinter);

        mAskEditorCancelBtn.setOnClickListener(this);
        mAskEditorConfirmBtn.setOnClickListener(this);

        mMenuEditorPriceEdt.setFilters(new InputFilter[]{new PriceInputFilter()});
        mMenuEditorMemberPriceEdt.setFilters(new InputFilter[]{new PriceInputFilter()});

        mMenuEditorNameEdt.addTextChangedListener(textWatcher);
        mMenuEditorUnitNameEdt.addTextChangedListener(textWatcher);
        mMenuEditorPriceEdt.addTextChangedListener(textWatcher);
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            String name = mMenuEditorNameEdt.getText().toString();
            String unitName = mMenuEditorUnitNameEdt.getText().toString();
            String price = mMenuEditorPriceEdt.getText().toString();
            if (com.mwee.android.pos.util.TextUtils.validate(name, unitName, price)) {
                mAskEditorConfirmBtn.setEnabled(true);
            } else {
                mAskEditorConfirmBtn.setEnabled(false);
            }
        }
    };

    private void initData() {
        if (isEditorMode()) {
            mAskEditorTitleLabel.setText("编辑菜品");
            mMenuEditorNameEdt.setText(menuItemBean.fsItemName);
            mMenuEditorUnitNameEdt.setText(menuItemBean.fsOrderUint);
            mMenuEditorPriceEdt.setText(Calc.formatShow(menuItemBean.fdSalePrice, RoundConfig.ROUND_SINGLE_PRICE));
            mMenuEditorMemberPriceEdt.setText(Calc.formatShow(menuItemBean.fdVIPPrice, RoundConfig.ROUND_SINGLE_PRICE));
            BigDecimal num = AppCache.getInstance().getSelloutNum(menuItemBean.fiOrderUintCd);
            if (num.compareTo(BigDecimal.ZERO) >= 0) {
                mMenuEditorRepertoryNumberEdt.setText(num + "");
            }
            //mMenuSupportWeightCB.setChecked(menuItemBean.fiIsEditQty == 1);
            tvCanDiscount.setChecked(menuItemBean.fiIsDiscount == 1);
            tvCanGift.setChecked(menuItemBean.fiIsGift == 1);
            tvCanTimePrice.setChecked(menuItemBean.fiIsEditPrice == 1);
            tvCanWeight.setChecked(menuItemBean.fiIsEditQty == 1);
            //tvCanDiscount.setChecked(menuItemBean.fiIsDiscount == 1);
            tvCanOutTake.setChecked(menuItemBean.fiIsTakeAway == 1);
            tvCanPrinter.setChecked(menuItemBean.fiIsPrn == 1);


        } else {
            mAskEditorTitleLabel.setText("新增菜品");
            mAskEditorConfirmBtn.setEnabled(false);
        }
        menuProcessor = new MenuProcessor();
        menuClsAdapter = new CommonAdapter<MenuClsBean>(getContext(), menuClsBeanList, R.layout.simple_spinner_item) {
            @Override
            public void convert(ViewHolder viewHolder, MenuClsBean data, int position) {
                ((TextView) viewHolder.getConvertView()).setText(data.fsMenuClsName);
            }
        };
        mMenuClsSpinner.setAdapter(menuClsAdapter);
        int position = 0;
        for (int i = 0; i < menuClsBeanList.size(); i++) {
            if (TextUtils.equals(menuClsBeanList.get(i).fsMenuClsId, menuClsId)) {
                position = i;
            }
        }
        mMenuClsSpinner.setSelection(position);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mAskEditorCancelBtn:
                dismissSelf();
                break;
            case R.id.mAskEditorConfirmBtn:
                doConfirm();
                break;
            default:
                break;
        }
    }

    private void doConfirm() {
        final String name = mMenuEditorNameEdt.getText().toString().trim();
        final String unitName = mMenuEditorUnitNameEdt.getText().toString().trim();
        final String price = mMenuEditorPriceEdt.getText().toString().trim();
        final String memberPrice = mMenuEditorMemberPriceEdt.getText().toString().trim();
        final String repertoryNumber = mMenuEditorRepertoryNumberEdt.getText().toString().trim();

        final boolean isCanDiscount = tvCanDiscount.isChecked();
        final boolean isCanGift = tvCanGift.isChecked();
        final boolean isCanTimePrice = tvCanTimePrice.isChecked();
        final boolean isCanWeight = tvCanWeight.isChecked();
        final boolean isCanOutTake = tvCanOutTake.isChecked();
        final boolean isCanPrinter = tvCanPrinter.isChecked();

        /**
         * 可手机点菜 和可打印暂时没有
         */
        //final boolean isCanPhone = tvCanPhone.isChecked();


        menuClsId = ((MenuClsBean) mMenuClsSpinner.getSelectedItem()).fsMenuClsId;
        if (!checkInput(name, unitName, price, memberPrice, repertoryNumber)) {
            return;
        }
      /*  if (mMenuClsSpinner.getSelectedItemPosition() == 0) {
            ToastUtil.showToast("请选择菜品分类");
            return;
        }*/
        if (isEditorMode()) {
            final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
            menuProcessor.loadUpdateMenuInfo(menuItemBean.fiItemCd, menuClsId, menuItemBean.fiOrderUintCd, name, unitName, price, memberPrice, repertoryNumber
                    , isCanDiscount, isCanGift, isCanTimePrice, isCanWeight, isCanOutTake, isCanPrinter
                    , new ResultCallback<String>() {
                        @Override
                        public void onSuccess(String data) {
                            progress.dismissSelf();
                            ToastUtil.showToast(data);
                            menuItemBean.fsMenuClsId = menuClsId;
                            menuItemBean.fdSalePrice = new BigDecimal(price);
                            menuItemBean.fsItemName = name;

                            menuItemBean.fiIsDiscount = isCanDiscount ? 1 : 0;
                            menuItemBean.fiIsGift = isCanGift ? 1 : 0;
                            menuItemBean.fiIsEditPrice = isCanTimePrice ? 1 : 0;
                            menuItemBean.fiIsEditQty = isCanWeight ? 1 : 0;
                            menuItemBean.fiIsTakeAway = isCanOutTake ? 1 : 0;
                            menuItemBean.fiIsPrn = isCanPrinter ? 1 : 0;

                            menuItemBean.fdVIPPrice = TextUtils.isEmpty(memberPrice) ? menuItemBean.fdSalePrice : new BigDecimal(memberPrice);
                            menuItemBean.fdInvQty = TextUtils.isEmpty(repertoryNumber) ? BigDecimal.ZERO : new BigDecimal(repertoryNumber);
                            menuItemBean.fsOrderUint = unitName;
                            menuItemBean.fsHelpCode = HelpCodeUtil.createHelpCode(menuItemBean.fsItemName);
                            listener.onMenuUpdateSuccess(menuItemBean);
                            dismissSelf();
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            progress.dismissSelf();
                            ToastUtil.showToast(msg);
                        }
                    });
        } else {
            final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
            menuProcessor.loadAddMenuInfo(menuClsId, name, unitName, price, memberPrice, repertoryNumber
                    , isCanDiscount, isCanGift, isCanTimePrice, isCanWeight, isCanOutTake, isCanPrinter
                    , new ResultCallback<MenuItemAddResponse>() {
                        @Override
                        public void onSuccess(MenuItemAddResponse data) {

                            /**
                             * 构建临时的bean
                             */
                            MenuItemBean menuItemBean = new MenuItemBean();
                            menuItemBean.fsMenuClsId = menuClsId;
                            menuItemBean.fdSalePrice = new BigDecimal(price);
                            menuItemBean.fsItemName = name;

                            menuItemBean.fiIsDiscount = isCanDiscount ? 1 : 0;
                            menuItemBean.fiIsGift = isCanGift ? 1 : 0;
                            menuItemBean.fiIsEditPrice = isCanTimePrice ? 1 : 0;
                            menuItemBean.fiIsEditQty = isCanWeight ? 1 : 0;
                            menuItemBean.fiIsTakeAway = isCanOutTake ? 1 : 0;
                            menuItemBean.fiIsPrn = isCanPrinter ? 1 : 0;

                            menuItemBean.fdVIPPrice = TextUtils.isEmpty(memberPrice) ? menuItemBean.fdSalePrice : new BigDecimal(memberPrice);
                            menuItemBean.fdInvQty = TextUtils.isEmpty(repertoryNumber) ? BigDecimal.ZERO : new BigDecimal(repertoryNumber);
                            menuItemBean.fsOrderUint = unitName;

                            progress.dismissSelf();
                            listener.onMenuAddSuccess(data.menuItem, menuItemBean);
                            dismissSelf();
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            progress.dismissSelf();
                            ToastUtil.showToast(msg);
                        }
                    });

        }
        dismissSelf();
    }


    private boolean checkInput(String name, String unitName, String price, String memberPrice, String repertoryNumber) {
        if (TextUtils.isEmpty(name)) {
            ToastUtil.showToast(" 菜品名称不能为空");
            return false;
        } else if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast(" 菜品名称输入字符非法");
            return false;
        } else if (TextUtils.isEmpty(unitName)) {
            ToastUtil.showToast("菜品规格不能为空");
            return false;
        } else if (!RegexUtil.checkName(unitName)) {
            ToastUtil.showToast(" 菜品规格输入字符非法");
            return false;
        } else if (TextUtils.isEmpty(price)) {
            ToastUtil.showToast("菜品价格不能为空");
            return false;
        }
        return true;
    }

    public void setParam(String fsMenuClsId, List<MenuClsBean> menuClsBeanList) {
        this.menuClsId = fsMenuClsId;
        this.menuClsBeanList.clear();
        this.menuClsBeanList.addAll(menuClsBeanList);
        //buildChoiceHint();
    }

    public void setParam(MenuItemBean menuItemBean, List<MenuClsBean> menuClsBeanList) {
        this.menuClsId = menuItemBean.fsMenuClsId;
        this.menuItemBean = menuItemBean;
        this.menuClsBeanList.clear();
        this.menuClsBeanList.addAll(menuClsBeanList);
        //buildChoiceHint();
    }

    /*public void buildChoiceHint() {
        MenuClsBean menuClsBean = new MenuClsBean();
        menuClsBean.fsMenuClsId = "hint";
        menuClsBean.fsMenuClsName = "请选择";
        menuClsBeanList.add(0, menuClsBean);
    }*/


    /**
     * 是否是修改菜品
     *
     * @return
     */
    public boolean isEditorMode() {
        return menuItemBean != null;
    }

    public void setOnMenuEditorListener(OnMenuEditorListener listener) {
        this.listener = listener;
    }

    public interface OnMenuEditorListener {
        void onMenuUpdateSuccess(MenuItemBean bean);

        void onMenuAddSuccess(MenuItem menuItem, MenuItemBean bean);
    }


}