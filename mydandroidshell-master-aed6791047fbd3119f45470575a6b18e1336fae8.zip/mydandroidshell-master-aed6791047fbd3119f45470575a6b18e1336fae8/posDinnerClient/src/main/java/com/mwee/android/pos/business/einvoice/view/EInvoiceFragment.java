package com.mwee.android.pos.business.einvoice.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.business.einvoice.api.InvoiceConnectInfoResponse;
import com.mwee.android.pos.business.einvoice.api.InvoiceIsActiveResponse;
import com.mwee.android.pos.business.einvoice.api.InvoiceRateResponse;
import com.mwee.android.pos.business.einvoice.model.InvoiceConnectStatusBean;
import com.mwee.android.pos.business.einvoice.model.InvoiceConnectStatusThirdBean;
import com.mwee.android.pos.business.einvoice.model.InvoiceConnectStatusViceBean;
import com.mwee.android.pos.business.einvoice.model.InvoiceRateBean;
import com.mwee.android.pos.business.einvoice.model.IsInvoiceActiveBean;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;

/**
 * author:luoshenghua
 * create on:2018/4/26
 * description:setting-电子发票入口
 */
public class EInvoiceFragment extends BaseFragment implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    public static final String TAG = "EInvoiceFragment";

    private EInvoiceStatusRefreshView mEInvoiceStatusRefreshView;
    // 美易点3.1去掉秒付开票入口
    private Switch /*mSwElectronicInvoice,*/ mSwitchPrintQRAuto, mSwitchPrintQRInBillManage;
    private View /*mInvoiceQRPayLL, */mInvoiceQRPrintLL;
    //    private TextView mTvTipsEinvoiceRapidPay;
    private View ll_invoice_date_line;
    private TextView tv_invoice_date;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_invoice, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        getIsInvoiceActive();
    }

    private void initView(View rootView) {
        mEInvoiceStatusRefreshView = rootView.findViewById(R.id.fl_invoice_status_refresh_view);
        mEInvoiceStatusRefreshView.setParams(EInvoiceFragment.this);
        // 美易点3.1去掉秒付开票入口
//        mInvoiceQRPayLL = rootView.findViewById(R.id.ll_invoice_qr_pay);
//        mSwElectronicInvoice = rootView.findViewById(R.id.switch_electronic_invoice);
//        mTvTipsEinvoiceRapidPay = rootView.findViewById(R.id.tv_tips_einvoice_rapid_pay);
        mInvoiceQRPrintLL = rootView.findViewById(R.id.ll_invoice_qr_print);
        mSwitchPrintQRAuto = rootView.findViewById(R.id.switch_print_qr_auto);
        mSwitchPrintQRInBillManage = rootView.findViewById(R.id.switch_print_qr_in_bill_manage);
        ll_invoice_date_line = rootView.findViewById(R.id.ll_invoice_date_line);
        tv_invoice_date = rootView.findViewById(R.id.tv_invoice_date);
        rootView.findViewById(R.id.tv_refresh_date).setOnClickListener(this);

        // 初始化到期时间显示
        Pair<String, IsInvoiceActiveBean> lastEInvoiceDateInfo = SettingProcessor.getLastEInvoiceDateInfo();
        if (!TextUtils.isEmpty(lastEInvoiceDateInfo.first)) {
            refreshInvoiceDate(lastEInvoiceDateInfo.first);
        }
    }

    /**
     * 请求获取是否已开通电子发票
     */
    private void getIsInvoiceActive() {
        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        final Progress progress = ProgressManager.showProgressUncancel(this, "请稍候...");
        ActionLog.addLog("电子发票->请求获取是否开已通电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
        EInvoiceProcess.isInvoiceActive(shopId, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                boolean isActive = false;
                if (responseData.responseBean instanceof InvoiceIsActiveResponse) {
                    InvoiceIsActiveResponse invoiceIsActiveResponse = (InvoiceIsActiveResponse) responseData.responseBean;
                    if (invoiceIsActiveResponse != null) {
                        if (invoiceIsActiveResponse.errno != 0) {
                            progress.dismiss();
                            ActionLog.addLog("电子发票->是否开已通->服务器连接失败", "", "", ActionLog.SS_MORE_JOIN, "");
                            invoiceOffline();
                            return;
                        } else {
                            IsInvoiceActiveBean isInvoiceActiveBean = invoiceIsActiveResponse.data;
                            if (isInvoiceActiveBean != null) {
                                if (TextUtils.equals("Y", isInvoiceActiveBean.state)) {
                                    isActive = true;

                                    // 刷新电子发票到期时间
                                    refreshInvoiceDate(isInvoiceActiveBean.end_date);
                                    SettingProcessor.saveEInvoiceDateInfo(DateUtil.getCurrentDate("yyyy-MM-dd"), isInvoiceActiveBean);
                                }
                            } else {
                                ActionLog.addLog("电子发票->errno=" + invoiceIsActiveResponse.errno + "|errmsg=" + invoiceIsActiveResponse.errmsg, "", "", ActionLog.SS_MORE_JOIN, "");
                            }
                        }
                    }
                }

                if (isActive) {
                    ActionLog.addLog("电子发票->已开通电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
                    getInvoiceConnectStatus(progress, shopId);
                } else {
                    progress.dismiss();
                    ActionLog.addLog("电子发票->未开通电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
                    invoiceNotApply();
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                progress.dismiss();
                invoiceNotApply();
                return false;
            }
        });
    }

    /**
     * 请求获取票通宝连接状态
     */
    private void getInvoiceConnectStatus(Progress progress, String shopId) {
        ActionLog.addLog("电子发票->请求获取票通宝连接状态", "", "", ActionLog.SS_MORE_JOIN, "");
        EInvoiceProcess.invoiceConnectInfo(shopId, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                boolean online = false;
                if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceConnectInfoResponse) {
                    InvoiceConnectInfoResponse invoiceConnectInfoResponse = (InvoiceConnectInfoResponse) responseData.responseBean;
                    if (invoiceConnectInfoResponse != null) {
                        InvoiceConnectStatusBean invoiceConnectStatusBean = invoiceConnectInfoResponse.data;
                        if (invoiceConnectStatusBean != null) {
                            InvoiceConnectStatusViceBean invoiceConnectStatusViceBean = invoiceConnectStatusBean.data;
                            if (invoiceConnectStatusViceBean != null) {
                                ArrayList<InvoiceConnectStatusThirdBean> invoiceConnectStatusThirdBeanList = invoiceConnectStatusViceBean.list;
                                if (invoiceConnectStatusThirdBeanList != null) {
                                    for (int i = 0; i < invoiceConnectStatusThirdBeanList.size(); i++) {
                                        InvoiceConnectStatusThirdBean invoiceConnectStatusThirdBean = invoiceConnectStatusThirdBeanList.get(i);
                                        if (invoiceConnectStatusThirdBean != null) {
                                            //默认税盘号与分机号确定已连接的设备
                                            if (TextUtils.equals(invoiceConnectStatusViceBean.tax_tray_no, invoiceConnectStatusThirdBean.extensionNum)) {
                                                //extensionStatus:"0"表示已连接，"1"表示未连接.
                                                if (TextUtils.equals("0", invoiceConnectStatusThirdBean.extensionStatus)) {
                                                    online = true;
                                                } else {
                                                    ActionLog.addLog("电子发票->票通宝离线 status=" + invoiceConnectStatusThirdBean.extensionStatus, "", "", ActionLog.SS_MORE_JOIN, "");
                                                }
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (online) {
                    ActionLog.addLog("电子发票->票通宝已连接", "", "", ActionLog.SS_MORE_JOIN, "");
                    getInvoiceNumAndRate(progress, shopId);
                } else {
                    progress.dismiss();
                    ActionLog.addLog("电子发票->票通宝未连接", "", "", ActionLog.SS_MORE_JOIN, "");
                    invoiceOffline();
                }

            }

            @Override
            public boolean fail(ResponseData responseData) {
                progress.dismiss();
                invoiceOffline();
                return false;
            }
        });
    }

    /**
     * 请求获取电子发票的库存及税率
     */
    private void getInvoiceNumAndRate(Progress progress, String shopId) {
        ActionLog.addLog("电子发票->请求获取电子发票的库存及税率", "", "", ActionLog.SS_MORE_JOIN, "");
        //获取税率
        EInvoiceProcess.getInvoiceNumAndRate(shopId, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                progress.dismiss();
                //已经是MainThread.
                boolean isGetSuccess = false;
                if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceRateResponse) {
                    InvoiceRateResponse invoiceRateResponse = (InvoiceRateResponse) responseData.responseBean;
                    if (invoiceRateResponse != null) {
                        InvoiceRateBean invoiceRateBean = invoiceRateResponse.data;
                        if (invoiceRateBean != null) {
                            isGetSuccess = true;
                            ActionLog.addLog("电子发票->税率和库存获取成功 stock=" + invoiceRateBean.stock + "|taxRate=" + invoiceRateBean.taxRate, "", "", ActionLog.SS_MORE_JOIN, "");
                            invoiceOnline(invoiceRateBean.stock, invoiceRateBean.taxRate);
                            // 美易点3.1去掉秒付开票入口
//                            getInvoiceSwitchStatus(shopId);
                        }
                    }
                }
                if (!isGetSuccess) {
                    invoiceOffline();
                    ActionLog.addLog("电子发票->税率和库存获取失败", "", "", ActionLog.SS_MORE_JOIN, "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                progress.dismiss();
                invoiceOffline();
                return false;
            }
        });
    }

    /**
     * 美易点3.1去掉秒付开票入口
     *
     * 请求获取秒付开具电子发票开关状态
     */
    /*private void getInvoiceSwitchStatus(String shopId) {
        //获取秒付开具发票开关状态
        ActionLog.addLog("电子发票->请求获取秒付开具电子发票开关状态", "", "", ActionLog.SS_MORE_JOIN, "");
        String[] shopIds = new String[]{shopId};
        EInvoiceProcess.getInvoiceSwitchStatus(shopIds, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                boolean switchOn = false;
                if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceSwitchStatusGetResponse) {
                    InvoiceSwitchStatusGetResponse invoiceSwitchStatusGetResponse = (InvoiceSwitchStatusGetResponse) responseData.responseBean;
                    if (invoiceSwitchStatusGetResponse.data != null) {
                        InvoiceSwitchStatusGetBean statusBean = invoiceSwitchStatusGetResponse.data;
                        ArrayList<InvoiceSwitchStatusGetViceBean> dataList = statusBean.dataList;
                        if (dataList != null) {
                            for (int i = 0; i < dataList.size(); i++) {
                                InvoiceSwitchStatusGetViceBean viceBean = dataList.get(i);
                                if (viceBean != null) {
                                    if (TextUtils.equals(viceBean.shopId, shopId)) {
                                        if (TextUtils.equals(viceBean.fapiaoEnable, "2")) {
                                            switchOn = true;
                                            mSwElectronicInvoice.setChecked(true);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }

                }
                if (switchOn) {
                    mTvTipsEinvoiceRapidPay.setText(R.string.tips_einvoice_rapid_pay_close);
                    ActionLog.addLog("电子发票->秒付开具电子发票开关为开启状态", "", "", ActionLog.SS_MORE_JOIN, "");
                } else {
                    mTvTipsEinvoiceRapidPay.setText(R.string.tips_einvoice_rapid_pay_open);
                    ActionLog.addLog("电子发票->秒付开具电子发票开关为关闭状态", "", "", ActionLog.SS_MORE_JOIN, "");
                }
                //请求回来setChecked之后设置Listener,防止触发onCheckedChanged.
                mSwElectronicInvoice.setOnCheckedChangeListener(EInvoiceFragment.this);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                mSwElectronicInvoice.setChecked(false);
                mTvTipsEinvoiceRapidPay.setText(R.string.tips_einvoice_rapid_pay_open);
                //请求回来setChecked之后设置Listener,防止触发onCheckedChanged.
                mSwElectronicInvoice.setOnCheckedChangeListener(EInvoiceFragment.this);
                return false;
            }
        });
    }*/

    /**
     * 美易点3.1去掉秒付开票入口
     *
     * 请求更新秒付开具电子发票开关状态
     */
    /*private void updateInvoiceSwitchStatus(boolean isChecked) {
        //先设置为null，请求回来setChecked之后设置Listener,防止自动触发onCheckedChanged再次执行以下请求.
        mSwElectronicInvoice.setOnCheckedChangeListener(null);

        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        EInvoiceProcess.updateInvoiceSwitchStatus(shopId, isChecked, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceSwitchStatusUpdateResponse) {
                    InvoiceSwitchStatusUpdateResponse invoiceSwitchStatusUpdateResponse = (InvoiceSwitchStatusUpdateResponse) responseData.responseBean;
                    if (invoiceSwitchStatusUpdateResponse != null) {
                        if (0 != invoiceSwitchStatusUpdateResponse.errno) {
                            //更新失败.
                            if (!TextUtils.isEmpty(invoiceSwitchStatusUpdateResponse.errmsg)) {
                                ToastUtil.showToast(invoiceSwitchStatusUpdateResponse.errmsg);
                            }
                            mSwElectronicInvoice.setChecked(false);
                        }
                    }

                }
                mSwElectronicInvoice.setOnCheckedChangeListener(EInvoiceFragment.this);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceSwitchStatusUpdateResponse) {
                    InvoiceSwitchStatusUpdateResponse invoiceSwitchStatusUpdateResponse = (InvoiceSwitchStatusUpdateResponse) responseData.responseBean;
                    if (invoiceSwitchStatusUpdateResponse != null) {
                        if (!TextUtils.isEmpty(invoiceSwitchStatusUpdateResponse.errmsg)) {
                            ToastUtil.showToast(invoiceSwitchStatusUpdateResponse.errmsg);
                        }
                    }

                }
                mSwElectronicInvoice.setChecked(false);
                mSwElectronicInvoice.setOnCheckedChangeListener(EInvoiceFragment.this);
                return false;
            }
        });
    }*/

    /**
     * 票通宝已连接
     */
    private void invoiceOnline(int num, int rate) {
        mEInvoiceStatusRefreshView.showInvoiceOnline(num, rate);
        // 美易点3.1去掉秒付开票入口
//        mInvoiceQRPayLL.setVisibility(View.VISIBLE);
        mInvoiceQRPrintLL.setVisibility(View.VISIBLE);

        mSwitchPrintQRAuto.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "0"), "1"));
        mSwitchPrintQRInBillManage.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "0"), "1"));

        mSwitchPrintQRAuto.setOnCheckedChangeListener(this);
        mSwitchPrintQRInBillManage.setOnCheckedChangeListener(this);
    }

    private void refreshInvoiceDate(String dateStr) {
        ll_invoice_date_line.setVisibility(View.VISIBLE);
        tv_invoice_date.setText("服务到期时间：" + dateStr);
    }

    /**
     * 票通宝连接异常
     */
    private void invoiceOffline() {
        mEInvoiceStatusRefreshView.showInvoiceOffline();
        // 美易点3.1去掉秒付开票入口
//        mInvoiceQRPayLL.setVisibility(View.GONE);
//        mSwElectronicInvoice.setOnCheckedChangeListener(null);
        mInvoiceQRPrintLL.setVisibility(View.GONE);
        mSwitchPrintQRAuto.setOnCheckedChangeListener(null);
        mSwitchPrintQRInBillManage.setOnCheckedChangeListener(null);
    }

    /**
     * 未开通电子发票
     */
    private void invoiceNotApply() {
        mEInvoiceStatusRefreshView.showInvoiceNotApply();
        // 美易点3.1去掉秒付开票入口
//        mInvoiceQRPayLL.setVisibility(View.GONE);
//        mSwElectronicInvoice.setOnCheckedChangeListener(null);
        mInvoiceQRPrintLL.setVisibility(View.GONE);
        mSwitchPrintQRAuto.setOnCheckedChangeListener(null);
        mSwitchPrintQRInBillManage.setOnCheckedChangeListener(null);

        ll_invoice_date_line.setVisibility(View.GONE);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (buttonView.getId()) {
            // 美易点3.1去掉秒付开票入口
//            case R.id.switch_electronic_invoice:
//                if (isChecked) {//打开
//                    mTvTipsEinvoiceRapidPay.setText(R.string.tips_einvoice_rapid_pay_close);
//                    ActionLog.addLog("更多设置->电子发票->点击了开启秒付开具电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
//                } else {// 关闭
//                    mTvTipsEinvoiceRapidPay.setText(R.string.tips_einvoice_rapid_pay_open);
//                    ActionLog.addLog("更多设置->电子发票->点击了关闭秒付开具电子发票", "", "", ActionLog.SS_MORE_JOIN, "");
//                }
//                updateInvoiceSwitchStatus(isChecked);
//                break;
            case R.id.switch_print_qr_auto:
                if (isChecked) {//打开
                    ActionLog.addLog("更多设置->电子发票->点击了开启结账时小票自动打印开票二维码", "", "", ActionLog.SS_MORE_JOIN, "");
                    SettingProcessor.refreshSettingStatus(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "1");
                } else {// 关闭
                    ActionLog.addLog("更多设置->电子发票->点击了关闭结账时小票自动打印开票二维码", "", "", ActionLog.SS_MORE_JOIN, "");
                    SettingProcessor.refreshSettingStatus(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "0");
                }
                break;
            case R.id.switch_print_qr_in_bill_manage:
                if (isChecked) {//打开
                    ActionLog.addLog("更多设置->电子发票->点击了开启账单管理中结账小票打印开票二维码", "", "", ActionLog.SS_MORE_JOIN, "");
                    SettingProcessor.refreshSettingStatus(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "1");
                } else {// 关闭
                    ActionLog.addLog("更多设置->电子发票->点击了关闭账单管理中结账小票打印开票二维码", "", "", ActionLog.SS_MORE_JOIN, "");
                    SettingProcessor.refreshSettingStatus(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "0");
                }
                break;
        }
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tv_refresh_date:
                ActionLog.addLog("更多设置->电子发票->点击了手动刷新电子发票到期时间", "", "", ActionLog.SS_MORE_JOIN, "");
                getIsInvoiceActive();
                break;
        }
    }
}
