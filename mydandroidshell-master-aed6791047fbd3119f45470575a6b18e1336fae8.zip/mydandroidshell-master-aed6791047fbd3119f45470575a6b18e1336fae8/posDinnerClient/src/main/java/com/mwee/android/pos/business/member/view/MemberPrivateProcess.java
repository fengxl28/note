package com.mwee.android.pos.business.member.view;

import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;

import java.util.ArrayList;
import java.util.List;

/**
 * MemberPrivateProcess
 *
 * @author ZM
 * @date 17/2/22
 */
public class MemberPrivateProcess {

    /**
     * 构建固定的会员数据
     * @param privateModels CRM数据
     */
    public static List<MemberPrivateModel> buildSolidMemberPrivateD(List<MemberPrivateModel> privateModels){

        //构建会员特权
        List<MemberPrivateModel> list = new ArrayList();
        if(!privateModels.isEmpty()){
            list.addAll(privateModels);
        }

        //加入菜品会员价
        MemberPrivateModel modelDiscount = new MemberPrivateModel();
        modelDiscount.title = "菜品会员价";
        modelDiscount.category = 2;
        list.add(0,modelDiscount);

        //加入会员特价数据
        MemberPrivateModel modelPrice = new MemberPrivateModel();
        modelPrice.title = "会员折扣";
        modelPrice.category = 1;
        list.add(0,modelPrice);

       return list;
    }

    public static List<MemberPrivateDetailModel.CardPrivilege> creatDefaultData(){
        List<MemberPrivateDetailModel.CardPrivilege> data = new ArrayList<>();
        //加入菜品会员价
        MemberPrivateDetailModel.CardPrivilege modelDiscount = new MemberPrivateDetailModel.CardPrivilege();
        modelDiscount.title = "菜品会员价";
        modelDiscount.priv_type = -1;
        data.add(modelDiscount);

        //加入会员特价数据
        MemberPrivateDetailModel.CardPrivilege modelPrice = new MemberPrivateDetailModel.CardPrivilege();
        modelPrice.title = "会员折扣";
        modelPrice.priv_type = 2;
        data.add(modelPrice);
        return data;
    }
}
