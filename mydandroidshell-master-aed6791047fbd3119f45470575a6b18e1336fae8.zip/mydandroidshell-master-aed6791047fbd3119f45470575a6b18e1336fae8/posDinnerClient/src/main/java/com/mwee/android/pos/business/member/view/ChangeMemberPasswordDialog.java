package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardInfoModel;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by liuxiuxiu on 2018/02/24.
 */

public class ChangeMemberPasswordDialog extends BaseDialogFragment implements View.OnClickListener {
    private EditText mPsdEdt;
    private EditText mPsdConfirmEdt;

    private Button mCancelBtn;
    private Button mChangeConfirmBtn;

    private MemberEditorProcessor mMemberEditorProcessor;

    private MemberCardInfoModel cardModel;
    private String mCardId;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_change_password_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
//        if (cardModel == null) {
//            dismissSelf();
//        }
        initView(view);
        initData();
    }

    private void initView(View view) {

        mPsdEdt = (EditText) view.findViewById(R.id.mPsdEdt);
        mPsdConfirmEdt = (EditText) view.findViewById(R.id.mPsdConfirmEdt);

        mCancelBtn = (Button) view.findViewById(R.id.mCancelBtn);
        mChangeConfirmBtn = (Button) view.findViewById(R.id.mChangeConfirmBtn);

        mCancelBtn.setOnClickListener(this);
        mChangeConfirmBtn.setOnClickListener(this);
    }


    private void initData() {
        mMemberEditorProcessor = new MemberEditorProcessor();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mChangeConfirmBtn:
                final String psd = mPsdEdt.getText().toString().trim();
                final String psdConfirm = mPsdConfirmEdt.getText().toString().trim();

                if (check(psd, psdConfirm)) {
                    doChangeMemberPassword(psd);
                }
                break;
            case R.id.mCancelBtn:
                dismissSelf();
                break;
            default:
                break;
        }
    }

    /**
     * 修改支付密码
     *
     * @param psd
     */
    private void doChangeMemberPassword(String psd) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        /*mMemberEditorProcessor.doChangeMemberPassword(cardModel, psd, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                ToastUtil.showToast("修改成功");
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });*/

        ClientMemberApi.changeMemberPsw(mCardId, psd, new SocketCallback<Boolean>() {
            @Override
            public void callback(SocketResponse<Boolean> response) {
                progress.dismiss();
                if(response != null && response.success()){
                    ToastUtil.showToast("修改成功");
                    dismissSelf();
                }else{
                    String msg = "网络超时，请重试";
                    if(response != null && !TextUtils.isEmpty(response.message)){
                        msg = response.message;
                    }
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    private boolean check(String psd, String psdConfirm) {
        if (TextUtils.isEmpty(psd)) {
            ToastUtil.showToast("请输入六位数字的支付密码");
            return false;
        }
        if (psd.length() != 6) {
            ToastUtil.showToast("请输入六位数字的支付密码");
            return false;
        }

        if (TextUtils.isEmpty(psdConfirm)) {
            ToastUtil.showToast("请输入确认密码");
            return false;
        }

        if (!TextUtils.equals(psd, psdConfirm)) {
            ToastUtil.showToast("支付密码和确认密码不一致");
            return false;
        }
        return true;
    }

    public void setParam(MemberCardInfoModel cardModel) {
        this.cardModel = cardModel;
    }

    public void setParam(String cardId){
        mCardId = cardId;
    }
}
