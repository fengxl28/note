package com.mwee.android.pos.business.menu.adapter;

import android.content.Context;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.DinnerApplication;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ItemDetailModelAdapter extends BaseAdapter {
    private Context context;
    private List<MenuItem> itemDetailModels = new ArrayList<>();
    //	private TextTypeFace textTypeFace = TextTypeFace.getInstance();
    private LayoutInflater inflater;

    private ArrayMap<String, BigDecimal> selectCache;

    /**
     * 是否显示菜品编号
     */
    private boolean isShowItemCd = false;

    public ItemDetailModelAdapter(Context context) {
        this.context = context;
        if (context == null) {
            context = DinnerApplication.instance;
        }
        inflater = LayoutInflater.from(context);
    }

    public List<MenuItem> getDatas() {
        return itemDetailModels;
    }

    public void setItemDetails(List<MenuItem> dataList) {
        this.itemDetailModels.clear();
        if (dataList != null) {
            this.itemDetailModels.addAll(dataList);
        }
    }

    public void setHelpCodeShow(boolean isShowItemCd) {
        this.isShowItemCd = isShowItemCd;
    }

    public void setSelectCache(ArrayMap<String, BigDecimal> selectCache) {
        this.selectCache = selectCache;
    }

    @Override
    public int getCount() {
        if (itemDetailModels == null) {
            return 0;
        }
        return itemDetailModels.size();
    }

    @Override
    public MenuItem getItem(int arg0) {
        if (itemDetailModels == null) {
            return null;
        }
        return itemDetailModels.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    /**
     * @param position
     * @param convertView
     * @param viewGroup
     * @return
     */
    @SuppressWarnings("deprecation")
    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_model_layout, viewGroup, false);
            holder = new ViewHolder();
            convertView.findViewById(R.id.tv_peiliao_tag).setVisibility(View.GONE);
            holder.rlytContainer = (RelativeLayout) convertView.findViewById(R.id.rlyt_menu_item_container);
            holder.tv_item_name = (TextView) convertView.findViewById(R.id.tv_item_name);
            holder.tvPrice = (TextView) convertView.findViewById(R.id.tv_item_price);
            holder.tvRemain = (TextView) convertView.findViewById(R.id.tv_item_remain);
            holder.tvCount = (TextView) convertView.findViewById(R.id.tv_item_count);
            holder.tvItemEffective = (TextView) convertView.findViewById(R.id.tv_item_effective);
            holder.tvHelpCode = (TextView) convertView.findViewById(R.id.tvHelpCode);
            holder.imgMenuItemTemp = convertView.findViewById(R.id.imgMenuItemTemp);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        MenuItem menuItem = getItem(position);
        holder.tvHelpCode.setText(isShowItemCd ? menuItem.fsItemId : "");

        if (menuItem != null) {
            holder.tv_item_name.setText(menuItem.name);

            if ((menuItem.config & 512) == 512) {
                holder.tvPrice.setText(TextUtils.concat("时价"));
            } else {
                holder.tvPrice.setText(TextUtils.concat(Calc.formatShow(menuItem.currentUnit.fdSalePrice)));
            }
            //fiStatus   数据状态;0未同步到店DB / 1正常 / 2临时沽清 / 3数量沽清 /13删除
            BigDecimal sellOutCount = AppCache.getInstance().getSelloutNum(menuItem.currentUnit.fiOrderUintCd);
            if (sellOutCount.compareTo(BigDecimal.ZERO) >= 0) {
                holder.tvRemain.setVisibility(View.VISIBLE);
                holder.tvRemain.setText(String.format(Locale.SIMPLIFIED_CHINESE, "剩余:%s", sellOutCount + menuItem.currentUnit.fsOrderUint));
            } else {
                holder.tvRemain.setText("");
                holder.tvRemain.setVisibility(View.GONE);
            }

            BigDecimal count = getSelectedCount(menuItem);
            if (count.compareTo(BigDecimal.ZERO) > 0) {
                holder.tvCount.setVisibility(View.VISIBLE);
                holder.tvCount.setText("x" + Calc.formatShow(count, 0));

                holder.tvCount.setActivated(true);
                holder.rlytContainer.setActivated(true);
                holder.tv_item_name.setActivated(true);
                holder.tvPrice.setActivated(true);
                holder.imgMenuItemTemp.setSelected(true);

            } else {
                holder.tvCount.setVisibility(View.INVISIBLE);

                holder.tvCount.setActivated(false);
                holder.rlytContainer.setActivated(false);
                holder.tv_item_name.setActivated(false);
                holder.tvPrice.setActivated(false);
                holder.imgMenuItemTemp.setSelected(false);
            }

            if (sellOutCount.compareTo(BigDecimal.ZERO) == 0 || !dataIsEffectiveDate(menuItem.itemID)) {
                holder.tv_item_name.setEnabled(false);
                holder.tvCount.setEnabled(false);
                holder.tvPrice.setEnabled(false);
                holder.tvRemain.setEnabled(false);
                holder.rlytContainer.setEnabled(false);
                if (!dataIsEffectiveDate(menuItem.itemID)) {
                    holder.tvItemEffective.setEnabled(false);
                    holder.tvItemEffective.setVisibility(View.VISIBLE);
                    holder.tvItemEffective.setText("此菜品未生效");
                }
            } else {
                holder.tv_item_name.setEnabled(true);
                holder.tvCount.setEnabled(true);
                holder.tvPrice.setEnabled(true);
                holder.tvRemain.setEnabled(true);
                holder.rlytContainer.setEnabled(true);
                holder.tvItemEffective.setEnabled(true);
                holder.tvItemEffective.setVisibility(View.GONE);
            }

            holder.imgMenuItemTemp.setVisibility(menuItem.isMenuTemporary() ? View.VISIBLE : View.GONE);

        }

        holder.tv_item_name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return convertView;
    }

    private boolean dataIsEffectiveDate(String itemId) {
        MenuEffectiveInfo info = AppCache.getInstance().menuEffectiveInfoMap.get(itemId);
        if (info == null) {
            return true;
        }
        return info.dataIsEffectiveDate();
    }

    /**
     * 从OrderCache中遍历获取已点菜品的数量
     *
     * @param itemDetailModel
     * @return
     */
    private BigDecimal getSelectedCount(MenuItem itemDetailModel) {
        if (selectCache == null) {
            return BigDecimal.ZERO;
        }
        BigDecimal count = BigDecimal.ZERO;
        if (selectCache.containsKey(itemDetailModel.itemID)) {
            count = selectCache.get(itemDetailModel.itemID);
        }
        return count;
    }

    class ViewHolder {
        public RelativeLayout rlytContainer;
        public TextView tv_item_name;
        public TextView tvPrice;
        public TextView tvRemain;
        public TextView tvCount;
        public TextView tvItemEffective;
        public TextView tvHelpCode;
        public ImageView imgMenuItemTemp;
    }


}
