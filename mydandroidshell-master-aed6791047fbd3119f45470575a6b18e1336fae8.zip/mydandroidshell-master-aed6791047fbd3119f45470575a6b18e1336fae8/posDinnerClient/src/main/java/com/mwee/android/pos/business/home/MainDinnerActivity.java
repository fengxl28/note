package com.mwee.android.pos.business.home;

import android.animation.Animator;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.member.MemberQueryFragment;
import com.mwee.android.pos.air.business.setting.api.ShopApi;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.ChildPageFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.base.OnKeyBackListener;
import com.mwee.android.pos.base.OverHomeFragment;
import com.mwee.android.pos.base.OverMainDinnerFragment;
import com.mwee.android.pos.business.bill.view.BillFragment;
import com.mwee.android.pos.business.common.dialog.PrintErrorMessageNotice;
import com.mwee.android.pos.business.custommodule.CustomModuleFragment;
import com.mwee.android.pos.business.dinner.DinnerFoodOrderFragment;
import com.mwee.android.pos.business.dinner.api.LockTableApi;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.login.component.LoginProcess;
import com.mwee.android.pos.business.member.MemberSelectFragment;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.business.message.UnDealCountMessageModel;
import com.mwee.android.pos.business.orderdishes.view.widget.TablesTitleTabView;
import com.mwee.android.pos.business.pay.view.PayDinnerFragment;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.print.view.PrintMonitorFragment;
import com.mwee.android.pos.business.print.view.ToPoContainerFragment;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.business.reports.view.ReportFragment;
import com.mwee.android.pos.business.setting.view.SettingFragment;
import com.mwee.android.pos.business.setting.view.koubeiservice.KoubeiServiceV2Fragment;
import com.mwee.android.pos.business.shift.ShiftFragment;
import com.mwee.android.pos.business.shop.KouBeiShopInfo;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.business.table.processor.TableViewProcessor;
import com.mwee.android.pos.business.table.view.TablesFragment;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.dinner.IKoubeiService;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import cn.mwee.android.skynet.ui.floatball.controller.DemoFloatService;

/**
 * 首页Activity
 */
public class MainDinnerActivity extends BaseActivity implements IDriver, TablesTitleTabView.TableArea {

    private final static String DRIVER_TAG = "main";
    /**
     * Tab的Fragment列表
     */
    //private SparseArray<HomeFragment> fragmentList = new SparseArray<>();
    /**
     * tab列表
     */
    private SparseArray<View> tabList = new SparseArray<>();

    private int currentIndex = MAIN_TAB.DEFAULT;

    private ImageView print_warning;

    private TextView mMsgCountTv;
    //未处理消息提醒
    private ImageView main_table_msg_warning;
    //未处理消息提醒
    private ImageView main_table_bill_msg_warning;
    //此activity是否是最前面的
    private boolean mIsFront;

    private int area = 0;
    //是否是主站标志
    private boolean isMainHost = false;

    /**
     * 打印失败的Receiver
     */
    private final BroadcastReceiver printFailReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.ACTION_Fail_PRINT)) {
                printWaring();
            }
        }
    };

    private final BroadcastReceiver floatBallReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Constants.ACTION_FLOAT_JUMP)) {
                Intent jumpIntent = new Intent(MainDinnerActivity.this, MainDinnerActivity.class);
                jumpIntent.putExtra("topo", 1);
                jumpIntent.putExtra("itemId", intent.getStringExtra("itemId"));
                jumpIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                MainDinnerActivity.this.startActivity(jumpIntent);
            }
        }
    };

    private View.OnClickListener clickTab = new View.OnClickListener() {//账单管理（主导航栏入口拦截）
        @Override
        public void onClick(View v) {
            if (!ButtonClickTimer.canClick(200)) {
                return;
            }
            Object tab = v.getTag(R.id.id_main_tab);
            if (tab != null && tab instanceof Integer) {
                final int tab_int = (Integer) tab;
                ActionLog.addLog("Main 点击Tab " + tab_int + ",[" + AppCache.getInstance().userDBModel.fsUserName + ","
                        + AppCache.getInstance().userDBModel.fsUserId + "]", ActionLog.USER_ACTION_TRACE);
                BaseFragment tempFragment = (BaseFragment) getActivityWithinHost().getSupportFragmentManager()
                        .findFragmentById(R.id.main_menufragment);
                if (tempFragment != null && tempFragment.isAdded()) {
                    if (tempFragment instanceof PayDinnerFragment && tempFragment.onKeyBack()) {
                        return;
                    } else if (tempFragment instanceof DinnerFoodOrderFragment && tempFragment.onKeyBack()) {
                        return;
                    }
                }
                if (tab_int == MAIN_TAB.BILL) {
                    PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance()
                            .userDBModel, Permission.DINNER_bnBillManage, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            BillFragment.index = 1;
                            jump(tab_int);
                        }
                    });
                    return;
                }
                jump(tab_int);
            }
        }
    };

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.main_table_exit_btn:
                    RunTimeLog.addLog(RunTimeLog.THREAD_NUM, "线程数量：" + Thread.getAllStackTraces().keySet().size());
                    ActionLog.addLog("注销", "", "", ActionLog.LOGOUT, "");
                    if (AppCache.getInstance().userDBModel != null) {
                        ActionLog.addLog("点击退出登录[" + AppCache.getInstance().userDBModel.fsUserName + "," + AppCache
                                .getInstance().userDBModel.fsUserId + "]", ActionLog.USER_ACTION_TRACE);
                    }
                    processLogout();
                    break;
            }
        }
    };
    private TextView mMain_table_user_name;

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinner_main_layout);

        doDataPrepare();
        initUI();
        //初始化赋值
        showTab(MAIN_TAB.TABLE);
        getActivityWithinHost().registerReceiver(this.printFailReceiver, new IntentFilter(Constants.ACTION_Fail_PRINT));
        getActivityWithinHost().registerReceiver(this.floatBallReceiver, new IntentFilter(Constants.ACTION_FLOAT_JUMP));
        LockTableApi.releaseHostLock(AppCache.getInstance().currentHostId);

        if (APPConfig.isMydKouBei()) {
            //口碑门店/业务中心站点 唤醒口碑心跳apk
            if (!TextUtils.isEmpty(AppCache.getInstance().getAlipayShopId())) {
                startHeartService(AppCache.getInstance().getAlipayShopId());
                return;
            }
            initKouBeiHeart();
        }

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (isJumpToPo(intent)) {
            jump(MAIN_TAB.PRINT);
        }
    }

    private boolean isJumpToPo(Intent intent) {
        return intent.getIntExtra("topo", 0) == 1;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (AppCache.getInstance().userDBModel != null) {
            mMain_table_user_name.setText(AppCache.getInstance().userDBModel.fsUserName);
        }
        new LowThread(new Runnable() {
            @Override
            public void run() {
                DriverBus.registerDriver(MainDinnerActivity.this);
            }
        }).start();
    }

    @Override
    public void syncTableArea(int area) {
        this.area = area;
    }

    @Override
    public int getTableArea() {
        return this.area;
    }

    @Override
    protected void onStop() {
        super.onStop();
//        DriverBus.unRegisterDriver(this);
        mIsFront = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        NotifyToServer.refreshMessageUndeal(AppCache.getInstance().currentHostId);
        mIsFront = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void initUI() {

        View tab_table = findViewById(R.id.tab_table);
        View tab_bill = findViewById(R.id.tab_bill);
        View tab_print = findViewById(R.id.tab_print);
        View tab_custom = findViewById(R.id.tab_custommodule);
        View tab_msg = findViewById(R.id.tab_msg);
        View tab_setting = findViewById(R.id.tab_setting);
        View tab_shift = findViewById(R.id.tab_shift);
        View tab_report = findViewById(R.id.tab_report);
        View tab_member = findViewById(R.id.tab_member);

        tab_table.setTag(R.id.id_main_tab, MAIN_TAB.TABLE);
        tab_bill.setTag(R.id.id_main_tab, MAIN_TAB.BILL);
        tab_setting.setTag(R.id.id_main_tab, MAIN_TAB.SET);
        tab_custom.setTag(R.id.id_main_tab, MAIN_TAB.CUSTOM);
        tab_print.setTag(R.id.id_main_tab, MAIN_TAB.PRINT);
        tab_msg.setTag(R.id.id_main_tab, MAIN_TAB.MESSAGE);
        tab_shift.setTag(R.id.id_main_tab, MAIN_TAB.SHIFT);
        tab_report.setTag(R.id.id_main_tab, MAIN_TAB.REPORT);
        tab_member.setTag(R.id.id_main_tab, MAIN_TAB.MEMBER);

        tabList.clear();
        tabList.put(MAIN_TAB.TABLE, tab_table);
        tabList.put(MAIN_TAB.BILL, tab_bill);
        tabList.put(MAIN_TAB.PRINT, tab_print);
        tabList.put(MAIN_TAB.PRINT, tab_print);
        tabList.put(MAIN_TAB.SET, tab_setting);
        tabList.put(MAIN_TAB.SHIFT, tab_shift);
        tabList.put(MAIN_TAB.MEMBER, tab_member);
        tabList.put(MAIN_TAB.REPORT, tab_report);
        tabList.put(MAIN_TAB.MESSAGE, tab_msg);
        tabList.put(MAIN_TAB.CUSTOM, tab_custom);

        tab_table.setOnClickListener(clickTab);
        tab_bill.setOnClickListener(clickTab);
        tab_print.setOnClickListener(clickTab);
        tab_custom.setOnClickListener(clickTab);
        tab_msg.setOnClickListener(clickTab);
        tab_setting.setOnClickListener(clickTab);
        tab_shift.setOnClickListener(clickTab);
        tab_report.setOnClickListener(clickTab);
        tab_member.setOnClickListener(clickTab);

        print_warning = (ImageView) findViewById(R.id.main_table_print_warning);
        TextView tvPrint = (TextView) findViewById(R.id.tv_text_print);
        if (!ClientMetaUtil.isCurrentHostMain()) {
            tvPrint.setText(R.string.main_tab_print);
        }
        mMain_table_user_name = (TextView) findViewById(R.id.main_table_user_name);
        mMain_table_user_name.setTextColor(getResources().getColor(R.color.text_gray));
        findViewById(R.id.main_table_exit_btn).setOnClickListener(clickListener);

        mMsgCountTv = (TextView) findViewById(R.id.tv_msg_count);
        main_table_msg_warning = (ImageView) findViewById(R.id.main_table_msg_warning);
        main_table_bill_msg_warning = (ImageView) findViewById(R.id.main_table_bill_msg_warning);

        //处理显示自定义模块按钮
        boolean useModule = AppCache.getInstance().useModule;
        String customModuleName = AppCache.getInstance().customModuleName;
        String customModuleUrl = AppCache.getInstance().customModuleUrl;
        if (useModule && !TextUtils.isEmpty(customModuleName) && !TextUtils.isEmpty(customModuleUrl)) {
            TextView customName  = (TextView) findViewById(R.id.tv_text_custommodule);
            customName.setText(customModuleName);
        } else {
            tab_custom.setVisibility(View.GONE);
        }
    }

    @DrivenMethod(uri = "main/updateUserNameColor", UIThread = true)
    public void updateUserNameColor(boolean isRed) {
        if (isRed) {
            mMain_table_user_name.setTextColor(getResources().getColor(R.color.red));
        } else {
            mMain_table_user_name.setTextColor(getResources().getColor(R.color.text_gray));
        }
    }


    /**
     * 点击其他任何区域关闭软键盘
     *
     * @param ev
     * @return
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        KeyboardManager.closeSoftInput(this);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        closeLastSubPage();
    }


    @DrivenMethod(uri = DRIVER_TAG + "/jump", UIThread = true)
    public void jump(int index) {
        MAIN_TAB.PermisionInfo permisionInfo  = MAIN_TAB.MODULE_PERMISSION_MAP.get(index);
        if (null == permisionInfo || TextUtils.isEmpty(permisionInfo.permision) || TextUtils.isEmpty(permisionInfo.permisionType)) {
            jump2(index);
        } else {
            PermissionsUtil.requestReportFragment(getActivityWithinHost(), AppCache.getInstance().userDBModel, permisionInfo.permision, permisionInfo.permisionType, new PermissionCallback() {
                @Override
                public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                    jump2(index);
                }
            });
        }
    }

    private void jump2(int index) {
        closeDialog();
        boolean stop = false;
        while (!stop) {
            BaseFragment tempFragment = (BaseFragment) getActivityWithinHost().getSupportFragmentManager()
                    .findFragmentById(R.id.main_menufragment);
            if (tempFragment == null || tempFragment instanceof HomeFragment) {
                stop = true;
                break;
            } else {
                tempFragment.dismissSelf();
            }
        }
        showTab(index);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/meituanPhoneDowngrade", UIThread = true)
    public void meituanPhoneDowngrade() {
        jump(MAIN_TAB.MESSAGE);
        MessageV2Fragment.isRecvMeituanPhoneDowngrade = true;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/messageUndealTip", UIThread = true)
    public void undealTip(UnDealCountMessageModel unDealCountMessageModel) {
        if (unDealCountMessageModel == null) {
            return;
        }
        if (main_table_msg_warning != null) {
            int count = unDealCountMessageModel.orderUndealCount;
            count += unDealCountMessageModel.payUndealCount;
            count += unDealCountMessageModel.netOrderCount;
            count += unDealCountMessageModel.wechatOrderCount;
            count += unDealCountMessageModel.systemCount;
            count += unDealCountMessageModel.fastfood;
            count += unDealCountMessageModel.abnormalOrders;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !Settings.canDrawOverlays(this)) {
                count++;
            }
            if (count > 0) {
                main_table_msg_warning.setVisibility(View.VISIBLE);
            } else {
                main_table_msg_warning.setVisibility(View.INVISIBLE);
            }
        }

        if (main_table_bill_msg_warning != null) {
            if (unDealCountMessageModel.unMappingOrderCount > 0) {
                main_table_bill_msg_warning.setVisibility(View.VISIBLE);
            } else {
                main_table_bill_msg_warning.setVisibility(View.INVISIBLE);
            }
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refreshMsg", UIThread = true)
    private void refreshMsgCount(int count) {
        if (mMsgCountTv != null) {
            if (count > 0) {
                mMsgCountTv.setVisibility(View.VISIBLE);
                mMsgCountTv.setText(String.valueOf(count));
            } else {
                mMsgCountTv.setVisibility(View.GONE);
            }
        }
    }

    /*用于保留fragment实例化对象*/
    private final ConcurrentHashMap<Integer, BaseFragment> fragMap = new ConcurrentHashMap<>();

    private BaseFragment getTabFragment(int index) {
        BaseFragment to = fragMap.get(Integer.valueOf(index));
        if (to != null) {
            return to;
        }

        if (index == MAIN_TAB.TABLE) {
            to = new TablesFragment();
            fragMap.put(index, to);
        } else if (index == MAIN_TAB.BILL) {
            to = new BillFragment();
        } else if (index == MAIN_TAB.PRINT) {
            if (isMainHost) {
                to = new ToPoContainerFragment();
            } else {
                to = PrintMonitorFragment.newInstance("", false);
            }
        } else if (index == MAIN_TAB.SET) {
                to = new SettingFragment();
        } else if (index == MAIN_TAB.SHIFT) {
            to = new ShiftFragment();
        } else if (index == MAIN_TAB.MEMBER) {
            if (AppCache.getInstance().isRetailMode()) {
                to = new MemberQueryFragment();
            } else {
                to = new MemberSelectFragment();
            }
        } else if (index == MAIN_TAB.REPORT) {
            to = new ReportFragment();
        } else if (index == MAIN_TAB.MESSAGE) {
            to = new MessageV2Fragment();
        } else if (index == MAIN_TAB.CUSTOM) {
            to = new CustomModuleFragment();
        }

        return to;
    }

    /**
     * 跳转到指定的Tab
     *
     * @param index int
     */
    private void showTab(int index) {
//        if (index == currentIndex) return;
        FragmentManager fm = getActivityWithinHost().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Fragment from = fm.findFragmentById(R.id.main_menufragment);
        BaseFragment to = getTabFragment(index);
        if (from != null) {
            if (isPrintWarnShake) {
                if (from instanceof ToPoContainerFragment || from instanceof PrintMonitorFragment)
                    clearPrintShake();
            }

            if (currentIndex != index && from.isAdded() && !(from instanceof TablesFragment)) {
                //从FragmentTransaction中清除非"点菜收银"的fragment：注意此时fragMap中依旧还保留部分fragment实例对象
                ft.remove(from);
            }
            if (to.isAdded() && to instanceof TablesFragment) {
                ft.show(to).commitAllowingStateLoss();
            } else {
                if (from.isAdded() && from instanceof TablesFragment) {
                    ft.hide(from).add(R.id.main_menufragment, to).commitAllowingStateLoss();
                } else {
                    if (!to.isAdded()) {
                        ft.replace(R.id.main_menufragment, to).commitAllowingStateLoss();
                    }
                }
            }
        } else {
            //首次进入页面
            ft.add(R.id.main_menufragment, to).commitAllowingStateLoss();
        }

        tabList.valueAt(index).setSelected(true);
        tabList.valueAt(currentIndex).setSelected(currentIndex == index);
        currentIndex = index;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/closesub", UIThread = true)
    public void closeLastSubPage() {
        closeLastSubPage(null);
    }

    private boolean isPrintWarnShake = false;//保存当前打印动画监控状态

    @DrivenMethod(uri = DRIVER_TAG + "/printwarning", UIThread = true)
    public void printWaring() {
        FragmentManager fm = getActivityWithinHost().getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.main_menufragment);
        if (fragment instanceof PrintMonitorFragment) {//当前所处位置为打印监控 不显示shadow动画
            return;
        }
        print_warning.setVisibility(View.VISIBLE);//设置警告图标
        View fl_warning = findViewById(R.id.tv_text_print);
        //如果阅读过则将状态改为未阅读，开启未读动画
        if (!isPrintWarnShake) {
//            ani = ViewToolsUtil.startAlpha(fl_warning, findViewById(R.id.tv_text_print), 1500, ValueAnimator
//                    .INFINITE, R.color.color_DD3030);
            isPrintWarnShake = true;
        }
    }

    Animator ani = null;

    private void clearPrintShake() {
        if (isPrintWarnShake) {
            View fl_warning = findViewById(R.id.tv_text_print);

            Animator animator = ani;
            if (animator != null && animator.isRunning()) {
                animator.end();
            }
            fl_warning.setBackgroundResource(android.R.color.transparent);
            print_warning.setVisibility(View.GONE);//设置警告图标
            isPrintWarnShake = false;
        }
    }

    /**
     * 关闭所有的子页面
     */
    @DrivenMethod(uri = DRIVER_TAG + "/closesingle", UIThread = true)
    public void closeLastSubPage(Class<? extends BaseFragment> fragmentClz) {
        BaseFragment baseFragment = (BaseFragment) getSupportFragmentManager().findFragmentById(android.R.id.content);
        if (baseFragment != null && baseFragment instanceof OverHomeFragment) {//直接拦截手机支付fragment 不做处理
            return;
        }
        //当前页面是反馈页面/打印机管理页面/小票模版页面/模版编辑页面，就关闭
        if (baseFragment != null && baseFragment instanceof ChildPageFragment) {
            FragmentController.removeFragment(getSupportFragmentManager(), baseFragment);
            return;
        }
        BaseFragment temp = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.main_root);
        if (temp != null && !(temp instanceof HomeFragment)) {
            boolean handled = false;
            if (temp instanceof OnKeyBackListener) {
                handled = temp.onKeyBack();
            }
            if (handled) {
                return;
            }
            FragmentController.removeFragment(getSupportFragmentManager(), temp);
            return;
        }

        BaseFragment tempFragment = (BaseFragment) getSupportFragmentManager().findFragmentById(R.id.main_menufragment);
        if (tempFragment.onKeyBack()) {
            return;
        }


        if (tempFragment instanceof HomeFragment) {
            return;
        } else if (baseFragment != null) {
            FragmentController.removeFragment(getSupportFragmentManager(), baseFragment);
        } else {
            FragmentController.removeFragment(getSupportFragmentManager(), tempFragment);
        }
    }

    private void doDataPrepare() {
        TextView tvMoniter = (TextView) findViewById(R.id.tv_text_print);
        isMainHost = ClientMetaUtil.isCurrentHostMain();
        if (isMainHost) {
            tvMoniter.setText(R.string.main_tab_system);
        }
    }

    public void closeDialog() {
        List<Fragment> fragmentList = getSupportFragmentManager().getFragments();
        if (!ListUtil.isEmpty(fragmentList)) {
            for (Fragment temp : fragmentList) {
                closeFragment(temp);
            }
        }
    }

    private void closeFragment(Fragment tempFragment) {
        if (tempFragment == null) {
            return;
        }
        if (tempFragment instanceof ChildPageFragment) {
            FragmentController.removeFragment(getSupportFragmentManager(), tempFragment);
            return;
        }

        if (tempFragment instanceof BaseDialogFragment) {
            ((BaseDialogFragment) tempFragment).dismiss();
            return;
        }
        if (tempFragment instanceof OverMainDinnerFragment) {
            FragmentController.removeFragment(getSupportFragmentManager(), tempFragment);
            return;
        }
        if (tempFragment instanceof HomeFragment) {
            return;
        }
//        if(tempFragment instanceof FastFoodOrderDishesFragment&&((DinnerFoodOrderFragment) tempFragment).onKeyBack()){
//            return;
//        }
//        FragmentController.removeFragment(getSupportFragmentManager(), tempFragment);
    }

    /**
     * 网络订单没有找到匹配的菜品提示
     */
    @DrivenMethod(uri = DRIVER_TAG + "/netOrderPrintErr", UIThread = true)
    public void netOrderPrintErr(String errInfo) {
        DialogManager.showSingleDialog(MainDinnerActivity.this, errInfo + "没有关联到本店菜品，无法根据制作部门出单", "外卖制作单", "知道了", null);
    }

    @Override
    protected void onDestroy() {
        closeDialog();
        clearPrintShake();
        getActivityWithinHost().unregisterReceiver(this.printFailReceiver);
        closeFloatBall();
//        getActivityWithinHost().unregisterReceiver(this.updateReceiver);
        super.onDestroy();
    }

    private void closeFloatBall() {
        getActivityWithinHost().unregisterReceiver(this.floatBallReceiver);
        DemoFloatService.showFloatingMenu(this, false);
    }

    /**
     * 发起退出登录
     */
    @DrivenMethod(uri = DRIVER_TAG + "/logout", UIThread = true)
    public void processLogout() {

        if (AppCache.getInstance().userDBModel == null) {
            return;
        }
        final String userName = AppCache.getInstance().userDBModel.fsUserName;
        final String userId = AppCache.getInstance().userDBModel.fsUserId;
        RunTimeLog.addLog(RunTimeLog.Close, "登出" + userName);
        final Progress progress = ProgressManager.showProgress(MainDinnerActivity.this, "正在更新站点状态");
        LoginProcess.doLogout(userId, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse socketResponse) {
                progress.dismiss();
                if (socketResponse.code != SocketResultCode.SUCCESS) {
                    ToastUtil.showToast(socketResponse.message);
                    return;
                }
                LogUtil.log("收银员[--fsUserName--" + userName + "--fsUserId--" + userId + " 退出登录]");
                ActionLog.waiterID = "";
                ActionLog.waiterName = "";
                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_STATUS, HostStatus.CLOSE);
                UIHelp.startLoginDinnerActvity(getActivityWithinHost());
                leave(false);
                AppCache.getInstance().userDBModel = null;
                AppCache.getInstance().currentShiftID = "";
            }
        });
    }

    /**
     * 离开页面
     *
     * @param isClose boolean | 是否是打烊登出页面
     */
    @DrivenMethod(uri = DRIVER_TAG + "/leave", UIThread = true)
    public void leave(boolean isClose) {
        TableViewProcessor.release();
        // 打烊时，副站点执行页面跳转。主站点交由打烊callback执行
        if (isClose && ClientBindProcessor.isCurrentHostMain()) {
            return;
        }
        finish();
    }

    /**
     * 打印失败
     */
    @DrivenMethod(uri = DRIVER_TAG + "/printerError", UIThread = true)
    public void printerError(String errorMsg) {
        printWaring();
        //将吐司换成弹框
        if (PrintErrorMessageNotice.getInstance().isShow) {
            PrintErrorMessageNotice.getInstance().updateFloatWindow(errorMsg);
        } else {
            PrintErrorMessageNotice.getInstance().showFloatWindow(errorMsg);
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/superJump", UIThread = true)
    public void superJump(int index) {
        if (!isFinishing()) {
            if (!mIsFront) {
                UIHelp.startMainDinnerActvity(topActivity);
            }
            jump(index);
        }
    }

    private void initKouBeiHeart() {
        //查询绑定门店信息
        ShopApi.loadKouBeiShopInfo(new ResultCallback<KouBeiShopInfo>() {
            @Override
            public void onSuccess(KouBeiShopInfo data) {
                if (TextUtils.isEmpty(data.alipayShopId)) {
                    String isFirstShow = ClientMetaUtil.getConfig(META.KEY_IS_FIRST_SHOW_BIND_KOUBEI_ALERT, "");
                    if (TextUtils.isEmpty(isFirstShow)) {
                        //提示
                        DialogManager.showExecuteDialog(MainDinnerActivity.this, "绑定口碑门店，可以享有“预点单、智能营销、线上流量”等服务\n\n" +
                                "是否立即去绑定？", "取消", "立即去绑定", new DialogResponseListener() {
                            @Override
                            public void response() {
                                UIHelp.jumpContainerActivity(getActivityWithinHost(), "口碑服务", KoubeiServiceV2Fragment.class);
                            }
                        }, null);
                        ClientMetaUtil.updateSettingsValueByKey(META.KEY_IS_FIRST_SHOW_BIND_KOUBEI_ALERT, "1");
                    }
                } else {
                    startHeartService(data.alipayShopId);
                }

            }

            @Override
            public void onFailure(int code, String msg) {
                //1代表没有绑定门店信息
                if (code != 1) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!isDestroyed()) {
                                initKouBeiHeart();
                            }
                        }
                    }, 2000);
                }
            }
        });
    }

    private void startHeartService(String kbShopId) {
        Intent intent = new Intent("com.koubei.pos.heart.START_HEART");
        intent.setPackage("com.koubei.pos");
        intent.putExtra("ISV_PID", KBConstants.ISV_PID);//2088311069027504
        intent.putExtra("SHOP_ID", kbShopId);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT);
        startService(intent);
        unbindService(mConnection);
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            IKoubeiService iKoubeiService = IKoubeiService.Stub.asInterface(service);
            try {
                iKoubeiService.init();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            startHeartService(AppCache.getInstance().getAlipayShopId());
        }

        @Override
        public void onBindingDied(ComponentName name) {
            startHeartService(AppCache.getInstance().getAlipayShopId());
        }
    };
}
