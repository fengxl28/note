package com.mwee.android.pos.business.bill.view;

import com.mwee.android.pos.db.business.order.Order;

/**
 * Created by virgil on 2016/10/11.
 */

public interface IGetOrder {
    void getOrder(Order order);
}
