package com.mwee.android.pos.business.message;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.message.processor.wechatFastFood.MessageWechatFastFoodView;
import com.mwee.android.pos.business.message.processor.wechatFastFood.WechatFastFoodClientUtil;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: MessageWechatFastFoodFragment
 * @Description: 微信快餐
 * @author: SugarT
 * @date: 2017/10/27 下午8:23
 */
public class MessageWechatFastFoodFragment extends HomeFragment implements IDriver {

    public static final String TAG = MessageWechatFastFoodFragment.class.getSimpleName();

    public static final String DRIVER_TAG = "messageWechatFastFood";

    private MessageWechatFastFoodView wechat_order_detail;
    private ListView lv_msg_wechat_order;
    private CommonAdapter<MessageFastFoodBean> adapter;

    private List<MessageFastFoodBean> wechatOrderModelList = new ArrayList<>();

    private int chosedMsgId = 0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_message_wechat_fastfood, container, false);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        initAdapter();
        loadData(AppCache.getInstance().businessDate);
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!MessageWechatFastFoodFragment.this.isVisible()) {
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    /**
     * 更新某一条记录
     *
     * @param model
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshWechatFastfood", UIThread = true)
    public void refreshTempApporder(MessageFastFoodBean model) {
        if (model == null) {
            return;
        }
        updateData(model);
        refreshDetail();
    }

    /**
     * 更新显示列表
     *
     * @param wechatOrderModel
     */
    private void updateData(MessageFastFoodBean wechatOrderModel) {
        if (!ListUtil.isEmpty(wechatOrderModelList)) {
            int index = -1;
            for (int i = 0; i < wechatOrderModelList.size(); i++) {
                MessageFastFoodBean order = wechatOrderModelList.get(i);
                if (order.msgId == wechatOrderModel.msgId) {
                    index = i;
                    break;
                }
            }

            if (index > -1) {
                wechatOrderModelList.remove(index);
                wechatOrderModelList.add(index, wechatOrderModel);
            } else {
                wechatOrderModelList.add(0, wechatOrderModel);
            }
            adapter.notifyDataSetChanged();
        }
    }

    private void assignViews(View convertView) {
        wechat_order_detail = (MessageWechatFastFoodView) convertView.findViewById(R.id.layout_message_wechat_fast_food_detail);
        lv_msg_wechat_order = (ListView) convertView.findViewById(R.id.rv_message_wechat_fast_food_content);
        wechat_order_detail.setHost(this);
        wechat_order_detail.setVisibility(View.GONE);

        if (AppCache.getInstance().isRetailMode()) {//小易2.2 修改样式
            ViewGroup root = rootView.findViewById(R.id.lyt_wechat_fast_food_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            lv_msg_wechat_order.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root, getResources().getColor(R.color.color_656565));
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup, int color) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof TextView) {
                ((TextView) view).setTextColor(color);
            }
        }
    }

    private void initAdapter() {
        adapter = new CommonAdapter<MessageFastFoodBean>(getContext(), wechatOrderModelList, R.layout.item_message_wechat_fast_food) {

            @Override
            public void convert(ViewHolder viewHolder, MessageFastFoodBean data, int position) {
                String time = DateUtil.formartDateStrToTarget(data.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                viewHolder.setText(R.id.msg_wechat_fast_food_no, data.msgHead + "");
                viewHolder.setText(R.id.msg_wechat_fast_food_time, time);
                viewHolder.setText(R.id.msg_wechat_fast_food_source, data.optSourse());
                viewHolder.setText(R.id.msg_wechat_fast_food_number, data.number());
                viewHolder.setText(R.id.msg_wechat_fast_food_amt, data.payAmt());
                viewHolder.setText(R.id.msg_wechat_fast_food_status, data.optBizStatus());

                View root = viewHolder.getView(R.id.lyt_wechat_fast_food_root);

                if (AppCache.getInstance().isRetailMode()) {
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.system_red);
                        setTextColorOfViewGroup((ViewGroup) root, Color.WHITE);
                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.color_f9f9f9);
                        setTextColorOfViewGroup((ViewGroup) root, getResources().getColor(R.color.color_404040));
                    }
                } else {
                    int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                    if (data.doUnDeal()) {//新订单
                        colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                    }
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_no, colorR);
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_time, colorR);
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_source, colorR);
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_number, colorR);
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_amt, colorR);
                    viewHolder.setTextColor(R.id.msg_wechat_fast_food_status, colorR);
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
                    }
                }
            }
        };
        lv_msg_wechat_order.setAdapter(adapter);
    }

    private void registerEvent() {
        lv_msg_wechat_order.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                chosedMsgId = wechatOrderModelList.get(position).msgId;
                if (wechat_order_detail != null) {
                    refreshDetail();
                    ActionLog.addLog("点击了 消息中心 外卖 条目", "", "", ActionLog.MESSAGE_TAKEAWAY, wechatOrderModelList.get(position));
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * 取数据
     *
     * @param businessDate
     */
    public void loadData(final String businessDate) {
        ProgressManager.showProgress(getActivityWithinHost(), "请稍后...");

        WechatFastFoodClientUtil.getfastfoodList(businessDate, new IResponse<List<MessageFastFoodBean>>() {

            @Override
            public void callBack(boolean result, int code, String msg, List<MessageFastFoodBean> info) {
                wechatOrderModelList.clear();
                wechatOrderModelList.addAll(info);
                refreshDetail();
                adapter.notifyDataSetChanged();
                if (!result) {
                    ToastUtil.showToast(msg);
                    ActionLog.addLog("消息中心 微信外卖 获取订单列表失败 " + msg, "", "", ActionLog.MESSAGE_TAKEAWAY, msg);
                }

                ProgressManager.closeProgress(getActivityWithinHost());
            }
        });
    }

    private void refreshDetail() {
        MessageFastFoodBean bean = null;
        //查查当前选中在不在列表中
        for (MessageFastFoodBean wechatOrderModel : wechatOrderModelList) {
            if (wechatOrderModel.msgId == chosedMsgId) {
                bean = wechatOrderModel;
                break;
            }
        }

        if (bean != null) {
            wechat_order_detail.updateData(bean);
            wechat_order_detail.setVisibility(View.VISIBLE);
        } else {
            chosedMsgId = 0;
            wechat_order_detail.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

}
