//package com.mwee.android.pos.air.business.payment.view;
//
//import android.graphics.Bitmap;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.mwee.android.air.db.business.payment.PaymentManageInfo;
//import com.mwee.android.pos.air.base.AirBaseFragment;
//import com.mwee.android.pos.air.business.biz.BizcenterApi;
//import com.mwee.android.pos.air.business.payment.component.PaymentConstant;
//import com.mwee.android.pos.air.business.payment.entity.PayOpenStatus;
//import com.mwee.android.pos.air.business.payment.process.PaymentManageProcess;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.component.callback.OnResultListener;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.DialogResponseListener;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.ButtonClickTimer;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.widget.TitleBar;
//import com.mwee.android.pos.widget.pull.BaseListAdapter;
//import com.mwee.android.pos.widget.pull.BaseViewHolder;
//import com.mwee.android.print.processor.BarcodeUtil;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @ClassName: PaymentManageFragment
// * @Description: 支付方式编辑
// * @author: SugarT
// * @date: 2017/10/14 上午11:11
// */
//public class PaymentManageFragment extends AirBaseFragment {
//
//    public static final String TAG = PaymentManageFragment.class.getSimpleName();
//
//    public static final String EMPTY_PAYMENT_ID = "ForAddPayment";
//
//    private TitleBar mTitleBar;
//    private RecyclerView mPaymentRv;
//
//    private BaseListAdapter<PaymentManageInfo> mAdapter;
//
//    private ArrayList<PaymentManageInfo> mAllPayment = new ArrayList<>();
//
//    private PaymentManageProcess mProcess;
//
//    public static PaymentManageFragment newInstance() {
//        PaymentManageFragment fragment = new PaymentManageFragment();
//        new PaymentManageProcess(fragment);
//        return fragment;
//    }
//
//    public void setProcess(PaymentManageProcess process) {
//        mProcess = process;
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_account_manage, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        assignViews(view);
//        initTitle();
//        initAdapter();
//        mProcess.start();
//
//        mProcess.loadPayOpenStatus(new ResultCallback<ArrayList<PayOpenStatus>>() {
//
//            @Override
//            public void onSuccess(ArrayList<PayOpenStatus> data) {
//
//                for (PayOpenStatus datum : data) {
//                    if (TextUtils.equals("weixin", datum.pay_type)) {
//
//                        if (datum.pay_status == 0) {
//                            imgWX.setSelected(true);
//                            tvWX.setText("微信  已开通");
//                            tvWX.setTextColor(getResourcesWithinHost().getColor(R.color.color_00C801));
//                        } else {
//                            imgWX.setSelected(false);
//                            tvWX.setText("微信  未开通");
//                        }
//                    }
//                    if (TextUtils.equals("alipay", datum.pay_type)) {
//                        if (datum.pay_status == 0) {
//                            imgZFB.setSelected(true);
//                            tvZFB.setText("支付宝  已开通");
//                            tvZFB.setTextColor(getResourcesWithinHost().getColor(R.color.color_02A9F1));
//                        } else {
//                            imgZFB.setSelected(false);
//                            tvZFB.setText("支付宝  未开通");
//                        }
//                    }
//
//                }
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                super.onFailure(code, msg);
//                ToastUtil.showToast(msg);
//            }
//        });
//    }
//
//    private void assignViews(View convertView) {
//        mTitleBar = (TitleBar) convertView.findViewById(R.id.tb_fragment_account_manage_title);
//        mPaymentRv = (RecyclerView) convertView.findViewById(R.id.rv_fragment_account_manage_content);
//    }
//
//    private void initTitle() {
//        mTitleBar.setTitle("支付方式");
//
//        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
//            @Override
//            public void onBackClick() {
//                BizcenterApi.uploadLocalChangeData(null);
//                dismissSelf();
//            }
//        });
//
//    }
//
//    private ImageView imgWX;
//    private ImageView imgZFB;
//    private TextView tvWX;
//    private TextView tvZFB;
//
//
//    private void initAdapter() {
//        mAdapter = new BaseListAdapter<PaymentManageInfo>(mAllPayment) {
//
//            View.OnClickListener innerClick = new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (!ButtonClickTimer.canClick()) {
//                        return;
//                    }
//                    switch (v.getId()) {
//                        /*case R.id.btn_payment_manage_footer_open:
//                            // 去开通支付方式, 弹出二维码
//                            if (!TextUtils.equals(AppCache.getInstance().userDBModel.fsUserId, "admin") && !TextUtils.equals(AppCache.getInstance().userDBModel.fsUserId, "99999")) {
//                                DialogManager.showSingleDialog(PaymentManageFragment.this, "当前账号无操作权限");
//                                return;
//                            }
//                            QrCodeDisplayView dialog = new QrCodeDisplayView();
//                            dialog.setOriginUri(PaymentConstant.getUrlBindPay());
//                            dialog.show(getFragmentManager(), "QrCodeDisplayView");
//                            break;*/
//                        case R.id.rlyt_item_account_manage_root:
//                            // 添加/编辑
//                            if (v.getTag() instanceof PaymentManageInfo) {
//                                PaymentManageInfo model = (PaymentManageInfo) v.getTag();
//                                if (model.fiDataKind == 1) {
//                                    // 后台预置数据不可编辑
//                                    return;
//                                }
//                                editPayment(model);
//                            }
//                            break;
//                        case R.id.iv_item_account_manage_del:
//                            // 删除
//                            if (v.getTag() instanceof PaymentManageInfo) {
//                                PaymentManageInfo model = (PaymentManageInfo) v.getTag();
//                                delPayment(model);
//                            }
//                            break;
//                        default:
//                            break;
//                    }
//                }
//            };
//
//            @Override
//            protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
//                View itemView = LayoutInflater.from(getContextWithinHost()).inflate(R.layout.item_account_manage, parent, false);
//                BaseViewHolder holder = new PaymentVH(itemView);
//                return holder;
//            }
//
//            @Override
//            protected View onCreateHeaderView(ViewGroup parent) {
//
//                View header = LayoutInflater.from(getContextWithinHost()).inflate(R.layout.view_payment_manage_header, parent, false);
//
//                imgWX = header.findViewById(R.id.imgWX);
//                tvWX = header.findViewById(R.id.tvWX);
//
//                imgZFB = header.findViewById(R.id.imgZFB);
//                tvZFB = header.findViewById(R.id.tvZFB);
//
//                TextView tvSaoMa = header.findViewById(R.id.tvSaoMa);
//
//                ImageView imgCode = header.findViewById(R.id.imgCode);
//                start(imgCode);
//
//                return header;
//            }
//
//         /*   @Override
//            protected View onCreateFooterView(ViewGroup parent) {
//                View footer = View.inflate(getContextWithinHost(), R.layout.view_payment_manage_footer, null);
//                footer.findViewById(R.id.btn_payment_manage_footer_open).setOnClickListener(innerClick);
//                return footer;
//            }*/
//
//            class PaymentVH extends BaseViewHolder {
//
//                public PaymentVH(View itemView) {
//                    super(itemView);
//                }
//
//                @Override
//                public void bindData(int position) {
//                    PaymentManageInfo model = modules.get(position);
//                    if (model == null) {
//                        return;
//                    }
//
//                    RelativeLayout rlytRoot = (RelativeLayout) itemView.findViewById(R.id.rlyt_item_account_manage_root);
//                    TextView tvName = (TextView) itemView.findViewById(R.id.tv_item_account_manage_name);
//                    TextView tvCalc = (TextView) itemView.findViewById(R.id.tv_item_account_manage_id);
//                    TextView tvAdd = (TextView) itemView.findViewById(R.id.tv_item_account_manage_add);
//                    ImageView ivDel = (ImageView) itemView.findViewById(R.id.iv_item_account_manage_del);
//
//                    rlytRoot.setOnClickListener(innerClick);
//                    rlytRoot.setTag(model);
//                    ivDel.setOnClickListener(innerClick);
//                    ivDel.setTag(model);
//
//                    if (TextUtils.equals(model.fsPaymentId, EMPTY_PAYMENT_ID)) {
//                        tvName.setVisibility(View.GONE);
//                        tvCalc.setVisibility(View.GONE);
//                        tvAdd.setVisibility(View.VISIBLE);
//                        tvAdd.setText("+添加");
//                        ivDel.setVisibility(View.GONE);
//                        return;
//                    }
//
//                    tvName.setVisibility(View.VISIBLE);
//                    tvName.setText(model.fsPaymentName);
//                    tvCalc.setVisibility(View.VISIBLE);
//                    tvCalc.setText(model.fiIsCalcPaid == 1 ? "实收" : "非实收");
//                    tvAdd.setVisibility(View.GONE);
//
//                    // 后台预置的支付方式，不可删除
//                    if (model.fiDataKind == 1) {
//                        ivDel.setVisibility(View.GONE);
//                    } else {
//                        ivDel.setVisibility(View.VISIBLE);
//                    }
//                }
//            }
//        };
//        mAdapter.isHeaderShow = true;
//        mAdapter.isFooterShow = false;
//
//        mPaymentRv.setLayoutManager(getGridLayoutManager(5));
//        mPaymentRv.setAdapter(mAdapter);
//    }
//
//    public void refreshView(List<PaymentManageInfo> data) {
//        mAllPayment.clear();
//        mAllPayment.addAll(data);
//        mAllPayment.add(buildEmpty());
//        if (mAdapter != null) {
//            mAdapter.notifyDataSetChanged();
//        }
//    }
//
//    private void editPayment(PaymentManageInfo model) {
//        int editType = PaymentEditView.TYPE_EDIT;
//        if (TextUtils.equals(model.fsPaymentId, EMPTY_PAYMENT_ID)) {
//            model = new PaymentManageInfo();
//            editType = PaymentEditView.TYPE_ADD;
//        }
//        PaymentEditView paymentEditView = PaymentEditView.newInstance();
//        paymentEditView.setOptPayment(model, editType)
//                .setListener(new OnResultListener<List<PaymentManageInfo>>() {
//                    @Override
//                    public void callBack(List<PaymentManageInfo> var1) {
//                        refreshView(var1);
//                    }
//                });
//        DialogManager.showCustomDialog(PaymentManageFragment.this, paymentEditView, PaymentEditView.TAG);
//    }
//
//    private void delPayment(final PaymentManageInfo model) {
//        DialogManager.showExecuteDialog(this, getString(R.string.account_manage_del), new DialogResponseListener() {
//            @Override
//            public void response() {
//                mProcess.delete(model);
//            }
//        });
//    }
//
//    private PaymentManageInfo buildEmpty() {
//        PaymentManageInfo result = new PaymentManageInfo();
//        result.fsPaymentId = EMPTY_PAYMENT_ID;
//        return result;
//    }
//
//    public GridLayoutManager getGridLayoutManager(int spanCount) {
//        final GridLayoutManager manager = new GridLayoutManager(getContextWithinHost(), spanCount);
//        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
//            @Override
//            public int getSpanSize(int position) {
//                if (mAdapter.isHeaderShow(position) || mAdapter.isFooterShow(position)) {
//                    return manager.getSpanCount();
//                }
//                return 1;
//            }
//        });
//        return manager;
//    }
//
//    private void start(ImageView mQRCodeIv) {
//        mQRCodeIv.post(new Runnable() {
//            @Override
//            public void run() {
//                Bitmap bmp = createQRImage(PaymentConstant.getUrlBindPay(), mQRCodeIv.getWidth(), mQRCodeIv.getHeight());
//                if (bmp == null) {
//                    ToastUtil.showToast("二维码生成失败");
//                    return;
//                }
//                mQRCodeIv.setImageBitmap(bmp);
//            }
//        });
//    }
//
//
//
//
//    private Bitmap createQRImage(String str, final int width, final int height) {
//        try {
//            return BarcodeUtil.createQRImage(str, width, height);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//}
