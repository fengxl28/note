package com.mwee.android.pos.business.login;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.MainThread;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.ClientApplication;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.business.backup.ForceSetAsMainHost;
import com.mwee.android.pos.business.bill.view.BillFragment;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.common.dialog.pay.KBNewFutureOrderNotice;
import com.mwee.android.pos.business.common.dialog.pay.KBNewOrderNotice;
import com.mwee.android.pos.business.common.dialog.pay.KBPreOrderNotice;
import com.mwee.android.pos.business.common.notification.CommonNotice;
import com.mwee.android.pos.business.common.notification.NoticeType;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.business.message.processor.FastfoodUtil;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.business.message.processor.abnormalOrders.AbnormalOrdersClientUtil;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderClientUtil;
import com.mwee.android.pos.business.message.processor.rapidOrder.RapidPayConformUtil;
import com.mwee.android.pos.business.message.processor.wechatFastFood.WechatFastFoodClientUtil;
import com.mwee.android.pos.business.message.processor.wechatOrder.WechatOrderClientUtil;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.setting.meituan.MeituanOverlayView;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.business.table.processor.TableBizProcessor;
import com.mwee.android.pos.business.table.processor.TableDBProcessor;
import com.mwee.android.pos.business.table.processor.TableViewProcessor;
import com.mwee.android.pos.business.tv.FloatViewProcess;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.component.basecon.CPublic;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.dialog.SingleDialogFragment;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.MydLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.notify.NotifyDispatchService;
import com.mwee.android.pos.component.notify.NotifySender;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.ShopPayResponse;
import com.mwee.android.pos.connect.business.data.GetDataFromCenterResponse;
import com.mwee.android.pos.connect.business.order.GetSellOutResponse;
import com.mwee.android.pos.connect.business.order.PayConfirmResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.FastfoodUnDealCountResponse;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.tv.connect.TVConfig;
import com.mwee.android.pos.util.ClientHardwareUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.PlaySound;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.android.upgrade.processor.UpgradeProcessor;

import java.util.ArrayList;
import java.util.List;

/**
 * LoginDriver
 * Created by virgil on 16/8/15.
 */
@SuppressWarnings("unused")
public class LoginDriver implements IDriver {
    private final static String TAG = "login";

    @Override
    public String getModuleName() {
        return TAG;
    }

    @DrivenMethod(uri = TAG + "/syncShopPayStatus")
    public void syncShopPayStatus(String data) {
        if (TextUtils.isEmpty(data)) {
            return;
        }
        try {
            ShopPayResponse shopPay = JSON.parseObject(data, ShopPayResponse.class);
            // 更新是否允许退款配置
            if (shopPay != null) {
                SettingHelper.putLocalSetting(META.ALLOW_ALIPAY_BACK, shopPay.allowAliPayBack ? "1" : "0");
                SettingHelper.putLocalSetting(META.ALLOW_WXPAY_BACK, shopPay.allowWxPayBack ? "1" : "0");
            }
        } catch (Exception e) {
            LogUtil.logError("parse ShopPayResponse exception", e);
        }
    }

    @DrivenMethod(uri = "login/dataSyncFailed")
    public void dataSyncFailed(String code, String message) {
        DriverBus.call("logindinnerfragment/dataSyncFailed", code, message);
    }

    @DrivenMethod(uri = "login/dataSyncProgress")
    public void dataSyncProgress(String progress, String tag) {
        DriverBus.call("logindinnerfragment/dataSyncProgress", progress, tag);
    }

    @DrivenMethod(uri = "login/uploadDataProgress")
    public void uploadDataProgress(String progress, String tag) {
        DriverBus.call("setting/uploadDataProgress", progress, tag);
    }

    @DrivenMethod(uri = "login/dataSyncResult")
    public void dataSyncResult(String code, String message) {
        LogUtil.logBusiness("LoginDriver", "dataSyncResult   " + code + ", " + message);
        DriverBus.call("setting/dataSyncResult", code, message);
    }

    @DrivenMethod(uri = "login/writeHostData")
    public void writeHostData(final Host host, HostDBModel hostDBModel, String shopID) {
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, hostDBModel.fsHostId);
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, hostDBModel.fsHostId);

    }

    @DrivenMethod(uri = "login/show_progress")
    public void j(final Host host, boolean cancelAble) {
        ProgressManager.showProgress(host, "请稍等", cancelAble);
    }

    @DrivenMethod(uri = "login/show_progress_content")
    public void showProgress(final Host host, String content, boolean cancelAble) {
        ProgressManager.showProgress(host, content, cancelAble);
    }

    @DrivenMethod(uri = "login/close_progress")
    public void closeProgress(final Host host) {
        ProgressManager.closeProgress(host);
    }

    /**
     * 站点首次绑定并初始化成功,
     *
     * @param host Host
     */
    @DrivenMethod(uri = TAG + "/startbusiness")
    public void e(final Host host) {
        final Progress progress = ProgressManager.showProgressUncancel(host, "正在准备数据");
        BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                MydLog.refreshConfig();
                ServerConnector.getInstance().sendExecute("biz/finishActive");
                AppCache.getInstance().init();
                ClientApplication.initBiz();
                AppCache.getInstance().refresh();
                return true;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                progress.dismiss();
                UIHelp.startLoginDinnerActvity(host.getActivityWithinHost());
                host.getActivityWithinHost().finish();
            }
        });
    }

    @DrivenMethod(uri = TAG + "/sync_data_from_center")
    public void f(final Host host, final IResult result) {
        MCon.c(CPublic.class, new ConCallBack<GetDataFromCenterResponse>() {
            @Override
            public void subCall(SocketResponse<GetDataFromCenterResponse> socketResponse) {
                if (socketResponse != null && socketResponse.success()) {
                    GetDataFromCenterResponse response = socketResponse.data;
                    if (response != null && !TextUtils.isEmpty(response.datas)) {
                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_CLIENT, response.datas, response.newTimeTag);
                        AppCache.getInstance().init();
                        AppCache.getInstance().refresh();
                    }
                }
            }

            @Override
            public void callback(SocketResponse<GetDataFromCenterResponse> socketResponse) {
                if (socketResponse != null && socketResponse.success()) {
                    //在数据同步成功的情况下，必须返回空字符串
                    result.callBack(true, "");
                } else {
                    result.callBack(false, (socketResponse != null && !TextUtils.isEmpty(socketResponse.message)) ? socketResponse.message : "同步数据失败");
                }
            }
        }).syncData();
    }

    /**
     * 登录中控失败
     */
    @DrivenMethod(uri = TAG + "/loginPDError")
    public void showMwPwdError(String errorInfo) {
        if (AppCache.getInstance().loginErrshowDialog) {
            if (BaseActivity.topActivity != null) {
                showMwPwdErrDoalog(errorInfo);
            } else {
                ToastUtil.showToast("无法收到秒点订单, 原因[" + errorInfo + "]");
            }
        } else {
            ToastUtil.showToast("无法收到秒点订单, 原因[" + errorInfo + "]");
        }
        notShowMwPwdErrDoalog(errorInfo);

    }

    /**
     * 中控登录失败--显示弹框提示
     *
     * @param errMsg
     */
    private void showMwPwdErrDoalog(final String errMsg) {
        DialogManager.showExecuteDialog(BaseActivity.topActivity, "无法收到秒点订单,原因[" + errMsg + "]", "重试", "我知道了", new DialogResponseListener() {
                    @Override
                    public void response() {
                        AppCache.getInstance().loginErrshowDialog = false;
                        notShowMwPwdErrDoalog(errMsg);
                    }
                },
                new DialogResponseListener() {
                    @Override
                    public void response() {
                        AppCache.getInstance().loginErrshowDialog = true;
                        NotifyToServer.doPDLogin();
                    }
                });
    }

    /**
     * 中控登录失败Toast+Notification提示
     *
     * @param errMsg String
     */
    private void notShowMwPwdErrDoalog(final String errMsg) {
        AppCache.getInstance().loginErrshowDialog = false;
        //通知内容的准备
        Intent notifyIntent = new Intent(GlobalCache.getContext(), NotifyDispatchService.class);
        //设置收到的订单信息
        notifyIntent.putExtra(NotifyDispatchService.ENTER_TYPE_KEY, NotifyDispatchService.ENTER_TYPE_VALUE_DO_LOGIN_MWEE);
        PendingIntent contentIntent = PendingIntent.getService(GlobalCache.getContext(), NotifyDispatchService.NOTITY_ID_LOGIN_ERROR, notifyIntent, 0);
        NotifySender.sendNotify(NotifyDispatchService.NOTITY_ID_LOGIN_ERROR, "无法收到秒点订单", "原因[" + errMsg + "]", contentIntent);
    }

    /**
     * 执行关闭站点的操作并跳转到开门页
     */
    @DrivenMethod(uri = TAG + "/closeDoor")
    public void close() {
        // 1清除本地估清菜品 2数据提交到bizCenter主机 更新DB
        AppCache.getInstance().updateBusinessDate("");
        //update 重置沽清的条件放到日切之后
//        AppCache.getInstance().clearSellOut();
        if (BaseActivity.topActivity != null) {
            UIHelp.startLoginDinnerActvity(BaseActivity.topActivity);
        }

        ActionLog.waiterID = "";
        ActionLog.waiterName = "";
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_STATUS, HostStatus.CLOSE);
        AppCache.getInstance().userDBModel = null;
        // 清除站点拼桌信息
        TableDBProcessor.cleanShareTables(null);

        DriverBus.call("main/leave", true);
    }

    /**
     * 登出
     */
    @DrivenMethod(uri = TAG + "/callLogout")
    public void jumpToLogin(String error) {
        // 1清除本地估清菜品 2数据提交到bizCenter主机 更新DB
        DriverBus.call("main/logout");
        if (!TextUtils.isEmpty(error)) {
            ToastUtil.showToast(error);
        }
    }

    /**
     * 更新估清数据
     */
    @DrivenMethod(uri = TAG + "/refresh_menu_unit")
    public void refreshAllMenu() {

        MCon.c(COrder.class, new SocketCallback<GetSellOutResponse>() {
            @Override
            public void callback(SocketResponse<GetSellOutResponse> socketResponse) {
                DriverBus.broadcast("selloutchanged");
            }
        }, new SocketThreadCallback<GetSellOutResponse>() {
            @Override
            public void callback(SocketResponse<GetSellOutResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    OrderDishesBizUtil.updateSellOutUnit(socketResponse.data.dataList);
                }
            }
        }).GetSellOutRequest(false);
    }

    /**
     * 打印指定的小票
     *
     * @param task
     */
    @DrivenMethod(uri = TAG + "/printReceipt")
    public void printReceipt(final String task) {
        //收到消息
        LogUtil.logBusiness("-----收到小票任务----");
        PrintConnector.getInstance().printSyncTaskFromServer(JSON.parseObject(task, PrintTaskDBModel.class));
    }

    @DrivenMethod(uri = TAG + "/rePrintReceipt")
    public void rePrintReceipt(final String task) {
        PrintConnector.getInstance().print(JSON.parseObject(task, PrintTaskDBModel.class));
    }

    @DrivenMethod(uri = TAG + "/rapidorderchange")
    public void rapidorderchange(String tableID) {
        refreshTablesFromBiz();

        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    DialogManager.showSingleDialog(BaseActivity.topActivity, "收到顾客的秒点订单，请确认");
                }
            }, 1000);
        }
    }

    /**
     * 口碑订单 桌台消息变更
     * 目前处理 口碑后付款支付通知 接单成功
     *
     * @param tableID
     */
    @DrivenMethod(uri = TAG + "/kborderchange")
    public void kborderchange(String tableID) {
        refreshTablesFromBiz();
        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
        }
    }

    @DrivenMethod(uri = TAG + "/shareShopOrderChange")
    public void shareShopOrderChange(String tableID) {
        refreshTablesFromBiz();

        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    DialogManager.showSingleDialog(BaseActivity.topActivity, "收到线上退款信息，请确认");
                }
            }, 1000);
        }
    }

    @DrivenMethod(uri = TAG + "/orderChangeForSmart")
    public void orderChangeForSmart(String orderID, String tableID) {
//        BackUpDataAuto.startSyncOrderInfo(orderID);
        refreshTablesFromBiz();

        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    DialogManager.showSingleDialog(BaseActivity.topActivity, "美小二修改了订单内容，请确认");
                }
            }, 1000);
        }
    }

    /**
     * 预定提醒
     */
    @DrivenMethod(uri = TAG + "/newBookOrderTips", UIThread = true)
    public void netOrderPrintErr(String tipMsg) {
        Host host = BaseActivity.topActivity;
        if (host != null) {
            DialogManager.showSingleDialog(host, tipMsg, "预定单提醒", "知道了", null);
        }
    }

    /**
     * 订单信息发生了变化。
     *
     * @param orderID String | 订单号
     */
    @DrivenMethod(uri = TAG + "/orderChange")
    public void orderChange(String orderID) {
//        BackUpDataAuto.startSyncOrderInfo(orderID);
        refreshTablesFromBiz();
    }

    /**
     * 骑手取消订单
     */
    @DrivenMethod(uri = TAG + "/orderChangeWithinDeliveryCancel")
    public void orderChangeWithinDeliveryCancel() {
        CommonNotice notice = new CommonNotice.Builder()
                .setType(NoticeType.DELIVERY_CANCEL)
                .setContent("有外卖订单配送异常，请前往消息中心处理")
                .setPisitive("前往消息中心")
                .setPositiveCallback(() -> {
                    if (BaseActivity.topActivity != null) {
                        MessageV2Fragment.index = 3;
                    }
                    DriverBus.call("main/closesub");
//                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                })
                .setNegative("忽略")
                .create();
        notice.show();
    }

    @DrivenMethod(uri = TAG + "/callRefrehMessageData")
    public void refrehMessageData() {
        MessageUtil.getUndealMessageCount(AppCache.getInstance().businessDate);
        DriverBus.broadcast("refrehMessageData");
    }

    @DrivenMethod(uri = "login/cloudShopInfoChange")
    public void cloudShopInfoChange() {
        DriverBus.call("main/updateUserNameColor", true);
        DriverBus.call("logindinnerfragment/showUpdate");
    }

    @DrivenMethod(uri = "login/hideSyncUpdate")
    public void hideSyncUpdate() {
        ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
        DriverBus.call("logindinnerfragment/hideUpdate");
//        DriverBus.call("main/updateUserNameColor", false);
    }

    @DrivenMethod(uri = TAG + "/refreshUndealMessage")
    public void refreshUndealMessage() {
        MessageUtil.getUndealMessageCount(AppCache.getInstance().businessDate);
    }

    /**
     * 上送日志
     */
    @DrivenMethod(uri = TAG + "/uploadLog")
    public void uploadLog() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                LogUpload.manualUpload();
                MwLog.manualCallUploadLog();
            }
        }).start();
    }

    /**
     * 支付新消息通知
     * 1、获取数量
     * 2、通知页面刷新
     * 3、播放音频通知
     *
     * @param areaId 该消息所属的区域ID
     */
    @DrivenMethod(uri = TAG + "/newPayMessage")
    public void newPayMessage(String msgType, String areaId, String tableName) {
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messagePay/refrehMessageData");
        //3
//        PlaySound.playVoid(areaId, "pay.ogg");
        // 文字中的标点用来模拟播放间隔
        if (TextUtils.isEmpty(tableName.trim())) {
            PlaySound.newInstance().playVoid(areaId, "pay.ogg");
        } else {
            PlaySound.newInstance().playBySyntherizer(areaId, "桌台，，，，，。。。。。" + tableName + "有客人买单");
        }
    }

    /**
     * 支付新异常订单消息通知
     * 1、弹框
     * 2、更新数据
     * 3、播放音频通知
     *
     * @param billNo 该消息所属的区域ID
     */
    @DrivenMethod(uri = TAG + "/addAbnormalOrderMessage")
    public void addAbnormalOrderMessage(String msgType, String billNo) {
        //1
//        if (!AbnormalMessageNotice.getInstance().isShow) {
//            AbnormalMessageNotice.getInstance().showFloatWindow(billNo);
//        }
        CommonNotice notice = new CommonNotice.Builder()
                .setType(NoticeType.ABNORMAL)
                .setContent("您有一条异常订单，请及时处理！")
                .setPisitive("前往消息中心")
                .setPositiveCallback(() -> {
                    if (BaseActivity.topActivity != null) {
                        MessageV2Fragment.index = 6;
                        if (APPConfig.isAir()) {
                            UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                        } else {
                            DriverBus.call("main/closesub");
                            DriverBus.call("main/closesub");
//                            DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                            DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                        }
                    }
                })
                .setNegative("忽略")
                .create();
        notice.show();
        //2
        optAbnormalOrderInfo("", billNo);
        //3
        PlaySound.newInstance().playVoid("", "abnormal_order.ogg");
    }

    /**
     * 有异常订单数据被更新了
     *
     * @param msgId 消息ID
     */
    @DrivenMethod(uri = TAG + "/optAbnormalOrderInfo")
    public void optAbnormalOrderInfo(String msgId, String billNo) {
        // 数据更新
        (new AbnormalOrdersClientUtil()).optAbnormalOrderInfo(msgId, billNo);
    }

    /**
     * 更新系统消息
     *
     * @param msgType
     */
    @DrivenMethod(uri = TAG + "/newSystemMessage")
    public void newSystemMessage(String msgType, String session) {
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messageSystem/refrehMessageData");
        // 登录后，Client 进程赋值
        if (!TextUtils.equals(session, "-1")) {
            ClientMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, session);
            LogUpload.SESSION = session;
        } else {
            ClientMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, "");
            LogUpload.SESSION = "";
        }
    }

    /**
     * 新微信快餐消息
     * 1、获取数量
     * 2、通知页面刷新
     * 3、播放音频通知
     */
    @DrivenMethod(uri = TAG + "/addFastFoodMessage")
    public void addFastFoodMessage(String msgId) {
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messageWechatFastFood/refrehMessageData");
        //3
//        PlaySound.playVoid("", "order.ogg");
        PlaySound.newInstance().playBySyntherizer("", "有客人点菜");

        FastfoodUtil.getUnDealFastFoodMsgCount(AppCache.getInstance().businessDate, new SocketCallback<FastfoodUnDealCountResponse>() {
            @Override
            public void callback(SocketResponse<FastfoodUnDealCountResponse> response) {
                if (response.success() && response.data.count > 0) {
//                    if (FastFoodRapidMessageNotice.getInstance().isShow) {
//                        FastFoodRapidMessageNotice.getInstance().updateFloatWindow(response.data.count + "");
//                    } else {
//                        FastFoodRapidMessageNotice.getInstance().showFloatWindow(response.data.count + "");
//                    }
                    CommonNotice notice = new CommonNotice.Builder()
                            .setType(NoticeType.FAST_FOOD_RAPID)
                            .setContent("有" + response.data.count + "个微信快餐订单，请前往消息中心处理！")
                            .setPisitive("前往消息中心")
                            .setPositiveCallback(() -> {
                                if (BaseActivity.topActivity != null) {
//                                    ActivityManager.getInstance().finishOtherActivity(MainDinnerActivity.class);
                                    MessageV2Fragment.index = 5;
                                    DriverBus.call("main/closesub");
                                    DriverBus.call("main/closesub");
//                                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                }
                            })
                            .setNegative("忽略")
                            .create();
                    notice.show();
                }
            }
        });
    }

    /**
     * 外卖单未映射菜品提示
     */
    @DrivenMethod(uri = TAG + "/thirdOrderMappingTip")
    public void thirdOrderMappingTip(String count) {
        if (StringUtil.toInt(count, 0) > 0) {
//            if (ThirdOrderMessageNotice.getInstance().isShow) {
//                ThirdOrderMessageNotice.getInstance().updateFloatWindow(count);
//            } else {
//                ThirdOrderMessageNotice.getInstance().showFloatWindow(count);
//            }
            CommonNotice notice = new CommonNotice.Builder()
                    .setType(NoticeType.THIRD_ORDER)
                    .setTitle(String.format(GlobalCache.getContext().getString(R.string.third_order_mapping_message), count))
                    .setContent("未关联菜品可在后台“设置”-“菜品映射”中操作")
                    .setPisitive("前往消息中心")
                    .setPositiveCallback(() -> {
                        if (BaseActivity.topActivity != null) {
                            BillFragment.index = 2;
//                            DriverBus.call("main/jump", MAIN_TAB.BILL);
                            DriverBus.call("main/closesub");
                            DriverBus.call("main/closesub");
                            DriverBus.call("main/superJump", MAIN_TAB.BILL);
                        }
                    })
                    .setNegative("忽略")
                    .create();
            notice.show();
        }
    }

    /**
     * 新秒付拉单确认消息
     * 1、获取数量
     * 2、通知页面刷新
     * 3、播放音频通知
     */
    @DrivenMethod(uri = TAG + "/addRapidPayConfirm")
    public void addRapidPayConfirm(String msgId) {
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messagePay/refrehMessageData");
        //3
//        MessageBiz.playVoid("", "pay.ogg");
        RapidPayConformUtil.unDealConfirmMessageList(new SocketCallback<PayConfirmResponse>() {
            @Override
            public void callback(SocketResponse<PayConfirmResponse> response) {
                if (response.success() && !ListUtil.isEmpty(response.data.payConfirmBeanList)) {
//                    RapidPayMessageDialogFragment fragment = new RapidPayMessageDialogFragment();
//                    fragment.setData(response.data.payConfirmBeanList);
//                    DialogManager.showCustomDialog(BaseActivity.topActivity, fragment, "");

//                    if (RapidPayMessageNotice.getInstance().isShow) {
//                        RapidPayMessageNotice.getInstance().updateFloatWindow(response.data.payConfirmBeanList.size() + "");
//                    } else {
//                        RapidPayMessageNotice.getInstance().showFloatWindow(response.data.payConfirmBeanList.size() + "");
//                    }

                    CommonNotice notice = new CommonNotice.Builder()
                            .setType(NoticeType.RAPID_PAY)
                            .setContent(String.format(GlobalCache.getContext().getString(R.string.rapid_pay_message), response.data.payConfirmBeanList.size() + ""))
                            .setPisitive("前往消息中心")
                            .setPositiveCallback(() -> {
                                if (BaseActivity.topActivity != null) {
                                    MessageV2Fragment.index = 1;
                                    DriverBus.call("main/closesub");
                                    DriverBus.call("main/closesub");
//                                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                }
                            })
                            .setNegative("忽略")
                            .create();
                    notice.show();
                }
            }
        });
    }

    /**
     * 点菜新消息通知
     * 1、获取数量
     * 2、通知页面刷新
     * 3、播放音频通知
     *
     * @param areaId
     */
    @DrivenMethod(uri = TAG + "/newOrderMessage")
    public void newOrderMessage(String msgType, String areaId, String tableName) {
        LogUtil.log("点菜新消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messageOrder/refrehMessageData");
        //3
//        PlaySound.playVoid(areaId, "order.ogg");
        // 文字中的标点用来模拟播放间隔
        if (TextUtils.isEmpty(tableName.trim())) {
            PlaySound.newInstance().playVoid(areaId, "order.ogg");
        } else {
            PlaySound.newInstance().playBySyntherizer(areaId, "桌台，，，，，。。。。。" + tableName + "有客人点菜");
        }
    }

    /**
     * 点菜新消息通知
     * 1、获取数量
     * 2、通知页面刷新
     * 3、播放音频通知
     *
     * @param areaId
     */
    @DrivenMethod(uri = TAG + "/receiveRapidOrderAndRefresh")
    public void newOrderMessage(String areaId, String tableName) {
        if (!PlaySound.newInstance().checkPlay(areaId)) {
            return;
        }
        LogUtil.log("点菜新消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        //1
        refreshUndealMessage();
        //2
        DriverBus.call("messageOrder/refrehMessageData");

        // 文字中的标点用来模拟播放间隔
        if (TextUtils.isEmpty(tableName.trim())) {
            PlaySound.newInstance().playBySyntherizer(areaId, "有客人加菜失败");
        } else {
            PlaySound.newInstance().playBySyntherizer(areaId, "桌台，，，，，。。。。。" + tableName + "客人加菜失败");
        }

        if (Looper.myLooper() != Looper.getMainLooper()) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    CommonNotice notice = new CommonNotice.Builder()
                            .setType(NoticeType.RAPID_ORDER)
                            .setContent("桌台" + tableName + "客人加菜失败，请前往消息中心查看")
                            .setPisitive("前往消息中心")
                            .setPositiveCallback(() -> {
                                if (BaseActivity.topActivity != null) {
                                    MessageV2Fragment.index = 0;
                                    if (APPConfig.isAir()) {
                                        UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                                    } else {
                                        DriverBus.call("main/closesub");
                                        DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                    }
                                }
                            })
                            .setNegative("忽略")
                            .create();
                    notice.show();
                }
            });
        } else {
            CommonNotice notice = new CommonNotice.Builder()
                    .setType(NoticeType.RAPID_ORDER)
                    .setContent("桌台" + tableName + "客人加菜失败，请前往消息中心查看")
                    .setPisitive("前往消息中心")
                    .setPositiveCallback(() -> {
                        if (BaseActivity.topActivity != null) {
                            MessageV2Fragment.index = 0;
                            if (APPConfig.isAir()) {
                                UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                            } else {
                                DriverBus.call("main/closesub");
                                DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                            }
                        }
                    })
                    .setNegative("忽略")
                    .create();
            notice.show();
        }

    }

    /**
     * 更新网络订单信息
     *
     * @param appOrderId 订单详情
     */
    @DrivenMethod(uri = TAG + "/updateTempApporder")
    public void updateTempApporder(String appOrderId) {
        LogUtil.logBusiness("网络订单更新通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        try {
            NetOrderClientUtil.optTempAppOrderFromBizById(appOrderId, false);
        } catch (Exception e) {
            LogUtil.logBusiness("LoginDriver.updateTempApporder()网络订单更新通知:" + e.getMessage());
        }
    }

    /**
     * 新增网络订单信息
     *
     * @param appOrderId 订单号
     */
    @DrivenMethod(uri = TAG + "/addNewTempAppOrder")
    public void addNewTempAppOrder(String appOrderId, String bizType, String source, String date) {

        NotifyDispatchService.notifyOrderList++;
        if (refreshDelayQueue == null) {
            refreshDelayQueue = new DelayQueue<>("addNewTempAppOrder");
            refreshDelayQueue.setWorker(refreshWorker);
            refreshDelayQueue.setDelay(2000);
        }
        LogUtil.logBusiness("网络订单新消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        try {
            refreshDelayQueue.addTask("RefreshNetOrderTips");
        } catch (Exception e) {
            LogUtil.logError("LoginDriver.addNewTempAppOrder()新网络消息订单异常:" + e.getMessage(), e);
        }
    }

    /**
     * 自动配送失败通知
     *
     * @param appOrderId 订单号
     */
    @DrivenMethod(uri = TAG + "/autoDeliveryFail")
    public void autoDeliveryFail(String appOrderId, String reason) {
        NotifyDispatchService.autoDeliveryFailCount++;
        if (refreshAutoDeliveryFailQueue == null) {
            refreshAutoDeliveryFailQueue = new DelayQueue<>("autoDeliveryFailNotify");
            refreshAutoDeliveryFailQueue.setWorker(refreshAutoDeliveryFailWorker);
            refreshAutoDeliveryFailQueue.setDelay(2000);
        }
        LogUtil.logBusiness(appOrderId + "自动配送失败通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + " " + reason);
        LogUtil.logBusiness(NotifyDispatchService.autoDeliveryFailCount + "个未读数量 自动配送失败通知");
        try {
            refreshAutoDeliveryFailQueue.addTask("AutoDeliveryFail");
        } catch (Exception e) {
            LogUtil.logError("LoginDriver.autoDeliveryFail()自动配送失败通知:" + e.getMessage(), e);
        }
    }

    //刷新
    DelayQueue refreshDelayQueue;

    private IDQWorker refreshWorker = new IDQWorker() {
        @Override
        public void work(Object o) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        CommonNotice notice = new CommonNotice.Builder()
                                .setType(NoticeType.NET_ORDER)
                                .setContent("已收到" + NotifyDispatchService.notifyOrderList + "个外卖订单,请前往消息中心处理")
                                .setPisitive("前往消息中心")
                                .setPositiveCallback(() -> {
                                    NotifyDispatchService.notifyOrderList = 0;
                                    if (BaseActivity.topActivity != null) {
                                        MessageV2Fragment.index = 3;
                                        if (APPConfig.isAir()) {
                                            UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                                        } else {
                                            DriverBus.call("main/closesub");
//                                            DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                                            DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                        }
                                    }
                                })
                                .setNegative("忽略")
                                .create();
                        notice.show();
                    }
                });
            } else {
                CommonNotice notice = new CommonNotice.Builder()
                        .setType(NoticeType.NET_ORDER)
                        .setContent("已收到" + NotifyDispatchService.notifyOrderList + "个外卖订单,请前往消息中心处理")
                        .setPisitive("前往消息中心")
                        .setPositiveCallback(() -> {
                            NotifyDispatchService.notifyOrderList = 0;
                            if (BaseActivity.topActivity != null) {
                                MessageV2Fragment.index = 3;
                                if (APPConfig.isAir()) {
                                    UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                                } else {
                                    DriverBus.call("main/closesub");
//                                    DriverBus.call("main/jump", MAIN_TAB.MESSAGE);
                                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                }
                            }
                        })
                        .setNegative("忽略")
                        .create();
                notice.show();
            }

            NotifySender.playSound();
            refreshUndealMessage();
            DriverBus.broadcast("refrehMessageData");  //通知消息中心页面刷新订单列表

            DriverBus.call("billTakeOut/refrehNetOrderData");  //通知消息中心页面刷新订单列表

            refreshDelayQueue.done("RefreshNetOrderTips");
        }
    };

    DelayQueue refreshAutoDeliveryFailQueue;
    private IDQWorker refreshAutoDeliveryFailWorker = new IDQWorker() {
        @Override
        public void work(Object o) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        CommonNotice notice = new CommonNotice.Builder()
                                .setType(NoticeType.NET_ORDER)
                                .setContent(NotifyDispatchService.autoDeliveryFailCount + "个外卖配送失败，请及时处理")
                                .setPisitive("前往消息中心")
                                .setPositiveCallback(() -> {
                                    NotifyDispatchService.autoDeliveryFailCount = 0;
                                    if (BaseActivity.topActivity != null) {
                                        MessageV2Fragment.index = 3;
                                        if (APPConfig.isAir()) {
                                            UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                                        } else {
                                            DriverBus.call("main/closesub");
                                            DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                        }
                                    }
                                })
                                .setNegative("忽略")
                                .create();
                        notice.show();
                    }
                });
            } else {
                CommonNotice notice = new CommonNotice.Builder()
                        .setType(NoticeType.NET_ORDER)
                        .setContent(NotifyDispatchService.autoDeliveryFailCount + "个外卖配送失败，请及时处理")
                        .setPisitive("前往消息中心")
                        .setPositiveCallback(() -> {
                            NotifyDispatchService.autoDeliveryFailCount = 0;
                            if (BaseActivity.topActivity != null) {
                                MessageV2Fragment.index = 3;
                                if (APPConfig.isAir()) {
                                    UIHelp.jumpStartActivity(BaseActivity.topActivity, "消息中心", MessageV2Fragment.class);
                                } else {
                                    DriverBus.call("main/closesub");
                                    DriverBus.call("main/superJump", MAIN_TAB.MESSAGE);
                                }
                            }
                        })
                        .setNegative("忽略")
                        .create();
                notice.show();
            }

            PlaySound.newInstance().playBySyntherizer("","外卖配送失败，请及时处理");

            refreshUndealMessage();
            DriverBus.broadcast("refrehMessageData");  //通知消息中心页面刷新订单列表

            DriverBus.call("billTakeOut/refrehNetOrderData");  //通知消息中心页面刷新订单列表

            refreshAutoDeliveryFailQueue.done("AutoDeliveryFail");
        }
    };


    /**
     * 后付款 口碑订单 支付信息变更
     * 目前处理 口碑后付款支付通知
     *
     * @param tableID
     * @param tableName
     */
    @DrivenMethod(uri = TAG + "/kbFutureOrderPay")
    public void kbFutureOrderPay(String tableID, String tableName) {
        refreshTablesFromBiz();
        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
        }
        PlaySound.newInstance().playBySyntherizer(String.format("桌台%s有客人买单", tableName));
    }


    /**
     * 后付款 口碑订单 桌台消息变更
     * 目前处理 口碑后付款支付通知 接单成功
     *
     * @param tableID
     * @param tableName
     */
    @DrivenMethod(uri = TAG + "/kborderchange")
    public void kborderchange(String tableID, String tableName) {

        refreshTablesFromBiz();
        if (BaseActivity.topActivity != null && TextUtils.equals(AppCache.getInstance().orderingTableID, tableID)) {
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
        }
    }


    /**
     * 新增口碑预点单
     *
     * @param tableName 桌台名称
     */
    @DrivenMethod(uri = TAG + "/addNewKBFutureOrder")
    public void addNewKBFutureOrder(String tableName) {

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                KBNewFutureOrderNotice.getInstance().showFloatWindow(String.format("桌台%s有客人点菜", tableName));
            }
        });
        PlaySound.newInstance().playBySyntherizer(String.format("桌台%s有客人点菜", tableName));
    }



    /*-----推送收到口碑预点单----*/

    /**
     * 新增口碑预点单
     *
     * @param appOrderId 订单号
     */
    @DrivenMethod(uri = TAG + "/addNewKBPreOrder")
    public void addNewKBPreOrder(String appOrderId) {

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                NotifyDispatchService.notifyKBOrderCount++;
                KBNewOrderNotice.getInstance().showFloatWindow();
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单新消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "订单号-->" + appOrderId);
            }
        });
        NotifySender.playSound();
    }


    /**
     * 收到  口碑用户发起退款
     *
     * @param appOrderId 订单号
     */
    @DrivenMethod(uri = TAG + "/kbOrderApplyRefund")
    public void kbOrderApplyRefund(String appOrderId) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                NotifyDispatchService.notifyKBOrderApplyRefundCount++;
                KBPreOrderNotice kbPreOrderNotice = KBPreOrderNotice.getInstance();
                kbPreOrderNotice.setCurrentIndex(0);
                kbPreOrderNotice.setParams(KBPreOrderNotice.ACTION_REFUND, NotifyDispatchService.notifyKBOrderApplyRefundCount + "个口碑单退款申请");
                kbPreOrderNotice.showFloatWindow();
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "收到  口碑用户发起退款消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "订单号-->" + appOrderId);
            }
        });
        PlaySound.newInstance().playBySyntherizer("您有一条退款申请，请及时处理");
    }


    /**
     * 收到异常的口碑订单
     *
     * @param order_id 口碑订单号
     */
    @DrivenMethod(uri = TAG + "/KBOrderException")
    public void KBOrderException(String order_id, String index) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                NotifyDispatchService.notifyKBOrderExceptionCount++;
                KBPreOrderNotice kbPreOrderNotice = KBPreOrderNotice.getInstance();
                kbPreOrderNotice.setCurrentIndex(Integer.valueOf(index));
                kbPreOrderNotice.setParams(KBPreOrderNotice.ACTION_MENU_EXCEPTION, NotifyDispatchService.notifyKBOrderExceptionCount + "笔口碑单接单失败");
                kbPreOrderNotice.showFloatWindow();
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "收到  收到异常的口碑订单 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "订单号-->" + order_id);
            }
        });
        PlaySound.newInstance().play("exception_order.ogg");
    }


    /**
     * 口碑堂食预点单退款0元结账 需要清除桌台信息
     */
    @DrivenMethod(uri = TAG + "/clearDishCache")
    public void clearDishCache() {

        DriverBus.call("_AirTableContainer/clearDishCache");

    }


    /**
     * 刷新口碑订单数据 美易点主辅机需要使用
     */
    @DrivenMethod(uri = TAG + "/refreshKBOrderItem")
    public void refreshKBOrderItem(String param) {
        DriverBus.call("kbOrderFragment/refreshKBOrderItem", JSON.parseObject(param, KBPreOrderUpdateResponse.class));
    }


    /**
     * 刷新口碑订单数据 美易点主辅机需要使用
     */
    @DrivenMethod(uri = TAG + "/refreshKBFutureOrderItem")
    public void refreshKBFutureOrderItem(String id, String status) {
        DriverBus.call("kbFutureOrderFragment/refreshKBFutureOrderItem", id, status);
    }


    /**
     * 更新微信外卖信息
     *
     * @param appOrderId 订单详情
     */
    @DrivenMethod(uri = TAG + "/updateWechatOrder")
    public void updateWechatOrder(String appOrderId) {
        LogUtil.logBusiness("微信外卖更新通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        try {
            WechatOrderClientUtil.optWechatOrderFromBizById(appOrderId, false);
        } catch (Exception e) {
            LogUtil.logBusiness("LoginDriver.updateTempApporder()微信外卖更新通知:" + e.getMessage());
        }
    }

    /**
     * 更新微信快餐信息
     *
     * @param outerOrderId 订单ID
     */
    @DrivenMethod(uri = TAG + "/updateWechatFastFood")
    public void updateWechatFastFood(String outerOrderId) {
        LogUtil.logBusiness("微信快餐更新通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        try {
            WechatFastFoodClientUtil.optWechatFastfoodFromBizById(outerOrderId, false);
        } catch (Exception e) {
            LogUtil.logBusiness("LoginDriver.updateWechatFastFood()微信快餐更新通知:" + e.getMessage());
        }
    }

    /**
     * 新增网络订单信息
     *
     * @param appOrderId 订单号
     */
    @DrivenMethod(uri = TAG + "/addNewWechatOrder")
    public void addNewWechatOrder(String appOrderId, String date) {
        LogUtil.logBusiness("微信外卖新消息通知 ： " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        try {
            NotifySender.showOrderNotify(appOrderId, 0);
            refreshUndealMessage();
            DriverBus.broadcast("refrehMessageData");  //通知消息中心页面刷新订单列表

        } catch (Exception e) {
            LogUtil.logBusiness("LoginDriver.addNewWechatOrder()新微信外卖异常:" + e.getMessage());
        }
    }

    /**
     * 本地设置更新关于Meta的设置
     *
     * @param type
     * @param value
     */
    @DrivenMethod(uri = "login/refreshClientSetting")
    public static void refreshSetting(String type, String value) {
        SettingHelper.putLocalSetting(StringUtil.toInt(type), value);
        PrintConnector.getInstance().refreshSetting();
        DriverBus.broadcast("refreshSetting", type, value);
        if (TextUtils.equals(type, META.PRINT_BAR_CODE + "")) {
            DriverBus.call("login/showScanFloatView");
        } else if (TextUtils.equals(type, META.TV_ADDRESS + "")) {
            TVConfig.ADDRESS = value;
        } else if (type.equals(String.valueOf(META.XMPP_BBOX))) {
            ClientMetaUtil.updateSettingsValueByKey(META.XMPP_BBOX, value);
            LogUtil.setOnlineDebugMode("1".equals(value));
            PrintConnector.getInstance().refreshSetting();  //更新打印进程
        } else if (TextUtils.equals(type, String.valueOf(META.SWITCH_MEITUAN_OVERLAY))) {
            // 美团悬浮球状态变更
            DriverBus.call("login/showMeituanOverlay");
        }
    }

    /**
     * 本地设置更新关于Meta的设置
     *
     * @param value
     */
    @DrivenMethod(uri = "login/refreshBatchSetting")
    public static void refreshBatchSetting(String value) {
        try {
            List<DataModel> paramList = JSON.parseArray(value, DataModel.class);
            if (!ListUtil.isEmpty(paramList)) {
                List<Pair<Integer, String>> list = new ArrayList<Pair<Integer, String>>();

                for (DataModel model : paramList) {
                    Pair<Integer, String> pair = new Pair<Integer, String>(StringUtil.toInt(model.id), model.value);
                    list.add(pair);
                }
                ClientMetaUtil.updateSettingsValueByKey(list);
            }
        } catch (Exception e) {
            LogUtil.logError("批量更新配置异常 value = " + value, e);
        }
    }

    /**
     * 餐厅设置,更新存在tbparamvalue的设置
     *
     * @param type
     * @param value
     */
    @DrivenMethod(uri = "login/refreshClientDBConfig")
    public static void refreshDBConfig(String type, String value) {
        SettingHelper.putDinnerSetting(type, value);
        PrintConnector.getInstance().refreshSetting();
        DriverBus.broadcast("refreshDBConfig", type, value);

    }

    @DrivenMethod(uri = "login/checkAliHotFix")
    public static void checkAliHotFix(Activity activity) {
        AliHotFix.checkAliHotFix();
    }

    /**
     * 检查版本更新
     *
     * @param activity Activity
     * @return boolean
     */
    @DrivenMethod(uri = "login/checkUpdate")
    public static boolean checkUpdate(Activity activity) {
        return UpgradeProcessor.Builder
                .newInstance()
                .setContext(activity)
                .setAPPID(BuildConfig.APPID)
                .setShopID(AppCache.getInstance().fsShopGUID)
                .setDeviceID(ClientHardwareUtil.getHardWareSymbol())
                .setShowDialog(true)
                .setAutoShowDialogAfterDownload(true)
                .setFileSubFix("apk")
                .start();
    }

    /**
     * 强制杀掉所有进程
     *
     * @param activity Activity Activity
     */
    @DrivenMethod(uri = "login/forceRelaunch")
    public static void forceRelaunch(Activity activity) {
        ForceSetAsMainHost.exitAllProcssAfterSeconds(activity);
    }

    private static BaseDialogFragment fragment;

    /**
     * 业务中心数据已发生变化
     */
    @DrivenMethod(uri = "login/dataChanged")
    public static void dataChanged() {
        Host host = BaseActivity.topActivity;
        if (host != null && (!ClientBindProcessor.isCurrentHostMain())) {
            String msg = "业务中心更新了数据，为保持数据一致，建议先退出到登录页更新数据。";
            fragment = (BaseDialogFragment) BaseActivity.topActivity.getSupportFragmentManager().findFragmentByTag(SingleDialogFragment.FRAGMENT_TAG);
            if (fragment == null) {
                fragment = DialogManager.showSingleDialog(host, msg, "提醒", "知道了", new DialogResponseListener() {
                    @Override
                    public void response() {
                        fragment = null;
                    }
                });
            }
        }
    }

    /**
     * 业务中心数据变更
     */
    @DrivenMethod(uri = "login/dataChangedAir")
    public void dataChangedAir() {
        final Host host = BaseActivity.topActivity;
        if (host != null) {
            ProgressManager.showProgress(host);
        }

        MCon.c(CPublic.class, new ConCallBack<GetDataFromCenterResponse>() {
            @Override
            public void subCall(SocketResponse<GetDataFromCenterResponse> socketResponse) {
                if (socketResponse.success()) {
                    GetDataFromCenterResponse response = socketResponse.data;
                    if (response != null && !TextUtils.isEmpty(response.datas)) {
                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_CLIENT, response.datas, response.newTimeTag);

                        JSONObject obj = JSONObject.parseObject(response.datas);
                        if (obj.containsKey("tbmarea")
                                || obj.containsKey("tbmtable")) {
                            TableBizProcessor.onCreateLoadLocalTables(TableViewProcessor.instance, new IResult() {
                                @Override
                                public void callBack(boolean result, String info) {
                                    DriverBus.call("table/onBizTableChanged");
                                    refreshTablesFromBiz();
                                }
                            });
                        }
                        if (obj.containsKey("tbmenucls")
                                || obj.containsKey("tbmenuitem")
                                || obj.containsKey("tbmenuitemuint")
                                || obj.containsKey("tbmenuitemsetside")
                                || obj.containsKey("tbmenuitemsetsidedtl")
                                || obj.containsKey("tbaskgp")
                                || obj.containsKey("tbask")
                                || obj.containsKey("tbmenuitemaskgp")) {
                            AppCache.getInstance().init();
                            AppCache.getInstance().refresh();
                            DriverBus.broadcast("menuDataChanged");
                        }
                    }
                }
            }

            @Override
            public void callback(SocketResponse<GetDataFromCenterResponse> socketResponse) {
                if (host != null) {
                    ProgressManager.closeProgress(host);
                }
            }
        }).syncData();
    }


    @DrivenMethod(uri = "login/refreshAllPrinterStatus")
    public static void refreshBackUpPrinter() {
        MCon.c(CPublic.class, new SocketThreadCallback<String>() {
            @Override
            public void callback(SocketResponse<String> socketResponse) {
                if (socketResponse.success() && !TextUtils.isEmpty(socketResponse.data)) {
                    List<PrinterDBModel> list = JSON.parseArray(socketResponse.data, PrinterDBModel.class);
                    if (!ListUtil.isEmpty(list)) {
                        for (PrinterDBModel temp : list) {
                            temp.setDbName(APPConfig.DB_CLIENT);
                            temp.replaceNoTrans();
                        }
                    }
                }
                DriverBus.call("printerlist/refreshPrinter");

            }
        }).getAllPrinter();
    }

    /**
     * 显示电视叫号扫码浮层
     */
    @DrivenMethod(uri = "login/showScanFloatView", UIThread = true)
    @MainThread
    private static void showScanFloatView() {
        boolean openedTv = TextUtils.equals(ClientMetaUtil.getSettingsValueByKey(META.PRINT_BAR_CODE), "1");
        if (openedTv) {
            FloatViewProcess.getInstance().createFloatView();
        } else {
            FloatViewProcess.getInstance().dismissFloatView();
        }
    }

    /**
     * 刷新快餐订单锁定
     *
     * @param info
     */
    @DrivenMethod(uri = "login/fastfoodOrdersRefreshLockState")
    public void fastfoodOrdersRefreshLockState(String info) {
        DriverBus.call("fastfoodOrders/refreshLockState", info);
    }

    /**
     * 刷新正餐桌台锁定
     *
     * @param info
     */
    @DrivenMethod(uri = "login/dinnerTablesRefreshLockState")
    public void dinnerTablesRefreshLockState(String info) {
        DriverBus.call("dinnerTables/refreshLockState", info);
    }

    /**
     * 更新交班列表
     */
    @DrivenMethod(uri = "login/refresh_shift")
    public static void refreshShift() {
        DriverBus.call("shift/refresh_shift");
    }

    /**
     * 外卖菜品映射关系更新
     */
    @DrivenMethod(uri = "login/updateMappingRelation")
    public static void updateMappingRelation() {
        DriverBus.call("MeituanMappingFragment/updateMappingRelation");
    }

    /**
     * 被迫退出
     */
    @DrivenMethod(uri = "login/be_forced_exist")
    public static void beForcedExist() {
        DriverBus.call("orderDishesView/exist");
    }

    /**
     * 刷新点菜收银页面数据
     */
    @DrivenMethod(uri = "login/refreshTablesFromBiz")
    public static void refreshTablesFromBiz() {
        LogUtil.logBusiness("table--finish", "客户端收到刷新桌台、快餐列表广播");
        DriverBus.call("table/refreshTablesFromBiz");
        DriverBus.call("orderDishesView/refreshTablesFromBiz");
    }

    /**
     * 未匹配到的菜
     */
    @DrivenMethod(uri = "login/unMatchMenuItems")
    public static void unMatchMenuItems(String tips) {
        DriverBus.call("main/netOrderPrintErr", tips);
    }

    @DrivenMethod(uri = "login/synComplete")
    public static void synComplete(String message) {
        DriverBus.call("bill_opt/syncStateComplete", message);
    }

    @DrivenMethod(uri = TAG + "/replication")
    public void replication(final IResult result) {
        MCon.c(CPublic.class, (SocketCallback<BaseSocketResponse>) response -> {
            if (response != null && response.success()) {
                result.callBack(true, "");
            } else {
                result.callBack(false, (response != null && !TextUtils.isEmpty(response.message)) ? response.message : "数据迁移失败");
            }
        }).checkReplication();
    }

    private static boolean isMeituanDowngradeDialogInShowing = false;

    @DrivenMethod(uri = TAG + "/meituanPhoneDowngrade")
    public static void showMeituanDowngrade(String orderId, String realPhoneNumber) {
        LogUtil.logBusiness("美团外卖隐私号降级通知：订单号：" + orderId + ", 时间：" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        if (BaseActivity.topActivity == null) {
            return;
        }

        if (!isMeituanDowngradeDialogInShowing) {
            isMeituanDowngradeDialogInShowing = true;
            DialogManager.showExecuteDialog(BaseActivity.topActivity, "美团外卖订单配送有风险，请注意订单手机号变化", "忽略", "前往消息中心",
                    new DialogResponseListener() {
                        @Override
                        public void response() {
                            ActionLog.addLog("美团外卖订单配送风险通知窗口->点击前往消息中心", ActionLog.MESSAGE_TAKEAWAY);
                            isMeituanDowngradeDialogInShowing = false;
                            DriverBus.call("main/meituanPhoneDowngrade");
                        }
                    }, new DialogResponseListener() {
                        @Override
                        public void response() {
                            ActionLog.addLog("美团外卖订单配送风险通知窗口->点击忽略", ActionLog.MESSAGE_TAKEAWAY);
                            DriverBus.call(TAG + "/refreshUndealMessage");
                            isMeituanDowngradeDialogInShowing = false;
                        }
                    });
        }
    }

    @DrivenMethod(uri = TAG + "/uploadP433Data")
    public void uploadP433Data(String paramValue) {
        PrintConnector.getInstance().uploadP433Data();
        LogUtil.log("LoginDriver-uploadP433Data");
    }

    /**
     * 显示直接跳转美团商家 APP 的悬浮球
     */
    @DrivenMethod(uri = "login/showMeituanOverlay", UIThread = true)
    @MainThread
    private static void showMeituanOverlay() {
        boolean show = TextUtils.equals(ClientMetaUtil.getSettingsValueByKey(META.SWITCH_MEITUAN_OVERLAY), "1");
        if (show) {
            MeituanOverlayView.getInstance().createFloatView();
        } else {
            MeituanOverlayView.getInstance().dismissFloatView();
        }
    }
}
