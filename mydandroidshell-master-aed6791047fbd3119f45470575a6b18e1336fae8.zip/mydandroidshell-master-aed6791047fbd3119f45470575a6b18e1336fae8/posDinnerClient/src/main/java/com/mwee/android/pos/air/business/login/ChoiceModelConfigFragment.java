//package com.mwee.android.pos.air.business.login;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.FragmentTransaction;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//
//import com.mwee.android.pos.base.AppCache;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.business.constants.AirHostConstant;
//import com.mwee.android.pos.client.db.ClientMetaUtil;
//import com.mwee.android.pos.db.base.META;
//import com.mwee.android.pos.dinner.R;
//
///**
// * Created by qinwei on 2018/1/11.
// */
//
//public class ChoiceModelConfigFragment extends BaseFragment implements View.OnClickListener {
//    private ImageView mChoiceModelDinnerFoodImg;
//    private ImageView mChoiceModelFastFoodImg;
//    private Button mChoiceModelNextBtn;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.air_choose_order_model_fragment, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        initView(view);
//        initData();
//    }
//
//    private void initView(View view) {
//        mChoiceModelDinnerFoodImg = (ImageView) view.findViewById(R.id.mChoiceModelDinnerFoodImg);
//        mChoiceModelFastFoodImg = (ImageView) view.findViewById(R.id.mChoiceModelFastFoodImg);
//        mChoiceModelNextBtn = (Button) view.findViewById(R.id.mChoiceModelNextBtn);
//        mChoiceModelDinnerFoodImg.setOnClickListener(this);
//        mChoiceModelFastFoodImg.setOnClickListener(this);
//        mChoiceModelNextBtn.setOnClickListener(this);
//        ((GuideListener)getActivity()).currentPage(AppConfigContainerActivity.PAGE_SELECTMODE);
//    }
//
//    private void initData() {
//        mChoiceModelDinnerFoodImg.setSelected(true);
//        String mode = ClientMetaUtil.getConfig(META.AIR_ORDER_MODE, AirHostConstant.DINNER_MODEL + "");
//        if (mode.equals(AirHostConstant.DINNER_MODEL + "")) {
//            mChoiceModelDinnerFoodImg.setSelected(true);
//            mChoiceModelFastFoodImg.setSelected(false);
//        } else {
//            mChoiceModelDinnerFoodImg.setSelected(false);
//            mChoiceModelFastFoodImg.setSelected(true);
//        }
//    }
//
//    @Override
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.mChoiceModelDinnerFoodImg:
//                mChoiceModelDinnerFoodImg.setSelected(true);
//                mChoiceModelFastFoodImg.setSelected(false);
//                break;
//            case R.id.mChoiceModelFastFoodImg:
//                mChoiceModelDinnerFoodImg.setSelected(false);
//                mChoiceModelFastFoodImg.setSelected(true);
//                break;
//            case R.id.mChoiceModelNextBtn:
//                if (mChoiceModelDinnerFoodImg.isSelected()) {
//                    ClientMetaUtil.updateSettingsValueByKey(META.AIR_ORDER_MODE, AirHostConstant.DINNER_MODEL);
//                    AppCache.getInstance().currentHostType = AirHostConstant.DINNER_MODEL;
//                } else {
//                    ClientMetaUtil.updateSettingsValueByKey(META.AIR_ORDER_MODE, AirHostConstant.FASTFOOD_MODEL);
//                    AppCache.getInstance().currentHostType = AirHostConstant.FASTFOOD_MODEL;
//                }
//                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.mAppConfigContainer, new PrinterConfigFragment());
//                transaction.addToBackStack("PrinterConfigFragment");
//                transaction.commit();
////                UIHelp.startAirHomeActivity((BaseActivity) getContext());
//                break;
//            default:
//                break;
//        }
//    }
//}
