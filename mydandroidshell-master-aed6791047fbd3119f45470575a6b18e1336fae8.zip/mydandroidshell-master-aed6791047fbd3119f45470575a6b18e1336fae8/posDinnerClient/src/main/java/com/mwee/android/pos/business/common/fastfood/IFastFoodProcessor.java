package com.mwee.android.pos.business.common.fastfood;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodOrdersViewProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.pay.view.component.IPayCallback;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.business.pay.model.PayViewBaseData;
import com.mwee.android.pos.connect.business.pay.model.PayViewBean;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/9/21.
 */

public interface IFastFoodProcessor {
    /**
     * 开单
     *
     * @param fsBillSourceId 来源
     * @param callback
     */
    void loadOpenOrder(String fsBillSourceId, final ResultCallback<StartFastFoodOrderResponse> callback);


    /**
     * 下单
     *
     * @param orderId    订单id
     * @param menuItems  下单菜品
     * @param mealNumber 牌号
     * @param callback
     */
    void loadOrderToCenter(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, final ResultCallback<OnlyOrderMenuItemsResponse> callback);

    /**
     * 获取所有快餐未完成订单
     */
    void loadOrderCacheById(String orderId, final ResultCallback<StartFastFoodOrderResponse> callback);

    /**
     * 获取所有快餐未完成订单
     */
    void loadAllFastFoodOrder(String fsBillSourceId, final ResultCallback<List<FastFoodSimpInfo>> callback);

    /**
     * 获取所有快餐未完成订单
     *
     * @param iResult
     */
    void refreshAllData(String fsBillSourceId, final IResult iResult);


    /**
     * 在线支付
     *
     * @param host
     * @param baseData
     * @param viewBean
     * @param callback
     */
    void doOnlinePay(final Host host, final PayViewBaseData baseData, PayViewBean viewBean, final IPayCallback callback);

    /**
     * 修改牌号
     *
     * @param orderID  订单id
     * @param count    牌号
     * @param callback
     */
    void loadUpdateMealNumber(String orderID, String count, final ResultCallback<String> callback);


    /**
     * 检查订单是否可以支付
     *
     * @return
     */
    boolean checkOrder(FastFoodDishCache dishCache);

    /**
     * 更新订单来源
     *
     * @param orderId      订单ID
     * @param billSourceId 来源id
     * @param callback
     */
    void loadUpdateBillSource(String orderId, String billSourceId, final ResultCallback<String> callback);

    /**
     * 删除微下单到菜品
     *
     * @param dishCache 点单列表
     */
    void clearNewMenuItemList(FastFoodDishCache dishCache);

    /**
     * 解绑会员
     *
     * @param orderId  订单id
     * @param cardNo   卡号
     * @param callback
     */
    void unBindMemberInfoFromOrder(String orderId, String cardNo, ResultCallback<ChangeOrderWithMemberResponse> callback);

    /**
     * 未下单的菜品入库
     *
     * @param orderId
     * @param menuItems
     * @param mealNumber
     * @param callback
     */
    void loadMenuItemsInsertToSellDB(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, final ResultCallback<OnlyOrderMenuItemsResponse> callback);
    void setViewProcessor(FastFoodOrdersViewProcessor viewProcessor);
}
