package com.mwee.android.pos.business.bill.bean;

/**
 *
 * Created by huangming on 2018/9/7.
 */

public class SearchDataItem{

    public boolean isOrderNo;
    public String dataContent;

    public SearchDataItem(){}

    public SearchDataItem(boolean isOrderNo,String dataContent){
        this.isOrderNo = isOrderNo;
        this.dataContent = dataContent;
    }
}
