package com.mwee.android.pos.business.member.entity;

import com.mwee.android.pos.base.BaseFragment;

/**
 * Created by qinwei on 2017/3/10.
 */

public class MemberManagerType {
    public int iconResId;
    public String label;
    public String value;
    public BaseFragment fragment;

    public MemberManagerType(int iconResId, String label, String value, BaseFragment fragment) {
        this.iconResId = iconResId;
        this.label = label;
        this.value = value;
        this.fragment = fragment;
    }
}
