package com.mwee.android.pos.air.business.menu.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.mwee.android.air.connect.business.menu.MenuClsAddResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.pos.air.business.menu.processor.MenuClsProcessor;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;


/**
 * 菜品分类编辑
 * 1.新增菜品分类
 * 2.修改菜品分类
 * Created by qinwei on 2017/10/11.
 */

public class MenuClsEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mMenuClsTitleLabel;
    private EditText mMenuClsNameEdt;
    private Button mMenuClsDeleteOrCancelBtn;
    private Button mMenuClsConfirmBtn;
    //private ImageView mDialogCancelImg;
    private OnMenuClsEditorListener listener;
    private MenuClsProcessor mMenuClsProcessor;
    private GridView mMenuClsPrinterGV;
    private PrinterAdapter adapter;
    private MenuClsBean menuClsBean;
    private ArrayList<PrinterItem> allPrinters;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_menu_cls_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mMenuClsPrinterGV = (GridView) view.findViewById(R.id.mMenuClsPrinterGV);
        //mDialogCancelImg = (ImageView) view.findViewById(R.id.mDialogCancelImg);
        mMenuClsTitleLabel = (TextView) view.findViewById(R.id.mMenuClsTitleLabel);
        mMenuClsNameEdt = (EditText) view.findViewById(R.id.mMenuClsNameEdt);
        mMenuClsDeleteOrCancelBtn = (Button) view.findViewById(R.id.mMenuClsDeleteOrCancelBtn);
        mMenuClsConfirmBtn = (Button) view.findViewById(R.id.mMenuClsConfirmBtn);
        mMenuClsConfirmBtn.setOnClickListener(this);
        mMenuClsDeleteOrCancelBtn.setOnClickListener(this);
        adapter = new PrinterAdapter();
        adapter.modules.addAll(allPrinters);
        mMenuClsPrinterGV.setAdapter(adapter);
    }


    private void initData() {
        mMenuClsProcessor = new MenuClsProcessor();
        if (isEditorMode()) {
            mMenuClsTitleLabel.setText("编辑分类");
            mMenuClsDeleteOrCancelBtn.setText("取消");
            mMenuClsNameEdt.setText(menuClsBean.fsMenuClsName);
          /*  mDialogCancelImg.setOnClickListener(this);
            mDialogCancelImg.setVisibility(View.VISIBLE);*/
        } else {
            mMenuClsTitleLabel.setText("新增菜品分类");
            mMenuClsDeleteOrCancelBtn.setText("取消");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMenuClsDeleteOrCancelBtn:
                dismissSelf();
                break;
           /* case R.id.mDialogCancelImg:
                DialogManager.showExecuteDialog(getActivityWithinHost(),
                        "是否确认删除？",
                        getStringWithinHost(R.string.cacel),
                        getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                            @Override
                            public void response() {
                                doDelete();
                            }
                        }, null);
                break;*/
            case R.id.mMenuClsConfirmBtn:
                String name = mMenuClsNameEdt.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    ToastUtil.showToast("请输入菜品分类名称");
                    return;
                }
                if (!RegexUtil.checkName(name)) {
                    ToastUtil.showToast("菜品分类名称输入非法");
                    return;
                }
                menuClsBean.fsMenuClsName = name;
                if (isEditorMode()) {
                    doUpdate(name);
                } else {
                    doSave(name);
                }
                break;
            default:
                break;
        }
    }

    private void doDelete() {
        final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuClsProcessor.loadMenuClsDelete(menuClsBean.fsMenuClsId, new ResultCallback<String>() {

            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast(data);
                listener.onMenuClsDeleteSuccess();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void doSave(String name) {
        final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuClsProcessor.loadMenuClsAdd(name, menuClsBean.printerNames, new ResultCallback<MenuClsAddResponse>() {

            @Override
            public void onSuccess(MenuClsAddResponse data) {
                progress.dismissSelf();
                ToastUtil.showToast("添加成功");
                dismissSelf();
                listener.onMenuClsAddSuccess(data.menuClsId, data.name);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void doUpdate(final String name) {
        final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuClsProcessor.loadMenuClsUpdate(menuClsBean, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast(data);
                dismissSelf();
                listener.onMenuClsUpdateSuccess(name);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    class PrinterAdapter extends BaseMwAdapter<PrinterItem> {

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.air_printer_choice_menu_item_cls_item, parent, false);
                holder = new Holder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }
            holder.bindData(position);
            return convertView;
        }

        class Holder implements CompoundButton.OnCheckedChangeListener {

            private CheckBox mPrinterMenuClsItemNameCB;
            private PrinterItem printerItem;

            public Holder(View v) {
                mPrinterMenuClsItemNameCB = (CheckBox) v.findViewById(R.id.mPrinterMenuClsItemNameCB);
                mPrinterMenuClsItemNameCB.setOnCheckedChangeListener(this);
            }

            public void bindData(int position) {
                printerItem = modules.get(position);
                mPrinterMenuClsItemNameCB.setText(printerItem.name);
                mPrinterMenuClsItemNameCB.setChecked(menuClsBean.printerNames.contains(printerItem.name));
            }

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    menuClsBean.printerNames.add(printerItem.name);
                } else {
                    menuClsBean.printerNames.remove(printerItem.name);
                }
            }
        }
    }

    public void setParam(MenuClsBean menuClsBean, ArrayList<PrinterItem> allPrinters) {
        this.menuClsBean = menuClsBean;
        this.allPrinters = allPrinters;
    }

    public boolean isEditorMode() {
        return menuClsBean.fsMenuClsId != null;
    }

    public void setOnMenuClsEditorListener(OnMenuClsEditorListener listener) {
        this.listener = listener;
    }

    public interface OnMenuClsEditorListener {
        void onMenuClsAddSuccess(String id, String name);

        void onMenuClsUpdateSuccess(String name);

        void onMenuClsDeleteSuccess();
    }
}
