package com.mwee.android.pos.business.common.entity;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;


public class PackageItemEditViewBean extends BusinessBean {
    public MenuItem menu = null;
    public String voidReason = "";
    public UserDBModel voidUser = null;

    public PackageItemEditViewBean() {

    }
}
