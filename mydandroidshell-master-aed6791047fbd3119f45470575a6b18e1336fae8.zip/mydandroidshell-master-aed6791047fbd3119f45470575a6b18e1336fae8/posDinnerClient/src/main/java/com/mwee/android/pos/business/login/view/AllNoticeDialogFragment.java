package com.mwee.android.pos.business.login.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.login.component.LoginProcess;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.NoticeDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.FooterStateView;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/22.
 */
public class AllNoticeDialogFragment extends BaseDialogFragment implements PullRecyclerView.OnPullRecyclerViewListener, FooterStateView.OnFooterViewListener {
    public static final String TAG = "AllNoticeDialogFragment";
    private ImageView closeImag;
    private TextView tv_notice_content;
    private PullRecyclerView lv_notice;
    private ArrayList<NoticeDBModel> noticeDBModelList = new ArrayList<>();//全部的数据
    private AllNoticeAdapter adapter;
    private int currentPosition = 0;
    private String fsUpdateTime = "";
    private TextView tvNoticeTime;
    private TextView tvNoticeTitle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.all_notices_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view) {
        closeImag = (ImageView) view.findViewById(R.id.closeImag);
        lv_notice = (PullRecyclerView) view.findViewById(R.id.lv_notice);
        tv_notice_content = (TextView) view.findViewById(R.id.tv_notice_content);
        tvNoticeTime = (TextView) view.findViewById(R.id.tvNoticeTime);
        tvNoticeTitle = (TextView) view.findViewById(R.id.tvNoticeTitle);
        closeImag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        lv_notice.setOnPullRecyclerViewListener(this);
        lv_notice.setColorSchemeResources(android.R.color.holo_blue_light, android.R.color.holo_red_light, android.R.color.holo_orange_light, android.R.color.holo_green_light);

        adapter = new AllNoticeAdapter(noticeDBModelList);
        lv_notice.setEnablePullToEnd(true);
        lv_notice.setLayoutManager(new LinearLayoutManager(getActivity()));
        //lv_notice.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));
        lv_notice.setItemAnimator(new DefaultItemAnimator());
        lv_notice.setAdapter(adapter);
        loadDataFromServer(PullRecyclerView.STATE_PULL_TO_START);

    }


    public void showContent() {
        lv_notice.setVisibility(View.VISIBLE);
        if (adapter != null && !ListUtil.isEmpty(adapter.modules)) {
            if (currentPosition < 0 || currentPosition >= adapter.modules.size()) {
                currentPosition = 0;
            }
            tv_notice_content.setText(adapter.modules.get(currentPosition).fsContent);
        } else {
            tv_notice_content.setText("没有公告记录");
        }
    }

    public void showEmpty() {
        lv_notice.setVisibility(View.GONE);
        tv_notice_content.setText("没有公告记录");
    }

    private void loadDataFromServer(final int mode) {
        ProgressManager.showProgress(AllNoticeDialogFragment.this, "请稍候...");
        LoginProcess.getAllNotice(fsUpdateTime, new ResultCallback<List<NoticeDBModel>>() {
            @Override
            public void onSuccess(List<NoticeDBModel> data) {
                ProgressManager.closeProgress(AllNoticeDialogFragment.this);
                if (PullRecyclerView.MODE_PULL_TO_START == mode) {
                    adapter.modules.clear();
                }
                if (data.size() == 17) {//有下一页数据
                    lv_notice.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_IDLE);
                } else {
                    //最后一页数据
                    lv_notice.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                }
                if (data.size() > 0) {
                    tvNoticeTitle.setText(data.get(0).fsTitle);
                    tvNoticeTime.setText(DateUtil.formartDateStrToTarget(data.get(0).fsCreatTime, "yyyy-MM-dd HH:mm:ss", "yyyy年MM月dd日"));
                    adapter.modules.addAll(data);
                    adapter.notifyDataSetChanged();
                }
                if (adapter.modules.size() > 0) {
                    showContent();
                } else {
                    showEmpty();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                lv_notice.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
            }
        });
    }


    @Override
    public void onRefresh(int mode) {
        if (mode == PullRecyclerView.MODE_PULL_TO_END) {//底部加载更多
            fsUpdateTime = adapter.modules.get(adapter.modules.size() - 1).fsUpdateTime;
        } else {
            fsUpdateTime = "";
        }
        loadDataFromServer(mode);
    }


    class AllNoticeAdapter extends BaseListAdapter<NoticeDBModel> {

        public AllNoticeAdapter(ArrayList<NoticeDBModel> modules) {
            this.modules = modules;
        }

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new NoticeViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.notices_fragment_item, parent, false));
        }

        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            FooterStateView footerView = new FooterStateView(getActivity());
            footerView.setOnFooterViewListener(AllNoticeDialogFragment.this);
            ViewGroup.LayoutParams layoutParams = null;
            if (lv_notice.getLayoutManager() instanceof StaggeredGridLayoutManager) {
                layoutParams = lv_notice.getLayoutManager().generateDefaultLayoutParams();
            } else {
                layoutParams = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT);
            }
            footerView.setLayoutParams(layoutParams);
            return footerView;
        }

        private class NoticeViewHolder extends BaseViewHolder {
            public TextView tv_notice_time;
            public TextView tv_notice_title;
            public View root;
            public NoticeDBModel noticeDBModel;

            public NoticeViewHolder(View itemView) {
                super(itemView);
                tv_notice_time = (TextView) itemView.findViewById(R.id.tv_notice_time);
                tv_notice_title = (TextView) itemView.findViewById(R.id.tv_notice_title);
                root = itemView.findViewById(R.id.lyt_root);
            }

            @Override
            public void bindData(int position) {
                noticeDBModel = modules.get(position);
                tv_notice_time.setText(DateUtil.formartDateStrToTarget(noticeDBModel.fsUpdateTime, "yyyy-MM-dd HH:mm:ss", "yyyy年MM月dd日"));
                tv_notice_title.setText(noticeDBModel.fsTitle.trim());
                ViewToolsUtil.setBackgroundResourceKeepPadding(root, position == currentPosition ? R.color.item_selected_bg : R.color.menu_bg);
                root.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        currentPosition = adapter.modules.indexOf(noticeDBModel);
                        if (currentPosition < noticeDBModelList.size() && currentPosition > -1) {
                            NoticeDBModel noticeDBModel = noticeDBModelList.get(currentPosition);
                            tv_notice_content.setText(noticeDBModel.fsContent);
                            tvNoticeTitle.setText(noticeDBModel.fsTitle);
                            tvNoticeTime.setText(DateUtil.formartDateStrToTarget(noticeDBModel.fsUpdateTime, "yyyy-MM-dd HH:mm:ss", "yyyy年MM月dd日"));
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
            }
        }
    }

    @Override
    public void onLoadMoreRetry() {

        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    public void onScrollUp() {

    }

    @Override
    public void onScrollDown() {

    }
}
