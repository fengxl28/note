package com.mwee.android.pos.air.business.menu.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.menu.processor.MenuPackageProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by qinwei on 2017/10/19.
 */

public class MenuPackageEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mAskEditorTitleLabel;
    private EditText mMenuPackageNameEdt;
    private EditText mMenuPackagePriceEdt;
    private Button mMenuPackageCancelBtn;
    private Button mMenuPackageConfirmBtn;
    private MenuPackageProcessor mMenuPackageProcessor;
    private OnMenuPackageAddListener listener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_menu_package_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mAskEditorTitleLabel =  view.findViewById(R.id.mAskEditorTitleLabel);
        mMenuPackageNameEdt =  view.findViewById(R.id.mMenuPackageNameEdt);
        mMenuPackagePriceEdt =  view.findViewById(R.id.mMenuPackagePriceEdt);
        mMenuPackageCancelBtn = view.findViewById(R.id.mMenuPackageCancelBtn);
        mMenuPackageConfirmBtn =  view.findViewById(R.id.mMenuPackageConfirmBtn);

        if (editorMenuItemBean != null) {
            mAskEditorTitleLabel.setText("编辑套餐");
            mMenuPackageNameEdt.setText(editorMenuItemBean.fsItemName);
            mMenuPackagePriceEdt.setText(editorMenuItemBean.fdSalePrice + "");
        }


        mMenuPackageCancelBtn.setOnClickListener(this);
        mMenuPackageConfirmBtn.setOnClickListener(this);
    }

    private void initData() {
        mMenuPackageProcessor = new MenuPackageProcessor();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMenuPackageCancelBtn:
                dismissSelf();
                break;
            case R.id.mMenuPackageConfirmBtn:
                String name = mMenuPackageNameEdt.getText().toString().trim();
                String price = mMenuPackagePriceEdt.getText().toString().trim();
                if (!check(name, price)) {
                    return;
                }
                if (editorMenuItemBean != null) {//编辑模式
                    doEditor(name, price);
                } else {
                    doAdd(name, price);
                }

                break;
            default:
                break;
        }
    }

    private void doAdd(String name, String price) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMenuPackageProcessor.loadAddMenuPackage(name, price, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast(data);
                listener.onMenuPackageAddSuccess();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }


    private void doEditor(String name, String price) {

        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMenuPackageProcessor.loadUpdatePackageMenu(editorMenuItemBean.fiItemCd, name, price, null, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast(data);
                listener.onMenuPackageUpdateSuccess();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                mMenuPackageConfirmBtn.setEnabled(true);
                progress.dismissSelf();
            }
        });

    }


    private MenuItemBean editorMenuItemBean;

    public void setEditorParams(MenuItemBean editorMenuItemBean) {
        this.editorMenuItemBean = editorMenuItemBean;
    }
    private boolean check(String name, String price) {
        if (!TextUtils.validate(name)) {
            ToastUtil.showToast("请输入套餐名称！");
            return false;
        } else if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("请套餐名称输入非法！");
            return false;
        } else {
            if (!TextUtils.validate(price)) {
                ToastUtil.showToast("请输入套餐价格！");
                return false;
            }
        }
        return true;
    }

    public void setOnMenuPackageAddListener(OnMenuPackageAddListener listener) {
        this.listener = listener;
    }

    public interface OnMenuPackageAddListener {

        void onMenuPackageAddSuccess();

        void onMenuPackageUpdateSuccess();

    }

}
