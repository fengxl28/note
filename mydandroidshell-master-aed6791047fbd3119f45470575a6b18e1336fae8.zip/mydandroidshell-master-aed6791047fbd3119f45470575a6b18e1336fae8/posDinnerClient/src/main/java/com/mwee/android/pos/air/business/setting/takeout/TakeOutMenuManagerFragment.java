package com.mwee.android.pos.air.business.setting.takeout;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.business.setting.api.TakeOutApi;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemContainer;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

/**
 * 第三方外卖菜品映射列表
 * Created by qinwei on 2018/3/13.
 */

public class TakeOutMenuManagerFragment extends BaseListFragment<TakeOutMenuItem> implements View.OnClickListener {
    public static final String KEY_TAKE_AWAY = "key_take_away";
    private TitleBar mTitleBar;

    private int currentPage = 1;
    private String mTakeAway = "";
    private TextView mTakeOutMenuTitleLabel;
    private PullRecyclerView mTakeOutMenuStatusTypeTabPRV;
    private TabAdapter mTabAdapter;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.air_take_out_menu_manager_fragment;
    }

    public static TakeOutMenuManagerFragment newInstance(String takeAway) {
        TakeOutMenuManagerFragment fragment = new TakeOutMenuManagerFragment();
        Bundle args = new Bundle();
        args.putString(KEY_TAKE_AWAY, takeAway);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mTakeOutMenuTitleLabel = (TextView) view.findViewById(R.id.mTakeOutMenuTitleLabel);
        view.findViewById(R.id.mTakeOutAutoMappingBtn).setOnClickListener(this);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToStart(true);
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL_LIST));
        mTitleBar = (TitleBar) view.findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
        mTitleBar.setTitle("菜品管理");
        mTitleBar.setRightContent("功能介绍");
        mTitleBar.setRightIcon(R.drawable.icon_air_help);
        mTitleBar.setRightClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                showTakeOutMenuManagerDescriptionDialog();
            }
        });

        mTakeOutMenuStatusTypeTabPRV = (PullRecyclerView) view.findViewById(R.id.mTakeOutMenuStatusTypeTabPRV);
        mTakeOutMenuStatusTypeTabPRV.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        mTakeOutMenuStatusTypeTabPRV.setEnablePullToStart(false);
        mTabAdapter = new TabAdapter();
        mTabAdapter.modules.add("全部菜品");
        mTabAdapter.modules.add("未关联菜品");
        mTakeOutMenuStatusTypeTabPRV.setAdapter(mTabAdapter);
    }

    public void refreshNum(String all, String noMapper) {
        mTabAdapter.modules.clear();
        mTabAdapter.modules.add("全部菜品(" + all + ")");
        mTabAdapter.modules.add("未关联菜品(" + noMapper + ")");
        mTabAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        if (ButtonClickTimer.canClick()) {
            DialogManager.showExecuteDialog(this, "外卖菜品与本地菜品名称相同，将自动关联", "取消", "开始关联", new DialogResponseListener() {
                @Override
                public void response() {
                    //自动匹配
                    loadTakeOutMenuAutoMatch();
                }
            });
        }
    }

    class TabAdapter extends BaseListAdapter<String> {
        public int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.view_air_take_out_relevance_status_item, parent, false));
        }

        class Holder extends BaseViewHolder implements View.OnClickListener {
            private TextView tvCategoryName;
            private int position;

            public Holder(View itemView) {
                super(itemView);
                tvCategoryName = (TextView) itemView;
                tvCategoryName.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                tvCategoryName.setText(mTabAdapter.modules.get(position));
                if (selectPosition == position) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(tvCategoryName, R.drawable.bg_take_out_relevance_status_item_checked);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(tvCategoryName, 0);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.color_2d2d2d));
                }
            }

            @Override
            public void onClick(View v) {
                if (mTabAdapter.selectPosition != position) {
                    mTabAdapter.selectPosition = position;
                    mPullRecyclerView.setRefreshing();
                    mTabAdapter.notifyDataSetChanged();
                }
            }
        }
    }

    @Override
    protected void initData() {
        super.initData();
        if (getArguments() != null) {
            mTakeAway = getArguments().getString(KEY_TAKE_AWAY);
        }
        switch (mTakeAway) {
            case Constants.TAKE_AWAY_SOURCE_MEITUAN:
                mTakeOutMenuTitleLabel.setText("美团菜品");
                break;
            case Constants.TAKE_AWAY_SOURCE_ELEME:
                mTakeOutMenuTitleLabel.setText("饿了么菜品");
                break;
        }
        mPullRecyclerView.setRefreshing();
    }

    public void loadDataFromServer(int mode) {
        String mapping_status = null;
        if (mTabAdapter.selectPosition == 1) {
            mapping_status = "0";
        }
        TakeOutApi.loadTakeOutMenuList(mTakeAway, mapping_status, currentPage, new ResultCallback<TakeOutMenuItemContainer>() {
            @Override
            public void onSuccess(TakeOutMenuItemContainer data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                if (data.items.totalPages <= currentPage) {//没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (currentPage == 1 && ListUtil.isEmpty(data.items.result)) {
                    mPullRecyclerView.showEmptyView();
                } else {
                    mPullRecyclerView.showContent();
                    modules.addAll(data.items.result);
                }
                adapter.notifyDataSetChanged();
                refreshNum(data.all_third_item_count + "", "" + data.no_mapped_item_count);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.air_take_out_menu_manager_item, parent, false));
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private View mTakeOutLocalLayout;
        private TextView mTakeOutMenuItemIdLabel;
        private TextView mTakeOutMenuItemNameLabel;
        private TextView mTakeOutMenuItemUnitLabel;
        private TextView mTakeOutMenuItemPriceLabel;
        private TextView mLocalMenuItemIdLabel;
        private TextView mLocalMenuItemNameLabel;
        private TextView mLocalMenuItemUnitLabel;
        private TextView mLocalMenuItemPriceLabel;
        private TextView mTakeOutMenuItemOperationLabel;
        private TakeOutMenuItem module;

        public Holder(View v) {
            super(v);
            mTakeOutMenuItemIdLabel = (TextView) v.findViewById(R.id.mTakeOutMenuItemIdLabel);
            mTakeOutMenuItemNameLabel = (TextView) v.findViewById(R.id.mTakeOutMenuItemNameLabel);
            mTakeOutMenuItemUnitLabel = (TextView) v.findViewById(R.id.mTakeOutMenuItemUnitLabel);
            mTakeOutMenuItemPriceLabel = (TextView) v.findViewById(R.id.mTakeOutMenuItemPriceLabel);
            mLocalMenuItemIdLabel = (TextView) v.findViewById(R.id.mLocalMenuItemIdLabel);
            mLocalMenuItemNameLabel = (TextView) v.findViewById(R.id.mLocalMenuItemNameLabel);
            mLocalMenuItemUnitLabel = (TextView) v.findViewById(R.id.mLocalMenuItemUnitLabel);
            mLocalMenuItemPriceLabel = (TextView) v.findViewById(R.id.mLocalMenuItemPriceLabel);
            mTakeOutMenuItemOperationLabel = (TextView) v.findViewById(R.id.mTakeOutMenuItemOperationLabel);
            v.findViewById(R.id.mTakeOutManagerLocalFrameLayout).setOnClickListener(this);
            mTakeOutLocalLayout = v.findViewById(R.id.mTakeOutLocalLayout);
        }

        @Override
        public void bindData(int position) {
            module = modules.get(position);
            if (TextUtils.isEmpty(module.itemId)) {
                mTakeOutMenuItemOperationLabel.setVisibility(View.VISIBLE);
                mTakeOutLocalLayout.setVisibility(View.GONE);
            } else {
                mTakeOutLocalLayout.setVisibility(View.VISIBLE);
                mTakeOutMenuItemOperationLabel.setVisibility(View.GONE);
            }
            mLocalMenuItemIdLabel.setText(showLabel(module.itemId));
            mLocalMenuItemNameLabel.setText(showLabel(module.itemName));
            mLocalMenuItemUnitLabel.setText(showLabel(module.specName));
            mLocalMenuItemPriceLabel.setText(showLabel(module.price));

            mTakeOutMenuItemIdLabel.setText(showLabel(module.takeawayItemId));
            mTakeOutMenuItemNameLabel.setText(showLabel(module.takeawayItemName));
            mTakeOutMenuItemUnitLabel.setText(showLabel(module.takeawaySpecName));
            mTakeOutMenuItemPriceLabel.setText(showLabel(module.takeawayPrice));
        }

        public String showLabel(String content) {
            return TextUtils.isEmpty(content) ? "-" : content;
        }

        @Override
        public void onClick(View v) {
            try {
                //选择本地菜品进行映射
                TakeOutMenuLocalChoiceDialogFragment fragment = new TakeOutMenuLocalChoiceDialogFragment();
                fragment.setParam((TakeOutMenuItem) module.clone(), mTakeAway, new TakeOutMenuLocalChoiceDialogFragment.OnLocalMenuItemChoiceListener() {
                    @Override
                    public void onTakeOutMenuMappedSuccess(MenuItemBean menuItemBean) {
                        module.itemId = menuItemBean.fiItemCd;
                        module.itemName = menuItemBean.fsItemName;
                        module.price = menuItemBean.fdSalePrice.toPlainString();
                        module.specName = menuItemBean.fsOrderUint;
                        adapter.notifyDataSetChanged();
                    }
                });
                DialogManager.showCustomDialog(TakeOutMenuManagerFragment.this, fragment, "");
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
    }

    private void showTakeOutMenuManagerDescriptionDialog() {
        DialogManager.showCustomDialog(this, new TakeOutMenuManagerNoteDialogFragment(), "");
    }

    private void loadTakeOutMenuAutoMatch() {
        Progress progress = ProgressManager.showProgressUncancel(this);
        TakeOutApi.loadTakeOutMenuAutoMatch(mTakeAway, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                showAutoResultMessage(data);
                progress.dismissSelf();
                mPullRecyclerView.setRefreshing();

            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void showAutoResultMessage(String data) {
        DialogManager.showSingleDialog(this, "已完成关联本次共自动关联" + data + "道菜品");
    }
}
