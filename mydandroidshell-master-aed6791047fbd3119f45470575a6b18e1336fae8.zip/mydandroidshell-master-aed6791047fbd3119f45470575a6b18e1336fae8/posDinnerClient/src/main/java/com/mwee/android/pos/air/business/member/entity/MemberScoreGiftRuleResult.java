package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberScoreGiftRuleResult extends BusinessBean {
    public CardSettingModel card_setting = new CardSettingModel();
    public MemberScoreGiftRuleResult() {
    }
}
