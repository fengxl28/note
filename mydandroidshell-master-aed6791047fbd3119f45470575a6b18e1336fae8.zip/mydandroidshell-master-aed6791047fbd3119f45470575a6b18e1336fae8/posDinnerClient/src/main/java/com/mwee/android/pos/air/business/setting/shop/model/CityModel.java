package com.mwee.android.pos.air.business.setting.shop.model;

import com.mwee.android.base.net.BusinessBean;

/**
 * @author changsunhaipeng
 * @date 2018/2/10
 */

public class CityModel extends BusinessBean {
    public int cityId;
    public String cityName;
    public String shouzimu;
}
