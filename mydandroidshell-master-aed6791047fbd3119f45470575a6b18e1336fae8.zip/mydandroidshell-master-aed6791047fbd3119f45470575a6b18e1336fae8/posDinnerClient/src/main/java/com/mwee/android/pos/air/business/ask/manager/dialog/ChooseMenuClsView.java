package com.mwee.android.pos.air.business.ask.manager.dialog;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: ChooseMenuClsView
 * @Description: 选择菜品分类
 * @author: liuxiuxiu
 * @date: 2017/11/17 下午3:29
 */
public class ChooseMenuClsView extends BaseDialogFragment implements Host, View.OnClickListener {

    public static final String TAG = ChooseMenuClsView.class.getSimpleName();

    private ListView menu_cls_lv;
    private TextView air_choose_menu_cls_confirm_tv;

    private List<String> choosedList = new ArrayList<>();
    private List<MenuTypeBean> firstNodeMap = new ArrayList<>();

    private CommonAdapter<MenuTypeBean> adapter;
    private OnChoosedMenuClsListener onChoosedMenuClsListener;

    public static ChooseMenuClsView newInstance() {
        ChooseMenuClsView fragment = new ChooseMenuClsView();
        return fragment;
    }

    public ChooseMenuClsView setParams(List<MenuTypeBean> menuTypeList, List<String> selectenuClsId, OnChoosedMenuClsListener onChoosedMenuClsListener) {
        this.choosedList.clear();
        if (!ListUtil.isEmpty(selectenuClsId)) {
            this.choosedList.addAll(selectenuClsId);
        }
        this.firstNodeMap = menuTypeList;
        this.onChoosedMenuClsListener = onChoosedMenuClsListener;
        return this;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.air_choose_menu_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (ListUtil.isEmpty(firstNodeMap)) {
            ToastUtil.showToast("没找到可用菜品分类");
            dismissSelf();
            return;
        }
        assignViews(view);
        intiAdapter();
    }

    private void assignViews(View convertView) {
        menu_cls_lv = convertView.findViewById(R.id.menu_cls_lv);
        air_choose_menu_cls_confirm_tv = convertView.findViewById(R.id.air_choose_menu_cls_confirm_tv);
        air_choose_menu_cls_confirm_tv.setOnClickListener(this);
    }

    private void intiAdapter() {
        adapter = new CommonAdapter<MenuTypeBean>(getContextWithinHost(), firstNodeMap, R.layout.air_choose_menu_cls_item) {
            @Override
            public void convert(ViewHolder viewHolder, MenuTypeBean data, int position) {
                viewHolder.setText(com.mwee.android.pos.dinner.R.id.menu_cls_name_tv, data.fsMenuClsName + "");
                viewHolder.getView(R.id.select_img).setSelected(choosedList.contains(data.fsMenuClsId));
            }
        };

        menu_cls_lv.setAdapter(adapter);
        menu_cls_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                MenuTypeBean menuTypeBean = adapter.getItem(i);
                if (menuTypeBean != null) {
                    if (!choosedList.remove(menuTypeBean.fsMenuClsId)) {
                        choosedList.add(menuTypeBean.fsMenuClsId);
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public Context getContextWithinHost() {
        return getActivity();
    }

    @Override
    public BaseActivity getActivityWithinHost() {
        return (BaseActivity) getActivity();
    }

    @Override
    public FragmentManager getFragmentManagerWithinHost() {
        return getFragmentManager();
    }

    @Override
    public void startActivityWithinHost(Intent intent) {
        startActivity(intent);
    }

    @Override
    public void startActivityForResultWithinHost(Intent intent, int requestCode) {
        startActivityForResult(intent, requestCode);
    }

    @Override
    public void startActivityForResultWithinHost(Intent intent, int requestCode, @Nullable Bundle options) {
        startActivityForResult(intent, requestCode, options);
    }

    @Override
    public Resources getResourcesWithinHost() {
        return getResources();
    }

    @Override
    public Drawable getDrawableWithinHost(@DrawableRes int id) {
        return ViewToolsUtil.getDrawable(getActivity(), id);
    }

    @Override
    public String getStringWithinHost(@StringRes int resId) {
        return getString(resId);
    }

    public interface OnChoosedMenuClsListener {
        void onConfirm(List<String> choosedMenuClsIdList);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.air_choose_menu_cls_confirm_tv:
                if (onChoosedMenuClsListener != null) {
                    onChoosedMenuClsListener.onConfirm(choosedList);
                }
                dismiss();
                break;
            default:
                break;
        }
    }
}
