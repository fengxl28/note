package com.mwee.android.pos.business.member.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.business.member.entity.RechargePayType;
import com.mwee.android.pos.dinner.R;

import java.util.ArrayList;

/**
 * 会员管理   会员充值数据适配器
 * Created by chris on 16/8/18.
 */
public class MemberRechargePayTypeAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<RechargePayType> mData;
    private int selectPosition = -1;

    public MemberRechargePayTypeAdapter(Context context, ArrayList<RechargePayType> data) {
        this.mContext = context;
        this.mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Holder holder;
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.member_recharge_paytype_item, viewGroup, false);
            holder = new Holder();
            holder.initView(view);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }
        holder.initData(i);
        return view;
    }

    public class Holder implements View.OnClickListener {

        private TextView mRechargePayTypeItemNameLabel;
        private int position;
        private ImageView mRechargePayTypeItemIconImg;
        private View v;

        public void initView(View v) {
            this.v = v.findViewById(R.id.content);
            mRechargePayTypeItemNameLabel = (TextView) v.findViewById(R.id.mRechargePayTypeItemNameLabel);
            mRechargePayTypeItemIconImg = (ImageView) v.findViewById(R.id.mRechargePayTypeItemIconImg);
            v.setOnClickListener(this);
        }

        public void initData(int position) {
            this.position = position;
            RechargePayType type = mData.get(position);
            mRechargePayTypeItemNameLabel.setText(type.name);
            mRechargePayTypeItemIconImg.setImageResource(type.icon);
            v.setBackgroundResource(type.bg);
            if (selectPosition == position) {
                v.setSelected(true);
            } else {
                v.setSelected(false);
            }
        }

        @Override
        public void onClick(View v) {
            selectPosition = this.position;
            notifyDataSetChanged();
        }
    }

    public RechargePayType getSelectRechargePayType() {
        if (selectPosition == -1) {
            return null;
        }
        return mData.get(selectPosition);
    }
}
