//package com.mwee.android.pos.air.business.login;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//
//import com.mwee.android.pos.air.business.payment.component.PaymentConstant;
//import com.mwee.android.pos.base.BaseFragment;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.UIHelp;
//import com.mwee.android.print.processor.BarcodeUtil;
//import com.mwee.android.tools.DisplayUtil;
//
///**
// * Created by qinwei on 2018/1/11.
// */
//
//public class OpenPayScannerFragment extends BaseFragment implements View.OnClickListener {
//    private Button mOpenPayScannerNextBtn;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_air_open_pay_scanner, container, false);
//    }
//
//    @Override
//    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        initView(view);
//    }
//
//    private void initView(View view) {
//        mOpenPayScannerNextBtn = (Button) view.findViewById(R.id.mOpenPayScannerNextBtn);
//        mOpenPayScannerNextBtn.setOnClickListener(this);
//        view.findViewById(R.id.mOpenPayScannerPreBtn).setOnClickListener(this);
//        ((GuideListener) getActivity()).currentPage(AppConfigContainerActivity.PAGE_OPENPAY);
//        ImageView erweima = view.findViewById(R.id.iv_erweima);
//        try {
//            erweima.setImageBitmap(BarcodeUtil.createQRImage(PaymentConstant.getUrlBindPay(), DisplayUtil.dp2px(getActivity(), 239), DisplayUtil.dp2px(getActivity(), 239)));
//        } catch (Exception e) {
//        }
//    }
//
//    @Override
//    public void onClick(View view) {
//        if (view.getId() == R.id.mOpenPayScannerPreBtn) {
//            getActivity().getSupportFragmentManager().popBackStack();
//        } else if (view.getId() == R.id.mOpenPayScannerNextBtn) {
//            UIHelp.startAirHomeActivity(getActivityWithinHost());
//            getActivity().finish();
//        }
//    }
//}
