package com.mwee.android.pos.business.fastfood;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodMenuItemProcessor;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodProcessor;
import com.mwee.android.pos.business.fastfood.widget.FastFoodOrderBar;
import com.mwee.android.pos.business.fastfood.widget.FastFoodOrderOperationLayout;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.menu.view.MenuFragment;
import com.mwee.android.pos.business.order.view.discount.DiscountJump;
import com.mwee.android.pos.business.order.view.discount.FastMultiDiscountCallBack;
import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.business.pay.connect.PayDinnerJump;
import com.mwee.android.pos.business.pay.view.component.IPayCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.business.viceshow.ViceShowConnector;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderModel;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderynamicDMode;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.MenuTerminal;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;

import java.lang.ref.WeakReference;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 快餐点菜界面
 * Created by qinwei on 2017/4/6.
 */

public class FastFoodOrderDishesFragment extends BaseFragment implements IDriver, FastFoodOrderBar.OnFastFoodOrderBarClickListener, IPayCallback, FastFoodOrderDishesAdapter.OnFastFoodOrderItemClickListener, FastFoodOrderOperationLayout.OnFastFoodOrderOperationListener {
    private final static String DRIVER_TAG = "orderDishesView";
    private ListView mFastFoodOrderLsv;//点菜列表展示
    private TextView mFastFoodOrderTotalCountLabel;//总笔数
    private TextView mFastFoodOrderTotalPriceLabel;//总价格
    private FastFoodOrderBar mFastFoodOrderBar;//快餐头部布局控件
    private FastFoodOrderOperationLayout mFastFoodOrderOperationLayout;//订单操作布局
    private FastFoodOrderDishesAdapter adapter;

    private FastFoodMenuItemProcessor mMenuItemProcessor;//菜品操作业务处理
    private FastFoodProcessor mFastFoodProcessor;

    private MenuFragment menuFragment;
    private FastFoodDishCache dishCache;
    private DelayQueue<Object> refreshDelayQueue;

    private static class DelayQueueWorker implements IDQWorker {
        private WeakReference<FastFoodOrderDishesFragment> reference;

        public DelayQueueWorker(FastFoodOrderDishesFragment fragment) {
            this.reference = new WeakReference<FastFoodOrderDishesFragment>(fragment);
        }

        @Override
        public void work(Object o) {
            FastFoodOrderDishesFragment fastFoodOrderDishesFragment = reference.get();
            if (fastFoodOrderDishesFragment != null) {
                ViceShowConnector.getInstance().sendFastMsg(fastFoodOrderDishesFragment.dishCache);
                fastFoodOrderDishesFragment.refreshDelayQueue.done("fastRefresh");
            }
        }
    }


    public void setParam(FastFoodDishCache dishCache) {
        this.dishCache = dishCache;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.view_fast_food_order_dishes, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (dishCache == null) {
            UIHelp.startMainDinnerActvity(getActivityWithinHost());
            return;
        }
        initView(view);
        initData();
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);//用于监听点菜操作
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);//用于监听点菜操作
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        refreshDelayQueue = new DelayQueue<>("fastFoodViceShow");
        refreshDelayQueue.setWorker(new DelayQueueWorker(FastFoodOrderDishesFragment.this));
        refreshDelayQueue.setDelay(500);
    }

    private void initView(View view) {
        mFastFoodOrderBar = (FastFoodOrderBar) view.findViewById(R.id.mFastFoodOrderBar);
        mFastFoodOrderTotalCountLabel = (TextView) view.findViewById(R.id.mFastFoodOrderTotalCountLabel);
        mFastFoodOrderTotalPriceLabel = (TextView) view.findViewById(R.id.mFastFoodOrderTotalPriceLabel);
        mFastFoodOrderOperationLayout = (FastFoodOrderOperationLayout) view.findViewById(R.id.mFastFoodOrderOperationLayout);
        mFastFoodOrderOperationLayout.setOnFastFoodOrderOperationListener(this);
        mFastFoodOrderLsv = (ListView) view.findViewById(R.id.mFastFoodOrderLsv);
        mFastFoodOrderLsv.setEmptyView(view.findViewById(R.id.mFastFoodListViewEmptyLayout));
        mFastFoodOrderBar.setOnFastFoodOrderBarClickListener(this);
        adapter = new FastFoodOrderDishesAdapter(getActivityWithinHost(), dishCache);
        adapter.setOnFastFoodOrderItemClickListener(this);
        mFastFoodOrderLsv.setAdapter(adapter);
    }

    private void initData() {
        mMenuItemProcessor = new FastFoodMenuItemProcessor(this);
        mFastFoodProcessor = new FastFoodProcessor();
        mFastFoodOrderBar.setHost(this);
        mFastFoodOrderBar.initData(dishCache, mFastFoodProcessor);
        mFastFoodOrderBar.notifyDataChanged();
        mFastFoodOrderOperationLayout.initData(dishCache);
        //加载菜单
        menuFragment = (MenuFragment) getChildFragmentManager().findFragmentByTag("menuFragment");
        menuFragment.setParam(dishCache.tempSelectQuantity, dishCache.fastOrderModel.sectionId);
        menuFragment.refreshView();

        //计算显示总价格总数量
        adapter.notifyDataSetChanged();
        refreshOrderInfo();
    }

    private void refreshOrderInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append(Calc.formatShow(dishCache.fastOrderModel.totalPrice, RoundConfig.ROUND_TOTAL));
        if (!TextUtils.isEmpty(dishCache.fastOrderModel.discountMsg)) {
            builder.append(" (" + dishCache.fastOrderModel.discountMsg + ")");
        }
        mFastFoodOrderTotalPriceLabel.setText(builder.toString());
        mFastFoodOrderTotalCountLabel.setText(String.format("共%s笔", adapter.modules.size()));

        //刷新客显
        refreshDelayQueue.addTask("fastRefresh");
    }

    private void refreshOrderInfo(FastOrderynamicDMode data) {
        dishCache.fastOrderModel.totalPrice = data.totalAmt;
        dishCache.fastOrderModel.discountMsg = data.CouponCutMoneyInfo;
        dishCache.fastOrderModel.fsDiscountCutId = data.fsDiscountCutId;
        dishCache.fastOrderModel.fdDiscountCutAmt = data.fdDiscountCutAmt;
        dishCache.fastOrderModel.orderCutOperUserId = data.orderCutOperUserId;
        dishCache.fastOrderModel.orderCutAuthUserId = data.orderCutAuthUserId;
        dishCache.fastOrderModel.discountAmt = data.discountAmt;
        dishCache.fastOrderModel.couponCut = data.couponCut;
        refreshOrderInfo();
    }

    /**
     * 重置数据以及ui显示
     *
     * @param data
     */
    public void reset(FastOrderModel data, ArrayList<MenuItem> menuItems) {
        //重新开单
        dishCache.clean();
        dishCache.fastOrderModel = data;
        if (!ListUtil.isEmpty(menuItems)) {
            dishCache.menuItems.addAll(menuItems);
        }
        adapter.notifyDataSetChanged();
        //连续开单是否设置牌号
        if (SettingHelper.isShouldSetMealNumber()) {
            mFastFoodOrderBar.showSetMealNumberFragment(1);
        }
        mFastFoodOrderBar.notifyDataChanged();
        mFastFoodOrderOperationLayout.refreshOperationBtnStatus();
        refreshOrderInfo();
        DriverBus.broadcast("notifyall");
    }

    @DrivenMethod(uri = DRIVER_TAG + "/clickone", UIThread = true)
    public void clickone(MenuItem item) {
        trace("点击菜品" + item.toString(), ActionLog.FF_MENU, item);
        // 菜品沽清判断
        if (item.isCategory || OrderDishesBizUtil.isOutOfStock(dishCache.tempUnitQuantity, item)) {
            return;
        }
        //设置点菜单序
        item.init(dishCache.fastOrderModel.orderSeqId, dishCache.isBindMember());
        //菜品合并处理
        MenuItem mergeMenuItem = OrderDishesBizUtil.findMergeMenuItem(dishCache.menuItems, item);
        if (mergeMenuItem != null) {
            mergeMenuItem.terminal_id = MenuTerminal.DINNER;
            //查询到有合并到菜品则进行合并操作
            dishCache.mergeOrderMenuItem(mergeMenuItem, item);
            //合并后的菜品选中
            adapter.selectPosition = adapter.modules.indexOf(mergeMenuItem);
        } else {
            //第0个位置选中
            adapter.selectPosition = 0;
            item.terminal_id = MenuTerminal.DINNER;
            //绑定会员并设置为自动使用会员价，则给新增加菜品使用会员价
            if (dishCache.isBindMember() && SettingHelper.isAutoUsedMemberPrice()) {
                item.useVipPrice(AppCache.getInstance().userDBModel.fsUserId, "");
            }
            //添加到点菜列表
            dishCache.addFastFoodMenuItem(item);
        }
        //滚动到新增菜品的位置
        mFastFoodOrderLsv.smoothScrollToPosition(adapter.selectPosition, adapter.selectPosition);
        adapter.notifyDataSetChanged();
        //通知菜品列表更新UI
        DriverBus.call("menuview/notifyone", item);
        //刷新top bar按钮状态
        mFastFoodOrderBar.refreshOperationBtnStatus();
        //刷新foot布局中按钮状态
        mFastFoodOrderOperationLayout.refreshOperationBtnStatus();

        if (mergeMenuItem != null) {
            loadUpdateMenuItem(mergeMenuItem);
        } else {
            //同步数据到业务中心
            loadAddMenuItem(item);
        }
    }

    public void loadAddMenuItem(final MenuItem item) {
        mMenuItemProcessor.doAddMenuItem(dishCache.getOrderId(), item, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                if (!ListUtil.isEmpty(data.changedItemList)) {
                    for (MenuItem localItem : dishCache.menuItems) {
                        for (MenuItem changedItem : data.changedItemList) {
                            if (TextUtils.equals(localItem.menuBiz.uniq, changedItem.menuBiz.uniq)) {
                                localItem.currentUnit.fdVIPPrice = changedItem.currentUnit.fdVIPPrice;
                                localItem.useVipPrice(AppCache.getInstance().userDBModel.fsUserId, "");
                            }
                        }
                    }
                    adapter.notifyDataSetChanged();

                }
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "取消", "重试", new DialogResponseListener() {
                    @Override
                    public void response() {
                        loadAddMenuItem(item);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        dismissSelf();
                    }
                });
            }
        });
    }

    @Override
    public void onOrderClearClick() {
        trace("点击清台", ActionLog.USER_ACTION_TRACE);
        mMenuItemProcessor.doClearOrderMenuItems(dishCache.fastOrderModel.orderId, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                mFastFoodProcessor.clearNewMenuItemList(dishCache);
                mFastFoodOrderOperationLayout.refreshOperationBtnStatus();
                mFastFoodOrderBar.refreshOperationBtnStatus();
                //重新计算点菜数量相关缓存
                dishCache.initSelectUnitQuantity();
                adapter.notifyDataSetChanged();
                //通知菜品列表刷新UI
                DriverBus.broadcast("notifyall");
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                showSingleDialogTip(msg);
            }
        });
    }

    /**
     * 结账
     */
    @Override
    public void onOrderCheckClick() {
        trace("点击结帐", ActionLog.USER_ACTION_TRACE);
        if (!mFastFoodProcessor.checkOrder(dishCache)) {
            return;
        }
        if (isShowSetMealNumberFragment()) {
            showSetMealNumberFragment(new CountKeyboardCallback() {
                @Override
                public void callback(BigDecimal originNum, BigDecimal newNum) {
                    dishCache.fastOrderModel.mealNumber = newNum + "";
                    mFastFoodOrderBar.notifyDataChanged();//更新牌号显示
                    loadMenuItemsInsertToSellDB(false);
                }
            });
        } else {
            loadMenuItemsInsertToSellDB(false);
        }
    }

    @Override
    public void onOrderCommitClick() {
        trace("点击仅下单", ActionLog.FF_ORDER_COMMIT);
        //根据配置显示是否需要输入牌号
        if (isShowSetMealNumberFragment()) {
            showSetMealNumberFragment(new CountKeyboardCallback() {
                @Override
                public void callback(BigDecimal originNum, BigDecimal newNum) {
                    dishCache.fastOrderModel.mealNumber = newNum + "";
                    mFastFoodOrderBar.notifyDataChanged();//更新牌号显示
                    doMenuOrder();
                }
            });
        } else {
            doMenuOrder();
        }
    }

    /**
     * 判断是否弹出输入牌号
     *
     * @return
     */
    private boolean isShowSetMealNumberFragment() {
        return SettingHelper.isShouldSetMealNumber() && TextUtils.isEmpty(dishCache.fastOrderModel.mealNumber);
    }

    /**
     * 下单操作
     */
    private void doMenuOrder() {
        trace("下单操作", ActionLog.FF_ORDER_COMMIT, dishCache.fastOrderModel);
        final Progress progress = ProgressManager.showProgressUncancel(this, "下单中...");
        mFastFoodProcessor.loadOrderToCenter(dishCache.fastOrderModel.orderId, dishCache.getFastFoodNotOrderMenuItems(), dishCache.fastOrderModel.mealNumber, new ResultCallback<OnlyOrderMenuItemsResponse>() {
            @Override
            public void onSuccess(OnlyOrderMenuItemsResponse data) {
                progress.dismiss();
                if (data.fastOrderModel != null) {
                    trace("下单成功,重新开单", ActionLog.FF_ORDER_COMMIT, data);
                    reset(data.fastOrderModel, (ArrayList<MenuItem>) data.menuItemList);
                } else {
                    trace("下单成功,关闭当前点单界面", ActionLog.FF_ORDER_COMMIT, data);
                    dismissSelf();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                trace("下单失败:" + msg, ActionLog.FF_ORDER_COMMIT);
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    @Override
    public void onMobilePaymentClick() {
        trace("点击手机支付", ActionLog.FF_ORDER_MOBILE_PAY);
        //手机支付前数据校验
        if (ListUtil.isEmpty(dishCache.menuItems)) {
            ToastUtil.showToast("空单不能结帐");
            return;
        }
        if (!mFastFoodProcessor.checkOrder(dishCache)) {
            return;
        }
        if (isShowSetMealNumberFragment()) {
            showSetMealNumberFragment(new CountKeyboardCallback() {
                @Override
                public void callback(BigDecimal originNum, BigDecimal newNum) {
                    dishCache.fastOrderModel.mealNumber = newNum.intValue() + "";
                    mFastFoodOrderBar.notifyDataChanged();//更新牌号显示
                    loadMenuItemsInsertToSellDB(true);
                }
            });
        } else {
            loadMenuItemsInsertToSellDB(true);
        }
    }


    /**
     * 结帐前将未下单的菜品入库
     *
     * @param isOnlinePay
     */
    public void loadMenuItemsInsertToSellDB(final boolean isOnlinePay) {
        ArrayList<MenuItem> menuItems = dishCache.getFastFoodNotOrderMenuItems();
        if (ListUtil.isEmpty(menuItems)) {
            goPayDinnerFragment(isOnlinePay);
        } else {
            final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
            mFastFoodProcessor.loadMenuItemsInsertToSellDB(dishCache.fastOrderModel.orderId, menuItems, dishCache.fastOrderModel.mealNumber, new ResultCallback<OnlyOrderMenuItemsResponse>() {
                @Override
                public void onSuccess(OnlyOrderMenuItemsResponse data) {
                    progress.dismiss();
                    goPayDinnerFragment(isOnlinePay);
                }

                @Override
                public void onFailure(int code, String msg) {
                    progress.dismiss();
                    ToastUtil.showToast(msg);
                }
            });
        }

    }

    /**
     * 跳转收银界面
     *
     * @param isOnlinePay true代表手机支付，false 跳转到收银界面
     */
    public void goPayDinnerFragment(boolean isOnlinePay) {
        if (isOnlinePay) {
            trace("显示手机支付", ActionLog.FF_ORDER_MOBILE_PAY);
            if (dishCache.fastOrderModel.totalPrice.compareTo(BigDecimal.ZERO) == 0) {
                ToastUtil.showToast("待支付金额为0");
                return;
            }
            if (dishCache.antiPay) {
                PayDinnerJump.jumpToOnlineRePayForFastFood(FastFoodOrderDishesFragment.this, dishCache.fastOrderModel.orderId, R.id.main_menufragment, FastFoodOrderDishesFragment.this);
            } else {
                PayDinnerJump.jumpToOnlinePayForFastFood(FastFoodOrderDishesFragment.this, dishCache.fastOrderModel.orderId, R.id.main_menufragment, FastFoodOrderDishesFragment.this);
            }
        } else {
            trace("跳转结帐界面", ActionLog.FF_ORDER_PAY);
            if (dishCache.antiPay) {
                PayDinnerJump.jumpToRePay(getActivityWithinHost(), dishCache.fastOrderModel.orderId, R.id.main_menufragment, FastFoodOrderDishesFragment.this);
            } else {
                PayDinnerJump.jumpToPayForFastFood(getActivityWithinHost(), dishCache.fastOrderModel.orderId, R.id.main_menufragment, false, FastFoodOrderDishesFragment.this);
            }
        }
    }


    private void showSetMealNumberFragment(final CountKeyboardCallback callback) {
        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle(getString(R.string.set_meal_number_title));
        fragment.setOriginCount(1);
        fragment.setCanBe0(true);
        fragment.setErrorTips(getString(R.string.error_tips_input_number));
        fragment.setCallback(new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                trace("输入牌号为:" + newNum, ActionLog.USER_ACTION_TRACE);
                callback.callback(originNum, newNum);
            }
        });
        fragment.setMaxCount(999);
        trace("显示输入牌号", ActionLog.USER_ACTION_TRACE);
        DialogManager.showCustomDialog(getActivityWithinHost(), fragment, CountKeyboardFragment.FRAGMENT_TAG);
    }


    @Override
    public void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel) {
        trace("显示菜品改数弹框", ActionLog.FF_MENU_NUMBER);
        ModifyQuantityUtils.showModifyQuantitySupportWeight(this, item, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                trace("改数结果，修改前:" + originNum.toString() + ",修改后:" + newNum.toString(), ActionLog.FF_MENU_NUMBER);
                if (newNum.compareTo(BigDecimal.ZERO) < 1 || originNum.compareTo(newNum) == 0) {
                    return;
                }
                //沽清判断
                if (OrderDishesBizUtil.isOutOfStock(dishCache.tempUnitQuantity, item, newNum)) {
                    return;
                }
                item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundConfig.Decimal_ROUND_Type));
                //重新计算价格
                item.calcTotal(dishCache.isBindMember());
                //更新DishCache缓存信息
                dishCache.initSelectUnitQuantity();
                adapter.notifyDataSetChanged();
                DriverBus.broadcast("notifyall");
                loadUpdateMenuItem(item);
            }
        });
    }

    private void loadUpdateMenuItem(MenuItem menuItem) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(menuItem);
        loadUpdateMenuItem(menuItems);
    }

    private void loadUpdateMenuItem(final ArrayList<MenuItem> menuItems) {
        mMenuItemProcessor.doUpdateMenuItem(dishCache.getOrderId(), menuItems, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "取消", "重试", new DialogResponseListener() {
                    @Override
                    public void response() {
                        loadUpdateMenuItem(menuItems);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        dismissSelf();
                    }
                });
            }
        });
    }

    @Override
    public void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel) {
        trace("已下单称重,显示称重界面", ActionLog.FF_ORDER_PAY);
        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, dishCache.fastOrderModel.orderId, new ResultCallback<UpdateBuyNumResponse>() {
            @Override
            public void onSuccess(UpdateBuyNumResponse data) {
                trace("称重修改成功:" + item.menuBiz.buyNum.toString(), ActionLog.FF_MENU_NUMBER);
                dishCache.replaceMenuItem(item, data.menuItem);
                adapter.notifyDataSetChanged();
                DriverBus.call("menuview/refreshMenu");
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                trace("称重修改失败:" + msg, ActionLog.FF_MENU_NUMBER);
                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    DriverBus.call("menuview/refreshMenu");
                } else {
                    dismissSelf();
                }
            }
        });
    }

    @Override
    public void doDeleteMenu(MenuItem item) {
        loadDeleteMenu(item);

    }

    public void loadDeleteMenu(final MenuItem item) {
        mMenuItemProcessor.doDeleteMenuItem(dishCache.getOrderId(), item.menuBiz.uniq, new ResultCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void onSuccess(ChangeFastFoodMenuItemsResponse data) {
                adapter.selectPosition = -1;
                dishCache.removeFastFoodMenuItem(item);
                adapter.notifyDataSetChanged();
                mFastFoodOrderBar.refreshOperationBtnStatus();
                mFastFoodOrderOperationLayout.refreshOperationBtnStatus();
                DriverBus.broadcast("notifyall");
                if (!ListUtil.isEmpty(data.changedItemList)){
                    dishCache.replaceAllMenuItems(data.changedItemList);
                    adapter.notifyDataSetChanged();
                }
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                DialogManager.showExecuteDialog(getActivityWithinHost(), msg, "取消", "重试", new DialogResponseListener() {
                    @Override
                    public void response() {
                        loadDeleteMenu(item);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                    }
                });
            }
        });
    }


    @Override
    public void doEditorMenuNoteContent(final MenuItem item) {
        mMenuItemProcessor.doEditorMenuNoteContent(item, new NoteCallback() {
            @Override
            public void callBack(List<NoteItemModel> selectedInfo) {
                trace("选择要求回调：", ActionLog.FF_MENU_REQUEST, selectedInfo);
                item.menuBiz.selectNote = selectedInfo;
                item.buildNotesString();
                item.calcTotal(dishCache.isBindMember());
                adapter.notifyDataSetChanged();
                DriverBus.broadcast("notifyone", item);
                loadUpdateMenuItem(item);
            }
        });
    }

    @Override
    public void doChangeMenuPrivilege(final MenuItem item) {
        mMenuItemProcessor.doChangeMenuPrivilege(item, dishCache, new SingleCouponFragment.OnSingleDiscountListener() {
            @Override
            public void callback(OrderCache orderCache, FastOrderynamicDMode fastOrder, List<MenuItem> menuItemList) {
                trace("菜品优惠成功：", ActionLog.FF_MENU_DISCOUNT, item);
                dishCache.replaceAllMenuItems(menuItemList);
                adapter.notifyDataSetChanged();
                refreshOrderInfo(fastOrder);
            }
        });
    }

    @Override
    public void doChangeMenuPrice(final MenuItem item, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateDishPrice(dishCache.getOrderId(), item, false, new ResultCallback<OperateDishToCenterResponse>() {
            @Override
            public void onSuccess(OperateDishToCenterResponse data) {
                trace("菜品改价成功：" + item.toString(), ActionLog.FF_MENU_PRICE, item);
                item.calcTotal(dishCache.isBindMember());
                adapter.notifyDataSetChanged();
                DriverBus.broadcast("notifyall");
                loadUpdateMenuItem(item);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                trace("菜品改价失败," + item.toString() + ":" + msg, ActionLog.FF_MENU_PRICE);
            }
        });
    }

    @Override
    public void doChangeOrderedMenuPrice(final MenuItem menuItem, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateDishPrice(dishCache.getOrderId(), menuItem, true, new ResultCallback<OperateDishToCenterResponse>() {
            @Override
            public void onSuccess(OperateDishToCenterResponse data) {
                trace("菜品改价成功：" + menuItem.toString(), ActionLog.FF_MENU_PRICE, menuItem);
                //替换server处理后的菜品信息
                dishCache.replaceMenuItem(menuItem, data.menuItem);
                adapter.notifyDataSetChanged();
                DriverBus.broadcast("notifyall");
                refreshOrderInfo(data.fastOrderynamicDMode);//刷新订单相关信息
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                trace("菜品改价失败," + menuItem.toString() + ":" + msg, ActionLog.FF_MENU_PRICE);
                dismissSelf();
            }
        });
    }

    @Override
    public void doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item) {
        trace("点击菜品编辑，[" + item.name + "]" + item.menuBiz.uniq, ActionLog.FF_MENU_EDITOR);
        if (mMenuItemProcessor.doEditMenuInfo(oldUnit, item, dishCache)) {
            adapter.notifyDataSetChanged();
            DriverBus.broadcast("notifyall");
            loadUpdateMenuItem(item);
        }
    }

    @Override
    public void doRetreatDish(final MenuItem item, final UserDBModel userDBModel, String msg) {
        mMenuItemProcessor.doRetreatDish(dishCache.getOrderId(), item, msg, new ResultCallback<BactchReturnDishesForFastFoodResponse>() {
            @Override
            public void onSuccess(BactchReturnDishesForFastFoodResponse data) {
                trace("退菜成功:" + item.toString(), ActionLog.FF_MENU_RETREAT);
                //可以优化
                dishCache.replaceAllMenuItems(data.menuItemList);
                adapter.notifyDataSetChanged();
                dishCache.initSelectUnitQuantity();
                DriverBus.call("menuview/notifyone", item);
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                trace("退菜失败:" + item.toString(), ActionLog.FF_MENU_RETREAT);
                showSingleDialogTip(msg);
            }
        });
    }

    @Override
    public void doChangeIngredient(final MenuItem menuItem, final MenuItem newMenuItem) {
        mMenuItemProcessor.doChangeIngredient(dishCache.getOrderId(), menuItem, newMenuItem, new ResultCallback<ChangeIngredientResponse>() {
            @Override
            public void onSuccess(ChangeIngredientResponse data) {
                trace("编辑配料菜成功:" + data.toString(), ActionLog.FF_MENU_EDITOR, data);
                //替换server处理后的菜品信息
                dishCache.replaceMenuItem(menuItem, data.newItem);
                adapter.notifyDataSetChanged();
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                trace("编辑配料菜失败:" + msg, ActionLog.FF_MENU_EDITOR, newMenuItem);
                ToastUtil.showToast(msg);
                dismissSelf();
            }
        });
    }

    /**
     * 修改套餐子项
     *
     * @param menuItem    修改前套餐
     * @param newMenuItem 修改后套餐
     */
    @Override
    public void doChangePackageItems(final MenuItem menuItem, final MenuItem newMenuItem, PackageItemEditViewBean otherData) {
        mMenuItemProcessor.doChangePackageItems(dishCache.getOrderId(), menuItem, newMenuItem, otherData, new ResultCallback<ChangePackageItemsResponse>() {
            @Override
            public void onSuccess(ChangePackageItemsResponse data) {
                dishCache.replaceMenuItem(menuItem, data.newItem);
                adapter.notifyDataSetChanged();
                refreshOrderInfo(data.fastOrderynamicDMode);
            }

            @Override
            public void onFailure(int code, String msg) {
                dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onPackageMenuChanged(MenuItem menuItem) {
        loadUpdateMenuItem(menuItem);
    }


    @Override
    public void onFastFoodBarBackClick() {
        // 检查是否包含菜品券 并且订单未缓存
        List<MenuItem> items = dishCache.menuItems;
        boolean existDishCoupon = false;
        for (MenuItem item : items) {
            // 已下单下单的菜品不检查
            if (dishCache.fastOrderModel.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                continue;
            }
            if (item.usedMbCouponSucc() && item.memberDishCoupon != null) {
                existDishCoupon = true;
                break;
            }
        }
        if (existDishCoupon) {
            showSingleDialogTip(getResources().getString(R.string.message_membercoupon_del_tip));
            return;
        }
        dismissSelf();
    }

    @Override
    public void onFastFoodBarOrderRequestClick() {
        List<MenuItem> reqMenuItems = dishCache.getFastFoodNotOrderMenuItems();
        mMenuItemProcessor.doBatchRequest(ListUtil.cloneList(reqMenuItems), dishCache, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                trace("菜品批量要求成功", ActionLog.FF_BATCH_REQUEST);
                adapter.selectPosition = -1;
                adapter.notifyDataSetChanged();
                loadUpdateMenuItem(dishCache.menuItems);
            }
        });
    }

    @Override
    public void onFastFoodBarOrderPrivilegeClick() {
        DiscountJump.jumpToFastDiscount(this, dishCache, new FastMultiDiscountCallBack() {
            @Override
            public void call(FastOrderynamicDMode fastOrder, List<MenuItem> menuItemList) {
                trace("菜品批量优惠成功", ActionLog.FF_BATCH_DISCOUNT);
                dishCache.replaceAllMenuItems(menuItemList);
                adapter.notifyDataSetChanged();
                refreshOrderInfo(fastOrder);
            }
        });
    }

    @Override
    public void onFastFoodBarOrderBindMember(QueryMemberInfoAndBindToOrderResponse member) {
        dishCache.replaceAllMenuItems(member.menuItemList);
        adapter.notifyDataSetChanged();
        refreshOrderInfo(member.fastOrderynamicDMode);
    }

    @Override
    public void onFastFoodBarOrderBindMember(NewQueryMemberInfoAndBindToOrderResponse member) {
        dishCache.replaceAllMenuItems(member.menuItemList);
        adapter.notifyDataSetChanged();
        refreshOrderInfo(member.fastOrderynamicDMode);
    }

    @Override
    public void onFastFoodBarOrderUnBindMember(ChangeOrderWithMemberResponse data) {
        dishCache.replaceAllMenuItems(data.menuItemList);
        adapter.notifyDataSetChanged();
        refreshOrderInfo(data.fastOrderynamicDMode);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        refreshDelayQueue.callDestroy();
        NotifyToServer.unlockOrderByHost(AppCache.getInstance().currentHostId);
        ViceShowConnector.getInstance().clearOrderInfo();
    }

    @Override
    public void payFinish(int result) {
        if (result == IPayCallback.FINISH) {
            if (SettingHelper.isShouldContinueOpen()) {
                trace("结帐后执行连续开单", ActionLog.FF_ORDER_NEW);
                openOrder(dishCache.fastOrderModel.billSourceId);
            } else {
                if (dishCache.antiPay) {
                    trace("结帐后跳转快餐单列表", ActionLog.FF_ORDER_BACK);
                    DriverBus.call("main/jump", MAIN_TAB.TABLE);
                }
                dismissSelf();
            }
        }
    }

    public void openOrder(String originBillSourceID) {
        if (OrderDishesBizUtil.isBillSourceDefault(originBillSourceID) || TextUtils.equals("-1", originBillSourceID)) {
            originBillSourceID = "1";
        }
        String fsBillSourceId = originBillSourceID;
        LogUtil.logBusiness("----快餐页---开单中----");
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.order_fast_food_open_ing);
        mFastFoodProcessor.loadOpenOrder(fsBillSourceId, new ResultCallback<StartFastFoodOrderResponse>() {
            @Override
            public void onSuccess(StartFastFoodOrderResponse data) {
                trace("结帐后连续开单成功", ActionLog.FF_ORDER_NEW, data);
                // ProgressManager#showProgressUncancel 可能返回 null
                if (progress != null && progress.isVisible()) {
                    progress.dismiss();
                }
                reset(data.fastOrderModel, data.menuItems);
            }

            @Override
            public void onFailure(int code, String msg) {
                trace("结帐后连续失败,弹出重试弹窗", ActionLog.FF_ORDER_NEW);
                progress.dismiss();
                DialogManager.showExecuteDialog(getActivityWithinHost(), "开单失败，是否重试？", "退出", "确定", new DialogResponseListener() {
                    @Override
                    public void response() {
                        openOrder(fsBillSourceId);
                    }
                }, new DialogResponseListener() {
                    @Override
                    public void response() {
                        if (dishCache.antiPay) {
                            DriverBus.call("main/jump", MAIN_TAB.TABLE);
                        }
                        dismissSelf();
                    }
                });
            }
        });
    }

    @Override
    public boolean onKeyBack() {
        trace("点击返回键", ActionLog.FF_ORDER_BACK);
        return super.onKeyBack();
    }

    private void trace(String msg, String action) {
        trace(msg, action, "");
    }

    private void trace(String msg, String action, Object arg0) {
        ActionLog.addLog("快餐点单界面->" + msg, dishCache.getOrderId(), dishCache.fastOrderModel.mealNumber, action, arg0);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    public void showSingleDialogTip(String tipMsg) {
        DialogManager.showSingleDialog(getActivityWithinHost(), tipMsg);
    }
}
