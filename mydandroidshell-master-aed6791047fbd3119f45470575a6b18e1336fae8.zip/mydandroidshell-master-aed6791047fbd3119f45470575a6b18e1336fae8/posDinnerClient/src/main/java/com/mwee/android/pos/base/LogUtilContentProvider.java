package com.mwee.android.pos.base;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.mwee.android.log.db.LogDBUtil;

/**
 * Description:
 *
 * @author zhou.junyou
 * Create by:Android Studio
 * Date:2019/1/16
 */
public class LogUtilContentProvider extends ContentProvider {
    public static final String TAG = LogUtilContentProvider.class.getSimpleName();
    protected LogDBUtil instance;
    public static  String AUTOHORITY ;
    public static final String LOG_TABLE = "log";
    public static final String SHOP_TABLE = "shop";

    private  UriMatcher mMatcher;
    public static final int LOG_CODE = 1;
    public static final int SQL_CODE = 2;
    public static final int SHOP_CODE = 3;
    private SQLiteDatabase db;


    @Override
    public boolean onCreate() {
        AUTOHORITY = getContext().getPackageName()+".LogUtilContentProvider";
        mMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        // 初始化
        mMatcher.addURI(AUTOHORITY, LOG_TABLE+"/1", LOG_CODE);
        mMatcher.addURI(AUTOHORITY, LOG_TABLE+"/2", SQL_CODE);
        mMatcher.addURI(AUTOHORITY, SHOP_TABLE+"/3", SHOP_CODE);
        instance = LogDBUtil.getInstance(getContext());
        db = instance.getDb();
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable Bundle queryArgs, @Nullable CancellationSignal cancellationSignal) {
        String sql = queryArgs.getString("sql", "");
        if (!TextUtils.isEmpty(sql)) {
            return db.rawQuery(sql, null);
        }
        return super.query(uri, projection, queryArgs, cancellationSignal);
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        Log.i(TAG, "query uri " + uri + " selection " + selection);
        if (mMatcher.match(uri) == SQL_CODE && selection != null) {
            String sql = selection;
            return db.rawQuery(sql, null);

        }
        return db.query(LOG_TABLE, projection, selection, selectionArgs, null, null, sortOrder);
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        Log.i(TAG, "insert uri " + uri + " thread: " + Thread.currentThread().getName());
        int match = mMatcher.match(uri);
        synchronized (this) {
            if (match == SHOP_CODE) {
                db.insert(SHOP_TABLE, null, values);
            } else {
                db.insert(LOG_TABLE, null, values);
            }
        }
        return uri;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        Log.i(TAG, "delete uri " + uri + " selection " + selection + " selectionArgs " + selectionArgs);
        int match = mMatcher.match(uri);

        int delete=0;
        synchronized (this) {
            if (match == SQL_CODE && selection != null) {
                db.execSQL(selection);
                return delete;
            }
            delete = db.delete(LOG_TABLE, selection, selectionArgs);
        }
        return delete;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        Log.i(TAG, "update uri" + uri + " selection " + selection + " selectionArgs " + selectionArgs);
        int update=0;
        synchronized (this) {
             update = db.update(LOG_TABLE, values, selection, selectionArgs);
        }
        return update;
    }
}
