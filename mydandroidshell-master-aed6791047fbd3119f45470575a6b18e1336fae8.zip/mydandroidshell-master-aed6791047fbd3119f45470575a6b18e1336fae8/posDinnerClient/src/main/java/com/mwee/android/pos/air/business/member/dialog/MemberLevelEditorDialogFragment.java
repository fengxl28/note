package com.mwee.android.pos.air.business.member.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.entity.MemberLevelModel;
import com.mwee.android.pos.air.business.member.processor.MemberLevelEditorProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by zhangmin on 2018/1/02.
 */

public class MemberLevelEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView tvLevelName;
    private TextView tvPreLeverName;


    private EditText mMemberExpenseAmountEdt;
    private EditText mMemberLevelGiftScoreEdt;

    private Button mMemberCancelBtn;
    private Button mMemberConfirmBtn;
    private MemberLevelModel model;
    private OnMemberLevelEditorListener listener;
    private MemberLevelEditorProcessor mMemberLevelEditorProcessor;

    private String preTitle;//前一个等级的名称

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_level_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }


    private void initView(View view) {

        tvLevelName = view.findViewById(R.id.tvLevelName);
        tvPreLeverName = view.findViewById(R.id.tvPreLeverName);
        mMemberExpenseAmountEdt = view.findViewById(R.id.mMemberExpenseAmountEdt);
        mMemberLevelGiftScoreEdt = view.findViewById(R.id.mMemberLevelGiftScoreEdt);

        mMemberCancelBtn = view.findViewById(R.id.mMemberCancelBtn);
        mMemberConfirmBtn = view.findViewById(R.id.mMemberConfirmBtn);
        mMemberCancelBtn.setOnClickListener(this);
        mMemberConfirmBtn.setOnClickListener(this);
    }

    private void initData() {

        mMemberLevelEditorProcessor = new MemberLevelEditorProcessor();
        tvLevelName.setText(model.title);
        tvPreLeverName.setText(String.format("1.需先成为%s", preTitle));
        mMemberExpenseAmountEdt.setText(model.expense_amount);
        mMemberLevelGiftScoreEdt.setText(model.reward_point);
    }

    public void setParam(MemberLevelModel model, String preTitle) {
        this.model = model;
        this.preTitle = preTitle;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMemberConfirmBtn:
                String expense_amount = mMemberExpenseAmountEdt.getText().toString().trim();
                String reward_point = mMemberLevelGiftScoreEdt.getText().toString().trim();

                if (!check(expense_amount)) {
                    return;
                }
                doUpdate(expense_amount, reward_point);

                break;
            case R.id.mMemberCancelBtn:
                dismissSelf();
                break;
            default:
                break;
        }
    }


    private void doUpdate(String expense_amount, String reward_point) {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        mMemberLevelEditorProcessor.loadMemberLevelUpdate(model.id, model.title, expense_amount, reward_point, new ResultCallback<String>() {

            @Override
            public void onSuccess(String data) {
                listener.onMemberLevelEditorSuccess();
                progress.dismissSelf();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }

    private boolean check(String expense_amount) {
        if (!TextUtils.validate(expense_amount)) {
            ToastUtil.showToast("消费金额不可为空!");
            return false;
        }
        if (Integer.valueOf(expense_amount) == 0) {
            ToastUtil.showToast("消费金额必须大于0!");
            return false;
        }
        return true;
    }

    public void setOnMemberLevelEditorListener(OnMemberLevelEditorListener listener) {
        this.listener = listener;
    }

    public interface OnMemberLevelEditorListener {
        void onMemberLevelEditorSuccess();
    }
}
