package com.mwee.android.pos.air.business.member.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.air.base.ContainerFragmentActivity;
import com.mwee.android.pos.air.business.member.entity.AirMemberCardModel;
import com.mwee.android.pos.air.business.member.entity.MemberCardContainer;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberCardResponse;
import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.air.business.member.utils.MemberUtils;
import com.mwee.android.pos.air.business.widget.EditorView;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.MemberInfoContainerFragment;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * Created by zhangmin on 2017/02/01.
 */

public class MemberListFragment extends BaseListFragment<AirMemberCardModel> {

    private EditorView etMemberSearch;

    private TextView tvMemberCount;
    private TextView tvMemberAddCount;
    private TextView tvSearchConfirm;


    private MemberProcess mMemberProcess;

    private MemberEditorProcessor memberEditorProcessor;


    /**
     * 是否是第一次查询数据
     */
    private boolean isSearchFirst = true;

    /**
     * 卡号搜索
     */
    private String cardNo = "";
    /**
     * 手机号搜索
     */
    private String mobile = "";

    /**
     * 当前的搜索页
     */
    private int pageNo = 1;
    private FrameLayout mEmptyLayout;


    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_air_member_list;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.fragment_air_member_list_item, parent, false));
    }

    @Override
    protected void initView(View view) {
        super.initView(view);

        etMemberSearch = view.findViewById(R.id.etMemberSearch);
        tvSearchConfirm = view.findViewById(R.id.tvSearchConfirm);
        tvMemberCount = view.findViewById(R.id.tvMemberCount);
        tvMemberAddCount = view.findViewById(R.id.tvMemberAddCount);

        mEmptyLayout = view.findViewById(R.id.mEmptyLayout);
        TextView tvLableSub = view.findViewById(R.id.tvLableSub);
        tvLableSub.setVisibility(View.VISIBLE);
        view.findViewById(R.id.tvEmptyCreateFirst).setVisibility(View.GONE);

        tvSearchConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doSearch();
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        mMemberProcess = new MemberProcess();
        memberEditorProcessor = new MemberEditorProcessor();
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();


    }


    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            pageNo = 1;
        } else {
            pageNo++;
        }
        loadDataFromServer( mode);

    }


    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer( PullRecyclerView.MODE_PULL_TO_END);

    }

    /**
     * 根据名称手机号卡号查询会员
     */
    private void doSearch() {

        String number = etMemberSearch.getText().toString().trim();
        if (TextUtils.isEmpty(number)) {
            ToastUtil.showToast("请输入手机或者卡号搜索");
            return;
        }
        if (MemberUtils.checkIsPhoneNumber(number)) {
            mobile = number;
            cardNo = "";
        } else {
            mobile = "";
            cardNo = number;
           /* if (MemberUtils.checkIsCardNo(number)) {
                cardNo = number;
            } else {
                ToastUtil.showToast("请正确输入会员卡号或者手机号");
                return;
            }*/
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
        KeyboardManager.hideSoftInput(etMemberSearch.getEditText());
    }


    /**
     * 请求会员列表
     *
     */
    private void loadDataFromServer(final int mode) {

        memberEditorProcessor.loadMemberCardList(cardNo, mobile, pageNo, new ResultCallback<AirMemberCardResponse>() {
            @Override
            public void onSuccess(AirMemberCardResponse data) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                if (pageNo >= data.data.pages) {//没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }

                if (!com.mwee.android.pos.util.TextUtils.validate(data.data.rows)) {
                    mPullRecyclerView.showEmptyView();
                    adapter.notifyDataSetChanged();
                    mEmptyLayout.setVisibility(View.VISIBLE);
                } else {
                    mPullRecyclerView.showContent();
                    mEmptyLayout.setVisibility(View.GONE);
                    MemberCardContainer memberCardContainer = data.data;
                    refreshUI(memberCardContainer);
                    refreshMemberListAdapter(memberCardContainer.rows);
                    isSearchFirst = false;
                }


            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                        mEmptyLayout.setVisibility(View.VISIBLE);
                    }
                    mPullRecyclerView.onRefreshCompleted(mode,IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });

    }


    private void refreshUI(MemberCardContainer memberCardContainer) {

        if(isSearchFirst){
            tvMemberCount.setText(String.format("共%s个会员", memberCardContainer.count));
            tvMemberAddCount.setText(String.format("今日新增 %s", memberCardContainer.size));
            setText(tvMemberCount, "共", memberCardContainer.count + "", "个会员");
            setText(tvMemberAddCount, "今日新增 ", memberCardContainer.todayIncreaseMember + "", "");
        }
    }


    private void setText(TextView textView, String contentLable, String content1, String contentLable2) {

        SpannableString sp = new SpannableString(contentLable + content1 + contentLable2);
        sp.setSpan(new ForegroundColorSpan(Color.BLACK), 0, contentLable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new ForegroundColorSpan(Color.RED), contentLable.length(), contentLable.length() + content1.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new ForegroundColorSpan(Color.BLACK), contentLable.length() + content1.length(), contentLable.length() + content1.length() + contentLable2.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(sp);

    }


    private void refreshMemberListAdapter(List<AirMemberCardModel> rows) {
        modules.addAll(rows);
        adapter.notifyDataSetChanged();

    }


    class Holder extends BaseViewHolder implements View.OnClickListener {

        private TextView tvMobile;
        private TextView tvCardNo;
        private TextView tvName;
        private TextView tvLeverName;
        //private TextView tvDiscount;
        private TextView tvOpenCardTime;
        private ImageView tvOperate;

        private AirMemberCardModel model;


        public Holder(View v) {
            super(v);
            tvMobile = v.findViewById(R.id.tvMobile);
            tvCardNo = v.findViewById(R.id.tvCardNo);
            tvName = v.findViewById(R.id.tvName);
            tvLeverName = v.findViewById(R.id.tvLeverName);
            //tvDiscount = v.findViewById(R.id.tvDiscount);
            tvOpenCardTime = v.findViewById(R.id.tvOpenCardTime);
            tvOperate = v.findViewById(R.id.tvOperate);

            tvOperate.setOnClickListener(this);

        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);

            tvMobile.setText(model.mobile);
            tvCardNo.setText(model.card_no);
            tvName.setText(model.real_name);
            tvLeverName.setText(model.title);
            tvOpenCardTime.setText(DateTimeUtil.getTime((model.add_time) * 1000));

        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.tvOperate:
                    String card_no = model.card_no;
                    doOperate(card_no);
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 编辑会员列表
     */
    private void doOperate(String card_no) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_query_ing);
        LogUtil.log(TAG, "会员查询ing");
        mMemberProcess.onlyLoadMemberInfo(card_no, new IResponse<QueryMemberInfoResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse data) {

                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    LogUtil.log(TAG, "会员查询done cardNo=" + data.memberCardModel.card_info.card_no);
                    showMemberInfoFragment(data.memberCardModel);
                } else {
                    LogUtil.log(TAG, "会员查询failure msg=" + msg);
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    private void showMemberInfoFragment(MemberCardModel memberCardModel) {

        LogUtil.log(TAG, "显示会员详情界面 cardNo=" + memberCardModel.card_info.card_no);
        //MemberInfoContainerFragment fragment = MemberInfoContainerFragment.getInstance(memberCardModel);
        Bundle bundle = new Bundle();
        bundle.putSerializable(MemberInfoContainerFragment.KEY_MEMBER_INFO, memberCardModel);
        //fragment.setArguments(bundle);
        Intent intent = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
        intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("会员", MemberInfoContainerFragment.class));
        intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle);
        getActivityWithinHost().startActivity(intent);
    }





}
