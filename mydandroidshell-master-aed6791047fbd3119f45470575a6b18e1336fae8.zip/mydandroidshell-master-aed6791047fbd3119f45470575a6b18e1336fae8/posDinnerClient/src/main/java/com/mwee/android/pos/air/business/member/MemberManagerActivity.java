package com.mwee.android.pos.air.business.member;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.member.fragment.MemberDiscountSettingFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberLevelManagerFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberListFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberPackageFragment;
import com.mwee.android.pos.air.business.member.fragment.MemberScoreGiftRuleFragment;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;

import java.io.Serializable;

/**
 * Created by qinwei on 2017/10/16.
 */

public class MemberManagerActivity extends AirBaseActivity {
    private TitleBar mTitleBar;
    private RecyclerView mRecyclerView;
    private BaseListAdapter<ClazzInfo> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_manager);
        mTitleBar = (TitleBar) findViewById(R.id.mTitleBar);
        mRecyclerView = (RecyclerView) findViewById(R.id.mRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.addItemDecoration(new DividerItemDecoration(getContextWithinHost(), DividerItemDecoration.VERTICAL_LIST));
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });
        initData();
    }

    private void initData() {
        mTitleBar.setTitle("会员管理");
        adapter = new BaseListAdapter<ClazzInfo>() {
            int choicePosition;

            @Override
            protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
                return new Holder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.menu_class_son_category_item_layout, parent, false));
            }

            class Holder extends BaseViewHolder implements View.OnClickListener {

                private TextView label;
                private int position;


                public Holder(View itemView) {
                    super(itemView);
                    label = (TextView) itemView;
                    label.setOnClickListener(this);
                }

                @Override
                public void bindData(int position) {
                    this.position = position;
                    label.setText(modules.get(position).name);
                    this.position = position;

                    if (position == choicePosition) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_air_category_item_checked);
                        label.setTextColor(getResources().getColor(R.color.system_red));

                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                        label.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                    }
                }

                @Override
                public void onClick(View v) {

                    if (choicePosition != position) {
                        choicePosition = this.position;
                        notifyDataSetChanged();

                        BaseFragment baseFragment = (BaseFragment) getSupportFragmentManager().findFragmentByTag("tab");
                        if (baseFragment instanceof MemberScoreGiftRuleFragment) {

                            MemberScoreGiftRuleFragment ruleFragment = (MemberScoreGiftRuleFragment) baseFragment;
                            if (ruleFragment.checkDataChange()) {
                                DialogManager.showExecuteDialog(getActivityWithinHost(), "会员积分规则变动了,您是否保存", "取消", "确定", new DialogResponseListener() {
                                    @Override
                                    public void response() {
                                        ruleFragment.doSave();
                                        setCurrentTab(position);

                                    }
                                }, new DialogResponseListener() {
                                    @Override
                                    public void response() {
                                        setCurrentTab(position);
                                    }
                                });
                            }else {
                                setCurrentTab(position);
                            }
                            return;
                        }

                        if (baseFragment instanceof MemberPackageFragment) {
                            MemberPackageFragment memberPackageFragment = (MemberPackageFragment) baseFragment;
                            if (memberPackageFragment.checkDataChange()) {
                                DialogManager.showExecuteDialog(getActivityWithinHost(), "会员套餐数据变动了,您是否保存", "取消", "确定", new DialogResponseListener() {
                                    @Override
                                    public void response() {
                                        memberPackageFragment.doSave();
                                        setCurrentTab(position);

                                    }
                                }, new DialogResponseListener() {
                                    @Override
                                    public void response() {
                                        setCurrentTab(position);
                                    }
                                });
                            }else {
                                setCurrentTab(position);
                            }
                            return;
                        }
                        setCurrentTab(position);

                    }

                }
            }
        };
        adapter.modules.add(new ClazzInfo("积分规则", MemberScoreGiftRuleFragment.class));
        adapter.modules.add(new ClazzInfo("会员优惠", MemberDiscountSettingFragment.class));
        adapter.modules.add(new ClazzInfo("会员列表", MemberListFragment.class));
        adapter.modules.add(new ClazzInfo("等级管理", MemberLevelManagerFragment.class));
        adapter.modules.add(new ClazzInfo("充值套餐", MemberPackageFragment.class));
        mRecyclerView.setAdapter(adapter);
        setCurrentTab(0);
    }

    public void setCurrentTab(int position) {
        try {
            getSupportFragmentManager().beginTransaction().replace(R.id.mMemberContainerLayout, adapter.modules.get(position).clazz.newInstance(), "tab").commit();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static class ClazzInfo implements Serializable {
        public ClazzInfo(String name, Class<? extends BaseFragment> clazz) {
            this.name = name;
            this.clazz = clazz;
        }

        public String name;
        public Class<? extends BaseFragment> clazz;
    }
}
