package com.mwee.android.pos.business.member;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.entity.Coupon;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.AnimatorListenerImpl;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/2/21.
 */

public class CouponListFragment extends BaseListFragment<MemberCouponsDetailModel.CouponData> {

    private static final String KEY_MEMBER_INFO = "key_member_info";
    private static final String KEY_CARD_ID = "key_card_id";
    private MemberProcess mMemberProcess;
//    private MemberCardModel memberCardModel;
    private ImageView mCouponItemTopImg;
    private int mCurrentPage = 1;
    private String mCardNo;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_coupon_list;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new CouponListFragment.Holder(LayoutInflater.from(getContext()).inflate(R.layout.member_coupon_item, parent, false));
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mCouponItemTopImg = (ImageView) view.findViewById(R.id.mCouponItemTopImg);
        mCouponItemTopImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPullRecyclerView.smoothScrollToPosition(0);
            }
        });
        mPullRecyclerView.setEnablePullToEnd(true);
    }

    @Override
    protected void initData() {
        super.initData();
        mMemberProcess = new MemberProcess();
        mCardNo = getArguments().getString(KEY_CARD_ID);
//        memberCardModel = (MemberCardModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setRefreshing();
    }

    /*private void loadDataFromServer(final int mode) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_coupon_load_msg);
        mMemberProcess.loadMemberCoupons(memberCardModel.card_info.card_no, 1, 1000, new ResultCallback<ArrayList<Coupon>>() {
            @Override
            public void onSuccess(ArrayList<Coupon> data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (TextUtils.validate(data)) {
                    modules.clear();
                    modules.addAll(data);
                    adapter.notifyDataSetChanged();
                    mPullRecyclerView.showContent();
                } else {
                    mPullRecyclerView.showEmptyView();
                }
                mPullRecyclerView.onRefreshCompleted(mode);
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                mPullRecyclerView.onRefreshCompleted(mode);
                if (modules.size() == 0) {
                    mPullRecyclerView.showEmptyView();
                }
                ToastUtil.showToast(msg);
            }
        });
    }*/

    private void loadNewDataFromServer(final int mode) {
        ClientMemberApi.queryMemberCoupons(mCardNo, mCurrentPage, response -> {
            if(response == null || response.data == null){
                mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                if(mCurrentPage > 1 ){
                    mCurrentPage --;
                }
                return;
            }
            if(response.success()){
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                MemberCouponsDetailModel data = response.data;
                if(mCurrentPage < data.pages){
                    mPullRecyclerView.onRefreshCompleted(mode);
                }else{
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                }
                if (ListUtil.isEmpty(data.rows)) {
                    if(mCurrentPage == 1){
                        mPullRecyclerView.showEmptyView();
                    }
                } else {
                    mPullRecyclerView.showContent();
                    modules.addAll(data.rows);
                    adapter.notifyDataSetChanged();
                }
            }else{
                if(mCurrentPage > 1 ){
                    mCurrentPage --;
                }
                if (!android.text.TextUtils.isEmpty(response.message)) {
                    ToastUtil.showToast(response.message);
                }
                if (mode == PullRecyclerView.STATE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            mCurrentPage = 1;
        } else {
            mCurrentPage ++;
        }
        loadNewDataFromServer(mode);
    }

    @Override
    public void onScrollUp() {
        super.onScrollUp();
        if (!AnimatorListenerImpl.isRunning && mCouponItemTopImg.getVisibility() == View.GONE) {
            mCouponItemTopImg.setVisibility(View.VISIBLE);
            ObjectAnimator animator = ObjectAnimator.ofFloat(mCouponItemTopImg, "alpha", 0f, 1f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mCouponItemTopImg.setVisibility(View.VISIBLE);
                }
            });
            animator.start();
        }
    }

    @Override
    public void onScrollDown() {
        super.onScrollDown();
        if (!AnimatorListenerImpl.isRunning && mCouponItemTopImg.getVisibility() == View.VISIBLE) {
            ObjectAnimator animator = ObjectAnimator.ofFloat(mCouponItemTopImg, "alpha", 1f, 0f);
            animator.setDuration(800);
            animator.addListener(new AnimatorListenerImpl() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mCouponItemTopImg.setVisibility(View.GONE);
                }
            });
            animator.start();
        }
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private View mCouponItemTypeLayout;
        private TextView mCouponItemTypeNameLabel;
        private TextView mCouponItemTitleLabel;
        private TextView mCouponItemTimeLabel;
        private TextView mCouponItemCurrentShopEnable;
        private MemberCouponsDetailModel.CouponData coupon;

        public Holder(View v) {
            super(v);
            mCouponItemTypeNameLabel = (TextView) v.findViewById(R.id.mCouponItemTypeNameLabel);
            mCouponItemTitleLabel = (TextView) v.findViewById(R.id.mCouponItemTitleLabel);
            mCouponItemTimeLabel = (TextView) v.findViewById(R.id.mCouponItemTimeLabel);
            mCouponItemCurrentShopEnable = (TextView) v.findViewById(R.id.mCouponItemCurrentShopEnableLabel);
            mCouponItemTypeLayout = v.findViewById(R.id.mCouponItemTypeLayout);
            v.findViewById(R.id.mCouponItemContainer).setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            coupon = modules.get(position);
            mCouponItemTitleLabel.setText(coupon.title);
            mCouponItemTimeLabel.setText(coupon.expiryAll);
            mCouponItemTypeNameLabel.setText(coupon.typeName);
            if (position == 0 || !coupon.ctype.equals(modules.get(position - 1).ctype)) {
                mCouponItemTypeLayout.setVisibility(View.VISIBLE);
            } else {
                mCouponItemTypeLayout.setVisibility(View.GONE);
            }
            if (coupon.status.equals("0")) {
                mCouponItemCurrentShopEnable.setVisibility(View.GONE);
            } else {
                mCouponItemCurrentShopEnable.setText(getStatusName(coupon.status));
                mCouponItemCurrentShopEnable.setVisibility(View.VISIBLE);
            }
        }

        public String getStatusName(String status) {
            String name = "";
            switch (status) {
                case "1":
                    name = "已使用";
                    break;
                case "2":
                    name = "退还中";
                    break;
                case "3":
                    name = "已退还";
                    break;
                case "4":
                    name = "已过期作废";
                    break;
                case "5":
                    name = "微信预分配";
                    break;
                default:
                    break;
            }
            return name;
        }


        @Override
        public void onClick(View v) {
            //0=>未使用 1=>使用 2=>退款中/申请退款 3=>已退款 4=>作废/过期 5=>微信预分配
            switch (coupon.status) {
                case "0":
                    ToastUtil.showToast(getString(R.string.mCouponMessage));
                    break;
                default:
                    break;
            }
        }
    }


    public static BaseFragment getInstance(MemberCardModel memberCardModel) {
        BaseFragment fragment = new CouponListFragment();
        Bundle args = new Bundle();
        args.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        fragment.setArguments(args);
        return fragment;
    }

    public static BaseFragment getInstance(String cardNo) {
        BaseFragment fragment = new CouponListFragment();
        Bundle args = new Bundle();
        args.putSerializable(KEY_CARD_ID, cardNo);
        fragment.setArguments(args);
        return fragment;
    }
}
