package com.mwee.android.pos.air.business.setting;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.box.TBoxFragment;
import com.mwee.android.pos.air.business.tprinter.TPrinterSetFragment;
import com.mwee.android.pos.air.business.tshop.TPhotoAlbummFragment;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.business.setting.process.UsbSerialJump;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;

/**
 * Created by zhangmin on 2017/12/13.
 */

public class AirSetExternalFragment extends BaseFragment implements IDriver, View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    public static final String TAG = "setting";



    private TextView tvPrinterSet;
    private TextView tvEleSet;
    private TextView tvScreenSet;
    private RelativeLayout rlBoxLayout;

    private View t_restaurantLayout;
    private Switch swPrinterTicketSet;
    private Switch swWaiterPreBillSet;

    /**
     * 美小二服务开关
     */
    private Switch mWaiterService;

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_set_external_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        DriverBus.registerDriver(this);
        assignViews(view);
        registerEvent();
        initData();
    }

    private void assignViews(View container) {


        /*基础配置*/
        tvPrinterSet = (TextView) container.findViewById(R.id.tvPrinterSet);
        tvEleSet = (TextView) container.findViewById(R.id.tvEleSet);
        tvScreenSet = (TextView) container.findViewById(R.id.tvScreenSet);
        rlBoxLayout = (RelativeLayout) container.findViewById(R.id.rlBoxLayout);

        /*餐厅设置*/
        t_restaurantLayout = container.findViewById(R.id.t_restaurantLayout);
        swPrinterTicketSet = (Switch) container.findViewById(R.id.swPrinterTicketSet);//打烊打印报表
        swWaiterPreBillSet = (Switch) container.findViewById(R.id.swWaiterPreBillSet);//美小二预结单打印

        mWaiterService = container.findViewById(R.id.switch_waiter_service_turn);
    }


    private void registerEvent() {


        tvPrinterSet.setOnClickListener(this);
        tvEleSet.setOnClickListener(this);
        tvScreenSet.setOnClickListener(this);
        rlBoxLayout.setOnClickListener(this);

        /*餐厅设置*/

        swPrinterTicketSet.setOnCheckedChangeListener(this);
        swWaiterPreBillSet.setOnCheckedChangeListener(this);

        mWaiterService.setOnCheckedChangeListener(this);
    }


    private void initData() {

        if (ClientBindProcessor.isCurrentHostMain()) {
            swPrinterTicketSet.setChecked(SettingHelper.isShiftReport());
            swWaiterPreBillSet.setChecked(TextUtils.equals(SettingHelper.getDinnerSetting(DBPrintConfig.RAPID_PRINT_BILL, "1"), "1"));
            mWaiterService.setChecked(ClientMetaUtil.needStartUpWaiterServer());
        }else {
            t_restaurantLayout.setVisibility(View.GONE);
        }


    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tvPrinterSet:
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    ToastUtil.showToast("收银小票配置仅仅主机可以操作");
                    return;
                }
                ActionLog.addLog("更多设置->点击了打印设置", "", "", ActionLog.SS_MORE_JOIN, "");
                TPrinterSetFragment tPrinterSetFragment = new TPrinterSetFragment();
                FragmentController.addFragment(getActivityWithinHost(), tPrinterSetFragment);
                break;
            case R.id.tvEleSet:
                ActionLog.addLog("更多设置->点击了电子秤设置", "", "", ActionLog.SS_MORE_JOIN, "");
                UsbSerialJump.showUsbEleFragmentJump(getActivityWithinHost());
                break;
            case R.id.tvScreenSet:
                ActionLog.addLog("更多设置->点击了屏显设置", "", "", ActionLog.SS_MORE_JOIN, "");
                TPhotoAlbummFragment tPhotoAlbummFragment = new TPhotoAlbummFragment();
                FragmentController.addFragment(getActivityWithinHost(), tPhotoAlbummFragment);
                break;
            case R.id.rlBoxLayout:
                ActionLog.addLog("更多设置->点击了开钱箱设置", "", "", ActionLog.SS_MORE_JOIN, "");
                TBoxFragment tBoxFragment = new TBoxFragment();
                FragmentController.addFragment(getActivityWithinHost(), tBoxFragment);
                break;
            default:
                break;
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        /*餐厅设置*/
        switch (buttonView.getId()) {

            case R.id.swPrinterTicketSet:
                ActionLog.addLog("更多设置->点击了打烊是否打印报表", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBPrintConfig.AUTO_PRINT_CLOSE, isChecked ? "1" : "0");
                break;

            case R.id.swWaiterPreBillSet:
                ActionLog.addLog("更多设置->美小二通过区域打印预结单", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBPrintConfig.WAITER_PRE_PRINT, isChecked ? "0" : "1");
                break;
            case R.id.switch_waiter_service_turn:
                // 美小二服务开关
                ActionLog.addLog("更多设置->点击了美小二服务开关按钮", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.refreshSettingStatus(META.SWITCH_WAITER_SERVICE, isChecked ? "1" : "0");
                break;
            default:
                break;
        }


    }


    @DrivenMethod(uri = TAG + "/refreshDBConfig", UIThread = true)
    public void refreshDBConfig(String type, String value) {
        switch (type) {

            case DBPrintConfig.AUTO_PRINT_CLOSE:   //交班打印报表
                if (swPrinterTicketSet != null) {
                    swPrinterTicketSet.setChecked(TextUtils.equals(value, "1"));
                }
                break;

            case DBPrintConfig.WAITER_PRE_PRINT:   //美小二通过区域打印预结单
                if (swWaiterPreBillSet != null) {
                    swWaiterPreBillSet.setChecked(TextUtils.equals(value, "0"));
                }
                break;

            default:
                break;

        }
    }


}
