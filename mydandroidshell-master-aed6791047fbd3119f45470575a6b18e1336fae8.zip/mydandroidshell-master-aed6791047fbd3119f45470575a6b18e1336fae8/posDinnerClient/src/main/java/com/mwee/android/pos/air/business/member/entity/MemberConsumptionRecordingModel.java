package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class MemberConsumptionRecordingModel extends BusinessBean {

    public String m_shopid;

    public String shopname;

    public String card_no;

    public String score;

    public String mobile;

    public String type;

    public String trade_no;

    //会员卡支付金额
    public String amount;

    //账户余额
    public String total_amount;

    public String add_time;

    public String present_moeny;

    //会员卡实付金额
    public String amount_use_reality;

    public String type_name;


}
