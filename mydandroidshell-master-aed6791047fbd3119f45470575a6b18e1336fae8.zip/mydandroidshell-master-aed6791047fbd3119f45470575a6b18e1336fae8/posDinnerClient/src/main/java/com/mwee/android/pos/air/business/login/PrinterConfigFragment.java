//package com.mwee.android.pos.air.business.login;
//
//import android.support.v4.app.FragmentTransaction;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//
//import com.mwee.android.air.db.business.menu.MenuClsBean;
//import com.mwee.android.pos.air.business.tprinter.PrinterEditorDialogFragment;
//import com.mwee.android.pos.air.business.tprinter.PrinterProcessor;
//import com.mwee.android.pos.base.BaseListFragment;
//import com.mwee.android.pos.component.callback.ResultCallback;
//import com.mwee.android.pos.component.dialog.DialogManager;
//import com.mwee.android.pos.component.dialog.Progress;
//import com.mwee.android.pos.component.dialog.ProgressManager;
//import com.mwee.android.pos.connect.business.print.PrinterItem;
//import com.mwee.android.pos.dinner.R;
//import com.mwee.android.pos.util.TextUtils;
//import com.mwee.android.pos.util.ToastUtil;
//import com.mwee.android.pos.widget.RefreshView;
//import com.mwee.android.pos.widget.pull.BaseViewHolder;
//import com.mwee.android.posmodel.print.PrinterConstants;
//import com.mwee.android.posmodel.print.PrinterType;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Created by qinwei on 2018/1/11.
// */
//
//public class PrinterConfigFragment extends BaseListFragment<PrinterItem> implements RefreshView.OnRetryListener, PrinterEditorDialogFragment.OnPrinterEditorListener, View.OnClickListener {
//    private PrinterProcessor mProcessor;
//    private RefreshView mRefreshView;
//    private Button mPrinterConfigPreBtn;
//    private Button mPrinterConfigNextBtn;
//    private View mPrinterOperationLayout;
//
//    @Override
//    public int getFragmentLayoutId() {
//        return R.layout.fragment_air_printer_config;
//    }
//
//
//    @Override
//    public void initView(View view) {
//        super.initView(view);
//        mPrinterOperationLayout = view.findViewById(R.id.mPrinterOperationLayout);
//        mPrinterConfigPreBtn = (Button) view.findViewById(R.id.mPrinterConfigPreBtn);
//        mPrinterConfigNextBtn = (Button) view.findViewById(R.id.mPrinterConfigNextBtn);
//        mPullRecyclerView.setEnablePullToStart(false);
//        mRefreshView = (RefreshView) view.findViewById(R.id.mRefreshView);
//        mRefreshView.setErrorView(R.layout.air_printer_add);
//        mRefreshView.setOnRetryListener(this);
//        mPrinterConfigPreBtn.setOnClickListener(this);
//        mPrinterConfigNextBtn.setOnClickListener(this);
//        ((GuideListener) getActivity()).currentPage(AppConfigContainerActivity.PAGE_SETTINGPRINT);
//        mPrinterOperationLayout.setVisibility(View.INVISIBLE);
//    }
//
//    @Override
//    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
//        return new BaseViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.view_printer_config_item, parent, false)) {
//            @Override
//            public void bindData(int position) {
//                PrinterItem item = modules.get(position);
//                setText(R.id.mPrinterConfigItemNameLabel, item.name);
//                setText(R.id.mPrinterConfigItemTypeLabel, mProcessor.getPrinterType(item.type));
//                setText(R.id.mPrinterConfigItemSizeLabel, getCommandTypeString(item.size));
//            }
//
//            public String getCommandTypeString(int fiPaperSize) {
//                if (fiPaperSize == PrinterConstants.SIZE_58) {
//                    return 58 + "mm";
//                } else if (fiPaperSize == PrinterConstants.SIZE_80) {
//                    return 80 + "mm";
//                }
//                return 76 + "mm";
//            }
//        };
//    }
//
//    @Override
//    public void initData() {
//        mProcessor = new PrinterProcessor(getContext());
//        mRefreshView.notifyDataChanged(RefreshView.State.ing);
//        loadDataFromServer();
//    }
//
//    @Override
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.mPrinterConfigPreBtn:
//                getActivity().getSupportFragmentManager().popBackStack();
//                break;
//            case R.id.mPrinterConfigNextBtn:
//                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
//                transaction.replace(R.id.mAppConfigContainer, new OpenPayScannerFragment());
//                transaction.addToBackStack("OpenPayScannerFragment");
//                transaction.commit();
//                break;
//            default:
//                break;
//        }
//    }
//
//    private void loadDataFromServer() {
//        mProcessor.loadAllPrinter(new ResultCallback<List<PrinterItem>>() {
//            @Override
//            public void onSuccess(List<PrinterItem> data) {
//                if (TextUtils.validate(data)) {
//                    modules.clear();
//                    modules.addAll(data);
//                    adapter.notifyDataSetChanged();
//                    mRefreshView.notifyDataChanged(RefreshView.State.done);
//                    mPrinterConfigNextBtn.setText("下一步");
//                } else {
//                    mRefreshView.notifyDataChanged(RefreshView.State.error);
//                    mPrinterConfigNextBtn.setText("暂不设置，下一步");
//                }
//                mPrinterOperationLayout.setVisibility(View.VISIBLE);
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                mPrinterOperationLayout.setVisibility(View.VISIBLE);
//                mRefreshView.notifyDataChanged(RefreshView.State.error);
//            }
//        });
//    }
//
//    @Override
//    public void onRetry() {
//        PrinterItem item = PrinterProcessor.buildPrinterItem(PrinterType.USB);
//        item.name = "";
//        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
//        mProcessor.loadMenuCls(new ResultCallback<ArrayList<MenuClsBean>>() {
//            @Override
//            public void onSuccess(ArrayList<MenuClsBean> data) {
//                progress.dismiss();
//                PrinterEditorDialogFragment fragment = new PrinterEditorDialogFragment();
//                fragment.setParam(item, data, PrinterConfigFragment.this);
//                fragment.setIsManualMode(true);
//                DialogManager.showCustomDialog(PrinterConfigFragment.this, fragment, "PrinterEditorDialogFragment");
//            }
//
//            @Override
//            public void onFailure(int code, String msg) {
//                progress.dismiss();
//                ToastUtil.showToast(msg);
//            }
//        });
//
//    }
//
//    @Override
//    public void onPrinterEditorSuccess() {
//
//    }
//
//    @Override
//    public void onPrinterAddSuccess() {
//        loadDataFromServer();
//    }
//
//
//}
