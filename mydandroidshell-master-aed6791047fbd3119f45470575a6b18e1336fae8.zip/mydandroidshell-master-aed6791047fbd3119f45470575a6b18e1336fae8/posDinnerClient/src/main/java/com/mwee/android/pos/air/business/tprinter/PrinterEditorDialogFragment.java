package com.mwee.android.pos.air.business.tprinter;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrinterConstants;
import com.mwee.android.posmodel.print.PrinterType;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by qinwei on 2017/12/20.
 */

public class PrinterEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private ImageView mPrinterCloseImg;
    private LinearLayout mPrinterTypeLayout;
    private TextView mPrinterUSBLabel;
    private TextView mPrinterNetLabel;
    private TextView mPrinterBluetoothLabel;
    private EditText mPrinterNameEdt;
    private LinearLayout mPrinterIPLayout;
    private TextView mPrinterIPLabel;
    private EditText mPrinterIPEdt;
    private RadioButton mPrinterSize58RB;
    private RadioButton mPrinterSize76RB;
    private RadioButton mPrinterSize80RB;
    private CheckBox mPrinterTicketCashCB;
    private CheckBox mPrinterTicketMakeCB;
    private CheckBox mPrinterTicketTagCB;
    private Button mPrinterCheckBtn;
    private Button mPrinterConfirmBtn;
    private GridView mPrinterMenuClsGV;
    private OnPrinterEditorListener listener;
    private PrinterItem printerItem;
    private PrinterProcessor processor;
    private MenuClsAdapter adapter;
    private ArrayList<MenuClsBean> menuClsBeans;

    private Spinner mDeviceSpinner;
    private CommonAdapter<String> mDeviceAdapter;
    private LinearLayout mPrintUsbLayout;
    private List<String> mDeviceNameList = new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_printer_self_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        view.setOnClickListener(null);
        mPrinterMenuClsGV = (GridView) view.findViewById(R.id.mPrinterMenuClsGV);
        mPrinterCloseImg = (ImageView) view.findViewById(R.id.mPrinterCloseImg);
        mPrinterTypeLayout = (LinearLayout) view.findViewById(R.id.mPrinterTypeLayout);
        mPrinterUSBLabel = (TextView) view.findViewById(R.id.mPrinterUSBLabel);
        mPrinterNetLabel = (TextView) view.findViewById(R.id.mPrinterNetLabel);
        mPrinterBluetoothLabel = (TextView) view.findViewById(R.id.mPrinterBluetoothLabel);
        mPrinterNameEdt = (EditText) view.findViewById(R.id.mPrinterNameEdt);
        mPrinterIPLayout = (LinearLayout) view.findViewById(R.id.mPrinterIPLayout);
        mPrinterIPLabel = (TextView) view.findViewById(R.id.mPrinterIPLabel);
        mPrinterIPEdt = (EditText) view.findViewById(R.id.mPrinterIPEdt);
        mPrinterSize58RB = (RadioButton) view.findViewById(R.id.mPrinterSize58RB);
        mPrinterSize76RB = (RadioButton) view.findViewById(R.id.mPrinterSize76RB);
        mPrinterSize80RB = (RadioButton) view.findViewById(R.id.mPrinterSize80RB);
        mPrinterTicketCashCB = (CheckBox) view.findViewById(R.id.mPrinterTicketCashCB);
        mPrinterTicketMakeCB = (CheckBox) view.findViewById(R.id.mPrinterTicketMakeCB);
        mPrinterTicketTagCB = (CheckBox) view.findViewById(R.id.mPrinterTicketTagCB);
        mPrinterCheckBtn = (Button) view.findViewById(R.id.mPrinterCheckBtn);
        mPrinterConfirmBtn = (Button) view.findViewById(R.id.mPrinterConfirmBtn);

        mPrinterTicketCashCB.setOnCheckedChangeListener(this);
        mPrinterTicketMakeCB.setOnCheckedChangeListener(this);
        mPrinterTicketTagCB.setOnCheckedChangeListener(this);

        mPrinterUSBLabel.setOnClickListener(this);
        mPrinterNetLabel.setOnClickListener(this);
        mPrinterBluetoothLabel.setOnClickListener(this);

        mPrinterCheckBtn.setOnClickListener(this);
        mPrinterConfirmBtn.setOnClickListener(this);
        mPrinterCloseImg.setOnClickListener(this);

        adapter = new MenuClsAdapter();
        mPrinterMenuClsGV.setAdapter(adapter);


        mPrintUsbLayout = view.findViewById(R.id.mPrintUsbLayout);
        mDeviceSpinner = view.findViewById(R.id.mDeviceSpinner);


    }


    private void initData() {

        initDeviceAdapter();
        processor = new PrinterProcessor(getContext());
        mPrinterNameEdt.setText(printerItem.name);
        mPrinterIPEdt.setText(printerItem.ip);
        if (isEditor()) {
            mPrinterTypeLayout.setVisibility(View.GONE);
            switch (printerItem.size) {
                case PrinterConstants.SIZE_58:
                    mPrinterSize58RB.setChecked(true);
                    break;
                case PrinterConstants.SIZE_76:
                    mPrinterSize76RB.setChecked(true);
                    break;
                case PrinterConstants.SIZE_80:
                    mPrinterSize80RB.setChecked(true);
                    break;
                default:
                    break;
            }
            mPrinterTicketCashCB.setChecked(printerItem.isUseHost);
            mPrinterTicketMakeCB.setChecked(printerItem.isUseMake);
            mPrinterTicketTagCB.setChecked(printerItem.isUseTag);
        } else {
            mPrinterSize58RB.setChecked(true);
            mPrinterTicketCashCB.setChecked(true);
            mPrinterTicketMakeCB.setChecked(true);
            //默认全部选中
            for (int i = 0; i < menuClsBeans.size(); i++) {
                printerItem.menuClsIds.add(menuClsBeans.get(i).fsMenuClsId);
            }
        }
        refreshTickCheckStatus();
        refreshPrinterTypeStatus(printerItem.type);

        if (!ListUtil.isEmpty(menuClsBeans)) {
            adapter.modules.addAll(menuClsBeans);
            adapter.notifyDataSetChanged();
        }

    }


    private void initDeviceAdapter() {


        mDeviceAdapter = new CommonAdapter<String>(getContext(), mDeviceNameList, R.layout.simple_spinner_item) {
            @Override
            public void convert(ViewHolder viewHolder, String data, int position) {
                ((TextView) viewHolder.getConvertView()).setText(data);
            }
        };

        mDeviceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {

                String symbol = (String) parent.getAdapter().getItem(position);
                if (TextUtils.isEmpty(symbol) || TextUtils.equals("无", symbol)) {
                    return;
                }
                ActionLog.addLog("选择了指定的USB设备" + symbol.toString(), "", "", ActionLog.PR_PRINT, "");
                printerItem.fsStr1 = symbol;
                PrinterProcessor.updatePrinterConfig(printerItem.name, symbol);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        mDeviceSpinner.setAdapter(mDeviceAdapter);
    }


    /**
     * 获取USB打印机设备列表
     */
    private void loadConnectUsbPrinter() {
        //usb
        PrinterProcessor.loadConnectUsbPrinter(getActivityWithinHost(), new ResultCallback<ArrayList<PrinterItem>>() {
            @Override
            public void onSuccess(ArrayList<PrinterItem> data) {

                refreshDeviceAdapter(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                //没有打印机的时候 默认使用无
                mDeviceNameList.clear();
                mDeviceNameList.add("无");
                mDeviceAdapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * 刷新设备列表
     */
    private void refreshDeviceAdapter(ArrayList<PrinterItem> data) {

        mDeviceNameList.clear();
        mDeviceNameList.add("无");
        for (PrinterItem datum : data) {
            mDeviceNameList.add(datum.fsStr1);
        }
        mDeviceAdapter.notifyDataSetChanged();
        if (!TextUtils.isEmpty(printerItem.fsStr1)) {

            if (mDeviceNameList.contains(printerItem.fsStr1)) {
                //跳转到指定的设备
                int index = mDeviceNameList.indexOf(printerItem.fsStr1);
                mDeviceSpinner.setSelection(index, true);
            } else {
                String hardSymbol = "";
                if (printerItem.fsStr1.contains("@")) {
                    hardSymbol = printerItem.fsStr1.substring(0, printerItem.fsStr1.indexOf("@"));
                } else {
                    hardSymbol = printerItem.fsStr1;
                }
                if (TextUtils.isEmpty(hardSymbol)) {
                    return;
                }
                for(int i=0;i<mDeviceNameList.size();i++){
                    String s = mDeviceNameList.get(i);
                    if (s.contains(hardSymbol)) {
                        mDeviceSpinner.setSelection(i, true);
                        break;
                    }
                }


            }
        }


    }

    /**
     * 控制打印机类型选择
     *
     * @param type
     */
    public void refreshPrinterTypeStatus(int type) {
        printerItem.type = type;
        switch (type) {
            case PrinterType.USB:
                mPrinterUSBLabel.setSelected(true);
                mPrinterNetLabel.setSelected(false);
                mPrinterBluetoothLabel.setSelected(false);
                mPrinterIPLayout.setVisibility(View.GONE);
                if (isManualMode) {//只有手动添加才会生效
                    mPrintUsbLayout.setVisibility(View.VISIBLE);
                    loadConnectUsbPrinter();
                }
                break;
            case PrinterType.NET:
                mPrinterUSBLabel.setSelected(false);
                mPrinterNetLabel.setSelected(true);
                mPrinterBluetoothLabel.setSelected(false);
                mPrinterIPLayout.setVisibility(View.VISIBLE);
                mPrintUsbLayout.setVisibility(View.GONE);
                mPrinterIPLabel.setText("IP地址");
                mPrinterIPEdt.setHint("请输入IP地址");
                break;
            case PrinterType.BLUETOOTH:
                mPrinterUSBLabel.setSelected(false);
                mPrinterNetLabel.setSelected(false);
                mPrinterBluetoothLabel.setSelected(true);
                mPrinterIPLayout.setVisibility(View.VISIBLE);
                mPrintUsbLayout.setVisibility(View.GONE);
                mPrinterIPLabel.setText("MAC地址");
                mPrinterIPEdt.setHint("请输入MAC地址");
                break;
            default:
                break;
        }
    }

    /**
     * 控制小票可选状态
     */
    public void refreshTickCheckStatus() {
        boolean cash = mPrinterTicketCashCB.isChecked();
        boolean make = mPrinterTicketMakeCB.isChecked();
        boolean tag = mPrinterTicketTagCB.isChecked();
        if (cash || make) {
            mPrinterTicketTagCB.setEnabled(false);
        } else {
            mPrinterTicketTagCB.setEnabled(true);
        }
        if (tag) {
            mPrinterTicketCashCB.setEnabled(false);
            mPrinterTicketMakeCB.setEnabled(false);
        } else {
            mPrinterTicketCashCB.setEnabled(true);
            mPrinterTicketMakeCB.setEnabled(true);
        }
    }

    public void setParam(PrinterItem printerItem, ArrayList<MenuClsBean> menuClsBeans, OnPrinterEditorListener listener) {
        this.printerItem = printerItem;
        this.listener = listener;
        this.menuClsBeans = menuClsBeans;
    }


    /**
     * 是否可以指定USB打印机对应的设备
     */
    boolean isManualMode = false;

    public void setIsManualMode(boolean isManualMode) {
        this.isManualMode = isManualMode;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mPrinterCloseImg:
                dismiss();
                break;
            case R.id.mPrinterUSBLabel:
                refreshPrinterTypeStatus(PrinterType.USB);
                break;
            case R.id.mPrinterBluetoothLabel:
                refreshPrinterTypeStatus(PrinterType.BLUETOOTH);
                break;
            case R.id.mPrinterNetLabel:
                refreshPrinterTypeStatus(PrinterType.NET);
                break;
            case R.id.mPrinterCheckBtn:
                doPrinterCheck();
                break;
            case R.id.mPrinterConfirmBtn:
                String name = mPrinterNameEdt.getText().toString().trim();
                String ip = mPrinterIPEdt.getText().toString().trim();
                if (!check(name, ip)) {
                    return;
                }

                if (mPrinterSize58RB.isChecked()) {
                    printerItem.size = PrinterConstants.SIZE_58;
                } else if (mPrinterSize76RB.isChecked()) {
                    printerItem.size = PrinterConstants.SIZE_76;
                } else {
                    printerItem.size = PrinterConstants.SIZE_80;
                }
                printerItem.name = name;
                printerItem.ip = ip;
                printerItem.isUseTag = mPrinterTicketTagCB.isChecked();
                printerItem.isUseMake = mPrinterTicketMakeCB.isChecked();
                printerItem.isUseHost = mPrinterTicketCashCB.isChecked();
                if (printerItem.isUseTag) {
                    //标签
                    printerItem.fsCommandType = "TSC";
                } else {
                    //普通
                    printerItem.fsCommandType = "ESC";
                }
                if (isEditor()) {
                    doSave();
                } else {
                    doAdd();
                }
                break;
            default:
                break;
        }
    }

    public boolean check(String name, String ip) {
        if (TextUtils.isEmpty(name)) {
            ToastUtil.showToast("打印机名称不能为空");
            return false;
        }
        if (TextUtils.isEmpty(ip)) {
            if (mPrinterNetLabel.isSelected()) {
                ToastUtil.showToast("IP地址不能为空");
                return false;
            }
            if (mPrinterBluetoothLabel.isSelected()) {
                ToastUtil.showToast("MAC地址不能为空");
                return false;
            }
        }
        return true;
    }

    private void doPrinterCheck() {
        String name = mPrinterNameEdt.getText().toString().trim();
        String ip = mPrinterIPEdt.getText().toString().trim();
        if (!check(name, ip)) {
            return;
        }
        if (mPrinterSize58RB.isChecked()) {
            printerItem.size = PrinterConstants.SIZE_58;
        } else if (mPrinterSize76RB.isChecked()) {
            printerItem.size = PrinterConstants.SIZE_76;
        } else {
            printerItem.size = PrinterConstants.SIZE_80;
        }
        //设置打印机打印指令类型
        if (mPrinterTicketTagCB.isChecked()) {
            //标签
            printerItem.fsCommandType = "TSC";
        } else {
            //普通
            printerItem.fsCommandType = "ESC";
        }
        printerItem.ip = ip;
        printerItem.name = name;
        processor.processDetectionPrinter(processor.copyToPrinterDBModel(printerItem));
    }

    private void doSave() {
        final Progress progress = ProgressManager.showProgressUncancel(this, "修改中...");
        processor.loadUpdatePrinter(printerItem, new ResultCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {
                listener.onPrinterEditorSuccess();
                progress.dismiss();
                dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismiss();
            }
        });
    }

    private void doAdd() {
        final Progress progress = ProgressManager.showProgressUncancel(this, "添加中...");
        processor.loadAddPrinter(printerItem, new ResultCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {
                listener.onPrinterAddSuccess();
                progress.dismiss();
                dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.mPrinterTicketCashCB:
            case R.id.mPrinterTicketMakeCB:
            case R.id.mPrinterTicketTagCB:
                refreshTickCheckStatus();
                break;
            default:
                break;
        }
    }

    class MenuClsAdapter extends BaseMwAdapter<MenuClsBean> {
        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.air_printer_choice_menu_item_cls_item, parent, false);
                holder = new Holder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }
            holder.bindData(position);
            return convertView;
        }

        class Holder implements CompoundButton.OnCheckedChangeListener {
            private CheckBox mPrinterMenuClsItemNameCB;
            private MenuClsBean bean;

            public Holder(View v) {
                mPrinterMenuClsItemNameCB = (CheckBox) v.findViewById(R.id.mPrinterMenuClsItemNameCB);
                mPrinterMenuClsItemNameCB.setOnCheckedChangeListener(this);
            }

            public void bindData(int position) {
                bean = modules.get(position);
                mPrinterMenuClsItemNameCB.setText(bean.fsMenuClsName);
                mPrinterMenuClsItemNameCB.setChecked(printerItem.menuClsIds.contains(bean.fsMenuClsId));
            }

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    printerItem.menuClsIds.add(bean.fsMenuClsId);
                } else {
                    printerItem.menuClsIds.remove(bean.fsMenuClsId);
                }
            }
        }
    }

    /**
     * 打印机编辑监听
     */
    public interface OnPrinterEditorListener {
        /**
         * 编辑成功回调
         */
        void onPrinterEditorSuccess();

        /**
         * 新增成功回调
         */
        void onPrinterAddSuccess();
    }

    /**
     * 是否是编辑打印机
     *
     * @return
     */
    public boolean isEditor() {
        return printerItem.id > -1;
    }
}
