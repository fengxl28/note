package com.mwee.android.pos.air.business.fastfood.processor;

import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.fastfood.proccessor.FastFoodMenuItemProcessor;
import com.mwee.android.pos.business.order.view.discount.FastMultiDiscountCallBack;

/**
 * Created by qinwei on 2017/11/15.
 */

public class FastFoodMenuItemAirProcessor extends FastFoodMenuItemProcessor {
    public FastFoodMenuItemAirProcessor(Host host) {
        super(host);
    }

    @Override
    public void doMenuItemsDiscount(final FastFoodDishCache dishCache, final FastMultiDiscountCallBack callBack) {
        // 该Fragment已删除
//        final Progress progress = ProgressManager.showProgress(mHost);
//        final FastDiscountDataProcessor processor = new FastDiscountDataProcessor(dishCache, mHost);
//        ActionLog.addLog("获取所有折扣信息", dishCache.getOrderId(), dishCache.fastOrderModel.mealNumber, ActionLog.DF_BATCH_DISCOUNT, "");
//        processor.loadAllDiscounts(dishCache.getOrderId(), dishCache.menuItems, new ResultCallback<String>() {
//            @Override
//            public void onSuccess(String data) {
//                progress.dismiss();
//                processor.initData(dishCache.menuItems, dishCache.fastOrderModel.fsDiscountCutId);
//                FastFoodAirMultiDiscountFragment fragment = new FastFoodAirMultiDiscountFragment();
//                fragment.setParam(processor, callBack);
//                ActionLog.addLog("获取所有折扣信息，打开批量折扣界面", dishCache.getOrderId(), dishCache.fastOrderModel.mealNumber, ActionLog.DF_BATCH_DISCOUNT, "");
//                fragment.show(mHost.getFragmentManagerWithinHost(), "DinnerMultiDiscountFragment");
//            }

//            @Override
//            public void onFailure(int code, String msg) {
//                ToastUtil.showToast(msg);
//                progress.dismiss();
//            }
//        });
    }
}
