package com.mwee.android.pos.air.business.netorder;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.air.business.tshop.THelpActivity;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.bill.view.BillTakeOutFragment;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;

/**
 * @ClassName: AirNetOrderManageFragment
 * @Description: 外卖管理
 * @author: 刘秀秀
 * @date: 2017/10/16
 */
public class AirNetOrderManageFragment extends AirBaseFragment implements View.OnClickListener {

    public static final String TAG = AirNetOrderManageFragment.class.getSimpleName();

    //private TitleBar mTitleBar;

    private TextView meituan_setting_tv, eleme_setting_tv;
    private LinearLayout meituan_bottom_lyt, eleme_bottom_lyt, other_bottom_lyt;

    private AirNetOrderProcessor processor;

    public static AirNetOrderManageFragment newInstance() {
        AirNetOrderManageFragment fragment = new AirNetOrderManageFragment();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.air_netorder_manager_activity, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        processor = new AirNetOrderProcessor();
        assignViews(view);
        initTitle();
    }

    private void assignViews(View convertView) {
        meituan_setting_tv = (TextView) convertView.findViewById(R.id.meituan_setting_tv);
        eleme_setting_tv = (TextView) convertView.findViewById(R.id.eleme_setting_tv);

        meituan_bottom_lyt = (LinearLayout) convertView.findViewById(R.id.meituan_bottom_lyt);
        eleme_bottom_lyt = (LinearLayout) convertView.findViewById(R.id.eleme_bottom_lyt);
        other_bottom_lyt = (LinearLayout) convertView.findViewById(R.id.other_bottom_lyt);

        meituan_setting_tv.setOnClickListener(this);
        eleme_setting_tv.setOnClickListener(this);
        meituan_bottom_lyt.setOnClickListener(this);
        eleme_bottom_lyt.setOnClickListener(this);
        other_bottom_lyt.setOnClickListener(this);

        meituan_bottom_lyt.setSelected(true);

        eleme_bottom_lyt.setSelected(TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_ELEME, "0"), "1"));
        meituan_bottom_lyt.setSelected(TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_MEITUAN, "0"),
                "1"));
        other_bottom_lyt.setSelected(TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_OTHER, "0"), "1"));

        convertView.findViewById(R.id.netorder_history_tv).setOnClickListener(this);

        RelativeLayout wechat_ryt = convertView.findViewById(R.id.wechat_ryt);
        wechat_ryt.setOnClickListener(this);
        if (APPConfig.isAir()) {
            wechat_ryt.setVisibility(View.GONE);
        } else {
            wechat_ryt.setVisibility(View.VISIBLE);
        }

        //mTitleBar = (TitleBar) convertView.findViewById(R.id.title_tv);

    }

    private void initTitle() {
      /*  mTitleBar.setTitle("外卖管理");

        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {

                //BizcenterApi.uploadLocalChangeData(null);
                dismissSelf();
            }
        });*/
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.meituan_setting_tv:
//                PaymentBindView meituanBarcode = new PaymentBindView();
//                meituanBarcode.setOriginUri(processor.optMeituanUrl());
                Intent intent = new Intent(getActivityWithinHost(), THelpActivity.class);
                intent.putExtra(THelpActivity.KEY_WEB_URI, processor.optMeituanUrl());
                intent.putExtra(THelpActivity.KEY_TITLE_CONTENT, "美团外卖");
                startActivity(intent);
//                DialogManager.showCustomDialog(this, meituanBarcode, "meituanBindBarcode");
                break;
            case R.id.eleme_setting_tv:
//                PaymentBindView elemeBarcode = new PaymentBindView();
//                elemeBarcode.setOriginUri(processor.optElemeUrl());
//                DialogManager.showCustomDialog(AirNetOrderManageFragment.this, elemeBarcode, "elemeBindBarcode");
                intent = new Intent(getActivityWithinHost(), THelpActivity.class);
                intent.putExtra(THelpActivity.KEY_WEB_URI, processor.optElemeUrl());
                intent.putExtra(THelpActivity.KEY_TITLE_CONTENT, "饿了么");
                startActivity(intent);
                break;
            case R.id.eleme_bottom_lyt:
                if (!eleme_bottom_lyt.isSelected()) {//打开
                    ActionLog.addLog("更多设置->外卖接单->点击了开启饿了么外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_ELEME, "1");
                } else {// 关闭
                    ActionLog.addLog("更多设置->外卖接单->点击了关闭饿了么外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_ELEME, "0");
                }

                eleme_bottom_lyt.setSelected(!eleme_bottom_lyt.isSelected());
                break;
            case R.id.meituan_bottom_lyt:
                if (!meituan_bottom_lyt.isSelected()) {//打开
                    ActionLog.addLog("更多设置->外卖接单->点击了开启美团外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_MEITUAN, "1");
                } else {// 关闭
                    ActionLog.addLog("更多设置->外卖接单->点击了关闭美团外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_MEITUAN, "0");
                }

                meituan_bottom_lyt.setSelected(!meituan_bottom_lyt.isSelected());
                break;
            case R.id.other_bottom_lyt:
                if (!other_bottom_lyt.isSelected()) {//打开
                    ActionLog.addLog("更多设置->外卖接单->点击开启其他外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_OTHER, "1");
                } else {// 关闭
                    ActionLog.addLog("更多设置->外卖接单->点击了关闭其他外卖单", "", "", ActionLog.SS_MORE_JOIN, "");
                    ClientMetaUtil.updateSettingsValueByKey(META.NET_AUTO_ORDER_OTHER, "0");
                }
                other_bottom_lyt.setSelected(!other_bottom_lyt.isSelected());
                break;
            case R.id.netorder_history_tv:  //外卖平台对接记录
                BillTakeOutFragment billTakeOutFragment = new BillTakeOutFragment();
                FragmentController.addFragment(getActivityWithinHost(), billTakeOutFragment);
                break;
            case R.id.wechat_ryt:  //微信外卖
                AirWechatOrderManageFragment airWechatOrderManageFragment = new AirWechatOrderManageFragment();
                FragmentController.addFragment(getActivityWithinHost(), airWechatOrderManageFragment);
                break;

            default:
                break;
        }
    }
}
