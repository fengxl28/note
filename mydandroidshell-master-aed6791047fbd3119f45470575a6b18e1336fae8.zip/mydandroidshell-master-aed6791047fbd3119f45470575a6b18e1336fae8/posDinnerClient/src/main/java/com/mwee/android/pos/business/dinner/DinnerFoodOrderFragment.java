package com.mwee.android.pos.business.dinner;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.ArrayMap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.drivenbus.exception.DriverBusException;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.IBizProcessor;
import com.mwee.android.pos.business.bonus.BonusUtils;
import com.mwee.android.pos.business.common.dialog.pay.RapidPayMessageProcessor;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.business.dinner.adapter.DinnerFoodOrderAdapter;
import com.mwee.android.pos.business.dinner.api.LockTableApi;
import com.mwee.android.pos.business.dinner.processor.DinnerOrderProcessor;
import com.mwee.android.pos.business.dinner.processor.MenuItemProcessor;
import com.mwee.android.pos.business.dinner.widget.DinnerFoodOrderOperationLayout;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.localpush.NotifyToServer;
import com.mwee.android.pos.business.menu.view.MenuFragment;
import com.mwee.android.pos.business.order.view.batchoperation.BatchOperationJump;
import com.mwee.android.pos.business.order.view.bonus.BonusJumper;
import com.mwee.android.pos.business.order.view.bonus.BonusUserChosenCallBack;
import com.mwee.android.pos.business.order.view.delimit.DelimitView;
import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.business.order.view.discount.DiscountJump;
import com.mwee.android.pos.business.order.view.discount.IBatchOperate;
import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.business.order.widget.ModifyQuantityUtils;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.business.orderdishes.view.jump.JumpFlag;
import com.mwee.android.pos.business.orderdishes.view.widget.OrderDishesTableView;
import com.mwee.android.pos.business.pay.connect.PayDinnerJump;
import com.mwee.android.pos.business.pay.view.component.IPayCallback;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.prepay.PrePayJumper;
import com.mwee.android.pos.business.rapid.api.bean.IgnoreRapidOnlyPayOrderResponse;
import com.mwee.android.pos.business.table.processor.TableBizProcessor;
import com.mwee.android.pos.business.viceshow.ViceShowConnector;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderynamicDMode;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.MenuTerminal;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.DishesUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;
import com.mwee.android.tools.LogUtil;

import java.lang.ref.WeakReference;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Created by qinwei on 2017/4/27.
 *
 * @author qinwei
 */

public class DinnerFoodOrderFragment extends BaseFragment implements IDriver, DinnerFoodOrderAdapter.OnDinnerFoodOrderItemClickListener, IPayCallback, DinnerFoodOrderOperationLayout.OnDinnerFoodOrderOperationClickListener {
    private final static String DRIVER_TAG = "orderDishesView";
    private ListView mDinnerFoodOrderLsv;

    private DinnerOrderProcessor mDinnerOrderProcessor;
    private MenuItemProcessor mMenuItemProcessor;
    private DishCache mDishCache;
    private DinnerFoodOrderAdapter adapter;
    private MenuFragment menuFragment;
    private JumpFlag jumpFlag;
    private DelayQueue<Object> refreshDelayQueue;

    private OrderDishesTableView orderDishesTableView;
    private TextView mDinnerFoodOrderUsernameLabel;//开单人
    private TextView mDinnerFoodOrderNumberLabel;//账单号
    private TextView mDinnerFoodOrderLeftPriceLabel;//待支付金额
    private TextView mDinnerFoodOrderTotalCountLabel;//支付总笔数
    private TextView mDinnerFoodOrderRedHintLabel;//满减信息及超出标准红字提示
    private DinnerFoodOrderOperationLayout mDinnerFoodOrderOperationLayout;
    private View ll_mDinnerFoodOrderLeftPrice;
    private TextView mDinnerFoodOrderAllMenuPriceLabel;

    private boolean isShowAgreeRapid;//是否显示允许秒付拉单支付按钮
    private int msgId;//秒付拉单支付消息id

    public BigDecimal mPrePayAmt = BigDecimal.ZERO;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (mDishCache != null && mDishCache.orderDishesCache != null) {
            AppCache.getInstance().orderingTableID = mDishCache.orderDishesCache.fsmtableid;
            LockTableApi.lockTable(mDishCache.getOrderId(), mDishCache.orderDishesCache.fsmtableid, AppCache.getInstance().userDBModel, AppCache.getInstance().currentHostId, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (!result) {
                        ToastUtil.showToast(info);
                        dismissSelf();
                    } else {
                        if (orderDishesTableView != null && mDishCache.isBindMember() && !mDinnerOrderProcessor.mDishCache.order.memberInfoS.checkInfoEnough()) {
                            orderDishesTableView.queryAndBindMember();
                        }
                    }
                }
            });
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dinner_food_order_dishes, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (mDishCache == null) {
            UIHelp.startMainDinnerActvity(getActivityWithinHost());
            return;
        }
        initView(view);
        initData();
    }

    private void initView(View view) {
        mDinnerFoodOrderOperationLayout = (DinnerFoodOrderOperationLayout) view.findViewById(R.id.mDinnerOrderFooterLayout);
        mDinnerFoodOrderLsv = (ListView) view.findViewById(R.id.mDinnerFoodOrderLsv);

        //订单信息
        mDinnerFoodOrderUsernameLabel = (TextView) view.findViewById(R.id.mDinnerFoodOrderUsernameLabel);
        mDinnerFoodOrderNumberLabel = (TextView) view.findViewById(R.id.mDinnerFoodOrderNumberLabel);
        mDinnerFoodOrderTotalCountLabel = (TextView) view.findViewById(R.id.mDinnerFoodOrderTotalCountLabel);
        mDinnerFoodOrderLeftPriceLabel = (TextView) view.findViewById(R.id.mDinnerFoodOrderLeftPriceLabel);
        mDinnerFoodOrderRedHintLabel = (TextView) view.findViewById(R.id.mDinnerFoodOrderRedHintLabel);
        ll_mDinnerFoodOrderLeftPrice = view.findViewById(R.id.ll_mDinnerFoodOrderLeftPrice);
        mDinnerFoodOrderAllMenuPriceLabel = view.findViewById(R.id.mDinnerFoodOrderAllMenuPriceLabel);

        adapter = new DinnerFoodOrderAdapter(this, mDishCache);
        adapter.setOnDinnerFoodOrderItemClickListener(this);
        mDinnerFoodOrderLsv.setEmptyView(view.findViewById(R.id.mDinnerFoodListViewEmptyLayout));

        mDinnerFoodOrderLsv.setAdapter(adapter);

        /*头布局*/
        orderDishesTableView = (OrderDishesTableView) view.findViewById(R.id.orderDishesTableView);
        orderDishesTableView.setOnOrderDishesTableViewClickListener(new OrderDishesTableView.OnOrderDishesTableViewClickListener() {
            @Override
            public void backToTable() {
                onKeyBack();
            }

            @Override
            public void showPrePay(String tableID, String orderID) {
                PrePayJumper.showPrePay(DinnerFoodOrderFragment.this, tableID, orderID, mDishCache);
            }

            @Override
            public void showBonusUserChosen(String tableID, String orderID) {
                BonusJumper.showBonusUserChosen(DinnerFoodOrderFragment.this, mDishCache, new BonusUserChosenCallBack() {
                    @Override
                    public void onBonusUserChosen(List<MenuItem> menuItems) {
                        if (mDishCache != null) {
                            if (mDishCache.order != null) {
                                BonusUtils.copyBonusInfo(mDishCache.order.originMenuList, menuItems);
                            }
                            if (mDishCache.orderDishesCache != null) {
                                BonusUtils.copyBonusInfo(mDishCache.orderDishesCache.tempSelectedMenuList, menuItems);
                            }
                        }
                    }
                });
            }
        });
        orderDishesTableView.mPrePayAmt = this.mPrePayAmt;
        orderDishesTableView.refreshPrePay();
        mDinnerFoodOrderOperationLayout.setShowAgreeRapidButton(isShowAgreeRapid);
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    private void initData() {
        menuFragment = (MenuFragment) getChildFragmentManager().findFragmentByTag("menufragment");
        String sectionId = "";//计算餐端
        if (mDishCache.order != null) {
            sectionId = mDishCache.order.currentSectionID;
        } else {
            sectionId = mDishCache.orderDishesCache.currentSectionID;
        }
        menuFragment.setParam(mDishCache.tempSelectQuantity, sectionId);
        menuFragment.refreshView();
//        FragmentController.addFragmentWithHide(getChildFragmentManager(), menuFragment, MenuFragment.FRAGMENT_TAG, R.id.menuLayout, false);
        mDinnerOrderProcessor = new DinnerOrderProcessor(this, mDishCache);
        mMenuItemProcessor = new MenuItemProcessor(this, mDishCache);
        mDinnerFoodOrderOperationLayout.initData(mDishCache, this);
        orderDishesTableView.initData(mDinnerOrderProcessor);
        orderDishesTableView.notifyDataChanged();
        refreshOrderUI();

        refreshDelayQueue = new DelayQueue<>("dinnerFoodViceShow");
        refreshDelayQueue.setWorker(new DelayQueueWorker(DinnerFoodOrderFragment.this));
        refreshDelayQueue.setDelay(500);
        adapter.setRefreshViceCallBack(new NormalListener() {
            @Override
            public void callBack() {
                refreshDelayQueue.addTask("dinnerRefresh");
            }
        });

        adapter.notifyDataSetChanged();
        //桌台未开台 并且不是秒点过来的订单 则获取开台菜品
        if (mDishCache.order == null && !mDishCache.orderDishesCache.isRapidTempOrderCache) {
            loadDataFromCenterBiz();
        } else {
            calculateTotalPrice();
        }
    }

    private void refreshOrderUI() {
        //订单信息ui处理
        if (mDishCache.order != null) {
            mDinnerFoodOrderUsernameLabel.setVisibility(View.VISIBLE);
            mDinnerFoodOrderNumberLabel.setVisibility(View.VISIBLE);
            mDinnerFoodOrderUsernameLabel.setText(getString(R.string.order_user_name_label, mDishCache.order.waiterName));
            mDinnerFoodOrderNumberLabel.setText(getString(R.string.order_number_label, mDishCache.order.orderID));
        } else {
            mDinnerFoodOrderUsernameLabel.setVisibility(View.INVISIBLE);
            mDinnerFoodOrderNumberLabel.setVisibility(View.INVISIBLE);
        }
    }

    private void loadDataFromCenterBiz() {
        //初次开台 加入开台预置数据
        RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品中...");
        TableBizProcessor.loadOpenParamMenus(mDishCache.orderDishesCache.fsmareaid, mDishCache.orderDishesCache.personNum, new ResultCallback<List<MenuItem>>() {
            @Override
            public void onSuccess(List<MenuItem> data) {
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品成功", "", data);
//                progress.dismiss();
                if (!isVisible()) {
                    return;
                }
                if (!ListUtil.isEmpty(data) && isFragmentAlive()) {
                    for (MenuItem item : data) {
                        if (item == null || item.menuBiz == null) {
                            continue;
                        }
                        // 开台预点菜默认计入餐标
                        if (mDishCache.orderDishesCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
                            DinnerStandardUtil.placeMenuIntoStandard(item, true);
                        }
                        // 设置菜品的原桌台信息
                        OrderDishesBizUtil.setDishOriginTable(item, mDishCache.orderDishesCache.fsmtableid, mDishCache.orderDishesCache.fsmtablename);
                    }
                    mDishCache.orderDishesCache.tempSelectedMenuList.addAll(data);
                    mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
                    mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
                    mDishCache.initSelectUnitQuantity();
                    adapter.notifyDataChanged(mDishCache);
                }
                calculateTotalPrice();
            }

            @Override
            public void onFailure(int code, String msg) {
                RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "获取预点菜品失败", "code=" + code + ",msg=" + msg);
                ToastUtil.showToast(msg);
            }
        });
    }


    private static class DelayQueueWorker implements IDQWorker {
        private WeakReference<DinnerFoodOrderFragment> reference;

        public DelayQueueWorker(DinnerFoodOrderFragment fragment) {
            this.reference = new WeakReference<DinnerFoodOrderFragment>(fragment);
        }

        @Override
        public void work(Object o) {
            DinnerFoodOrderFragment foodOrderFragment = reference.get();
            if (foodOrderFragment != null) {
                ViceShowConnector.getInstance().sendDinnerMsg(foodOrderFragment.mDishCache);
                foodOrderFragment.refreshDelayQueue.done("dinnerRefresh");
            }
        }
    }

    @Override
    public void onBatchRequestClick() {
        ActionLog.addLog("点菜页->点击批量要求", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_BATCH_REQUEST, "");
        mMenuItemProcessor.doBatchRequest(ListUtil.cloneList(mDishCache.orderDishesCache.tempSelectedMenuList), new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
//                adapter.selectPosition = -1;
                adapter.selectItemUniq = "";
                OrderDishesBizUtil.doTryMergeInnerOrders(mDishCache);
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBatchWaitClick() {
        PermissionsUtil.requestPermissionCommon(this, AppCache.getInstance().userDBModel, Permission.DINNER_bnWaitItem, new PermissionCallback() {
            @Override
            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                if (errCode == 0) {
                    ActionLog.addLog("点菜页->点击批量等叫", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_BATCH_WAIT, "");
                    //等叫处理
                    mDinnerOrderProcessor.doBatchWait(new ResultCallback<String>() {
                        @Override
                        public void onSuccess(String data) {
//                            adapter.selectPosition = -1;
                            adapter.selectItemUniq = "";
                            adapter.notifyDataSetChanged();
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onBatchDiscountClick() {
        if (mDishCache.order != null) {
            ActionLog.addLog("点击批量优惠折扣", mDishCache.order.orderID, mDishCache.getOrderId(), ActionLog.DF_BATCH_DISCOUNT, "");
        }
        DiscountJump.jumpToDiscount(this, mDishCache.order, mDishCache.orderDishesCache, new DinnerMultiDiscountCallBack() {
            @Override
            public void call(OrderCache cache, List<MenuItem> tempList) {
                mDishCache.order = cache;
                if (mDishCache.orderDishesCache != null && !ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList) && !ListUtil.isEmpty(tempList)) {
                    mDishCache.orderDishesCache.tempSelectedMenuList.clear();
                    mDishCache.orderDishesCache.tempSelectedMenuList.addAll(tempList);
                }
                adapter.notifyDataChanged(mDishCache);
                calculateTotalPrice();
            }

            @Override
            public void onFailure(int code, String msg) {

            }
        });
    }

    @Override
    public void onBatchOperationClick() {
        ActionLog.addLog("点击批量菜品操作", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_BATCH_OPERATION, "");
        BatchOperationJump.jumpToBatchOperation(this, mDishCache.order, jumpFlag.jumpFrom, R.id.main_menufragment, new IBatchOperate() {
            @Override
            public void call(OrderCache cache) {
                mDishCache.order = cache;
                mDishCache.initSelectUnitQuantity();//重新计算菜品沽清
                DriverBus.call("menuview/refreshMenu");
                calculateTotalPrice();
                adapter.notifyDataChanged(mDishCache);
            }
        });
    }

    @Override
    public void onOrderMenuCommitClick() {
        if (!AppCache.getInstance().openOrder){
            ToastUtil.showToast("您没有该操作权限,请管理员在后台配置权限.");
            return;
        }

        if (!OrderDishesBizUtil.checkOrderInfo(mDishCache.orderDishesCache)) {
            return;
        }
        StringBuilder menuInfo = new StringBuilder(":");
        for (MenuItem menuItem : mDishCache.orderDishesCache.tempSelectedMenuList) {
            if (menuItem != null) {
                menuInfo.append(menuItem.name).append("(").append(menuItem.itemID).append("),");
            }
        }
        menuInfo.deleteCharAt(menuInfo.length() - 1);
        ActionLog.addLog("点菜页->点击下单" + menuInfo.toString(), mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);

        // 使用餐标时，需提示称重菜/时价菜未修改重量/价格
        if (mDishCache.orderDishesCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0 &&
                DinnerStandardUIUtil.hasEmptyWeightOrAmt(mDishCache.orderDishesCache.tempSelectedMenuList)) {
            DinnerStandardUIUtil.showConfirmWeightOrAmt(this, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    // 计入标准并下单
                    if (result) {
                        toOrder(true);
                    }
                }
            });
        } else {
            toOrder(true);
        }
    }

    /**
     * 去下单（开台下单/加菜下单）
     */
    private void toOrder(boolean isPrinter) {
        if (mDishCache.order == null || mDishCache.order.orderStatus == OrderStatus.CREATED) {
            // 开台下单
            LogUtil.logOnlineDebug("--order--toOrder--开台下单--");
            orderAndOpenTable(isPrinter);
        } else {
            // 加菜下单
            tryOrderToBizCenter(isPrinter);
        }
    }

    /**
     * 触发加菜下单
     */
    private void tryOrderToBizCenter(boolean isPrinter) {
        // 使用了餐标
        LogUtil.logOnlineDebug("--order--开始--tryOrderToBizCenter--isPrinter:"+isPrinter);
        if (mDishCache.orderDishesCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
            // 加菜下单时需提示是否计入餐标
            DinnerStandardUIUtil.showWithinDiningStandard(this, mDishCache.orderDishesCache.tempTotalMenuPrice, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    ActionLog.addLog("点菜页->点击下单（加菜下单），加菜金额：" + mDishCache.orderDishesCache.tempTotalMenuPrice + "加菜是否计入餐标：" + result,
                            mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
                    DinnerStandardUtil.batchPlaceMenuIntoStandard(mDishCache.orderDishesCache.tempSelectedMenuList, result);

                    orderToBizCenter(isPrinter);
                }
            });
        } else {
            orderToBizCenter(isPrinter);
        }
    }

    /**
     * 开台下单
     */
    private void orderAndOpenTable(boolean isPrinter) {
        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), "正在下单...");
        mDinnerOrderProcessor.orderAndOpenTable(isPrinter, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
                progress.dismiss();
                ActionLog.addLog("点菜页->下单成功", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
                mDishCache.order = data;
                LogUtil.logOnlineDebug("--order--下单成功--orderAndOpenTable--");
                nextStep();
            }

            @Override
            public void onFailure(int code, String msg) {
                LogUtil.logOnlineDebug("--order--下单失败--orderAndOpenTable--");
                progress.dismiss();
                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    mDinnerOrderProcessor.showOrderErrMsg(msg);
                } else {
                    ToastUtil.showToast(!TextUtils.isEmpty(msg) ? msg : getString(R.string.dinner_food_order_failure));
                }
                ActionLog.addLog("点菜页->下单失败:" + msg, mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
            }
        });
    }

    /**
     * 加菜下单
     *
     * @param isPrinter 是否打印，补单不打印，传false
     */
    private void orderToBizCenter(boolean isPrinter) {
        LogUtil.logOnlineDebug("--order--发送到业务中心--orderToBizCenter--");
        mDinnerOrderProcessor.orderToCenter(isPrinter, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache orderCache) {
                ActionLog.addLog("点菜页->下单成功", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
                LogUtil.logOnlineDebug("--order--发送到业务中心--成功--orderToBizCenter--");
                if (mDishCache.antiPay) {
                    mDishCache.order = orderCache;
                    mDishCache.clearTempOrderDishesCache();
                    mDishCache.initSelectUnitQuantity();
                    if (mDishCache.order != null) {
                        mDishCache.orderDishesCache.diningStandardAmt = mDishCache.order.diningStandardAmt;
                        mDishCache.orderDishesCache.minStandardAmt = mDishCache.order.minStandardAmt;
                    }
                    mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
                    adapter.notifyDataChanged(mDishCache);
                    processSaveOrderSuccess();
                    LogUtil.logOnlineDebug("table--finish", "----加菜结束----跳转到桌台页面----" + orderCache.orderID + "--------");
                } else {
                    mDishCache.order = orderCache;
                    nextStep();
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                ActionLog.addLog("点菜页->下单失败", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.order);
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onPrinterPreBillClick() {
        PermissionsUtil.requestPermissionCommon(this, AppCache.getInstance().userDBModel, Permission.DINNER_bnPrnExpBill, new PermissionCallback() {
            @Override
            public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                if (errCode == 0) {
                    ActionLog.addLog("点菜页->点击打印预结单", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_PRINTPREINVOICE, "");
                    mDinnerOrderProcessor.printDinnerPreBill();
                }
            }
        });
    }


    @Override
    public void onPayClick() {
        if (!AppCache.getInstance().collectMoney) {
            ToastUtil.showToast(String.format(getString(R.string.waiter_not_has_conllect), AppCache.getInstance().userDBModel.fsUserName));
            return;
        }


        //解决在点菜页及结账页使用扫码枪扫条码时点菜页自动点菜问题
        if (menuFragment != null) {
            menuFragment.moveFocusToOtherView();
        }

        //口碑订单直接结账
        if (DishUtils.isKBPreOrder(mDishCache.order.thirdOrderType)) {
            mDinnerOrderProcessor.doCheckOutForKBOrder(mDishCache.order.orderID, new ResultCallback<String>() {
                @Override
                public void onSuccess(String data) {
                    dismissSelf();
                }

                @Override
                public void onFailure(int code, String msg) {
                    super.onFailure(code, msg);
                    ToastUtil.showToast(msg);
                }
            });
            return;
        }
        ActionLog.addLog("点菜页->点击结账", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_PAY, mDishCache.order);
        mDinnerOrderProcessor.doPay(new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                if (aBoolean) {
                    // 结账时重新计算订单金额
                    mDishCache.order.reCalcAllByAll();
                    if (DishUtils.isKBPreOrder(mDishCache.order.thirdOrderType)) {
                        goPayDinnerFragment();
                    } else {
                        doCheckDishOpenParamError();
                    }
                }
            }
        });
    }

    private void doCheckDishOpenParamError() {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mDinnerOrderProcessor.loadCheckDishOpenParamError(mDishCache.order.orderID, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                goPayDinnerFragment();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                if (code == -10001) {
                    //预制菜品匹配没匹配通过
                    DialogManager.showExecuteDialog(getActivityWithinHost(), msg, new DialogResponseListener() {
                        @Override
                        public void response() {
                            goPayDinnerFragment();
                        }
                    });
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }

    @Override
    public void onOrderReplacementClick() {
        if (!AppCache.getInstance().openOrder){
            ToastUtil.showToast("您没有该操作权限,请管理员在后台配置权限.");
            return;
        }

        ActionLog.addLog("点菜页->点击补单", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, "");
        if (!OrderDishesBizUtil.checkOrderInfo(mDishCache.orderDishesCache)) {
            return;
        }
//        tryOrderToBizCenter(false);//补单不打印
        toOrder(false);//补单不打印
    }

    @Override
    public void onPrinterMenuClick() {
        ActionLog.addLog("点菜页->点击打印点菜预览单", mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_PRINTPREINVOICE, "");
        mDinnerOrderProcessor.printPreMenuList(mDishCache);
    }

    @Override
    public void onRapidAllowClick() {
        new RapidPayMessageProcessor().allowRapidConfirmMessage(msgId, new SocketCallback<IgnoreRapidOnlyPayOrderResponse>() {
            @Override
            public void callback(SocketResponse<IgnoreRapidOnlyPayOrderResponse> response) {
                if (response != null) {
                    if (response.success()) {
                        mDinnerFoodOrderOperationLayout.setShowAgreeRapidButton(false);
                        mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
                    }
                    ToastUtil.showToast(response.message);
                } else {
                    ToastUtil.showToast("业务异常，请重试");
                }
            }
        });
    }

    /**
     * 添加订单备注
     */
    @Override
    public void onOrderNote() {
        mDinnerOrderProcessor.doEditOrderNote();
    }

    /**
     * 跳转收银界面
     */
    private void goPayDinnerFragment() {
        if (mDishCache.antiPay) {
            PayDinnerJump.jumpToRePay(getActivityWithinHost(), mDishCache.order.orderID, R.id.main_menufragment, DinnerFoodOrderFragment.this);
        } else {
            PayDinnerJump.jumpToPay(getActivityWithinHost(), mDishCache.order.orderID, R.id.main_menufragment, DinnerFoodOrderFragment.this);
        }
    }

    /**
     * 下单是否自动登出 是本机设置
     *
     * @param
     */
    private void nextStep() {
        //1=登出回登入界面/ 0,2=回桌台管理 3=停留点菜页面
        String status = SettingHelper.getOrderedOperation();
        if (TextUtils.equals(status,"1")) {
            mDishCache.clearTempOrderDishesCache();
            DriverBus.call(Constants.DRIVER_TAG_LOGOUT);
        } else if(TextUtils.equals(status,"2") || TextUtils.equals(status,"0")){ //桌台页
            LogUtil.logBusiness("table--finish", "----加菜结束--桌台页--跳转到桌台页面------------");
            mDishCache.clearTempOrderDishesCache();
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
        }else{
            //停留点菜页面,刷新数据
            if(mDishCache.orderDishesCache != null && mDishCache.order != null){
                mDishCache.orderDishesCache.diningStandardAmt = mDishCache.order.diningStandardAmt;
                mDishCache.orderDishesCache.minStandardAmt = mDishCache.order.minStandardAmt;
                mDishCache.orderDishesCache.tempSelectedMenuList.clear();
            }
            mDishCache.initSelectUnitQuantity();//计算点菜规格数量
            mDinnerOrderProcessor.setDishCache(mDishCache);
            mMenuItemProcessor.setDishCache(mDishCache);
            mDinnerFoodOrderOperationLayout.initData(mDishCache, this);
            orderDishesTableView.initData(mDinnerOrderProcessor);
            orderDishesTableView.notifyDataChanged();
            refreshOrderUI();
            adapter.notifyDataChanged(mDishCache);
            menuFragment.setSelectCache(mDishCache.tempSelectQuantity);
            getOrderToken(0);
        }
    }

    private void getOrderToken(int retryCount){
        //停留点菜页面模式下，假如4次都获取不到orderToken就强制回到桌台页
        if(retryCount > 3){
            mDishCache.clearTempOrderDishesCache();
            DriverBus.call("main/jump", MAIN_TAB.TABLE);
            return;
        }
        //停留点菜页面模式下，下单后要去生成一个orderToken
        mDinnerOrderProcessor.getOrderToken(mDishCache.getOrderId(), new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
            }
            @Override
            public void onFailure(int code, String msg) {
                getOrderToken(retryCount+1);
                LogUtil.logBusiness("getOrderToken error",msg);
            }
        });
    }

    private void processSaveOrderSuccess() {
        ToastUtil.showToast(mDishCache.antiPay ? getString(R.string.dinner_food_order_menu_add_success) : getString(R.string.dinner_food_order_success));
        try {
            DriverBus.broadcast("notifyall");
        } catch (DriverBusException e) {
            e.printStackTrace();
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/clickone", UIThread = true)
    public void clickone(MenuItem item) {
        if (!DishUtils.isSupportEditor(mDishCache.order)) {
            return;
        }

        if (item.isCategory || OrderDishesBizUtil.isOutOfStock(mDishCache.tempUnitQuantity, item)) {// 菜品沽清判断
            return;
        }

        // 未下单&&使用了餐标时
        if (mDishCache.order == null && mDishCache.orderDishesCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            // 默认计入餐标
            DinnerStandardUtil.placeMenuIntoStandard(item, true);
            // 比较餐标，超出餐标时提示用户，让用户决定菜品是否落到列表
            if (mDishCache.orderDishesCache.checkOutStandard(item).compareTo(BigDecimal.ZERO) > 0) {
                DinnerStandardUIUtil.showOutDiningStandard(this, new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        if (result) {// 计入餐标，加到点菜列表
                            DinnerStandardUtil.placeMenuIntoStandard(item, true);
                            addMenu(item);
                        } else { // 不计入，重新点菜，不加到点菜列表
                            DinnerStandardUtil.placeMenuIntoStandard(item, false);
                        }

                        ActionLog.addLog("点菜页->点菜，超标确认：" + result,
                                mDishCache.getOrderId(), mDishCache.getTableId(), ActionLog.DF_ORDER_COMMIT, mDishCache.orderDishesCache);
                    }
                });
            } else {
                addMenu(item);
            }
        } else {
            addMenu(item);
        }
    }

    /**
     * 点菜
     *
     * @param item 选择的菜品
     */
    private void addMenu(MenuItem item) {
        int currentSeq = -1;
        if (mDishCache.order != null) {
            currentSeq = mDishCache.order.currentSeq;
        }

        // 设置菜品的原桌台信息
        OrderDishesBizUtil.setDishOriginTable(item, mDishCache.orderDishesCache.fsmtableid, mDishCache.orderDishesCache.fsmtablename);

        item.init(currentSeq, mDishCache.isBindMember());//设置点菜单序
        MenuItem mergeMenuItem = OrderDishesBizUtil.findMergeMenuItem(mDishCache.orderDishesCache.tempSelectedMenuList, item);
        if (mergeMenuItem != null) {
            mergeMenuItem.terminal_id = MenuTerminal.DINNER;
            mDishCache.mergeOrderMenuItem(mergeMenuItem, item);//更新dishCache里面缓存数据
            adapter.selectItemUniq = mergeMenuItem.menuBiz.uniq;
        } else {
//            adapter.selectPosition = 0;
            adapter.selectItemUniq = item.menuBiz.uniq;
            item.terminal_id = MenuTerminal.DINNER;
            mDishCache.addDinnerMenuItem(item);
        }
        calculateTotalPrice();
        DriverBus.call("menuview/notifyone", item);
        adapter.notifyDataChanged(mDishCache);
        mDinnerFoodOrderLsv.smoothScrollToPosition(adapter.getItemPosition());
        mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
        orderDishesTableView.refreshBonusUserBtn();
    }

    /**
     * 刷新笔数与总价
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshInfo", UIThread = true)
    public void calculateTotalPrice() {
        if (isAdded()) {
            // FIXME: 2017/6/22 总价格计算方法
            mDishCache.orderDishesCache.plusTempSelectedMenuAmount();
            if (mDishCache.order == null) {
//            mDinnerFoodOrderLeftPriceLabel.setText(new StringBuilder().append(getString(R.string.pay_left_price_label)).append(Calc.formatShow(mDishCache.orderDishesCache.tempTotalPrice, RoundConfig.ROUND_TOTAL)));
                ll_mDinnerFoodOrderLeftPrice.setVisibility(View.INVISIBLE);
                mDinnerFoodOrderAllMenuPriceLabel.setText(Calc.formatShow(mDishCache.orderDishesCache.tempTotalPrice, RoundConfig.ROUND_TOTAL));
                mDinnerFoodOrderTotalCountLabel.setText(getString(R.string.order_menu_total_size, mDishCache.orderDishesCache.tempSelectedMenuList.size(), mDishCache.orderDishesCache.tempTotalCount.intValue()));
                // 超出标准金额
                BigDecimal outAmt = mDishCache.orderDishesCache.checkOutStandard(null);
                if (outAmt.compareTo(BigDecimal.ZERO) > 0) {
                    mDinnerFoodOrderRedHintLabel.setText("超出标准" + outAmt.toPlainString());
                } else {
                    mDinnerFoodOrderRedHintLabel.setText("");
                }
                return;
            }
            refreshOrderInfo();
        }
    }

    public void refreshOrderInfo() {
        if (getHost() == null) {//解决 not attached to Activity 异常
            return;
        }
        ll_mDinnerFoodOrderLeftPrice.setVisibility(View.VISIBLE);
        if (!ListUtil.listIsEmpty(mDishCache.order.originMenuList)) {
            BigDecimal cut = BigDecimal.ZERO;
            String discountInfo = "";
            if (mDishCache.order.couponCut != null && mDishCache.order.couponCut.fdCutmoney.compareTo(BigDecimal.ZERO) > 0) {
                cut = mDishCache.order.couponCut.fdCutmoney;
                discountInfo = mDishCache.order.couponCut.fsBargainName + "：-" + cut.toString();
            }
            if (!DishUtils.isSupportRound(mDishCache.order)) {
//                mDinnerFoodOrderLeftPriceLabel.setText(new StringBuilder().append(getString(R.string.pay_left_price_label)).append(Calc.formatShow(mDishCache.order.optTotalMenuPrice().subtract(cut))));
                mDinnerFoodOrderLeftPriceLabel.setText(Calc.formatShow(DinnerStandardUtil.optLeftPriceWhenUseStandard(mDishCache.order).subtract(cut)));
            } else {
//                mDinnerFoodOrderLeftPriceLabel.setText(new StringBuilder().append(getString(R.string.pay_left_price_label)).append(Calc.formatShow(mDishCache.order.optTotalMenuPrice().subtract(cut), RoundConfig.ROUND_TOTAL)));
                mDinnerFoodOrderLeftPriceLabel.setText(Calc.formatShow(DinnerStandardUtil.optLeftPriceWhenUseStandard(mDishCache.order).subtract(cut), RoundConfig.ROUND_TOTAL));
            }
            mDinnerFoodOrderAllMenuPriceLabel.setText(Calc.formatShow(mDishCache.orderDishesCache.tempTotalPrice.add(mDishCache.order.optTotalMenuPrice()), RoundConfig.ROUND_TOTAL));
            //菜品真实数=菜品总数量-退的份数
            int realCount = mDishCache.order.totalCount.subtract(DishesUtil.getVoidNum(mDishCache.order)).intValue();
            mDinnerFoodOrderTotalCountLabel.setText(String.format(getString(R.string.order_menu_total_size), mDishCache.order.optMenuCount(), realCount));
            mDinnerFoodOrderUsernameLabel.setText(getString(R.string.order_user_name_label, mDishCache.order.waiterName));
            mDinnerFoodOrderNumberLabel.setText(getString(R.string.order_number_label, mDishCache.order.orderID));
            refreshOrderRedHint(discountInfo);
        }
    }

    /**
     * 刷新订单满减信息及超出标准金额
     *
     * @param discount 折扣信息，"满70减30"
     */
    private void refreshOrderRedHint(String discount) {
        if (mDishCache.order == null) {
            return;
        }
        StringBuilder showText = new StringBuilder();
        if (!TextUtils.isEmpty(discount)) {
            showText.append(discount).append(";");
        }
        // 超出标准金额
        BigDecimal outerAmt = BigDecimal.ZERO;
        if (mDishCache.order.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
            outerAmt = mDishCache.order.diningStandardMenusAmt.subtract(mDishCache.order.diningStandardAmt);
            if (outerAmt != null && outerAmt.compareTo(BigDecimal.ZERO) > 0) {
                showText.append("超出标准").append(outerAmt.toPlainString());
            }
        }
        mDinnerFoodOrderRedHintLabel.setText(showText.toString());
    }

    private void setText(TextView textView, String totalNumber, String discount) {
        SpannableString sp = new SpannableString(totalNumber + discount);
        if (mDinnerOrderProcessor.mHost != null) {
            Context context = mDinnerOrderProcessor.mHost.getContextWithinHost();
            if (context != null) {
                sp.setSpan(new TextAppearanceSpan(context, R.style.order_total_size), 0, totalNumber.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sp.setSpan(new TextAppearanceSpan(context, R.style.order_discount_font), totalNumber.length(), sp.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                textView.setText(sp);
            }
        }
    }

    /**
     * 改未下单称重菜重量
     *
     * @param item
     * @param userDBModel
     */
    @Override
    public void doChangeMenuBuyNum(final MenuItem item, UserDBModel userDBModel) {
        if (item == null) {
            return;
        }
        ModifyQuantityUtils.showModifyQuantitySupportWeight(this, item, new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                if (newNum.compareTo(BigDecimal.ZERO) < 1 || originNum.compareTo(newNum) == 0) {
                    return;
                }
                //沽清判断
                if (OrderDishesBizUtil.isOutOfStock(mDishCache.tempUnitQuantity, item, newNum)) {
                    return;
                }
                //删除已使用买减优惠的菜品，需要清除其他联动菜品的买减信息
                if (item.menuBiz.bugGiftItem != null) {
                    item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundingMode.HALF_UP));
                    //重新计算价格
                    item.calcTotal(mDishCache.orderDishesCache.isMember);

                    final Progress progress = ProgressManager.showProgressUncancel(DinnerFoodOrderFragment.this, R.string.message_please_wait);
                    mMenuItemProcessor.doCleanGiftBuyInfoByOne(item, new DinnerMultiDiscountCallBack() {
                        @Override
                        public void call(OrderCache cache, List<MenuItem> tempList) {
                            progress.dismissSelf();
                            mDishCache.order = cache;
                            if (mDishCache.orderDishesCache != null && !ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList) && !ListUtil.isEmpty(tempList)) {
                                mDishCache.orderDishesCache.tempSelectedMenuList.clear();
                                mDishCache.orderDishesCache.tempSelectedMenuList.addAll(tempList);
                            }
                            adapter.notifyDataChanged(mDishCache);
                            calculateTotalPrice();
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            progress.dismissSelf();
                            ToastUtil.showToast(msg);
                        }
                    });
                } else {
                    item.updateBuyNum(Calc.format(newNum, RoundConfig.ROUND_QUANTITY_3, RoundingMode.HALF_UP));
                    //重新计算价格
                    item.calcTotal(mDishCache.orderDishesCache.isMember);
                    //更新DishCache缓存信息
                    mDishCache.initSelectUnitQuantity();
                    adapter.notifyDataSetChanged();
                    DriverBus.broadcast("notifyall");
                    calculateTotalPrice();
                }
            }
        });
    }

    /**
     * 改已下单称重菜重量
     *
     * @param item
     * @param userDBModel
     */
    @Override
    public void doChangeOrderedMenuNumber(final MenuItem item, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateMenuItemBuyNumber(item, mDishCache.order, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                adapter.notifyDataSetChanged();
                mDishCache.order.reCalcAllByAll();
                calculateTotalPrice();
                DriverBus.call("menuview/refreshMenu");
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    DriverBus.call("menuview/refreshMenu");
                } else {
                    dismissSelf();
                }
            }
        });
    }

    @Override
    public void doDeleteMenu(MenuItem item) {
        //删除已使用买减优惠的菜品，需要清除其他联动菜品的买减信息
        if (item.menuBiz.bugGiftItem != null) {
            mDishCache.orderDishesCache.tempSelectedMenuList.remove(item);
            final Progress progress = ProgressManager.showProgressUncancel(DinnerFoodOrderFragment.this, R.string.message_please_wait);
            mMenuItemProcessor.doCleanGiftBuyInfoByOne(item, new DinnerMultiDiscountCallBack() {
                @Override
                public void call(OrderCache cache, List<MenuItem> tempList) {
                    progress.dismissSelf();
                    mDishCache.order = cache;
                    if (mDishCache.orderDishesCache != null && !ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList) && !ListUtil.isEmpty(tempList)) {
                        mDishCache.orderDishesCache.tempSelectedMenuList.clear();
                        mDishCache.orderDishesCache.tempSelectedMenuList.addAll(tempList);
                    }
                    adapter.notifyDataChanged(mDishCache);
                    orderDishesTableView.refreshBonusUserBtn();
                    calculateTotalPrice();
                }

                @Override
                public void onFailure(int code, String msg) {
                    progress.dismissSelf();
                    ToastUtil.showToast(msg);
                }
            });
        } else {
            adapter.selectItemUniq = "";
            mDishCache.removeDinnerMenuItem(item);
            adapter.notifyDataChanged(mDishCache);
            orderDishesTableView.refreshBonusUserBtn();
            DriverBus.broadcast("notifyall");
            mDinnerFoodOrderOperationLayout.refreshOperationBtnStatus();
            calculateTotalPrice();
        }
    }

    @Override
    public void doEditorMenuNoteContent(final MenuItem item) {
        mMenuItemProcessor.doEditorMenuNoteContent(item, new NoteCallback() {
            @Override
            public void callBack(List<NoteItemModel> selectedInfo) {
                item.menuBiz.selectNote = selectedInfo;
                item.buildNotesString();
                item.calcTotal(mDishCache.orderDishesCache.isMember);
                adapter.notifyDataSetChanged();
                calculateTotalPrice();
            }
        });
    }

    @Override
    public void doChangeMenuPrivilege(MenuItem item) {
        mMenuItemProcessor.doChangeMenuPrivilege(item, new SingleCouponFragment.OnSingleDiscountListener() {
            @Override
            public void callback(OrderCache orderCache, FastOrderynamicDMode fastOrder, List<MenuItem> menuItemList) {
                mDishCache.order = orderCache;
                adapter.notifyDataChanged(mDishCache);
                calculateTotalPrice();
            }
        });
    }

    /**
     * 修改时价菜的名称
     *
     * @param item
     * @param userDBModel
     */
    @Override
    public void doChangeMenuName(final MenuItem item, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateMenuName(mDishCache.getOrderId(), item, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                item.name = data;
                item.name2 = data;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                dismissSelf();
            }
        });
    }

    /**
     * 修改时价菜
     *
     * @param item
     * @param userDBModel
     */
    @Override
    public void doChangeMenuPrice(final MenuItem item, UserDBModel userDBModel) {
        mMenuItemProcessor.doUpdateDishPrice(mDishCache.getOrderId(), item, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                item.calcTotal(false);
                adapter.notifyDataSetChanged();
                if (mDishCache.order != null) {
                    mDishCache.order.reCalcAllByAll();
                }
                calculateTotalPrice();//刷新总价
                DriverBus.broadcast("notifyall");
            }

            @Override
            public void onFailure(int code, String msg) {
                dismissSelf();
            }
        });
    }


    @Override
    public void doEditMenuInfo(UnitModel oldUnit, BigDecimal oldBuyNum, MenuItem item) {
        if (mMenuItemProcessor.doEditMenuInfo(oldUnit, oldBuyNum, item)) {
            adapter.notifyDataSetChanged();
            calculateTotalPrice();
            DriverBus.broadcast("notifyall");
        }
    }

    @Override
    public void doRetreatDish(final MenuItem item, final UserDBModel userDBModel, final String msg) {
        mMenuItemProcessor.doRetreatDish(mDishCache.getOrderId(), item, msg, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
//                adapter.notifyDataSetChanged();
                mDishCache.order = data;
                mDishCache.initSelectUnitQuantity();
                // adapter 中 item click 使用了菜品引用，需要更新 adapter 数据源
                adapter.notifyDataChanged(mDishCache);
                orderDishesTableView.refreshBonusUserBtn();
                DriverBus.call("menuview/notifyone", item);
                calculateTotalPrice();
            }

            @Override
            public void onFailure(int code, String msg) {
                showSingleDialogTip(msg);
            }
        });
    }

    public void showSingleDialogTip(String tipMsg) {
        DialogManager.showSingleDialog(getActivityWithinHost(), tipMsg);
    }

    @Override
    public void doRemindersDish(final MenuItem item, UserDBModel userDBModel) {
        if (item.menuBiz.fiItemMakeState == 2) {
            return;
        }
        mMenuItemProcessor.loadRemindersDish(mDishCache.order.orderID, item.menuBiz.uniq, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                item.menuBiz.fiHurryTimes++;//更新适配器数据
                calculateTotalPrice();//更新列表ui以及总金额
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void doPaddleDish(MenuItem item, UserDBModel userDBModel) {
        if (item.hasAllVoid()) {
            ToastUtil.showToast("已退菜品不支持划菜");
        }

        // 最大可划菜数量
        BigDecimal max = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
        if (item.supportWeight() && max.compareTo(BigDecimal.ZERO) > 0) {
            max = BigDecimal.ONE;
        }

        // 当前已划菜数量
        BigDecimal current = item.menuBiz.delimitNum;
        if (item.supportWeight() && current.compareTo(BigDecimal.ZERO) > 0) {
            current = BigDecimal.ONE;
        }

        // 默认选择全部
        if (current.compareTo(BigDecimal.ZERO) == 0) {
            current = max;
        }
        DelimitView delimitView = DelimitView.newInstance(max, current);
        delimitView.setOnDishDelimit(new DelimitView.OnDishDelimit() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void confirm(int num) {
                ArrayMap<String, BigDecimal> count = new ArrayMap<>();
                count.put(item.menuBiz.uniq, new BigDecimal(num));
                mMenuItemProcessor.loadPaddleDishV2(mDishCache.order.orderID, count, new ResultCallback<String>() {
                    @Override
                    public void onSuccess(String data) {
                        item.menuBiz.fiMenuProgress = item.menuBiz.fiMenuProgress == 0 ? 1 : 0;
                        item.menuBiz.delimitNum = new BigDecimal(num);
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        ToastUtil.showToast(msg);
                    }
                });
            }

            @Override
            public void cancel() {

            }
        });
        DialogManager.showCustomDialog(DinnerFoodOrderFragment.this, delimitView, DelimitView.TAG);
    }

    @Override
    public void doTurnDish(final MenuItem item, UserDBModel userDBModel) {
        mDinnerOrderProcessor.doTurnDish(item, new IResponse<OrderCache>() {
            @Override
            public void callBack(boolean result, int code, String msg, OrderCache info) {
                if (result) {
                    // TransferDishProcessor已完成转菜的逻辑
//                    adapter.selectPosition = -1;
                    adapter.selectItemUniq = "";
                    mDishCache.order = info;
                    adapter.notifyDataChanged(mDishCache);
                    //转菜后重新计算已选数量
                    mDishCache.initSelectUnitQuantity();
                    DriverBus.call("menuview/notifyone", item);
                    calculateTotalPrice();
                } else {
                    if (!TextUtils.isEmpty(msg)) {
                        ToastUtil.showToast(msg);
                    }
                }
            }
        });
    }

    @Override
    public void doWaitCallUp(final MenuItem menuItem, UserDBModel userDBModel) {
        mMenuItemProcessor.loadDoDish(mDishCache.order.orderID, menuItem.menuBiz.uniq, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                menuItem.waitOrCall(3);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 修改配料菜
     *
     * @param menuItem
     * @param newMenuItem
     */
    @Override
    public void doChangeIngredient(final MenuItem menuItem, final MenuItem newMenuItem) {
        mMenuItemProcessor.doChangeIngredient(mDishCache.order.orderID, menuItem, newMenuItem, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
                mDishCache.order = data;
                adapter.notifyDataChanged(mDishCache);
                calculateTotalPrice();
            }

            @Override
            public void onFailure(int code, String msg) {
//                dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 修改套餐子项
     *
     * @param menuItem    修改前套餐
     * @param newMenuItem 修改后套餐
     */
    @Override
    public void doChangePackageItems(final MenuItem menuItem, final MenuItem newMenuItem, PackageItemEditViewBean otherData) {
        mMenuItemProcessor.doChangePackageItems(mDishCache.order.orderID, menuItem, newMenuItem, otherData, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
                mDishCache.order = data;
                adapter.notifyDataChanged(mDishCache);
                calculateTotalPrice();
            }

            @Override
            public void onFailure(int code, String msg) {
//                dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onPackageMenuChanged(MenuItem menuItem) {
        calculateTotalPrice();
    }

    public void setParam(DishCache dishCache, JumpFlag jumpFlag) {
        setParam(dishCache, false, 0, jumpFlag);
    }

    /**
     * 点菜需要的数据
     *
     * @param dishCache        点菜缓存
     * @param isShowAgreeRapid 是否显示允许秒付拉单
     * @param jumpFlag         跳转标记
     */
    public void setParam(DishCache dishCache, boolean isShowAgreeRapid, int msgId, JumpFlag jumpFlag) {
        this.jumpFlag = jumpFlag;//跳转来源
        this.mDishCache = dishCache;
        this.isShowAgreeRapid = isShowAgreeRapid;
        this.msgId = msgId;
        OrderDishesBizUtil.fillOriginTable(mDishCache);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @Override
    public void onDetach() {
        NotifyToServer.sendExcuteMsg("table/unlockTableByHost", AppCache.getInstance().currentHostId);
        AppCache.getInstance().orderingTableID = "";
        super.onDetach();
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loginInMember", UIThread = true)
    public void loginMember(OrderCache orderCache) {
        if (mDishCache.order == null) {
            return;
        }
        mDishCache.order = orderCache;
        refreshOrderInfo();
        adapter.notifyDataChanged(mDishCache);
    }

    /**
     * 当会员退出时,清空菜品中会员相关的设置
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loginOutMember", UIThread = true)
    public void clearMemberInfo() {
        if (mDishCache.order == null) {
            return;
        }
        refreshOrderInfo();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void payFinish(int result) {
        switch (result) {
            case IPayCallback.FINISH:
                DriverBus.call("main/jump", MAIN_TAB.TABLE);
                LogUtil.logBusiness("table--finish", "----支付清台结束----跳转到桌台页面----");
                break;
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/notifyall", UIThread = true)
    public void a() {
        //换桌
        calculateTotalPrice();
        adapter.notifyDataChanged(mDishCache);
        DriverBus.call("menuview/notifyall");
    }

    @DrivenMethod(uri = DRIVER_TAG + "/exist", UIThread = true)
    public void exist() {
        //收到被踢出的通知
        DriverBus.call("main/jump", MAIN_TAB.TABLE);
    }

    /**
     * 预付金收款，刷新页面
     */
    @DrivenMethod(uri = DRIVER_TAG + "/paypre", UIThread = true)
    public void paypre(BigDecimal amt) {
        refreshOrderUI();
        mPrePayAmt = amt;
        orderDishesTableView.mPrePayAmt = mPrePayAmt;
        orderDishesTableView.refreshPrePay();
    }

    @Override
    public IBizProcessor getBizProcessor() {
        return mDinnerOrderProcessor;
    }

    @Override
    public boolean onKeyBack() {
        if (mDishCache.orderDishesCache.tempSelectedMenuList.size() > 0) {
            DialogManager.showExecuteDialog(getActivityWithinHost(), R.string.dinner_food_order_back_msg, getString(R.string.cacel), getString(R.string.confirm), new DialogResponseListener() {
                @Override
                public void response() {
                    dismissSelf();
                }
            }, null);
        } else {
            dismissSelf();
        }
        return true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (refreshDelayQueue != null) {
            refreshDelayQueue.callDestroy();
        }
        ViceShowConnector.getInstance().clearOrderInfo();
    }
}
