package com.mwee.android.pos.air.db;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.HelpCodeUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2017/11/25.
 */

public class DTOMenuItemDBController {
    public static void update(final MenuItemBean bean) {
        //同步修改client数据库  解决套餐数据是从Client db中取 实时套餐明细刷新数据
        DBManager.getInstance(APPConfig.DB_CLIENT).executeInTransactionWithOutThread(new IDBOperate<String>() {
            @Override
            public String doJob(SQLiteDatabase database) {
                ContentValues unit = new ContentValues();
                unit.put("fdSalePrice", bean.fdSalePrice.toPlainString());
                unit.put("fdVIPPrice", bean.fdVIPPrice.toPlainString());
                unit.put("fsOrderUint", bean.fsOrderUint);
                database.update("tbmenuitemuint", unit, "fiOrderUintCd=?", new String[]{bean.fiOrderUintCd + ""});
                ContentValues menuitem = new ContentValues();
                menuitem.put("fsItemName", bean.fsItemName);

                menuitem.put("fiIsDiscount", bean.fiIsDiscount);
                menuitem.put("fiIsGift", bean.fiIsGift);
                menuitem.put("fiIsEditPrice", bean.fiIsEditPrice);
                menuitem.put("fiIsEditQty", bean.fiIsEditQty);
                menuitem.put("fiIsTakeAway", bean.fiIsTakeAway);
                menuitem.put("fiIsPrn", bean.fiIsPrn);

                menuitem.put("fsHelpCode", HelpCodeUtil.createHelpCode(bean.fsItemName));
                database.update("tbmenuitem", menuitem, "fiItemCd=?", new String[]{bean.fiItemCd});
                return "";
            }
        });
        String checkPackageIsExistMenuItemSql = "select count(*) from tbMenuItemSetSideDtl where fiStatus=1  and fiItemCd='" + bean.fiItemCd + "'";
        String count = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, checkPackageIsExistMenuItemSql);
        if (StringUtil.toInt(count, 0) > 0) {
//            刷新套餐cache
            AppCache.getInstance().refreshMenuPackages();
        }
    }
}
