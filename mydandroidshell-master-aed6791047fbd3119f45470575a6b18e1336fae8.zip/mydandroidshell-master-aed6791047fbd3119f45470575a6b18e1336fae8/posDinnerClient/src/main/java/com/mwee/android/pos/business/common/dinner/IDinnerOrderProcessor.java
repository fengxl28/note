package com.mwee.android.pos.business.common.dinner;

import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;

/**
 * Created by qinwei on 2017/9/22.
 *
 * @author qinwei
 */

public interface IDinnerOrderProcessor {
    void showOrderErrMsg(String message);

    /**
     * 批量等叫
     *
     * @param callback
     */
    void doBatchWait(final ResultCallback<String> callback);

    void orderAndOpenTable(boolean isPrinter, ResultCallback<OrderCache> callback);

    /**
     * 下单到业务中心
     *
     * @param isPrinter
     * @param callback
     */
    void orderToCenter(boolean isPrinter, final ResultCallback<OrderCache> callback);

    /**
     * 转菜处理
     *
     * @param item
     * @param iResponse
     */
    void doTurnDish(MenuItem item, IResponse<OrderCache> iResponse);

    /**
     * 结帐预处理
     *
     * @param callback
     */
    void doPay(final SyncCallback<Boolean> callback);


    /**
     * 打印预结单
     */
    void printDinnerPreBill();

    /**
     * 打印点菜预览单
     *
     * @param dishCache
     */
    void printPreMenuList(DishCache dishCache);

    /**
     * 检查预点菜品
     *
     * @param orderID
     * @param callback
     */
    void loadCheckDishOpenParamError(String orderID, ResultCallback<String> callback);

    void unBindMemberInfoFromOrder(String orderId, String cardNo, ResultCallback<ChangeOrderWithMemberResponse> callback);

    void doEditOrderNote();

    void doCheckOutForKBOrder(String orderID, ResultCallback<String> callback);
}
