package com.mwee.android.pos.business.common.fastfood;

import com.mwee.android.pos.business.order.view.discount.SingleCouponFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.order.view.discount.FastMultiDiscountCallBack;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.business.common.entity.PackageItemEditViewBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/9/22.
 */

public interface IFastFoodMenuItemProcessor {

    /**
     * 添加
     *
     * @param orderId  订单id
     * @param menuItem
     * @param callback
     */
    void doAddMenuItem(String orderId, MenuItem menuItem, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback);

    /**
     * 更新单个菜品
     *
     * @param orderId  订单id
     * @param menuItem
     * @param callback
     */
    void doUpdateMenuItem(String orderId, MenuItem menuItem, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback);

    /**
     * 批量更新菜品
     *
     * @param orderId   订单id
     * @param menuItems
     * @param callback
     */
    void doUpdateMenuItem(String orderId, ArrayList<MenuItem> menuItems, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback);

    /**
     * 删除
     *
     * @param orderId  订单id
     * @param uniq
     * @param callback
     */
    void doDeleteMenuItem(String orderId, String uniq, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback);

    /**
     * 通知业务中删除未下单到菜品
     *
     * @param orderId  订单id
     * @param callback
     */
    void doClearOrderMenuItems(String orderId, ResultCallback<ChangeFastFoodMenuItemsResponse> callback);

    /**
     * 菜品改数量处理
     *
     * @param menuItem
     * @param orderId
     * @param callback
     */
    void doUpdateMenuItemBuyNumber(final MenuItem menuItem, final String orderId, final ResultCallback<UpdateBuyNumResponse> callback);

    /**
     * 改时价菜
     *
     * @param orderId  订单id
     * @param menuItem 菜品
     * @param callback 回调
     */
    void doUpdateDishPrice(final String orderId, final MenuItem menuItem, final boolean isUpdateBizCenter, final ResultCallback<OperateDishToCenterResponse> callback);

    /**
     * 退菜业务逻辑
     *
     * @param orderId  订单id
     * @param item     退菜菜品
     * @param reason   退菜理由
     * @param callback
     */
    void doRetreatDish(final String orderId, final MenuItem item, final String reason, final ResultCallback<BactchReturnDishesForFastFoodResponse> callback);

    /**
     * 单个菜品优惠处理
     *
     * @param item
     * @param listener
     */
    void doChangeMenuPrivilege(final MenuItem item, final FastFoodDishCache dishCache, final SingleCouponFragment.OnSingleDiscountListener listener);

    /**
     * 单个菜品要求处理
     *
     * @param item
     * @param noteCallback
     */
    void doEditorMenuNoteContent(MenuItem item, NoteCallback noteCallback);

    /**
     * 批量要求
     *
     * @param callback
     */
    void doBatchRequest(List<MenuItem> reqMenuItems, final FastFoodDishCache mDishCache, final ResultCallback<String> callback);

    /**
     * 菜品编辑数据处理
     *
     * @param oldUnit
     * @param item
     */
    boolean doEditMenuInfo(UnitModel oldUnit, MenuItem item, FastFoodDishCache mDishCache);

    /**
     * 加退配料菜
     *
     * @param orderId  订单id
     * @param oldItem  修改之前菜品
     * @param newItem  修改之后菜品
     * @param callback call from main Thread
     */
    void doChangeIngredient(String orderId, MenuItem oldItem, MenuItem newItem, final ResultCallback<ChangeIngredientResponse> callback);

    /**
     * 加、退套餐子项
     *
     * @param orderId  订单id
     * @param oldItem  修改前的套餐
     * @param newItem  修改后的套餐
     * @param callback
     */
    void doChangePackageItems(String orderId, MenuItem oldItem, MenuItem newItem, PackageItemEditViewBean otherData, final ResultCallback<ChangePackageItemsResponse> callback);

    /**
     * 修改菜品名称
     *
     * @param menuItem
     * @param callback
     */
    void doUpdateMenuName(MenuItem menuItem, ResultCallback<String> callback);

    /**
     * 单个菜品优惠
     */
    void doMenuItemDiscount();

    /**
     * 批量菜品优惠
     */
    void doMenuItemsDiscount(final FastFoodDishCache dishCache, final FastMultiDiscountCallBack callBack);
}
