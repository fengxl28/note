package com.mwee.android.pos.air.business.discount.api;

import com.mwee.android.air.acon.CDiscountManager;
import com.mwee.android.air.connect.business.discount.GetAllDiscountManagerInfoResponse;
import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class DiscountManagerApi {

    public static void optAllDiscount(final IResponse<List<DiscountManagerInfo>> iResult) {

        MCon.c(CDiscountManager.class, new SocketCallback<GetAllDiscountManagerInfoResponse>() {
            @Override
            public void callback(SocketResponse<GetAllDiscountManagerInfoResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data.discountManagerInfoArrayList);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).optAllDiscount();
    }

    /**
     * 新增折扣
     *
     * @param discountManagerInfo
     * @param iResult
     */
    public static void addDiscount(DiscountManagerInfo discountManagerInfo, final IResponse<List<DiscountManagerInfo>> iResult) {

        MCon.c(CDiscountManager.class, new SocketCallback<GetAllDiscountManagerInfoResponse>() {
            @Override
            public void callback(SocketResponse<GetAllDiscountManagerInfoResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data.discountManagerInfoArrayList);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addDiscount(discountManagerInfo);
    }

    /**
     * 修改优惠
     *
     * @param discountManagerInfo
     * @param iResult
     */
    public static void updateDiscount(DiscountManagerInfo discountManagerInfo, final IResponse<List<DiscountManagerInfo>> iResult) {

        MCon.c(CDiscountManager.class, new SocketCallback<GetAllDiscountManagerInfoResponse>() {
            @Override
            public void callback(SocketResponse<GetAllDiscountManagerInfoResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data.discountManagerInfoArrayList);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updateDiscount(discountManagerInfo);
    }

    /**
     * 批量删除桌台
     *
     * @param tableIdList
     * @param iResult
     */
    public static void batchDeleteTable(ArrayList<String> tableIdList, final IResponse<List<DiscountManagerInfo>> iResult) {

        MCon.c(CDiscountManager.class, new SocketCallback<GetAllDiscountManagerInfoResponse>() {
            @Override
            public void callback(SocketResponse<GetAllDiscountManagerInfoResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data.discountManagerInfoArrayList);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).batchDeleteDiscount(tableIdList);
    }
}
