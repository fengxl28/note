package com.mwee.android.pos.business.bill.view;

import com.mwee.android.pos.connect.business.pay.GetPaySessionResponse;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CTable;

/**
 * Created by liuxiuxiu on 2017/5/20.
 */

public class BillConnectServiceUtil {

    /**
     * 生成一个账单号
     *
     * @param callback SocketCallback<GetNumOrderIDResponse>
     */
    public static void sendGetPaySession(String orderiD, SocketCallback<GetPaySessionResponse> callback) {
        MCon.c(CTable.class, callback).sendGetPaySession(orderiD, true, false, 0, null);
    }
}
