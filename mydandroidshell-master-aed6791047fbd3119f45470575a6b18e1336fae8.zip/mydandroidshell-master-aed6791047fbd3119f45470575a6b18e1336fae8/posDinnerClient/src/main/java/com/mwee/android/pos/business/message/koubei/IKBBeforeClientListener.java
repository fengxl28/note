package com.mwee.android.pos.business.message.koubei;

import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDinnerResponse;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/5/24.
 */

public interface IKBBeforeClientListener {


    /**
     * 拉取先付款订单详情
     *
     * @param pageNo
     * @param searchParam
     * @param queryType
     * @param resultCallback
     */
    void loadOrderList(int pageNo, String searchParam, int queryType, String status, ResultCallback<KPreTempDataResponse> resultCallback);

    /**
     * 根据订单号拉取订单
     *
     * @param order_Id
     * @param
     */
    void loadOrder(String order_Id, String merchantPid, ResultCallback<KPreOrderDataResponse> resultCallback);


    /**
     * 获取到口碑预点单正餐 预点单桌台信息
     *
     * @param
     */
    void loadTempDinnerReminder(ResultCallback<KPreTempDinnerResponse> resultCallback);


    /**
     * 拉取订单头信息
     */
    //void loadTempOrderHeader(int pageNo, String searchParam, Integer queryType, ResultCallback<KPreTempDataResponse> resultCallback);


    /**
     * 接单
     *
     * @param order_id
     * @param resultCallback
     */
    void doPrinter(String order_id, ResultCallback<BaseSocketResponse> resultCallback);


    /**
     * 接单
     *
     * @param order_id
     * @param resultCallback
     */
    void acceptOrder(String order_id, String merchantPid, ResultCallback<KBPreOrderUpdateResponse> resultCallback);


    /**
     * 拒单
     *
     * @param order_id
     * @param merchantPid
     * @param reason
     * @param resultCallback
     */
    void rejectOrder(String order_id, String merchantPid, String reason, ResultCallback<KBPreOrderUpdateResponse> resultCallback);


    //备餐
    void prepareOrder(String order_id, String merchantPid, ResultCallback<KBPreOrderUpdateResponse> resultCallback);


    //退款
    void refundOrder(String order_id, String merchantPid, String fsSellNo, String reason, String refundAmount, ArrayList<MenuItem> choiceRefundMenuList, ResultCallback<KBPreOrderUpdateResponse> resultCallback);

    /**
     * C端用户发起退款  商户拒绝退款
     */
    void rejectRefundOrder(String order_id, String merchantPid, String fsSellNo, String rejectReason, ResultCallback<KBPreOrderUpdateResponse> resultCallback);

    /**
     * C端用户发起退款 商户同意退款
     */
    void agreenRefundOrder(String order_id, String merchantPid, String fsSellNo, String agreeRefundReason, ResultCallback<KBPreOrderUpdateResponse> resultCallback);


    /**
     * 分配桌台
     */
    void allocationTable(KBPreOrderCache orderCache, boolean printMake, ResultCallback<KBPreOrderUpdateResponse> resultCallback);

    /**
     * 扫码核销取餐
     *
     * @param verify_order_id 用户核销码中的核销数值串
     * @param callback
     */
    void verifyOrder(String verify_order_id, ResultCallback<KBPreOrderUpdateResponse> callback);


    void showVerifyDialog(ResultCallback<String> callback);

}
