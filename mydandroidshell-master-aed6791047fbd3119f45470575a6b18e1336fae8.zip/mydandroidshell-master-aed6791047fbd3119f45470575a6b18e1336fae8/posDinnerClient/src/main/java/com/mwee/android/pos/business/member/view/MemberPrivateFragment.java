package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.recycler.CommonRecycleAdapter;
import com.mwee.android.pos.component.recycler.ViewHolder;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * MemberPrivateFragment
 *
 * @author ZM
 * @date 17/2/20
 */
public class MemberPrivateFragment extends BaseFragment {

    private static final String KEY_MEMBER_INFO = "key_private_member_info";


//    private MemberCardModel memberCardModel;
    private NewMemberCardDetailsModel memberCardModel;

    /**
     * 会员特权
     */
//    public List<MemberPrivateModel> datas = new ArrayList<>();//展示的会员特权

    private CommonRecycleAdapter<MemberPrivateDetailModel.CardPrivilege> commonRecycleAdapter;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_member_private_layout, container, false);
//        memberCardModel = (MemberCardModel) getArguments().getSerializable(KEY_MEMBER_INFO);

        initAdapter(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        /*List<MemberPrivateModel> models = MemberPrivateProcess.buildSolidMemberPrivateD(memberCardModel.member_private);
        memberCardModel = (MemberCardModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        if (memberCardModel != null && memberCardModel.member_private.size() > 0) {
            datas.addAll(memberCardModel.member_private);
        }
        datas.addAll(0, models);
        commonRecycleAdapter.setData(datas);*/

        initData();
    }

    private void initData(){
        memberCardModel = (NewMemberCardDetailsModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        if(memberCardModel == null){
            return;
        }
        Progress progress = ProgressManager.showProgress(this);
        ClientMemberApi.queryMemberPrivate(""+memberCardModel.cardInfo.cs_id, memberCardModel.cardInfo.level,memberCardModel.cardInfo.card_no, new SocketCallback<MemberPrivateDetailModel>() {
            @Override
            public void callback(SocketResponse<MemberPrivateDetailModel> response) {
                progress.dismiss();
                List<MemberPrivateDetailModel.CardPrivilege> data = MemberPrivateProcess.creatDefaultData();
                if(response == null){
                    ToastUtil.showToast("网络超时，请稍后重试");
                    commonRecycleAdapter.setData(data);
                    return;
                }
                if(response.success() && response.data != null){
                    if(!ListUtil.isEmpty(response.data.plusCardPrivilege)){
                        data.addAll(response.data.plusCardPrivilege);
                    }
                    if(!ListUtil.isEmpty(response.data.cardPrivilege)){
                        data.addAll(response.data.cardPrivilege);
                    }
                }else{
                    ToastUtil.showToast(response.message);
                }
                commonRecycleAdapter.setData(data);
            }
        });
    }

    private void initAdapter(View view) {
        commonRecycleAdapter = new CommonRecycleAdapter<MemberPrivateDetailModel.CardPrivilege>(getActivityWithinHost(), R.layout.fragment_member_privilege_item) {
            @Override
            public boolean onItemClick(View view, MemberPrivateDetailModel.CardPrivilege data, int position) {
                onClickMemberPrivate(data);
                return false;
            }

            @Override
            public void onBind(ViewHolder holder, MemberPrivateDetailModel.CardPrivilege memberPrivateModel, int position) {

                holder.getView(R.id.tv_privilege_directions).setVisibility(memberPrivateModel.priv_type == 1 ? View.VISIBLE : View.GONE);
                holder.setText(R.id.tv_privilege_name, memberPrivateModel.title);
                holder.setText(R.id.tv_privilege_directions, memberPrivateModel.directions);

            }
        };
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.lv_member_private);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContextWithinHost()));
        recyclerView.setAdapter(commonRecycleAdapter);
    }


    public void onClickMemberPrivate(MemberPrivateDetailModel.CardPrivilege privateModel) {
        if (privateModel.priv_type != 1) {
            if(privateModel.priv_type == -1){
                ToastUtil.showToast("使用会员价请到桌台内账单操作");
            }else if(privateModel.priv_type == 2){
                ToastUtil.showToast( "使用折扣请到桌台内账单操作");
            }
        } else {
            MemberPrivatePrintDialog memberPrivilegePrintDialog = new MemberPrivatePrintDialog();
            memberPrivilegePrintDialog.setData(privateModel,memberCardModel.cardInfo.card_no, new MemberPrivatePrintDialog.Callback() {
                @Override
                public void onUsePrivateSuccess(MemberPrivateDetailModel.CardPrivilege privateModel, String cardNo) {
                    MemberPrintProcess.printPrivilege(getActivityWithinHost(), cardNo, privateModel);
                }
            });
            DialogManager.showCustomDialog(getActivityWithinHost(), memberPrivilegePrintDialog, MemberPrivatePrintDialog.TAG);
        }
    }

    public static MemberPrivateFragment getInstance(NewMemberCardDetailsModel memberCardModel) {
        MemberPrivateFragment memberPrivateFragment = new MemberPrivateFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        memberPrivateFragment.setArguments(bundle);
        return memberPrivateFragment;
    }

}
