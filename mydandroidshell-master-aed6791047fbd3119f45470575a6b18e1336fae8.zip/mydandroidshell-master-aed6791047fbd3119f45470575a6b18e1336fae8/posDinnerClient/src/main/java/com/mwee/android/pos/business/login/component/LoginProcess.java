package com.mwee.android.pos.business.login.component;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.login.view.AlertNoticeDialogFragment;
import com.mwee.android.pos.business.login.view.AllNoticeDialogFragment;
import com.mwee.android.pos.business.login.ClientInfoCollect;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.login.LoginToCenterForDinnerResponse;
import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;
import com.mwee.android.pos.connect.business.monitor.login.GetWorkModeResponse;
import com.mwee.android.pos.connect.business.monitor.notice.CNotice;
import com.mwee.android.pos.connect.business.monitor.notice.GetLastNoticeResponse;
import com.mwee.android.pos.connect.business.monitor.notice.GetNoticeFromBizCenterResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CLogin;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.NoticeDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Liming on 16/9/23.
 */

public class LoginProcess {


    public static void getAlllLoginData(SocketCallback<GetLoginDataResponse> callback) {
        MCon.c(CLogin.class, callback).getAllData();
    }

    /**
     * `
     * 进行登录
     *
     * @param userID   String
     * @param pwd      String 密码
     * @param hostid   String | 当前站点ID
     * @param callback SocketCallback<LoginToCenterForDinnerResponse>
     */
    public static void doLogin(String userID, String pwd, String fsiccardcode, String fsUserName, String hostid, int loginWay, ConCallBack<LoginToCenterForDinnerResponse> callback) {
        if (loginWay == 0) {
            MCon.c(CLogin.class, callback).login(userID, fsUserName, pwd);
        } else {
            MCon.c(CLogin.class, callback).loginWithIDCard(1, fsiccardcode);
        }
    }

    /**
     * 注销登录
     *
     * @param userID   String
     * @param callback SocketCallback<LoginToCenterForDinnerResponse>
     */

    public static void doLogout(String userID, SocketCallback callback) {
        ClientInfoCollect.destroy();
        MCon.c(CLogin.class, callback).logOut(userID);
    }

    /**
     * 获取所有公告 -- 20条
     *
     * @param fsUpdateTime
     * @param callback
     */
    public static void getAllNotice(String fsUpdateTime, final ResultCallback<List<NoticeDBModel>> callback) {
        MCon.c(CNotice.class, new SocketCallback<GetNoticeFromBizCenterResponse>() {

            @Override
            public void callback(SocketResponse<GetNoticeFromBizCenterResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data.noticeDBModelList == null) {
                        response.data.noticeDBModelList = new ArrayList<>();
                    }
                    callback.onSuccess(response.data.noticeDBModelList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).allNotice(fsUpdateTime);
    }


    /**
     * 获取最后一条公告
     *
     * @param host
     * @param id
     * @param unAlert
     * @param fsUpdateTime
     * @param iResponse
     */
    public static void getLastNotice(final Host host, int id, int unAlert, String fsUpdateTime, final IResponse<NoticeDBModel> iResponse) {
        MCon.c(CNotice.class, new SocketCallback<GetLastNoticeResponse>() {

            @Override
            public void callback(SocketResponse<GetLastNoticeResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data != null && response.data.noticeDBModel != null) {
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", response.data.noticeDBModel);
                        } else {
                            AlertNoticeDialogFragment dialogFragment = new AlertNoticeDialogFragment();
                            dialogFragment.setData(response.data.noticeDBModel);
                            DialogManager.showCustomDialog(host, dialogFragment, dialogFragment.TAG);
                        }
                    } else {
                        if (iResponse != null) {
                            iResponse.callBack(true, -1, "没有更多数据了", response.data.noticeDBModel);
                        }
                    }
                } else if (response.code == SocketResultCode.VERSION_HIGH &&
                        ClientBindProcessor.isCurrentHostMain()) {
                    response.message = GlobalCache.getContext().getString(R.string.serr_host_version_low);
                    ToastUtil.showToast(response.message);
                }else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).lastNotice(id, unAlert, fsUpdateTime);
    }

    /**
     * 查看所有公告
     *
     * @param host
     */
    public static void showAllNotice(Host host) {
        AllNoticeDialogFragment fragment = new AllNoticeDialogFragment();
        DialogManager.showCustomDialog(host, fragment, fragment.TAG);
    }

    /**
     * 不再提醒某公告
     *
     * @param id
     * @param unAlert
     */
    public static void unAlertNotice(int id, int unAlert) {
        MCon.c(CNotice.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {

            }
        }).unalert(id, unAlert);
    }


    public static void loadWorkMode(ResultCallback<Integer> resultCallback) {
        MCon.c(CLogin.class, new SocketCallback<GetWorkModeResponse>() {
            @Override
            public void callback(SocketResponse<GetWorkModeResponse> response) {
                if (response.success()) {
                    resultCallback.onSuccess(response.data.fiworkMode);
                }
            }
        }).loadWorkMode();
    }
}
