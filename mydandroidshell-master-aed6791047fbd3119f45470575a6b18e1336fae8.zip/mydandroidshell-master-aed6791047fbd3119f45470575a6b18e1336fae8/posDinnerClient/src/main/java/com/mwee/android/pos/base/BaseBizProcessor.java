package com.mwee.android.pos.base;

/**
 * Created by qinwei on 2017/7/3.
 */

public class BaseBizProcessor implements IBizProcessor {

    @Override
    public void onDestroy() {

    }
}
