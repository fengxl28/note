package com.mwee.android.pos.air.business.member.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.constant.MemberRechargeChoosePayType;
import com.mwee.android.pos.business.member.entity.RechargePayType;
import com.mwee.android.pos.business.pay.view.netpay.ICutomeNetPay;
import com.mwee.android.pos.business.pay.view.netpay.NetPayJump;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permissions.inf.PermissionCallback;
import com.mwee.android.pos.business.permissions.util.PermissionsUtil;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberBalanceRechargeDialog extends BaseDialogFragment implements View.OnClickListener, ICutomeNetPay {
    private TextView mBalanceRechargeTitleLabel;
    private EditText mBalanceRechargePriceEdt;
    private EditText mBalanceRechargeGiftPriceEdt;
    private Button mBalanceRechargeCancelBtn;
    private Button mBalanceRechargeConfirmBtn;
    private OnMemberBalanceRechargeListener listener;
    private MemberEditorProcessor mMemberEditorProcessor;
    private String card_no;
    private String mobile;
    private GridView mBalanceRechargeTypeGv;
    private RechargeTypeAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_balance_recharge_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mBalanceRechargeTypeGv = (GridView) view.findViewById(R.id.mBalanceRechargeTypeGv);
        mBalanceRechargeTitleLabel = (TextView) view.findViewById(R.id.mBalanceRechargeTitleLabel);
        mBalanceRechargePriceEdt = (EditText) view.findViewById(R.id.mBalanceRechargePriceEdt);
        mBalanceRechargeGiftPriceEdt = (EditText) view.findViewById(R.id.mBalanceRechargeGiftPriceEdt);
        mBalanceRechargeCancelBtn = (Button) view.findViewById(R.id.mBalanceRechargeCancelBtn);
        mBalanceRechargeConfirmBtn = (Button) view.findViewById(R.id.mBalanceRechargeConfirmBtn);
        mBalanceRechargeCancelBtn.setOnClickListener(this);
        mBalanceRechargeConfirmBtn.setOnClickListener(this);
    }


    private void initData() {
        mMemberEditorProcessor = new MemberEditorProcessor();
        adapter = new RechargeTypeAdapter();
        adapter.modules.add(new RechargePayType("线下支付", MemberRechargeChoosePayType.CASH, R.drawable.selector_member_recharge_type_icon_cash, R.drawable.selector_member_recharge_type_bg_cash));
        mBalanceRechargeTypeGv.setAdapter(adapter);
    }

    @Override
    public void callPay(int type, String micro, final IResponse callback) {
//        if (memberCardModel != null) {
//            final MemberRechargePackageModel selectPackage = mMemberRechargeAdapter.getSelectPackage();
//            MemberCardInfoModel memberCardInfoCache = memberCardModel.card_info;
//            if (memberCardInfoCache != null) {
//                ProgressManager.showProgressUncancel(getActivityWithinHost(), "在线支付充值中...");
//                RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付ing,type=" + type + " micro=" + micro);
//                //ActionLog.addLog("网络支付ing,type=" + type + " micro=" + micro, "", "", ActionLog.MEMBER_BALANCE_RECHARGE, "");
//                mMemberProcess.loadOnlineRechargeRequest(StringUtil.toInt(selectPackage.id), new BigDecimal(selectPackage.money), memberCardInfoCache.pay_code, type, micro, memberCardInfoCache.card_no, new ResultCallback<MemberCardPayDepositModel>() {
//                    @Override
//                    public void onSuccess(MemberCardPayDepositModel data) {
//                        RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付done ", data.toString());
//                        // ActionLog.addLog("网络支付done", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, data);
//                        ProgressManager.closeProgress(getActivityWithinHost());
//                        if (callback != null) {
//                            callback.success(null);
//                        }
//                        doMemberRechargeOrderRequest(data.trade_no, "充值" + selectPackage.money + "元 " + selectPackage.present_desc, mMemberRechargePayTypeAdapter.getSelectRechargePayType());
//                    }
//
//                    @Override
//                    public void onFailure(int code, String msg) {
//                        ProgressManager.closeProgress(getActivityWithinHost());
//                        RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付FAIL " + msg);
//                        //ActionLog.addLog("网络支付FAIL", "", "", ActionLog.MEMBER_BALANCE_RECHARGE, msg);
//                        if (callback != null) {
//                            callback.fail(null);
//                        }
//                        ToastUtil.showToast(msg);
//                    }
//                });
//            }
//        }
    }

    @Override
    public void queryPayResult(String tradeNo, IResponse<String> callback) {

    }

    class RechargeTypeAdapter extends BaseMwAdapter<RechargePayType> {
        public int selectPosition;

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_balance_recharge_type, null);
                holder = new Holder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }
            holder.initData(position);
            return convertView;
        }

        class Holder implements View.OnClickListener {
            private CheckedTextView mBalanceRechargeTypeItemNameLabel;
            private int position;

            public Holder(View item) {
                mBalanceRechargeTypeItemNameLabel = (CheckedTextView) item;
                item.setOnClickListener(this);
            }

            public void initData(int position) {
                this.position = position;
                RechargePayType type = modules.get(position);
                mBalanceRechargeTypeItemNameLabel.setText(type.name);
                mBalanceRechargeTypeItemNameLabel.setChecked(position == selectPosition);
            }

            @Override
            public void onClick(View view) {
                selectPosition = position;
                notifyDataSetChanged();
            }
        }

        /**
         * 获取当前选中支付方式
         *
         * @return
         */
        public RechargePayType getPayType() {
            return modules.get(selectPosition);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBalanceRechargeConfirmBtn:
                final String price = mBalanceRechargePriceEdt.getText().toString().trim();
                final String priceGift = mBalanceRechargeGiftPriceEdt.getText().toString().trim();
                final RechargePayType payType = adapter.getPayType();
                if (check(price, priceGift)) {
                    PermissionsUtil.requestPermissionCommon(getActivityWithinHost(), AppCache.getInstance().userDBModel, Permission.DINNER_vTempVIPAuth, new PermissionCallback() {
                        @Override
                        public void onCall(int errCode, String msg, UserDBModel userDBModel) {
                            switch (payType.type) {
                                case MemberRechargeChoosePayType.CASH:
                                    doRecharge(price, priceGift);
                                    break;
                                case MemberRechargeChoosePayType.ALIPAY:
                                case MemberRechargeChoosePayType.WECHAT:
                                    RunTimeLog.addLog(RunTimeLog.MEMBER, "网络支付" + price.toString());
                                    NetPayJump.jumpToMemberChargePay(getActivityWithinHost(), new BigDecimal(price), payType.type, MemberBalanceRechargeDialog.this);
                                    break;
                                default:
                                    break;
                            }
                        }
                    });
                }
                break;
            case R.id.mBalanceRechargeCancelBtn:
                dismissSelf();
                break;
            default:
                break;
        }
    }

    private void doRecharge(String price, String priceGift) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMemberEditorProcessor.loadBalanceRecharge(card_no, mobile, price, priceGift, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                dismissSelf();
                listener.onMemberBalanceRechargeSuccess();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    private boolean check(String price, String priceGift) {
        if (TextUtils.isEmpty(price)) {
            ToastUtil.showToast("请输入充值金额");
            return false;
        }
        return true;
    }

    public void setOnMemberBalanceRechargeListener(OnMemberBalanceRechargeListener listener) {
        this.listener = listener;
    }

    public interface OnMemberBalanceRechargeListener {
        void onMemberBalanceRechargeSuccess();
    }

    public void setParam(String card_no, String mobile) {
        this.card_no = card_no;
        this.mobile = mobile;
    }
}
