package com.mwee.android.pos.business.dinner;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.util.List;

/**
 * 点菜工具类
 * Created by qinwei on 2018/9/13.
 */

public class DishUtils {

    /**
     * 共享餐厅订单，口碑订单，不可修改订单菜品信息
     *
     * @param order
     * @return
     */
    public static boolean isSupportEditor(OrderCache order) {
        if (order != null && (order.shareShopOrder() || NetOrderType.isKouBeiOrder(order.thirdOrderType))) {
            ToastUtil.showToast(GlobalCache.getContext().getString(R.string.share_shop_operation_err_tips));
            return false;
        }
        return true;
    }

    /**
     * 订单是否允许圆整
     *
     * @param order
     * @return
     */
    public static boolean isSupportRound(OrderCache order) {
        return !(NetOrderType.isKouBeiOrder(order.thirdOrderType) || order.shareShopOrder());
    }

    public static boolean isKBPreOrder(int thirdOrderType) {
        return NetOrderType.isKouBeiOrder(thirdOrderType);
    }
}
