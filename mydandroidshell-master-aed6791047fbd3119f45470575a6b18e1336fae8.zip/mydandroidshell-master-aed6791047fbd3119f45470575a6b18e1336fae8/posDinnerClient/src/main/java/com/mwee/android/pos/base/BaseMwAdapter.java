package com.mwee.android.pos.base;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/10/16.
 */

public abstract class BaseMwAdapter<T> extends BaseAdapter {
    public ArrayList<T> modules = new ArrayList<>();

    @Override
    public int getCount() {
        return modules.size();
    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getItemView(position, convertView, parent);
    }

    protected abstract View getItemView(int position, View convertView, ViewGroup parent);
}
