package com.mwee.android.pos.air.business.netorder;

import android.text.TextUtils;
import android.support.v4.util.ArrayMap;

import com.mwee.android.air.acon.CWechatOrderManager;
import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.air.connect.business.wechatorder.GetWechatSettingResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;

/**
 * Created by liuxiuxiu on 2017/10/17.
 */

public class AirWechatOrderApi {

    public static void loadWechatOrderSetting(final IResponse<ArrayMap<String, String>> iResult) {

        MCon.c(CWechatOrderManager.class, new SocketCallback<GetWechatSettingResponse>() {
            @Override
            public void callback(SocketResponse<GetWechatSettingResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null)
                            iResult.callBack(true, 0, response.message, response.data.stringList);
                        else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadWechatOrderSetting();
    }

    public static void updateWechatOrderSetting(ArrayMap<String, String> settings, final IResult iResult) {

        MCon.c(CWechatOrderManager.class, new SocketCallback<GetAllAreaAndTableResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAreaAndTableResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, "保存成功");
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, TextUtils.isEmpty(response.message) ? "保存失败" : response.message);
                    }
                }
            }
        }).updateWechatOrderSetting(settings);
    }

}
