package com.mwee.android.pos.base;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/12/25 10:37 AM
 * email: qin.wei@mwee.cn
 */

public class FClazzInfo extends BusinessBean {
    public String title;
    public Class<? extends BaseFragment> clazz;

    public FClazzInfo(String title, Class<? extends BaseFragment> clazz) {
        this.title = title;
        this.clazz = clazz;
    }
}
