package com.mwee.android.pos.business.dinner.processor;

import android.text.TextUtils;

import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseBizProcessor;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.common.dinner.IDinnerOrderProcessor;
import com.mwee.android.pos.business.dinner.api.DinnerFoodOrderApi;
import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.orderdishes.view.fragment.OrderDishesBatchSetWaitCallFragment;
import com.mwee.android.pos.business.orderdishes.view.jump.OrderDishesJump;
import com.mwee.android.pos.business.pay.component.PayViewUtil;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.business.table.processor.TableBizProcessor;
import com.mwee.android.pos.business.table.transferdish.TransferDishProcessor;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.text.CallChangeText;
import com.mwee.android.pos.component.text.IChangeText;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.order.GetOrderTokenResponse;
import com.mwee.android.pos.connect.business.order.PreMenuListResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CKouBei;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * 正餐点菜业务处理类
 * Created by qinwei on 2017/4/27.
 *
 * @author virgil
 */

public class DinnerOrderProcessor extends BaseBizProcessor implements IDinnerOrderProcessor {
    public DishCache mDishCache;
    public Host mHost;

    public DinnerOrderProcessor(Host host, DishCache dishCache) {
        this.mDishCache = dishCache;
        this.mHost = host;
    }

    public void setDishCache(DishCache dishCache){
        mDishCache = dishCache;
    }

    @Override
    public void showOrderErrMsg(String message) {
        DialogManager.showSingleDialog(mHost, message, "", mHost.getStringWithinHost(R.string.confirm), null);
    }

    @Override
    public void doBatchWait(final ResultCallback<String> callback) {
        List<MenuItem> waitCallMenuItems = ListUtil.cloneList(mDishCache.orderDishesCache.tempSelectedMenuList);
        OrderDishesJump.showBatchSetWaitCall(mHost, waitCallMenuItems, new OrderDishesBatchSetWaitCallFragment.Callback() {
            @Override
            public void onConfirm(List<MenuItem> menuItemList) {
                if (!ListUtil.isEmpty(menuItemList) && !ListUtil.isEmpty(mDishCache.orderDishesCache.tempSelectedMenuList)) {
                    for (MenuItem temp : menuItemList) {
                        for (MenuItem item : mDishCache.orderDishesCache.tempSelectedMenuList) {
                            if (TextUtils.equals(temp.menuBiz.uniq, item.menuBiz.uniq)) {
                                item.waitOrCall(temp.menuBiz.fiItemMakeState);
                                break;
                            }
                        }
                    }
                }
                callback.onSuccess("");
            }
        });
    }

    @Override
    public void orderAndOpenTable(boolean isPrinter, ResultCallback<OrderCache> callback) {
        DinnerFoodOrderApi.orderAndOpenTable(mDishCache.orderDishesCache, isPrinter, callback);
    }

    @Override
    public void orderToCenter(boolean isPrinter, final ResultCallback<OrderCache> callback) {
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
        DinnerFoodOrderApi.orderToCenter(mDishCache.orderDishesCache, mDishCache.getOrderId(), isPrinter, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
                progress.dismiss();
                callback.onSuccess(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    showOrderErrMsg(msg);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }

    @Override
    public void doTurnDish(MenuItem item, IResponse<OrderCache> iResponse) {
        TransferDishProcessor processor = new TransferDishProcessor(mHost, mDishCache.order, item, iResponse);
        processor.start();
    }

    @Override
    public void doPay(final SyncCallback<Boolean> callback) {
        if (mDishCache.orderDishesCache.tempSelectedMenuList.size() > 0) {
            DialogManager.showExecuteDialog(mHost, R.string.dinner_food_order_pay_validate_msg, mHost.getStringWithinHost(R.string.do_pay), mHost.getStringWithinHost(R.string.do_failure), null, new DialogResponseListener() {
                @Override
                public void response() {
                    checkAndGoPayDinner(callback);
                }
            });
        } else {
            checkAndGoPayDinner(callback);
        }
    }

    /**
     * 检查结帐前数据 通过则跳转到结帐界面
     *
     * @param callback
     */
    private void checkAndGoPayDinner(SyncCallback<Boolean> callback) {
        BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                if (mDishCache.order != null) {
                    // LogBiz.logNoEnv("dishesorde 用户点击结账按钮,orderid=" + mDishCache.order.orderID);
                    ActionLog.addLog("dishesorde 用户点击结账按钮,orderid=", ActionLog.FF_ORDER_BACK);
                }
                String checkDishWeightError = OrderDishesBizUtil.checkOrderCanPay(mDishCache.order.originMenuList);
                if (!TextUtils.isEmpty(checkDishWeightError)) {
                    ToastUtil.showToast(checkDishWeightError);
                    return false;
                }
                String checkError = PayViewUtil.canPay(AppCache.getInstance().userDBModel.fsUserId);
                if (!TextUtils.isEmpty(checkError)) {
                    ToastUtil.showToast(checkError);
                    return false;
                }
                return true;
            }
        }, callback);
    }

    @Override
    public void printDinnerPreBill() {
        TableBizProcessor.modifyPreStatus(mDishCache.order.fsmtableid, mDishCache.order.orderID, TableStatusBean.PRINT_COMPLETE, null);
        final Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.printer_send_ing);
        DinnerFoodOrderApi.printDinnerPreBill(mDishCache.order.orderID, null, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                ToastUtil.showToast(R.string.printer_send_done);
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void printPreMenuList(DishCache dishCache) {
        String hostId = AppCache.getInstance().currentHostId;
        String printUser = AppCache.getInstance().userDBModel.fsUserName;
        List<MenuItem> tempSelectedMenuList = new ArrayList<>();
        List<MenuItem> originMenuList = new ArrayList<>();
        String fsSellNo = "";
        String fsMTableName = "";
        String fiCustSum = "";
        String fsSellDate = "";
        String currentSectionID = "";
        if (!dishCache.orderDishesCache.tempSelectedMenuList.isEmpty()) {
            tempSelectedMenuList.addAll(dishCache.orderDishesCache.tempSelectedMenuList);
            fsSellNo = "";
            fsMTableName = dishCache.orderDishesCache.fsmtablename;

            fiCustSum = dishCache.orderDishesCache.personNum + "";

            fsSellDate = dishCache.orderDishesCache.businessDate;
            currentSectionID = dishCache.orderDishesCache.currentSectionID;
        }
        if (dishCache.order != null && !dishCache.order.originMenuList.isEmpty()) {
            //过滤掉餐标加上的两个服务费菜品
            for (MenuItem menuItem : dishCache.order.originMenuList) {
                if(menuItem != null){
                    if(!DinnerStandardUtil.isStandardMenu(menuItem.itemID)){
                        originMenuList.add(menuItem);
                    }
                }
            }
//            originMenuList.addAll(dishCache.order.originMenuList);
            fsSellNo = dishCache.order.orderID;
            fsMTableName = dishCache.order.fsmtablename;
            fiCustSum = dishCache.order.personNum + "";
            fsSellDate = dishCache.order.businessDate;
            currentSectionID = dishCache.order.currentSectionID;
        }
        ProgressManager.showProgress(mHost, R.string.printer_send_ing);
        DinnerFoodOrderApi.printPreMenuList(tempSelectedMenuList, originMenuList, printUser, hostId, fsSellNo,
                fsMTableName, fiCustSum, fsSellDate, currentSectionID, new SocketCallback<PreMenuListResponse>() {
                    @Override
                    public void callback(SocketResponse<PreMenuListResponse> response) {
                        ProgressManager.closeProgress(mHost);
                        if (response == null) {
                            return;
                        }
                        if (response.code == SocketResultCode.SUCCESS) {
                            ToastUtil.showToast(R.string.printer_send_done);
                            if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                                PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                            }
                        } else {
                            if (!TextUtils.isEmpty(response.message)) {
                                ToastUtil.showToast(response.message);
                            }
                        }
                    }
                });
    }

    @Override
    public void loadCheckDishOpenParamError(String orderID, ResultCallback<String> callback) {
        DinnerFoodOrderApi.loadCheckDishOpenParamError(orderID, callback);
    }

    @Override
    public void unBindMemberInfoFromOrder(String orderId, String cardNo, ResultCallback<ChangeOrderWithMemberResponse> callback) {
        MemberApi.unBindMemberInfoFromOrder(orderId, cardNo, callback);
    }

    @Override
    public void doEditOrderNote() {
        String defaultContent = "";
        if (mDishCache.order != null) {
            defaultContent = mDishCache.order.note;
        } else if (mDishCache.orderDishesCache != null) {
            defaultContent = mDishCache.orderDishesCache.note;
        }
        CallChangeText.call(mHost, new IChangeText() {
            @Override
            public boolean confirmTxt(final String note) {
                if (mDishCache.order != null) {
                    final Progress progress = ProgressManager.showProgress(mHost, R.string.progress_loading);
                    MCon.c(COrder.class, new ConCallBack<SocketBaseResponse>() {
                        @Override
                        public void subCall(SocketResponse<SocketBaseResponse> socketResponse) {

                        }

                        @Override
                        public void callback(SocketResponse<SocketBaseResponse> socketResponse) {
                            if (socketResponse.success()) {
                                mDishCache.order.note = note;
                            }
                            progress.dismiss();
                        }
                    }).addOrderNote(mDishCache.order.orderID, note);
                } else {
                    mDishCache.orderDishesCache.note = note;
                }
                return true;
            }
        }, "备注", "最多输入50个字", "备注输入不符合规则", 50, defaultContent, false);
    }

    @Override
    public void doCheckOutForKBOrder(String orderID, ResultCallback<String> callback) {
        Progress progress = ProgressManager.showProgressUncancel(mHost, "结账中...");
        MCon.c(CKouBei.class, new SocketCallback<SocketResponse>() {
            @Override
            public void callback(SocketResponse<SocketResponse> response) {
                progress.dismissSelf();
                if (response.success()) {
                    callback.onSuccess("结账成功");
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).loadCheckOut(orderID);
    }

    public void getOrderToken(String orderId,ResultCallback<String> callback){
        Progress progress = ProgressManager.showProgressUncancel(mHost, R.string.progress_loading);
        MCon.c(COrder.class, (SocketCallback<GetOrderTokenResponse>) response -> {
            progress.dismissSelf();
            if(response != null && response.success() && response.data != null){
                AppCache.getInstance().refreshOrderToken(response.data.orderToken);
                if(callback != null){
                    callback.onSuccess("");
                }
            }else{
                if(callback != null){
                    callback.onFailure(SocketResultCode.BUSINESS_FAILED,response == null ? "业务失败":response.message);
                }
            }
        }).GetOrderTokenRequest(orderId);
    }
}