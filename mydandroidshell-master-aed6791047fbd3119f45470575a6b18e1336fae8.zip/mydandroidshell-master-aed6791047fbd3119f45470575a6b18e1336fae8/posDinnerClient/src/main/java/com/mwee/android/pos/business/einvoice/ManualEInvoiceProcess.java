package com.mwee.android.pos.business.einvoice;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.business.setting.GetAllManualIEnvoiceResponse;
import com.mwee.android.pos.connect.business.setting.PrintManualIEnvoiceResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.ListUtil;

public class ManualEInvoiceProcess {

    public void optDataFromServer(int page, String date, ResultCallback<GetAllManualIEnvoiceResponse> callback) {

        ManualEInvoiceApi.optDataFromServer(page, date, new SocketCallback<GetAllManualIEnvoiceResponse>() {
            @Override
            public void callback(SocketResponse<GetAllManualIEnvoiceResponse> response) {
                GetAllManualIEnvoiceResponse getAllManualIEnvoiceResponse = response.data;
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(getAllManualIEnvoiceResponse);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    /**
     * 开发票
     *
     * @param amt     开票金额
     * @param date    日期
     * @param iResult
     */
    public void addManualEInvoice(String amt, String date, IResult iResult) {

        ManualEInvoiceApi.addManualEInvoice(amt, date, new SocketCallback<PrintManualIEnvoiceResponse>() {
            @Override
            public void callback(SocketResponse<PrintManualIEnvoiceResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    //打印小票
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }
                    iResult.callBack(true, "");
                } else {
                    iResult.callBack(false, response.message);
                }
            }
        });
    }

    /**
     * 重印小票
     *
     * @param orderId 小票订单号
     * @param iResult
     */
    public void reprintManualEInvoice(String orderId, IResult iResult) {

        ManualEInvoiceApi.reprintManualEInvoice(orderId, new SocketCallback<PrintManualIEnvoiceResponse>() {
            @Override
            public void callback(SocketResponse<PrintManualIEnvoiceResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    //打印小票
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }
                    iResult.callBack(true, "打印任务已发送");
                } else {
                    iResult.callBack(false, response.message);
                }
            }
        });
    }


}
