package com.mwee.android.pos.air.business.tticket;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.air.business.tshop.TShopProcessor;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.ChooseNumJump;
import com.mwee.android.pos.business.orderdishes.view.widget.choosenum.IChooseNumListner;
import com.mwee.android.pos.business.setting.process.SettingProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.SettingHelper;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2017/9/28.
 */

public class TCashierTicketFragment extends AirBaseFragment implements CompoundButton.OnCheckedChangeListener {

    private Switch swWhetherCut;
    private Switch swWhetherPrinter;
    private TextView tvBillPrintCount;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_ticket_cashier_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        init();
        initData();
    }

    private void assignViews(View containView) {

        swWhetherCut = (Switch) containView.findViewById(R.id.swWhetherCut);
        swWhetherPrinter = (Switch) containView.findViewById(R.id.swWhetherPrinter);
        tvBillPrintCount = containView.findViewById(R.id.tvBillPrintCount);

        containView.findViewById(R.id.mBillPrintLayout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doClickBillPrint();
            }
        });

    }

    private HostexternalDBModel hostexternalDBModel;

    private void initData() {

        TShopProcessor.queryTHostexternal(4, new TResult<HostexternalDBModel>() {
            @Override
            public void callBack(final HostexternalDBModel model) {
                hostexternalDBModel = model;
                tvBillPrintCount.setText(TextUtils.isEmpty(model.fsParamValue) ? "1" : model.fsParamValue);
            }
        });
    }


    private void doClickBillPrint() {

        BigDecimal originValue = new BigDecimal(1);
        if (!TextUtils.isEmpty(hostexternalDBModel.fsParamValue)) {
            originValue = new BigDecimal(hostexternalDBModel.fsParamValue);
        }
        BigDecimal maxValue = new BigDecimal(10);

        ChooseNumJump.showChooseNum(getActivityWithinHost(), "选择数量", originValue, maxValue, true, "", new IChooseNumListner() {
            @Override
            public void callback(boolean confirm, final BigDecimal confirmCount) {
                if (!confirm) {
                    return;
                }
                hostexternalDBModel.fsParamValue = confirmCount.toString();
                TShopProcessor.replaceTHostexternal(hostexternalDBModel);
                tvBillPrintCount.setText(TextUtils.isEmpty(hostexternalDBModel.fsParamValue) ? "1" : hostexternalDBModel.fsParamValue);

            }
        });
    }


    private void registerEvent() {
        swWhetherCut.setOnCheckedChangeListener(this);
        swWhetherPrinter.setOnCheckedChangeListener(this);

    }


    private void init() {
        swWhetherCut.setChecked(TextUtils.equals(SettingHelper.getDinnerSetting(DBPrintConfig.PRINT_BILL_CUT, "0"), "0"));
        swWhetherPrinter.setChecked(TextUtils.equals(ClientMetaUtil.getConfig(META.T_CASHIER_PRINTER, "1"), "1"));
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        switch (buttonView.getId()) {
            case R.id.swWhetherCut:
                ActionLog.addLog(ActionLog.TICKET_CONFIG, "点击了收银小票是否切单");
                ActionLog.addLog("更多设置->结账单切单设置", "", "", ActionLog.SS_MORE_JOIN, "");
                SettingProcessor.updateDBSetting(DBPrintConfig.PRINT_BILL_CUT, isChecked ? "0" : "1");
                break;
            case R.id.swWhetherPrinter:
                ActionLog.addLog(ActionLog.TICKET_CONFIG, "点击了收银小票是否打印");
                SettingProcessor.refreshSettingStatus(META.T_CASHIER_PRINTER, isChecked ? "1" : "0");
                break;
            default:
                break;

        }
    }


}
