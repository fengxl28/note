package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.dinner.R;

/**
 * MemberPrivateFragment
 *
 * @author ZM
 * @date 17/2/21
 */
public class MemberPrivatePrintDialog extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = MemberPrivatePrintDialog.class.getSimpleName();

    private TextView privilegeTitleTxt;
    private TextView privilegeDirectionTxt;
    private Button cancelBtn;
    private Button privilegePrintBtn;

    private MemberPrivateDetailModel.CardPrivilege memberPrivateModel;
    private String cardNo;
    private Callback privatePrintCallback;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_member_private_print, container, false);
        initUi(view);
        return view;
    }

    public void initUi(View view) {

        privilegeTitleTxt = (TextView) view.findViewById(R.id.privilege_title_txt);
        privilegeDirectionTxt = (TextView) view.findViewById(R.id.privilege_direction_txt);
        cancelBtn = (Button) view.findViewById(R.id.cancel_btn);
        privilegePrintBtn = (Button) view.findViewById(R.id.privilege_print_btn);

        cancelBtn.setOnClickListener(this);
        privilegePrintBtn.setOnClickListener(this);

        privilegeTitleTxt.setText(memberPrivateModel.title);
        privilegeDirectionTxt.setText(memberPrivateModel.directions);
    }


    public void setData(MemberPrivateDetailModel.CardPrivilege model, String cardNo, Callback privatePrintCallback) {
        this.memberPrivateModel = model;
        this.cardNo = cardNo;
        this.privatePrintCallback = privatePrintCallback;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cancel_btn:
                dismiss();
                break;
            case R.id.privilege_print_btn:
               // ProgressManager.showProgress((Host) getActivity());
                privilegePrintBtn.setEnabled(false);
                //MemberApi.sendMemberUsePrivateRequest(callback, cardNo, memberPrivateModel.id);
                if (privatePrintCallback != null) {
                    privatePrintCallback.onUsePrivateSuccess(memberPrivateModel, cardNo);
                }
                dismiss();
                break;
        }
    }

    public interface Callback {
        void onUsePrivateSuccess(MemberPrivateDetailModel.CardPrivilege privateModel, String cardNo);
    }

}
