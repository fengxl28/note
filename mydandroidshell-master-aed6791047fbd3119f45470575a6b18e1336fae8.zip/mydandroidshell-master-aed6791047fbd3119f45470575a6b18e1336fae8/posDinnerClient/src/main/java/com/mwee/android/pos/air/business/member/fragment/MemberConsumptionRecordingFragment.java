package com.mwee.android.pos.air.business.member.fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.air.business.member.entity.MemberConsumptionRecordingModel;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberConsumptionRecordingResponse;
import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.air.business.member.utils.MemberUtils;
import com.mwee.android.pos.air.business.widget.EditorView;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.BaseToastUtil;

import java.text.ParseException;
import java.util.List;

/**
 * 消费记录
 * Created by zhangmin on 2018/1/26.
 */

public class MemberConsumptionRecordingFragment extends BaseListFragment<MemberConsumptionRecordingModel> implements View.OnClickListener {


    private TextView tvDateStart;
    private TextView tvDateEnd;
    private EditorView etSearch;
    private TextView tvSearchConfirm;

    private TextView tvCount;
    private TextView tvRechargeMoney;
    private TextView tvRealMoney;
    private TextView tvGiftScore;

    private MemberEditorProcessor memberEditorProcessor;


    //查询条件
    String card_no = "";
    String mobile = "";
    String start_date = "";
    String end_date = "";
    int page = 1;
    private TextView tvTotalAmount;
    private FrameLayout mEmptyLayout;

    private String inputStr = "";


    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_air_member_consumption;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.fragment_air_member_consumption_item, parent, false));
    }


    @Override
    protected void initView(View v) {
        super.initView(v);
        tvDateStart = v.findViewById(R.id.tvDateStart);
        tvDateEnd = v.findViewById(R.id.tvDateEnd);
        etSearch = v.findViewById(R.id.etSearch);
        tvSearchConfirm = v.findViewById(R.id.tvSearchConfirm);
        tvCount = v.findViewById(R.id.tvCount);
        tvTotalAmount = v.findViewById(R.id.tvTotalAmount);
        tvRechargeMoney = v.findViewById(R.id.tvRechargeMoney);
        tvRealMoney = v.findViewById(R.id.tvRealMoney);
        tvGiftScore = v.findViewById(R.id.tvGiftScore);

        mEmptyLayout = v.findViewById(R.id.mEmptyLayout);
        ImageView mMenuEmptyLabel = (ImageView) v.findViewById(R.id.mMenuEmptyLabel);
        if (APPConfig.isAir()) {
            mMenuEmptyLabel.setImageResource(R.drawable.bg_air_order_list_empty);
        } else {
            mMenuEmptyLabel.setImageResource(R.drawable.bg_dinner_order_list_empty);
        }
        TextView tvLableSub = v.findViewById(R.id.tvLableSub);
        tvLableSub.setVisibility(View.VISIBLE);
        v.findViewById(R.id.tvEmptyCreateFirst).setVisibility(View.GONE);

        tvDateStart.setOnClickListener(this);
        tvDateEnd.setOnClickListener(this);
        tvSearchConfirm.setOnClickListener(this);

        KeyboardManager.hideSoftInput(etSearch.getEditText());

    }


    @Override
    protected void initData() {
        super.initData();
        inputStr = getArguments().getString("key_member_info");

        memberEditorProcessor = new MemberEditorProcessor();

        //初始化查询条件
        if (MemberUtils.checkIsPhoneNumber(inputStr)) {
            mobile = inputStr;
            card_no = "";
        } else {
            mobile = "";
            card_no = inputStr;
        }
        etSearch.setText(inputStr);
        start_date = DateUtil.getCurrentDate("yyyy-MM-dd");
        end_date = DateUtil.getCurrentDate("yyyy-MM-dd");

        tvDateStart.setText(start_date);
        tvDateEnd.setText(end_date);

        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        //mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();

    }


    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            page = 1;
        } else {
            page++;
        }
        loadDataFromServer(mode);
    }


    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    private void loadDataFromServer(final int mode) {

        memberEditorProcessor.loadMemberConsumptionRecording(card_no, mobile, start_date, end_date, page, new ResultCallback<AirMemberConsumptionRecordingResponse>() {
            @Override
            public void onSuccess(AirMemberConsumptionRecordingResponse data) {

                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    modules.clear();
                }
                if (page >= data.data.page_count) {//没有下一页数据
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode);
                }
//                无交易记录判断
                if (!com.mwee.android.pos.util.TextUtils.validate(data.data.list)) {
                    mPullRecyclerView.showEmptyView();
                    adapter.notifyDataSetChanged();
                    refreshUI(data, true);
                } else {
                    mPullRecyclerView.showContent();
                    List<MemberConsumptionRecordingModel> list = data.data.list;
                    refreshUI(data, false);
                    refreshAdapter(list);
                }


            }

            @Override
            public void onFailure(int code, String msg) {
                BaseToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                refreshUI(null, true);
                super.onFailure(code, msg);
            }
        });

    }


    /**
     * 刷新布局
     */
    private void refreshUI(AirMemberConsumptionRecordingResponse model, boolean isError) {
        if(model == null || ListUtil.isEmpty(model.data.list)){
            mEmptyLayout.setVisibility(View.VISIBLE);
            return;
        }else {
            mEmptyLayout.setVisibility(View.GONE);
        }
        tvCount.setText(String.format("共%s笔", isError ? 0 : model.data.total));
        tvTotalAmount.setText(String.format("消费合计 %s", isError ? 0 : model.data.total_amount));
        tvRechargeMoney.setText(String.format("消费储值金额 %s", isError ? 0 : model.data.total_amount_use_reality));
        tvRealMoney.setText(String.format("消费赠送金额 %s", isError ? 0 : model.data.total_present_moeny));
        tvGiftScore.setText(String.format("积分抵扣 %s", isError ? 0 : model.data.total_score));

    }

    /**
     * 刷新会员储值消费记录adapter
     */
    private void refreshAdapter(List<MemberConsumptionRecordingModel> list) {
        modules.addAll(list);
        adapter.notifyDataSetChanged();
    }


    class Holder extends BaseViewHolder {

        private TextView tvTime;
        private TextView tvSellNo;
        private TextView tvTransactionType;
        private TextView tvMobile;
        private TextView tvCardNo;
        private TextView tvAmount;
        private TextView tvBalance;
        private TextView tvRealMoney;
        private TextView tvPayType;

        private MemberConsumptionRecordingModel model;


        public Holder(View v) {
            super(v);
            tvTime = v.findViewById(R.id.tvTime);
            tvSellNo = v.findViewById(R.id.tvSellNo);
            tvTransactionType = v.findViewById(R.id.tvTransactionType);
            tvMobile = v.findViewById(R.id.tvMobile);
            tvCardNo = v.findViewById(R.id.tvCardNo);
            tvAmount = v.findViewById(R.id.tvAmount);
            tvBalance = v.findViewById(R.id.tvBalance);
            tvRealMoney = v.findViewById(R.id.tvRealMoney);
            tvPayType = v.findViewById(R.id.tvPayType);

        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);

            tvTime.setText(DateTimeUtil.getTime(Long.parseLong(model.add_time) * 1000));
            tvSellNo.setText(model.trade_no);
            tvTransactionType.setText(model.type_name);//deposit=>在线储值     cash=>现金储值
            tvMobile.setText(entcyMobile(model.mobile.trim()));
            tvCardNo.setText(model.card_no);
            tvAmount.setText(model.amount);
            tvBalance.setText(model.amount_use_reality);//消费储值金额
            tvRealMoney.setText(model.present_moeny);//消费赠送金额
            tvPayType.setText(model.score);//积分抵扣
        }
    }


    private String entcyMobile(String mobile) {
        if (mobile.length() != 11) {
            return mobile;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(mobile.substring(0, 3));
        stringBuilder.append("****");
        stringBuilder.append(mobile.substring(7, 11));
        return stringBuilder.toString();
    }


    /**
     * 选择营业时间
     *
     * @param currentTime 当前要显示的营业时间
     * @param callback
     */
    public void choseBussinessDateStart(String currentTime, final CalendarPopupWindow.Callback callback) {

        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), this.getView());
        calendarPopupwindow.setDate(currentTime);
        calendarPopupwindow.setCancelable(true);
        calendarPopupwindow.setSupportStartDate("1970-01-01");
        calendarPopupwindow.setSupportEndDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                callback.onConfirm(newDate);
            }
        });
    }


    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.tvDateStart:

                choseBussinessDateStart(start_date, new CalendarPopupWindow.Callback() {
                    @Override
                    public void onConfirm(String newDate) {
                        try {
                            if (DateUtil.daysBetween(newDate, end_date) >= 0) {// 选择的起始日期和 结束日期比较
                                start_date = newDate;
                                tvDateStart.setText(newDate);
                            } else {
                                com.mwee.android.pos.util.ToastUtil.showToast("选择的起始营业日期必须小于截止营业日期");
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                });

                break;
            case R.id.tvDateEnd:

                choseBussinessDateStart(end_date, new CalendarPopupWindow.Callback() {
                    @Override
                    public void onConfirm(String newDate) {
                        try {
                            if (DateUtil.daysBetween(start_date, newDate) >= 0) {//选择的结束日期和起始日期比较
                                end_date = newDate;
                                tvDateEnd.setText(newDate);
                            } else {
                                com.mwee.android.pos.util.ToastUtil.showToast("选择的起始营业日期必须小于截止营业日期");
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                });


                break;
            case R.id.tvSearchConfirm:
                doSearchConfirm();
                break;
        }
    }

    private void doSearchConfirm() {

        String number = etSearch.getText().toString().trim();
        if (!TextUtils.isEmpty(number)) {
            if (MemberUtils.checkIsPhoneNumber(number)) {
                mobile = number;
                card_no = "";
            } else {
                mobile = "";
                card_no = number;
                /*if (MemberUtils.checkIsCardNo(number)) {
                    card_no = number;
                } else {
                    ToastUtil.showToast("请正确输入会员卡号或者手机号");
                    return;
                }*/
            }
        }else {
            mobile = "";
            card_no = "";
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
        KeyboardManager.hideSoftInput(etSearch.getEditText());
    }



}
