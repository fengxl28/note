package com.mwee.android.pos.business.dinner;

import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.order.OrderManager;
import com.mwee.android.pos.business.orderdishes.constant.OrderDishesJumpFlagDefined;
import com.mwee.android.pos.business.orderdishes.view.DishCache;
import com.mwee.android.pos.business.orderdishes.view.jump.JumpFlag;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2017/4/27.
 */

public class DinnerOrderDishesJump {
    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, TempOrderDishesCache tempOrder, JumpFlag jumpFlag) {
        DinnerFoodOrderFragment fragment = new DinnerFoodOrderFragment();
        DishCache dishCache = new DishCache();
        dishCache.orderDishesCache = tempOrder;
        dishCache.initSelectUnitQuantity();//计算点菜规格数量
        fragment.setParam(dishCache, jumpFlag);
        FragmentController.addFragmentWithHide(parentHost.getFragmentManagerWithinHost(), fragment, fragment.TAG, main_menufragment, false);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, OrderCache orderCache, JumpFlag jumpFlag) {
        showOrderDishesContainer(parentHost, main_menufragment, orderCache, false, 0, jumpFlag);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, OrderCache orderCache, BigDecimal amtPrePay, JumpFlag jumpFlag) {
        showOrderDishesContainer(parentHost, main_menufragment, orderCache, false, 0, amtPrePay, jumpFlag);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, OrderCache orderCache, boolean isShowAgreeRapid, int msgId, JumpFlag jumpFlag) {
        showOrderDishesContainer(parentHost, main_menufragment, orderCache, isShowAgreeRapid, msgId, BigDecimal.ZERO, jumpFlag);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, OrderCache orderCache, boolean isShowAgreeRapid, int msgId, BigDecimal amtPrePay, JumpFlag jumpFlag) {
        DinnerFoodOrderFragment fragment = new DinnerFoodOrderFragment();
        DishCache dishCache = new DishCache();
        dishCache.order = orderCache;
        dishCache.orderDishesCache = OrderManager.buildTempOrder();
        dishCache.orderDishesCache.fsmareaid = orderCache.fsmareaid;
        dishCache.orderDishesCache.fsmtableid = orderCache.fsmtableid;
        dishCache.orderDishesCache.fsmtablename = orderCache.fsmtablename;
        dishCache.orderDishesCache.diningStandardAmt = orderCache.diningStandardAmt;
        dishCache.orderDishesCache.minStandardAmt = orderCache.minStandardAmt;
        if (jumpFlag.jumpFrom == OrderDishesJumpFlagDefined.JumpFrom.ANTI_PAY) {
            dishCache.antiPay = true;
        }
        dishCache.initSelectUnitQuantity();//计算点菜规格数量
        fragment.setParam(dishCache, isShowAgreeRapid, msgId, jumpFlag);
        fragment.mPrePayAmt = amtPrePay;
        FragmentController.addFragmentWithHide(parentHost.getFragmentManagerWithinHost(), fragment, fragment.TAG, main_menufragment, false);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, TempOrderDishesCache tempOrder, OrderCache orderCache, JumpFlag jumpFlag) {
        showOrderDishesContainer(parentHost, main_menufragment, tempOrder, orderCache, BigDecimal.ZERO, jumpFlag);
    }

    public static void showOrderDishesContainer(Host parentHost, int main_menufragment, TempOrderDishesCache tempOrder, OrderCache orderCache, BigDecimal amtPrePay, JumpFlag jumpFlag) {
        DinnerFoodOrderFragment fragment = new DinnerFoodOrderFragment();
        DishCache dishCache = new DishCache();
        dishCache.orderDishesCache = tempOrder;
        dishCache.orderDishesCache.diningStandardAmt = orderCache.diningStandardAmt;
        dishCache.orderDishesCache.minStandardAmt = orderCache.minStandardAmt;
        dishCache.order = orderCache;
        if (jumpFlag.jumpFrom == OrderDishesJumpFlagDefined.JumpFrom.ANTI_PAY) {
            dishCache.antiPay = true;
        }
        dishCache.initSelectUnitQuantity();//计算点菜规格数量
        fragment.setParam(dishCache, jumpFlag);
        fragment.mPrePayAmt = amtPrePay;
        FragmentController.addFragmentWithHide(parentHost.getFragmentManagerWithinHost(), fragment, fragment.TAG, main_menufragment, false);
    }

}
