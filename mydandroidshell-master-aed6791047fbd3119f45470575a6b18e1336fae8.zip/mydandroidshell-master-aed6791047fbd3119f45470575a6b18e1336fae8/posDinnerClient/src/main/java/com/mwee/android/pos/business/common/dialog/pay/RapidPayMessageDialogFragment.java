package com.mwee.android.pos.business.common.dialog.pay;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.dinner.DinnerOrderDishesJump;
import com.mwee.android.pos.business.orderdishes.constant.OrderDishesJumpFlagDefined;
import com.mwee.android.pos.business.orderdishes.view.jump.JumpFlag;
import com.mwee.android.pos.business.rapid.api.bean.IgnoreRapidOnlyPayOrderResponse;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.message.PayConfirmBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DensityUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.DotView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/9/6.
 */

public class RapidPayMessageDialogFragment extends BaseDialogFragment {
    private ArrayList<PayConfirmBean> modules = new ArrayList<>();
    private MessagePageAdapter adapter;
    private ViewPager viewpager;
    private RapidPayMessageProcessor mProcessor;
    private DotView mDotView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_message_rapid_pay_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view) {
        mDotView = (DotView) view.findViewById(R.id.mDotView);
        viewpager = (ViewPager) view.findViewById(R.id.viewpager);
        viewpager.setPageMargin(DensityUtil.dip2px(getContext(), 50));
        //将root 布局的滑动⌚️交给viewpager进行处理
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return viewpager.dispatchTouchEvent(event);
            }
        });
        adapter = new MessagePageAdapter();
        viewpager.setAdapter(adapter);
        mProcessor = new RapidPayMessageProcessor();
        viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mDotView.notifyDataChanged(position, modules.size());
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        if (modules.size() > 1) {
            mDotView.setVisibility(View.VISIBLE);
            mDotView.notifyDataChanged(0, modules.size());
        } else {
            mDotView.setVisibility(View.GONE);
        }
    }

    public void setData(List<PayConfirmBean> data) {
        modules.addAll(data);
    }

    class MessagePageAdapter extends PagerAdapter implements View.OnClickListener {

        @Override
        public int getCount() {
            return modules.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_message_rapid_pay_dialog_item, container, false);
            TextView mMessageTitleLabel = (TextView) view.findViewById(R.id.mMessageTitleLabel);
            TextView mMessageContentLabel = (TextView) view.findViewById(R.id.mMessageContentLabel);
            Button mMessageCloseBtn = (Button) view.findViewById(R.id.mMessageCloseBtn);
            Button mMessageAllowBtn = (Button) view.findViewById(R.id.mMessageAllowBtn);
            Button mMessageOpenTableBtn = (Button) view.findViewById(R.id.mMessageOpenTableBtn);
            mMessageAllowBtn.setOnClickListener(this);
            mMessageCloseBtn.setOnClickListener(this);
            mMessageOpenTableBtn.setOnClickListener(this);
            mMessageAllowBtn.setTag(position);
            mMessageCloseBtn.setTag(position);
            mMessageOpenTableBtn.setTag(position);
            PayConfirmBean bean = modules.get(position);
            mMessageTitleLabel.setText(String.format(getString(R.string.rapid_pay_message_title), bean.tableName()));
            mMessageContentLabel.setText(String.format(getString(R.string.rapid_pay_message_content), bean.tableName()));
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public void onClick(View v) {
            final int position = (int) v.getTag();
            final PayConfirmBean bean = modules.get(position);
            final Progress progress;
            switch (v.getId()) {
                case R.id.mMessageCloseBtn:
                    progress = ProgressManager.showProgressUncancel(RapidPayMessageDialogFragment.this, R.string.progress_loading);
                    mProcessor.ignoreRapidConfirmMessage(bean.msgId, new SocketCallback<IgnoreRapidOnlyPayOrderResponse>() {
                        @Override
                        public void callback(SocketResponse<IgnoreRapidOnlyPayOrderResponse> response) {
                            progress.dismiss();
                            if (response !=null) {
                                if (response.success()) {
                                    delete(position);
                                }
                                ToastUtil.showToast(response.message);
                            }else {
                                ToastUtil.showToast("业务异常，请重试");
                            }
                        }
                    });
                    break;
                case R.id.mMessageAllowBtn:
                    progress = ProgressManager.showProgressUncancel(RapidPayMessageDialogFragment.this, R.string.progress_loading);
                    mProcessor.allowRapidConfirmMessage(bean.msgId, new SocketCallback<IgnoreRapidOnlyPayOrderResponse>() {
                        @Override
                        public void callback(SocketResponse<IgnoreRapidOnlyPayOrderResponse> response) {
                            progress.dismiss();
                            if (response.success()) {
                                delete(position);
                            }
                            ToastUtil.showToast(response.message);
                        }
                    });
                    break;
                case R.id.mMessageOpenTableBtn:
                    progress = ProgressManager.showProgressUncancel(RapidPayMessageDialogFragment.this, R.string.progress_loading);
                    mProcessor.loadTableOrderInfo(bean.fsmtableid, new ResultCallback<OrderCache>() {
                        @Override
                        public void onSuccess(OrderCache data) {
                            progress.dismissSelf();
                            JumpFlag jumpFlag = new JumpFlag();
                            jumpFlag.jumpToIndex = OrderDishesJumpFlagDefined.JumpIndex.ORDER;
                            jumpFlag.jumpFrom = OrderDishesJumpFlagDefined.JumpFrom.TABLE;
                            DinnerOrderDishesJump.showOrderDishesContainer(RapidPayMessageDialogFragment.this, R.id.main_menufragment, data, true, bean.msgId, jumpFlag);
                            dismissSelf();
                        }

                        @Override
                        public void onFailure(int code, String msg) {
                            progress.dismissSelf();
                            DialogManager.showSingleDialog(RapidPayMessageDialogFragment.this, msg);
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    }


    public void delete(int position) {
        modules.remove(position);
        adapter.notifyDataSetChanged();
        if (modules.size() == 0) {
            dismissSelf();
        }

        if (modules.size() == 1) {
            mDotView.setVisibility(View.GONE);
        }
    }
}
