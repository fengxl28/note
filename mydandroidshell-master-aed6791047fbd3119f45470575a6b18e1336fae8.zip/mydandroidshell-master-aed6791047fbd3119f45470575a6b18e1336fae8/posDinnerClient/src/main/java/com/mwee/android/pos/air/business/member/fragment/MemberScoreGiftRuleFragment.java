package com.mwee.android.pos.air.business.member.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.mwee.android.pos.air.business.member.entity.CardSettingModel;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberResponse;
import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;

/**
 * Created by zhangmin on 2017/02/01.
 */

public class MemberScoreGiftRuleFragment extends BaseFragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private MemberEditorProcessor mMemberEditorProcessor;
    private View mMemberViewHide1;
    private View mMemberViewHide2;

    private Switch mMemberScoreSw;
    private Switch mMemberDeductionSw;
    private RadioGroup mMemberScoreGp;

    private EditText mMemberRulePriceEdt;
    private EditText mMemberRuleScoreEdt;

    private EditText mMemberRuleDeductionScoreEdt;
    private EditText mMemberRuleDeductionMoneyEdt;

    //数据源
    private CardSettingModel cardSettingModel;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_member_score_rule, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {

        mMemberRulePriceEdt = view.findViewById(R.id.mMemberRulePriceEdt);
        mMemberRuleScoreEdt = view.findViewById(R.id.mMemberRuleScoreEdt);

        mMemberViewHide1 = view.findViewById(R.id.mMemberViewHide1);
        mMemberViewHide2 = view.findViewById(R.id.mMemberViewHide2);

        //会员积分开关
        mMemberScoreSw = view.findViewById(R.id.mMemberScoreSw);
        //积分抵扣现金开关
        mMemberDeductionSw = view.findViewById(R.id.mMemberDeductionSw);

        //抵扣现金
        mMemberRuleDeductionScoreEdt = view.findViewById(R.id.mMemberRuleDeductionScoreEdt);
        //抵扣金额
        mMemberRuleDeductionMoneyEdt = view.findViewById(R.id.mMemberRuleDeductionMoneyEdt);
        //积分清零规则
        mMemberScoreGp = view.findViewById(R.id.mMemberScoreGp);

        mMemberScoreSw.setOnCheckedChangeListener(this);
        mMemberDeductionSw.setOnCheckedChangeListener(this);
        view.findViewById(R.id.mMemberScoreRuleConfirmBtn).setOnClickListener(this);
    }

    private void initData() {
        mMemberEditorProcessor = new MemberEditorProcessor();
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMemberEditorProcessor.loadShopMemberRule(new ResultCallback<AirMemberResponse>() {
            @Override
            public void onSuccess(AirMemberResponse data) {
                refreshView(data);
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


    private void refreshView(AirMemberResponse data) {

        cardSettingModel = data.data.card_setting;

        mMemberRulePriceEdt.setText(new BigDecimal(cardSettingModel.cost_money_unit).intValue() + "");
        mMemberRuleScoreEdt.setText(new BigDecimal(cardSettingModel.increase_bonus).intValue() + "");

        //crm后台没有积分抵扣现金开关按钮  根据积分抵扣比例中 每使用 积分和兑换金额 是否大于0进行判断
        if (Integer.valueOf(cardSettingModel.cost_bonus_unit) > 0 && Float.valueOf(cardSettingModel.reduce_money) > 0) {
            mMemberDeductionSw.setChecked(true);
        } else {
            mMemberDeductionSw.setChecked(false);
        }

        mMemberRuleDeductionScoreEdt.setText(new BigDecimal(cardSettingModel.cost_bonus_unit).intValue() + "");
        mMemberRuleDeductionMoneyEdt.setText(new BigDecimal(cardSettingModel.reduce_money).intValue() + "");

        if (Integer.valueOf(cardSettingModel.is_clear) == 0) {
            ((RadioButton) mMemberScoreGp.getChildAt(0)).setChecked(true);
        } else {
            if (Integer.valueOf(cardSettingModel.clear_day) == 365) {
                ((RadioButton) mMemberScoreGp.getChildAt(1)).setChecked(true);
            } else {
                ((RadioButton) mMemberScoreGp.getChildAt(2)).setChecked(true);
            }
        }
        if (Integer.valueOf(cardSettingModel.is_score) == 1) {
            mMemberScoreSw.setChecked(true);
            mMemberViewHide1.setVisibility(View.VISIBLE);
        } else {
            mMemberScoreSw.setChecked(false);
            mMemberViewHide1.setVisibility(View.GONE);
        }
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        doSave();

    }


    public void doSave() {
        /**
         *
         *   注意点
         *      1.如果会员积分开关为关 点击切换界面 直接切换 界面数据不保存
         *
         *      2.如果会员积分开关为关 点击保存 如何处理????[传什么数据给CRM]
         *
         *      3.如果会员积分开关为开 编辑以后 点击保存 会触发调用CRM接口上传数据
         *
         *      4.如果会员积分开关为开 点击切换界面 如果当前界面有编辑过 提示保存信息  如果当前界面没有编辑过 直接切换
         *
         */

        String is_score = mMemberScoreSw.isChecked() ? "1" : "0";

        String cost_money_unit = mMemberRulePriceEdt.getText().toString().trim();
        String increase_bonus = mMemberRuleScoreEdt.getText().toString().trim();

        String cost_bonus_unit = "0";
        String reduce_money = "0";

        if (mMemberDeductionSw.isChecked()) {
            cost_bonus_unit = mMemberRuleDeductionScoreEdt.getText().toString().trim();
            reduce_money = mMemberRuleDeductionMoneyEdt.getText().toString().trim();
        }

        String is_clear = "0";
        String clear_day = "";

        if (((RadioButton) mMemberScoreGp.getChildAt(0)).isChecked()) {
            is_clear = "0";
            clear_day = "";

        }
        if (((RadioButton) mMemberScoreGp.getChildAt(1)).isChecked()) {
            is_clear = "1";
            clear_day = "365";
        }
        if (((RadioButton) mMemberScoreGp.getChildAt(2)).isChecked()) {
            is_clear = "1";
            clear_day = "730";
        }

        if (mMemberScoreSw.isChecked()) {//会员积分 开关为开 点击保存

            if (TextUtils.isEmpty(cost_money_unit)) {
                ToastUtil.showToast("消费金额不能为空");
                return;
            }
            if (TextUtils.isEmpty(increase_bonus)) {
                ToastUtil.showToast("奖励积分不能为空");
                return;
            }
            if (TextUtils.isEmpty(cost_bonus_unit)) {
                ToastUtil.showToast("抵扣比例中积分不能为空");
                return;
            }
            if (TextUtils.isEmpty(reduce_money)) {
                ToastUtil.showToast("抵扣比例中金额不能为空");
                return;
            }

            if (Integer.valueOf(increase_bonus) > 0) {//当奖励金额有值，消费金额为0，点击保存，toast提示：消费金额应大于0

                if (Float.valueOf(cost_money_unit) == 0) {
                    ToastUtil.showToast("消费金额应大于0");
                    return;
                }
            }

            if (Float.valueOf(reduce_money) > 0) {//当抵扣比例中 金额不为0，积分为0时，点击保存，toast提示：抵扣比例中积分应大于0

                if (Integer.valueOf(cost_bonus_unit) == 0) {
                    ToastUtil.showToast("抵扣比例中积分应大于0");
                    return;
                }
            }
            if (Float.valueOf(cost_bonus_unit) > 0) {//当抵扣比例中 积分不为0，金额为0时，点击保存，toast提示：抵扣比例中金额应大于0

                if (Integer.valueOf(reduce_money) == 0) {
                    ToastUtil.showToast("抵扣比例中金额应大于0");
                    return;
                }
            }

        } else {
            //如果会员积分开关为关 点击保存 如何处理????[传什么数据给CRM]  按理说应该都使用0
            cost_money_unit = "0";
            increase_bonus = "0";
            cost_bonus_unit = "0";
            reduce_money = "0";
            is_clear = "0";
            clear_day = "";

        }
        loadMemberScoreGiftRuleUpdate(is_score, cost_money_unit, increase_bonus, cost_bonus_unit, reduce_money, is_clear, clear_day);
    }

    /**
     * 更新积分规则
     *
     * @param cost_money_unit
     * @param increase_bonus
     */
    private void loadMemberScoreGiftRuleUpdate(String is_score, String cost_money_unit, String increase_bonus, String cost_bonus_unit, String reduce_money, String is_clear, String clear_day) {


        final Progress progress = ProgressManager.showProgressUncancel(this, "保存中...");

        mMemberEditorProcessor.loadMemberScoreGiftRuleUpdate(is_score, cost_money_unit, increase_bonus, cost_bonus_unit, reduce_money, is_clear, clear_day, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                ToastUtil.showToast("保存成功");
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }


    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        switch (compoundButton.getId()) {
            case R.id.mMemberScoreSw:
                mMemberViewHide1.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                break;
            case R.id.mMemberDeductionSw:
                mMemberViewHide2.setVisibility(isChecked ? View.VISIBLE : View.GONE);
                break;
            default:
                break;
        }
    }


    /**
     * 校验数据源是否改变了
     * return  ture表示数据源改变了  false表示数据源没有改变
     */
    public boolean checkDataChange() {

        if (cardSettingModel == null) {
            //处理会员信息获取异常的处理
            return false;
        }
        //会员积分开关改变
        String is_score = mMemberScoreSw.isChecked() ? "1" : "0";
        if (!TextUtils.equals(is_score, cardSettingModel.is_score)) {
            return true;
        }
        //奖励规则 消费改变
        if (!TextUtils.equals(mMemberRulePriceEdt.getText().toString().trim(), new BigDecimal(cardSettingModel.cost_money_unit).intValue() + "")) {
            return true;
        }
        //奖励规则 积分改变
        if (!TextUtils.equals(mMemberRuleScoreEdt.getText().toString().trim(), new BigDecimal(cardSettingModel.increase_bonus).intValue() + "")) {
            return true;
        }
        //抵扣比例 积分改变
        if (!TextUtils.equals(mMemberRuleDeductionScoreEdt.getText().toString().trim(), new BigDecimal(cardSettingModel.cost_bonus_unit).intValue() + "")) {
            return true;
        }
        //抵扣比例 抵扣金钱改变
        if (!TextUtils.equals(mMemberRuleDeductionMoneyEdt.getText().toString().trim(), new BigDecimal(cardSettingModel.reduce_money).intValue() + "")) {
            return true;
        }

        //积分清零规则改变
        String is_clear = "0";

        if (((RadioButton) mMemberScoreGp.getChildAt(0)).isChecked()) {
            is_clear = "0";

        }
        if (((RadioButton) mMemberScoreGp.getChildAt(1)).isChecked()) {
            is_clear = "1";
        }
        if (((RadioButton) mMemberScoreGp.getChildAt(2)).isChecked()) {
            is_clear = "2";
        }
        if (!TextUtils.equals(is_clear, cardSettingModel.is_clear)) {
            return true;
        }
        return false;
    }


}
