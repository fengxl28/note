package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class MemberRechargeRecordingContainer extends BusinessBean {

    public String total;

    public int page_count;

    //充值总金额
    public String total_amount;

    //充值实收总额
    public String total_reality_amount;

    //赠送总金额
    public String total_present_moeny;

    //赠送总积分
    public String total_score;





    public List<MemberRechargeRecordingModel> list = new ArrayList<>();


}
