package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.db.business.order.OrderMemberInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;

/**
 * 会员信息展示及解除关联页
 */
public class NewMemberOrderUnBindDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private ImageView iv_close;
    private TextView tv_unbind_member_card;
    private TextView tv_switch_member_card;
    private TextView tv_member_super;
    private TextView tv_member_level_name;
    private TextView tv_member_level;
    private ImageView iv_member_card_default_flag;
    private TextView tv_member_info_user_name;
    private TextView tv_member_info_birthday;
    private TextView tv_member_info_gender;
    private TextView tv_member_info_mobile;
    private TextView tv_member_info_level_name;
    private TextView tv_member_info_card_no;
    private String mOrderId;
    private OrderMemberInfo mMemberInfo;
    private NewMemberCheckCallBack mCallback;
    private OnMemberInfoListener mListener;

    public interface OnMemberInfoListener {
        void onUnbindMember();
    }

    public static NewMemberOrderUnBindDialogFragment getInstance(OrderMemberInfo memberInfoS) {
        NewMemberOrderUnBindDialogFragment fragment = new NewMemberOrderUnBindDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable("member", memberInfoS);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_new_member_order_unbind, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        if (getArguments() != null) {
            mMemberInfo = (OrderMemberInfo) getArguments().getSerializable("member");
            if (mMemberInfo != null) {
                refreshMemberInfo();
            }
        }
    }

    private void initView(View view) {
        iv_close = view.findViewById(R.id.iv_close);
        tv_unbind_member_card = view.findViewById(R.id.tv_unbind_member_card);
        tv_switch_member_card = view.findViewById(R.id.tv_switch_member_card);

        tv_member_super = view.findViewById(R.id.tv_member_super);
        tv_member_level_name = view.findViewById(R.id.tv_member_level_name);
        tv_member_level = view.findViewById(R.id.tv_member_level);
        iv_member_card_default_flag = view.findViewById(R.id.iv_member_card_default_flag);
        tv_member_info_user_name = view.findViewById(R.id.tv_member_info_user_name);
        tv_member_info_birthday = view.findViewById(R.id.tv_member_info_birthday);
        tv_member_info_gender = view.findViewById(R.id.tv_member_info_gender);
        tv_member_info_mobile = view.findViewById(R.id.tv_member_info_mobile);
        tv_member_info_level_name = view.findViewById(R.id.tv_member_info_level_name);
        tv_member_info_card_no = view.findViewById(R.id.tv_member_info_card_no);

        iv_close.setOnClickListener(this);
        tv_unbind_member_card.setOnClickListener(this);
        tv_switch_member_card.setOnClickListener(this);
    }

    private void refreshMemberInfo() {
        if (mMemberInfo == null) {
            return;
        }

        tv_switch_member_card.setVisibility(mMemberInfo.cardSize > 1 ? View.VISIBLE : View.GONE);

        // 卡类型,0 品牌卡；1 区域卡
        if (mMemberInfo.bindType == 1) {
            tv_member_level_name.setText(mMemberInfo.csName);
        } else {
            tv_member_level_name.setText(mMemberInfo.level_name);
        }
        tv_member_level.setText("v" + mMemberInfo.level);
        tv_member_level.setVisibility(View.GONE);
        tv_member_info_user_name.setText(mMemberInfo.real_name);
        tv_member_info_birthday.setText(mMemberInfo.birthday);
        tv_member_info_gender.setText(mMemberInfo.optGender());
        tv_member_info_mobile.setText(mMemberInfo.mobile);
        tv_member_info_level_name.setText(mMemberInfo.level_name);
        tv_member_info_card_no.setText(mMemberInfo.card_no);
        if (mMemberInfo.isPlusCard) { // 是黑卡
            tv_member_super.setVisibility(View.VISIBLE);
            tv_member_super.setText(mMemberInfo.plusName);
        } else {
            tv_member_super.setVisibility(View.INVISIBLE);
        }
        // 默认卡
        iv_member_card_default_flag.setVisibility(mMemberInfo.isDefaultCard == 1 ? View.VISIBLE : View.GONE);
    }

    public void setParams(String orderId, NewMemberCheckCallBack callback, OnMemberInfoListener listener) {
        mOrderId = orderId;
        mCallback = callback;
        mListener = listener;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void onClick(View view) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.iv_close: // 关闭
                dismissSelf();
                break;
            case R.id.tv_switch_member_card: // 切换卡
                RunTimeLog.addLog(RunTimeLog.MEMBER, "切换会员卡, orderId=" + mOrderId);
                Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
                new MemberProcess().optMemberInfoWithoutVerify(mMemberInfo.mobile, new ResultCallback<NewQueryMemberListResponse>() {
                    @Override
                    public void onSuccess(NewQueryMemberListResponse data) {
                        if (progress != null) {
                            progress.dismiss();
                        }
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->card size=" + data.cardList.size() + ", orderId=" + mOrderId);
                        if (data.bindResponse != null) {
                            if (mCallback != null) {
                                mCallback.call(data.bindResponse);
                            }
                            dismiss();
                            return;
                        }
                        MemberCardListChooseFragment fragment = new MemberCardListChooseFragment();
                        fragment.setParams(data.cardList, mOrderId, mMemberInfo.card_no, mCallback);
                        DialogManager.showCustomDialog(getActivityWithinHost(), fragment, fragment.getTag());
                        dismiss();
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        if (progress != null) {
                            progress.dismiss();
                        }
                        ToastUtil.showToast(msg);
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询failure code=" + code + " msg=" + msg + ", orderId=" + mOrderId);
                    }
                });
                break;
            case R.id.tv_unbind_member_card: // 解除关联
                RunTimeLog.addLog(RunTimeLog.MEMBER, "解除关联会员卡, orderId=" + mOrderId);
                if (mListener != null) {
                    mListener.onUnbindMember();
                }
                dismiss();
                break;
        }
    }
}
