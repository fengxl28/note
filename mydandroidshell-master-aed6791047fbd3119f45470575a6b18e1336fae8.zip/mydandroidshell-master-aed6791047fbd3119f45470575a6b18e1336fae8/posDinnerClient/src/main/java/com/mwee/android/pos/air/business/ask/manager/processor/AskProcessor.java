package com.mwee.android.pos.air.business.ask.manager.processor;

import com.mwee.android.air.connect.business.ask.GetAllAskGPAndAskResponse;
import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.air.business.ask.manager.api.AirAskApi;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by qinwei on 2017/10/10.
 */

public class AskProcessor {

    public ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoList = new ArrayList<>();
    public ArrayList<AirAskGroupManagerInfo> airAskGroupManagerInfoWhisOutAllList = new ArrayList<>();
    public ArrayList<AirAskManageInfo> airAskManageInfoList = new ArrayList<>();
    public ArrayList<AirAskManageInfo> airAskManageInfoToShowList = new ArrayList<>();
    public HashMap<String, List<AirAskManageInfo>> allAskMap = new HashMap<>();

    public void optAllAsk(final IResult iResult) {
        AirAskApi.optAllAsk(new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    /**
     * 去出'全部'要求
     */
    private void filterArea() {
        airAskGroupManagerInfoWhisOutAllList.clear();
        airAskGroupManagerInfoWhisOutAllList.addAll(airAskGroupManagerInfoList);
        if (airAskGroupManagerInfoWhisOutAllList.size() > 0) {
            AirAskGroupManagerInfo airAskGroupManagerInfo = airAskGroupManagerInfoWhisOutAllList.get(0);
            if (android.text.TextUtils.equals(airAskGroupManagerInfo.fsAskGpId, "")) {
                airAskGroupManagerInfoWhisOutAllList.remove(0);
            }
        }
    }

    /**
     * 将要求分组
     */
    private void filterAsk() {
        allAskMap.clear();

        for (AirAskManageInfo airAskManageInfo : airAskManageInfoList) {
            List<AirAskManageInfo> airAskManageInfos = allAskMap.get(airAskManageInfo.fsAskGpId);
            if (airAskManageInfos == null) {
                airAskManageInfos = new ArrayList<>();
                allAskMap.put(airAskManageInfo.fsAskGpId, airAskManageInfos);
            }
            airAskManageInfos.add(airAskManageInfo);
        }

    }


    /**
     * 更改选中区域
     *
     * @param fsAskGpId
     */
    public void selectAskGroup(String fsAskGpId) {

        airAskManageInfoToShowList.clear();

        if (android.text.TextUtils.isEmpty(fsAskGpId)) {
            airAskManageInfoToShowList.addAll(airAskManageInfoList);
            return;
        }

        List<AirAskManageInfo> airAskManageInfos = allAskMap.get(fsAskGpId);
        if (!ListUtil.isEmpty(airAskManageInfos)) {
            airAskManageInfoToShowList.addAll(airAskManageInfos);
        }
    }

    public void doDeleteAskGp(String fsaskgpId, final IResult iResult) {
        AirAskApi.doDeleteAskGp(fsaskgpId, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    public void doUpdateAskGp(String fsaskgpId, String fsaskGpName, boolean all, List<String> menuClsIdList, final IResult iResult) {
        AirAskApi.doUpdateAskGp(fsaskgpId, fsaskGpName, all, menuClsIdList, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    public void doAddAskGp(String fsaskGpName, boolean all, List<String> menuClsIdList, final IResult iResult) {
        AirAskApi.doAddAskGp(fsaskGpName, all, menuClsIdList, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    /**
     * 更新要求
     *
     * @param fsaskName
     * @param iResult
     */
    public void updateAsk(String fsaskId, String fsaskName, BigDecimal price, String askGpId, final IResult iResult) {
        AirAskApi.updateAsk(fsaskId, fsaskName, price, askGpId, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    /**
     * 新增要求
     *
     * @param fsaskName
     * @param iResult
     */
    public void addAsk(String fsaskName, BigDecimal price, String askGpId, final IResult iResult) {
        AirAskApi.addAsk(fsaskName, price, askGpId, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    /**
     * 批量删除要求
     *
     * @param askIdLsit
     * @param iResult
     */
    public void batcheDeleteAsk(List<String> askIdLsit, final IResult iResult) {
        AirAskApi.batcheDeleteAsk(askIdLsit, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });

    }

    /**
     * 获取菜品的要求
     *
     * @param fiItemCd
     * @param iResult
     */
    public void optNoteList(String fiItemCd, String fsMenuClsId, final IResponse<List<NoteModel>> iResult) {
        AirAskApi.optNoteList(fiItemCd, fsMenuClsId, iResult);

    }

    /**
     * 生成一个默认的要求
     *
     * @return
     */
    public NoteItemModel optDefaultNoteItemModel(String groupID) {
        NoteItemModel noteItemModel = new NoteItemModel();
        noteItemModel.groupIDFather = groupID;
        noteItemModel.id = "-1000";
        return noteItemModel;
    }

    public void loadAskGroupToTop(String currentAskGpId, final IResult iResult) {
        AirAskApi.loadAskGroupToTop(currentAskGpId, new IResponse<GetAllAskGPAndAskResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, GetAllAskGPAndAskResponse info) {
                if (result) {
                    airAskGroupManagerInfoList.clear();
                    airAskGroupManagerInfoList.addAll(info.airAskGroupManagerInfos);
                    airAskManageInfoList.clear();
                    airAskManageInfoList.addAll(info.airAskManageInfos);
                    filterAsk();
                    filterArea();
                }
                if (iResult != null) {
                    iResult.callBack(result, msg);
                }
            }
        });
    }
}
