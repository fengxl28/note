package com.mwee.android.pos.air.business.menu.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.air.business.menu.processor.MenuPackageProcessor;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;

/**
 * Created by zhangmin on 2017/12/19
 */
public class MenuPackageSetSideEditorDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private EditText mMenuPackageNameEdt;
    private Button mMenuPackageCancelBtn;
    private Button mMenuPackageConfirmBtn;
    private MenuPackageProcessor mMenuPackageProcessor;
    private OnMenuPackageSetSideAddListener listener;

    private MenuItemBean menuItemBean;//套餐菜品
    private MenuPackageSetSideBean menuPackageSetSideBean;//套餐分组明细
    private TextView mAskEditorTitleLabel;
    //添加模式
    public final static int ADD_MODEL = 1;
    //编辑模式
    public final static int EDITOR_MODEL = 2;
    //当前运行的模式
    private int currentModel = 1;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_menu_package_setside_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {

        mAskEditorTitleLabel = view.findViewById(R.id.mAskEditorTitleLabel);
        mMenuPackageNameEdt = view.findViewById(R.id.mMenuPackageNameEdt);

        mMenuPackageCancelBtn = view.findViewById(R.id.mMenuPackageCancelBtn);
        mMenuPackageConfirmBtn = view.findViewById(R.id.mMenuPackageConfirmBtn);

        mMenuPackageCancelBtn.setOnClickListener(this);
        mMenuPackageConfirmBtn.setOnClickListener(this);
    }

    private void initData() {
        mMenuPackageProcessor = new MenuPackageProcessor();

        if (currentModel == EDITOR_MODEL) {
            mAskEditorTitleLabel.setText("编辑分组");
            mMenuPackageNameEdt.setText(menuPackageSetSideBean.fsSetFoodName);
        } else {
            mAskEditorTitleLabel.setText("添加分组");
        }

    }

    public void setMenuItemBean(MenuItemBean menuItemBean) {
        this.menuItemBean = menuItemBean;
    }

    public void setMenuPackageSetSideBean(MenuPackageSetSideBean menuPackageSetSideBean) {
        this.menuPackageSetSideBean = menuPackageSetSideBean;
    }


    public void setModel(int currentModel) {
        this.currentModel = currentModel;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mMenuPackageCancelBtn:
                dismissSelf();
                break;
            case R.id.mMenuPackageConfirmBtn:
                String mPackageSetSideName = mMenuPackageNameEdt.getText().toString().trim();
                if (!check(mPackageSetSideName)) {
                    return;
                }

                if (currentModel == EDITOR_MODEL) {
                    doEditor(mPackageSetSideName);
                } else {
                    doAdd(mPackageSetSideName);
                }

                break;
            default:
                break;
        }
    }

    /**
     * 添加一条套餐分组
     *
     * @param mPackageSetSideName
     */
    private void doAdd(String mPackageSetSideName) {
        ArrayList<MenuPackageSetSideBean> beans = new ArrayList<>();
        beans.add(buildMenuPackageSetSideBean(mPackageSetSideName));
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMenuPackageProcessor.loadUpdatePackageMenu(menuItemBean.fiItemCd, menuItemBean.fsItemName, menuItemBean.fdSalePrice + "", beans, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                listener.onMenuPackageSetSideAddSuccess();
                dismissSelf();

            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    /**
     * 编辑套餐分组
     */
    private void doEditor(String mPackageSetSideName) {

        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        ArrayList<MenuPackageSetSideBean> beans = new ArrayList<>();
        menuPackageSetSideBean.fsSetFoodName = mPackageSetSideName;
        beans.add(menuPackageSetSideBean);
        mMenuPackageProcessor.loadUpdatePackageMenu(menuItemBean.fiItemCd, menuItemBean.fsItemName, menuItemBean.fdSalePrice + "", beans, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                ToastUtil.showToast(data);
                progress.dismissSelf();
                listener.onMenuPackageSetSideEditorSuccess();
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });


    }


    /**
     * 构建一组套餐分组数据
     *
     * @param mPackageSetSideName
     */
    private MenuPackageSetSideBean buildMenuPackageSetSideBean(String mPackageSetSideName) {

        MenuPackageSetSideBean side = new MenuPackageSetSideBean();
        side.fiItemCd_M = menuItemBean.fiItemCd;
        side.fiSetFoodCd = "-1";//新增套餐组标示
        side.fsSetFoodName = mPackageSetSideName;
        side.fiSetFoodQty = 1;
        side.fiSetFoodType = 1;
        side.fiIsRequired = 1;//是否必选项目;0/1
        side.fiSortOrder = 88;
        side.fiStatus = 1;
        side.choiceMenuItems = null;
        return side;

    }


    private boolean check(String name) {
        if (!TextUtils.validate(name)) {
            ToastUtil.showToast("请输入套餐分组名称！");
            return false;
        } else if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("套餐分组名称输入非法！");
            return false;
        }
        return true;
    }

    public void setOnMenuPackageAddListener(OnMenuPackageSetSideAddListener listener) {
        this.listener = listener;
    }

    public interface OnMenuPackageSetSideAddListener {

        void onMenuPackageSetSideAddSuccess();

        void onMenuPackageSetSideEditorSuccess();
    }

}
