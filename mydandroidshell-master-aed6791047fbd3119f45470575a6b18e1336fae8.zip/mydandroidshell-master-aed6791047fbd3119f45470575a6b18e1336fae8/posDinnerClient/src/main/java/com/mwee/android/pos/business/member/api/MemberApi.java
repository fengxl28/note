package com.mwee.android.pos.business.member.api;

import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.business.member.MemberSendCodeForMobilePayRequest;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.business.member.entity.MemberHistoryResponse;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.MemberBalanceChangedListRequest;
import com.mwee.android.pos.business.member.MemberCouponRequest;
import com.mwee.android.pos.business.member.MemberRechargePayTypeDefined;
import com.mwee.android.pos.business.member.MemberSendCodeRequest;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.component.member.net.GetMemberRechargeOrderRequest;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageRequest;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageResponse;
import com.mwee.android.pos.component.member.net.MemberPackageContainer2;
import com.mwee.android.pos.component.member.net.NewMemberChargeOnlineRequest;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.bean.NewMemberRechargResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CMember;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.util.ClientHardwareUtil;
import com.mwee.android.pos.util.TextUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * MemberApi
 * Created by chris on 16/8/10.
 */
public class MemberApi {

    /**
     * 会员充值-网络支付
     *
     * @param ruleID   int | 充值规则的ID
     * @param amount   BigDecimal | 待充值金额
     * @param pay_code String | 卡号pay_code 支付码 加密卡号
     * @param payType  int | 1微信,2支付宝
     * @param micro    String | 扫描出来的码
     * @param callback IExecutorCallback
     */
    public static void sendOnlineRechargeRequestV2(int ruleID, BigDecimal amount, String pay_code, int payType, String micro, String cardNo, ResultCallback<QueryNewMembeChargeResultModel> callback) {
        MCon.c(COrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (callback != null) {
                    if (response != null && response.code == SocketResultCode.SUCCESS) {

                        if (response.data != null) {
                            NewMemberRechargResponse newMemberRechargResponse = (NewMemberRechargResponse) response.data;
                            //0支付中1成功2失败
                            if (newMemberRechargResponse.status == 2) {
                                callback.onFailure(newMemberRechargResponse.status, newMemberRechargResponse.msg);
                            } else {
                                callback.onSuccess(newMemberRechargResponse.queryNewMembeChargeResultModel);
                            }
                        } else {
                            callback.onFailure(2, "充值失败");
                        }
                    } else {
                        callback.onFailure(2, "充值失败");
                    }
                }

            }
        }).sendOnlineRechargeRequest(ruleID, amount, pay_code, payType, micro, cardNo);
    }

    /**
     * 查询会员充值结果
     *
     * @param tradeNo  int | 交易号
     * @param callback IExecutorCallback
     */
    public static void queryOnlineRechargeRequest(String tradeNo, ResultCallback<QueryNewMembeChargeResultModel> callback) {
        MCon.c(COrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (callback != null) {
                    if (response != null && response.code == SocketResultCode.SUCCESS) {

                        if (response.data != null) {
                            NewMemberRechargResponse newMemberRechargResponse = (NewMemberRechargResponse) response.data;
                            //0支付中1成功2失败
                            if (newMemberRechargResponse.status == 2) {
                                callback.onFailure(newMemberRechargResponse.status, newMemberRechargResponse.msg);
                            } else {
                                callback.onSuccess(newMemberRechargResponse.queryNewMembeChargeResultModel);
                            }
                        } else {
                            callback.onFailure(2, "充值失败");
                        }

                    } else {
                        callback.onFailure(2, "充值失败");
                    }
                }

            }
        }).queryOnlineRechargeRequest(tradeNo);
    }

    /**
     * 会员充值-现金支付
     *
     * @param ruleID   int | 充值规则的ID
     * @param amount   BigDecimal | 待充值金额
     * @param pay_code String | 卡号pay_code 支付码 加密卡号
     * @param callback IExecutorCallback
     */
    public static void sendCashRechargeRequestV2(int ruleID, BigDecimal amount, String pay_code, String cardNo, IExecutorCallback callback) {

        NewMemberChargeOnlineRequest request = new NewMemberChargeOnlineRequest();
        request.pay_price = Calc.format(amount, 0, RoundingMode.DOWN).intValue();
        request.card_no = cardNo;
        request.pay_code = pay_code;
        request.rule_id = ruleID;
        request.pay_type = MemberRechargePayTypeDefined.PayTypeDefined.CASH;

        request.paysourceid = 161;
        request.pay_name = "Android-" + AppCache.getInstance().shop.fsShopName;
        request.device_id = ClientHardwareUtil.getHardWareSymbol();
        BusinessExecutor.execute(request, callback);
    }

    /**
     * 第三方会员卡号与美味会员卡号绑定---已废弃
     *
     * @param thirdNumber 第三方会员卡号
     * @param mwNumber    美味会员卡号号
     * @param iResult
     */
    @Deprecated
    public static void thirdMemberBind(String thirdNumber, String mwNumber, final IResult iResult) {
        MCon.c(COrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null && response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, "开卡成功");
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, TextUtils.validate(response.message) ? response.message : "开卡失败，请重试");
                    }
                }
            }
        }).thirdMemberBind(thirdNumber, mwNumber);
    }

    /**
     * 会员开卡：支持第三方卡与会员实体卡
     *
     * @param cardType       卡类型 0：虚拟卡； 1：手机号激活； 2：不记名激活
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @param nameValue        姓名
     * @param sex              性别
     * @param birthdayValue    生日
     */
    public static void memberBindCard(String cardType, String cardNumber, String phone,
                                      String verificationCode, String nameValue,
                                      int sex, String birthdayValue, final IResult iResult) {
        MCon.c(COrder.class, new SocketCallback<BaseSocketResponse>() {
            @Override
            public void callback(SocketResponse<BaseSocketResponse> response) {
                if (response != null && response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, TextUtils.validate(response.message) ? response.message : "开卡成功");
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, (response != null && TextUtils.validate(response.message)) ? response.message : "开卡失败，请重试");
                    }
                }
            }
        }).memberBindCard(cardType, cardNumber, phone, verificationCode, nameValue, sex, birthdayValue);
    }

    /**
     * 通知业务中心查询会员信息
     *
     * @param number  会员卡号、手机号
     * @param iResult
     */
    public static void quaryMemberInfo(String number, final IResponse<QueryMemberInfoResponse> iResult) {
        MCon.c(COrder.class, new SocketCallback<QueryMemberInfoResponse>() {
            @Override
            public void callback(SocketResponse<QueryMemberInfoResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).queryMemberInfo(number);
    }

    /**
     * 查询并绑定会员信息
     *
     * @param number  会员卡号、手机号
     * @param orderId 订单号
     * @param iResult
     */
    public static void queryAndBindMemberToOrder(String number, String orderId, boolean isUsedMemberPrice, final IResponse<QueryMemberInfoAndBindToOrderResponse> iResult) {
        MCon.c(COrder.class, new SocketCallback<QueryMemberInfoAndBindToOrderResponse>() {
            @Override
            public void callback(SocketResponse<QueryMemberInfoAndBindToOrderResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).queryAndBindMemberToOrder(orderId, number, isUsedMemberPrice);
    }

    public static void queryAndBindMemberToOrder(String number, String code, String orderId, boolean isUsedMemberPrice, final IResponse<QueryMemberInfoAndBindToOrderResponse> iResult) {
        MCon.c(COrder.class, new SocketCallback<QueryMemberInfoAndBindToOrderResponse>() {
            @Override
            public void callback(SocketResponse<QueryMemberInfoAndBindToOrderResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).queryAndBindMemberToOrder(orderId, number, code, isUsedMemberPrice);
    }

    /**
     * 仅查询会员信息
     *
     * @param number  会员卡号、手机号
     * @param iResult
     */
    public static void onlyQuaryMemberInfo(String number, final IResponse<QueryMemberInfoResponse> iResult) {
        quaryMemberInfo(number, iResult);
    }


    public static void unBindMemberInfoFromOrder(String orderId, String cardNo, final ResultCallback<ChangeOrderWithMemberResponse> callback) {
        MCon.c(COrder.class, new SocketCallback<ChangeOrderWithMemberResponse>() {
            @Override
            public void callback(SocketResponse<ChangeOrderWithMemberResponse> response) {
                if (response == null) {
                    callback.onFailure(SocketResultCode.EXCEPTION, "业务异常，请重试");
                    return;
                }

                if (response.success()) {
                    if (callback != null) {
                        callback.onSuccess(response.data);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }
        }).orderUnBindMenberInfo(orderId, cardNo);

    }


    public static void loadMemberRechargePackage(String csID, SocketCallback<GetMemberRechargePackageResponse> callback) {
        MCon.c(CMember.class, callback).loadMemberRechargePackage(csID, "2.0");
    }


    public static void loadMemberRechargeOrder(String tradeNo, SocketCallback<MemberRechargeOrderModel> callback) {
        MCon.c(CMember.class, callback).loadMemberRechargeOrder(tradeNo);
    }

    /**
     * 获取会员储值交易记录
     *
     * @param cardNo 会员卡号
     * @param lastID 最后一条记录id
     * @param limit  每页记录数
     */
    public static void loadMemberBalanceChangedData(String cardNo, String lastID, int limit, SocketCallback<BalanceOrderList> callback) {
        MCon.c(CMember.class, callback).loadMemberBalanceChangedData(cardNo, lastID, limit);
    }

    /**
     * 获取会员历史积分
     *
     * @param cardNo String | 会员卡号
     * @param lastID int | 最后一条记录id
     */
    public static void loadMemberHistoryScore(String cardNo, int lastID, SocketCallback<MemberHistoryResponse> callback) {
        MCon.c(CMember.class, callback).loadMemberHistoryScore(cardNo, lastID);
    }

    /**
     * 获取优惠券列表
     */
    public static void loadMemberCoupons(String cardNo, int page, int pageSize, SocketCallback<MemberCouponResponse> callback) {
        String shopID = AppCache.getInstance().shop.fsShopId;
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CMember.class, callback).loadMemberCoupons(shopID, mShopID, cardNo, page, pageSize);
    }

    /**
     * 获取验证码---开卡
     * @param mobile
     * @param iExecutorCallback
     */
    public static void loadSendMobileForMobilePayCode(String mobile, IExecutorCallback iExecutorCallback) {
        MemberSendCodeRequest request = new MemberSendCodeRequest();
        request.mobile = mobile;
        request.m_shopid = Integer.valueOf(AppCache.getInstance().shop.fsCompanyGUID);
        request.brandId = Integer.valueOf(AppCache.getInstance().shop.fsCompanyGUID);
        request.device_id = ClientHardwareUtil.getHardWareSymbol();
        BusinessExecutor.execute(request, iExecutorCallback);
    }

    /**
     * 获取验证码---手机消费
     * @param mobile
     * @param iExecutorCallback
     */
    public static void loadSendMobileCode(String mobile, IExecutorCallback iExecutorCallback) {
        MemberSendCodeForMobilePayRequest request = new MemberSendCodeForMobilePayRequest();
        request.mobile = mobile;
        request.m_shopid = Integer.valueOf(AppCache.getInstance().shop.fsCompanyGUID);
        request.brandId = Integer.valueOf(AppCache.getInstance().shop.fsCompanyGUID);
        request.device_id = ClientHardwareUtil.getHardWareSymbol();
        BusinessExecutor.execute(request, iExecutorCallback);
    }

    public static void loadMemberConfig(SocketCallback<MemberConfig> callback) {
        String shopID = AppCache.getInstance().shop.fsShopId;
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CMember.class, callback).loadMemberConfig(shopID, mShopID);
    }
}
