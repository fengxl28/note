package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.RadioButton;

import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.view.widget.MemberCardView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 点菜 关联会员->会员卡列表选择
 */
public class MemberCardListChooseFragment extends BaseDialogFragment implements View.OnClickListener {

    private GridView gv_member_card_list;
    private String mOrderId;
    private List<NewMemberCardListItemModel> mMemberCardList = new ArrayList<>();
    private NewMemberCheckCallBack mCallBack;
    private CommonAdapter<NewMemberCardListItemModel> mAdapter;
    private int selectPosition = 0;
    private String mBindingCardNo;// 订单当前绑定的卡号，用来初始化选中位置，用户点击其他卡时清空

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_card_list_choose, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.content).setOnClickListener(null);
        initView(view);
    }

    private void initView(View view) {
        view.findViewById(R.id.tv_confirm).setOnClickListener(this);
        gv_member_card_list = view.findViewById(R.id.gv_member_card_list);
        mAdapter = new CommonAdapter<NewMemberCardListItemModel>(getContext(), mMemberCardList, R.layout.item_member_card_choose) {
            @Override
            public void convert(ViewHolder viewHolder, NewMemberCardListItemModel data, int position) {
                ((MemberCardView) viewHolder.getView(R.id.v_member_card)).setMember(data);
                RadioButton rb_member_card_choose = viewHolder.getView(R.id.rb_member_card_choose);
                if (!TextUtils.isEmpty(mBindingCardNo)) {
                    rb_member_card_choose.setChecked(TextUtils.equals(mBindingCardNo, data.cardNo));
                } else {
                    rb_member_card_choose.setChecked(position == selectPosition);
                }
                viewHolder.getConvertView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectPosition = position;
                        mBindingCardNo = "";
                        refresh();
                    }
                });
            }
        };
        gv_member_card_list.setAdapter(mAdapter);
        refresh();
    }

    private void refresh() {
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    public void setParams(List<NewMemberCardListItemModel> memberCardList, String orderId, NewMemberCheckCallBack callback) {
        setParams(memberCardList, orderId, "", callback);
    }

    public void setParams(List<NewMemberCardListItemModel> memberCardList, String orderId, String bindingCardNo, NewMemberCheckCallBack callback) {
        mMemberCardList.addAll(memberCardList);
        mOrderId = orderId;
        mBindingCardNo = bindingCardNo;
        mCallBack = callback;
        if (!TextUtils.isEmpty(mBindingCardNo)) {
            selectPosition = -1;
        }
        refresh();
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tv_confirm:
                if (selectPosition < 0) {
                    dismissSelf();
                    return;
                }

                NewMemberCardListItemModel memberCard = mMemberCardList.get(selectPosition);
                if (memberCard == null) {
                    dismissSelf();
                    return;
                }
                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员卡绑定到订单---选择的会员卡为：" + memberCard.cardNo + "，orderId=" + mOrderId);
                Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
                new MemberProcess().bindMemberCardToOrder(memberCard, mOrderId, new ResultCallback<NewQueryMemberInfoAndBindToOrderResponse>() {
                    @Override
                    public void onSuccess(NewQueryMemberInfoAndBindToOrderResponse data) {
                        if (progress != null) {
                            progress.dismiss();
                        }

                        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员卡绑定到订单done MemberCardModel->cardno=" + data.memberCardModel.cardInfo.card_no + "，orderId=" + mOrderId);
                        if (mCallBack != null) {
                            mCallBack.call(data);
                        }
                        dismissSelf();
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        if (progress != null) {
                            progress.dismiss();
                        }
                        ToastUtil.showToast(msg);
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员卡绑定到订单failure code=" + code + " msg=" + msg + "，orderId=" + mOrderId);
                    }
                });
                break;
            default:
                break;
        }
    }
}