package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * 消费储值记录
 * Created by zhangmin on 2018/1/30.
 */

public class MemberConsumptionRecordingContainer extends BusinessBean {

    //记录总数
    public String total;

    //记录页数
    public int page_count;

    //消费储值总额
    public String total_amount;

    //消费积分总数
    public String total_score;

    //消费赠送金额总数
    public String total_present_moeny;

    //消费实付金额总数 什么意思？
    public String total_amount_use_reality;

    public List<MemberConsumptionRecordingModel> list = new ArrayList<>();


}
