package com.mwee.android.pos.business.message.koubei;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDinnerResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.base.Constants;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.member.view.widget.CompatibleListView;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.callback.OnResultListener;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/24.
 * <p>
 * 先付款订单详情
 */
public class KBBeforeOrderDetailView extends LinearLayout implements View.OnClickListener {

    private TextView tvPayStatus;
    private TextView tvOrderStatus;
    private TextView tvSellNO;
    private TextView tvThirdNo;
    private TextView tvTime;
    private TextView tvPersonSum;
    private TextView tvMobile;
    private TextView tvMenuCount;
    private TextView tvTotalAmount;
    private TextView tvServiceAmount;
    private TextView tvDiscountAmount;
    private TextView tvBoxAmount;
    private TextView tvPayAmount;
    private TextView tvOtherAmount;
    private TextView tvReceiptAmount;

    private TextView tvPrinter;
    private TextView tvAccept;
    private TextView tvReject;
    private TextView tvPack;

    private TextView tvRefundAmount;

    /**
     * 商户发起退款
     */
    private TextView tvRefund;
    /**
     * C端用户发起退款  商户拒绝退款
     */
    private TextView tvRejectRefund;
    /**
     * C端用户发起退款 商户同意退款
     */
    private TextView tvAgreenRefund;

    /**
     * 正餐模式分配桌台
     */
    private TextView tvAllocationTable;

    private View mLayoutApplyRefund;


    private KBBeforeClientProcessor processor;
    private KBPreOrderCache orderCache;

    private String fsSellNo;
    private ListView listView;
    private MenuAdapter adapter;
    private TextView tvMemoLable;

    private Host mHost;


    public KBBeforeOrderDetailView(Context context) {
        super(context);
        init(context);
        initData();

    }

    public KBBeforeOrderDetailView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
        initData();

    }

    public KBBeforeOrderDetailView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
        initData();
    }

    private void init(Context context) {
        View.inflate(context, R.layout.view_kbbefore_detail, this);

        tvPayStatus = findViewById(R.id.tvPayStatus);
        tvOrderStatus = findViewById(R.id.tvOrderStatus);
        tvSellNO = findViewById(R.id.tvSellNO);
        tvThirdNo = findViewById(R.id.tvThirdNo);
        tvTime = findViewById(R.id.tvTime);
        tvPersonSum = findViewById(R.id.tvPersonSum);
        tvMobile = findViewById(R.id.tvMobile);
        tvMemoLable = findViewById(R.id.tvMemoLable);
        tvMenuCount = findViewById(R.id.tvMenuCount);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        tvServiceAmount = findViewById(R.id.tvServiceAmount);
        tvDiscountAmount = findViewById(R.id.tvDiscountAmount);
        tvBoxAmount = findViewById(R.id.tvBoxAmount);
        tvPayAmount = findViewById(R.id.tvPayAmount);
        tvOtherAmount = findViewById(R.id.tvOtherAmount);
        tvReceiptAmount = findViewById(R.id.tvReceiptAmount);
        tvRefundAmount = findViewById(R.id.tvRefundAmount);

        tvPrinter = findViewById(R.id.tvPrinter);
        tvAccept = findViewById(R.id.tvAccept);
        tvReject = findViewById(R.id.tvReject);
        tvPack = findViewById(R.id.tvPack);
        tvRefund = findViewById(R.id.tvRefund);

        mLayoutApplyRefund = findViewById(R.id.mLayoutApplyRefund);
        tvRejectRefund = findViewById(R.id.tvRejectRefund);
        tvAgreenRefund = findViewById(R.id.tvAgreenRefund);
        tvAllocationTable = findViewById(R.id.tvAllocationTable);

        listView = findViewById(R.id.listView);

    }

    private void initData() {

        tvPrinter.setOnClickListener(this);
        tvAccept.setOnClickListener(this);
        tvReject.setOnClickListener(this);
        tvPack.setOnClickListener(this);
        tvRefund.setOnClickListener(this);
        tvRejectRefund.setOnClickListener(this);
        tvAgreenRefund.setOnClickListener(this);
        tvAllocationTable.setOnClickListener(this);

        adapter = new MenuAdapter();
        listView.setAdapter(adapter);
    }


    public void refreshUI(KBPreOrderCache orderCache, String fsSellNo) {

        this.setVisibility(VISIBLE);

        this.orderCache = orderCache;

        this.fsSellNo = fsSellNo;

        tvPayStatus.setText(android.text.TextUtils.equals(orderCache.status, "REFUND") ? "已退款" : "已支付");

        StringBuilder stringBuilder = new StringBuilder();
        /**
         * 订单的状态
         */
        String orderStatusMsg = processor.buildOrderStatusMsg(orderCache.status);
        /**
         * 支付的状态
         */
        String payStatusMsg = processor.buildPayStatusMsg(orderCache.payStatus);

        stringBuilder.append(orderStatusMsg);
        //备餐中 请取餐
        if (android.text.TextUtils.equals("RECEIPT", orderCache.status) || android.text.TextUtils.equals("PREPARE", orderCache.status)) {
            if (!android.text.TextUtils.isEmpty(payStatusMsg)) {
                stringBuilder.append("[").append(payStatusMsg).append("]");
            }
        }
        tvOrderStatus.setText(stringBuilder.toString());

        tvSellNO.setText(fsSellNo);
        tvThirdNo.setText(orderCache.order_id);
        tvTime.setText(orderCache.order_time);
        tvPersonSum.setText(String.format("%s人", orderCache.people_num));
        tvMobile.setText(orderCache.user_mobile);
        tvMemoLable.setText(orderCache.memo);


        BigDecimal mMenuCount = BigDecimal.ZERO;
        for (KBPreMenuItemModel dish_detail : orderCache.dish_details) {
            //todo 不计算预点单餐盒费数量
            if(!android.text.TextUtils.equals("预点单餐盒费", dish_detail.dish_name)){
                mMenuCount = mMenuCount.add(dish_detail.dish_num);
                for (KBPreMenuItemModel model : dish_detail.selectedModifier) {
                    mMenuCount = mMenuCount.add(model.dish_num.multiply(dish_detail.dish_num));
                }
            }
        }

        tvMenuCount.setText(String.format("菜品数:%s", mMenuCount + ""));

        tvTotalAmount.setText(String.format("合计:%s", orderCache.bill_amount + ""));
        tvServiceAmount.setText(String.format("服务费:%s", orderCache.service_amount + ""));
        //todo 优惠金额 = 应收金额(合计)-实收金额
        BigDecimal bill_discount_amount = orderCache.bill_amount.subtract(orderCache.pay_amount);
        tvDiscountAmount.setText(String.format("优惠:%s", bill_discount_amount + ""));
        tvBoxAmount.setText(String.format("打包费:%s", orderCache.packing_amount + ""));
        tvPayAmount.setText(String.format("实付:%s", orderCache.pay_amount + ""));
        tvOtherAmount.setText(String.format("其他杂费:%s", orderCache.other_amount + ""));
        tvReceiptAmount.setText(String.format("实收:%s", orderCache.receipt_amount + ""));

        if (!TextUtils.isEmpty(orderCache.ext_info)) {
            JSONObject jsonObject = JSONObject.parseObject(orderCache.ext_info);
            String refund_amount = jsonObject.getString("refund_amount");
            if (!TextUtils.isEmpty(refund_amount)) {
                tvRefundAmount.setText(String.format("退款:%s", refund_amount));
            } else {
                tvRefundAmount.setText("");
            }
        } else {
            tvRefundAmount.setText("");
        }

        controlButtomStatus();
        refreshAdapter();
    }

    public void setParams(Host mHost, KBBeforeClientProcessor processor) {
        this.mHost = mHost;
        this.processor = processor;
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.tvPrinter:
                doPrinter();
                break;
            case R.id.tvReject:
                doReject();
                break;
            case R.id.tvAccept:
                doAccept();
                break;
            case R.id.tvPack:
                doPack();
                break;
            case R.id.tvRefund:
                //doRefund();
                getOrderMenuList();//获取订单的菜品列表
                break;
            case R.id.tvRejectRefund:
                doRejectRefund();
                break;
            case R.id.tvAgreenRefund:
                doAgreenRefund();
                break;
            case R.id.tvAllocationTable:
                doAllocationTable();
                break;
        }
    }

    /**
     * 点击了请打印按钮
     */
    private void doPrinter() {

        processor.doPrinter(orderCache.order_id, null);
    }

    /**
     * 点击了请拒单按钮
     */
    private void doReject() {

        String mContent = String.format("订单【%s】,请确认是否继续拒单", processor.buildOrderStatusMsg(orderCache.status));
        ArrayList<String> reasons = new ArrayList<>();
        reasons.add(Constants.BUSY);
        reasons.add(Constants.DUPLICATE_ORDER);
        reasons.add(Constants.SHOP_CLOSE);
        reasons.add(Constants.SELL_OUT);
        reasons.add(Constants.TABLE_NOT_EXIST);
        reasons.add(Constants.OTHER_REASON);
        ReasonDialongFragment reasonDialongFragment = new ReasonDialongFragment();
        reasonDialongFragment.setParams(reasons, "请选择拒单理由", mContent, new TResult<String>() {
            @Override
            public void callBack(String reason) {

                processor.rejectOrder(orderCache.order_id, orderCache.merchant_id, reason, new ResultCallback<KBPreOrderUpdateResponse>() {
                    @Override
                    public void onSuccess(KBPreOrderUpdateResponse data) {
                        refreshCallBack(data);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        super.onFailure(code, msg);
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });
        reasonDialongFragment.show(mHost.getFragmentManagerWithinHost(), "");
    }

    /**
     * 点击了接单按钮
     */
    private void doAccept() {

        //todo 正餐模式 并且为线上点菜 并且为堂食 弹出提示框
        if ("DINNER".equals(orderCache.business_type) && "PLATFORM".equals(orderCache.order_style) && "堂食".equals(orderCache.dinner_type)) {

            processor.loadTempDinnerReminder(new ResultCallback<KPreTempDinnerResponse>() {
                @Override
                public void onSuccess(KPreTempDinnerResponse data) {

                    if (ListUtil.isEmpty(data.data.koubeiOrder)) {
                        doSureAccept();
                        return;
                    }

                    TableReminderFragment fragment = new TableReminderFragment();
                    fragment.setListener(data.data.koubeiOrder, new NormalListener() {
                        @Override
                        public void callBack() {
                            doSureAccept();
                        }
                    });
                    fragment.show(mHost.getFragmentManagerWithinHost(), fragment.getClass().getName());
                }

                @Override
                public void onFailure(int code, String msg) {
                    super.onFailure(code, msg);
                    ToastUtil.showToast(msg);
                }
            });

        } else {
            doSureAccept();
        }
    }


    private void doSureAccept() {
        processor.acceptOrder(orderCache.order_id, orderCache.merchant_id, new ResultCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void onSuccess(KBPreOrderUpdateResponse data) {
                refreshCallBack(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                if (code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                    DialogManager.showSingleDialog(mHost, msg, "确定");
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });
    }


    /**
     * 点击了备餐完成按钮
     */
    private void doPack() {

        processor.prepareOrder(orderCache.order_id, orderCache.merchant_id, new ResultCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void onSuccess(KBPreOrderUpdateResponse data) {
                refreshCallBack(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                ToastUtil.showToast(msg);
                if (code == -100) {//todo 菜品 规格 做法校验不通过直接拒单
                    doReject();
                }
            }
        });
    }

    /**
     * 获取订单的菜品列表
     */
    private void getOrderMenuList() {
        Progress progress = ProgressManager.showProgress(mHost);
        processor.kbRefundGetOrder(orderCache.order_id, new ResultCallback<OrderCache>() {
            @Override
            public void onSuccess(OrderCache data) {
                progress.dismiss();
                showChooseMenuDialog(data.originMenuList, null);//显示选择退款菜品页面
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                progress.dismiss();
                showChooseMenuDialog(null, orderCache.dish_details);//显示选择退款菜品页面
            }
        });
    }


    /**
     * 商户点击了退款按钮
     *
     * @param refundAmount         退款金额
     * @param choiceRefundMenuList 本地口碑订单选中需要退款的菜品菜品唯一标识符
     */
    private void doRefund(final String refundAmount, final ArrayList<MenuItem> choiceRefundMenuList) {

        String mContent = String.format("订单【%s】,请确认是否继续退款", processor.buildOrderStatusMsg(orderCache.status));

        ArrayList<String> reasons = new ArrayList<>();
        reasons.add("店铺太忙，无法接待");
        reasons.add("店铺已打烊");
        reasons.add("菜品售完");
        reasons.add("其他原因");

        ReasonDialongFragment reasonDialongFragment = new ReasonDialongFragment();
        reasonDialongFragment.setParams(reasons, "请选择退款理由", mContent, new TResult<String>() {
            @Override
            public void callBack(String reason) {
                tvRefund.setEnabled(false);
                refundOrder(reason, refundAmount, choiceRefundMenuList);//口碑整单退款
            }
        });


        reasonDialongFragment.show(mHost.getFragmentManagerWithinHost(), "");
    }


    /**
     * 口碑预点桌台单 并且为堂食模式下 分配桌台
     */
    private void doAllocationTable() {

        processor.allocationTable(orderCache, false, new ResultCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void onSuccess(KBPreOrderUpdateResponse data) {
                refreshCallBack(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                ToastUtil.showToast(msg);
            }
        });


    }

    /**
     * 口碑整单退款
     *
     * @param reason
     */
    private void refundOrder(String reason, final String refundAmount, final ArrayList<MenuItem> choiceRefundMenuList) {
        RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户退款", "端上发送 开始 退款请求 到业务中心");
        processor.refundOrder(orderCache.order_id, orderCache.merchant_id, fsSellNo, reason, refundAmount, choiceRefundMenuList, new ResultCallback<KBPreOrderUpdateResponse>() {
            @Override
            public void onSuccess(KBPreOrderUpdateResponse data) {
                ToastUtil.showToast("退款成功");
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户退款结果", "端上 退款成功");
                refreshCallBack(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                tvRefund.setEnabled(true);
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户退款结果", "端上 退款失败 msg=" + msg);
                doRefundFail(msg, refundAmount, choiceRefundMenuList);
            }
        });
    }


    /**
     * 处理退款失败的结果
     *
     * @param failMsg
     */
    private void doRefundFail(String failMsg, final String refundAmount, final ArrayList<MenuItem> choiceRefundMenuList) {

        String mContent = String.format("口碑点餐订单【%s】退款失败，失败原因：%s,是否重新退款？", orderCache.order_id, failMsg);
        DialogManager.showExecuteDialog(mHost, mContent, "取消", "重试", new DialogResponseListener() {
            @Override
            public void response() {
                doRefund(refundAmount, choiceRefundMenuList);
            }
        });
    }


    /**
     * 显示选择退款菜品页面
     *
     * @param orderMenuItem   本地口碑订单菜品信息
     * @param kbOrderMenuItem 口碑订单菜品信息
     */
    private void showChooseMenuDialog(List<MenuItem> orderMenuItem, List<KBPreMenuItemModel> kbOrderMenuItem) {
        //todo 选择要退款的菜品
        final KBPartRefundChooseMenuDialogFragment refundChooseMenuDialogFragment = new KBPartRefundChooseMenuDialogFragment();
        refundChooseMenuDialogFragment.setParameter(orderMenuItem, kbOrderMenuItem, fsSellNo);
        refundChooseMenuDialogFragment.setOnChoiceRefundMenuListListener(new KBPartRefundChooseMenuDialogFragment.OnChoiceRefundMenuListListener() {

            //本地订单存在  才会调用该接口
            @Override
            public void onChoiceRefundMenu(ArrayList<MenuItem> choiceRefundMenuList, boolean isCheckAll) {
                refundChooseMenuDialogFragment.dismiss();
                if (isCheckAll) {//整单退
                    RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户选择了退款菜品", "为 本地 整单退款  fsSellNo：" + fsSellNo);

                    doRefund("", null);
                } else {//部分退款
                    RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户选择了退款菜品", "为 本地 部分退款  fsSellNo：" + fsSellNo);

                    doRefund("", choiceRefundMenuList);
                }
            }

            //退款金额(部分退款，本地订单不存在或已经清除时才传) 才会调用该接口
            @Override
            public void onKBChoiceRefundMenu(String refundAmount, boolean isCheckAll) {
                refundChooseMenuDialogFragment.dismiss();
                if (isCheckAll) {//整单退
                    RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户选择了退款菜品", "为 口碑 整单退款  fsSellNo：" + fsSellNo);
                    doRefund("", null);
                } else {//部分退款
                    RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "商户选择了退款菜品", "为 口碑 部分退款  fsSellNo：" + fsSellNo);
                    doRefund(refundAmount, null);
                }
            }
        });
        DialogManager.showCustomDialog(mHost, refundChooseMenuDialogFragment, "KBPartRefundChooseMenuDialogFragment");
    }


    /**
     * 点击了 拒绝退款按钮
     */
    private void doRejectRefund() {

        ArrayList<String> rejectReasons = new ArrayList<>();
        rejectReasons.add("用户已取餐");
        rejectReasons.add("和用户协商一致，线下解决");
        rejectReasons.add("其他原因");
        ReasonDialongFragment reasonDialongFragment = new ReasonDialongFragment();
        reasonDialongFragment.setParams(rejectReasons, "请选择拒绝退款理由", "", new TResult<String>() {
            @Override
            public void callBack(String rejectReason) {

                processor.rejectRefundOrder(orderCache.order_id, orderCache.merchant_id, fsSellNo, rejectReason, new ResultCallback<KBPreOrderUpdateResponse>() {
                    @Override
                    public void onSuccess(KBPreOrderUpdateResponse data) {
                        refreshCallBack(data);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        super.onFailure(code, msg);
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });
        reasonDialongFragment.show(mHost.getFragmentManagerWithinHost(), "");
    }

    /**
     * 点击了  同意退款按钮
     */
    private void doAgreenRefund() {

        String mContent = String.format("订单【%s】，退款后钱款将直接返还给用户，请确认是否继续退款？", processor.buildOrderStatusMsg(orderCache.status));
        ArrayList<String> reasons = new ArrayList<>();
        reasons.add("店铺太忙，无法接待");
        reasons.add("店铺已打烊");
        reasons.add("菜品售完");
        reasons.add("其他原因");

        ReasonDialongFragment reasonDialongFragment = new ReasonDialongFragment();
        reasonDialongFragment.setParams(reasons, "请选择同意退款理由", mContent, new TResult<String>() {
            @Override
            public void callBack(String reason) {

                processor.agreenRefundOrder(orderCache.order_id, orderCache.merchant_id, fsSellNo, reason, new ResultCallback<KBPreOrderUpdateResponse>() {
                    @Override
                    public void onSuccess(KBPreOrderUpdateResponse data) {
                        //ToastUtil.showToast("同意退款成功");
                        refreshCallBack(data);
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        super.onFailure(code, msg);
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });


        //预约时间
        Long appointTime = DateTimeUtil.getLongByTimeReal(orderCache.table_time, "yyyy-MM-dd HH:mm:ss");
        //当前时间
        Long currentTime = System.currentTimeMillis();
        //预约用餐时间30分钟以内 需要赔偿违约金
        boolean isPayPenalty = (appointTime - currentTime) < 30 * 60 * 1000;
        if (isPayPenalty) {
            //违约金
            BigDecimal refundViolateAmount = null;
            JSONObject jsonObject = null;
            try {
                jsonObject = JSONObject.parseObject(orderCache.ext_info);
                String mBuyerDefaultRealAmount = jsonObject.getString("buyerDefaultRealAmount");
                refundViolateAmount = new BigDecimal(mBuyerDefaultRealAmount);
                reasonDialongFragment.setRefundAmount(orderCache.pay_amount.subtract(refundViolateAmount), refundViolateAmount);
            } catch (Exception e) {
                e.printStackTrace();
                LogUtil.logBusiness("[违约金]解析失败" + orderCache.order_id + "ext_info:" + jsonObject);
            }
        }
        reasonDialongFragment.show(mHost.getFragmentManagerWithinHost(), "");
    }


    /**
     * 刷新商户操作按钮的回调
     *
     * @param data
     */
    private void refreshCallBack(KBPreOrderUpdateResponse data) {
        orderCache = data.data;
        fsSellNo = data.local_order_id;
        refreshUI(orderCache, fsSellNo);
        //stringList 存订单头取餐号以及状态
        //todo 这个应该去后台在进行查一次数据为准更好
        List<String> stringList = new ArrayList<>();
        stringList.add(orderCache.take_no);
        stringList.add(orderCache.status);
        stringList.add(orderCache.payStatus);
        listener.callBack(stringList);
    }


    private void refreshAdapter() {

        adapter.modules.clear();

        Iterator<KBPreMenuItemModel> iterator = orderCache.dish_details.iterator();
        while (iterator.hasNext()) {

            KBPreMenuItemModel model = iterator.next();
            if (android.text.TextUtils.equals("预点单餐盒费", model.dish_name)) {
                iterator.remove();
            } else {
                adapter.modules.add(model);
            }
        }

        adapter.notifyDataSetChanged();
    }


    /**
     * 控制底部按钮显示的状态
     */
    private void controlButtomStatus() {

        switch (orderCache.status) {
            case "PUSH"://todo 推过来新订单
                tvPrinter.setVisibility(GONE);
                tvReject.setVisibility(VISIBLE);
                tvAccept.setVisibility(VISIBLE);
                tvPack.setVisibility(GONE);
                tvRefund.setVisibility(GONE);
                mLayoutApplyRefund.setVisibility(GONE);
                tvAllocationTable.setVisibility(GONE);
                break;
            case "RECEIPT"://todo 接单完成
                tvPrinter.setVisibility(VISIBLE);
                tvReject.setVisibility(GONE);
                tvAccept.setVisibility(GONE);
                tvPack.setVisibility(VISIBLE);
                tvRefund.setVisibility(VISIBLE);
                tvRefund.setEnabled(true);
                mLayoutApplyRefund.setVisibility(GONE);
                tvAllocationTable.setVisibility(GONE);
                break;
            case "COOKING"://todo 已下厨
            case "PREPARE"://todo 备餐完成
            case "DELIVER"://todo 送餐完成
            case "FINISH": //todo 订单已完成（接单后未发生退款，24小时超时自动完成
                tvPrinter.setVisibility(VISIBLE);
                tvReject.setVisibility(GONE);
                tvAccept.setVisibility(GONE);
                tvPack.setVisibility(GONE);
                tvRefund.setVisibility(VISIBLE);
                tvRefund.setEnabled(true);
                mLayoutApplyRefund.setVisibility(GONE);
                tvAllocationTable.setVisibility(GONE);
                break;
            case "REJECT"://todo  拒单完成
            case "CLOSE":
            case "CANCEL":
            case "REFUND":
            default:
                tvPrinter.setVisibility(GONE);
                tvReject.setVisibility(GONE);
                tvAccept.setVisibility(GONE);
                tvPack.setVisibility(GONE);
                tvRefund.setVisibility(GONE);
                mLayoutApplyRefund.setVisibility(GONE);
                tvAllocationTable.setVisibility(GONE);
                break;
        }

        //订单状态处于待接单 或者备餐中    支付状态为用户申请退款
        if ("RECEIPT".equals(orderCache.status) || "PREPARE".equals(orderCache.status)) {
            if (android.text.TextUtils.equals("APPLY_REFUND", orderCache.payStatus)) {
                tvPrinter.setVisibility(GONE);
                tvReject.setVisibility(GONE);
                tvAccept.setVisibility(GONE);
                tvPack.setVisibility(GONE);
                tvRefund.setVisibility(GONE);
                mLayoutApplyRefund.setVisibility(VISIBLE);
            }
        }

        /**
         * 控制分配桌台的按钮显示
         */
        if ("RECEIPT".equals(orderCache.status) || "PREPARE".equals(orderCache.status) || "DELIVER".equals(orderCache.status)) {
            //todo 控制 口碑预点桌台单 为堂食模式 为预约单 并且没有分配过桌台 下 分配桌台按钮显示
            if ("DINNER".equals(orderCache.business_type)
                    && "堂食".equals(orderCache.dinner_type)
                    && "PLATFORM".equals(orderCache.order_style)
                    && android.text.TextUtils.isEmpty(fsSellNo)
                    && !"APPLY_REFUND".equals(orderCache.payStatus)) {
                tvAllocationTable.setVisibility(VISIBLE);
                //分配桌台应该在备餐完成之前操作
                tvPack.setVisibility(GONE);
            }
        }


        if ("ACCEPT_REFUND".equals(orderCache.payStatus)
                || "REFUNDED".equals(orderCache.payStatus)) {
            tvPrinter.setVisibility(GONE);
            tvReject.setVisibility(GONE);
            tvAccept.setVisibility(GONE);
            tvPack.setVisibility(GONE);
            tvRefund.setVisibility(GONE);
            mLayoutApplyRefund.setVisibility(GONE);
        }

        //todo 吴丽丽产品的特殊需求  控制 口碑预点桌台单 为堂食模式 为预约单 隐藏备餐完成按钮
        if ("RECEIPT".equals(orderCache.status) && android.text.TextUtils.equals("DINNER", orderCache.business_type) && android.text.TextUtils.equals("PLATFORM", orderCache.order_style) && android.text.TextUtils.equals("堂食", orderCache.dinner_type)) {
            tvPack.setVisibility(GONE);
        }

        //todo  吴丽丽产品的特殊需求 控制 口碑预点桌台单 为堂食模式 为预约单 已下厨过或者核销后 需要释放备餐完成按钮

        if ("COOKING".equals(orderCache.status) || "DELIVER".equals(orderCache.status)) {
            if ("DINNER".equals(orderCache.business_type)
                    && "PLATFORM".equals(orderCache.order_style) && "堂食".equals(orderCache.dinner_type)) {
                tvPack.setVisibility(VISIBLE);
            }
        }

    }


    class MenuAdapter extends BaseMwAdapter<KBPreMenuItemModel> {

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.view_kbbefore_detail_item, parent, false);
                viewHolder = new ViewHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.bindData(position);
            return convertView;
        }

        class ViewHolder {

            private TextView tvName;
            private TextView tvQty;
            private TextView tvPrice;
            private TextView tvTotal;
            private CompatibleListView packageList;
            private CompatibleListView modifierList;
            private TextView tvMemo;

            public ViewHolder(View v) {

                tvName = v.findViewById(R.id.tv_item_name);
                tvPrice = v.findViewById(R.id.tv_item_price);
                tvQty = v.findViewById(R.id.tv_item_qty);
                tvTotal = v.findViewById(R.id.tv_item_total);
                packageList = v.findViewById(R.id.packageList);
                modifierList = v.findViewById(R.id.modifierList);
                tvMemo = v.findViewById(R.id.itemProperties);

            }

            private void bindData(int position) {

                KBPreMenuItemModel model = modules.get(position);
                if (android.text.TextUtils.isEmpty(model.fiItemCd) || android.text.TextUtils.isEmpty(model.fiOrderUintCd)) {
                    tvName.setText(model.dish_name + "[口碑]");
                } else {
                    tvName.setText(model.dish_name);
                }
                tvPrice.setText(model.sell_price + "");
                tvQty.setText(model.dish_num + "");
                //todo 菜品总价 = (菜品单价+加价)*菜品数量  【会员价 菜品加价怎么计算？？？ 】
                BigDecimal totalPrice = model.sell_price.multiply(model.dish_num).setScale(2, BigDecimal.ROUND_HALF_UP);
                tvTotal.setText(totalPrice + "");

                tvMemo.setText(model.memo + model.practice_info);
                if (model.main_flag && model.type.equals("COMBO")) {
                    packageList.setVisibility(View.VISIBLE);
                    PackageAdapter packageAdapter = new PackageAdapter();
                    packageAdapter.modules.clear();
                    packageAdapter.modules.addAll(model.packageMenuItemDetails);
                    packageList.setAdapter(packageAdapter);
                } else {
                    packageList.setVisibility(View.GONE);
                }

                //配料菜
                if (model.main_flag && model.type.equals("SINGLE")) {
                    modifierList.setVisibility(View.VISIBLE);
                    ModifierAdapter modifierAdapter = new ModifierAdapter();
                    modifierAdapter.modules.clear();
                    modifierAdapter.modules.addAll(model.selectedModifier);
                    modifierAdapter.setOrderDishNumber(model.dish_num);
                    modifierList.setAdapter(modifierAdapter);
                } else {
                    modifierList.setVisibility(View.GONE);
                }
                tvMemo.setVisibility(android.text.TextUtils.isEmpty(model.memo) && android.text.TextUtils.isEmpty(model.practice_info) ? GONE : VISIBLE);
            }
        }
    }


    class PackageAdapter extends BaseMwAdapter<KBPreMenuItemModel> {
        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            PackageViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.view_kbbefore_detail_package_item, parent, false);
                viewHolder = new PackageViewHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (PackageViewHolder) convertView.getTag();
            }
            viewHolder.bindData(position);
            return convertView;
        }

        class PackageViewHolder {
            private TextView tvPackageName;
            private TextView tvPackageNumber;
            private TextView tvPackageMemo;

            public PackageViewHolder(View v) {
                tvPackageName = v.findViewById(R.id.tvPackageName);
                tvPackageNumber = v.findViewById(R.id.tvPackageNumber);
                tvPackageMemo = v.findViewById(R.id.tvPackageMemo);
            }

            private void bindData(int position) {
                KBPreMenuItemModel model = modules.get(position);
                if (android.text.TextUtils.isEmpty(model.fiItemCd) || android.text.TextUtils.isEmpty(model.fiOrderUintCd)) {
                    tvPackageName.setText(model.dish_name + "[口碑]");
                } else {
                    tvPackageName.setText(model.dish_name);
                }
                tvPackageNumber.setText(String.format("x%s", model.dish_num + ""));
                tvPackageMemo.setText(model.memo);
                tvPackageMemo.setVisibility(android.text.TextUtils.isEmpty(model.memo) ? GONE : VISIBLE);
            }
        }
    }


    class ModifierAdapter extends BaseMwAdapter<KBPreMenuItemModel> {
        BigDecimal dish_num_order = BigDecimal.ONE;

        public void setOrderDishNumber(BigDecimal dish_num_order) {
            this.dish_num_order = dish_num_order;
        }

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            ModifierViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.view_kbbefore_detail_modify_item, parent, false);
                viewHolder = new ModifierViewHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ModifierViewHolder) convertView.getTag();
            }
            viewHolder.bindData(position);
            return convertView;
        }

        class ModifierViewHolder {
            private TextView tvModifierName;
            private TextView tvModifierPrice;
            private TextView tvModifierNumber;
            private TextView tvModifierTotal;

            public ModifierViewHolder(View v) {
                tvModifierName = v.findViewById(R.id.tvModifierName);
                tvModifierPrice = v.findViewById(R.id.tvModifierPrice);
                tvModifierNumber = v.findViewById(R.id.tvModifierNumber);
                tvModifierTotal = v.findViewById(R.id.tvModifierTotal);
            }

            private void bindData(int position) {
                KBPreMenuItemModel model = modules.get(position);
                if (android.text.TextUtils.isEmpty(model.fiItemCd) || android.text.TextUtils.isEmpty(model.fiOrderUintCd)) {
                    tvModifierName.setText(model.dish_name + "[口碑]");
                } else {
                    tvModifierName.setText(model.dish_name);
                }
                tvModifierPrice.setText(model.sell_price + "");
                tvModifierNumber.setText(model.dish_num.multiply(dish_num_order) + "");
                tvModifierTotal.setText(model.dish_total_amount.multiply(dish_num_order) + "");
            }
        }
    }


    private OnResultListener<List<String>> listener;

    public void setListener(OnResultListener<List<String>> listener) {
        this.listener = listener;
    }

}

