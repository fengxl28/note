package com.mwee.android.pos.business.bill.api;

import com.mwee.android.pos.component.datasync.net.model.NetorderItemMappingRelationshipDBModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.business.netorder.GetNetOrderSimpleInfoResponse;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.connect.business.netorder.QueryMeituanMappingResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CNetOrder;

/**
 * Created by zhangmin on 2017/9/3.
 */

public class CNetOrderApi {


    public static void getAllNetOrderRequest(int currentPage, String businessDate, String time, String source, String areaIds, boolean checkDate, SocketCallback<GetAllNetOrderResponse> socketCallback) {

        MCon.c(CNetOrder.class, socketCallback).GetAllNetOrderRequest(currentPage, businessDate, time, source, areaIds, checkDate);
    }

    public static void updateNetOrderTurnErrInfo(String orderId, String time, String areaIds, SocketCallback<OptNetOrderFromBizResponse> socketCallback) {
        MCon.c(CNetOrder.class, socketCallback).updateNetOrderTurnErrInfo(orderId, "", time, areaIds);
    }

    /**
     * 查询网络订单---仅支持查询饿了么、美团
     *
     * @param businessDate   营业日期
     * @param source         来源 all/-1/"" 表示全部 2 饿了么 3 美团
     * @param socketCallback
     */
    public static void optTempappordersList(int currentPage, String businessDate, String source, String sellNo, SocketCallback<GetNetOrderSimpleInfoResponse> socketCallback) {

        MCon.c(CNetOrder.class, socketCallback).optTempappordersList(currentPage, businessDate, source, sellNo);
    }


    /**
     * 获取外卖单
     * @param orderId
     * @param businessDate
     * @param time
     * @param source
     * @param areaIds
     * @param socketCallback
     */
    public static void optNetOrderFromBizRequest(String orderId, String businessDate, String time, String source, String areaIds, SocketCallback<BaseSocketResponse> socketCallback) {

        MCon.c(CNetOrder.class, socketCallback).optNetOrderFromBizRequest(orderId, businessDate, time, source, areaIds);
    }

    /**
     * 查询美团外卖菜品映射
     *
     * @param state
     * @param socketCallback
     */
    public static void queryMeituanMappingMenu(int state, SocketCallback<QueryMeituanMappingResponse> socketCallback) {
        MCon.c(CNetOrder.class, socketCallback).queryMeituanMapping(state);
    }

    /**
     * 更新美团外卖菜品映射
     *
     * @param model
     * @param socketCallback
     */
    public static void updateMeituanMapping(NetorderItemMappingRelationshipDBModel model, SocketCallback<BaseSocketResponse> socketCallback) {
        MCon.c(CNetOrder.class, socketCallback).updateMeituanMapping(model);
    }
}
