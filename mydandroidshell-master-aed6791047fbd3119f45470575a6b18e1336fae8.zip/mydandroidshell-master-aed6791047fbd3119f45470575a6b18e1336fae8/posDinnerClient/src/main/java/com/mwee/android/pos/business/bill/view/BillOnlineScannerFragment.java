package com.mwee.android.pos.business.bill.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.bill.component.BillOnlineProcess;
import com.mwee.android.pos.business.netpay.model.ScanPaymentModel;
import com.mwee.android.pos.business.netpay.model.ScanPaymentModelList;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;

/**
 * Created by qinwei on 2017/7/21.
 */

public class BillOnlineScannerFragment extends BaseListFragment<ScanPaymentModel> implements View.OnClickListener {
    private String mSelectDate;
    private int currentPage = 0;//当前页索引
    private int willLoadPage;//需要加载的页索引
    private TextView mBillOnlineFilterTimeLabel;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_bill_online_scanner;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mBillOnlineFilterTimeLabel = (TextView) view.findViewById(R.id.mBillOnlineFilterTimeLabel);
        mBillOnlineFilterTimeLabel.setOnClickListener(this);
    }


    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setRefreshing();
        mSelectDate = DateUtil.getCurrentDate("yyyy-MM-dd");//默认当前日期
        mBillOnlineFilterTimeLabel.setText(mSelectDate);
    }

    public void loadDataFromServer() {
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    public void loadDataFromServer(final int mode) {
        BillOnlineProcess.loadBillOnlineScannerData(mSelectDate, willLoadPage, new ResultCallback<ScanPaymentModelList>() {
            @Override
            public void onSuccess(ScanPaymentModelList data) {
                if (TextUtils.validate(data.result)) {
                    currentPage = willLoadPage;//更新当前页数
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    //显示数据内容
                    mPullRecyclerView.showContent();
                    if (willLoadPage == data.totalPageNo) {//nextPage==0表明当前已经是最后一页
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);//显示无更多数据label
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    modules.addAll(data.result);
                    adapter.notifyDataSetChanged();
                } else {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                        adapter.notifyDataSetChanged();
                        mPullRecyclerView.showEmptyView();
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);//移除state footerView
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            willLoadPage = 1;
        } else {
            willLoadPage = currentPage + 1;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBillOnlineFilterTimeLabel:
                showChoiceDate();
                break;
            default:
                break;
        }
    }

    public void showChoiceDate() {
        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), rootView);
        calendarPopupwindow.setDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                if (!newDate.equals(mSelectDate)) {
                    mSelectDate = newDate;
                    mBillOnlineFilterTimeLabel.setText(newDate);
                    modules.clear();
                    adapter.notifyDataSetChanged();
                    mPullRecyclerView.setRefreshing();
                }
            }
        });
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.bill_online_fragment_item, parent, false));
    }


    private class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView mBillOnlineItemTableNameLabel;
        private TextView mBillOnlineItemPriceLabel;
        private TextView mBillOnlineItemPayTypeLabel;
        private TextView mBillOnlineItemPayStatusLabel;
        private TextView mBillOnlineItemPayOrderLabel;
        private TextView mBillOnlineItemBillNumberLabel;
        private TextView mBillOnlineItemCreateTimeLabel;
        private TextView mBillOnlineItemRefundLabel;
        private ScanPaymentModel model;

        public Holder(View v) {
            super(v);
            mBillOnlineItemTableNameLabel = (TextView) v.findViewById(R.id.mBillOnlineItemTableNameLabel);
            mBillOnlineItemPriceLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPriceLabel);
            mBillOnlineItemPayTypeLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayTypeLabel);
            mBillOnlineItemPayStatusLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayStatusLabel);
            mBillOnlineItemPayOrderLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayOrderLabel);
            mBillOnlineItemBillNumberLabel = (TextView) v.findViewById(R.id.mBillOnlineItemBillNumberLabel);
            mBillOnlineItemCreateTimeLabel = (TextView) v.findViewById(R.id.mBillOnlineItemCreateTimeLabel);
            mBillOnlineItemRefundLabel = (TextView) v.findViewById(R.id.mBillOnlineItemRefundLabel);
            mBillOnlineItemRefundLabel.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);
            mBillOnlineItemTableNameLabel.setText(model.fsMTableId);
            mBillOnlineItemPriceLabel.setText(model.fdamount.toString());
            mBillOnlineItemPayTypeLabel.setText(model.getPayTypeLabel());
            mBillOnlineItemPayStatusLabel.setText(model.getPayStatusLabel());
            mBillOnlineItemPayOrderLabel.setText(model.fspayno);
            mBillOnlineItemBillNumberLabel.setText(model.fssellno);
            mBillOnlineItemCreateTimeLabel.setText(DateUtil.formartDateStrToTarget(model.fscreatetime, DateUtil.DATE_VISUAL14FORMAT, "MM-dd HH:mm"));

            mBillOnlineItemRefundLabel.setVisibility(View.GONE);
//            当天订单，并且支付状态为已支付,重复支付的支付信息对应的收银账单号是为null的 然后需要显示退款按钮，有收银账单号的记录显示信息提示到账单列表进行反结账操作进行退款
//            if (!TextUtils.validate(model.sellno) && DateUtil.getCurrentDate("yyyy-MM-dd").equals(mSelectDate) && (model.state == Constants.STATE_PAY_DONE || model.state == Constants.STATE_REFUND_ING)) {
//                mBillOnlineItemRefundLabel.setVisibility(View.VISIBLE);
//            } else {
//                mBillOnlineItemRefundLabel.setVisibility(View.GONE);
//            }
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.mBillOnlineItemRefundLabel:
                    DialogManager.showExecuteDialog(getActivityWithinHost(), getStringWithinHost(R.string.setting_online_refund), getStringWithinHost(R.string.cacel), getStringWithinHost(R.string.setting_sure_refunds), new DialogResponseListener() {
                        @Override
                        public void response() {
//                            doRefund(model);
                        }
                    }, null);
                    break;
                default:
                    break;
            }
        }
    }
}
