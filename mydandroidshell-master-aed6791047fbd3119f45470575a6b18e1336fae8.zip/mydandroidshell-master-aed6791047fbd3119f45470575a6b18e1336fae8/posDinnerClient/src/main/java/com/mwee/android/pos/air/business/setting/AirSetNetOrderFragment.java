package com.mwee.android.pos.air.business.setting;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.air.business.netorder.AirNetOrderManageFragment;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.bill.view.BillContainerFragment;
import com.mwee.android.pos.business.bill.view.BillTakeOutFragment;
import com.mwee.android.pos.business.setting.view.WechatFastfoodSettingFragment;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UIHelp;

/**
 * Created by zhangmin on 2017/12/13.
 */

public class AirSetNetOrderFragment extends BaseFragment implements View.OnClickListener {

    private TextView tvMenuTakeSetting;
    private TextView tv_setting_bill_online;
    private TextView wechat_fastfood_tv;
    private TextView tvMenuTakeOutOrder;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_set_netorder_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        tvMenuTakeOutOrder = (TextView) v.findViewById(R.id.tvMenuTakeOutOrder);
        tvMenuTakeSetting = (TextView) v.findViewById(R.id.tvMenuTakeSetting);
        tv_setting_bill_online = (TextView) v.findViewById(R.id.tv_setting_bill_online);
        wechat_fastfood_tv = v.findViewById(R.id.wechat_fastfood_tv);
        tvMenuTakeSetting.setOnClickListener(this);
        tv_setting_bill_online.setOnClickListener(this);
        wechat_fastfood_tv.setOnClickListener(this);
        tvMenuTakeOutOrder.setOnClickListener(this);
        if (APPConfig.isAir()) {
            wechat_fastfood_tv.setVisibility(View.GONE);
        } else {
            wechat_fastfood_tv.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.wechat_fastfood_tv:
                ActionLog.addLog("更多设置->点击了微信快餐设置", "", "", ActionLog.SS_MORE_JOIN, "");
                UIHelp.jumpContainerActivity(getActivityWithinHost(), "微信快餐", WechatFastfoodSettingFragment.class);
                break;
            case R.id.tv_setting_bill_online:
                ActionLog.addLog("更多设置->点击了线上支付查询", "", "", ActionLog.SS_MORE_JOIN, "");
                UIHelp.jumpContainerActivity(getActivityWithinHost(), "线上支付查询", BillContainerFragment.class);
                break;

            case R.id.tvMenuTakeSetting://外卖管理
                if (!ClientBindProcessor.isCurrentHostMain()) {
                    ToastUtil.showToast("外卖设置仅仅主机可以操作");
                    return;
                }
                ActionLog.addLog("更多设置->点击了外卖设置", "", "", ActionLog.SS_MORE_JOIN, "");
                UIHelp.jumpContainerActivity(getActivityWithinHost(), "外卖管理", TakeOutSettingContainerFragment.class);
//                UIHelp.jumpContainerActivity(getActivityWithinHost(), "外卖设置", AirNetOrderManageFragment.class);
                break;
            case R.id.tvMenuTakeOutOrder:
                ActionLog.addLog("更多设置->外卖平台订单记录", "", "", ActionLog.SS_MORE_JOIN, "");
                UIHelp.jumpContainerActivity(getActivityWithinHost(), "外卖平台订单记录", BillTakeOutFragment.class);
                break;
            default:
                break;
        }
    }
}
