package com.mwee.android.pos.air.business.menu.db;

import android.text.TextUtils;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.List;

/**
 * Created by qinwei on 2018/3/20.
 */

public class DTOMenuItemDBController {
    /**
     * 根据菜品分类查询菜品列表信息
     *
     * @param menuClsId 菜品分类id
     * @return
     */
    public static List<MenuItemBean> queryMenusByClsId(String menuClsId) {
        String sql = "select tbmenuItem.fiItemCd,tbmenuItem.fiItemKind,tbmenuItem.fiSortOrder,tbmenuItem.fsItemName,fiOrderUintCd, fsOrderUint,fdInvQty,fdSalePrice,fdVIPPrice,fiIsEditQty,tbMenuItemUint.fistatus,tbmenuItem.fsMenuClsId " +
                ",tbmenuitem.fiIsDiscount,tbmenuitem.fiIsGift,tbmenuitem.fiIsEditPrice,tbmenuitem.fiIsTakeAway,tbmenuitem.fiIsPrn from tbMenuItemUint\n" +
                "inner join tbmenuItem on tbmenuItem.fiItemCd = tbMenuItemUint.fiItemCd \n" +
                "where tbmenuItem.fiIsPurePay ='0' and tbMenuItemUint.fistatus in (1,2) and tbmenuItem.fistatus = '1' and tbmenuItem.fiItemKind in (1,2)";
        if (!TextUtils.isEmpty(menuClsId) && !TextUtils.equals("-1localAll", menuClsId)) {
            sql += " and tbmenuItem.fsMenuClsId='" + menuClsId + "'";
        }
        sql += " order by tbmenuItem.fsMenuClsId asc,tbmenuItem.fiSortOrder asc";
        return DBSimpleUtil.queryList(APPConfig.DB_CLIENT, sql, MenuItemBean.class);
    }

    /**
     * 查询所有菜品
     *
     * @return
     */
    public static List<MenuItemBean> queryAll() {
        return queryMenusByClsId("");
    }

    public static List<MenuItemBean> search(String searchStr) {
        String sql = "select tbmenuItem.fiItemCd,tbmenuItem.fiItemKind,tbmenuItem.fiSortOrder,tbmenuItem.fsItemName,fiOrderUintCd, fsOrderUint,fdInvQty,fdSalePrice,fdVIPPrice,fiIsEditQty,tbMenuItemUint.fistatus,tbmenuItem.fsMenuClsId " +
                ",tbmenuitem.fiIsDiscount,tbmenuitem.fiIsGift,tbmenuitem.fiIsEditPrice,tbmenuitem.fiIsTakeAway,tbmenuitem.fiIsPrn from tbMenuItemUint\n" +
                "inner join tbmenuItem on tbmenuItem.fiItemCd = tbMenuItemUint.fiItemCd \n" +
                "where  (tbmenuItem.fsHelpCode like '%" + searchStr + "%' or tbmenuItem.fsItemName like '%" + searchStr + "%' or tbmenuItem.fiItemCd like '%" + searchStr + "%') and tbmenuItem.fiIsPurePay ='0' and tbMenuItemUint.fistatus in (1,2) and tbmenuItem.fistatus = '1' and tbmenuItem.fiItemKind in (1,2)";
        sql += " order by tbmenuItem.fsMenuClsId asc,tbmenuItem.fiSortOrder asc";
        return DBSimpleUtil.queryList(APPConfig.DB_CLIENT, sql, MenuItemBean.class);
    }

}
