package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.bill.component.BillOnlineProcess;
import com.mwee.android.pos.business.netpay.RapidPaySearchResponse;
import com.mwee.android.pos.business.netpay.model.BillOnlineModel;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;

/**
 * 在线订单查询
 * Created by qinwei on 2017/1/11.
 */

public class BillOnlineFragment extends BaseListFragment<BillOnlineModel> implements View.OnClickListener {

    public static final String TAG = "BillOnlineFragment";
    private TextView mBillOnlineFilterTimeLabel;
    private String mSelectDate;
    private int currentPage;//当前页索引
    private int willLoadPage;//需要加载的页索引
    private String bizType;

    public static BaseFragment getInstance(String bizType) {
        BaseFragment fragment = new BillOnlineFragment();
        Bundle args = new Bundle();
        args.putString(Constants.KEY_BIZ_TYPE, bizType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_bill_online_list;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mBillOnlineFilterTimeLabel = (TextView) view.findViewById(R.id.mBillOnlineFilterTimeLabel);
        mBillOnlineFilterTimeLabel.setOnClickListener(this);
        mPullRecyclerView.setEnablePullToEnd(true);

        mSelectDate = DateUtil.getCurrentDate("yyyy-MM-dd");//默认当前日期
        mBillOnlineFilterTimeLabel.setText(mSelectDate);
    }

    @Override
    protected void initData() {
        super.initData();
        bizType = getArguments().getString(Constants.KEY_BIZ_TYPE);
        mPullRecyclerView.setRefreshing();
    }

    private void loadDataFromServer(final int mode, String qryDate, int nextPage) {
        BillOnlineProcess.loadBillOnlineData(qryDate, bizType, nextPage + "", new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                RapidPaySearchResponse response = (RapidPaySearchResponse) responseData.responseBean;
                if (TextUtils.validate(response.orders)) {
                    currentPage = willLoadPage;//更新当前页数
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    modules.addAll(response.orders);
                    adapter.notifyDataSetChanged();
                    //显示数据内容
                    mPullRecyclerView.showContent();
                    if (0 == response.nextPage) {//nextPage==0表明当前已经是最后一页
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);//显示无更多数据label
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                } else {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                        adapter.notifyDataSetChanged();
                        mPullRecyclerView.showEmptyView();
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);//移除state footerView
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                ToastUtil.showToast(responseData.resultMessage);
                return true;
            }
        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBillOnlineFilterTimeLabel:
                showChoiceDate();
                break;
            default:
                break;
        }
    }

    public void showChoiceDate() {
        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), rootView);
        calendarPopupwindow.setDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                if (!newDate.equals(mSelectDate)) {
                    mSelectDate = newDate;
                    mBillOnlineFilterTimeLabel.setText(newDate);
                    modules.clear();
                    adapter.notifyDataSetChanged();
                    mPullRecyclerView.setRefreshing();
                }
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            willLoadPage = 0;
        } else {
            willLoadPage = currentPage + 1;
        }
        loadDataFromServer(mode, mSelectDate, willLoadPage);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END, mSelectDate, willLoadPage);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new BillOnlineHolder(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.bill_online_fragment_item, parent, false));
    }


    private class BillOnlineHolder extends BaseViewHolder implements View.OnClickListener {
        private TextView mBillOnlineItemTableNameLabel;
        private TextView mBillOnlineItemPriceLabel;
        private TextView mBillOnlineItemPayTypeLabel;
        private TextView mBillOnlineItemPayStatusLabel;
        private TextView mBillOnlineItemPayOrderLabel;
        private TextView mBillOnlineItemBillNumberLabel;
        private TextView mBillOnlineItemCreateTimeLabel;
        private TextView mBillOnlineItemRefundLabel;
        private BillOnlineModel model;

        public BillOnlineHolder(View v) {
            super(v);
            mBillOnlineItemTableNameLabel = (TextView) v.findViewById(R.id.mBillOnlineItemTableNameLabel);
            mBillOnlineItemPriceLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPriceLabel);
            mBillOnlineItemPayTypeLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayTypeLabel);
            mBillOnlineItemPayStatusLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayStatusLabel);
            mBillOnlineItemPayOrderLabel = (TextView) v.findViewById(R.id.mBillOnlineItemPayOrderLabel);
            mBillOnlineItemBillNumberLabel = (TextView) v.findViewById(R.id.mBillOnlineItemBillNumberLabel);
            mBillOnlineItemCreateTimeLabel = (TextView) v.findViewById(R.id.mBillOnlineItemCreateTimeLabel);
            mBillOnlineItemRefundLabel = (TextView) v.findViewById(R.id.mBillOnlineItemRefundLabel);
            mBillOnlineItemRefundLabel.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);
            mBillOnlineItemTableNameLabel.setText(model.tableName);
            mBillOnlineItemPriceLabel.setText(model.leftTotal + "");
            mBillOnlineItemPayTypeLabel.setText(model.getPayTypeName());
            mBillOnlineItemPayStatusLabel.setText(model.orderState);
            mBillOnlineItemPayOrderLabel.setText(model.id + "");
            mBillOnlineItemBillNumberLabel.setText(model.sellno);
            mBillOnlineItemCreateTimeLabel.setText(model.LastTime);
//            当天订单，并且支付状态为已支付,重复支付的支付信息对应的收银账单号是为null的 然后需要显示退款按钮，有收银账单号的记录显示信息提示到账单列表进行反结账操作进行退款
            if (!TextUtils.validate(model.sellno) && DateUtil.getCurrentDate("yyyy-MM-dd").equals(mSelectDate) && (model.state == Constants.STATE_PAY_DONE || model.state == Constants.STATE_REFUND_ING)) {
                mBillOnlineItemRefundLabel.setVisibility(View.VISIBLE);
            } else {
                mBillOnlineItemRefundLabel.setVisibility(View.GONE);
            }

            // 关联支付后台配置，支付宝/微信是否允许退款
            if ((model.payType == 2 && !SettingHelper.allowAliPayBack()) ||
                    (model.payType == 1 && !SettingHelper.allowWxPayBack())) {
                mBillOnlineItemRefundLabel.setEnabled(false);
                mBillOnlineItemRefundLabel.setOnClickListener(null);
            } else {
                mBillOnlineItemRefundLabel.setEnabled(true);
                mBillOnlineItemRefundLabel.setOnClickListener(this);
            }
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.mBillOnlineItemRefundLabel:
                    DialogManager.showExecuteDialog(getActivityWithinHost(), getStringWithinHost(R.string.setting_online_refund), getStringWithinHost(R.string.cacel), getStringWithinHost(R.string.setting_sure_refunds), new DialogResponseListener() {
                        @Override
                        public void response() {
                            doRefund(model);
                        }
                    }, null);
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 处理退款操作
     *
     * @param model 退款对应订单实体
     */
    private void doRefund(final BillOnlineModel model) {
        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.setting_wait_refounds);
        BillOnlineProcess.loadBillOnlineRefund(model.id + "", new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                progress.dismiss();
                model.state = Constants.STATE_REFUND_DONE;
                model.orderState = getStringWithinHost(R.string.setting_wait_refounds);
                ToastUtil.showToast(responseData.responseBean.errmsg);
                adapter.notifyDataSetChanged();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                progress.dismiss();
                ToastUtil.showToast(responseData.resultMessage);
                return false;
            }
        });
    }
}
