package com.mwee.android.pos.business.backup;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.boot.BootDistribution;
import com.mwee.android.pos.connect.center.ServerConnector;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * 强制设置为主站点
 * Created by virgil on 2017/5/12.
 */

public class ForceSetAsMainHost {

    /**
     * 将ordercache的订单保存到报表
     */
    public static void transferOrder(){
        String fromForceMain=ClientMetaUtil.getSettingsValueByKey(META.FORCE_SET_MAIN);
        ClientMetaUtil.updateSettingsValueByKey(META.FORCE_SET_MAIN,"0");
        if(TextUtils.equals(fromForceMain,"1")) {
            List<OrderCache> syncOrderList = OrderSaveDBUtil.getUnfishedOrder();
            if (!ListUtil.isEmpty(syncOrderList)) {
                for (OrderCache temp : syncOrderList) {
                    temp.reCalcAllByAll();
                    PaySession session = PaySaveDBUtil.get(temp.orderID);
                    OrderProcessor.submit(temp, session);
                }
            }
            resetToken();
        }
    }
    public static void resetToken(){
//        DBMetaUtil.updateSettingsValueByKey(META.TOKEN,"-1");
//        DBMetaUtil.updateSettingsValueByKey(META.SEED,"-1");
//        ClientMetaUtil.updateSettingsValueByKey(META.TOKEN,"-1");
//        ClientMetaUtil.updateSettingsValueByKey(META.SEED,"-1");
    }
    public static void setCurrentAsMain(final Host host) {
        final Progress progress = ProgressManager.showProgressUncancel(host, "正在设置");
        new LowThread(new Runnable() {
            @Override
            public void run() {
                try {

                    ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);
                    ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");
                    ClientMetaUtil.updateSettingsValueByKey(META.DATA_SYNC_TIME, "0");
                    ClientMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, "0");
                    ClientMetaUtil.updateSettingsValueByKey(META.FORCE_SET_MAIN,"1");
                    //扩大PRINTNO，
                    String printNo = ClientMetaUtil.getSettingsValueByKey(META.PRINT_NO);
                    DBMetaUtil.updateSettings(ClientMetaUtil.getAllValue());
                    ClientMetaUtil.updateSettingsValueByKey(META.PRINT_NO, StringUtil.toInt(printNo, 100) + 1000);
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbSeqNo set fiSeqNo=fiSeqNo+100 where fscls in ('Documentflow','Orderflow')");

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    ToastUtil.showToast("请重启APP");
                    //定时重启
//                    reluanchAfterSeconds(host.getContextWithinHost(), 1000 * 4);
                    //杀进程
                    try {
                        Thread.sleep(2 * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progress.dismiss();
                    exit(host);

                }
            }
        }).start();
    }

    public static void reluanchAfterSeconds(final Context context, long delay) {
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        intent.setAction("com.mwee.android.pos.dinner.boot");
        intent.setPackage(context.getPackageName());

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        am.set(AlarmManager.RTC, System.currentTimeMillis() + delay, pendingIntent);
    }

    public static void exit(final Host context) {
        BootDistribution.exitApp(context);
    }

    public static void exitAllProcssAfterSeconds(final Context context) {
        //关闭所有数据库的链接
        APPConfig.closeAllDBInstance();
        //通知打印进程关闭数据库的链接
        PrintConnector.getInstance().killProcess();
        //通知业务中心进程关闭链接
        ServerConnector.getInstance().sendExecute("biz/killprocess");

        //1秒钟后杀进程
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
                List<ActivityManager.RunningAppProcessInfo> proList = am.getRunningAppProcesses();
                final String packageName = context.getPackageName();
                LogUtil.log("准备杀进程，packageName = " + packageName + "  proList.size() = " + proList.size());
                for (int i = proList.size() - 1; i >= 0; i--) {
                    ActivityManager.RunningAppProcessInfo temp = proList.get(i);
                    LogUtil.log("准备杀进程，temp.processName = " + temp.processName + "  temp.pid = " + temp.pid);
                    if(!TextUtils.equals(temp.processName,packageName)) {
                        if (temp.processName.startsWith(packageName)) {
                            LogUtil.log("杀进程：" + temp.processName + "  "  + temp.pid);
                            android.os.Process.killProcess(temp.pid);
                        }
                    }
                }
                AliHotFix.killSelf();
            }
            //            调整时间延迟为200毫秒：不知历史原因为何添加延时机制，但为解决在延时时间限制之内重新打开应用时发现数据库资源已释放的问题
        },200);

    }
}
