package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.db.business.order.OrderMemberInfo;
import com.mwee.android.pos.dinner.R;

/**
 * Created by chris on 16/8/11.
 */
public class MemberOrderUnBindDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    public final static String MODULE_NAME = "memberInfo";
    private Button mMemberSelectUnBindBtn;
    private OnMemberInfoListener listener;
    private TextView mMemberInfoNameLabel;
    private TextView mMemberInfoSexLabel;
    private TextView mMemberInfoBirthdayLabel;
    private TextView mMemberInfoPhoneLabel;
    private TextView mMemberInfoLevelNameLabel;
    private TextView mMemberInfoCardNumberNameLabel;
    private ImageView mMemberInfoLevelIconImg;

    public interface OnMemberInfoListener {
        void onUnbindMember();
    }

    public void setParam(OnMemberInfoListener listener) {
        this.listener = listener;
    }

    public static MemberOrderUnBindDialogFragment getInstance(OrderMemberInfo memberInfoS) {
        MemberOrderUnBindDialogFragment fragment = new MemberOrderUnBindDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable("member", memberInfoS);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.member_info_view, container, false);
        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMemberSelectUnBindBtn = (Button) view.findViewById(R.id.mMemberSelectUnBindBtn);
        mMemberInfoNameLabel = (TextView) view.findViewById(R.id.mMemberInfoNameLabel);
        mMemberInfoSexLabel = (TextView) view.findViewById(R.id.mMemberInfoSexLabel);
        mMemberInfoBirthdayLabel = (TextView) view.findViewById(R.id.mMemberInfoBirthdayLabel);
        mMemberInfoPhoneLabel = (TextView) view.findViewById(R.id.mMemberInfoPhoneLabel);
        mMemberInfoLevelNameLabel = (TextView) view.findViewById(R.id.mMemberInfoLevelNameLabel);
        mMemberInfoCardNumberNameLabel = (TextView) view.findViewById(R.id.mMemberInfoCardNumberNameLabel);
        mMemberInfoLevelIconImg = (ImageView) view.findViewById(R.id.mMemberInfoLevelIconImg);
        mMemberSelectUnBindBtn.setOnClickListener(this);
        OrderMemberInfo member = (OrderMemberInfo) getArguments().getSerializable("member");
        if (member != null) {
            setMemberInfo(member);
        } else {
            mMemberInfoNameLabel.setText("");
            mMemberInfoSexLabel.setText("");
            mMemberInfoBirthdayLabel.setText("");
            mMemberInfoPhoneLabel.setText("");
            mMemberInfoLevelNameLabel.setText("");
            mMemberInfoCardNumberNameLabel.setText("");
        }
    }

    public void setMemberInfo(OrderMemberInfo memberCardModel) {
        //会员卡用户信息
        mMemberInfoNameLabel.setText(memberCardModel.real_name);
        mMemberInfoSexLabel.setText(memberCardModel.optGender());
        mMemberInfoBirthdayLabel.setText(memberCardModel.birthday);
        mMemberInfoPhoneLabel.setText(memberCardModel.mobile);
        mMemberInfoLevelNameLabel.setText(memberCardModel.level_name);
        mMemberInfoCardNumberNameLabel.setText(memberCardModel.card_no);
        switch (memberCardModel.level) {//1.粉丝 2.普通 3.黄金 4.铂金 5.钻石
            case 1:
                mMemberInfoLevelIconImg.setImageResource(R.drawable.ic_member_level_1);
                break;
            case 2:
                mMemberInfoLevelIconImg.setImageResource(R.drawable.ic_member_level_normal);
                break;
            case 3:
                mMemberInfoLevelIconImg.setImageResource(R.drawable.ic_member_level_gold);
                break;
            case 4:
                mMemberInfoLevelIconImg.setImageResource(R.drawable.ic_member_level_4);
                break;
            case 5:
                mMemberInfoLevelIconImg.setImageResource(R.drawable.ic_member_level_diamonds);
                break;
            default:
                break;
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mMemberSelectUnBindBtn:
                listener.onUnbindMember();
                dismiss();
                break;
        }
    }
}
