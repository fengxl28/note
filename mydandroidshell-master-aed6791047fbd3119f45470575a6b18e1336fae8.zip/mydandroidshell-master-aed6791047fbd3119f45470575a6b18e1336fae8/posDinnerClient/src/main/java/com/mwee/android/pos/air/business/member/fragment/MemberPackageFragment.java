package com.mwee.android.pos.air.business.member.fragment;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.air.business.member.dialog.MemberPackageDialogFragment;
import com.mwee.android.pos.air.business.member.entity.MemberPackageContainer;
import com.mwee.android.pos.air.business.member.entity.MemberPackageModel;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberResponse;
import com.mwee.android.pos.air.business.member.processor.MemberEditorProcessor;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/01/26.
 */

public class MemberPackageFragment extends BaseListFragment<MemberPackageModel> implements MemberPackageDialogFragment.OnMemberLevelEditorListener {


    /**
     * 套餐处理都是整体提交
     * 1 编辑 整体编辑
     * 2 删除 整体删除
     * 3 添加 整体添加
     */

    private MemberEditorProcessor mMemberEditorProcessor;

    private ArrayList<MemberPackageModel> addCache = new ArrayList<>();
    private ArrayList<MemberPackageModel> editorCache = new ArrayList<>();
    private ArrayList<MemberPackageModel> deleteCache = new ArrayList<>();
    private View mEmptyLayout;


    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_air_member_package;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(getContext()).inflate(R.layout.view_member_package_item, parent, false));
    }

    @Override
    protected void initView(View view) {
        super.initView(view);

        view.findViewById(R.id.mMemberPackageSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doSave();
            }
        });

        //view.findViewById(R.id.mMenuEmptyLabel);
        mEmptyLayout = view.findViewById(R.id.mEmptyLayout);
        ImageView mMenuEmptyLabel = view.findViewById(R.id.mMenuEmptyLabel);
        mMenuEmptyLabel.setImageResource(R.drawable.icon_package_set);
        TextView tvEmptyCreateFirst = view.findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建充值套餐");
        tvEmptyCreateFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doAddMemberPackage();
            }
        });

    }

    @Override
    protected void initData() {
        super.initData();
        adapter.isFooterShow = true;
        mMemberEditorProcessor = new MemberEditorProcessor();
        mPullRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
        loadDataFromServer();
    }

    private void loadDataFromServer() {

        final Progress progress = ProgressManager.showProgress(this);
        mMemberEditorProcessor.loadShopMemberRule(new ResultCallback<AirMemberResponse>() {
            @Override
            public void onSuccess(AirMemberResponse data) {
                ArrayList<MemberPackageContainer> rechargepkg_list = data.data.rechargepkg_list;
                refreshMemberPackageAdapter(rechargepkg_list);
                clearCache();
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


    private void refreshMemberPackageAdapter(ArrayList<MemberPackageContainer> rechargepkg_list) {

        if (!ListUtil.isEmpty(rechargepkg_list) && rechargepkg_list.size() > 0) {
            adapter.modules.clear();
            adapter.modules.addAll(rechargepkg_list.get(0).recharge_rules);
            adapter.notifyDataSetChanged();
        }
        mEmptyLayout.setVisibility(ListUtil.isEmpty(modules) ? View.VISIBLE : View.GONE);


    }


    /**
     * 添加会员套餐
     */
    private void doAddMemberPackage() {

        MemberPackageDialogFragment memberPackageDialogFragment = new MemberPackageDialogFragment();
        memberPackageDialogFragment.setOnMemberLevelEditorListener(this);
        memberPackageDialogFragment.setCostMoneyCache(buildCostMoneyCache());
        memberPackageDialogFragment.show(getFragmentManagerWithinHost(), "");

    }

    /**
     * 编辑会员套餐
     *
     * @param model
     */
    private void doEditorMmberPackage(MemberPackageModel model) {

        MemberPackageDialogFragment memberPackageDialogFragment = new MemberPackageDialogFragment();
        memberPackageDialogFragment.setOnMemberLevelEditorListener(this);
        memberPackageDialogFragment.setParam(model);
        memberPackageDialogFragment.setCostMoneyCache(buildCostMoneyCache());
        memberPackageDialogFragment.show(getFragmentManagerWithinHost(), "");
    }


    /**
     * 保存数据
     */
    public void doSave() {

        if (addCache.isEmpty() && editorCache.isEmpty() && deleteCache.isEmpty()) {
            ToastUtil.showToast("请先进行会员套餐操作,再进行保存");
            return;
        }

        //构建新增规则
        JSONArray addRuleDataArray = new JSONArray();
        for (int i = 0; i < addCache.size(); i++) {
            MemberPackageModel model = addCache.get(i);
            JSONObject addRuleData = new JSONObject();
            addRuleData.put("present_type", "1,2");//类型 0=>不赠送  1=>金额    2=>积分 3=>优惠券 2，3同时送积分和优惠券
            addRuleData.put("money", new BigDecimal(model.money));
            addRuleData.put("present_price", TextUtils.isEmpty(model.present_price) ? "0" : model.present_price);
            addRuleData.put("present_score", TextUtils.isEmpty(model.present_score) ? "0" : model.present_score);
            addRuleDataArray.add(addRuleData);
        }

        //构建编辑规则
        JSONArray editorRuleDataArray = new JSONArray();
        for (int i = 0; i < editorCache.size(); i++) {
            MemberPackageModel model = editorCache.get(i);
            JSONObject editorRuleData = new JSONObject();
            editorRuleData.put("id", model.id);//类型 0=>不赠送  1=>金额    2=>积分 3=>优惠券 2，3同时送积分和优惠券
            editorRuleData.put("money", new BigDecimal(model.money));
            editorRuleData.put("present_price", TextUtils.isEmpty(model.present_price) ? "0" : model.present_price);
            editorRuleData.put("present_score", TextUtils.isEmpty(model.present_score) ? "0" : model.present_score);
            editorRuleDataArray.add(editorRuleData);
        }

        //构建删除规则
        JSONArray deleteRuleDataArray = new JSONArray();
        for (int i = 0; i < deleteCache.size(); i++) {
            MemberPackageModel model = deleteCache.get(i);
            JSONObject delRuleData = new JSONObject();
            delRuleData.put("id", model.id);
            deleteRuleDataArray.add(delRuleData);
        }

        //final Progress progress = ProgressManager.showProgressUncancel(this);
        mMemberEditorProcessor.loadMemberPackageSave(addRuleDataArray, editorRuleDataArray, deleteRuleDataArray, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                ToastUtil.showToast("保存充值套餐成功");
                loadDataFromServer();
                //progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                //progress.dismissSelf();
                super.onFailure(code, msg);
            }
        });


    }

    /**
     * 数据编辑成功清除缓存
     */
    private void clearCache() {
        addCache.clear();
        editorCache.clear();
        deleteCache.clear();
    }


    /**
     * 新增会员套餐成功
     * <p>
     * 新增数据 需要存入cache构建规则
     *
     * @param model
     */
    @Override
    public void onMemberPackageAddSuccess(MemberPackageModel model) {
        if (!addCache.contains(model)) {
            addCache.add(model);
        }
        modules.add(model);
        adapter.notifyDataSetChanged();
        mEmptyLayout.setVisibility(ListUtil.isEmpty(modules) ? View.VISIBLE : View.GONE);
    }

    /**
     * 编辑会员套餐成功
     * 编辑CRM后台存在的数据 需要存入editorCache构建规则
     *
     * @param model
     */
    @Override
    public void onMemberPackageEditorSuccess(MemberPackageModel model) {
        if (!TextUtils.isEmpty(model.id) && !editorCache.contains(model)) {
            editorCache.add(model);
        }
        adapter.notifyDataSetChanged();
    }


    /**
     * 删除会员套餐
     * <p>
     * 删除CRM后台存在的数据 需要存入deleteCache构建规则
     *
     * @param model
     */
    private void doDeleteMemberPackage(MemberPackageModel model) {

        DialogManager.showExecuteDialog(getActivityWithinHost(), "请确认是否删除此套餐?", new DialogResponseListener() {
            @Override
            public void response() {

                if (!TextUtils.isEmpty(model.id) && !deleteCache.contains(model)) {
                    deleteCache.add(model);
                }

                //需要移除掉临时的添加缓存数据
                if (TextUtils.isEmpty(model.id) && addCache.contains(model)) {
                    addCache.remove(model);
                }

                modules.remove(model);
                adapter.notifyDataSetChanged();
            }
        });
    }


    class ViewHolder extends BaseViewHolder implements View.OnClickListener {

        private TextView tvRechargeMoney;
        private TextView tvGiftLable;

        private ImageView imgDelete;
        private ImageView imgEditor;

        private MemberPackageModel model;

        public ViewHolder(View itemView) {
            super(itemView);
            tvRechargeMoney = itemView.findViewById(R.id.tvRechargeMoney);
            tvGiftLable = itemView.findViewById(R.id.tvGiftLable);
            imgDelete = itemView.findViewById(R.id.imgDelete);
            imgEditor = itemView.findViewById(R.id.imgEditor);
            imgDelete.setOnClickListener(this);
            imgEditor.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);
            tvRechargeMoney.setText(String.format("充: %s元", model.money));
            tvGiftLable.setText(String.format("赠: %s元   %s积分", TextUtils.isEmpty(model.present_price) ? "0" : model.present_price
                    , TextUtils.isEmpty(model.present_score) ? "0" : model.present_score));
        }

        @Override
        public void onClick(View view) {
            if (!ButtonClickTimer.canClick()) {
                return;
            }
            switch (view.getId()) {
                case R.id.imgDelete:
                    doDeleteMemberPackage(model);
                    break;
                case R.id.imgEditor:
                    doEditorMmberPackage(model);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    protected View onCreateFooterView(ViewGroup parent) {
        super.onCreateFooterView(parent);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.view_footer_add, parent, false);
        TextView mFooterAddLabel = view.findViewById(R.id.mFooterAddLabel);
        mFooterAddLabel.setTextColor(Color.BLACK);
        mFooterAddLabel.setText(" + 新建充值套餐");
        mFooterAddLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doAddMemberPackage();
            }
        });
        return view;
    }


    /**
     * 构建 缓存的充值金额数据
     */
    private List<Integer> buildCostMoneyCache() {

        //缓存的充值金额数据
        List<Integer> costMoneyCache = new ArrayList<>();
        /*for (MemberPackageModel model : addCache) {
            costMoneyCache.add(new BigDecimal(model.money).intValue());
        }
       */
        for (MemberPackageModel module : modules) {
            costMoneyCache.add(new BigDecimal(module.money).intValue());
        }
        return costMoneyCache;
    }


    /**
     * 检测数据源是否发生了改变
     *
     * @return
     */
    public boolean checkDataChange() {

        if (!ListUtil.isEmpty(addCache) || !ListUtil.isEmpty(editorCache) || !ListUtil.isEmpty(deleteCache)) {
            return true;
        }

        return false;

    }


}
