package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderClientUtil;
import com.mwee.android.pos.business.message.processor.netOrder.NetOrderDetailView;
import com.mwee.android.pos.business.message.processor.wechatOrder.WechatOrderClientUtil;
import com.mwee.android.pos.business.message.processor.wechatOrder.WechatOrderDetailView;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.connect.business.wechatorder.GetAllWechatOrderResponse;
import com.mwee.android.pos.connect.business.wechatorder.OptWechatOrderFromBizResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/9/18.
 * 外卖订单对接记录页面
 */
public class BillTakeOutFragment extends BaseListFragment<BusinessBean> implements IDriver, View.OnClickListener {
    public static final String TAG = "billTakeOut";

    public static final String ELEME = TakeAwaySource.ELEME;
    public static final String MEITUAN = TakeAwaySource.MEITUAN;
    public static final String OTHER = "OTHER";
    public static final String WECHAT = "WECHAT";

    private static String dataTypeTag = ELEME;

    private View root_bill;
    private TextView bill_filter_time_tv;

    //饿了么、美团
    private CheckedTextView eleme_rb, meituan_rb, other_rb, wecaht_rb;
    private View eleme_rb_status, meituan_rb_status, other_rb_status, wechat_rb_status;

    private TextView netorder_norecord_tv;

    private String date = AppCache.getInstance().businessDate;

    private BillNetOrderDataProcess billNetOrderDataProcess;

    private int currentPage = 1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.bill_takeout_fragment;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new TakeOutHolder(LayoutInflater.from(getContext()).inflate(R.layout.bill_netorder_item, parent, false));
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        eleme_rb = view.findViewById(R.id.eleme_rb);
        meituan_rb = view.findViewById(R.id.meituan_rb);
        other_rb = view.findViewById(R.id.other_rb);
        wecaht_rb = view.findViewById(R.id.wecaht_rb);
        View mLayoutWeChat = view.findViewById(R.id.mLayoutWeChat);
        if (APPConfig.isAir()) {
            mLayoutWeChat.setVisibility(View.GONE);
        } else {
            mLayoutWeChat.setVisibility(View.VISIBLE);
        }

        eleme_rb_status = view.findViewById(R.id.eleme_rb_status);
        meituan_rb_status = view.findViewById(R.id.meituan_rb_status);
        other_rb_status = view.findViewById(R.id.other_rb_status);
        wechat_rb_status = view.findViewById(R.id.wechat_rb_status);

        root_bill = view.findViewById(R.id.root_bill);
        bill_filter_time_tv = view.findViewById(R.id.bill_filter_time_tv);
        netorder_norecord_tv = view.findViewById(R.id.netorder_norecord_tv);

        registerEvent();
        eleme_rb.performClick();
    }

    private void registerEvent() {
        bill_filter_time_tv.setOnClickListener(this);
        eleme_rb.setOnClickListener(this);
        meituan_rb.setOnClickListener(this);
        other_rb.setOnClickListener(this);
        wecaht_rb.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        super.initData();
        dataTypeTag = ELEME;
        billNetOrderDataProcess = new BillNetOrderDataProcess();

        updateBussinessDate();

        mPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
            modules.clear();
            adapter.notifyDataSetChanged();
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    private void loadDataFromServer(int mode) {
        if (billNetOrderDataProcess == null) {
            billNetOrderDataProcess = new BillNetOrderDataProcess();
        }
        if (isWeChatTag()) {
            billNetOrderDataProcess.getAllWechatOrderData(currentPage, date, new ResultCallback<GetAllWechatOrderResponse>() {
                @Override
                public void onSuccess(GetAllWechatOrderResponse data) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.wechatOrderModelList)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshAdapter(data.wechatOrderModelList);
                    }
                }

                @Override
                public void onFailure(int code, String msg) {
                    loadDataFailed(mode, code, msg);
                    super.onFailure(code, msg);
                }
            });
        } else {
            billNetOrderDataProcess.getAllData(currentPage, date, dataTypeTag, new ResultCallback<GetAllNetOrderResponse>() {
                @Override
                public void onSuccess(GetAllNetOrderResponse data) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.tempAppOrderList)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshAdapter(data.tempAppOrderList);
                    }
                }

                @Override
                public void onFailure(int code, String msg) {
                    loadDataFailed(mode, code, msg);
                    super.onFailure(code, msg);
                }
            });
        }
    }

    public void refreshAdapter(List data) {
        modules.addAll(data);
        if (ListUtil.isEmpty(modules)) {
            mPullRecyclerView.setVisibility(View.GONE);
            netorder_norecord_tv.setVisibility(View.VISIBLE);
        } else {
            mPullRecyclerView.setVisibility(View.VISIBLE);
            netorder_norecord_tv.setVisibility(View.GONE);
        }
        adapter.notifyDataSetChanged();
    }

    private void loadDataFailed(int mode, int code, String msg) {
        BaseToastUtil.showToast(msg);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            if (modules.size() == 0) {
                mPullRecyclerView.showEmptyView();
            }
            mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
        } else {
            mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
        }
    }

    /**
     * 刷新网络订单账单列表
     */
    @DrivenMethod(uri = TAG + "/refrehNetOrderData")
    public void refrehNetOrderData() {
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    private boolean isWeChatTag() {
        return TextUtils.equals(dataTypeTag, WECHAT);
    }

    private void updateBussinessDate() {
        bill_filter_time_tv.setText(date);
    }

    @Override
    public void onClick(final View view) {
        if (!ButtonClickTimer.canClick(200)) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_bill_netorder_detail:   //外卖单详情
                if (isWeChatTag()) {
                    WechatOrderModel wechatOrderModel = (WechatOrderModel) view.getTag(R.integer.tv_bill_wechatorder_detail);
                    getWechatOrderDetail(wechatOrderModel.fsorderno, 0);
                } else {
                    TempAppOrder netOrder = (TempAppOrder) view.getTag(R.integer.tv_bill_netorder_detail);
                    getNetOrderDetail(netOrder.orderId + "", 0);
                }
                break;
            case R.id.tv_bill_netorder_print:   //外卖单打印
                if (isWeChatTag()) {
                    WechatOrderModel wechatOrderModel = (WechatOrderModel) view.getTag(R.integer.tv_bill_wechatorder_print);
                    getWechatOrderDetail(wechatOrderModel.fsorderno, 1);
                } else {
                    TempAppOrder tempAppOrder = (TempAppOrder) view.getTag(R.integer.tv_bill_netorder_print);
                    getNetOrderDetail(tempAppOrder.orderId + "", 1);
                }
                ProgressManager.showProgress(getActivityWithinHost(), "打印中...", true);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ProgressManager.closeProgress(getActivityWithinHost());
                    }
                }, 1000);
                break;
            case R.id.bill_filter_time_tv:
                //日期筛选
                CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), root_bill);
                calendarPopupwindow.setDate(date);
                calendarPopupwindow.show();
                calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
                    @Override
                    public void onConfirm(String newDate) {
                        ActionLog.addLog("切换日期：" + date, "", "", ActionLog.SS_NET_WORK, date);
                        date = newDate;
                        updateBussinessDate();
                        mPullRecyclerView.setRefreshing();
                    }
                });
                break;
            case R.id.eleme_rb: //饿了么
                clickEleme();
                ActionLog.addLog("查看饿了么订单记录：", "", "", ActionLog.SS_NET_WORK, "");
                break;
            case R.id.meituan_rb:  //美团
                clickMeituan();
                ActionLog.addLog("查看美团订单记录：", "", "", ActionLog.SS_NET_WORK, "");
                break;
            case R.id.other_rb:  //其他
                clickOther();
                ActionLog.addLog("查看其他订单记录：", "", "", ActionLog.SS_NET_WORK, "");
                break;
            case R.id.wecaht_rb:  //微信外卖
                clickWechatOrder();
                ActionLog.addLog("查看微信外卖记录：", "", "", ActionLog.SS_NET_WORK, "");
                break;
            default:
                break;
        }
    }

    private void getNetOrderDetail(String orderId, int showOrPrint) { // showOrPrint: 0-show, 1-print
        NetOrderClientUtil.optTempAppOrderFromBizById(orderId, new ResultCallback<OptNetOrderFromBizResponse>() {
            @Override
            public void onSuccess(OptNetOrderFromBizResponse data) {
                TempAppOrder order = data.tempAppOrder;
                if (showOrPrint == 0) {
                    showNetOrderDetail(order);
                } else if (showOrPrint == 1) {
                    NetOrderClientUtil.printNetworkOrder(order.orderId, 1, AppCache.getInstance().currentHostId, AppCache.getInstance().userDBModel.fsUserName);
                    ActionLog.addLog("手动打印外卖单：", "", "", ActionLog.SS_NET_WORK, order);
                    LogUtil.logBusiness("手动打印外卖单" + order.orderId);
                }
            }
        });
    }

    private void getWechatOrderDetail(String orderId, int showOrPrint) { // showOrPrint: 0-show, 1-print
        WechatOrderClientUtil.optWechatOrderFromBizById(orderId, new ResultCallback<OptWechatOrderFromBizResponse>() {
            @Override
            public void onSuccess(OptWechatOrderFromBizResponse data) {
                WechatOrderModel order = data.wechatOrderModel;
                if (showOrPrint == 0) {
                    showWechatOrderDetail(order);
                } else if (showOrPrint == 1) {
                    WechatOrderClientUtil.printWechatOrkOrder(order.fsorderno, 1, AppCache.getInstance().currentHostId, AppCache.getInstance().userDBModel.fsUserName);
                    ActionLog.addLog("手动打印外卖单：", "", "", ActionLog.SS_NET_WORK, order);
                    LogUtil.logBusiness("手动打印外卖单" + order.fsorderno);
                }
            }
        });
    }

    private void showNetOrderDetail(TempAppOrder netOrder) {
        if (netOrder != null) {
            NetOrderDetailView netOrderDetailView = new NetOrderDetailView(BillTakeOutFragment.this.getContext());
            netOrderDetailView.setHost(BillTakeOutFragment.this);
            netOrderDetailView.updateData(netOrder, false);
            NetOrderDetailDialog unitDialog = NetOrderDetailDialog.getDialog(new NetOrderDetailDialog.OnClickDialogListener() {
                @Override
                public void onClickLeftBtn(NetOrderDetailDialog dialog) {
                    dialog.dismissSelf();
                }

                @Override
                public void onClickRightBtn(NetOrderDetailDialog dialog) {
                    dialog.dismissSelf();
                }
            }, "外卖订单详情", "", "确定", netOrderDetailView);
            unitDialog.show(BillTakeOutFragment.this.getFragmentManagerWithinHost(), "tempAppOrderDetail");
            ActionLog.addLog("查看外卖单详情", "", "", ActionLog.SS_NET_WORK, netOrder);
            LogUtil.logBusiness("查看外卖单详情" + netOrder.orderId);
        }
    }

    private void showWechatOrderDetail(WechatOrderModel wechatOrderModel) {
        if (wechatOrderModel != null) {
            WechatOrderDetailView wechatOrderDetailView = new WechatOrderDetailView(BillTakeOutFragment.this.getContext());
            wechatOrderDetailView.setHost(BillTakeOutFragment.this);
            wechatOrderDetailView.updateData(wechatOrderModel, false);
            NetOrderDetailDialog unitDialog = NetOrderDetailDialog.getDialog(new NetOrderDetailDialog.OnClickDialogListener() {
                @Override
                public void onClickLeftBtn(NetOrderDetailDialog dialog) {
                    dialog.dismissSelf();
                }

                @Override
                public void onClickRightBtn(NetOrderDetailDialog dialog) {
                    dialog.dismissSelf();
                }
            }, "外卖订单详情", "", "确定", wechatOrderDetailView);
            unitDialog.show(BillTakeOutFragment.this.getFragmentManagerWithinHost(), "tempAppOrderDetail");
            ActionLog.addLog("查看外卖单详情", "", "", ActionLog.SS_NET_WORK, wechatOrderModel);
            LogUtil.logBusiness("查看外卖单详情" + wechatOrderModel.fsorderno);
        }
    }

    /**
     * 点击饿了么
     */
    private void clickEleme() {
        if (TextUtils.equals(dataTypeTag, ELEME)) {
            return;
        }
        eleme_rb.setChecked(true);
        meituan_rb.setChecked(false);
        other_rb.setChecked(false);
        wecaht_rb.setChecked(false);
        eleme_rb_status.setVisibility(View.VISIBLE);
        meituan_rb_status.setVisibility(View.GONE);
        other_rb_status.setVisibility(View.GONE);
        wechat_rb_status.setVisibility(View.GONE);
        dataTypeTag = ELEME;
        currentPage = 1;
        mPullRecyclerView.setRefreshing();
    }

    /**
     * 点击美团
     */
    private void clickMeituan() {
        if (TextUtils.equals(dataTypeTag, MEITUAN)) {
            return;
        }
        eleme_rb_status.setVisibility(View.GONE);
        meituan_rb_status.setVisibility(View.VISIBLE);
        other_rb_status.setVisibility(View.GONE);
        wechat_rb_status.setVisibility(View.GONE);
        meituan_rb.setChecked(true);
        eleme_rb.setChecked(false);
        other_rb.setChecked(false);
        wecaht_rb.setChecked(false);
        dataTypeTag = MEITUAN;
        currentPage = 1;
        mPullRecyclerView.setRefreshing();
    }

    /**
     * 点击其他
     */
    private void clickOther() {
        if (TextUtils.equals(dataTypeTag, OTHER)) {
            return;
        }
        eleme_rb_status.setVisibility(View.GONE);
        meituan_rb_status.setVisibility(View.GONE);
        other_rb_status.setVisibility(View.VISIBLE);
        wechat_rb_status.setVisibility(View.GONE);
        meituan_rb.setChecked(false);
        eleme_rb.setChecked(false);
        other_rb.setChecked(true);
        wecaht_rb.setChecked(false);
        dataTypeTag = OTHER;
        currentPage = 1;
        mPullRecyclerView.setRefreshing();
    }

    /**
     * 点击微信外卖
     */
    private void clickWechatOrder() {
        if (TextUtils.equals(dataTypeTag, WECHAT)) {
            return;
        }
        eleme_rb_status.setVisibility(View.GONE);
        meituan_rb_status.setVisibility(View.GONE);
        other_rb_status.setVisibility(View.GONE);
        wechat_rb_status.setVisibility(View.VISIBLE);
        meituan_rb.setChecked(false);
        eleme_rb.setChecked(false);
        other_rb.setChecked(false);
        wecaht_rb.setChecked(true);
        dataTypeTag = WECHAT;
        currentPage = 1;
        mPullRecyclerView.setRefreshing();
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    class TakeOutHolder extends BaseViewHolder {

        private TextView tv_bill_netorder_id;
        private TextView tv_bill_netorder_total;
        private TextView tv_bill_netorder_time;
        private TextView tv_bill_netorder_status;
        private TextView tv_bill_netorder_pay_status;
        private TextView tv_bill_netorder_detail;
        private TextView tv_bill_netorder_print;

        public TakeOutHolder(View itemView) {
            super(itemView);
            tv_bill_netorder_id = itemView.findViewById(R.id.tv_bill_netorder_id);
            tv_bill_netorder_total = itemView.findViewById(R.id.tv_bill_netorder_total);
            tv_bill_netorder_time = itemView.findViewById(R.id.tv_bill_netorder_time);
            tv_bill_netorder_status = itemView.findViewById(R.id.tv_bill_netorder_status);
            tv_bill_netorder_pay_status = itemView.findViewById(R.id.tv_bill_netorder_pay_status);
            tv_bill_netorder_detail = itemView.findViewById(R.id.tv_bill_netorder_detail);
            tv_bill_netorder_print = itemView.findViewById(R.id.tv_bill_netorder_print);
        }

        @Override
        public void bindData(int position) {
            BusinessBean temp = modules.get(position);
            if (isWeChatTag() && temp instanceof WechatOrderModel) {
                bindWeChatData(temp);
            } else if (temp instanceof TempAppOrder) {
                bindNormalData(temp);
            }
        }

        private void bindNormalData(BusinessBean source) {
            TempAppOrder data = (TempAppOrder) source;
            tv_bill_netorder_id.setText(data.orderId);
            tv_bill_netorder_total.setText(Calc.formatShow(data.total));
            tv_bill_netorder_time.setText(data.date);
            tv_bill_netorder_status.setText(data.optOrderStatus());
            tv_bill_netorder_pay_status.setText(data.optPayStatus());

            tv_bill_netorder_detail.setVisibility(View.VISIBLE);
            tv_bill_netorder_print.setVisibility(View.VISIBLE);

            tv_bill_netorder_detail.setOnClickListener(BillTakeOutFragment.this);
            tv_bill_netorder_detail.setTag(R.integer.tv_bill_netorder_detail, data);

            tv_bill_netorder_print.setOnClickListener(BillTakeOutFragment.this);
            tv_bill_netorder_print.setTag(R.integer.tv_bill_netorder_print, data);
        }

        private void bindWeChatData(BusinessBean source) {
            WechatOrderModel data = (WechatOrderModel) source;
            tv_bill_netorder_id.setText(data.fsorderno);
            tv_bill_netorder_total.setText(Calc.formatShow(data.fdrealamount));
            tv_bill_netorder_time.setText(data.fscreatetime);
            tv_bill_netorder_status.setText(data.optStatus());
            tv_bill_netorder_pay_status.setText(data.optPayState());

            tv_bill_netorder_detail.setVisibility(View.VISIBLE);
            tv_bill_netorder_print.setVisibility(View.VISIBLE);

            tv_bill_netorder_detail.setOnClickListener(BillTakeOutFragment.this);
            tv_bill_netorder_detail.setTag(R.integer.tv_bill_wechatorder_detail, data);

            tv_bill_netorder_print.setOnClickListener(BillTakeOutFragment.this);
            tv_bill_netorder_print.setTag(R.integer.tv_bill_wechatorder_print, data);
        }
    }
}
