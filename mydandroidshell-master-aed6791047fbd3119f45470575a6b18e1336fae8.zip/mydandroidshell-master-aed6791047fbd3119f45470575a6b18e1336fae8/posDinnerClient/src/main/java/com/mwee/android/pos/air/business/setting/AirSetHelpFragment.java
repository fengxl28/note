package com.mwee.android.pos.air.business.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.air.business.payment.component.PaymentConstant;
import com.mwee.android.pos.air.business.tshop.THelpActivity;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.setting.jump.JumpToFragment;
import com.mwee.android.pos.business.setting.view.AdminConfigFragment;
import com.mwee.android.pos.business.setting.view.LogSearchFragment;
import com.mwee.android.pos.business.sync.view.BizCenterConfigFragment;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;

/**
 * Created by zhangmin on 2017/12/13.
 */

public class AirSetHelpFragment extends BaseFragment implements View.OnClickListener{


    /*管理员设置*/
    private TextView tv_dinner_name;
    private TextView tv_dinner_id;
    private TextView tv_set_connect;
    private TextView tv_config;
    private TextView tvHelp;
    private TextView tv_contronl_msg;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_set_help_fragment_layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        initData();
    }

    private void assignViews(View container) {

        /*管理员设置*/
        tv_dinner_name = (TextView) container.findViewById(R.id.tv_dinner_name);
        tv_dinner_id = (TextView) container.findViewById(R.id.tv_dinner_id);
        tv_set_connect = (TextView) container.findViewById(R.id.tv_set_connect);
        tv_config = (TextView) container.findViewById(R.id.tv_config);
        tvHelp = (TextView) container.findViewById(R.id.tvHelp);
        tv_contronl_msg = (TextView) container.findViewById(R.id.tv_contronl_msg);



    }


    private void registerEvent() {

        tv_set_connect.setOnClickListener(this);
        tv_config.setOnClickListener(this);
        tvHelp.setOnClickListener(this);
        tv_contronl_msg.setOnClickListener(this);


    }


    private void initData() {

        tv_dinner_name.setText(AppCache.getInstance().shop.fsShopName);
        tv_dinner_id.setText(AppCache.getInstance().fsShopGUID);

    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {

            case R.id.tv_feedback:
                ActionLog.addLog("更多设置->点击了意见反馈", "", "", ActionLog.SS_MORE_JOIN, "");
                JumpToFragment.jumpFeedBackFragment(getActivityWithinHost());
                break;

            case R.id.tvHelp:
                ActionLog.addLog("更多设置->点击了操作指南", "", "", ActionLog.SS_MORE_JOIN, "");
                Intent intent = new Intent(getContextWithinHost(), THelpActivity.class);
                intent.putExtra(THelpActivity.KEY_TITLE_CONTENT, "操作指南");
                intent.putExtra(THelpActivity.KEY_WEB_URI, PaymentConstant.getUrlHelp());
                startActivity(intent);
                break;

            case R.id.tv_config:
                ActionLog.addLog("更多设置->点击了后台设置", "", "", ActionLog.SS_MORE_JOIN, "");
                AdminConfigFragment adminConfigFragment = new AdminConfigFragment();
                FragmentController.addFragment(getActivityWithinHost(), adminConfigFragment);
                break;

            case R.id.tv_contronl_msg:
                ActionLog.addLog("更多设置->点击了操作日志入口", "", "", ActionLog.SS_MORE_JOIN, "");
                BusinessExecutor.executeAsyncExcute(new ASyncExecute<Object>() {
                    @Override
                    public Object execute() {
                        MwLog.writeToIONow();
                        return null;
                    }
                }, new SyncCallback<Object>() {
                    @Override
                    public void callback(Object o) {
                        LogSearchFragment logSearchFragment = new LogSearchFragment();
                        FragmentController.addFragment(getActivityWithinHost(), logSearchFragment);
                    }
                });
                break;
            case R.id.tv_set_connect:
                ActionLog.addLog("更多设置->点击了IP设置", "", "", ActionLog.SS_MORE_JOIN, "");
                BizCenterConfigFragment fragment = new BizCenterConfigFragment();
                FragmentController.addFragment(getActivityWithinHost(), fragment);
                break;
            default:
                break;
        }

    }

}
