package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.pos.air.business.member.entity.MemberLevelModel;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class AirMemberLeverResponse extends BaseMemberResponse {


    public ArrayList<MemberLevelModel> data = new ArrayList<>();

    public AirMemberLeverResponse(){

    }
}
