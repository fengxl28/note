package com.mwee.android.pos.business.fastfood.proccessor;

import android.text.TextUtils;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.common.fastfood.IFastFoodProcessor;
import com.mwee.android.pos.business.fastfood.api.FastFoodOrderSocketApi;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.pay.component.PayViewUtil;
import com.mwee.android.pos.business.pay.view.PayNetProcessor;
import com.mwee.android.pos.business.pay.view.component.IPayCallback;
import com.mwee.android.pos.business.pay.view.netpay.INetPayResult;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.fastfood.FastFoodOrderListResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.model.PayViewBaseData;
import com.mwee.android.pos.connect.business.pay.model.PayViewBean;
import com.mwee.android.pos.connect.callback.AbstractCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.ToastUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * 快餐单相关业务处理
 * Created by qinwei on 2017/4/10.
 */

public class FastFoodProcessor implements IFastFoodProcessor {
    private FastFoodOrdersViewProcessor viewProcessor;

    @Override
    public void setViewProcessor(FastFoodOrdersViewProcessor viewProcessor) {
        this.viewProcessor=viewProcessor;
    }

    @Override
    public void loadOpenOrder(String fsBillSourceId, final ResultCallback<StartFastFoodOrderResponse> callback) {
        FastFoodOrderSocketApi.loadOpenFastFoodOrder(fsBillSourceId, new AbstractCallback<StartFastFoodOrderResponse>() {
            @Override
            public void onSuccess(StartFastFoodOrderResponse response) {
                AppCache.getInstance().currentOrderID = response.fastOrderModel.orderId;
                AppCache.getInstance().refreshOrderToken(response.orderOptToken);
                callback.onSuccess(response);
            }

            @Override
            public void onFailure(int code, String msg) {
                callback.onFailure(code, msg);
            }
        });
    }

    @Override
    public void loadOrderToCenter(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, final ResultCallback<OnlyOrderMenuItemsResponse> callback) {
        FastFoodOrderSocketApi.loadSynOrderCache(orderId, menuItems, mealNumber, SettingHelper.isShouldContinueOpen(), new ResultCallback<OnlyOrderMenuItemsResponse>() {
            @Override
            public void onSuccess(OnlyOrderMenuItemsResponse response) {
                if (response.fastOrderModel != null) {
                    AppCache.getInstance().currentOrderID = response.fastOrderModel.orderId;
                    AppCache.getInstance().refreshOrderToken(response.orderOptToken);
                }
                callback.onSuccess(response);
            }

            @Override
            public void onFailure(int code, String msg) {
                callback.onFailure(code, msg);
            }
        });
    }

    @Override
    public void loadOrderCacheById(String orderId, final ResultCallback<StartFastFoodOrderResponse> callback) {
        FastFoodOrderSocketApi.loadOrderCacheById(orderId, new AbstractCallback<StartFastFoodOrderResponse>() {
            @Override
            public void onSuccess(StartFastFoodOrderResponse response) {
                AppCache.getInstance().currentOrderID = response.fastOrderModel.orderId;
                AppCache.getInstance().refreshOrderToken(response.orderOptToken);
                callback.onSuccess(response);
            }

            @Override
            public void onFailure(int code, String msg) {
                callback.onFailure(code, msg);
            }
        });
    }

    @Override
    public void loadAllFastFoodOrder(String fsBillSourceId, final ResultCallback<List<FastFoodSimpInfo>> callback) {
        FastFoodOrderSocketApi.loadAllFastFoodOrder(fsBillSourceId, AppCache.getInstance().businessDate, new SocketCallback<FastFoodOrderListResponse>() {
            @Override
            public void callback(SocketResponse<FastFoodOrderListResponse> response) {
                if (response.code == SocketResultCode.SUCCESS && response.data != null) {
                    callback.onSuccess(response.data.fastFoodSimpInfoList);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        });
    }

    @Override
    public void refreshAllData(String fsBillSourceId, final IResult iResult) {
        FastFoodOrderSocketApi.loadAllFastFoodOrder(fsBillSourceId, AppCache.getInstance().businessDate, new SocketCallback<FastFoodOrderListResponse>() {
            @Override
            public void callback(SocketResponse<FastFoodOrderListResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS && socketResponse.data != null) {
                    viewProcessor.updateAllOrderssData(socketResponse.data.fastFoodSimpInfoList);
                    iResult.callBack(true, "");
                } else {
                    iResult.callBack(false, socketResponse.message);
                }

            }
        });
    }

    @Override
    public void doOnlinePay(final Host host, final PayViewBaseData baseData, PayViewBean viewBean, final IPayCallback callback) {
        PayNetProcessor netProcessor = new PayNetProcessor();
        netProcessor.setHost(host);
        UserDBModel userDBModel = AppCache.getInstance().userDBModel;
        final PayModel currentSelectPay = new PayModel(userDBModel.fsUserId, userDBModel.fsUserName);
        currentSelectPay.payAmount = viewBean.amtLeftToPay;
        if (viewBean.amtLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
            ToastUtil.showToast("待支付金额为0");
            return;
        }
        netProcessor.jumpToNetPay(baseData, viewBean, null, new INetPayResult() {
            @Override
            public void result(int result, String msg, String netPayBllNO, SocketResponse<PayResultResponse> socketResponse) {
                if (socketResponse.success()) {
                    if (socketResponse.data.payFinished) {
                        PrintReceiptUtil.printAfterPayFinish(AppCache.getInstance().currentHostId);
                        if (callback != null) {
                            callback.payFinish(IPayCallback.FINISH);
                        }
                    }
                } else {
                    ToastUtil.showToast(socketResponse.message);
                }
            }
        });
    }

    @Override
    public void loadUpdateMealNumber(String orderID, String count, final ResultCallback<String> callback) {
        FastFoodOrderSocketApi.loadUpdateMealNumber(orderID, count, callback);
    }


    @Override
    public boolean checkOrder(FastFoodDishCache dishCache) {
        if (dishCache != null) {
            RunTimeLog.addLog(RunTimeLog.FAST_ORDER, "dishesorde 用户点击结账按钮,orderid=" + dishCache.fastOrderModel.orderId);
        }
        String checkDishWeightError = OrderDishesBizUtil.checkOrderCanPay(dishCache.menuItems);
        if (!TextUtils.isEmpty(checkDishWeightError)) {
            ToastUtil.showToast(checkDishWeightError);
            return false;
        }
        String checkError = PayViewUtil.canPay(AppCache.getInstance().userDBModel.fsUserId);
        if (!TextUtils.isEmpty(checkError)) {
            ToastUtil.showToast(checkError);
            return false;
        }
        return true;
    }

    @Override
    public void loadUpdateBillSource(String orderId, String billSourceId, final ResultCallback<String> callback) {
        FastFoodOrderSocketApi.loadUpdateBillSource(orderId, billSourceId, callback);
    }

    @Override
    public void clearNewMenuItemList(FastFoodDishCache dishCache) {
        for (int i = 0; i < dishCache.menuItems.size(); i++) {
            if (!dishCache.fastOrderModel.isOrderedSeqNo(dishCache.menuItems.get(i).menuBiz.orderSeqID)) {
                dishCache.menuItems.remove(i);
                i--;
            }
        }
    }

    @Override
    public void unBindMemberInfoFromOrder(String orderId, String cardNo, ResultCallback<ChangeOrderWithMemberResponse> callback) {
        MemberApi.unBindMemberInfoFromOrder(orderId, cardNo, callback);
    }

    @Override
    public void loadMenuItemsInsertToSellDB(String orderId, ArrayList<MenuItem> menuItems, String mealNumber, final ResultCallback<OnlyOrderMenuItemsResponse> callback) {
        FastFoodOrderSocketApi.loadMenuItemsInsertToSellDB(orderId, menuItems, mealNumber, callback);
    }
}
