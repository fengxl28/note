package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * 会员等级模型
 * Created by qinwei on 2017/10/18.
 */

public class MemberLevelModel extends BusinessBean {
    public String id;

    public String cs_id;

    public String m_shopid;

    public String level;

    public String title;

    public String image;

    public String type;

    public String day;

    public String expense_num;

    public String expense_amount;

    public String expense;

    public String is_degrade;

    public String stop_day;

    public String public_ids;

    public String status;

    public String add_time;

    public String update_time;

    public String discount;

    public String cost_money_unit;

    public String reward_score;

    public String wxcard_level_pic;

    public String is_all_pmt;

    public String is_group;

    public String group_num;

    public String group_update_time;

    public String is_reward;

    public String reward_couponid;

    public String reward_point;

    public String reward_coupon_name;

    public String reward_coupon_type;

    public MemberLevelModel() {
    }
}
