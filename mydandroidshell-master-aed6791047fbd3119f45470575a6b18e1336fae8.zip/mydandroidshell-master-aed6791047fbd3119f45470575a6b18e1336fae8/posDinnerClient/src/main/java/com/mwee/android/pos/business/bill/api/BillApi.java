package com.mwee.android.pos.business.bill.api;

import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.GetOrderDetailsResponse;
import com.mwee.android.pos.connect.business.bean.GetOrderFromCenterRespone;
import com.mwee.android.pos.connect.business.bill.BillOptFilterResponse;
import com.mwee.android.pos.connect.business.bill.BillOptLogResponse;
import com.mwee.android.pos.connect.business.bill.BillOptViewResponse;
import com.mwee.android.pos.connect.business.bill.OrderPrintDataResponse;
import com.mwee.android.pos.connect.business.monitor.report.LoadAccountBookResponse;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.business.CBill;
import com.mwee.android.pos.db.business.AccountBookDBModel;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by zhangmin on 2017/9/3.
 */

public class BillApi {

    /**
     * 获取订单详情
     */
    public static void getOrderDetails(String orderId, boolean isKoubei,
                                       SocketCallback<GetOrderDetailsResponse> callback) {
        MCon.c(CBill.class, callback).getOrderDetails(orderId, isKoubei);
    }

    /**
     * 获取订单列表
     *
     * @param businessDate
     * @param fiSellType         订单类型 0：正餐； 1：快餐
     * @param fsBillSourceId     本店、饿了么、美团外卖、百度外卖
     * @param withOutOrderID     剔除指定的OrderID
     * @param withOrderID        只查询指定的OrderID
     * @param searchUnPayedOrder 是否包含菜品信息
     * @param searchMenu         是否包含支付列表
     * @param searchPay          是否包含支付列表
     * @return
     */
    public static void GetOrderFromCenterRequest(int currentPage, String businessDate, int fiSellType,
                                                 String fsBillSourceId, int billType,String accountBookId,
                                                 int payStatus, String withOutOrderID, String withOrderID,
                                                 boolean searchUnPayedOrder, boolean searchMenu, boolean searchPay,
                                                 String tableName, SocketCallback<GetOrderFromCenterRespone> callback) {
        MCon.c(CBill.class, callback).GetOrderFromCenterRequest(currentPage, businessDate, fiSellType,
                fsBillSourceId, billType, accountBookId, payStatus,
                withOutOrderID, withOrderID, searchUnPayedOrder, searchMenu, searchPay, tableName);
    }

    /**
     * @param callback
     */
    public static void startBillOpt(SocketCallback<BillOptViewResponse> callback) {
        MCon.c(CBill.class, callback).startOptBill();
    }

    /**
     * 根据条件筛选订单
     *
     * @param date            营业日期
     * @param paymentList     支付方式
     * @param checkAllPayment 是否全选支付方式
     * @param percent         账单数量 %
     * @param callback
     */
    public static void filterBill(String date, List<String> paymentList, int checkAllPayment,
                                  BigDecimal percent, String accountBookId,
                                  SocketCallback<BillOptFilterResponse> callback) {
        MCon.c(CBill.class, callback).filterBill(date, paymentList, checkAllPayment, percent, accountBookId);
    }

    /**
     * 上传账单
     *
     * @param businessDate
     * @param callback
     */
    @Deprecated
    public static void uploadBill(String businessDate, SocketCallback<BaseSocketResponse> callback) {
        MCon.c(CBill.class, callback).uploadBill(businessDate);
    }

    /**
     * 上传账单
     *
     * @param businessDate
     * @param callback
     */
    public static void uploadBillManual(String accountBookId, String businessDate, SocketCallback<BaseSocketResponse> callback) {
        MCon.c(CBill.class, callback).uploadBillManual(accountBookId, businessDate);
    }

    /**
     * 优化账单
     *
     * @param businessDate 营业日期
     * @param orderList
     * @param hidden
     * @param callback
     */
    public static void optimizeBill(String businessDate, List<String> orderList, int hidden,
                                    List<String> allList, String accountBookId,
                                    SocketCallback<BillOptFilterResponse> callback) {
        MCon.c(CBill.class, callback).optimize(businessDate, orderList, hidden, allList, accountBookId);
    }

    /**
     * 查询日志
     *
     * @param callback
     */
    public static void queryUploadLog(String accountBookId, SocketCallback<BillOptLogResponse> callback) {
        MCon.c(CBill.class, callback).queryLog(accountBookId);
    }

    /**
     * 保存设置
     *
     * @param config
     * @param callback
     */
    @Deprecated
    public static void saveConfig(String config, SocketCallback<BaseSocketResponse> callback) {
        MCon.c(CBill.class, callback).saveSetting(config);
    }

    /**
     * 保存设置
     *
     * @param config
     * @param callback
     */
    public static void saveAccountBookConfig(AccountBookDBModel config, SocketCallback<BaseSocketResponse> callback) {
        MCon.c(CBill.class, callback).saveAccountBookConfig(config);
    }

    /**
     * 获取订单打印数据
     *
     * @param businessDate
     * @param callback
     */
    public static void getOrderPrintData(String orderId, String businessDate, String fiSellType, String orderSource, SocketCallback<OrderPrintDataResponse> callback) {
        MCon.c(CBill.class, callback).getOrderPrintData(orderId, businessDate, fiSellType, orderSource);
    }

    /**
     * 根据用户输入的字符去业务中心模糊查询符合的订单或桌台名
     * 用来展示输入框的提示框
     *
     * @param businessDate
     */
    public static void getOrderPrintData(String businessDate, int fiSellType, String fsBillSourceId, int billType, String accountBookId, int payStatus, String searchType, String searchContent, SocketCallback<GetOrderFromCenterRespone> callback) {
        MCon.c(CBill.class, callback).getSearchDropList(businessDate, fiSellType, fsBillSourceId, billType, accountBookId, payStatus, searchType, searchContent);
    }

    public static void loadAccountBook(boolean checkUser, SocketCallback<LoadAccountBookResponse> callback) {
        MCon.c(CBill.class, callback).loadAccountBook(checkUser);
    }
}
