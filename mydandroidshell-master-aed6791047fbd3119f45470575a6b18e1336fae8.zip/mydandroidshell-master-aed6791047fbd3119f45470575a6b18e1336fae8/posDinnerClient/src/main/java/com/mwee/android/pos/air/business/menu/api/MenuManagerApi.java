package com.mwee.android.pos.air.business.menu.api;

import com.mwee.android.air.acon.CMenuManager;
import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAddResponse;
import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.connect.business.menu.MenuItemAddResponse;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageSetSideResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public class MenuManagerApi {
    /**
     * 加载菜品管理数据
     *
     * @param isLoadAllMenu 是否加载所有菜品
     * @param callback
     */
    public static void loadMenuManagerIndexData(boolean isLoadAllMenu, SocketCallback<AllMenuClsAndMenuItemResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsList(isLoadAllMenu);
    }

    public static void loadMenuItemsByClsId(String fsMenuClsId, SocketCallback<MenuItemsResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuItemsByClsId(fsMenuClsId);
    }

    public static void loadMenuClsUpdate(MenuClsBean menuClsBean, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsUpdate(menuClsBean);
    }

    public static void loadMenuClsPrinters(String fsMenuClsId, SocketCallback<MenuClsPrintersResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsPrinters(fsMenuClsId);
    }

    public static void loadMenuClsAdd(String name, ArrayList<String> printerNames, SocketCallback<MenuClsAddResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsAdd(name, printerNames);
    }

    public static void loadMenuClsDelete(String fsMenuClsId, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsDelete(fsMenuClsId);
    }

    public static void loadUpdateMenuInfo(String fiItemCd, String menuClsId, String fiOrderUintCd, String name, String unitName, String price, String memberPrice, String repertoryNumber
            , boolean isCanDiscount, boolean isCanGift, boolean isCanTimePrice, boolean isCanWeight, boolean isCanOutTake, boolean isCanPrinter
            , SocketCallback<SocketResponse> callback) {
//        MCon.c(CMenuManager.class, callback).loadUpdateMenuInfo(fiItemCd, menuClsId, fiOrderUintCd, name, unitName, price, memberPrice, repertoryNumber,
//                isCanDiscount, isCanGift, isCanTimePrice, isCanWeight, isCanOutTake, isCanPrinter);
    }


    public static void loadAddMenuInfo(String fsMenuClsId, String name, String unitName, String price, String memberPrice, String repertoryNumber
            , boolean isCanDiscount, boolean isCanGift, boolean isCanTimePrice, boolean isCanWeight, boolean isCanOutTake, boolean isCanPrinter, int fiIsTemporaryMenu
            , SocketCallback<MenuItemAddResponse> callback) {
//        MCon.c(CMenuManager.class, callback).loadAddMenuInfo(fsMenuClsId, name, unitName, price, memberPrice, repertoryNumber
//                , isCanDiscount, isCanGift, isCanTimePrice, isCanWeight, isCanOutTake, isCanPrinter,fiIsTemporaryMenu);
    }

    public static void loadBatchDeleteMenuItems(ArrayList<String> choiceStates, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadBatchDeleteMenuItems(choiceStates);
    }

    public static void loadMenuPackageItems(boolean isLoadFirstDetailInfo, SocketCallback<MenuPackageItemsResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuPackageItems(isLoadFirstDetailInfo);
    }

    public static void loadMenuPackageSetSidesByMenuId(String fiItemCd, SocketCallback<MenuPackageSetSideResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuPackageSetSidesByMenuId(fiItemCd);
    }

    public static void loadUpdatePackageMenu(String fiItemCd, String name, String price, List<MenuPackageSetSideBean> beans, SocketCallback<SocketResponse> callback) {
//        MCon.c(CMenuManager.class, callback).loadUpdatePackageMenu(fiItemCd, name, price, beans);
    }

    public static void loadAddMenuPackage(String name, String price, SocketCallback<SocketResponse> callback) {
//        MCon.c(CMenuManager.class, callback).loadAddMenuPackage(name, price);
    }

    public static void loadDeleteMenuItemSetSide(String fiSetFoodCd, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadDeleteMenuItemSetSide(fiSetFoodCd);
    }

    public static void loadDeletePackageMenuItem(String fiItemCd, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadDeletePackageMenuItem(fiItemCd);
    }

    public static void loadMenuClsToTop(String fsMenuClsId, SocketCallback<MenuClsToTopResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuClsToTop(fsMenuClsId);
    }

    public static void loadMenuItemToTop(String itemId, SocketCallback<SocketResponse> callback) {
        MCon.c(CMenuManager.class, callback).loadMenuItemToTop(itemId);
    }


}