package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/1/30.
 */

public class MemberRechargeRecordingModel extends BusinessBean {

    public String m_shopid;

    public String shopname;

    public String card_no;

    public String score;

    public String mobile;

    public String type;

    public String trade_no;

    //实充金额
    public String amount;

    //total_amoun
    public String total_amount;

    //实收+赠送
    public String total_recharge_amount;

    public String add_time;

    public String present_moeny;

    public String pay_type;

    public String type_name;

    public String pay_type_name;




}
