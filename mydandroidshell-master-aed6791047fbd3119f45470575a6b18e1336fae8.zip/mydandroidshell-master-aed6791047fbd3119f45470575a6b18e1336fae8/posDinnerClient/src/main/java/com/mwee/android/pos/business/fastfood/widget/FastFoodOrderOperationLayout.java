package com.mwee.android.pos.business.fastfood.widget;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.fastfood.domain.FastFoodDishCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;

/**
 * 快餐订单操作view
 * Created by qinwei on 2017/7/6.
 */

public class FastFoodOrderOperationLayout extends LinearLayout implements View.OnClickListener {
    private Button mFastFoodOrderClearBtn;//清台
    private Button mFastFoodOrderCommitBtn;//下订单
    private Button mFastFoodOrderMobilePaymentBtn;//手机支付
    private Button mFastFoodOrderDoCheckBtn;//结帐
    private FastFoodDishCache mDishCache;
    private OnFastFoodOrderOperationListener listener;

    public interface OnFastFoodOrderOperationListener {
        /**
         * 批量删除未下单的菜品
         */
        void onOrderClearClick();

        /**
         * 点击结帐
         */
        void onOrderCheckClick();

        /**
         * 点击下单
         */
        void onOrderCommitClick();


        /**
         * 点击手机支付
         */
        void onMobilePaymentClick();


    }


    public FastFoodOrderOperationLayout(Context context) {
        super(context);
        initView();
    }

    public FastFoodOrderOperationLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public FastFoodOrderOperationLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        setOrientation(HORIZONTAL);
        LayoutInflater.from(getContext()).inflate(R.layout.widget_fast_food_order_operation, this);
        mFastFoodOrderClearBtn = (Button) findViewById(R.id.mFastFoodOrderClearBtn);
        mFastFoodOrderCommitBtn = (Button) findViewById(R.id.mFastFoodOrderCommitBtn);
        mFastFoodOrderDoCheckBtn = (Button) findViewById(R.id.mFastFoodOrderDoCheckBtn);
        mFastFoodOrderMobilePaymentBtn = (Button) findViewById(R.id.mFastFoodOrderMobilePaymentBtn);
        mFastFoodOrderClearBtn.setOnClickListener(this);
        mFastFoodOrderCommitBtn.setOnClickListener(this);
        mFastFoodOrderMobilePaymentBtn.setOnClickListener(this);
        mFastFoodOrderDoCheckBtn.setOnClickListener(this);
    }

    public void initData(FastFoodDishCache dishCache) {
        this.mDishCache = dishCache;
        refreshOperationBtnStatus();
    }

    /**
     * 刷新订单操作按钮可用状态
     */
    public void refreshOperationBtnStatus() {
        if (mDishCache.menuItems.size() == 0) {
            mFastFoodOrderCommitBtn.setEnabled(false);
            mFastFoodOrderMobilePaymentBtn.setEnabled(false);
        } else {
            mFastFoodOrderMobilePaymentBtn.setEnabled(true);
        }
        if (hasNoOrderedMenu()) {
            mFastFoodOrderClearBtn.setEnabled(true);
            mFastFoodOrderCommitBtn.setEnabled(true);
        } else {
            mFastFoodOrderClearBtn.setEnabled(false);
            mFastFoodOrderCommitBtn.setEnabled(false);
        }
    }

    /**
     * 判断是否有未下单的菜品
     *
     * @return
     */
    private boolean hasNoOrderedMenu() {
        for (MenuItem menuItem : mDishCache.menuItems) {
            if (!mDishCache.fastOrderModel.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                return true;
            }
        }
        return false;
    }


    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mFastFoodOrderClearBtn:
                listener.onOrderClearClick();
                break;
            case R.id.mFastFoodOrderDoCheckBtn:
                //根据配置显示是否需要输入牌号
                if (!AppCache.getInstance().collectMoney) {
                    ToastUtil.showToast("当前用户没有收银权限");
                    RunTimeLog.addLog(RunTimeLog.FAST_ORDER, "你没有结帐权限");
                    return;
                }
                listener.onOrderCheckClick();
                break;
            case R.id.mFastFoodOrderCommitBtn:
                listener.onOrderCommitClick();
                break;
            case R.id.mFastFoodOrderMobilePaymentBtn:
                if (!AppCache.getInstance().collectMoney) {
                    ToastUtil.showToast("你没有该权限，不可执行操作");
                    return;
                }
                listener.onMobilePaymentClick();
                break;
            default:
                break;
        }
    }

    public void setOnFastFoodOrderOperationListener(OnFastFoodOrderOperationListener listener) {
        this.listener = listener;
    }
}
