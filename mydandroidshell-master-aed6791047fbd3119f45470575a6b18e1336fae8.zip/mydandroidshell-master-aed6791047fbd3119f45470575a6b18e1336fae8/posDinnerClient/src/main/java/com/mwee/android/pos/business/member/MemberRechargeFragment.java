package com.mwee.android.pos.business.member;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.member.adapter.MemberRechargePayTypeAdapter;
import com.mwee.android.pos.business.member.biz.RechargeProcess;
import com.mwee.android.pos.business.member.entity.RechargePayType;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.KeyHelper;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberKeyboard;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangming on 2018/12/5.
 *
 */

public class MemberRechargeFragment extends BaseFragment {

    //每满储值
    public static final int TYPE_FULL = 1;
    //区间挡储值
    public static final int TYPE_BETWEEN = 2;

    private ListView mRuleListView;
    private GridView mpayTypeGridView;
    private NumberKeyboard mKeyboard;
    private TextView mInputMoneyTv;
    private String mInputMoney = "";

    private int mChargeType;

    private MemberRechargePayTypeAdapter mPayTypeAdapter;

    private RuleAdapter mRuleAdapter;

    private List<MemberRechargePackageModel.Rule> mRuleList;
    private NewMemberCardDetailsModel mMemberCardModel;
    private int mRechargeMaxLimit;
    private int mRechargeMinLimit;
    private RechargeProcess mRechargeProcess;

    public static MemberRechargeFragment getInstance(NewMemberCardDetailsModel memberCardModel,List<MemberRechargePackageModel.Rule> rules,int chargeMinLimit,int chargeMaxLimit,int chargeType){
        MemberRechargeFragment fragment = new MemberRechargeFragment();
        fragment.mRuleList = rules;
        fragment.mMemberCardModel = memberCardModel;
        fragment.mRechargeMaxLimit = chargeMaxLimit;
        fragment.mRechargeMinLimit = chargeMinLimit;
        fragment.mChargeType =chargeType;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getContext()).inflate(R.layout.fragment_new_member_recharge, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        View noteView = view.findViewById(R.id.member_recharge_note);
        if(mChargeType == TYPE_BETWEEN){
            noteView.setVisibility(View.VISIBLE);
        }else{
            noteView.setVisibility(View.GONE);
        }
        mRuleListView = view.findViewById(R.id.member_recharge_listView);
        mpayTypeGridView = view.findViewById(R.id.member_payType_gridView);

        ((TextView)view.findViewById(R.id.member_recharge_minMoney)).setText(String.format(getString(R.string.member_recharge_minMoney),mRechargeMinLimit));

        mInputMoneyTv = view.findViewById(R.id.member_input_money);
        mKeyboard = view.findViewById(R.id.member_money_keyboard);
        mKeyboard.setItemLayoutId(R.layout.view_key_item);
        mKeyboard.initData(KeyHelper.generateCrossPayKeys(), key -> {
            switch (key.type) {
                case NumberKeyboard.KeyEntity.TYPE_NUM:
                    if (TextUtils.equals(mInputMoney, "0")) {
                        mInputMoney = "";
                    }
                    if (com.mwee.android.pos.util.TextUtils.isMoneyStr(mInputMoney + key.value)) {
                        mInputMoney += key.value;
                    }
                    break;
                case NumberKeyboard.KeyEntity.TYPE_CLEAR:
                    mInputMoney = "";
                    break;
                case NumberKeyboard.KeyEntity.TYPE_POINT:
                    if (com.mwee.android.pos.util.TextUtils.isMoneyStr(mInputMoney + key.value)) {
                        mInputMoney += key.value;
                    }
                    break;
                default:
                    break;
            }
            if(TextUtils.isEmpty(mInputMoney) || TextUtils.equals(mInputMoney,".")){
                mRuleAdapter.update(BigDecimal.ZERO);
            }else{
                mRuleAdapter.update(new BigDecimal(mInputMoney));
            }
            mInputMoneyTv.setText(mInputMoney);
        });
        mKeyboard.notifyDataChanged();

        mRechargeProcess = new RechargeProcess(this,mMemberCardModel);

        view.findViewById(R.id.member_recharge_ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BigDecimal chargeMoney = mRuleAdapter.getChargeMoney();
                if(chargeMoney == null || chargeMoney.compareTo(BigDecimal.ZERO) <= 0){
                    ToastUtil.showToast("请输入充值金额");
                    return;
                }
                if(chargeMoney.intValue() < mRechargeMinLimit){
                    ToastUtil.showToast("最低充值金额"+mRechargeMinLimit);
                    return;
                }
                if(chargeMoney.intValue() > mRechargeMaxLimit){
                    ToastUtil.showToast("最多只能充值"+mRechargeMaxLimit);
                    return;
                }
                MemberRechargePackageModel.Rule rule = mRuleAdapter.getMatchRule();
                if(rule == null){
                    rule = new MemberRechargePackageModel.Rule();
                }
                rule.id = "";
                mRechargeProcess.charge(rule,mPayTypeAdapter.getSelectRechargePayType(),chargeMoney);
            }
        });

    }

    private void initData(){
        mPayTypeAdapter = new MemberRechargePayTypeAdapter(getActivity(), RechargePayType.getPayTypes());
        mpayTypeGridView.setAdapter(mPayTypeAdapter);

        mRuleAdapter = new RuleAdapter(this,mRuleList);
        mRuleListView.setAdapter(mRuleAdapter);
    }

    static class RuleAdapter extends CommonAdapter<MemberRechargePackageModel.Rule>{

        private MemberRechargeFragment mFragment;
        private List<MemberRechargePackageModel.Rule> mRuleList = new ArrayList<>();
        private BigDecimal mChargeMoney;
        private MemberRechargePackageModel.Rule mMatchRule;

        public RuleAdapter(MemberRechargeFragment fragment, List<MemberRechargePackageModel.Rule> dataList) {
            super(fragment.getContext(), new ArrayList<>(), R.layout.view_member_charge_rule_item);
            mFragment = fragment;
            if(!ListUtil.isEmpty(dataList)){
                for (int i = dataList.size()-1; i >= 0; i--) {
                    mRuleList.add(dataList.get(i));
                }
            }
            setData(mRuleList);
        }

        @Override
        public void convert(ViewHolder viewHolder, MemberRechargePackageModel.Rule data, int position) {
            TextView title = viewHolder.getView(R.id.rule_item_title);
            if(data.isMatchData){
                title.setText(data.tempTitle);
                title.setTextColor(title.getResources().getColor(R.color.system_red));
            }else{
                if(mFragment.mChargeType == TYPE_BETWEEN){
                    String left = "充值" + data.money;
                    String right = "";
                    if(position < mRuleList.size() - 1){
                        right = "-"+mRuleList.get(position+1).money;
                    }else{
                        right = "以上";
                    }
                    title.setText(left+right);
                }else if(mFragment.mChargeType == TYPE_FULL){
                    title.setText("每满"+data.money);
                }else{
                    title.setText(data.title);
                }
                title.setTextColor(Color.BLACK);
            }
            ((TextView)viewHolder.getView(R.id.rule_item_detail)).setText(data.presentDesc);
        }

        public void update(BigDecimal money){
            if(mChargeMoney != null && mChargeMoney.compareTo(money) == 0){
                return;
            }
            mChargeMoney = money;
            if(money == null || BigDecimal.ZERO.compareTo(money) >= 0){
                setData(mRuleList);
            }else{
                showPresentHint();
            }
        }

        private void showPresentHint(){
            boolean isMatchRule = false;
            if(mFragment.mChargeType == TYPE_FULL){
                if(mRuleList.size() <= 0){
                    return;
                }
                MemberRechargePackageModel.Rule rule = mRuleList.get(0);
                mMatchRule = rule.clone();
                mMatchRule.tempTitle = "充值"+mChargeMoney.intValue()+",您将获得：";
                String presentDesc = "无";
                int presentCount = mChargeMoney.intValue()/mMatchRule.money;
                if(presentCount > 0){
                    if(!TextUtils.isEmpty(rule.presentType) && !TextUtils.equals(rule.presentType,"0")){
                        if(rule.presentType.contains(",")){
                            StringBuilder presentStr = new StringBuilder("");
                            String types[] = rule.presentType.split(",");
                            for (String type : types) {
                                presentStr.append(toPresentStr(type)).append("；");
                            }
                            if(presentStr.length() > 0){
                                presentDesc = "送："+presentStr.substring(0,presentStr.length()-1);
                            }
                        }else{
                            presentDesc = "送："+toPresentStr(rule.presentType);
                        }
                    }
                }
                isMatchRule = true;
                mMatchRule.presentDesc = presentDesc;
            }else{
                int maxMatchMoney = 0;
                for (MemberRechargePackageModel.Rule rule : mRuleList) {
                    if(rule != null && mChargeMoney.intValue() >= rule.money && rule.money > maxMatchMoney){
                        mMatchRule = rule.clone();
                        isMatchRule = true;
                        maxMatchMoney = rule.money;
                    }
                }
            }
            if(isMatchRule && mMatchRule != null){
                mMatchRule.tempTitle = "充值"+mChargeMoney.intValue()+",您将获得：";
                mMatchRule.isMatchData = true;
                List<MemberRechargePackageModel.Rule> data = new ArrayList<>(1);
                data.add(mMatchRule);
                setData(data);
            }else{
                mMatchRule = null;
            }
        }

        private String toPresentStr(String presentType){
            String presentDesc = "";
            if(TextUtils.isEmpty(presentType) || mMatchRule == null || mMatchRule.money <= 0){
                return presentDesc;
            }
            int presentCount = mChargeMoney.intValue()/mMatchRule.money;

            if(presentCount <= 0){
                return presentDesc;
            }

            if(TextUtils.equals(presentType,"1")){
                if(mMatchRule.presentPrice != 0){
                    int amount = presentCount*mMatchRule.presentPrice;
                    if(amount > mMatchRule.presentPriceUpLimit){
                        amount = mMatchRule.presentPriceUpLimit;
                    }
                    presentDesc = "储值金额"+amount + "";
                }
            }else if(TextUtils.equals(presentType,"2")){
                if(mMatchRule.presentScore != 0){
                    int score = presentCount*mMatchRule.presentScore;
                    if(score > mMatchRule.presentScoreUpLimit){
                        score = mMatchRule.presentScoreUpLimit;
                    }
                    presentDesc = score + "积分";
                }
            }else if(TextUtils.equals(presentType,"3")){
                StringBuilder couponStr = new StringBuilder("");
                if(!ListUtil.isEmpty(mMatchRule.presentCouponList)){
                    for (MemberRechargePackageModel.PresentCoupon coupon : mMatchRule.presentCouponList) {
                        if(coupon != null){
                            int couponCount = presentCount*coupon.num;
                            if(couponCount > coupon.presentCouponUpLimit){
                                couponCount = coupon.presentCouponUpLimit;
                            }
                            couponStr.append(coupon.couponName).append("*").append(couponCount).append("张,");
                        }
                    }
                }
                if(couponStr.length() > 0){
                    presentDesc = couponStr.substring(0,couponStr.length()-1);
                }
            }
            return presentDesc;
        }

        public BigDecimal getChargeMoney(){
            return mChargeMoney;
        }

        public MemberRechargePackageModel.Rule getMatchRule(){
            return mMatchRule;
        }
    }
}
