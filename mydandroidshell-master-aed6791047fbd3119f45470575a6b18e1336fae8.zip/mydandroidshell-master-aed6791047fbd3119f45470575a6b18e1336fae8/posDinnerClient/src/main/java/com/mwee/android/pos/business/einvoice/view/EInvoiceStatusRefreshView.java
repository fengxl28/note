package com.mwee.android.pos.business.einvoice.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.business.einvoice.api.InvoiceRateUpdateResponse;
import com.mwee.android.pos.business.einvoice.model.InvoiceRateUpdateBean;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

/**
 * author:luoshenghua
 * create on:2018/4/26
 * description:
 */
public class EInvoiceStatusRefreshView extends FrameLayout implements View.OnClickListener {
    private static String TAG = "InvoiceStatusRefreshView";
    /**
     * 税率值
     */
    private static final int RATE_LESS = 3;
    private static final int RATE_MORE = 6;

    private TextView mTvStatusOffline, mTvInvoiceRateModify, mTvInvoiceNum, mTvInvoiceRate;
    private Button mBtConfirm, mBtCancel;
    private LinearLayout mTvStatusOnlineLL;
    private Host mHost;
    private BaseDialogFragment mBaseDialogFragment;
    private RadioButton mRadioButtonLess, mRadioButtonMore;
    private View mStatusNotApplyLL;
    private View mRateLessLL, mRateMoreLL;
    private int mInvoiceStackNum = 0;
    private int mRate = 0;

    public EInvoiceStatusRefreshView(Context context) {
        super(context);
    }

    public EInvoiceStatusRefreshView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        initView();
    }

    private void initView() {
        mStatusNotApplyLL = findViewById(R.id.ll_status_not_apply);
        mTvStatusOffline = findViewById(R.id.tv_status_offline);
        mTvStatusOnlineLL = findViewById(R.id.ll_status_online);
        mTvInvoiceNum = findViewById(R.id.tv_invoice_num);
        mTvInvoiceRate = findViewById(R.id.tv_invoice_rate);
        mTvInvoiceRateModify = findViewById(R.id.tv_invoice_rate_modify);

        mTvInvoiceRateModify.setOnClickListener(this);

    }

    public void setParams(Host host) {
        mHost = host;
    }

    public void showInvoiceNotApply() {
        mStatusNotApplyLL.setVisibility(View.VISIBLE);
        mTvStatusOffline.setVisibility(View.GONE);
        mTvStatusOnlineLL.setVisibility(View.GONE);
        mTvInvoiceRateModify.setOnClickListener(null);
    }

    public void showInvoiceOffline() {
        mStatusNotApplyLL.setVisibility(View.GONE);
        mTvStatusOffline.setVisibility(View.VISIBLE);
        mTvStatusOnlineLL.setVisibility(View.GONE);
        mTvInvoiceRateModify.setOnClickListener(null);
    }

    public void showInvoiceOnline(int num, int rate) {
        mInvoiceStackNum = num;
        mRate = rate;
        mStatusNotApplyLL.setVisibility(View.GONE);
        mTvStatusOffline.setVisibility(View.GONE);
        mTvStatusOnlineLL.setVisibility(View.VISIBLE);
        mTvInvoiceRateModify.setOnClickListener(this);

        updateNumAndRate(num, rate);
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        switch (viewId) {
            case R.id.tv_invoice_rate_modify:
                View customView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_invoice_rate_modify, null, false);
                initDialog(customView);
                mBaseDialogFragment = DialogManager.showCustomDialog(mHost, customView, TAG);
                break;
            case R.id.ll_rate_less:
            case R.id.rb_rate_less:
                changeRadioBtnStatus(true, false);
                break;
            case R.id.ll_rate_more:
            case R.id.rb_rate_more:
                changeRadioBtnStatus(false, true);
                break;
            case R.id.bt_confirm:
                String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                if (mRadioButtonLess.isChecked()) {
                    mRate = RATE_LESS;
                } else if (mRadioButtonMore.isChecked()) {
                    mRate = RATE_MORE;
                }
                if (mRate > 0) {
                    EInvoiceProcess.updateInvoiceRate(shopId, mRate, new IExecutorCallback() {
                        @Override
                        public void success(ResponseData responseData) {
                            if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceRateUpdateResponse) {
                                InvoiceRateUpdateResponse invoiceRateUpdateResponse = (InvoiceRateUpdateResponse) responseData.responseBean;
                                if (invoiceRateUpdateResponse != null) {
                                    if (0 != invoiceRateUpdateResponse.errno) {
                                        //更新失败.
                                        if (!TextUtils.isEmpty(invoiceRateUpdateResponse.errmsg)) {
                                            ToastUtil.showToast(invoiceRateUpdateResponse.errmsg);
                                        }
                                        ActionLog.addLog("电子发票->税率更新失败errno!=0", "", "", ActionLog.SS_MORE_JOIN, "");
                                    } else {
                                        InvoiceRateUpdateBean invoiceRateUpdateBean = invoiceRateUpdateResponse.data;
                                        if (invoiceRateUpdateBean != null) {
                                            if (TextUtils.equals(invoiceRateUpdateBean.code, "0")) {
                                                //更新成功 code:0
                                                updateNumAndRate(mInvoiceStackNum, mRate);
                                            } else {
                                                ActionLog.addLog("电子发票->税率更新失败code!=0", "", "", ActionLog.SS_MORE_JOIN, "");
                                            }
                                        }
                                    }

                                }

                            }
                        }

                        @Override
                        public boolean fail(ResponseData responseData) {
                            ActionLog.addLog("电子发票->税率更新失败", "", "", ActionLog.SS_MORE_JOIN, "");
                            return false;
                        }
                    });
                }

                dismiss();
                break;
            case R.id.bt_cancel:
                dismiss();
                break;
        }
    }

    private void updateNumAndRate(int num, int rate) {
        mTvInvoiceNum.setText(String.valueOf(num));
        mTvInvoiceRate.setText(String.valueOf(rate) + "%");
    }

    private void initDialog(View rootView) {
        mRateLessLL = rootView.findViewById(R.id.ll_rate_less);
        mRateMoreLL = rootView.findViewById(R.id.ll_rate_more);
        mRadioButtonLess = rootView.findViewById(R.id.rb_rate_less);
        mRadioButtonMore = rootView.findViewById(R.id.rb_rate_more);
        mBtCancel = rootView.findViewById(R.id.bt_cancel);
        mBtConfirm = rootView.findViewById(R.id.bt_confirm);
        if (mRate == RATE_LESS) {
            changeRadioBtnStatus(true, false);
        } else if (mRate == RATE_MORE) {
            changeRadioBtnStatus(false, true);
        }
        mRadioButtonLess.setOnClickListener(this);
        mRadioButtonMore.setOnClickListener(this);
        mRateLessLL.setOnClickListener(this);
        mRateMoreLL.setOnClickListener(this);
        mBtCancel.setOnClickListener(this);
        mBtConfirm.setOnClickListener(this);

    }

    private void dismiss() {
        if (mBaseDialogFragment != null) {
            mBaseDialogFragment.dismiss();
        }
    }

    private void changeRadioBtnStatus(boolean rateLess, boolean rateMore) {
        mRadioButtonLess.setChecked(rateLess);
        mRadioButtonMore.setChecked(rateMore);
    }
}
