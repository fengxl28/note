package com.mwee.android.pos.business.backup;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.support.v4.content.ContextCompat;

import java.io.File;
import java.io.InputStream;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Locale;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Created by virgil on 2017/7/3.
 */

public class RestoreUtil {

    /**
     * 获取USB存储设备
     *
     * @return HashSet<String>
     */
    private static HashSet<String> getExternalMounts() {
        final HashSet<String> out = new HashSet<String>();
        String reg = "(?i).*vold.*(vfat|ntfs|exfat|fat32|ext3|ext4).*rw.*";
        String s = "";
        try {
            final Process process = new ProcessBuilder().command("mount")
                    .redirectErrorStream(true).start();
            process.waitFor();
            final InputStream is = process.getInputStream();
            final byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                s = s + new String(buffer);
            }
            is.close();
        } catch (final Exception e) {
            e.printStackTrace();
        }

        // parse output
        final String[] lines = s.split("\n");
        for (String line : lines) {
            String lower = line.toLowerCase(Locale.US);
            if (!lower.contains("asec") && lower.contains("usb")) {
                if (line.matches(reg)) {
                    String[] parts = line.split(" ");
                    for (String part : parts) {
                        if (part.startsWith("/"))
                            if (!part.toLowerCase(Locale.US).contains("vold"))
                                out.add(part);
                    }
                }
            }
        }
        return out;
    }

    /**
     * 构建USB存储设备的路径
     *
     * @param context Context
     * @param read    boolean
     * @return String | 路径，读取失败则返回空
     */
    protected static String buildSdcardPath(Context context, boolean read) {
        File[] list = ContextCompat.getExternalFilesDirs(context, null);
        if (list.length <= 1) {
            HashSet<String> set = getExternalMounts();
            if (set.isEmpty()) {
                return "";
            } else {
                String path = set.iterator().next();
                return path;
            }
        } else {
            if (list[1] == null) {
                return "";
            }
            String path = list[1].getAbsolutePath();
            if (read) {
                path = list[1].getParentFile().getParentFile().getParentFile().getParentFile().getAbsolutePath()+"/";
            }
            return path;
        }
    }

    protected static String searchRestoreFile(String path) {
        File file = new File(path);
        SortedMap<Long, String> sortedMap = new TreeMap<>(new Comparator<Long>() {
            @Override
            public int compare(Long o1, Long o2) {
                return (int) (o1 - o2);
            }
        });
        if (file.exists() && file.isDirectory()) {
            File[] files = file.listFiles();
            for (File temp : files) {
                if (temp.getName().startsWith("美易点备份_")) {
                    Long value = Long.valueOf(temp.getName().replace("美易点备份_", "").replace("-", "").replace("_", "").replace(":", ""));
                    sortedMap.put(value, temp.getAbsolutePath());
                }
            }
        }
        if (sortedMap.size() <= 0) {
            return "";
        }
        return sortedMap.entrySet().iterator().next().getValue();
    }

    public static void updateSingleRecord(String filename, Context context)//绝对路径
    {
        MediaScannerConnection.scanFile(context,
                new String[]{filename}, null, null);
    }
}
