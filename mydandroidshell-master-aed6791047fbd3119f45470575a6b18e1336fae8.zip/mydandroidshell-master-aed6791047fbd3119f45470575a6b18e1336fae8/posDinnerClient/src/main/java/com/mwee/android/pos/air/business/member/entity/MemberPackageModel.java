package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * 会员等级模型
 * Created by zhangmin on 2018/02/01.
 */

public class MemberPackageModel extends BusinessBean {

    public String id;

    public String pkg_id;

    public String reward_type;

    public String m_shopid;

    public String money;

    public String present_type;

    public String present_price;

    public String present_score;

    public String is_del;

    public String buy_num;

    public String pay_amount;

    public String add_time;

    public String present_price_up_limit;

    public String present_score_up_limit;

    public MemberPackageModel() {
    }
}
