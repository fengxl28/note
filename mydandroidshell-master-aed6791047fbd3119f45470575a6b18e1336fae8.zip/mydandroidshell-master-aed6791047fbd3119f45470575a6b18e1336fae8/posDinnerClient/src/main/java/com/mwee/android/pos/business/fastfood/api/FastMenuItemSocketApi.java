package com.mwee.android.pos.business.fastfood.api;


import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.MenuItemOperateAction;
import com.mwee.android.pos.connect.business.bean.OperateDishParameter;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.discount.DoDiscountResponse;
import com.mwee.android.pos.connect.business.discount.FastFoodDoDiscountResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.connect.callback.ConCallBack;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CDinnerFoodMenu;
import com.mwee.android.pos.connect.connect.business.CFastFoodOrder;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 菜品操作同步业务中心相关接口
 * Created by qinwei on 2017/5/31.
 */

public class FastMenuItemSocketApi {

    public static void loadChangeFastFoodMenuItems(String orderId, ArrayList<MenuItem> menuItems, String uniq, int operationType, final ResultCallback<ChangeFastFoodMenuItemsResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<ChangeFastFoodMenuItemsResponse>() {
            @Override
            public void callback(SocketResponse<ChangeFastFoodMenuItemsResponse> response) {
                if (response.success()) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).changeFastFoodMenuItems(orderId, menuItems, uniq, operationType);
    }


    /**
     * 称重菜称重改数量请求
     *
     * @param orderId  订单id
     * @param uniq     点菜唯一标示
     * @param buyNum   点菜数量
     * @param callback 回调
     */
    public static void loadUpdateMenuItemBuyNumber(String orderId, String uniq, BigDecimal buyNum, ConCallBack<UpdateBuyNumResponse> callback) {
        MCon.c(CDinnerFoodMenu.class, callback).loadUpdateMenuItemBuyNumber(orderId, uniq, buyNum);
    }


    /**
     * 批量退菜
     *
     * @param orderId  订单id
     * @param callback sendResponse in main thread
     */
    public static void loadReturnDishes(String orderId, List<VoidMenuItemModel> voidMenuItemModels, final ResultCallback<BactchReturnDishesForFastFoodResponse> callback) {
        MCon.c(CFastFoodOrder.class, new ConCallBack<BactchReturnDishesForFastFoodResponse>() {
            @Override
            public void subCall(SocketResponse<BactchReturnDishesForFastFoodResponse> response) {
                if (response.success() && response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }

            @Override
            public void callback(SocketResponse<BactchReturnDishesForFastFoodResponse> response) {
                if (response.success()) {
                    if (callback != null) {
                        callback.onSuccess(response.data);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }
        }).batchReturnDishesForFastFood(orderId, voidMenuItemModels);
    }

    /**
     * 退单个菜品
     *
     * @param orderId           退菜订单
     * @param voidMenuItemModel 退菜信息
     * @param callback          异步监听
     */
    public static void loadReturnDish(String orderId, VoidMenuItemModel voidMenuItemModel, ResultCallback<BactchReturnDishesForFastFoodResponse> callback) {
        List<VoidMenuItemModel> voidMenuItemModels = new ArrayList<>();
        voidMenuItemModels.add(voidMenuItemModel);
        loadReturnDishes(orderId, voidMenuItemModels, callback);
    }

    /**
     * 催菜请求
     *
     * @param orderId  订单id
     * @param seq      菜品唯一标示
     * @param callback sendResponse in main thread
     */
    public static void loadRemindersDish(String orderId, String seq, final ResultCallback<OperateDishToCenterResponse> callback) {
        List<String> seqList = new ArrayList<>();
        seqList.add(seq);
        loadRemindersDish(orderId, seqList, callback);
    }

    /**
     * 催菜请求--批量
     */
    public static void loadRemindersDish(String orderId, List<String> seqList, final ResultCallback<OperateDishToCenterResponse> callback) {
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_HURRY);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, callback);
    }

    /**
     * 更改时价菜请求
     *
     * @param orderId     销售单id
     * @param seq         消费菜品明细id
     * @param fdSalePrice 修改价格
     * @param callback    sendResponse in main thread
     */
    public static void loadUpdateDishPrice(String orderId, String seq, BigDecimal fdSalePrice, final ResultCallback<OperateDishToCenterResponse> callback) {
        List<String> seqList = new ArrayList<>();
        seqList.add(seq);
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_CHANGE_PRICE);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.changePrice = fdSalePrice;//时价菜价格
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, callback);
    }


    /**
     * 起菜请求
     *
     * @param orderId  订单id
     * @param seq      点菜菜品唯一标示
     * @param callback sendResponse in main thread
     */
    public static void loadDoDish(String orderId, String seq, final ResultCallback<OperateDishToCenterResponse> callback) {
        List<String> uniqList = new ArrayList<>();
        uniqList.add(seq);
        loadDoDish(orderId, uniqList, callback);
    }

    /**
     * 起菜请求---支持批量操作
     *
     * @param orderId  订单id
     * @param seqList  批量操作菜品唯一标示集合
     * @param callback sendResponse in main thread
     */
    public static void loadDoDish(String orderId, List<String> seqList, final ResultCallback<OperateDishToCenterResponse> callback) {
        OperateDishParameter parameter = new OperateDishParameter(MenuItemOperateAction.ACTION_DO_DISHES);
        parameter.menuUniq = seqList;
        parameter.orderID = orderId;
        parameter.operateUser = AppCache.getInstance().userDBModel;
        loadOperateDish(parameter, callback);
    }


    /**
     * 菜品操作封装
     *
     * @param parameter 请求参数封装
     * @param callback  sendResponse in main thread
     */
    private static void loadOperateDish(OperateDishParameter parameter, final ResultCallback<OperateDishToCenterResponse> callback) {
        MCon.c(CDinnerFoodMenu.class, new ConCallBack<OperateDishToCenterResponse>() {
            @Override
            public void callback(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.success()) {
                    if (callback != null) {
                        callback.onSuccess(response.data);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }

            @Override
            public void subCall(SocketResponse<OperateDishToCenterResponse> response) {
                if (response.success() && response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    //业务中心打印不了的打印任务id 交给本地打印进程打印
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            }
        }).loadOperateDish(parameter.orderID, parameter.menuUniq, parameter.operateType, parameter.privllegeUser, parameter.changeNum, parameter.changePrice);
    }

    /**
     * 加减配料菜请求
     *
     * @param orderId  订单id
     * @param newItem  修改后菜品信息
     * @param callback call in main thread
     */
    public static void loadChangeIngredient(String orderId, MenuItem newItem, List<MenuItem> addedMenuItem, List<MenuItem> deletedMenuItem, final ResultCallback<ChangeIngredientResponse> callback) {
        MCon.c(CDinnerFoodMenu.class, new SocketCallback<ChangeIngredientResponse>() {
            @Override
            public void callback(SocketResponse<ChangeIngredientResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    if (callback != null) {
                        callback.onSuccess(response.data);
                    }
                    if (response.data != null && !ListUtil.isEmpty(response.data.printTaskIds)) {
                        //业务中心打印不了的打印任务id 交给本地打印进程打印
                        PrintReceiptUtil.addPrintNo(response.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailure(response.code, response.message);
                    }
                }
            }
        }).loadChangeIngredient(orderId, newItem, addedMenuItem, deletedMenuItem);
    }

    /**
     * 加、退套餐子项
     *
     * @param orderId         订单id
     * @param newItem         修改后套餐
     * @param addedMenuItem   加菜列表
     * @param deletedMenuItem 退菜列表
     * @param updatedMenuItem 更新的菜品列表（要求/做法更新）
     * @param iResult
     */
    public static void loadChangePackageItems(String orderId, MenuItem newItem, List<MenuItem> addedMenuItem, List<MenuItem> deletedMenuItem, List<MenuItem> updatedMenuItem, final IResponse<ChangePackageItemsResponse> iResult) {
        MCon.c(CDinnerFoodMenu.class, new SocketCallback<ChangePackageItemsResponse>() {
            @Override
            public void callback(SocketResponse<ChangePackageItemsResponse> response) {

                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        iResult.callBack(true, response.code, "", response.data);
                    }
                    if (response.data != null && !ListUtil.isEmpty(response.data.printTaskIds)) {
                        //业务中心打印不了的打印任务id 交给本地打印进程打印
                        PrintReceiptUtil.addPrintNo(response.data.printTaskIds, AppCache.getInstance().currentHostId);
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).loadChangePackageItems(orderId, newItem, addedMenuItem, deletedMenuItem, updatedMenuItem);
    }

    /**
     * 处理菜品折扣
     *
     * @param orderID            订单id
     * @param ids                菜品id集合
     * @param isUseMember        是否使用会员价格
     * @param isUseGift          是否赠送
     * @param menuItemDiscountId 菜品折扣id
     * @param orderDiscountId    订单折扣id
     * @param callback           回调
     */
    public static void loadUpdateMenuItemDiscount(String orderID, ArrayList<String> ids, boolean isUseMember, boolean isUseGift, boolean cleanAllDiscount, String menuItemDiscountId, String orderDiscountId, String reason, final ResultCallback<FastFoodDoDiscountResponse> callback) {
        MCon.c(CFastFoodOrder.class, new SocketCallback<FastFoodDoDiscountResponse>() {
            @Override
            public void callback(SocketResponse<FastFoodDoDiscountResponse> response) {
                if (response.code == SocketResultCode.SUCCESS) {
                    callback.onSuccess(response.data);
                } else {
                    callback.onFailure(response.code, response.message);
                }
            }
        }).doDiscountForFastFood(orderID, orderDiscountId, menuItemDiscountId, isUseMember, isUseGift, reason, ids, cleanAllDiscount);
    }

    /**
     * @param orderID
     * @param ids
     * @param isUseMember
     * @param isUseGift
     * @param cleanAllDiscount
     * @param menuItemDiscountId
     * @param orderDiscountId
     * @param reason
     * @param customRate
     * @param customAmt
     * @param giftInfo
     * @param buygiftRelation
     * @param callback
     */
    public static void loadUpdateMenuItemDiscount(String orderID, ArrayList<String> ids, boolean isUseMember,
                                                  boolean isUseGift, boolean cleanAllDiscount,
                                                  String menuItemDiscountId, String orderDiscountId,
                                                  String reason, BigDecimal customRate, BigDecimal customAmt,
                                                  ArrayMap<String, BigDecimal> giftInfo,
                                                  Map<String, Map<String, List<String>>> buygiftRelation,
                                                  Map<String, List<String>> ingredientsMapping,
                                                  Map<String, List<String>> cleanCouponMapping,
                                                  final ResultCallback<FastFoodDoDiscountResponse> callback) {
        MCon.c(CFastFoodOrder.class, (SocketCallback<FastFoodDoDiscountResponse>) response -> {
            if (response.code == SocketResultCode.SUCCESS) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).doDiscountForFastFood(orderID, orderDiscountId, menuItemDiscountId,
                isUseMember, isUseGift, reason, ids, cleanAllDiscount,
                customRate, customAmt, giftInfo, buygiftRelation, ingredientsMapping, cleanCouponMapping);
    }
}
