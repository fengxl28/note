package com.mwee.android.pos.air.business.fastfood;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.business.member.widget.MemberBindOperationView;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;

/**
 * Created by qinwei on 2017/11/6.
 */

public class FastFoodOperationLayout extends LinearLayout implements View.OnClickListener {
    private TextView mOperationRequestLabel;
    private TextView mOperationDiscountLabel;
    private TextView mOperationGetOrderLabel;
    private TextView mOperationCheckLabel;
    private TextView mFastFoodOrderTotalPriceLabel;
    private OnFastFoodOperationClickListener listener;
    private TextView mOperationOrderSizeTagLabel;
    private MemberBindOperationView mOperationMemberBindOperationView;


    public FastFoodOperationLayout(Context context) {
        super(context);
        initView();
    }


    public FastFoodOperationLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public FastFoodOperationLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        LayoutInflater.from(getContext()).inflate(R.layout.widget_air_fastfood_operation, this);
        mOperationRequestLabel = findViewById(R.id.mOperationRequestLabel);
        mOperationDiscountLabel = findViewById(R.id.mOperationDiscountLabel);
        mOperationGetOrderLabel = findViewById(R.id.mOperationGetOrderLabel);
        mOperationMemberBindOperationView = (MemberBindOperationView) findViewById(R.id.mOperationMemberBindOperationView);
        mOperationCheckLabel = findViewById(R.id.mOperationCheckLabel);
        mOperationOrderSizeTagLabel = findViewById(R.id.mOperationOrderSizeTagLabel);
        mFastFoodOrderTotalPriceLabel = findViewById(R.id.mFastFoodOrderTotalPriceLabel);
        mOperationRequestLabel.setOnClickListener(this);
        mOperationDiscountLabel.setOnClickListener(this);
        mOperationGetOrderLabel.setOnClickListener(this);
        mOperationMemberBindOperationView.setOnClickListener(this);
        mOperationCheckLabel.setOnClickListener(this);
        mOperationOrderSizeTagLabel.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View view) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (view.getId()) {
            case R.id.mOperationRequestLabel:
                listener.onMenuItemRequestClick();
                break;
            case R.id.mOperationDiscountLabel:
                listener.onOperationDiscountClick();
                break;
            case R.id.mOperationGetOrderLabel:
                listener.onOperationGetOrderClick();
                break;
            case R.id.mOperationMemberBindOperationView:
                listener.onOperationMemberBindClick();
                break;
            case R.id.mOperationCheckLabel:
                listener.onOrderCheckClick();
                break;
            default:
                break;
        }
    }

    public void setTotalPrice(String price) {
        mFastFoodOrderTotalPriceLabel.setText(price);
    }

    public void setOrderNumber(int number) {
        if (number == 0) {
            mOperationOrderSizeTagLabel.setVisibility(View.GONE);
        } else {
            mOperationOrderSizeTagLabel.setText(number + "");
            mOperationOrderSizeTagLabel.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 得到当前挂起来的单子数量
     *
     * @return
     */
    public int getOrderNumber() {

        if (mOperationOrderSizeTagLabel.getVisibility() == View.GONE) {

            return 0;
        }
        return Integer.valueOf(mOperationOrderSizeTagLabel.getText().toString().trim());

    }


    public void setOnFastFoodOperationClickListener(OnFastFoodOperationClickListener listener) {
        this.listener = listener;
    }

    public void unBindMember() {
        mOperationMemberBindOperationView.unBind();
    }

    public void bindMember(String name, String phone) {
        mOperationMemberBindOperationView.bind(name, phone);
    }

    public interface OnFastFoodOperationClickListener {
        /**
         * 要求
         */
        void onMenuItemRequestClick();

        /**
         * 折扣
         */
        void onOperationDiscountClick();

        /**
         * 取单
         */
        void onOperationGetOrderClick();

        /**
         * 会员
         */
        void onOperationMemberBindClick();

        /**
         * 点击结帐
         */
        void onOrderCheckClick();
    }
}
