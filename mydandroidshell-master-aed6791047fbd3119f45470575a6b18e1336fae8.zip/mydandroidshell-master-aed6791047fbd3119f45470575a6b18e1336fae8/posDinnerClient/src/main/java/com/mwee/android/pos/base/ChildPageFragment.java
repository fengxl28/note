package com.mwee.android.pos.base;

/**
 * 子页面，当点击物理返回键的时候，页面会被  remove
 */
public class ChildPageFragment extends BaseFragment {
}
