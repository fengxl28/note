package com.mwee.android.pos.air.business.payment.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.cashier.connect.bean.http.BaseCashierPosRequest;

/**
 * Created by qinwei on 2018/2/6.
 */
@HttpParam(httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "setting/getMsyShopPayStatus",
        response = PayOpenStatusResponse.class)
public class PayOpenStatusRequest extends BaseCashierPosRequest {
    public String shopId;
    public int type;

    public PayOpenStatusRequest() {
    }
}
