package com.mwee.android.pos.business.backup;


import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.setting.api.SettingApi;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.connect.business.backup.GetBackupDataResponse;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataSimpleResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.db.business.table.TableStatusSimpleBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by virgil on 2017/5/12.
 */

public class BackUpDataAuto {

    /**
     * 存储桌台数据的队列
     */
    private static DelayQueue<RefreshTableBizDataSimpleResponse> queue = new DelayQueue<>("TaskBack");
    private static IDQWorker<RefreshTableBizDataSimpleResponse> dqWorker = new IDQWorker<RefreshTableBizDataSimpleResponse>() {
        @Override
        public void work(RefreshTableBizDataSimpleResponse response) {
            if (!ClientBindProcessor.isCurrentHostMain()) {
                if (!ListUtil.isEmpty(response.hintTableList)) {
                    for (MtableSimpleModel temp : response.hintTableList) {
                        temp.replaceNoTrans();
                    }
                }
                if (response.tableStatus != null && !response.tableStatus.isEmpty()) {
                    HashMap<String, TableStatusSimpleBean> mapTemp=new HashMap<>();
                    mapTemp.putAll(response.tableStatus);
                    for (Map.Entry<String, TableStatusSimpleBean> temp : mapTemp.entrySet()) {
                        temp.getValue().replaceNoTrans();
                    }
                }
            }
            queue.done(response);
        }
    };

    public static void autoSaveTableBiz(final RefreshTableBizDataSimpleResponse response) {
        if(ClientBindProcessor.isCurrentHostMain()){
            return;
        }
        queue.setWorker(dqWorker);
        queue.setDelay(3 * 1000);
        queue.addTask(response);
        if (firstTimeBackUp) {
            startSyncOrderInfo("", true);
        }
    }

    /**
     * 是否是第一次同步灾备数据
     */
    private static boolean firstTimeBackUp = true;

    /**
     * 开始同步指定的订单数据
     *
     * @param orderID String | 订单号
     */
    public static void startSyncOrderInfo(final String orderID) {
        startSyncOrderInfo(orderID, false);
    }

    /**
     * 同步订单
     *
     * @param orderID          String | 需要同步的订单号
     * @param forceReadAsFirst boolean | 是否强制按照第一次来同步数据
     */
    private static void startSyncOrderInfo(final String orderID, boolean forceReadAsFirst) {
        if (TextUtils.isEmpty(orderID) && !forceReadAsFirst) {
            return;
        }
        if (ClientBindProcessor.isCurrentHostMain()) {
            return;
        }
        SettingApi.GetBackupDataRequest(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), orderID, forceReadAsFirst ? 1 : (firstTimeBackUp ? 1 : 0), new SocketThreadCallback<GetBackupDataResponse>() {
            @Override
            public void callback(final SocketResponse<GetBackupDataResponse> socketResponse) {

                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    firstTimeBackUp = false;
                    if (TextUtils.isEmpty(orderID)&&!TextUtils.isEmpty(socketResponse.data.notFinishedOrderID)) {
                        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                            @Override
                            public Boolean doJob(SQLiteDatabase db) {
                                String sql = "order_id not in(" + socketResponse.data.notFinishedOrderID + ")";
                                db.delete("order_cache", sql, null);
                                db.delete("order_menu_cache", sql, null);
                                db.delete("order_pay_cache", sql, null);
                                return null;
                            }
                        });
                    }

                    if (socketResponse.data.orderCache != null) {
                        OrderSaveDBUtil.saveOnly(orderID, socketResponse.data.orderCache, false);
                        if (socketResponse.data.session != null) {
                            PaySaveDBUtil.save(orderID, socketResponse.data.session);
                        }
                    }
                    final JSONObject ob = socketResponse.data.backData;
                    if (ob != null && !ob.isEmpty()) {
                        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                            @Override
                            public Boolean doJob(SQLiteDatabase db) {
                                for (String temp : ob.keySet()) {
                                    JSONArray array = ob.getJSONArray(temp);
                                    if (array != null && !array.isEmpty()) {
                                        for (int i = 0; i < array.size(); i++) {
                                            String sql = buildSql(array.getJSONObject(i), temp);
                                            if (!TextUtils.isEmpty(sql)) {
                                                LogUtil.log("backup sql="+sql);
                                                db.execSQL(sql);
                                            }
                                        }
                                    }

                                }
                                return null;
                            }
                        });

                    }
                }


            }
        });

     /*
        GetBackupDataRequest request = new GetBackupDataRequest();
        request.orderID = orderID;
        request.requestHostID = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        request.firstRead = forceReadAsFirst ? 1 : (firstTimeBackUp ? 1 : 0);
        SocketExecutor.executeOnMain(request, null, new SocketThreadCallback<GetBackupDataResponse>() {
            @Override
            public void callback(final SocketResponse<GetBackupDataResponse> socketResponse) {
                if (socketResponse.code == SocketResultCode.SUCCESS) {
                    firstTimeBackUp = false;
                    if (TextUtils.isEmpty(orderID)&&!TextUtils.isEmpty(socketResponse.data.notFinishedOrderID)) {
                        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                            @Override
                            public Boolean doJob(SQLiteDatabase db) {
                                String sql = "order_id not in(" + socketResponse.data.notFinishedOrderID + ")";
                                db.delete("order_cache", sql, null);
                                db.delete("order_menu_cache", sql, null);
                                db.delete("order_pay_cache", sql, null);
                                return null;
                            }
                        });
                    }

                    if (socketResponse.data.orderCache != null) {
                        OrderSaveDBUtil.save(orderID, socketResponse.data.orderCache);
                        if (socketResponse.data.session != null) {
                            PaySaveDBUtil.save(orderID, socketResponse.data.session);
                        }
                    }
                    final JSONObject ob = socketResponse.data.backData;
                    if (ob != null && !ob.isEmpty()) {
                        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                            @Override
                            public Boolean doJob(SQLiteDatabase db) {
                                for (String temp : ob.keySet()) {
                                    JSONArray array = ob.getJSONArray(temp);
                                    if (array != null && !array.isEmpty()) {
                                        for (int i = 0; i < array.size(); i++) {
                                            String sql = buildSql(array.getJSONObject(i), temp);
                                            if (!TextUtils.isEmpty(sql)) {
                                                LogUtil.log("backup sql="+sql);
                                                db.execSQL(sql);
                                            }
                                        }
                                    }

                                }
                                return null;
                            }
                        });

                    }
                }
            }
        });*/
    }

    /**
     * 解析Json并拼接成Sql
     *
     * @param object    JSONObject
     * @param tableName String | 表名
     * @return String | 完整的SQL
     */
    private static String buildSql(JSONObject object, String tableName) {
        StringBuilder sql = new StringBuilder();
        if (object != null) {
            StringBuilder sbKey = new StringBuilder();
            StringBuilder sbValue = new StringBuilder();

            for (String temp : object.keySet()) {
                sbKey.append(temp).append(",");
                sbValue.append("'").append(object.getString(temp)).append("',");
            }
            sbKey.deleteCharAt(sbKey.length() - 1);
            sbValue.deleteCharAt(sbValue.length() - 1);
            sql.append("insert or replace into ")
                    .append(tableName)
                    .append(" (")
                    .append(sbKey.toString())
                    .append(") values (")
                    .append(sbValue.toString())
                    .append(")");
        }
        return sql.toString();
    }
}
