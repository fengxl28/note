package com.mwee.android.pos.air.base;

import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.base.BaseActivity;

/**
 * @ClassName: AirBaseActivity
 * @Description:
 * @author: SugarT
 * @date: 2017/10/25 下午4:14
 */
public class AirBaseActivity extends BaseActivity {

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BizcenterApi.uploadLocalChangeData(null);
    }
}
