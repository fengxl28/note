package com.mwee.android.pos.business.member.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.pos.air.base.ContainerFragmentActivity;
import com.mwee.android.pos.business.member.MemberInfoContainerFragment;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.order.OrderMemberInfo;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by chris on 16/8/11.
 */
public class MemberOrderUnBindAirDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    public final static String MODULE_NAME = "memberInfo";
    private Button mMemberSelectUnBindBtn;
    private OnMemberInfoListener listener;
    private TextView mMemberInfoNameLabel;
    private TextView mMemberInfoSexLabel;
    private TextView mMemberInfoBirthdayLabel;
    private TextView mMemberInfoPhoneLabel;
    private TextView mMemberInfoLevelNameLabel;
    private TextView mMemberInfoCardNumberNameLabel;
    private TextView mMemberInfoBalanceLabel;
    private TextView mMemberInfoScoreLabel;
    private Button mMemberBalanceAddBtn;
    private View mMemberInfoBalanceAndScoreLayout;
    private boolean isShowBalanceAndScore;
    private OrderMemberInfo member;

    public interface OnMemberInfoListener {
        void onUnbindMember();
    }

    public void setParam(OnMemberInfoListener listener) {
        this.listener = listener;
    }

    public static MemberOrderUnBindAirDialogFragment getInstance(OrderMemberInfo memberInfoS, boolean isShowBalanceAndScore) {
        MemberOrderUnBindAirDialogFragment fragment = new MemberOrderUnBindAirDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable("member", memberInfoS);
        args.putBoolean("isShowBalanceAndScore", isShowBalanceAndScore);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.air_member_info_view, container, false);
        view.setOnClickListener(this);
        setCancelable(false);
        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.mMemberInfoCloseImg).setOnClickListener(this);
        mMemberBalanceAddBtn = (Button) view.findViewById(R.id.mMemberBalanceAddBtn);
        mMemberInfoBalanceLabel = (TextView) view.findViewById(R.id.mMemberInfoBalanceLabel);
        mMemberInfoScoreLabel = (TextView) view.findViewById(R.id.mMemberInfoScoreLabel);
        mMemberInfoBalanceAndScoreLayout = view.findViewById(R.id.mMemberInfoBalanceAndScoreLayout);
        mMemberSelectUnBindBtn = (Button) view.findViewById(R.id.mMemberSelectUnBindBtn);
        mMemberInfoNameLabel = (TextView) view.findViewById(R.id.mMemberInfoNameLabel);
        mMemberInfoSexLabel = (TextView) view.findViewById(R.id.mMemberInfoSexLabel);
        mMemberInfoBirthdayLabel = (TextView) view.findViewById(R.id.mMemberInfoBirthdayLabel);
        mMemberInfoPhoneLabel = (TextView) view.findViewById(R.id.mMemberInfoPhoneLabel);
        mMemberInfoLevelNameLabel = (TextView) view.findViewById(R.id.mMemberInfoLevelNameLabel);
        mMemberInfoCardNumberNameLabel = (TextView) view.findViewById(R.id.mMemberInfoCardNumberNameLabel);
        mMemberSelectUnBindBtn.setOnClickListener(this);
        member = (OrderMemberInfo) getArguments().getSerializable("member");
        mMemberBalanceAddBtn.setOnClickListener(this);
        isShowBalanceAndScore = getArguments().getBoolean("isShowBalanceAndScore");
        if (isShowBalanceAndScore) {
            mMemberInfoBalanceLabel.setText("储值余额   " + member.balance.toPlainString());
            mMemberInfoScoreLabel.setText("积分   " + member.score);
            mMemberInfoBalanceAndScoreLayout.setVisibility(View.VISIBLE);
        } else {
            mMemberInfoBalanceAndScoreLayout.setVisibility(View.GONE);
        }
        if (member != null) {
            setMemberInfo(member);
        } else {
            mMemberInfoNameLabel.setText("");
            mMemberInfoSexLabel.setText("");
            mMemberInfoBirthdayLabel.setText("");
            mMemberInfoPhoneLabel.setText("");
            mMemberInfoLevelNameLabel.setText("");
            mMemberInfoCardNumberNameLabel.setText("");
        }
    }

    public void setMemberInfo(OrderMemberInfo memberCardModel) {
        //会员卡用户信息
        mMemberInfoNameLabel.setText(memberCardModel.real_name);
        mMemberInfoSexLabel.setText(memberCardModel.optGender());
        mMemberInfoBirthdayLabel.setText(memberCardModel.birthday);
        mMemberInfoPhoneLabel.setText(memberCardModel.mobile);
        mMemberInfoLevelNameLabel.setText(memberCardModel.level_name);
        mMemberInfoCardNumberNameLabel.setText(memberCardModel.card_no);
        switch (memberCardModel.level) {//1.粉丝 2.普通 3.黄金 4.铂金 5.钻石
            case 1:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_1, 0, 0, 0);
                break;
            case 2:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_normal, 0, 0, 0);
                break;
            case 3:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_gold, 0, 0, 0);
                break;
            case 4:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_4, 0, 0, 0);
                break;
            case 5:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_diamonds, 0, 0, 0);
                break;
            default:
                break;
        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mMemberSelectUnBindBtn:
                listener.onUnbindMember();
                dismiss();
                break;
            case R.id.mMemberBalanceAddBtn:
                Progress progress = ProgressManager.showProgressUncancel(this);
                new MemberProcess().onlyLoadMemberInfo(member.card_no, new IResponse<QueryMemberInfoResponse>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse info) {
                        progress.dismissSelf();
                        if (result) {
                            showMemberInfoFragment(info.memberCardModel);
                        } else {
                            BaseToastUtil.showToast(msg);
                        }
                    }
                });
                break;
            case R.id.mMemberInfoCloseImg:
                dismissSelf();
                break;
            default:
                break;
        }
    }

    private void showMemberInfoFragment(MemberCardModel memberCardModel) {
        LogUtil.log("显示会员详情界面 cardNo=" + memberCardModel.card_info.card_no);
        //MemberInfoContainerFragment fragment = MemberInfoContainerFragment.getInstance(memberCardModel);
        Bundle bundle = new Bundle();
        bundle.putSerializable(MemberInfoContainerFragment.KEY_MEMBER_INFO, memberCardModel);
        bundle.putSerializable(MemberInfoContainerFragment.KEY_TAB_INDEX, 1);
        //fragment.setArguments(bundle);
        Intent intent = new Intent(getActivityWithinHost(), ContainerFragmentActivity.class);
        intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ, new ContainerFragmentActivity.Clazz("会员", MemberInfoContainerFragment.class));
        intent.putExtra(ContainerFragmentActivity.KEY_FRAGMENT_CLAZZ_ARGS, bundle);
        getActivityWithinHost().startActivity(intent);
    }

}
