package com.mwee.android.pos.business.message;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseListHomeFragment;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.message.processor.wechatOrder.WechatOrderClientUtil;
import com.mwee.android.pos.business.message.processor.wechatOrder.WechatOrderDetailView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.wechatorder.GetAllWechatOrderResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.BaseToastUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/8/25.
 * 消息中心-微信外卖页
 */
public class MessageWechatOrderFragment extends BaseListHomeFragment<WechatOrderModel> implements IDriver {

    public static final String TAG = MessageOrderFragment.class.getSimpleName();
    public static final String DRIVER_TAG = "messageWechatOrder";


    private WechatOrderDetailView wechat_order_detail;

    private String chosedMsgId = "";

    private int currentPage = 1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!MessageWechatOrderFragment.this.isVisible()) {
            return;
        }
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    /**
     * 更新某一条记录
     */
    @DrivenMethod(uri = DRIVER_TAG + "/refreshWechatOrder", UIThread = true)
    public void refreshTempApporder(WechatOrderModel wechatOrderModel) {
        if (wechatOrderModel == null) {
            return;
        }
        updateData(wechatOrderModel);
    }

    /**
     * 更新显示列表
     */
    private void updateData(WechatOrderModel wechatOrderModel) {
        if (!ListUtil.isEmpty(modules)) {
            int index = -1;
            for (int i = 0; i < modules.size(); i++) {
                WechatOrderModel order = modules.get(i);
                if (TextUtils.equals(order.fsorderno, wechatOrderModel.fsorderno)) {
                    index = i;
                    break;
                }
            }

            if (index > -1) {
                modules.remove(index);
                modules.add(index, wechatOrderModel);
            } else {
                modules.add(0, wechatOrderModel);
            }
            adapter.notifyDataSetChanged();

        }
    }

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_message_wechat_order;
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new WechatOrderHolder(LayoutInflater.from(getContext()).inflate(R.layout.message_net_order_item, parent, false));
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        wechat_order_detail = view.findViewById(R.id.wechat_order_detail);
        wechat_order_detail.setHost(this);
        wechat_order_detail.setVisibility(View.GONE);
        view.findViewById(R.id.msg_order_item_delivery_status).setVisibility(View.GONE);

        if (AppCache.getInstance().isRetailMode()) {//小易2.2 修改样式
            ViewGroup root = view.findViewById(R.id.lyt_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            mPullRecyclerView.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root, getResources().getColor(R.color.color_656565));
        }
    }

    @Override
    protected void initData() {
        super.initData();

        mPullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setRefreshing();
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            currentPage = 1;
        } else {
            currentPage++;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    private void loadDataFromServer(int mode) {
        WechatOrderClientUtil.getOrderList(currentPage, new ResultCallback<GetAllWechatOrderResponse>() {
            @Override
            public void onSuccess(GetAllWechatOrderResponse data) {
                if (isAdded()) {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    if (currentPage >= data.pageCount) {//没有下一页数据
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    if (ListUtil.isEmpty(data.wechatOrderModelList)) {
                        mPullRecyclerView.showEmptyView();
                        adapter.notifyDataSetChanged();
                    } else {
                        mPullRecyclerView.showContent();
                        refreshDetail();
                        refreshAdapter(data.wechatOrderModelList);
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                BaseToastUtil.showToast(msg);
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                super.onFailure(code, msg);
            }
        });
    }

    public void refreshAdapter(List<WechatOrderModel> data) {
        modules.addAll(data);
        adapter.notifyDataSetChanged();
    }

    private void refreshDetail() {
        WechatOrderModel bean = null;
        //查查当前选中在不在列表中
        for (WechatOrderModel wechatOrderModel : modules) {
            if (TextUtils.equals(wechatOrderModel.fsorderno, chosedMsgId)) {
                bean = wechatOrderModel;
                break;
            }
        }

        if (bean != null) {
            if (ListUtil.isEmpty(bean.orderitem)) {
                optWechartOrderDetail(bean.fsorderno);
            } else {
                wechat_order_detail.updateData(bean);
                wechat_order_detail.setVisibility(View.VISIBLE);
            }
        } else {
            chosedMsgId = "";
            wechat_order_detail.setVisibility(View.INVISIBLE);
        }
    }

    public void optWechartOrderDetail(String fsorderno) {
        ProgressManager.showProgress(getActivityWithinHost(), "请稍后...");
        WechatOrderClientUtil.optWechatOrderFromBizById(fsorderno, false, new IResponse<WechatOrderModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, WechatOrderModel info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    if (wechat_order_detail != null) {
                        wechat_order_detail.updateData(info);
                        wechat_order_detail.setVisibility(View.VISIBLE);
                    }
                } else {
                    ToastUtil.showToast(msg);
                    if (wechat_order_detail != null) {
                        wechat_order_detail.updateData(null);
                        wechat_order_detail.setVisibility(View.GONE);
                    }
                }
            }
        });
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup, int color) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if (view instanceof TextView) {
                ((TextView) view).setTextColor(color);
            }
        }
    }

    private void clickItem(int position) {
        chosedMsgId = modules.get(position).fsorderno;
        if (wechat_order_detail != null) {
            refreshDetail();
            ActionLog.addLog("点击了 消息中心 外卖 条目", "", "", ActionLog.MESSAGE_TAKEAWAY, modules.get(position));
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    class WechatOrderHolder extends BaseViewHolder {

        private View root;
        private TextView msg_order_item_no;
        private TextView msg_order_item_time;
        private TextView msg_order_item_source;
        private TextView msg_order_item_mobile;
        private TextView msg_order_item_amt;
        private TextView msg_order_item_status;
        private TextView msg_order_item_delivery_status;

        public WechatOrderHolder(View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.lyt_root);
            msg_order_item_no = itemView.findViewById(R.id.msg_order_item_no);
            msg_order_item_time = itemView.findViewById(R.id.msg_order_item_time);
            msg_order_item_source = itemView.findViewById(R.id.msg_order_item_source);
            msg_order_item_mobile = itemView.findViewById(R.id.msg_order_item_mobile);
            msg_order_item_amt = itemView.findViewById(R.id.msg_order_item_amt);
            msg_order_item_status = itemView.findViewById(R.id.msg_order_item_status);
            msg_order_item_delivery_status = itemView.findViewById(R.id.msg_order_item_delivery_status);
        }

        @Override
        public void bindData(int position) {
            WechatOrderModel data = modules.get(position);
            String time = DateUtil.formartDateStrToTarget(data.fscreatetime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
            msg_order_item_no.setText(data.fsorderno + "");
            msg_order_item_time.setText(time);
            msg_order_item_source.setText("微信");
            msg_order_item_mobile.setText(data.fsmobile);
            msg_order_item_amt.setText(Calc.formatShow(data.fdrealamount));
            msg_order_item_status.setText(data.optStatus());
            msg_order_item_delivery_status.setVisibility(View.GONE);

            if (AppCache.getInstance().isRetailMode()) {
                if (TextUtils.equals(data.fsorderno, chosedMsgId)) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.system_red);
                    setTextColorOfViewGroup((ViewGroup) root, Color.WHITE);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.color_f9f9f9);
                    setTextColorOfViewGroup((ViewGroup) root, getResources().getColor(R.color.color_404040));
                }
            } else {
                int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                if (data.fistatus == 0) {//新订单
                    colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                }
                msg_order_item_no.setTextColor(colorR);
                msg_order_item_time.setTextColor(colorR);
                msg_order_item_source.setTextColor(colorR);
                msg_order_item_mobile.setTextColor(colorR);
                msg_order_item_amt.setTextColor(colorR);
                msg_order_item_status.setTextColor(colorR);
                if (TextUtils.equals(data.fsorderno, chosedMsgId)) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
                }
            }
            itemView.setOnClickListener(v -> clickItem(position));
        }
    }
}
