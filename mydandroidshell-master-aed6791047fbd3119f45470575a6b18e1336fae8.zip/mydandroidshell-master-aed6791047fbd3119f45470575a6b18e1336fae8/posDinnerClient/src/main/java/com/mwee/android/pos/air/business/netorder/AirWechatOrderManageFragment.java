package com.mwee.android.pos.air.business.netorder;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.component.callback.ResultListener;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.permission.PermissionProcessor;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;


/**
 * @ClassName: AirNetOrderManageFragment
 * @Description: 微信外卖
 * @author: 刘秀秀
 * @date: 2017/10/16
 */
public class AirWechatOrderManageFragment extends BaseFragment implements View.OnClickListener {

    public static final String TAG = AirWechatOrderManageFragment.class.getSimpleName();

    private TitleBar mTitleBar;

    private Switch open_sw;
    private TextView start_time, end_time;
    private EditText min_money_edt, send_edt, distance_edt;
    private TextView address_tv;


    private AirWechatOrderProcessor processor;

    private String open, startTime, endTime, minMoney, send, distance, address;

    private double mLongitude, mLatitude;

    public static AirWechatOrderManageFragment newInstance() {
        AirWechatOrderManageFragment fragment = new AirWechatOrderManageFragment();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_wechat_order_manager_activity, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        processor = new AirWechatOrderProcessor();
        initUI(view);
        initTitle();
        loadData();
    }

    private void loadData() {
        ProgressManager.showProgress(getActivityWithinHost());
        processor.loadWechatOrderSetting(new IResponse<ArrayMap<String, String>>() {
            @Override
            public void callBack(boolean result, int code, String msg, ArrayMap<String, String> info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (!result) {
                    ToastUtil.showToast(msg);
                    return;
                }
                assineData(info);
            }
        });
    }

    private void assineData(ArrayMap<String, String> settings) {
        if (settings == null) {
            open_sw.setSelected(false);
            start_time.setText("");
            end_time.setText("");
            min_money_edt.setText("");
            send_edt.setText("");
            distance_edt.setText("");
            address_tv.setText("");
        } else {
            open_sw.setChecked(TextUtils.equals(settings.get("chat1"), "1"));
            start_time.setText(TextUtils.isEmpty(settings.get("chat2")) ? "" : settings.get("chat2"));
            end_time.setText(TextUtils.isEmpty(settings.get("chat3")) ? "" : settings.get("chat3"));

            min_money_edt.setText(TextUtils.isEmpty(settings.get("chat4")) ? "" : settings.get("chat4"));
            send_edt.setText(TextUtils.isEmpty(settings.get("chat4fsStr1")) ? "" : settings.get("chat4fsStr1"));
            if (TextUtils.equals(settings.get("chat5"), "1")) {
                distance_edt.setText(TextUtils.isEmpty(settings.get("chat6")) ? "" : settings.get("chat6"));
            } else {
                distance_edt.setText("");
            }


            distance_edt.setText(TextUtils.isEmpty(settings.get("chat6")) ? "" : settings.get("chat6"));

            address_tv.setText(settings.get("address"));
        }
    }

    private boolean checkFormat() {

        open = open_sw.isChecked() ? "1" : "0";
        startTime = start_time.getText().toString().trim();
        endTime = end_time.getText().toString().trim();
        minMoney = min_money_edt.getText().toString().trim();
        send = send_edt.getText().toString().trim();
        distance = distance_edt.getText().toString().trim();
        address = address_tv.getText().toString().trim();


        if (TextUtils.isEmpty(startTime)) {
            ToastUtil.showToast("请选择营业开始时间");
            return false;
        }
        if (TextUtils.isEmpty(endTime)) {
            ToastUtil.showToast("请选择营业结束时间");
            return false;
        }

//            if (DateUtil.comareDateByLevel("2017-12-09 " + endTime+":23", "HH:mm", "2017-12-09 " + startTime+":23", "HH:mm") >= 0) {
        if (DateUtil.comareDateByLevel(endTime,startTime, "HH:mm", "HH:mm") >= 0) {
            ToastUtil.showToast("营业结束时间必须大于营业开始时间");
            return false;
        }

        if (StringUtil.toFloat(distance, 0f) <= 0f) {
            ToastUtil.showToast("配送距离要大于0");
            return false;
        }
        return true;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_time: {
                TimePickerView timePickerView = new TimePickerView();
                timePickerView.setTime(start_time.getText().toString().trim());
                timePickerView.setOnTimeCheckListener(new TimePickerView.OnTimeCheckListener() {
                    @Override
                    public void onSave(String time) {
                        start_time.setText(time);
                    }
                });
                DialogManager.showCustomDialog(this, timePickerView, "startTime");
                break;
            }
            case R.id.end_time: {
                TimePickerView timePickerView = new TimePickerView();
                timePickerView.setTime(end_time.getText().toString().trim());
                timePickerView.setOnTimeCheckListener(new TimePickerView.OnTimeCheckListener() {
                    @Override
                    public void onSave(String time) {
                        end_time.setText(time);
                    }
                });
                DialogManager.showCustomDialog(this, timePickerView, "endTime");
                break;
            }
            case R.id.change_address_tv:  //更改定位
                PermissionProcessor.applyPermission(getActivityWithinHost(), new ResultListener() {
                    @Override
                    public void callBack(int value) {
                        if (value == PackageManager.PERMISSION_GRANTED) {
                            AirLocationView airLocationView = AirLocationView.newInstance();
                            airLocationView.setListener(new AirLocationView.OnLocationListener() {
                                @Override
                                public void located(String address, double latitude, double longitude) {
                                    mLongitude = longitude;
                                    mLatitude = latitude;
                                    address_tv.setText(address);
                                }
                            });
                            DialogManager.showCustomDialog(AirWechatOrderManageFragment.this, airLocationView, AirLocationView.TAG);
                        } else {
                            String content = "";
                            content = getString(R.string.lack_permission);
                            if (!TextUtils.isEmpty(content)) {
                                PermissionProcessor.showMissingPermissionDialog(AirWechatOrderManageFragment.this, content, null, "取消定位");
                            }
                        }
                    }
                }, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION);
                break;
            case R.id.submit_btn:  //保存

                if (checkFormat()) {
                    ProgressManager.showProgress(getActivityWithinHost());
                    ArrayMap<String, String> settings = new ArrayMap<>();
                    // 公司 开启门店 外卖状态。0=false / 1=true
                    settings.put("a01", "1");
                    settings.put("chat1", open);
                    settings.put("chat2", startTime);
                    settings.put("chat3", endTime);
                    settings.put("chat4", minMoney);
                    settings.put("chat4fsStr1", send);
                    // 满xx元，配送费xx元。0=不选中 / 1=选中。页面无入口，默认不勾选
                    settings.put("chat5", "0");
                    settings.put("chat6", distance);
                    settings.put("address", address);
                    settings.put("longitude", String.valueOf(mLongitude));
                    settings.put("latitude", String.valueOf(mLatitude));
                    processor.updateWechatOrderSetting(settings, new IResult() {
                        @Override
                        public void callBack(boolean result, String info) {
                            ProgressManager.closeProgress(getActivityWithinHost());
                            if (result) {
                                ToastUtil.showToast("保存成功");
                            } else {
                                ToastUtil.showToast(info);
                            }
                        }
                    });
                }
                break;

            default:
                break;
        }
    }

    private void initUI(View convertView) {
        open_sw = (Switch) convertView.findViewById(R.id.open_sw);
        start_time = (TextView) convertView.findViewById(R.id.start_time);
        end_time = (TextView) convertView.findViewById(R.id.end_time);

        min_money_edt = (EditText) convertView.findViewById(R.id.min_money_edt);
        send_edt = (EditText) convertView.findViewById(R.id.send_edt);
        distance_edt = (EditText) convertView.findViewById(R.id.distance_edt);

        address_tv = (TextView) convertView.findViewById(R.id.address_tv);

        start_time.setOnClickListener(this);
        end_time.setOnClickListener(this);

        convertView.findViewById(R.id.change_address_tv).setOnClickListener(this);
        convertView.findViewById(R.id.submit_btn).setOnClickListener(this);

        mTitleBar = (TitleBar) convertView.findViewById(R.id.title_tv);
    }

    private void initTitle() {
        mTitleBar.setTitle("微信外卖设置");
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
    }
}
