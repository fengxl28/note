package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.recycler.RecycleViewDivider;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.NumberEditorView;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * created by 2018/11/2
 *
 * @author lxd
 *         Description:口碑部分退款选择退款菜品DialogFragment
 */
public class KBPartRefundChooseMenuDialogFragment extends BaseDialogFragment implements View.OnClickListener {
    private TextView mKBPartRefundTitle;
    private TextView mKBPartRefundMenuChoiceAll;//全选
    private RecyclerView mKBPartRefundRecyclerView;

    private MwPartRefundChooseMenuAdapter mwPartRefundChooseMenuAdapter;
    private KBPartRefundChooseMenuAdapter kbPartRefundChooseMenuAdapter;

    /**
     * 选择的先付款口碑菜品
     */
    private HashMap<KBPreMenuItemModel, Integer> kbChoiceStates = new HashMap<>();

    private List<MenuItem> orderMenuItems;
    private List<KBPreMenuItemModel> kbOrderMenuItem;


    private HashMap<MenuItem, Integer> choiceStates = new HashMap<>();

    private String fsSellNo;
    private OnChoiceRefundMenuListListener menuListListener;


    public void setParameter(List<MenuItem> orderMenuItem, List<KBPreMenuItemModel> kbOrderMenuItem, String fsSellNo) {
        //TODO 处理配料菜退款问题 价格需要重新计算

        this.orderMenuItems = orderMenuItem;
        this.kbOrderMenuItem = kbOrderMenuItem;
        this.fsSellNo = fsSellNo;

//        if (!ListUtil.isEmpty(orderMenuItems)) {
//            //需要加上配料菜的价格
//            for (MenuItem menuItem : orderMenuItems) {
//                for (MenuItem item : menuItem.menuBiz.selectedModifier) {
//                    //menuItem.price = menuItem.price.add(item.price);
//                    menuItem.menuBiz.totalPrice = (item.price.multiply(item.menuBiz.buyNum)).add(menuItem.menuBiz.totalPrice);
//                }
//            }
//        }
        if (!ListUtil.isEmpty(kbOrderMenuItem)) {
            for (KBPreMenuItemModel model : kbOrderMenuItem) {
                for (KBPreMenuItemModel kbPreMenuItemModel : model.selectedModifier) {
                    model.sell_price = model.sell_price.add((kbPreMenuItemModel.sell_price.multiply(kbPreMenuItemModel.dish_num)));
                }
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_fragment_kb_part_refund_choose_menu, container, false);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    /**
     * 初始化控件
     *
     * @param view
     */
    private void initView(View view) {
        mKBPartRefundTitle = view.findViewById(R.id.mKBPartRefundTitle);
        mKBPartRefundMenuChoiceAll = view.findViewById(R.id.mKBPartRefundMenuChoiceAll);
        mKBPartRefundRecyclerView = view.findViewById(R.id.mKBPartRefundRecyclerView);
        view.findViewById(R.id.mKBPartRefundCancelBtn).setOnClickListener(this);
        view.findViewById(R.id.mKBPartRefundSubmitBtn).setOnClickListener(this);
        mKBPartRefundMenuChoiceAll.setOnClickListener(this);
        view.setOnClickListener(this);

        //设置布局样式
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());//设置方向
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);//关联RecyclerView
        mKBPartRefundRecyclerView.setLayoutManager(linearLayoutManager);//设置分割线
        RecycleViewDivider viewDivider = new RecycleViewDivider(getContext(), linearLayoutManager.getOrientation());
        mKBPartRefundRecyclerView.addItemDecoration(viewDivider);
        if (!ListUtil.isEmpty(orderMenuItems)) {
            mwPartRefundChooseMenuAdapter = new MwPartRefundChooseMenuAdapter();
            mKBPartRefundRecyclerView.setAdapter(mwPartRefundChooseMenuAdapter);
        } else {
            kbPartRefundChooseMenuAdapter = new KBPartRefundChooseMenuAdapter();
            mKBPartRefundRecyclerView.setAdapter(kbPartRefundChooseMenuAdapter);
        }
    }


    /**
     * 初始化数据
     */
    private void initData() {
        mKBPartRefundTitle.setText("请选择退款菜品？");
        if (!ListUtil.isEmpty(orderMenuItems)) {
            mwPartRefundChooseMenuAdapter.modules.addAll(orderMenuItems);
            mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
        } else {
            kbPartRefundChooseMenuAdapter.modules.addAll(kbOrderMenuItem);
            kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mKBPartRefundCancelBtn://取消
                dismiss();
                break;

            case R.id.mKBPartRefundSubmitBtn://确定
                if (!ListUtil.isEmpty(orderMenuItems)) {
                    if (choiceStates.isEmpty()) {
                        ToastUtil.showToast("请选择需要退款的菜品");
                        return;
                    }
                    //判断是否全部退款
                    boolean refundAllVoid = true;
                    ArrayList<MenuItem> choiceStatesFrom = new ArrayList<>();
                    Iterator<Map.Entry<MenuItem, Integer>> iterator = choiceStates.entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry<MenuItem, Integer> entry = iterator.next();
                        MenuItem model = entry.getKey();
                        Integer value = entry.getValue();
                        if (value != model.menuBiz.buyNum.intValue()) {
                            refundAllVoid = false;
                        }

                        model.menuBiz.buyNum = new BigDecimal(value);
                        choiceStatesFrom.add(model);
                    }
                    menuListListener.onChoiceRefundMenu(choiceStatesFrom, mKBPartRefundMenuChoiceAll.isSelected() && refundAllVoid);
                } else {
                    if (kbChoiceStates.isEmpty()) {
                        ToastUtil.showToast("请选择需要退款的菜品");
                        return;
                    }

                    //判断是否全部退款 成立条件 1选择全部 2菜品数量也全部选择
                    boolean refundAllVoid = true;
                    BigDecimal totalAmount = BigDecimal.ZERO;
                    Iterator<Map.Entry<KBPreMenuItemModel, Integer>> iterator = kbChoiceStates.entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry<KBPreMenuItemModel, Integer> entry = iterator.next();
                        KBPreMenuItemModel model = entry.getKey();
                        Integer value = entry.getValue();
                        if (value != model.dish_num.intValue()) {
                            refundAllVoid = false;
                        }
                        BigDecimal totalPrice = model.sell_price.multiply(new BigDecimal(value)).setScale(2, BigDecimal.ROUND_HALF_UP);
                        totalAmount = totalAmount.add(totalPrice);

                    }

                    menuListListener.onKBChoiceRefundMenu(totalAmount.toString(), mKBPartRefundMenuChoiceAll.isSelected() && refundAllVoid);
                }

                break;
            case R.id.mKBPartRefundMenuChoiceAll://全选
                if (!ListUtil.isEmpty(orderMenuItems)) {
                    doChoiceAll();
                } else {
                    doKBChoiceAll();
                }

                break;
            default:
                dismiss();
                break;
        }
    }

    /**
     * 口碑订单菜品信息Adapter
     */
    private class KBPartRefundChooseMenuAdapter extends BaseListAdapter<KBPreMenuItemModel> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.kb_part_refund_choose_menu_item, parent, false));
        }

        class ViewHolder extends BaseViewHolder implements View.OnClickListener, NumberEditorView.OnNumberEditorClickListener {

            private ImageView mKBPartRefundMenuItemCheck;//选中图标
            private TextView mKBPartRefundMenuItemName;//名称
            private TextView mKBPartRefundMenuItemUnitPrice;//单价
            private TextView mKBPartRefundMenuItemAmount;//金额

            private RelativeLayout mLayoutCheck;
            private NumberEditorView mNumberEditorView;

            private KBPreMenuItemModel kbMenuItem;

            public ViewHolder(View v) {
                super(v);
                mKBPartRefundMenuItemCheck = v.findViewById(R.id.mKBPartRefundMenuItemCheck);
                mKBPartRefundMenuItemName = v.findViewById(R.id.mKBPartRefundMenuItemName);
                mKBPartRefundMenuItemUnitPrice = v.findViewById(R.id.mKBPartRefundMenuItemUnitPrice);
                mKBPartRefundMenuItemAmount = v.findViewById(R.id.mKBPartRefundMenuItemAmount);
                mNumberEditorView = v.findViewById(R.id.mNumberEditorView);
                mNumberEditorView.setOnNumberEditorClick(this);
                mLayoutCheck = v.findViewById(R.id.mLayoutCheck);
                mLayoutCheck.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                kbMenuItem = modules.get(position);
                mKBPartRefundMenuItemName.setText(kbMenuItem.dish_name);
                mKBPartRefundMenuItemUnitPrice.setText(kbMenuItem.sell_price + "");//单价
                BigDecimal totalPrice = kbMenuItem.sell_price.multiply(kbMenuItem.dish_num).setScale(2, BigDecimal.ROUND_HALF_UP);
                mKBPartRefundMenuItemAmount.setText(totalPrice + "");


                if (kbChoiceStates.containsKey(kbMenuItem)) {
                    mKBPartRefundMenuItemCheck.setSelected(true);

                    //配料菜不支持部分退
                    if (kbMenuItem.dish_num.intValue() > 1 && ListUtil.isEmpty(kbMenuItem.selectedModifier)) {
                        mNumberEditorView.setMax(kbMenuItem.dish_num.intValue());
                        mNumberEditorView.setMin(1);
                        mNumberEditorView.mNumberContentLabel.setBackground(null);
                        mNumberEditorView.mNumberMinusBtn.setVisibility(View.VISIBLE);
                        mNumberEditorView.mNumberAddBtn.setVisibility(View.VISIBLE);
                    } else {
                        mNumberEditorView.mNumberMinusBtn.setVisibility(View.GONE);
                        mNumberEditorView.mNumberAddBtn.setVisibility(View.GONE);
                        mNumberEditorView.mNumberContentLabel.setBackground(null);
                    }
                    mNumberEditorView.notifyDataChanged(kbChoiceStates.get(kbMenuItem).intValue());
                } else {
                    mKBPartRefundMenuItemCheck.setSelected(false);

                    mNumberEditorView.mNumberMinusBtn.setVisibility(View.GONE);
                    mNumberEditorView.mNumberAddBtn.setVisibility(View.GONE);
                    mNumberEditorView.mNumberContentLabel.setBackground(null);
                    mNumberEditorView.notifyDataChanged(kbMenuItem.dish_num.intValue());
                }

            }

            @Override
            public void onClick(View view) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                kbChoice(kbMenuItem);
                kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
                mKBPartRefundMenuChoiceAll.setSelected(isKBChoiceAll());
            }

            @Override
            public boolean onMinusClick(View view, int before, int after) {
                kbChoiceStates.put(kbMenuItem, new BigDecimal(kbChoiceStates.get(kbMenuItem)).subtract(BigDecimal.ONE).intValue());
                return before != 1;
            }

            @Override
            public boolean onAddClick(View view, int before, int after) {
                kbChoiceStates.put(kbMenuItem, new BigDecimal(kbChoiceStates.get(kbMenuItem)).add(BigDecimal.ONE).intValue());
                return before < kbMenuItem.dish_num.intValue();
            }

            @Override
            public void onNumberEditorClick() {

            }
        }
    }

    /**
     * 全选或清除全选（口碑）
     */
    private void doKBChoiceAll() {
        mKBPartRefundMenuChoiceAll.setSelected(!mKBPartRefundMenuChoiceAll.isSelected());
        if (mKBPartRefundMenuChoiceAll.isSelected()) {
            kbChoiceAll();
        } else {
            kbCancelChoiceAll();
        }
        kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 单选一个菜品（口碑）
     *
     * @param value
     */
    private void kbChoice(KBPreMenuItemModel value) {

        if (kbChoiceStates.containsKey(value)) {
            kbChoiceStates.remove(value);
        } else {
            kbChoiceStates.put(value, value.dish_num.intValue());
        }
        kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 判断是否全选（口碑）
     *
     * @return
     */
    private boolean isKBChoiceAll() {
        for (int i = 0; i < kbPartRefundChooseMenuAdapter.modules.size(); i++) {
            if (!kbChoiceStates.containsKey(kbPartRefundChooseMenuAdapter.modules.get(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选（口碑）
     */
    private void kbChoiceAll() {
        kbChoiceStates.clear();
        for (KBPreMenuItemModel module : kbPartRefundChooseMenuAdapter.modules) {
            kbChoiceStates.put(module, module.dish_num.intValue());
        }
        kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 清除全选（口碑）
     */
    private void kbCancelChoiceAll() {
        kbChoiceStates.clear();
        kbPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }


    /**
     * 本地口碑订单信息Adapter
     */
    private class MwPartRefundChooseMenuAdapter extends BaseListAdapter<MenuItem> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.kb_part_refund_choose_menu_item, parent, false));
        }

        class ViewHolder extends BaseViewHolder implements View.OnClickListener, NumberEditorView.OnNumberEditorClickListener {

            private ImageView mKBPartRefundMenuItemCheck;//选中图标
            private TextView mKBPartRefundMenuItemName;//名称
            private TextView mKBPartRefundMenuItemUnitPrice;//单价
            private TextView mKBPartRefundMenuItemAmount;//金额

            private NumberEditorView mNumberEditorView;
            private RelativeLayout mLayoutCheck;

            private MenuItem menuItem;


            public ViewHolder(View v) {
                super(v);
                mKBPartRefundMenuItemCheck = v.findViewById(R.id.mKBPartRefundMenuItemCheck);
                mKBPartRefundMenuItemName = v.findViewById(R.id.mKBPartRefundMenuItemName);
                mKBPartRefundMenuItemUnitPrice = v.findViewById(R.id.mKBPartRefundMenuItemUnitPrice);
                mKBPartRefundMenuItemAmount = v.findViewById(R.id.mKBPartRefundMenuItemAmount);
                mNumberEditorView = v.findViewById(R.id.mNumberEditorView);
                mLayoutCheck = v.findViewById(R.id.mLayoutCheck);
                mNumberEditorView.setOnNumberEditorClick(this);
                mLayoutCheck.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                menuItem = modules.get(position);
                mKBPartRefundMenuItemName.setText(menuItem.name);


                //先计算单价 含有配料菜品的菜品总价 = 菜品头价格+配料菜总价格
                BigDecimal price = BigDecimal.ZERO;
                //退含有赔偿菜的菜品 需要加上配料菜的价格
                for (MenuItem modifierMenuItem : menuItem.menuBiz.selectedModifier) {
                    price = price.add(modifierMenuItem.menuBiz.buyNum.multiply(modifierMenuItem.currentUnit.fdOriginPrice));
                }
                price = price.add(menuItem.currentUnit.fdSalePrice);
                mKBPartRefundMenuItemUnitPrice.setText(price + "");//单价
                mKBPartRefundMenuItemAmount.setText(price.multiply(menuItem.menuBiz.buyNum) + "");


                if (choiceStates.containsKey(menuItem)) {
                    mKBPartRefundMenuItemCheck.setSelected(true);
                    if (menuItem.menuBiz.buyNum.intValue() > 1 && ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                        mNumberEditorView.setMax(menuItem.menuBiz.buyNum.intValue());
                        mNumberEditorView.setMin(1);
                        mNumberEditorView.mNumberContentLabel.setBackground(null);
                        mNumberEditorView.mNumberMinusBtn.setVisibility(View.VISIBLE);
                        mNumberEditorView.mNumberAddBtn.setVisibility(View.VISIBLE);
                    } else {
                        mNumberEditorView.mNumberMinusBtn.setVisibility(View.GONE);
                        mNumberEditorView.mNumberAddBtn.setVisibility(View.GONE);
                        mNumberEditorView.mNumberContentLabel.setBackground(null);
                    }
                    mNumberEditorView.notifyDataChanged(choiceStates.get(menuItem).intValue());
                } else {
                    mKBPartRefundMenuItemCheck.setSelected(false);

                    mNumberEditorView.mNumberMinusBtn.setVisibility(View.GONE);
                    mNumberEditorView.mNumberAddBtn.setVisibility(View.GONE);
                    mNumberEditorView.mNumberContentLabel.setBackground(null);
                    mNumberEditorView.notifyDataChanged(menuItem.menuBiz.buyNum.intValue());
                }
            }

            @Override
            public void onClick(View view) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                choice(menuItem);
                mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
                mKBPartRefundMenuChoiceAll.setSelected(isChoiceAll());
            }

            @Override
            public boolean onMinusClick(View view, int before, int after) {
                //menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(BigDecimal.ONE);
                choiceStates.put(menuItem, new BigDecimal(choiceStates.get(menuItem)).subtract(BigDecimal.ONE).intValue());
                return before != 1;
            }

            @Override
            public boolean onAddClick(View view, int before, int after) {
                //menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.add(BigDecimal.ONE);
                choiceStates.put(menuItem, new BigDecimal(choiceStates.get(menuItem)).add(BigDecimal.ONE).intValue());
                return before < menuItem.menuBiz.buyNum.intValue();
            }

            @Override
            public void onNumberEditorClick() {

            }
        }
    }

    private void doChoiceAll() {
        mKBPartRefundMenuChoiceAll.setSelected(!mKBPartRefundMenuChoiceAll.isSelected());
        if (mKBPartRefundMenuChoiceAll.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 单选一个菜品
     *
     * @param menuItem
     */
    private void choice(MenuItem menuItem) {

        if (choiceStates.containsKey(menuItem)) {
            choiceStates.remove(menuItem);
        } else {
            choiceStates.put(menuItem, menuItem.menuBiz.buyNum.intValue());
        }
        mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 判断是否全选
     *
     * @return
     */
    private boolean isChoiceAll() {
        for (int i = 0; i < mwPartRefundChooseMenuAdapter.modules.size(); i++) {
            if (!choiceStates.containsKey(mwPartRefundChooseMenuAdapter.modules.get(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选
     */
    private void choiceAll() {
        choiceStates.clear();
        for (MenuItem module : mwPartRefundChooseMenuAdapter.modules) {
            choiceStates.put(module, module.menuBiz.buyNum.intValue());
        }
        mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    /**
     * 清除全选
     */
    private void cancelChoiceAll() {
        choiceStates.clear();
        mwPartRefundChooseMenuAdapter.notifyDataSetChanged();
    }

    public interface OnChoiceRefundMenuListListener {
        void onChoiceRefundMenu(ArrayList<MenuItem> choiceRefundMenuList, boolean isCheckAll);

        void onKBChoiceRefundMenu(String refundAmount, boolean isCheckAll);
    }

    public void setOnChoiceRefundMenuListListener(OnChoiceRefundMenuListListener listener) {
        this.menuListListener = listener;
    }

}
