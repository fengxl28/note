package com.mwee.android.pos.air.business.payment.component;

import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.NetWorkUtil;

import java.util.HashMap;

/**
 * @ClassName: PaymentConstant
 * @Description:
 * @author: SugarT
 * @date: 2017/10/14 下午5:08
 */
public class PaymentConstant {

    public static final String URL_BIND_PAY_DEV = "http://shop.test.9now.net/emanage/openpay?shopid=";

    public static final String URL_BIND_PAY_PRODUCT = "http://shop.mwee.cn/emanage/openpay?shopid=";


    //public static final String URL_HELP_DEV = "http://test.adminui.mwpos.cn/static/pages/help.html";
    public static final String URL_HELP_DEV = "http://test.adminui.mwpos.cn/static/pages/help21.html";

    //public static final String URL_HELP_PRODUCT = "http://adminui.mwpos.cn/static/pages/help.html";
    public static final String URL_HELP_PRODUCT = "http://adminui.mwpos.cn/static/pages/help21.html";


    public static final String URL_FEEDBACK_DEV = "http://st.9now.net/Html/APP/FeedBack/feedBack.html";

    public static final String URL_FEEDBACK_PRODUCT = "http://b.mwee.cn/Html/APP/FeedBack/feedBack.html";


    /**
     * 获取绑定支付账号的链接
     *
     * @return
     */
    public static String getUrlBindPay() {
        StringBuilder sb = new StringBuilder();
        if (BaseConfig.isProduct()) {
            sb.append(URL_BIND_PAY_PRODUCT);
        } else {
            sb.append(URL_BIND_PAY_DEV);
        }
        sb.append(AppCache.getInstance().fsShopGUID);
        return sb.toString();
    }

    /**
     * 获取帮助中心的地址
     *
     * @return
     */
    public static String getUrlHelp() {

        StringBuilder sb = new StringBuilder();
        if (BaseConfig.isProduct()) {
            sb.append(URL_HELP_PRODUCT);
        } else {
            sb.append(URL_HELP_DEV);
        }
        return sb.toString();
    }

    /**
     * 获取意见反馈的地址
     *
     * @return
     */
    public static String getUrlFeedBack() {

        StringBuilder sb = new StringBuilder();
        if (BaseConfig.isProduct()) {
            sb.append(URL_FEEDBACK_PRODUCT);
        } else {
            sb.append(URL_FEEDBACK_DEV);
        }
        return sb.toString();
    }


    /**
     * 意见反馈携带参数
     * @param mhost
     * @return
     */
    public static HashMap<String, Object> getParameters(Host mhost) {
        WindowManager wm = (WindowManager) mhost.getActivityWithinHost().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        HashMap<String, Object> map = new HashMap<>();
        map.put("token", ClientMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID));
        map.put("apiVersion", "V8");
        map.put("appver", BuildConfig.VERSION_NAME);
        map.put("resolution", display.getWidth() + "*" + display.getHeight());
        map.put("network", NetWorkUtil.getNetWorkDes(mhost.getContextWithinHost()));
        map.put("device", DeviceUtil.getSerialNO());
        map.put("softtype", BuildConfig.APPID);
        map.put("faq", 0);
        return map;
    }


}
