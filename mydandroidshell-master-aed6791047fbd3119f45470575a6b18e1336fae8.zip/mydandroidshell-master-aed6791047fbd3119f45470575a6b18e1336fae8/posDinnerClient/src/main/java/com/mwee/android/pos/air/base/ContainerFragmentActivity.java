package com.mwee.android.pos.air.base;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;

import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.TitleBar;

import java.io.Serializable;


/**
 * Created by qinwei on 2017/4/4.
 */

public class ContainerFragmentActivity extends BaseActivity {
    public static final String KEY_FRAGMENT_CLAZZ = "key_fragment_clazz";
    public static final String KEY_FRAGMENT_CLAZZ_ARGS = "key_fragment_clazz_args";

    /**
     * title 显示
     */
    public static final String KEY_SHOW_TITLE = "key_show_title";

    public TitleBar mTitleBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (APPConfig.isAir()) {
            setContentView(R.layout.activity_fragment_container);
        } else {
            setContentView(R.layout.activity_fragment_container_black);
        }
        mTitleBar = (TitleBar) findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                KeyboardManager.hideKeyboard(getActivityWithinHost());
                onBackPressed();
//                finish();
            }
        });
        initData(savedInstanceState);
    }

    protected void initData(Bundle savedInstanceState) {
        Clazz clazzInfo = (Clazz) getIntent().getSerializableExtra(KEY_FRAGMENT_CLAZZ);
        mTitleBar.setTitle(clazzInfo.name);
        try {
            Fragment fragment = clazzInfo.clazz.newInstance();
            Bundle mBundle = getIntent().getBundleExtra(KEY_FRAGMENT_CLAZZ_ARGS);
            if (mBundle != null) {
                fragment.setArguments(mBundle);
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.main_menufragment, fragment).commit();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        int isShowTitle = getIntent().getIntExtra(KEY_SHOW_TITLE, 1);
        if (isShowTitle == 1) {
            mTitleBar.setVisibility(View.VISIBLE);
        } else {
            mTitleBar.setVisibility(View.GONE);
        }
    }

    public void setmTitleBar(String mTitle) {
        mTitleBar.setTitle(mTitle);
    }

    public static class Clazz implements Serializable {
        public Clazz(String name, Class<? extends BaseFragment> clazz) {
            this.name = name;
            this.clazz = clazz;
        }

        public String name;
        public Class<? extends BaseFragment> clazz;
    }
}
