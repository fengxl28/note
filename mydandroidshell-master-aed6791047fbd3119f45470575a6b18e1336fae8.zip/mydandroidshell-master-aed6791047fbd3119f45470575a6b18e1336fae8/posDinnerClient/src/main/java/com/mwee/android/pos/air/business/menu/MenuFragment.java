package com.mwee.android.pos.air.business.menu;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.drivenbus.DrivenBusManager;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.menu.dialog.MenuClsEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.dialog.MenuEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.processor.MenuClsProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuManagerProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author qinwei
 * @date 2017/11/6
 */

public class MenuFragment extends BaseFragment implements IDriver {
    private ListView mMenuClsLsv;
    private RecyclerView mMenuRecyclerView;
    private MenuClsAdapter menuClsAdapter;
    private MenuAdapter menuAdapter;
    private MenuManagerProcessor mMenuManagerProcessor;
    private MenuProcessor menuProcessor;
    private MenuClsProcessor menuClsProcessor;
    private final static String TAG = "menuFragment";
    private View mMenuEmptyLabel;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_air_menu_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    private void initView(View view) {
        mMenuClsLsv = view.findViewById(R.id.mMenuClsLsv);
        mMenuEmptyLabel = view.findViewById(R.id.mMenuEmptyLabel);
        mMenuRecyclerView = view.findViewById(R.id.mMenuRecyclerView);
        mMenuRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 4));
        View v = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_cls_add, mMenuClsLsv, false);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadMenuClsPrinters(new MenuTypeBean());
            }
        });
        mMenuClsLsv.addFooterView(v);
        mMenuClsLsv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                MenuTypeBean bean = (MenuTypeBean) adapterView.getAdapter().getItem(i);
                if (!mMenuManagerProcessor.isNormalMenuCls(bean.fsMenuClsId) || i == 0) {
                    return true;
                }
                //获取前一个分类，i为0的情况被前面过滤了。
                MenuTypeBean topBean = (MenuTypeBean) adapterView.getAdapter().getItem(i - 1);
                boolean isShowTop = mMenuManagerProcessor.isShowTop(topBean.fsMenuClsId);
                showMenuClsPopupMenu(view, bean, isShowTop);
                return true;
            }
        });
        mMenuClsLsv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (menuClsAdapter.selectPosition != i) {
                    choiceMenuClsItem(i);
                    loadMenuItemsByClsPosition(i);
                }
            }
        });

    }


    private void initData() {
        mMenuManagerProcessor = new MenuManagerProcessor();
        menuProcessor = new MenuProcessor();
        menuClsProcessor = new MenuClsProcessor();
        menuClsProcessor.initMenuCls();
        menuClsAdapter = new MenuClsAdapter();
        mMenuClsLsv.setAdapter(menuClsAdapter);
        menuAdapter = new MenuAdapter();
        menuAdapter.isFooterShow = true;
        menuAdapter.isHeaderShow = true;
        mMenuRecyclerView.setAdapter(menuAdapter);
        loadAllMenuCls();
        choiceMenuClsItem(0);
        loadMenuItemsByClsPosition(0);
    }


    private void loadAllMenuCls() {
        if (AppCache.getInstance().firstNodeMap.size() > 0) {
            mMenuRecyclerView.setVisibility(View.VISIBLE);
            mMenuEmptyLabel.setVisibility(View.GONE);
        } else {
            mMenuRecyclerView.setVisibility(View.GONE);
            mMenuEmptyLabel.setVisibility(View.VISIBLE);
        }
        menuClsProcessor.initMenuCls();
        menuClsAdapter.modules = (ArrayList<MenuTypeBean>) AppCache.getInstance().firstNodeMap;
        menuClsAdapter.notifyDataSetChanged();
    }

    private void choiceMenuClsItem(int position) {
        menuClsAdapter.selectPosition = position;
        menuClsAdapter.notifyDataSetChanged();
    }

    private void loadMenuItemsByClsPosition(int index) {
        menuAdapter.modules.clear();
        int size = AppCache.getInstance().firstNodeMap.size();
        if (size != 0 && index < size) { //fix IndexOutOfBoundsException  https://bugly.qq.com/v2/crash-reporting/crashes/900025575/11890?pid=1
            menuAdapter.modules.addAll(AppCache.getInstance().firstNodeMap.get(index).menuList);
        } else {
            LogUtil.log(TAG, "loadMenuItemsByClsPosition size = " + size );
        }
        menuAdapter.notifyDataSetChanged();
    }

    private void loadMenuClsTop(final MenuTypeBean bean) {
        final Progress progress = ProgressManager.showProgressUncancel(this, "置顶中...");
        menuClsProcessor.loadMenuClsToTop(bean.fsMenuClsId, new ResultCallback<MenuClsToTopResponse>() {
            @Override
            public void onSuccess(MenuClsToTopResponse data) {
                menuClsAdapter.selectPosition = 1;
                menuClsAdapter.modules.remove(bean);
                menuClsAdapter.modules.add(mMenuManagerProcessor.getNotNormalMenuNum(menuClsAdapter.modules), bean);
                menuClsAdapter.notifyDataSetChanged();
                progress.dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void showMenuClsEditorDialog(final MenuTypeBean bean, MenuClsPrintersResponse data) {
        MenuClsEditorDialogFragment fragment = new MenuClsEditorDialogFragment();
        MenuClsBean menuClsBean = menuClsProcessor.copyTo(bean);
        menuClsBean.printerNames = data.choicePrinters;
        fragment.setParam(menuClsBean, data.allPrinters);
        fragment.setOnMenuClsEditorListener(new MenuClsEditorDialogFragment.OnMenuClsEditorListener() {
            @Override
            public void onMenuClsAddSuccess(String id, String name) {
            }

            @Override
            public void onMenuClsUpdateSuccess(String name) {
                bean.fsMenuClsName = name;
                menuClsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onMenuClsDeleteSuccess() {
                menuClsProcessor.deleteMenuCls(bean);
                //全部选中
                choiceMenuClsItem(0);
                //刷全部菜品
                loadMenuItemsByClsPosition(0);
                loadAllMenuCls();
            }
        });
        DialogManager.showCustomDialog(this, fragment, "MenuClsEditorDialogFragment");
    }

    public void loadMenuClsPrinters(final MenuTypeBean bean) {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        menuClsProcessor.loadMenuClsPrinters(bean.fsMenuClsId, new ResultCallback<MenuClsPrintersResponse>() {
            @Override
            public void onSuccess(MenuClsPrintersResponse data) {
                progress.dismiss();
                if (TextUtils.isEmpty(bean.fsMenuClsId)) {
                    showMenuClsAddDialog(data);
                } else {
                    showMenuClsEditorDialog(bean, data);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void showMenuClsAddDialog(MenuClsPrintersResponse data) {
        MenuClsEditorDialogFragment fragment = new MenuClsEditorDialogFragment();
        MenuClsBean menuClsBean = new MenuClsBean();
        //默认选择所有打印机
        for (PrinterItem allPrinter : data.allPrinters) {
            menuClsBean.printerNames.add(allPrinter.name);
        }
        fragment.setParam(menuClsBean, data.allPrinters);
        fragment.setOnMenuClsEditorListener(new MenuClsEditorDialogFragment.OnMenuClsEditorListener() {
            @Override
            public void onMenuClsAddSuccess(String id, String name) {
                MenuTypeBean bean = new MenuTypeBean();
                bean.fsMenuClsId = id;
                bean.fsMenuClsName = name;
                bean.fiMenuClsKind = 1;
                menuClsProcessor.addMenuCls(bean);
                loadAllMenuCls();
            }

            @Override
            public void onMenuClsUpdateSuccess(String name) {
            }

            @Override
            public void onMenuClsDeleteSuccess() {
            }
        });
        DialogManager.showCustomDialog(this, fragment, "MenuClsEditorDialogFragment");
    }

    private void loadMenuClsDelete(final MenuTypeBean bean) {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        menuClsProcessor.loadMenuClsDelete(bean.fsMenuClsId, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismiss();
                menuClsProcessor.deleteMenuCls(bean);
                //全部选中
                choiceMenuClsItem(0);
                //刷全部菜品
                loadMenuItemsByClsPosition(0);
                loadAllMenuCls();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }


    private void showMenuItemSearchDialog() {
        MenuSearchFragment fragment = new MenuSearchFragment();
        fragment.setParam(new ArrayMap<>(), "");
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.mMenuLayout, fragment, "MenuSearchFragment");
        fragmentTransaction.commit();
    }

    private void loadMenuItemTop(final MenuItem menuItem) {
        final Progress progress = ProgressManager.showProgress(this, "置顶中...");
        mMenuManagerProcessor.loadMenuItemToTop(menuItem.itemID, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                menuClsAdapter.getCurrentMenuCls().menuList.remove(menuItem);
                menuClsAdapter.getCurrentMenuCls().menuList.add(0, menuItem);
                loadMenuItemsByClsPosition(menuClsAdapter.selectPosition);
                ToastUtil.showToast(data);
                progress.dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismiss();
            }
        });
    }

    private void showMenuItemAddDialog() {
        MenuEditorDialogFragment fragment = new MenuEditorDialogFragment();
        String fsMenuClsId = null;
        List<MenuClsBean> menuClsBeans = buildMenuClsBeans();
        MenuTypeBean menuTypeBean = menuClsAdapter.getCurrentMenuCls();
        if (mMenuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
            fsMenuClsId = menuTypeBean.fsMenuClsId;
        } else {
            fsMenuClsId = "";
        }
        fragment.setParam(fsMenuClsId, menuClsBeans);
        fragment.setOnMenuEditorListener(new MenuEditorDialogFragment.OnMenuEditorListener() {
            @Override
            public void onMenuUpdateSuccess(MenuItemBean bean) {

            }

            @Override
            public void onMenuAddSuccess(MenuItem menuItem, MenuItemBean bean) {
                mMenuManagerProcessor.sync(menuItem, bean);
                mMenuManagerProcessor.refreshMenuItem(menuItem);
                menuClsAdapter.modules.get(0).menuList.add(menuItem);
                loadMenuItemsByClsPosition(menuClsAdapter.selectPosition);
            }
        });
        DialogManager.showCustomDialog(this, fragment, "MenuEditorDialogFragment");

    }


    private void loadMenuItemDelete(final MenuItem menuItem) {
        ArrayList<String> ids = new ArrayList<>();
        ids.add(menuItem.itemID);
        final Progress progress = ProgressManager.showProgressUncancel(this);
        menuProcessor.loadBatchDelete(ids, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                for (MenuTypeBean menuTypeBean : AppCache.getInstance().firstNodeMap) {
                    menuTypeBean.menuList.remove(menuItem);
                }
                progress.dismiss();
                loadMenuItemsByClsPosition(menuClsAdapter.selectPosition);
                ToastUtil.showToast(R.string.delete_success);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismiss();
            }
        });
    }


    private void showMenuItemEditorDialog(final MenuItem data) {
        MenuEditorDialogFragment fragment = new MenuEditorDialogFragment();
        MenuTypeBean menuTypeBean = menuClsAdapter.getCurrentMenuCls();
        if (mMenuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
            data.categoryCode = menuTypeBean.fsMenuClsId;
        }
        fragment.setParam(MenuItemBean.copyTo(data, AppCache.getInstance().getSelloutNum(data.currentUnit.fiOrderUintCd)), buildMenuClsBeans());
        fragment.setOnMenuEditorListener(new MenuEditorDialogFragment.OnMenuEditorListener() {

            @Override
            public void onMenuUpdateSuccess(MenuItemBean bean) {
                mMenuManagerProcessor.refreshMenuItem(data, bean);
                loadMenuItemsByClsPosition(menuClsAdapter.selectPosition);
            }

            @Override
            public void onMenuAddSuccess(MenuItem menuItem, MenuItemBean bean) {

            }

        });
        DialogManager.showCustomDialog(this, fragment, "MenuEditorDialogFragment");
    }

    /**
     * 构建分类列表
     *
     * @return
     */
    private List<MenuClsBean> buildMenuClsBeans() {
        List<MenuClsBean> beans = new ArrayList<>();
        MenuTypeBean menuTypeBean = null;
        for (int i = 1; i < menuClsAdapter.modules.size(); i++) {
            menuTypeBean = menuClsAdapter.modules.get(i);
            if (mMenuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId) && menuTypeBean.fiMenuClsKind == 1) {
                beans.add(MenuClsBean.copyTo(menuTypeBean));
            }
        }
        return beans;
    }

    private void onMenuItemClick(MenuItem data) {
        //获取缓存中菜品时效信息
        MenuEffectiveInfo menuEffectiveInfo = AppCache.getInstance().menuEffectiveInfoMap.get(data.itemID);
        //未设置时效菜品或者菜品时效时间生效中
        if (menuEffectiveInfo == null || menuEffectiveInfo.dataIsEffectiveDate()) {
            String sectionID = "";
            OrderDishesBizUtil.startProcessClickedMenu(getActivityWithinHost(), data, false, sectionID);
        }
    }


    @DrivenMethod(uri = TAG + "/selloutchanged", UIThread = true)
    public void selloutchanged() {
        menuAdapter.notifyDataSetChanged();
    }

    @DrivenMethod(uri = TAG + "/menuDataChanged", UIThread = true)
    public void menuDataChanged() {
        loadAllMenuCls();
        if (menuClsAdapter.modules.size() - 1 < menuClsAdapter.selectPosition) {
            //删除
            loadMenuItemsByClsPosition(0);
        } else {
            loadMenuItemsByClsPosition(menuClsAdapter.selectPosition);
        }
    }

    private void showMenuClsPopupMenu(View view, final MenuTypeBean bean, boolean isShowTop) {
        PopupMenu popupMenu = new PopupMenu(getContext(), view);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(android.view.MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_editor:
                        loadMenuClsPrinters(bean);
                        break;
                    case R.id.action_top:
                        loadMenuClsTop(bean);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
        popupMenu.getMenuInflater().inflate(R.menu.menu_editor_and_top, popupMenu.getMenu());
        popupMenu.getMenu().findItem(R.id.action_delete).setVisible(false);
        menuEditorSet(popupMenu, isShowTop);
        popupMenu.show();
    }

    /**
     * 菜品分类长按弹窗显示选项
     *
     * @param popupMenu
     * @param isShowTop
     */
    private void menuEditorSet(PopupMenu popupMenu, boolean isShowTop) {
        if (isShowTop) {
            popupMenu.getMenu().findItem(R.id.action_top).setVisible(true);
        } else {
            popupMenu.getMenu().findItem(R.id.action_top).setVisible(false);
        }
    }

    private void showMenuItemPopupMenu(View view, final MenuItem data) {
        PopupMenu popupMenu = new PopupMenu(getContext(), view);
        popupMenu.getMenuInflater().inflate(R.menu.menu_editor_and_top, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(android.view.MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_editor:
                        showMenuItemEditorDialog(data);
                        break;
                    case R.id.action_delete:
                        DialogManager.showExecuteDialog(getActivityWithinHost(),
                                "确定删除该菜品吗？",
                                getStringWithinHost(R.string.cacel),
                                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                                    @Override
                                    public void response() {
                                        loadMenuItemDelete(data);
                                    }
                                }, null);
                        break;
                    case R.id.action_top:
                        loadMenuItemTop(data);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
        boolean isShowToMenu = menuAdapter.modules.indexOf(data) != 0 && mMenuManagerProcessor.isNormalMenuCls(menuClsAdapter.getCurrentMenuCls().fsMenuClsId);
        menuEditorSet(popupMenu, isShowToMenu);
        popupMenu.show();
    }

    public void refreshMenuItems() {
        menuAdapter.notifyDataSetChanged();
    }

    class MenuAdapter extends BaseListAdapter<MenuItem> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuAdapter.MenuHolder(LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_item, parent, false));
        }

        @Override
        protected View onCreateHeaderView(ViewGroup parent) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_item_header, parent, false);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMenuItemSearchDialog();
                }
            });
            return view;
        }

        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            View view = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_item_footer, parent, false);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (menuClsAdapter.selectPosition == 0 || menuClsAdapter.getCurrentMenuCls().fiMenuClsKind == 1) {
                        showMenuItemAddDialog();
                    } else {
                        ToastUtil.showToast("套餐菜品请到套餐管理界面添加!");
                    }
                }
            });
            return view;
        }

        class MenuHolder extends BaseViewHolder implements View.OnClickListener, View.OnLongClickListener {

            private TextView mMenuItemNameLabel;
            private TextView mMenuItemRepertoryLabel;
            private TextView mMenuItemSellPriceLabel;
            private TextView mMenuTagSellOutLabel;
            private MenuItem data;

            public MenuHolder(View v) {
                super(v);
                mMenuItemNameLabel = v.findViewById(R.id.mMenuItemNameLabel);
                mMenuItemRepertoryLabel = v.findViewById(R.id.mMenuItemRepertoryLabel);
                mMenuItemSellPriceLabel = v.findViewById(R.id.mMenuItemSellPriceLabel);
                mMenuTagSellOutLabel = v.findViewById(R.id.mMenuTagSellOutLabel);
                v.setOnClickListener(this);
                v.setOnLongClickListener(this);
            }

            @Override
            public void bindData(int position) {
                data = modules.get(position);
                mMenuItemNameLabel.setText(data.name);
                BigDecimal num = AppCache.getInstance().getSelloutNum(data.currentUnit.fiOrderUintCd);
                //临时沽清显示沽清数量
                mMenuItemSellPriceLabel.setTextColor(getResources().getColor(R.color.color_3b3b3b));
                mMenuItemNameLabel.setTextColor(getResources().getColor(R.color.color_363636));
                if (num.compareTo(BigDecimal.ZERO) >= 0) {
                    if (num.compareTo(BigDecimal.ZERO) == 0) {
                        mMenuTagSellOutLabel.setVisibility(View.VISIBLE);
                        mMenuItemRepertoryLabel.setVisibility(View.GONE);
                        //沽清字体颜色样式修改
                        mMenuItemSellPriceLabel.setTextColor(getResources().getColor(R.color.color_969696));
                        mMenuItemNameLabel.setTextColor(getResources().getColor(R.color.color_969696));
                    } else {
                        mMenuItemRepertoryLabel.setText(num + "");
                        mMenuTagSellOutLabel.setVisibility(View.GONE);
                        mMenuItemRepertoryLabel.setVisibility(View.VISIBLE);
                    }
                } else {
                    mMenuTagSellOutLabel.setVisibility(View.GONE);
                    mMenuItemRepertoryLabel.setVisibility(View.GONE);
                }
                mMenuItemSellPriceLabel.setText(Calc.formatShow(data.currentUnit.fdSalePrice, RoundConfig.ROUND_SINGLE_PRICE));
            }

            @Override
            public void onClick(View v) {
                if (!AppCache.getInstance().openOrder){
                    ToastUtil.showToast("您没有该操作权限,请管理员在后台配置权限.");
                    return;
                }
                BigDecimal num = AppCache.getInstance().getSelloutNum(data.currentUnit.fiOrderUintCd);
                if (num.compareTo(BigDecimal.ZERO) != 0) {
                    onMenuItemClick(data);
                }
            }

            @Override
            public boolean onLongClick(View view) {
                if (!ButtonClickTimer.canClick()) {
                    return true;
                }
                if (data.supportPackage()) {
                    ToastUtil.showToast("套餐菜品，请到套餐管理页面编辑");
                    return true;
                    //多规格 多做法
                } else if (data.supportIngredient()) {
                    ToastUtil.showToast("暂不支持配料菜品修改");
                } else if ((data.config & 2) == 2 || (data.config & 4) == 4) {
                    ToastUtil.showToast("多规格菜品，请到菜品管理页面编辑");
                    return true;
                }
                showMenuItemPopupMenu(view, data);
                return true;
            }
        }
    }


    class MenuClsAdapter extends BaseMwAdapter<MenuTypeBean> {
        int selectPosition;

        public MenuTypeBean getCurrentMenuCls() {
            return modules.get(selectPosition);
        }

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            MenuClsHolder holder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_class_item, parent, false);
                holder = new MenuClsHolder(convertView);
                convertView.setTag(holder);
            } else {
                holder = (MenuClsHolder) convertView.getTag();
            }
            holder.bindData(position);
            return convertView;
        }

        class MenuClsHolder {
            private View itemView;

            public MenuClsHolder(View itemView) {
                this.itemView = itemView;
            }

            public void bindData(int position) {
                boolean isSelected = position == selectPosition;
                TextView mAskGroupItemLabel = (TextView) itemView;
                mAskGroupItemLabel.setText(modules.get(position).fsMenuClsName);
                if (isSelected) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, R.drawable.bg_category_son_white_item_checked);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, 0);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.color_2d2d2d));
                }
            }
        }
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onResume() {
        super.onResume();
        menuAdapter.notifyDataSetChanged();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        DrivenBusManager.getInstance().unRegisterDriver(this);
    }
}
