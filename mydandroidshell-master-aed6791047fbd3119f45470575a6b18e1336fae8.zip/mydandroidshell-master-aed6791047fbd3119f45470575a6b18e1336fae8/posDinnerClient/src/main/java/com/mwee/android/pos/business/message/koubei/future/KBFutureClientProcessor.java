package com.mwee.android.pos.business.message.koubei.future;

import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBFutureUpdateReponse;
import com.mwee.android.air.db.business.kbbean.future.KBFuturePushOrderDetailRequest;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataRequest;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CKouBei;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.tools.DateUtil;

import java.text.ParseException;

/**
 * Created by zhangmin on 2018/10/16.
 */

public class KBFutureClientProcessor implements IKBFutureClientListener {

    private Host mHost;

    public KBFutureClientProcessor(Host mHost) {
        this.mHost = mHost;
    }

    @Override
    public void loadFutureOrder(String id, ResultCallback<KBFutureUpdateReponse> resultCallback) {
        KBFuturePushOrderDetailRequest request = new KBFuturePushOrderDetailRequest();
        request.id = id;
        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KBFutureUpdateReponse) {
                    KBFutureUpdateReponse response = (KBFutureUpdateReponse) responseData.responseBean;

                    //TODO 数据需要中转 因为后台推过来的菜 fiItemCD 和 fiOrderUintCd 在本地不一定存在 不可能在客户端校验 这时候需要自己特别处理 否则前台显示不准确
                   /* for (KBDishMenuItem dish_detail : response.data.dish_list) {
                        if (TextUtils.isEmpty(dish_detail.out_dish_id) || TextUtils.isEmpty(dish_detail.out_sku_id)) {
                            continue;
                        }
                        String sqlMenuItem = "select fsItemName from tbmenuitem where fiItemCd='" + dish_detail.out_dish_id + "' and fistatus = '1'";
                        String fsItemName = DBSimpleUtil.queryString(APPConfig.DB_CLIENT, sqlMenuItem);
                        if (TextUtils.isEmpty(fsItemName)) {//菜品

                            LogUtil.logError(String.format("获取订单详情 [%s]菜品与本地数据匹配不上 直接设置返回数据fiItemCd=null 防止界面显示错误  ", dish_detail.dish_name)+String.format("口碑订单号[%s] 口碑菜品fiItemCd[%s]", response.data.order_id, dish_detail.out_dish_id));
                            dish_detail.out_dish_id = null;
                            continue;
                        }
                        String sqlMenuItemUint = "SELECT fiOrderUintCd from tbmenuitemuint where fiOrderUintCd= '" + dish_detail.out_sku_id + "' and fistatus ='1'";
                        if (TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_CLIENT, sqlMenuItemUint))) {//规格
                            LogUtil.logError(String.format("获取订单详情 [%s]菜品的规格与本地数据匹配不上 直接设置返回数据fiOrderUintCd=null 防止界面显示错误  ", dish_detail.dish_name)+String.format(" 口碑订单号[%s] 口碑菜品规格fiOrderUintCd[%s]", response.data.order_id, dish_detail.out_sku_id));
                            dish_detail.out_sku_id = null;
                            continue;
                        }
                    }*/
                    resultCallback.onSuccess(response);
                } else {
                    resultCallback.onFailure(responseData.result, responseData.resultMessage);
                }
                progress.dismissSelf();

            }

            @Override
            public boolean fail(ResponseData responseData) {
                resultCallback.onFailure(responseData.result, responseData.resultMessage);
                progress.dismissSelf();
                return false;
            }
        });
    }

    @Override
    public void loadFutureTempOrderHeader(int pageIndex, String orderId,String status, ResultCallback<KBFutureTempDataResponse> resultCallback) {


        MCon.c(CKouBei.class, new SocketCallback<KBFutureTempDataResponse>() {
            @Override
            public void callback(SocketResponse<KBFutureTempDataResponse> response) {
                if (response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
            }
        }).loadFutureOrderList(pageIndex,orderId,status);

        /*KBFutureTempDataRequest request = new KBFutureTempDataRequest();
        request.pageIndex = pageIndex;
        request.orderId = orderId;
        request.pageSize = 20;
        //Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KBFutureTempDataResponse) {
                    KBFutureTempDataResponse response = (KBFutureTempDataResponse) responseData.responseBean;
                    resultCallback.onSuccess(response);
                } else {
                    resultCallback.onFailure(responseData.result, responseData.resultMessage);
                }
                //progress.dismissSelf();

            }

            @Override
            public boolean fail(ResponseData responseData) {
                resultCallback.onFailure(responseData.result, responseData.resultMessage);
                //progress.dismissSelf();
                return false;
            }
        });*/

    }

   /* @Override
    public void doFuturePrinter(String order_id, ResultCallback<BaseSocketResponse> resultCallback) {


    }*/

    @Override
    public void acceptFutureOrder(KBAfterPayOrder kbAfterPayOrder, ResultCallback<ScannerTableOrderAcceptResponse> resultCallback) {

        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<ScannerTableOrderAcceptResponse>() {
            @Override
            public void callback(SocketResponse<ScannerTableOrderAcceptResponse> response) {
                if (response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
                progress.dismissSelf();
            }
        }).acceptKbAfterPayOrder(kbAfterPayOrder);

    }

    @Override
    public void rejectFutureOrder(String orderId, String batchNo, String rejectReason, String id, ResultCallback<ScannerTableOrderAcceptResponse> resultCallback) {

        Progress progress = ProgressManager.showProgress(mHost.getActivityWithinHost());
        MCon.c(CKouBei.class, new SocketCallback<ScannerTableOrderAcceptResponse>() {
            @Override
            public void callback(SocketResponse<ScannerTableOrderAcceptResponse> response) {
                if (response.success()) {
                    resultCallback.onSuccess(response.data);
                } else {
                    resultCallback.onFailure(response.code, response.message);
                }
                progress.dismissSelf();
            }
        }).rejectFutureOrder(orderId, batchNo, rejectReason, id);
    }


    public String buildOrderStatusMsg(String status, String order_time, String receiptTimeOut) {

        String orderStatusMsg = "";
        switch (status) {
            case "WAIT_RECEIPT"://todo 推过来新订单
                if (caluteReceiptTimeout(order_time, receiptTimeOut)) {
                    orderStatusMsg = "超时已拒单";
                } else {
                    orderStatusMsg = "待接单";
                }
                break;
            case "RECEIPT"://todo 接单完成
                orderStatusMsg = "已接单";
                break;
            case "REJECT"://todo  拒单完成
                orderStatusMsg = "已拒单";
                break;
            default:
                break;
        }
        return orderStatusMsg;
    }


    /**
     * 口碑后付款模式不会超时不会推送拒单状态 需要本地根据超时时间进行计算
     * <p>
     *
     * @param order_time
     * @param receiptTimeOut
     */
    public boolean caluteReceiptTimeout(String order_time, String receiptTimeOut) {
        try {
            Long a = DateTimeUtil.getMillisBetween(order_time, DateUtil.getCurrentTime()) + 2 * 1000;
            Long b = DateTimeUtil.getMillisBetween(order_time, receiptTimeOut);
            return a - b > 0;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;

    }


}
