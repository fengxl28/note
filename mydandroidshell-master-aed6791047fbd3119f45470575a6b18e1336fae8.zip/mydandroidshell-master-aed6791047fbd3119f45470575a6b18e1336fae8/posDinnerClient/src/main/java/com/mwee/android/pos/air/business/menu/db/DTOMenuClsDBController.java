package com.mwee.android.pos.air.business.menu.db;

import android.text.TextUtils;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by qinwei on 2018/3/20.
 */

public class DTOMenuClsDBController {
    public static List<MenuTypeBean> queryMenuTypes() {
        String sqlMenuType = "select * from tbmenucls"
                + " where fsShopGUID='" + AppCache.getInstance().fsShopGUID + "'"
                + " and fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind <> '4' "
                + " order by fsMenuClsId_p asc, fiSortOrder asc,fiDtlLvl asc";
        return DBSimpleUtil.queryList(APPConfig.DB_CLIENT, sqlMenuType, MenuTypeBean.class);
    }

    public static List<MenuTypeBean> queryAllMenuTypesContainerAllType() {
        MenuTypeBean typeAll = new MenuTypeBean();
        typeAll.menuList = new ArrayList<>();
        typeAll.fsMenuClsName = "全部";
        typeAll.fsMenuClsId = "-1localAll";
        typeAll.typeIndex = true;
        List<MenuTypeBean> menuTypes = queryMenuTypes();
        if (menuTypes == null) {
            menuTypes = new ArrayList<>();
        }
        menuTypes.add(0, typeAll);
        return menuTypes;
    }

    /**
     * 构建所有分类数据
     *
     * @return
     */
    public static List<MenuTypeBean> queryMenuClsAndSort() {
        // 子分类的 fiSortOrder 小于 父分类的 fiSortOrder，可能出现的首次遍历无法找到关联父级分类的情况
        List<MenuTypeBean> sortResult = new ArrayList<>();
        LinkedList<MenuTypeBean> makeuplist = new LinkedList<>();
        HashMap<String, MenuTypeBean> fullDataMap = new HashMap<>();
        for (MenuTypeBean temp : queryMenuTypes()) {
            if (TextUtils.equals(temp.fsMenuClsId, temp.fsMenuClsId_P)) {
                continue;
            }
            fullDataMap.put(temp.fsMenuClsId, temp);
            if (StringUtil.emptyInt(temp.fsMenuClsId_P)) {
                sortResult.add(temp);
            } else {
                MenuTypeBean father = fullDataMap.get(temp.fsMenuClsId_P);
                if (father != null) {
                    if (father.sonTypeList == null) {
                        father.sonTypeList = new ArrayList<>();
                    }
                    father.sonTypeList.add(temp);
                } else {
                    // 暂未找到父级分类的菜品分类加入列表，稍后二次查找
                    makeuplist.addFirst(temp);
                }
            }
        }
        if (!ListUtil.isEmpty(makeuplist)) {
            while (makeuplist.size() != 0) {
                MenuTypeBean menuTypeBean = makeuplist.removeFirst();
                MenuTypeBean father = fullDataMap.get(menuTypeBean.fsMenuClsId_P);
                if (father == null) {
                    RunTimeLog.addLog(RunTimeLog.BOOT_BUILD_MENU_TYPE, "菜品分类[" + menuTypeBean.fsMenuClsName + "]异常，未找到父级分类");
                    continue;
                }
                if (father.sonTypeList == null) {
                    father.sonTypeList = new ArrayList<>();
                }
                father.sonTypeList.add(0, menuTypeBean);
            }
        }
        return sortResult;
    }
}
