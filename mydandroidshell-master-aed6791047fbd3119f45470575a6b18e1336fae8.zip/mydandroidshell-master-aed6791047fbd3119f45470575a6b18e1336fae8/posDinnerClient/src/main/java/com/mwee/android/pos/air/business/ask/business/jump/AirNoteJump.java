package com.mwee.android.pos.air.business.ask.business.jump;

import com.mwee.android.pos.air.business.ask.business.AirNoteFragment;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.orderdishes.view.callback.NoteCallback;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.tools.LogUtil;

/**
 * AirNoteJump
 * Created by liuxiuxiu on 17/11/17.
 */
public class AirNoteJump {

    /**
     * @param host
     * @param callBack
     */
    public static void showNote(Host host, MenuItem item, NoteCallback callBack) {
        if (item == null) {
            LogUtil.logError("AirNoteJump.showNote failed within no MenuItem");
            return;
        }
        AirNoteFragment fragment = new AirNoteFragment();
        fragment.setMenuItem(item);
        fragment.setNoteCallback(callBack);
        fragment.show(host.getFragmentManagerWithinHost(), fragment.TAG);
    }


}
