package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberCreate extends BaseMemberParam {
    public int m_shopid;
    public int shop_id;
    public String mobile = "";
    public String name = "";
    /**
     * 0 保密  1=>男  2=>女
     */
    public int gender = 0;
    /**
     * '1' => '微信', '2' => '排队', '3' => '预订', '4' => '支付',
     * '5' => '点菜', '6' => '导入', '7' => '秒付', '8' => '实体卡(16位)',
     * '9' => '支付宝',‘10’ => '美易点'，
     * '101'=>'美团外卖','102'=>'饿了么外卖','103'=>'百度外卖'
     */
    public int source = 10;
    /**
     * 密码(要求6位数字)+cardmwee
     */
    public String password;
    /**
     * 出生日期
     */
    public String birthday;
    /**
     * 1 粉丝会员2 普通会员3 黄金会员4 铂金会员5 钻石会员
     */
    public int default_level = 3;

    public MemberCreate() {
    }
}
