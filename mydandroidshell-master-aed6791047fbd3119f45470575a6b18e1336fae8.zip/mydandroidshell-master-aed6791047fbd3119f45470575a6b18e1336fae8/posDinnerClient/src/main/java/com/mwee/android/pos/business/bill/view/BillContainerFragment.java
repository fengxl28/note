package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.tab.TabLayout;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/7/20.
 */

public class BillContainerFragment extends BaseFragment implements TabLayout.OnTabClickListener {
    private TabLayout mTabLayout;
    public static final String TAG = "BillContainerFragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        int layout;
        if (AppCache.getInstance().isRetailMode()) {
            layout = R.layout.air_fragment_bill_container;
        } else {
            layout = R.layout.fragment_bill_container;
        }
        return inflater.inflate(layout, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mTabLayout = (TabLayout) view.findViewById(R.id.mTabLayout);
    }

    private void initData() {
        ArrayList<TabLayout.TabView.Tab> tabs = new ArrayList<>();
        tabs.add(new TabLayout.TabView.Tab(getString(R.string.setting_online_seconds_pay), false, BillOnlineFragment.class));
        tabs.add(new TabLayout.TabView.Tab(getString(R.string.setting_online_scanning), false, BillOnlineScannerFragment.class));
        tabs.add(new TabLayout.TabView.Tab(getString(R.string.setting_online_almighty_pos), false, BillOnlineFragment.class));
        tabs.add(new TabLayout.TabView.Tab(getString(R.string.setting_online_line_cash_register), false, BillOnlinePosFragment.class));
        tabs.add(new TabLayout.TabView.Tab("口碑", false, KBAfterPayOrderLstFragment.class));
        //mTabLayout.initData(tabs, this);
        mTabLayout.initData(tabs, this, AppCache.getInstance().isRetailMode());
        mTabLayout.setCurrentTab(0);
    }

    @Override
    public void onTabItemClick(int currentIndex, TabLayout.TabView.Tab tab) {
        Fragment fragment = null;
        switch (currentIndex) {
            case 0:
                //秒付订单 11,12,15,21,22
                fragment = BillOnlineFragment.getInstance("11,12,15,22");
                break;
            case 1:
                //扫码支付单
                fragment = new BillOnlineScannerFragment();
                break;
            case 2:
                //全能pos
                fragment = BillOnlineFragment.getInstance("21");
                break;
            case 3:
                //pos线下收银
                fragment = new BillOnlinePosFragment();
                break;
            case 4:
                fragment = new KBAfterPayOrderLstFragment();
                break;
            default:
                break;
        }
        if (fragment != null) {
            getFragmentManager().beginTransaction().replace(R.id.mBillContainer, fragment).commitAllowingStateLoss();
        }
    }
}
