package com.mwee.android.pos.air.business.setting.takeout;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.air.business.menu.db.DTOMenuClsDBController;
import com.mwee.android.pos.air.business.menu.db.DTOMenuItemDBController;
import com.mwee.android.pos.air.business.setting.api.TakeOutApi;
import com.mwee.android.pos.air.business.widget.EditorView;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.util.List;

/**
 * Created by qinwei on 2018/3/20.
 */
public class TakeOutMenuLocalChoiceDialogFragment extends BaseDialogFragment implements EditorView.OnTextChangedListener, View.OnClickListener {
    private EditorView mLocalMenuSearchEv;
    private PullRecyclerView mLocalMenuRecyclerView;
    private TextView mLocalMenuChoiceCancelLabel;
    private TextView mLocalMenuChoiceConfirmLabel;
    private MenuItemAdapter mLocalMenuAdapter;
    private OnLocalMenuItemChoiceListener listener;
    private TakeOutMenuItem takeOutMenuItem;
    private MenuItemBean choice;
    private String mTakeAway;
    private PullRecyclerView mLocalMenuClsPRV;
    private MenuClsAdapter mLocalMenuClsAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_fragment_take_out_menu_local_choice_dailog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    private void initView(View view) {
        mLocalMenuClsPRV = (PullRecyclerView) view.findViewById(R.id.mLocalMenuClsPRV);
        mLocalMenuRecyclerView = (PullRecyclerView) view.findViewById(R.id.mLocalMenuRecyclerView);
        mLocalMenuSearchEv = (EditorView) view.findViewById(R.id.mLocalMenuSearchEv);
        mLocalMenuChoiceCancelLabel = (TextView) view.findViewById(R.id.mLocalMenuChoiceCancelLabel);
        mLocalMenuChoiceConfirmLabel = (TextView) view.findViewById(R.id.mLocalMenuChoiceConfirmLabel);
        mLocalMenuSearchEv.setOnTextChangedListener(this);
        mLocalMenuChoiceCancelLabel.setOnClickListener(this);
        mLocalMenuChoiceConfirmLabel.setOnClickListener(this);
        mLocalMenuClsPRV.setLayoutManager(new LinearLayoutManager(getContext()));
        mLocalMenuClsPRV.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL_LIST));
        mLocalMenuRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL_LIST));
        mLocalMenuRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mLocalMenuClsPRV.setLayoutManager(new LinearLayoutManager(getContext()));

        mLocalMenuClsPRV.setEnablePullToStart(false);
        mLocalMenuRecyclerView.setEnablePullToStart(false);
        mLocalMenuAdapter = new MenuItemAdapter();
        mLocalMenuRecyclerView.setAdapter(mLocalMenuAdapter);
        mLocalMenuClsAdapter = new MenuClsAdapter();
        mLocalMenuClsPRV.setAdapter(mLocalMenuClsAdapter);
    }

    private void initData() {
        mLocalMenuClsAdapter.modules.addAll(DTOMenuClsDBController.queryAllMenuTypesContainerAllType());
        mLocalMenuClsAdapter.selectPosition = 0;
        mLocalMenuClsAdapter.notifyDataSetChanged();
        //查询所有分类id
        refreshMenuItemBeansByMenuCls("");
    }


    public void refreshMenuItemBeansByMenuCls(String fsMenuClsId) {
        mLocalMenuAdapter.modules.clear();
        mLocalMenuAdapter.modules.addAll(DTOMenuItemDBController.queryMenusByClsId(fsMenuClsId));
        mLocalMenuAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mLocalMenuChoiceCancelLabel:
                dismissSelf();
                break;
            case R.id.mLocalMenuChoiceConfirmLabel:
                if (choice == null) {
                    ToastUtil.showToast("请选择需要映射的菜品信息。");
                    return;
                }
                loadMapper();
                break;
            default:
                break;
        }
    }

    private void loadMapper() {
        takeOutMenuItem.itemId = choice.fiItemCd;
        takeOutMenuItem.itemName = choice.fsItemName;
        takeOutMenuItem.specName = choice.fsOrderUint;
        takeOutMenuItem.price = choice.fdSalePrice.toPlainString();
        takeOutMenuItem.specId = choice.fiOrderUintCd;
        Progress progress = ProgressManager.showProgressUncancel(this);
        TakeOutApi.loadMapper(mTakeAway, takeOutMenuItem, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();
                if (listener != null) {
                    listener.onTakeOutMenuMappedSuccess(choice);
                }
                dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }


    class MenuClsAdapter extends BaseListAdapter<MenuTypeBean> {
        int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuClsHolder(LayoutInflater.from(getContext()).inflate(R.layout.view_air_menu_class_item, parent, false));
        }

        class MenuClsHolder extends BaseViewHolder implements View.OnClickListener {
            private View itemView;
            private int position;

            public MenuClsHolder(View itemView) {
                super(itemView);
                this.itemView = itemView;
                itemView.setOnClickListener(this);
            }

            public void bindData(int position) {
                this.position = position;
                boolean isSelected = position == selectPosition;
                TextView mAskGroupItemLabel = (TextView) itemView;
                mAskGroupItemLabel.setText(modules.get(position).fsMenuClsName);
                if (isSelected) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, R.drawable.bg_category_son_white_item_checked);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(mAskGroupItemLabel, 0);
                    mAskGroupItemLabel.setTextColor(getResources().getColor(R.color.color_2d2d2d));
                }
            }

            @Override
            public void onClick(View v) {
                if (selectPosition != position) {
                    selectPosition = position;
                    mLocalMenuClsAdapter.notifyDataSetChanged();
                    refreshMenuItemBeansByMenuCls(modules.get(position).fsMenuClsId);
                }
            }
        }
    }

    class MenuItemAdapter extends BaseListAdapter<MenuItemBean> {
        public int selectPosition = -1;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.air_view_take_out_menu_choice_item, parent, false));
        }

        class Holder extends BaseViewHolder implements View.OnClickListener {
            private TextView mLocalMenuItemIdLabel;
            private TextView mLocalMenuItemNameLabel;
            private TextView mLocalMenuItemUnitLabel;
            private TextView mLocalMenuItemPriceLabel;
            private MenuItemBean module;
            private int position;

            public Holder(View v) {
                super(v);
                mLocalMenuItemIdLabel = (TextView) v.findViewById(R.id.mLocalMenuItemIdLabel);
                mLocalMenuItemNameLabel = (TextView) v.findViewById(R.id.mLocalMenuItemNameLabel);
                mLocalMenuItemUnitLabel = (TextView) v.findViewById(R.id.mLocalMenuItemUnitLabel);
                mLocalMenuItemPriceLabel = (TextView) v.findViewById(R.id.mLocalMenuItemPriceLabel);
                v.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                this.position = position;
                module = mLocalMenuAdapter.modules.get(position);
                mLocalMenuItemIdLabel.setText(module.fiItemCd);
                mLocalMenuItemNameLabel.setText(module.fsItemName);
                mLocalMenuItemUnitLabel.setText(module.fsOrderUint);
                mLocalMenuItemPriceLabel.setText(module.fdSalePrice.toPlainString());
                if (selectPosition == position) {
                    itemView.setBackgroundColor(GlobalCache.getContext().getResources().getColor(R.color.pink));
                    setTextColorOfViewGroup((ViewGroup) itemView, GlobalCache.getContext().getResources().getColor(R.color.system_red));
                } else {
                    itemView.setBackgroundColor(0);
                    setTextColorOfViewGroup((ViewGroup) itemView, GlobalCache.getContext().getResources().getColor(R.color.color_363636));
                }
            }

            private void setTextColorOfViewGroup(ViewGroup viewGroup, int color) {
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    View view = viewGroup.getChildAt(i);
                    if (view instanceof TextView) {
                        ((TextView) view).setTextColor(color);
                    }
                }
            }

            @Override
            public void onClick(View v) {
                if (selectPosition != position) {
                    selectPosition = position;
                    choice = mLocalMenuAdapter.modules.get(position);
                    mLocalMenuAdapter.notifyDataSetChanged();
                }
            }
        }
    }

    @Override
    public void onTextChanged(CharSequence c) {
        handler.removeMessages(0);
        handler.sendEmptyMessageDelayed(0, 500);
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mLocalMenuAdapter.selectPosition = -1;
            choice = null;
            mLocalMenuAdapter.modules.clear();
            List<MenuItemBean> result = DTOMenuItemDBController.search(mLocalMenuSearchEv.getText().toString().trim());
            if (!ListUtil.isEmpty(result)) {
                mLocalMenuAdapter.modules.addAll(result);
            }
            mLocalMenuAdapter.notifyDataSetChanged();
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeMessages(0);
    }

    public void setParam(TakeOutMenuItem takeOutMenuItem, String mTakeAway, OnLocalMenuItemChoiceListener listener) {
        this.listener = listener;
        this.takeOutMenuItem = takeOutMenuItem;
        this.mTakeAway = mTakeAway;
    }

    public interface OnLocalMenuItemChoiceListener {
        void onTakeOutMenuMappedSuccess(MenuItemBean menuItemBean);
    }
}
