package com.mwee.android.pos.air.business.payment.entity;

import com.mwee.android.cashier.connect.bean.http.BaseCashierPosResponse;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/2/6.
 */

public class PayOpenStatusResponse extends BaseCashierPosResponse {
    public ArrayList<PayOpenStatus> data = new ArrayList<>();

    public PayOpenStatusResponse() {
    }
}
