package com.mwee.android.pos.business.member.api;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.print.PrinterMemberResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CNewMember;
import com.mwee.android.pos.util.SettingHelper;

import java.math.BigDecimal;

/**
 * MemberApi
 * Created by chris on 16/8/10.
 */
public class ClientMemberApi {

    public static void loadMemberInfo(String account, String verifyCode, int verifyCodeType, boolean needBindToOrder, String orderId, SocketCallback<NewQueryMemberListResponse> callback){
        MCon.c(CNewMember.class, callback).loadMemberInfo(account, verifyCode, verifyCodeType, needBindToOrder, orderId);
    }

    public static void queryMemberScore(String cardNoOrMobile,int pageNo,SocketCallback<MemberScoreDetailModel> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryMemberScore(mShopID,cardNoOrMobile,pageNo);
    }

    public static void queryTradeDetail(String cardNoOrMobile,int pageNo,SocketCallback<MemberTradeDetailModel> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryTradeDetail(mShopID,cardNoOrMobile,pageNo);
    }

    public static void queryMemberCoupons(String cardNo,int pageNo,SocketCallback<MemberCouponsDetailModel> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryMemberCoupons(mShopID,cardNo,pageNo);
    }

    public static void bindMemberCardToOrder(NewMemberCardListItemModel memberCard, String orderId, SocketCallback<NewQueryMemberInfoAndBindToOrderResponse> callback) {
        MCon.c(CNewMember.class, callback).bindMemberCardToOrder(memberCard, orderId);
    }

    public static void sendVerifyCode(String mobile, int type, SocketCallback<Boolean> callback) {
        String companyGUID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).sendVerifyCode(companyGUID, mobile, type);
    }
    public static void changeMemberPsw(String cardNo,String password,SocketCallback<Boolean> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).changeMemberPsw(mShopID,cardNo,password);
    }

    public static void queryMemberPrivate(String csId,int memberLevel,String cardNo,SocketCallback<MemberPrivateDetailModel> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryMemberPrivate(mShopID,csId,memberLevel,cardNo);
    }

    public static void printPrivilege(String cardNo,MemberPrivateDetailModel.CardPrivilege data,SocketCallback<PrinterMemberResponse> callback) {
        MCon.c(CNewMember.class, callback).printPrivilege(cardNo,data);
    }

    public static void queryRechargePackage(String cardNo,int memberLevel,SocketCallback<MemberRechargePackageModel> callback) {
        String mShopID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryRechargePackage(mShopID,cardNo,memberLevel);
    }

    public static void memberRecharge(String cardNo, String payMicro, String ruleId, BigDecimal buyAmount,int payType, SocketCallback<MemberRechargeResultModel> callback) {
        String fsCompanyGUID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).memberRecharge(fsCompanyGUID,cardNo,payMicro,ruleId,buyAmount,payType);
    }

    public static void queryPayResult(String tradeNo, SocketCallback<MemberRechargeResultModel> callback) {
        String fsCompanyGUID = AppCache.getInstance().shop.fsCompanyGUID;
        MCon.c(CNewMember.class, callback).queryPayResult(fsCompanyGUID,tradeNo);
    }

    public static void printerChargeInfo(String payType, String memberName, MemberRechargeResultModel chargeInfo,SocketCallback<PrinterMemberResponse> callback) {
        MCon.c(CNewMember.class, callback).printerChargeInfo(payType,memberName,chargeInfo);
    }
}
