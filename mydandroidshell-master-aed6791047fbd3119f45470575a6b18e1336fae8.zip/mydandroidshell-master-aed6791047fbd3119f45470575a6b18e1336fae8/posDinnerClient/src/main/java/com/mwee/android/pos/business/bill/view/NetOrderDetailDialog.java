package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Configure;

/**
 * Created by liuxiuxiu on 2017/3/24.
 */

public class NetOrderDetailDialog extends BaseDialogFragment implements View.OnClickListener {

    public final static String TAG = NetOrderDetailDialog.class.getSimpleName();

    private TextView tv_dialog_title;
    private LinearLayout ll_dialog_bottom;
    private LinearLayout customLayout;
    private Button leftBtn;
    private View btnSplitLine;
    private Button rightBtn;

    private String title;
    private String leftBtnTxt;
    private String rightBtnTxt;
    private View customView;

    private OnClickDialogListener mOnClickDialogListener;

    public void setOnClickDialogListener(OnClickDialogListener onClickDialoglistener) {
        this.mOnClickDialogListener = onClickDialoglistener;
    }

    public void setParams(String title,String leftBtnTxt, String rightBtnTxt, View customView) {
        this.title = title;
        this.leftBtnTxt = leftBtnTxt;
        this.rightBtnTxt = rightBtnTxt;
        this.customView = customView;
    }

    public void setParams(String title,String rightBtnTxt, View customView) {
        this.title = title;
        this.rightBtnTxt = rightBtnTxt;
        this.customView = customView;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_netorder_detail_dialog, container, false);
        tv_dialog_title = (TextView) view.findViewById(R.id.tv_dialog_title);
        customLayout = (LinearLayout) view.findViewById(R.id.customLayout);
        ll_dialog_bottom = (LinearLayout) view.findViewById(R.id.ll_dialog_bottom);
        leftBtn = (Button) view.findViewById(R.id.leftBtn);
        btnSplitLine = view.findViewById(R.id.btnSplitLine);
        rightBtn = (Button) view.findViewById(R.id.rightBtn);
        leftBtn.setOnClickListener(this);
        rightBtn.setOnClickListener(this);
        Configure.init(getActivityWithinHost());
        int max = BizConstant.screenHeight > BizConstant.screenWidth ? BizConstant.screenWidth : BizConstant.screenHeight;
        if (max > 0){
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) view.findViewById(R.id.root_view).getLayoutParams();
            lp.width = (max/3)*2;
            view.findViewById(R.id.root_view).setLayoutParams(lp);
        }


        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        refresh();
    }

    private void refresh() {
        if (!TextUtils.isEmpty(title)) {
            tv_dialog_title.setVisibility(View.VISIBLE);
            tv_dialog_title.setText(title);
        } else {
            tv_dialog_title.setVisibility(View.GONE);
        }
        if (customView != null) {
            customLayout.setVisibility(View.VISIBLE);
            customLayout.addView(customView);
        } else {
            customLayout.setVisibility(View.GONE);
        }
        if (TextUtils.isEmpty(leftBtnTxt) && TextUtils.isEmpty(rightBtnTxt)) {
            ll_dialog_bottom.setVisibility(View.GONE);
        } else {
            ll_dialog_bottom.setVisibility(View.VISIBLE);
        }
        if (!TextUtils.isEmpty(leftBtnTxt)) {
            leftBtn.setVisibility(View.VISIBLE);
            leftBtn.setText(leftBtnTxt);
            btnSplitLine.setVisibility(View.VISIBLE);
        } else {
            leftBtn.setVisibility(View.GONE);
            btnSplitLine.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(rightBtnTxt)) {
            rightBtn.setVisibility(View.VISIBLE);
            rightBtn.setText(rightBtnTxt);
        } else {
            rightBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.leftBtn:
                if (mOnClickDialogListener != null) {
                    mOnClickDialogListener.onClickLeftBtn(NetOrderDetailDialog.this);
                }
                break;
            case R.id.rightBtn:
                if (mOnClickDialogListener != null) {
                    mOnClickDialogListener.onClickRightBtn(NetOrderDetailDialog.this);
                }
                break;
        }
    }

    public interface OnClickDialogListener {
        void onClickLeftBtn(NetOrderDetailDialog dialog);
        void onClickRightBtn(NetOrderDetailDialog dialog);
    }

    public static NetOrderDetailDialog getDialog(OnClickDialogListener onClickDialogListener, String title, String leftBtnTxt, String rightBtnTxt, View customView) {
        NetOrderDetailDialog orderDishesCommonDialog = new NetOrderDetailDialog();
        orderDishesCommonDialog.setOnClickDialogListener(onClickDialogListener);
        orderDishesCommonDialog.setParams(title, leftBtnTxt, rightBtnTxt, customView);
        return orderDishesCommonDialog;
    }
}
