package com.mwee.android.pos.air.business.utils;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;

import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;

/**
 * @ClassName: NumDecimalFilter
 * @Description:
 * @author: SugarT
 * @date: 2017/11/15 下午1:53
 */
public class NumDecimalFilter implements InputFilter {

    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        if (TextUtils.isEmpty(source)) {
            return null;
        }
        String dValue = dest.toString();

        BigDecimal num = BigDecimal.ZERO;
        try {
            num = new BigDecimal(dValue + source);
            if (num.compareTo(BizConstant.HUNDREND) > 0) {
                return "";
            }
        } catch (Exception ex) {
            LogUtil.log(ex.getMessage());
        }

        String[] splitArray = dValue.split("\\.");
        if (splitArray.length > 1) {
            String dotValue = splitArray[1];
            if (dotValue.length() >= 1) {
                return "";
            }
        }
        return null;
    }
}
