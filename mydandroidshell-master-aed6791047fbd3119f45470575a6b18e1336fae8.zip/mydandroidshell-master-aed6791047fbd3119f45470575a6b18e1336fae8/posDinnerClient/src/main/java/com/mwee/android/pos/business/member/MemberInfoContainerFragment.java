package com.mwee.android.pos.business.member;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.air.business.member.dialog.MemberEditorDialogFragment;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.business.home.MAIN_TAB;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.business.member.entity.MemberManagerType;
import com.mwee.android.pos.business.member.view.MemberCardListChooseFragment;
import com.mwee.android.pos.business.member.view.MemberCardListFragment;
import com.mwee.android.pos.business.member.view.MemberPrivateFragment;
import com.mwee.android.pos.business.member.view.MemberScoreFragment;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * 会员详情展示容器 包含会员基本信息和会员操作
 * Created by qinwei on 2017/2/20.
 */

public class MemberInfoContainerFragment extends BaseFragment implements IDriver,MemberCardListFragment.Callback {
    public static final String TAG = MemberInfoContainerFragment.class.getSimpleName();
    public static final String KEY_MEMBER_INFO = "key_member_info";
    public static final String KEY_TAB_INDEX = "key_tab_index";
//    private MemberCardModel memberCardModel;
    private TextView mMemberInfoNameLabel;
    private TextView mMemberInfoSexLabel;
    private TextView mMemberInfoBirthdayLabel;
    private TextView mMemberInfoPhoneLabel;
    private TextView mMemberInfoLevelNameLabel;
    private TextView mMemberInfoCardNumberNameLabel;
    private PullRecyclerView mMemberManagerTypePullRecyclerView;
    private MemberManagerTypeAdapter adapter;
    private View mMemberManagerUpdateInfoBtn;
    private MemberProcess mMemberProcess;

    private NewMemberCardDetailsModel mCurrentCardDetail;

    private Button mChangeMemberCard;
    private String mPhoneNum;
    private View mDefaultCardView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_info_container, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    private void initView(View view) {
        mMemberManagerUpdateInfoBtn = view.findViewById(R.id.mMemberManagerUpdateInfoBtn);
        mMemberManagerTypePullRecyclerView = (PullRecyclerView) view.findViewById(R.id.mMemberManagerTypePullRecyclerView);
        mMemberInfoNameLabel = (TextView) view.findViewById(R.id.mMemberInfoNameLabel);
        mMemberInfoSexLabel = (TextView) view.findViewById(R.id.mMemberInfoSexLabel);
        mMemberInfoBirthdayLabel = (TextView) view.findViewById(R.id.mMemberInfoBirthdayLabel);
        mMemberInfoPhoneLabel = (TextView) view.findViewById(R.id.mMemberInfoPhoneLabel);
        mMemberInfoLevelNameLabel = (TextView) view.findViewById(R.id.mMemberInfoLevelNameLabel);
        mMemberInfoCardNumberNameLabel = (TextView) view.findViewById(R.id.mMemberInfoCardNumberNameLabel);
        mMemberManagerTypePullRecyclerView.setLayoutManager(new LinearLayoutManager(getActivityWithinHost()));
        mMemberManagerTypePullRecyclerView.setEnablePullToStart(false);
        mDefaultCardView = view.findViewById(R.id.mIsDefaultCard);

        mChangeMemberCard = view.findViewById(R.id.mChangeMemberCard);
        View changeMemberRl = view.findViewById(R.id.rl_ChangeMemberCard);
        if(mCurrentCardDetail == null){
            mChangeMemberCard.setVisibility(View.VISIBLE);
            changeMemberRl.setVisibility(View.VISIBLE);
            showCardListView();
            mChangeMemberCard.setOnClickListener(v -> {
                if(ButtonClickTimer.canClick()){
                    showCardListView();
                }
            });
        }else{
            mChangeMemberCard.setVisibility(View.GONE);
            changeMemberRl.setVisibility(View.INVISIBLE);
        }
    }

    private void initData() {
        mMemberProcess = new MemberProcess();
//        memberCardModel = (MemberCardModel) getArguments().getSerializable(KEY_MEMBER_INFO);
        int tabIndex = 0;
        if(getArguments() != null){
            tabIndex = getArguments().getInt(KEY_TAB_INDEX, 0);
        }
        adapter = new MemberManagerTypeAdapter();
        mMemberManagerTypePullRecyclerView.setAdapter(adapter);
        mMemberManagerTypePullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_member_container_empty, null));
        if(mCurrentCardDetail != null){
            setMemberInfo();
            showTab(adapter.modules.get(tabIndex));
        }else{
            mMemberManagerTypePullRecyclerView.showEmptyView();
        }
        if (AppCache.getInstance().isRetailMode()) {
            mMemberManagerUpdateInfoBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMemberEditorDialog();
                }
            });
        } else {
            mMemberManagerUpdateInfoBtn.setVisibility(View.GONE);
        }
    }

    public void setMemberInfo() {

        if(mCurrentCardDetail == null){
            return;
        }

        //会员卡用户信息
        mMemberInfoNameLabel.setText(mCurrentCardDetail.cardInfo.real_name);
        mMemberInfoSexLabel.setText(mCurrentCardDetail.cardInfo.optGender());
        mMemberInfoBirthdayLabel.setText(mCurrentCardDetail.cardInfo.birthday);
        mMemberInfoPhoneLabel.setText(mCurrentCardDetail.cardInfo.mobile);
        String memberName = mCurrentCardDetail.cardInfo.bind_type == 0 ? mCurrentCardDetail.cardInfo.level_name : mCurrentCardDetail.csName;
        mMemberInfoLevelNameLabel.setText(memberName);
        mMemberInfoCardNumberNameLabel.setText(mCurrentCardDetail.cardInfo.card_no);
        mDefaultCardView.setVisibility(mCurrentCardDetail.cardInfo.is_defaultcard== 1 ? View.VISIBLE : View.INVISIBLE);
        switch (mCurrentCardDetail.cardInfo.level) {//1.粉丝 2.普通 3.黄金 4.铂金 5.钻石
            case 1:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_1, 0, 0, 0);
                break;
            case 2:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_normal, 0, 0, 0);
                break;
            case 3:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_gold, 0, 0, 0);
                break;
            case 4:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_4, 0, 0, 0);
                break;
            case 5:
                mMemberInfoLevelNameLabel.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_member_level_diamonds, 0, 0, 0);
                break;
            default:
                break;
        }
        String score = mCurrentCardDetail.cardData.score + "";
        String balance = "" + mCurrentCardDetail.cardData.amount;
        String couponTotal = mCurrentCardDetail.cardData.coupon_total + getString(R.string.zhang);
//        String privateNumber = (/*memberCardModel.member_private.size()*/ + 2) + getString(R.string.ge);
        adapter.modules.clear();
        mMemberManagerTypePullRecyclerView.showContent();
        if (mCurrentCardDetail.cardConfig.is_score == 1) {
            adapter.modules.add(new MemberManagerType(R.drawable.ic_member_score, getString(R.string.member_score_balance_label), score, MemberScoreFragment.getInstance(mCurrentCardDetail.cardInfo.card_no)));
        }
        if (mCurrentCardDetail.cardConfig.is_pay == 1) {
            adapter.modules.add(new MemberManagerType(R.drawable.ic_member_balance, getString(R.string.member_money_balance_label), balance, BalanceChangesListFragment.getInstance(mCurrentCardDetail)));
        }
        adapter.modules.add(new MemberManagerType(R.drawable.ic_member_coupon, getString(R.string.member_coupon_label), couponTotal, CouponListFragment.getInstance(mCurrentCardDetail.cardInfo.card_no)));
        adapter.modules.add(new MemberManagerType(R.drawable.ic_member_private, getString(R.string.member_vip), "", MemberPrivateFragment.getInstance(mCurrentCardDetail)));
        adapter.notifyDataSetChanged();
    }

    private void showMemberEditorDialog() {
        MemberEditorDialogFragment dialog = new MemberEditorDialogFragment();
        //--会员重构修改--此方法是小易调用的，美易点暂时不用，先注释设置参数
//        dialog.setParam(memberCardModel);
        dialog.setOnMemberEditorListener(new MemberEditorDialogFragment.OnMemberEditorListener() {
            @Override
            public void onMemberEditorSuccess() {
                doRefresh(mCurrentCardDetail.cardInfo.card_no);
            }
        });
        DialogManager.showCustomDialog(this, dialog, "MemberEditorDialogFragment");
    }

    private void showCardListView(){
        Fragment tempFragment = optChildFragmentManager().findFragmentByTag(MemberCardListFragment.TAG);
        if (tempFragment != null && tempFragment.isVisible()) {
            return;
        }
        closeSubFragment();

        MemberCardListFragment fragment = new MemberCardListFragment();
        fragment.setParams(mPhoneNum,mCurrentCardDetail == null ? "" : mCurrentCardDetail.cardInfo.card_no,this);
        FragmentController.addFragmentWithHide(optChildFragmentManager(), fragment, MemberCardListFragment.TAG, R.id.mMemberInfoOperationDetailContainer, false);
    }

    @Override
    public void onCardSelected(String cardNo) {
        refreshMemberInfo(cardNo);
    }

    class MemberManagerTypeAdapter extends BaseListAdapter<MemberManagerType> {
        public int selectPosition = -1;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MemberManagerTypeHolder(LayoutInflater.from(getActivity()).inflate(R.layout.item_member_manager_type, parent, false));
        }
    }

    class MemberManagerTypeHolder extends BaseViewHolder implements View.OnClickListener {
        private View rootView;
        private ImageView mMemberManagerItemIconImg;
        private TextView mMemberManagerItemNameLabel;
        private TextView mMemberManagerItemValueLabel;
        private MemberManagerType type;

        public MemberManagerTypeHolder(View v) {
            super(v);
            this.rootView = v;
            mMemberManagerItemIconImg = (ImageView) v.findViewById(R.id.mMemberManagerItemIconImg);
            mMemberManagerItemNameLabel = (TextView) v.findViewById(R.id.mMemberManagerItemNameLabel);
            mMemberManagerItemValueLabel = (TextView) v.findViewById(R.id.mMemberManagerItemValueLabel);
            v.setOnClickListener(this);
        }

        @Override
        public void bindData(int position) {
            type = adapter.modules.get(position);
            mMemberManagerItemIconImg.setImageResource(type.iconResId);
            mMemberManagerItemNameLabel.setText(type.label);
            mMemberManagerItemValueLabel.setText(type.value);
            if (position == adapter.selectPosition) {
                rootView.setSelected(true);
            } else {
                rootView.setSelected(false);
            }
        }

        @Override
        public void onClick(View v) {
            showTab(type);
            LogUtil.log("用户点击" + type.label);

        }
    }

    private void showTab(MemberManagerType type) {

        if(mCurrentCardDetail == null){
            return;
        }

        closeSubFragment();
        FragmentTransaction transaction = optChildFragmentManager().beginTransaction();
        BaseFragment fragment = (BaseFragment) optChildFragmentManager().findFragmentByTag(type.label);
        if (fragment == null) {
            fragment = type.fragment;
        }
        if (!fragment.isAdded()) {
            transaction.add(R.id.mMemberInfoOperationDetailContainer, fragment, type.label);
        }
        int index = adapter.modules.indexOf(type);
        if (adapter.selectPosition != -1 && index != adapter.selectPosition) {
            Fragment hide = optChildFragmentManager().findFragmentByTag(adapter.modules.get(adapter.selectPosition).label);
            if (hide != null) {
                transaction.hide(hide);
            }
        }
        transaction.show(fragment);
        transaction.commitAllowingStateLoss();
        adapter.selectPosition = adapter.modules.indexOf(type);
        adapter.notifyDataSetChanged();
    }

    private void closeSubFragment() {
        Fragment fragment = optChildFragmentManager().findFragmentByTag(BalanceRechargeFragment.TAG);
        if (fragment != null && fragment.isAdded()) {
            optChildFragmentManager().beginTransaction().remove(fragment).commit();
        }
        fragment = optChildFragmentManager().findFragmentByTag(MemberCardListFragment.TAG);
        if (fragment != null && fragment.isAdded()) {
            optChildFragmentManager().beginTransaction().remove(fragment).commit();
        }
    }

    public static MemberInfoContainerFragment getInstance(MemberCardModel memberCardModel, int index) {
        MemberInfoContainerFragment fragment = new MemberInfoContainerFragment();
        Bundle args = new Bundle();
        args.putSerializable(KEY_MEMBER_INFO, memberCardModel);
        args.putInt(KEY_TAB_INDEX, index);
        fragment.setArguments(args);
        return fragment;
    }

    public static MemberInfoContainerFragment getInstance(MemberCardModel memberCardModel) {
        return getInstance(memberCardModel, 0);
    }

    public static MemberInfoContainerFragment getInstance() {
        return new MemberInfoContainerFragment();
    }

    public void setMemberCardDetails(NewMemberCardDetailsModel cardDetails) {
        mCurrentCardDetail = cardDetails;
    }

    public void setPhoneNum(String phoneNum){
        mPhoneNum = phoneNum;
    }

    @Override
    public String getModuleName() {
        return "member";
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @DrivenMethod(uri = "member/rechargeSuccess", UIThread = true)
    public void rechargeSuccess() {
        if(mCurrentCardDetail == null){
            return;
        }
        doRefresh(mCurrentCardDetail.cardInfo.card_no);
    }

    @DrivenMethod(uri = "member/refreshMemberInfo", UIThread = true)
    public void refreshMemberInfo(String cardNo) {
        if(android.text.TextUtils.isEmpty(cardNo)){
            return;
        }
        doRefresh(cardNo);
    }

    private void doRefresh(String cardNo) {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.member_query_ing);
        /*mMemberProcess.onlyLoadMemberInfo(memberCardModel.card_info.card_no, new IResponse<QueryMemberInfoResponse>() {
            @Override
            public void callBack(boolean result, int code, String msg, QueryMemberInfoResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    memberCardModel = data.memberCardModel;
                    if (getActivityWithinHost() != null && isFragmentAlive()) {
                        setMemberInfo();
                    }
                } else {
                    ToastUtil.showToast(msg);
                }
            }
        });*/

        mMemberProcess.optMemberInfoWithoutVerify(cardNo, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if(data == null || data.cardDetails == null || getActivityWithinHost() == null || !isFragmentAlive()){
                    return;
                }
                List<Fragment> fragments = optChildFragmentManager().getFragments();
                if(!ListUtil.isEmpty(fragments)){
                    for (Fragment fragment : fragments) {
                        optChildFragmentManager().beginTransaction().hide(fragment).commit();
                        if (fragment instanceof BaseFragment) {
                            ((BaseFragment)fragment).dismissSelf();
                        } else if (fragment instanceof DialogFragment) {
                            ((DialogFragment)fragment).dismiss();
                        }
                        optChildFragmentManager().beginTransaction().remove(fragment).commit();
                    }
                }
                optChildFragmentManager().popBackStack();
                mCurrentCardDetail = data.cardDetails;
                setMemberInfo();
                showTab(adapter.modules.get(0));
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());
                ToastUtil.showToast(msg);
            }
        });
    }

    private FragmentManager optChildFragmentManager(){
        return MemberInfoContainerFragment.this.getChildFragmentManager();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onKeyBack() {
        DriverBus.call("main/jump", MAIN_TAB.MEMBER);
        return true;
    }
}
