package com.mwee.android.pos.air.business.tprinter;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.recycler.CommonRecycleAdapter;
import com.mwee.android.pos.component.recycler.ViewHolder;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/10/17.
 */

public class TPrinterSearchView extends LinearLayout implements View.OnClickListener {
    private TextView tvBulletSet;
    private RecyclerView recyclerViewPrinter;
    private TResult<PrinterItem> listener;
    private CommonRecycleAdapter<PrinterItem> searchAdapter;
    public List<PrinterItem> modules = new ArrayList<>();

    public TPrinterSearchView(Context context) {
        super(context);
        init(context);
    }

    public TPrinterSearchView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public TPrinterSearchView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }


    private void init(Context mContext) {
        View.inflate(mContext, R.layout.t_printer_search_fragment, this);
        tvBulletSet = (TextView) findViewById(R.id.tvBulletSet);
        recyclerViewPrinter = (RecyclerView) findViewById(R.id.recyclerViewPrinter);
        tvBulletSet.setOnClickListener(this);
         /*搜索的adapter*/
        searchAdapter = new CommonRecycleAdapter<PrinterItem>(getContext(), R.layout.t_printer_search_item) {
            OnClickListener innerClick = new OnClickListener() {
                @Override
                public void onClick(View v) {
                    PrinterItem model = (PrinterItem) v.getTag();
                    listener.callBack(model);
                }
            };

            @Override
            public boolean onItemClick(View view, PrinterItem data, int position) {
                return false;
            }

            @Override
            public void onBind(ViewHolder holder, PrinterItem model, int position) {
                holder.setText(R.id.tvPrinterNameItem, model.name);
                holder.getView(R.id.tvPrinterAddItem).setTag(model);
                holder.getView(R.id.tvPrinterAddItem).setOnClickListener(innerClick);
                holder.setText(R.id.tvPrinterAddItem, "添加");
                holder.getView(R.id.tvPrinterAddItem).setEnabled(true);
            }
        };
        recyclerViewPrinter.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewPrinter.setAdapter(searchAdapter);
    }

    /**
     * 添加数据
     *
     * @param model
     */
    public void addPrinterModel(PrinterItem model) {
        modules.add(model);
        searchAdapter.setData(modules);
    }

    public void addAllPrinterModel(ArrayList<PrinterItem> data) {
        if (!ListUtil.isEmpty(data)) {
            modules.addAll(data);
            searchAdapter.setData(modules);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvBulletSet:
                Intent requestBluetoothOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                requestBluetoothOn.setAction(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                getContext().startActivity(requestBluetoothOn);
                break;
            default:
                break;
        }
    }

    public void setCallBack(TResult<PrinterItem> listener) {
        this.listener = listener;
    }
}
