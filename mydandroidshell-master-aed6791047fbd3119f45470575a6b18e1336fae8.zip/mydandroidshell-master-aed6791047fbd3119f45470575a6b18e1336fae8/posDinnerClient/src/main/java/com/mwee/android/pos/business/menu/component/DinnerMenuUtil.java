package com.mwee.android.pos.business.menu.component;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseArray;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.client.db.ClientMenuDBUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.DishesUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuExtra;
import com.mwee.android.pos.db.business.menu.bean.MenuExtraItem;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuPackageGroup;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * DinnerMenuUtil
 * Created by virgil on 16/6/15.
 */
public class DinnerMenuUtil {

    /**
     * 查菜品的所有要求
     *
     * @param menuItem 菜品
     * @return List<NoteModel>
     */
    public static List<NoteModel> getRequestByMenuItem(final MenuItem menuItem) {
        List<NoteModel> result = DBManager.getInstance(APPConfig.DB_CLIENT).executeQuery(new IDBOperate<List<NoteModel>>() {
            @Override
            public List<NoteModel> doJob(SQLiteDatabase sqLiteDatabase) {
                Cursor cursor = null;
                List<NoteModel> noteModelList = new ArrayList<>();
                try {
                    String sql = " select askgp.fsAskGpId,askgp.fsAskGpName,ask.fiId,ask.fsAskName,ask.fdAddPrice, askgp.fiIsShow " +
                            "from tbmenuitemaskgp as menuitemaskgp inner join tbaskgp as askgp on menuitemaskgp.fsAskGpId=askgp.fsAskGpId " +
                            "inner join tbask as ask on askgp.fsAskGpId=ask.fsAskGpId " +
                            "where  menuitemaskgp.fsShopGUID='" + AppCache.getInstance().fsShopGUID + "' and menuitemaskgp.fiStatus='1' and askgp.fiStatus='1' and ask.fiStatus='1' " +
                            "and askgp.fsAskGpId!='-1' and menuitemaskgp.fiItemCd='" + menuItem.itemID + "' GROUP by ask.fiId order by askgp.fisortOrder asc,askgp.fsAskGpName asc,askgp.fsupdateTime asc,ask.fsUpdateTime";
                    cursor = sqLiteDatabase.rawQuery(sql, null);
                    if (cursor != null) {
                        int fsAskGpIdIndex = cursor.getColumnIndex("fsAskGpId");
                        int fsAskGpNameIndex = cursor.getColumnIndex("fsAskGpName");
                        int fiIdIndex = cursor.getColumnIndex("fiId");
                        int fsAskNameIndex = cursor.getColumnIndex("fsAskName");
                        int fdAddPriceIndex = cursor.getColumnIndex("fdAddPrice");
                        int fiIsShowIndex = cursor.getColumnIndex("fiIsShow");
                        while (cursor.moveToNext()) {
                            String fsAskGpId = cursor.getString(fsAskGpIdIndex);
                            String fsAskGpName = cursor.getString(fsAskGpNameIndex);
                            String fiId = cursor.getString(fiIdIndex);
                            String fsAskName = cursor.getString(fsAskNameIndex);
                            String fdAddPrice = cursor.getString(fdAddPriceIndex);
                            int fiIsShow = cursor.getInt(fiIsShowIndex);
                            NoteItemModel noteItemModel = new NoteItemModel();
                            noteItemModel.groupIDFather = fsAskGpId;
                            noteItemModel.id = fiId;
                            noteItemModel.name = fsAskName;
                            noteItemModel.fiIsShow = fiIsShow;
                            if (!TextUtils.isEmpty(fdAddPrice)) {
                                noteItemModel.price = new BigDecimal(fdAddPrice);
                            }
                            NoteModel noteModel = getMenuExtraById(noteModelList, fsAskGpId);
                            if (noteModel != null) {
                                noteModel.itemList.add(noteItemModel);
                            } else {
                                noteModel = new NoteModel();
                                noteModel.groupID = fsAskGpId;
                                noteModel.name = fsAskGpName;
                                noteModel.itemList.add(noteItemModel);
                                noteModelList.add(noteModel);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return noteModelList;
            }
        });
        return result;
    }

    /**
     * 循环列表去对象
     *
     * @param menuExtraList
     * @param id
     * @return
     */
    private static NoteModel getMenuExtraById(List<NoteModel> menuExtraList, String id) {
        if (!ListUtil.listIsEmpty(menuExtraList) && !TextUtils.isEmpty(id)) {
            for (NoteModel menuExtra : menuExtraList) {
                if (TextUtils.equals(menuExtra.groupID, id)) {
                    return menuExtra;
                }
            }
        }
        return null;
    }


    /**
     * 获取一个菜品的所有的套餐
     *
     * @param menuItem MenuItem
     * @return List<MenuExtra>
     */
    public static List<MenuPackageGroup> getAllPackageByMenu(MenuItem menuItem) {
        List<MenuPackageGroup> result = new ArrayList<>();
        if (menuItem != null && menuItem.supportPackage()) {
//            SparseArray<MenuPackageGroup> packList = AppCache.getInstance().menuPackages.get(menuItem.itemID);
            LinkedHashMap<String, MenuPackageGroup> packList = AppCache.getInstance().menuPackages.get(menuItem.itemID);
            if (packList != null) {
                result.addAll(packList.values());
//                for (int i = 0; i < packList.size(); i++) {
//                    result.add(packList.valueAt(i));
//                }
            }
        }
        return result;
    }

    /**
     * 将已选择的配料替换到数据列表
     *
     * @param extraList  List<MenuExtra>
     * @param selectList List<MenuExtraItem>
     */
    public static void replaceExtraInfo(List<MenuExtra> extraList, List<MenuExtra> selectList) {
        for (int i = 0; i < extraList.size(); i++) {
            MenuExtra temp = extraList.get(i);
            for (MenuExtra tempSelected : selectList) {
                if (TextUtils.equals(temp.groupID, tempSelected.groupID) && temp.type == tempSelected.type) {
                    extraList.set(i, tempSelected);
                }
            }
        }
    }

    /**
     * 当前套餐是否还可以再增加选择的菜品
     *
     * @param extra MenuExtra
     * @return boolean
     */
    public static boolean canAddSelected(MenuExtra extra, BigDecimal addNum) {
        if (extra == null) {
            return false;
        }
        BigDecimal tempTotal = BigDecimal.ZERO;
        for (MenuExtraItem detailItem : extra.itemList) {
            if (detailItem.selected) {
                tempTotal = tempTotal.add(detailItem.num);
            }
        }
        tempTotal = tempTotal.add(addNum);
        return tempTotal.compareTo(new BigDecimal(Integer.toString(extra.pacFoodNum))) <= 0;

    }

    /**
     * 当前套餐是否还可以再增加选择的菜品
     *
     * @param group       MenuPackageGroup
     * @param selectCache
     * @return boolean
     */
    public static boolean canAddSelected(MenuPackageGroup group, BigDecimal addNum, ArrayMap<String, Boolean> selectCache) {
        if (group == null) {
            return false;
        }
        BigDecimal tempTotal = BigDecimal.ZERO;
        Boolean selected = false;
        for (MenuItem detailItem : group.itemList) {
            selected = selectCache.get(detailItem.getMenuPackageItemId(group.id));
            if (null != selected && selected) {
                tempTotal = tempTotal.add(detailItem.menuBiz.buyNum);
            }
        }
        tempTotal = tempTotal.add(addNum);
        return tempTotal.compareTo(new BigDecimal(Integer.toString(group.pacFoodNum))) <= 0;

    }

    /**
     * 当前套餐是否还可以修改选择菜品的数量
     *
     * @param extra MenuExtra
     * @return boolean
     * @deprecated see {@link DinnerMenuUtil #canModifyNum(MenuPackageGroup extra, MenuItem item, BigDecimal newNum}
     */
    public static boolean canModifyNum(MenuExtra extra, MenuExtraItem extraItem, BigDecimal newNum) {
        if (extra == null) {
            return false;
        }
        BigDecimal tempTotal = BigDecimal.ZERO;
        for (MenuExtraItem detailItem : extra.itemList) {
            if (detailItem.selected) {
                if (TextUtils.equals(detailItem.groupIDFather, extraItem.groupIDFather) && TextUtils.equals(detailItem.id, extraItem.id)) {
                    tempTotal = tempTotal.add(newNum);
                } else {
                    tempTotal = tempTotal.add(detailItem.num);
                }
            }
        }
        return tempTotal.compareTo(new BigDecimal(Integer.toString(extra.pacFoodNum))) <= 0;

    }

    /**
     * 当前套餐是否还可以修改选择菜品的数量
     *
     * @param extra MenuExtra
     * @return boolean
     */
    public static boolean canModifyNum(MenuPackageGroup extra, MenuItem item, BigDecimal newNum, ArrayMap<String, Boolean> selectCache) {
        if (extra == null) {
            return false;
        }
        BigDecimal tempTotal = BigDecimal.ZERO;
        Boolean selected = false;
        for (MenuItem detailItem : extra.itemList) {
            selected = selectCache.get(detailItem.getMenuPackageItemId(extra.id));
            if (selected != null && selected) {
                if (TextUtils.equals(detailItem.categoryCode, item.categoryCode) && TextUtils.equals(detailItem.itemID, item.itemID)) {
                    tempTotal = tempTotal.add(newNum);
                } else {
                    tempTotal = tempTotal.add(detailItem.menuBiz.buyNum);
                }
            }
        }
        return tempTotal.compareTo(new BigDecimal(Integer.toString(extra.pacFoodNum))) <= 0;

    }

    /**
     * 检查必选项是否有项目被选中
     *
     * @return boolean
     */
    public static String checkSelectMustSelected(MenuItem menuItem, List<MenuExtra> extraList) {

        boolean hasOneSelected = false;
        for (MenuExtra menuExtra : extraList) {
            for (MenuExtraItem menuExtraItem : menuExtra.itemList) {
                if (menuExtraItem.isDefault || menuExtraItem.selected) {
                    hasOneSelected = true;
                    break;
                }
            }
            if (hasOneSelected) {
                break;
            }
        }
        if (!hasOneSelected) {
            return "套餐[" + menuItem.name + "]的选择内容不能为空";
        }
        for (MenuExtra temp : extraList) {
            if (temp.isRequired) {
                boolean hasSelected = false;
                for (MenuExtraItem tempDetail : temp.itemList) {
                    if (tempDetail.selected) {
                        hasSelected = true;
                        break;
                    }
                }
                if (!hasSelected) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + temp.name + "]" + "是必选项";
                }
            }
        }
        for (MenuExtra menuExtra : extraList) {
            if (!menuExtra.isSolid) {
                BigDecimal currentSelected = BigDecimal.ZERO;
                for (MenuExtraItem detailItem : menuExtra.itemList) {
                    if (detailItem.selected) {
                        currentSelected = currentSelected.add(detailItem.num);
                    }
                }
                if (currentSelected.compareTo(BigDecimal.ZERO) > 0 && currentSelected.compareTo(new BigDecimal(Integer.toString(menuExtra.pacFoodNum))) < 0) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + menuExtra.name + "]" + "需要选择" + menuExtra.pacFoodNum + "项";
                }
            }
        }
        return "";
    }


    /**
     * 检查必选项是否有项目被选中
     *
     * @return boolean
     */
    public static String checkSelectMustSelectedV2(MenuItem menuItem, List<MenuPackageGroup> extraList, ArrayMap<String, Boolean> selectCache) {

        boolean hasOneSelected = false;
        Boolean selected = false;
        for (MenuPackageGroup menuExtra : extraList) {
            for (MenuItem menuExtraItem : menuExtra.itemList) {
                selected = selectCache.get(menuExtraItem.getMenuPackageItemId(menuExtra.id));
                if (menuExtraItem.supportPackageDefaultSelect() || (selected != null && selected)) {
                    hasOneSelected = true;
                    break;
                }
            }
            if (hasOneSelected) {
                break;
            }
        }
        if (!hasOneSelected) {
            return "套餐[" + menuItem.name + "]的选择内容不能为空";
        }
        for (MenuPackageGroup temp : extraList) {

            BigDecimal currentSelected = BigDecimal.ZERO;
            for (MenuItem detailItem : temp.itemList) {
                selected = selectCache.get(detailItem.getMenuPackageItemId(temp.id));
                if (selected != null && selected) {
                    currentSelected = currentSelected.add(detailItem.menuBiz.buyNum.subtract(detailItem.menuBiz.voidNum));
                }
            }

            BigDecimal max = new BigDecimal(temp.pacFoodNum);

            if (temp.isSolid) {
                // TODO: 2018/2/8 固定项(固定项客户端控制不可点击, 暂不校验, 交由客户端控制)
            } else if (temp.isRequired) {
                // 必选项
                if (currentSelected.compareTo(BigDecimal.ZERO) == 0) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + temp.name + "]" + "是必选项";
                }
                if (currentSelected.compareTo(max) < 0) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + temp.name + "]" + "需要选择" + temp.pacFoodNum + "项";
                }
                if (currentSelected.compareTo(max) > 0) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + temp.name + "]" + "最多可选择" + temp.pacFoodNum + "项";
                }
            } else {
                // 可选项
                if (currentSelected.compareTo(max) > 0) {
                    return "套餐[" + menuItem.name + "]" + "的" + "[" + temp.name + "]" + "最多可选择" + temp.pacFoodNum + "项";
                }
            }
        }
        return "";
    }

    public static String checkMultiPracticeInPackage(MenuItem menuItem) {
        if (menuItem == null) {
            return "";
        }

        String shopGUID = AppCache.getInstance().fsShopGUID;
        MenuitemDBModel tempMenu = ClientMenuDBUtil.getMenuitemByFiItemCd(shopGUID, menuItem.itemID);
        int menuProcedureSize = ClientMenuDBUtil.getMenuProcedureSize(tempMenu.fiItemCd);
        DishesUtil.buildMenuConfig(menuItem, tempMenu, menuProcedureSize,
                ClientMenuDBUtil.getMenuUnitSize(tempMenu.fiItemCd), ClientMenuDBUtil.optIngredientGPCount(tempMenu.fiItemCd));

        // 做法数量为0
        if (menuProcedureSize == 0) {
            return "";
        }

        String errorMsg = "";
        List<AskDBModel> selectMulProcedure = menuItem.menuBiz.selectMulProcedure;
        if (((menuItem.config & 1) == 1)) {// 必选做法
            if (selectMulProcedure.size() == 0) {
                errorMsg = "请选择" + "[" + menuItem.name + "]" + "做法";
                return errorMsg;
            }
        } else {// 非必选做法
            if (selectMulProcedure.size() == 0) {// 可以不选做法
                errorMsg = "";
                return errorMsg;
            }
        }

        if (menuItem.supportMultipractice()) {// 勾选了多做法
            if (selectMulProcedure.size() >= tempMenu.fipracticemin && selectMulProcedure.size() <= tempMenu.fipracticemax) {// 当前选中的做法 在多做法区间内
                errorMsg = "";
            } else {
                if (tempMenu.fipracticemin == tempMenu.fipracticemax) {
                    errorMsg = String.format("[" + menuItem.name + "]需选择%s种做法", tempMenu.fipracticemin);
                } else {
                    errorMsg = String.format("[" + menuItem.name + "]需选择%s~%s种做法", tempMenu.fipracticemin, tempMenu.fipracticemax);
                }
            }
        } else {// 没有勾选多做法  1 可以不选做法  2 如果选择做法的话 只能选一个做法
            if (selectMulProcedure.size() > 1) {
                errorMsg = "[" + menuItem.name + "]只能选中一个做法";
            }
        }

        return errorMsg;
    }

//    public static void voidAll(OrderCache orderCache, boolean print) {
//        for (MenuItem temp : orderCache.originMenuList) {
//            if (temp.hasAllVoid()) {
//                continue;
//            }
//            voidMenu(AppCache.getInstance().userDBModel, orderCache, temp, print);
//        }
//    }

//    /**
//     * 退菜  退掉指定菜品的指定份数
//     *
//     * @param currentUser 退菜人
//     * @param orderCache  OrderCache
//     * @param menu        MenuItem
//     * @param retreatNum  BigDecimal
//     * @param
//     * @param print       boolean | 是否需要打印退菜单，true：打印；false：不打印
//     */
//    public static void voidSpecifyNumMenu(UserDBModel currentUser, OrderCache orderCache, MenuItem menu, BigDecimal retreatNum, String reason,boolean print) {
//        //UserDBModel currentUser = AppCache.getInstance().userDBModel;
//        menu.doVoid(retreatNum, currentUser.fsUserId, currentUser.fsUserName, reason);
//        menu.calcTotal(orderCache.isMember);
//        orderCache.recalcQuantity();
//        orderCache.plusAllMenuAmount();
//
//        if (print) {
//            if (orderCache.dinnerModel()) {
////                PrintOrderUtil.printVoidNoThread(orderCache, menu, retreatNum, AppCache.getInstance().userDBModel.fsUserName);
//            } else {
//                PrintFastFoodOrderUtil.printVoid(orderCache, menu, retreatNum, AppCache.getInstance().userDBModel.fsUserName);
//            }
//        }
//    }

    /**
     * 修改菜品配料
     *
     * @param isMember   是否登录了会员
     * @param menu       改动的菜品
     * @param voidItems  退菜列表
     * @param addedItems 新增菜列表
     */
    public static void changeMenuItemIngredient(boolean isMember, MenuItem menu, List<MenuItem> addedItems, List<MenuItem> voidItems) {
        UserDBModel currentUser = AppCache.getInstance().userDBModel;

        for (MenuItem orderItem : menu.menuBiz.selectedModifier) {
            for (MenuItem voidItem : voidItems) {
                if (TextUtils.equals(orderItem.itemID, voidItem.itemID)) {
                    orderItem.doVoid(voidItem.menuBiz.buyNum, currentUser.fsUserId, currentUser.fsUserName, "");
                    orderItem.calcTotal(isMember);
                    break;
                }
            }
            for (MenuItem addItem : addedItems) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID)) {
                    orderItem.menuBiz.buyNum = orderItem.menuBiz.buyNum.add(addItem.menuBiz.buyNum);
                    orderItem.calcTotal(isMember);
                    break;
                }
            }
        }

        for (MenuItem addItem : addedItems) {
            boolean isExist = false;
            for (MenuItem orderItem : menu.menuBiz.selectedModifier) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID)) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                addItem.calcTotal(isMember);
                menu.menuBiz.selectedModifier.add(addItem);
            }
        }
        menu.calcTotal(isMember);
    }

//    /**
//     * 退菜，退掉当前菜品的所有菜
//     *
//     * @param currentUser
//     * @param orderCache  OrderCache
//     * @param menu        MenuItem
//     * @param print       boolean | 是否需要打印退菜单，true：打印；false：不打印
//     */
//    public static void voidMenu(UserDBModel currentUser, OrderCache orderCache, MenuItem menu, boolean print) {
//        voidSpecifyNumMenu(currentUser, orderCache, menu, menu.menuBiz.buyNum, "",print);
//    }

    public static List<MenuExtraItem> getAllSelectedMenuExtraItems(List<MenuExtra> menuExtraList) {
        List<MenuExtraItem> menuExtraItems = new ArrayList<>();
        if (!ListUtil.listIsEmpty(menuExtraList)) {
            for (MenuExtra item : menuExtraList) {
                if (!ListUtil.listIsEmpty(item.itemList)) {

                    for (MenuExtraItem extraItem :
                            item.itemList) {
                        if (extraItem.isDefault || extraItem.selected) {
                            menuExtraItems.add(extraItem);
                        }
                    }
                }
            }
        }
        return menuExtraItems;
    }

    public static BigDecimal getSelectedMenuExtraCount(MenuExtra menuExtra) {
        List<MenuExtraItem> itemList = menuExtra.itemList;
        BigDecimal count = BigDecimal.ZERO;
        if (!ListUtil.listIsEmpty(itemList)) {
            for (MenuExtraItem item : itemList) {
                if (item.selected) {
                    count = count.add(BigDecimal.ONE);
                }
            }
        }
        return count;
    }

    public static BigDecimal getSelectedMenuExtraCount(MenuPackageGroup group, ArrayMap<String, Boolean> selectCache) {
        List<MenuItem> itemList = group.itemList;
        BigDecimal count = BigDecimal.ZERO;
        Boolean selected;
        if (!ListUtil.listIsEmpty(itemList)) {
            for (MenuItem item : itemList) {
                selected = selectCache.get(item.getMenuPackageItemId(group.id));
                if (selected != null && selected) {
                    count = count.add(BigDecimal.ONE);
                }
            }
        }
        return count;
    }

    /**
     * 菜品翻页-每页显示个数
     */
    public static int countPerPage = 0;
    /**
     * 菜品翻页-当前页数
     */
    public static int currentPage = 1;
    /**
     * 最大页数
     */
    public static int maxPage = 1;
    /**
     * 匹配待显示的所有菜品
     */
    public static List<MenuItem> allMenu2Show = new ArrayList<>();
    /**
     * 当前显示分类id
     */
    public static String currentTypeId;

    /**
     * 获取当前页的菜品列表
     *
     * @return
     */
    public static List<MenuItem> getMenuOfPage() {
        List<MenuItem> menus = new ArrayList<>();
        int startPosition = countPerPage * (currentPage - 1);
        int endPosition = countPerPage * currentPage;
        if (allMenu2Show.size() < endPosition) {
            endPosition = allMenu2Show.size();
        }
        menus.addAll(allMenu2Show.subList(startPosition, endPosition));
        return menus;
    }
}
