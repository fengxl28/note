package com.mwee.android.pos.business.menu.db;


import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseIntArray;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/8/7.
 */

public class MenuDBController {
    public static ArrayMap<String, MenuEffectiveInfo> queryAllMenuEffectiveInfo() {
        ArrayMap<String, MenuEffectiveInfo> menuEffectiveInfoArrayMap = new ArrayMap<>();
        String sql = "select fiItemCd,fiIsEffectiveDate,fsStarDate,fsEndDate from  tbmenuitem where " +
                "fiIsEffectiveDate=1";
        ArrayList<MenuEffectiveInfo> menuEffectiveInfos = (ArrayList<MenuEffectiveInfo>) DBSimpleUtil.queryList
                (APPConfig.DB_CLIENT, sql, MenuEffectiveInfo.class);
        if (!ListUtil.isEmpty(menuEffectiveInfos)) {
            for (MenuEffectiveInfo menuEffectiveInfo : menuEffectiveInfos) {
                if (menuEffectiveInfo != null && !TextUtils.isEmpty(menuEffectiveInfo.fsStarDate) && !TextUtils.isEmpty(menuEffectiveInfo.fsEndDate)) {
                    try {
                        menuEffectiveInfo.startTime = DateTimeUtil.strToDate(menuEffectiveInfo.fsStarDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
                        menuEffectiveInfo.endTime = DateTimeUtil.strToDate(menuEffectiveInfo.fsEndDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
                        menuEffectiveInfoArrayMap.put(menuEffectiveInfo.fiItemCd, menuEffectiveInfo);
                    } catch (Exception e) {
                        LogUtil.logError(e);
                    }
                }
            }
        }
        return menuEffectiveInfoArrayMap;
    }

//    public static SparseIntArray queryAllMaxOrderCount() {
    public static ArrayMap<String, Integer> queryAllMaxOrderCount() {
//        SparseIntArray maxOrderCounts = new SparseIntArray();
        ArrayMap<String, Integer> maxOrderCounts = new ArrayMap<>();
        String sql = "select * from tbmenuitem where fiMax>0";
        ArrayList<MenuitemDBModel> menuitemDBModels = (ArrayList<MenuitemDBModel>) DBSimpleUtil.queryList(APPConfig
                .DB_CLIENT, sql, MenuitemDBModel.class);
        if (!ListUtil.isEmpty(menuitemDBModels)) {
            for (MenuitemDBModel menuitemDBModel : menuitemDBModels) {
                maxOrderCounts.put(menuitemDBModel.fiItemCd, menuitemDBModel.fiMax);
            }
        }
        return maxOrderCounts;
    }
}
