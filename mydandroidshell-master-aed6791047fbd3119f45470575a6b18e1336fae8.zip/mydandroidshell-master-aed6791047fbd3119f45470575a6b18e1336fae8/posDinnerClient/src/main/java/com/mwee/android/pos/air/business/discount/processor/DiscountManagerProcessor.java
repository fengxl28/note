package com.mwee.android.pos.air.business.discount.processor;

import android.text.TextUtils;

import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.pos.air.business.discount.api.DiscountManagerApi;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class DiscountManagerProcessor {
    /**
     * 所有餐区信息
     */
    public ArrayList<DiscountManagerInfo> discountManagerInfoArrayList = new ArrayList<>();

    private IResult iResult;

    private IResponse<List<DiscountManagerInfo>> iResponse = new IResponse<List<DiscountManagerInfo>>() {
        @Override
        public void callBack(boolean result, int code, String msg, List<DiscountManagerInfo> info) {

            if (result && info != null) {
                discountManagerInfoArrayList.clear();
                discountManagerInfoArrayList.addAll(rebuildInfos(info));
            }
            if (iResult != null) {
                iResult.callBack(result, msg);
            }
        }
    };

    /**
     * 格式化分类名称
     *
     * @param info
     * @return
     */
    public static List<DiscountManagerInfo> rebuildInfos(List<DiscountManagerInfo> info) {
        if (!ListUtil.isEmpty(info)) {
            for (DiscountManagerInfo discountManagerInfo : info) {
                if (discountManagerInfo != null) {
                    if (discountManagerInfo.ficouponid == 2) {
                        discountManagerInfo.discountClsNameTag = "全部";
                    } else {
                        if (TextUtils.isEmpty(discountManagerInfo.discountClsNameTag)){
                            discountManagerInfo.discountClsNameTag = "无";
                        }
                    }
                }
            }
        }
        return info;
    }

    /**
     * 格式化分类名称
     *
     * @param menuclsMap
     * @return
     */
    public static String buildMenuClsName(LinkedHashMap<String, String> menuclsMap) {
        if (menuclsMap != null && menuclsMap.size() > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            for (Map.Entry<String, String> entry : menuclsMap.entrySet()) {
                stringBuilder.append(entry.getValue())
                        .append(",");
            }
            String result = stringBuilder.toString().trim();
            if (!TextUtils.isEmpty(result)) {
                result = result.substring(0, result.length() - 1);
                return result;
            }
        }

        return "无";
    }

    public static ArrayList<String> optMenuClsList(LinkedHashMap<String, String> menuclsMap) {
        ArrayList<String> menuclsIds = new ArrayList<>();

        if (menuclsMap != null && menuclsMap.size() > 0) {
            for (Map.Entry<String, String> entry : menuclsMap.entrySet()) {
                menuclsIds.add(entry.getKey());
            }
        }
        return menuclsIds;

    }

    public void optAllDiscount(final IResult iResult) {
        this.iResult = iResult;
        DiscountManagerApi.optAllDiscount(iResponse);
    }


    /**
     * 新增区域
     *
     * @param discountManagerInfo 折扣信息
     * @param iResult
     */
    public void addDiscount(DiscountManagerInfo discountManagerInfo, final IResult iResult) {
        this.iResult = iResult;
        DiscountManagerApi.addDiscount(discountManagerInfo, iResponse);
    }


    /**
     * 修改折扣
     */
    public void updateDiscount(DiscountManagerInfo discountManagerInfo, final IResult iResult) {
        this.iResult = iResult;
        DiscountManagerApi.updateDiscount(discountManagerInfo, iResponse);
    }


    /**
     * 批量删除桌台
     *
     * @param tableIdList
     * @param iResult
     */
    public void batchDeleteTable(ArrayList<String> tableIdList, final IResult iResult) {
        this.iResult = iResult;
        DiscountManagerApi.batchDeleteTable(tableIdList, iResponse);
    }


}
