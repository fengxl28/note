package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;

/**
 * 查询会员等级列表
 * Created by zhangmin on 2018/1/30.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "crm.membercard.listMemberLevel",
        contentType = "application/json",
        response = AirMemberLeverResponse.class,
        saveToLog = true
)
public class AirMemberLeverRequest extends BaseMemberRequest {

    public AirMemberLeverRequest() {
        super("crm.membercard.listMemberLevel");
    }
}
