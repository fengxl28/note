package com.mwee.android.pos.air.business.utils;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;

import com.mwee.android.tools.LogUtil;

/**
 * Created by qinwei on 2017/10/31.
 */

public class PriceInputFilter implements InputFilter {

    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

        LogUtil.log("source---" + source);
        LogUtil.log("dest---" + dest);
        LogUtil.log("start---" + start);
        LogUtil.log("end---" + end);
        LogUtil.log("dstart---" + dstart);
        LogUtil.log("dend---" + dend);

        if (TextUtils.isEmpty(source)) {
            return null;
        }

        String dString = dest.toString();
        if (dest.toString().contains(".")) {
            if (dString.length() >= 12) {//小数的整数位不超过9位   12为整数9位加上小数点再加上2位小数
                return "";
            }
            String[] splitArray = dString.split("\\.");
            if (splitArray.length > 1) {
                if (splitArray[1].length() >= 2 && dstart > dString.indexOf(".")) {//如果小数位超过2位并且新输入的字符在小数点之后
                    return "";
                }
            }
        } else {
            if (dString.length() >= 9) {//整数不超过9位
                return "";
            }
        }
        return null;
    }
}
