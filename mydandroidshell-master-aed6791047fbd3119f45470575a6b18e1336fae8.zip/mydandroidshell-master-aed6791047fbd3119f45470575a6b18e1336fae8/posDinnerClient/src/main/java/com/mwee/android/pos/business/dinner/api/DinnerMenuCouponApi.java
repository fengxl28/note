package com.mwee.android.pos.business.dinner.api;

import com.mwee.android.pos.business.order.view.discount.DinnerMultiDiscountCallBack;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.connect.business.discount.DoDiscountResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.connect.business.CDinnerMenuCoupon;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponModel;

import java.util.List;
import java.util.Map;

/**
 * 菜品优惠业务中心相关接口
 */
public class DinnerMenuCouponApi {

    /**
     * 处理菜品优惠
     *
     * @param orderId         订单Id
     * @param tableId         桌台Id--快餐传空值
     * @param tempMenuList    未下单菜品--快餐传空值
     * @param menuCouponMap   已下单菜品优惠信息，Map<菜品seq, MenuItemCouponModel>
     * @param orderCutModel   整单立减信息
     * @param buygiftRelation 买减信息
     * @param callback
     */
    public static void doMenuItemCoupon(String orderId, String tableId, List<MenuItem> tempMenuList,
                                        Map<String, MenuItemCouponModel> menuCouponMap,
                                        MenuItemCouponBean orderCutModel,
                                        Map<String, Map<String, List<String>>> buygiftRelation,
                                        ResultCallback<DoDiscountResponse> callback) {
        MCon.c(CDinnerMenuCoupon.class, (SocketCallback<DoDiscountResponse>) response -> {
            if (response.code == SocketResultCode.SUCCESS) {
                callback.onSuccess(response.data);
            } else {
                callback.onFailure(response.code, response.message);
            }
        }).doMenuItemCoupon(orderId, tableId, tempMenuList, menuCouponMap, orderCutModel, buygiftRelation);
    }
}
