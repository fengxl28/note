package com.mwee.android.pos.business.message;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.HomeFragment;
import com.mwee.android.pos.business.message.processor.MessageUtil;
import com.mwee.android.pos.business.message.processor.pay.MessagePayDetailView;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessagePayBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 17/2/9.
 */

public class MessagePayFragment extends HomeFragment implements IDriver {

    public static final String DRIVER_TAG = "messagePay";

    public static final String TAG = MessagePayFragment.class.getSimpleName();


    private ListView lv_msg_pay;
    private CommonAdapter<MessagePayBean> adapter;

    private MessagePayDetailView msg_pay_detail;

    private List<MessagePayBean> messagePayBeanList = new ArrayList<>();

    private int chosedMsgId = -1;

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    @DrivenMethod(uri = DRIVER_TAG + "/refrehMessageData", UIThread = true)
    public void refrehData() {
        if (!MessagePayFragment.this.isVisible()) {
            return;
        }
        loadData(AppCache.getInstance().businessDate);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_message_pay, container, false);
        assignViews(rootView);
        registerEvent();
        initAdapter();
        loadData(AppCache.getInstance().businessDate);
        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();
        DriverBus.registerDriver(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        DriverBus.unRegisterDriver(this);
    }

    private void assignViews(View rootView) {
        lv_msg_pay = (ListView) rootView.findViewById(R.id.lv_msg_pay);
        msg_pay_detail = (MessagePayDetailView) rootView.findViewById(R.id.msg_pay_detail);
        msg_pay_detail.setVisibility(View.GONE);

        if(AppCache.getInstance().isRetailMode()){//小易2.2 修改样式
            ViewGroup root = rootView.findViewById(R.id.lyt_root);
            root.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            lv_msg_pay.setBackgroundColor(getResources().getColor(R.color.color_f2f2f2));
            setTextColorOfViewGroup(root,getResources().getColor(R.color.color_656565));
        }
    }

    private void setTextColorOfViewGroup(ViewGroup viewGroup,int color){
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            if(view instanceof TextView){
                ((TextView)view).setTextColor(color);
            }
        }
    }

    private void registerEvent() {
        lv_msg_pay.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                chosedMsgId = messagePayBeanList.get(position).msgId;
                ActionLog.addLog("点击了 消息中心 支付  条目 --> ", "", "", ActionLog.MESSAGE_PAY, messagePayBeanList.get(position));
                if (msg_pay_detail != null) {
                    msg_pay_detail.setDate(messagePayBeanList.get(position));
                }
                msg_pay_detail.setVisibility(View.VISIBLE);
                adapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * 拉数据
     *
     * @param businessDate
     */
    public void loadData(final String businessDate) {
        ProgressManager.showProgress(getActivityWithinHost(), getStringWithinHost(R.string.message_please_wait));
        MessageUtil.getPayList(businessDate, new IResponse<List<MessagePayBean>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<MessagePayBean> info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    //LogBiz.logNoEnv("获取支付数量："+info.size());
                    messagePayBeanList.clear();
                    messagePayBeanList.addAll(info);
                    refreshDetail();
                    adapter.notifyDataSetChanged();
                } else {
                    ToastUtil.showToast(msg);
                    //LogBiz.logNoEnv("获取支付消息异常"+msg);
                }
            }
        });
    }

    private void refreshDetail() {
        MessagePayBean bean = null;
        //查查当前选中在不在列表中
        for (MessagePayBean messagePayBean : messagePayBeanList) {
            if (messagePayBean.msgId == chosedMsgId) {
                bean = messagePayBean;
                break;
            }
        }

        if (bean != null) {
            msg_pay_detail.setDate(bean);
            msg_pay_detail.setVisibility(View.VISIBLE);
        } else {
            chosedMsgId = -1;
            msg_pay_detail.setVisibility(View.INVISIBLE);
        }
    }

    private void initAdapter() {
        adapter = new CommonAdapter<MessagePayBean>(getContext(), messagePayBeanList, R.layout.message_pay_item) {

            @Override
            public void convert(ViewHolder viewHolder, MessagePayBean data, int position) {
                String time = DateUtil.formartDateStrToTarget(data.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                viewHolder.setText(R.id.msg_pay_item_time, time + "");
                viewHolder.setText(R.id.msg_pay_item_source, data.getSourse());
                viewHolder.setText(R.id.msg_pay_item_table, data.tableName());
                viewHolder.setText(R.id.msg_pay_item_amt, data.payAmt());
                viewHolder.setText(R.id.msg_pay_item_status, data.getBizStatus());

                View root = viewHolder.getView(R.id.lyt_root);

                if(AppCache.getInstance().isRetailMode()){//小易2.2样式更改
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.system_red);
                        setTextColorOfViewGroup((ViewGroup) root, Color.WHITE);
                    }else{
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.color_f9f9f9);
                        setTextColorOfViewGroup((ViewGroup) root, getResources().getColor(R.color.color_404040));
                    }
                }else{
                    int colorR = getContextWithinHost().getResources().getColor(R.color.font1);
                    if (data.isUnDeal()) {
                        colorR = getContextWithinHost().getResources().getColor(R.color.system_red);
                    }
                    viewHolder.setTextColor(R.id.msg_pay_item_time, colorR);
                    viewHolder.setTextColor(R.id.msg_pay_item_source, colorR);
                    viewHolder.setTextColor(R.id.msg_pay_item_table, colorR);
                    viewHolder.setTextColor(R.id.msg_pay_item_amt, colorR);
                    viewHolder.setTextColor(R.id.msg_pay_item_status, colorR);
                    if (data.msgId == chosedMsgId) {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.item_selected_bg);
                    } else {
                        ViewToolsUtil.setBackgroundResourceKeepPadding(root, R.color.menu_bg);
                    }
                }
            }
        };
        lv_msg_pay.setAdapter(adapter);
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
