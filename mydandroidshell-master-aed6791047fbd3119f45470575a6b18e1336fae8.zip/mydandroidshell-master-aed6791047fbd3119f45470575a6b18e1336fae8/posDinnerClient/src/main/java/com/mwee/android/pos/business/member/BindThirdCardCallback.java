package com.mwee.android.pos.business.member;


/**
 * Created by lxx on 16/9/8.
 */
public interface BindThirdCardCallback {
    void callback(String thirdNumber, String mwNumber);
}
