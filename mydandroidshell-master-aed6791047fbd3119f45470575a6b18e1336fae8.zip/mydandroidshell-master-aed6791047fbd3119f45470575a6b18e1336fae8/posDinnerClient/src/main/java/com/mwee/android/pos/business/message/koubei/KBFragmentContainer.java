package com.mwee.android.pos.business.message.koubei;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.message.MessageV2Fragment;
import com.mwee.android.pos.business.message.koubei.future.KBFutureOrderFragment;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.XFragmentAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/10/13.
 */

public class KBFragmentContainer extends BaseFragment {

    private String[] titles = {"先付款订单", "后付款订单"};
    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_kbcontainer_layout, container, false);
        initView(v);
        initData();
        return v;
    }

    private void initView(View v) {
        viewPager = v.findViewById(R.id.viewPager);
        tabLayout = v.findViewById(R.id.tabLayout);
    }

    private void initData() {
        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(KBBeforeOrderFragment.newInstance());
        fragmentList.add(KBFutureOrderFragment.newInstance());

        XFragmentAdapter adapter = new XFragmentAdapter(getChildFragmentManager(), fragmentList, titles);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setCurrentItem(MessageV2Fragment.koubei_current_index);
    }
}
