package com.mwee.android.pos.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.FooterStateView;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;

import java.util.ArrayList;

/**
 * 带有列表组件功能的ui模版类，主要负责列表组件初始化，通用算法处理，需要下拉刷新，上拉加载更多继承此类即可快速实现此类需求
 * Created by qinwei on 2017/1/16.
 */

public abstract class BaseListFragment<T> extends BaseFragment implements PullRecyclerView.OnPullRecyclerViewListener, FooterStateView.OnFooterViewListener {
    protected PullRecyclerView mPullRecyclerView;
    protected ListAdapter adapter;
    protected ArrayList<T> modules = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(getFragmentLayoutId(), container, false);
    }

    public abstract int getFragmentLayoutId();


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    protected void initData() {
    }

    protected void initView(View view) {
        mPullRecyclerView = (PullRecyclerView) view.findViewById(R.id.mPullRecyclerView);
        mPullRecyclerView.setOnPullRecyclerViewListener(this);
        mPullRecyclerView.setColorSchemeResources(android.R.color.holo_blue_light, android.R.color.holo_red_light, android.R.color.holo_orange_light, android.R.color.holo_green_light);
        adapter = new ListAdapter(modules);
        mPullRecyclerView.setLayoutManager(getLayoutManager());
        mPullRecyclerView.setItemAnimator(getItemAnimator());
        mPullRecyclerView.setAdapter(adapter);
    }

    @Override
    public void onRefresh(int mode) {

    }

    @Override
    public void onScrollUp() {

    }

    @Override
    public void onScrollDown() {

    }

    @Override
    public void onLoadMoreRetry() {
        mPullRecyclerView.onRefreshCompleted(PullRecyclerView.MODE_PULL_TO_END, IFooterState.LOAD_MORE_STATE_ING);
    }

    public RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(getActivity());
    }

    public RecyclerView.ItemAnimator getItemAnimator() {
        return new DefaultItemAnimator();
    }


    public class ListAdapter extends BaseListAdapter<T> {

        public ListAdapter(ArrayList<T> modules) {
            super(modules);
        }

        @Override
        protected View onCreateHeaderView(ViewGroup parent) {
            return BaseListFragment.this.onCreateHeaderView(parent);
        }

        /**
         * @param parent
         * @return view  this view must impl IFooterState interface @{@link com.mwee.android.pos.widget.pull.IFooterState }  because of framework will call IFooterState onLoadMoreStateChanged(int state) changed load more state
         */
        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            return BaseListFragment.this.onCreateFooterView(parent);
        }

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return BaseListFragment.this.onCreateItemView(parent, viewType);
        }

        @Override
        protected int getItemViewTypeWithPosition(int position) {
            return BaseListFragment.this.getItemViewTypeWithPosition(position);
        }
    }

    protected View onCreateFooterView(ViewGroup parent) {
        FooterStateView footerView = new FooterStateView(getActivity());
        footerView.setOnFooterViewListener(this);
        ViewGroup.LayoutParams layoutParams = null;
//        这里有个坑 设置瀑布流StaggeredGridLayoutManager布局 第一次footer不独占一行
//        debug后发现footerView的layoutParams类型不是StaggeredGridLayoutManager.LayoutParams类型
//        很奇怪加载更多后footerView的layoutParams类型又变为StaggeredGridLayoutManager.LayoutParams类型l
//        下面是一个解决方案 大家要是有更好的方案可以联系我 qq:435231045
        if (mPullRecyclerView.getLayoutManager() instanceof StaggeredGridLayoutManager) {
            layoutParams = mPullRecyclerView.getLayoutManager().generateDefaultLayoutParams();
        } else {
            layoutParams = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT);
        }
        footerView.setLayoutParams(layoutParams);
        return footerView;
    }

    /**
     * 创建头布局
     *
     * @param parent RecyclerView 容器
     * @return
     */
    protected View onCreateHeaderView(ViewGroup parent) {
        return null;
    }

    /**
     * 根据位置获取子视图类型
     *
     * @param position 数据集合索引
     * @return
     */
    protected int getItemViewTypeWithPosition(int position) {
        return 0;
    }

    /**
     * 根据子视图类型获取子视图viewHolder包装类
     *
     * @param parent   RecyclerView 容器
     * @param viewType 数据集合索引
     * @return
     */
    protected abstract BaseViewHolder onCreateItemView(ViewGroup parent, int viewType);
}
