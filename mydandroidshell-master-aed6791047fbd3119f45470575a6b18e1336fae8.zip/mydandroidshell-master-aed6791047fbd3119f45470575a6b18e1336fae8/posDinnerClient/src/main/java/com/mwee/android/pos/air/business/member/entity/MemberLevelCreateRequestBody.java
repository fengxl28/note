package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BaseResponse;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseAirMemberRequest;

/**
 * Created by qinwei on 2017/10/19.
 */
@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json",
        method = "proxy/crm",
        response = BaseResponse.class,
        timeOut = 270)
public class MemberLevelCreateRequestBody extends BaseAirMemberRequest {
    public MemberLevelCreateRequest crm_membercard_addMemberLevel = new MemberLevelCreateRequest();

    public MemberLevelCreateRequestBody() {
    }
}
