package com.mwee.android.pos.air.business.payment.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2018/2/6.
 */

public class PayOpenStatus extends BusinessBean {
    /**
     * 0表示开通，1表示关闭
     */
    public int pay_status;

    /**
     * "weixin" //微信 "alipay"//支付宝
     */
    public String pay_type;

    public PayOpenStatus() {
    }
}
