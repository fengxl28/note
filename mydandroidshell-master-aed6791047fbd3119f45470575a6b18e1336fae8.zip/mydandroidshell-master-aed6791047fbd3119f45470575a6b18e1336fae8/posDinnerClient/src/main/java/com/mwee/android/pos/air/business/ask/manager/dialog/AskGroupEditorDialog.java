package com.mwee.android.pos.air.business.ask.manager.dialog;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.pos.air.business.ask.manager.processor.AskProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuManagerProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/9/30.
 */

public class AskGroupEditorDialog extends BaseDialogFragment implements View.OnClickListener, ChooseMenuClsView.OnChoosedMenuClsListener {
    private TextView mAskGroupTitleLabel;

    private EditText mAskGroupNameEdt;

    private TextView menucls_tv;

    private Button mAskGroupDeleteOrCancelBtn;
    private Button mAskGroupConfirmBtn;

    private AirAskGroupManagerInfo askgpDBModel;
    private OnAskGroupEditorListener listener;

    private AskProcessor mAskProcessor;

    private List<String> selectenuClsId = new ArrayList<>();
    private List<MenuTypeBean> allMenuTypeBean = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ask_group_editor_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initMenuData();
        initData();
        initMenuClsView();
    }

    private void initView(View view) {
        mAskGroupTitleLabel = view.findViewById(R.id.mAskGroupTitleLabel);
        mAskGroupNameEdt = view.findViewById(R.id.mAskGroupNameEdt);
        menucls_tv = view.findViewById(R.id.menucls_tv);
        mAskGroupDeleteOrCancelBtn = view.findViewById(R.id.mAskGroupDeleteOrCancelBtn);
        mAskGroupConfirmBtn = view.findViewById(R.id.mAskGroupConfirmBtn);
        mAskGroupDeleteOrCancelBtn.setOnClickListener(this);
        mAskGroupConfirmBtn.setOnClickListener(this);
    }

    private void initMenuData() {
        MenuManagerProcessor menuManagerProcessor = new MenuManagerProcessor();
        if (!ListUtil.isEmpty(AppCache.getInstance().firstNodeMap)) {
            for (MenuTypeBean menuTypeBean : AppCache.getInstance().firstNodeMap) {
                if (menuManagerProcessor.isNormalMenuCls(menuTypeBean.fsMenuClsId)) {
                    allMenuTypeBean.add(menuTypeBean);
                }
            }
        }
    }

    private void initData() {
        if (isEditorMode()) {
            mAskGroupTitleLabel.setText("编辑分组");
            mAskGroupNameEdt.setText(askgpDBModel.fsAskGpName);

            mAskGroupDeleteOrCancelBtn.setText("取消");
        } else {
            mAskGroupTitleLabel.setText("新增分组");
            mAskGroupDeleteOrCancelBtn.setText("取消");
        }
    }

    private void initMenuClsView() {
        menucls_tv.setOnClickListener(this);
        if (isEditorMode()) {
            if (askgpDBModel.fiUseAllMenuCls == 1) {
                selectAllMenuCls();
                menucls_tv.setText("全部");
            } else if (!ListUtil.isEmpty(askgpDBModel.fsMenuClsIdList)) {
                menucls_tv.setText(optClsName(askgpDBModel.fsMenuClsIdList));
            } else {
                selectenuClsId.clear();
                menucls_tv.setText("无");
            }
        } else {
            selectAllMenuCls();
            menucls_tv.setText("全部");
        }
    }

    private void selectAllMenuCls() {
        selectenuClsId.clear();
        if (!ListUtil.isEmpty(allMenuTypeBean)) {
            for (MenuTypeBean menuTypeBean : allMenuTypeBean) {
                selectenuClsId.add(menuTypeBean.fsMenuClsId);
            }

        }
    }

    private String optClsName(List<String> clsList) {
        selectenuClsId.clear();
        if (ListUtil.isEmpty(clsList)) {
            return "无";
        }
        selectenuClsId.addAll(clsList);
        if (selectedAll()) {
            return "全部";
        }
        StringBuilder stringBuilder = new StringBuilder();
        MenuTypeBean menuTypeBean;
        for (String id : clsList) {
            menuTypeBean = AppCache.getInstance().fullDataMap.get(id);
            if (menuTypeBean != null) {
                stringBuilder.append(menuTypeBean.fsMenuClsName).append(",");
            }
        }

        String result = stringBuilder.toString();
        if (TextUtils.validate(result)) {
            result = result.substring(0, result.length() - 1);
        }

        return result;
    }

    private boolean selectedAll() {
        return selectenuClsId.size() == allMenuTypeBean.size();
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mAskGroupDeleteOrCancelBtn:

                dismissSelf();
               /* if (isEditorMode()) {
                    DialogManager.showExecuteDialog(getActivityWithinHost(),
                            "是否确认删除？",
                            getStringWithinHost(R.string.cacel),
                            getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                                @Override
                                public void response() {
                                    doDelete();
                                }
                            }, null);
                } else {
                    dismissSelf();
                }*/
                break;
            case R.id.mAskGroupConfirmBtn:
                String name = mAskGroupNameEdt.getText().toString().trim();
                if (!TextUtils.validate(name)) {
                    ToastUtil.showToast("请输入要求组名称");
                    return;
                }
                if (!RegexUtil.checkName(name)) {
                    ToastUtil.showToast("分组名称输入字符非法");
                    return;
                }
                if (isEditorMode()) {
                    doUpdate(name);
                } else {
                    doSave(name);
                }
                break;
            case R.id.menucls_tv:
                //菜品分类
                ChooseMenuClsView dialog = new ChooseMenuClsView();
                dialog.setParams(allMenuTypeBean, selectenuClsId, this);
                dialog.show(getFragmentManagerWithinHost(), "ChooseMenuClsView");
                break;
            default:
                break;
        }
    }

    private void doDelete() {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.doDeleteAskGp(askgpDBModel.fsAskGpId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onAskGroupDeleteSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "删除失败" : info);
                }
            }
        });
    }

    private void doSave(String name) {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.doAddAskGp(name, selectedAll(), selectenuClsId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onAskGroupAddSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "添加失败" : info);
                }
            }
        });
    }

    private void doUpdate(String name) {
        ProgressManager.showProgress(getActivityWithinHost());
        mAskProcessor.doUpdateAskGp(askgpDBModel.fsAskGpId, name, selectedAll(), selectenuClsId, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onAskGroupUpdateSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? "修改失败" : info);
                }
            }
        });
    }

    public void setParam(AirAskGroupManagerInfo askgpDBModel, AskProcessor mAskProcessor) {
        this.askgpDBModel = askgpDBModel;
        this.mAskProcessor = mAskProcessor;
    }

    public boolean isEditorMode() {
        return this.askgpDBModel != null;
    }

    public void setOnAskGroupEditorListener(OnAskGroupEditorListener listener) {
        this.listener = listener;
    }

    @Override
    public void onConfirm(List<String> choosedMenuClsIdList) {

        menucls_tv.setText(optClsName(choosedMenuClsIdList));
    }

    public interface OnAskGroupEditorListener {
        void onAskGroupAddSuccess();

        void onAskGroupUpdateSuccess();

        void onAskGroupDeleteSuccess();
    }

}
