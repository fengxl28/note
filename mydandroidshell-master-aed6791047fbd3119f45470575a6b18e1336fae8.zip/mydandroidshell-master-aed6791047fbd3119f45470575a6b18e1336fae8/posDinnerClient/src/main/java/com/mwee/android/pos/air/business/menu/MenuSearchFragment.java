package com.mwee.android.pos.air.business.menu;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.business.menu.adapter.ItemDetailModelAdapter;
import com.mwee.android.pos.business.menu.component.DinnerMenuUtil;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.KEditView;
import com.mwee.android.pos.widget.SKeyboardView;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/11/3.
 */

public class MenuSearchFragment extends BaseFragment {

    private KEditView searchInputEdt;
    private GridView gv_menu_detail;
    private LinearLayout ll_keyboard;
    private SKeyboardView keyboardView;

    ItemDetailModelAdapter itemAdp;

    private ArrayMap<String, BigDecimal> selectCache;

    private String sectionID = "";
    private TextView tvCancelSearch;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.air_main_page_menu_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        registerEvent();
        init();
        refreshMenuList();

    }

    private void assignViews(View v) {

        searchInputEdt = v.findViewById(R.id.main_menu_fragment_search_input_edt);

        gv_menu_detail = v.findViewById(R.id.gv_menu_detail);

        ll_keyboard = v.findViewById(R.id.ll_keyboard);

        keyboardView = v.findViewById(R.id.keyboard_view);

        tvCancelSearch = v.findViewById(R.id.tvCancelSearch);

    }


    private void registerEvent() {

        searchInputEdt.addTextChangedListener(new SearchTextWatcher());

        tvCancelSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissSelf();
            }
        });

        gv_menu_detail.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    int arg2, long arg3) {
                if (itemAdp != null) {
                    MenuItem menuItem = itemAdp.getDatas().get(arg2);
                    //获取缓存中菜品时效信息
                    MenuEffectiveInfo menuEffectiveInfo = AppCache.getInstance().menuEffectiveInfoMap.get(menuItem.itemID);
                    //未设置时效菜品或者菜品时效时间生效中
                    if (menuEffectiveInfo == null || menuEffectiveInfo.dataIsEffectiveDate()) {
                        OrderDishesBizUtil.startProcessClickedMenu(getActivityWithinHost(), menuItem, false, sectionID);
                        if (searchInputEdt.getVisibility() == View.VISIBLE && !TextUtils.isEmpty(searchInputEdt.getText().toString())) {
                            searchInputEdt.setText("");
                        }
                        searchInputEdt.hide();
                    }
                }
            }
        });

    }


    private void init() {

        searchInputEdt.setKeyBoardEditView(R.xml.keyboard_number_normal, R.xml.keyboard_english_normal);

        itemAdp = new ItemDetailModelAdapter(getActivityWithinHost());
        itemAdp.setSelectCache(selectCache);
        gv_menu_detail.setAdapter(itemAdp);
        searchInputEdt.setEditView(ll_keyboard, keyboardView, false);
        searchInputEdt.show();

    }


    public void setParam(ArrayMap<String, BigDecimal> selectCache, String currentSectionID) {
        sectionID = currentSectionID;
        this.selectCache = selectCache;
    }


    public class SearchTextWatcher implements TextWatcher {
        @Override
        public void onTextChanged(CharSequence s, int start, int before,
                                  int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            if (searchInputEdt.getVisibility() != View.VISIBLE || searchInputEdt.getText().toString().trim().isEmpty()) {
                return;
            }
            long time = DateUtil.getCurrentTimeInMills();
            if (searchInputEdt.getTag() == null) {
                searchHandler.sendEmptyMessageDelayed(1, 600);
            } else {
                if (time - (Long) searchInputEdt.getTag() < 700) {//输入的字符间隔时间 小于700毫秒 移除以前的handler 延时600毫秒执行
                    searchHandler.removeMessages(1);
                    searchHandler.sendEmptyMessageDelayed(1, 600);
                } else {
                    searchHandler.sendEmptyMessage(1);
                }
            }
            searchInputEdt.setTag(time);
        }
    }

    private Handler searchHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            search();

        }
    };


    private void search() {

        if (searchInputEdt.getText().toString().isEmpty()) {
            return;
        }

        BusinessExecutor.executeAsyncExcute(new ASyncExecute<List<MenuItem>>() {
            @Override
            public List<MenuItem> execute() {
                return getMethcingData(searchInputEdt.getText().toString().trim());
            }
        }, new SyncCallback<List<MenuItem>>() {
            @Override
            public void callback(List<MenuItem> menuItems) {
                //DinnerMenuUtil.allMenu2Show = menuItems;
                itemAdp.setHelpCodeShow(true);
                itemAdp.setItemDetails(menuItems);
                itemAdp.notifyDataSetChanged();
            }
        });
    }


    private List<MenuItem> getMethcingData(String et_result) {
        List<MenuItem> menuListAll = AppCache.getInstance().firstNodeMap.get(0).menuList;
        List<MenuItem> mathcingItemList = new ArrayList<>();
        if (!TextUtils.isEmpty(et_result)) {
            et_result = et_result.trim().replaceAll("\\s+", "").replaceAll(" ", "").toUpperCase();
            for (int i = 0; i < menuListAll.size(); i++) {
                MenuItem itemDtail = menuListAll.get(i);
                if (itemDtail.isCategory) {
                    continue;
                }
                if (TextUtils.isEmpty(itemDtail.fsHelpCode)) {
                    continue;
                }
                /*助记码匹配*/
                String nameAll = itemDtail.fsHelpCode.toUpperCase();
                String nameFrist = String.valueOf(itemDtail.fsHelpCode.charAt(0)).toUpperCase();

                if (itemDtail.fsHelpCode.contains(et_result)
                        || nameAll.contains(et_result.toUpperCase())
                        || nameFrist.contains(et_result.toUpperCase())
                        || itemDtail.fsItemId.contains(et_result)) {
                    mathcingItemList.add(itemDtail);
                }
            }
        }
        return mathcingItemList;
    }


    public void refreshMenuList() {

        DinnerMenuUtil.allMenu2Show = AppCache.getInstance().firstNodeMap.get(0).menuList;
        itemAdp.setItemDetails(DinnerMenuUtil.allMenu2Show);
        itemAdp.notifyDataSetChanged();

    }


}
