package com.mwee.android.pos.air.business.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.mwee.android.pos.dinner.R;

/**
 * Created by zhangmin on 2017/11/6.
 */

public class CountKeyboard extends LinearLayout implements View.OnClickListener{

    private KeyBoardClickListener keyBoardClickListener;
    private Button btn_dot;

    public CountKeyboard(Context context) {
        super(context);
        init(context);
    }

    public CountKeyboard(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        View.inflate(context, R.layout.air_count_keyboard, this);
        Button btn_1 = (Button) findViewById(R.id.btn_1);
        Button btn_2 = (Button) findViewById(R.id.btn_2);
        Button btn_3 = (Button) findViewById(R.id.btn_3);
        Button btn_4 = (Button) findViewById(R.id.btn_4);
        Button btn_5 = (Button) findViewById(R.id.btn_5);
        Button btn_6 = (Button) findViewById(R.id.btn_6);
        Button btn_7 = (Button) findViewById(R.id.btn_7);
        Button btn_8 = (Button) findViewById(R.id.btn_8);
        Button btn_9 = (Button) findViewById(R.id.btn_9);
        Button btn_0 = (Button) findViewById(R.id.btn_0);

        btn_dot = (Button) findViewById(R.id.btn_dot);
        Button btn_C = (Button) findViewById(R.id.btn_C);


        btn_1.setTag("1");
        btn_1.setOnClickListener(this);
        btn_2.setTag("2");
        btn_2.setOnClickListener(this);
        btn_3.setTag("3");
        btn_3.setOnClickListener(this);
        btn_4.setTag("4");
        btn_4.setOnClickListener(this);
        btn_5.setTag("5");
        btn_5.setOnClickListener(this);
        btn_6.setTag("6");
        btn_6.setOnClickListener(this);
        btn_7.setTag("7");
        btn_7.setOnClickListener(this);
        btn_8.setTag("8");
        btn_8.setOnClickListener(this);
        btn_9.setTag("9");
        btn_9.setOnClickListener(this);
        btn_0.setTag("0");
        btn_0.setOnClickListener(this);

        btn_dot.setTag(".");
        btn_dot.setOnClickListener(this);
        btn_C.setTag("C");
        btn_C.setOnClickListener(this);

        setSupportFloat(true);
    }

    public void setKeyBoardClickListener(KeyBoardClickListener keyBoardClickListener) {
        this.keyBoardClickListener = keyBoardClickListener;
    }

    public interface KeyBoardClickListener {
        void onKeyBoardClick(String key);
    }

    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        switch (v.getId()) {
            default:
                if (keyBoardClickListener != null)
                    keyBoardClickListener.onKeyBoardClick((String) button.getTag());
                break;
        }

    }

    /**
     * 是否支持小数
     *
     * @param isSupportFloat boolean | 支持小数点
     */
    public void setSupportFloat(boolean isSupportFloat) {
        if (isSupportFloat) {
            btn_dot.setEnabled(true);
            btn_dot.setTag(".");
            btn_dot.setOnClickListener(this);
        } else {
            btn_dot.setEnabled(false);
            btn_dot.setOnClickListener(null);
        }
    }
}
