package com.mwee.android.pos.air.business.menu.processor;

import com.mwee.android.pos.air.business.menu.MenuAttributeFragment;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.order.widget.ModifyQuantityElectronicFragment;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.component.callback.NormalListener;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;

/**
 * Created by zhangmin on 2017/11/7.
 */

public class MenuAttributeProcessor {


    public static void jumpMenuAttributeFragment(Host mHost, MenuItem menuItem) {

        MenuAttributeFragment menuAttributeFragment = new MenuAttributeFragment();
        menuAttributeFragment.setParams(mHost,menuItem);
        menuAttributeFragment.show(mHost.getFragmentManagerWithinHost(), "");

    }


    public static void jumpQuantityElectronicFragment(final Host mHost, final MenuItem menuItem, NormalListener normalListener,final CountKeyboardCallback callback){

        ModifyQuantityElectronicFragment fragment = new ModifyQuantityElectronicFragment();
        fragment.setParams(menuItem, callback);
        fragment.setRightBtnCallBack(normalListener);
        DialogManager.showCustomDialog(mHost, fragment, ModifyQuantityElectronicFragment.FRAGMENT_TAG);
    }


}
