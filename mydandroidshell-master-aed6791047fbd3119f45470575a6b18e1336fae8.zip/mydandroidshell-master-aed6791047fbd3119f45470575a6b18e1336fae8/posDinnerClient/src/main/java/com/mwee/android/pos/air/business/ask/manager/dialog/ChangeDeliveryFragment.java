package com.mwee.android.pos.air.business.ask.manager.dialog;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import com.mwee.android.pos.business.message.processor.netOrder.DeliveryUtil;
import com.mwee.android.pos.business.setting.view.TakeoutDeleveryChannelFragment;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.connect.business.delivery.OptAllDeliveryChannelResponse;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 更改配送方案
 */
public class ChangeDeliveryFragment extends BaseDialogFragment implements View.OnClickListener {
    private View rootView;
    private TextView takeout_ok;
    private TextView takeout_cacel;

//    private RadioButton rbt_sf, rbt_dada;

    private ListView lv_delivery_channel;
    private List<DeliveryChannelBean> mDeliveryChannelList = new ArrayList<>();
    private CommonAdapter<DeliveryChannelBean> mAdapter;

    private ConfirmCallBack confirmCallBack;

    private static final String Key_TakeawaySource = "Key_TakeawaySource";
    private static final String Key_Delivery_Channel = "Key_Delivery_Channel";

    private String deliveryChannel = "SF";
    private String mTakeawaySource;

    /**
     * @param takeawaySource  订单来源：eleme\meituan
     * @param deliveryChannel 配送平台标识
     * @return
     */
    public static ChangeDeliveryFragment createDeliverySetting(String takeawaySource, String deliveryChannel) {
        ChangeDeliveryFragment changeDeliveryFragment = new ChangeDeliveryFragment();
        Bundle bundle = new Bundle();
        bundle.putString(Key_TakeawaySource, takeawaySource);
        bundle.putString(Key_Delivery_Channel, deliveryChannel);
        changeDeliveryFragment.setArguments(bundle);
        return changeDeliveryFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_change_delivery, null);
        LinearLayout container_change_deliver = rootView.findViewById(R.id.container_change_deliver);

        takeout_ok = rootView.findViewById(R.id.takeout_ok);
        takeout_cacel = rootView.findViewById(R.id.takeout_cacel);
        lv_delivery_channel = rootView.findViewById(R.id.lv_delivery_channel);

        //重置弹框大小
        Display display = ((WindowManager) getActivity().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        Point point = new Point();
        display.getSize(point);
        ViewGroup.LayoutParams lp = container_change_deliver.getLayoutParams();
        lp.width = point.x * 3 / 5;
        container_change_deliver.setLayoutParams(lp);

        if (getArguments() != null) {
            mTakeawaySource = getArguments().getString(Key_TakeawaySource);
            this.deliveryChannel = getArguments().getString(Key_Delivery_Channel);
        }

        takeout_ok.setOnClickListener(this);
        takeout_cacel.setOnClickListener(this);

        initAdapter();
        lv_delivery_channel.setAdapter(mAdapter);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadAllChannel();
    }

    private void initAdapter() {
        mAdapter = new CommonAdapter<DeliveryChannelBean>(getContext(), mDeliveryChannelList, R.layout.item_change_delivery_channel) {
            @Override
            public void convert(ViewHolder holder, DeliveryChannelBean data, int position) {
                String deliveryCheckStatus = DeliveryUtil.getDeliveryCheckStatus(data); // 审核状态
                String checkInfo = TextUtils.isEmpty(deliveryCheckStatus) ? "" : "（" + deliveryCheckStatus + "）";

                RadioButton rb_item = holder.getView(R.id.rb_item);
                rb_item.setText(data.channelName + "配送" + checkInfo);
                rb_item.setChecked(TextUtils.equals(data.channel, deliveryChannel));

                if (!DeliveryUtil.supportDeliveryCheck(mTakeawaySource, data.channel)) {
                    // 置灰
                    rb_item.setTextColor(getResources().getColor(R.color.font3));
                    holder.getConvertView().setTag(null);
                    holder.getConvertView().setOnClickListener(null);
                } else {
                    rb_item.setTextColor(getResources().getColor(R.color.font1));
                    holder.getConvertView().setTag(data);
                    holder.getConvertView().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            deliveryChannel = data.channel;
                            refreshAdapter();
                        }
                    });
                }
            }
        };
    }

    private void refreshAdapter() {
        if (Looper.getMainLooper() != Looper.myLooper()) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    refreshAdapter();
                }
            });
            return;
        }
        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.takeout_ok:
                if (this.confirmCallBack != null) {
                    this.confirmCallBack.onCallBack(this.deliveryChannel);
                }
                dismissSelf();
                break;
            case R.id.takeout_cacel:
                dismissSelf();
                break;
        }
    }

    public void setConfirmCallBack(ConfirmCallBack confirmCallBack) {
        this.confirmCallBack = confirmCallBack;
    }

    public void loadAllChannel() {
        ProgressManager.showProgress(getActivityWithinHost(), R.string.message_please_wait);
        DeliveryUtil.optAllDeliveryChannel(new SocketCallback<OptAllDeliveryChannelResponse>() {
            @Override
            public void callback(SocketResponse<OptAllDeliveryChannelResponse> response) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (response != null) {
                    if (response.success()) {
                        mDeliveryChannelList.addAll(response.data.deliveryChannelList);
                        refreshAdapter();
                    } else {
                        ToastUtil.showToast(response.message);
                    }
                }
            }
        });
    }

    public interface ConfirmCallBack {
        void onCallBack(String deliveryChannel);
    }
}
