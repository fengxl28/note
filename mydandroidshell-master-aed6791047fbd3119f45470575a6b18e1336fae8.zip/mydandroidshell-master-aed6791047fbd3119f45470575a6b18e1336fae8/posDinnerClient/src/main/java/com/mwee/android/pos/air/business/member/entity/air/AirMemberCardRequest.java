package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;

/**
 * 查询会员等级列表
 * Created by zhangmin on 2018/1/30.
 * 备注：不需要公共参数 不继承BaseMemberRequest
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "cpCardMemberList",
        contentType = "application/json",
        response = AirMemberCardResponse.class,
        saveToLog = true
)
public class AirMemberCardRequest extends BasePosRequest {

    public String cardNo;
    public String mobile;
    public String realName;
    public String cardParentNo;
    public Integer level;
    public Integer type;
    public Integer source;
    public Integer isWxCardUsed;
    public Integer isAliCardUsed;
    public Integer startDate;
    public Integer endDate;
    public Integer identity;
    public PageVo pageVo = new PageVo();//分页信息


    public AirMemberCardRequest() {
        //super("cpCardMemberList");
    }

    @Override
    public String optBaseUrl() {
        return Constant.getBusinessMemberUrl();
    }
}
