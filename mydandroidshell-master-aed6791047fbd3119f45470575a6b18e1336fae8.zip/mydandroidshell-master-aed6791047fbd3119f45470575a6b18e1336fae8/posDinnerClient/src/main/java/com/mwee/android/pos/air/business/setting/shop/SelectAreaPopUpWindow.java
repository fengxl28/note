package com.mwee.android.pos.air.business.setting.shop;

import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mwee.android.pos.air.business.setting.api.ShopApi;
import com.mwee.android.pos.air.business.setting.shop.model.CityModel;
import com.mwee.android.pos.air.business.setting.shop.model.DistrictModel;
import com.mwee.android.pos.air.business.setting.shop.model.GetCityListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.GetDistrictListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.GetProvinceListResponse;
import com.mwee.android.pos.air.business.setting.shop.model.ProvinceModel;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DensityUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.wheelview.ArrayWheelAdapter;
import com.mwee.android.pos.widget.wheelview.WheelView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by changsunhaipeng on 2018/2/8.
 */

public class SelectAreaPopUpWindow {
    private Host host;
    private View contentView;
    private View parentView;
    private PopupWindow popupWindow;
    private TextView mCancel;
    private TextView mOk;
    private List<String> provinceList = new ArrayList<>();
    private List<String> cityList = new ArrayList<>();
    private List<String> districtList = new ArrayList<>();
    private List<ProvinceModel> provinceData = new ArrayList<>();
    private List<CityModel> cityData = new ArrayList<>();
    private List<DistrictModel> districtData = new ArrayList<>();
    private WheelView mProvinceWheelView;
    private WheelView mCityWheelView;
    private WheelView mDistrictWheelView;
    private AreaCallback areaCallback;

    public void setSubCallback(AreaCallback areaCallback) {
        this.areaCallback = areaCallback;
    }

    public SelectAreaPopUpWindow(Host host, View parentView, GetProvinceListResponse data) {
        provinceList.clear();
        cityList.clear();
        districtList.clear();
        provinceData.clear();
        cityData.clear();
        districtData.clear();

        this.host = host;
        this.parentView = parentView;
        provinceData.addAll(data.data);
        for (ProvinceModel item : data.data) {
            provinceList.add(item.name);
        }
        cityList.add(" ");
        districtList.add(" ");
    }

    public void init() {
        contentView = LayoutInflater.from(host.getContextWithinHost()).inflate(R.layout.cashier_pop_select_area_list, null);
        initContentView(contentView);
        popupWindow = new PopupWindow(contentView, RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout
                .LayoutParams.WRAP_CONTENT);

        //在PopupWindow里面就加上下面代码，让键盘弹出时，不会挡住pop窗口。
        popupWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
        popupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        popupWindow.setContentView(contentView);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable());

        //添加pop窗口关闭事件
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                backgroundAlpha(1f);//设置透明
            }
        });
        contentView.setFocusable(true);
        contentView.setFocusableInTouchMode(true);
        contentView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    if (popupWindow != null) {
                        popupWindow.dismiss();
                    }
                }
                return false;
            }
        });
    }

    private void initContentView(View contentView) {
        mCancel = contentView.findViewById(R.id.tv_cancel);
        mOk = contentView.findViewById(R.id.tv_ok);
        mProvinceWheelView = contentView.findViewById(R.id.wheel_view_province);
        mCityWheelView = contentView.findViewById(R.id.wheel_view_city);
        mDistrictWheelView = contentView.findViewById(R.id.wheel_view_district);

        initWheelView(mProvinceWheelView);
        initWheelView(mCityWheelView);
        initWheelView(mDistrictWheelView);

        initListener();

        mProvinceWheelView.setWheelData(provinceList);
        mCityWheelView.setWheelData(cityList);
        mDistrictWheelView.setWheelData(districtList);
    }

    private void initListener() {
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        mOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int provincePosition = mProvinceWheelView.getCurrentPosition();
                int cityPosition = mCityWheelView.getCurrentPosition();
                int districtPosition = mDistrictWheelView.getCurrentPosition();
                areaCallback.updateinfo(provinceData.get(provincePosition), cityData.get(cityPosition), districtData.get(districtPosition));
                dismiss();
            }
        });
        mProvinceWheelView.setOnWheelItemSelectedListener(new WheelView.OnWheelItemSelectedListener() {
            @Override
            public void onItemSelected(int position, Object o) {
                ProgressManager.showProgress(host);
                ShopApi.getCityList(provinceData.get(position).id, new ResultCallback<GetCityListResponse>() {
                    @Override
                    public void onSuccess(GetCityListResponse data) {
                        ProgressManager.closeProgress(host);
                        cityData.clear();
                        cityList.clear();
                        cityData.addAll(data.data);
                        for (CityModel item : data.data) {
                            cityList.add(item.cityName);
                        }
                        //mCityWheelView.setWheelData(cityList);
                        mCityWheelView.resetDataFromTop(cityList);

                        mCityWheelView.setOnWheelItemSelectedListener(new WheelView.OnWheelItemSelectedListener() {
                            @Override
                            public void onItemSelected(int position, Object o) {
                                ProgressManager.showProgress(host);
                                ShopApi.getDistrictList(cityData.get(position).cityId, new ResultCallback<GetDistrictListResponse>() {
                                    @Override
                                    public void onSuccess(GetDistrictListResponse data) {
                                        ProgressManager.closeProgress(host);
                                        districtList.clear();
                                        districtData.clear();
                                        districtData.addAll(data.data);
                                        for (DistrictModel item : data.data) {
                                            districtList.add(item.name);
                                        }
                                        //mDistrictWheelView.setWheelData(districtList);
                                        mDistrictWheelView.resetDataFromTop(districtList);
                                    }

                                    @Override
                                    public void onFailure(int code, String msg) {
                                        super.onFailure(code, msg);
                                        ProgressManager.closeProgress(host);
                                        ToastUtil.showToast(msg);
                                    }
                                });
                            }
                        });
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        super.onFailure(code, msg);
                        ProgressManager.closeProgress(host);
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });
    }

    private void initWheelView(WheelView mWheelView) {
        mWheelView.setWheelAdapter(new ArrayWheelAdapter(host.getContextWithinHost()));
        mWheelView.setSkin(WheelView.Skin.Holo);
        mWheelView.setLoop(false);
        mWheelView.setWheelSize(5);

        WheelView.WheelViewStyle style = new WheelView.WheelViewStyle();
        style.backgroundColor = host.getResourcesWithinHost().getColor(R.color.color_EEEEEE);
        style.textColor = host.getResourcesWithinHost().getColor(R.color.color_999999);
        style.textSize = 14;
        style.selectedTextColor = host.getResourcesWithinHost().getColor(R.color.color_007aff);
        style.selectedTextSize = 15;
        style.holoBorderWidth = DensityUtil.dip2px(host.getContextWithinHost(), 1);
        style.holoBorderColor = host.getResourcesWithinHost().getColor(R.color.color_EEEEEE);

        mWheelView.setStyle(style);
    }

    /**
     * 设置透明度
     *
     * @param alpha
     */
    private void backgroundAlpha(float alpha) {
        WindowManager.LayoutParams lp = host.getActivityWithinHost().getWindow().getAttributes();
        lp.alpha = alpha;
        host.getActivityWithinHost().getWindow().setAttributes(lp);
    }

    public void dismiss() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        }
    }

    public void show() {
        if (isShowing()) {
            return;
        }
        init();
        popupWindow.showAtLocation(parentView, Gravity.BOTTOM, 0, 0);
        backgroundAlpha(0.5f);//设置半透明

    }

    public boolean isShowing() {
        if (popupWindow != null) {
            return popupWindow.isShowing();
        }
        return false;
    }

    public interface AreaCallback {
        void updateinfo(ProvinceModel provinceModel, CityModel cityModel, DistrictModel districtModel);
    }
}
