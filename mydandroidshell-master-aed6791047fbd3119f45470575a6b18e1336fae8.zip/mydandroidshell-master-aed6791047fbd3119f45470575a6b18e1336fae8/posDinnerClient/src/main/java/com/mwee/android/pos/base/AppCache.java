package com.mwee.android.pos.base;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseArray;
import android.util.SparseIntArray;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.image.PictureManager;
import com.mwee.android.pos.business.constants.AirHostConstant;
import com.mwee.android.pos.business.constants.HostConstant;
import com.mwee.android.pos.business.menu.db.MenuDBController;
import com.mwee.android.pos.business.orderdishes.util.OrderDishesBizUtil;
import com.mwee.android.pos.business.pay.ClientRoundConfig;
import com.mwee.android.pos.business.viceshow.ViceShowConnector;
import com.mwee.android.pos.client.db.BillSourceDBUtil;
import com.mwee.android.pos.client.db.ClientAskDBUtil;
import com.mwee.android.pos.client.db.ClientCommonDBUtil;
import com.mwee.android.pos.client.db.ClientDBUtil;
import com.mwee.android.pos.client.db.ClientMenuDBUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.client.db.MenuIngredientDBUtil;
import com.mwee.android.pos.client.db.PackageDBUtil;
import com.mwee.android.pos.component.basecon.COrder;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.connect.business.order.GetSellOutResponse;
import com.mwee.android.pos.connect.callback.SocketThreadCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.BillSourceDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.bean.MenuExtra;
import com.mwee.android.pos.db.business.menu.bean.MenuIngredientType;
import com.mwee.android.pos.db.business.menu.bean.MenuPackageGroup;
import com.mwee.android.pos.db.business.menu.bean.MenuTypeBean;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.discount.CouponBargainModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.NetWorkUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.android.tools.log.LogUpload;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * AppCache
 * Created by virgil on 16/6/14.
 */
public class AppCache extends Cache {
    public final static String BIZ_CODE = "104";
    private static final AppCache instance = new AppCache();
    /**
     * Shop的ID,测试店ID,93330
     */
    public String fsShopGUID = "";
    public ShopDBModel shop = new ShopDBModel();
    public String seed = "";//
    public String token = "";//
    public boolean isConnectNetWork;
    //当前站点ID
    public String currentHostId = "";
    public String currentShiftID = "";
    public int currentHostType = HostConstant.CASHIER_HOST;

    /**
     * 外卖开台配置信息
     * ELEME --> [{SF,顺丰}, {DADA,达达}]
     */
    public LinkedHashMap<String, List<DeliveryChannelBean>> deliverSettingMap = new LinkedHashMap<>();

    /**
     * 要求名称;
     * key为{@link com.mwee.android.pos.db.business.AskgpDBModel#fsAskGpId}
     * value为{@link com.mwee.android.pos.db.business.AskgpDBModel#fsAskGpName}
     */
    public ArrayMap<String, String> askTypeMap = new ArrayMap<>();

    /**
     * 套餐信息列表;
     * 组成信息参见{@link PackageDBUtil#getAllMenuPackages(String)}
     */
//    public SparseArray<SparseArray<MenuPackageGroup>> menuPackages = new SparseArray<>();
    public ArrayMap<String, LinkedHashMap<String, MenuPackageGroup>> menuPackages = new ArrayMap<>();


    /**
     * 菜品规格
     * key : 菜品ID
     * value : 规格集合 List<MenuItemUnitDBModel>
     */
//    public SparseArray<List<UnitModel>> menuItemUnitArr = new SparseArray<>();
    public ArrayMap<String, List<UnitModel>> menuItemUnitArr = new ArrayMap<>();
    /**
     * 订单来源
     */
    public List<BillSourceDBModel> billSourceDBModelMap = new ArrayList<>();
    public List<BillSourceDBModel> billSourceAll = new ArrayList<>();

    /**
     * 所有配料组;
     * 组成信息参见{@link MenuIngredientDBUtil#initMenuIngredientGP(String)}
     */
    public LinkedHashMap<String, MenuIngredientType> initMenuIngredientGPMap = new LinkedHashMap<>();

    /**
     * 菜品对应配料组关系
     * 组成信息参见{@link MenuIngredientDBUtil#initMenuRelIngredient(String)}
     */
    public LinkedHashMap<String, List<String>> menuIngredGPRelMap = new LinkedHashMap<>();

    /**
     * 要求列表
     * 组成信息参见{@link ClientAskDBUtil#getAskList(String, ArrayMap<String, String>)}
     */
    public ArrayMap<String, MenuExtra> askList = new ArrayMap<>();

    /**
     * 当前的用户信息
     */
    public UserDBModel userDBModel = null;

    /**
     * 当前登录用户是否有收银权限
     * TRUE： 有
     * FALSE： 没有
     */
    public boolean collectMoney = false;
    /**
     * 当前登录用户是否有开台下单权限
     * TRUE： 有
     * FALSE： 没有
     */
    public boolean openOrder = false;

    public String isAllDataInLaw = "";
    /**
     * 当前营业日期
     */
    public String businessDate = "";
    /**
     * 所有菜品
     */
    public LinkedHashMap<String, MenuTypeBean> fullDataMap = new LinkedHashMap<>();
    /**
     * 根节点菜品
     */
    public List<MenuTypeBean> firstNodeMap = new ArrayList<>();
    /**
     * 当前在点菜的桌台ID
     */
    public String orderingTableID = "";
    /**
     * 中控登录失败是否弹框提示
     * true ： 弹框提示
     * false:  Toast+Notification提示
     */
    public boolean loginErrshowDialog = true;
    /**
     * 当前正在操作的订单
     */
    public String currentOrderID = "";
    /**
     * 当前正在操作的订单Token
     * 直接存入DB，放在报文头里，不需要再手动访问这个字段
     */
    @Deprecated
    public String currentOrderToken = "";
    /**
     * 存储所有设置时效菜品
     */
    public ArrayMap<String, MenuEffectiveInfo> menuEffectiveInfoMap = new ArrayMap<>();
    /**
     * 特价菜的列表
     */
    public List<CouponBargainModel> couponBargainList = new ArrayList<>();
    /**
     * 存储最大可点份数
     */
//    public SparseIntArray maxOrderNumbers = new SparseIntArray();
    public ArrayMap<String, Integer> maxOrderNumbers = new ArrayMap<>();
    /**
     * 门店会员 手机号使用会员的配置 0 未开启（不支持手机号使用），1验证消费（支持手机号并需要手机验证码）, 2免密消费（手机号即可使用会员）
     */
    public String shop_member_config = "0";
    /**
     * 打印监控成功或者失败的标识
     */
    public boolean isPrintWaring = false;
    /**
     * 估清
     * 规格：剩余数量
     */
//    private SparseArray<BigDecimal> sellOutUnits = new SparseArray();
    private ArrayMap<String, BigDecimal> sellOutUnits = new ArrayMap<>();
    /**
     * 本机配置信息缓存
     */
    private SparseArray<String> localSettings;
    /**
     * 餐厅配置信息缓存
     */
    private HashMap<String, String> dinnerSettings;
    private String alipayShopId;

    /**
     * 是否打开自定义模块
     */
    public boolean useModule = false;
    /**
     * 自定义模块名称
     */
    public String customModuleName = "";
    /**
     * 自定义模块URL
     */
    public String customModuleUrl = "";

    private AppCache() {
        localSettings = new SparseArray<>();
        dinnerSettings = new HashMap<>();
        isConnectNetWork = NetWorkUtil.isNetworkAvailable(DinnerApplication.instance);
    }

    public static AppCache getInstance() {
        return instance;
    }

    /**
     * 网络订单
     * key:不同类型--外卖、堂食、历史
     */
    // public ArrayMap<String, List<TempAppOrder>> networckOrdersMap = new ArrayMap<>();
    @Override
    public void refresh() {
        getDataFromDB();
    }

    public void init() {
        initToken();
    }

    public void initToken() {
        seed = ClientMetaUtil.getSettingsValueByKey(META.SEED);
        token = ClientMetaUtil.getSettingsValueByKey(META.TOKEN);
        fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
    }

    public void refreshMenuPackages() {
        //构建套餐
        menuPackages = PackageDBUtil.getAllMenuPackages(fsShopGUID);
    }

    protected void getDataFromDB() {
        LogUpload.setShopID(AppCache.getInstance().fsShopGUID);
        shop = DBSimpleUtil.query(APPConfig.DB_CLIENT, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where fiStatus='1' and fsShopGUID='" + fsShopGUID + "'", ShopDBModel.class);
        if (shop == null) {//门店状态可能存在禁用状态，避免为空，不去过滤状态
            shop = DBSimpleUtil.query(APPConfig.DB_CLIENT, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where  fsShopGUID='" + fsShopGUID + "'", ShopDBModel.class);
        }
        APPConfig.fiWorkMode = shop.fiWorkMode;
        initHost();

        //构建要求名称
        askTypeMap = ClientAskDBUtil.getAskGoup(fsShopGUID);
        //构建要求列表
        askList = ClientAskDBUtil.getAskList(fsShopGUID, askTypeMap);

        refreshMenuPackages();

        //构建订单来源
        billSourceDBModelMap = BillSourceDBUtil.optAllAvailableBillSource();
        billSourceAll = BillSourceDBUtil.optAllBillSource();
        initMenuIngredientGPMap = MenuIngredientDBUtil.initMenuIngredientGP(fsShopGUID);
        menuIngredGPRelMap = MenuIngredientDBUtil.initMenuRelIngredient(fsShopGUID);

        menuItemUnitArr = ClientMenuDBUtil.initMenuItemUnitArr();

        menuEffectiveInfoMap = MenuDBController.queryAllMenuEffectiveInfo();
        maxOrderNumbers = MenuDBController.queryAllMaxOrderCount();

        useModule = TextUtils.equals(ClientCommonDBUtil.getConfigWithDefault(DBOrderConfig.CUSTOM_MODULE, "0"), "1");
        customModuleUrl = ClientCommonDBUtil.getFSStr1WithDefault(DBOrderConfig.CUSTOM_MODULE, "");
        customModuleName = ClientCommonDBUtil.getFSStr2WithDefault(DBOrderConfig.CUSTOM_MODULE, "");

        refreshAllMenu();
        ClientRoundConfig.init(fsShopGUID);
        PrintConnector.getInstance().init(GlobalCache.getContext());
        ViceShowConnector.getInstance().init(GlobalCache.getContext());
        PictureManager.downLoadBitmap(shop.fslogourl);
        initSellOut();
    }

    public void initHost() {
        currentHostId = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        HostDBModel hostDBModel = ClientDBUtil.getHostByID(AppCache.getInstance().fsShopGUID, currentHostId);
        if (isRetailMode()) {
            currentHostType = StringUtil.toInt(ClientMetaUtil.getSettingsValueByKey(META.AIR_ORDER_MODE), AirHostConstant.DINNER_MODEL);
        } else {
            if (hostDBModel != null) {
                currentHostType = hostDBModel.fiHostCls;
            }
            switch (currentHostType) {
                case HostConstant.CASHIER_HOST:
                case HostConstant.FASTFOOD_HOST:
                case HostConstant.ORDER_DISHES_HOST:
                case HostConstant.SUPER_HOST:
                    break;
                default:
                    currentHostType = HostConstant.CASHIER_HOST;
                    break;
            }
        }
    }

    /**
     * 初始化所有菜品
     */
    public synchronized void refreshAllMenu() {
        fullDataMap.clear();
        firstNodeMap.clear();
        ClientMenuDBUtil.buildMenuType(fsShopGUID, fullDataMap, firstNodeMap);
    }

    private void initSellOut() {

        MCon.c(COrder.class, null, new SocketThreadCallback<GetSellOutResponse>() {
            @Override
            public void callback(SocketResponse<GetSellOutResponse> socketResponse) {
                if (socketResponse != null && socketResponse.code == SocketResultCode.SUCCESS) {
                    OrderDishesBizUtil.updateSellOutUnit(socketResponse.data.dataList);
                }
            }
        }).GetSellOutRequest(false);
    }

    /**
     * 返回估清数量。
     * -1表示不估清。
     *
     * @param fiUnitCd int  | 规格ID
     * @return int | 估清数量，-1表示不估清
     */
    public synchronized BigDecimal getSelloutNum(String fiUnitCd) {
//        return AppCache.getInstance().sellOutUnits.get(fiUnitCd, new BigDecimal(-1));
        BigDecimal num = AppCache.getInstance().sellOutUnits.get(fiUnitCd);
        if (num == null) {
            num = BizConstant.NEGATIVE;
        }
        return num;
    }

//    public synchronized void setSellOut(SparseArray<BigDecimal> sellOutUnits) {
    public synchronized void setSellOut(ArrayMap<String, BigDecimal> sellOutUnits) {
        this.sellOutUnits = sellOutUnits;
    }

    public int getMaxOrderCount(String menuItem) {
//        return maxOrderNumbers.get(menuItem, -1);
        Integer count = maxOrderNumbers.get(menuItem);
        if (count == null) {
            count = -1;
        }
        return count;
    }

    public synchronized void clearSellOut() {
        this.sellOutUnits.clear();
    }

    public synchronized void removeSellOut(String fiUnitCd) {
//        this.sellOutUnits.delete(fiUnitCd);
        this.sellOutUnits.remove(fiUnitCd);
    }

    public void updateCouponBargain(List<CouponBargainModel> couponBargainList) {
        this.couponBargainList.clear();
        if (!ListUtil.isEmpty(couponBargainList)) {
            this.couponBargainList.addAll(couponBargainList);
        }
    }

    @Override
    public void clean() {

    }

    public void updateBusinessDate(String date) {
        businessDate = date;
//        ClientMetaUtil.updateSettingsValueByKey(META.BUSINESS_DATE, date);
    }

    /**
     * 设置本地配置
     *
     * @param key
     * @param value 2、习惯手势
     *              3、桌台视图
     *              4、快餐连续开单
     *              5、快餐牌号
     */
    public void putLocalSetting(int key, String value) {
        if (key == META.FLIP_HABITS
                || key == META.TABLE_BIZ_SIZE
                || key == META.FASTPOS_CONTINUOUS_OPEN || key == META.ALLOW_PAY_OVERFLOW
                || key == META.FASTPOS_TABLE_NUM || key == META.TABLE_UNLOCK_SHOT_OFF || key == META.AUTO_USE_MEMBER_PRICE
                || key == META.KEEP_ORIGIN_TABLE || key == META.WESTERN_FOOD_MODE || key == META.CHOOSE_BONUS_USER
                || key == META.ALLOW_ALIPAY_BACK || key == META.ALLOW_WXPAY_BACK
                || key == META.MWWIFI_OPEN_STATUS || key == META.MWWIFI_LAST_CONNECTION_INFO
                || key == META.OPEN_DINING_STANDARD || key == META.OPEN_MIN_STANDARD || key == META.OPEN_BOX_WHEN_USE_COUPON
                || key == META.AUTO_USE_MEMBER_DISCOUNT || key == META.USE_MEMBER_PRICE_FIRST) {
            localSettings.put(key, value);
        }
        ClientMetaUtil.updateSettingsValueByKey(key, value);
    }

    public void clearLocalSetting() {
        localSettings.clear();
    }

    public void clearDinnerSetting() {
        dinnerSettings.clear();
    }

    /**
     * 获取本地配置
     *
     * @param key
     * @param defValue
     * @return
     */
    public String getLocalSetting(int key, String defValue) {
        if (TextUtils.isEmpty(localSettings.get(key))) {
            localSettings.put(key, ClientMetaUtil.getConfig(key, defValue));
        }
        return localSettings.get(key);
    }

    /**
     * 更新订单操作的Token
     *
     * @param orderToken String
     */
    public void refreshOrderToken(String orderToken) {
        currentOrderToken = orderToken;
        ClientMetaUtil.updateSettingsValueByKey(META.ORDER_TOKEN, orderToken);
    }

    /**
     * 设置餐厅配置
     *
     * @param key
     * @param value
     */
    public void putDinnerSetting(String key, String value) {
        dinnerSettings.put(key, value);
        ClientCommonDBUtil.setConfig(key, value);
        if (TextUtils.equals(DBOrderConfig.ROUND_SUB_TOTAL, key)
                || TextUtils.equals(DBOrderConfig.ROUND_TOTAL, key)
                || TextUtils.equals(DBOrderConfig.ROUND_COUNT, key)) {
            ClientRoundConfig.init(AppCache.getInstance().fsShopGUID);
        }
    }

    /**
     * 获取餐厅配置
     *
     * @param key
     * @param defValue
     * @return
     */
    public String getDinnerSetting(String key, String defValue) {
        if (TextUtils.isEmpty(dinnerSettings.get(key))) {
            dinnerSettings.put(key, ClientCommonDBUtil.getConfigWithDefault(key, defValue));
        }
        return dinnerSettings.get(key);
    }

    /**
     * 判断是否为小散模式
     * fiShopType  0:普通门店 1:小散门店'
     *
     * @return
     */
    public boolean isRetailMode() {
//        if (shop != null && shop.fiShopType == ShopType.AIR) {
//            return true;
//        } else {
//            return false;
//        }
        return APPConfig.isAir();
    }

    public void refreshKouBeiShopId(String alipayShopId) {
        this.alipayShopId = alipayShopId;
    }

    public String getAlipayShopId() {
        return alipayShopId;
    }
}
