package com.mwee.android.pos.business.common.notification;

import android.support.annotation.IntDef;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @ClassName: NoticeType
 * @Description:
 * @author: SugarT
 * @date: 2018/7/10 上午10:40
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@IntDef(value = {NoticeType.UnKnow, NoticeType.ABNORMAL, NoticeType.RAPID_PAY, NoticeType.FAST_FOOD_RAPID, NoticeType.NET_ORDER, NoticeType.THIRD_ORDER, NoticeType.PRINT_ERROR, NoticeType.DELIVERY_CANCEL, NoticeType.RAPID_ORDER})
public @interface NoticeType {

    int UnKnow = 0;

    /**
     * 异常消息
     */
    int ABNORMAL = 1;

    /**
     * 秒付拉单
     */
    int RAPID_PAY = 2;

    /**
     * 微信快餐
     */
    int FAST_FOOD_RAPID = 3;

    /**
     * 外卖订单
     */
    int NET_ORDER = 4;

    /**
     * 外卖菜品未关联
     */
    int THIRD_ORDER = 5;

    /**
     * 打印异常
     */
    int PRINT_ERROR = 6;
    /**
     * 骑手取消配送
     */
    int DELIVERY_CANCEL = 7;
    /**
     * 秒点点菜消息
     */
    int RAPID_ORDER = 8;
}
