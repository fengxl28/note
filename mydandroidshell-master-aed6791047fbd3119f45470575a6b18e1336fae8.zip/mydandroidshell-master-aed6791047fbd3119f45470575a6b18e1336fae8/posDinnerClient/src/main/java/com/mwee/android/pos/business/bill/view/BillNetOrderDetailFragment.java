package com.mwee.android.pos.business.bill.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.pos.base.BaseFragment;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * created by 2018/9/19
 *
 * @author lxd
 * Description: 外卖单订单详情Fragment
 */
public class BillNetOrderDetailFragment extends BaseFragment {
    private TextView tvThridSellNo;//第三方订单号
    private TextView tvOrderTime;//下单时间
    private TextView tvSendTime;//期望送达时间
    private TextView tvMobile;//电话

    private TextView tvMWSellNo;//美味订单号
    private TextView tvName;//姓名
    private TextView tvPersonSum;//人数
    private TextView tvFaPiao;//发票

    private TextView tvTaxNo;//税号
    private TextView tvAddress;//地址

    private TextView tvBillAmount;//消费合计
    private TextView tvDiscountAmt;//优惠合计
    private TextView tvPayAmount;//实付
    private TextView tvDeliveryAmount;//配送费
    private TextView tvMemo;//备注
    private OrderDetailsView viewOrderDetails;//订单明细&支付方式

    private String netOrderid;//订单号

    private BillDataProcess billDataProcess;

    public void setParam(String netOrderid) {
        this.netOrderid = netOrderid;

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_bill_net_order_detail, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        billDataProcess = new BillDataProcess();
        initView(view);
        initData();
    }

    /**
     * 初始化View
     */
    public void initView(View view) {
        TitleBar mOrderTitleBar = (TitleBar) view.findViewById(R.id.mOrderTitleBar);
        mOrderTitleBar.setTitle("订单详情");
        mOrderTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });

        tvThridSellNo = (TextView) view.findViewById(R.id.tvThridSellNo);
        tvOrderTime = (TextView) view.findViewById(R.id.tvOrderTime);
        tvSendTime = (TextView) view.findViewById(R.id.tvSendTime);
        tvMobile = (TextView) view.findViewById(R.id.tvMobile);

        tvMWSellNo = (TextView) view.findViewById(R.id.tvMWSellNo);
        tvName = (TextView) view.findViewById(R.id.tvName);
        tvPersonSum = (TextView) view.findViewById(R.id.tvPersonSum);
        tvFaPiao = (TextView) view.findViewById(R.id.tvFaPiao);

        tvTaxNo = (TextView) view.findViewById(R.id.tvTaxNo);
        tvAddress = (TextView) view.findViewById(R.id.tvAddress);

        tvBillAmount = (TextView) view.findViewById(R.id.tvBillAmount);
        tvDiscountAmt = (TextView) view.findViewById(R.id.tvDiscountAmt);
        tvPayAmount = (TextView) view.findViewById(R.id.tvPayAmount);
        tvDeliveryAmount = (TextView) view.findViewById(R.id.tvDeliveryAmount);
        tvMemo = (TextView) view.findViewById(R.id.tvMemo);

        viewOrderDetails = view.findViewById(R.id.viewOrderDetails);
    }

    /**
     * 获取外卖订单详细数据
     */
    private void initData() {
        LogUtil.log("lxd", "开始加载数据   netOrderid=" + netOrderid);

        Progress progress = ProgressManager.showProgress(BillNetOrderDetailFragment.this);
        billDataProcess.optTempAppOrderFromBizById(netOrderid, new ResultCallback<OptNetOrderFromBizResponse>() {
            @Override
            public void onSuccess(OptNetOrderFromBizResponse response) {
//                LogUtil.log("lxd", "返回数据    data=" + data);
                if (response.tempAppOrder != null) {
                    loadingData(response);
                }
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                LogUtil.log("lxd", "数据加载失败    code=" + code + "    msg=" + msg);
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 加载界面数据
     *
     * @param response
     */
    private void loadingData(OptNetOrderFromBizResponse response) {
        TempAppOrder tempAppOrder = response.tempAppOrder;
        LogUtil.log("lxd", "加载界面数据");
        String orderTakeawaySource = billDataProcess.getOrderTakeawaySource(tempAppOrder.orderTakeawaySource);
        if (!TextUtils.isEmpty(orderTakeawaySource)) {
            tvThridSellNo.setText(orderTakeawaySource + "订单号:" + tempAppOrder.outerOrderId);
        } else {
            tvThridSellNo.setText("第三方订单号:" + tempAppOrder.outerOrderId);
        }


        tvOrderTime.setText("下单时间:" + tempAppOrder.date);
        if (tempAppOrder.distributionType == NetworkConstans.DISTRIBUTION_TYPE_SEVEN_DAYS) {
            tvSendTime.setText("期望送达时间：七天内");
        } else {
            tvSendTime.setText("期望送达时间："+tempAppOrder.distributionStartTime);
        }
        tvMobile.setText("电话：" + tempAppOrder.distributionPhone);

        tvMWSellNo.setText("美味订单号：" + tempAppOrder.orderId);
        tvName.setText("姓名：" + tempAppOrder.distributionName);
        tvPersonSum.setText("人数：" + tempAppOrder.person);
        tvFaPiao.setText("发票：" + tempAppOrder.optReceiptName());
        tvTaxNo.setText("税号：" + tempAppOrder.taxNo);
        tvAddress.setText("地址：" + tempAppOrder.address);

        if (tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
            tvBillAmount.setText("消费合计：" + Calc.formatShow(tempAppOrder.total));
        } else {
            tvBillAmount.setText("消费合计：" + Calc.formatShow(tempAppOrder.subTotal));
        }
        tvDiscountAmt.setText("优惠合计：" + Calc.formatShow(tempAppOrder.optYouhuiAmt()));
        if (tempAppOrder.realPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
            tvPayAmount.setText(Calc.formatShow(tempAppOrder.realPaymentAmount));
        } else {
            tvPayAmount.setText(Calc.formatShow(tempAppOrder.total));
        }
        if (!(BigDecimal.ZERO.compareTo(tempAppOrder.deliveryFee) > -1)) {
            tvDeliveryAmount.setText("配送费：" + tempAppOrder.deliveryFee.toPlainString());
        } else {
            tvDeliveryAmount.setText("配送费：0");
        }
        tvMemo.setText("备注：" + tempAppOrder.orderRemark);
        ArrayList<TempAppOrderDetail> detailArrayList = new ArrayList<TempAppOrderDetail>();
        for (List<TempAppOrderDetail> tempAppOrderDetails : tempAppOrder.orderDetailSparseArray) {
            detailArrayList.addAll(tempAppOrderDetails);
        }
        ArrayList<PayModel> selectPayListFull = new ArrayList<>();
        if (response.paySession != null) {
            selectPayListFull.addAll(response.paySession.selectPayListFull);
        }
        viewOrderDetails.setNetParams(getActivityWithinHost(), detailArrayList, selectPayListFull,tempAppOrder.appOrderCouponList);

    }

}
