//package com.mwee.android.pos.air.business.login;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.FragmentTransaction;
//import android.widget.ImageView;
//
//import com.mwee.android.pos.base.BaseActivity;
//import com.mwee.android.pos.dinner.R;
//
//
///**
// * 小散商户选择营业模式
// */
//public class AppConfigContainerActivity extends BaseActivity implements GuideListener {
//
//    public static final int PAGE_SELECTMODE = 1;
//    public static final int PAGE_SETTINGPRINT = 2;
//    public static final int PAGE_OPENPAY = 3;
//
//    private ImageView mStepView;
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_air_app_config_container);
//
//        mStepView = findViewById(R.id.iv_config_step);
//
//        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//        transaction.replace(R.id.mAppConfigContainer, new ChoiceModelConfigFragment());
//        transaction.addToBackStack("ChoiceModelConfigFragment");
//        transaction.commit();
//    }
//
//    @Override
//    public void onBackPressed() {
//        if (getSupportFragmentManager().getBackStackEntryCount() != 1) {
//            super.onBackPressed();
//        }
//    }
//
//    @Override
//    public void currentPage(int pageIndex) {
//        if(pageIndex == PAGE_SELECTMODE){
//            mStepView.setImageResource(R.drawable.ic_config_step_1);
//        }else if(pageIndex == PAGE_SETTINGPRINT){
//            mStepView.setImageResource(R.drawable.ic_config_step_2);
//        }else if(pageIndex == PAGE_OPENPAY){
//            mStepView.setImageResource(R.drawable.ic_config_step_3);
//        }
//    }
//}
