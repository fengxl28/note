package com.mwee.android.pos.base;

import android.content.Context;
import android.text.TextUtils;

import com.mwee.android.alp.PushClient;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.exception.DrivenException;
import com.mwee.android.pos.InitDebugTools;
import com.mwee.android.pos.business.localpush.PushClientReceiver;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.udp.UDPReceiverHost;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.syntherizer.SyntherizerHelper;
import com.mwee.android.pos.util.ClientHardwareUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.ProcessUtil;
import com.mwee.android.tools.log.LogBizConfigBuilder;
import com.mwee.android.upgrade.processor.UpgradeProcessor;

/**
 * 点菜的Application
 * Created by virgil on 16/8/25.
 *
 * @author virgil
 */
public class ClientApplication {
    public static void init(final Context context) {
        if (ProcessUtil.isMainProcess(context)) {
            if (BuildConfig.DEBUG && TextUtils.equals(ClientMetaUtil.getConfig(META.STETHO_DEBUG, "1"), "1")) {
                InitDebugTools.initStetho(context);
            }
            //配置日志
            LogBizConfigBuilder build = new LogBizConfigBuilder("", ClientHardwareUtil.getHardWareSymbol()) {
                @Override
                public String getHostId() {
                    return ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
                }
            };
            build.setUploadInterval(120).setTest(!BaseConfig.isProduct());
            build.setAutoUpload(true);
            LogUtil.updateUploadConfig(build);

            //初始化APPCache
            AppCache.getInstance().init();
            //开始其他可以后台初始化的任务
            initInBackground(context);
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    UDPReceiverHost.getInstance().start();
                }
            }).start();
            PushClient.getInstance().init(context);
            UpgradeProcessor.setEnv(BaseConfig.isProduct());

            initBiz();
            AliHotFix.initLoopAliHotFix();
            ShopDBModel shop = DBSimpleUtil.query(APPConfig.DB_CLIENT, "select * from tbshop where fiStatus='1'", ShopDBModel.class);
            if(shop != null){
                APPConfig.fiWorkMode = shop.fiWorkMode;
            }
        }
    }


    /**
     * 独立进程启动的业务
     */
    private static void initInBackground(final Context context) {
        new LowThread(new Runnable() {
            @Override
            public void run() {
                try {
                    //初始化Driver
                    DriverBus.init(context.getResources().getStringArray(R.array.drive_path));
                    DriverBus.init(context.getResources().getStringArray(R.array.drive_bind_path));
                    //初始化网络订单轮询
//                    JobStackUtil.startJob();
                    //初始化Bugly的自动更新

                } catch (DrivenException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void initBiz() {
        SocketConfig.ADDRESS = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_ADDRESS);
        if (TextUtils.isEmpty(SocketConfig.ADDRESS)) {
            SocketConfig.ADDRESS = "127.0.0.1";
        }
        if (!ClientBindProcessor.isActived()) {
            return;
        }
        if (TextUtils.isEmpty(SocketConfig.ADDRESS)) {
            return;
        }
        initPushClient();
    }

    /**
     * 注册站点间推送
     */
    public static void initPushClient() {
        if (!ClientBindProcessor.isActived()) {
            return;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                PushClientReceiver.getInstance().setHostID(ClientMetaUtil.getSettingsValueByKey(META
                        .BIZ_CENTER_CURRENT_HOST_ID));
                PushClient.getInstance().startClient(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_ADDRESS),
                        APPConfig.PUSH_PORT, PushClientReceiver.getInstance());
                return null;
            }
        });
    }


}
