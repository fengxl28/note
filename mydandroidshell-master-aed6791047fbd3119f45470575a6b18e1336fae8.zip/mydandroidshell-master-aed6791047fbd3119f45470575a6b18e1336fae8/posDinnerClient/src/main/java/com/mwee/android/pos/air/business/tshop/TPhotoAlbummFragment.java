package com.mwee.android.pos.air.business.tshop;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.mwee.android.pos.air.base.AirBaseFragment;
import com.mwee.android.pos.business.viceshow.ViceShowConnector;
import com.mwee.android.pos.business.viceshow.other.ViceShowHelp;
import com.mwee.android.pos.component.callback.TResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.tools.LogUtil;

/**
 * Created by zhangmin on 2017/10/25.
 */
public class TPhotoAlbummFragment extends AirBaseFragment {


    private Switch swScreen;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.t_photoabnum_fragment, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        assignViews(view);
        init();

    }


    private void assignViews(View v) {
        swScreen = v.findViewById(R.id.swScreen);
        TitleBar titleBar = v.findViewById(R.id.titleBar);
        titleBar.setTitle("屏显设置");
        titleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
/*

        RadioGroup rgScreenModel = v.findViewById(R.id.rgScreenModel);
        RadioButton rbImageModel = v.findViewById(R.id.rbImageModel);
        RadioButton rbVideoModel = v.findViewById(R.id.rbVideoModel);

        rgScreenModel.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbImageModel) {
                    LogUtil.log("选取了图片播放");
                    ClientMetaUtil.updateSettingsValueByKey(META.T_VICESHOW_MODE, 0);
                    if(ViceHardDeviceUtils.isSunMi()){
                        SMViceShowHelp.getInstance().playSMImage("");
                    }else {
                        ViceShowHelp.getInstance().playImage();
                    }
                } else {
                    LogUtil.log("选取了视频播放");
                    ClientMetaUtil.updateSettingsValueByKey(META.T_VICESHOW_MODE, 1);
                    if(ViceHardDeviceUtils.isSunMi()){
                        SMViceShowHelp.getInstance().playSMVideo("");
                    }else {
                        ViceShowHelp.getInstance().playVideo("");
                    }
                }

            }
        });

        String temp = ClientMetaUtil.getConfig(META.T_VICESHOW_MODE, "0");
        if (TextUtils.equals("0", temp)) {
            rbImageModel.setChecked(true);
        } else {
            rbVideoModel.setChecked(true);
        }
*/


    }


    private void init() {
        TShopProcessor.queryTHostexternal(2, new TResult<HostexternalDBModel>() {
            @Override
            public void callBack(final HostexternalDBModel model) {

                swScreen.setChecked(TextUtils.equals(model.fsParamValue, "2"));
                swScreen.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked) {//开启
                            ActionLog.addLog("小散设置界面->点击了 开启客显", "", "", ActionLog.SS_MORE_JOIN, "");
                            LogUtil.log("update tbhostexternal set fsparamvalue 2");
                            model.fsParamValue = "2";
                            ViceShowHelp.getInstance().showPresentation();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    ViceShowConnector.getInstance().startPlay();
                                }
                            },2000);

                        } else {//关闭
                            ActionLog.addLog("小散设置界面->点击了 关闭客显", "", "", ActionLog.SS_MORE_JOIN, "");
                            LogUtil.log("update tbhostexternal set fsparamvalue 2");
                            model.fsParamValue = "1";
                            ViceShowHelp.getInstance().dismissPresentation();
                        }
                        TShopProcessor.replaceTHostexternal(model);

                    }
                });

            }
        });


    }


}
