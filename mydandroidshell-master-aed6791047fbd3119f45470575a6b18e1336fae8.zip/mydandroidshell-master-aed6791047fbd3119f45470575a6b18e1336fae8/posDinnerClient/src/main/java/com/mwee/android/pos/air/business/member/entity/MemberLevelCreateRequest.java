package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberLevelCreateRequest extends BaseMemberParam {
    public int m_shopid;
    public String title;
    public String up_rule;//会员升级规则
    public String down_rule;//会员降级规则
    public String up_reward;

    public MemberLevelCreateRequest() {
    }
}
