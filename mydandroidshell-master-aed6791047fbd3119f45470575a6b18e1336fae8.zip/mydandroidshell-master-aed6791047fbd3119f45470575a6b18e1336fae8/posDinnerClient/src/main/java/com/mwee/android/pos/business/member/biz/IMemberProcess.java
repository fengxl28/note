package com.mwee.android.pos.business.member.biz;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.Coupon;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by qinwei on 2017/2/20.
 */

public interface IMemberProcess {

    /**
     * 仅查询会员信息
     *
     * @param number
     * @param callback
     */
    void onlyLoadMemberInfo(String number, IResponse<QueryMemberInfoResponse> callback);

    /**
     * 查询会员信息并绑定到订单
     *
     * @param number
     * @param orderId
     * @param callback
     */
    void loadMemberInfoAndBindToOrder(String number, String orderId, boolean isUsedMemberPrice, IResponse<QueryMemberInfoAndBindToOrderResponse> callback);


    /**
     * 查询会员信息并绑定到订单
     *
     * @param number
     * @param orderId
     * @param callback
     */
    void loadMemberInfoAndBindToOrder(String number, String code, String orderId, boolean isUsedMemberPrice, IResponse<QueryMemberInfoAndBindToOrderResponse> callback);


    /**
     * 加载会员储值记录
     *
     * @param card_no  会员卡号
     * @param last_id  分页数据
     * @param limit    一次请求数据个数
     * @param callback 异步回调函数
     */
    void loadMemberBalanceChangeData(String card_no, String last_id, int limit, ResultCallback<BalanceOrderList> callback);


    /**
     * 加载会员优惠券列表
     *
     * @param card_no  会员卡号
     * @param page     当前页码
     * @param pageSize 一页请求数据个数
     */
    void loadMemberCoupons(String card_no, int page, int pageSize, ResultCallback<ArrayList<Coupon>> callback);


    /**
     * 加载会员充值套餐
     *
     * @param cardId
     * @param callback
     */
    void loadMemberRechargePackages(String cardId, ResultCallback<ArrayList<MemberRechargePackageModel>> callback);


    /**
     * 现金付款充值
     *
     * @param ruleID
     * @param amount
     * @param pay_code
     * @param cardNo
     * @param callback
     */
    void loadCashRechargeRequest(int ruleID, BigDecimal amount, String pay_code, String cardNo, ResultCallback<QueryNewMembeChargeResultModel> callback);


    /**
     * 会员储值
     *
     * @param tradeNo
     * @param callback
     */
    void loadMemberRechargeOrderRequest(String tradeNo, ResultCallback<MemberRechargeOrderModel> callback);

    /**
     * 在线付款充值
     *
     * @param ruleID
     * @param amount
     * @param pay_code
     * @param payType
     * @param micro
     * @param cardNo
     * @param callback
     */
    void loadOnlineRechargeRequest(int ruleID, BigDecimal amount, String pay_code, int payType, String micro, String cardNo, ResultCallback<QueryNewMembeChargeResultModel> callback);

    /**
     * 发送验证码接口
     *
     * @param mobile   手机号
     * @param callback
     */
    void loadSendMobileCode(String mobile, ResultCallback<ResponseData> callback);

    /**
     * 获取门店会员配置信息
     *
     * @param callback
     */
    void loadShopMemberConfig(ResultCallback<MemberConfig> callback);

    /**
     * 第三方会员卡号与美味会员卡号绑定
     *
     * @param thirdNumber 第三方会员卡号
     * @param mwNumber    美味会员卡号号
     */
    void thirdMemberBind(String thirdNumber, String mwNumber, IResult iResult);

    /**
     * 查询充值支付结果
     */
    void queryOnlineRechargeRequest(String tradeNo, ResultCallback<QueryNewMembeChargeResultModel> iResult);

    /**
     * 查询会员卡信息，不带验证码---会员重构版本
     *
     * @param account  手机号/会员卡号
     * @param callback
     */
    void optMemberInfoWithoutVerify(String account, ResultCallback<NewQueryMemberListResponse> callback);

    /**
     * 查询会员卡信息，不带验证码，并绑定到订单---会员重构版本
     *
     * @param account  手机号/会员卡号
     * @param orderId  订单号
     * @param callback
     */
    void optMemberInfoWithoutVerifyAndBindToOrder(String account, String orderId, ResultCallback<NewQueryMemberListResponse> callback);

    /**
     * 查询会员卡信息，带验证码---会员重构版本
     *
     * @param account        手机号/会员卡号
     * @param verifyCode     手机验证码
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     * @param callback
     */
    void optMemberInfo(String account, String verifyCode, int verifyCodeType, ResultCallback<NewQueryMemberListResponse> callback);

    /**
     * 查询会员卡信息，带验证码，并绑定到订单---会员重构版本
     *
     * @param account        手机号
     * @param verifyCode     手机验证码
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     * @param orderId        订单号
     * @param callback
     */
    void optMemberInfoAndBindToOrder(String account, String verifyCode, int verifyCodeType, String orderId, ResultCallback<NewQueryMemberListResponse> callback);

    /**
     * 将指定会员卡绑定到订单---会员重构版本
     *
     * @param memberCard 会员卡
     * @param orderId    订单Id
     * @param callback
     */
    void bindMemberCardToOrder(NewMemberCardListItemModel memberCard, String orderId, ResultCallback<NewQueryMemberInfoAndBindToOrderResponse> callback);

    /**
     * 发送手机验证码
     *
     * @param mobile   手机号
     * @param type     验证码使用场景，1-关联会员，2-会员开卡
     * @param callback
     */
    void sendVerifyCode(String mobile, int type, ResultCallback<Boolean> callback);
}
