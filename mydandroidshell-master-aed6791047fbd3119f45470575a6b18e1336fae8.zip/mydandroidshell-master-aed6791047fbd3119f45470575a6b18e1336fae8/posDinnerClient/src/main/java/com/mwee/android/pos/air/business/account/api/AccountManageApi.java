package com.mwee.android.pos.air.business.account.api;

import com.mwee.android.air.acon.CAccountManage;
import com.mwee.android.air.connect.business.account.GetAccountDetailResponse;
import com.mwee.android.air.connect.business.account.GetAllAccountResponse;
import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;

/**
 * @ClassName: AccountManageApi
 * @Description:
 * @author: SugarT
 * @date: 2017/10/17 上午10:23
 */
public class AccountManageApi {

    /**
     * 获取所有员工账号
     *
     * @param iResult
     */
    public static void getAllAccount(final IResponse<GetAllAccountResponse> iResult) {
        MCon.c(CAccountManage.class, new SocketCallback<GetAllAccountResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAccountResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).getAllAccount();
    }

    public static void getAccountDetail(String fsUserId, final IResponse<GetAccountDetailResponse> iResult) {
        MCon.c(CAccountManage.class, new SocketCallback<GetAccountDetailResponse>() {
            @Override
            public void callback(SocketResponse<GetAccountDetailResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).getAccountDetail(fsUserId);
    }

    public static void addAccount(AccountManageInfo model, final IResponse<GetAllAccountResponse> iResult) {
        MCon.c(CAccountManage.class, new SocketCallback<GetAllAccountResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAccountResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).addAccount(model);
    }

    public static void updaetAccount(AccountManageInfo model, final IResponse<GetAllAccountResponse> iResult) {
        MCon.c(CAccountManage.class, new SocketCallback<GetAllAccountResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAccountResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).updateAccount(model);
    }

    public static void deleteAccount(String fsUserId, final IResponse<GetAllAccountResponse> iResult) {
        MCon.c(CAccountManage.class, new SocketCallback<GetAllAccountResponse>() {
            @Override
            public void callback(SocketResponse<GetAllAccountResponse> response) {
                if (response == null) {
                    if (iResult != null) {
                        iResult.callBack(false, SocketResultCode.EXCEPTION, "业务异常，请重试", null);
                    }
                    return;
                }

                if (response.code == SocketResultCode.SUCCESS) {
                    if (iResult != null) {
                        if (response.data != null) {
                            iResult.callBack(true, 0, response.message, response.data);
                        } else {
                            iResult.callBack(false, response.code, response.message, null);
                        }
                    }
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, response.code, response.message, null);
                    }
                }
            }
        }).deleteAccount(fsUserId);
    }
}
