package com.mwee.android.pos.business.member.view;

import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.Host;
import com.mwee.android.pos.business.member.api.ClientMemberApi;
import com.mwee.android.pos.client.print.PrintReceiptUtil;
import com.mwee.android.pos.component.basecon.CPrint;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.connect.business.print.PrinterMemberResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.connect.MCon;
import com.mwee.android.pos.connect.callback.SocketCallback;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;

/**
 * 会员打印的数据构造
 * Created by virgil on 16/8/18.
 */
public class MemberPrintProcess {

    /**
     * 打印会员特权
     *
     * @param cardNo          String | 会员卡号
     * @param memberPrivilege MemberPrivateModel | 会员特权
     */
    public static void printPrivilege(final Host host, final String cardNo, final MemberPrivateModel memberPrivilege) {
        ProgressManager.showProgress(host, "打印中...");
        MCon.c(CPrint.class, new SocketCallback<PrinterMemberResponse>() {
            @Override
            public void callback(SocketResponse<PrinterMemberResponse> response) {
                ProgressManager.closeProgress(host);
                if (response == null) {
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }

                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).printerMemberPrivate(cardNo, memberPrivilege);
    }

    /**
     * 打印会员特权
     *
     * @param cardNo          String | 会员卡号
     * @param memberPrivilege MemberPrivateModel | 会员特权
     */
    public static void printPrivilege(final Host host, final String cardNo, final MemberPrivateDetailModel.CardPrivilege memberPrivilege) {
        ProgressManager.showProgress(host, "打印中...");
        ClientMemberApi.printPrivilege(cardNo, memberPrivilege, new SocketCallback<PrinterMemberResponse>() {
            @Override
            public void callback(SocketResponse<PrinterMemberResponse> response) {
                ProgressManager.closeProgress(host);
                if (response == null) {
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }
                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        });
    }

    /**
     * 打印会员充值
     *
     * @param orderModel String | 会员卡号
     * @param payType    String|支付类型
     * @param memberName String|会员姓名
     */
    public static void printCharge(final Host host, final MemberRechargeOrderModel orderModel, final String payType, final String memberName) {
        ProgressManager.showProgress(host, "打印中...");
        MCon.c(CPrint.class, new SocketCallback<PrinterMemberResponse>() {
            @Override
            public void callback(SocketResponse<PrinterMemberResponse> response) {
                ProgressManager.closeProgress(host);
                if (response == null) {
                    return;
                }
                if (response.code == SocketResultCode.SUCCESS) {
                    if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                        PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                    }

                } else {
                    ToastUtil.showToast(response.message);
                }
            }
        }).printerMemberCharge(orderModel, payType, memberName);
    }

    /**
     * 打印会员充值
     *
     * @param orderModel String | 会员卡号
     * @param payType    String|支付类型
     * @param memberName String|会员姓名
     */
    public static void printChargeInfo(final Host host, final MemberRechargeResultModel orderModel, final String payType, final String memberName) {
        ProgressManager.showProgress(host, "打印中...");
        ClientMemberApi.printerChargeInfo(payType,memberName,orderModel, response -> {
            ProgressManager.closeProgress(host);
            if (response == null) {
                return;
            }
            if (response.code == SocketResultCode.SUCCESS) {
                if (response.data != null && !ListUtil.isEmpty(response.data.printNoList)) {
                    PrintReceiptUtil.addPrintNo(response.data.printNoList, AppCache.getInstance().currentHostId);
                }
            } else {
                ToastUtil.showToast(response.message);
            }
        });
    }
}
