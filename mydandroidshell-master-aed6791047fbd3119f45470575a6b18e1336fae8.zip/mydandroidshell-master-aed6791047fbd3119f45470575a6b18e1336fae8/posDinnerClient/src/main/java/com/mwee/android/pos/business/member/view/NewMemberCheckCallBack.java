package com.mwee.android.pos.business.member.view;

import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;

/**
 * Created by lxx on 16/7/5.
 */
public interface NewMemberCheckCallBack {

    void call(NewQueryMemberInfoAndBindToOrderResponse member);
}
