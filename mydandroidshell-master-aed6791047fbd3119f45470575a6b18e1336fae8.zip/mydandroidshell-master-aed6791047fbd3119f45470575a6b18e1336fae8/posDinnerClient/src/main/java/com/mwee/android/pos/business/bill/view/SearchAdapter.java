package com.mwee.android.pos.business.bill.view;

import android.content.Context;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.mwee.android.pos.business.bill.bean.SearchDataItem;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.Constants;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xuboo on 2016/12/27 0027.
 */

public class SearchAdapter extends BaseAdapter implements Filterable {
    private Context context;
    public List<OrderListModel> orderListModels;
    public ArrayList<SearchDataItem> modules = new ArrayList<>();//匹配keyword
    private ArrayFilter mFilter;

    private String inputKeyWord = "";

    private String searchType = "0";

    public SearchAdapter(Context context, List<OrderListModel> orderListModels) {
        this.context = context;
        this.orderListModels = orderListModels;
    }


    public void setOrderListModels(List<OrderListModel> orderListModels) {
        this.orderListModels = orderListModels;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    @Override
    public int getCount() {
        return modules == null ? 0 : modules.size();

    }

    @Override
    public Object getItem(int position) {
        return modules.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.bill_search_hint_item, parent, false);
            holder.tv_item = (TextView) convertView.findViewById(R.id.tv_item);
            holder.tableNoLabel = convertView.findViewById(R.id.searchItem_tableNo_label);
            holder.orderNoLabel = convertView.findViewById(R.id.searchItem_orderNo_label);
            holder.splitLine = convertView.findViewById(R.id.searchItem_splitLine);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        if (modules != null && position < modules.size()) {
            SearchDataItem searchData = modules.get(position);
            //最后一行分界线不显示
            if (position == modules.size() - 1) {
                holder.splitLine.setVisibility(View.GONE);
            } else {
                holder.splitLine.setVisibility(View.VISIBLE);
            }
            //显示 订单号/桌台名标志
            if (searchData.isOrderNo) {
                holder.orderNoLabel.setVisibility(View.VISIBLE);
                holder.tableNoLabel.setVisibility(View.GONE);
            } else {
                holder.orderNoLabel.setVisibility(View.GONE);
                holder.tableNoLabel.setVisibility(View.VISIBLE);
            }
            String label = searchData.dataContent;
            String tempInputKeyWord = inputKeyWord;
            int index = label.indexOf(tempInputKeyWord);
            String start = "";
            if (index != -1) {
                start = label.substring(0, index);
            }

            if(start.length() + tempInputKeyWord.length() <= label.length()){
                String end = label.substring(start.length() + tempInputKeyWord.length(), label.length());
                holder.tv_item.setText(Html.fromHtml(start + "<u><font color= 'red' >" + tempInputKeyWord + "</font></u>" + end));
            }else{
                holder.tv_item.setText(label);
            }
        }
        return convertView;
    }


    private static class ViewHolder {
        public TextView tv_item;
        public View tableNoLabel;
        public View orderNoLabel;
        public View splitLine;
    }

    @Override
    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ArrayFilter();
        }
        return mFilter;
    }

    private class ArrayFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            if (TextUtils.isEmpty(constraint)) {//若输入为空
                results.values = null;
                results.count = 0;
            } else {//输入不为空
                inputKeyWord = constraint.toString();//将输入内容传出去
                LogUtil.log("inputKeyWord", inputKeyWord);
                ArrayList<SearchDataItem> values = new ArrayList<>();
                List<OrderListModel> orderList = new ArrayList<>();
                if (orderListModels != null) {
                    orderList.addAll(orderListModels);
                }
                if (!TextUtils.equals(searchType, "1")) {
                    for (OrderListModel orderListModel : orderList) {
//                    if (orderListModel.fiSellType == Constants.SELL_TYPE_FAST_FOOD) {
//                        if (orderListModel.mealNumber.contains(inputKeyWord) || orderListModel.orderID.contains(inputKeyWord)) {
//                            values.add(orderListModel.mealNumber + regex + orderListModel.orderID);
//                        }
//                    } else {
//                        if (orderListModel.fsmtablename.toUpperCase().contains(inputKeyWord.toUpperCase()) || orderListModel.orderID.contains(inputKeyWord)) {
//                            values.add(orderListModel.fsmtablename + regex + orderListModel.orderID);
//                        }
//                    }
                        if (orderListModel != null && !TextUtils.isEmpty(orderListModel.fsmtablename)) {
                            if (orderListModel.fsmtablename.toUpperCase().contains(inputKeyWord.toUpperCase())) {
                                //过滤掉重复的桌台名
                                if (!isTableNameExist(values, orderListModel.fsmtablename)) {
                                    values.add(new SearchDataItem(false, orderListModel.fsmtablename));
                                }
                            }
                        }
                    }
                }
                if (!TextUtils.equals(searchType, "0")) {
                    for (OrderListModel orderListModel : orderList) {
                        if (orderListModel != null && !TextUtils.isEmpty(orderListModel.orderID)) {
                            if (orderListModel.orderID.contains(inputKeyWord)) {
                                values.add(new SearchDataItem(true, orderListModel.orderID));
                            }
                        }
                    }
                }
                results.values = values;
                results.count = values.size();
            }
            return results;
        }

        /**
         * 过滤掉重复的桌台名
         *
         * @return
         */
        private boolean isTableNameExist(ArrayList<SearchDataItem> values, String newTableName) {
            for (SearchDataItem temp : values) {
                if (temp != null && TextUtils.equals(temp.dataContent, newTableName)) {
                    return true;
                }
            }
            return false;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            modules = (ArrayList<SearchDataItem>) results.values;
            notifyDataSetChanged();
        }
    }

    public String regex = "_";
}
