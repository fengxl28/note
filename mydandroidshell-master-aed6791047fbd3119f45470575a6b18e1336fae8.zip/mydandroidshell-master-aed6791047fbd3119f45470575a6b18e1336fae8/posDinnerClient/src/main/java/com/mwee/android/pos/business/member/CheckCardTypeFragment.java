package com.mwee.android.pos.business.member;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.mwee.android.pos.business.member.api.MemberApi;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.business.bean.CheckCardTypeResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TimeButton;
import com.mwee.android.tools.DateUtil;

/**
 * Created by lxx on 16/9/08.
 */
public class CheckCardTypeFragment extends BaseDialogFragment {
    public static final String FRAGMENT_TAG = CheckCardTypeFragment.class.getName();

    private RelativeLayout bind_ryt;

    /**
     * 会员卡号
     */
    private EditText cardNumberEdt;

    /**
     * 取消
     */
    private Button cancel;

    /**
     * 绑定
     */
    private Button next;

    private CheckCardTypeCallback callback;

    private String cardNumber = "";


    public void setCallback(CheckCardTypeCallback callback) {
        this.callback = callback;
    }

    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.next:
                    if (checkFormat()) {
                        ProgressManager.showProgress(getActivityWithinHost());
                        (new MemberProcess()).checkCardType(cardNumber, new IResponse<CheckCardTypeResponse>() {
                            @Override
                            public void callBack(boolean result, int code, String msg, CheckCardTypeResponse info) {
                                ProgressManager.closeProgress(getActivityWithinHost());
                                if (result) {
                                    dismiss();
                                    if (callback != null){
                                        callback.callback(cardNumber, info.type, info.msg);
                                    }
                                }else {
                                    ToastUtil.showToast(msg);
                                }
                            }

                        });
                    }
                    break;
                case R.id.cancel:
                    dismiss();
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.check_card_type_fragment_layout, container, false);
        setCancelable(true);
        initUI(contentView);
        registEvent();
        return contentView;
    }

    private void initUI(View contentView) {
        bind_ryt = contentView.findViewById(R.id.bind_ryt);
        cancel = contentView.findViewById(R.id.cancel);
        next = contentView.findViewById(R.id.next);
        cardNumberEdt = contentView.findViewById(R.id.thirdNumber);
    }

    private void registEvent() {
        bind_ryt.setOnClickListener(null);
        cancel.setOnClickListener(onClickListener);
        next.setOnClickListener(onClickListener);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    /**
     * @return 验证通过返回true
     * @author ：
     */
    public boolean checkFormat() {

        cardNumber = TextUtils.formatSpace(cardNumberEdt.getText().toString().trim());
        if (!TextUtils.validate(cardNumber)) {
            ToastUtil.showToast("请输入会员卡号");
            return false;
        }
        if (!RegexUtil.checkNumberLetter(cardNumber)) {
            ToastUtil.showToast("请输入正确的会员卡号");
            return false;
        }
        return true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}