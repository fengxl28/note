package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/18.
 */

public class MemberLevelUpdateRequest extends BaseMemberParam {
    public int level_id;
    public int m_shopid;
    public String title;
    public String up_rule;//会员升级规则
    public String down_rule;//会员降级规则
    public String up_reward;//升级奖励

    public MemberLevelUpdateRequest() {
    }
}
