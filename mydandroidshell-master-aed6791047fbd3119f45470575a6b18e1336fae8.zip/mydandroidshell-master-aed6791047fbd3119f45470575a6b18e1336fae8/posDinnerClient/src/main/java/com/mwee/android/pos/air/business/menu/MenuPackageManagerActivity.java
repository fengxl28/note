package com.mwee.android.pos.air.business.menu;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.air.connect.business.menu.MenuPackageItemsResponse;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideDtlBean;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.menu.dialog.MenuItemSetSideEditorFragment;
import com.mwee.android.pos.air.business.menu.dialog.MenuPackageEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.dialog.MenuPackageSetSideEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.processor.MenuPackageProcessor;
import com.mwee.android.pos.base.FragmentController;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardCallback;
import com.mwee.android.pos.business.personcount.CountKeyboardFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by qinwei on 2017/10/12.
 */

public class MenuPackageManagerActivity extends AirBaseActivity {
    private TitleBar mTitleBar;
    private RecyclerView mMenuPackageRecyclerView;

    private MenuItemPackageAdapter menuItemPackageAdapter;
    private MenuItemSetSideAdapter menuItemSetSideAdapter;
    private MenuPackageProcessor mMenuPackageProcessor;
    private RecyclerView mMenuPackageSetSideRecyclerView;

    private FrameLayout mEmptyLayout;
    private TextView tvEmptyCreateFirst;
    private LinearLayout mOperationTitleLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_package_manager);

        mEmptyLayout = findViewById(R.id.mEmptyLayout);
        tvEmptyCreateFirst = findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建套餐");
        tvEmptyCreateFirst.setOnClickListener(this);

        mTitleBar = findViewById(R.id.mTitleBar);
        mTitleBar.setTitle("套餐配置");
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });

        mOperationTitleLayout = findViewById(R.id.mOperationTitleLayout);


        findViewById(R.id.tvAddCategoryLabel).setOnClickListener(this);

        initData();
    }

    private void initData() {
        mMenuPackageProcessor = new MenuPackageProcessor();

        mMenuPackageRecyclerView = (RecyclerView) findViewById(R.id.mMenuPackageRecyclerView);
        mMenuPackageRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mMenuPackageRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        menuItemPackageAdapter = new MenuItemPackageAdapter();
        mMenuPackageRecyclerView.setAdapter(menuItemPackageAdapter);

        mMenuPackageSetSideRecyclerView = (RecyclerView) findViewById(R.id.mMenuPackageSetSideRecyclerView);
        mMenuPackageSetSideRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mMenuPackageSetSideRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        menuItemSetSideAdapter = new MenuItemSetSideAdapter();
        menuItemSetSideAdapter.isFooterShow = true;
        mMenuPackageSetSideRecyclerView.setAdapter(menuItemSetSideAdapter);

        loadDataFromServer();
    }

    private void loadDataFromServer() {
        mMenuPackageProcessor.loadMenuPackageItems(true, new ResultCallback<MenuPackageItemsResponse>() {
            @Override
            public void onSuccess(MenuPackageItemsResponse data) {
                refreshMenuPackageList(data.menuItemBeanList);
                refreshMenuPackageSetSideList(data.menuPackageSetSideBeanList);
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }

    /**
     * 获取套餐数据
     *    然后跳转到最后一个条目并选中
     */
    private void loadSmoothDataFromServer() {
        mMenuPackageProcessor.loadMenuPackageItems(true, new ResultCallback<MenuPackageItemsResponse>() {
            @Override
            public void onSuccess(MenuPackageItemsResponse data) {
                menuItemPackageAdapter.selectPosition = data.menuItemBeanList.size() - 1;
                refreshMenuPackageList(data.menuItemBeanList);

                loadMenuPackageSetSidesByMenuId();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
            }
        });
    }


    private void refreshMenuPackageList(List<MenuItemBean> menuItemBeanList) {
        menuItemPackageAdapter.modules.clear();
        menuItemPackageAdapter.modules.addAll(menuItemBeanList);
        menuItemPackageAdapter.notifyDataSetChanged();

        mEmptyLayout.setVisibility(ListUtil.isEmpty(menuItemBeanList) ? View.VISIBLE : View.GONE);

    }

    private void refreshMenuPackageSetSideList(List<MenuPackageSetSideBean> menuPackageSetSideBeanList) {
        menuItemSetSideAdapter.modules.clear();
        menuItemSetSideAdapter.modules.addAll(menuPackageSetSideBeanList);
        menuItemSetSideAdapter.notifyDataSetChanged();

        mOperationTitleLayout.setVisibility(ListUtil.isEmpty(menuPackageSetSideBeanList) ? View.GONE : View.VISIBLE);

    }

    @Override
    protected void handlerClickEvent(View v) {

        switch (v.getId()) {
            case R.id.tvEmptyCreateFirst:
            case R.id.tvAddCategoryLabel:
                showMenuPackageAdd();
                break;
            default:
                break;
        }
    }


    /*----------------------------------------套餐菜品操作------------------------------------------------*/
    class MenuItemPackageAdapter extends BaseListAdapter<MenuItemBean> {
        int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuPackageHolder(LayoutInflater.from(MenuPackageManagerActivity.this).inflate(R.layout.air_category_item_layout, parent, false));
        }

        public MenuItemBean getCurrentMenuPackage() {
            if (modules.size() > 0) {
                return modules.get(selectPosition);
            }
            return null;
        }

        class MenuPackageHolder extends BaseViewHolder implements View.OnClickListener {

            private int position;

            private LinearLayout tvCategoryLayout;
            private TextView tvCategoryName;
            private TextView tvCategoryPrice;
            private ImageView iconDelete;
            private ImageView iconTop;
            private ImageView iconEditor;

            public MenuPackageHolder(View itemView) {
                super(itemView);

                tvCategoryLayout = itemView.findViewById(R.id.tvCategoryLayout);
                tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
                tvCategoryPrice = itemView.findViewById(R.id.tvCategoryPrice);
                iconDelete = itemView.findViewById(R.id.iconDelete);
                iconTop = itemView.findViewById(R.id.iconTop);
                iconEditor = itemView.findViewById(R.id.iconEditor);

                //tvCategoryName.setOnClickListener(this);
                tvCategoryLayout.setOnClickListener(this);
                iconDelete.setOnClickListener(this);
                iconEditor.setOnClickListener(this);

            }

            @Override
            public void bindData(int position) {
                this.position = position;
                MenuItemBean menuItem = modules.get(position);

                tvCategoryName.setText(menuItem.fsItemName);
                tvCategoryPrice.setVisibility(View.VISIBLE);
                tvCategoryPrice.setText("" + menuItem.fdSalePrice);
                if (position == selectPosition) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_air_category_item_checked);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                }
                iconTop.setVisibility(View.GONE);
                if (position == selectPosition) {
                    iconDelete.setVisibility(View.VISIBLE);
                    iconEditor.setVisibility(View.VISIBLE);
                } else {
                    iconDelete.setVisibility(View.GONE);
                    iconEditor.setVisibility(View.GONE);
                }
            }

            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.tvCategoryLayout:
                        if (selectPosition != position) {
                            selectPosition = position;
                            loadMenuPackageSetSidesByMenuId();
                            menuItemPackageAdapter.notifyDataSetChanged();
                        }
                        break;
                    case R.id.iconDelete:
                        LogUtil.log("MenuClsAdapter delete");
                        doDelete();
                        break;
                    case R.id.iconEditor:
                        LogUtil.log("MenuClsAdapter editor");
                        showMenuPackageEditor();
                        break;
                    default:
                        break;
                }

            }
        }
    }

    /**
     * 通过套餐菜品 获取到套餐明细数据
     */
    private void loadMenuPackageSetSidesByMenuId() {
        mMenuPackageProcessor.loadMenuPackageSetSidesByMenuId(menuItemPackageAdapter.getCurrentMenuPackage().fiItemCd, new ResultCallback<List<MenuPackageSetSideBean>>() {
            @Override
            public void onSuccess(List<MenuPackageSetSideBean> data) {
                refreshMenuPackageSetSideList(data);
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
            }
        });
    }

    private void doDelete() {
        DialogManager.showExecuteDialog(getActivityWithinHost(),
                "确定删除该套餐吗？",
                getStringWithinHost(R.string.cacel),
                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                    @Override
                    public void response() {
                        final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
                        mMenuPackageProcessor.loadDeletePackageMenuItem(menuItemPackageAdapter.getCurrentMenuPackage().fiItemCd, new ResultCallback<String>() {

                            @Override
                            public void onSuccess(String data) {
                                progress.dismissSelf();
                                ToastUtil.showToast(data);
                                menuItemPackageAdapter.modules.remove(menuItemPackageAdapter.getCurrentMenuPackage());
                                menuItemPackageAdapter.selectPosition = 0;
                                loadDataFromServer();
                            }

                            @Override
                            public void onFailure(int code, String msg) {
                                progress.dismissSelf();
                                ToastUtil.showToast(msg);
                            }
                        });
                    }
                }, null);

    }


    private void showMenuPackageAdd() {
        MenuPackageEditorDialogFragment dialog = new MenuPackageEditorDialogFragment();
        dialog.setOnMenuPackageAddListener(new MenuPackageEditorDialogFragment.OnMenuPackageAddListener() {
            @Override
            public void onMenuPackageAddSuccess() {
                LogUtil.log("onMenuPackageAddSuccess");
                //loadDataFromServer();
                loadSmoothDataFromServer();
            }

            @Override
            public void onMenuPackageUpdateSuccess() {
                LogUtil.log("onMenuPackageUpdateSuccess");
            }
        });
        DialogManager.showCustomDialog(this, dialog, "MenuPackageEditorDialogFragment");
    }

    //编辑套餐头
    private void showMenuPackageEditor() {

        MenuPackageEditorDialogFragment dialog = new MenuPackageEditorDialogFragment();
        dialog.setEditorParams(menuItemPackageAdapter.getCurrentMenuPackage());
        dialog.setOnMenuPackageAddListener(new MenuPackageEditorDialogFragment.OnMenuPackageAddListener() {
            @Override
            public void onMenuPackageAddSuccess() {
                LogUtil.log("onMenuPackageAddSuccess");
            }

            @Override
            public void onMenuPackageUpdateSuccess() {
                LogUtil.log("onMenuPackageUpdateSuccess");
                loadDataFromServer();

            }
        });
        DialogManager.showCustomDialog(this, dialog, "MenuPackageEditorDialogFragment");

    }





    /*----------------------------------------套餐明细操作------------------------------------------------*/

    class MenuItemSetSideAdapter extends BaseListAdapter<MenuPackageSetSideBean> {

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuItemSetSideHolder(LayoutInflater.from(MenuPackageManagerActivity.this).inflate(R.layout.view_package_set_side_item, parent, false));
        }

        @Override
        protected View onCreateFooterView(ViewGroup parent) {
            View view = LayoutInflater.from(MenuPackageManagerActivity.this).inflate(R.layout.view_menu_package_footer_add, parent, false);
            Button mSetSideItemAddBtn = view.findViewById(R.id.mSetSideItemAddBtn);
            mSetSideItemAddBtn.setText("添加分组");
            mSetSideItemAddBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSetSideAddGroupDialog();
                }
            });
            return view;
        }

        class MenuItemSetSideHolder extends BaseViewHolder implements View.OnClickListener {
            private TextView mSetSideItemNameGroupLabel;//分组名称
            private TextView mSetSideItemNameLabel;
            private TextView mSetSideItemSizeLabel;
            private TextView mSetSideItemChoiceSizeBtn;
            private ImageView mSetSideItemEditorBtn;
            private ImageView mSetSideItemDeleteBtn;
            private MenuPackageSetSideBean model;

            public MenuItemSetSideHolder(View v) {
                super(v);
                mSetSideItemNameGroupLabel = v.findViewById(R.id.mSetSideItemNameGroupLabel);
                mSetSideItemNameLabel = v.findViewById(R.id.mSetSideItemNameLabel);
                mSetSideItemSizeLabel = v.findViewById(R.id.mSetSideItemSizeLabel);
                mSetSideItemChoiceSizeBtn = v.findViewById(R.id.mSetSideItemChoiceSizeBtn);
                mSetSideItemEditorBtn = v.findViewById(R.id.mSetSideItemEditorBtn);
                mSetSideItemDeleteBtn = v.findViewById(R.id.mSetSideItemDeleteBtn);

                mSetSideItemNameGroupLabel.setOnClickListener(this);
                mSetSideItemNameLabel.setOnClickListener(this);
                mSetSideItemEditorBtn.setOnClickListener(this);
                mSetSideItemDeleteBtn.setOnClickListener(this);
                mSetSideItemChoiceSizeBtn.setOnClickListener(this);
            }

            @Override
            public void bindData(int position) {
                model = modules.get(position);

                mSetSideItemNameGroupLabel.setText(model.fsSetFoodName);
                if (!TextUtils.isEmpty(model.fsSetFoodNameMenuItemDtal)) {
                    mSetSideItemNameLabel.setText(model.fsSetFoodNameMenuItemDtal);
                } else {
                    mSetSideItemNameLabel.setText("+添加菜品");
                }
                mSetSideItemSizeLabel.setText("" + model.choiceMenuItems.size());
                mSetSideItemChoiceSizeBtn.setText(model.fiSetFoodQty + "");
            }

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.mSetSideItemNameGroupLabel:
                        showSetSideEditorGroupDialog(model);
                        LogUtil.log("编辑套餐分组名称");
                        break;
                    case R.id.mSetSideItemNameLabel:
                        LogUtil.log("套餐分组添加菜品");
                        showSetSideEditorDialog(model);
                        break;
                    case R.id.mSetSideItemEditorBtn:
                        showSetSideEditorDialog(model);
                        break;
                    case R.id.mSetSideItemDeleteBtn:
                        showSetSideDeleteDialog(model);
                        break;
                    case R.id.mSetSideItemChoiceSizeBtn:
                        showSetSideSetFoodQtyDialog(model);
                        break;
                    default:
                        break;
                }
            }
        }

    }

    /**
     * 添加套餐分组
     */
    private void showSetSideAddGroupDialog() {

        MenuPackageSetSideEditorDialogFragment dialogFragment = new MenuPackageSetSideEditorDialogFragment();
        dialogFragment.setMenuItemBean(menuItemPackageAdapter.getCurrentMenuPackage());
        dialogFragment.setModel(MenuPackageSetSideEditorDialogFragment.ADD_MODEL);
        dialogFragment.setOnMenuPackageAddListener(new MenuPackageSetSideEditorDialogFragment.OnMenuPackageSetSideAddListener() {
            @Override
            public void onMenuPackageSetSideAddSuccess() {
                loadMenuPackageSetSidesByMenuId();
            }

            @Override
            public void onMenuPackageSetSideEditorSuccess() {

            }
        });
        DialogManager.showCustomDialog(this, dialogFragment, "MenuPackageSetSideEditorDialogFragment");
    }


    /**
     * 编辑套餐分组
     */
    private void showSetSideEditorGroupDialog(MenuPackageSetSideBean menuPackageSetSideBean) {

        MenuPackageSetSideEditorDialogFragment dialogFragment = new MenuPackageSetSideEditorDialogFragment();
        dialogFragment.setMenuItemBean(menuItemPackageAdapter.getCurrentMenuPackage());
        dialogFragment.setMenuPackageSetSideBean(menuPackageSetSideBean);
        dialogFragment.setModel(MenuPackageSetSideEditorDialogFragment.EDITOR_MODEL);
        dialogFragment.setOnMenuPackageAddListener(new MenuPackageSetSideEditorDialogFragment.OnMenuPackageSetSideAddListener() {
            @Override
            public void onMenuPackageSetSideAddSuccess() {
            }

            @Override
            public void onMenuPackageSetSideEditorSuccess() {
                loadMenuPackageSetSidesByMenuId();
            }
        });
        DialogManager.showCustomDialog(this, dialogFragment, "MenuPackageSetSideEditorDialogFragment");
    }

    private void showSetSideEditorDialog(MenuPackageSetSideBean model) {


        MenuItemSetSideEditorFragment menuItemSetSideEditorFragment = new MenuItemSetSideEditorFragment();
        menuItemSetSideEditorFragment.setParam(model);
        menuItemSetSideEditorFragment.setOnMenuItemSetSideEditorListener(new MenuItemSetSideEditorFragment.OnMenuItemSetSideEditorListener() {

            @Override
            public void onOnMenuItemSetSideUpdateSuccess() {
                doSave();
            }

            @Override
            public void onOnMenuItemSetSideAddSuccess(List<MenuPackageSetSideDtlBean> choiceItems) {

            }

        });
        FragmentController.addFragment(getActivityWithinHost(), menuItemSetSideEditorFragment);
    }


    private void showSetSideDeleteDialog(final MenuPackageSetSideBean model) {
        DialogManager.showExecuteDialog(getActivityWithinHost(),
                "是否确认删除？",
                getStringWithinHost(R.string.cacel),
                getStringWithinHost(R.string.confirm), new DialogResponseListener() {
                    @Override
                    public void response() {
//                        if (model.fiSetFoodCd > 0) {
                        if (StringUtil.toInt(model.fiSetFoodCd, 0) > 0) {
                            final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), R.string.progress_loading);
                            mMenuPackageProcessor.loadDeleteMenuItemSetSide(model.fiSetFoodCd, new ResultCallback<String>() {
                                @Override
                                public void onSuccess(String data) {
                                    menuItemSetSideAdapter.modules.remove(model);
                                    menuItemSetSideAdapter.notifyDataSetChanged();
                                    ToastUtil.showToast(data);
                                    progress.dismissSelf();
                                }

                                @Override
                                public void onFailure(int code, String msg) {
                                    ToastUtil.showToast(msg);
                                    progress.dismissSelf();
                                }
                            });
                        } else {
                            menuItemSetSideAdapter.modules.remove(model);
                            menuItemSetSideAdapter.notifyDataSetChanged();
                        }

                    }
                }, null);
    }


    /**
     * 设置套餐组选择数量
     *
     * @param model 套餐组成项数据模型
     */
    private void showSetSideSetFoodQtyDialog(final MenuPackageSetSideBean model) {
        CountKeyboardFragment fragment = new CountKeyboardFragment();
        fragment.setTitle("请输入选择数量");
        fragment.setOriginCount(model.fiSetFoodQty);
        fragment.setCallback(new CountKeyboardCallback() {
            @Override
            public void callback(BigDecimal originNum, BigDecimal newNum) {
                model.fiSetFoodQty = newNum.intValue();
                doSave();
                //menuItemSetSideAdapter.notifyDataSetChanged();
            }
        });
        DialogManager.showCustomDialog(this, fragment, "fragment");
    }


    /**
     * 保存套餐信息
     */
    private void doSave() {

        final Progress progress = ProgressManager.showProgressUncancel(this, R.string.progress_loading);
        mMenuPackageProcessor.loadUpdatePackageMenu(menuItemPackageAdapter.getCurrentMenuPackage().fiItemCd, menuItemPackageAdapter.getCurrentMenuPackage().fsItemName, menuItemPackageAdapter.getCurrentMenuPackage().fdSalePrice + "", menuItemSetSideAdapter.modules, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                ToastUtil.showToast(data);
                progress.dismissSelf();
                loadMenuPackageSetSidesByMenuId();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                progress.dismissSelf();
            }
        });
    }


}
