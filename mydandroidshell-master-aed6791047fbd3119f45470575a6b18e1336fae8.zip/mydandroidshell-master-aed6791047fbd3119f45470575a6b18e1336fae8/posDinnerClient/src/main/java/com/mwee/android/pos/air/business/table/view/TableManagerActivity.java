package com.mwee.android.pos.air.business.table.view;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.table.dialog.EditAreaDialog;
import com.mwee.android.pos.air.business.table.processor.TableManagerProcessor;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;


/**
 * Created by zhangmin on 2017/12/21.
 * 桌台管理界面
 */

public class TableManagerActivity extends AirBaseActivity {

    private TitleBar mTitleBar;

    private RecyclerView area_RecyclerView;
    private RecyclerView table_RecyclerView;

    private AreaAdapter areaAdapter;
    private TableAdapter tableAdapter;

    private TableManagerProcessor tableManagerProcessor;

    /**
     * 当前选中的餐区Index
     */
    private int selectAreaIndex = 0;


    private LinearLayout mOperationAddLayout;
    private TextView tvAdd;
    private TextView tvBatchDelete;

    private LinearLayout mOperationDeleteLayout;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchCancelBtn;
    private TextView mAskBatchDeleteBtn;
    private TextView tvAddCategoryLabel;


    private FrameLayout mEmptyLayout;
    private TextView tvEmptyCreateFirst;

    private TextView mClsEmptyLabel;
    private TextView mBatchChoiceValueLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air_table_manager_activity);
        tableManagerProcessor = new TableManagerProcessor();

        initUI();
        initButtomLayut();
        initData();
    }


    private void initUI() {

        mEmptyLayout = findViewById(R.id.mEmptyLayout);
        tvEmptyCreateFirst = findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建区域");
        tvEmptyCreateFirst.setOnClickListener(this);

        mClsEmptyLabel = findViewById(R.id.mClsEmptyLabel);

        mTitleBar = findViewById(R.id.mTitleBar);
        mTitleBar.setTitle("桌台管理");
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });

        tvAddCategoryLabel = findViewById(R.id.tvAddCategoryLabel);
        tvAddCategoryLabel.setText("新建区域");
        tvAddCategoryLabel.setOnClickListener(this);

        //桌台
        table_RecyclerView = findViewById(R.id.table_RecyclerView);
        table_RecyclerView.setLayoutManager(new LinearLayoutManager(this));
        table_RecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        tableAdapter = new TableAdapter();
        table_RecyclerView.setAdapter(tableAdapter);

        //餐区
        area_RecyclerView = findViewById(R.id.area_RecyclerView);
        area_RecyclerView.setLayoutManager(new LinearLayoutManager(this));
        area_RecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        areaAdapter = new AreaAdapter();
        area_RecyclerView.setAdapter(areaAdapter);


    }


    /**
     * 初始化底部bottom
     */
    private void initButtomLayut() {

        mOperationAddLayout = findViewById(R.id.mOperationAddLayout);
        tvAdd = findViewById(R.id.tvAdd);
        tvAdd.setText("新建桌台");
        tvAdd.setOnClickListener(this);
        tvBatchDelete = findViewById(R.id.tvBatchDelete);
        tvBatchDelete.setOnClickListener(this);

        mBatchChoiceValueLabel = findViewById(R.id.mBatchChoiceValueLabel);
        mOperationDeleteLayout = findViewById(R.id.mOperationDeleteLayout);
        mAskBatchChoiceAllLabel = findViewById(R.id.mAskBatchChoiceAllLabel);
        mAskBatchCancelBtn = findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn = findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchDeleteBtn.setOnClickListener(this);

    }

    /**
     * 去业务中心获取数据
     */
    public void initData() {

        ProgressManager.closeProgress(this);
        tableManagerProcessor.optAllAreaAndTable(new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(TableManagerActivity.this);
                if (!result) {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "数据获取失败，请重试");
                } else {
                    refreshArea();
                    refreshTable();
                }
            }
        });
    }


    /**
     * 刷新餐区
     */
    private void refreshArea() {

        if (selectAreaIndex >= tableManagerProcessor.airAreaManagerInfoList.size()) {
            selectAreaIndex = 0;
        }
        tableManagerProcessor.selectArea(selectAreaIndex);
        areaAdapter.modules = tableManagerProcessor.airAreaManagerInfoList;
        areaAdapter.notifyDataSetChanged();

        mEmptyLayout.setVisibility(ListUtil.isEmpty(tableManagerProcessor.airAreaManagerInfoList) ? View.VISIBLE : View.GONE);
    }


    /**
     * 刷新桌台数据
     */
    private void refreshTable() {

        tableAdapter.modules.clear();
        tableAdapter.modules.addAll(tableManagerProcessor.tableManageInfoToShowList);
        tableAdapter.notifyDataSetChanged();


        /**
         * 当前分类下 没有任何桌台时候
         *   1 显示美容点提示界面
         *   2 批量删除按钮不显示
         *   3 删除模式 底部显示添加布局
         */
        mClsEmptyLabel.setVisibility(ListUtil.isEmpty(tableManagerProcessor.tableManageInfoToShowList) ? View.VISIBLE : View.GONE);

        tvBatchDelete.setVisibility(ListUtil.isEmpty(tableManagerProcessor.tableManageInfoToShowList) ? View.GONE : View.VISIBLE);

        if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
            mOperationAddLayout.setVisibility(ListUtil.isEmpty(tableManagerProcessor.tableManageInfoToShowList) ? View.VISIBLE : View.GONE);
            mOperationDeleteLayout.setVisibility(ListUtil.isEmpty(tableManagerProcessor.tableManageInfoToShowList) ? View.GONE : View.VISIBLE);
        }
        refreshChoiceMenuCount();


    }


    /**
     * 刷新选中菜品个数显示
     */
    private void refreshChoiceMenuCount() {

        mBatchChoiceValueLabel.setText(String.format("选中%s个", choiceStates.size()));

    }


    /**
     * 刷新餐区和桌台
     */
    private void refreshUI() {

        refreshArea();
        refreshTable();
    }



    /*--------------------------桌台全选删除的操作---------------------------------*/

    private ArrayList<String> choiceStates = new ArrayList<>();

    /**
     * 单选一个菜品
     *
     * @param value
     */
    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }


    /**
     * 判断是否全选
     *
     * @return
     */
    private boolean isChoiceAll() {
        for (int i = 0; i < tableAdapter.modules.size(); i++) {
            if (!choiceStates.contains(tableAdapter.modules.get(i).fsmtableid + "")) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选
     */
    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < tableAdapter.modules.size(); i++) {
            choiceStates.add(tableAdapter.modules.get(i).fsmtableid + "");
        }
    }

    /**
     * 清除全选
     */
    private void cancelChoiceAll() {
        choiceStates.clear();
    }


    class AreaAdapter extends BaseListAdapter<AirAreaManagerInfo> {


        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new AreaHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.air_category_item_layout, parent, false));
        }

        class AreaHolder extends BaseViewHolder implements View.OnClickListener {

            private LinearLayout tvCategoryLayout;
            private TextView tvCategoryName;

            private ImageView iconDelete;
            private ImageView iconTop;
            private ImageView iconEditor;
            private int position;

            public AreaHolder(View itemView) {
                super(itemView);
                tvCategoryLayout = itemView.findViewById(R.id.tvCategoryLayout);
                tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
                iconDelete = itemView.findViewById(R.id.iconDelete);
                iconTop = itemView.findViewById(R.id.iconTop);
                iconEditor = itemView.findViewById(R.id.iconEditor);

                tvCategoryLayout.setOnClickListener(this);
                iconDelete.setOnClickListener(this);
                //iconTop.setOnClickListener(this);
                iconEditor.setOnClickListener(this);
            }


            @Override
            public void bindData(int position) {

                this.position = position;

                AirAreaManagerInfo askgpDBModel = modules.get(position);
                tvCategoryName.setText(askgpDBModel.fsMAreaName);

                if (position == selectAreaIndex) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_air_category_item_checked);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.system_red));
                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                }

                iconTop.setVisibility(View.GONE);
                if (position == selectAreaIndex && TextUtils.validate(askgpDBModel.fsMAreaId)) {
                    iconDelete.setVisibility(View.VISIBLE);
                    iconEditor.setVisibility(View.VISIBLE);
                    //iconTop.setVisibility(View.VISIBLE);

                } else {
                    iconDelete.setVisibility(View.GONE);
                    //iconTop.setVisibility(View.GONE);
                    iconEditor.setVisibility(View.GONE);
                }

            }


            @Override
            public void onClick(View v) {

                switch (v.getId()) {

                    case R.id.tvCategoryLayout:
                        if (selectAreaIndex != position) {
                            mOperationAddLayout.setVisibility(View.VISIBLE);
                            mOperationDeleteLayout.setVisibility(View.GONE);
                            mAskBatchChoiceAllLabel.setSelected(false);
                            cancelChoiceAll();

                            selectAreaIndex = position;
                            areaAdapter.notifyDataSetChanged();
                            //修改当前餐区对应的桌台数据 刷新桌台
                            tableManagerProcessor.selectArea(selectAreaIndex);
                            refreshTable();
                        }
                        break;
                    case R.id.iconDelete:
                        //doDelete();
                        ActionLog.addLog("桌台管理页面--->点击了分类删除", "", "", ActionLog.SS_MORE_JOIN, "");
                        doTableClsDelete();
                        break;
                    case R.id.iconTop:
                        ActionLog.addLog("桌台管理页面--->点击了分类置顶", "", "", ActionLog.SS_MORE_JOIN, "");
                        break;
                    case R.id.iconEditor:
                        ActionLog.addLog("桌台管理页面--->点击了分类编辑", "", "", ActionLog.SS_MORE_JOIN, "");
                        showAreaEditorDialog();
                        break;
                    default:
                        break;
                }
            }
        }


    }

    /**
     * 删除桌台分类
     */
    private void doTableClsDelete() {

        final AirAreaManagerInfo airAreaManagerInfo = tableManagerProcessor.airAreaManagerInfoList.get(selectAreaIndex);
        if (airAreaManagerInfo.allTableInUse > 0) {
            ToastUtil.showToast("该餐区下有桌台正在被占用");
            return;
        }

        DialogManager.showExecuteDialog(getActivityWithinHost(), "确定删除该区域吗?", new DialogResponseListener() {
            @Override
            public void response() {

                ProgressManager.showProgress(getActivityWithinHost());
                tableManagerProcessor.deleteArea(airAreaManagerInfo.fsMAreaId, new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (result) {
                            selectAreaIndex = 0;//删除餐区以后  回到全部
                            ToastUtil.showToast("删除成功");
                            refreshUI();
                        } else {
                            ToastUtil.showToast(TextUtils.validate(info) ? info : "删除区域失败");

                        }
                    }
                });
            }
        });


    }

    class TableAdapter extends BaseListAdapter<AirTableManageInfo> {


        private int selectPostiton = 0;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new TableHolder(LayoutInflater.from(getContextWithinHost()).inflate(R.layout.view_ask_item, parent, false));
        }


        class TableHolder extends BaseViewHolder implements View.OnClickListener {

            private TextView tvItemCheck;
            private TextView mAskNameLabel;
            private TextView mAskPriceLabel;
            private AirTableManageInfo model;
            private TextView tvSubMind;
            private int position = 0;

            public TableHolder(View v) {
                super(v);
                mAskNameLabel = v.findViewById(R.id.mAskNameLabel);
                mAskPriceLabel = v.findViewById(R.id.mAskPriceLabel);
                tvSubMind = v.findViewById(R.id.tvSubMind);
                tvItemCheck = v.findViewById(R.id.tvItemCheck);

                tvItemCheck.setOnClickListener(this);
                v.setOnClickListener(this);
            }


            @Override
            public void bindData(int position) {

                this.position = position;
                model = modules.get(position);

                mAskNameLabel.setText(model.fsmtablename);
                mAskPriceLabel.setText(String.format("%s人桌", model.fiseats));

                if (model.fisharebillsInUse > 0 || android.text.TextUtils.equals(model.fsmtablesteid, "2")) {
                    mAskNameLabel.setTextColor(getResources().getColor(R.color.color_c6c6c6));
                    tvSubMind.setVisibility(View.VISIBLE);
                } else {
                    mAskNameLabel.setTextColor(getResources().getColor(R.color.color_363636));
                    tvSubMind.setVisibility(View.GONE);
                }

                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
                    tvItemCheck.setVisibility(View.VISIBLE);
                    if (choiceStates.contains(String.valueOf(model.fsmtableid))) {
                        tvItemCheck.setSelected(true);
                    } else {
                        tvItemCheck.setSelected(false);
                    }
                } else {
                    tvItemCheck.setVisibility(View.INVISIBLE);
                }


                if (position == selectPostiton) {
                    itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FFD2CB));
                } else {
                    itemView.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));
                }
            }


            @Override
            public void onClick(View v) {

                selectPostiton = position;
                notifyDataSetChanged();

                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为菜品删除模式 不触发编辑菜品事件
                    choice(model.fsmtableid);
                    notifyDataSetChanged();
                    refreshChoiceMenuCount();
                    mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
                } else {
                    EditTableFragment dialog = new EditTableFragment();
                    dialog.setAreaSouce(tableManagerProcessor.airAreaManagerInfoWhisoutAllList);
                    dialog.setParam(model.fsmareaid, tableManagerProcessor, model);
                    dialog.setOnEditTableListener(onEditTableListener);
                    dialog.show(getFragmentManagerWithinHost(), "EditTableFragment");
                }
            }
        }

    }


    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.tvEmptyCreateFirst:
            case R.id.tvAddCategoryLabel:
                ActionLog.addLog("桌台管理页面--->点击了新建分组", "", "", ActionLog.SS_MORE_JOIN, "");
                showAreaAddDialog();
                break;
            case R.id.tvAdd:
                ActionLog.addLog("桌台管理页面--->点击了新建桌台", "", "", ActionLog.SS_MORE_JOIN, "");
                showAddTableDialog();
                break;
            case R.id.tvBatchDelete:
                ActionLog.addLog("桌台管理页面--->点击了批量删除", "", "", ActionLog.SS_MORE_JOIN, "");
                mOperationAddLayout.setVisibility(View.GONE);
                mOperationDeleteLayout.setVisibility(View.VISIBLE);
                tableAdapter.notifyDataSetChanged();
                break;
            case R.id.mAskBatchChoiceAllLabel://全选
                ActionLog.addLog("桌台管理页面--->点击了全选", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickAll();
                break;
            case R.id.mAskBatchCancelBtn://取消
                ActionLog.addLog("桌台管理页面--->点击了取消", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickCancel();
                break;
            case R.id.mAskBatchDeleteBtn://删除
                ActionLog.addLog("桌台管理页面--->点击了删除", "", "", ActionLog.SS_MORE_JOIN, "");
                doClickDelete();

                break;
            default:
                break;
        }
    }

    /**
     * 全选
     */
    private void doClickAll() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        tableAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();
    }


    /**
     * 取消
     */
    private void doClickCancel() {
        mOperationAddLayout.setVisibility(View.VISIBLE);
        mOperationDeleteLayout.setVisibility(View.GONE);
        cancelChoiceAll();
        mAskBatchChoiceAllLabel.setSelected(false);
        tableAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();
    }

    /**
     * 删除桌台
     */
    private void doClickDelete() {
        if (choiceStates.isEmpty()) {
            ToastUtil.showToast("请先选择桌台");
            return;
        }
        String content = "";
        if (choiceStates.size() == 1) {
            content = "确定删除该桌台吗?";
        } else {
            content = String.format("确定删除这%s个桌台吗?", choiceStates.size());
        }

        DialogManager.showExecuteDialog(getActivityWithinHost(), content, new DialogResponseListener() {
            @Override
            public void response() {

                ProgressManager.showProgress(getActivityWithinHost());
                tableManagerProcessor.batchDeleteTable(choiceStates, new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(getActivityWithinHost());
                        if (result) {
                            //删除完成 释放choice
                            choiceStates.clear();
                            mAskBatchChoiceAllLabel.setSelected(false);

                            refreshUI();
                        } else {
                            ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? getResources().getString(R.string.tip_delete_error) : info);
                        }
                    }
                });

            }
        });
    }


    /**
     * 餐区变动监听回调
     */
    EditAreaDialog.OnAreaEditorListener onAreaEditorListener = new EditAreaDialog.OnAreaEditorListener() {
        @Override
        public void onAddSuccess(MareaDBModel mareaDBModel, ArrayList<MtableSimpleModel> newTableDBModels) {
            selectAreaIndex = tableManagerProcessor.airAreaManagerInfoList.size() - 1;//添加餐区的时候 默认选到最后一个
            refreshUI();
        }

        @Override
        public void onUpdateSuccess(String name) {
            refreshUI();
        }

    };

    /**
     * 新增区域
     */
    private void showAreaAddDialog() {
        EditAreaDialog dialog = new EditAreaDialog();
        dialog.setParam(null, tableManagerProcessor);
        dialog.setOnAreaEditorListener(onAreaEditorListener);
        DialogManager.showCustomDialog(this, dialog, "EditAreaDialog");
    }

    /**
     * 编辑区域--修改餐区名称、删除餐区
     */
    private void showAreaEditorDialog() {

        AirAreaManagerInfo airAreaManagerInfo = tableManagerProcessor.airAreaManagerInfoList.get(selectAreaIndex);

        EditAreaDialog dialog = new EditAreaDialog();
        dialog.setParam(airAreaManagerInfo, tableManagerProcessor);
        dialog.setOnAreaEditorListener(onAreaEditorListener);
        DialogManager.showCustomDialog(this, dialog, "EditAreaDialog");
    }


    /**
     * 新增桌台
     */
    private void showAddTableDialog() {
        if (ListUtil.isEmpty(tableManagerProcessor.airAreaManagerInfoWhisoutAllList)) {
            ToastUtil.showToast("请先新增区域");
            return;
        }
        String currentAreaId = "";
        if (selectAreaIndex > 0 && selectAreaIndex < tableManagerProcessor.airAreaManagerInfoList.size()) {
            AirAreaManagerInfo airAreaManagerInfo = tableManagerProcessor.airAreaManagerInfoList.get(selectAreaIndex);
            if (airAreaManagerInfo != null) {
                currentAreaId = airAreaManagerInfo.fsMAreaId;
            }
        }
        EditTableFragment dialog = new EditTableFragment();
        dialog.setAreaSouce(tableManagerProcessor.airAreaManagerInfoWhisoutAllList);
        dialog.setParam(currentAreaId, tableManagerProcessor);
        dialog.setOnEditTableListener(onEditTableListener);
        dialog.show(getFragmentManagerWithinHost(), "EditTableFragment");
    }


    EditTableFragment.OnEditTableListener onEditTableListener = new EditTableFragment.OnEditTableListener() {

        @Override
        public void onEditorSuccess(MtableSimpleModel data) {
            LogUtil.log("onEditorSuccess");
            refreshUI();
        }

        @Override
        public void onUpdateSuccess(MtableSimpleModel data) {
            LogUtil.log("onUpdateSuccess");
            refreshUI();
        }

        @Override
        public void onDeleteSuccess() {
            LogUtil.log("onDeleteSuccess");
            refreshUI();
        }
    };

}
