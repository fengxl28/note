package com.mwee.android.pos.business.backup;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.base.BaseActivity;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.business.sync.ClientBindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * 还原数据的Activity
 * Created by virgil on 2017/6/29.
 */

public class RestoreDataActivity extends BaseActivity {
    private final int FILE_SELECT_CODE = 3291;
    private final int SELECT_BACKUP_PATH = 3292;
    private View.OnClickListener click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.select_restore_path:
                    showChooser(FILE_SELECT_CODE);
                    break;
                case R.id.auto_restore:
                    DialogManager.showSingleDialog(RestoreDataActivity.this, "请插入设备，并将备份文件放到设备根目录，或者保持在原来的备份目录", "", "", new DialogResponseListener() {
                        @Override
                        public void response() {
                            startAutoRestore();
                        }
                    });
                    break;
                case R.id.manualBack:
                    if (ClientBindProcessor.isCurrentHostMain()) {
                        startBackUp();
                    } else {
                        ToastUtil.showToast("你应该在主站点操作");
                    }
                    break;
            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_restore_data);
    }

    @Override
    protected void onStart() {
        super.onStart();
        findViewById(R.id.select_restore_path).setOnClickListener(click);
        findViewById(R.id.manualBack).setOnClickListener(click);
        findViewById(R.id.auto_restore).setOnClickListener(click);
    }


    private void showChooser(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(
                    Intent.createChooser(intent, "请选择"),
                    requestCode);
        } catch (android.content.ActivityNotFoundException ex) {
            DialogManager.showSingleDialog(RestoreDataActivity.this, "你需要安装一个文件管理器");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case FILE_SELECT_CODE:
                    resotreWithUri(data.getData());
                    break;
                case SELECT_BACKUP_PATH:
                    break;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 自动还原，从USB设备中读取加密文件
     */
    private void startAutoRestore() {
        final String path = RestoreUtil.buildSdcardPath(RestoreDataActivity.this, true);
        if (TextUtils.isEmpty(path)) {
            DialogManager.showSingleDialog(this, "没有检测到USB存储设备。");
            return;
        } else {
            DialogManager.showExecuteDialog(this, "设备路径为：" + path, new DialogResponseListener() {
                @Override
                public void response() {
                    String dataPath = RestoreUtil.searchRestoreFile(path);
                    if (TextUtils.isEmpty(dataPath)) {
                        dataPath = RestoreUtil.searchRestoreFile(path + "/Android/data/" + getPackageName() + "/files/");
                    }
                    LogUtil.log("BackUp", "找到的文件：" + dataPath);
                    if (!TextUtils.isEmpty(dataPath)) {
                        restoreWithPath(dataPath);
                    } else {
                        DialogManager.showSingleDialog(RestoreDataActivity.this, "没有找到备份文件，请确定文件名称的前缀是\"美易点备份_\"");
                    }
                }
            });
        }
    }


    /**
     * 开始备份，自动将加密文件写入到USB存储设备
     */
    private void startBackUp() {
        final Progress progress = ProgressManager.showProgressUncancel(RestoreDataActivity.this, "正在备份");
        new LowThread(new Runnable() {
            @Override
            public void run() {
                String path = RestoreUtil.buildSdcardPath(RestoreDataActivity.this, false);
                if (TextUtils.isEmpty(path)) {
                    progress.dismiss();
                    DialogManager.showSingleDialog(RestoreDataActivity.this, "没有检测到USB存储设备。");
                    return;
                }
                String encryptedFilePath = BackUpDataManual.startManualDoBackUp(RestoreDataActivity.this);
                boolean result = false;
                if (!TextUtils.isEmpty(encryptedFilePath)) {
                    try {
                        progress.updateText("加密完成，正在拷贝");
                        String fileName = encryptedFilePath.substring(encryptedFilePath.lastIndexOf("/"));
                        path = path + fileName;
                        result = copyFileToUsbSdcard(encryptedFilePath, path);
                        FileUtil.deleteAllFile(encryptedFilePath);
                        RestoreUtil.updateSingleRecord(path, RestoreDataActivity.this);
                    } catch (Exception e) {
                        LogUtil.logError(e);
                        result=false;
                    }
                    progress.dismiss();
                }
                if (result) {
                    DialogManager.showSingleDialog(RestoreDataActivity.this, "备份完成，请不要修改备份文件的名称\n备份文件路径：" + path);
                } else {
                    DialogManager.showSingleDialog(RestoreDataActivity.this, "备份失败");
                }
            }
        }).start();
    }

    /**
     * 解析Uri并开始还原的流程
     *
     * @param uri Uri
     */
    private void resotreWithUri(final Uri uri) {
        if (uri == null) {
            ToastUtil.showToast("请重新选择路加密的备份文件");
        }
        final Progress progress = ProgressManager.showProgressUncancel(RestoreDataActivity.this, "正在处理");
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                String filePath = getCacheDir() + "/tempMwDecrytFile";
                FileUtil.deleteAllFile(filePath);
                boolean result = copyFileToData(filePath, uri);
                progress.dismiss();
                if (!result) {
                    DialogManager.showSingleDialog(RestoreDataActivity.this, "读取失败，请检查你的文件路径");
                } else {
                    restoreWithPath(filePath);
                }
                return null;
            }
        });
    }

    /**
     * 根据文件路径，开始整个还原流程：
     * 1，解密文件到DB目录 {@link #doDecrypt(String, Progress)}
     * 2，从db文件读取数据并写入到本地的db{@link #transferData(String, Progress)}
     *
     * @param selecPath String | 文件路径
     */
    private void restoreWithPath(final String selecPath) {
        LogUtil.log("mwbackup processWithPath=" + selecPath);
        if (TextUtils.isEmpty(selecPath)) {
            ToastUtil.showToast("文件路径不正确");
            return;
        }
        final Progress progress = ProgressManager.showProgressUncancel(RestoreDataActivity.this, "开始解密");
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                String dbName = doDecrypt(selecPath, progress);
                if (!TextUtils.isEmpty(dbName)) {
                    startTransferAfterDecrypt(dbName, progress);
                }
                return null;
            }
        });
    }


    /**
     * 解密
     *
     * @param selecPath String
     * @param progress  Progress
     */
    private String doDecrypt(String selecPath, Progress progress) {
        File file = new File(selecPath);
        if (file.exists()) {
            final String dbName = BackUpDataManual.startManualRestore(this, selecPath);
            if (TextUtils.isEmpty(dbName)) {
                progress.dismiss();
                DialogManager.showSingleDialog(RestoreDataActivity.this, "解密失败，请检查你的文件路径");
            } else {
                return dbName;

            }
        } else {
            progress.dismiss();
            DialogManager.showSingleDialog(RestoreDataActivity.this, "备份文件已不存在");
        }
        return "";
    }

    /**
     * 开始抽取数据的流程
     *
     * @param dbName   String
     * @param progress Progress
     */
    private void startTransferAfterDecrypt(final String dbName, Progress progress) {
        DBManager.init(RestoreDataActivity.this, dbName, 1000, null);
        boolean result = transferData(dbName, progress);
        progress.dismiss();
        if (result) {
            ForceSetAsMainHost.resetToken();
            DialogManager.showSingleDialog(RestoreDataActivity.this, "还原完毕，你可以手动重启APP", "", "好的", new DialogResponseListener() {
                @Override
                public void response() {
                    ProgressManager.showProgressUncancel(RestoreDataActivity.this, "准备退出");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            FileUtil.deleteAllFile(getDatabasePath(dbName));
                            try {
                                Thread.sleep(3 * 1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            ForceSetAsMainHost.exit(RestoreDataActivity.this);
                        }
                    }).start();
                }
            });
        } else {
            DialogManager.showSingleDialog(RestoreDataActivity.this, "出现了一些问题，你需要再尝试一次");

        }
        if (DBManager.getInstance(dbName) != null) {
            DBManager.getInstance(dbName).closeAll();
        }
    }

    /**
     * 从DB中抽取数据
     *
     * @param dbName   String
     * @param progress Progress
     * @return boolean
     */
    private boolean transferData(String dbName, Progress progress) {
        List<String> tableList = DBSimpleUtil.queryStringList(dbName, "select name from sqlite_master where type='table'");
        String sql = "select * from %s";
        String sqlDelete = "delete from %s";
        JSONObject ob = new JSONObject();
        try {
            int totalSize = tableList.size();
            for (int i = 0; i < totalSize; i++) {
                ob.clear();
                String temp = tableList.get(i);
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, String.format(sqlDelete, temp));
                progress.updateText("正在导入" + i + "/" + totalSize + "");
                List<JSONObject> array = DBSimpleUtil.queryJsonList(dbName, String.format(sql, temp));
                JSONArray jsonArray = new JSONArray();
                jsonArray.addAll(array);
                ob.put(temp, jsonArray);
                WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, ob, "");
            }
            ClientMetaUtil.deleteAll();
            ClientMetaUtil.updateSettingsValueByKey(META.TOKEN,"");
            ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");
            ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, "1");

        } catch (Exception e) {
            LogUtil.logError(e);
            return false;
        }
        return true;
    }

    private boolean copyFileToData(String targetFile, Uri srcUri) {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        FileUtil.deleteAllFile(targetFile);
        boolean result = false;
        try {
            InputStream in = getContentResolver().openInputStream(srcUri);
            if (in == null) {
                return false;
            }
            bis = new BufferedInputStream(in);
            bos = new BufferedOutputStream(new FileOutputStream(targetFile));
            byte[] buf = new byte[1024];
            int length = 0;
            int totalLength = 0;
            while ((length = bis.read(buf)) != -1) {
                if (totalLength > 1544208 * 100) {
                    //文件过大
                    return false;
                }
                bos.write(buf, 0, length);
                totalLength += length;
            }
            if (totalLength < 1024 * 10) {
                //文件过小
                return false;
            }
            bos.flush();
            result = true;
        } catch (Exception e) {
            result = false;
            LogUtil.logError(e);
        } catch (Error e) {
            result = false;
            LogUtil.logError(e);
        } finally {
            try {
                if (bis != null) {
                    bis.close();
                }
                if (bos != null) {
                    bos.close();
                }
            } catch (IOException e) {
                LogUtil.logError(e);
            }
        }
        return result;
    }


    private boolean copyFileToUsbSdcard(String srcFile, String targetPath) {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        FileUtil.deleteAllFile(targetPath);
        boolean result = false;
        try {
            OutputStream out = new FileOutputStream(targetPath);
            InputStream in = new FileInputStream(srcFile);
            bis = new BufferedInputStream(in);
            bos = new BufferedOutputStream(out);
            byte[] buf = new byte[1024];
            int length = 0;
            int totalLength = 0;
            while ((length = bis.read(buf)) != -1) {
                if (totalLength > 1544208 * 100) {
                    //文件过大
                    return false;
                }
                bos.write(buf, 0, length);
                totalLength += length;
            }
            if (totalLength < 1024 * 10) {
                //文件过小
                return false;
            }
            bos.flush();
            out.flush();
            result = true;
        } catch (Exception e) {
            result = false;
            LogUtil.logError(e);
        } catch (Error e) {
            result = false;
            LogUtil.logError(e);
        } finally {
            try {
                if (bis != null) {
                    bis.close();
                }
                if (bos != null) {
                    bos.close();
                }
            } catch (IOException e) {
                LogUtil.logError(e);
            }
        }
        return result;
    }
}
