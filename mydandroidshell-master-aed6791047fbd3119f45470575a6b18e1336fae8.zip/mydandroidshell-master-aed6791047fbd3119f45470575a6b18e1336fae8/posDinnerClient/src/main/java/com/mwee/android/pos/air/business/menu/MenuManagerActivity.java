package com.mwee.android.pos.air.business.menu;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.air.base.AirBaseActivity;
import com.mwee.android.pos.air.business.biz.BizcenterApi;
import com.mwee.android.pos.air.business.menu.dialog.MenuClsEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.dialog.MenuEditorDialogFragment;
import com.mwee.android.pos.air.business.menu.processor.MenuClsProcessor;
import com.mwee.android.pos.air.business.menu.processor.MenuManagerProcessor;
import com.mwee.android.pos.base.AppCache;
import com.mwee.android.pos.base.BaseMwAdapter;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.DialogResponseListener;
import com.mwee.android.pos.component.dialog.Progress;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.Tools;
import com.mwee.android.pos.util.ViewToolsUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseListAdapter;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.DividerItemDecoration;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/9/27.
 */

public class MenuManagerActivity extends AirBaseActivity implements MenuClsEditorDialogFragment.OnMenuClsEditorListener {
    private TitleBar mTitleBar;
    private RecyclerView mMenuClsRecyclerView;
    private ListView mMenuRecyclerView;
    private TextView tvAdd;
    private TextView tvBatchDelete;
    private MenuAdapter menuAdapter;
    private MenuClsAdapter menuClsAdapter;

    private MenuManagerProcessor mMenuManagerProcessor;
    private MenuClsProcessor menuClsProcessor;

    private LinearLayout mOperationAddLayout;
    private LinearLayout mOperationDeleteLayout;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchCancelBtn;
    private TextView mAskBatchDeleteBtn;

    private FrameLayout mEmptyLayout;
    private TextView tvEmptyCreateFirst;

    private TextView mClsEmptyLabel;
    private TextView mBatchChoiceValueLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_manager);


        mEmptyLayout = findViewById(R.id.mEmptyLayout);
        tvEmptyCreateFirst = findViewById(R.id.tvEmptyCreateFirst);
        tvEmptyCreateFirst.setText("新建分类");
        tvEmptyCreateFirst.setOnClickListener(this);

        mClsEmptyLabel = findViewById(R.id.mClsEmptyLabel);

        mTitleBar = findViewById(R.id.mTitleBar);
        mMenuClsRecyclerView = findViewById(R.id.mMenuClsRecyclerView);
        mMenuRecyclerView = findViewById(R.id.mMenuRecyclerView);


        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                finish();
            }
        });
        mTitleBar.setRightClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                ProgressManager.showProgressUncancel(MenuManagerActivity.this);
                BizcenterApi.syncData2C(new IResult() {
                    @Override
                    public void callBack(boolean result, String info) {
                        ProgressManager.closeProgress(MenuManagerActivity.this);
                        if (!TextUtils.isEmpty(info)) {
                            ToastUtil.showToast(info);
                        }
                    }
                });
            }
        });


        findViewById(R.id.tvAddCategoryLabel).setOnClickListener(this);

        initButtomLayut();
        initData();
    }


    /**
     * 初始化底部bottom
     */
    private void initButtomLayut() {


        mOperationAddLayout = findViewById(R.id.mOperationAddLayout);
        tvAdd = findViewById(R.id.tvAdd);
        tvBatchDelete = findViewById(R.id.tvBatchDelete);
        tvAdd.setOnClickListener(this);
        tvBatchDelete.setOnClickListener(this);

        mOperationDeleteLayout = findViewById(R.id.mOperationDeleteLayout);
        mAskBatchChoiceAllLabel = findViewById(R.id.mAskBatchChoiceAllLabel);
        mBatchChoiceValueLabel = findViewById(R.id.mBatchChoiceValueLabel);
        mAskBatchCancelBtn = findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn = findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchDeleteBtn.setOnClickListener(this);

    }

    /*--------------------------菜品选删除的操作---------------------------------*/
    private ArrayList<String> choiceStates = new ArrayList<>();

    /**
     * 单选一个菜品
     *
     * @param value
     */
    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }


    /**
     * 判断是否全选
     *
     * @return
     */
    private boolean isChoiceAll() {
        for (int i = 0; i < menuAdapter.modules.size(); i++) {
            if (!choiceStates.contains(menuAdapter.modules.get(i).fiItemCd)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 全选
     */
    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < menuAdapter.modules.size(); i++) {
            choiceStates.add(menuAdapter.modules.get(i).fiItemCd);
        }
    }

    /**
     * 清除全选
     */
    private void cancelChoiceAll() {
        choiceStates.clear();
    }


    private void initData() {
        mMenuManagerProcessor = new MenuManagerProcessor();
        menuClsProcessor = new MenuClsProcessor();

        mTitleBar.setTitle(R.string.menu_manager_title);
        mTitleBar.setRightContent("数据同步");
        mMenuClsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mMenuClsRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        menuClsAdapter = new MenuClsAdapter();
        mMenuClsRecyclerView.setAdapter(menuClsAdapter);

        menuAdapter = new MenuAdapter();
        mMenuRecyclerView.setAdapter(menuAdapter);
        loadDataFromServer(true);
    }

    /**
     * 获取菜品分类 以及分类对应的菜品数据
     *
     * @param isLoadAllMenu
     */
    private void loadDataFromServer(final boolean isLoadAllMenu) {
        //final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuManagerProcessor.loadMenuManagerIndexData(isLoadAllMenu, new ResultCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void onSuccess(AllMenuClsAndMenuItemResponse data) {
                refreshMenuClsList(data.menuClsBeanList);
                if (isLoadAllMenu && !ListUtil.isEmpty(data.menuClsBeanList)) {
                    refreshMenuItemsList(data.menuItemBeanList);
                }
                //progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                //progress.dismissSelf();
            }
        });
    }


    /**
     * 获取菜品分类 以及分类对应的菜品数据
     *
     * @param
     */
    private void loadSmoothDataFromServer() {
        //final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuManagerProcessor.loadMenuManagerIndexData(true, new ResultCallback<AllMenuClsAndMenuItemResponse>() {
            @Override
            public void onSuccess(AllMenuClsAndMenuItemResponse data) {
                menuClsAdapter.selectPosition = data.menuClsBeanList.size() - 1;
                refreshMenuClsList(data.menuClsBeanList);
                loadMenuItemsByClsId();

                //progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                //progress.dismissSelf();
            }
        });
    }


    /**
     * 通过菜品分类ID获取数据
     */
    private void loadMenuItemsByClsId() {
        //final Progress progress = ProgressManager.showProgress(this, R.string.progress_loading);
        mMenuManagerProcessor.loadMenuItemsByClsId(getCurrentMenuClsModel().fsMenuClsId, new ResultCallback<List<MenuItemBean>>() {
            @Override
            public void onSuccess(List<MenuItemBean> data) {
                refreshMenuItemsList(data);
                //progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                ToastUtil.showToast(msg);
                //progress.dismissSelf();
            }
        });
    }


    private void refreshMenuClsList(List<MenuClsBean> menuClsBeanList) {
        menuClsAdapter.modules.clear();
        menuClsAdapter.modules.addAll(menuClsBeanList);
        menuClsAdapter.notifyDataSetChanged();

        /**
         * 菜品分类没有数据时候
         *    显示空的界面
         */
        mEmptyLayout.setVisibility(ListUtil.isEmpty(menuClsBeanList) ? View.VISIBLE : View.GONE);
    }


    private void refreshMenuItemsList(List<MenuItemBean> menuItemBeanList) {
        menuAdapter.modules.clear();
        menuAdapter.modules.addAll(menuItemBeanList);
        menuAdapter.notifyDataSetChanged();

        /**
         * 当前分类下 没有任何菜品时候
         *   1 显示美容点提示界面
         *   2 批量删除按钮不显示
         *   3 删除模式 底部显示添加布局
         */
        mClsEmptyLabel.setVisibility(ListUtil.isEmpty(menuItemBeanList) ? View.VISIBLE : View.GONE);

        tvBatchDelete.setVisibility(ListUtil.isEmpty(menuItemBeanList) ? View.GONE : View.VISIBLE);

        if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
            mOperationAddLayout.setVisibility(ListUtil.isEmpty(menuItemBeanList) ? View.VISIBLE : View.GONE);
            mOperationDeleteLayout.setVisibility(ListUtil.isEmpty(menuItemBeanList) ? View.GONE : View.VISIBLE);
        }
        refreshChoiceMenuCount();

    }


    /**
     * 刷新选中菜品个数显示
     */
    private void refreshChoiceMenuCount() {

        mBatchChoiceValueLabel.setText(String.format("选中%s个", choiceStates.size()));

    }


    @Override
    protected void handlerClickEvent(View v) {
        switch (v.getId()) {
            case R.id.tvEmptyCreateFirst:
            case R.id.tvAddCategoryLabel:
                ActionLog.addLog("菜品管理页面->点击了新建分组", "", "", ActionLog.SS_MORE_JOIN, "");
                loadMenuClsPrinters(false);
                break;
            case R.id.tvAdd:
                ActionLog.addLog("菜品管理页面->点击了新建菜品", "", "", ActionLog.SS_MORE_JOIN, "");
                showMenuAddDialog();
                break;
            case R.id.tvBatchDelete:
                ActionLog.addLog("菜品管理页面->点击了批量删除", "", "", ActionLog.SS_MORE_JOIN, "");
                mOperationAddLayout.setVisibility(View.GONE);
                mOperationDeleteLayout.setVisibility(View.VISIBLE);
                menuAdapter.notifyDataSetChanged();
                break;
            case R.id.mAskBatchChoiceAllLabel://全选
                ActionLog.addLog("菜品管理页面->点击了全选", "", "", ActionLog.SS_MORE_JOIN, "");
                doChoiceAll();
                break;
            case R.id.mAskBatchCancelBtn://取消
                ActionLog.addLog("菜品管理页面->点击了取消", "", "", ActionLog.SS_MORE_JOIN, "");
                doCancelChoiceAll();
                break;
            case R.id.mAskBatchDeleteBtn://删除
                ActionLog.addLog("菜品管理页面->点击了删除", "", "", ActionLog.SS_MORE_JOIN, "");
                doBatchDeleteChoice();
                break;
            default:
                break;
        }
    }

    /**
     * 点击全选按钮
     */
    private void doChoiceAll() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        menuAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();


    }

    /**
     * 执行取消事件
     */
    private void doCancelChoiceAll() {
        mOperationAddLayout.setVisibility(View.VISIBLE);
        mOperationDeleteLayout.setVisibility(View.GONE);
        cancelChoiceAll();
        mAskBatchChoiceAllLabel.setSelected(false);
        menuAdapter.notifyDataSetChanged();
        refreshChoiceMenuCount();

    }


    private void doBatchDeleteChoice() {

        if (choiceStates.isEmpty()) {
            ToastUtil.showToast("请先选择菜品");
            return;
        }
        String content = "";
        if (choiceStates.size() == 1) {
            content = "确定删除该菜品吗?";
        } else {
            content = String.format("确定删除这%s个菜品吗?", choiceStates.size());
        }
        DialogManager.showExecuteDialog(getActivityWithinHost(), content, new DialogResponseListener() {
            @Override
            public void response() {

                final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost());
                mMenuManagerProcessor.loadBatchDelete(choiceStates, new ResultCallback<String>() {
                    @Override
                    public void onSuccess(String data) {
                        ToastUtil.showToast("已删除");
                        progress.dismissSelf();
                        //删除完成 释放choice
                        choiceStates.clear();
                        mAskBatchChoiceAllLabel.setSelected(false);
                        loadMenuItemsByClsId();
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        progress.dismissSelf();
                        ToastUtil.showToast(msg);
                    }
                });

            }
        });

    }


    /**
     * 分类删除
     */
    private void doMenuClsDelete() {

        DialogManager.showExecuteDialog(getActivityWithinHost(), "确定删除该分类吗?", new DialogResponseListener() {
            @Override
            public void response() {
                final Progress progress = ProgressManager.showProgressUncancel(getActivityWithinHost(), "删除中...");
                menuClsProcessor.loadMenuClsDelete(getCurrentMenuClsModel().fsMenuClsId, new ResultCallback<String>() {
                    @Override
                    public void onSuccess(String data) {
                        progress.dismissSelf();
                        menuClsAdapter.selectPosition = 0;//删除分类以后 默认选中全部
                        loadDataFromServer(true);
                        ToastUtil.showToast("已删除");
                    }

                    @Override
                    public void onFailure(int code, String msg) {
                        super.onFailure(code, msg);
                        progress.dismissSelf();
                        ToastUtil.showToast(msg);
                    }
                });
            }
        });

    }

    /**
     * 分类置顶
     */
    private void doMenuClsTop() {
        final Progress progress = ProgressManager.showProgressUncancel(this, "置顶中...");
        menuClsProcessor.loadMenuClsToTop(getCurrentMenuClsModel().fsMenuClsId, new ResultCallback<MenuClsToTopResponse>() {
            @Override
            public void onSuccess(MenuClsToTopResponse data) {
                menuClsAdapter.selectPosition = 1;
                refreshMenuClsList(data.menuClsBeenList);
                progress.dismissSelf();
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }

    private void showMenuClsEditorDialog(MenuClsPrintersResponse data) {
        MenuClsEditorDialogFragment fragment = new MenuClsEditorDialogFragment();
        MenuClsBean bean = getCurrentMenuClsModel();
        bean.printerNames = data.choicePrinters;
        fragment.setParam(bean, data.allPrinters);
        fragment.setOnMenuClsEditorListener(this);
        DialogManager.showCustomDialog(this, fragment, "MenuClsEditorDialogFragment");
    }

    public void loadMenuClsPrinters(final boolean isEditor) {
        final Progress progress = ProgressManager.showProgressUncancel(this);
        String menuClsId = "";
        if (isEditor) {
            menuClsId = getCurrentMenuClsModel().fsMenuClsId;
        }
        menuClsProcessor.loadMenuClsPrinters(menuClsId, new ResultCallback<MenuClsPrintersResponse>() {
            @Override
            public void onSuccess(MenuClsPrintersResponse data) {
                progress.dismiss();
                if (isEditor) {
                    showMenuClsEditorDialog(data);
                } else {
                    showMenuClsAddDialog(data.allPrinters);
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                progress.dismiss();
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onMenuClsAddSuccess(String id, String name) {
        loadSmoothDataFromServer();
    }

    @Override
    public void onMenuClsUpdateSuccess(String name) {
        loadDataFromServer(false);
    }

    @Override
    public void onMenuClsDeleteSuccess() {
        //删除菜品分类后选中全部
        menuClsAdapter.selectPosition = 0;
        loadDataFromServer(true);
    }


    private void showMenuClsAddDialog(ArrayList<PrinterItem> allPrinters) {
        MenuClsEditorDialogFragment fragment = new MenuClsEditorDialogFragment();
        MenuClsBean menuClsBean = new MenuClsBean();
        //默认选择所有打印机
        for (PrinterItem allPrinter : allPrinters) {
            menuClsBean.printerNames.add(allPrinter.name);
        }
        fragment.setParam(menuClsBean, allPrinters);
        fragment.setOnMenuClsEditorListener(this);
        DialogManager.showCustomDialog(this, fragment, "MenuClsEditorDialogFragment");
    }

    private void showMenuAddDialog() {
        MenuEditorDialogFragment dialog = new MenuEditorDialogFragment();
        dialog.setParam(getCurrentMenuClsModel().fsMenuClsId, menuClsAdapter.modules.subList(1, menuClsAdapter.modules.size()));
        dialog.setOnMenuEditorListener(new MenuEditorDialogFragment.OnMenuEditorListener() {

            @Override
            public void onMenuUpdateSuccess(MenuItemBean bean) {
                loadMenuItemsByClsId();
            }

            @Override
            public void onMenuAddSuccess(MenuItem menuItem, MenuItemBean bean) {
                loadMenuItemsByClsId();
            }
        });
        DialogManager.showCustomDialog(MenuManagerActivity.this, dialog, "MenuEditorDialogFragment");
    }


    class MenuClsAdapter extends BaseListAdapter<MenuClsBean> {
        int selectPosition;

        @Override
        protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
            return new MenuClsHolder(LayoutInflater.from(MenuManagerActivity.this).inflate(R.layout.air_category_item_layout, parent, false));
        }

        public MenuClsBean getSelectMenuclsDBModel() {
            return modules.get(selectPosition);
        }

        class MenuClsHolder extends BaseViewHolder implements View.OnClickListener {

            private int position;
            private LinearLayout tvCategoryLayout;
            private TextView tvCategoryName;
            private ImageView iconDelete;
            private ImageView iconTop;
            private ImageView iconEditor;


            public MenuClsHolder(View itemView) {
                super(itemView);
                tvCategoryLayout = itemView.findViewById(R.id.tvCategoryLayout);
                tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
                iconDelete = itemView.findViewById(R.id.iconDelete);
                iconTop = itemView.findViewById(R.id.iconTop);
                iconEditor = itemView.findViewById(R.id.iconEditor);

                tvCategoryLayout.setOnClickListener(this);
                iconDelete.setOnClickListener(this);
                iconTop.setOnClickListener(this);
                iconEditor.setOnClickListener(this);

            }

            @Override
            public void bindData(int position) {
                this.position = position;
                MenuClsBean menuClsBean = modules.get(position);
                tvCategoryName.setText(menuClsBean.fsMenuClsName);
                if (position == selectPosition) {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.drawable.bg_air_category_item_checked);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.system_red));

                } else {
                    ViewToolsUtil.setBackgroundResourceKeepPadding(itemView, R.color.white);
                    tvCategoryName.setTextColor(getResources().getColor(R.color.color_3a3a3a));
                }

                if (position == selectPosition && mMenuManagerProcessor.isNormalMenuCls(menuClsBean.fsMenuClsId)) {
                    iconDelete.setVisibility(View.VISIBLE);
                    iconEditor.setVisibility(View.VISIBLE);
                    if (modules.indexOf(menuClsBean) == 1) {//第一个菜品分类不显示置顶按钮
                        iconTop.setVisibility(View.GONE);
                    } else {
                        iconTop.setVisibility(View.VISIBLE);
                    }

                } else {
                    iconDelete.setVisibility(View.GONE);
                    iconTop.setVisibility(View.GONE);
                    iconEditor.setVisibility(View.GONE);
                }

            }

            @Override
            public void onClick(View v) {

                switch (v.getId()) {
                    case R.id.tvCategoryLayout:
                        if (selectPosition != position) {
                            //执行取消编辑事件
                            mOperationAddLayout.setVisibility(View.VISIBLE);
                            mOperationDeleteLayout.setVisibility(View.GONE);
                            mAskBatchChoiceAllLabel.setSelected(false);
                            cancelChoiceAll();

                            selectPosition = position;
                            loadMenuItemsByClsId();
                            menuClsAdapter.notifyDataSetChanged();
                        }
                        break;
                    case R.id.iconDelete:
                        ActionLog.addLog("菜品管理页面->点击了分类删除", "", "", ActionLog.SS_MORE_JOIN, "");
                        doMenuClsDelete();
                        break;
                    case R.id.iconTop:
                        ActionLog.addLog("菜品管理页面->点击分类置顶", "", "", ActionLog.SS_MORE_JOIN, "");
                        LogUtil.log("MenuClsAdapter top");
                        doMenuClsTop();
                        break;
                    case R.id.iconEditor:
                        ActionLog.addLog("菜品管理页面->点击了分类编辑", "", "", ActionLog.SS_MORE_JOIN, "");
                        LogUtil.log("MenuClsAdapter editor");
                        loadMenuClsPrinters(true);
                        break;
                    default:
                        break;
                }
            }
        }
    }


    /**
     * 得到当前分类bean
     *
     * @return
     */
    private MenuClsBean getCurrentMenuClsModel() {
        return menuClsAdapter.getSelectMenuclsDBModel();
    }


    class MenuAdapter extends BaseMwAdapter<MenuItemBean> {


        public int selectPosition = 0;

        @Override
        protected View getItemView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = LayoutInflater.from(MenuManagerActivity.this).inflate(R.layout.view_menu_item, parent, false);
                viewHolder = new ViewHolder(convertView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.bindData(position);

            return convertView;
        }

        class ViewHolder implements View.OnClickListener {

            private int position;
            private MenuItemBean data;

            private View itemViewLayout;
            private TextView mMenuItemNameLabel;
            private TextView mMenuItemRepertoryLabel;
            private TextView mMenuItemSellPriceLabel;
            private TextView mMenuItemMemberPriceLabel;
            private ImageView mIconTop;//菜品置顶
            private ImageView tvItemCheck;
            private TextView tvCanWeight;
            private TextView tvCanTimePrice;


            public ViewHolder(View v) {
                LogUtil.log(v.toString() + "biubiubiu");
                itemViewLayout = v.findViewById(R.id.itemViewLayout);
                mMenuItemNameLabel = v.findViewById(R.id.mMenuItemNameLabel);
                tvCanWeight = v.findViewById(R.id.tvCanWeight);
                tvCanTimePrice = v.findViewById(R.id.tvCanTimePrice);
                mMenuItemRepertoryLabel = v.findViewById(R.id.mMenuItemRepertoryLabel);
                mMenuItemSellPriceLabel = v.findViewById(R.id.mMenuItemSellPriceLabel);
                mMenuItemMemberPriceLabel = v.findViewById(R.id.mMenuItemMemberPriceLabel);
                mIconTop = v.findViewById(R.id.mIconTop);

                tvItemCheck = v.findViewById(R.id.tvItemCheck);
                mIconTop.setOnClickListener(this);
                //tvItemCheck.setOnClickListener(this);
                v.setOnClickListener(this);

            }


            public void bindData(int position) {

                this.position = position;
                this.data = modules.get(position);

                mMenuItemNameLabel.setText(data.fsItemName);

                tvCanWeight.setVisibility(data.fiIsEditQty == 1 ? View.VISIBLE : View.GONE);
                tvCanTimePrice.setVisibility(data.fiIsEditPrice == 1 ? View.VISIBLE : View.GONE);
                BigDecimal num = AppCache.getInstance().getSelloutNum(data.fiOrderUintCd);
                if (num.compareTo(new BigDecimal(-1)) == 0) {
                    mMenuItemRepertoryLabel.setText("不限");
                } else {
                    if (num.compareTo(BigDecimal.ZERO) == 0) {
                        mMenuItemRepertoryLabel.setText("售罄");
                    } else {
                        mMenuItemRepertoryLabel.setText(num + "");
                    }
                }
                String sellPriceLabelContent = Calc.formatShow(data.fdSalePrice, RoundConfig.ROUND_SINGLE_PRICE) + "/" + data.fsOrderUint;
                mMenuItemSellPriceLabel.setText(sellPriceLabelContent);

                /**
                 * 会员价大于0 显示会员价 否则使用原价
                 */
                if (data.fdVIPPrice.compareTo(BigDecimal.ZERO) > 0) {
                    mMenuItemMemberPriceLabel.setText(Calc.formatShow(data.fdVIPPrice, RoundConfig.ROUND_SINGLE_PRICE) + "/" + data.fsOrderUint);
                } else {
                    mMenuItemMemberPriceLabel.setText(sellPriceLabelContent);
                }

                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为删除模式
                    tvItemCheck.setVisibility(View.VISIBLE);
                    if (choiceStates.contains(data.fiItemCd)) {
                        tvItemCheck.setSelected(true);
                    } else {
                        tvItemCheck.setSelected(false);
                    }
                } else {
                    tvItemCheck.setVisibility(View.INVISIBLE);
                }

                if (modules.indexOf(data) == 0 || menuClsAdapter.getSelectMenuclsDBModel().fsMenuClsId.equals("-1localAll")) {//第一个菜品置顶不显示
                    mIconTop.setVisibility(View.INVISIBLE);
                } else {
                    mIconTop.setVisibility(View.VISIBLE);
                }

                if (position == selectPosition) {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.color_FFD2CB));
                } else {
                    itemViewLayout.setBackgroundColor(ViewToolsUtil.getColor(getContextWithinHost(), R.color.white));
                }
            }


            @Override
            public void onClick(View v) {
                if (!ButtonClickTimer.canClick()) {
                    return;
                }
                selectPosition = position;
                menuAdapter.notifyDataSetChanged();

                if (v.getId() == R.id.mIconTop) {
                    doMenuTop();
                    return;
                }
                if (mOperationDeleteLayout.getVisibility() == View.VISIBLE) {//当前为菜品删除模式 不触发编辑菜品事件
                    choice(data.fiItemCd);
                    menuAdapter.notifyDataSetChanged();
                    refreshChoiceMenuCount();
                    mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
                } else {
                    MenuEditorDialogFragment dialog = new MenuEditorDialogFragment();
                    dialog.setParam(data, menuClsAdapter.modules.subList(1, menuClsAdapter.modules.size()));
                    dialog.setOnMenuEditorListener(new MenuEditorDialogFragment.OnMenuEditorListener() {

                        @Override
                        public void onMenuUpdateSuccess(MenuItemBean bean) {
                            loadMenuItemsByClsId();
                        }

                        @Override
                        public void onMenuAddSuccess(MenuItem menuItem, MenuItemBean bean) {

                        }
                    });
                    DialogManager.showCustomDialog(MenuManagerActivity.this, dialog, "MenuEditorDialogFragment");
                }

            }
        }

    }

    //菜品置顶
    private void doMenuTop() {

        final Progress progress = ProgressManager.showProgressUncancel(this, "置顶中...");
        mMenuManagerProcessor.loadMenuItemToTop(menuAdapter.modules.get(menuAdapter.selectPosition).fiItemCd, new ResultCallback<String>() {
            @Override
            public void onSuccess(String data) {
                progress.dismissSelf();

                menuAdapter.selectPosition = 0;
                loadMenuItemsByClsId();
            }

            @Override
            public void onFailure(int code, String msg) {
                super.onFailure(code, msg);
                progress.dismissSelf();
                ToastUtil.showToast(msg);
            }
        });
    }


}
