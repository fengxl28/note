package com.mwee.android.pos.air.business.table.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.pos.air.business.table.processor.TableManagerProcessor;
import com.mwee.android.pos.component.adapter.CommonAdapter;
import com.mwee.android.pos.component.adapter.ViewHolder;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/15.
 */

public class EditTableFragment extends BaseDialogFragment implements View.OnClickListener {

    private TextView title_tv;

    private EditText table_name_edt;
    private EditText shits_edt;

    private Spinner area_sp;

    private Button cancel_btn;
    private Button submit_btn;

    private OnEditTableListener listener;
    private TableManagerProcessor mProcessor;

    private AirTableManageInfo airTableManageInfo;
    private String areaId = "";

    private CommonAdapter<AirAreaManagerInfo> airAreaManagerInfoCommonAdapter;
    private ArrayList<AirAreaManagerInfo> airAreaManagerInfos = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.edit_table_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(this);
        initUI(view);
        initData();
    }

    private void initUI(View view) {
        title_tv = (TextView) view.findViewById(R.id.title_tv);
        table_name_edt = (EditText) view.findViewById(R.id.table_name_edt);
        shits_edt = (EditText) view.findViewById(R.id.shits_edt);
        area_sp = (Spinner) view.findViewById(R.id.area_sp);
        cancel_btn = (Button) view.findViewById(R.id.cancel_btn);
        submit_btn = (Button) view.findViewById(R.id.submit_btn);
        cancel_btn.setOnClickListener(this);
        submit_btn.setOnClickListener(this);
    }

    private void initData() {
        if (isEditor()) {
            title_tv.setText("编辑桌台");
            table_name_edt.setText(airTableManageInfo.fsmtablename);
            shits_edt.setText(String.valueOf(airTableManageInfo.fiseats));
        } else {
            title_tv.setText("新增桌台");
        }
        airAreaManagerInfoCommonAdapter = new CommonAdapter<AirAreaManagerInfo>(getContext(), airAreaManagerInfos, R.layout.simple_spinner_item) {
            @Override
            public void convert(ViewHolder viewHolder, AirAreaManagerInfo data, int position) {
                ((TextView) viewHolder.getConvertView()).setText(data.fsMAreaName);
            }
        };

        area_sp.setAdapter(airAreaManagerInfoCommonAdapter);
        int position = 0;
        for (int i = 0; i < airAreaManagerInfos.size(); i++) {
            if (android.text.TextUtils.equals(airAreaManagerInfos.get(i).fsMAreaId, areaId)) {
                position = i;
            }
        }
        area_sp.setSelection(position);
    }

    public void setAreaSouce(ArrayList<AirAreaManagerInfo> airAreaManagerInfoWhisoutAllList) {
        airAreaManagerInfos.clear();
        airAreaManagerInfos.addAll(airAreaManagerInfoWhisoutAllList);
        //buildChoiceHint();
    }

   /* public void buildChoiceHint() {
        AirAreaManagerInfo areaManagerInfo = new AirAreaManagerInfo();
        areaManagerInfo.fsMAreaId = "hint";
        areaManagerInfo.fsMAreaName = "请选择";
        airAreaManagerInfos.add(0, areaManagerInfo);
    }*/


    public void setAreaSouce(List<MareaDBModel> mareaDBModelList) {
        airAreaManagerInfos.clear();
        if (!ListUtil.isEmpty(mareaDBModelList)) {
            for (MareaDBModel mareaDBModel : mareaDBModelList) {
                AirAreaManagerInfo airAreaManagerInfo = new AirAreaManagerInfo();
                airAreaManagerInfo.fsMAreaId = mareaDBModel.fsMAreaId;
                airAreaManagerInfo.fsMAreaName = mareaDBModel.fsMAreaName;
                if (mareaDBModel.fsMAreaId.equalsIgnoreCase("all")) {//去除全部的分类
                    continue;
                }
                airAreaManagerInfos.add(airAreaManagerInfo);
            }
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cancel_btn:
                dismissSelf();
                break;
            case R.id.submit_btn:
               /* if (area_sp.getSelectedItemPosition() == 0) {
                    ToastUtil.showToast("请选择餐区");
                    return;
                }*/
                String name = table_name_edt.getText().toString().trim();
                int seats = StringUtil.toInt(shits_edt.getText().toString().trim(), 0);
                if (validate(name, seats)) {
                    if (isEditor()) {
                        update(name, seats);
                    } else {
                        save(name, seats);
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * 表单校验
     *
     * @param name
     * @param seats
     * @return
     */
    private boolean validate(String name, int seats) {
        if (android.text.TextUtils.isEmpty(name)) {
            ToastUtil.showToast("请输入桌台名称");
            return false;
        }

        if (!RegexUtil.checkName(name)) {
            ToastUtil.showToast("输入的字符非法");
            return false;
        }

        if (seats <= 0) {
            ToastUtil.showToast("请输入人数");
            return false;
        }

        return true;
    }

    private void update(String name, int seats) {
        AirAreaManagerInfo airAreaManagerInfo = (AirAreaManagerInfo) area_sp.getSelectedItem();
        if (airAreaManagerInfo == null || airTableManageInfo == null) {
            return;
        }
        ProgressManager.showProgress(getActivityWithinHost(), getStringWithinHost(R.string.message_please_wait));
        mProcessor.updateTable(airAreaManagerInfo.fsMAreaId, airTableManageInfo.fsmtableid, name, seats, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onUpdateSuccess(mProcessor.mtableDBModel);
                    dismissSelf();
                } else {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "修改桌台失败");
                }
            }
        });
    }

    /**
     * 新增桌台
     *
     * @param name
     * @param seats
     */
    private void save(String name, int seats) {
        AirAreaManagerInfo airAreaManagerInfo = (AirAreaManagerInfo) area_sp.getSelectedItem();
        ProgressManager.showProgress(getActivityWithinHost(), getStringWithinHost(R.string.message_please_wait));
        mProcessor.addTable(airAreaManagerInfo.fsMAreaId, name, seats, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onEditorSuccess(mProcessor.inSertMtableDBModel);
                    dismissSelf();
                } else {
                    ToastUtil.showToast(TextUtils.validate(info) ? info : "新增桌台失败");
                }
            }
        });
    }

    public void setParam(String areaId, TableManagerProcessor mProcessor) {
        setParam(areaId, mProcessor, null);
    }

    public void setParam(String areaId, TableManagerProcessor mProcessor, AirTableManageInfo airTableManageInfo) {
        this.areaId = areaId;
        this.mProcessor = mProcessor;
        this.airTableManageInfo = airTableManageInfo;
    }

    private boolean isEditor() {
        return airTableManageInfo != null;
    }

    public interface OnEditTableListener {
        /**
         * 新增桌台
         *
         * @param data
         */
        void onEditorSuccess(MtableSimpleModel data);

        /**
         * 编辑桌台
         *
         * @param data 业务中心返回编辑的桌台信息
         */
        void onUpdateSuccess(MtableSimpleModel data);

        void onDeleteSuccess();
    }

    public void setOnEditTableListener(OnEditTableListener listener) {
        this.listener = listener;
    }
}
