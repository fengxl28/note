package com.mwee.android.pos.air.business.member.processor;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.air.business.member.api.MemberApi;
import com.mwee.android.pos.air.business.member.entity.MemberBalanceRechargeResonpseBody;
import com.mwee.android.pos.air.business.member.entity.MemberCreateResonpseBody;
import com.mwee.android.pos.air.business.member.entity.MemberLevelModel;
import com.mwee.android.pos.air.business.member.entity.MemberInfoUpdateResponseBody;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberCardResponse;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberConsumptionRecordingResponse;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberLeverResponse;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberRechargeRecordingResponse;
import com.mwee.android.pos.air.business.member.entity.air.AirMemberResponse;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.member.net.model.MemberCardInfoModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SafeUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberEditorProcessor {
    public void loadMemberAdd(String name, String phone, String birthday, int sex, String password, final ResultCallback<String> callback) {

        MemberApi.loadMemberAdd(name, phone, birthday, sex, password,new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberCreateResonpseBody) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(-1, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    public void loadBalanceRecharge(String card_no, String mobile, String price, String priceGift, final ResultCallback<String> callback) {
        if (!TextUtils.validate(priceGift)) {
            priceGift = "0";
        }
        MemberApi.loadBalanceRecharge(card_no, mobile, price, priceGift, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceRechargeResonpseBody) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(-1, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public void loadUpdateMemberInfo(String card_no, String name, String phone, String birthday, int sex, String password, int level, final ResultCallback<String> callback) {
        if (TextUtils.validate(password)) {
            password = SafeUtil.sha1Encrypt(password + "cardmwee");
        }
        MemberApi.loadUpdateMemberInfo(card_no, name, phone, birthday, sex, password, level, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberInfoUpdateResponseBody) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(-1, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 获取会员积分规则 和 充值套餐规则(两者并用一个接口)
     * @param callback
     */
    public void loadShopMemberRule(final ResultCallback<AirMemberResponse> callback) {
        MemberApi.loadShopMemberRule(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof AirMemberResponse) {
                    callback.onSuccess((AirMemberResponse) responseData.responseBean);
                } else {
                    callback.onFailure(-1, responseData.resultMessage);
                }

            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    public void loadShopMemberLevelList(final ResultCallback<AirMemberLeverResponse> callback) {
        MemberApi.loadShopMemberLevelList(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof AirMemberLeverResponse) {
                    callback.onSuccess((AirMemberLeverResponse) responseData.responseBean);
                } else {
                    callback.onFailure(-1, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    /**
     * 会员积分规则更新
     *
     * @param is_score 是否积分
     * @param cost_money_unit 每消费多少
     * @param increase_bonus  赠送积分
     * @param cost_bonus_unit 每使用 积分
     * @param reduce_money  兑换金额
     * @param is_clear  积分清零规则 是否清零
     * @param clear_day 积分清零规则 多少天以后清除
     * @param callback
     */
    public void loadMemberScoreGiftRuleUpdate(String is_score,String cost_money_unit, String increase_bonus
            , String cost_bonus_unit,String  reduce_money,String is_clear,String clear_day,final ResultCallback<String> callback) {
        MemberApi.loadMemberScoreGiftRuleUpdate(is_score,cost_money_unit, increase_bonus,cost_bonus_unit, reduce_money,is_clear,clear_day,new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    public void doLevelDelete(MemberLevelModel model, final ResultCallback<String> callback) {
        MemberApi.loadMemberLevelDelete(StringUtil.toInt(model.id, 0), new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }


    /**
     * 设置会员充值套餐
     * @param addRuleData
     * @param editorRuleData
     * @param delRuleData
     * @param callback
     */
    public void loadMemberPackageSave(Object addRuleData,Object editorRuleData,Object delRuleData,final ResultCallback<String> callback){

        MemberApi.loadMemberPackageSave(addRuleData, editorRuleData, delRuleData, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if(responseData != null ){
                    callback.onSuccess("");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result,responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 修改会员支付密码
     *
     * @param psd
     * @param callback
     */
    public void doChangeMemberPassword(MemberCardInfoModel cardModel, String psd, final ResultCallback<String> callback) {
        if (TextUtils.validate(psd)) {
            psd = SafeUtil.sha1Encrypt(psd + "cardmwee");
        }
        MemberApi.loadUpdateMemberInfo(cardModel.card_no, cardModel.real_name, cardModel.mobile, cardModel.birthday, cardModel.gender, psd, cardModel.level, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.onSuccess("");
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result, responseData.resultMessage);
                return false;
            }
        });
    }

    /**
     * 会员储值消费记录查询
     * @param card_no
     * @param mobile
     * @param start_date
     * @param end_date
     * @param page
     * @param callback
     */
    public void loadMemberRechaageRecording(String card_no, String mobile, String start_date, String end_date
            , int page, final ResultCallback<AirMemberRechargeRecordingResponse> callback){
        MemberApi.loadMemberRechaageRecording(card_no, mobile, start_date, end_date, page, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if(responseData != null && responseData.responseBean instanceof  AirMemberRechargeRecordingResponse){
                    callback.onSuccess((AirMemberRechargeRecordingResponse) responseData.responseBean);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result,responseData.resultMessage);
                return false;
            }
        });
    }


    /**
     * 会员储值消费记录查询
     * @param card_no
     * @param mobile
     * @param start_date
     * @param end_date
     * @param page
     * @param callback
     */
    public void loadMemberConsumptionRecording(String card_no, String mobile, String start_date, String end_date
            , int page, final ResultCallback<AirMemberConsumptionRecordingResponse> callback){
        MemberApi.loadMemberConsumptionRecording(card_no, mobile, start_date, end_date, page, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if(responseData != null && responseData.responseBean instanceof  AirMemberConsumptionRecordingResponse){
                    callback.onSuccess((AirMemberConsumptionRecordingResponse) responseData.responseBean);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result,responseData.resultMessage);
                return false;
            }
        });
    }


    public void loadMemberCardList(String cardNo, String mobile, int pageNo,final ResultCallback<AirMemberCardResponse> callback){

        MemberApi.loadMemberCardList(cardNo, mobile, pageNo,new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if(responseData != null && responseData.responseBean instanceof  AirMemberCardResponse){
                    callback.onSuccess((AirMemberCardResponse) responseData.responseBean);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.onFailure(responseData.result,responseData.resultMessage);
                return false;
            }
        });


    }

}
