package com.mwee.android.pos.air.business.member.entity.air;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.member.net.BaseMemberRequest;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;

import java.math.BigDecimal;

/**
 * 更新会员积分储值规则
 * Created by zhangmin on 2018/1/30.
 */

@HttpParam(
        httpType = HttpType.POST,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        method = "crm.membercard.setScRuleInfo",
        contentType = "application/json",
        response = BaseMemberResponse.class,
        saveToLog = true
)
public class AirMemberSocreGiftRuleUpdateRequest extends BaseMemberRequest {



    public BigDecimal cost_money_unit;//每消费多少
    public Integer increase_bonus;//赠送积分

    public String is_score;//是否开启积分


    public String cost_bonus_unit;//每使用 积分

    public String reduce_money;   //兑换金额

    public String is_clear;

    public String clear_day;

    public AirMemberSocreGiftRuleUpdateRequest() {
        super("crm.membercard.setScRuleInfo");
    }
}
