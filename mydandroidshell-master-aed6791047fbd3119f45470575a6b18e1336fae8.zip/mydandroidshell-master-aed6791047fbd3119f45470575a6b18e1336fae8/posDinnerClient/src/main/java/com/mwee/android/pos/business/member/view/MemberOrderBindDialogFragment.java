package com.mwee.android.pos.business.member.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mwee.android.pos.business.member.biz.IMemberProcess;
import com.mwee.android.pos.business.member.biz.MemberProcess;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.component.dialog.BaseDialogFragment;
import com.mwee.android.pos.component.dialog.DialogManager;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.component.keyboard.KeyboardManager;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.SettingHelper;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;

/**
 * 会员识别界面
 * Created by qinwei on 2017/2/20.
 */

public class MemberOrderBindDialogFragment extends BaseDialogFragment implements View.OnClickListener, TextView.OnEditorActionListener {
    public static final String TAG = MemberOrderBindDialogFragment.class.getSimpleName();
    private EditText mMemberSelectEdt;
    private Button mMemberSelectCommitBtn;
    private IMemberProcess mMemberProcess;
    private MemberCheckCallBack callBack;
    private NewMemberCheckCallBack newCallBack;
    private String orderId;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_member_bind_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.content).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mMemberSelectEdt = (EditText) view.findViewById(R.id.mMemberSelectEdt);
        mMemberSelectEdt.setOnEditorActionListener(this);
        mMemberSelectCommitBtn = (Button) view.findViewById(R.id.mMemberSelectCommitBtn);
        mMemberSelectCommitBtn.setOnClickListener(this);
        mMemberProcess = new MemberProcess();
    }


    @Override
    public void onDestroyView() {
        KeyboardManager.closeSoftInput(getActivityWithinHost());
        super.onDestroyView();
    }

    @Override
    public void onClick(View v) {
        String account = mMemberSelectEdt.getText().toString().trim();
        if (validateInput(account)) {
            doSelectRequest(account);
        }
    }

    private boolean validateInput(String account) {
        if (TextUtils.validate(account)) {
            return true;
        }
        ToastUtil.showToast("请输入会员卡号或者手机号");
        return false;
    }

    private void doSelectRequest(String cardNo) {
        ProgressManager.showProgress(getActivityWithinHost(), "查询会员中");
        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询ing 录入内容:" + cardNo);
        //ActionLog.addLog("会员信息查询ing", "", "", ActionLog.MEMBER_SELECT, "");
        mMemberProcess.optMemberInfoWithoutVerifyAndBindToOrder(cardNo, orderId, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());

                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->cardno=" + data.bindResponse.memberCardModel.cardInfo.card_no);
                newCallBack.call(data.bindResponse);
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());

                ToastUtil.showToast(msg);
                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询failure code=" + code + " msg=" + msg);
            }
        });
    }

    private void doSelectRequestByMobile(String mobile) {
        ProgressManager.showProgress(getActivityWithinHost(), "查询会员中");
        RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询ing 录入内容:" + mobile);
        mMemberProcess.optMemberInfoWithoutVerifyAndBindToOrder(mobile, orderId, new ResultCallback<NewQueryMemberListResponse>() {
            @Override
            public void onSuccess(NewQueryMemberListResponse data) {
                ProgressManager.closeProgress(getActivityWithinHost());

                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询done MemberCardModel->card size=" + data.cardList.size());
                if (data.bindResponse != null) {
                    newCallBack.call(data.bindResponse);
                    return;
                }
                MemberCardListChooseFragment fragment = new MemberCardListChooseFragment();
                fragment.setParams(data.cardList, orderId, newCallBack);
                DialogManager.showCustomDialog(getActivityWithinHost(), fragment, fragment.getTag());
                dismiss();
            }

            @Override
            public void onFailure(int code, String msg) {
                ProgressManager.closeProgress(getActivityWithinHost());

                ToastUtil.showToast(msg);
                RunTimeLog.addLog(RunTimeLog.MEMBER, "会员信息查询failure code=" + code + " msg=" + msg);
            }
        });
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            switch (v.getId()) {
                case R.id.mMemberSelectEdt:
                    String account = v.getText().toString();
                    if (validateInput(account)) {
                        if (RegexUtil.checkIsPhoneNumber(account)) {
                            doSelectRequestByMobile(account);
                        } else {
                            doSelectRequest(account);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        return false;
    }

    public void setNewCallBack(NewMemberCheckCallBack callBack) {
        this.newCallBack = callBack;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
