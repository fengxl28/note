package com.mwee.android.pos.business.member.entity;

import com.mwee.android.pos.business.member.constant.MemberRechargeChoosePayType;
import com.mwee.android.pos.dinner.R;

import java.util.ArrayList;

/**
 * 支付方式
 * Created by qinwei on 2017/3/1.
 */

public class RechargePayType {
    public String name;
    /**
     * 支付类型
     *
     * @see MemberRechargeChoosePayType
     */
    public int type;

    public int icon;
    public int bg;

    public RechargePayType(String name, int type, int icon, int bg) {
        this.name = name;
        this.type = type;
        this.icon = icon;
        this.bg = bg;
    }

    public static ArrayList<RechargePayType> getPayTypes() {
        ArrayList<RechargePayType> payTypes = new ArrayList<>();
        payTypes.add(new RechargePayType("微信", MemberRechargeChoosePayType.WECHAT, R.drawable.selector_member_recharge_type_icon_weixin, R.drawable.selector_member_recharge_type_bg_weixin));
        payTypes.add(new RechargePayType("支付宝", MemberRechargeChoosePayType.ALIPAY, R.drawable.selector_member_recharge_type_icon_alipay, R.drawable.selector_member_recharge_type_bg_alipay));
        payTypes.add(new RechargePayType("线下支付", MemberRechargeChoosePayType.CASH, R.drawable.selector_member_recharge_type_icon_cash, R.drawable.selector_member_recharge_type_bg_cash));
        return payTypes;
    }

}
