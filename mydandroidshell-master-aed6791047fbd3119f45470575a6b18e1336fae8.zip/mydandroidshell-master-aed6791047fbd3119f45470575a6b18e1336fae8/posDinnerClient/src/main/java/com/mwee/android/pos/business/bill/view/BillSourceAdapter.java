package com.mwee.android.pos.business.bill.view;

import android.content.Context;

import com.mwee.android.pos.business.permissions.view.NiceSpinnerAdapter;
import com.mwee.android.pos.db.business.BillSourceDBModel;

import java.util.List;

/**
 * Created by zhangmin on 2017/5/23.
 */

public class BillSourceAdapter extends NiceSpinnerAdapter {


    public BillSourceAdapter(Context context){
      super(context);
    }

    public BillSourceAdapter(Context context, List<BillSourceDBModel> items) {
        super(context, items);
    }

    @Override
    public String getItemInDataset(int position) {
        return getItem(position) == null ? "" : ((BillSourceDBModel)getItem(position)).fsBillSourceName;
    }
}
