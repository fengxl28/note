package com.mwee.android.pos.business.bill.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mwee.android.air.db.business.kbbean.future.KBPayOrderListResponse;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.business.bill.component.BillOnlineProcess;
import com.mwee.android.pos.component.calendar.CalendarPopupWindow;
import com.mwee.android.pos.component.callback.ResultCallback;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.TextUtils;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.pull.BaseViewHolder;
import com.mwee.android.pos.widget.pull.IFooterState;
import com.mwee.android.pos.widget.pull.PullRecyclerView;
import com.mwee.android.tools.DateUtil;

import java.util.Date;

/**
 * Created by qinwei on 2018/12/5.
 */

public class KBAfterPayOrderLstFragment extends BaseListFragment<KBPayOrderListResponse.KBAfterPayOrder> implements View.OnClickListener {

    private String mSelectDate;
    private int currentPage = 1;//当前页索引
    private int willLoadPage;//需要加载的页索引
    private TextView mBillOnlineFilterTimeLabel;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.kb_after_pay_order_list_fragment;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mPullRecyclerView.setEnablePullToEnd(true);
        mPullRecyclerView.setEmptyView(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.view_data_empty, null));
        mBillOnlineFilterTimeLabel = (TextView) view.findViewById(R.id.mBillOnlineFilterTimeLabel);
        mBillOnlineFilterTimeLabel.setOnClickListener(this);
    }


    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setRefreshing();
        mSelectDate = DateUtil.getCurrentDate("yyyy-MM-dd");//默认当前日期
        mBillOnlineFilterTimeLabel.setText(mSelectDate);
    }

    public void loadDataFromServer() {
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_START);
    }

    public void loadDataFromServer(final int mode) {
        BillOnlineProcess.loadBillKBAfterPayList(mSelectDate, willLoadPage, new ResultCallback<KBPayOrderListResponse.KBPayOrderList>() {
            @Override
            public void onSuccess(KBPayOrderListResponse.KBPayOrderList data) {
                if (data != null && TextUtils.validate(data.list)) {
                    currentPage = willLoadPage;//更新当前页数
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                    }
                    //显示数据内容
                    mPullRecyclerView.showContent();
                    if (data.list.size() < 20) {//nextPage==0表明当前已经是最后一页
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);//显示无更多数据label
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode);
                    }
                    modules.addAll(data.list);
                    adapter.notifyDataSetChanged();
                } else {
                    if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                        modules.clear();
                        adapter.notifyDataSetChanged();
                        mPullRecyclerView.showEmptyView();
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);//移除state footerView
                    } else {
                        mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_NO_DATA);
                    }
                }
            }

            @Override
            public void onFailure(int code, String msg) {
                if (mode == PullRecyclerView.MODE_PULL_TO_START) {
                    if (modules.size() == 0) {
                        mPullRecyclerView.showEmptyView();
                    }
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_REMOVE);
                } else {
                    mPullRecyclerView.onRefreshCompleted(mode, IFooterState.LOAD_MORE_STATE_ERROR);
                }
                ToastUtil.showToast(msg);
            }
        });
    }

    @Override
    public void onRefresh(int mode) {
        super.onRefresh(mode);
        if (mode == PullRecyclerView.MODE_PULL_TO_START) {
            willLoadPage = 1;
        } else {
            willLoadPage = currentPage + 1;
        }
        loadDataFromServer(mode);
    }

    @Override
    public void onLoadMoreRetry() {
        super.onLoadMoreRetry();
        loadDataFromServer(PullRecyclerView.MODE_PULL_TO_END);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBillOnlineFilterTimeLabel:
                showChoiceDate();
                break;
            default:
                break;
        }
    }

    public void showChoiceDate() {
        CalendarPopupWindow calendarPopupwindow = new CalendarPopupWindow(getActivityWithinHost(), rootView);
        calendarPopupwindow.setDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        calendarPopupwindow.show();
        calendarPopupwindow.setCallback(new CalendarPopupWindow.Callback() {
            @Override
            public void onConfirm(String newDate) {
                if (!newDate.equals(mSelectDate)) {
                    mSelectDate = newDate;
                    mBillOnlineFilterTimeLabel.setText(newDate);
                    modules.clear();
                    adapter.notifyDataSetChanged();
                    mPullRecyclerView.setRefreshing();
                }
            }
        });
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getActivityWithinHost()).inflate(R.layout.kb_after_pay_order_item, parent, false));
    }


    private class Holder extends BaseViewHolder {
        private TextView mPayPriceItemLabel;
        private TextView mPayTypeItemLabel;
        private TextView mPayStatusItemLabel;
        private TextView mPayBillNoItemLabel;
        private TextView mPayKBOrderIdItemLabel;
        private TextView mPayPosOrderIdItemLabel;
        private TextView mPayCreateTimeItemLabel;
        private KBPayOrderListResponse.KBAfterPayOrder model;


        public Holder(View v) {
            super(v);
            mPayPriceItemLabel = (TextView) v.findViewById(R.id.mPayPriceItemLabel);
            mPayTypeItemLabel = (TextView) v.findViewById(R.id.mPayTypeItemLabel);
            mPayStatusItemLabel = (TextView) v.findViewById(R.id.mPayStatusItemLabel);
            mPayBillNoItemLabel = (TextView) v.findViewById(R.id.mPayBillNoItemLabel);
            mPayKBOrderIdItemLabel = (TextView) v.findViewById(R.id.mPayKBOrderIdItemLabel);
            mPayPosOrderIdItemLabel = (TextView) v.findViewById(R.id.mPayPosOrderIdItemLabel);
            mPayCreateTimeItemLabel = (TextView) v.findViewById(R.id.mPayCreateTimeItemLabel);
        }

        @Override
        public void bindData(int position) {
            model = modules.get(position);
            mPayPriceItemLabel.setText(model.buyerAmount.toPlainString());
            String payTypeName = model.payType;
            switch (model.payType) {
                case KBPayOrderListResponse.KBAfterPayOrder.PayType.ALIPAY:
                    payTypeName = "支付宝";
                    break;
                default:
                    break;
            }
            mPayTypeItemLabel.setText(payTypeName);
            String status = model.status;
            switch (model.status) {
                case KBPayOrderListResponse.KBAfterPayOrder.Status.SUCCESS:
                    status = "已结账";
                    break;
                case KBPayOrderListResponse.KBAfterPayOrder.Status.REFUND:
                    status = "已退款";
                    break;
                case KBPayOrderListResponse.KBAfterPayOrder.Status.PAY:
                    status = "支付";
                    break;
                case KBPayOrderListResponse.KBAfterPayOrder.Status.CLOSE:
                    status = "已关单";
                    break;
                default:
                    break;
            }
            mPayStatusItemLabel.setText(status);
            mPayBillNoItemLabel.setText(model.paymentId);
            mPayKBOrderIdItemLabel.setText(model.thirdOrderId);
            mPayPosOrderIdItemLabel.setText(model.posOrderId);
            mPayCreateTimeItemLabel.setText(model.payTime);
        }

    }
}
