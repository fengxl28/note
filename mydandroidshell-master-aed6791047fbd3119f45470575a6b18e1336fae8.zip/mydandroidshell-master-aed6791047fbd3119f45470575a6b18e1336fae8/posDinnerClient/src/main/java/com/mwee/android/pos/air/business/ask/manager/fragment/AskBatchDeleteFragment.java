package com.mwee.android.pos.air.business.ask.manager.fragment;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.pos.air.business.ask.manager.processor.AskProcessor;
import com.mwee.android.pos.base.BaseListFragment;
import com.mwee.android.pos.component.dialog.ProgressManager;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.dinner.R;
import com.mwee.android.pos.util.ButtonClickTimer;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.widget.TitleBar;
import com.mwee.android.pos.widget.pull.BaseViewHolder;

import java.util.ArrayList;

/**
 * Created by qinwei on 2017/10/10.
 */

public class AskBatchDeleteFragment extends BaseListFragment<AirAskManageInfo> implements View.OnClickListener {
    private TitleBar mTitleBar;
    private TextView mAskBatchChoiceAllLabel;
    private TextView mAskBatchChoiceValueLabel;
    private Button mAskBatchDeleteBtn;
    private Button mAskBatchCancelBtn;
    private AskProcessor mProcessor;
    private ArrayList<String> choiceStates = new ArrayList<>();
    private OnAskBatchDeleteListener listener;

    @Override
    public int getFragmentLayoutId() {
        return R.layout.fragment_ask_batch_delete;
    }


    @Override
    protected void initView(View view) {
        super.initView(view);
        mTitleBar = (TitleBar) view.findViewById(R.id.mTitleBar);
        mTitleBar.setOnBackClickListener(new TitleBar.OnBackClickListener() {
            @Override
            public void onBackClick() {
                dismissSelf();
            }
        });
        mTitleBar.setTitle(R.string.ask_batch_delete_title);
        ((TextView) view.findViewById(R.id.title_tips)).setText("请选择需要删除的菜品要求");
        mAskBatchChoiceAllLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceAllLabel);
        mAskBatchChoiceValueLabel = (TextView) view.findViewById(R.id.mAskBatchChoiceValueLabel);
        mAskBatchDeleteBtn = (Button) view.findViewById(R.id.mAskBatchDeleteBtn);
        mAskBatchCancelBtn = (Button) view.findViewById(R.id.mAskBatchCancelBtn);
        mAskBatchDeleteBtn.setOnClickListener(this);
        mAskBatchCancelBtn.setOnClickListener(this);
        mAskBatchChoiceAllLabel.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        super.initData();
        mPullRecyclerView.setEnablePullToStart(false);
        modules.addAll(mProcessor.airAskManageInfoToShowList);
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    @Override
    public RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(getContext(), 7);
    }

    @Override
    protected BaseViewHolder onCreateItemView(ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(getContext()).inflate(R.layout.item_ask_batch_delete_item, parent, false));
    }

    @Override
    public void onClick(View v) {
        if (!ButtonClickTimer.canClick()) {
            return;
        }
        switch (v.getId()) {
            case R.id.mAskBatchDeleteBtn:
                doBatchDeleteChoice();
                break;
            case R.id.mAskBatchCancelBtn:
                dismissSelf();
                break;
            case R.id.mAskBatchChoiceAllLabel:
                doChoiceAllClick();
                break;
            default:
                break;
        }
    }

    private void doChoiceAllClick() {
        mAskBatchChoiceAllLabel.setSelected(!mAskBatchChoiceAllLabel.isSelected());
        if (mAskBatchChoiceAllLabel.isSelected()) {
            choiceAll();
        } else {
            cancelChoiceAll();
        }
        adapter.notifyDataSetChanged();
        refreshUI();
    }

    private void doBatchDeleteChoice() {
        if (ListUtil.isEmpty(choiceStates)) {
            ToastUtil.showToast("请选择要删除的要求");
            return;
        }

        ProgressManager.showProgress(getActivityWithinHost());
        mProcessor.batcheDeleteAsk(choiceStates, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                ProgressManager.closeProgress(getActivityWithinHost());
                if (result) {
                    listener.onDeleteSuccess();
                    dismissSelf();
                } else {
                    ToastUtil.showToast(android.text.TextUtils.isEmpty(info) ? getResources().getString(R.string.tip_delete_error) : info);
                }
            }
        });
    }

    private void refreshUI() {
        mAskBatchChoiceValueLabel.setText(String.format(getString(R.string.ask_choice_size_label), choiceStates.size()));
        mAskBatchDeleteBtn.setEnabled(choiceStates.size() > 0);
    }

    class Holder extends BaseViewHolder implements View.OnClickListener {
        private TextView mAskNameLabel;
        private TextView mAskPriceLabel;
        private AirAskManageInfo askDBModel;

        public Holder(View v) {
            super(v);
            v.setOnClickListener(this);
            mAskNameLabel = (TextView) v.findViewById(R.id.mAskNameLabel);
            mAskPriceLabel = (TextView) v.findViewById(R.id.mAskPriceLabel);
        }

        @Override
        public void bindData(int position) {
            askDBModel = modules.get(position);
            mAskNameLabel.setText(askDBModel.fsAskName);
            mAskPriceLabel.setText(String.format(getString(R.string.ask_price_label), askDBModel.fdAddPrice.toPlainString()));
            if (choiceStates.contains(askDBModel.fiId)) {
                itemView.setBackgroundColor(getResources().getColor(R.color.system_red));
                mAskNameLabel.setTextColor(getResources().getColor(R.color.white));
                mAskPriceLabel.setTextColor(getResources().getColor(R.color.white));
            } else {
                itemView.setBackgroundColor(getResources().getColor(R.color.white));
                mAskNameLabel.setTextColor(getResources().getColor(R.color.color_363636));
                mAskPriceLabel.setTextColor(getResources().getColor(R.color.color_282828));
            }
        }

        @Override
        public void onClick(View v) {
            choice(askDBModel.fiId);
            adapter.notifyItemChanged(modules.indexOf(askDBModel));
            mAskBatchChoiceAllLabel.setSelected(isChoiceAll());
            refreshUI();
        }
    }

    private void choice(String value) {
        if (choiceStates.contains(value)) {
            choiceStates.remove(value);
        } else {
            choiceStates.add(value);
        }
    }


    private boolean isChoiceAll() {
        for (int i = 0; i < modules.size(); i++) {
            if (!choiceStates.contains(modules.get(i).fiId)) {
                return false;
            }
        }
        return true;
    }

    private void choiceAll() {
        choiceStates.clear();
        for (int i = 0; i < modules.size(); i++) {
            choiceStates.add(modules.get(i).fiId);
        }
    }

    private void cancelChoiceAll() {
        choiceStates.clear();
    }

    public void setParam(OnAskBatchDeleteListener listener, AskProcessor mProcessor) {
        this.listener = listener;
        this.mProcessor = mProcessor;
    }

    public interface OnAskBatchDeleteListener {
        void onDeleteSuccess();
    }
}
