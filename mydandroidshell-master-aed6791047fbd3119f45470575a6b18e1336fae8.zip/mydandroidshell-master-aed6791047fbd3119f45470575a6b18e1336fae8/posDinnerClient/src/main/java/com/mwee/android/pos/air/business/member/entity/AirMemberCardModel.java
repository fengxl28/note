package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/1/29.
 */

public class AirMemberCardModel extends BusinessBean {


    public String country;

    public String card_parent_no;

    public int source;

    public int type;

    public int is_perfect;

    public int is_sync_wx_card;

    public String ali_user_id;

    public long score;

    public String province;

    public long balance;

    public String entity_card_act_pwd;

    public String merge_card_no;

    public String lat;

    public String area;

    public String image;

    public String lng;

    public int level;

    public String openid;

    public String shop_name;

    public int act_shopid;

    public int user_id;

    public long shopid;

    public String wx_card_code;

    public int is_entreprise;

    public int gender;

    public String city;

    public String id_card;

    public String who_open_entity_card;

    public String real_name;

    public String remark;

    public int entity_card_status;

    public String nick;

    public int is_bind_entity_card;

    public long update_time;

    public String card_no;

    public int last_deposit_time;

    public String pay_password;

    public int m_shopid;

    public String ali_app_id;

    public int entity_card_is_main;

    public int cs_id;

    public int cost;

    public int act_time;

    public String ali_card_no;

    public String mobile;

    public String appid;

    public String from_identif;

    public long add_time;

    public int is_sync_ali_card;

    public String title;//黄金会员


}
