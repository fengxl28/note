package com.mwee.android.pos.air.business.member.entity;

/**
 * Created by qinwei on 2017/10/17.
 */

public class MemberInfoUpdate extends BaseMemberParam {
    public int m_shopid;
    public int shop_id;
    public String editor_mobile = "";
    public String name = "";
    public int gender = 0;//0 保密  1=>男  2=>女
    public int source = 8;//1、商家微信关注 2、排队 3、预定 4、支付 5、点菜 6、导入 7、秒付8、美易点 101、美团外卖 102、饿了么外卖 103、百度外卖
    public String password;//密码(要求6位数字)+cardmwee
    public String birthday;//出生日期
    public int level;
    public String card_no;

    public MemberInfoUpdate() {

    }
}
