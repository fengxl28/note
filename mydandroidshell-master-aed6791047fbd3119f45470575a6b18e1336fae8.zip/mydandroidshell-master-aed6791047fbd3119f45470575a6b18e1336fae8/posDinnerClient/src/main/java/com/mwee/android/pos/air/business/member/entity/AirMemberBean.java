package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by qinwei on 2017/10/17.
 */

public class AirMemberBean<T> extends BusinessBean {
    public int status;
    public T data;
    public String msg = "";

    public AirMemberBean() {
    }
}
