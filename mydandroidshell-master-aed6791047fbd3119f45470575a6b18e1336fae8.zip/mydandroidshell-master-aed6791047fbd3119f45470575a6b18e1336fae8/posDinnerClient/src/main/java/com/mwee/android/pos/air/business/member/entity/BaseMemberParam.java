package com.mwee.android.pos.air.business.member.entity;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.util.ClientHardwareUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by qinwei on 2017/10/17.
 */

public class BaseMemberParam extends BusinessBean {
    public String v = "1.0";
    public String appid = String.valueOf(1010);
    public String method = "";
    public String uuid = ClientHardwareUtil.getHardWareSymbol();
    public String platform = "android";
    public String _timestamp = String.valueOf(DateUtil.getCurrentTimeInMills() / 1000);

    public BaseMemberParam() {
    }
}
