--[[
    Virtual Bluetooth Lua Parse Script
    虚拟蓝牙打印解析脚本

Global function:
    setId(String)
    setName(String)
    setAddress(String)
    setPhone(String)
    setTotal(String)
    setTime(String)
    setComment(String)
    setPayed(Boolean)
    addParam(String Key, String Value)
    addProduct(String Name, String Number, String Price)
    toUtf8(String)
    removeBytes(String src, String bytes)
    pkgVersion(String)
    regx(String, String)
    regxnext(Object)
    setPrintCmd(String)
    setExp(String)
    setEst(String)
]]

function version()
    return "1.6.2"
end

function fixOrders()
    -- return as "20180101"
    return ""
end

function autoRunFix()
    -- For debug
    return ""
end

-------------------------------------------------
-- Utility
string.split = function(s, p)
    local rt = {}
    string.gsub(s, '[^' .. p .. ']+', function(w)
        table.insert(rt, w)
    end)
    return rt
end

local utf8 = {}

function utf8.charbytes (s, i)
    -- argument defaults
    i = i or 1
    local c = string.byte(s, i)

    -- determine bytes needed for character, based on RFC 3629
    if c > 0 and c <= 127 then
        -- UTF8-1
        return 1
    elseif c >= 194 and c <= 223 then
        -- UTF8-2
        local c2 = string.byte(s, i + 1)
        return 2
    elseif c >= 224 and c <= 239 then
        -- UTF8-3
        local c2 = s:byte(i + 1)
        local c3 = s:byte(i + 2)
        return 3
    elseif c >= 240 and c <= 244 then
        -- UTF8-4
        local c2 = s:byte(i + 1)
        local c3 = s:byte(i + 2)
        local c4 = s:byte(i + 3)
        return 4
    end
end

-- returns the number of characters in a UTF-8 string
function utf8.len (s)
    local pos = 1
    local bytes = string.len(s)
    local len = 0

    while pos <= bytes and len ~= chars do
        local c = string.byte(s, pos)
        len = len + 1

        pos = pos + utf8.charbytes(s, pos)
    end

    if chars ~= nil then
        return pos - 1
    end

    return len
end

-- functions identically to string.sub except that i and j are UTF-8 characters
-- instead of bytes
function utf8.sub (s, i, j)
    j = j or -1

    if i == nil then
        return ""
    end

    local pos = 1
    local bytes = string.len(s)
    local len = 0

    -- only set l if i or j is negative
    local l = (i >= 0 and j >= 0) or utf8.len(s)
    local startChar = (i >= 0) and i or l + i + 1
    local endChar = (j >= 0) and j or l + j + 1

    -- can't have start before end!
    if startChar > endChar then
        return ""
    end

    -- byte offsets to pass to string.sub
    local startByte, endByte = 1, bytes

    while pos <= bytes do
        len = len + 1

        if len == startChar then
            startByte = pos
        end

        pos = pos + utf8.charbytes(s, pos)

        if len == endChar then
            endByte = pos - 1
            break
        end
    end

    return string.sub(s, startByte, endByte)
end

-- replace UTF-8 characters based on a mapping table
function utf8.replace (s, mapping)
    local pos = 1
    local bytes = string.len(s)
    local charbytes
    local newstr = ""

    while pos <= bytes do
        charbytes = utf8.charbytes(s, pos)
        local c = string.sub(s, pos, pos + charbytes - 1)
        newstr = newstr .. (mapping[c] or c)
        pos = pos + charbytes
    end

    return newstr
end

--return utf8
--local utf8 = require("utf8")


function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local xstr = {}

function isdigit(str)
    if str == nil then
        return nil, "the string parameter is nil"
    end
    local len = string.len(str)
    for i = 1, len do
        local ch = string.sub(str, i, i)
        if ch ~= '-' and ch ~= '.' then
            if ch < '0' or ch > '9' then
                return false
            end
        end
    end
    return true
end
-------------------------------------------------

PRODUCT_PACKAGE_ELE = 1
PRODUCT_PACKAGE_MEITUAN = 2
PRODUCT_PACKAGE_TAO = 3
PRODUCT_PACKAGE_BAIDU = 4
PRODUCT_PACKAGE_LING = 5
PRODUCT_PACKAGE_JD = 6
PRODUCT_PACKAGE_SM = 7
PRODUCT_PACKAGE_PAI = 8

pkgs = {
    ["美团外卖"] = PRODUCT_PACKAGE_MEITUAN,
}

apps = {
    [PRODUCT_PACKAGE_MEITUAN] = "com.sankuai.meituan.meituanwaimaibusiness",
}

orderids = {
    [PRODUCT_PACKAGE_ELE] = "#(%d+)",
    [PRODUCT_PACKAGE_MEITUAN] = "＃(%d+)|#(%d+)",
    [PRODUCT_PACKAGE_TAO] = "#(%d+)",
    [PRODUCT_PACKAGE_BAIDU] = "#(%d+)",
    [PRODUCT_PACKAGE_LING] = "(%d+%a+%d+)",
    [PRODUCT_PACKAGE_JD] = "订单编号：(%d+)|订单编号:(%d+)",
    [PRODUCT_PACKAGE_SM] = "#(%d+)",
    [PRODUCT_PACKAGE_PAI] = "#(%d+)"
}

cids = {
    [PRODUCT_PACKAGE_ELE] = "hov:LK3_APP_ELM/",
    [PRODUCT_PACKAGE_MEITUAN] = "hov:LK3_APP_MTWM/",
    [PRODUCT_PACKAGE_TAO] = "hov:LK3_APP_KBWM/",
    [PRODUCT_PACKAGE_BAIDU] = "hov:LK3_APP_BDWM/",
    [PRODUCT_PACKAGE_PAI] = "hov:LK3_APP_PLQ/"
}

templates = {
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "3.1.8",
        blocks = "--------------------------------",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 8,
        sign = "",
        items = {
            {
                reg = "(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME",
                global = true,
                num = 0
            },
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "总计\\s+\\S+￥([0-9]+.?[0-9]*)",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "总计\\s+￥([0-9]+.?[0-9]*)",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 6
            },
            {
                reg = "(.*)\\s+x(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 3
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 4
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 4
            },
            {
                reg = "(.*):-￥([0-9]*.?[0-9]*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 4
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "3.1.8",
        blocks = "--------------------------------",
        blocktype = "HEAD|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 7,
        sign = "",
        items = {
            {
                reg = "(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME",
                global = true,
                num = 0
            },
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 5
            },
            {
                reg = "(.*)\\s+x(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 3
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 3
            },
            {
                reg = "(.*):-?￥([0-9]*.?[0-9]*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 3
            },
            {
                reg = "(.*):-?￥([0-9]*.?[0-9]*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 4
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "3.1.8",
        blocks = "--------------------------------",
        blocktype = "HEAD|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 6,
        sign = "",
        items = {
            {
                reg = "(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME",
                global = true,
                num = 0
            },
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s+x(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "3.4.0.226",
        blocks = "--------------------------------",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "",
        items = {
            {
                reg = "(\\d\\d\\d\\d)-(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME",
                global = true,
                num = 0
            },
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "合计:\\s+\\S+\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "总计\\s+\\S+￥([0-9]+.?[0-9]*)",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "总计\\s+￥([0-9]+.?[0-9]*)",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 6
            },
            {
                reg = "(.*)\\s*x(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 3
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 4
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 4
            },
            {
                reg = "(.*):\\s+-?￥([0-9]*.?[0-9]*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 4
            }
        }
    },

    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "4.2.0",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "商家联",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "4.2.0",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "给商家",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 5
            },
            {
                reg = "(.*)\\s*\\*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 3
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 3
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 3
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "4.2.0",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "商家小票",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 5
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 3
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 3
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 3
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "4.2.0",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "给顾客",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "原价：[0-9]+.?[0-9]*元\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "4.2.0",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "给配送",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 0,
        sign = "商家小票",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 3
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 3
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 3
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 6,
        sign = "",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 5,
        sign = "",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER2",
                global = false,
                num = 1
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|GOODS|SIGNLEGOODS|DUMMY|CUSTOMER|DUMMY",
        blocknum = 7,
        sign = "",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|DUMMY|DUMMY|CUSTOMER|GOODS|SIGNLEGOODS|DUMMY",
        blocknum = 8,
        sign = "",
        items = {
            {
                reg = "(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 4
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "【顾客到店自取】|--------------------------------|--------------------------------|********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|CUSTOMER2|GOODS|SIGNLEGOODS|DUMMY|DUMMY",
        blocknum = 9,
        sign = "",
        items = {
            {
                reg = "下单时间：(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER2",
                global = false,
                num = 1
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "预计\\\n(\\S+) (\\d+):(\\d+)\\\n到店",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预计(\\S+) (\\d+):(\\d+)到店",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "【顾客到店自取】|--------------------------------|--------------------------------|********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|CUSTOMER2|GOODS|SIGNLEGOODS|DUMMY|DUMMY",
        blocknum = 11,
        sign = "",
        items = {
            {
                reg = "下单时间：(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER2",
                global = false,
                num = 1
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "预计\\\n(\\S+) (\\d+):(\\d+)\\\n到店",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "预计(\\S+) (\\d+):(\\d+)到店",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "【顾客到店自取】|--------------------------------|--------------------------------|********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|CUSTOMER2|GOODS|SIGNLEGOODS|DUMMY|DUMMY",
        blocknum = 15,
        sign = "",
        items = {
            {
                reg = "下单时间：(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER2",
                global = false,
                num = 1
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "预计(\\S+) (\\d+):(\\d+)到店",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*\\s*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
    {
        pkg = "com.sankuai.meituan.meituanwaimaibusiness",
        ver = "default",
        blocks = "********************************|--------------------------------|--------------其它--------------|------------[其它]------------|----------+其它----------+[^-]|----------+[其它]----------+[^-]",
        blocktype = "HEAD|DUMMY|CUSTOMER|GOODS|SIGNLEGOODS|DUMMY|DUMMY",
        blocknum = 0,
        sign = "给顾客",
        items = {
            {
                reg = "下单时间：(\\d\\d)-(\\d\\d) (\\d\\d):(\\d\\d)",
                type = "TIME2",
                global = true,
                num = 0
            },
            {
                reg = "原价：([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "原价：[0-9]+.?[0-9]*元\\s+([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(已付款\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户货到付款\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(用户在线支付\\)([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "\\(在线支付\\)\\\n([0-9]+.?[0-9]*)元",
                type = "TOTAL",
                global = true,
                num = 0
            },
            {
                reg = "已付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线付款",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "在线支付",
                type = "HASPAYED",
                global = true,
                num = 0
            },
            {
                reg = "期望送达时间: \\[(\\d+):(\\d+)\\]",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望(\\S+) (\\d+):(\\d+)送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "期望\\\n(\\S+) (\\d+):(\\d+)\\\n送达",
                type = "ESPTIME",
                global = true,
                num = 0
            },
            {
                reg = "备注:(\.*)",
                type = "NOTE",
                global = true,
                num = 0
            },
            {
                reg = "发票:(\.*)",
                type = "REPITE",
                global = true,
                num = 0
            },
            {
                reg = "预订单送达时间\\[(\\d+)-(\\d+)-(\\d+) (\\d+):(\\d+)\\]",
                type = "ESPTIME2",
                global = true,
                num = 0
            },
            {
                reg = "(\\S+)",
                type = "CUSTOMER",
                global = false,
                num = 0
            },
            {
                reg = "(.*)\\s*\\*(\\d+)\\s+(-?[0-9]+.?[0-9]*)",
                type = "GOODS",
                global = false,
                num = 1
            },
            {
                reg = "(.*)\\s+(-?[0-9]+.?[0-9]*)",
                type = "SIGNLEGOODS",
                global = false,
                num = 2
            },
            {
                reg = "\\[赠送(\\S*)\\s?(\\S*)\\s*x(\\d+)\\]",
                type = "GIVE",
                global = false,
                num = 2
            },
            {
                reg = "(.*)\\s+-?￥([0-9]*.?[0-9]*)(.*)",
                type = "SIGNLEGOODS2",
                global = false,
                num = 2
            }
        }
    },
}

APP_TYPE = 0
PKG_VERSION = ""
BILL_TIME = ""
BILL_ID = ""
BILL_NO = ""
EXT_BLOCK_NUM = 0
START_BLOCK_NO = 0

function parseAppType(data)
    for key, value in pairs(pkgs) do
        local pos = string.find(data, key, 0)
        if pos ~= nil then
            setApp(apps[value])
            APP_TYPE = value
            PKG_VERSION = pkgVersion(apps[value])
            print("PKG_VERSION: " .. PKG_VERSION)
            setCid(cids[value])
            do
                return
            end
        end
    end
end

function setCustomPrintCommand(cfg)
    if APP_TYPE == PRODUCT_PACKAGE_LING then
        if cfg.ver == "3.0.2" then
            setPrintCmd('\32\32\10\32\32\10\32\32\10\32\32\10\32\32\10\32\32\10\32\32\10')
        end
    end
end

function parseOrderId(data)
    local idt = orderids[APP_TYPE]
    local idts = string.split(idt, "|")
    for _, s in ipairs(idts) do
        local _, _, id = string.find(data, s, 0)
        if id ~= nil then
            setId(id)
            BILL_ID = id
        end
    end
end

function setShortId()
    if BILL_ID ~= "" then
        local sid = ""
        local btime = BILL_TIME
        if btime == "" then
            btime = os.date("%Y%m%d%H%M%S", os.time());
        end
        if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
            sid = "mt" .. btime .. string.format("%04d", BILL_ID);
        else
            local ts = os.date("%Y%m%d%H%M%S", os.time());
            sid = "lkerr" .. ts
        end
        setId(sid)
    end
end

--[[
function setShortId()
    if BILL_ID ~= "" then
        local sid = ""
        local btime = BILL_TIME
        if btime == "" then
            btime = os.date("%Y%m%d%H%M%S", os.time());
        end
        if APP_TYPE == PRODUCT_PACKAGE_ELE then
            sid = "EL" .. btime .. string.format("%04d", BILL_ID);
        elseif APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
            sid = "MT" .. btime .. string.format("%04d", BILL_ID);
        elseif APP_TYPE == PRODUCT_PACKAGE_TAO then
            sid = "TO" .. btime .. string.format("%04d", BILL_ID);
        elseif APP_TYPE == PRODUCT_PACKAGE_BAIDU then
            sid = "BD" .. btime .. string.format("%04d", BILL_ID);
        elseif APP_TYPE == PRODUCT_PACKAGE_LING then
            sid = "ZL" .. BILL_ID;
        elseif APP_TYPE == PRODUCT_PACKAGE_JD then
            sid = "JD" .. BILL_ID;
        elseif APP_TYPE == PRODUCT_PACKAGE_SM then
            sid = "SM" .. BILL_NO .. string.format("%04d", BILL_ID);
        elseif APP_TYPE == PRODUCT_PACKAGE_PAI then
            sid = "PI" .. btime .. string.format("%04d", BILL_ID);
        else
            local ts = os.date("%Y%m%d%H%M%S", os.time());
            sid = "LKERR" .. ts
        end
        setId(sid)
    end
end
]]

function removePrintCommand(data)
    local cmds = "1b4404121800 1b240000 1b241a01 1b242501 1b242c01 1b243001 1b243b01 1b243b0a 1b244001 1b244601 1b24dc00 1b24f200 1b24fa00 1b24e700 1b33000a 1b33210a 1b2100 1b2101 1b2108 1b2110 1b2138 1b2400 1b3300 1b3321 1b3364 1b4500 1b4501 1b450f 1b4700 1b4701 1b4d00 1b6100 1b6101 1b6102 1d2100 1d2101 1d2111 1d4200 1b40"
    local u8data = removeBytes(data, cmds)
    return u8data
end

function removeplacePrintCommand(data)
    local rmcmds = "1b4404121800 1b240000 1b241a01 1b242501 1b242c01 1b243001 1b243b01 1b243b0a 1b244001 1b244601 1b24dc00 1b24f200 1b24fa00 1b33000a 1b33210a 1b2101 1b2108 1b2110 1b2138 1b2400 1b3300 1b3321 1b3364 1b4500 1b4501 1b450f 1b4700 1b4701 1b4d00 1b6100 1b6101 1b6102 1d2100 1d2101 1d2111 1d4200 1b40"
    local rpcmds = "1b2100 1b2110 1b2120"
    local u8data = replaceBytes(data, rmcmds, rpcmds)
    return u8data
end

function calcblocknum(data, split)
    local count = 1;
    local sps = string.split(split, "|")
    for _, s in ipairs(sps) do
        local sf = string.gsub(s, "%*", "%%*")
        sf = string.gsub(sf, "%-", "%%-")
        local _, cc = string.gsub(data, sf, "")
        count = count + cc
    end
    return count
end

function calcPackageVersion(version)
    local count = 0;
    if version == "default" or version == "" then
        return 999999
    end
    local sps = string.split(version, ".")
    local no = 1
    for _, s in ipairs(sps) do
        count = count * 100
        count = count + s

        no = no + 1
        if no > 3 then
            break
        end
    end
    return count
end

function getblockpos(data, split, num, pos)
    local count = 1
    local sps = string.split(split, "|")
    local start = -1
    local len = 0
    for _, s in ipairs(sps) do
        local sf = string.gsub(s, "%*", "%%*")
        sf = string.gsub(sf, "%-", "%%-")
        local tmp = string.find(data, sf, pos)
        if tmp ~= nil then
            if start < 0 or tmp < start then
                start = tmp
                len = string.len(s)
            end
        end
    end
    return start, len
end

function getblockdata(data, split, num)
    local spos = 0
    local epos = 0
    local rs = nil
    local len = 1
    for i = 0, num do
        epos, len = getblockpos(data, split, 1, spos)
        if num == i then
            if epos == nil then
                rs = string.sub(data, spos)
            else
                rs = string.sub(data, spos, epos - 1)
                --print("spos:" .. spos .. " epos:" .. epos .. " slen:" .. len)
            end
            break
        end
        if len == 0 then
            len = 1
        end
        spos = epos + len
    end
    return rs
end

function calcExtBlock(data)
    EXT_BLOCK_NUM = 0
    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        --for i = 2, 100 do
        --    local s = i .. "号口袋"
        --    if string.find(data, s) == nil then
        --        break
        --    end
        --    EXT_BLOCK_NUM = EXT_BLOCK_NUM + 1
        --end
        --

        local s2, e2 = string.find(data, "【顾客到店自取】")
        if s2 ~= nil then
            EXT_BLOCK_NUM = EXT_BLOCK_NUM + 3
            local s3, e3 = string.find(data, "备注:")
            local s4, e4 = string.find(data, "发票:")
            if s3 ~= nil or s4 ~= nil then
                EXT_BLOCK_NUM = EXT_BLOCK_NUM + 1
            end
            --print("-------------找的自取了---------------")
        end

        local s2, e2 = string.find(data, "%*  预订单  %*")
        if s2 ~= nil then
            START_BLOCK_NO = 1
        end

        local s3, e3 = string.find(data, "预订单送达时间")
        if s3 ~= nil then
            local vernum = calcPackageVersion(PKG_VERSION)
            --print("vernum: " .. vernum .. "   PKG_VERSION:" .. PKG_VERSION)
            if vernum < 30212 then
                START_BLOCK_NO = 2
            else
                START_BLOCK_NO = 1
            end
        end
    end
    print("Extent Block number: " .. EXT_BLOCK_NUM)
    print("Start Block No: " .. START_BLOCK_NO)
end

function calcConfig(data)
    calcExtBlock(data)
    for i = 1, #templates do
        while true do
            cfg = templates[i]
            if cfg.pkg == apps[APP_TYPE] then
                if cfg.ver == PKG_VERSION or cfg.ver == "default" then
                    --print("Find app configure pkg: " .. cfg.pkg .. " ver: " .. cfg.ver .. " blocks: " .. cfg.blocks
                    --        .. " num: " .. cfg.blocknum .. " type: " .. cfg.blocktype)

                    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
                        local vernum = calcPackageVersion(PKG_VERSION)
                        if vernum > 30700 and cfg.sign ~= "" then
                            local s, e = string.find(data, cfg.sign)
                            if s == null then
                                break
                            end
                            print("sign:" .. cfg.sign)
                        end
                    end

                    if cfg.blocknum == 0 then
                        -- ignore block number
                        return cfg
                    end

                    local blocknum = calcblocknum(data, cfg.blocks)

                    --print("---------cfg.blocknum-----------" .. cfg.blocknum ..
                    --        "-------EXT_BLOCK_NUM----" .. EXT_BLOCK_NUM .. "------START_BLOCK_NO------"
                    --        .. START_BLOCK_NO .. "----")

                    print("block num:" .. blocknum)
                    if blocknum == (cfg.blocknum + EXT_BLOCK_NUM + START_BLOCK_NO) then
                        -- Find it
                        print("Configure find it:" .. cfg.blocknum)
                        return cfg
                    end
                end
            end
            break
        end
    end
    return nil
end

function parseDetails(srcdata, data, cfg)
    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        -- Parse meituan
        parseMeituan(srcdata, data, cfg)
    else
        print("Unknown app " .. APP_TYPE)
        -- Unknown app
    end
end

function hasElePrintCode(data)
    local codeCmd = '\29\104\96\29\119\2\29\107\73'
    --print("cus:" .. data)
    --print(string.find(data, codeCmd))
    if string.find(data, codeCmd) ~= nil then
        return 1
    end
    return 0
end

function isPhoneNumber(str)
    local sphone = string.gsub(str, "%-", "")
    if tonumber(sphone) then
        return true;
    end
    return false;
end

function meituanIgnoreGoods(name)
    if string.find(name, "购买:") == nil then
        return true
    end
    return false
end

function parseMeituan(srcdata, data, cfg)
    print("Parse Meituan order... ")
    local items = cfg.items

    local vernum = calcPackageVersion(PKG_VERSION)
    print("version: " .. vernum)
    if vernum <= 30108 then
        parseMeituan318(srcdata, data, cfg)
        return
    end
    if vernum <= 30400 then
        parseMeituan340(srcdata, data, cfg)
        return
    end

    if vernum <= 40200 then
        parseMeituan420(srcdata, data, cfg)
        return
    end

    local hejiblock = 0
    local bzs, bze = string.find(data, "备注")
    if bze ~= nil then
        local bss, bsz = string.find(data, "%*%*%*%*%*%*%*%*")
        if bss > bzs then
            hejiblock = 1
        end
    else
        local bzs1, bze1 = string.find(data, "发票")
        if bze1 ~= nil then
            local bss, bsz = string.find(data, "%*%*%*%*%*%*%*%*")
            if bss > bzs1 then
                hejiblock = 1
            end
        end
    end

    local bzs1, bze1 = string.find(data, "期望")
    local bzs2, bze2 = string.find(data, "送达")
    if bze1 ~= nil and bze2 ~= nil then
        hejiblock = hejiblock + 1
    end
    local bzs1, bze1 = string.find(data, "预计")
    local bzs2, bze2 = string.find(data, "到店")
    if bze1 ~= nil and bze2 ~= nil then
        hejiblock = hejiblock + 3
    end
    print("hejiblock:" .. hejiblock)

    print("cfg.sign " .. cfg.sign .. " block +1")

    local syear, smonth, sday, shour, sminute
    for i = 1, #items do
        local item = items[i]
        --[[
        print("reg:" .. item.reg)
        print("type:" .. item.type)
        print("global:" .. ((item.global and "true") or "false"))
        print("num: " .. item.num)
        --]]

        if item.global then
            -- global data search
            if item.type == "TIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)

                --print("解析:" .. tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5])

                if tr ~= nil then
                    BILL_TIME = tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5]
                    setTime(BILL_TIME)
                    print("解析:" .. tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5])
                    syear = tr[1]
                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "TIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    syear = os.date("%Y", os.time())
                    BILL_TIME = syear .. tr[1] .. tr[2] .. tr[3] .. tr[4]
                    setTime(BILL_TIME)

                    smonth = tr[1]
                    sday = tr[2]
                end
            elseif item.type == "NOTE" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    --printd("备注--------------- " .. tr[1] .. "------")
                    setNote(tr[1]);
                end
            elseif item.type == "REPITE" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    --printd("发票--------------- " .. tr[1] .. "------")
                    setREPITE(tr[1]);
                end
            elseif item.type == "HASPAYED" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    setPayed(true)
                end
            elseif item.type == "TOTAL" then
                --printd("TOTAL: data: --------------reg:" .. item.reg)
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    --printd("--------------reg:"..tr[1])
                    if string.find(item.reg, "支付") ~= nil then
                        --printd("---------1-----reg:"..tr[1])
                        setCustomPay(tr[1])
                    else
                        --printd("---------2-----reg:"..tr[1])
                        setTotal(tr[1])
                    end
                end
            elseif item.type == "ESPTIME" then
                --print("exp time-----:")
                --print("reg:" .. item.reg)
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then

                    if #tr == 2 then
                        shour = tr[1]
                        sminute = tr[2]
                        local ts = os.time({ year = syear, month = smonth, day = sday, hour = shour, min = sminute, sec = 0 })
                        print("exp time:" .. ts)
                        if setExp ~= nil then
                            setExp(ts)
                        end
                    end
                    if #tr == 3 then
                        -- day check tr[1] 预约时间修改为String
                        shour = tr[2]
                        sminute = tr[3]

                        if string.find(tr[1], "-") ~= nil and #tr[1] == 5 then
                            smonth = string.sub(tr[1], 0, 2)
                            sday = string.sub(tr[1], 4, #tr[1])
                        end
                        local ts = os.time({ year = syear, month = smonth, day = sday, hour = shour, min = sminute, sec = 0 })
                        print("exp time-----:" .. syear .. " " .. smonth .. " " .. sday)
                        print("exp time:" .. ts .. " " .. tr[2] .. ":" .. tr[3])
                        if tr[1] == "明日" then
                            ts = ts + 60 * 60 * 24
                        end

                        print("exp time:" .. ts .. " " .. tr[2] .. ":" .. tr[3])
                        if setExp ~= nil then
                            setExp(ts)
                        end
                    end
                end
            elseif item.type == "ESPTIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = tr[1], month = tr[2], day = tr[3], hour = tr[4], min = tr[5], sec = 0 })
                    print("exp time2:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            else
                print("Unknown block type:" .. item.type)
            end


        else
            if item.type == "GOODS" then
                --print(">>>>>>>>>>>>>>>>>> GOODS " .. item.num .. "  " .. hejiblock)

                local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                --print("goods block data:" .. item.num .. "\n" .. blockdata)

                local bag = ""
                local bagReg = "(\\d+)号口袋"

                local lines = string.split(blockdata, "\n")
                local lastline = nil
                for _, line in ipairs(lines) do
                    while true do
                        --print("line:" .. line)

                        if string.find(line, "号口袋") ~= nil then
                            print("skip line: " .. line)

                            local bagrx = regx(line, bagReg)
                            local bagtr = regxnext(bagrx)
                            if bagtr ~= nil then
                                print("bag no: " .. bagtr[1])
                                bag = bagtr[1]
                            else
                                print("bag no unknown")
                            end
                            break
                        end

                        local fs = string.find(line, "%-%-%-%-%-%-")
                        if fs ~= nil then
                            --print("xxxxxx " .. line)
                            lastline = nil
                            break
                        end

                        local oline = line

                        if lastline ~= nil then
                            print("---------lastline---:" .. lastline .. "------111111")

                            line = lastline .. " " .. line
                        end

                        print("---------line---:" .. line .. "------111111")

                        local rx = regx(line, item.reg)
                        local tr = regxnext(rx)
                        if tr ~= nil then
                            addProduct(tr[1], tr[2] .. "-" .. bag, tr[3] / tr[2])
                            lastline = nil
                            break
                        else
                            if lastline == nil then
                                lastline = ''
                            end
                            lastline = lastline .. oline
                            print("---------lastline---:" .. lastline .. "------222222")
                            if #lastline > 120 then
                                lastline = nil;
                            end
                            break
                        end
                    end
                end
            else
                if item.type == "SIGNLEGOODS" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", tr[2])
                                end
                                lastline = nil
                                break
                            end
                            lastline = line
                            break
                        end
                    end
                elseif item.type == "GIVE" then
                    print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    print("block data:" .. (item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " " .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    --for i = 1, #lines do
                    --    print("single goods line:" .. i .. "--" .. lines[i] .. "------" .. #lines)
                    --end


                    for i = 1, #lines do
                        --if string.find(line, ":%-") ~= nil then
                        --    break
                        --end

                        local temp = lines[i];
                        if lastline ~= nil then
                            temp = lastline .. temp
                            print("single goods line merge:" .. temp .. "------111111")
                            lastline = nil
                            --print("single goods line merge:" .. temp .. "------222222")
                        end

                        --print("single goods line:" .. lines[i] .. "------" .. #lines)

                        local rx = regx(temp, item.reg)
                        local tr = regxnext(rx)
                        if tr ~= nil then
                            if meituanIgnoreGoods(tr[1]) then
                                --print(tr[1])
                                --print(tr[2])
                                --print(tr[3])
                                --printd("赠送 " .. tr[1] .. "    reg:" .. tr[2] .. "----" .. tr[3])

                                if #tr == 3 then
                                    if #tr[2] > 0 then
                                        --printd("赠送 " .. tr[1] .. "    reg:" .. tr[2] .. "----3--------" .. tr[3])
                                        addProduct(tr[1] .. "(" .. tr[2] .. ")" .. "[赠]", tr[3], "0")
                                    else
                                        addProduct(tr[1] .. "[赠]", tr[3], "0")
                                    end
                                else
                                    --printd("赠送 " .. tr[1] .. "    reg:" .. tr[2] .. "----2----------")
                                    addProduct(tr[1] .. "[赠]", tr[2], "0")
                                end
                            end
                        else
                            if string.find(temp, "赠送") ~= nil then
                                --print("-------qqq222---------");
                                temp = string.gsub(temp, "^%s*(.-)%s*$", "%1")
                                lastline = temp
                            end
                        end
                    end

                    --for _, line in ipairs(lines) do
                    --    while true do
                    --        if string.find(line, ":%-") ~= nil then
                    --            break
                    --        end
                    --
                    --        if lastline ~= nil then
                    --            line = lastline .. " " .. line
                    --            print("single goods line merge:" .. lastline .. "------111111")
                    --
                    --            print("single goods line merge:" .. line .. "------222222")
                    --        end
                    --
                    --        print("single goods line:" .. line .. "------")
                    --
                    --        local rx = regx(line, item.reg)
                    --        local tr = regxnext(rx)
                    --        if tr ~= nil then
                    --            if meituanIgnoreGoods(tr[1]) then
                    --                printd("赠送 " .. tr[1] .. "    reg:" .. tr[2])
                    --                addProduct(tr[1] .. "[赠]", tr[2], "0")
                    --            end
                    --            lastline = nil
                    --            break
                    --        else
                    --            lastline = line
                    --            break
                    --        end
                    --    end
                    --end
                elseif item.type == "CUSTOMER2" then
                    --print(">>>>>>>>>>>>>>>>>>")
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num)
                    local lines = string.split(blockdata, "\n")
                    print("------------block data:" .. (item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " --" ..
                            hejiblock .. "--lines--" .. #lines .. " --" ..
                            blockdata .. " +++++")
                    --print("------------开始:" .. #lines .. "===========")
                    if #lines == 2 then
                        setName(lines[2])
                        setPhone(string.gsub(lines[1], "顾客号码:", ""))
                        setAddress("到店自取")
                    elseif #lines == 3 then
                        setName(lines[2])
                        setPhone(lines[1])
                        setAddress("到店自取")
                    elseif #lines == 4 then
                        setName(lines[4])
                        setPhone(string.gsub(lines[2], "虚拟号码:", ""))
                        setAddress("到店自取")
                    elseif #lines == 7 or #lines == 6 or #lines == 5 then
                        local bakPhone = "备用号码1:"
                        if string.find(lines[3], bakPhone) then
                            setName(lines[5])
                            setPhone(string.gsub(lines[2], "虚拟号码:", "") .. "或者" .. string.gsub(lines[3], bakPhone, ""))
                            setAddress("到店自取")
                        else
                            setName(lines[4])
                            setPhone(string.gsub(lines[2], "虚拟号码:", ""))
                            setAddress("到店自取")
                        end
                    end

                elseif item.type == "SIGNLEGOODS2" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS2")
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line 2:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line 2 merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    --print("meituan line tr 3:" .. tr[3])
                                    if trim(tr[3]) == "" then
                                        addProduct(tr[1], "1", -tr[2])
                                    else
                                        addProduct(trim(tr[1]) .. trim(tr[3]), "1", -tr[2])
                                    end
                                end
                                lastline = nil
                                break
                            else
                                -- none : line
                                rx = regx(line, "(.*)\\s+(-?[0-9]+.?[0-9]*)")
                                tr = regxnext(rx)
                                if tr ~= nil then
                                    lastline = nil
                                    break
                                end
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "CUSTOMER" then
                    local heij = hejiblock
                    if cfg.sign == "商家联" or cfg.sign == "给顾客" then
                        heij = 0
                    end
                    if cfg.sign == "商家小票" then
                        heij = heij + 1
                    end
                    print(">>>>>> heij:" .. heij .. " " .. cfg.sign)
                    local blockdata = getblockdata(data, cfg.blocks, item.num + heij)
                    if cfg.sign == "给顾客" then
                        local ss1, ee1 = nil
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-在线支付[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 2:" .. blockdata)
                            end
                        end
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-货到付款[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 3:" .. blockdata)
                            end
                        end

                        --print("CUSTOMER blockdata:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        --print("lines:" .. #lines)
                        local cc = 0
                        local i = 1
                        while i <= #lines do
                            --print(">>>>>>>>>>> lines:")
                            --print("lines data: len:" .. string.len(lines[i]))
                            local exps = "期望送达时间"
                            if string.find(lines[i], exps) == nil then
                                if lines[i] ~= "" then
                                    if cc == 0 then

                                    end
                                    if cc == 1 then
                                        local nplines = string.split(lines[i], " ")
                                        --print(">>>>>>>>> nplines: " .. #nplines)
                                        setName(nplines[1])
                                        setPhone(nplines[2])
                                    end
                                    if cc == 2 then
                                        setAddress(lines[i])
                                    end
                                    cc = cc + 1
                                end
                            end
                            i = i + 1
                        end
                        --[[
                        if 4 == #lines then
                            local nplines = string.split(lines[2], "\n")
                            setName(nplines[1])
                            setPhone(nplines[2])
                            setAddress(lines[3])
                        end
                        --]]
                    elseif cfg.sign == "给配送" then
                        local ss1, ee1 = nil
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-在线支付[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 2:" .. blockdata)
                            end
                        end
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-货到付款[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 3:" .. blockdata)
                            end
                        end

                        --print("CUSTOMER blockdata:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        --print("lines:" .. #lines)
                        local cc = 0
                        local i = 1
                        while i <= #lines do
                            --print(">>>>>>>>>>> customer lines:" .. lines[i])
                            --print("lines data: len:" .. string.len(lines[i]))
                            local exps = "期望送达时间"
                            if string.find(lines[i], exps) == nil then
                                if lines[i] ~= "" then
                                    if cc == 1 then
                                        setAddress(lines[i])
                                    end
                                    if cc == 2 then
                                        setPhone(lines[i])
                                    end
                                    if cc == 3 then
                                        setName(lines[i])
                                    end
                                    cc = cc + 1
                                end
                            end
                            i = i + 1
                        end
                        --[[
                        if 4 == #lines then
                            local nplines = string.split(lines[2], "\n")
                            setName(nplines[1])
                            setPhone(nplines[2])
                            setAddress(lines[3])
                        end
                        --]]
                    else
                        local ss1, ee1 = string.find(blockdata, "(%d+-%d+ %d+:%d+)")
                        if ee1 ~= nil then
                            --print("CUSTOMER blockdata 1:" .. blockdata)
                            blockdata = string.sub(blockdata, ee1 + 1)
                            --print("CUSTOMER blockdata 2:" .. blockdata)
                        end

                        local ss2, ee2 = string.find(data, "(%d+-%d+ %d+:%d+)")
                        print(">>>>> ee2:" .. ee2)
                        ee2 = nil
                        if ee2 ~= nil then
                            local ss3, ee3 = string.find(data, "%*%*%*%*%*%*%*%*");
                            --print(">>>>> ee3:" .. ee3)
                            if ss3 ~= nil then
                                --print(">>>>> ss3 - ee2:" .. ss3 - ee2)
                                if (ss3 - ee2) > 10 then
                                    --print("CUSTOMER blockdata 11:" .. blockdata)
                                    blockdata = string.sub(data, ee2 + 1, ss3)
                                    --print("CUSTOMER blockdata 22:" .. blockdata)
                                end
                            end
                        end

                        print("CUSTOMER blockdata 3:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        print("---------------------lines:" .. #lines)

                        if #lines == 7 or #lines == 6 or #lines == 5 then
                            local bakPhone = "备用号码1:"
                            if string.find(lines[4], bakPhone) then
                                setAddress(lines[1])
                                setPhone(string.gsub(lines[3], "虚拟号码:", "") .. "或者" .. string.gsub(lines[4], bakPhone, ""))
                                setName(lines[6])
                            else
                                setAddress(lines[1])
                                setPhone(string.gsub(lines[3], "虚拟号码:", ""))
                                setName(lines[5])
                            end
                        else
                            local cc = 0
                            local i = 1
                            while i <= #lines do
                                --print(">>>>>>>>>>> lines:")
                                --print("lines data: len:" .. string.len(lines[i]))
                                local exps = "期望送达时间"
                                if string.find(lines[i], exps) == nil then
                                    if lines[i] ~= "" then
                                        if cc == 0 then
                                            setAddress(lines[i])
                                        end
                                        if cc == 1 then
                                            setPhone(string.gsub(lines[i], "顾客号码:", ""))
                                        end
                                        if cc == 2 then
                                            setName(lines[i])
                                        end
                                        cc = cc + 1
                                    end
                                end
                                i = i + 1
                            end
                        end
                        --[[
                        if 4 == #lines then
                            setName(lines[4])
                            setPhone(lines[3])
                            setAddress(lines[2])
                        end
                        --]]
                    end
                else
                    print("Unknown block type:" .. item.type)
                end
            end
        end
    end
end

function parseMeituan420(srcdata, data, cfg)

    --寻找解析内容的头部
    if vernum > 30700 and cfg.sign ~= "" then
        local s, e = string.find(data, cfg.sign)
        if s ~= null then
            --print("se " .. s .. " " .. e)
            data = string.sub(data, s)
            --print("find data head:" .. data)
        end
    end

    local hejiblock = 0
    local bzs, bze = string.find(data, "备注")
    if bze ~= nil then
        local bss, bsz = string.find(data, "%*%*%*%*%*%*%*%*")
        if bss > bzs then
            hejiblock = 1
        end
    end
    --print("hejiblock:" .. hejiblock)

    local syear, smonth, sday, shour, sminute
    for i = 1, #items do
        local item = items[i]
        --[[
        print("reg:" .. item.reg)
        print("type:" .. item.type)
        print("global:" .. ((item.global and "true") or "false"))
        print("num: " .. item.num)
        --]]

        if item.global then
            -- global data search
            if item.type == "TIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    BILL_TIME = tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5]
                    setTime(BILL_TIME)

                    syear = tr[1]
                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "TIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    syear = os.date("%Y", os.time())
                    BILL_TIME = syear .. tr[1] .. tr[2] .. tr[3] .. tr[4]
                    setTime(BILL_TIME)

                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "HASPAYED" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    setPayed(true)
                end
            elseif item.type == "TOTAL" then
                printd("------TOTAL: data: " .. data .. "    reg:" .. item.reg)
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    printd("---TOTAL----" .. #tr)
                    if string.find(item.reg, "支付") ~= nil then
                        setCustomPay(tr[1])
                    else
                        setTotal(tr[1])
                    end
                end
            elseif item.type == "ESPTIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = syear, month = smonth, day = sday, hour = shour, min = sminute, sec = 0 })
                    --print("exp time:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            elseif item.type == "ESPTIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = tr[1], month = tr[2], day = tr[3], hour = tr[4], min = tr[5], sec = 0 })
                    --print("exp time2:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            else
                print("Unknown block type:" .. item.type)
            end
        else
            if item.type == "GOODS" then
                --print(">>>>>>>>>>>>>>>>>> GOODS " .. item.num .. "  " .. hejiblock)

                local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                --print("goods block data:" .. item.num .. "\n" .. blockdata)


                local lines = string.split(blockdata, "\n")
                local lastline = nil
                for _, line in ipairs(lines) do
                    while true do
                        --print("line:" .. line)
                        local oline = line

                        if string.find(line, "号口袋") ~= nil then
                            --print("skip line: " .. line)
                            break
                        end

                        if lastline ~= nil then
                            line = lastline .. " " .. line
                        end
                        local rx = regx(line, item.reg)
                        local tr = regxnext(rx)
                        if tr ~= nil then
                            addProduct(tr[1], tr[2], tr[3] / tr[2])
                            lastline = nil
                            break
                        end
                        lastline = oline
                        break
                    end
                end
            else
                if item.type == "SIGNLEGOODS" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", tr[2])
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "GIVE" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    printd("赠送 " .. tr[1] .. "    reg:" .. tr[2])
                                    addProduct(tr[1] .. "[赠]", tr[2], "0")
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "SIGNLEGOODS2" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS2")
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line 2:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line 2 merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    --print("meituan line tr 3:" .. tr[3])
                                    if trim(tr[3]) == "" then
                                        addProduct(tr[1], "1", -tr[2])
                                    else
                                        addProduct(trim(tr[1]) .. trim(tr[3]), "1", -tr[2])
                                    end
                                end
                                lastline = nil
                                break
                            else
                                -- none : line
                                rx = regx(line, "(.*)\\s+(-?[0-9]+.?[0-9]*)")
                                tr = regxnext(rx)
                                if tr ~= nil then
                                    lastline = nil
                                    break
                                end
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "CUSTOMER" then
                    local heij = hejiblock
                    if cfg.sign == "商家联" or cfg.sign == "给顾客" then
                        heij = 0
                    end
                    local blockdata = getblockdata(data, cfg.blocks, item.num + heij)
                    --print(">>>>>>>>> sign : " .. cfg.sign)
                    if cfg.sign == "给顾客" then
                        local ss1, ee1 = nil
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-在线支付[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 2:" .. blockdata)
                            end
                        end
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-货到付款[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 3:" .. blockdata)
                            end
                        end

                        --print("CUSTOMER blockdata:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        --print("lines:" .. #lines)
                        local cc = 0
                        local i = 1
                        while i <= #lines do
                            --print(">>>>>>>>>>> lines:")
                            --print("lines data: len:" .. string.len(lines[i]))
                            local exps = "期望送达时间"
                            if string.find(lines[i], exps) == nil then
                                if lines[i] ~= "" then
                                    if cc == 0 then

                                    end
                                    if cc == 1 then
                                        local nplines = string.split(lines[i], " ")
                                        --print(">>>>>>>>> nplines: " .. #nplines)
                                        setName(nplines[1])
                                        setPhone(nplines[2])
                                    end
                                    if cc == 2 then
                                        setAddress(lines[i])
                                    end
                                    cc = cc + 1
                                end
                            end
                            i = i + 1
                        end
                        --[[
                        if 4 == #lines then
                            local nplines = string.split(lines[2], "\n")
                            setName(nplines[1])
                            setPhone(nplines[2])
                            setAddress(lines[3])
                        end
                        --]]
                    elseif cfg.sign == "给配送" then
                        local ss1, ee1 = nil
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-在线支付[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 2:" .. blockdata)
                            end
                        end
                        if ee1 == nil then
                            ss1, ee1 = string.find(blockdata, "-货到付款[(%d+.%d*)元]-")
                            if ee1 ~= nil then
                                blockdata = string.sub(blockdata, ee1 + 1)
                                --print("CUSTOMER blockdata 3:" .. blockdata)
                            end
                        end

                        --print("CUSTOMER blockdata:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        --print("lines:" .. #lines)
                        local cc = 0
                        local i = 1
                        while i <= #lines do
                            --print(">>>>>>>>>>> customer lines:" .. lines[i])
                            --print("lines data: len:" .. string.len(lines[i]))
                            local exps = "期望送达时间"
                            if string.find(lines[i], exps) == nil then
                                if lines[i] ~= "" then
                                    if cc == 1 then
                                        setAddress(lines[i])
                                    end
                                    if cc == 2 then
                                        setPhone(lines[i])
                                    end
                                    if cc == 3 then
                                        setName(lines[i])
                                    end
                                    cc = cc + 1
                                end
                            end
                            i = i + 1
                        end
                        --[[
                        if 4 == #lines then
                            local nplines = string.split(lines[2], "\n")
                            setName(nplines[1])
                            setPhone(nplines[2])
                            setAddress(lines[3])
                        end
                        --]]
                    else
                        local ss1, ee1 = string.find(blockdata, "(%d+-%d+ %d+:%d+)")
                        if ee1 ~= nil then
                            blockdata = string.sub(blockdata, ee1 + 1)
                            --print("CUSTOMER blockdata 1:" .. blockdata)
                        end

                        --print("CUSTOMER blockdata:" .. blockdata)
                        local lines = string.split(blockdata, "\n")
                        --print("lines:" .. #lines)
                        local cc = 0
                        local i = 1
                        while i <= #lines do
                            --print(">>>>>>>>>>> lines:")
                            --print("lines data: len:" .. string.len(lines[i]))
                            local exps = "期望送达时间"
                            if string.find(lines[i], exps) == nil then
                                if lines[i] ~= "" then
                                    if cc == 0 then
                                        setAddress(lines[i])
                                    end
                                    if cc == 1 then
                                        setPhone(lines[i])
                                    end
                                    if cc == 2 then
                                        setName(lines[i])
                                    end
                                    cc = cc + 1
                                end
                            end
                            i = i + 1
                        end
                        --[[
                        if 4 == #lines then
                            setName(lines[4])
                            setPhone(lines[3])
                            setAddress(lines[2])
                        end
                        --]]
                    end
                else
                    print("Unknown block type:" .. item.type)
                end
            end
        end
    end
end

function parseMeituan340(srcdata, data, cfg)
    print("Parse Meituan order 340... ")
    local items = cfg.items

    local hejiblock = 0
    for i = 3, 100 do
        local blockdata = getblockdata(data, cfg.blocks, i)
        local ss1, ee1 = string.find(blockdata, "合计")
        if ss1 ~= nil then
            hejiblock = i
            break
        end
    end
    --print("hejiblock:" .. hejiblock)

    local syear, smonth, sday, shour, sminute
    for i = 1, #items do
        local item = items[i]
        --[[
        print("reg:" .. item.reg)
        print("type:" .. item.type)
        print("global:" .. ((item.global and "true") or "false"))
        print("num: " .. item.num)
        --]]

        if item.global then
            -- global data search
            if item.type == "TIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    BILL_TIME = tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5]
                    setTime(BILL_TIME)

                    syear = tr[1]
                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "TIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    syear = os.date("%Y", os.time())
                    BILL_TIME = syear .. tr[1] .. tr[2] .. tr[3] .. tr[4]
                    setTime(BILL_TIME)

                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "HASPAYED" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    setPayed(true)
                end
            elseif item.type == "TOTAL" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    if string.find(item.reg, "支付") ~= nil then
                        setCustomPay(tr[1])
                    else
                        setTotal(tr[1])
                    end
                end
            elseif item.type == "ESPTIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = syear, month = smonth, day = sday, hour = shour, min = sminute, sec = 0 })
                    --print("exp time:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            elseif item.type == "ESPTIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = tr[1], month = tr[2], day = tr[3], hour = tr[4], min = tr[5], sec = 0 })
                    --print("exp time2:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            else
                print("Unknown block type:" .. item.type)
            end
        else
            if item.type == "GOODS" then
                for extNum = 2, hejiblock - 2 do
                    -- block num search
                    --print("goods block num: " .. extNum)
                    local blockdata = getblockdata(data, cfg.blocks, extNum)
                    --print("goods block data:" .. blockdata)
                    if item.type == "GOODS" then
                        local lines = string.split(blockdata, "\n")
                        local lastline = nil
                        for _, line in ipairs(lines) do
                            while true do
                                --print("line:" .. line)
                                local oline = line

                                local sts = utf8.sub(line, 3, 5)
                                --print("sts: " .. sts)
                                if string.find(sts, "号口袋") ~= nil then
                                    --print("skip line: " .. line)
                                    break
                                end

                                if lastline ~= nil then
                                    line = lastline .. " " .. line
                                end
                                local rx = regx(line, item.reg)
                                local tr = regxnext(rx)
                                if tr ~= nil then
                                    addProduct(tr[1], tr[2], tr[3] / tr[2])
                                    lastline = nil
                                    break
                                end
                                lastline = oline
                                break
                            end
                        end
                    end
                end
            else
                if item.type == "SIGNLEGOODS" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS")
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, hejiblock - 1)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", tr[2])
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "GIVE" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, item.num + hejiblock)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    printd("赠送 " .. tr[1] .. "    reg:" .. tr[2])
                                    addProduct(tr[1] .. "[赠]", tr[2], "0")
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "SIGNLEGOODS2" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS2")
                    -- block num search
                    local blockdata = getblockdata(data, cfg.blocks, hejiblock - 1)
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line 2:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line 2 merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", -tr[2])
                                end
                                lastline = nil
                                break
                            else
                                -- none : line
                                rx = regx(line, "(.*)\\s+(-?[0-9]+.?[0-9]*)")
                                tr = regxnext(rx)
                                if tr ~= nil then
                                    lastline = nil
                                    break
                                end
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "CUSTOMER" then
                    --print(">>>>>>>>>>>>>>>>>> CUSTOMER")
                    local blockdata = getblockdata(data, cfg.blocks, hejiblock + 1)
                    local lines = string.split(blockdata, "\n")
                    --print("lines:" .. #lines)
                    if 3 == #lines then
                        local ccs = string.split(lines[1], " ")
                        --print("ccs:" .. #ccs)
                        if 2 == #ccs then
                            setName(ccs[1])
                            setPhone(ccs[2])
                        else
                            setPhone(lines[1])
                        end
                        setAddress(lines[2])
                    end
                else
                    print("Unknown block type:" .. item.type)
                end
            end
        end
    end
end

function parseMeituan318(srcdata, data, cfg)
    print("Parse Meituan 318 order... ")
    local items = cfg.items
    --print("items: " .. #items)
    local syear, smonth, sday, shour, sminute
    for i = 1, #items do
        local item = items[i]
        --[[
        print("reg:" .. item.reg)
        print("type:" .. item.type)
        print("global:" .. ((item.global and "true") or "false"))
        print("num: " .. item.num)
        --]]

        if item.global then
            -- global data search
            if item.type == "TIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    BILL_TIME = tr[1] .. tr[2] .. tr[3] .. tr[4] .. tr[5]
                    setTime(BILL_TIME)

                    syear = tr[1]
                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "TIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    syear = os.date("%Y", os.time())
                    BILL_TIME = syear .. tr[1] .. tr[2] .. tr[3] .. tr[4]
                    setTime(BILL_TIME)

                    smonth = tr[2]
                    sday = tr[3]
                end
            elseif item.type == "HASPAYED" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    setPayed(true)
                end
            elseif item.type == "TOTAL" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    if string.find(item.reg, "支付") ~= nil then
                        setCustomPay(tr[1])
                    else
                        setTotal(tr[1])
                    end
                end
            elseif item.type == "ESPTIME" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = syear, month = smonth, day = sday, hour = shour, min = sminute, sec = 0 })
                    print("exp time:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            elseif item.type == "ESPTIME2" then
                local rx = regx(data, item.reg)
                local tr = regxnext(rx)
                if tr ~= nil then
                    shour = tr[1]
                    sminute = tr[2]
                    local ts = os.time({ year = tr[1], month = tr[2], day = tr[3], hour = tr[4], min = tr[5], sec = 0 })
                    print("exp time2:" .. ts)
                    if setExp ~= nil then
                        setExp(ts)
                    end
                end
            else
                print("Unknown block type:" .. item.type)
            end
        else
            if item.type == "GOODS" then
                for extNum = 0, EXT_BLOCK_NUM do
                    -- block num search
                    print("goods block num: " .. item.num + extNum + START_BLOCK_NO)
                    local blockdata = getblockdata(data, cfg.blocks, item.num + extNum + START_BLOCK_NO)
                    --print("goods block data:" .. blockdata)
                    if item.type == "GOODS" then
                        local lines = string.split(blockdata, "\n")
                        local lastline = nil
                        for _, line in ipairs(lines) do
                            while true do
                                print("line:" .. line)
                                local oline = line

                                local sts = utf8.sub(line, 3, 5)
                                print("sts: " .. sts)
                                if string.find(sts, "号口袋") ~= nil then
                                    print("skip line: " .. line)
                                    break
                                end

                                if lastline ~= nil then
                                    line = lastline .. " " .. line
                                end
                                local rx = regx(line, item.reg)
                                local tr = regxnext(rx)
                                if tr ~= nil then
                                    addProduct(tr[1], tr[2], tr[3] / tr[2])
                                    lastline = nil
                                    break
                                end

                                --[[
                                local objs = string.split(line, " ")
                                local count = 0
                                for _,obj in ipairs(objs) do
                                    --print("obj:" .. obj)
                                    count = count + 1
                                end
                                if count == 2 then
                                    addProduct(objs[1], "1", objs[2])
                                    lastline = nil
                                    break
                                end
--]]
                                lastline = oline
                                break
                            end
                        end
                    end
                end
            else
                -- block num search
                local blockdata = getblockdata(data, cfg.blocks, item.num + EXT_BLOCK_NUM + START_BLOCK_NO)
                --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                if item.type == "SIGNLEGOODS" then
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, "号口袋") ~= nil then
                                print("skip line 5: " .. line)
                                break
                            end
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", tr[2])
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "GIVE" then
                    --print(">>>>>>>>>>>>>>>>>> SIGNLEGOODS " .. item.num .. "  " .. hejiblock)
                    -- block num search
                    --print("block data:" .. ( item.num + EXT_BLOCK_NUM + START_BLOCK_NO) .. " "  .. blockdata)
                    local lines = string.split(blockdata, "\n")
                    local lastline = nil
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, ":%-") ~= nil then
                                break
                            end
                            --print("single goods line:" .. line)

                            if lastline ~= nil then
                                line = lastline .. " " .. line
                                --print("single goods line merge:" .. line)
                            end

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    printd("赠送 " .. tr[1] .. "    reg:" .. tr[2])
                                    addProduct(tr[1] .. "[赠]", tr[2], "0")
                                end
                                lastline = nil
                                break
                            end

                            lastline = line
                            break
                        end
                    end
                elseif item.type == "SIGNLEGOODS2" then
                    local lines = string.split(blockdata, "\n")
                    for _, line in ipairs(lines) do
                        while true do
                            if string.find(line, "号口袋") ~= nil then
                                print("skip line 6: " .. line)
                                break
                            end
                            if string.find(line, ":%-") == nil then
                                break
                            end
                            print("single goods 2 line:" .. line)
                            print("reg:" .. item.reg)

                            local rx = regx(line, item.reg)
                            local tr = regxnext(rx)
                            if tr ~= nil then
                                if meituanIgnoreGoods(tr[1]) then
                                    addProduct(tr[1], "1", -tr[2])
                                else
                                    print("SIGNLEGOODS2 ignore")
                                end
                                break
                            end

                            break
                        end
                    end
                elseif item.type == "CUSTOMER" then
                    local lines = string.split(blockdata, "\n")
                    --print("lines:" .. #lines)
                    if 3 == #lines then
                        local ccs = string.split(lines[1], " ")
                        --print("ccs:" .. #ccs)
                        if 2 == #ccs then
                            setName(ccs[1])
                            setPhone(ccs[2])
                        else
                            setPhone(lines[1])
                        end
                        setAddress(lines[2])
                    end
                else
                    print("Unknown block type:" .. item.type)
                end
            end
        end
    end
end

function countStartSpace(line)
    local sc = 0
    for i = 1, 8 do
        local cc = utf8.sub(line, i, i)
        if cc == ' ' then
            sc = sc + 1
        else
            break
        end
    end
    return sc
end

BLOCK_BILL_NO = ""

function isBlockEnd(data)
    if BLOCK_BILL_NO == "" then
        print(">>>>>>>>>>>>>>> isBLockEnd BILL_NO is empty")
        return true
    end
    local s, e = string.find(data, BLOCK_BILL_NO)
    if e ~= nil then
        local s1, e1
        e1 = e
        while e1 ~= nil do
            s1, e1 = string.find(data, BLOCK_BILL_NO, e1 + 1)
            if e1 ~= nil then
                e = e1
            else
                break
            end
        end
        local ld = string.sub(data, e + 3)
        --print("ld:--------------------" .. ld .. "\n---------------------")
        ld = string.gsub(ld, " ", "")
        ld = string.gsub(ld, "\n", "")
        --print("ld:-------------------" .. ld .. "\n---------------------")
        --print("ld len:" .. string.len(ld))
        if string.len(ld) == 0 then
            return true
        end
    end
    return false
end

function isfull(data, first)
    local result = "skip"

    -- Remove print command character
    local ldata = removePrintCommand(data)
    --if true then return "1" end

    -- Parse order source app
    if first == true then
        init()

        parseAppType(ldata)
        if APP_TYPE == 0 then
            return result
        end
    end

    --print(">>>>>>>> PRODUCT_PACKAGE_MEITUAN")
    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        local vernum = calcPackageVersion(PKG_VERSION)
        --print("vernum:" .. vernum)
        if vernum >= 30700 then
            local hes = ""
            for i = -6, -1, 1 do
                hes = hes .. string.format("%02x", string.byte(data, i))
            end
            if hes == "0a0a0a0a1b40" or hes == "0a1d56001b40" then
                result = "yes"
            else
                result = "no"
            end
        end
    end

    --[[

    --print(">>>>>>>> PRODUCT_PACKAGE_MEITUAN")
    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        local vernum = calcPackageVersion(PKG_VERSION)
        --print("vernum:" .. vernum)
        if vernum >= 30700 then
            if first == true then
                --print("first block find.")
                BLOCK_BILL_NO = ""
                local rx = regx(data, "-*-*#(\\d+)美团外卖-*-*")
                local tr = regxnext(rx)
                if tr ~= nil then
                    BLOCK_BILL_NO = tr[1]
                    print("Block Bill No: " .. BLOCK_BILL_NO)
                    result = "no"
                end
            end

            BLOCK_END = "-*-*#" .. BLOCK_BILL_NO .. "-*-*"
            --print("FIND BLOCK_END:" .. BLOCK_END)
            local s,e = string.find(data, BLOCK_END)
            if s ~= nil then
                --print("find not nil")
                if isBlockEnd(data) then
                    result = "yes"
                else
                    result = "no"
                end
            end
        end
    end

    --print("Function is full: " .. result)
--]]
    return result
end

function init()
    APP_TYPE = 0
    PKG_VERSION = ""
    BILL_TIME = ""
    BILL_ID = ""
    EXT_BLOCK_NUM = 0
    START_BLOCK_NO = 0
end

function parse(data)
    init()

    --testReg()
    --if 1==1 then return "1" end

    local srcdata = data

    -- Remove print command character
    data = removePrintCommand(data)
    --if true then return "1" end

    -- Parse order source app
    parseAppType(data)
    if APP_TYPE == 0 then
        return "1"
    end

    if APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        local vernum = calcPackageVersion(PKG_VERSION)
        if vernum > 30600 then
            print("redo use removeplacePrintCommand")
            data = removeplacePrintCommand(srcdata)
        end
    end

    if APP_TYPE == PRODUCT_PACKAGE_BAIDU then
        local s21, e21 = string.find(data, "#(%d+)%s+百度外卖")
        if s21 ~= nil then
            local s22, e23 = string.find(data, "#(%d+)%s+百度外卖", s21 + 5)
            if s22 ~= nil then
                print("data end : " .. e23)
                data = string.sub(data, 0, e23)
            end
        end
    elseif APP_TYPE == PRODUCT_PACKAGE_ELE then
        local s2, e2 = string.find(data, "(第2联)")
        if s2 ~= nil then
            data = string.sub(data, 0, s2 - 25)
        end
        local ss2, ee2 = string.find(data, "***%s+#%d+%s*完%s+****")
        local ss3, ee3 = string.find(data, "***%s+#%d+%s+饿了么订单%s+****", ee2)
        if ss2 ~= nil and ss3 ~= nil then
            data = string.sub(data, 0, ss3 - 5)
        end
    elseif APP_TYPE == PRODUCT_PACKAGE_MEITUAN then
        local vernum = calcPackageVersion(PKG_VERSION)
        print("vernum: " .. vernum)
        if vernum > 30700 then
            local s2, e2 = string.find(data, "-*-*#(%d+)美团外卖-*-*")
            local s3, e3 = string.find(data, "-*-*-#(%d+)-*-*", e2)
            if s2 ~= nil then
                print("start s2:" .. s2)
            else
                print("start s2: is null")
            end
            if s2 ~= nil and s3 ~= nil then
                print("start s3:" .. s3)
                data = string.sub(data, 0, e3)
            else
                print("start s3 : is null")
            end
        else
            local s2, e2 = string.find(data, "＃(%d+)%s+美团外卖")
            local s3, e3 = string.find(data, "＃(%d+)%s+美团外卖", e2)
            if s2 ~= nil and s3 ~= nil then
                data = string.sub(data, s2, e3)
            end
        end
    elseif APP_TYPE == PRODUCT_PACKAGE_TAO then
        local s2, e2 = string.find(data, "#%d+口碑外卖")
        local s3, e3 = string.find(data, "#%d+口碑外卖", e2)
        if s2 ~= nil and s3 ~= nil then
            data = string.sub(data, s2, s3 - 1)
        end
    elseif APP_TYPE == PRODUCT_PACKAGE_SM then
        local s2, e2 = string.find(data, "----　#%d+　----")
        local s3, e3 = string.find(data, "----　#%d+　----", e2)
        if s2 ~= nil and s3 ~= nil then
            data = string.sub(data, s2, e3)
        end
    elseif APP_TYPE == PRODUCT_PACKAGE_PAI then
        local s2, e2 = string.find(data, "第二联")
        if s2 ~= nil then
            data = string.sub(data, 0, s2 - 25)
        end
    end

    print("-----------data start--------------")
    print(data)
    print("-----------data end--------------")
    --if 1==1 then return "1" end

    -- Parse order id
    parseOrderId(data)

    -- Calculate block number and configure
    local cfg = calcConfig(data)

    print("-----------calcConfig--------------")

    -- set custom print command
    setCustomPrintCommand(cfg)

    -- Parse details
    if cfg ~= nil then
        parseDetails(srcdata, data, cfg)

        --set custom short id
        setShortId()
    else
        print("Configure is nil")
    end

    return "0"
end

function testReg()
    --"墨西哥腿肉腿排双拼饭+猛甲鸡排+加多宝 [6.5折,原价29.0]      x1   18.85"
    local data = "墨西哥腿肉腿排双拼饭+猛甲鸡排+加多宝 [6.5折,原价29.0]      x1   18.85"
    local reg = "(.*)\\s+x(\\d+)\\s+(-?[0-9]+.?[0-9]*)"

    local rx = regx(data, reg)
    local tr = regxnext(rx)
    if tr ~= nil then
        print(" data: " .. tr[1] .. " " .. tr[2] .. " " .. tr[3])
    else
        print(" data reg error.")
    end
end