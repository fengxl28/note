package com.mwee.android.pos.dinner.test;

import android.support.test.runner.AndroidJUnit4;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.printer.ConnectWatcher;
import com.mwee.android.pos.printer.PrinterConnectManager;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;

import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by virgil on 2017/1/9.
 */
@RunWith(AndroidJUnit4.class)
public class TestRapidOrder {

    @Test
    public void testRapidOrderReceive() throws Exception {
        new LowThread(new Runnable() {
            @Override
            public void run() {
                final String commitID = "f5035ab3-3f9e-432c-8acf-8251e913f2a2";
                for (int i = 0; i < 100; i++) {
                    RapidBiz.receiveID(commitID);
                }
            }
        }).start();

    }

    @Test
    public void mwBos() throws Exception {
        String data = RapidBiz.queryTableInfoList();
        System.out.println(data);

    }

    @Test
    public void name() throws Exception {
        String ip = DeviceUtil.getLocalIpAddress();
        if (ip != null) {

            LogUtil.log("qinwei", ip.substring(0, ip.lastIndexOf(".")));
            LogUtil.log("qinwei", ip.substring(1 + ip.lastIndexOf(".")));
        }
        LogUtil.log("qinwei", ip);

    }

    ConnectWatcher watcher = new ConnectWatcher() {
        @Override
        protected void onStopSearch() {

        }

        @Override
        protected void onStartSearch() {

        }

        @Override
        protected void onFindNetPrinterIp(String ip) {
            LogUtil.log("testSearchNetPrinter:" + ip);
        }
    };

    @Test
    public void testSearchNetPrinter() throws Exception {
        PrinterConnectManager.getInstance().addConnectWatcher(watcher);
        PrinterConnectManager.getInstance().startSearch();
    }
}
