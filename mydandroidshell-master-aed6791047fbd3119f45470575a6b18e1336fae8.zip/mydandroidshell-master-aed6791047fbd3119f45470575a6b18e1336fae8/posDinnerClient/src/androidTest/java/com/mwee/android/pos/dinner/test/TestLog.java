package com.mwee.android.pos.dinner.test;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.alibaba.fastjson.JSON;
import com.mwee.android.mwscale.utils.USBEleConfig;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

/**
 * Created by virgil on 2017/1/9.
 */
@RunWith(AndroidJUnit4.class)
public class TestLog {

    @Test
    public void testAutoLog() throws Exception {
        Context appContext = InstrumentationRegistry.getTargetContext();
//        GlobalCache.getInstance().registerContext(appContext);
//        GlobalCache.getInstance().setLogOpen(true);
//        LogUtil.setWriteLog(true);
//        LogUtil.init(appContext, true);
        for (int i = 0; i < 1000; i++) {
            LogUtil.logBusiness(DateUtil.getCurrentTime() + "___开始记录日志__日志序号[" + i + "]");
        }
    }

    @Test
    public void testConfig() throws Exception {
        Context context = InstrumentationRegistry.getTargetContext();
        List<USBEleConfig> configList = ConfigProcess.getInstance().getConfigList("parse", USBEleConfig.class);
        System.out.print("获取到的配置数据:\n" + JSON.toJSONString(configList));
    }
}
