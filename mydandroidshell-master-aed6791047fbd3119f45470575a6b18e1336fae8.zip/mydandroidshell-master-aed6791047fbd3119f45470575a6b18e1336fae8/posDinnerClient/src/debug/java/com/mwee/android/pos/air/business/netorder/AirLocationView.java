package com.mwee.android.pos.air.business.netorder;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.mwee.android.pos.component.dialog.BaseDialogFragment;

/**
 * @ClassName: AirLocationView
 * @Description:
 * @author: SugarT
 * @date: 2017/11/3 下午4:18
 */
public class AirLocationView extends BaseDialogFragment {

    public static final String TAG = AirLocationView.class.getSimpleName();

    public static AirLocationView newInstance() {
        AirLocationView fragment = new AirLocationView();
        return fragment;
    }

    public void setListener(OnLocationListener listener) {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                dismissSelf();
            }
        }, 20);
    }

    public interface OnLocationListener {

        /**
         * 定位成功
         *
         * @param address   地址描述
         * @param latitude  纬度
         * @param longitude 经度
         */
        void located(String address, double latitude, double longitude);
    }
}
