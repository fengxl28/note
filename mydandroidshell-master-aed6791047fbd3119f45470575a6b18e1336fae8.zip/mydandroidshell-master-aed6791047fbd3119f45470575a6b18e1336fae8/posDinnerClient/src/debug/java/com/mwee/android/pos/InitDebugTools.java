package com.mwee.android.pos;

import android.app.Application;
import android.content.Context;

import com.facebook.stetho.Stetho;
import com.mwee.android.pos.base.DinnerApplication;
import com.mwee.android.pos.dinner.BuildConfig;
import com.mwee.android.tools.LogUtil;
import com.squareup.leakcanary.LeakCanary;

import pl.com.salsoft.sqlitestudioremote.SQLiteStudioService;

//import com.github.moduth.blockcanary.BlockCanary;


/**
 * Created by virgil on 2016/10/19.
 */

public class InitDebugTools {
    /**
     * Facebook的Stetho
     *
     * @param context Context
     */
    public static void initStetho(Context context) {
        if (BuildConfig.DEBUG) {
            Stetho.initializeWithDefaults(context);
            SQLiteStudioService.instance().start(context);

            System.out.println("initStetho------>"+"SQLiteStudioService.instance().start(context)");
        }
    }

    /**
     * see https://github.com/markzhai/AndroidPerformanceMonitor
     *
     * @param context Context
     */
    public static void initBlockCanary(Context context) {
        if (BuildConfig.DEV) {
            LogUtil.log("已开启严格模式");
            //StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyDropBox().penaltyLog().penaltyDialog().build());
            //StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().penaltyDropBox().penaltyLog().build());
//            BlockCanary.install(context, new AppBlockCanaryContext()).start();
            if (context instanceof DinnerApplication) {
                if (LeakCanary.isInAnalyzerProcess(context)) {
                    // This process is dedicated to LeakCanary for heap analysis.
                    // You should not init your app in this process.
                    return;
                }
                LeakCanary.install((Application) context);
            }
        }
    }
}
