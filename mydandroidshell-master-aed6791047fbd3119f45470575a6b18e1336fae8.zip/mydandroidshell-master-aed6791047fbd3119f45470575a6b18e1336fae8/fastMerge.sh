# git快捷操作
# 输入你需要的操作
# 输入相关的分支
# 完成
echo -n "what do you want? checkout, status, pull, merge, push, fetch"
read action

if [ $action = 'checkout' ]
then
    echo -n "which branch you want to checkout?"
    read branch
	git submodule foreach git checkout $branch
	git checkout $branch
fi

if [ $action = 'status' ]
then
	git submodule foreach git status
	git status
fi

if [ $action = 'pull' ]
then
	git submodule foreach git pull
	git pull
fi

if [ $action = 'merge' ]
then
	echo -n "which branch you want to merge?"
	read branch
	git submodule foreach git merge $branch
	git add .
	git commit -m "submodule merge from $branch"
	git merge $branch
fi

if [ $action = 'push' ]
then
	git submodule foreach git push
	git add .
    git commit -m "submodule"
	git push
fi

if [ $action = 'fetch' ]
then
	git submodule foreach git fetch origin
	git fetch origin
fi