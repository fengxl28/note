package com.mwee.android.pos.waiter.business;

/**
 * Server类型
 * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917545">接口说明</a>
 * Created by virgil on 2017/1/16.
 */

class ServiceType {
    final static String LOGIN = "login.t";
    final static String GET_DATA = "data.t";
    final static String BILL = "bill.t";
    final static String MEMBER = "member.t";

}
