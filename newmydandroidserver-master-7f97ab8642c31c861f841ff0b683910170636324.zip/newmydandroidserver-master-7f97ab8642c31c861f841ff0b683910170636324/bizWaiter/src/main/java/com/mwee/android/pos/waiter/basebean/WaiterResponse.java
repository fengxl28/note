package com.mwee.android.pos.waiter.basebean;

import android.text.TextUtils;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.waiter.server.WaiterResult;

/**
 * 美小二响应体的基类
 * Created by virgil on 2017/1/16.
 */
public class WaiterResponse<T> extends BusinessBean {
    public String Error = "";//错误信息
    public String ServiceTime = "";//服务器的返回时间,
    public String Status = "";//0 是成功 1是错误
    public T Data = null;//返回的数据 json格式
    public String Version="";
    public int BuildVersion=0;
    public int ServerType=2;//1，winpos；2，Android

    public WaiterResponse() {
        Status = WaiterResult.SUCCESS;
    }

    public void buildErrorMsg() {
        if (!TextUtils.isEmpty(Error)) {
            return;
        }
        switch (Status) {
            case WaiterResult.FAIL:
                Error = "出现异常，请稍后重试";
                break;
            case WaiterResult.SELLOUT:
                Error = "有菜品已估清，请检查";
                break;
            case WaiterResult.ORDER_CHANGED:
                Error = "别的服务员操作了这个订单，请回到桌台页重新操作";
                break;
        }
    }

    public boolean success(){
        return TextUtils.equals(Status,WaiterResult.SUCCESS);
    }
}
