package com.mwee.android.pos.waiter.server;

/**
 * 美小二服务端的配置项
 * Created by virgil on 2017/1/16.
 */
public class WaiterServerConfig {
    /**
     * 监听端口
     */
    public static final int PORT = 8089;

    /**
     * 2017-12-06 添加美小二多端口监听
     */
    public static final int[] PORT_LIST = {8089, 38089};
}
