package com.mwee.android.pos.waiter.business.bill;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.pay.NetPayResult;

/**
 * 美小二支付结果
 * Created by virgil on 2017/9/8.
 */

public class WaiterPayResult extends BusinessBean {
    /**
     * 订单支付结果：0，未完成支付；1，已完成支付
     */
    public int payFinished = 0;

    /**
     * 第三方支付的订单号
     */
    public String thirdPayOrderID = "";
    /**
     * 第三方支付结果。
     * 0：支付成功
     * 1：支付失败
     * 2：支付中
     */
    public int thirdPayStatus = NetPayResult.PROCESSING;
    /**
     * 会员储值是否需要密码。
     * 1:需要；
     * 0:不需要
     */
    public int needMemberPwd = 0;
    /**
     * 订单待支付信息
     */
    public WaiterPayView payView = null;

    public WaiterPayResult() {
    }
    public void buildPayView(String orderID){
        payView=NameUtil.buildPayView(orderID);
    }
}
