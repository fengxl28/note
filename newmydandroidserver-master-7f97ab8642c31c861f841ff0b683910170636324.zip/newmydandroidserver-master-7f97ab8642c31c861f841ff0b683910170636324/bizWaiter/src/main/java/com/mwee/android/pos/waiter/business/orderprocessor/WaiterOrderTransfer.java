package com.mwee.android.pos.waiter.business.orderprocessor;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.MenuTerminal;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsidedtlDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.menu.DishesUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.discount.CouponUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by virgil on 2017/2/1.
 */

public class WaiterOrderTransfer {
    /**
     * 构建规格
     *
     * @param item
     * @return
     */
    public static MenuItemUnitDBModel buildUnit(SellOrderItemDBModel item) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd='" + item.fiOrderUintCd + "'", MenuItemUnitDBModel.class);
    }

    public static AskDBModel buildProcedure(SellOrderItemDBModel item) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd='" + item.fiOrderUintCd, AskDBModel.class);
    }

    /**
     * 将菜品报表Model转化成MenuItem
     *
     * @param seqNo
     * @param isMember
     * @param sellItemList
     * @param source       订单来源：0：普通点菜 -1：秒点单
     * @return
     */
    public static List<MenuItem> tansSellItemToMenuItem(int seqNo, boolean isMember, String source, List<SellOrderItemDBModel> sellItemList) {
        List<MenuItem> list = new ArrayList<>();
        //规格的缓存
        ArrayMap<Integer, MenuItemUnitDBModel> unitCache = new ArrayMap<>();
        //套餐明细的缓存
        ArrayMap<String, List<MenuItem>> packageList = new ArrayMap<>();
        //套餐头的缓存
        ArrayMap<String, MenuItem> packageHead = new ArrayMap<>();
        //配料缓存
        ArrayMap<String, List<MenuItem>> ingredientMap = new ArrayMap<>();

        //将报表Model转为业务model，并缓存到不同的列表中
        for (SellOrderItemDBModel temp : sellItemList) {
            MenuItem menuItem = sellItemToMenuItem(temp, isMember, seqNo);
            if (menuItem == null) {
                continue;
            }
            // source 订单来源：0：普通点菜 -1：秒点单
            if (TextUtils.equals(source, "0")) {
                menuItem.terminal_id = MenuTerminal.MEALORDER;
            } else {
                menuItem.terminal_id = MenuTerminal.CLOUDSITE;
            }
            if (temp.fiOrderItemKind == 3) {  //套餐明细
                //套餐结构更改
                List<MenuItem> parnetList = packageList.get(temp.fsSeq_M);
                if (parnetList == null) {
                    parnetList = new ArrayList<>();
                    packageList.put(temp.fsSeq_M, parnetList);
                }
                parnetList.add(menuItem);
            } else if (temp.fiOrderItemKind == 2) {  //套餐头
                packageHead.put(temp.fsseq, menuItem);
                List<MenuItem> parnetList = packageList.get(temp.fsseq);
                if (parnetList == null) {
                    parnetList = new ArrayList<>();
                    packageList.put(temp.fsseq, parnetList);
                }
                list.add(menuItem);
            } else if (temp.fiOrderItemKind == 4) {//配料
                List<MenuItem> ingredientList = ingredientMap.get(temp.fsSeq_M);
                if (ingredientList == null) {
                    ingredientList = new ArrayList<>();
                    ingredientMap.put(temp.fsSeq_M, ingredientList);
                }
                ingredientList.add(menuItem);
            } else {
                list.add(menuItem);
            }
        }

        //将有关联关系的菜品关联起来

        //套餐菜
        for (Map.Entry<String, MenuItem> temp : packageHead.entrySet()) {
            MenuItem menu = temp.getValue();
            menu.menuBiz.selectedPackageItems = new ArrayList<>();

            List<MenuItem> itemsList = packageList.get(menu.menuBiz.uniq);
            if (!ListUtil.isEmpty(itemsList)) {
                for (MenuItem extraItem : itemsList) {
                    if (extraItem == null) {
                        continue;
                    }
                    if (menu.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0) {
                        extraItem.menuBiz.buyNum = extraItem.menuBiz.buyNum.divide(menu.menuBiz.buyNum, BigDecimal.ROUND_HALF_UP);
                    }
                    extraItem.packID = menu.itemID;

                    //非固定套餐要重新查询套餐明细价格及加价
                    if (!TextUtils.equals(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiSetFoodType from tbMenuItemSetSide where fiSetFoodCd = '" + extraItem.packSubID + "' and fiItemCd_M = '" + extraItem.packID + "'"), "0")) {

                        MenuitemsetsidedtlDBModel menuitemsetsidedtlDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN,
                                "select * from tbMenuItemSetSideDtl where fiSetFoodCd = '" + extraItem.packSubID + "' and fiItemCd = '" + extraItem.itemID + "' and fiItemCd_M = '" + extraItem.packID + "' ",
                                MenuitemsetsidedtlDBModel.class);

                        if (menuitemsetsidedtlDBModel != null) {
                            extraItem.currentUnit.fdSalePrice = menuitemsetsidedtlDBModel.fdIncrease;
                            extraItem.currentUnit.fdVIPPrice = menuitemsetsidedtlDBModel.fdVIPDifference;
                            if (!ListUtil.isEmpty(menu.menuBiz.selectNote) && menu.currentUnit.fdSalePrice != null) {
                                NoteItemModel noteItemModel = menu.menuBiz.selectNote.get(0);
                                if (noteItemModel != null && noteItemModel.price != null && noteItemModel.price.compareTo(extraItem.currentUnit.fdSalePrice) >= 0) {
                                    noteItemModel.price = noteItemModel.price.subtract(extraItem.currentUnit.fdSalePrice.multiply(extraItem.menuBiz.buyNum));
                                    noteItemModel.calcTotal();
                                }
                            }
                        }
                    }
                }
            }
            menu.menuBiz.selectedPackageItems.addAll(itemsList);
        }

        //配料菜
        for (MenuItem item : list) {
            List<MenuItem> ingredients = ingredientMap.get(item.menuBiz.uniq);
            if (!ListUtil.isEmpty(ingredients)) {
                item.menuBiz.selectedModifier = ingredients;
                if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) > 0 && !item.supportWeight()) {
                    for (MenuItem extraItem : item.menuBiz.selectedModifier) {
                        extraItem.menuBiz.buyNum = extraItem.menuBiz.buyNum.divide(item.menuBiz.buyNum, BigDecimal.ROUND_HALF_UP);
                    }
                }
            }
        }

        return list;
    }


    /**
     * 将菜品报表Model转化成MenuItem
     *
     * @param temp
     * @param isMember
     * @param seqNo
     * @return
     */
    public static MenuItem sellItemToMenuItem(SellOrderItemDBModel temp, boolean isMember, int seqNo) {
        UnitModel unitDBModel = UnitModel.copyTo(buildUnit(temp));
        if (unitDBModel == null) {
            return null;
        }
        if(temp.fiIsTemporaryMenu==1){
            unitDBModel.fdSalePrice = temp.fdSalePrice;
            unitDBModel.fdVIPPrice = temp.fdVIPPrice;
        }
        if (temp.fiOrderItemKind == 3) {
            //套餐结构更改
            MenuItem extraItem = new MenuItem();
            extraItem.itemID = temp.fiItemCd;
            if (extraItem.menuBiz == null) {
                extraItem.menuBiz = new MenuBiz();
            }
            extraItem.menuBiz.uniq = temp.fsseq;
            extraItem.packSubID = temp.fiSetFoodCd;
//            UnitModel uni = new UnitModel();
            unitDBModel.fiOrderUintCd = temp.fiOrderUintCd;
            //变价套餐的价格，是参与到加价里了，所以这里赋值为0是没有问题的。
            unitDBModel.fdSalePrice = BigDecimal.ZERO;
            //变价套餐的会员价格，是参与到加价里了，所以这里赋值为0是没有问题的。
            unitDBModel.fdVIPPrice = BigDecimal.ZERO;
//            uni.fdOriginPrice = BigDecimal.ZERO;
            extraItem.currentUnit = unitDBModel;
            extraItem.name = temp.fsItemName;
            extraItem.name2 = temp.fsItemName2;
            extraItem.price = BigDecimal.ZERO;
            extraItem.menuBiz.buyNum = temp.fdSaleQty.subtract(temp.fdBackQty);
            if (TextUtils.isEmpty(temp.fsCreateTime)) {
                extraItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            } else {
                extraItem.menuBiz.createTime = temp.fsCreateTime;
            }

            // 套餐明细备注
            NoteItemModel note = new NoteItemModel();
            note.id = "-2";
            note.groupIDFather = "-2";
            note.name = temp.fsNote;
            note.num = BigDecimal.ONE;
            note.selected = true;
            note.price = temp.fdAddPrice;
            note.calcTotal();
            if (extraItem.menuBiz.selectNote == null) {
                extraItem.menuBiz.selectNote = new ArrayList<>();
            }
            extraItem.menuBiz.selectNote.add(note);
            extraItem.menuBiz.buildNotesString();
            extraItem.terminal_id = MenuTerminal.MEALORDER;
            return extraItem;
        }
        MenuItem item = new MenuItem();

        item.itemID = temp.fiItemCd;
        item.name = temp.fsItemName;
        item.name2 = temp.fsItemName2;
        item.currentUnit = unitDBModel;
        item.restoreCurrentUnit();
        item.currentPractice = null;//待处理

        item.fsHelpCode = "";
        item.fsItemId = "";
        item.menuBiz = new MenuBiz();
        item.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        item.menuBiz.uniq = temp.fsseq;
        item.menuBiz.orderSeqID = seqNo;

        //pro 2.5多做法需求
        item.menuBiz.selectMulProcedure.clear();
        item.menuBiz.selectedExtraStr = "";

        item.menuBiz.buyNum = temp.fdSaleQty;
        //菜品配置项
        MenuitemDBModel dbModel = getMenuDBModelByID(temp.fiItemCd);
        if (dbModel == null) {
            RunTimeLog.addLog(RunTimeLog.SMART, "美小二下单异常菜品：" + temp.fsItemName + "; temp.fiItemCd = " + temp.fiItemCd);
            return null;
        }
        item.fiLedgerMode = dbModel.fiLedgerMode;
        DishesUtil.buildMenuConfig(item, dbModel, getMenuProcedureSize(dbModel.fiItemCd), getMenuUnitSize(dbModel.fiItemCd), optIngredientGPCount(dbModel.fiItemCd));

        // 时价菜
        if (item.supportTimes() && temp.fdSalePrice.compareTo(BigDecimal.ZERO) > 0 && temp.changePriceTimes > 0) {
            item.changeTimesPrice(temp.fdSalePrice);
        }

        if (!item.supportWeight() && temp.fdSaleQty.compareTo(BigDecimal.ZERO) == 0) {
            return null;
        }
        //折扣
        if (!TextUtils.isEmpty(temp.fsDiscountId) && !TextUtils.isEmpty(temp.fsDiscountName)) {
            DiscountDBModel model = new DiscountDBModel();
            model.fiDiscountRate = temp.fiDiscountRate;
            model.fsDiscountId = temp.fsDiscountId;
            model.fsDiscountName = temp.fsDiscountName;
            item.menuBiz.selectDiscount = CouponUtil.convertToDiscountBizModel(model);
        }

        //菜品备注
        NoteItemModel note = new NoteItemModel();
        note.id = "-2";
        note.groupIDFather = "-2";
        note.name = temp.fsNote;
        note.num = BigDecimal.ONE;
        note.selected = true;
        note.price = temp.fdAddPrice;
        note.calcTotal();
        if (item.menuBiz.selectNote == null) {
            item.menuBiz.selectNote = new ArrayList<>();
        }
        item.menuBiz.selectNote.add(note);
        //构建做法
        //item.menuBiz.buildSelectExtraString(item.currentPractice);
        item.menuBiz.buildSelectMulProcedureString(item.menuBiz.selectMulProcedure);
        //构建备注和菜品要求
        item.menuBiz.buildNotesString();

        item.menuBiz.menuSellType = temp.fiOrderMode;
        item.menuBiz.giftUserID = temp.fsGiftUserId;
        item.menuBiz.giftUserName = temp.fsGiftUserName;
        item.menuBiz.giftReason = temp.fsGiftReason;
        item.menuBiz.giftNum = temp.fdGiftqty;
        item.menuBiz.voidNum = temp.fdBackQty;
        item.menuBiz.voidUserID = temp.fsBackUserId;
        item.menuBiz.voidUserName = temp.fsBackUserName;
        item.menuBiz.voidReson = temp.fsBackremark;

        if (temp.fdBackQty != null && temp.fdBackQty.compareTo(BigDecimal.ZERO) > 0) {
            item.menuBiz.menuSellTime = temp.fsBacktime;
        } else {
            item.menuBiz.menuSellTime = temp.fsGifttime;
        }

//        item.menuBiz.currentPriceTimes = temp.changePriceTimes;
        item.menuBiz.fiItemMakeState = temp.fiItemMakeSte;
        item.menuBiz.fiHurryTimes = temp.fiHurryTimes;

        if (temp.fiPriceTag == 2) {
            item.menuBiz.addConfig(1);
            unitDBModel.fdBargainPrice = temp.fdBargainPrice;
            unitDBModel.fdSalePrice = unitDBModel.fdBargainPrice;
        } else if (temp.fiPriceTag == 3) {
            item.menuBiz.addConfig(16);
        }

        item.calcTotal(isMember);
        item.terminal_id = MenuTerminal.MEALORDER;
        return item;
    }


    /**
     * 根据菜品ID获取菜品Model
     *
     * @param id int
     * @return MenuitemDBModel
     */
    public static MenuitemDBModel getMenuDBModelByID(String id) {
        String sql = "select * from tbmenuitem where fiItemCd='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuitemDBModel.class);
    }

    /**
     * 获取菜品的做法数量
     *
     * @param menuID int | fiItemCd
     * @return int
     */
    public static int getMenuProcedureSize(String menuID) {
        String sql = "select count(*) as count from tbask"
                + " where fiStatus='1'" +
                "  and fiItemCd='" + menuID
                + "' and fsAskGpId='-1' ";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

    /**
     * 获取单个菜品的规格数量
     *
     * @param menuID int|菜品ID
     * @return List<MenuItemUnitDBModel>
     */
    public static int getMenuUnitSize(String menuID) {
        String sql = "select count(*) as count from tbmenuitemuint"
                + " where fiItemCd='" + menuID
                + "' and fiStatus <> '13' ";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

    /**
     * 获取菜品配料分组的数量
     *
     * @param menuID 菜品ID
     * @return
     */
    public static int optIngredientGPCount(String menuID) {
        String sql = "select count(*) as count from tbmenuingredgprel"
                + " where fiStatus='1'" +
                "  and fiItemCd='" + menuID + "'";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

}
