package com.mwee.android.pos.waiter.business.getdata;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.GetVerifyCodePosRequest;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.component.cross.net.CreditAccountListRequest;
import com.mwee.android.pos.component.cross.net.CreditAccountListResponse;
import com.mwee.android.pos.component.permission.UserRoleAuthorityDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.CreditAccountListSocketResponse;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.CreditaccountDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.waiter.basebean.NameInvoke;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBizUtil;
import com.mwee.android.pos.waiter.component.WaiterName;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 数据获取的相关的方法
 * Created by virgil on 2017/1/16.
 */

@SuppressWarnings("unused")
class NameGetData extends NameInvoke {

    /**
     * 获取所有数据
     *
     * @param request
     * @return
     */
    @WaiterName("getalldata")
    private static WaiterResponse getalldata(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject jsonObject = JSON.parseObject(request.Data);
        String clientTime = jsonObject.getString("time");
        String dbdatas = "";
        //更新站点的营业数据
        String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
        if (!TextUtils.equals(clientTime, currentDataVersion)) {
            dbdatas = buildData(clientTime);
        }

        JSONObject ob = new JSONObject();
        ob.put("dbdatas", dbdatas);
        ob.put("time", currentDataVersion);

        response.Data = ob.toString();

        return response;
    }

    /**
     * 查询数据
     *
     * @return
     */
    public static String buildData(String clientTime) {
        String[] tableList = new String[]{
                "tbask", "tbaskgp",
                "tbmenucls", "tbmenuingredgprel", "tbmenuitem", "tbmenuitemaskgp", "tbmenuitemsetside", "tbmenuitemsetsidedtl", "tbmenuitemuint",
                "tbmarea", "tbMTable", "tbmtablecls", "tbparamvalue", "tbmsection", "tbshop", "tbuser", "tbBargain", "tbBargainitem",
        "tbshopsellplan","tbsellmenumap"};
        JSONObject dbdatas = new JSONObject();
        String sqlParam = "";
        if (!TextUtils.isEmpty(clientTime)) {
            sqlParam = " where fsupdateTime > '" + clientTime + "'";
        }

        String sql = "select * from %s " + sqlParam;
        for (String temp : tableList) {
            dbdatas.put(temp, DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, temp)));
        }
        dbdatas.put("meta", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL));
        return dbdatas.toString();
    }


    //====================================菜品====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917731">获取菜品类别</a>
     */
    @WaiterName("getmenuclsdata")
    private static WaiterResponse a(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbmenucls");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917796">获取菜品信息</a>
     */
    @WaiterName("getmenudata")
    private static WaiterResponse b(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMenuItem");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917802">获取套餐分组</a>
     */
    @WaiterName("getsetside")
    private static WaiterResponse c(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMenuItemSetSide");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917802">获取套餐明细</a>
     */
    @WaiterName("getsetsidedtl")
    private static WaiterResponse m(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMenuItemSetSideDtl");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917821">获取菜品规格</a>
     */
    @WaiterName("getunitdata")
    private static WaiterResponse d(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMenuItemUint");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917844">获取沽清</a>
     */
    @WaiterName("getunitreasondata")
    private static WaiterResponse e(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = SellOutServerProcessor.getAllSellOutViewModel();
        return response;
    }

    //====================================菜品要求====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917878">获取菜品要求分类</a>
     */
    @WaiterName("getaskgp")
    private static WaiterResponse f(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbaskgp");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917887">获取菜品要求</a>
     */
    @WaiterName("getask")
    private static WaiterResponse g(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbAsk");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917891">获取要求菜品映射</a>
     */
    @WaiterName("getmenuitemask")
    private static WaiterResponse h(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbmenuitemaskgp");
        return response;
    }

    //====================================餐桌====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917849">获取餐桌分类</a>
     */
    @WaiterName("getMTableClsByWhere")
    private static WaiterResponse n(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = TableBusinessUtil.getAllTableCls();
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917857">获取所有桌台</a>
     */
    @WaiterName("getMTableByWhere")
    private static WaiterResponse i(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = JSON.toJSONString(TableBusinessUtil.getAllTablesForWaiter());
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=6328101">获取桌台业务状态（仅返回已开台桌台数据）</a>
     * <p>
     * 获取所有已开台桌台业务数据--- 桌台ID，开台时间，订单金额
     */
    @WaiterName("getTableSimpBiz")
    private static WaiterResponse ia(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = new JSONObject();
        RefreshTableBizDataResponse refreshTableBizDataResponse = new RefreshTableBizDataResponse();
        TableBusinessUtil.getRefreshTableBizDataResponse(refreshTableBizDataResponse);
        jsonObject.put("tableBizResponse", refreshTableBizDataResponse);
        response.Data = jsonObject.toJSONString();
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917866">获取所有餐区</a>
     */
    @WaiterName("getMareaByWhere")
    private static WaiterResponse j(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = TableBusinessUtil.getAllArea();
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917873">获取餐桌颜色状态</a>
     */
    @WaiterName("getMTableSteByWhere")
    private static WaiterResponse k(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = TableBusinessUtil.getAllTableSet();
        return response;
    }


    //====================================参数====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917816">获取参数设置</a>
     */
    @WaiterName("getparamvalue")
    private static WaiterResponse l(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbParamValue");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918791">获取餐段</a>
     */
    @WaiterName("getMSection")
    private static WaiterResponse q(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbmsection");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4924150">根据餐桌ID获取餐桌信息</a>
     */
    @WaiterName("getTableById")
    private static WaiterResponse r(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        response.Data = TableBusinessUtil.getTableInfoAndBizByTableId(jsonObject.getString("fsmtableid"));
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4926369">获取词库表</a>
     */
    @WaiterName("getWordHouse")
    private static WaiterResponse s(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        response.Data = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsWord from tbWordhouse where fiStatus='1' and fsFieldItem='" + jsonObject.get("fsFieldItem") + "' order by fiSortOrder asc");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4926363">获取指定权限的账号列表</a>
     */
    @WaiterName("getPermissionUsers")
    private static WaiterResponse t(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String permissionType = jsonObject.getString("permission");
        response.Data = UserRoleAuthorityDBUtil.getDinnerUserByProgdtlIdWithoutPWd(permissionType);
        return response;
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=5609571">60.查询支付明细</a>
     */
    @WaiterName("getsellreceive")
    private static WaiterResponse u(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String fsSellNo = jsonObject.getString("fsSellNo");
        String searchBackDetail = jsonObject.getString("searchBackDetail");
        String sql = "select * from tbSellReceive where fsSellNo='" + fsSellNo + "'";
        if (!TextUtils.equals("1", searchBackDetail)) {
            sql = sql + " and fiStatus='1'";
        }
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
        return response;
    }

    /**
     * 获取所有秒点信息
     * createTime       时间：HH:mm  String
     * tableName        桌台号       String
     * businessStatus   消息状态      int  0;//未处理  1;//自动下厨  2;//已处理  3;//已忽略
     * msgId            消息ID       int
     */
    @WaiterName("getOrderMessage")
    private static WaiterResponse v(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        //营业日期
        String businessDate = HostUtil.getHistoryBusineeDate("");

        //获取所有秒点信息
        response.Data = MessageDBUtil.getRapidMessageOrdersForSmart(businessDate);
        return response;
    }

    /**
     * 获取所有秒付信息
     * createTime       时间：HH:mm  String
     * tableName        桌台号       String
     * businessStatus   消息状态      int  0;//未支付 1;//已支付  2;//已拒绝
     * msgId            消息ID       int
     * payAmt           支付金额     String
     * allAmt           账单总金额   String
     */
    @WaiterName("getPayMessage")
    private static WaiterResponse w(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        // 营业日期
        String businessDate = HostUtil.getHistoryBusineeDate("");

        //获取所有秒付信息
        response.Data = MessageDBUtil.getRapidMessagePayForSmart(businessDate);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634501">76.支付-获取挂帐列表</a>
     */
    @WaiterName("getcreditaccount")
    private static WaiterResponse paySearchByBarcode(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);

        String accountName = jsonObject.getString("accountName");
        int currentPage = jsonObject.getInteger("currentPage");
        int size = jsonObject.getInteger("size");
        CreditAccountListRequest requestCreditAccount = new CreditAccountListRequest();
        requestCreditAccount.currentPage = currentPage;
        requestCreditAccount.pageSize = size;
        requestCreditAccount.accountName = accountName;
        requestCreditAccount.status = "1";
        requestCreditAccount.sellDate = HostUtil.getHistoryBusineeDate("");


        BusinessExecutor.execute(requestCreditAccount, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CreditAccountListResponse) {
                    CreditAccountListResponse accountListResponse = (CreditAccountListResponse) responseData.responseBean;
                    response.Data = accountListResponse.data;
                } else {
                    WaiterBizUtil.buildErrorRepsone(response, responseData.resultMessage);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                WaiterBizUtil.buildErrorRepsone(response, responseData.resultMessage);
                return false;
            }
        }, false);


        return response;
    }

    @WaiterName("getVerifyCode")
    private static WaiterResponse getVerifyCode(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);

        String mobile = jsonObject.getString("mobile");
        if (TextUtils.isEmpty(mobile)) {
            WaiterBizUtil.buildErrorRepsone(response, "手机号为空");
            return response;
        }
        if (!RegexUtil.checkIsPhoneNumber(mobile)) {
            WaiterBizUtil.buildErrorRepsone(response, "手机号格式不正确");
            return response;
        }
        GetVerifyCodePosRequest posRequest = new GetVerifyCodePosRequest();
        posRequest.userMobileNum = mobile;
        BusinessExecutor.execute(posRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                response.Error = responseData.resultMessage;
                if (responseData.responseBean != null) {
                    response.Status = responseData.responseBean.status + "";
                } else {
                    response.Status = responseData.result + "";
                }
                return false;
            }
        }, false);
        return response;
    }

    /**
     * 获取特价列表
     *
     * @param request
     * @return
     */
    @WaiterName("getBargainList")
    private static WaiterResponse getBarginList(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        response.Data = OrderUtil.initBarginList(HostUtil.getHistoryBusineeDate(""));
        return response;
    }
}
