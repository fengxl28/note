package com.mwee.android.pos.waiter.component;

import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.waiter.server.WaiterServer;

/**
 * Created by virgil on 2018/1/18.
 * @author virgil
 */
@SuppressWarnings("unused")
public class WaiterDriver implements IDriver {
    @Override
    public String getModuleName() {
        return "waiterEntry";
    }
    @DrivenMethod(uri = "waiterEntry/init")
    public void init(){
        WaiterServer.getInstance().init();
    }
}
