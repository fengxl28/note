package com.mwee.android.pos.waiter.basebean;

import com.mwee.android.base.net.BusinessBean;

/**
 * 美小二请求的基类
 * Created by virgil on 2017/1/16.
 */
public class WaiterRequest extends BusinessBean {

    /**
     * 请求的服务类型
     */
    public String Service = "";

    /**
     * 具体的服务
     */
    public String Name = "";

    /**
     * 发起请求的门店GUID
     */
    public String ShopGUID = "";

    /**
     * 用户的登录token
     */
    public String Token = "0";

    /**
     * 订单操作的Token
     */
    public String OrderToken = "";
    /**
     * 硬件设备唯一标示
     */
    public String Device = "";
    /**
     * 请求的类容 json格式
     */
    public String Data = "";


    public WaiterRequest() {

    }
}
