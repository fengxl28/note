package com.mwee.android.pos.waiter.business.bill;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.order.DiscountBizUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.connect.business.discount.NameDiscountModel;
import com.mwee.android.pos.connect.business.pay.model.PayViewBaseData;
import com.mwee.android.pos.connect.business.pay.model.PayViewBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.discount.CouponUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBizUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by virgil on 2017/9/8.
 */

class NameUtil {

    public static WaiterPayBase buildPayBase(String orderID) {
        WaiterPayBase base = new WaiterPayBase();
        PayViewBaseData payViewBaseData = BillUtil.buildPayBase(orderID, false);
        base.fssellno = payViewBaseData.orderID;
        base.billNO = payViewBaseData.billNO;
        base.fsmtableid = payViewBaseData.tableID;
        base.amtOrigin = payViewBaseData.amtOrigin;
        base.amtDiscounted = payViewBaseData.amtDiscounted;
        base.amtTotalNeedPay = payViewBaseData.amtTotalNeedPay;
        base.amtTotalCanDiscount = payViewBaseData.amtTotalCanDiscount;
        base.payTypeList = PayCache.getPayTypeList(false);
        base.rewardInfo = payViewBaseData.rewardInfo;
        base.memberCardNo = payViewBaseData.memberCardNo;
        base.amtService = payViewBaseData.amtService;
        base.hasFee = payViewBaseData.hasFee;
        return base;
    }

    public static WaiterPayView buildPayView(String orderID) {
        WaiterPayView base = new WaiterPayView();
        PayViewBean payViewBaseData = BillUtil.buildPayViewData(orderID);
        base.fssellno = payViewBaseData.orderID;
        base.amtLeftToPay = payViewBaseData.amtLeftToPay;
        base.amtNeedChange = payViewBaseData.amtNeedChange;
        base.amtLeftCanDiscount = payViewBaseData.amtLeftCanDiscount;
        base.payTypeList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbsellreceive where fssellno='" + orderID + "' and fiStatus='1' order by fiseq asc", SellreceiveDBModel.class);
        base.freeServiceFee = payViewBaseData.freeServiceFee;
        return base;
    }

    /**
     * 判断能否操作订单
     *
     * @param orderCache
     * @param userDBModel
     * @return
     */
    public static WaiterResponse isHandleFssellno(OrderCache orderCache, UserDBModel userDBModel) {
        WaiterResponse response = new WaiterResponse();
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
        }
        //共享餐厅的订单不允许
        if (orderCache.isNotSupportEditor()) {
            WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
        }
        //检测桌台锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
        }
        return response;
    }

    public static void doDiscount(WaiterResponse response,
                                  OrderCache orderCache, List<MenuItem> menuItemList,
                                  List<NameDiscountModel> nameDiscountList,
                                  String fsDiscountCutId) {
        //整单立减折扣
        DiscountDBModel discountDBModelCut = null;
        if (!TextUtils.isEmpty(fsDiscountCutId)) {
            discountDBModelCut = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where " +
                    "fsDiscountId = '" + fsDiscountCutId + "' and fiStatus = '1' ", DiscountDBModel.class);
            if (discountDBModelCut != null && !DiscountBizUtil.dataIsEffectiveDate(discountDBModelCut)) {
                WaiterBizUtil.buildErrorRepsone(response, "整单立减折扣[" + discountDBModelCut.fsDiscountName + "]未生效");
                return;
            }
        }
        orderCache.selectOrderDiscountCut = CouponUtil.convertToDiscountBizModel(discountDBModelCut);

        StringBuilder errMessage = new StringBuilder();
        if (!ListUtil.isEmpty(nameDiscountList) && !ListUtil.isEmpty(menuItemList)) {

            int memberLevel = -1;
            String csId = "";
            String plusId = "";
            if (orderCache.memberInfoS != null && orderCache.memberInfoS.level > 0) {
                memberLevel = orderCache.memberInfoS.level;
                csId = orderCache.memberInfoS.cs_id;
                plusId = orderCache.memberInfoS.plusId;
            }
            for (NameDiscountModel nameDiscountModel : nameDiscountList) {
                if (nameDiscountModel == null) {
                    continue;
                }
                for (MenuItem menuItem : menuItemList) {
                    if (menuItem == null) {
                        continue;
                    }
                    if (menuItem.hasAllVoid()) {
                        continue;
                    }
                    if (TextUtils.equals(nameDiscountModel.uniq, menuItem.menuBiz.uniq)) {
                        if (!nameDiscountModel.gift) {
                            menuItem.useMemberPrice = nameDiscountModel.useMember;
                            menuItem.disGift();

                            if (nameDiscountModel.useMember && memberLevel > 0 && !menuItem.supportTimes() &&
                                    !menuItem.isMenuTemporary()) {   //支持多等级会员价
                                menuItem.currentUnit.fdVIPPrice = MenuItemVipPriceUtil.getMemberVipPrice(menuItem
                                        .itemID, menuItem.currentUnit.fiOrderUintCd, memberLevel, csId, plusId);
                            }

                            if ((menuItem.config & 16) == 16 && !TextUtils.isEmpty(nameDiscountModel.dicountId)) {
                                DiscountDBModel discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select *" +
                                        " from tbdiscount where fsDiscountId = '" + nameDiscountModel.dicountId + "' and" +
                                        " fiStatus = '1' ", DiscountDBModel.class);
                                if (discountDBModel != null && !DiscountBizUtil.dataIsEffectiveDate
                                        (discountDBModel)) {
                                    errMessage.append("折扣[").append(discountDBModel.fsDiscountName).append
                                            ("]未生效").append(";");
                                }
                                if (discountDBModel != null && discountDBModel.ficouponid != 2) {
                                    //非整单打折的折扣要校验该菜品是否支持该折扣
                                    String sql = "select tbdiscount.fsDiscountId,tbdiscount.fsDiscountName," +
                                            "tbdiscount.fiIsVIPUse,tbdiscountitem.fiDiscountRate " +
                                            "from tbdiscount inner join tbdiscountitem " +
                                            "on tbdiscountitem.fsDiscountId=tbdiscount.fsDiscountId " +
                                            "where tbdiscount.fsDiscountId<>'99999' and tbdiscountitem" +
                                            ".fsDiscountId='" + nameDiscountModel.dicountId + "' " +
                                            "and tbdiscountitem.fiStatus ='1' and tbdiscount.fiStatus ='1' and " +
                                            "tbdiscountitem.fiOrderUintCd='" + menuItem.currentUnit
                                            .fiOrderUintCd + "' " +
                                            "and tbdiscountitem.fiItemCd='" + menuItem.itemID + "' order by " +
                                            "tbdiscount.fsDiscountId asc";
                                    DiscountDBModel discount = DBSimpleUtil.query(APPConfig.DB_MAIN, sql,
                                            DiscountDBModel.class);
                                    if (discount == null) {
                                        menuItem.cancelDiscount();
                                    } else if (discount.fiIsVIPUse == 0) {
                                        menuItem.giveDiscount(discount, nameDiscountModel.reason,
                                                nameDiscountModel.userId, nameDiscountModel.userName);
                                    } else if (discount.fiIsVIPUse == 1 && memberLevel > 0 && discount.fiVIPId <=
                                            memberLevel) {
                                        menuItem.giveDiscount(discount, nameDiscountModel.reason,
                                                nameDiscountModel.userId, nameDiscountModel.userName);
                                    } else {
                                        errMessage.append("不满足会员折扣[").append(discount.fsDiscountName).append
                                                ("]要求").append(";");
                                    }
                                } else {
                                    menuItem.giveDiscount(discountDBModel, nameDiscountModel.reason,
                                            nameDiscountModel.userId, nameDiscountModel.userName);
                                }
                            } else {
                                menuItem.cancelDiscount();
                            }
                            menuItem.calcTotal(nameDiscountModel.useMember);
                        } else {
//                                menuItem.doGift(nameDiscountModel.userId, nameDiscountModel.userName,
//                                        nameDiscountModel.reason);
//                                menuItem.calcTotal(nameDiscountModel.useMember);

                            //赠送菜品---没有给数量时，默认是全部赠送
                            if (nameDiscountModel.fdGiftqty != null) {
                                //赠送数量<=0时，认为是取消赠送
                                if (nameDiscountModel.fdGiftqty.compareTo(BigDecimal.ZERO) <= 0) {
                                    if (menuItem.doGift(nameDiscountModel.userId, "", nameDiscountModel.reason)) {
                                        menuItem.calcTotal(false);
                                    }
                                } else if (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
                                    //该菜品是赠送状态--再次提交的赠送数量小于已赠送数量---->取消部分赠送
                                    if (nameDiscountModel.fdGiftqty.compareTo(menuItem.menuBiz.giftNum) < 0) {
                                        MenuItem menuItemClone = menuItem.clone();
                                        menuItemClone.updateUniq();
                                        menuItemClone.menuBiz.buyNum = menuItemClone.menuBiz.buyNum.subtract(nameDiscountModel.fdGiftqty);
                                        menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                        menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                        menuItemClone.disGift();
                                        menuItemClone.calcTotal(false);

                                        if (DBOrderConfig.useKdsService()) {
                                            // 通知 KDS 菜品拆分
                                            KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                        }

                                        menuItem.menuBiz.buyNum = nameDiscountModel.fdGiftqty;
                                        if (menuItem.doGift(nameDiscountModel.userId, "", nameDiscountModel.reason)) {
                                            menuItem.cleanBuyGiftInfo();
                                            menuItem.calcTotal(false);
                                        }
                                        if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            menuItemList.add(menuItemClone);
                                        } else {
//                                                menuItemList.add(menuItemClone);
                                        }

                                        /* 调整划菜数量 */
                                        // 已划菜数量
                                        BigDecimal delimited = menuItem.menuBiz.delimitNum;
                                        // 划菜数量优先分配到赠送的菜品
                                        if (menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).compareTo(delimited) >= 0) {
                                            menuItem.menuBiz.delimitNum = delimited;
                                            menuItemClone.menuBiz.delimitNum = BigDecimal.ZERO;
                                        } else {
                                            menuItem.menuBiz.delimitNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                                            menuItemClone.menuBiz.delimitNum = delimited.subtract(menuItem.menuBiz.delimitNum);
                                        }
                                    }
                                } else if (nameDiscountModel.fdGiftqty.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).subtract(menuItem.menuBiz.giftNum)) < 0) {
                                    //非赠送菜品---赠送数量小于菜品数量时，认为是赠送部分菜品
                                    MenuItem menuItemClone = menuItem.clone();
                                    menuItemClone.updateUniq();
                                    menuItemClone.menuBiz.buyNum = nameDiscountModel.fdGiftqty;
                                    menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                    menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                    if (menuItemClone.doGift(nameDiscountModel.userId, "", nameDiscountModel.reason)) {
                                        menuItem.cleanBuyGiftInfo();
                                        menuItemClone.calcTotal(false);
                                    }
                                    menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(nameDiscountModel.fdGiftqty);
                                    menuItem.calcTotal(false);

                                    if (DBOrderConfig.useKdsService()) {
                                        // 通知 KDS 菜品拆分
                                        KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                    }

                                    if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                        menuItemList.add(menuItemClone);
                                    } else {
//                                            menuItemList.add(menuItemClone);
                                    }

                                    /* 调整划菜数量 */
                                    // 已划菜数量
                                    BigDecimal delimited = menuItem.menuBiz.delimitNum;
                                    // 划菜数量优先分配到赠送的菜品
                                    if (menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum).compareTo(delimited) >= 0) {
                                        menuItemClone.menuBiz.delimitNum = delimited;
                                        menuItem.menuBiz.delimitNum = BigDecimal.ZERO;
                                    } else {
                                        menuItemClone.menuBiz.delimitNum = menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum);
                                        menuItem.menuBiz.delimitNum = delimited.subtract(menuItemClone.menuBiz.delimitNum);
                                    }
                                } else {
                                    //非赠送菜品---赠送数量大于等于菜品数量时，认为是赠送全部菜品
                                    if (menuItem.doGift(nameDiscountModel.userId, "", nameDiscountModel.reason)) {
                                        menuItem.cleanBuyGiftInfo();
                                        menuItem.calcTotal(false);
                                    }
                                }
                            } else {
                                if (menuItem.doGift(nameDiscountModel.userId, "", nameDiscountModel.reason)) {
                                    menuItem.cleanBuyGiftInfo();
                                    menuItem.calcTotal(false);
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }

        if (errMessage.length() > 0) {
            response.Error = "折扣[" + errMessage.substring(errMessage.length() - 1) + "]未生效";
        }
    }
}
