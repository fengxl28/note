package com.mwee.android.pos.waiter.business.bill;

/**
 * Bill相关的业务分发
 * Created by virgil on 2017/1/16.
 */

public class WaiterInvokBill {

    public static Class getNameClass() {
        return NameBill.class;
    }
}
