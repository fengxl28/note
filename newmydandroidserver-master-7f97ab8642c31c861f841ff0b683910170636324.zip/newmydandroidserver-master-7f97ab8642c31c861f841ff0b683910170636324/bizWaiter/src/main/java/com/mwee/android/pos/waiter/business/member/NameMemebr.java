package com.mwee.android.pos.waiter.business.member;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.module.member.service.IMemberService;
import com.mwee.android.pos.businesscenter.module.member.service.impl.MemberServiceImpl;
import com.mwee.android.pos.businesscenter.module.order.service.IOrderService;
import com.mwee.android.pos.businesscenter.module.order.service.impl.OrderServiceImpl;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.component.member.net.GetMemberCardByCardNoRequest;
import com.mwee.android.pos.component.member.net.GetMemberCardResponse;
import com.mwee.android.pos.component.member.net.MemberConsumePreSearchResponse;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.waiter.basebean.NameInvoke;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBizUtil;
import com.mwee.android.pos.waiter.business.bill.WaiterPayResult;
import com.mwee.android.pos.waiter.component.WaiterName;

import java.math.BigDecimal;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 美小二会员相关的操作
 * Created by virgil on 2017/1/16.
 */
@SuppressWarnings("unused")
class NameMemebr extends NameInvoke {
    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919155">是否开通会员判断</a>
     */
    @WaiterName("appmembercardopenSevrice")
    private static WaiterResponse a(WaiterRequest request) {
       /* WaiterResponse response = new WaiterResponse();
        MemberConfigRequest memberConfigRequest = new MemberConfigRequest();
        memberConfigRequest.shopid = StringUtil.toInt(DBMetaUtil.getSettingsValueByKey(META.SHOPID), 0);
        String fsCompanyGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsShopGUID = '" + memberConfigRequest.shopid + "'");
        memberConfigRequest.m_shopid = StringUtil.toInt(fsCompanyGUID);
        BusinessExecutor.execute(memberConfigRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConfigResponse) {
                    MemberConfigResponse memberConfigResponse = ((MemberConfigResponse) responseData.responseBean);
                    response.Data = memberConfigResponse.data;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                response.Error = responseData.resultMessage;
                if (responseData.responseBean != null) {
                    response.Status = responseData.responseBean.status + "";
                } else {
                    response.Status = responseData.result + "";
                }
                return false;
            }
        }, false);
        return response;
*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919159">获取会员卡买单配置</a>
     */
    @WaiterName("appcardpaypaycnf")
    private static WaiterResponse b(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919170">查询会员信息:卡号查询会员</a>
     * 该接口支持查询会员且绑定；也支持仅查询会员信息
     * 当没有fsSellNo的时候我们认为是仅查询会员
     */
    @WaiterName("appmembercardget")
    private static WaiterResponse c(WaiterRequest request) {
//        final WaiterResponse response = new WaiterResponse();
//
//        JSONObject submitInfo = JSON.parseObject(request.Data);
//        String cardno = submitInfo.getString("cardno");
//        final String fsSellNo = submitInfo.getString("fsSellNo");
//        if (TextUtils.isEmpty(cardno)) {
//            WaiterBizUtil.buildErrorRepsone(response, "卡号为空");
//            return response;
//        }
//        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
//        if (userDBModel == null) {
//            WaiterBizUtil.buildInvalidTokenlRepsone(response);
//            return response;
//        }
//
//        //当订单号为空时，不需要校验订单
//        if (!TextUtils.isEmpty(fsSellNo)) {
//            if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
//                WaiterBizUtil.buildIneffectivenessOrderToken(response);
//                return response;
//            }
//            //判断是否可以操作订单
//            String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
//            if (!TextUtils.isEmpty(error)) {
//                WaiterBizUtil.buildErrorRepsone(response, error);
//                return response;
//            }
//            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
//            if (orderCache == null) {
//                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
//                return response;
//            }
//
//            //检查桌台是否被锁定
//            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
//            if (!TextUtils.isEmpty(erroInfo)) {
//                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
//                return response;
//            }
//
//            WaiterBizUtil.optToken(request.OrderToken, fsSellNo);
//        }
//
//        GetMemberCardByCardNoRequest getMemberCardByMobileRequest = new GetMemberCardByCardNoRequest();
//        getMemberCardByMobileRequest.card_no = cardno;
//        BusinessExecutor.execute(getMemberCardByMobileRequest, new IExecutorCallback() {
//            @Override
//            public void success(ResponseData responseData) {
//                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
//                    GetMemberCardResponse memberCardResponse = ((GetMemberCardResponse) responseData.responseBean);
//                    response.Data = memberCardResponse.data;
//                    bindMemberToOrder(fsSellNo, userDBModel, memberCardResponse);
//                }
//            }
//
//            @Override
//            public boolean fail(ResponseData responseData) {
//                response.Error = responseData.resultMessage;
//                if (responseData.responseBean != null) {
//                    response.Status = responseData.responseBean.status + "";
//                } else {
//                    response.Status = responseData.result + "";
//                }
//                return false;
//            }
//        }, false);
//        return response;

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919170">查询会员信息:手机号查询会员</a>
     * 该接口支持查询会员且绑定；也支持仅查询会员信息
     * 当没有fsSellNo的时候我们认为是仅查询会员
     */
    @WaiterName("appmembercardbyMobile")
    private static WaiterResponse d(WaiterRequest request) {
       /* final WaiterResponse response = new WaiterResponse();

        JSONObject submitInfo = JSON.parseObject(request.Data);
        String mobile = submitInfo.getString("mobile");//
        String smsCode = submitInfo.getString("sms_code");
        String deviceId = submitInfo.getString("device_id");
        final String fsSellNo = submitInfo.getString("fsSellNo");

        if (TextUtils.isEmpty(mobile)) {
            WaiterBizUtil.buildErrorRepsone(response, "手机号为空");
            return response;
        }
        if (!RegexUtil.checkIsPhoneNumber(mobile)) {
            WaiterBizUtil.buildErrorRepsone(response, "手机号格式不正确");
            return response;
        }
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        //当订单号为空时，不需要校验订单
        if (!TextUtils.isEmpty(fsSellNo)) {
            if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
                WaiterBizUtil.buildIneffectivenessOrderToken(response);
                return response;
            }
            //判断是否可以操作订单
            String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }

            //检查桌台是否被锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fsSellNo);
        }
        if (TextUtils.isEmpty(smsCode)) {//手机号查询会员信息
            GetMemberCardByMobileRequest getMemberCardByMobileRequest = new GetMemberCardByMobileRequest();
            getMemberCardByMobileRequest.mobile = mobile;
            BusinessExecutor.execute(getMemberCardByMobileRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    getMemberCardByMobileSuccess(responseData, response, fsSellNo, userDBModel);
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    getMemberCardByMobileFail(responseData, response);
                    return false;
                }
            }, false);
        } else {//手机号验证码查询会员信息
            MemberQueryByMobileAndCodeRequest memberQueryByMobileAndCodeRequest = new MemberQueryByMobileAndCodeRequest();
            memberQueryByMobileAndCodeRequest.sms_code = smsCode;
            memberQueryByMobileAndCodeRequest.mobile = mobile;
            memberQueryByMobileAndCodeRequest.device_id = deviceId;
            BusinessExecutor.execute(memberQueryByMobileAndCodeRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    getMemberCardByMobileSuccess(responseData, response, fsSellNo, userDBModel);
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    getMemberCardByMobileFail(responseData, response);
                    return false;
                }
            }, false);
        }
        return response;

*/
        return WaiterBizUtil.buildNotSupportRepsone();
    }

    private static void getMemberCardByMobileFail(ResponseData responseData, WaiterResponse response) {
        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
        response.Error = responseData.resultMessage;
        if (responseData.responseBean != null) {
            response.Status = responseData.responseBean.status + "";
        } else {
            response.Status = responseData.result + "";
        }
    }

    private static void getMemberCardByMobileSuccess(ResponseData responseData, WaiterResponse response, String fsSellNo, UserDBModel userDBModel) {
        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
            GetMemberCardResponse memberCardResponse = ((GetMemberCardResponse) responseData.responseBean);
            response.Data = memberCardResponse.data;
            bindMemberToOrder(fsSellNo, userDBModel, memberCardResponse);
        }
    }

    /**
     * 将会员信息绑定到订单
     *
     * @param fsSellno String
     * @param response GetMemberCardResponse
     */
    private static void bindMemberToOrder(String fsSellno, UserDBModel userDBModel, GetMemberCardResponse response) {
        if (TextUtils.isEmpty(fsSellno)) {
            return;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellno);
        if (orderCache != null) {
            orderCache.setMember(response.data);
//            if (DBMetaUtil.autoUseMemberPrice()) {
//                //开启默认使用会员价格
//                orderCache.updateAllMenuToMemberPrice();
//            }
            MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, userDBModel == null ? "" : userDBModel.fsUserId);
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().writeOrder(fsSellno, true, "bindMemberToOrder");
//            OrderProcessor.saveOrder(orderCache, null);
            NotifyToClient.orderChangeForSmart(fsSellno, orderCache.fsmtableid);
            MemberBizUtil.requestMemberComents(orderCache.memberInfoS.card_no);
//快餐单可以先不经过准备支付的阶段，所以需要校验PaySession是否已经生成
            if (OrderSession.getInstance().getPay(fsSellno) == null) {
                OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(fsSellno), userDBModel, HostBiz.mealorder);
            }
        }
    }

    /**
     * 解绑会员
     */
    @WaiterName("loginOutMenmber")
    private static WaiterResponse loginOutMenmber(WaiterRequest request) {
       /* final WaiterResponse response = new WaiterResponse();

        JSONObject submitInfo = JSON.parseObject(request.Data);
        final String fsSellno = submitInfo.getString("fsSellNo");

        if (TextUtils.isEmpty(fsSellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号不存在");
            return response;
        }

        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        if (!WaiterBizUtil.checkOrderToken(fsSellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        //判断是否可以操作订单
        String error = WaiterBizUtil.canOpertaOrder(fsSellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellno);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }

        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        WaiterBizUtil.optToken(request.OrderToken, fsSellno);

        if (orderCache.memberInfoS != null) {
            ServerCache.getInstance().releaseMemberComments(orderCache.memberInfoS.card_no);
        }
        orderCache.clearMember();
        OrderSession.getInstance().writeOrder(fsSellno, true, "loginOutMenmber");
//        OrderProcessor.saveOrder(orderCache, null);
        NotifyToClient.orderChangeForSmart(fsSellno, orderCache.fsmtableid);

        JSONObject result = new JSONObject();
        result.put("totalPrice", orderCache.optTotalPrice());
        response.Data = result;

        return response;
*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * 使用或取消使用会员价
     */
    @WaiterName("useOrCancelVIPPrince")
    private static WaiterResponse useOrCancelVIPPrince(WaiterRequest request) {
       /* final WaiterResponse response = new WaiterResponse();

        JSONObject submitInfo = JSON.parseObject(request.Data);
        final String fsSellno = submitInfo.getString("fsSellNo");

        //0：取消使用会员价； 1：使用会员价
        final int actionType = submitInfo.getIntValue("actionType");

        if (TextUtils.isEmpty(fsSellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号不存在");
            return response;
        }

        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        if (!WaiterBizUtil.checkOrderToken(fsSellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        //判断是否可以操作订单
        String error = WaiterBizUtil.canOpertaOrder(fsSellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellno);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }

        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        WaiterBizUtil.optToken(request.OrderToken, fsSellno);

        if (actionType == 0) {//取消使用会员价
            orderCache.clearAllVipPrice();
        } else {   //使用会员价---支持不同等级会员价
            //所有菜品使用会员价
            orderCache.updateAllMenuToMemberPrice();
        }
        orderCache.plusAllMenuAmount();
        OrderSession.getInstance().writeOrder(fsSellno, true, "useOrCancelVIPPrince");
//        OrderProcessor.saveOrder(orderCache, null);
        NotifyToClient.orderChangeForSmart(fsSellno, orderCache.fsmtableid);

        JSONObject result = new JSONObject();
        result.put("totalPrice", orderCache.optTotalPrice());
        response.Data = result;
        return response;

*/
        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * 查询会员积分
     * <p>
     * 支持翻页 lastId是上一次拉倒的最后一个积分的ID,如果第一次拉数据穿'0'
     * 默认一页20条数据
     *
     * @param request
     * @return
     */

    @WaiterName("queryMemberHistoryScore")
    private static WaiterResponse queryMemberHistoryScore(WaiterRequest request) {
       /* final WaiterResponse response = new WaiterResponse();
        JSONObject ob = JSON.parseObject(request.Data);

        String memberCardNo = ob.getString("memberCardNo");//会员卡号
        if (TextUtils.isEmpty(memberCardNo)) {
            WaiterBizUtil.buildErrorRepsone(response, "会员卡号异常，请重试");
            return response;
        }

        Integer lastId = ob.getInteger("lastId");//最后一个积分ID
        if (lastId == null) {
            lastId = Integer.getInteger("0");
        }

        MemberProcess.gotMemberHistoryScore(memberCardNo, lastId, new IResponse<List<MemberHistoryScoreModel>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<MemberHistoryScoreModel> info) {
                if (result) {
                    final JSONObject responsData = new JSONObject();
                    response.Data = responsData;
                    responsData.put("havenext", code);  //havenext 0:没有下一页数据了; 其他：还有数据
                    responsData.put("memberHistoryScoreModelList", info);
                } else {
                    WaiterBizUtil.buildErrorRepsone(response, msg);
                }
            }
        });

        return response;
*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * 查询会员储值记录
     * <p>
     * 支持翻页 lastId是上一次拉倒的最后一个积分的ID,如果第一次拉数据穿'0'
     * 默认一页20条数据
     *
     * @param request
     * @return
     */
    @WaiterName("queryMemberBalance")
    private static WaiterResponse queryMemberBalance(WaiterRequest request) {
       /* final WaiterResponse response = new WaiterResponse();
        JSONObject ob = JSON.parseObject(request.Data);

        String memberCardNo = ob.getString("memberCardNo");//会员卡号
        if (TextUtils.isEmpty(memberCardNo)) {
            WaiterBizUtil.buildErrorRepsone(response, "会员卡号异常，请重试");
            return response;
        }

        String lastId = ob.getString("lastId");//最后一个积分ID
        if (TextUtils.isEmpty(lastId)) {
            lastId = "0";
        }

        MemberProcess.gotMemberBalance(memberCardNo, lastId, new IResponse<List<BalanceOrder>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<BalanceOrder> info) {
                if (result) {
                    final JSONObject responsData = new JSONObject();
                    response.Data = responsData;
                    responsData.put("havenext", code);  //havenext 0:没有下一页数据了; 其他：还有数据
                    responsData.put("balanceOrderList", info);
                } else {
                    WaiterBizUtil.buildErrorRepsone(response, msg);
                }
            }
        });

        return response;

*/
        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * 查询会员优惠券---不支持分页
     *
     * @param request
     * @return
     */
    @WaiterName("gotMemberCoupon")
    private static WaiterResponse gotMemberCoupon(WaiterRequest request) {
        /*final WaiterResponse response = new WaiterResponse();
        JSONObject ob = JSON.parseObject(request.Data);

        String memberCardNo = ob.getString("memberCardNo");//会员卡号
        if (TextUtils.isEmpty(memberCardNo)) {
            WaiterBizUtil.buildErrorRepsone(response, "会员卡号异常，请重试");
            return response;
        }

        MemberProcess.gotMemberCoupon(memberCardNo, new IResponse<List<Coupon>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<Coupon> info) {
                if (result) {
                    final JSONObject responsData = new JSONObject();
                    response.Data = responsData;
                    responsData.put("couponList", info);
                } else {
                    WaiterBizUtil.buildErrorRepsone(response, msg);
                }
            }
        });

        return response;*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=5608474">59.使用会员抵用券</a>
     */
    @WaiterName("appmemberuseticket")
    private static WaiterResponse j(WaiterRequest request) {
        /*final WaiterResponse response = new WaiterResponse();
        JSONObject ob = JSON.parseObject(request.Data);
        final String fssellno = ob.getString("fsSellNo");//订单号
        final String tableno = ob.getString("tableno");//桌台ID
        String memberCardNo = ob.getString("memberCardNo");//会员卡号

        if (TextUtils.isEmpty(tableno)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台ID为空");
            return response;
        }
        //校验订单状态
        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        if (!PermissionCheckDinner.hasPayPermission(userDBModel.fsUserId)) {
            WaiterBizUtil.buildErrorRepsone(response, "账户[" + userDBModel.fsUserName + "]没有收银权限");
            return response;
        }
        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableno);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        //校验订单Token
        if (!WaiterBizUtil.verifyOrderTokenWithCreate(fssellno, request)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }
        MemberCouponModel ticketModel = JSON.parseObject(ob.getString("ticket"), MemberCouponModel.class);
        if (TextUtils.isEmpty(ticketModel.code)) {
            WaiterBizUtil.buildErrorRepsone(response, "券码为空");
            return response;
        }
        //快餐单可以先不经过准备支付的阶段，所以需要校验PaySession是否已经生成
        if (OrderSession.getInstance().getPay(fssellno) == null) {
            OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(fssellno), userDBModel, HostBiz.mealorder);
        }
        final JSONObject responsData = new JSONObject();
        response.Data = responsData;
        responsData.put("orderPayFinish", 1);

        PayOriginModel payModel = OrderUtil.buildPayModelByMemberTicketID(ticketModel.coupon_id);
        payModel.memberCouponModel = ticketModel;
        SocketResponse socketResponse = BillUtil.selectMemberTicket(request.OrderToken, fssellno, userDBModel, HostBiz.mealorder, payModel);
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        } else {
            socketResponse = BillUtil.checkAutoFinishAndStart(request.OrderToken, fssellno, true, null, userDBModel, HostBiz.mealorder);
            if (socketResponse.success()) {
                responsData.put("orderPayFinish", 0);
            }
        }
        return response;*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919725">会员卡支付</a>
     */
    @WaiterName("appcardpaypay")
    private static WaiterResponse e(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919730">积分抵扣/消费赠积分</a>
     */
    @WaiterName("appmembercardpay")
    private static WaiterResponse f(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919748">会员卡预消费查询</a>
     */
    @WaiterName("appmembercardorder")
    private static WaiterResponse g(WaiterRequest waiterRequest) {
/*
        final WaiterResponse response = new WaiterResponse();
        JSONObject submitInfo = JSON.parseObject(waiterRequest.Data);
        String card_no = submitInfo.getString("card_no");
        String amount = submitInfo.getString("amount");
        String pay_type = submitInfo.getString("pay_type");
        String fsSellNo = submitInfo.getString("fsSellNo");

        String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        if (TextUtils.isEmpty(card_no)) {
            WaiterBizUtil.buildErrorRepsone(response, "会员卡号为空");
            return response;
        }
        if (TextUtils.isEmpty(amount)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单金额为空");
            return response;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单[" + fsSellNo + "]不存在");
            return response;
        }
        PaySession session = OrderSession.getInstance().getPay(fsSellNo);

        if (TextUtils.isEmpty(pay_type)) {
            pay_type = "1";
        }
        //遍历寻找已经使用的会员优惠券
        String ticketCode = "";
        if (session != null) {
            PayModel model = PayUtil.getMemberTicket(session);
            if (model != null) {
                ticketCode = model.data.memberCouponModel.code;
            }
        }
        MemberConsumePreSearchRequest request = new MemberConsumePreSearchRequest();
        request.amount = orderCache.optTotalPrice();
        request.card_no = card_no;
        request.coupon_code = ticketCode;

        BigDecimal canDiscount = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);
        request.drop_amount = request.amount.subtract(canDiscount);
        if (request.drop_amount.compareTo(BigDecimal.ZERO) < 0) {
            request.drop_amount = BigDecimal.ZERO;
        }
        request.pay_type = StringUtil.toInt(pay_type, 1);
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(request.coupon_code)) {
            sb.append("3,");
        }
        if (session != null && PayUtil.hasMemberPoint(session.selectPayListFull)) {
            sb.append("4,");
        }
        if (session != null && PayUtil.hasMemberBalance(session.selectPayListFull)) {
            sb.append("5,");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        } else {
            sb.append("-4");
        }
        request.usePreferential = sb.toString();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
                    response.Data = ((MemberConsumePreSearchResponse) responseData.responseBean).data;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                response.Error = responseData.resultMessage;
                if (responseData.responseBean != null) {
                    response.Status = responseData.responseBean.status + "";
                } else {
                    response.Status = responseData.result + "";
                }
                return false;
            }
        }, false);
        return response;*/

        return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9639191">会员卡预消费查询</a>
     */
    @WaiterName("payGetMemberInfo")
    private static WaiterResponse payGetMemberInfo(WaiterRequest waiterRequest) {

        final WaiterResponse response = new WaiterResponse();
        JSONObject submitInfo = JSON.parseObject(waiterRequest.Data);
        String fsSellNo = submitInfo.getString("fsSellNo");//

        String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单[" + fsSellNo + "]不存在");
            return response;
        }
        if (!orderCache.isMember || orderCache.memberInfoS == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单[" + fsSellNo + "]没有绑定会员信息");
            return response;
        }

        PaySession session = OrderSession.getInstance().getPay(fsSellNo);

        MemberApi.sendPreSearchConsume(session.selectPayListFull, orderCache.optTotalPrice(), PayUtil.getCannnotDiscAmtByOrderTotal(orderCache.orderID), orderCache.memberInfoS.card_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
                    response.Data = ((MemberConsumePreSearchResponse) responseData.responseBean).data;
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                response.Error = responseData.resultMessage;
                if (responseData.responseBean != null) {
                    response.Status = responseData.responseBean.status + "";
                } else {
                    response.Status = responseData.result + "";
                }
                return false;
            }
        });
        return response;

        //return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919789">卡支付退款</a>
     */
    @WaiterName("appcardpaypayrefund")
    private static WaiterResponse h(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919792">积分抵扣 退款</a>
     */
    @WaiterName("appmembercardrefund")
    private static WaiterResponse i(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634499">78.支付-使用会员储值</a>
     */
    @WaiterName("payByMemberBalance")
    private static WaiterResponse payByMemberBalance(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String thirdPayOrderID = jsonObject.getString("thirdPayOrderID");
        String pwd = jsonObject.getString("pwd");

        String amount = jsonObject.getString("payamount");
        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        BigDecimal payAmount;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        //快餐单可以先不经过准备支付的阶段，所以需要校验PaySession是否已经生成
        if (OrderSession.getInstance().getPay(orderid) == null) {
            OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(orderid), userDBModel, HostBiz.mealorder);
        }

        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        socketResponse = BillUtil.selectMemberBalance(request.OrderToken, orderid, userDBModel, HostBiz.mealorder, thirdPayOrderID, pwd, payAmount, socketResponse);
        WaiterPayResult payResult = new WaiterPayResult();
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634592">79.支付-使用会员抵用券</a>
     */
    @WaiterName("payByMemberTicket")
    private static WaiterResponse payByMemberTicket(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        MemberCouponModel ticketModel = JSON.parseObject(jsonObject.getString("ticket"), MemberCouponModel.class);
        if (TextUtils.isEmpty(ticketModel.code)) {
            WaiterBizUtil.buildErrorRepsone(response, "券码为空");
            return response;
        }
        PayOriginModel payModel = OrderUtil.buildPayModelByMemberTicketID(ticketModel.coupon_id);
        payModel.memberCouponModel = ticketModel;
        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectMemberTicket(request.OrderToken, orderid, userDBModel, HostBiz.mealorder, payModel);
        WaiterPayResult payResult = new WaiterPayResult();
        payResult.payFinished = 0;
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
        //return WaiterBizUtil.buildNotSupportRepsone();
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634497">80.支付-使用会员积分</a>
     */
    @WaiterName("payByMemberPoint")
    private static WaiterResponse payByMemberPoint(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String amount = jsonObject.getString("payamount");
        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        BigDecimal payAmount;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectMemberPoint(request.OrderToken, orderid, userDBModel, HostBiz.mealorder, payAmount);
        WaiterPayResult payResult = new WaiterPayResult();
        payResult.payFinished = 0;
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
        //return WaiterBizUtil.buildNotSupportRepsone();
    }


    @WaiterName("memberDetail")
    private static WaiterResponse loadMemberDetail(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String cardNo = d.getString("cardNo");
        String fsSellNo = d.getString("fsSellNo");
        if (TextUtils.isEmpty(cardNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "cardNo不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        SocketResponse<NewMemberCardDetailsModel> result = memberService.loadMemberDetailByCardNo(ServerCache.getInstance().fsCompanyGUID, ServerCache.getInstance().shopID, cardNo);
        if (!result.success()) {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
        if (!TextUtils.isEmpty(fsSellNo)) {
            UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
            if (userDBModel == null) {
                return WaiterBizUtil.buildInvalidTokenlRepsone(response);
            }
            if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
                return WaiterBizUtil.buildIneffectivenessOrderToken(response);
            }
            //判断是否可以操作订单
            String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
            if (!TextUtils.isEmpty(error)) {
                return WaiterBizUtil.buildErrorRepsone(response, error);
            }

            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache == null) {
                return WaiterBizUtil.buildErrorRepsone(response, "订单不存在");
            }
            //检查桌台是否被锁定
            error = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
            if (!TextUtils.isEmpty(error)) {
                return WaiterBizUtil.buildErrorRepsone(response, error);
            }
            IOrderService orderService = new OrderServiceImpl();
            SocketResponse<OrderCache> bindResult = orderService.loadBindMember(orderCache, result.data, userDBModel.fsUserId);
            if (!bindResult.success()) {
                return WaiterBizUtil.buildErrorRepsone(response, result.message);
            }
            NotifyToClient.orderChangeForSmart(fsSellNo, bindResult.data.fsmtableid);
            //缓存会员最后一次评论信息
            MemberBizUtil.requestMemberComents(bindResult.data.memberInfoS.card_no);
        }
        response.Data = result.data;
        return response;
    }

    @WaiterName("memberList")
    private static WaiterResponse loadMemberList(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String mobile = d.getString("mobile");
        String verifyCode = d.getString("verifyCode");
        int verifyCodeType = d.getInteger("verifyCodeType");
        if (TextUtils.isEmpty(mobile)) {
            return WaiterBizUtil.buildErrorRepsone(response, "mobile不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        String companyId = ServerCache.getInstance().fsCompanyGUID;
        String shopId = ServerCache.getInstance().shopID;
        SocketResponse<List<NewMemberCardListItemModel>> result = memberService.loadMemberCardListByMobile(companyId, shopId, mobile, verifyCode, verifyCodeType);
        if (result.success()) {
            response.Data = result.data;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
    }

    @WaiterName("memberBalanceTrade")
    private static WaiterResponse loadMemberBalanceTrade(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String cardNoOrMobile = d.getString("cardNoOrMobile");
        int pageNo = d.getInteger("pageNo");
        if (TextUtils.isEmpty(cardNoOrMobile)) {
            return WaiterBizUtil.buildErrorRepsone(response, "卡号不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        String companyId = ServerCache.getInstance().fsCompanyGUID;
        SocketResponse<MemberTradeDetailModel> result = memberService.loadMemberTradeDetail(companyId, cardNoOrMobile, pageNo);
        if (result.success()) {
            response.Data = result.data;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
    }

    @WaiterName("memberScoreTrade")
    private static WaiterResponse loadMemberScoreTrade(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String cardNoOrMobile = d.getString("cardNoOrMobile");
        int pageNo = d.getInteger("pageNo");
        if (TextUtils.isEmpty(cardNoOrMobile)) {
            return WaiterBizUtil.buildErrorRepsone(response, "卡号不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        String companyId = ServerCache.getInstance().fsCompanyGUID;
        SocketResponse<MemberScoreDetailModel> result = memberService.loadMemberScore(companyId, cardNoOrMobile, pageNo);
        if (result.success()) {
            response.Data = result.data;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
    }

    @WaiterName("memberCoupons")
    private static WaiterResponse loadMemberCoupons(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String cardNo = d.getString("cardNo");
        int pageNo = d.getInteger("pageNo");
        if (TextUtils.isEmpty(cardNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "卡号不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        String companyId = ServerCache.getInstance().fsCompanyGUID;
        SocketResponse<MemberCouponsDetailModel> result = memberService.loadMemberCoupons(companyId, cardNo, pageNo);
        if (result.success()) {
            response.Data = result.data;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
    }

    @WaiterName("memberPrivate")
    private static WaiterResponse loadMemberPrivate(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请求参数为空");
        }
        JSONObject d = JSONObject.parseObject(request.Data);
        String cardNo = d.getString("cardNo");
        String csId = d.getString("csId");
        int level = d.getInteger("level");
        if (TextUtils.isEmpty(cardNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "卡号不能为空");
        }
        IMemberService memberService = new MemberServiceImpl();
        String companyId = ServerCache.getInstance().fsCompanyGUID;
        String shopId = ServerCache.getInstance().shopID;
        SocketResponse<MemberPrivateDetailModel> result = memberService.loadMemberPrivate(companyId, csId, level, shopId, cardNo);
        if (result.success()) {
            response.Data = result.data;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, result.message);
        }
    }

    /**
     * 解绑会员
     */
    @WaiterName("unBindMember")
    private static WaiterResponse loadUnBindMember(WaiterRequest request) {
        final WaiterResponse response = new WaiterResponse();
        JSONObject submitInfo = JSON.parseObject(request.Data);
        final String fsSellNo = submitInfo.getString("fsSellNo");
        if (TextUtils.isEmpty(fsSellNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "订单号不存在");
        }
        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            return WaiterBizUtil.buildInvalidTokenlRepsone(response);
        }
        if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
            return WaiterBizUtil.buildIneffectivenessOrderToken(response);
        }
        //判断是否可以操作订单
        String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }
        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            return WaiterBizUtil.buildErrorRepsone(response, erroInfo);
        }
        WaiterBizUtil.optToken(request.OrderToken, fsSellNo);
        IOrderService orderService = new OrderServiceImpl();
        SocketResponse<OrderCache> unBindResult = orderService.loadUnBindMember(orderCache, userDBModel.fsUserId);
        if (unBindResult.success()) {
            NotifyToClient.orderChangeForSmart(fsSellNo, orderCache.fsmtableid);
            JSONObject result = new JSONObject();
            result.put("totalPrice", orderCache.optTotalPrice());
            response.Data = result;
            return response;
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, unBindResult.message);
        }
    }
}
