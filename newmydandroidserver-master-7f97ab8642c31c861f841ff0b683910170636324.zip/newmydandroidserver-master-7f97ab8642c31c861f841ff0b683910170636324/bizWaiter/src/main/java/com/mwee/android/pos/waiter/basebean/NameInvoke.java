package com.mwee.android.pos.waiter.basebean;

/**
 * Created by virgil on 2017/2/8.
 */

public class NameInvoke {
}
