package com.mwee.android.pos.waiter.server;

import android.net.TrafficStats;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.NameConstant;
import com.mwee.android.pos.businesscenter.socket.SocketServer;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.framework.SerializeUtil;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SafeUtil;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBiz;
import com.mwee.android.tools.LogUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * 美小二服务端
 *
 * @ClassName: WaiterServer
 * @Description:
 * @author: SugarT
 * @date: 16/8/16 上午10:09
 */
public class WaiterServer implements IDriver {

    private static final String TAG = "WaiterServer";
    private static final int headerLength = 4;
    private static WaiterServer _instance = new WaiterServer();
    private static List<ServerThread> mServerThreads = new ArrayList<>();

    private static String mShopId;

    private WaiterServer() {
    }

    public static WaiterServer getInstance() {
        return _instance;
    }

    private static String getShopID() {
        if (TextUtils.isEmpty(mShopId)) {
            mShopId = HostUtil.getShopID();
        }
        return mShopId;
    }

    /**
     * 是否需要加密
     *
     * @param name    String
     * @param service String
     * @return boolean | true：需要加密；false：不需要加密
     */
    private static boolean needEncrypt(String name, String service) {
        return !(TextUtils.equals(service, "login.t") && TextUtils.equals(name, "CheckBizCenterConnected"));
    }

    @Override
    public String getModuleName() {
        return "waiter";
    }

    public void init() {
        DriverBus.registerDriver(this);
        checkAlive();
    }

    public void reInit() {
        if (mServerThreads != null && !mServerThreads.isEmpty()) {
            try {
                for (int i = 0; i < mServerThreads.size(); i++) {
                    ServerThread temp = mServerThreads.get(i);
                    temp.disconnect();
                    temp.finish();
                    temp.interrupt();
                    mServerThreads.remove(i);
                    i--;
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                checkAlive();
            }
        }
    }

    /**
     * 服务器停止监听
     */
    @DrivenMethod(uri = "waiter/finishServer")
    public void finishServer() {
        try {
            if(!ListUtil.isEmpty(mServerThreads)) {
                for (int i = 0; i < mServerThreads.size(); i++) {
                    ServerThread temp = mServerThreads.get(i);
                    temp.disconnect();
                    temp.finish();
                    temp.interrupt();
                    mServerThreads.remove(i);
                    i--;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DrivenMethod(uri = "waiter/checkAlive")
    public void checkAlive() {
        if (!BindProcessor.isActived()) {
            RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, "门店未激活，不启用美小二服务");
            return;
        }
        if (!DBMetaUtil.needStartUpWaiterServer()) {
            RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, "美小二服务开关关闭，不启用美小二服务");
            return;
        }
        if (ListUtil.listIsEmpty(mServerThreads)) {
            for (int i = 0; i < WaiterServerConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = new ServerThread(WaiterServerConfig.PORT_LIST[i]);
                serverThread.start();
                mServerThreads.add(serverThread);
            }
        } else {
            for (int i = 0; i < WaiterServerConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = mServerThreads.get(i);
                boolean alive = true;
                if (serverThread.finish || !serverThread.isAlive() || serverThread.isInterrupted()) {
                    alive = false;
                    try {
                        serverThread.interrupt();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                LogUtil.log("WaiterServer check Alive " + WaiterServerConfig.PORT_LIST[i] + " " + (alive ? "alive" : "dead"));

                if (!alive) {
                    serverThread = new ServerThread(WaiterServerConfig.PORT_LIST[i]);
                    serverThread.start();
                    mServerThreads.set(i, serverThread);
                }
            }
        }
    }

    private static class ServerThread extends Thread {


        public volatile boolean finish = false;
        int retryTimes = 0;
        private int socketPort;
        private ServerSocket mServer;
        private Socket mSocket;

        private ServerThread(int port) {
            socketPort = port;
            setDaemon(false);
            retryTimes = 0;
        }

        @Override
        public void run() {
            connect();
        }

        public void finish() {
            finish = true;
        }

        /**
         * 连接
         */
        private void connect() {
            try {
                if (BindProcessor.isActived() && !BindProcessor.isCurrentHostMain()) {
                    finish();
                    return;
                }
                if (BaseConfig.isDEV()) {
                    TrafficStats.setThreadStatsTag(0x9876);
                }
                mServer = new ServerSocket();
                mServer.setReuseAddress(true);
                mServer.bind(new InetSocketAddress(socketPort));
                while (true) {
                    if (finish) {
                        break;
                    }
                    LogUtil.log(TAG, "start listen, port=" + socketPort);

                    mSocket = mServer.accept();
                    mSocket.setKeepAlive(false);
                    ClientHandler client = new ClientHandler(mSocket);
                    SocketServer.pushTask(client);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                disconnect();
                if (!finish) {
                    if (retryTimes++ < 10) {
                        RunTimeLog.addLog(RunTimeLog.SOCKET, socketPort + " disconnected, reconnect now.retry times: " + retryTimes);
                        try {
                            Thread.sleep(10 * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        connect();
                    } else {
                        if (retryTimes++ > (SocketConfig.SERVER_MAX_RETRY_TIMES +3)) {
                            finish();
                        }else {
                            try {
                                Thread.sleep(60 * 1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            connect();
                        }
                    }
                }
            }
        }

        /**
         * 断开连接
         */
        private void disconnect() {
            try {
                if (mServer != null) {
                    mServer.close();
                    mServer = null;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Client处理线程
     */
    private static class ClientHandler implements Runnable {
        private Socket socket;

        //        private BufferedReader mReader;
//        private PrintWriter mWriter;
        private OutputStream out;
        private InputStream in;

        ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            out = socket.getOutputStream();
            in = socket.getInputStream();
//            mWriter = new PrintWriter(socket.getOutputStream());
//            mReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        }

        @Override
        public void run() {
            LogUtil.log(TAG + " " + String.format("开始监听客户端: %s", socket.getRemoteSocketAddress()));
            WaiterResponse res = new WaiterResponse();
            try {
                String strRequest;

                byte[] header = new byte[4];
                int readCount = in.read(header, 0, 4);
                int totalLength = SerializeUtil.bytesToInteger(header);
                byte[] content = new byte[totalLength];
                int totalReadCount = 0;
                while (totalLength > 0) {
                    readCount = in.read(content, totalReadCount, totalLength);
                    totalReadCount += readCount;
                    totalLength = totalLength - readCount;
                }
                strRequest = new String(content);
                if (!BaseConfig.isProduct()) {
                    LogUtil.logNET(TAG + " receive request" + strRequest);
                }
                if (TextUtils.isEmpty(strRequest)) {
                    res.Status = WaiterResult.FAIL;
                    sendResponse(res);
                    LogUtil.log(TAG, "request refused, close socket connection");
                    return;
                }
                String originRequest=strRequest;
                if (!strRequest.startsWith("{")) {
                    strRequest = SafeUtil.decrypt(NameConstant.PWD_SMART_WAITER, NameConstant.PWD_IV, strRequest);
                    if (!BaseConfig.isProduct()) {
                        LogUtil.logNET(TAG + " receive request" + strRequest);
                    }
                }
                if (TextUtils.isEmpty(strRequest)) {
                    res.Status = WaiterResult.FAIL;
                    sendResponse(res);
                    LogUtil.log(TAG, "request refused, close socket connection");
                    return;
                }
                WaiterRequest request = JSON.parseObject(strRequest, WaiterRequest.class);
                String filterError = doFilter(request);
                if (!TextUtils.isEmpty(filterError)) {
                    res.Status = WaiterResult.FAIL;
                    res.Error = filterError;
                    sendResponse(res);
                    LogUtil.log(TAG, "request refused, close socket connection");
                    return;
                }
                //如果报文没有加密，但是request对应的uri是需要加密的，则返回失败
                if (originRequest.startsWith("{") && needEncrypt(request.Name, request.Service)) {
                    res.Status = WaiterResult.FAIL;
                    res.Error = "美小二版本太低，请升级到4.3.1及以上的版本";
                    sendResponse(res);
                    LogUtil.log(TAG, "request refused, close socket connection");
                }
                res = WaiterBiz.invokBiz(request);

                if (res == null) {
                    res = new WaiterResponse();
                    res.Status = WaiterResult.FAIL;
                }

                sendResponse(res, needEncrypt(request.Name, request.Service));
            } catch (JSONException e) {
                LogUtil.logError(e);
                res = new WaiterResponse();
                res.Status = WaiterResult.FAIL;
                res.Error = "反序列化失败";
                sendResponse(res);
            } catch (Throwable e) {
                LogUtil.logError(e);
                res = new WaiterResponse();
                res.Status = WaiterResult.FAIL;
                sendResponse(res);

            }  finally {
                disconnect();
            }
        }

        private void sendResponse(WaiterResponse res) {
            sendResponse(res, false);
        }

        /**
         * 发送response
         *
         * @param res     WaiterResponse | response体
         * @param encrypt boolean | 是否需要加密：true：需要加密；false：不需要加密
         */
        private void sendResponse(WaiterResponse res, boolean encrypt) {
            if (res != null) {
                res.buildErrorMsg();
            }
            try {
                String info = JSON.toJSONString(res, SerializerFeature.DisableCircularReferenceDetect);
                if (!BaseConfig.isProduct()) {
                    LogUtil.logNET(TAG + " sendResponse " + info);
                }
                if (encrypt) {
                    info = SafeUtil.encrypt(NameConstant.PWD_SMART_WAITER, NameConstant.PWD_IV, info);
                }
                byte[] infoByte = info.getBytes();
                byte[] header = SerializeUtil.integerToBytes(infoByte.length, headerLength);

                out.write(header);
                out.write(infoByte);
                out.flush();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private String doFilter(WaiterRequest request) {
            if (request == null) {
                return "解析异常，请重试。";
            }

            String localShopID = getShopID();
            if (!TextUtils.isEmpty(localShopID) && !TextUtils.equals(localShopID, request.ShopGUID)) {
                RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, " shopId from request: " + request.ShopGUID + ", from center: " + localShopID);
                return "门店ID不匹配";
            }
            return "";
        }

        /**
         * 断开连接
         */
        private void disconnect() {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                out = null;
            }
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                in = null;
            }
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                socket = null;
            }
        }
    }
}
