package com.mwee.android.pos.waiter.business.member;

/**
 * Created by virgil on 2017/1/16.
 */

public class WaiterInvokMember {
    public static Class getNameClass() {
        return NameMemebr.class;
    }

}
