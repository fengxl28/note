package com.mwee.android.pos.waiter.business.bill;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.permission.PermissionCheckDinner;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.businesscenter.module.koubei.service.impl.KBOrderServiceImpl;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.order.DiscountBizUtil;
import com.mwee.android.pos.businesscenter.business.order.DishesBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.PermissionBizUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.driver.BonusBizUtil;
import com.mwee.android.pos.businesscenter.driver.DishesDriver;
import com.mwee.android.pos.businesscenter.driver.DishesUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.TableQRProcess;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintTableUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.permission.MenuSimpleInfo;
import com.mwee.android.pos.connect.business.bean.BatchTurnDishesRequest;
import com.mwee.android.pos.connect.business.bean.BatchTurnDishesResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.discount.NameDiscountModel;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.PayVoidResponse;
import com.mwee.android.pos.connect.business.permission.CheckPermissionResponse;
import com.mwee.android.pos.connect.business.table.ChangeTableResponse;
import com.mwee.android.pos.connect.business.table.TableProcessor;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.TurnMenuItemModel;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.order.bonus.SellOrderItemBonusSimpleModel;
import com.mwee.android.pos.db.business.pay.NetPayResult;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.waiter.basebean.NameInvoke;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBizUtil;
import com.mwee.android.pos.waiter.business.orderprocessor.WaiterOrderTransfer;
import com.mwee.android.pos.waiter.component.WaiterName;
import com.mwee.android.pos.waiter.server.WaiterResult;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 订单相关的方法
 * Created by virgil on 2017/1/16.
 */

@SuppressWarnings("unused")
class NameBill extends NameInvoke {
    //========================================================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918591">点菜/结账锁桌</a>
     */
    @WaiterName("OpenJob")
    private static WaiterResponse a(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String tableno = jsonObject.getString("tableno");
        String hostid = jsonObject.getString("hostid");
        String userid = jsonObject.getString("userid");
        String username = jsonObject.getString("username");

        String checkKeyError = checkTableUserHost(tableno, hostid, userid);
        if (!TextUtils.isEmpty(checkKeyError)) {
            WaiterBizUtil.buildErrorRepsone(response, checkKeyError);
            return response;
        }
        if (TextUtils.isEmpty(username)) {
            WaiterBizUtil.buildErrorRepsone(response, "username为空");
            return response;
        }

        String erroInfo = TableBusinessUtil.lockTable(tableno, hostid, userid, username);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        response.Data = null;
        return response;
    }

    /**
     * 检测桌台、用户、站点的合法性
     *
     * @param tableno String | 桌台ID
     * @param hostid  String | 站点ID
     * @param userid  String | 用户ID
     * @return String | 检查的结果，如果不合法，则此字段返回不合法原因，如果合法，则返回空字符串
     */
    private static String checkTableUserHost(String tableno, String hostid, String userid) {
        if (TextUtils.isEmpty(tableno)) {
            return "桌台号为空";
        }
        if (TextUtils.isEmpty(hostid)) {
            return "站点ID为空";
        }
        if (TextUtils.isEmpty(userid)) {
            return "userid为空";
        }
        if (!TableBusinessUtil.isExist(tableno)) {
            return "无此桌台";
        }
        return "";
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918614">餐桌解锁</a>
     */
    @WaiterName("UOpenJob")
    private static WaiterResponse b(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String tableno = jsonObject.getString("tableno");
        String hostid = jsonObject.getString("hostid");
        String userid = jsonObject.getString("userid");
        String username = jsonObject.getString("username");
        String checkKeyError = checkTableUserHost(tableno, hostid, userid);
        if (!TextUtils.isEmpty(checkKeyError)) {
            WaiterBizUtil.buildErrorRepsone(response, checkKeyError);
            return response;
        }
        if (TextUtils.isEmpty(username)) {
            WaiterBizUtil.buildErrorRepsone(response, "username为空");
            return response;
        }

        TableBusinessUtil.unlockTargetTable(tableno);
        response.Data = null;
        NotifyToClient.refreshTableLock();
        return null;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918623">开台</a>   f59cb6f7-0847-4510-8d82-67f6b83396fb
     */
    @WaiterName("OpenTable")
    private static WaiterResponse c(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        JSONObject tableinfo = jsonObject.getJSONObject("sell");
        int ficustsum = StringUtil.toInt(tableinfo.getString("ficustsum"), 1);
        String fsmtablename = tableinfo.getString("fsmtablename");
        String fsmtableid = tableinfo.getString("fsmtableid");
        String fsmareaid = tableinfo.getString("fsmareaid");
        String fsmsectionid = tableinfo.getString("fsmsectionid");
        if (TextUtils.isEmpty(fsmsectionid)) {
            fsmsectionid = OrderUtil.getSectionId();
        }
        if (ficustsum <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "顾客人数不正确，请重新选择");
            return response;
        }
        //检查桌台
        MtableDBModel mtableDBModel = TableDBUtil.getMTableById(fsmtableid);
        if (mtableDBModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此桌台");
            return response;
        }

        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String error = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, fsmtableid);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        String orderId = "";
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableid, "", " 开台 ");
        try {
            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(fsmtableid);

            if (TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid)) {

                if (TextUtils.isEmpty(tableBizModel.fssellno)) {
                    OrderCache orderCache = OrderDriver.generateNewOrder();
                    orderId = orderCache.orderID;
                    orderCache.waiterID = userDBModel.fsUserId;
                    orderCache.waiterName = userDBModel.fsUserName;
                    orderCache.currentHostID = HostBiz.mealorder;
                    orderCache.currentSectionID = fsmsectionid;
                    orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
                    orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
                    orderCache.fsmtableid = mtableDBModel.fsmtableid;
                    orderCache.fsmtablename = mtableDBModel.fsmtablename;
                    orderCache.fsmareaid = mtableDBModel.fsmareaid;
                    orderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from " +
                            "tbmarea where fsMAreaId = '" + mtableDBModel.fsmareaid + "'");
                    orderCache.personNum = ficustsum;
                    orderCache.shopID = mtableDBModel.fsshopguid;
                    orderCache.mealNumber = orderId.substring(8, 12);
                    orderCache.orderStatus = OrderStatus.NORMAL;
                    //目前，美小二开台，不需要将默认菜添加进去2017-02-20
//                orderCache.originMenuList.addAll(OrderBizUtil.getOpenParamOrderMenu(orderCache.fsmareaid,
// orderCache.personNum, orderCache.waiterID, orderCache.waiterName));
                    if (orderCache.originMenuList.size() > 0) {
                        for (MenuItem temp : orderCache.originMenuList) {
                            temp.menuBiz.orderSeqID = orderCache.currentSeq;
                            if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                                for (MenuItem modifier : temp.menuBiz.selectedModifier) {
                                    modifier.menuBiz.orderSeqID = orderCache.currentSeq;
                                }
                            }
                        }
                        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel,
                                HostBiz.mealorder);
                        orderCache.currentSeq++;
                    }
                    TableProcessor.openTableSuccess(orderCache);
                    OrderSession.getInstance().writeOrder(orderId, orderCache, true, "OpenTable");
//                    OrderProcessor.saveOrder(orderCache, null);
                    String hostId = HostUtil.getCurrentHost();
                    PrintTableUtil.openTableReport(orderCache, hostId);
                    if (orderCache.originMenuList.size() > 0) {
                        PrintOrderUtil.printMakeOrder(orderCache, hostId, orderCache.currentSeq - 1);
                        PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.mealorder);
                        PrintOrderUtil.printPassTo(orderCache, hostId);
                    }
                } else {
                    orderId = tableBizModel.fssellno;
                }
                SocketResponse socketResponse = new SocketResponse();
                TableBusinessUtil.doOpenTable(new SocketResponse(), HostBiz.mealorder, fsmtableid, orderId,
                        userDBModel, false);
                NotifyToClient.refreshTableOrOrders();
            } else {
                orderId = tableBizModel.fssellno;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableid, "", " 开台 ");
        }
        String iswx = jsonObject.getString("iswx");
//        SocketResponse socketResponse = new SocketResponse();
        JSONObject result = new JSONObject();
        result.put("sellno", orderId);
//        result.put("orderToken", "-1");

//        String checkKeyError = checkTableUserHost(tableno, hostid, userid);
//        if (!TextUtils.isEmpty(checkKeyError)) {
//            WaiterBizUtil.buildErrorRepsone(response, checkKeyError);
//            return response;
//        }
//        if (TextUtils.isEmpty(username)) {
//            WaiterBizUtil.buildErrorRepsone(response, "username为空");
//            return response;
//        }
//
//        TableDriver.unlockTargetTable(tableno);

        response.Data = result;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918640">下单</a>
     */
    @WaiterName("Foodsubmit")
    private static WaiterResponse d(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");

        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        String WxFoodsubmit = submitInfo.getString("WxFoodsubmit");//是否微信下单=0
        String isSaleOut = submitInfo.getString("isSaleOut");//授权沽清确认
        String AddOrder = submitInfo.getString("AddOrder");//是否下单不打印制作单
        String tableID = submitInfo.getString("fsMTableId");
        String source = submitInfo.getString("source");  //订单来源：0：普通点菜 -1：秒点单


        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableID, fssellno, "下单");
        try {

            //判断当前桌台对应的订单号是否是待操作的订单号
            if (!TextUtils.isEmpty(tableID)) {
                String tableOrderID = TableBusinessUtil.getOrderIDByTableID(tableID);
                if (!TextUtils.equals(tableOrderID, fssellno)) {
                    WaiterBizUtil.buildExpiredOrderRepsone(response, "此订单已换到另一个桌台，请刷新桌台");
                    return response;
                }
            }
            //判断是否可以操作订单
            String error = WaiterBizUtil.canOpertaOrder(fssellno);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }

            if (orderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0) {
                WaiterBizUtil.buildErrorRepsone(response, "您当前就餐的桌台设置了固定用餐标准，需服务员在客户端确认");
                return response;
            }

            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }
            //检查桌台是否被锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }
            //已点单的菜品数量
            int originMenuSize = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from " +
                    "tbsellorderitem where fssellno='" + fssellno + "'"), 0);
            List<SellOrderItemDBModel> sellItemList = JSON.parseArray(submitInfo.getString("tbsellorderitems"),
                    SellOrderItemDBModel.class);
            List<MenuItem> list = WaiterOrderTransfer.tansSellItemToMenuItem(orderCache.currentSeq, false, source,
                    sellItemList);
            if (ListUtil.isEmpty(list)) {
                response.Status = WaiterResult.FAIL;
                response.Error = "没有可下单菜品，请校验菜品是否存在";
                return response;
            }
            //去重的逻辑
            List<MenuItem> currentOrderMenu = new ArrayList<>();
            currentOrderMenu.addAll(orderCache.originMenuList);
            for (int i = 0; i < currentOrderMenu.size(); i++) {
                MenuItem tempMenu = currentOrderMenu.get(i);
                for (int j = 0; j < list.size(); j++) {
                    MenuItem temp = list.get(j);
                    if (TextUtils.equals(tempMenu.menuBiz.uniq, temp.menuBiz.uniq)) {
                        currentOrderMenu.remove(i);
                        i--;
                        list.remove(j);
                        j--;
                    }
                }
            }

            if (list.size() <= 0) {
                response.Status = WaiterResult.SUCCESS;
                response.Error = "重复提交，已处理";
                return response;
            }

            //判断菜品是否生效
            MenuEffectiveInfo menuEffectiveInfo = null;
            for (MenuItem menu : list) {
                menuEffectiveInfo = MenuDBUtil.queryMenuEffectiveInfoById(menu.itemID);
                if (menuEffectiveInfo != null && !MenuDBUtil.dataIsEffectiveDate(menuEffectiveInfo.startTime,
                        menuEffectiveInfo.endTime, menuEffectiveInfo.fiIsEffectiveDate)) {
                    response.Status = WaiterResult.FAIL;
                    response.Error = "菜品【" + menu.name + "】有效期为 " + menuEffectiveInfo.fsStarDate + "- " +
                            menuEffectiveInfo.fsEndDate;
                    return response;
                }
            }

            SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(list);
            if (!result.success) {
                WaiterBizUtil.buildSellOutRepsone(response, result.errorMsg);
                return response;
            }

            // 处理下单前提成
            List<SellOrderItemBonusDBModel> bonusList = JSON.parseArray(submitInfo.getString("tbSellOrderItemBonus"),
                    SellOrderItemBonusDBModel.class);
            BonusBizUtil.mergeBonusToMenuItem(list, bonusList);

            //如果是取用秒点单--清空秒点信息
            if (TextUtils.equals("-1", source)) {
                TableBusinessUtil.cleanRapidOrder(orderCache.fsmtableid);
                MessageDBUtil.updateMessageOrderByTableId(orderCache.fsmtableid, MessageConstance
                        .MessageOrderBuinessStatus.RAPID.GET, userDBModel);
                NotifyToClient.refreshTableOrOrders();
            }

            /**
             * 消息中心新增消息
             * MessageOrderUtil.addSmartOrderMessage(list, userDBModel.fsUserName, MessageConstance.CATEGORY_ORDER,
             * orderCache.fsmareaid, orderCache.fsmtablename, orderCache.fsmtableid, orderCache.businessDate);
             */
            MessageBiz.addSmartOrderMsg(list, userDBModel.fsUserName, MessageConstance.CATEGORY_ORDER, orderCache
                    .fsmareaid, orderCache.fsmtablename, orderCache.fsmtableid, orderCache.businessDate);
            NotifyToClient.addOrderMessage(MessageConstance.TYPE_SMART, orderCache.fsmareaid);

            WaiterBizUtil.optToken(request.OrderToken, fssellno);
            if (!ListUtil.isEmpty(list)) {
//                if (DBMetaUtil.autoUseMemberPrice()) {
//                    if (orderCache.isMember && orderCache.memberInfoS != null) {
//                        //开启自动使用会员价 后加菜的菜品自动使用会员价
//                        OrderCache.updateAllMenuToMemberPrice(list, orderCache.isMember, orderCache.memberInfoS.level);
//                    }
//                }
                if (orderCache.isMember && orderCache.memberInfoS != null) {
                    MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache.shopID, list, orderCache.isMember, orderCache.memberInfoS.level, userDBModel.fsUserId, orderCache.memberInfoS.cs_id, orderCache.memberInfoS.plusId);
                }
                orderCache.originMenuList.addAll(list);
            }

            String fsDiscountCutId = submitInfo.getString("fsDiscountCutId");
            List<NameDiscountModel> discountInfoList = JSON.parseArray(submitInfo.getString("discountInfo"), NameDiscountModel.class);
            if (!ListUtil.isEmpty(discountInfoList)) {
                NameUtil.doDiscount(response, orderCache, list, discountInfoList, fsDiscountCutId);
            }

            // 开台参数小二单独处理，这里去掉
//            if (originMenuSize <= 0) {
//                List<MenuItem> defaultList = OrderBizUtil.getOpenParamOrderMenu(orderCache.fsmareaid, orderCache
//                        .personNum, orderCache.waiterID, orderCache.waiterName);
//                if (!ListUtil.isEmpty(defaultList)) {
//                    for (MenuItem temp : defaultList) {
//                        temp.updateOrderSeq(orderCache.currentSeq);
//                    }
//                    orderCache.originMenuList.addAll(defaultList);
//                }
//            }

            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.mealorder);
            orderCache.currentSeq++;
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().writeOrder(fssellno, true, "Foodsubmit");
//            OrderProcessor.saveOrder(orderCache, null);
            String printHostId = HostUtil.getCurrentHost();
            final List<Integer> printTaskIds = new ArrayList<>();
            PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.mealorder);

            if (DBOrderConfig.useKdsService()) {
                KdsManager.getInstance().order(orderCache, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", HostBiz.mealorder, userDBModel);
            } else {
                PrintOrderUtil.printMakeOrder(orderCache, printHostId, orderCache.currentSeq - 1);
                PrintOrderUtil.printPassTo(orderCache, printHostId);
            }
            NotifyToClient.orderChangeForSmart(fssellno, orderCache.fsmtableid);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableID, fssellno, "下单");
        }
        return response;
    }


    /**
     * <a href="">编辑配料</a>
     */
    @WaiterName("changeIngredient")
    private static WaiterResponse changeIngredient(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");
        String uniq = submitInfo.getString("uniq");//菜品唯一标识符号
        String tableID = submitInfo.getString("fsMTableId");
        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }


        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableID, fssellno, "编辑配料");
        try {
            //判断当前桌台对应的订单号是否是待操作的订单号
            if (!TextUtils.isEmpty(tableID)) {
                String tableOrderID = TableBusinessUtil.getOrderIDByTableID(tableID);
                if (!TextUtils.equals(tableOrderID, fssellno)) {
                    WaiterBizUtil.buildExpiredOrderRepsone(response, "此订单已换到另一个桌台，请刷新桌台");
                    return response;
                }
            }
            //判断是否可以操作订单
            String error = WaiterBizUtil.canOpertaOrder(fssellno);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }
            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }
            //检查桌台是否被锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fssellno);

            MenuItem old = null;

            if (ListUtil.isEmpty(orderCache.originMenuList)) {
                WaiterBizUtil.buildExpiredOrderRepsone(response, "未找到该菜品，可能已被转桌或退菜");
                return response;
            }

            for (MenuItem item : orderCache.originMenuList) {
                if (item == null || item.hasAllVoid()) {
                    continue;
                }
                if (TextUtils.equals(uniq, item.menuBiz.uniq)) {
                    old = item;
                    break;
                }
            }

            if (old == null) {
                WaiterBizUtil.buildExpiredOrderRepsone(response, "未找到该菜品，可能已被转桌或退菜");
                return response;
            }

            List<MenuItem> addedMenuItem = new ArrayList<>();
            //新增配料
            List<SellOrderItemDBModel> sellItemList = JSON.parseArray(submitInfo.getString("addIngredients"),
                    SellOrderItemDBModel.class);
            if (!ListUtil.isEmpty(sellItemList)) {
                for (SellOrderItemDBModel temp : sellItemList) {
                    MenuItem menuItem = WaiterOrderTransfer.sellItemToMenuItem(temp, false, orderCache.currentSeq);
                    if (menuItem != null) {
                        addedMenuItem.add(menuItem);
                    }
                }
                //判断菜品是否生效
                for (MenuItem menu : addedMenuItem) {
                    MenuEffectiveInfo menuEffectiveInfo = MenuDBUtil.queryMenuEffectiveInfoById(menu.itemID);
                    if (!MenuDBUtil.dataIsEffectiveDate(menuEffectiveInfo.startTime, menuEffectiveInfo.endTime,
                            menuEffectiveInfo.fiIsEffectiveDate)) {
                        response.Status = WaiterResult.FAIL;
                        response.Error = "菜品【" + menu.name + "】有效期为 " + menuEffectiveInfo.fsStarDate + "- " +
                                menuEffectiveInfo.fsEndDate;
                        return response;
                    }
                }

                //判断估清
                SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(addedMenuItem);
                if (!result.success) {
                    WaiterBizUtil.buildSellOutRepsone(response, result.errorMsg);
                    return response;
                }
            }

            //删除的配料
            JSONArray list = submitInfo.getJSONArray("deletedMenuItem");

            List<MenuItem> deletedMenuItem = new ArrayList<>();

            for (MenuItem menuItem : old.menuBiz.selectedModifier) {
                if (menuItem == null || menuItem.hasAllVoid()) {
                    continue;
                }
                for (int i = 0; i < list.size(); i++) {
                    JSONObject item = (JSONObject) list.get(i);
                    String seq = item.getString("fsseq");

                    if (TextUtils.equals(menuItem.menuBiz.uniq, seq)) {
                        BigDecimal deleteQty = item.getBigDecimal("fdDeleteQty");
                        MenuItem deleteItem = menuItem.clone();
                        if (deleteItem.menuBiz.buyNum.subtract(deleteItem.menuBiz.voidNum).compareTo(deleteQty) < 0) {
                            deleteItem.menuBiz.buyNum = deleteItem.menuBiz.buyNum.subtract(deleteItem.menuBiz.voidNum);
                        } else {
                            deleteItem.menuBiz.buyNum = deleteQty;
                        }
                        deletedMenuItem.add(deleteItem);
                        break;
                    }
                }
            }

            if (ListUtil.isEmpty(addedMenuItem) && ListUtil.isEmpty(deletedMenuItem)) {
                WaiterBizUtil.buildExpiredOrderRepsone(response, "没有配料变动");
                return response;
            }

            DishesUtil.changeMenuItemIngredient(userDBModel, orderCache.isMember, old, addedMenuItem, deletedMenuItem);

            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.mealorder);
            orderCache.currentSeq++;
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().writeOrder(fssellno, true, "changeIngredient");
//            OrderProcessor.saveOrder(orderCache, null);

            // 打印退、加配料小票
            String printHostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            if (orderCache.orderStatus != OrderStatus.ANTI_PAIED) {
                if (deletedMenuItem.size() > 0) {
                    PrintOrderUtil.printVoidIngredient(orderCache, old, deletedMenuItem, userDBModel.fsUserName, printHostId);
                }
                if (addedMenuItem.size() > 0) {
                    PrintOrderUtil.printAddIngredient(orderCache, old, addedMenuItem, userDBModel.fsUserName, printHostId);
                }
            }
            NotifyToClient.orderChangeForSmart(fssellno, orderCache.fsmtableid);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableID, fssellno, "编辑配料");
        }
        return response;
    }


    //====================================打印====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918705">重新打印制作单</a>
     */
    @WaiterName("heavyprintitem")
    private static WaiterResponse e(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fsseq = submitInfo.getString("fsseq");//订单号
        if (TextUtils.isEmpty(fsseq)) {
            WaiterBizUtil.buildErrorRepsone(response, "菜品序号为空");
            return response;
        }
        String fssellno = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tbsellorderitem where " +
                "fsseq='" + fsseq + "'");
        OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }
        if (orderCache.isNotSupportEditor()) {
            WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
            return response;
        }
        String hostId = HostUtil.getCurrentHost();
        PrintOrderUtil.printMakeOrder(orderCache, hostId, null, fsseq);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918705">重打印点菜单</a>
     */
    @WaiterName("heavyorder")
    private static WaiterResponse f(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//订单号
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "账单号为空");
            return response;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }
        if (orderCache.isNotSupportEditor()) {
            WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
            return response;
        }
        String printHostId = HostUtil.getCurrentHost();
        PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.mealorder);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=6334042">拼桌</a>
     */
    @WaiterName("addsharetable")
    private static WaiterResponse addsharetable(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fsmtableid = submitInfo.getString("fsmtableid");//桌台号码

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableid, "", "拼桌");
        try {
            //判断当前桌台对应的订单号是否是待操作的订单号
            if (!TextUtils.isEmpty(fsmtableid)) {
                MtableDBModel tableModel = TableBusinessUtil.shareTable(fsmtableid, userDBModel);
                if (tableModel != null) {
                    JSONObject result = new JSONObject();
                    result.put("newTableId", tableModel.fsmtableid);
                    result.put("newTableName", tableModel.fsmtablename);
                    response.Data = result;
                    response.Error = WaiterResult.SUCCESS;
                } else {
                    WaiterBizUtil.buildErrorRepsone(response, "没有查到该桌台");
                    return response;
                }
            } else {
                WaiterBizUtil.buildErrorRepsone(response, "无次桌台");
                return response;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableid, "", "拼桌");
        }
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918709">打印结账单</a>
     */
    @WaiterName("PrintBill")
    private static WaiterResponse g(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//订单号
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "账单号为空");
            return response;
        }
        PrintBillUtil.printDinnerBill(fssellno, "", HostUtil.getCurrentHost(), false, userDBModel);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918713">打印预结单</a>
     */
    @WaiterName("PrintPreBill")
    private static WaiterResponse h(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//账单号
        OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        /**
         * 更新打印预结单
         */
        TableBusinessUtil.modifyPrePrint(new SocketResponse(), orderCache.fsmtableid, fssellno, TableStatusBean
                .PRINT_COMPLETE);
        PrintBillUtil.printRapidDinnerPreBill(orderCache, userDBModel);
        NotifyToClient.refreshTableOrOrders();
        return response;
    }

    //====================================菜品要求====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917878">结账</a>
     */
    @WaiterName("SellCheckout")
    private static WaiterResponse i(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        // FIXME: 2017/2/13 结账
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918782">退款</a>
     */
    @WaiterName("Refund")
    private static WaiterResponse j(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        // FIXME: 2017/2/13 退款
        return response;
    }


    //====================================菜品====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918800">设置沽清</a>
     * <p>
     * SellOutServerProcessor.resetAllSellOut();
     */
    @WaiterName("setSoutout")
    private static WaiterResponse l(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);

        List<String> fiOrderUintCdList = JSONArray.parseArray(submitInfo.getJSONArray("fiOrderUintCds").toString(),
                String.class);

        if (ListUtil.isEmpty(fiOrderUintCdList)) {
            WaiterBizUtil.buildErrorRepsone(response, "请选择菜品");
            return response;
        }
        // 库存数量
        BigDecimal fdInvQty = submitInfo.getBigDecimal("fdInvQty");

        //数据状态;0未同步到店DB / 1正常 / 2临时沽清 / 3数量沽清 /13删除
        int fiStatus = submitInfo.getInteger("fiStatus");

        if (!ListUtil.isEmpty(fiOrderUintCdList)) {
            for (String fiOrderUintCd : fiOrderUintCdList) {
                if (TextUtils.isEmpty(fiOrderUintCd)) {
                    continue;
                }
                SellOutServerProcessor.updateSellOut(fiOrderUintCd, fiStatus, fdInvQty);
            }

        }
        //通知秒点上送估清状态
        DriverBus.call("monitor/update_rapid_sell_out");
        //推送站点估清菜品
        NotifyToClient.refreshSellOut();

        response.Data = SellOutServerProcessor.getAllSellOutViewModel();
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918810">退菜</a>
     */
    @WaiterName("backfoods")
    private static WaiterResponse m(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//订单号

        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        //退菜列表
        List<VoidMenuItemModel> voidMenuItemModels = JSON.parseArray(submitInfo.getString("list"), VoidMenuItemModel
                .class);
        for (VoidMenuItemModel voidMenuItemModel : voidMenuItemModels) {
//            if (voidMenuItemModel.fiItemCd <= 0 || voidMenuItemModel.fiOrderUintCd <= 0) {
            if (TextUtils.isEmpty(voidMenuItemModel.fiItemCd) || StringUtil.toInt(voidMenuItemModel.fiItemCd, 0) <= 0 ||
                    TextUtils.isEmpty(voidMenuItemModel.fiOrderUintCd) || StringUtil.toInt(voidMenuItemModel.fiOrderUintCd, 0) <= 0) {
                return WaiterBizUtil.buildErrorRepsone(response, "菜品ID为0");
            }
            if (TextUtils.isEmpty(voidMenuItemModel.fsbackuserid)) {
                return WaiterBizUtil.buildErrorRepsone(response, "用户ID为空");
            }
            if (!PermissionCheckDinner.canBackAuth(voidMenuItemModel.fsbackuserid)) {
                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + voidMenuItemModel.fsbackusername + "]没有退菜权限");

            }
            if (!PermissionCheckDinner.canBackMenuItem(voidMenuItemModel.fsbackuserid, voidMenuItemModel.fiItemCd,
                    voidMenuItemModel.fiOrderUintCd)) {
                String itemName = MenuDBUtil.getMenuNameByID(voidMenuItemModel.fiItemCd);
                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + voidMenuItemModel.fsbackusername + "]没有[" +
                        itemName + "]的退菜权限");
            }
        }

        // 美小二不允许操作反结账的订单
        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        //共享餐厅的订单不允许退菜
        String thirdOrderType = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select thirdOrderType from tbsell where " +
                "fssellno = '" + fssellno + "'");
        if (TextUtils.equals(thirdOrderType, String.valueOf(NetOrderType.PRE_PAY_SHARE_SHOP))) {
            WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
            return response;
        }

        String tableID = OrderDriver.getTableIDByOrderID(fssellno);
        //检测桌台锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableID);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        WaiterBizUtil.optToken(request.OrderToken, fssellno);

        //发起站点（打印小票使用）--美小二使用业务中心站点
        String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        List<Integer> printNoList = new ArrayList<>();
        int result = DishesBizUtil.returnMenuItem(fssellno, hostId, tableID, userDBModel, voidMenuItemModels, printNoList);
        if (result == 0) {
            response.Status = WaiterResult.SUCCESS;
            response.Error = "退菜成功";
        } else if (result == -1) {
            WaiterBizUtil.buildErrorRepsone(response, "订单已不存在，请稍后重试");
        } else if (result == -2) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号异常");
        } else if (result == -3) {
            WaiterBizUtil.buildErrorRepsone(response, "订单已被结账");
        } else if (result == -4) {
            WaiterBizUtil.buildErrorRepsone(response, "退菜中包含菜品券，不允许退菜");
        }
        return response;
    }

    //====================================参数====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918836">催菜</a>
     */
    @WaiterName("UrgeFood")
    private static WaiterResponse o(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//
        String seqlist = submitInfo.getString("seqlist");//
        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }
        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        String fsmtableId = OrderDriver.getTableIDByOrderID(fssellno);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fssellno, "催菜");
        try {
            final OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }
            //共享餐厅的订单不允许退菜
            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }
            //检测桌台锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fssellno);

            //替换为适用于sql的形式
            seqlist = seqlist.replace("[", "(").replace("]", ")");
            //所有需要催菜的列表
            List<MenuItem> hurryList = new ArrayList<>();
            for (MenuItem temp : orderCache.originMenuList) {
                if (seqlist.contains(temp.menuBiz.uniq)) {
                    temp.menuBiz.fiHurryTimes++;
                    hurryList.add(temp);
                }
            }
            //批量将菜品的催菜次数加1
            boolean result = DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbSellOrderItem set " +
                    "fiHurryTimes=fiHurryTimes+1 where fsSeq in" + seqlist + " or fsSeq_M in " + seqlist + "");
            if (result) {
                OrderSession.getInstance().writeOrder(fssellno, false, "UrgeFood");
                if (!ListUtil.isEmpty(hurryList)) {
                    String hostId = HostUtil.getCurrentHost();
                    PrintOrderUtil.printBatchRush(hurryList, orderCache, userDBModel.fsUserName, hostId, null);
//                for (MenuItem temp : hurryList) {
//                    PrintOrderUtil.printRemindMenuOrder(temp, orderCache, userDBModel.fsUserName);
//                }
                }

                // KDS 服务
                if (DBOrderConfig.useKdsService()) {
                    List<String> uniqList = JSONArray.parseArray(submitInfo.getString("seqlist"), String.class);
                    if (!ListUtil.isEmpty(uniqList)) {
                        KdsManager.getInstance().hurry(fssellno, uniqList, HostBiz.mealorder, userDBModel);
                    }
                }
            } else {
                WaiterBizUtil.buildErrorRepsone(response, "催菜失败");
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fssellno, "催菜");
        }
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=16225810">划菜</a>
     */
    @WaiterName("PaddleFood")
    private static WaiterResponse PaddleFood(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fssellno = submitInfo.getString("fssellno");//
        String seqlist = submitInfo.getString("seqlist");//
        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }
        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        if (DBOrderConfig.useKdsService()) {
            String err = KdsManager.getInstance().inKdsSys(JSON.parseArray(seqlist, String.class));
            if (!TextUtils.isEmpty(err)) {
                WaiterBizUtil.buildErrorRepsone(response, "菜品[" + err + "]进入KDS，不支持站点划菜");
                return response;
            }
        }

        String fsmtableId = OrderDriver.getTableIDByOrderID(fssellno);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fssellno, "划菜");
        try {
            final OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
            WaiterResponse tempResponse = NameUtil.isHandleFssellno(orderCache, userDBModel);
            if (!tempResponse.success()) {
                return tempResponse;
            }

            WaiterBizUtil.optToken(request.OrderToken, fssellno);

            //替换为适用于sql的形式
            seqlist = seqlist.replace("[", "(").replace("]", ")");
            List<MenuItem> hurryList = new ArrayList<>();
            for (MenuItem temp : orderCache.originMenuList) {
                if (seqlist.contains(temp.menuBiz.uniq)) {
                    temp.menuBiz.fiMenuProgress = temp.menuBiz.fiMenuProgress == 0 ? 1 : 0;
                    hurryList.add(temp);
                }
            }
            OrderSaveDBUtil.replacePaddleData(orderCache, hurryList, userDBModel, hurryList.get(0).menuBiz
                    .fiMenuProgress, HostBiz.mealorder);
            OrderSession.getInstance().writeOrder(fssellno, false, "PaddleFood");
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fssellno, "划菜");
        }
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918836">起菜</a>
     */
    @WaiterName("Serving")
    private static WaiterResponse p(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String fsSellNo = jsonObject.getString("fssellno");//账单号

        if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
        if (!TextUtils.isEmpty(error)) {
            return WaiterBizUtil.buildErrorRepsone(response, error);
        }
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        String fsmtableId = OrderDriver.getTableIDByOrderID(fsSellNo);

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fsSellNo, "起菜");
        try {
            //校验订单是否存在
            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache == null) {
                return WaiterBizUtil.buildErrorRepsone(response, "查询不到[" + fsSellNo + "]订单");
            }

            //共享餐厅的订单不允许退菜
            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }


            //检测桌台锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fsSellNo);

            JSONArray seqList = jsonObject.getJSONArray("seqlist");

            for (int i = 0; i < seqList.size(); i++) {
                for (MenuItem item : orderCache.originMenuList) {
                    if (item.hasAllVoid()) {
                        continue;
                    }
                    if (TextUtils.equals(item.menuBiz.uniq, seqList.getString(i))) {
                        item.waitOrCall(3);
                        DishesUtil.doDishes("'" + item.menuBiz.uniq + "'");
                        PrintOrderUtil.printWaitCallData(orderCache, item, userDBModel);//打印起菜单
                    }
                }
            }
            OrderSaveDBUtil.saveMenu(orderCache.orderID, orderCache.originMenuList);

            // KDS 服务
            if (DBOrderConfig.useKdsService()) {
                List<String> uniqList = JSONArray.parseArray(jsonObject.getString("seqlist"), String.class);
                if (!ListUtil.isEmpty(uniqList)) {
                    KdsManager.getInstance().serving(uniqList, HostBiz.mealorder, userDBModel);
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fsSellNo, "起菜");
        }
        return response;
    }

    private static WaiterResponse doChangeTable(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String table = submitInfo.getString("table");//原桌号
        String newtable = submitInfo.getString("newtable");//新桌号
        String fssellno = submitInfo.getString("fssellno");//原账单号
        String reason = submitInfo.getString("reason");//原因
        String opman = submitInfo.getString("opman");//操作人
        String opmanid = submitInfo.getString("opmanid");//操作人ID
        if (TextUtils.isEmpty(table)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台ID为空");
            return response;
        }
        if (TextUtils.isEmpty(newtable)) {
            WaiterBizUtil.buildErrorRepsone(response, "目标桌台ID为空");
            return response;
        }
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "账单号为空");
            return response;
        }
        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }
        if (TextUtils.isEmpty(opmanid)) {
            WaiterBizUtil.buildErrorRepsone(response, "服务员ID为空");
            return response;
        }
        //口碑订单不允许操作
        OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
        if (NetOrderType.isKouBeiOrder(orderCache.thirdOrderType)) {
            WaiterBizUtil.buildErrorRepsone(response, "口碑订单不允许换桌");
            return response;
        }

        if (!TextUtils.equals(orderCache.fsmtableid, table)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台信息发生变化，请刷新");
            LogUtil.logBusiness("---table---" + table + "---orderCache---" + orderCache.toMiniString());
            return response;
        }

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(table, fssellno, "换桌");//1--
        try {
            String error = WaiterBizUtil.canOpertaOrder(fssellno);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            //检查桌台是否被锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, newtable);//2-----
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }
            erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, table);//2----
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fssellno);

            JSONObject requestChange = new JSONObject();
            requestChange.put("originOrderID", fssellno);//原单号
            requestChange.put("targetTableID", newtable);
            requestChange.put("operateWaiterID", opmanid);
            requestChange.put("operateWaiterName", opman);
            requestChange.put("originTableID", table);
            requestChange.put("operateHostID", HostBiz.mealorder);

            final SocketResponse<ChangeTableResponse> socketResponse = new SocketResponse<>();
            TableBusinessUtil.doChangeTable(request.OrderToken, requestChange, socketResponse, userDBModel, HostBiz
                    .mealorder);

            if (socketResponse.code != SocketResultCode.SUCCESS) {
                WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
            } else {
                String oldName = TableDBUtil.getTableNameById(table);
                String newTableName = TableDBUtil.getTableNameById(newtable);
                String printHostId = HostUtil.getCurrentHost();
                List<Integer> printNoList = PrintTableUtil.changeTableReport(userDBModel.fsUserName, oldName,
                        newTableName, socketResponse.data.newOrderCache.orderID, socketResponse.data.newSeqList,
                        printHostId);
                if (!ListUtil.isEmpty(printNoList)) {
                    (socketResponse.data).printNo = printNoList;
                }
                NotifyToClient.orderChangeForSmart(fssellno, socketResponse.data.newOrderCache.fsmtableid);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, table, fssellno, "换桌");
        }
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918856">换桌</a>
     */
    @WaiterName("ChangeTable")
    private static WaiterResponse r(WaiterRequest request) {
        return doChangeTable(request);
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918893">合并到餐桌</a>
     */
    @WaiterName("ChangeTableTo")
    private static WaiterResponse s(WaiterRequest request) {
        return doChangeTable(request);
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918903">菜品改数量</a>
     */
    //CALLME virgil 这个接口不正确
    @Deprecated
    @WaiterName("Changequantity")
    private static WaiterResponse t(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject jsonObject = JSONObject.parseObject(request.Data);
        String fsseq = jsonObject.getString("fsseq");
        int quantity = jsonObject.getInteger("quantity");
        if (TextUtils.isEmpty(fsseq)) {
            return WaiterBizUtil.buildErrorRepsone(response, "单个菜品下单序列不能为空!");
        }
        if (quantity <= 0) {
            return WaiterBizUtil.buildErrorRepsone(response, "修改数量不能小于0");
        }
//        菜品下单序列找到对应规格信息
        String selectUintCdsql = "select fiOrderUintCd from tbSellOrderItem where fsSeq='" + fsseq + "'";
        String fiOrderUintCd = DBSimpleUtil.queryString(APPConfig.DB_MAIN, selectUintCdsql);
        if (TextUtils.isEmpty(fiOrderUintCd)) {
            return WaiterBizUtil.buildErrorRepsone(response, "单个菜品下单序列fsseq[" + fsseq + "]不存在");
        }
        //根据规格id查询规格信息
        MenuItemUnitDBModel menuItemUnit = DBSimpleUtil.query(APPConfig.DB_MAIN, "select fdInvQty from tbMenuItemUint" +
                " where  fiOrderuintCd='" + fiOrderUintCd + "'", MenuItemUnitDBModel.class);
        if (menuItemUnit == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "未找到菜品菜品规格fiOrderUintCd[" + fiOrderUintCd + "]");
        }
        if (menuItemUnit.fiStatus == 2) {//临时沽清
            if (menuItemUnit.fdInvQty.doubleValue() <= quantity) {
                menuItemUnit.fdInvQty = menuItemUnit.fdInvQty.subtract(new BigDecimal(quantity));
                menuItemUnit.replaceNoTrans();//保存规格信息
                return WaiterBizUtil.buildSuccess(response);
            } else {
                String itemName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsItemName from tbMenuItem " +
                        "where fiItemCd in (select fiItemCd from tbmenuitemuint where fiOrderUintCd='" + fiOrderUintCd + "')");
                String errorMsg = "菜品[" + itemName + "]库存已不足" + menuItemUnit.fdInvQty + menuItemUnit.fsOrderUint;
                return WaiterBizUtil.buildErrorRepsone(response, errorMsg);
            }
        } else {
            return WaiterBizUtil.buildSuccess(response);
        }
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918903">菜品改数量 新接口老接口有问题 </a>
     */
    @WaiterName("waiterUpdateBuyNum")
    private static WaiterResponse tz(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject jsonObject = JSONObject.parseObject(request.Data);
        String uniq = jsonObject.getString("uniq");
        String fsSellNo = jsonObject.getString("fsSellNo");
        BigDecimal buyNum = jsonObject.getBigDecimal("buyNum");

        if (buyNum.compareTo(BigDecimal.ZERO) <= 0) {
            return WaiterBizUtil.buildErrorRepsone(response, "菜品数量不得小于零]");
        }

        if (TextUtils.isEmpty(uniq)) {
            return WaiterBizUtil.buildErrorRepsone(response, "请选择菜品]");
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "订单已不存在]");
        }

        if (orderCache.orderStatus == OrderStatus.PAIED) {
            return WaiterBizUtil.buildErrorRepsone(response, "订单已完成结账]");
        }

        if (ListUtil.isEmpty(orderCache.originMenuList)) {
            return WaiterBizUtil.buildErrorRepsone(response, "订单无已下单菜品]");
        }

        MenuItem menuItem = DishesUtil.findMenuItemBySeq(uniq, orderCache.originMenuList);

        if (menuItem == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "没有找到该菜品]");
        }
        menuItem.menuBiz.buyNum = buyNum;
        if (menuItem.isGift()) {
            menuItem.menuBiz.giftNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
        }
        List<MenuItem> indentfyList = new ArrayList<>();
        indentfyList.addAll(menuItem.menuBiz.selectedModifier);

        if (menuItem.supportWeight() && !ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) { //如果是修改称重菜重量则不校验配料数量
            menuItem.menuBiz.selectedModifier.clear();
        }
        List<MenuItem> itemList = new ArrayList<>();
        itemList.add(menuItem);
        SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(itemList);
        if (!result.success) {
            //还原数据
            List<MenuItem> list = OrderSaveDBUtil.getOrderMenuList(orderCache.orderID);
            if (!ListUtil.isEmpty(list)) {
                orderCache.originMenuList = list;
                orderCache.reCalcAllByAll();
            }
            return WaiterBizUtil.buildErrorRepsone(response, result.errorMsg);
        }
        menuItem.menuBiz.selectedModifier.addAll(indentfyList);
        menuItem.calcTotal(menuItem.useMemberPrice);
        orderCache.plusAllMenuAmount();
        OrderSession.getInstance().writeOrder(fsSellNo, true, "waiterUpdateBuyNum");
        NotifyToClient.orderChange(fsSellNo);
        return WaiterBizUtil.buildSuccess(response);
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918910">菜品改价格</a>
     */
    @WaiterName("Changeprice")
    private static WaiterResponse u(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String fsEditPirceUserId = jsonObject.getString("fsEditPirceUserId");//修改人id
        String fsEditPirceUserName = jsonObject.getString("fsEditPirceUserName");//修改人name
        String fsEditPirceReason = jsonObject.getString("fsEditPirceReason");//修改原因
        String fsSeq = jsonObject.getString("fsSeq");//菜品fsseq
        Double fdSalePrice = jsonObject.getDouble("fdSalePrice");//单价
        String fsNewName = jsonObject.getString("fsNewName");//菜品名称
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        if (TextUtils.isEmpty(fsSeq)) {
            return WaiterBizUtil.buildErrorRepsone(response, "销售明细fsSeq不能为空");
        }
        if (fdSalePrice == null || fdSalePrice == 0) {
            return WaiterBizUtil.buildErrorRepsone(response, "修改价格不能空，并且价格不能为0");
        }
        String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsSellno from tbSellOrderItem  where " +
                "fsseq='" + fsSeq + "'");
        if (TextUtils.isEmpty(orderId)) {
            return WaiterBizUtil.buildErrorRepsone(response, "未找到相关订单信息");
        }
        String error = WaiterBizUtil.canOpertaOrder(orderId);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        String fsmtableId = OrderDriver.getTableIDByOrderID(orderId);

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderId, "菜品改价格");
        try {
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                return WaiterBizUtil.buildErrorRepsone(response, "查询不到[" + orderId + "]订单");
            }
            MenuItem menuItem = DishesUtil.findMenuItemBySeq(fsSeq, orderCache.originMenuList);
            if (menuItem == null) {
                return WaiterBizUtil.buildErrorRepsone(response, "查询不到这个菜");
            }
            boolean result = DishesDriver.doUpdateDishPrice(orderId, new BigDecimal(fdSalePrice), orderCache, fsSeq);
            if (!result) {
                return WaiterBizUtil.buildErrorRepsone(response, "目标桌台ID为空");
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderId, "菜品改价格");
        }
        return WaiterBizUtil.buildSuccess(response);
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=17466666">赠送---(支持批量操作、支持部分赠菜)</a>
     */
    @WaiterName("GiftSupportBatch")
    private static WaiterResponse giftSupportBatch(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);

        String fssellno = submitInfo.getString("fssellno");//订单号

        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }


        List<VoidMenuItemModel> giftList = JSON.parseArray(submitInfo.getString("giftList"), VoidMenuItemModel.class);
        if (ListUtil.isEmpty(giftList)) {
            WaiterBizUtil.buildErrorRepsone(response, "请选择菜品");
            return response;
        }
        for (VoidMenuItemModel giftItemModel : giftList) {
//            if (giftItemModel.fiItemCd <= 0 || giftItemModel.fiOrderUintCd <= 0) {
            if (TextUtils.isEmpty(giftItemModel.fiItemCd) || StringUtil.toInt(giftItemModel.fiItemCd, 0) <= 0 ||
                    TextUtils.isEmpty(giftItemModel.fiOrderUintCd) || StringUtil.toInt(giftItemModel.fiOrderUintCd, 0) <= 0) {
                return WaiterBizUtil.buildErrorRepsone(response, "菜品ID为0");
            }
            if (TextUtils.isEmpty(giftItemModel.fsbackuserid)) {
                return WaiterBizUtil.buildErrorRepsone(response, "用户ID为空");
            }
            if (!PermissionCheckDinner.canGiftAuth(giftItemModel.fsbackuserid)) {
                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + giftItemModel.fsbackusername + "]没有赠菜权限");
            }

            if (!PermissionCheckDinner.canGiftMenuItem(giftItemModel.fsbackuserid, giftItemModel.fiItemCd, giftItemModel.fiOrderUintCd)) {
                String itemName = MenuDBUtil.getMenuNameByID(giftItemModel.fiItemCd);
                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + giftItemModel.fsbackusername + "]没有[" + itemName + "]的赠菜权限");
            }
        }

        String tableID = OrderDriver.getTableIDByOrderID(fssellno);
        //检测桌台锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableID);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        WaiterBizUtil.optToken(request.OrderToken, fssellno);

        String fsmtableId = OrderDriver.getTableIDByOrderID(fssellno);
        OrderCache orderCache = null;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fssellno, "赠送---(支持批量操作、支持部分赠菜)");
        try {
            String error = WaiterBizUtil.canOpertaOrder(fssellno);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            orderCache = OrderSession.getInstance().getOrder(fssellno);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }

            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }

            //检测桌台锁定
            erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, fssellno);

            boolean giftResult = false;
            for (VoidMenuItemModel giftModel : giftList) {
                if (giftModel == null) {
                    continue;
                }
                for (MenuItem menuItem : orderCache.originMenuList) {
                    if (menuItem == null) {
                        continue;
                    }
                    if (TextUtils.equals(giftModel.fsseq, menuItem.menuBiz.uniq)
                            && TextUtils.equals(giftModel.fiItemCd, menuItem.itemID)
                            && TextUtils.equals(giftModel.fiOrderUintCd, menuItem.currentUnit.fiOrderUintCd)) {
                        if (menuItem.usedMbCouponSucc() && menuItem.memberDishCoupon != null) {
                            return WaiterBizUtil.buildErrorRepsone(response, menuItem.name + " 使用了菜品券优惠，不允许赠菜");
                        }
                        if (giftModel.fdbackqty.compareTo(BigDecimal.ZERO) <= 0) {
                            menuItem.disGift();
                            //
                        } else if (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
                            //该菜品是赠送状态--再次提交的赠送数量小于已赠送数量---->取消部分赠送
                            if (giftModel.fdbackqty.compareTo(menuItem.menuBiz.giftNum) < 0) {
                                MenuItem menuItemClone = menuItem.clone();
                                menuItemClone.updateUniq();
                                menuItemClone.menuBiz.buyNum = menuItemClone.menuBiz.buyNum.subtract(giftModel.fdbackqty);
                                menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                menuItemClone.disGift();
                                menuItemClone.calcTotal(false);

                                if (DBOrderConfig.useKdsService()) {
                                    // 通知 KDS 菜品拆分
                                    KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                }

                                menuItem.menuBiz.buyNum = giftModel.fdbackqty;
                                if (menuItem.doGift(giftModel.fsbackuserid, "", giftModel.fsbackreason)) {
                                    menuItem.calcTotal(false);
                                }
                                if (orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    orderCache.originMenuList.add(menuItemClone);
                                }
                            }
                        } else if (giftModel.fdbackqty.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).subtract(menuItem.menuBiz.giftNum)) < 0) {
                            //非赠送菜品---赠送数量小于菜品数量时，认为是赠送部分菜品
                            MenuItem menuItemClone = menuItem.clone();
                            menuItemClone.updateUniq();
                            menuItemClone.menuBiz.buyNum = giftModel.fdbackqty;
                            menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                            menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                            if (menuItemClone.doGift(giftModel.fsbackuserid, "", giftModel.fsbackreason)) {
                                menuItemClone.calcTotal(false);
                            }
                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(giftModel.fdbackqty);
                            menuItem.calcTotal(false);

                            if (DBOrderConfig.useKdsService()) {
                                // 通知 KDS 菜品拆分
                                KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                            }

                            if (orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                orderCache.originMenuList.add(menuItemClone);
                            }
                        } else {
                            //非赠送菜品---赠送数量大于等于菜品数量时，认为是赠送全部菜品
                            if (menuItem.doGift(giftModel.fsbackuserid, "", giftModel.fsbackreason)) {
                                menuItem.calcTotal(false);
                            }
                        }
                        break;
                    }
                }
            }
            orderCache.plusAllMenuAmount();
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "giftSupportBatch");
//            OrderProcessor.saveOrder(orderCache, null);

            //订单待支付信息
            final JSONObject dataResponse = new JSONObject();
            dataResponse.put("payBase", NameUtil.buildPayBase(fssellno));
            dataResponse.put("payView", NameUtil.buildPayView(fssellno));
            response.Data = dataResponse;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fssellno, "赠送---(支持批量操作、支持部分赠菜)");
        }
        NotifyToClient.orderChangeForSmart(fssellno, orderCache.fsmtableid);

        return response;
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918926">赠送</a>
     */
    @WaiterName("Gift")
    private static WaiterResponse v(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fsGiftUserId = submitInfo.getString("fsGiftUserId");//赠送人id
        String fsGiftUserName = submitInfo.getString("fsGiftUserName");//赠送人name
        String fsGiftReason = submitInfo.getString("fsGiftReason");//赠送原因
        String fsSeq = submitInfo.getString("fsSeq");//菜品fsseq
        String fiItemCd = submitInfo.getString("fiItemCd");
        String fiOrderUintCd = submitInfo.getString("fiOrderUintCd");

//        if (fiItemCd <= 0 || fiOrderUintCd <= 0) {
        if (TextUtils.isEmpty(fiItemCd) || StringUtil.toInt(fiItemCd, 0) <= 0 ||
                TextUtils.isEmpty(fiOrderUintCd) || StringUtil.toInt(fiOrderUintCd, 0) <= 0) {
            return WaiterBizUtil.buildErrorRepsone(response, "菜品ID为0");
        }

        if (TextUtils.isEmpty(fsGiftUserId)) {
            return WaiterBizUtil.buildErrorRepsone(response, "用户ID为空");
        }
        if (!PermissionCheckDinner.canGiftAuth(fsGiftUserId)) {
            return WaiterBizUtil.buildErrorRepsone(response, "用户[" + fsGiftUserName + "]没有赠菜权限");

        }
        if (!PermissionCheckDinner.canGiftMenuItem(fsGiftUserId, fiItemCd, fiOrderUintCd)) {
            String itemName = MenuDBUtil.getMenuNameByID(fiItemCd);
            return WaiterBizUtil.buildErrorRepsone(response, "用户[" + fsGiftUserName + "]没有[" + itemName + "]的赠菜权限");
        }
        String sql = "select fsSellNo from tbSellOrderItem where fsSeq='" + fsSeq + "'";
        String orderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);

        if (!WaiterBizUtil.checkOrderToken(orderID, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }


        String fsmtableId = OrderDriver.getTableIDByOrderID(orderID);
        OrderCache orderCache = null;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "赠送");
        try {
            String error = WaiterBizUtil.canOpertaOrder(orderID);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            orderCache = OrderSession.getInstance().getOrder(orderID);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }

            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }

            //检测桌台锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }

            WaiterBizUtil.optToken(request.OrderToken, orderID);

            boolean giftResult = false;
            for (MenuItem temp : orderCache.originMenuList) {
                if (TextUtils.equals(temp.menuBiz.uniq, fsSeq)) {
                    giftResult = temp.doGift(fsGiftUserId, "", fsGiftReason);
                    temp.calcTotal(orderCache.isMember);
                    break;
                }
            }

            if (!giftResult) {
                WaiterBizUtil.buildErrorRepsone(response, "不能赠送");
                return response;
            }
            orderCache.plusAllMenuAmount();
            PayProcessor.saveOrderChangeNeedPay(orderCache, userDBModel);

            //订单待支付信息
            final JSONObject dataResponse = new JSONObject();
            dataResponse.put("payBase", NameUtil.buildPayBase(orderID));
            dataResponse.put("payView", NameUtil.buildPayView(orderID));
            response.Data = dataResponse;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "赠送");
        }

        NotifyToClient.orderChangeForSmart(orderID, orderCache.fsmtableid);

        return response;
    }

//    /**
//     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=17466666">赠送---(支持批量操作、支持部分赠菜)</a>
//     */
//    @WaiterName("GiftSupportBatch")
//    private static WaiterResponse giftSupportBatch(WaiterRequest request) {
//        WaiterResponse response = new WaiterResponse();
//        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
//        if (userDBModel == null) {
//            WaiterBizUtil.buildInvalidTokenlRepsone(response);
//            return response;
//        }
//        JSONObject submitInfo = JSON.parseObject(request.Data);
//
//        String fssellno = submitInfo.getString("fssellno");//订单号
//
//        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
//            WaiterBizUtil.buildIneffectivenessOrderToken(response);
//            return response;
//        }
//
//
//        List<VoidMenuItemModel> giftList = JSON.parseArray(submitInfo.getString("giftList"), VoidMenuItemModel.class);
//        if (ListUtil.isEmpty(giftList)) {
//            WaiterBizUtil.buildErrorRepsone(response, "请选择菜品");
//            return response;
//        }
//        for (VoidMenuItemModel giftItemModel : giftList) {
//            if (giftItemModel.fiItemCd <= 0 || giftItemModel.fiOrderUintCd <= 0) {
//                return WaiterBizUtil.buildErrorRepsone(response, "菜品ID为0");
//            }
//            if (TextUtils.isEmpty(giftItemModel.fsbackuserid)) {
//                return WaiterBizUtil.buildErrorRepsone(response, "用户ID为空");
//            }
//            if (!PermissionCheckDinner.canGiftAuth(giftItemModel.fsbackuserid)) {
//                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + giftItemModel.fsbackusername + "]没有赠菜权限");
//            }
//
//            if (!PermissionCheckDinner.canGiftMenuItem(giftItemModel.fsbackuserid, giftItemModel.fiItemCd,
//                    giftItemModel.fiOrderUintCd)) {
//                String itemName = MenuDBUtil.getMenuNameByID(giftItemModel.fiItemCd);
//                return WaiterBizUtil.buildErrorRepsone(response, "用户[" + giftItemModel.fsbackusername + "]没有[" +
//                        itemName + "]的赠菜权限");
//            }
//        }
//
//        String tableID = OrderDriver.getTableIDByOrderID(fssellno);
//        //检测桌台锁定
//        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableID);
//        if (!TextUtils.isEmpty(erroInfo)) {
//            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
//            return response;
//        }
//        WaiterBizUtil.optToken(request.OrderToken, fssellno);
//
//        final Object lock = ServerCache.getInstance().optLock(OrderDriver.getTableIDByOrderID(fssellno));
//        OrderCache orderCache = null;
//        synchronized (lock) {
//            String error = WaiterBizUtil.canOpertaOrder(fssellno);
//            if (!TextUtils.isEmpty(error)) {
//                WaiterBizUtil.buildErrorRepsone(response, error);
//                return response;
//            }
//            orderCache = OrderSession.getInstance().getOrder(fssellno);
//            if (orderCache == null) {
//                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
//                return response;
//            }
//
//            if (orderCache.shareShopOrder()) {
//                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
//                return response;
//            }
//
//            //检测桌台锁定
//            erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
//            if (!TextUtils.isEmpty(erroInfo)) {
//                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
//                return response;
//            }
//
//            WaiterBizUtil.optToken(request.OrderToken, fssellno);
//
//            boolean giftResult = false;
//            for (VoidMenuItemModel giftModel : giftList) {
//                if (giftModel == null) {
//                    continue;
//                }
//                for (MenuItem menuItem : orderCache.originMenuList) {
//                    if (menuItem == null) {
//                        continue;
//                    }
//                    if (TextUtils.equals(giftModel.fsseq, menuItem.menuBiz.uniq)
//                            && giftModel.fiItemCd == menuItem.itemID
//                            && giftModel.fiOrderUintCd == menuItem.currentUnit.fiOrderUintCd) {
//                        if (giftModel.fdbackqty.compareTo(BigDecimal.ZERO) <= 0) {
//                            menuItem.disGift();
//                            //
//                        } else if (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
//                            //该菜品是赠送状态--再次提交的赠送数量小于已赠送数量---->取消部分赠送
//                            if (giftModel.fdbackqty.compareTo(menuItem.menuBiz.giftNum) < 0) {
//                                MenuItem menuItemClone = menuItem.clone();
//                                menuItemClone.updateUniq();
//                                menuItemClone.menuBiz.buyNum = menuItemClone.menuBiz.buyNum.subtract(giftModel
//                                        .fdbackqty);
//                                menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
//                                menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
//                                menuItemClone.disGift();
//                                menuItemClone.calcTotal(false);
//
//                                menuItem.menuBiz.buyNum = giftModel.fdbackqty;
//                                if (menuItem.doGift(giftModel.fsbackuserid, giftModel.fsbackusername, giftModel
//                                        .fsbackreason)) {
//                                    menuItem.calcTotal(false);
//                                }
//                                if (orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
//                                    orderCache.originMenuList.add(menuItemClone);
//                                }
//                            }
//                        } else if (giftModel.fdbackqty.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz
//                                .voidNum).subtract(menuItem.menuBiz.giftNum)) < 0) {
//                            //非赠送菜品---赠送数量小于菜品数量时，认为是赠送部分菜品
//                            MenuItem menuItemClone = menuItem.clone();
//                            menuItemClone.updateUniq();
//                            menuItemClone.menuBiz.buyNum = giftModel.fdbackqty;
//                            menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
//                            menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
//                            if (menuItemClone.doGift(giftModel.fsbackuserid, giftModel.fsbackusername, giftModel
//                                    .fsbackreason)) {
//                                menuItemClone.calcTotal(false);
//                            }
//                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(giftModel.fdbackqty);
//                            menuItem.calcTotal(false);
//                            if (orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
//                                orderCache.originMenuList.add(menuItemClone);
//                            }
//                        } else {
//                            //非赠送菜品---赠送数量大于等于菜品数量时，认为是赠送全部菜品
//                            if (menuItem.doGift(giftModel.fsbackuserid, giftModel.fsbackusername, giftModel
//                                    .fsbackreason)) {
//                                menuItem.calcTotal(false);
//                            }
//                        }
//                        break;
//                    }
//                }
//            }
//            orderCache.plusAllMenuAmount();
//            OrderSession.getInstance().writeOrder(orderCache.orderID, true);
//            OrderProcessor.saveOrder(orderCache, null);
//        }
//        NotifyToClient.orderChangeForSmart(fssellno, orderCache.fsmtableid);
//
//        return response;
//    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919011">取消赠送</a>
     */
    @WaiterName("UGift")
    private static WaiterResponse w(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String fsGiftUserId = submitInfo.getString("fsGiftUserId");//赠送人id
        String fsGiftUserName = submitInfo.getString("fsGiftUserName");//赠送人name
        String fsGiftReason = submitInfo.getString("fsGiftReason");//赠送原因
        String fsSeq = submitInfo.getString("fsSeq");//菜品fsseq
        String sql = "select fsSellNo from tbSellOrderItem where fsSeq='" + fsSeq + "'";
        String orderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        String fsmtableId = OrderDriver.getTableIDByOrderID(orderID);
        OrderCache orderCache = null;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "取消赠送");
        try {
            String error = WaiterBizUtil.canOpertaOrder(orderID);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
            orderCache = OrderSession.getInstance().getOrder(orderID);
            if (orderCache == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此订单");
                return response;
            }
            //共享餐厅的订单不允许退菜
            if (orderCache.isNotSupportEditor()) {
                WaiterBizUtil.buildErrorRepsone(response, "该订单不支持任何修改");
                return response;
            }


            //检测桌台锁定
            String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                    .fsmtableid);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }
            boolean giftResult = false;
            for (MenuItem temp : orderCache.originMenuList) {
                if (TextUtils.equals(temp.menuBiz.uniq, fsSeq)) {
                    giftResult = temp.disGift();
                    if (giftResult) {
                        temp.calcTotal(orderCache.isMember);
                    }
                    break;
                }
            }

            if (!giftResult) {
                WaiterBizUtil.buildErrorRepsone(response, "不能取消");
                return response;
            }
            orderCache.plusAllMenuAmount();
            PayProcessor.saveOrderChangeNeedPay(orderCache, userDBModel);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "取消赠送");
        }
        NotifyToClient.orderChangeForSmart(orderID, orderCache.fsmtableid);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919016">打折</a>
     */
    @WaiterName("Defaultdiscount")
    private static WaiterResponse x(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919067">改账单人数</a>
     */
    @WaiterName("UpdateBill")
    private static WaiterResponse y(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        int ficustsum = StringUtil.toInt(submitInfo.getString("ficustsum"), 0);//新人数
        String fssellno = submitInfo.getString("fssellno");//订单号
        if (ficustsum < 1) {
            WaiterBizUtil.buildErrorRepsone(response, "人数输入不正确");
            return response;
        }
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "账单号为空");
            return response;
        }
        String erroInfo = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        /**
         * 判断原始桌是否已有支付信息，如果有，则不能修改人数
         */
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as count from " +
                "tbSellReceive where fsSellNo='" + fssellno + "'"), 0);
        if (count > 0) {
            WaiterBizUtil.buildErrorRepsone(response, "该订单已有支付信息，不能修改人数");
            return response;
        }
        OrderSession.getInstance().getOrder(fssellno).personNum = ficustsum;
        OrderSaveDBUtil.updatePersonNum(fssellno, ficustsum);
        String tableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select tableID from order_cache where " +
                "order_id = '" + fssellno + "'");
        NotifyToClient.orderChangeForSmart(fssellno, tableId);
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919128">转菜</a>
     */
    @WaiterName("ItemChangeTable")
    private static WaiterResponse z(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        JSONObject submitInfo = JSON.parseObject(request.Data);
        String oldSell = submitInfo.getString("oldSell");//原单号
        String reason = submitInfo.getString("reason");//转菜原因
        String newtableId = submitInfo.getString("newtableId");//新桌号

        if (!WaiterBizUtil.checkOrderToken(oldSell, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        String erroInfo = WaiterBizUtil.canOpertaOrder(oldSell);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        String newSell = TableBusinessUtil.getOrderIDByTableID(newtableId);
        if (!TextUtils.isEmpty(newSell)) {
            erroInfo = WaiterBizUtil.canOpertaOrder(newSell);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }
        }
        //检查桌台是否被锁定
        erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, newtableId);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }


        OrderCache orderCache = null;
        orderCache = OrderSession.getInstance().getOrder(oldSell);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单异常，请稍后重试");
            return response;
        }
        erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        WaiterBizUtil.optToken(request.OrderToken, oldSell);

        List<TurnMenuItemModel> list = JSON.parseArray(submitInfo.getString("list"), TurnMenuItemModel.class);

        BatchTurnDishesRequest transferDishRequest = new BatchTurnDishesRequest();
        transferDishRequest.oldSell = oldSell;
        transferDishRequest.fromSmart = true;
        transferDishRequest.reason = reason;
        transferDishRequest.mewTableId = newtableId;
        transferDishRequest.list = list;

        SocketHeader head = new SocketHeader();
        head.version = SocketConfig.API_VERSION;
        head.requestId = "dishes/batchTurnDishes" + "_" + System.currentTimeMillis();
        head.device = ServerHardwareUtil.getHardWareSymbol();
        head.shopid = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
//            head.verifySession = 1;
        head.us = request.Token;
        head.hd = HostBiz.mealorder;

        SocketResponse<BatchTurnDishesResponse> socketResponse = DriverBus.call("dishes/batchTurnDishes", head, JSON
                .toJSONString(transferDishRequest));
        if (socketResponse.code == SocketResultCode.SUCCESS) {

        } else {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        NotifyToClient.orderChangeForSmart(oldSell, orderCache.fsmtableid);

        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4919150">免服务费</a>
     */
    @WaiterName("FreeSvrAmt")
    private static WaiterResponse aa(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        WaiterBizUtil.buildErrorRepsone(response, "暂不支持此操作");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4924168">获取账单菜品明细</a>
     */
    @WaiterName("getsellitemlist")
    private static WaiterResponse ab(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        //过滤掉餐标模式下自动加上的 餐标服务费和低消服务费菜品
        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbsellorderitem where " +
                "fssellno='" + jsonObject.get("fssellno") + "' and (fiItemCd != '" + DinnerStandardUtil.DS_MENU_ID + "' and fiItemCd != '" + DinnerStandardUtil.MS_MENU_ID + "')");
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4924165">获取账单头</a>
     */
    @WaiterName("getsell")
    private static WaiterResponse ac(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String tableNo = jsonObject.getString("tableno");
        final JSONObject object = TableBusinessUtil.getSellJSONObject(tableNo);
        response.Data = object;

        if (object != null) {
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    //校验会员评论信息是否存在
                    String fsSellNO = object.getString("fsSellNo");
                    String cardNo = object.getString("fsCardNo");
                    if (!TextUtils.isEmpty(fsSellNO) && !TextUtils.isEmpty(cardNo) && ServerCache.getInstance()
                            .optMemberComments(cardNo) == null) {
                        MemberBizUtil.requestMemberComents(cardNo);
                    }
                    //检查短链
                    TableQRProcess.checkTableQRSortLink(tableNo);
                }
            }).start();

        }
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4924939">扫码支付</a>
     */
    @WaiterName("scanPay")
    private static WaiterResponse ad(WaiterRequest request) {
        return processPay(request, false);
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4924939">查询扫码支付的结果</a>
     */
    @WaiterName("searchPayResult")
    private static WaiterResponse ae(WaiterRequest request) {
        return processPay(request, true);
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=16226492">获取订单划菜数据</a>
     */
    @WaiterName("getsellpicklist")
    private static WaiterResponse ag(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);

        response.Data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbSellPickMenuitem where fsSellNo='" + jsonObject.get("fssellno") + "'");
        return response;
    }

    /**
     * 扫码支付
     *
     * @param request
     * @param onlySearch
     * @return
     */
    private static WaiterResponse processPay(final WaiterRequest request, final boolean onlySearch) {
        final WaiterResponse response = new WaiterResponse();

        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        if (!PermissionCheckDinner.hasPayPermission(userDBModel.fsUserId)) {
            WaiterBizUtil.buildErrorRepsone(response, "账户[" + userDBModel.fsUserName + "]没有收银权限");
            return response;
        }
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String tableid = jsonObject.getString("tableno");
        final String fssellno = jsonObject.getString("fssellno");
        String code = jsonObject.getString("scancode");
        String amount = jsonObject.getString("payamount");
        String disamount = jsonObject.getString("disamount");
        final String payOrder = jsonObject.getString("payOrder");

        if (!WaiterBizUtil.checkOrderToken(fssellno, request.OrderToken)) {
            WaiterBizUtil.buildIneffectivenessOrderToken(response);
            return response;
        }

        if (onlySearch) {
            if (TextUtils.isEmpty(payOrder)) {
                WaiterBizUtil.buildErrorRepsone(response, "支付单号为空");
                return response;
            }
        }
        if (TextUtils.isEmpty(amount)) {
            WaiterBizUtil.buildErrorRepsone(response, "金额为空");
            return response;
        }
        if (TextUtils.isEmpty(tableid)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台号为空");
            return response;
        }
        if (TextUtils.isEmpty(code)) {
            WaiterBizUtil.buildErrorRepsone(response, "支付码为空，请重新扫码");
            return response;
        }
//        if (code.length() < 17) {
//            WaiterBizUtil.buildErrorRepsone(response, "扫码错误，请重新扫码");
//            return response;
//        }
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        final Object payWaitLock = new Object();
        final JSONObject responsData = new JSONObject();

        BigDecimal payAmount = BigDecimal.ZERO;
        BigDecimal disAmount = BigDecimal.ZERO;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }

        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        final OrderCache order = OrderSession.getInstance().getOrder(fssellno);
        if (order == null) {
            WaiterBizUtil.buildErrorRepsone(response, "[" + fssellno + "]订单号不存在");
            return response;
        }
        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        if (!onlySearch) {
            erroInfo = DinnerStandardUtil.checkDinnerStandardPay(order);
            if (!TextUtils.isEmpty(erroInfo)) {
                WaiterBizUtil.buildErrorRepsone(response, erroInfo);
                return response;
            }
        }

        String checkToPayMsg = order.checkToPay();
        if (!TextUtils.isEmpty(checkToPayMsg)) {
            WaiterBizUtil.buildErrorRepsone(response, checkToPayMsg);
            return response;
        }
        String orderToken = WaiterBizUtil.optToken(request.OrderToken, fssellno);
        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectNetPay(orderToken, fssellno, onlySearch,
                payOrder, payAmount, code, userDBModel, HostBiz.mealorder);
        responsData.put("orderPayFinish", 0);
        responsData.put("payResult", NetPayResult.FAIL);

        if (socketResponse.data != null) {
            responsData.put("payResult", socketResponse.data.thirdPayStatus);
            responsData.put("payResultMsg", socketResponse.message);
            responsData.put("payOrder", socketResponse.data.thirdPayOrderID);
            responsData.put("orderPayFinish", socketResponse.data.payFinished ? 1 : 0);
        } else {
            if (!socketResponse.success()) {
                WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
            }
        }

        response.Data = responsData;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4926361">校验账户密码和权限</a>
     */
    @WaiterName("permissionVerify")
    private static WaiterResponse af(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String username = jsonObject.getString("username");
        String uid = jsonObject.getString("uid");

        String pwd = jsonObject.getString("pwd");
        String permission = jsonObject.getString("permission");

        if (TextUtils.isEmpty(username) && TextUtils.isEmpty(uid)) {
            WaiterBizUtil.buildErrorRepsone(response, "用户名为空");
            return response;
        }
        if (TextUtils.isEmpty(pwd)) {
            WaiterBizUtil.buildErrorRepsone(response, "密码为空");
            return response;
        }
        if (TextUtils.isEmpty(permission)) {
            WaiterBizUtil.buildErrorRepsone(response, "权限类型为空");
            return response;
        }

        UserDBModel user = null;
        if (!TextUtils.isEmpty(uid)) {
            user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fsUserId='" + uid + "'",
                    UserDBModel.class);
        } else if (!TextUtils.isEmpty(username)) {
            user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fsUserName='" + username + "'",
                    UserDBModel.class);
        }
        if (user == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "无此用户");
        }
        if (!TextUtils.equals(user.fsPwd, pwd)) {
            return WaiterBizUtil.buildErrorRepsone(response, "密码不正确");
        }
        if (!PermissionCheckDinner.hasPermission(user.fsUserId, permission)) {
            return WaiterBizUtil.buildErrorRepsone(response, "账号[" + user.fsUserName + "]无此权限");
        }

        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918805">清台</a>
     */
    @WaiterName("Cleartable")
    private static WaiterResponse clearTable(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String tableno = jsonObject.getString("tableno");
        if (TextUtils.isEmpty(tableno)) {
            return WaiterBizUtil.buildErrorRepsone(response, "桌台编号不能为空");
        }

        MtableDBModel mtableDBModel = TableDBUtil.getMTableById(tableno);
        if (mtableDBModel == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "没有查到该桌台");
        }

        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(tableno);
        if (tableBizModel != null && TextUtils.equals(tableBizModel.fsmtablesteid, "2")) {//已开台
//              清台条件 无销售单 或者有销售单 并且无菜品销售记录
            boolean hasCanClearTable = false;
            if (!TextUtils.isEmpty(tableBizModel.fssellno)) {
                String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbsellorderitem " +
                        "where fssellno='" + tableBizModel.fssellno + "'");
                if (StringUtil.toInt(count) == 0) {
                    hasCanClearTable = true;
                }
            } else {
                hasCanClearTable = true;
            }
            if (hasCanClearTable) {
                TableDBUtil.releaseTableBizById(tableno);
                return WaiterBizUtil.buildSuccess(response);
            }

        } else {
            return WaiterBizUtil.buildErrorRepsone(response, "桌台未开台，不可清台");
        }

        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4918853">反结账</a>
     */
    @WaiterName("Antinode")
    private static WaiterResponse antinode(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String fsSellNo = jsonObject.getString("fsSellNo");//账单号
        String fsrecheckreason = jsonObject.getString("fsrecheckreason");//反结账原因
        String fsrecheckuserId = jsonObject.getString("fsrecheckuserId");//操作人id
        String fsrecheckusername = jsonObject.getString("fsrecheckusername");//操作人姓名
//        表单校验
        if (TextUtils.isEmpty(fsSellNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "账单号不能为空");
        }
        if (TextUtils.isEmpty(fsrecheckuserId)) {
            return WaiterBizUtil.buildErrorRepsone(response, "操作人id不能为空");
        }
        if (TextUtils.isEmpty(fsrecheckusername)) {
            return WaiterBizUtil.buildErrorRepsone(response, "操作人姓名不能为空");
        }
//         反结账处理
        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "fsSellNo[" + fsSellNo + "]无效账单号");
        }
        MtableDBModel mtableDBModel = TableDBUtil.getMTableById(orderCache.fsmtableid);
        if (mtableDBModel == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "找不到目标桌台");
        }

        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(mtableDBModel.fsmtableid);

        if (TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid) && TextUtils.isEmpty
                (tableBizModel.fssellno)) {
            UserDBModel userDBModel = new UserDBModel();
            userDBModel.fsUserId = fsrecheckuserId;
            userDBModel.fsUserName = fsrecheckusername;
            TableBusinessUtil.openTable(orderCache.fsmtableid, orderCache.orderID, userDBModel);

            OrderSession.updateOrderStatus(fsSellNo, OrderStatus.ANTI_PAIED);
            OrderSession.setPayed(fsSellNo, 0);
            return WaiterBizUtil.buildSuccess(response);
        } else if (TextUtils.equals(tableBizModel.fssellno, fsSellNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "已开台");
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, "桌台已被占用");
        }
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=5610733">61.根据单号获取待支付金额</a>
     */
    @WaiterName("getsellmoney")
    private static WaiterResponse getsellmoney(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String fsSellNo = jsonObject.getString("fssellno");//账单号
        //校验订单号是否存在
        if (TextUtils.isEmpty(fsSellNo)) {
            return WaiterBizUtil.buildErrorRepsone(response, "账单号不能为空");
        }

        //校验订单是否存在
        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "查询不到[" + fsSellNo + "]订单");
        }

        String error = WaiterBizUtil.canOpertaOrder(fsSellNo);
        if (!TextUtils.isEmpty(error)) {
            return WaiterBizUtil.buildErrorRepsone(response, error);
        }
        JSONObject reuslt = new JSONObject();
        reuslt.put("fdexpamt", orderCache.optTotalPrice().toPlainString());

        PaySession session = OrderSession.getInstance().getPay(fsSellNo);
        if (session == null) {
            BigDecimal cut = orderCache.optTotalSpecialCoupon();
            reuslt.put("fdpayamt", cut.toPlainString());
            reuslt.put("fdnotpayamt", orderCache.optTotalPrice().subtract(cut).toPlainString());
        } else {
            orderCache.reCalcAllByAll();

            //刷新Session的待支付金额部分
            OrderUtil.buildPayCache(session, orderCache, session.billNO, session.currentHostID,
                    session.waiterID, session.waiterName);

            reuslt.put("fdpayamt", orderCache.optTotalPrice().subtract(session.priceLeftToPay).toPlainString());
            reuslt.put("fdnotpayamt", session.priceLeftToPay.toPlainString());
        }
        response.Data = reuslt;
        return response;
    }


    /**
     * <a href="">处理秒点单</a>
     */
    @WaiterName("processRapid")
    private static WaiterResponse ah(WaiterRequest request) {
        final WaiterResponse response = new WaiterResponse();
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        JSONObject jsonObject = JSON.parseObject(request.Data);
        final String tableid = jsonObject.getString("tableNo");

        //检查桌台ID是否正确
        if (TextUtils.isEmpty(tableid)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台号为空");
            return response;
        }

        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableid, "", " 处理秒点订单 ");
        try {
            //检查桌台
            MtableDBModel mtableDBModel = TableDBUtil.getMTableById(tableid);
            if (mtableDBModel == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此桌台");
                return response;
            }

            //检查桌台业务状态及锁桌状态
            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(tableid);
            if (tableBizModel == null) {
                WaiterBizUtil.buildErrorRepsone(response, "桌子不存在");
                return response;
            }

            if (TextUtils.isEmpty(tableBizModel.extra_order)) {
                WaiterBizUtil.buildErrorRepsone(response, "该秒点订单已被其他服务员处理");
                return response;
            }

            int operationType = 0;
            Integer isTake = jsonObject.getInteger("isTake");   //0:弃用, 1:取用
            if (isTake == null) {
                operationType = 0;
            } else {
                operationType = isTake.intValue();
            }

            if (operationType == 0) {  //弃用秒点单
                TableBusinessUtil.cleanRapidOrder(tableid);
                MessageDBUtil.updateMessageOrderByTableId(tableid, MessageConstance.MessageOrderBuinessStatus.RAPID
                        .IGNORE, userDBModel);
                NotifyToClient.refreshTableOrOrders();
            } else {  //取用秒点单
                nameGetRapid(response, userDBModel, mtableDBModel, tableBizModel);
//                if (TextUtils.equals(response.Status, WaiterResult.SUCCESS)) {
//                    TableBusinessUtil.cleanRapidOrder(tableid);
//                    MessageDBUtil.updateMessageOrderByTableId(tableBizModel.fsmtableid, MessageConstance
// .MessageOrderBuinessStatus.RAPID_NORMAL.GET, userDBModel);
//                    NotifyToClient.refreshTableOrOrders();
//                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableid, "", " 处理秒点订单 ");
        }
        return response;
    }

    /**
     * 取用秒点单
     *
     * @param response
     * @return
     */
    private static WaiterResponse nameGetRapid(WaiterResponse response, UserDBModel userDBModel, MtableDBModel
            mtableDBModel, TableBizModel tableBizModel) {

        TempOrderDishesCache extraOrder = JSON.parseObject(tableBizModel.extra_order,
                TempOrderDishesCache.class);
        if (extraOrder == null) {
            WaiterBizUtil.buildErrorRepsone(response, "秒点单异常，请稍后重试");
            return response;
        }

        //秒点菜品
        if (ListUtil.isEmpty(extraOrder.tempSelectedMenuList)) {
            WaiterBizUtil.buildErrorRepsone(response, "秒点单异常，请稍后重试");
            return response;
        }

        List<SellOrderItemDBModel> newMenuItemList = new ArrayList<>();

        UserDBModel cloudUser = RapidBiz.getCloudUser();
        if (cloudUser == null) {
            cloudUser = userDBModel;
        }
        String orderId;
        if (TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid)) {
            OrderCache orderCache = OrderDriver.generateNewOrder();
            orderId = orderCache.orderID;
            orderCache.waiterID = cloudUser.fsUserId;
            orderCache.waiterName = cloudUser.fsUserName;
            orderCache.currentHostID = HostBiz.mealorder;
            orderCache.currentSectionID = OrderUtil.getSectionId();
            orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
            orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
            orderCache.fsmtableid = mtableDBModel.fsmtableid;
            orderCache.fsmtablename = mtableDBModel.fsmtablename;
            orderCache.fsmareaid = mtableDBModel.fsmareaid;
            orderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where " +
                    "fsMAreaId = '" + mtableDBModel.fsmareaid + "'");
            orderCache.personNum = extraOrder.personNum;
            orderCache.shopID = mtableDBModel.fsshopguid;
            orderCache.mealNumber = orderId.substring(8, 12);
            orderCache.orderStatus = OrderStatus.NORMAL;
            if (orderCache.originMenuList.size() > 0) {
                for (MenuItem temp : orderCache.originMenuList) {
                    temp.menuBiz.orderSeqID = orderCache.currentSeq;
                    if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : temp.menuBiz.selectedModifier) {
                            modifier.menuBiz.orderSeqID = orderCache.currentSeq;
                        }
                    }
                }
                orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, cloudUser, HostBiz.mealorder);
                orderCache.currentSeq++;
            }
            TableProcessor.openTableSuccess(orderCache);
            OrderSession.getInstance().writeOrder(orderId, orderCache, true, "nameGetRapid");
//            OrderProcessor.saveOrder(orderCache, null);
            String printHostId = HostUtil.getCurrentHost();
            PrintTableUtil.openTableReport(orderCache, printHostId);
            if (orderCache.originMenuList.size() > 0) {
                PrintOrderUtil.printMakeOrder(orderCache, printHostId, orderCache.currentSeq - 1);
                PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.mealorder);
                PrintOrderUtil.printPassTo(orderCache, printHostId);
            }
            SocketResponse socketResponse = new SocketResponse();
            TableBusinessUtil.doOpenTable(new SocketResponse(), HostBiz.mealorder, tableBizModel.fsmtableid, orderId,
                    cloudUser);
        } else {
            orderId = tableBizModel.fssellno;
            //判断是否可以操作订单
            String error = WaiterBizUtil.canOpertaOrder(orderId);
            if (!TextUtils.isEmpty(error)) {
                WaiterBizUtil.buildErrorRepsone(response, error);
                return response;
            }
        }

        //秒点单桌台上的订单信息
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单异常，请稍后重试");
            return response;
        }

        /**
         * 将秒点单中的菜品转化为报表SellOrderItems List
         */
        for (MenuItem temp : extraOrder.tempSelectedMenuList) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelByID(temp.itemID);
            newMenuItemList.addAll(OrderProcessor.createSellMenuItem(orderCache, itemDB, temp, null));
        }

        //已下单菜品
        String sql = "select * from tbSellOrderItem where fsSellNo = '" + orderId + "'";
        List<SellOrderItemDBModel> orderMenuItemList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOrderItemDBModel.class);
        if (ListUtil.isEmpty(orderMenuItemList)) {
            orderMenuItemList = new ArrayList<>();
        }


        JSONObject result = new JSONObject();
        result.put("sellno", orderId);
        result.put("orderList", orderMenuItemList);
        result.put("newMenuList", newMenuItemList);
        response.Data = result;
        return response;
    }


    /**
     * 获取订单token
     */
    @WaiterName("getOrderToken")
    private static WaiterResponse getOrderToken(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "未查询到登录用户");
            return response;
        }
        String tableId = jsonObject.getString("tableId");

        if (TextUtils.isEmpty(tableId)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台错误");
            return response;
        }

        //检查桌台是否正在被占用
        String tableLock = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, tableId);
        if (!TextUtils.isEmpty(tableLock)) {
            WaiterBizUtil.buildErrorRepsone(response, tableLock);
            return response;
        }
        //没被锁定的桌台，拿订单ID，生产一个新的token
        String token = ServerCache.getInstance().generateNewToken(TableBusinessUtil.getOrderIDByTableID(tableId));
        JSONObject object = new JSONObject();
        object.put("orderToken", token);
        response.Data = object.toString();

        return response;
    }

    /**
     * 获取点菜合并设置
     * 0:不合并， 1：合并
     */
    @WaiterName("getMenuMergeSetting")
    private static WaiterResponse getMenuMergeSetting(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String setting = CommonDBUtil.getConfigWithDefault(DBOrderConfig.MERGE_MENUITEM_EQUALS, "0");
        JSONObject object = new JSONObject();
        object.put("setting", setting);
        response.Data = object.toString();

        return response;
    }


    /**
     * 获取美小二线下收款
     * 0/关闭 1/开启 默认关闭
     */
    @WaiterName("queryOfflinePayment")
    private static WaiterResponse queryOfflinePayment(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject dataResponse = new JSONObject();
        dataResponse.put("offlinePayment", ClientMetaUtil.getConfig(META.WAITER_OFFLINE_PAYMENT,"0"));
        response.Data = dataResponse;
        return response;
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634495">73.获取订单的支付信息</a>
     */
    @WaiterName("getBillInfo")
    private static WaiterResponse getBillInfo(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        response = WaiterBizUtil.checkCanPay(request.OrderToken, false, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderid);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, " 获取订单的支付信息 ");
        try {

            OrderProcessor.saveOrder(orderCache, null);
            PaySession session = OrderSession.getInstance().getPay(orderid);
            OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.mealorder);
            OrderSession.getInstance().writePay(orderid, true);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, " 获取订单的支付信息 ");
        }
        final JSONObject dataResponse = new JSONObject();
        dataResponse.put("payBase", NameUtil.buildPayBase(orderid));
        dataResponse.put("payView", NameUtil.buildPayView(orderid));

        response.Data = dataResponse;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634590">74.支付-扫码</a>
     */
    @WaiterName("payByBarcode")
    private static WaiterResponse payByBarcode(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String code = jsonObject.getString("barcode");
        String amount = jsonObject.getString("payamount");
        if (TextUtils.isEmpty(code)) {
            WaiterBizUtil.buildErrorRepsone(response, "支付码为空，请重新扫码");
            return response;
        }
        if (code.length() < 17) {
            WaiterBizUtil.buildErrorRepsone(response, "扫码错误，请重新扫码");
            return response;
        }
        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        BigDecimal payAmount;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectNetPay(request.OrderToken, orderid, false,
                "", payAmount, code, userDBModel, HostBiz.mealorder);
        WaiterPayResult payResult = new WaiterPayResult();
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
        }

        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.payView = NameUtil.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634505">77.支付-挂帐</a>
     */
    @WaiterName("payByHung")
    private static WaiterResponse payByHung(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String accountID = jsonObject.getString("accountID");
        String accountName = jsonObject.getString("accountName");
        String amount = jsonObject.getString("payamount");
        if (TextUtils.isEmpty(accountID)) {
            WaiterBizUtil.buildErrorRepsone(response, "账户为空");
            return response;
        }
        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        BigDecimal payAmount;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectHung(request.OrderToken, orderid,
                userDBModel, HostBiz.mealorder, accountID, accountName, payAmount, null);
        WaiterPayResult payResult = new WaiterPayResult();
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.payView = NameUtil.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634517">81.支付-选择常规的支付方式</a>
     */
    @WaiterName("payByPayType")
    private static WaiterResponse payByPayType(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String amount = jsonObject.getString("payamount");
        String fsPaymentId = jsonObject.getString("fsPaymentId");

        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        BigDecimal payAmount;

        try {
            payAmount = new BigDecimal(amount);
        } catch (Exception e) {
            e.printStackTrace();
            WaiterBizUtil.buildErrorRepsone(response, "待支付金额[" + amount + "]不是有效的数字");
            return response;
        }
        if (payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            WaiterBizUtil.buildErrorRepsone(response, "金额必须大于0");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        PayOriginModel payModel = OrderUtil.buildPayModelByPaymentID(fsPaymentId);

        SocketResponse<PayResultResponse> socketResponse = BillUtil.selectPayType(request.OrderToken, orderid,
                payModel, payAmount, userDBModel, HostBiz.mealorder);
        WaiterPayResult payResult = new WaiterPayResult();
        payResult.payFinished = 0;
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9634507">82.支付-删除支付方式/退款</a>
     */
    @WaiterName("refundPay")
    private static WaiterResponse refundPay(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");
        String fsseq = jsonObject.getString("fsseq");

        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        if (TextUtils.isEmpty(fsseq)) {
            WaiterBizUtil.buildErrorRepsone(response, "支付序号为空");
            return response;
        }
        int seq = StringUtil.toInt(fsseq);
        if (seq < 0) {
            WaiterBizUtil.buildErrorRepsone(response, "支付序号不合法");
            return response;
        }
        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        SocketResponse<PayVoidResponse> socketResponse = BillUtil.startVoidPay(request.OrderToken, orderid,
                userDBModel, HostBiz.mealorder, seq);
        WaiterPayResult payResult = new WaiterPayResult();
        payResult.payFinished = 0;
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9636213">83.支付-完成结账</a>
     */
    @WaiterName("payFinish")
    private static WaiterResponse payFinish(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fssellno");


        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        //todo 兼容口碑先付款 结账清台 这个和其他的结账方法区别开来
        String thirdOrderType = jsonObject.getString("thirdOrderType");
        if (!TextUtils.isEmpty(thirdOrderType) && Integer.valueOf(thirdOrderType) == NetOrderType.KB_ORDER) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, JSON.toJSONString(jsonObject) + "  美小二调用口碑先付款的结账方法  ");
            SocketResponse socketResponse = new KBOrderServiceImpl().checkOut(orderid, userDBModel);
            WaiterPayResult payResult = new WaiterPayResult();
            payResult.payFinished = 1;
           /* payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;*/
            if (!socketResponse.success()) {
                WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
            } else {
                payResult.payFinished = 0;
            }
            payResult.buildPayView(orderid);
            response.Data = payResult;
            return response;
        }

        response = WaiterBizUtil.checkCanPay(request.OrderToken, true, orderid, userDBModel);
        if (!response.success()) {
            return response;
        }

        //设置了固定用餐标准的桌台，不允许结账。
        //有最低消费标准的桌台，未达最低消费标准时不允许结账，达到最低消费标准允许结账
        String errInfo = DinnerStandardUtil.checkDinnerStandardPay(OrderSession.getInstance().getOrder(orderid));
        if (!TextUtils.isEmpty(errInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, errInfo);
            return response;
        }

        SocketResponse<PayResultResponse> socketResponse = BillUtil.startFinalPayProcess(request.OrderToken, orderid,
                userDBModel, HostBiz.mealorder, true, true);
        WaiterPayResult payResult = new WaiterPayResult();
        payResult.payFinished = 0;
        if (socketResponse.data != null) {
            payResult.payFinished = socketResponse.data.payFinished ? 1 : 0;
            payResult.thirdPayOrderID = socketResponse.data.thirdPayOrderID;
            payResult.thirdPayStatus = socketResponse.data.thirdPayStatus;
            payResult.needMemberPwd = socketResponse.data.needMemberPwd ? 1 : 0;
        }
        if (!socketResponse.success()) {
            WaiterBizUtil.buildErrorRepsone(response, socketResponse.message);
        }
        payResult.buildPayView(orderid);
        response.Data = payResult;
        return response;
    }


    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9639632">89、获取所有优惠与折扣</a>
     */
    @WaiterName("optAllDiscount")
    private static WaiterResponse optAllDiscount(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String orderid = jsonObject.getString("fsSellno");

        String fsShopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

        if (TextUtils.isEmpty(orderid)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(orderid);

        JSONObject jsonResult = new JSONObject();
        jsonResult.put("discountCash", DiscountBizUtil.optDiscountCash(fsShopId));
        jsonResult.put("discountCutList", DiscountBizUtil.optDiscountCutList(fsShopId));
        jsonResult.put("discountList", DiscountBizUtil.optDiscountList(fsShopId, ""));

        //已选中的整单立减ID
        String selectDiscountCutId = "";
        //所有菜对应的折扣Map<菜品ID_规格ID, 折扣IDList>
        ArrayMap<String, List<String>> menuItemAndDiscountMap = new ArrayMap<>();
        int isMember = 0, canGift = 0;
        if (orderCache != null) {
            if (orderCache.isMember) {
                isMember = 1;
            }
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                for (MenuItem menuItem : orderCache.originMenuList) {
                    if (menuItem == null) {
                        continue;
                    }
                    if (menuItem.hasAllVoid()) {
                        continue;
                    }
                    //判断菜品是否可赠送
                    if ((menuItem.config & 8) == 8) {  //有一个菜品可赠送，赠送按钮就可点击
                        canGift = 1;
                        break;
                    }
                }
            }
            menuItemAndDiscountMap = DiscountBizUtil.getAllMenuItemAndDiscountIDs(DiscountBizUtil
                    .menuItem2DiscountMenuItem(orderCache.originMenuList));

            if (orderCache.selectOrderDiscountCut != null) {
                selectDiscountCutId = orderCache.selectOrderDiscountCut.fsDiscountId;
            }
        }
        jsonResult.put("menuItemAndDiscountMap", menuItemAndDiscountMap);
        jsonResult.put("isMember", isMember);
        jsonResult.put("canGift", canGift);
        jsonResult.put("selectDiscountCutId", selectDiscountCutId);
        response.Data = jsonResult.toJSONString();
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9640602">92、校验权限及获取理由和有权限的用户列表</a>
     */
    @WaiterName("checkPermission")
    private static WaiterResponse checkPermission(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        String waiterId = userDBModel.fsUserId;
        String fsProgDtlId = jsonObject.getString("fsProgDtlId");
        String permissionType = jsonObject.getString("permissionType");
        String fsDiscountId = jsonObject.getString("fsDiscountId");
        List<MenuSimpleInfo> menuInfoLists = JSON.parseArray(jsonObject.getString("menuInfoLists"), MenuSimpleInfo
                .class);

        CheckPermissionResponse responseData = new CheckPermissionResponse();
        String errMsg = PermissionBizUtil.checkPermission(responseData, waiterId, fsProgDtlId, permissionType,
                fsDiscountId, menuInfoLists);
        if (!TextUtils.isEmpty(errMsg)) {
            WaiterBizUtil.buildErrorRepsone(response, errMsg);
            return response;
        }
        response.Status = WaiterResult.SUCCESS;
        response.Data = responseData;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9642157">93.校验授权账户密码</a>
     */
    @WaiterName("authorityChecking")
    private static WaiterResponse authorityChecking(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String waiterId = jsonObject.getString("waiterId");
        String hostId = HostBiz.mealorder;
        String pwd = jsonObject.getString("pwd");
        String fsiccardcode = jsonObject.getString("fsiccardcode");  //IC卡号
        String checkResult = PermissionBizUtil.checkPermissionAuthor(waiterId, pwd, hostId, fsiccardcode);
        if (!TextUtils.isEmpty(checkResult)) {
            WaiterBizUtil.buildErrorRepsone(response, checkResult);
            return response;
        }
        response.Status = WaiterResult.SUCCESS;
        response.Error = "授权成功";

        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9639783">90. 使用优惠与折扣</a>
     */
    @WaiterName("doDiscount")
    private static WaiterResponse doDiscount(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }
        String fsSellNo = jsonObject.getString("fsSellNo");
        List<NameDiscountModel> itemList = JSONArray.parseArray(jsonObject.getString("menuList"), NameDiscountModel
                .class);
        String fsDiscountCutId = jsonObject.getString("fsDiscountCutId");

        if (TextUtils.isEmpty(fsSellNo)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "订单已不存在");
            return response;
        }

        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, orderCache
                .fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, " 使用优惠与折扣 ");
        try {
//            orderCache = OrderSession.getInstance().getOrder(fsSellNo);

            if (!WaiterBizUtil.checkOrderToken(fsSellNo, request.OrderToken)) {
                WaiterBizUtil.buildIneffectivenessOrderToken(response);
                return response;
            }

            NameUtil.doDiscount(response, orderCache, orderCache.originMenuList, itemList, fsDiscountCutId);

            //重新计算价格
            orderCache.plusAllMenuAmount();
            //存入报表
            OrderSession.getInstance().writeOrder(fsSellNo, true, "doDiscount");
//            OrderProcessor.saveOrder(orderCache, null);

            OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.mealorder);
            OrderSession.getInstance().writePay(fsSellNo, true);

            //订单待支付信息
            final JSONObject dataResponse = new JSONObject();
            dataResponse.put("payBase", NameUtil.buildPayBase(fsSellNo));
            dataResponse.put("payView", NameUtil.buildPayView(fsSellNo));
            response.Data = dataResponse;
            NotifyToClient.refreshTableOrOrders();
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, " 使用优惠与折扣 ");
        }
        return response;
    }

    @WaiterName("buildPayOrder")
    private static WaiterResponse buildPayOrder(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        JSONObject jsonObject = JSON.parseObject(request.Data);
        String orderId = jsonObject.getString("orderId");

        if (TextUtils.isEmpty(orderId)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        String payOrder = BillUtil.buildPayOrder(orderId, userDBModel, HostBiz.mealorder);

        JSONObject result = new JSONObject();
        result.put("payOrder", payOrder);
        response.Data = result;
        return response;
    }

    /**
     * 取消服务铃
     */
    @WaiterName("cancelRapidbell")
    private static WaiterResponse cancelRapidbell(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        final UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "未查询到登录用户");
            return response;
        }
        String tableNo = jsonObject.getString("tableNo");

        if (TextUtils.isEmpty(tableNo)) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台错误");
            return response;
        }

        TableBizModel tableBizModel = TableDBUtil.getTableBizModelById(tableNo);
        if (tableBizModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "桌台错误");
            return response;
        }
        // 标记该服务铃已读
        tableBizModel.fiwxmsgflag = TableStatusBean.NONE;
        tableBizModel.flag &= ~2;
        TableBusinessUtil.updateRapidOrder(tableNo, tableBizModel.flag, tableBizModel.fiwxmsgflag, tableBizModel
                .extra_order);
        NotifyToClient.refreshTableOrOrders();
        NotifyToClient.refreshRapidbell(tableNo, "1", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));

        return response;
    }

    @WaiterName("getsellchcek")
    private static WaiterResponse getsellchcek(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String fssellno = jsonObject.getString("fssellno");
        if (TextUtils.isEmpty(fssellno)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }
        response.Data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "SELECT * FROM tbSellCheck WHERE fsSellno = '" + fssellno + "'");
        return response;
    }

    @WaiterName("searchTableByMenu")
    private static WaiterResponse searchTableByMenu(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        List<String> menuitem = JSON.parseArray(jsonObject.getString("menuitem"), String.class);
        if (!ListUtil.isEmpty(menuitem)) {
            String param = ListUtil.optSqlParams(menuitem);
            String sql = "SELECT * FROM tbMtable WHERE fsMTableId IN (SELECT fsMTableId FROM tbSell WHERE fsSellNo IN (SELECT fsSellNo FROM tbSellOrderItem WHERE fiItemCd IN (" + param + ")) AND fiStatus = '" + OrderStatus.NORMAL + "');";
            response.Data = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        }
        return response;
    }

    /**
     * 获取菜品、提成人关联
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28670148
     */
    @WaiterName("loadAllBonusUser")
    private static WaiterResponse loadAllBonusUser(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);

        String fsUserId = jsonObject.getString("fsUserId");

        UserDBModel userDBModel = null;
        if (!TextUtils.isEmpty(fsUserId)) {
            userDBModel = UserDBUtils.queryById(fsUserId);
        }

        JSONObject ob = new JSONObject();
        ob.put("user", userDBModel);
        ob.put("bonusUserList", BonusBizUtil.queryAllBonusUser());
        response.Data = ob.toString();

        return response;
    }

    /**
     * 下单后提成人修改
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28670238
     */
    @WaiterName("updateBonus")
    private static WaiterResponse updateBonus(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String orderId = jsonObject.getString("orderId");

        if (TextUtils.isEmpty(orderId)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        String error = WaiterBizUtil.canOpertaOrder(orderId);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }

        String fsmtableId = OrderDriver.getTableIDByOrderID(orderId);

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderId, "美小二修改提成人");
        try {
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                return WaiterBizUtil.buildErrorRepsone(response, "查询不到[" + orderId + "]订单");
            }

            List<SellOrderItemBonusDBModel> bonusItemList = JSON.parseArray(jsonObject.getString("tbSellOrderItemBonus"), SellOrderItemBonusDBModel.class);
            BonusBizUtil.updateBonusBySell(orderCache, bonusItemList);

            OrderSession.getInstance().writeOrder(orderId, false, "updateBonus");
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderId, "美小二修改提成人");
        }

        return response;
    }

    /**
     * 菜品已绑定提成人获取
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28670240
     */
    @WaiterName("loadBindBonusUser")
    private static WaiterResponse loadBindBonusUser(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String orderId = jsonObject.getString("orderId");

        if (TextUtils.isEmpty(orderId)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单号为空");
            return response;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }

        if (ListUtil.isEmpty(orderCache.originMenuList)) {
            WaiterBizUtil.buildErrorRepsone(response, "订单内无菜品");
            return response;
        }

        List<SellOrderItemBonusSimpleModel> bonusList = new ArrayList<>();
        for (MenuItem item : orderCache.originMenuList) {
            SellOrderItemBonusSimpleModel bonusItem = new SellOrderItemBonusSimpleModel();
            bonusItem.fsSeq = item.menuBiz.uniq;
            bonusItem.fsBonusUserId = item.menuBiz.bonusUserId;
            bonusItem.fsBonusCertigierUserId = item.menuBiz.bonusAuthorizerId;
            bonusList.add(bonusItem);
            if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
                for (MenuItem modifier : item.menuBiz.selectedModifier) {
                    SellOrderItemBonusSimpleModel bonusModifier = new SellOrderItemBonusSimpleModel();
                    bonusModifier.fsSeq = modifier.menuBiz.uniq;
                    bonusModifier.fsBonusUserId = modifier.menuBiz.bonusUserId;
                    bonusModifier.fsBonusCertigierUserId = modifier.menuBiz.bonusAuthorizerId;
                    bonusList.add(bonusModifier);
                }
            }
        }

        JSONObject ob = new JSONObject();
        ob.put("orderId", orderId);
        ob.put("tbSellOrderItemBonus", bonusList);
        response.Data = ob.toString();

        return response;
    }

    /**
     * 获取开台参数
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28670326
     */
    @WaiterName("loadOpenParam")
    private static WaiterResponse loadOpenParam(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String fsmareaid = jsonObject.getString("fsmareaid");
        int personNum = jsonObject.getIntValue("personNum");
        String fsUserId = jsonObject.getString("fsUserId");

        UserDBModel userDBModel = UserDBUtils.queryById(fsUserId);
        if (userDBModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此用户");
            return response;
        }
        response.Data = OrderBizUtil.getOpenParamOrderMenu(fsmareaid, personNum, userDBModel.fsUserId, userDBModel.fsUserName);

        return response;
    }

    /**
     * 校验开台参数
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=28670964
     */
    @WaiterName("checkOpenParam")
    private static WaiterResponse checkOpenParam(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String orderId = jsonObject.getString("orderId");
        String fsUserId = jsonObject.getString("fsUserId");

        UserDBModel userDBModel = UserDBUtils.queryById(fsUserId);
        if (userDBModel == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此用户");
            return response;
        }

        OrderCache orderCache = OrderSaveDBUtil.get(orderId);
        if (orderCache == null) {
            WaiterBizUtil.buildErrorRepsone(response, "无此订单");
            return response;
        }

        String checkResult = OrderBizUtil.checkOrderOpenParam(orderCache, userDBModel.fsUserId, userDBModel.fsUserName);

        if (TextUtils.isEmpty(checkResult)) {
            response.Status = WaiterResult.SUCCESS;
            response.Error = "预定菜已全部下单";
        } else {
            response.Status = WaiterResult.FAIL;
            response.Error = checkResult;
        }

        return response;
    }


}
