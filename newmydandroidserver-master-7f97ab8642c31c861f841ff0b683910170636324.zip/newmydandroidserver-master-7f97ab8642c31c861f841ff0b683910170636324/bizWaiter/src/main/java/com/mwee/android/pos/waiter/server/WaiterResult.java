package com.mwee.android.pos.waiter.server;

/**
 * 美小二通讯结果
 * Created by virgil on 2017/1/16.
 */

public class WaiterResult {


    /**
     * 订单操作的token已过期
     */
    public final static String ORDER_TOKEN_EXPIRED = "16";

    /**
     * 功能站不支持
     */
    public final static String NOT_SUPPORT = "4";

    /**
     * 订单状态已发生变化
     */
    public final static String ORDER_CHANGED = "3";

    /**
     * 已估清
     */
    public final static String SELLOUT = "2";


    public final static String FAIL = "1";
    public final static String SUCCESS = "0";

}
