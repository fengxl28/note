package com.mwee.android.pos.waiter.business.bill;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.PaymentDBModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 返回给美小二的订单支付信息
 * Created by virgil on 2017/9/8.
 */

class WaiterPayBase extends BusinessBean {
    /**
     * 订单号
     */
    public String fssellno = "";
    /**
     * 支付单号
     */
    public String billNO = "";
    /**
     * 桌台ID
     */
    public String fsmtableid = "";
    /**
     * 折前总价
     */
    public BigDecimal amtOrigin = BigDecimal.ZERO;
    /**
     * 总折扣掉的金额
     */
    public BigDecimal amtDiscounted = BigDecimal.ZERO;
    /**
     * 需要支付的总价
     */
    public BigDecimal amtTotalNeedPay = BigDecimal.ZERO;
    /**
     * 可折扣总额
     */
    public BigDecimal amtTotalCanDiscount = BigDecimal.ZERO;

    /**
     * 支付方式列表
     */
    public List<PaymentDBModel> payTypeList = new ArrayList<>();

    /**
     * 打赏信息
     */
    public String rewardInfo = "";
    public String memberCardNo = "";
    /**
     * 服务费
     */
    public BigDecimal amtService = BigDecimal.ZERO;

    /**
     * 订单是否包含服务费逻辑：1，包含服务费；0，无服务费
     */
    public int hasFee = 0;

    public WaiterPayBase() {

    }
}
