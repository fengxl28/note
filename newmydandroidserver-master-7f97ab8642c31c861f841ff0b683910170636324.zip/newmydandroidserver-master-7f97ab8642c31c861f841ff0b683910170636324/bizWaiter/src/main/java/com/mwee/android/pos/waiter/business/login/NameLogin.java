package com.mwee.android.pos.waiter.business.login;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.shift.ShiftDinnerProcessor;
import com.mwee.android.pos.businesscenter.air.dbUtil.component.HostStatusDBUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.driver.PreparePrintUtil;
import com.mwee.android.pos.businesscenter.print.PrintReportUtil;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShiftDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.waiter.basebean.NameInvoke;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.WaiterBizUtil;
import com.mwee.android.pos.waiter.component.WaiterName;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * 登录相关的方法
 * Created by virgil on 2017/1/16.
 */
@SuppressWarnings("unused")
class NameLogin extends NameInvoke {
    public static final String TAG = "NameLogin";
    //====================================菜品====================================

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=4917699">登录接口</a>
     */
    @WaiterName("Login")
    private static WaiterResponse a(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        if (request == null || TextUtils.isEmpty(request.Data)) {
            return WaiterBizUtil.buildIlleagalRepsone(response);
        }
        JSONObject jsonObject = JSON.parseObject(request.Data);
        String uid = jsonObject.getString("uid");
        String pwd = jsonObject.getString("pwd");
        String device = request.Device;
        if (TextUtils.isEmpty(uid)) {
            return WaiterBizUtil.buildErrorRepsone(response, "账号为空");
        }
        if (TextUtils.isEmpty(pwd)) {
            return WaiterBizUtil.buildErrorRepsone(response, "密码为空");
        }

        if (HostUtil.isShopFinished()) {
            return WaiterBizUtil.buildErrorRepsone(response, "门店已打烊");
        }

        UserDBModel user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fsUserId='" + uid + "'", UserDBModel.class);
        if (user == null) {
            return WaiterBizUtil.buildErrorRepsone(response, "无此用户");
        }
        if (user.fiStatus != 1) {
            return WaiterBizUtil.buildErrorRepsone(response, "此用户不可用");
        }
        if (!TextUtils.equals(user.fsPwd, pwd)) {
            return WaiterBizUtil.buildErrorRepsone(response, "密码不正确");
        }

        //检查服务员是否正在其他设备登录着
        String target = HostUtil.checkUserRelogin(uid, device);
        if (!TextUtils.isEmpty(target)) {
            //通知该设备，服务员已被剔除
            NotifyToClient.userRelogin(target, user.fsUserName, "其他美小二设备");
        }

        String token = HostUtil.waiterLogin(uid, request.Device,jsonObject.getIntValue("printConfig"));

        JSONObject result = new JSONObject();
        result.put("IsSales", user.fiIsSales);
        result.put("SDeptId", user.fsDeptId);
        result.put("SUserId", user.fsUserId);
        result.put("SUserName", user.fsUserName);
        result.put("T", token);
        result.put("couponBargainList", OrderUtil.initBarginList(HostUtil.getHistoryBusineeDate("")));
        response.Data = result;
        return response;
    }

    /**
     * <a href="http://wiki.mwbyd.cn/pages/viewpage.action?pageId=6334308">64. 检测业务中心连接状态</a>
     */
    @WaiterName("CheckBizCenterConnected")
    private static WaiterResponse CheckBizCenterConnected(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        //发起请求的门店GUID
        String shopGUID = request.ShopGUID;
        //当前门店GUID
        String localShopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

        response.Status = TextUtils.equals(shopGUID, localShopId) ? "0" : "1";
        return response;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23034219'>获取班别列表</a>
     *
     * @param request
     * @return
     */
    @WaiterName("queryShiftList")
    private static WaiterResponse queryShiftList(WaiterRequest request) {
        String sql = "SELECT tbshift.*\n" +
                "FROM tbshift\n" +
                "       LEFT JOIN (SELECT * FROM datacache WHERE type = '%d') AS datacache ON tbshift.fsShiftId = datacache.key\n" +
                "WHERE tbshift.fiStatus = '1'";
        List<ShiftDBModel> result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sql, IOCache.TYPE_SHIFT_CLOSE), ShiftDBModel.class);
        WaiterResponse response = new WaiterResponse();
        response.Data = result;
        return response;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23034221'>选择登录班别</a>
     *
     * @param request
     * @return
     */
    @WaiterName("chooseShift")
    private static WaiterResponse chooseShift(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        final JSONObject param = JSON.parseObject(request.Data);

        String fsShiftId = param.getString("fsShiftId");

        String dbShiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsShiftId FROM tbshift WHERE fsShiftId = '" + fsShiftId + "' AND fiStatus = '1'");
        String closedShiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT key FROM datacache WHERE type = '" + IOCache.TYPE_SHIFT_CLOSE + "' AND key = '" + fsShiftId + "'");

        if (!TextUtils.isEmpty(dbShiftID)) {
            if (!TextUtils.isEmpty(closedShiftID)) {
                return WaiterBizUtil.buildErrorRepsone(response, "此班别已关账");
            } else {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "UPDATE host_status SET shiftid = '" + fsShiftId + "' WHERE hostid = '" + HostBiz.mealorder + "' AND user_session = '" + request.Token + "'");
            }
        } else {
            return WaiterBizUtil.buildErrorRepsone(response, "此班别已失效");
        }
        JSONObject data = new JSONObject();
        data.put("businessDate", HostUtil.getHistoryBusineeDate(""));
        response.Data = data;
        return response;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23034226'>获取交班列表</a>
     *
     * @param request
     * @return
     */
    @WaiterName("unfinishShift")
    private static WaiterResponse unfinishShift(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        UserDBModel userDBModel = WaiterBizUtil.getUserByToken(request.Token);
        if (userDBModel == null) {
            WaiterBizUtil.buildInvalidTokenlRepsone(response);
            return response;
        }

        JSONObject param = JSONObject.parseObject(request.Data);

        String businessDate = param.getString("businessDate");
        String sql = "" +
                "SELECT tbSellCheck.fsUpdateUserId                             AS waiterid,\n" +
                "       tbSellCheck.fsUpdateUserName                           AS waitername,\n" +
                "       tbSellCheck.fsShiftId                                  AS shiftid,\n" +
                "       tbshift.fsShiftName                                    AS shiftName,\n" +
                "       sum(tbSellCheck.fdRealAmt)                             AS totalAmount,\n" +
//                "       count(*)                                               AS ordernum,\n" +
//                "       sum(CASE tbSell.fiBillStatus WHEN 3 THEN 1 ELSE 0 END) AS payednum,\n" +
                "       (CASE tbSellCheck.fiStatus WHEN 2 THEN 1 ELSE 0 END)   AS locked\n" +
                "FROM tbSellCheck\n" +
                "       INNER JOIN tbshift ON tbSellCheck.fsShiftId = tbshift.fsShiftId\n" +
                "       INNER JOIN tbSell ON tbSellCheck.fsSellNo = tbSell.fsSellNo\n" +
                "WHERE tbSell.fiBillStatus IN ('3', '4')\n" +
                "  AND tbsell.fiSellType <> '2'\n" +
                "  AND tbSellCheck.fsSellDate = '" + businessDate + "'\n" +
                "GROUP BY tbSellCheck.fsUpdateUserId, tbSellCheck.fsShiftId, tbSellCheck.fiStatus\n" +
                "ORDER BY tbSellCheck.fiStatus ASC";

        List<JSONObject> shiftModels = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);

        if (ListUtil.isEmpty(shiftModels)) {
            return response;
        }
        buildShiftDetail(userDBModel, businessDate, shiftModels);
        LogUtil.log(TAG, "shiftModels size =" + shiftModels.size());
        response.Data = shiftModels;
        return response;
    }

    /**
     * 构建交班详情
     *
     * @param userDBModel
     * @param businessDate
     * @param shiftModels
     */
    private static void buildShiftDetail(UserDBModel userDBModel, String businessDate, List<JSONObject> shiftModels) {
        for (JSONObject model : shiftModels) {
            if (!TextUtils.equals(userDBModel.fsUserId, model.getString("waiterid"))) {
                continue;
            }
            JSONObject detail = new JSONObject();
            detail.put("businessDate", businessDate);

            String orderId = "";
            if (model.getIntValue("locked") == 0) {
                orderId = PaySaveDBUtil.getDinnerUnShiftOrder(businessDate, model.getString("waiterid"), model.getString("shiftid"));
            } else {
                orderId = PaySaveDBUtil.getDinnerShiftOrder(businessDate, model.getString("waiterid"), model.getString("shiftid"));
            }

            String sqlDetail = "" +
                    "SELECT tbSellReceive.fsPaymentName AS fspaymentname, sum(tbSellReceive.fdReceMoney) AS " +
                    "fdrecemoney, sum(1) AS qty\n" +
                    "FROM tbSellReceive\n" +
                    "       INNER JOIN tbSellCheck ON tbSellReceive.fsSellNo = tbSellCheck.fsSellNo\n" +
                    "WHERE tbSellCheck.fsSellNo IN (" + orderId + ")\n" +
                    "  and tbSellReceive.fsSellDate = '" + businessDate + "'\n" +
                    "  AND tbSellCheck.fsShiftId = '" + model.getString("shiftid") + "'\n" +
                    "  AND tbSellCheck.fsUpdateUserId = '" + model.getString("waiterid") + "'\n" +
                    "  AND tbSellReceive.fiStatus = '1'\n" +
                    "GROUP BY fsPaymentId;";
            List<JSONObject> paymentList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sqlDetail);
            if (ListUtil.isEmpty(paymentList)) {
                paymentList = new ArrayList<>();
            }
            detail.put("paymentList", paymentList);
            detail.put("businessDate", businessDate);

            BigDecimal total = BigDecimal.ZERO;
            for (JSONObject payment : paymentList) {
                BigDecimal fdReceMoney = BigDecimal.ZERO;
                try {
                    fdReceMoney = new BigDecimal(payment.getString("fdrecemoney"));
                } catch (Exception ex) {
                    fdReceMoney = BigDecimal.ZERO;
                }
                total = total.add(fdReceMoney);
            }
            detail.put("HJ", total);
            model.put("detail", detail);
        }
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23034228'>交班</a>
     *
     * @param request
     * @return
     */
    @WaiterName("doShift")
    private static WaiterResponse doShift(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject param = JSON.parseObject(request.Data);

        // 非授权交班的操作，仅限本人交班
        if (!param.getBooleanValue("isAuthorize") && !TextUtils.equals(param.getString("currentWaiterID"), param.getString("waiterID"))) {
            return WaiterBizUtil.buildErrorRepsone(response, "交班仅限收银员本人");
        }

        String sql_unpayed_order = "select order_id " +
                "from order_pay_cache   " +
                "where " +
                "business_date='" + param.getString("businessDate") + "'  " +
                "and waiterid='" + param.getString("waiterID") + "' " +
                "and shiftid='" + param.getString("shiftID") + "' " +
                "and payed='0'";
        String unPayedOrderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);

        if (!TextUtils.isEmpty(unPayedOrderID)) {
            return WaiterBizUtil.buildErrorRepsone(response, getErrorMsg(unPayedOrderID));
        }

        String unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(param.getString("businessDate"), param.getString("waiterID"), param.getString("shiftID"));
        //更新指定订单的交班状态
        ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
        NotifyToClient.refreshShift();

        shiftPrintWithConfig(param, unfinishOrderID);
        return response;
    }


    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23034389'>打印预交班表</a>
     *
     * @param request
     * @return
     */
    @WaiterName("printPreShift")
    private static WaiterResponse printPreShift(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject param = JSON.parseObject(request.Data);

        String unfinishOrderID = "";
        if (param.getIntValue("rePrintOrPrePrint") == 0) {
            // 未交班订单号
            unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(param.getString("businessDate"), param.getString("waiterID"), param.getString("shiftID"));
        } else {
            //已交班订单号
            unfinishOrderID = PaySaveDBUtil.getDinnerShiftOrder(param.getString("businessDate"), param.getString("waiterID"), param.getString("shiftID"));
        }

        shiftPrintWithConfig(param, unfinishOrderID);

        return response;
    }

    /**
     * 构建交班错误信息
     *
     * @param orderId
     * @return
     */
    private static String getErrorMsg(String orderId) {
        String errorMsg = "订单[" + orderId + "]尚未完成结账";
        String sellType = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiSellType from tbsell where fssellno = '" + orderId + "'");
        if (TextUtils.equals("0", sellType)) {
            String tableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tableBiz where fssellno = '" + orderId + "'");
            if (TextUtils.isEmpty(tableId)) {
                errorMsg = "存在未结账的异常订单" + orderId + "，请至”收银站点-账单管理“处理此订单";
            }
        } else if (TextUtils.equals("1", sellType)) {
            String bizStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderId + "'");
            if (!TextUtils.equals("1", bizStatus)) {
                errorMsg = "存在未结账的异常订单" + orderId + "，请至”收银站点-账单管理“处理此订单";
            }
        }
        return errorMsg;
    }

    /**
     * 构建并打印交班表
     *
     * @param param
     * @param unfinishOrderID
     * @param printConfig
     */
    private static void buildAndPrintShift(JSONObject param, String unfinishOrderID, int printConfig) {
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where fiStatus='1' and fsShopGUID='" + HostUtil.getShopID() + "'", ShopDBModel.class);
        HashMap<String, Object> printValue = PreparePrintUtil.prepareShiftPrintValue(shopDBModel
                , param.getString("businessDate")
                , param.getString("waiterID")
                , param.getString("waiterName")
                , param.getString("shiftID")
                , param.getString("shiftName")
                , HostBiz.mealorder
                , unfinishOrderID
                , param.getBooleanValue("isAuthorize")
                , param.getString("authorizeUsername")
                , param.getString("authorizeUserId")
                , printConfig
        );

        if (printValue != null && printValue.size() > 0) {
            String titleRemind = "";
            LogUtil.log("交班表打印：" + titleRemind);
            //默认从主站点出
            String hostId = HostUtil.getCurrentHost();
            //读美小二结账单打印配置：美小二出交班表，端上不出小票
            if(TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_ShIFT_ON_WAITER,"0"),"1")){
                HostStatusModel waiter = HostStatusDBUtils.queryWaiter(param.getString("waiterID"));
                //printConfig：打印配置 0：不可打印，1可打印，默认0
                if(waiter != null && TextUtils.equals(waiter.hostid, HostBiz.mealorder) && waiter.printConfig == 1 && !TextUtils.isEmpty(waiter.device)){
                    hostId = waiter.device;//美小二硬件标志
                }else{
                    LogUtil.logBusiness("美小二打印交班表开关为开，但不可打印："+ (waiter == null ? "" : "printConfig:"+waiter.printConfig+",device:"+waiter.device));
                }
            }
            List<Integer> printNoList = PrintReportUtil.printShiftReceipt(hostId, param.getString("businessDate"), printValue, titleRemind);
        }
    }

    /**
     * 根据配置打印交班表
     *
     * @param param
     * @param unfinishOrderID
     */
    private static void shiftPrintWithConfig(JSONObject param, String unfinishOrderID) {
        //config : 0 :不打印交班表 1：打印全部 2：不打印档口明细
        int printConfig = param.getIntValue("printConfig");
        if (printConfig != 0) {
            buildAndPrintShift(param, unfinishOrderID, printConfig);
            //保存用户的选择
            DBMetaUtil.updateSettingsValueByKey(META.SHIFT_PRINT_CONFIG, printConfig);
        }

//        UploadDataProcessor.doUploadOrderWithBaseData();
        UploadDataHelper.uploadOrderData(true);
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=26873822'>更新美小二打印的小票状态</a>
     *
     * @param request
     * @return
     */
    @WaiterName("updatePrintTask")
    private static WaiterResponse updatePrintTask(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();

        JSONObject param = JSON.parseObject(request.Data);
        if(param != null){
            int printNo = param.getInteger("printNo");
            //打印状态
            int printStatus = param.getInteger("printStatus");
            String errorMsg = param.getString("errorMsg");

            JSONObject contents = new JSONObject();
            contents.put("fiPrintCount","1");
            contents.put("fiStatus",""+printStatus);
            contents.put("fsFinishTime", DateUtil.getCurrentTime());
            JSONObject detail = new JSONObject();
            detail.put("printNumber","1");
            detail.put("status",""+printStatus);
            detail.put("time",DateUtil.getCurrentTime());
            detail.put("errorMsg",errorMsg);
            List<JSONObject> details = new ArrayList<>(1);
            details.add(detail);
            String detailStr = JSON.toJSONString(details);
            contents.put("fsTaskDetail",detailStr);

            PrintConnector.getInstance().updateTask(request.Device, printNo, contents.toJSONString());
        }
        return response;
    }
}
