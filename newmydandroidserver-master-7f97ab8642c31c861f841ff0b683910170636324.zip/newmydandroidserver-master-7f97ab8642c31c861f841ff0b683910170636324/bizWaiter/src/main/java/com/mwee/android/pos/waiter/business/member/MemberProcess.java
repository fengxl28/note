package com.mwee.android.pos.waiter.business.member;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberBalanceChangedListRequest;
import com.mwee.android.pos.business.member.MemberBalanceChangedResponse;
import com.mwee.android.pos.business.member.MemberCouponRequest;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.business.member.entity.BalanceOrder;
import com.mwee.android.pos.business.member.entity.Coupon;
import com.mwee.android.pos.component.member.net.MemberHistoryScoreSearchRequest;
import com.mwee.android.pos.component.member.net.MemberHistoryScoreSearchResponse;
import com.mwee.android.pos.component.member.net.model.MemberHistoryScoreModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Created by liuxiuxiu on 2017/9/1.
 */

public class MemberProcess {


    /**
     * 查询会员积分记录信息
     *
     * @param card_no
     * @param last_id
     * @param iResponse
     */
    public static void gotMemberHistoryScore(String card_no, final int last_id, final IResponse<List<MemberHistoryScoreModel>> iResponse) {
        MemberHistoryScoreSearchRequest historyScoreSearchRequest = new MemberHistoryScoreSearchRequest();
        historyScoreSearchRequest.card_no = card_no;
        historyScoreSearchRequest.last_id = last_id;
        historyScoreSearchRequest.pagesize = 20;
        BusinessExecutor.execute(historyScoreSearchRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberHistoryScoreSearchResponse) {
                    MemberHistoryScoreSearchResponse historyScoreSearchResponse = (MemberHistoryScoreSearchResponse) responseData.responseBean;
                    if (iResponse != null) {
                        iResponse.callBack(true, (historyScoreSearchResponse.data.havenext), "获取数据成功", historyScoreSearchResponse.data.list);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, -1, "获取数据异常", null);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (iResponse != null) {
                    if (responseData != null && responseData.resultMessage != null) {
                        iResponse.callBack(false, -2, responseData.resultMessage, null);
                    } else {
                        iResponse.callBack(false, -2, "获取数据异常", null);
                    }
                }

                return false;
            }
        }, null, false);
    }

    /**
     * 查询会员储值记录信息
     *
     * @param card_no
     * @param last_id
     * @param iResponse
     */
    public static void gotMemberBalance(String card_no, final String last_id, final IResponse<List<BalanceOrder>> iResponse) {
        MemberBalanceChangedListRequest request = new MemberBalanceChangedListRequest();
        request.card_no = card_no;
        request.last_id = last_id;
        request.limit = 20;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");

                if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceChangedResponse) {
                    MemberBalanceChangedResponse responseBean = (MemberBalanceChangedResponse) responseData.responseBean;
                    if (iResponse != null) {
                        iResponse.callBack(true, responseBean.data.havenext, "成功", responseBean.data.list);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, -1, "获取数据异常", null);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (iResponse != null) {
                    if (responseData != null && responseData.resultMessage != null) {
                        iResponse.callBack(false, -2, responseData.resultMessage, null);
                    } else {
                        iResponse.callBack(false, -2, "获取数据异常", null);
                    }
                }

                return false;
            }
        }, null, false);
    }

    /**
     * 查询会员优惠券记录信息
     *
     * @param card_no
     * @param iResponse
     */
    public static void gotMemberCoupon(String card_no, final IResponse<List<Coupon>> iResponse) {
        MemberCouponRequest request = new MemberCouponRequest();
        request.card_no = card_no;
        request.page = 1;
        request.shopid = StringUtil.toInt(DBMetaUtil.getSettingsValueByKey(META.SHOPID), 0);
        String fsCompanyGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsShopGUID = '" + request.shopid + "'");
        request.m_shopid = StringUtil.toInt(fsCompanyGUID);
        request.pageSize = 1000;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberCouponResponse) {
                    MemberCouponResponse responseBean = (MemberCouponResponse) responseData.responseBean;
                    Coupon[] objs = new Coupon[responseBean.data.list.size()];
                    objs = responseBean.data.list.toArray(objs);
                    Arrays.sort(objs, new Comparator<Coupon>() {
                        @Override
                        public int compare(Coupon o1, Coupon o2) {
                            return o1.c_type.compareTo(o2.c_type);
                        }
                    });
                    ArrayList<Coupon> coupons = new ArrayList<>();
                    for (int i = 0; i < objs.length; i++) {
                        coupons.add(objs[i]);
                    }

                    if (iResponse != null) {
                        iResponse.callBack(true, 1, "成功", coupons);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, -1, "获取数据异常", null);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (iResponse != null) {
                    if (responseData != null && responseData.resultMessage != null) {
                        iResponse.callBack(false, -2, responseData.resultMessage, null);
                    } else {
                        iResponse.callBack(false, -2, "获取数据异常", null);
                    }
                }

                return false;
            }
        }, null, false);
    }
}
