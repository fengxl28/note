package com.mwee.android.pos.waiter.business;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.util.FormatUtil;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.server.WaiterResult;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

/**
 * 美小二的相关的业务处理类
 * Created by virgil on 2017/1/17.
 */

public class WaiterBizUtil {
    /**
     * 是否可以操作订单。
     * 如果不能操作订单，则返回错误信息
     *
     * @param fssellno String | 订单号
     * @return String
     */
    public static String canOpertaOrder(String fssellno) {
        JSONObject info = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsMTableId,fiBillStatus from tbsell where fssellno='" + fssellno + "'");
        String order_status = info.getString("fiBillStatus");
        String tableID = info.getString("fsMTableId");
        if (TextUtils.isEmpty(order_status)) {
            return "订单号不存在";
        }
        int orderStatusInt = StringUtil.toInt(order_status, 0);
        if (orderStatusInt == OrderStatus.ANTI_PAIED) {
            return "订单正在反结账";
        }
        if (orderStatusInt == OrderStatus.PAIED) {
            return "订单已结账";
        }
        if (orderStatusInt == OrderStatus.CANCEL) {
            return "订单已取消";
        }
        String tableOrderID = TableBusinessUtil.getOrderIDByTableID(tableID);

        if (!TextUtils.equals(tableOrderID, fssellno)) {
            if (tableID.contains("_")) {
                tableID = FormatUtil.restoreTableID(tableID);
                tableOrderID = TableBusinessUtil.getOrderIDByTableID(tableID);
                if (!TextUtils.equals(tableOrderID, fssellno)) {
                    return "订单已发生变化，请重新开台";
                }
            } else {
                return "订单已发生变化，请重新开台";
            }
        }
        return "";
    }

    public static WaiterResponse checkCanPay(String orderToken,boolean checkToken, String fssellno, UserDBModel userDBModel) {
        WaiterResponse response = new WaiterResponse();

        final OrderCache order = OrderSession.getInstance().getOrder(fssellno);
        if (order == null) {
            WaiterBizUtil.buildErrorRepsone(response, "[" + fssellno + "]订单号不存在");
            return response;
        }
        //检查桌台是否被锁定
        String erroInfo = TableBusinessUtil.checkTableLock(HostBiz.mealorder, userDBModel.fsUserId, order.fsmtableid);
        if (!TextUtils.isEmpty(erroInfo)) {
            WaiterBizUtil.buildErrorRepsone(response, erroInfo);
            return response;
        }
        if(checkToken) {
            if (!WaiterBizUtil.checkOrderToken(fssellno, orderToken)) {
                WaiterBizUtil.buildIneffectivenessOrderToken(response);
                return response;
            }
        }
        String error = WaiterBizUtil.canOpertaOrder(fssellno);
        if (!TextUtils.isEmpty(error)) {
            WaiterBizUtil.buildErrorRepsone(response, error);
            return response;
        }
        String checkToPayMsg = order.checkToPay();
        if (!TextUtils.isEmpty(checkToPayMsg)) {
            WaiterBizUtil.buildErrorRepsone(response, checkToPayMsg);
            return response;
        }
        return response;
    }

    /**
     * 构建成功的Response
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    public static WaiterResponse buildSuccess(WaiterResponse response) {
        return buildRepsone(response, WaiterResult.SUCCESS, "数据异常");
    }

    /**
     * 构建出现异常的Response
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    public static WaiterResponse buildIlleagalRepsone(WaiterResponse response) {
        return buildErrorRepsone(response, "数据异常");
    }

    /**
     * 构建Token以过期的Response
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    public static WaiterResponse buildInvalidTokenlRepsone(WaiterResponse response) {
        return buildErrorRepsone(response, "此账号已在别的设备登录，请重新登录");
    }

    /**
     * 订单信息已发生变化，需要重新刷新
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    public static WaiterResponse buildExpiredOrderRepsone(WaiterResponse response) {
        return buildExpiredOrderRepsone(response, "订单已发生变化");
    }

    /**
     * 订单信息已发生变化，需要重新刷新
     *
     * @param response WaiterResponse
     * @param error    String | 提示文案
     * @return WaiterResponse
     */
    public static WaiterResponse buildExpiredOrderRepsone(WaiterResponse response, String error) {
        return buildRepsone(response, WaiterResult.ORDER_CHANGED, error);
    }

    /**
     * 此订单已被其他服务员操作，请刷新
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    public static WaiterResponse buildIneffectivenessOrderToken(WaiterResponse response) {
        return buildRepsone(response, WaiterResult.ORDER_TOKEN_EXPIRED, "此订单已被其他服务员操作，请刷新");
    }

    /**
     * 构建默认的错误的Response
     *
     * @param response
     * @param msg
     * @return
     */
    public static WaiterResponse buildErrorRepsone(WaiterResponse response, String msg) {
        return buildRepsone(response, WaiterResult.FAIL, msg);
    }

    /**
     * 构建已估清的Response
     *
     * @param response WaiterResponse
     * @param msg      String
     * @return WaiterResponse
     */
    public static WaiterResponse buildSellOutRepsone(WaiterResponse response, String msg) {
        return buildRepsone(response, WaiterResult.SELLOUT, msg);
    }

    /**
     * 构建功能暂不支持的Response
     *
     * @return WaiterResponse
     */
    public static WaiterResponse buildNotSupportRepsone() {
        return buildRepsone(new WaiterResponse(), WaiterResult.NOT_SUPPORT, "暂不支持");
    }

    public static WaiterResponse buildRepsone(WaiterResponse response, String code, String msg) {
        if (response == null) {
            response = new WaiterResponse();
        }
        response.Status = code;
        response.Error = msg;
        return response;
    }


    /**
     * 根据Token来获取服务员Model
     *
     * @param token String
     * @return UserDBModel
     */
    public static UserDBModel getUserByToken(String token) {
        return HostUtil.getUserModelBySession(token);
    }

    /**
     * 校验订单Token
     *
     * @param fsSellNo String | 订单号
     * @param request  WaiterRequest | 订单token
     *                 空token或者-1都认为是合法token
     * @return boolean
     */
    public static boolean verifyOrderTokenWithCreate(String fsSellNo, WaiterRequest request) {
        if (TextUtils.isEmpty(request.OrderToken) || TextUtils.equals("-1", request.OrderToken)) {
            request.OrderToken = ServerCache.getInstance().generateNewToken(fsSellNo);
            return true;
        } else if (ServerCache.getInstance().verifyToken(fsSellNo, request.OrderToken)) {
            return true;
        }
        return false;
    }

    /**
     * 校验订单Token
     *
     * @param fsSellNo   String | 订单号
     * @param orderToken String | 订单token
     *                   空token或者-1都认为是合法token
     * @return boolean
     */
    public static boolean checkOrderToken(String fsSellNo, String orderToken) {
        if (emptyToken(orderToken)) {
            return true;
        } else if (ServerCache.getInstance().verifyToken(fsSellNo, orderToken)) {
            return true;
        }
        return false;
    }

    /**
     * 空token
     *
     * @param orderToken
     * @return
     */
    public static boolean emptyToken(String orderToken) {
        if (TextUtils.isEmpty(orderToken) || TextUtils.equals("-1", orderToken)) {
            return true;
        }
        return false;
    }

    public static String optToken(String token, String fssellno) {
        if (emptyToken(token)) {
            return ServerCache.getInstance().generateNewToken(fssellno);
        }
        return token;
    }

}
