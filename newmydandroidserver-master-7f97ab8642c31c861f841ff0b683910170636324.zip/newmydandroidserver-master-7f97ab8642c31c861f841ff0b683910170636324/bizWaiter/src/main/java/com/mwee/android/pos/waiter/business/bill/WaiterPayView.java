package com.mwee.android.pos.waiter.business.bill;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.db.business.SellreceiveDBModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 返回给美小二的订单待支付信息
 * Created by virgil on 2017/9/8.
 */

public class WaiterPayView extends BusinessBean {
    /**
     * 订单号
     */
    public String fssellno = "";
    /**
     * 剩余待支付的金额
     */
    public BigDecimal amtLeftToPay = BigDecimal.ZERO;
    /**
     * 需要找零的金额
     */
    public BigDecimal amtNeedChange = BigDecimal.ZERO;
    /**
     * 剩余待支付金额中的可折扣的金额
     */
    public BigDecimal amtLeftCanDiscount = BigDecimal.ZERO;

    public List<SellreceiveDBModel> payTypeList = new ArrayList<>();

    /**
     * 是否免了服务费：1，免了；其他，没有免
     */
    public int freeServiceFee = 0;

    public WaiterPayView() {

    }
}
