package com.mwee.android.pos.waiter.business.getdata;

/**
 * Created by virgil on 2017/1/16.
 */

public class WaiterInvokGetData {


    public static Class getNameClass() {
        return NameGetData.class;
    }
}
