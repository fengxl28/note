package com.mwee.android.pos.waiter.business;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.waiter.basebean.WaiterRequest;
import com.mwee.android.pos.waiter.basebean.WaiterResponse;
import com.mwee.android.pos.waiter.business.bill.WaiterInvokBill;
import com.mwee.android.pos.waiter.business.getdata.WaiterInvokGetData;
import com.mwee.android.pos.waiter.business.login.WaiterInvokLogin;
import com.mwee.android.pos.waiter.business.member.WaiterInvokMember;
import com.mwee.android.pos.waiter.component.WaiterName;
import com.mwee.android.pos.waiter.server.WaiterResult;
import com.mwee.android.tools.DateUtil;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 业务分发
 * Created by virgil on 2017/1/16.
 */

public class WaiterBiz {
    /**
     * 缓存的登录的method集合
     */
    private static ArrayMap<String, Method> methodMapLogin = new ArrayMap<>();
    /**
     * 缓存的获取数据的method集合
     */
    private static ArrayMap<String, Method> methodMapDATA = new ArrayMap<>();
    /**
     * 缓存的结账的method集合
     */
    private static ArrayMap<String, Method> methodMapBILL = new ArrayMap<>();
    /**
     * 缓存的会员的method集合
     */
    private static ArrayMap<String, Method> methodMapMEMBER = new ArrayMap<>();

    /**
     * 根据{@link ServiceType}来进行业务分发
     *
     * @param request WaiterRequest
     * @return WaiterResponse
     */
    public static WaiterResponse invokBiz(WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        int status = HostUtil.getShopBizStatus();
        if (status == HostStatus.FINISH) {
            WaiterBizUtil.buildErrorRepsone(response, "门店尚未开始营业");
            processCommonResponse(response);
            return response;
        }

        // PAD V1.1 登录、数据同步不做用户 token 校验
        if (!TextUtils.equals(request.Service, ServiceType.LOGIN) &&
                !TextUtils.equals(request.Service, ServiceType.GET_DATA)) {
            if (!checkToken(request)) {
                WaiterBizUtil.buildInvalidTokenlRepsone(response);
                processCommonResponse(response);
                return response;
            }
        }
        switch (request.Service) {
            case ServiceType.LOGIN:
                response = invokBiz(methodMapLogin, WaiterInvokLogin.getNameClass(), request);
                break;
            case ServiceType.GET_DATA:
                response = invokBiz(methodMapDATA, WaiterInvokGetData.getNameClass(), request);
                break;
            case ServiceType.BILL:
                response = invokBiz(methodMapBILL, WaiterInvokBill.getNameClass(), request);
                break;
            case ServiceType.MEMBER:
                response = invokBiz(methodMapMEMBER, WaiterInvokMember.getNameClass(), request);
                break;
        }

        processCommonResponse(response);
        return response;
    }

    /**
     * 处理WaiterResponse中的公用字段
     *
     * @param response WaiterResponse
     * @return WaiterResponse
     */
    private static WaiterResponse processCommonResponse(WaiterResponse response) {
        if (response == null) {
            response = new WaiterResponse();
        }
        response.ServiceTime = DateUtil.getCurrentTime();
        if (TextUtils.isEmpty(response.Status)) {
            response.Status = WaiterResult.SUCCESS;
        }
        response.BuildVersion = BizConstant.VERSION_CODE;
        response.Version = BizConstant.VERSION_NAME;
        return response;
    }

    /**
     * 判断Token是否有效
     *
     * @param request WaiterRequest
     * @return boolean | true：token有效；false：token无效
     */
    private static boolean checkToken(WaiterRequest request) {
        if (request == null) {
            return false;
        }
        if (TextUtils.isEmpty(request.Token)) {
            return false;
        }
        return HostUtil.sessionInvalid(request.Token);
    }

    /**
     * 反射执行所有的方法
     *
     * @param methodMap ArrayMap<String, Method>
     * @param cls       Class
     * @param request   WaiterRequest
     * @return WaiterResponse
     */
    private static WaiterResponse invokBiz(ArrayMap<String, Method> methodMap, Class cls, WaiterRequest request) {
        WaiterResponse response = new WaiterResponse();
        Method method = methodMap.get(request.Name);
        if (method == null) {
            Method[] methods = cls.getDeclaredMethods();
            if (methods != null && methods.length > 0) {
                for (Method temp : methods) {
                    temp.setAccessible(true);
                    WaiterName anno = temp.getAnnotation(WaiterName.class);
                    if (anno == null) {
                        continue;
                    }
                    if (TextUtils.equals(anno.value(), request.Name)) {
                        methodMap.put(anno.value(), temp);
                        method = temp;
                    }
                }
            }
        }
        try {
            if (method == null) {
                WaiterBizUtil.buildErrorRepsone(response, "无此接口");
                return null;
            }
            Object result = method.invoke(cls, request);
            if (result == null) {
                return null;
            } else {
                response = (WaiterResponse) result;
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return response;
    }
}
