package com.mwee.android.pos.queue.server;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.NameConstant;
import com.mwee.android.pos.businesscenter.socket.SocketServer;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SerializeUtil;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketRequest;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.queue.R;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SafeUtil;
import com.mwee.android.tools.LogUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @ClassName: QueueServer
 * @Description:
 * @author: SugarT
 * @date: 2018/10/9 下午7:48
 */
public class QueueServer implements IDriver {

    public static final String TAG = "QueueServer";

    public static final String DRIVER_TAG = "queue_server";

    private static final int headerLength = 4;

    private static List<ServerThread> mServerThreads = new ArrayList<>();

    private static String mShopId;

    private volatile static QueueServer instance;

    private QueueServer() {
        QueueConfig.PORT_LIST = GlobalCache.getContext().getResources().getIntArray(R.array.port_list);

        String[] ignoreSession = GlobalCache.getContext().getResources().getStringArray(R.array.ignore_session);
        QueueConfig.URI_IGNORE_SESSION = new ArrayList<>();
        Collections.addAll(QueueConfig.URI_IGNORE_SESSION, ignoreSession);
        LogUtil.logBusiness("Queue", "初始化排队服务配置。\n端口: " + JSON.toJSONString(QueueConfig.PORT_LIST));
    }

    public static QueueServer getInstance() {
        if (instance == null) {
            synchronized (QueueServer.class) {
                if (instance == null) {
                    instance = new QueueServer();
                }
            }
        }
        return instance;
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    public void init() {
        DriverBus.registerDriver(this);
        checkAlive();
    }

    public void reInit() {
        if (mServerThreads != null && !mServerThreads.isEmpty()) {
            try {
                for (int i = 0; i < mServerThreads.size(); i++) {
                    ServerThread temp = mServerThreads.get(i);
                    temp.disconnect();
                    temp.finish();
                    temp.interrupt();
                    mServerThreads.remove(i);
                    i--;
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                checkAlive();
            }
        }
    }

    /**
     * 服务器停止监听
     */
    @DrivenMethod(uri = DRIVER_TAG + "/finishServer")
    public void finishServer() {
        try {
            if (!ListUtil.isEmpty(mServerThreads)) {
                for (int i = 0; i < mServerThreads.size(); i++) {
                    ServerThread temp = mServerThreads.get(i);
                    temp.disconnect();
                    temp.finish();
                    temp.interrupt();
                    mServerThreads.remove(i);
                    i--;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DrivenMethod(uri = DRIVER_TAG + "/checkAlive")
    public void checkAlive() {
        if (!BindProcessor.isActived()) {
            RunTimeLog.addLog(RunTimeLog.SYS_QUEUE_SERVER, "门店未激活，不启用排队服务");
            return;
        }
        if (!DBMetaUtil.startQueueServer()) {
            RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, "排队服务开关关闭，不启用排队服务");
            return;
        }
        if (ListUtil.listIsEmpty(mServerThreads)) {
            for (int i = 0; i < QueueConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = new ServerThread(QueueConfig.PORT_LIST[i]);
                serverThread.start();
                mServerThreads.add(serverThread);
            }
        } else {
            for (int i = 0; i < QueueConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = mServerThreads.get(i);
                boolean alive = true;
                if (serverThread.finish || !serverThread.isAlive() || serverThread.isInterrupted()) {
                    alive = false;
                    try {
                        serverThread.interrupt();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (!alive) {
                    serverThread = new ServerThread(QueueConfig.PORT_LIST[i]);
                    serverThread.start();
                    mServerThreads.set(i, serverThread);
                }
            }
        }
    }

    private static String getShopID() {
        if (TextUtils.isEmpty(mShopId)) {
            mShopId = HostUtil.getShopID();
        }
        return mShopId;
    }

    private static class ServerThread extends Thread {

        public volatile boolean finish = false;
        int retryTimes = 0;
        private int socketPort;
        private ServerSocket mServer;
        private Socket mSocket;

        private ServerThread(int port) {
            socketPort = port;
            setDaemon(false);
            retryTimes = 0;
        }

        @Override
        public void run() {
            connect();
        }

        public void finish() {
            finish = true;
        }

        /**
         * 连接
         */
        private void connect() {
            try {
                if (BindProcessor.isActived() && !BindProcessor.isCurrentHostMain()) {
                    finish();
                    return;
                }
                LogUtil.logBusiness("Queue", "初始化排队服务开始监听端口: " + socketPort);
                mServer = new ServerSocket();
                mServer.setReuseAddress(true);
                mServer.bind(new InetSocketAddress(socketPort));
                while (true) {
                    if (finish) {
                        break;
                    }

                    mSocket = mServer.accept();
                    mSocket.setKeepAlive(false);
                    ClientHandler client = new ClientHandler(mSocket);
                    SocketServer.pushTask(client);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                disconnect();
                if (!finish) {
                    if (retryTimes++ < 10) {
                        try {
                            Thread.sleep(10 * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        connect();
                    } else {
                        if (retryTimes++ > (SocketConfig.SERVER_MAX_RETRY_TIMES + 3)) {
                            finish();
                        } else {
                            try {
                                Thread.sleep(60 * 1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            connect();
                        }
                    }
                }
            }
        }

        /**
         * 断开连接
         */
        private void disconnect() {
            try {
                if (mServer != null) {
                    mServer.close();
                    mServer = null;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Client处理线程
     */
    private static class ClientHandler implements Runnable {
        private Socket socket;

        private InputStream mReader;
        private OutputStream mWriter;

        ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            mWriter = socket.getOutputStream();
            mReader = socket.getInputStream();
        }

        @Override
        public void run() {
            LogUtil.log(TAG + " " + String.format("开始监听客户端: %s", socket.getRemoteSocketAddress()));
            SocketResponse res;
            String requestId = "";
            try {
                String strRequest;

                byte[] header = new byte[4];
                int readCount = mReader.read(header, 0, 4);
                if (readCount <= 0) {
                    sendResponse(buildErrorResponse(SocketResultCode.DESERIALIZE_FAILED));
                    return;
                }
                int totalLength = SerializeUtil.bytesToInteger(header);
                if (totalLength >= 50000000) {
                    sendResponse(buildErrorResponse(SocketResultCode.DESERIALIZE_FAILED));
                    return;
                }
                byte[] content = new byte[totalLength];
                int totalReadCount = 0;
                while (totalLength > 0) {
                    readCount = mReader.read(content, totalReadCount, totalLength);
                    totalReadCount += readCount;
                    totalLength = totalLength - readCount;
                }
                strRequest = new String(content);
                LogUtil.logOnlineDebug(TAG + " receive request: " + strRequest);

                SocketRequest request = JSON.parseObject(strRequest, SocketRequest.class);
                SocketHeader head = request.head;
                int filterError = doFilter(request);
                if (filterError != SocketResultCode.SUCCESS) {
                    sendResponse(buildErrorResponse(filterError));
                    RunTimeLog.addLog(RunTimeLog.SOCKET_REQUEST, "request refused, close socket connection");
                    return;
                }

                String userSession = head.us;
                if (!QueueConfig.URI_IGNORE_SESSION.contains(request.uri)) {
                    if (TextUtils.isEmpty(userSession)) {
                        sendResponse(buildErrorResponse(SocketResultCode.USER_SESSION_EXPIRED));
                        return;
                    }
                    String session = HostUtil.getQueueByDeviceId(head.device);
                    if (!TextUtils.isEmpty(session) && !TextUtils.equals(session, userSession)) {
                        sendResponse(buildErrorResponse(SocketResultCode.USER_SESSION_EXPIRED));
                        return;
                    }
                }
                requestId = request.head.requestId;
                Object obj;
                if (TextUtils.isEmpty(request.params)) {
                    obj = DriverBus.call(request.uri, request.head);
                } else {
                    obj = DriverBus.call(request.uri, request.head, request.params);
                }

                if (obj != null && obj instanceof SocketResponse) {
                    res = (SocketResponse) obj;
                } else {
                    res = new SocketResponse();
                    res.code = SocketResultCode.EXCEPTION;
                }
                res.head = head;
                sendResponse(res);
            } catch (JSONException e) {
                LogUtil.logError(e);
                res = new SocketResponse();
                res.code = SocketResultCode.DESERIALIZE_FAILED;
                sendResponse(res);
            } catch (Exception e) {
                LogUtil.logError(e);
                sendResponse(buildExceptionResponse());

            } catch (Error e) {
                LogUtil.logError(e);
                sendResponse(buildExceptionResponse());
            } finally {
                disconnect();
            }
        }

        private SocketResponse buildExceptionResponse() {
            return buildExceptionResponse("");
        }

        private SocketResponse buildExceptionResponse(String msg) {
            return buildErrorResponse(SocketResultCode.EXCEPTION, msg);
        }

        private SocketResponse buildErrorResponse(int code) {
            return buildErrorResponse(code, "");
        }

        private SocketResponse buildErrorResponse(int code, String msg) {
            SocketResponse res = new SocketResponse();
            res.code = code;
            res.message = msg;
            return res;
        }

        private void sendResponse(SocketResponse res) {
            sendResponse(res, false);
        }

        private void sendResponse(SocketResponse res, boolean encrypt) {
            if (res == null) {
                res = buildExceptionResponse();
            }
            res.buildMessage();

            try {
                String info = JSON.toJSONString(res, SerializerFeature.DisableCircularReferenceDetect);
                LogUtil.logOnlineDebug(TAG + " sendResponse " + info);

                if (encrypt) {
                    info = SafeUtil.encrypt(NameConstant.PWD_HOST_CON, NameConstant.PWD_IV, info);
                }
                byte[] infoByte = info.getBytes();
                byte[] requestHeader = SerializeUtil.integerToBytes(infoByte.length, 4);

                mWriter.write(requestHeader);
                mWriter.write(infoByte);
                mWriter.flush();
            } catch (Exception e) {
                LogUtil.logError(e);
            } catch (Error e) {
                LogUtil.logError(e);
            }
        }

        private int doFilter(SocketRequest request) {
            SocketHeader headers = request.head;
            if (headers == null) {
                RunTimeLog.addLog(RunTimeLog.SOCKET, "request header is empty");
                return SocketResultCode.SUCCESS;
            }

            String localShopID = getShopID();
            if (!TextUtils.isEmpty(localShopID) && !TextUtils.equals(localShopID, headers.shopid)) {
                RunTimeLog.addLog(RunTimeLog.SOCKET, " shopId from request: " + headers.shopid + ", from center: " + localShopID);
                return SocketResultCode.WRONG_SHOP;
            }

            return SocketResultCode.SUCCESS;
        }

        /**
         * 断开连接
         */
        private void disconnect() {
            try {
                if (mWriter != null) {
                    mWriter.close();
                    mWriter = null;
                }
                if (mReader != null) {
                    mReader.close();
                    mReader = null;
                }
                if (socket != null) {
                    socket.close();
                    socket = null;
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }
}