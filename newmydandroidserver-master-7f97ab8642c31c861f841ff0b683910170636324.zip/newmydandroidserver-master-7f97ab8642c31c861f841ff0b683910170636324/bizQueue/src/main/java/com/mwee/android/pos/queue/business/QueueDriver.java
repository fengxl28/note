package com.mwee.android.pos.queue.business;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintTableUtil;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.table.TableProcessor;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.queue.business.bean.QTableBizDBModel;
import com.mwee.android.pos.queue.business.bean.QTableBizExtModel;
import com.mwee.android.pos.queue.business.bean.QTableBizModel;
import com.mwee.android.pos.queue.business.bean.QTableModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: QueueDriver
 * @Description: 排队服务
 * @author: SugarT
 * @date: 2018/10/10 下午4:17
 */
public class QueueDriver implements IDriver {

    public static final String TAG = "queue";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019186'>登录</a>
     *
     * @param head
     * @return
     */
    @DrivenMethod(uri = TAG + "/login")
    public SocketResponse login(SocketHeader head) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            String deviceId = head.requestId;
            if (TextUtils.isEmpty(deviceId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "设备信息不能为空";
                return socketResponse;
            }

            if (HostUtil.isShopFinished()) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "门店尚未开业";
                return socketResponse;
            }

            JSONObject data = new JSONObject();
            data.put("token", HostUtil.loginQueue(deviceId));

            socketResponse.message = "登录成功";
            socketResponse.data = data;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "登录失败";
        }
        return socketResponse;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019191'>获取桌台配置</a>
     *
     * @param head
     * @return
     */
    @DrivenMethod(uri = TAG + "/getAllTable")
    public SocketResponse getAllTable(SocketHeader head) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            String sql = "SELECT fsMTableId AS tableId, fsMTableName AS tableName, fiSeats AS capacityMin, fiSeats AS capacityMax, fiStatus FROM tbmtable WHERE fiStatus IN ('1', '2') AND fsmareaid NOT IN (SELECT fsmareaid FROM tbmarea WHERE fiStatus <> '1')";
            List<QTableModel> result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, QTableModel.class);

            socketResponse.message = "查询成功";
            socketResponse.data = result;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "查询失败";
        }
        return socketResponse;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019219'>获取指定桌台配置</a>
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getTableById")
    public SocketResponse getTableById(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String tableId = request.getString("tableId");

            if (TextUtils.isEmpty(tableId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "桌台不能为空";
                return socketResponse;
            }

            String sql = "SELECT fsMTableId AS tableId, fsMTableName AS tableName, fiSeats AS capacityMin, fiSeats AS capacityMax, fiStatus FROM tbmtable WHERE fsMTableId = '" + tableId + "'";
            QTableModel result = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, QTableModel.class);

            socketResponse.message = "查询成功";
            socketResponse.data = result;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "查询失败";
        }
        return socketResponse;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019193'>获取桌台状态列表</a>
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getTableBiz")
    public SocketResponse getTableBiz(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int bizStatus = request.getInteger("bizStatus");

            JSONObject data = new JSONObject();

            switch (bizStatus) {
                case 1:
                    // 空闲
                    data.put("unusable", buildIdle());
                    break;
                case 2:
                    // 非空闲
                    data.put("usable", buildOpened());
                    break;
                case 3:
                    // 即将空闲
                    data.put("beFree", buildCheck());
                    break;
                case 4:
                    // 占用
                    data.put("occupy", buildOccupy());
                    break;
                case 0:
                    // 全部状态
                default:
                    data.put("unusable", buildIdle());
                    data.put("usable", buildOpened());
                    data.put("beFree", buildCheck());
                    data.put("occupy", buildOccupy());
                    break;
            }

            socketResponse.message = "查询成功";
            socketResponse.data = data;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "查询失败";
        }
        return socketResponse;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019211'>获取指定桌台状态</a>
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getTableBizById")
    public SocketResponse getTableBizById(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String tableId = request.getString("tableId");

            if (TextUtils.isEmpty(tableId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "桌台不能为空";
                return socketResponse;
            }

            QTableBizExtModel bizExtModel = new QTableBizExtModel();

            QTableBizModel result = new QTableBizModel();
            result.tableId = tableId;
            result.ext_info = new ArrayList<>();
            result.ext_info.add(bizExtModel);

            socketResponse.message = "查询成功";
            socketResponse.data = result;

            TableBizModel tableBizModel = TableDBUtil.getTableBizModelById(tableId);
            if (tableBizModel != null) {
                switch (tableBizModel.fsmtablesteid) {
                    case TableConstans.TABLE_STATUS_FREE:
                        bizExtModel.status = QTableStatus.IDLE;
                        break;
                    case TableConstans.TABLE_STATUS_OPEN:
                    case TableConstans.TABLE_STATUS_BUSY:
                        if (TextUtils.isEmpty(tableBizModel.fssellno)) {
                            bizExtModel.status = QTableStatus.IDLE;
                        } else {
                            String sql = "SELECT count(*) FROM tbSellReceive WHERE fssellno = '" + tableBizModel.fssellno + "' AND fiStatus <> '13' AND isCouponMoney <> '1'";
                            String hasPayInfo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                            if (StringUtil.toInt(hasPayInfo, 0) > 0) {
                                bizExtModel.status = QTableStatus.CHECKED_OUT;
                            } else if (tableBizModel.fioccupyflag == TableStatusBean.PRINT_COMPLETE) {
                                bizExtModel.status = QTableStatus.PRINTED;
                            } else {
                                bizExtModel.status = QTableStatus.OPENED;
                            }

                            String sqlNumber = "SELECT value, createtime FROM datacache WHERE type = '" + IOCache.TYPE_QUEUE_OPEN_TABLE + "' AND key = '" + tableBizModel.fssellno + "'";
                            JSONObject jsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sqlNumber);
                            if (jsonObject != null) {
                                bizExtModel.number = jsonObject.getString("value");
                                bizExtModel.create_time = jsonObject.getString("createtime");
                            }
                        }
                        break;
                    case TableConstans.TABLE_STATUS_RESERVATION:
                        bizExtModel.status = QTableStatus.RESERVED;
                        break;
                    case TableConstans.TABLE_STATUS_INVALID:
                        bizExtModel.status = QTableStatus.DISABLE;
                        break;
                    default:
                        bizExtModel.status = QTableStatus.IDLE;
                        break;
                }
            } else {
                bizExtModel.status = QTableStatus.IDLE;
            }

            if (TableBusinessUtil.getLockedTableIDList().contains(tableId)) {
                bizExtModel.status = QTableStatus.TABLE_LOCK;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "查询失败";
        }
        return socketResponse;
    }

    /**
     * <a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23019195'>开台</a>
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/openTable")
    public SocketResponse openTable(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            String queueNumber = request.getString("queueNumber");
            if (TextUtils.isEmpty(queueNumber)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "排队单号为空";
                return socketResponse;
            }

            JSONArray info = request.getJSONArray("table");
            if (ListUtil.isEmpty(info)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "开台信息为空";
                return socketResponse;
            }

            // 排队开台使用云收银账号、业务中心站点
            UserDBModel userDBModel = RapidBiz.getCloudUser();
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "未查询到云收银账号";
                return socketResponse;
            }

            // 餐段
            String fsmsectionid = OrderUtil.getSectionId();

            // 已开台的订单
            List<QTableBizModel> data = new ArrayList<>();

            List<JSONObject> infoArr = info.toJavaList(JSONObject.class);
            for (JSONObject object : infoArr) {

                String fsmtableid = object.getString("tableId");
                int fiCustsum = object.getInteger("personNum");

                if (queueOpenTable(socketResponse, queueNumber, userDBModel, fsmsectionid, data, fsmtableid, fiCustsum)) {
                    return socketResponse;
                }
            }

            JSONObject result = new JSONObject();
            result.put("tables", data);

            socketResponse.message = "开台成功";
            socketResponse.data = result;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "开台失败";
        }
        return socketResponse;
    }

    /**
     * 排队开台
     *
     * @param socketResponse
     * @param queueNumber
     * @param userDBModel
     * @param fsmsectionid
     * @param data
     * @param fsmtableid
     * @param fiCustsum
     * @return
     */
    private boolean queueOpenTable(SocketResponse socketResponse, String queueNumber, UserDBModel userDBModel, String fsmsectionid, List<QTableBizModel> data, String fsmtableid, int fiCustsum) {
        if (fiCustsum <= 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "顾客人数不正确，请重新选择";
            return true;
        }

        MtableDBModel mtableDBModel = TableDBUtil.getMTableById(fsmtableid);
        if (mtableDBModel == null) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "无此桌台";
            return true;
        }

        String error = TableBusinessUtil.checkTableLock(HostBiz.cloudsite, userDBModel.fsUserId, fsmtableid);
        if (!TextUtils.isEmpty(error)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = error;
            return true;
        }

        final String finalTableId = fsmtableid;

        String orderId = "";
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(finalTableId, "", " 开台 ");
        try {
            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(fsmtableid);

            if ((!TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid)) || !TextUtils.isEmpty(tableBizModel.fssellno)) {
                // 如果已有订单，则认为是拼桌开台
                mtableDBModel = TableBusinessUtil.shareTable(fsmtableid, userDBModel);
                if (mtableDBModel == null) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "没有查到该桌台";
                    return true;
                }
                fsmtableid = mtableDBModel.fsmtableid;
            }

            OrderCache orderCache = OrderDriver.generateNewOrder();
            orderId = orderCache.orderID;
            buildQueueOrderCache(userDBModel, fsmsectionid, fiCustsum, mtableDBModel, orderId, orderCache);
            TableProcessor.openTableSuccess(orderCache);
            OrderSession.getInstance().writeOrder(orderId, orderCache, true, "QueueDriver queueOpenTable");
//            OrderProcessor.saveOrder(orderCache, null);
            String hostId = HostUtil.getCurrentHost();
            PrintTableUtil.openTableReport(orderCache, hostId);
            if (orderCache.originMenuList.size() > 0) {
                PrintOrderUtil.printMakeOrder(orderCache, hostId, orderCache.currentSeq - 1);
                PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.cloudsite);
                PrintOrderUtil.printPassTo(orderCache, hostId);
            }

            TableBusinessUtil.doOpenTable(new SocketResponse(), HostUtil.getCurrentHost(), fsmtableid, orderId, userDBModel, false, queueNumber);

            QTableBizDBModel bizModel = new QTableBizDBModel();
            bizModel.tableId = fsmtableid;
            bizModel.status = QTableStatus.OPENED;
            bizModel.number = queueNumber;
            bizModel.create_time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            data.add(bizModel.convert());
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, finalTableId, "", " 开台 ");
        }
        return false;
    }

    /**
     * 构建排队 OrderCache
     *
     * @param userDBModel   UserDBModel | 服务员
     * @param fsmsectionid  fsmsectionid | 餐段
     * @param fiCustsum     int | 人数
     * @param mtableDBModel MtableDBModel | 桌台
     * @param orderId       String | 订单号
     * @param orderCache    OrderCache | 已生成的订单
     */
    private void buildQueueOrderCache(UserDBModel userDBModel, String fsmsectionid, int fiCustsum, MtableDBModel mtableDBModel, String orderId, OrderCache orderCache) {
        orderCache.waiterID = userDBModel.fsUserId;
        orderCache.waiterName = userDBModel.fsUserName;
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = fsmsectionid;
        orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.fsmtableid = mtableDBModel.fsmtableid;
        orderCache.fsmtablename = mtableDBModel.fsmtablename;
        orderCache.fsmareaid = mtableDBModel.fsmareaid;
        orderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + mtableDBModel.fsmareaid + "'");
        orderCache.personNum = fiCustsum;
        orderCache.shopID = mtableDBModel.fsshopguid;
        orderCache.mealNumber = orderId.substring(8, 12);
        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.originMenuList.addAll(OrderBizUtil.getOpenParamOrderMenu(orderCache.fsmareaid, orderCache.personNum, orderCache.waiterID, orderCache.waiterName));
        if (orderCache.originMenuList.size() > 0) {
            for (MenuItem temp : orderCache.originMenuList) {
                temp.menuBiz.orderSeqID = orderCache.currentSeq;
                if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                    for (MenuItem modifier : temp.menuBiz.selectedModifier) {
                        modifier.menuBiz.orderSeqID = orderCache.currentSeq;
                    }
                }
            }
            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
            orderCache.currentSeq++;
        }
    }

    /**
     * 空闲
     * @return
     */
    private List<QTableBizModel> buildIdle() {
        String sql = "SELECT fsmtableid AS tableId, 100 AS status\n" +
                "FROM tbmtable\n" +
                "WHERE fiStatus IN ('1', '2')\n" +
                "  AND fsmareaid NOT IN (SELECT fsmareaid FROM tbmarea WHERE fiStatus <> '1')\n" +
                "  AND fsmtableid NOT IN (SELECT fsmtableid FROM tableBiz WHERE fsmtablesteid IN ('2', '3', '8', '9'))\n" +
                "  AND fsmtableid NOT IN (SELECT fsmtableid FROM tableBiz WHERE lockedStatus = '1')";
        List<QTableBizDBModel> bizDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, QTableBizDBModel.class);
        if (ListUtil.isEmpty(bizDBModelList)) {
            return null;
        }

        List<QTableBizModel> result = new ArrayList<>();
        for (QTableBizDBModel model : bizDBModelList) {
            if (model == null) {
                continue;
            }
            result.add(model.convert());
        }
        return result;
    }

    /**
     * 占用
     * @return
     */
    private List<QTableBizModel> buildOccupy() {
        String sql = "SELECT fsmtableid AS tableId, (CASE fsmtablesteid\n" +
                "                                 WHEN '8' THEN '400'\n" +
                "                                 WHEN '9' THEN '401'\n" +
                "                                 ELSE '400' END) AS status\n" +
                "FROM tableBiz\n" +
                "WHERE fsmtablesteid IN ('8', '9')";
        List<QTableBizDBModel> bizDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, QTableBizDBModel.class);
        if (ListUtil.isEmpty(bizDBModelList)) {
            bizDBModelList = new ArrayList<>();
        }

        // 锁桌桌台
        String sqlLock = "SELECT fsmtableid AS tableId, '403' AS status FROM tableBiz WHERE lockedStatus = '1'";
        List<QTableBizDBModel> lockList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlLock, QTableBizDBModel.class);
        if (!ListUtil.isEmpty(lockList)) {
            bizDBModelList.addAll(lockList);
        }

        List<QTableBizModel> result = new ArrayList<>();
        for (QTableBizDBModel model : bizDBModelList) {
            if (model == null) {
                continue;
            }
            result.add(model.convert());
        }
        return result;
    }

    /**
     * 非空闲
     * @return
     */
    private List<QTableBizModel> buildOpened() {
        String sql = "SELECT fsmtableid AS tableId, 200 AS status, fsopenhstime AS create_time, datacache.value AS number\n" +
                "FROM (SELECT IFNULL(payInfo.hasPayInfo, 0) hasPayInfo,\n" +
                "             tbsell.thirdOrderType,\n" +
                "             tbsell.fdExpAmt,\n" +
                "             tbsell.fiCustSum,\n" +
                "             tableBiz.*\n" +
                "      FROM tableBiz\n" +
                "             LEFT OUTER JOIN tbsell ON tableBiz.fssellno = tbsell.fssellno\n" +
                "             LEFT JOIN (SELECT fsSellNo, count(*) AS hasPayInfo\n" +
                "                        FROM tbSellReceive\n" +
                "                        WHERE fiStatus <> '13'\n" +
                "                          AND isCouponMoney <> '1'\n" +
                "                        GROUP BY fssellno) AS payInfo ON payInfo.fssellno = tbsell.fssellno\n" +
                "      WHERE fsmtablesteid IN ('2', '3')) m\n" +
                "       LEFT JOIN datacache ON m.fssellno = datacache.key\n" +
                "WHERE m.hasPayInfo = 0\n" +
                "  AND m.fioccupyflag IN ('0', '1')\n" +
                "  AND m.fsmtableid NOT IN (SELECT fsmtableid FROM tableBiz WHERE lockedStatus = '1');";
        List<QTableBizDBModel> bizDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, QTableBizDBModel.class);
        if (ListUtil.isEmpty(bizDBModelList)) {
            return null;
        }

        List<QTableBizModel> result = new ArrayList<>();
        for (QTableBizDBModel model : bizDBModelList) {
            if (model == null) {
                continue;
            }
            result.add(model.convert());
        }
        return result;
    }

    /**
     * 即将空闲
     * @return
     */
    private List<QTableBizModel> buildCheck() {
        String sql = "SELECT fsmtableid                                             AS tableId,\n" +
                "       (CASE fioccupyflag WHEN '2' THEN '301' ELSE '300' END) AS status,\n" +
                "       fsopenhstime                                           AS create_time,\n" +
                "       datacache.value                                        AS number\n" +
                "FROM (SELECT IFNULL(payInfo.hasPayInfo, 0) hasPayInfo,\n" +
                "             tbsell.thirdOrderType,\n" +
                "             tbsell.fdExpAmt,\n" +
                "             tbsell.fiCustSum,\n" +
                "             tableBiz.*\n" +
                "      FROM tableBiz\n" +
                "             LEFT OUTER JOIN tbsell ON tableBiz.fssellno = tbsell.fssellno\n" +
                "             LEFT JOIN (SELECT fsSellNo, count(*) AS hasPayInfo\n" +
                "                        FROM tbSellReceive\n" +
                "                        WHERE fiStatus <> '13'\n" +
                "                          AND isCouponMoney <> '1'\n" +
                "                        GROUP BY fssellno) AS payInfo ON payInfo.fssellno = tbsell.fssellno\n" +
                "      WHERE fsmtablesteid IN ('2', '3')) m\n" +
                "       LEFT JOIN datacache ON m.fssellno = datacache.key\n" +
                "WHERE (m.hasPayInfo > 0\n" +
                "  OR m.fioccupyflag IN ('2', '3', '4'))\n" +
                "  AND fsmtableid NOT IN (SELECT fsmtableid FROM tableBiz WHERE lockedStatus = '1');";
        List<QTableBizDBModel> bizDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, QTableBizDBModel.class);
        if (ListUtil.isEmpty(bizDBModelList)) {
            return null;
        }

        List<QTableBizModel> result = new ArrayList<>();
        for (QTableBizDBModel model : bizDBModelList) {
            if (model == null) {
                continue;
            }
            result.add(model.convert());
        }
        return result;
    }
}
