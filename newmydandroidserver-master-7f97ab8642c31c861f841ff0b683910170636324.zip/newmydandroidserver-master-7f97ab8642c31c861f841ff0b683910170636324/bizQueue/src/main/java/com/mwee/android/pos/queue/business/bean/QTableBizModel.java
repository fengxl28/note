package com.mwee.android.pos.queue.business.bean;

import com.mwee.android.base.net.BusinessBean;

import java.util.List;

/**
 * @ClassName: QTableBizModel
 * @Description:
 * @author: SugarT
 * @date: 2018/10/10 下午6:04
 */
public class QTableBizModel extends BusinessBean {

    /**
     * 桌台id
     */
    public String tableId = "";

    /**
     * 桌台相关业务信息
     */
    public List<QTableBizExtModel> ext_info = null;

    public QTableBizModel() {
    }
}
