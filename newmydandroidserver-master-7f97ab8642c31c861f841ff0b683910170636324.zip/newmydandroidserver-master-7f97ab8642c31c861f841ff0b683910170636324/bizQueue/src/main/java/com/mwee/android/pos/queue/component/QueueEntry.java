package com.mwee.android.pos.queue.component;

import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.queue.server.QueueServer;

/**
 * @ClassName: QueueEntry
 * @Description:
 * @author: SugarT
 * @date: 2018/10/10 下午3:56
 */
public class QueueEntry implements IDriver {

    public static final String DRIVER_TAG = "queueEntry";

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/init")
    public void init(){
        QueueServer.getInstance().init();
    }
}
