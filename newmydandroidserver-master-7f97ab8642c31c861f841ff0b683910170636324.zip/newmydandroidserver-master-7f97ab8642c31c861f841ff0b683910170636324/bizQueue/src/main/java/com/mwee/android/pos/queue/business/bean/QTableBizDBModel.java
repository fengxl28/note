package com.mwee.android.pos.queue.business.bean;

import com.mwee.android.pos.queue.business.QTableStatus;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.util.ArrayList;

/**
 * @ClassName: QTableBizDBModel
 * @Description:
 * @author: SugarT
 * @date: 2018/10/16 下午2:44
 */
public class QTableBizDBModel extends DBModel {

    /**
     * 桌台id
     */
    @ColumnInf(name = "tableId")
    public String tableId = "";

    /**
     * 桌台状态
     */
    @ColumnInf(name = "status")
    public @QTableStatus int status = QTableStatus.IDLE;

    /**
     * 开台时间
     */
    @ColumnInf(name = "create_time")
    public String create_time = "";

    /**
     * 排队单号
     */
    @ColumnInf(name = "number")
    public String number = "";

    public QTableBizDBModel() {
    }

    /**
     * DBModel 转化为业务 Bean
     *
     * @return
     */
    public QTableBizModel convert() {
        QTableBizExtModel model = new QTableBizExtModel();
        model.number = this.number;
        model.status = this.status;
        model.create_time = this.create_time;

        QTableBizModel result = new QTableBizModel();
        result.tableId = this.tableId;
        result.ext_info = new ArrayList<>();
        result.ext_info.add(model);
        return result;
    }
}
