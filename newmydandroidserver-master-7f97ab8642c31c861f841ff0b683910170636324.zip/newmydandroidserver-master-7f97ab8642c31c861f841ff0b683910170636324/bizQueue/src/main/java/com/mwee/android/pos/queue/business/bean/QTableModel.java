package com.mwee.android.pos.queue.business.bean;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * @ClassName: QTableModel
 * @Description:
 * @author: SugarT
 * @date: 2018/10/10 下午4:33
 */
public class QTableModel extends DBModel {

    /**
     * 桌台id
     */
    @ColumnInf(name = "tableId")
    public String tableId = "";

    /**
     * 桌台名称
     */
    @ColumnInf(name = "tableName")
    public String tableName = "";

    /**
     * 桌台最小容纳人数
     */
    @ColumnInf(name = "capacityMin")
    public int capacityMin = 0;

    /**
     * 桌台最大容纳人数
     */
    @ColumnInf(name = "capacityMax")
    public int capacityMax = 0;

    /**
     * 数据状态;1=正常 / 2=临时用(搭台、拆分餐单、反结…的＋1桌) / 9=禁用/ 13删除
     */
    @ColumnInf(name = "fiStatus")
    public int fiStatus = 0;

    /**
     * 附加信息
     */
    public String other = "";

    public QTableModel() {
    }
}
