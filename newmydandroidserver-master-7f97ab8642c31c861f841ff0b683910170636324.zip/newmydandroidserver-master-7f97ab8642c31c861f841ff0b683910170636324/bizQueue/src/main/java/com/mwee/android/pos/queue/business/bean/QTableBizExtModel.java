package com.mwee.android.pos.queue.business.bean;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.queue.business.QTableStatus;

/**
 * @ClassName: QTableBizExtModel
 * @Description:
 * @author: SugarT
 * @date: 2018/10/15 下午8:17
 */
public class QTableBizExtModel extends BusinessBean {

    /**
     * 排队单号
     */
    public String number = "";

    /**
     * 桌台状态
     */
    public @QTableStatus int status = QTableStatus.IDLE;

    /**
     * 预定手机号
     */
    public String reserve_phone = "";

    /**
     * 预定者名称
     */
    public String reserve_name = "";

    /**
     * 预定时间
     */
    public String reserve_time = "";

    /**
     * 开台时间
     */
    public String create_time = "";

    /**
     * 备注信息
     */
    public String remark = "";

    public QTableBizExtModel() {
    }
}
