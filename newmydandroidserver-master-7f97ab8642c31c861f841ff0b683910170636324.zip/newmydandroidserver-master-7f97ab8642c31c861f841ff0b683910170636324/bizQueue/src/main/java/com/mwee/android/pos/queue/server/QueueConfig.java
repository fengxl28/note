package com.mwee.android.pos.queue.server;

import java.util.List;

/**
 * @ClassName: QueueConfig
 * @Description:
 * @author: SugarT
 * @date: 2018/10/9 下午8:27
 */
public class QueueConfig {

    /**
     * 排队服务多端口监听
     */
    public static int[] PORT_LIST;

    /**
     * 忽略登录session的请求
     */
    public static List<String> URI_IGNORE_SESSION;
}
