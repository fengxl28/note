package com.mwee.android.pos.queue.business;

import android.support.annotation.IntDef;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static com.mwee.android.pos.queue.business.QTableStatus.CHECKED_OUT;
import static com.mwee.android.pos.queue.business.QTableStatus.DISABLE;
import static com.mwee.android.pos.queue.business.QTableStatus.IDLE;
import static com.mwee.android.pos.queue.business.QTableStatus.LOCKED;
import static com.mwee.android.pos.queue.business.QTableStatus.OPENED;
import static com.mwee.android.pos.queue.business.QTableStatus.PRINTED;
import static com.mwee.android.pos.queue.business.QTableStatus.RESERVED;
import static com.mwee.android.pos.queue.business.QTableStatus.TABLE_LOCK;

/**
 * @ClassName: QTableStatus
 * @Description: 排队桌台状态明细
 * @author: SugarT
 * @date: 2018/10/10 下午6:18
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@IntDef(value = {IDLE, OPENED, CHECKED_OUT, PRINTED, RESERVED, LOCKED, DISABLE, TABLE_LOCK})
public @interface QTableStatus {

    /**
     * 空闲
     */
    int IDLE = 100;

    /**
     * 已开台
     */
    int OPENED = 200;

    /**
     * 已结账
     */
    int CHECKED_OUT = 300;

    /**
     * 已打印
     */
    int PRINTED = 301;

    /**
     * 已预订
     */
    int RESERVED = 400;

    /**
     * 已锁桌
     */
    int LOCKED = 401;

    /**
     * 已停用
     */
    int DISABLE = 402;

    /**
     * 桌台锁桌
     */
    int TABLE_LOCK = 403;
}
