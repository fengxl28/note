package com.mwee.myd.server;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.annotation.Keep;
import android.support.annotation.WorkerThread;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.AppEnv;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.android.upgrade.callback.IUpgradeCallBack;
import com.mwee.android.upgrade.processor.UpgradeProcessor;
import com.mwee.plugin.PluginManger;
import com.mwee.plugin.PluginUtil;

import org.json.JSONObject;

import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 美易点的插件管理类
 * Created by virgil on 2018/3/8.
 *
 * @author virgil
 */

class MydPluginLoader {
    private final static String CLZ_PROXY = "com.mwee.myd.server.ServerProxy";
    private static volatile MydPluginLoader loader;
    private final int INTERVAL_LONG = 30 * 60 * 1000;
    private final int INTERVAL_SHORT = 30 * 1000;
    public Context context;
    private int interval = INTERVAL_LONG;
    private PluginManger pluginManger;
    /**
     * 插件加载结果
     */
    private volatile boolean pluginLoaded = false;
    private int currentPluginVersion = -1;
    private CountDownLatch initLock;
    private AppEnv env = null;
    private Object serverProxy = null;
    private Handler mainHandler;
    private Runnable pluginUpdater = new Runnable() {
        @Override
        public void run() {
            checkUpdate();
            //每30分钟检测一次
            mainHandler.postDelayed(pluginUpdater, interval);
        }
    };
    private Pattern p = Pattern.compile(".*Build([0-9-a-f-A-F]+)\\.apk", Pattern.CASE_INSENSITIVE);

    private MydPluginLoader(Context context) {
        this.context = context;
        pluginManger = new PluginManger(context, "MydServer");
        initLock = new CountDownLatch(1);
    }

    public static MydPluginLoader getInstance(Context context) {
        if (loader == null) {
            synchronized (MydPluginLoader.class) {
                if (loader == null) {
                    loader = new MydPluginLoader(context.getApplicationContext());
                }
            }
        }
        return loader;
    }

    protected void setMainHandler(Handler handler) {
        this.mainHandler = handler;
        //1分钟之后检测更新
        if (BaseConfig.isDEV()) {
            mainHandler.postDelayed(pluginUpdater, 40 * 1000);
        } else {
            mainHandler.postDelayed(pluginUpdater, 60 * 1000);
        }
    }

    private int getVersionCode(String path) {
        if (TextUtils.isEmpty(path)) {
            return -1;
        }
        Matcher m = p.matcher(path);
        if (m.find()) {
            return StringUtil.toInt(m.group(1));
        }
        return -1;
    }

    private void checkAssetPlugin() {
        //如果没有插件，则进行copy
        String pluginName = AssertUtil.readProperty(context, "plugin/path.properties", "path");
        if (TextUtils.isEmpty(pluginName)) {
            LogUtil.logBusiness("PluginInit", "读取path.properties失败");

            try {
                String[] fileList = context.getAssets().list("plugin");
                for (String temp : fileList) {
                    if (temp.contains("Build") || temp.contains("apk") || temp.contains("server")) {
                        LogUtil.logBusiness("PluginInit", "遍历assert目录找到路径[" + temp + "]");
                        pluginName = temp;
                        break;
                    }
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        String folderPluginPath = context.getCacheDir() + "/mydPlugin/";
        FileUtil.makeFolderPathSafe(context, folderPluginPath);
        File folderPlugin = new File(folderPluginPath);
        boolean contains = false;
        for (File temp : folderPlugin.listFiles()) {
            if (!temp.isFile()) {
                continue;
            }
            if (temp.length() > 20 && temp.getName().contains("Build") || temp.getName().contains("apk") || temp.getName().contains("server")) {
                contains = true;
                LogUtil.logBusiness("PluginInit", "遍历插件目录，检测到插件已存在[" + temp.getName() + "]");

                break;
            }
        }
        if (!contains || pluginManger.getCurrentPluginVersion() <= 0 || getVersionCode(pluginName) > pluginManger.getCurrentPluginVersion() || BaseConfig.isDEV()) {
            if (!TextUtils.isEmpty(pluginName)) {
                LogUtil.logBusiness("PluginInit", "从assets开始copy插件 " + pluginName);
                checkUpdate(true, true, PluginAppID.BASE);
                try {
                    String path = PluginUtil.copyAssetToPath(context, "plugin/" + pluginName, folderPluginPath);
                    int versionCode = PluginUtil.getApkVersionCode(context, path);
                    pluginManger.receiveNewPlugin(versionCode, path);
                } catch (Exception e) {
                    LogUtil.logBusiness("PluginInit-copy异常");
                    LogUtil.logError(e);

                }
            } else {
                LogUtil.logBusiness("PluginInit", "APK包内没有检测到插件 ");
            }
        } else {
            LogUtil.log("PluginInit", "不需要copy，版本号[" + pluginManger.getCurrentPluginVersion() + "] ");
        }
    }

    @WorkerThread
    protected void prepare() {
        LogUtil.logBusiness("PluginInit", "开始初始化");
        checkAssetPlugin();
        pluginManger.init();
        if (pluginManger.getCurrentPluginVersion() <= 0) {
            LogUtil.logBusiness("PluginInit", "内置插件异常，开始联网下载插件");
            checkUpdate(true, true, PluginAppID.BASE);
            delayReload();
        } else {
            LogUtil.logBusiness("PluginInit", "当前插件版本[" + pluginManger.getCurrentPluginVersion() + "]");
        }
    }


    private void forceFinish() {
        if (pluginLoaded) {
            invoke("forceFinish");
        }
    }

    private void killSelf() {
        AliHotFix.killSelf();
    }

    /**
     * 延迟加载插件
     */
    private synchronized void delayReload() {
        pluginLoaded = false;
        serverProxy = null;
        //重置插件的版本
        currentPluginVersion = -1;
        //延迟10秒重新加载
        new Handler(Looper.getMainLooper()).postDelayed(this::init, 10000);
    }

    /**
     * 杀进程重新激活
     */
    private synchronized void forceReActive() {
        forceFinish();
        LogUtil.logBusiness("MydPluginLoader", "杀进程");
        killSelf();
    }

    /**
     * 使用新插件
     */
    private synchronized void loadPlugin() {
        LogUtil.logBusiness("MydPluginLoader", "开始加载插件");

        //版本不一致，则进行卸载的操作
        if (serverProxy != null && currentPluginVersion > 0 && pluginManger.getCachedNewVersoion() >
                currentPluginVersion) {
            LogUtil.log("MydPluginLoader", "开始卸载旧插件");
            forceReActive();
            return;
        }

        int oldVersion = pluginManger.getCurrentPluginVersion();
        pluginManger.prepareToUseNewPlugin();
        currentPluginVersion = pluginManger.getCurrentPluginVersion();
        LogUtil.logBusiness("MydPluginLoader", "切换插件 currentVersion=[" + currentPluginVersion + "],oldVersion=[" + oldVersion + "]");

        if (pluginManger.loadPlugin() == 0) {
            if (active()) {
                LogUtil.logBusiness("MydPluginLoader", "插件加载成功");
            } else {
                LogUtil.logBusiness("MydPluginLoader", "插件激活失败");
                RunTimeLog.addLog(RunTimeLog.SYS_PLUGIN_FAILED, "插件生成代理类失败", String.valueOf(oldVersion),
                        currentPluginVersion);
                delayReload();
            }
        } else {
            LogUtil.logBusiness("MydPluginLoader", "插件加载失败");
            RunTimeLog.addLog(RunTimeLog.SYS_PLUGIN_FAILED, "插件加载失败", String.valueOf(oldVersion), currentPluginVersion);
            delayReload();
        }
    }

    private boolean active() {
        if (!createPluginProxy()) {
            return false;
        }
        if (env == null) {
            env = EnvUtil.buildEnv(context, pluginManger.getCurrentPluginPath());
        }
        try {
            if (env != null) {
                LogUtil.logBusiness("MydPluginLoader", "尝试激活业务中心");
                invoke(true, true, "work", context, MydPluginLoader.this, JSON.toJSONString(this.env));
                pluginLoaded = true;
                if (initLock != null) {
                    initLock.countDown();
                }
                LogUtil.logBusiness("MydPluginLoader", "激活业务中心成功");
                return true;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            LogUtil.logBusiness("MydPluginLoader", "业务中心激活失败");

        }
        return false;
    }

    @WorkerThread
    protected <T> T invoke(String method, Object... param) {
        try {
            return invoke(false, false, method, param);
        } catch (Exception e) {
            LogUtil.logError(e);
            return null;
        }
    }

    private void writeLog(String requestID, String request) {
        if (BaseConfig.isProduct()) {
            return;
        }
        CacheModel cacheModel = new CacheModel();
        cacheModel.key = requestID;
        cacheModel.value = String.valueOf(SystemClock.elapsedRealtime());
        cacheModel.type = IOCache.TYPE_PLUGIN_LOCK;
        cacheModel.biz_key = "";
        cacheModel.info = request;
        cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.updatetime = cacheModel.createtime;
//        cacheModel.replaceNoTrans();
        RunTimeLog.addLog(String.valueOf(IOCache.TYPE_PLUGIN_LOCK), JSON.toJSONString(cacheModel));
    }

    private void writeLogFinish(String requestID) {
        if (BaseConfig.isProduct()) {
            return;
        }
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update datacache set biz_key='" + SystemClock.elapsedRealtime() +
//                "' where key='" + requestID + "' and type='" + IOCache.TYPE_PLUGIN_LOCK + "'");
        RunTimeLog.addLog(String.valueOf(IOCache.TYPE_PLUGIN_LOCK), "Plugin - Key:" + requestID + ", BizKey:" + SystemClock.elapsedRealtime());
    }

    @SuppressWarnings("unchecked")
    @WorkerThread
    private <T> T invoke(boolean ignoreLock, boolean throwException, String method, Object... param) throws Exception {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            BusinessExecutor.executeNoWait(() -> {
                invoke(method, param);
                return null;
            });
            return null;
        }
        long key = SystemClock.elapsedRealtime();
        writeLog(String.valueOf(key), method);

        if (!ignoreLock) {
            if (initLock.getCount() > 0) {
                LogUtil.logBusiness("MydPluginLoader", "等待初始化完毕：" + method);

                try {
                    initLock.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        writeLogFinish(String.valueOf(key));

        if (serverProxy == null) {
            return null;
        }

        LogUtil.logBusiness("MydPluginLoader", "开始调用：" + method);

        try {
            if (param != null && param.length > 0) {
                return (T) pluginManger.invokeByObject(serverProxy, method, param);
            } else {
                return (T) pluginManger.invokeByObject(serverProxy, method);
            }
        } catch (Exception e) {
            LogUtil.logError("方法反射失败：" + method, e);

            RunTimeLog.addLog(RunTimeLog.SYS_PLUGIN_REFLECT_METHOD_FAILED, method, StringUtil.getExceptionInfo(e));
            if (throwException) {
                throw e;
            }
        }
        return null;
    }

    /**
     * 生产插件的代理类
     *
     * @return boolean | true: 生成成功；false：生成失败
     */
    private synchronized boolean createPluginProxy() {
        if (serverProxy == null) {
            try {
                serverProxy = pluginManger.reflectNewObject(CLZ_PROXY);
                return true;
            } catch (Exception e) {
                LogUtil.logBusiness("MydPluginLoader", "插件生成代理类失败");

                LogUtil.logError("类反射失败：", (e));
                RunTimeLog.addLog(RunTimeLog.SYS_PLUGIN_REFLECT_CLASS_FAILED, "插件反射类失败", StringUtil.getExceptionInfo
                        (e));
                //重置插件的版本
                pluginManger.resetPluginToOld();
                MwLog.writeToIONow();
            }
        }
        return false;
    }

    protected void checkUpdate() {
        checkUpdate(false, false, PluginAppID.BASE);
    }

    protected void checkUpdate(boolean forceLoadNew, boolean manualAppID, int appID) {
        currentPluginVersion = pluginManger.getCurrentPluginVersion();
        UpgradeProcessor.Builder
                .newInstance()
                .setContext(context)
                .setDeviceID(BizConstant.DEVICE_ID)
                .setShopID(ClientMetaUtil.getSettingsValueByKey(META.SHOPID))
                .setAPPID(manualAppID ? appID : PluginAppID.optAPPID())
                .setEnv(BaseConfig.isProduct())
                .setShowDialog(false)
                .setAutoDownload(true)
                .setCheckIgnoreCache(false)
                .setCurrentVersion(currentPluginVersion)
                .setTargetPath(context.getCacheDir() + "/mydPlugin/download/")
                .setFileSubFix("apk")
                .setCallback(new IUpgradeCallBack() {
                    @Override
                    public void checkResult(boolean checkSuccess, boolean hasNewVersion, JSONObject resultInfo) {

                    }

                    @Override
                    public boolean downloaded(int version, File file) {

                        String path = file.getPath();
                        if (version >= 1 && version > currentPluginVersion && !TextUtils.isEmpty(path)) {
                            if (BaseConfig.isDEV()) {
                                LogUtil.log("MydPlugin", "检测到新插件:" + path);
                            }
                            //简单的判断文件合法性
                            if (PluginUtil.getApkVersionCode(context, path) <= 0) {
                                return false;
                            }
                            LogUtil.logBusiness("MydPlugin", "新插件校验通过:" + path);
                            if (pluginManger.receiveNewPlugin(version, path)) {
                                if (forceLoadNew) {
                                    forceReActive();
                                } else if (BaseConfig.isDEV()) {
                                    loadPlugin();
                                }
                            }
                        }
                        return true;
                    }
                })
                .setCheckResultCallback((checkSuccess, hasNewVersion, resultInfo) -> {
                            if (checkSuccess && resultInfo != null) {

                            }
                        }
                ).start();
    }

    /**
     * 强制判断插件，如果有新版本，则强制加载新版本插件，供外部调用，keep住
     */
    @Keep
    public void hijklmn() {
        if (pluginManger != null && pluginManger.getCachedNewVersoion() > currentPluginVersion) {
            loadPlugin();
        }
    }

    /**
     * 强制检测一次更新，供外部调用，keep住
     */
    @Keep
    public void abcdefg() {
        checkUpdate();
    }

    public synchronized void init() {
        LogUtil.logBusiness("MydPluginLoader#init this hashcode: [" + this.hashCode() + "], plugin loaded: [" + this.pluginLoaded + "]");
        if (pluginLoaded) {
            return;
        }
        prepare();
        loadPlugin();
    }
}