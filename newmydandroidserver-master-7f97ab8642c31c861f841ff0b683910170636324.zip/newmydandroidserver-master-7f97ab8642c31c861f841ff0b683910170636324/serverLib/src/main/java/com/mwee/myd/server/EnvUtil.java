package com.mwee.myd.server;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.text.TextUtils;

import com.mwee.android.base.AppEnv;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.tools.LogUtil;

/**
 * Created by virgil on 2018/3/8.
 *
 * @author virgil
 */

public class EnvUtil {
    public static AppEnv buildEnv() {
        AppEnv env = new AppEnv();
        env.alpPort = APPConfig.PUSH_PORT;
        env.env = BaseConfig.ENV;
        env.socketPorts = SocketConfig.PORT_LIST;
        return env;
    }

    public static AppEnv buildEnv(Context context, String pluginPath) {
        AppEnv env = buildEnv();
        if (TextUtils.isEmpty(pluginPath)) {
            return env;
        }
        PackageInfo info = getPackageInfo(context, pluginPath);
        if (info != null) {
            env.versionCode = info.versionCode;
            env.versionName = info.versionName;
        }
        return env;
    }

    /**
     * 获取应用信息
     *
     * @param context
     * @return
     */
    public static PackageInfo getPackageInfo(Context context, String filePath) {
        PackageInfo info = null;
        try {
            info = context.getPackageManager().getPackageArchiveInfo(filePath, 0);
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
        return info;
    }
}
