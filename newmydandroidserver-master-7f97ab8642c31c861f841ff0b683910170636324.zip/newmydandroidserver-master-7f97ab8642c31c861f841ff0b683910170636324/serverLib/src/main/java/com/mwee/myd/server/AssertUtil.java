package com.mwee.myd.server;

import android.content.Context;

import com.mwee.android.tools.LogUtil;

import java.io.BufferedInputStream;
import java.util.Properties;

/**
 * Created by virgil on 2018/3/14.
 *
 * @author virgil
 */

public class AssertUtil {

    public static String readProperty(Context context, String path, String key) {
        Properties p = new Properties();

        try (BufferedInputStream inputStream = new BufferedInputStream(context.getResources().getAssets().open(path))) {
            p.load(inputStream);
            return p.getProperty(key);
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return "";

    }
}
