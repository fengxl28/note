package com.mwee.myd.server;

import com.mwee.android.pos.db.APPConfig;

/**
 * 业务中心插件的APPID
 */
public class PluginAppID {
    /**
     * 美易点
     */
    public final static int MYD = 71;
    /**
     * 美小易
     */
    public final static int XIAO_SAN = 72;
    /**
     * 美收银
     */
    public final static int CASHIER = 73;
    /**
     * 基础
     */
    public final static int BASE = 74;

    public static int optAPPID() {
        if (APPConfig.isMyd()) {
            return MYD;
        } else if (APPConfig.isAir()) {
            return XIAO_SAN;
        } else if (APPConfig.isCasiher()) {
            return BASE;
        }
        return BASE;
    }
}
