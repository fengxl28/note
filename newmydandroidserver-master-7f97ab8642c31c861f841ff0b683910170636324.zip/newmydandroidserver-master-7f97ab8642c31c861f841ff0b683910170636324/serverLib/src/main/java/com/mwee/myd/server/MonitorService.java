package com.mwee.myd.server;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.support.annotation.Nullable;

import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.connect.framework.BinderType;
import com.mwee.android.tools.LogUtil;

/**
 * Created by virgil on 2018/3/15.
 *
 * @author virgil
 */

public class MonitorService extends Service {
    private Messenger msnTarget = null;
    ServiceConnection mydServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            msnTarget = new Messenger(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (ClientMetaUtil.isCurrentHostVice()) {
                return;
            }
            if (!BaseConfig.isProduct()) {
                LogUtil.log("Monitor", "，开始自动绑定");
            }
            monitorMydService();
        }
    };
    private Messenger msnMe = null;

    private void monitorMydService() {
        Intent intent = new Intent();
        intent.setAction("com.mwee.android.pos.businesscenter.Active");
        intent.setPackage(getPackageName());

        bindService(intent, mydServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        monitorMydService();
        Handler handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case BinderType.MSG_RESULT:

                        break;
                    default:
                        break;
                }
            }
        };
        msnMe = new Messenger(handler);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        unbindService(mydServiceConnection);
        super.onDestroy();
    }
}
