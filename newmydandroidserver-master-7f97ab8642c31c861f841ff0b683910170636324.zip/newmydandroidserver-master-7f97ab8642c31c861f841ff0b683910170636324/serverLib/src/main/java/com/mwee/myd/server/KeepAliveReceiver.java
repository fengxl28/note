package com.mwee.myd.server;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.SystemClock;
import android.support.annotation.WorkerThread;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.tools.LogUtil;

/**
 * 一个定时器广播
 * Created by Virgil on 2015/8/17.
 */
public class KeepAliveReceiver extends BroadcastReceiver {
    public static final String ACTION_WAKE_UP = "com.mwee.android.pos.businesscenter.WAKEUP";
    public static final String ACTION_WAKE_LOOP = "com.mwee.android.pos.businesscenter.LOOP";

    public static void registAlarm(Context context) {
        if (context != null) {
            long firstime = SystemClock.elapsedRealtime();
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstime, 2 * 60 * 1000, getIntent(context));
        }
    }

    private static PendingIntent getIntent(Context context) {
        Intent intent = new Intent(context, KeepAliveReceiver.class);
        intent.setAction(ACTION_WAKE_LOOP);
        intent.setPackage(context.getPackageName());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return pendingIntent;
    }

    /**
     * 终止不断的轮询
     *
     * @param context Context
     */
    private static void cancelAlarm(Context context) {
        if (context != null) {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            am.cancel(getIntent(context));
        }
    }

    public static void checkFinish(Context context) {
        ServerService.checkFinish();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (BaseConfig.isDEV()) {
            LogUtil.log("KeepAliveReceiver " + action);
        }
        checkFinish(context);
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            registAlarm(context);
            //LogUtil.logBusiness("收到开机广播");
            RunTimeLog.addLog(RunTimeLog.NET, "收到开机广播");
        } else if (ConnectivityManager.CONNECTIVITY_ACTION.equals(action)) {
            networkChange(context);
        } else if (ACTION_WAKE_UP.equals(action)) {
            registAlarm(context);
            ServerService.keep();
        } else if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {

            // 接收卸载广播
//            String packagedata = intent.getDataString();
//            String packageName = null;
//            if (packagedata.startsWith("package:")) {
//                packageName = packagedata.substring("package:".length());
//            } else {
//                packageName = packagedata;
//            }
//            LogUtil.logBusiness("有应用被卸载，packageName："+packageName);
            ServerService.keep();
        }else{
            ServerService.keep();
        }
    }

    @WorkerThread
    private void networkChange(Context context) {

        ServerService.keep();
        ServerService.doBroadCast();
        ConnectivityManager conn = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(conn==null){
            return;
        }
        NetworkInfo networkInfo = conn.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {
            LogUtil.log("KeepAliveReceiver connected");
        } else if (networkInfo != null) {
            NetworkInfo.DetailedState state = networkInfo.getDetailedState();
            LogUtil.log("KeepAliveReceiver" + state.name());
        } else {
            LogUtil.log("KeepAliveReceiver lost connection");
        }
    }
}
