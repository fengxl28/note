package com.mwee.myd.server;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.connect.framework.BinderType;
import com.mwee.android.tools.LogUtil;

/**
 * ServerService
 * Created by virgil on 16/7/5
 *
 * @author virgil
 */
public class ServerService extends Service {


    private static ServerService instance = null;
    private Messenger server = null;
    private Handler mainHandler;

    private MydPluginLoader loader;
    private ServiceConnection monitorConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (ClientMetaUtil.isCurrentHostVice()) {
                return;
            }
            startMonitorService();
        }
    };

    public static void sendExcuteMessage(String uri, String... param) {
        Message message = Message.obtain();
        message.arg1 = BinderType.MSG_EXCUTE;
        message.what = BinderType.CLIENT_TYPE_EXCUTE;
        Bundle bundle = new Bundle();
        bundle.putString("uri", uri);
        if (param != null && param.length > 0) {
            bundle.putStringArray(uri, param);
        }
        message.setData(bundle);
    }

    public static void sendSyncMessage(final int loading, final String msg) {
//        if (instance != null) {
//            new LowThread(new Runnable() {
//                @Override
//                public void run() {
//                    Bundle bundle = new Bundle();
//                    bundle.putInt(UploadDataProcessor.KEY_STATUS, loading);
//                    bundle.putString(UploadDataProcessor.KEY_ERROR, msg);
//                    try {
//                        instance.sendInner(CLIENT_TYPE_LISTEN, bundle);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
//            }).start();
//
//        }
    }

    /**
     * 保活轮询
     */
    public static void keep() {
        if (instance != null && instance.loader != null) {
            instance.loader.invoke("keep", instance);
        }
    }

    public static void doBroadCast() {
        if (instance != null && instance.loader != null) {
            instance.loader.invoke("doBroadCast");
        }
    }

    /**
     * 检测是否需要结束当前进程
     */
    public static void checkFinish() {
        if (instance != null && instance.loader != null) {
            instance.loader.invoke("checkFinish", instance);
        }
    }

    private void startMonitorService() {
        Intent intent = new Intent();
        intent.setAction("com.mwee.android.myd.monitor");
        intent.setPackage(getPackageName());

        startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (BaseConfig.isDEV()) {
//            Debug.waitForDebugger();
        }
        startMonitorService();
        if (ClientMetaUtil.isCurrentHostVice()) {
            return;
        }
        instance = this;
        LogUtil.logBusiness("MydServer", "onCreate");
        loader = MydPluginLoader.getInstance(getApplicationContext());
        initMessenger();
        initPlugin();
    }

    public void initPlugin() {
        BusinessExecutor.executeNoWait(() -> {
            loader.init();
            //通过广播唤醒
            Intent intent = new Intent();
            intent.setAction("com.mwee.android.pos.businesscenter.WAKEUP");
            intent.setPackage(this.getPackageName());
            sendBroadcast(intent);
            return null;
        });
    }

    private void initMessenger() {
        mainHandler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case BinderType.CLIENT_TYPE_EXCUTE:
                        switch (msg.arg1) {
                            case BinderType.MSG_EXCUTE:
                                //msg并非线程共享，
                                final Bundle bundle = msg.getData();
                                final Messenger sClient = msg.replyTo;

                                BusinessExecutor.executeNoWait(() -> {
                                    String uri = bundle.getString("uri");
                                    Object[] paramList = bundle.getStringArray("param");
                                    LogUtil.log("MydServer", "messenger received:" + bundle.toString());

                                    if (TextUtils.isEmpty(uri)) {
                                        LogUtil.logError("ServerService uri is null");
                                        return null;
                                    }
                                    Object result = null;
                                    try {
                                        if (paramList != null && paramList.length > 0) {
                                            result = loader.invoke("call", uri, paramList);
                                        } else {
                                            result = loader.invoke("call", uri);
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    Bundle resultBundle = new Bundle();
                                    resultBundle.putString("skey", bundle.getString("skey"));
                                    if (result == null) {
                                        resultBundle.putString("result", "");
                                    } else if (result instanceof String) {
                                        resultBundle.putString("result", (String) result);
                                    } else if (result.getClass().isPrimitive()) {
                                        resultBundle.putString("result", String.valueOf(result));
                                    } else {
                                        resultBundle.putString("result", JSON.toJSONString(result));
                                    }
                                    reply(sClient, resultBundle);
                                    return null;

                                });

                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;

                }

            }
        };
        server = new Messenger(mainHandler);
        if(loader == null) {
            LogUtil.logBusiness("MydServer", "initMessenger loader is null");
            loader = MydPluginLoader.getInstance(getApplicationContext());
        }
        loader.setMainHandler(mainHandler);


    }

    private synchronized void reply(Messenger client, Bundle msg) {
        if (server == null) {
            return;
        }
        if (client == null) {
            return;
        }
        Message message = Message.obtain();
        message.setData(msg);
        message.what = BinderType.MSG_RESULT;
        try {
            client.send(message);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        LogUtil.logBusiness("MydServer", "onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        LogUtil.logBusiness("MydServer", "onBind");
        if (server == null) {
            initMessenger();
        }
        return server.getBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        LogUtil.logBusiness("MydServer", "onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        LogUtil.logBusiness("MydServer", "onDestroy");
        instance = null;
        super.onDestroy();
    }
}