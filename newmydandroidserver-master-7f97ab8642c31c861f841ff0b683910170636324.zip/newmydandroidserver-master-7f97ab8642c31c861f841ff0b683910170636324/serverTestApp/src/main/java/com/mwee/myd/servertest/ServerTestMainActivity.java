package com.mwee.myd.servertest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * Created by virgil on 2018/2/28.
 *
 * @author virgil
 */

public class ServerTestMainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.server_test_main);
        findViewById(R.id.active).setOnClickListener((v) -> doActive());
    }


    public void doActive() {
        try {
            Intent intentService = new Intent();
            intentService.setAction("com.mwee.android.pos.businesscenter.Active");
            intentService.setPackage(getPackageName());
            startService(intentService);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
