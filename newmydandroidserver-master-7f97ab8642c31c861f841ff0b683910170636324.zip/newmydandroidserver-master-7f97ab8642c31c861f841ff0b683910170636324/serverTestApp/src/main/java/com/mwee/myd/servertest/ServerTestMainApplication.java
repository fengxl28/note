package com.mwee.myd.servertest;

import android.app.Application;

import com.mwee.android.alp.AlpLog;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.Environment;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.ProcessUtil;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.android.tools.timesync.TimeSyncUtil;

/**
 * Created by virgil on 2018/2/28.
 *
 * @author virgil
 */

public class ServerTestMainApplication extends Application {
    private static ServerTestMainApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        APPConfig.PUSH_PORT = 49876;
        BizConstant.VERSION_CODE = BuildConfig.VERSION_CODE;
        BizConstant.VERSION_NAME = BuildConfig.VERSION_NAME;
        BaseConfig.ENV = 104;
        GlobalCache.getInstance().registerContext(this);

        instance = this;
        //加载阿里的hotfix模块
        //环境设置库的初始化

        GlobalCache.getInstance().setLogOpen(BaseConfig.ENV != Environment.PRODUCT);
        LogUtil.setWriteLog(true);
        LogUpload.setTest(!BaseConfig.isProduct());
        if (ProcessUtil.isMainProcess(this) && !BaseConfig.isProduct()) {
            new LowThread(() -> DeviceUtil.printSystemInfo(instance)).start();
        }
        DriverBus.setErrorWithException(false);
        AlpLog.setRelease(BaseConfig.isProduct());
        //时间同步
        new TimeSyncUtil().syncTime();
        //Bugly初始化

        SocketConfig.API_VERSION = 100;
        SocketConfig.PORT_LIST = new int[]{34501, 9999};
        SocketConfig.PORT = SocketConfig.PORT_LIST[0];

        //初始化DB,重要,需要放在业务初始化之前
//        BaseDBInit.initDB(this);
//        initDevConfig();
//
//
//        ClientApplication.init(this);
//        PrintApplication.init(this);
//        if (BuildConfig.DEBUG) {
//            InitDebugTools.initBlockCanary(this);
//        }
//
//        if (ProcessUtil.isMainProcess(this) && OEM.isElo()) {//初始化elo扫码器
//            ScannerManager.init(this);
//        }
    }
}
