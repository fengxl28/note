package com.mwee.android.pos.businesscenter.dbutil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.SystemClock;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.bonus.BonusUtils;
import com.mwee.android.pos.business.constants.BillSourceValue;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.rapid.api.bean.ClearTableRequest;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.business.shareshop.api.ShareShopApi;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.business.table.ChangeTableResponse;
import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataResponse;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataSimpleResponse;
import com.mwee.android.pos.connect.business.table.TableActionRespose;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.table.TableQRBizUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AreaBizDBModel;
import com.mwee.android.pos.db.business.MSectionDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.AreaBizSimpleModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableBizSimpInfo;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.db.business.table.TableStatusSimpleBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/3/7.
 */

public class TableBusinessUtil {


    /**
     * 开台并下单---下单前检验估清
     *
     * @param response SocketResponse
     * @param request  OpenTableAndCheckToOrderRequest   orderDishesCache
     * @return SocketResponse
     */
    public static void openTableAndOrder(SocketResponse<OpenTableAndCheckToOrderRespose> response, String hostID, JSONObject request) {
        long start = SystemClock.elapsedRealtime();
        long costCheck = 0;
        long costOpenTable = 0;
        long costMenu = 0;
        long totalCost = 0;
        TempOrderDishesCache orderDishesCache = request.getObject("orderDishesCache", TempOrderDishesCache.class);

        long timeEnterlock = 0;
        long timeCheck = 0;
        long timeCheckLock = 0;
        long timeOpenTable = 0;
        long timeAddMenu = 0;
        String logOrderID = "";
        UserDBModel userDBModel = new UserDBModel();
        userDBModel.fsUserName = orderDishesCache.waiterName;
        userDBModel.fsUserId = orderDishesCache.waiterID;

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--里面--开始");
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderDishesCache.fsmtableid, "", hostID + "站点 服务员：" + userDBModel.fsUserName + " --> 开台并下单---下单前检验估清 ");
        try {

            timeEnterlock = SystemClock.elapsedRealtime();
            LogUtil.log("TestLock", orderDishesCache.fsmtableid + ",openTableAndOrder" + " " + "optlock=" + (timeEnterlock - start));
            OpenTableAndCheckToOrderRespose responseData = new OpenTableAndCheckToOrderRespose();
            response.data = responseData;
            response.code = SocketResultCode.SUCCESS;
            response.message = "下单成功";

            //2、查询桌台状态
            SocketResponse<TableActionRespose> tableActionRespose = new SocketResponse<>();


            checkTableStatus(tableActionRespose, orderDishesCache.fsmtableid, userDBModel.fsUserId, userDBModel.fsUserName);
            timeCheck = SystemClock.elapsedRealtime();
            LogUtil.log("TestLock", orderDishesCache.fsmtableid + ",openTableAndOrder" + " " + "timeCheck=" + (timeCheck - timeEnterlock));

            // 锁桌判断
            String error = checkTableLock(hostID, userDBModel.fsUserId, orderDishesCache.fsmtableid);
            timeCheckLock = SystemClock.elapsedRealtime();
            LogUtil.log("TestLock", orderDishesCache.fsmtableid + ",openTableAndOrder" + " " + "timeCheckLock=" + (timeCheckLock - timeCheck));

            if (!TextUtils.isEmpty(error)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = error;
                return;
            }
            costCheck = SystemClock.elapsedRealtime() - start;
            if (tableActionRespose.code == SocketResultCode.SUCCESS) {
                OrderCache orderCache = null;
                if ((TextUtils.equals(TableConstans.TABLE_STATUS_FREE, tableActionRespose.data.tableStatusBean.fsmtablesteid) && tableActionRespose.data.orderCache == null)) {
                    SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(orderDishesCache.tempSelectedMenuList);
                    if (!result.success) {
                        response.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                        response.message = result.errorMsg;
                        response.data = responseData;
                        responseData.sellOutResult = result;
                        return;
                    }
                    orderCache = OrderDriver.generateNewOrder();
                    String orderId = orderCache.orderID;
                    String newId = orderId.substring(8);
                    //3、桌台开台
                    doOpenTable(response, request.getString("hostID"), orderDishesCache.fsmtableid, orderId, userDBModel);
                    timeOpenTable = SystemClock.elapsedRealtime();
                    LogUtil.log("TestLock", orderDishesCache.fsmtableid + ",openTableAndOrder" + " " + "timeOpenTable=" + (timeOpenTable - timeCheckLock));

                    costOpenTable = SystemClock.elapsedRealtime() - start - costCheck;
                    logOrderID = orderCache.orderID;
                    if (response.code == SocketResultCode.SUCCESS) {
                        orderCache.thirdOrderType = orderDishesCache.thirdBizType;
                        //4、订单保存
                        orderCache.fsmareaid = orderDishesCache.fsmareaid;
                        orderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + orderDishesCache.fsmareaid + "'");
                        orderCache.fsmtableid = orderDishesCache.fsmtableid;
                        orderCache.fsmtablename = orderDishesCache.fsmtablename;
                        orderCache.personNum = orderDishesCache.personNum;
                        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
                        orderCache.waiterID = orderDishesCache.waiterID;
                        orderCache.waiterName = orderDishesCache.waiterName;
                        orderCache.shopID = request.getString("shopId");
                        orderCache.currentHostID = orderDishesCache.currentHostID;
                        orderCache.currentSectionID = OrderUtil.getSectionId();
                        orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
                        orderCache.orderID = orderId;
                        orderCache.mealNumber = newId + "";
                        orderCache.orderStatus = OrderStatus.NORMAL;
                        if (orderCache.shareShopOrder()) {
                            orderCache.whetherRound = false;
                        }
                        //构建餐段
                        MSectionDBModel section = OrderUtil.getSection();
                        if (section != null) {
                            orderCache.currentSectionID = section.fsMSectionId;
                        }
                        // 保存餐标信息
                        orderCache.diningStandardAmt = orderDishesCache.diningStandardAmt;
                        orderCache.minStandardAmt = orderDishesCache.minStandardAmt;
                        OrderSession.getInstance().writeOrder(orderId, orderCache, false, "openTableAndOrder ");
                        // 开台时添加餐标、低消补充菜品,若添加成功，则单序+1
                        OrderDriver.addDinnerStandardMenus(orderCache, userDBModel, hostID);
                        //这里不需要再次检查估清
                        OrderDriver.addMenu(response, hostID, orderDishesCache.fsmtableid, orderId, orderDishesCache, false, orderDishesCache.source == -1);

                        // 是否下单前已绑定会员
                        if (orderDishesCache.isMember && (orderDishesCache.mMemberCardModel != null || orderDishesCache.mNewMemberCardModel != null)) {
                            if (orderDishesCache.mNewMemberCardModel != null) { // 会员重构对接，优先使用新的
                                orderCache.setMember(orderDishesCache.mNewMemberCardModel);
                            } else { // 兼容老的
                                orderCache.setMember(orderDishesCache.mMemberCardModel);
                            }
//                            if (DBMetaUtil.autoUseMemberPrice()) {
//                                orderCache.updateAllMenuToMemberPrice();
//                            }
                            MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, userDBModel.fsUserId);
                            orderCache.reCalcAllByAll();
                            OrderSession.getInstance().writeOrder(orderId, orderCache, false, "openTableAndOrder 2");
                            OrderProcessor.saveOrder(orderCache, null);
                            if (orderCache.dinnerModel()) {
                                MemberBizUtil.requestMemberComents(orderCache.memberInfoS.card_no);
                            }
                        }
                    }
                    costMenu = SystemClock.elapsedRealtime() - start - costCheck - costOpenTable;
                } else {
                    logOrderID = tableActionRespose.data.tableStatusBean.fssellno;
                    OrderCache o = OrderSession.getInstance().getOrder(logOrderID);
                    if (o != null && o.isNotSupportEditor()) {
                        //fixbugs 口碑先付订单加菜的问题
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "订单发生变化";
                    } else {
                        OrderDriver.addMenu(response, hostID, orderDishesCache.fsmtableid, tableActionRespose.data.tableStatusBean.fssellno, orderDishesCache, orderDishesCache.source == -1);
                    }
                }
                timeAddMenu = SystemClock.elapsedRealtime();
                LogUtil.log("TestLock", orderDishesCache.fsmtableid + ",openTableAndOrder" + " " + "timeAddMenu=" + (timeAddMenu - timeOpenTable));

            } else {
                response.code = tableActionRespose.code;
                response.message = tableActionRespose.message;
            }
            LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--里面-219");
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderDishesCache.fsmtableid, "", hostID + "站点 服务员：" + userDBModel.fsUserName + " --> 开台并下单---下单前检验估清 ");
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--里面-224-结束");
        totalCost = SystemClock.elapsedRealtime() - start;
        //超过两秒，则记录下这个日志
        if (totalCost > 2000) {
            RunTimeLog.addLog(RunTimeLog.SYS_TIME_OUT_OPEN, "下单超时，总耗时[" + totalCost + "]:检查桌台[" + costCheck + "],开台[" + costOpenTable + "],下单[" + costMenu + "]", logOrderID, orderDishesCache.fsmtableid, null);
//            LogUtil.log("TestLockFinal",orderDishesCache.fsmtableid+",openTableAndOrder"+" "+"optlock="+(timeEnterlock)+"timeCheck="+(timeCheck)+",timeCheckLock="+(timeCheckLock)+",timeOpenTable="+timeOpenTable+",timeAddMenu="+timeAddMenu);
        }
    }

    /**
     * 获取桌台相关业务数据
     * 桌台业务状态
     * 拼桌信息
     * 各个区域消息数
     *
     * @return
     */
    public static void getRefreshTableBizDataResponse(RefreshTableBizDataResponse responseData) {

        List<MtableDBModel> hintTables = TableDBUtil.getAllHintTables();
        List<TableStatusBean> tableS = TableDBUtil.getAllTableStatus();

        ArrayMap<String, TableStatusBean> tableStatus = new ArrayMap<>();
        List<JSONObject> kdsProgress = KDSUtils.queryKdsProgressByOrderId();
        for (TableStatusBean temp : tableS) {
            String tableId = temp.fsmtableid;
            tableStatus.put(tableId, temp);
            if (kdsProgress != null && temp.fiopenjob == 1) {//
                for (JSONObject jsonObject : kdsProgress) {
                    if (TextUtils.equals(tableId, jsonObject.getString("fsmtableid"))) {
                        temp.total = jsonObject.getIntValue("total");
                        temp.wait = jsonObject.getIntValue("wait");
                        temp.making = jsonObject.getIntValue("making");
                        temp.complete = jsonObject.getIntValue("complete");
                    }
                }
            }
        }

        List<AreaBizDBModel> allAreaBiz = TableDBUtil.getAllAreaBiz();
        ArrayMap<String, AreaBizDBModel> areaBizMap = new ArrayMap<>();
        if (!ListUtil.isEmpty(allAreaBiz)) {
            for (AreaBizDBModel areaBiz : allAreaBiz) {
                areaBizMap.put(areaBiz.fsMAreaId, areaBiz);
            }
        }

        ArrayMap<String, Integer> tableStateNum = TableDBUtil.queryTableStateNum();
        responseData.tableNumByState = tableStateNum;

        responseData.hintTableList = hintTables;
        responseData.tableStatus = tableStatus;
        responseData.areaMessage = TableDBUtil.getAllAreasMessage();
        responseData.areaBiz = areaBizMap;
    }

    /**
     * 获取桌台相关业务数据--简化版
     * 桌台业务状态
     * 拼桌信息
     * 各个区域消息数
     */
    public static void getRefreshTableBizDataSimpleResponse(RefreshTableBizDataSimpleResponse responseData) {

        List<MtableSimpleModel> hintTables = TableDBUtil.getAllHintTablesSimple();
        List<TableStatusSimpleBean> tableS = TableDBUtil.getAllTableStatusSimple();

        ArrayMap<String, TableStatusSimpleBean> tableStatus = new ArrayMap<>();
        List<JSONObject> kdsProgress = KDSUtils.queryKdsProgressByOrderId();
        for (TableStatusSimpleBean temp : tableS) {
            String tableId = temp.fsmtableid;
            tableStatus.put(tableId, temp);
            if (kdsProgress != null) {
                for (JSONObject jsonObject : kdsProgress) {
                    if (TextUtils.equals(temp.fssellno, jsonObject.getString("fsSellNo"))) {
                        temp.total = jsonObject.getIntValue("total");
                        temp.wait = jsonObject.getIntValue("wait");
                        temp.making = jsonObject.getIntValue("making");
                        temp.complete = jsonObject.getIntValue("complete");
                    }
                }
            }
        }

        List<AreaBizSimpleModel> allAreaBiz = TableDBUtil.getAllAreaBizSimple();
        ArrayMap<String, AreaBizSimpleModel> areaBizMap = new ArrayMap<>();
        if (!ListUtil.isEmpty(allAreaBiz)) {
            for (AreaBizSimpleModel areaBiz : allAreaBiz) {
                areaBizMap.put(areaBiz.fsMAreaId, areaBiz);
            }
        }

        ArrayMap<String, Integer> tableStateNum = TableDBUtil.queryTableStateNum();
        responseData.tableNumByState = tableStateNum;

        responseData.hintTableList = hintTables;
        responseData.tableStatus = tableStatus;
        responseData.areaMessage = TableDBUtil.getAllAreasMessage();
        responseData.areaBiz = areaBizMap;
        //刷新桌台数据时，刷新今日目标
        if (TextUtils.isEmpty(ServerCache.getInstance().salesTarget)) {
            ServerCache.getInstance().salesTarget = DataCacheDBUtil.getSalesTarget();
        }
        responseData.salesTarget = ServerCache.getInstance().salesTarget;
    }

    public static final Object lockTable = new Object();

    /**
     * 清台
     *
     * @param response
     * @param fstableId
     * @param sellNo
     */
    public static void closeTable(SocketResponse response, String fstableId, String sellNo) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fstableId, sellNo, "清台");
        try {
            String sql = "select fiselltype from order_cache where order_id = '" + sellNo + "'";
            Integer fiselltype = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "fiselltype", Integer.class);
            if (fiselltype != null && fiselltype == 1) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "快餐不需要清台";
                return;
            }
            MtableDBModel mtableDBModel = TableDBUtil.getMTableContantDeleteDataById(fstableId);
            if (mtableDBModel == null) {
                response.code = -1;
                response.message = "没有查到该桌台";
            } else {
                TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(fstableId);
                if ((tableBizModel.flag & 2) == 2) {
                    response.code = -1;
                    response.message = "当前桌台还有服务铃";
                    return;
                } else if (tableBizModel.hasUnConfirmedRapid()) {
                    response.code = -1;
                    response.message = "当前桌台还有秒点订单未被处理";
                    return;
                } else if (!tableBizModel.fssellno.equals(sellNo)) {
                    response.code = SocketResultCode.SUCCESS;
                    response.message = "清台出现异常";
                    RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "清台出现异常：业务数据[fstableId, sellNo] = [" + fstableId + "," + sellNo + "]; " +
                            "数据库中的数据[fstableId, sellNo] = [" + tableBizModel.fsmtableid + "," + tableBizModel
                            .fssellno + "]");
                    return;
                } else if (!TextUtils.isEmpty(mtableDBModel.fshint)) {   //当前桌台为拼出的桌台---桌台及桌台业务直接删除
                    cleanShareTables(fstableId);
                    NotifyToClient.refreshTableQueueByID(fstableId, 0);
                } else {
                    TableDBUtil.releaseTableBizById(fstableId);
                    //将秒点端的桌台状态设为已清台
                    notifyCloudToUnlockTable(mtableDBModel.fsmtableid);
                }

                // 清台通知排队端
                NotifyToClient.refreshTableBizQueue(mtableDBModel.fsmtableid);

                response.code = SocketResultCode.SUCCESS;
                response.message = "清台成功";

                ServerCache.getInstance().releaseTableQR(fstableId);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fstableId, sellNo, "清台");
        }
    }

    /**
     * 通知云端解锁桌台
     *
     * @param tableID String | 桌台ID
     */
    public static void notifyCloudToUnlockTable(String tableID) {
        ClearTableRequest request = new ClearTableRequest();
        request.tableNo = tableID;
        request.shopId = HostUtil.getShopID();
        BusinessExecutor.execute(request, null, null, true);
    }

    /**
     * 创建一个新桌
     *
     * @param table MtableDBModel
     * @return MtableDBModel
     */
    private static MtableDBModel creatNewTable(MtableDBModel table) {
        MtableDBModel newTable = table.clone();
        String nameKey = getNewTableName(newTable.fsmtableid, newTable.fsmtablename);
        newTable.fsmtablename = newTable.fsmtablename + "+" + nameKey;
        newTable.fsmtableid = table.fsmtableid + "_" + (nameKey);
        newTable.fshint = table.fsmtableid;
        newTable.fistatus = 2;

        return newTable;
    }

    /**
     * 取一个有效的新桌台名字
     *
     * @param fsmtableid String
     * @return String
     */
    private static String getNewTableName(String fsmtableid, String fsmtablename) {
        List<MtableDBModel> mtableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fshint = '" + fsmtableid + "'",
                MtableDBModel.class);
        String name = "";
        if (mtableDBModels != null && mtableDBModels.size() > 0) {
            for (int i = 1; i <= mtableDBModels.size(); i++) {
                boolean existing = false;
                for (MtableDBModel mtableDBModel : mtableDBModels) {
                    if (mtableDBModel.fsmtablename.equals(fsmtablename + "+" + i)) {
                        existing = true;
                        break;
                    }
                }
                if (!existing) {
                    name = "" + i;
                    break;
                }
            }
        }
        if (TextUtils.isEmpty(name)) {
            name = "" + (mtableDBModels.size() + 1);
        }
        return name;
    }

    /**
     * 拼台--获取有效拼台并写入数据库
     *
     * @param fstableId
     * @param userDBModel
     * @return
     */
    public static MtableDBModel shareTable(String fstableId, UserDBModel userDBModel) {
        MtableDBModel table = TableDBUtil.getMTableById(fstableId);
        if (table == null) {
            return null;
        } else {
            //如果该桌台是拼出的桌台就要取出其原生桌台
            if (!TextUtils.isEmpty(table.fshint)) {
                table = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsmtableid = '" + table.fshint + "'", MtableDBModel.class);
            }

            List<TableBizModel> tableBizModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fshint = '" + table.fsmtableid + "'",
                    TableBizModel.class);

            MtableDBModel validTable = null;
            if (tableBizModelList != null && !tableBizModelList.isEmpty() && tableBizModelList.size() > 0) {
                for (TableBizModel tableBiz : tableBizModelList) {
                    if (tableBiz.fistatus == 9) {
                        validTable = TableDBUtil.getMTableById(tableBiz.fsmtableid);
                        if (validTable == null) {
                            tableBiz.delete();
                        }
                        break;
                    }
                }
            }
            if (validTable == null) {
                //创建新桌台并加入数据库
                validTable = creatNewTable(table);
            }

            TableDBUtil.sumbmitShareTable(validTable, userDBModel);
            NotifyToClient.refreshTableOrOrders(); //拼桌成功，通知各站点刷新桌台页面
            NotifyToClient.refreshTableQueueByID(validTable.fsmtableid, 1);
            return validTable;
        }
    }

    /**
     * 开台
     *
     * @param fsmtableid
     * @param orderId
     * @param userDBModel
     */
    public static void openTable(final String fsmtableid, final String orderId, final UserDBModel userDBModel) {
        TableDBUtil.checkTableBizxists(fsmtableid);
        TableDBUtil.openTable(fsmtableid, orderId, userDBModel);
    }

    /**
     * 清除所有拼桌，并将拼桌业务信息清除
     *
     * @param tableId 指定的桌台ID
     *                如果不传ID，会清除当前库中所有的拼台信息
     */
    public static void cleanShareTables(final String tableId) {
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                String tableids = tableId;
                String fatherId = "";
                if (TextUtils.isEmpty(tableids)) {
                    String sql = "select fsmtableid from tbmtable where fistatus = '2'";
                    List<String> tableIdArr = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                    StringBuilder stringBuilder = new StringBuilder("");
                    for (String id : tableIdArr) {
                        stringBuilder.append("'").append(id).append("'").append(",");
                    }
                    String ids = stringBuilder.toString();
                    if (TextUtils.isEmpty(ids)) {
                        return true;
                    }
                    tableids = ids.substring(0, ids.length() - 1);
                } else {
                    StringBuilder stringBuilder = new StringBuilder("'");
                    stringBuilder.append(tableId).append("'");
                    tableids = stringBuilder.toString();
                    String sql = "select fshint from tbmtable where fsmtableid = " + tableids + "";
                    fatherId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                }

                RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "本次删除的拼台：【" + tableids + "】；fatherId = 【" + fatherId + "】");
                db.execSQL("delete from tableBiz where fsmtableid in (" + tableids + ")");
                db.execSQL("delete from tbmtable where fsmtableid in (" + tableids + ")");

                if (TextUtils.isEmpty(tableId)) {
                    ContentValues valuesFisharebills = new ContentValues();
                    valuesFisharebills.put("fisharebills", "0");
                    db.update("tbmtable", valuesFisharebills, "", null);
                } else {
                    db.execSQL("update tbmtable set fisharebills = (fisharebills - 1) where fsmtableid = '" + fatherId + "'");
                }

                return true;
            }
        });
    }

    public static SocketResponse doOpenTable(SocketResponse response, String hostid, String tableId, String orderId, UserDBModel
            userDBModel) {
        return doOpenTable(response, hostid, tableId, orderId, userDBModel, true);
    }

    public static SocketResponse doOpenTable(SocketResponse response, String hostid, String tableId, String orderId, UserDBModel userDBModel, boolean checkTableLock) {
        return doOpenTable(response, hostid, tableId, orderId, userDBModel, checkTableLock, null);
    }

    /**
     * 开台
     *
     * @param response
     * @param tableId
     * @param orderId
     * @param userDBModel
     * @param hostid
     * @param checkTableLock
     * @param queueNum       排队单号
     * @return
     */
    public static SocketResponse doOpenTable(SocketResponse response, String hostid, String tableId, String orderId, UserDBModel userDBModel, boolean checkTableLock, String queueNum) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableId, orderId, hostid + "站点 服务员：" + userDBModel.fsUserName + " --> 开台 ");
        try {
            if (!isExist(tableId)) {
                response.code = -1;
                response.message = "没有查到该桌台信息";
            } else {
                if (checkTableLock) {
                    String error = checkTableLock(hostid, userDBModel.fsUserId, tableId);
                    if (!TextUtils.isEmpty(error)) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = error;
                        return response;
                    }
                }
                TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(tableId);

                response.code = SocketResultCode.SUCCESS;
                //桌台状态只判断桌台状态，不判断订单
                if (TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid)) {
                    TableDBUtil.openTable(tableId, orderId, userDBModel);
                    response.code = SocketResultCode.SUCCESS;
                    response.message = "开台成功";
                } else if (TextUtils.equals(tableBizModel.fssellno, orderId)) {
                    response.code = SocketResultCode.SUCCESS;
                    response.message = "已开台";
                } else {
                    response.code = -2;
                    response.message = "桌台已被占用";
                }
            }

        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableId, orderId, hostid + "站点 服务员：" + userDBModel.fsUserName + " --> 开台 ");
        }
        // 广播刷新状态
        NotifyToClient.refreshTableOrOrders();
        if (response.code == SocketResultCode.SUCCESS) {  //开台存秒付码
            ServerCache.getInstance().putTableQR(tableId, TableQRBizUtil.createTableQRBiznessModel(tableId));

            // 关联排队单号，并通知排队刷新页面
            relateQueueNum(orderId, queueNum);
            NotifyToClient.refreshTableBizQueue(tableId);
        }
        return response;
    }

    /**
     * 订单关联排队单号
     *
     * @param orderId
     * @param queueNum
     */
    private static void relateQueueNum(String orderId, String queueNum) {
        if (TextUtils.isEmpty(orderId) || TextUtils.isEmpty(queueNum)) {
            return;
        }
        // 开台成功，插入排队单号关联
        CacheModel model = new CacheModel();
        model.type = IOCache.TYPE_QUEUE_OPEN_TABLE;
        model.key = orderId;
        model.value = queueNum;
        model.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        model.updatetime = model.createtime;
        model.replaceNoTrans();
    }


    /**
     * 查询桌子状态
     *
     * @param response
     * @param tableId
     * @return
     */
    public static SocketResponse checkTableStatus(SocketResponse<TableActionRespose> response, String tableId, String fsUserId, String fsUserName) {
        if (!isExist(tableId)) {
            response.code = -1;
            response.message = "没有查到该桌台信息";
            return response;
        }

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableId, "", fsUserName + " 查询桌子状态");
        try {
            TableActionRespose responseData = new TableActionRespose();
            TableStatusBean tableStatusBean = TableDBUtil.getTableStatusById(tableId);
            String fsmareaid = "";
            MtableDBModel mtableDBModel = TableDBUtil.getMTableById(tableId);
            if (tableStatusBean == null) {
                if (mtableDBModel == null) {
                    response.code = -2;
                    response.message = "没有查到该桌台信息";
                    return response;
                }
                tableStatusBean = new TableStatusBean();
                tableStatusBean.fsmtableid = tableId;
                tableStatusBean.fsmareaid = mtableDBModel.fsmareaid;
                fsmareaid = mtableDBModel.fsmareaid;
            } else {
                if (mtableDBModel == null) {
                    mtableDBModel = TableDBUtil.getMTableByIdWithDelete(tableId);
                    if (mtableDBModel == null) {
                        response.code = -3;
                        response.message = "没有查到该桌台信息";
                        return response;
                    }
                }
                fsmareaid = tableStatusBean.fsmareaid;
            }
            responseData.tableStatusBean = tableStatusBean;
            responseData.sectionId = OrderUtil.getSectionId();
            response.code = SocketResultCode.SUCCESS;
            responseData.hasopenParam = OrderBizUtil.hasOpenParam(fsmareaid);
            if (TableConstans.TABLE_STATUS_FREE.equals(tableStatusBean.fsmtablesteid) && TextUtils.isEmpty
                    (tableStatusBean.fssellno)) {
                response.message = "桌台空闲";
            } else {
                OrderCache orderCache = OrderSession.getInstance().getOrder(tableStatusBean.fssellno);
                checkMemberComments(orderCache);
                responseData.orderCache = orderCache;
                responseData.session = OrderSession.getInstance().getPay(tableStatusBean.fssellno);

                if (responseData.orderCache == null || TextUtils.isEmpty(tableStatusBean.fssellno)) {
                    response.message = "桌台空闲";
                    //出现异常状况的时候,要释放桌台
                    responseData.tableStatusBean.fsmtablesteid = TableConstans.TABLE_STATUS_FREE;
                    responseData.tableStatusBean.fssellno = "";
                    TableDBUtil.releaseTableBizById(tableId);
                    RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "发现异常桌台:tableId = " + tableId + "; tableStatusBean.fssellno" + tableStatusBean.fssellno + "; orderCache = " + JSON.toJSONString(responseData.orderCache));
                } else {
                    if (ListUtil.isEmpty(responseData.orderCache.originMenuList)) {
                        if (responseData.hasopenParam) {
                            responseData.openParamMenuList = OrderBizUtil.getOpenParamOrderMenu(responseData.orderCache.fsmareaid, responseData.orderCache.personNum, fsUserId, fsUserName);
                        }
                    }
                    responseData.amtPrePay = OrderUtil.getPrePayAmt(responseData.orderCache.orderID);
                    response.message = "桌台已被占用";
                }
            }
            // 开台预点菜关联提成人
            checkBonusInfo(responseData.openParamMenuList, fsUserId);
            // 开台预点菜添加桌台信息
            setOriginTable(responseData.openParamMenuList, tableId, mtableDBModel.fsmtablename, false, "");

            response.data = responseData;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableId, "", fsUserName + " 查询桌子状态");
        }
        return response;
    }

    /**
     * 设置菜品的原桌台信息
     *
     * @param menuItems           要设置的菜品列表
     * @param tableId             桌台id
     * @param tableName           桌台名称
     * @param needFilterWithOrder 是否需要根据订单过滤
     * @param filterOrderTableId  需要过滤的订单的桌台id，与该桌台id对应的菜品更改原桌台信息，不对应的不更改
     */
    public static void setOriginTable(List<MenuItem> menuItems, String tableId, String tableName, boolean needFilterWithOrder, String filterOrderTableId) {
        if (ListUtil.isEmpty(menuItems) || TextUtils.isEmpty(tableId) || TextUtils.isEmpty(tableName)) {
            return;
        }
        for (MenuItem item : menuItems) {
            if (needFilterWithOrder && !TextUtils.isEmpty(filterOrderTableId)) {
                if (!TextUtils.equals(item.originTableId, filterOrderTableId)) {
                    continue;
                }
            }
            item.originTableId = tableId;
            item.originTableName = tableName;
            if (item.menuBiz == null) {
                continue;
            }
            if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
                for (MenuItem modifier : item.menuBiz.selectedModifier) {
                    modifier.originTableId = tableId;
                    modifier.originTableName = tableName;
                }
            }
            if (!ListUtil.isEmpty(item.menuBiz.selectedPackageItems)) {
                for (MenuItem modifier : item.menuBiz.selectedPackageItems) {
                    modifier.originTableId = tableId;
                    modifier.originTableName = tableName;
                }
            }
        }
    }

    /**
     * 校验会员评论是否存在
     */
    private static void checkMemberComments(OrderCache orderCache) {
        if (orderCache != null && orderCache.dinnerModel() && orderCache.memberInfoS != null
                && ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no) == null) {
            MemberBizUtil.requestMemberComents(orderCache.memberInfoS.card_no);
        }

    }

    /**
     * 换台、并台
     *
     * @param request        ChangeTableRequest的request
     * @param socketResponse
     * @return
     */
    public static SocketResponse doChangeTable(String orderToken, JSONObject request, SocketResponse socketResponse, UserDBModel userDBModel, String hostID) {

        String targetTableNo = request.getString("targetTableID");
        String originTableNo = request.getString("originTableID");

        String originOrderId = request.getString("originOrderID");

        if (TextUtils.isEmpty(targetTableNo) || TextUtils.isEmpty(originTableNo)) {
            socketResponse.code = -1;
            socketResponse.message = "操作失败:数据异常，请稍后重试";
            return socketResponse;
        }

        if (TextUtils.equals(targetTableNo, originTableNo)) {
            socketResponse.code = -1;
            socketResponse.message = "操作失败，目标桌台和原桌台一致";
            return socketResponse;
        }

        //1、判断是否满足换台、并台条件

        MtableDBModel targetTableModel = TableDBUtil.getMTableById(targetTableNo);
        if (targetTableModel == null) {
            socketResponse.code = -1;
            socketResponse.message = "没有查到该桌台";
            return socketResponse;
        }

        MtableDBModel originTableModel = TableDBUtil.getMTableById(originTableNo);
        if (originTableModel == null) {
            socketResponse.code = -1;
            socketResponse.message = "桌台异常，请退出重试";
            return socketResponse;
        }

        TableBizModel originTableBiz = TableDBUtil.optDefaultTableBizModel(originTableNo);
        if (originTableBiz.hasUnConfirmedRapid()) {
            socketResponse.code = -1;
            socketResponse.message = "当前桌台还有秒点订单未被处理";
            return socketResponse;
        }

        TableBizModel targetTableBiz = TableDBUtil.optDefaultTableBizModel(targetTableNo);
        if (targetTableBiz == null) {
            socketResponse.code = -1;
            socketResponse.message = "没有查到目标桌台";
            return socketResponse;
        }

        OrderCache originOrderCache = OrderSession.getInstance().getOrder(originOrderId);//原桌台不变
        if (originOrderCache == null) {
            socketResponse.code = -1;
            socketResponse.message = "没查到订单信息";
            return socketResponse;
        }

        /*
         * 非共享餐厅订单：
         * ------判断原始桌是否已有支付信息，如果有，则不能被合桌;
         * 共享餐厅订单不需要校验支付信息
         * 校验的支付信息不包括超标赠送
         */
        if (!originOrderCache.shareShopOrder()) {
            String coutnReceive = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                    "select count(*) as count from tbSellReceive where fiStatus != '13' and fsSellNo='" + originOrderId + "'" +
                            " and fsPaymentId !='" + PayType.DINNERSTANDARD_COUPON + "' ");
            int count = StringUtil.toInt(coutnReceive, 0);
            if (count > 0) {
                socketResponse.code = -2;
                socketResponse.message = "[" + originTableModel.fsmtablename + "]桌台已有支付信息，不能被合桌/换桌";
                return socketResponse;
            }
        }

        OrderCache targetOrderCache = null;

        //如果目标桌台已开台，则获取目标桌台的订单
        if (TableConstans.TABLE_STATUS_OPEN.equals(targetTableBiz.fsmtablesteid) && !TextUtils.isEmpty(targetTableBiz.fssellno)) {
            String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiBillStatus from tbSell where fsSellNo='" + targetTableBiz.fssellno + "'");
            if (TextUtils.equals(fiBillStatus, "4")) {
                socketResponse.code = -1;
                socketResponse.message = "目标桌台正在反结账，不能被合桌";
                return socketResponse;
            }
            targetOrderCache = OrderSession.getInstance().getOrder(targetTableBiz.fssellno);
        }

        /*
         * 如果是共享餐厅的订单，目标订单也必须是共享餐厅的订单
         */
        if (targetOrderCache != null) {
            if ((originOrderCache.shareShopOrder() && !targetOrderCache.shareShopOrder()) ||
                    (!originOrderCache.shareShopOrder() && targetOrderCache.shareShopOrder())) {
                socketResponse.code = -1;
                socketResponse.message = "订单属性不同，不支持合并";
                return socketResponse;
            }
        }

        if (targetOrderCache != null) {
            if (targetOrderCache.existMemberCoupon()) {
                socketResponse.code = -1;
                socketResponse.message = targetTableNo + " 桌台订单存在使用了菜品券的菜品，无法进行合桌操作";
                return socketResponse;
            }
            if (originOrderCache.existMemberCoupon()) {
                socketResponse.code = -1;
                socketResponse.message = "该订单存在使用了菜品券的菜品，无法进行合桌操作";
                return socketResponse;
            }
        }

        if (targetOrderCache != null) {
            /**
             * 口碑订单不能换桌
             */

            if (targetOrderCache.isNotSupportEditor()) {
                socketResponse.code = -1;
                socketResponse.message = "口碑桌台不能进行换桌或合桌";
                return socketResponse;
            }
        }

        /**
         * 口碑订单不能换桌
         */

        if (targetOrderCache != null && targetOrderCache.isNotSupportEditor()) {
            socketResponse.code = -1;
            socketResponse.message = "口碑桌台不能进行换桌或合桌";
            return socketResponse;
        }

        // 固定用餐标准不同，不能合桌
        if (targetOrderCache != null) {
            if (originOrderCache.diningStandardAmt.compareTo(BigDecimal.ZERO) > 0 &&
                    originOrderCache.diningStandardAmt.compareTo(targetOrderCache.diningStandardAmt) != 0) {
                socketResponse.code = -1;
                socketResponse.message = "您选择的桌台与本桌台用餐标准不一致，不可进行合桌，请知晓！";
                return socketResponse;
            }
        }


        ChangeTableResponse response = new ChangeTableResponse();

        /*
         * 锁原订单
         */
        //2、锁住原有订单
        String lockUniqOrigin = ServerCache.getInstance().tableLockCache.doLock(originTableNo, originOrderCache.orderID, " 换并桌 ---原桌台");

        try {
            originOrderCache = OrderSession.getInstance().getOrder(originOrderId);

            if (TextUtils.equals(targetTableBiz.fsmtableid, originOrderCache.fsmtableid)) {
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "重复操作";
                return socketResponse;
            }

            /*
             * 开始锁桌--锁新桌台
             */
            String lockError = lockTable(request.getString("targetTableID"), request.getString("operateHostID"), request.getString("operateWaiterID"), request.getString("operateWaiterName"));
            if (!TextUtils.isEmpty(lockError)) {
                socketResponse.code = -1;
                socketResponse.message = lockError;
                return socketResponse;
            }

            /**
             * 锁新订单
             */
            String lockUniqTarget = ServerCache.getInstance().tableLockCache.doLock(targetTableNo, "", " 换并桌 --- 目标桌台");
            // 操作类型(1:整桌转台 2:部分转菜 3:整桌并台）
            int operationKind;
            List<MenuItem> tempOriginalMenuItems = new ArrayList<>(originOrderCache.originMenuList);
            try {
                /**
                 * 如果目标桌台已有订单信息，则将原始订单数据merge到目标桌台的订单
                 */
                if (targetOrderCache != null) {
                    operationKind = 3;
                    targetOrderCache = OrderSession.getInstance().getOrder(targetTableBiz.fssellno);
                    //并桌必须更换orderToken
                    orderToken = ServerCache.getInstance().generateNewToken(targetOrderCache.orderID);
                    /*
                     * 开始替换单序
                     */
                    int newSeq = targetOrderCache.currentSeq;
                    response.newSeqList = new ArrayList<>();
                    //处理口碑订单数据回流 原桌台进行关单处理
                    originOrderCache.kbStatus = KBConstants.KB_ACTION_CLOSE;
                    OrderProcessor.notifyOrderChanged(originOrderId);

                    List<MenuItem> tempMenuList = new ArrayList<>(originOrderCache.originMenuList);
                    for (OrderSeqModel originSeq : originOrderCache.seqList) {
                        newSeq++;
                        for (int index = 0; index < tempMenuList.size(); index++) {
                            MenuItem temp = tempMenuList.get(index);
                            if (temp.menuBiz.orderSeqID == originSeq.seqNo) {
                                temp.menuBiz.orderSeqID = newSeq;
                                tempMenuList.remove(index);
                                index--;
                            }
                            if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                                for (MenuItem menuItem : temp.menuBiz.selectedModifier) {
                                    if (menuItem.menuBiz.orderSeqID == originSeq.seqNo) {
                                        menuItem.menuBiz.orderSeqID = newSeq;
                                    }
                                }
                            }
                        }
                        response.newSeqList.add(newSeq);
                        originSeq.seqNo = newSeq;
                    }

                    targetOrderCache.seqList.addAll(originOrderCache.seqList);

                    for (int i = 0; i < originOrderCache.originMenuList.size(); i++) {
                        originOrderCache.originMenuList.get(i).cleanMemberInfo();
                        // 合桌时清除订单中的餐标/低消补充菜品
                        if (DinnerStandardUtil.isStandardMenu(originOrderCache.originMenuList.get(i).itemID)) {
                            originOrderCache.originMenuList.remove(i);
                            i--;
                        }
                    }
                    targetOrderCache.originMenuList.addAll(originOrderCache.originMenuList);

                    targetOrderCache.currentSeq = newSeq;
                    targetOrderCache.currentSeq++;
                    targetOrderCache.personNum += originOrderCache.personNum;
                    /**
                     * 原始订单清除所有数据
                     */
                    originOrderCache.clearAllMenu(true);
                    originOrderCache.personNum = 0;

                    //免除服务费
                    originOrderCache.writeConfig(1);
                    originOrderCache.feeFreeOperUID = userDBModel.fsUserId;
                    originOrderCache.feeFreeUID = userDBModel.fsUserId;
                    originOrderCache.feeFreeUName = userDBModel.fsUserName;
                    originOrderCache.reCalcAllByAll();
                    /**
                     * 将订单设为已结账并存储
                     */
                    originOrderCache.mergedOrderID = targetOrderCache.orderID;
                    originOrderCache.mergedOrderInfo = targetOrderCache.mergedOrderInfo = "服务员【" + userDBModel.fsUserName + "】并桌，导致订单结账 " + DateUtil.getCurrentDateTime();
                    //重算价格
                    OrderSession.getInstance().generatePaySession(originOrderCache, userDBModel, hostID);
                    OrderSession.getInstance().writePay(originOrderCache.orderID, true);

                    if (originOrderCache.shareShopOrder()) {
                        //共享餐厅的订单并桌时要将支付信息全部迁移
                        PaySession originPaySession = OrderSession.getInstance().getPay(originOrderId);
                        PaySession targetPaySession = OrderSession.getInstance().getPay(targetOrderCache.orderID);

                        if (originPaySession != null && !ListUtil.isEmpty(originPaySession.selectPayListFull)) {

                            if (targetPaySession == null) {
                                targetPaySession = OrderSession.getInstance().generatePaySession(targetOrderCache, userDBModel, hostID);
                            }

                            int targetPaySessionLastSeq = targetPaySession.lastSeq;

                            for (PayModel payModel : originPaySession.selectPayListFull) {
                                if (payModel == null) {
                                    continue;
                                }
                                payModel.seq = payModel.seq + targetPaySessionLastSeq;
                                targetPaySession.selectPayListFull.add(payModel);
                            }
                            originPaySession.selectPayListFull.clear();

                            PaySaveDBUtil.save(originOrderCache.orderID, originPaySession);
                            PaySaveDBUtil.save(targetOrderCache.orderID, targetPaySession);
                        }
                    }
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbSellPickMenuitem set fsSellNo= '" + targetTableBiz.fssellno + "' where fsSellNo= '" + originOrderId + "'");
                    // 更新缓存中状态为已结账
                    OrderSession.updateOrderStatus(originOrderCache.orderID, OrderStatus.PAIED);
                    OrderSession.setPayed(originOrderCache.orderID, 1);
                    //完成结账
                    PayProcessor.manualSetPaySuccess(originOrderCache, originOrderCache.orderID, originOrderCache.fsmtableid, userDBModel, hostID, 1);
                    OrderSession.getInstance().clearOrder(originOrderCache.orderID);
                } else {
                    operationKind = 1;
                    targetOrderCache = originOrderCache.clone();
                    handlerKBTableNo(targetOrderCache, targetTableModel.fsmtableid, targetTableModel.fsmtablename);
                    // 换桌更改原桌台信息，只更改当前桌台下菜品的原桌台信息，本来就有合桌信息的菜品不更改
                    setOriginTable(targetOrderCache.originMenuList, targetTableModel.fsmtableid, targetTableModel.fsmtablename, true, originOrderCache.fsmtableid);
                    response.newSeqList = new ArrayList<>();
                    for (OrderSeqModel originSeq : originOrderCache.seqList) {
                        response.newSeqList.add(originSeq.seqNo);
                    }
                }

                /**
                 * 如果新桌台未开台，则进行开台操作
                 */
                RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "换桌，检测是否需要对目标桌台进行开台操作：" + JSON.toJSONString(targetTableBiz));
                if (!(TextUtils.equals(TableConstans.TABLE_STATUS_OPEN, targetTableBiz.fsmtablesteid)
                        && TextUtils.equals(targetTableBiz.fssellno, targetOrderCache.orderID))) {
                    /**
                     * 新桌台开台
                     */
                    TableDBUtil.openTable(targetTableBiz.fsmtableid, targetOrderCache.orderID, userDBModel);
                }

                /**
                 * 订单库里的订单信息更新
                 */
                targetOrderCache.fsmareaid = targetTableModel.fsmareaid;
                targetOrderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + targetTableModel.fsmareaid + "'");
                targetOrderCache.fsmtableid = targetTableModel.fsmtableid;
                targetOrderCache.fsmtablename = targetTableModel.fsmtablename;

                // 添加餐标、低消补充菜品
                OrderDriver.addDinnerStandardMenus(targetOrderCache, userDBModel, targetOrderCache.currentHostID);

                targetOrderCache.reCalcAllByAll();

                OrderSession.getInstance().writeOrder(targetOrderCache.orderID, targetOrderCache, false, "doChangeTable");

                OrderProcessor.saveOrder(targetOrderCache, null);

                // 正餐模式下，合桌后，目标订单预结单打印状态变为未印单
                if (targetOrderCache.dinnerModel()) {
                    TableBusinessUtil.modifyPrePrint(null, targetOrderCache.fsmtableid, targetOrderCache.orderID, TableStatusBean.GENERAL);
                }

                /**
                 * 旧桌台关台
                 */
                closeTable(socketResponse, originTableModel.fsmtableid, originOrderCache.orderID);
//                    socketResponse.code = SocketResultCode.SUCCESS;
//                    socketResponse.message = "换台成功";
                /**
                 * 旧桌台解除锁定
                 */
                unlockTargetTable(originTableModel.fsmtableid);
                if (TextUtils.equals(request.getString("operateHostID"), HostBiz.mealorder)) {
                    unlockTargetTable(targetTableModel.fsmtableid);
                }

                NotifyToClient.refreshTableOrOrders();
                NotifyToClient.refreshTableLock();

                NotifyToClient.refreshTableBizQueue(originTableNo);
                NotifyToClient.refreshTableBizQueue(targetTableNo);

                if (DBOrderConfig.useKdsService()) {
                    KdsManager.getInstance().transferTable(originOrderCache.orderID, targetOrderCache.orderID, hostID, userDBModel);
                }

                response.orderToken = orderToken;

                socketResponse.data = response;
                response.newOrderCache = targetOrderCache;

                if (targetOrderCache.shareShopOrder()) {
                    ShareShopApi.notifyServerchangeTable(originOrderId, originTableModel.fsmtablename, targetOrderCache.orderID, targetTableModel.fsmtablename, 1, null);
                }

                // 保存换桌/并桌记录
                TableDBUtil.addChangeTable(originOrderId, originTableModel.fsmtableid, targetTableModel.fsmtableid, "", userDBModel.fsUserName, originOrderCache.shopID);
                TableDBUtil.writeTableChanged(originOrderId, targetOrderCache.orderID, originTableNo, targetTableNo,
                        originTableModel.fsmtablename, targetTableModel.fsmtablename, originTableModel.fsmareaid, targetTableModel.fsmareaid,
                        originOrderCache.areaName, targetOrderCache.areaName, targetOrderCache.businessDate, operationKind, tempOriginalMenuItems, userDBModel);
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniqTarget, targetTableNo, "", " 换并桌 --- 目标桌台");
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniqOrigin, originTableNo, originOrderId, " 换并桌 ---原桌台");
        }

        return socketResponse;
    }

    /**
     * 处理口碑订单回流 桌号数据
     *
     * @param orderCache
     * @param tableId
     * @param tableName
     */
    private static void handlerKBTableNo(OrderCache orderCache, String tableId, String tableName) {
        //根据桌码类型进行回流
        if (TextUtils.equals(ServerSettingHelper.getTableQrCodeType(), META.VALUE_TABLE_QR_CODE_KB)) {
            //口碑码回流id
            orderCache.kbTableNo = tableId;
        } else {
            //美味码回流name
            orderCache.kbTableNo = tableName;
        }
    }

    /**
     * 换台、并台
     *
     * @param request        ChangeTableRequest的request
     * @param socketResponse
     * @return
     */
 /*   public static SocketResponse doChangeTableOld(String orderToken, JSONObject request, SocketResponse socketResponse, UserDBModel userDBModel, String hostID) {
        MtableDBModel newTable = TableDBUtil.getMTableById(request.getString("targetTableID"));
        if (newTable == null) {
            socketResponse.code = -1;
            socketResponse.message = "没有查到该桌台";
            return socketResponse;
        }
        ChangeTableResponse response = new ChangeTableResponse();

        OrderCache originOrderCache = null;
        OrderCache targetOrderCache = null;

        MtableDBModel originTableModel = TableDBUtil.getMTableById(request.getString("originTableID"));
        if (originTableModel == null) {
            socketResponse.code = -1;
            socketResponse.message = "桌台异常，请退出重试";
            return socketResponse;
        }


        originOrderCache = OrderSession.getInstance().getOrder(request.getString("originOrderID"));
        if (originOrderCache == null) {
            socketResponse.code = -1;
            socketResponse.message = "没查到订单信息";
            return socketResponse;
        }

            *//*
     * 非共享餐厅订单：
     * ------判断原始桌是否已有支付信息，如果有，则不能被合桌;
     * 共享餐厅订单不需要校验支付信息
     *//*
        if (!originOrderCache.shareShopOrder()) {
            String coutnReceive = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as count from tbSellReceive where fiStatus != '13' and fsSellNo='" + request.getString("originOrderID") + "'");
            int count = StringUtil.toInt(coutnReceive, 0);
            if (count > 0) {
                socketResponse.code = -2;
                socketResponse.message = "[" + originTableModel.fsmtablename + "]桌台已有支付信息，不能被合桌/换桌";
                return socketResponse;
            }
        }


        TableBizModel originTableBiz = TableDBUtil.optDefaultTableBizModel(request.getString("originTableID"));
        if (originTableBiz.hasUnConfirmedRapid()) {
            socketResponse.code = -1;
            socketResponse.message = "当前桌台还有秒点订单未被处理";
            return socketResponse;
        }
        TableBizModel targetTableBiz = TableDBUtil.optDefaultTableBizModel(request.getString("targetTableID"));


        if (targetTableBiz == null) {
            socketResponse.code = -1;
            socketResponse.message = "没有查到目标桌台";
            return socketResponse;
        }

        *//*
     * 锁原订单
     *//*
        final Object originLock = ServerCache.getInstance().optLock(request.getString("originOrderID"));
        synchronized (originLock) {
                *//*
     * 获取原始订单信息
     *//*
            originOrderCache = OrderSession.getInstance().getOrder(request.getString("originOrderID"));

            if (TextUtils.equals(targetTableBiz.fsmtableid, originOrderCache.fsmtableid)) {
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "重复操作";
                return socketResponse;
            }

                *//*
     * 如果目标桌台已开台，则获取目标桌台的订单
     *//*
            if (TableConstans.TABLE_STATUS_OPEN.equals(targetTableBiz.fsmtablesteid) && !TextUtils.isEmpty(targetTableBiz.fssellno)) {
                String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiBillStatus from tbSell where fsSellNo='" + targetTableBiz.fssellno + "'");
                if (TextUtils.equals(fiBillStatus, "4")) {
                    socketResponse.code = -1;
                    socketResponse.message = "目标桌台正在反结账，不能被合桌";
                    return socketResponse;
                }
                targetOrderCache = OrderSession.getInstance().getOrder(targetTableBiz.fssellno);
            }

            *//**
     * 开始锁桌--锁新桌台
     *//*
            String lockError = lockTable(request.getString("targetTableID"), request.getString("operateHostID"), request.getString("operateWaiterID"), request.getString("operateWaiterName"));

            if (!TextUtils.isEmpty(lockError)) {
                socketResponse.code = -1;
                socketResponse.message = lockError;
                return socketResponse;
            }

            *//**
     * 锁新订单
     *//*
            final Object targetLock = ServerCache.getInstance().optLock(request.getString("targetTableID"));
            synchronized (targetLock) {

                *//**
     * 如果目标桌台已有订单信息，则将原始订单数据merge到目标桌台的订单
     *//*
                if (targetOrderCache != null) {
                    if ((originOrderCache.shareShopOrder() && !targetOrderCache.shareShopOrder()) ||
                            (!originOrderCache.shareShopOrder() && targetOrderCache.shareShopOrder())) {
                        socketResponse.code = -1;
                        socketResponse.message = "订单属性不同，不支持合并";
                        return socketResponse;
                    }
                    targetOrderCache = OrderSession.getInstance().getOrder(targetTableBiz.fssellno);
                    //并桌必须更换orderToken
                    orderToken = ServerCache.getInstance().generateNewToken(targetOrderCache.orderID);
                        *//*
     * 开始替换单序
     *//*
                    int newSeq = targetOrderCache.currentSeq;
                    response.newSeqList = new ArrayList<>();

                    List<MenuItem> tempMenuList = new ArrayList<>(originOrderCache.originMenuList);
                    for (OrderSeqModel originSeq : originOrderCache.seqList) {
                        newSeq++;
                        for (int index = 0; index < tempMenuList.size(); index++) {
                            MenuItem temp = tempMenuList.get(index);
                            if (temp.menuBiz.orderSeqID == originSeq.seqNo) {
                                temp.menuBiz.orderSeqID = newSeq;
                                tempMenuList.remove(index);
                                index--;
                            }
                            if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                                for (MenuItem menuItem : temp.menuBiz.selectedModifier) {
                                    if (menuItem.menuBiz.orderSeqID == originSeq.seqNo) {
                                        menuItem.menuBiz.orderSeqID = newSeq;
                                    }
                                }
                            }
                        }
                        response.newSeqList.add(newSeq);
                        originSeq.seqNo = newSeq;
                    }

                    targetOrderCache.seqList.addAll(originOrderCache.seqList);

                    for (int i = 0; i < originOrderCache.originMenuList.size(); i++) {
                        originOrderCache.originMenuList.get(i).cleanMemberInfo();
                    }
                    targetOrderCache.originMenuList.addAll(originOrderCache.originMenuList);

                    targetOrderCache.currentSeq = newSeq;
                    targetOrderCache.currentSeq++;
                    targetOrderCache.personNum += originOrderCache.personNum;
                    *//**
     * 原始订单清除所有数据
     *//*
                    originOrderCache.clearAllMenu();

                    //免除服务费
                    originOrderCache.writeConfig(1);
                    originOrderCache.feeFreeUID = userDBModel.fsUserId;
                    originOrderCache.feeFreeUName = userDBModel.fsUserName;

                    originOrderCache.reCalcAllByAll();
                    *//**
     * 将订单设为已结账并存储
     *//*
                    originOrderCache.mergedOrderID = targetOrderCache.orderID;
                    originOrderCache.mergedOrderInfo = targetOrderCache.mergedOrderInfo = "服务员【" + userDBModel.fsUserName + "】并桌，导致订单结账 " + DateUtil.getCurrentDateTime();
                    //重算价格
                    OrderSession.getInstance().generatePaySession(originOrderCache, userDBModel, hostID);
                    OrderSession.getInstance().writePay(originOrderCache.orderID, true);
                    //完成结账
                    PayProcessor.manualSetPaySuccess(originOrderCache, originOrderCache.orderID, originOrderCache.fsmtableid, userDBModel, hostID, 1);
                } else {
                    targetOrderCache = originOrderCache;
                    response.newSeqList = new ArrayList<>();
                    for (OrderSeqModel originSeq : originOrderCache.seqList) {
                        response.newSeqList.add(originSeq.seqNo);
                    }
                }

                *//**
     * 如果新桌台未开台，则进行开台操作
     *//*
                RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "换桌，检测是否需要对目标桌台进行开台操作：" + JSON.toJSONString(targetTableBiz));
                if (!(TextUtils.equals(TableConstans.TABLE_STATUS_OPEN, targetTableBiz.fsmtablesteid)
                        && TextUtils.equals(targetTableBiz.fssellno, targetOrderCache.orderID))) {
                    *//**
     * 新桌台开台
     *//*
                    TableDBUtil.openTable(targetTableBiz.fsmtableid, targetOrderCache.orderID, userDBModel);
                }

                *//**
     * 订单库里的订单信息更新
     *//*
                targetOrderCache.fsmareaid = newTable.fsmareaid;
                targetOrderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + newTable.fsmareaid + "'");
                targetOrderCache.fsmtableid = newTable.fsmtableid;
                targetOrderCache.fsmtablename = newTable.fsmtablename;
                targetOrderCache.reCalcAllByAll();
                OrderSession.getInstance().writeOrder(targetOrderCache.orderID, targetOrderCache);
                OrderProcessor.saveOrder(targetOrderCache, null);
                *//**
     * 旧桌台关台
     *//*
                closeTable(socketResponse, originTableModel.fsmtableid, originOrderCache.orderID);
//                    socketResponse.code = SocketResultCode.SUCCESS;
//                    socketResponse.message = "换台成功";
                    RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "旧桌台关台(orderID:"+originOrderCache.orderID+",oldTableID:"+originTableModel.fsmtableid+") message:"+socketResponse.message);
                    *//**
     * 旧桌台解除锁定
     *//*
                    unlockTargetTable(originTableModel.fsmtableid);
                    if (TextUtils.equals(request.getString("operateHostID"), HostBiz.mealorder)) {
                        unlockTargetTable(newTable.fsmtableid);
                    }
                NotifyToClient.refreshTableOrOrders();
                NotifyToClient.refreshTableLock();

                response.orderToken = orderToken;

                socketResponse.data = response;
                response.newOrderCache = targetOrderCache;
            }

=======
>>>>>>> origin/master
        }
        return socketResponse;
    }
*/

    /**
     * 修改桌台预预付金状态----没有通知各站点刷新桌台状态
     */
    public static void modifyPrePay(SocketResponse res, final String tableId, @TableStatusBean.PrePayFlag final int status) {
        try {
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                @Override
                public Boolean doJob(SQLiteDatabase db) {
                    ContentValues values = new ContentValues();
                    values.put("prePayFlag", status);
                    db.update(DBModel.getTableName(TableBizModel.class), values, "fsmtableid = '" + tableId
                            + "' ", null);
                    return true;
                }
            });
            if (res != null) {
                res.message = "success";
                res.code = SocketResultCode.SUCCESS;
            }
            NotifyToClient.refreshTableOrOrders();
        } catch (Exception e) {
            if (res != null) {
                res.code = SocketResultCode.BUSINESS_FAILED;
            }
            LogUtil.logError(e);
        }
    }


    /**
     * 修改桌台预结单打印状态
     */
    public static void modifyPrePrint(SocketResponse res, final String tableId, final String sellNo,
                                      @TableStatusBean.OccupyFlag final int status) {
        try {
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                @Override
                public Boolean doJob(SQLiteDatabase db) {
                    ContentValues values = new ContentValues();
                    values.put("fioccupyflag", status);
                    db.update(DBModel.getTableName(TableBizModel.class), values, "fsmtableid = '" + tableId
                            + "' and fssellno = '" + sellNo + "'", null);
                    return true;
                }
            });
            if (res != null) {
                res.message = "success";
                res.code = SocketResultCode.SUCCESS;
            }

            // 修改预结单打印状态后，需同步给排队
            NotifyToClient.refreshTableBizQueue(tableId);
        } catch (Exception e) {
            if (res != null) {
                res.code = SocketResultCode.BUSINESS_FAILED;
            }
            LogUtil.logError(e);
        }
    }

    /**
     * 根据桌台，获取当前桌台正在操作的订单号
     *
     * @param tableID String
     * @return String | orderID
     */
    public static String getOrderIDByTableID(String tableID) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tableBiz where fsmtableid='" + tableID + "'");
    }

    private final static Object lockTableLock = new Object();

    /**
     * 锁桌
     *
     * @param targetTableID   桌台ID
     * @param requestHostID   站点ID
     * @param requestUserID   收银员ID
     * @param requestUserName 收银员名称
     * @return
     */
    public static String lockTable(String targetTableID, String requestHostID, String requestUserID, String requestUserName) {
        return lockTable(targetTableID, requestHostID, requestUserID, requestUserName, true);
    }

    /**
     * 锁桌
     *
     * @param targetTableID    桌台ID
     * @param requestHostID    站点ID
     * @param requestUserID    收银员ID
     * @param requestUserName  收银员名称
     * @param needUnlockOthers 锁定桌台的同时是否需要解锁其他桌台
     * @return
     */
    public static String lockTable(String targetTableID, String requestHostID, String requestUserID, String requestUserName, boolean needUnlockOthers) {
        String errorInfo = "";
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(targetTableID, "", requestHostID + "站点 服务员：" + requestUserName + " --> 锁桌 ");
        try {

            errorInfo = checkTableLock(requestHostID, requestUserID, targetTableID);

            if (TextUtils.isEmpty(errorInfo)) {
                TableDBUtil.lockTable(targetTableID, requestHostID, requestUserID, requestUserName, needUnlockOthers);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, targetTableID, "", requestHostID + "站点 服务员：" + requestUserName + " --> 锁桌 ");
        }
        return errorInfo;
    }

    /**
     * 检测桌台锁定
     *
     * @param hostID        String
     * @param userID        String
     * @param targetTableID String
     * @return
     */
    public static String checkTableLock(String hostID, String userID, String targetTableID) {
        String errorInfo = "";

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(targetTableID, "", hostID + " 站点 " + userID + " 检测桌台锁定");
        try {

            TableBizModel model = TableDBUtil.optDefaultTableBizModel(targetTableID);

            //如果桌台目前没有被锁定，
            if (model == null || model.lockedStatus == 0) {
                errorInfo = "";
            } else if (TextUtils.equals(hostID, model.lockedHostId)) {
                errorInfo = "";
            } else {
                boolean locked = false;
                //如果桌台已被锁定，判断指定站点登录的服务员是否和锁定的服务员一致。
                //如果不一致，则意味着出现了异常，导致原来未能释放桌台的锁定，此时则清除该桌台的锁定状态
                if (!TextUtils.equals(HostBiz.mealorder, hostID)) {
                    String loginUserID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select current_user_id from host_status where hostid='" + model.lockedHostId + "'");
                    if (!TextUtils.equals(model.lockedUserID, loginUserID)) {
                        errorInfo = "";
                        TableDBUtil.unlocakTable(model);
                    } else {
                        locked = true;
                    }
                } else {
                    locked = true;
                }
                if (locked) {
                    errorInfo = "该桌台目前由[" + model.lockedUserName + "]在[" + model.lockedHostId + "]操作";
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, targetTableID, "", hostID + " 站点 " + userID + " 检测桌台锁定");
        }
        return errorInfo;
    }

    /**
     * 解除指定站点锁定的桌台
     *
     * @param requestHostID String
     */
    public static void unlockTableByHost(String requestHostID) {
        synchronized (lockTableLock) {
            TableDBUtil.unlockTableByHostId(requestHostID);
        }
    }

    /**
     * 解除指定站点锁定的指定桌台
     *
     * @param targetTableID String
     * @param requestHostID String
     */
    public static void unlockTable(String targetTableID, String requestHostID) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(targetTableID, "", requestHostID + "站点 解除指定站点锁定的指定桌台 ");
        try {
            TableDBUtil.unlockTableByTableIdAndHostId(targetTableID, requestHostID);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, targetTableID, "", requestHostID + "站点 解除指定站点锁定的指定桌台 ");
        }
    }

    /**
     * 解除指定桌台的锁定
     *
     * @param targetTableID
     */
    public static void unlockTargetTable(String targetTableID) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(targetTableID, "", "解除指定桌台的锁定 ");
        try {
            TableDBUtil.unlockTableById(targetTableID);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, targetTableID, "", "解除指定桌台的锁定 ");
        }
    }


    /**
     * 解除指定用户锁定的桌台
     *
     * @param userID String
     */
    public static void unlockTableByUser(String userID) {
        synchronized (lockTableLock) {
            TableDBUtil.unlocakAllTableByUser(userID);
        }
    }

    /******************秒点消息处理**************************/

    public static void callService(String tableId) {
        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(tableId);
        if (tableBizModel != null) {
            tableBizModel.fiwxmsgflag = TableStatusBean.SERVICE_BELL;
            tableBizModel.flag = tableBizModel.flag | 2;
            tableBizModel.replace();
        }
    }

    /**
     * 新增秒点订单
     */
    public static void addNewRapidOrder(TempOrderDishesCache order) {
        String extra_order = JSON.toJSONString(order);
        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(order.fsmtableid);

        tableBizModel.extra_order = extra_order;
        tableBizModel.fiwxmsgflag = TableStatusBean.ORDER_DISHES;
        tableBizModel.flag = tableBizModel.flag | 4;
        updateRapidOrder(order.fsmtableid, tableBizModel.flag, TableStatusBean.ORDER_DISHES, extra_order);
    }

    /**
     * 清除秒点订单
     *
     * @param tableId
     */
    public static void cleanRapidOrder(String tableId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set extra_order='' , fiwxmsgflag='" + TableStatusBean.NONE + "', flag=(flag & ~4) where fsmtableid='" + tableId + "'");
    }

    /**
     * 更新秒点信息
     *
     * @param tableId
     */
    public static void updateRapidOrder(String tableId, int flag, int fiwxmsgflag, String extraOrder) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set extra_order='" + extraOrder + "' , fiwxmsgflag='" + fiwxmsgflag + "', flag='" + flag + "' where fsmtableid='" + tableId + "'");
    }

    /**
     * 获取所有的锁定的桌台列表
     *
     * @return List<String>
     */
    public static List<String> getLockedTableIDList() {
        List<String> idList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsmtableid from tableBiz where lockedStatus='1'");
        if (idList == null) {
            idList = new ArrayList<>();
        }
        return idList;
    }

    /**
     * 清台---所有桌台
     */
    public static void cleanAllTable() {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set fsMTableSteId='1',fsSellNo='',flag = '0'");
    }

    /**
     * 清台---指定桌台
     */
    public static void cleanTableByTableId(String fsmtableid) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set fsMTableSteId='1',fsSellNo='' where fsMTableId='" + fsmtableid + "'");
    }

    /**
     * 桌台是否空闲
     *
     * @param tableID String
     * @return boolean
     */
    public static boolean checkTableFree(String tableID) {
        String tableStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMTableSteId from tableBiz where fsMTableId='" + tableID + "'");
        return TextUtils.equals(TableConstans.TABLE_STATUS_FREE, tableStatus);
    }

    /**
     * 获取未清台的桌子名称
     *
     * @return
     */
    public static String getUncleanTable() {
        String sql = "select tbmtable.fsMTableName as fsMTableName from tbmtable left join tableBiz on tbmtable.fsmtableid = tableBiz.fsmtableid where tableBIz.fsMTableSteId='2' limit 1";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 查询桌台是否存在
     *
     * @param fsmtableid 桌台ID
     * @return true:存在 ； false: 不存在
     */
    public static boolean isExist(String fsmtableid) {
        String resultTable = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tbmtable where fiStatus in ('1', '2') and fsmtableid='" + fsmtableid + "'");
        if (!TextUtils.isEmpty(resultTable)) {
            return true;
        }
        //已被删除的桌台
        String deleteBizTable = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tbmtable where fiStatus in ('9','13') and fsmtableid in (select fsmtableid from tablebiz where fsmtablesteid = '2' or extra_order <> '' or ((flag & 2) == 2) or ((flag & 4) == 4) ) and fsmtableid='" + fsmtableid + "'");
        if (!TextUtils.isEmpty(deleteBizTable)) {
            return true;
        }

        return false;
    }

    /**
     * 获取桌台上账单信息
     *
     * @param fsmtaleid 桌台ID
     * @return JSONObject
     */
    public static JSONObject getSellJSONObject(String fsmtaleid) {
        return DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select * from tbsell where fssellno=(select fssellno from tableBiz where fsmtableid='" + fsmtaleid + "')");
    }

    /**
     * 获取所有桌台--包含业务
     * 美小二用
     *
     * @return
     */
    public static List<MtableDBModel> getAllTablesForWaiter() {
        String sql = "select tbMTable.fsmtableid as fsmtableid, tbMTable.fsmtablename as fsmtablename, tbMTable.fsmtableclsid as fsmtableclsid, tbMTable.fiseats as fiseats, tbMTable.fsmareaid as fsmareaid, tbMTable.fiSortOrder, tbMTable.fsshopguid, IFNULL(tableBiz.fsmtablesteid, 1) as fsmtablesteid, (case tbMTable.fistatus when '0' then '1' else tbMTable.fistatus end) as fistatus " +
                "from tbMTable left join tableBiz on tbMTable.fsmtableid = tableBiz.fsmtableid where tbMTable.fistatus in (1, 2)";
        List<MtableDBModel> mtableDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        return mtableDBModelList;
    }

    /**
     * 获取所有已开台桌台业务数据--- 桌台ID，开台时间，订单金额
     * 美小二用、秒付纯收银用
     *
     * @return
     */
    public static List<TableBizSimpInfo> getAllTablesBizInfo() {
        String sql = "select tbsell.fdExpAmt as fdExpAmt,tableBiz.fsmtableid fsmtableid, tableBiz.fsopenhstime fsopenhstime, tbmtable.fsmtableName from tableBiz left join tbmtable on tableBiz.fsmtableid = tbmtable.fsmtableid left join tbsell on tableBiz.fssellno=tbsell.fssellno where tableBiz.fsmtablesteid = '2'";
        List<TableBizSimpInfo> tableBizSimpInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TableBizSimpInfo.class);
        if (ListUtil.listIsEmpty(tableBizSimpInfos)) {
            tableBizSimpInfos = new ArrayList<>();
        }
        return tableBizSimpInfos;
    }

    /**
     * 根据桌台ID查询桌台基础信息及业务信息
     *
     * @param fsmtableid
     * @return
     */
    public static JSONObject getTableInfoAndBizByTableId(String fsmtableid) {
        return DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select tbMTable.fsmtableid as fsmtableid, tbMTable.fsmtablename as fsmtablename, tbMTable.fsmtableclsid as fsmtableclsid, tbMTable.fiseats as fiseats, tbMTable.fsmareaid as fsmareaid, tbMTable.fiSortOrder, tbMTable.fsshopguid, (case tableBiz.fsmtablesteid when '' then '1' else tableBiz.fsmtablesteid end) as fsmtablesteid, (case tbMTable.fistatus when '0' then '1' else tbMTable.fistatus end) as fistatus from tbMTable left join tableBiz on tbMTable.fsmtableid = tableBiz.fsmtableid where tbMTable.fistatus in (1, 2) and  tbmtable.fsmtableid='" + fsmtableid + "'");
    }

    /**
     * 获取所有桌台分类
     * 美小二用
     *
     * @return
     */
    public static List<JSONObject> getAllTableCls() {
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMTableCls");
    }

    /**
     * 获取所有桌台颜色对象
     * 美小二用
     *
     * @return
     */
    public static List<JSONObject> getAllTableSet() {
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMTableSte");
    }

    /**
     * 获取所有餐区对象
     * 美小二用
     *
     * @return
     */
    public static List<JSONObject> getAllArea() {
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbMArea");
    }

    /**
     * 获取已开台的桌台数量
     *
     * @return int
     */
    public static int getOpendTableCount() {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tableBiz where fsmtablesteid = '2'");
        return StringUtil.toInt(count);
    }

    /**
     * 获取门店桌台数量
     *
     * @return int
     */
    public static int getTableCount() {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbmtable");
        return StringUtil.toInt(count);
    }

    public static boolean fixTableStatusByOrderID(String orderID) {
        int payed = 0;
        String payedStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select payed from order_pay_cache where order_id='" + orderID + "'");
        if (!TextUtils.isEmpty(payedStr)) {
            payed = StringUtil.toInt(payedStr, 0);
        }
        int orderStatus = 0;
        String orderStatusStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_status from order_cache where order_id='" + orderID + "'");
        if (!TextUtils.isEmpty(orderStatusStr)) {
            orderStatus = StringUtil.toInt(orderStatusStr, 0);
        }

        String tableID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select tableID from order_cache where order_id='" + orderID + "'");
        if (TextUtils.isEmpty(tableID)) {
            return false;
        }
        JSONObject ob = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fssellno,fsmtablesteid from tableBiz where fsmtableid='" + tableID + "'");
        int status = ob.getInteger("fsmtablesteid");
        String tableOrder = ob.getString("fssellno");

        boolean needRefresh = false;
        if (!(payed == 1 && orderStatus == OrderStatus.PAIED)) {
            //如果桌台是空闲状态
            if (status == 1) {
                needRefresh = true;
                openTable(tableID, orderID, null);
                OrderSession.updateOrderStatus(orderID, OrderStatus.NORMAL);
                OrderSession.setPayed(orderID, 0);
            } else if (status == 2) {
                if (payed == 1 || orderStatus == OrderStatus.PAIED) {
                    if (TextUtils.equals(tableOrder, orderID)) {
                        //如果已支付，且当前桌台关联的订单还是当前订单，则强制修正为未支付
                        needRefresh = true;
                        OrderSession.updateOrderStatus(orderID, OrderStatus.NORMAL);
                        OrderSession.setPayed(orderID, 0);
                    }
                }
            }
        } else {
            if (TextUtils.equals(tableOrder, orderID)) {
                //如果已支付，且当前桌台关联的订单还是当前订单，则强制修正为未支付
                needRefresh = true;
                OrderSession.updateOrderStatus(orderID, OrderStatus.NORMAL);
                OrderSession.setPayed(orderID, 0);
            } else {
                String unProcessTable = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tableBiz where fssellno='" + orderID + "'");
                if (!TextUtils.isEmpty(unProcessTable) && !TextUtils.equals(unProcessTable, tableID) && unProcessTable.contains("_")) {
                    needRefresh = true;
                    OrderSaveDBUtil.updateTableID(orderID, unProcessTable);
                    OrderSession.updateOrderStatus(orderID, OrderStatus.NORMAL);
                    OrderSession.setPayed(orderID, 0);
                }
            }
        }
        return needRefresh;

    }

    /**
     * 根据桌台id查询当前桌台绑定对站点id
     *
     * @param unLockTableId 桌台id
     * @return 站点id
     */
    public static String findHostIdByTableId(String unLockTableId) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select lockedHostId from tablebiz where fsmtableid='" + unLockTableId + "'");
    }

    /**
     * 是否可以关闭桌台
     *
     * @param sellNo
     * @return
     */
    public static String canCloseTable(String sellNo) {
        String sql = "select fiselltype from order_cache where order_id = '" + sellNo + "'";
        Integer fiselltype = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "fiselltype", Integer.class);
        if (fiselltype != null && fiselltype == 1) {
            LogUtil.log("快餐不需要清台");
            return "";
        }
        String sqlTable = "select * from tbmtable where fistatus in (1,2) and fsmtableid in (select tableID from order_cache where order_id = '" + sellNo + "')";
        MtableDBModel mtableDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlTable, MtableDBModel.class);
        if (mtableDBModel == null) {
            return "";
        }
        TableBizModel originTableBizModel = TableDBUtil.optDefaultTableBizModel(mtableDBModel.fsmtableid);
        if (originTableBizModel.hasUnConfirmedRapid()) {
            return "当前桌台还有秒点订单未被处理";
        }

        if (!KDSUtils.isOrderServed(sellNo)) {
            return "当前桌台还有菜品未上齐";
        }
        return "";
    }

    /**
     * 设置菜品默认的提成人信息
     *
     * @param menuItems       要设置的菜品列表
     * @param openOrderUserId 开单人id
     */
    public static void checkBonusInfo(List<MenuItem> menuItems, String openOrderUserId) {
        checkBonusInfo(menuItems, UserDBUtils.queryById(openOrderUserId));
    }

    public static void checkBonusInfo(List<MenuItem> menuItems, UserDBModel openOrderUser) {
        if (ListUtil.isEmpty(menuItems)) {
            return;
        }
        // 后台"提成菜模式"为关闭
        if (TextUtils.equals("0", CommonDBUtil.getConfigWithDefault(DBOrderConfig.BONUS_MODE, "0"))) {
            return;
        }
        for (MenuItem item : menuItems) {
            if (item == null || item.menuBiz == null || !item.isBonus() || item.hasAllVoid()) {
                continue;
            }
            String key = item.itemID + "_" + item.currentUnit.fiOrderUintCd;
            if (openOrderUser != null && openOrderUser.fiIsSales == 1) {// 开单人是销售人员
                String sql = "SELECT tbBonusManageMenu.fiItemCd || '_' || tbBonusManageMenu.fiOrderUintCd FROM tbBonusManageMenu" +
                        " INNER JOIN tbBonusManageUser ON tbBonusManageMenu.fsBonusMenuGuid=tbBonusManageUser.fsBonusMenuGuid" +
                        " WHERE tbBonusManageUser.fsUserId='" + openOrderUser.fsUserId + "' ";
                List<String> bonusMenus = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                // 菜品有提成人可以关联 && 菜品可关联的提成人中包含开单人
                if (!ListUtil.isEmpty(bonusMenus) && bonusMenus.contains(key)) {
                    // 默认关联到开单人
                    if (!item.menuBiz.checkBonus()) {
                        BonusUtils.setMenuItemBonusUser(item, openOrderUser.fsUserId, openOrderUser.fsUserId);
                    }
                } else {
                    // 默认关联到"无"
                    if (!item.menuBiz.checkBonus()) {
                        BonusUtils.setMenuItemBonusUser(item, "", "");
                    }
                }
            } else {
                // 开单人不是销售人员，默认关联到"无"
                if (!item.menuBiz.checkBonus()) {
                    BonusUtils.setMenuItemBonusUser(item, "", "");
                }
            }
        }
    }
}
