package com.mwee.android.pos.businesscenter.business.kds;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Pair;

import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.businesscenter.business.kds.algorithm.KdsAlgorithm;
import com.mwee.android.pos.businesscenter.business.kds.normal.KdsGeneral;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.kds.KdsMakeState;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: KdsManager
 * @Description:
 * @author: Cannan
 * @date: 2018/11/6 下午1:50
 */
public class KdsManager {

    /**
     * 各档口最大同时制作菜品数量
     */
    public static final int KDS_MAX_MAKE_MENU = 20;

    /**
     * 记录上次划菜的档口列表
     */
    public List<String> lastServedDeptIds = null;

    private volatile static KdsManager instance;

    private KdsManager() {
    }

    public static KdsManager getInstance() {
        if (instance == null) {
            synchronized (KdsManager.class) {
                if (instance == null) {
                    instance = new KdsManager();
                }
            }
        }
        return instance;
    }

    public void init() {
        KdsAlgorithm.getInstance().init();
        KdsGeneral.getInstance().init();
    }

    /**
     * 下单、加菜
     *
     * @param orderCache
     * @param seq
     * @param hostId
     * @param user
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void order(OrderCache orderCache, String seq, String hostId, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始下单");
            // 待操作的菜品
            List<SellOrderItemDBModel> sellOrderItemDBModelList;
            String sql = "" +
                    "select *\n" +
                    "from tbSellOrderItem\n" +
                    "where fsSellNo = '" + orderCache.orderID + "'\n" +
                    "  and fiOrderItemKind in ('1', '3', '4')\n" +
                    "  and fiOrderMode in (1, 3)\n" +
                    "  and fsSellDate = '" + orderCache.businessDate + "'\n" +
                    "  and fiOrderSeq = '" + seq + "'";
            sellOrderItemDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOrderItemDBModel.class);
            if (ListUtil.isEmpty(sellOrderItemDBModelList)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsManager#order 未能查询到批次[" + seq + "]待处理的菜品");
                return null;
            }
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsManager#order 批次[" + seq + "]的菜品数量: " + sellOrderItemDBModelList.size());

            // 不进入KDS系统的菜品(无制作部门的菜品) -- 不打印
            List<SellOrderItemDBModel> menuDisable = new ArrayList<>();
            // 菜品关联制作部门未绑定站点, 或者KDS不使用智能算法的菜品 -- 按原逻辑打印
            ArrayMap<String, Set<SellOrderItemDBModel>> menuKdsNormal = new ArrayMap<>();
            // KDS使用智能算法的菜品 - 进入算法的菜品，不在业务中心区分部门
            ArrayMap<String, Set<SellOrderItemDBModel>> menuKdsAlgorithm = new ArrayMap<>();
            // 菜品部门映射关系
            ArrayMap<String, List<String>> menuDeptMapping = new ArrayMap<>();

            for (SellOrderItemDBModel model : sellOrderItemDBModelList) {
                if (model.fiIsPrn != 1) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]配置不打印");
                    menuDisable.add(model);
                    continue;
                }
                List<DeptDBModel> deptDBModelList = KDSUtils.queryDeptByMenu(model, orderCache.fsmareaid);
                if (ListUtil.isEmpty(deptDBModelList)) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]未关联打印部门");
                    menuDisable.add(model);
                    continue;
                }
                MenuitemDBModel menuitemDBModel = MenuDBUtil.getUsefulMenuDBModelBy(model.fiItemCd);
                if (menuitemDBModel == null) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]未映射");
                    menuDisable.add(model);
                    continue;
                }

                List<String> deptIdList = menuDeptMapping.get(model.fiItemCd);
                if (deptIdList == null) {
                    deptIdList = new ArrayList<>();
                }

                for (DeptDBModel deptDBModel : deptDBModelList) {
                    HostDBModel hostByDept = KDSUtils.queryHostByDeptId(deptDBModel.fsDeptId);
                    if (hostByDept == null) {
                        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]关联的打印部门[" + deptDBModel.fsDeptId + ", " + deptDBModel.fsDeptName + "]未绑定制作站点");
                        Set<SellOrderItemDBModel> origin = menuKdsNormal.get(deptDBModel.fsDeptId);
                        if (origin == null) {
                            origin = new HashSet<>();
                        }
                        origin.add(model);
                        menuKdsNormal.put(deptDBModel.fsDeptId, origin);
                        continue;
                    }

                    if (hostByDept.fiIsEnableKDS == 1) {//TODO:需要自测(发现阻塞测试流程，先注释掉),用不用KDS的智能算法
                        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]关联的打印部门[" + deptDBModel.fsDeptId + ", " + deptDBModel.fsDeptName + "], 已绑定站点[" + hostByDept.fsHostId + "]并启用智能算法");
                        Set<SellOrderItemDBModel> origin = menuKdsAlgorithm.get("default");
                        if (origin == null) {
                            origin = new HashSet<>();
                        }
                        origin.add(model);
                        menuKdsAlgorithm.put("default", origin);

                        deptIdList.add(deptDBModel.fsDeptId);
                    } else {
                        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品[" + model.fiItemCd + ", " + model.fsItemName + "]关联的打印部门[" + deptDBModel.fsDeptId + ", " + deptDBModel.fsDeptName + "], 已绑定站点[" + hostByDept.fsHostId + "], 但为使用智能算法");
                        Set<SellOrderItemDBModel> origin = menuKdsNormal.get(deptDBModel.fsDeptId);
                        if (origin == null) {
                            origin = new HashSet<>();
                        }
                        origin.add(model);
                        menuKdsNormal.put(deptDBModel.fsDeptId, origin);
                    }
                }
                menuDeptMapping.put(model.fiItemCd, deptIdList);
            }
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 下单分拣菜品完成");

            if (menuKdsNormal != null && menuKdsNormal.size() > 0) {
                KdsGeneral.getInstance().order(orderCache, menuKdsNormal, menuDeptMapping, hostId, user);
            }

            if (menuKdsAlgorithm != null && menuKdsAlgorithm.size() > 0) {
                KdsAlgorithm.getInstance().order(orderCache, menuKdsAlgorithm, menuDeptMapping, hostId, user);
            }

            NotifyToClient.refreshKds();
            return null;
        });
    }

    /**
     * 菜品称重
     *
     * @param orderId
     * @param fsSeq
     * @param hostId
     * @param user
     */
    public void weigh(String orderId, String fsSeq, String hostId, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                OrderCache order = OrderSession.getInstance().getOrder(orderId);
                if (order == null) {
                    return null;
                }
                MenuItem menuItem = OrderSaveDBUtil.getMenuByUniq(fsSeq);
                if (menuItem == null) {
                    return null;
                }
                KdsAlgorithm.getInstance().weigh(order, fsSeq, hostId, user);
                String sql = "update tbKdsMenuItemState set fiState = '" + (menuItem.menuBiz.fiItemMakeState == 2 ? KdsMakeState.Wait : KdsMakeState.ToBeProduced) + "' where fsOriginSeq = '" + fsSeq + "' and fiState = '" + KdsMakeState.NotWeighed + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            } catch (Exception e) {
                LogUtil.logError(e);
            }
            return null;
        });
    }

    /**
     * 起菜
     *
     * @param seqList
     * @param hostId
     * @param user
     */
    public void serving(List<String> seqList, String hostId, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始起菜");
                if (ListUtil.isEmpty(seqList)) {
                    return null;
                }
                // KDS 算法处理
                KdsAlgorithm.getInstance().serving(seqList, hostId, user);

                // 修改本地状态
                String strSeq = ListUtil.optSqlParams(seqList);
                String sql = "" +
                        "update tbKdsMenuItemState\n" +
                        "set fiState          = '" + KdsMakeState.ToBeProduced + "',\n" +
                        "    fsUpdateHostId   = '" + hostId + "',\n" +
                        "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                        "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                        "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                        "where (fsOriginSeq in (" + strSeq + ") or fsOriginSeq_M in (" + strSeq + "))\n" +
                        "  AND fiState = '" + KdsMakeState.Wait + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

                NotifyToClient.refreshKds();
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 催菜
     *
     * @param fsSellNo
     * @param seqList
     * @param hostID
     * @param user
     */
    public void hurry(String fsSellNo, List<String> seqList, String hostID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                if (ListUtil.isEmpty(seqList)) {
                    return null;
                }
                KdsAlgorithm.getInstance().hurry(fsSellNo, seqList);

                // 修改本地状态
                String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                String tarSeq = ListUtil.optSqlParams(seqList);
                String sqlUpdate = "" +
                        "update tbKdsMenuItemState\n" +
                        "set fiHurryCount     = fiHurryCount + 1,\n" +
                        "    fsHurryTime      = '" + currentTime + "',\n" +
                        "    fsHurryUserId    = '" + user.fsUserId + "',\n" +
                        "    fsHurryUserName  = '" + user.fsUserName + "',\n" +
                        "    fsUpdateHostId   = '" + hostID + "',\n" +
                        "    fsUpdateTime     = '" + currentTime + "',\n" +
                        "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                        "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                        "where fsOriginSeq in (select fsseq\n" +
                        "                  from tbsellorderitem\n" +
                        "                  where fsseq in (" + tarSeq + ")\n" +
                        "                     or fsseq_m in (" + tarSeq + "))\n" +
                        "  AND fiState in ('" + KdsMakeState.ToBeProduced + "', '" + KdsMakeState.Making + "')";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlUpdate);

                NotifyToClient.kdsUrge(fsSellNo, seqList);
                NotifyToClient.refreshKds();
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 退菜
     *
     * @param seq         String | 退菜原菜品seq
     * @param num         BigDecimal | 退菜数量
     * @param isPkgHeader
     * @param hostID      String | 操作站点
     * @param user        UserDBModel | 操作用户
     */
    public synchronized void backMenu(String seq, BigDecimal num, boolean isPkgHeader, String hostID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                if (TextUtils.isEmpty(seq)) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsManager#backMenu 待退菜品标识为空");
                    return null;
                }

                // 本次待退菜的菜品seq(拆分后的单份标识)
                List<String> seqList;

                Map<String, BigDecimal> packNum = null;

                if (isPkgHeader) {
                    String sql = "select fsOriginSeq from tbKdsMenuItemState where fsOriginSeq_M = '" + seq + "' group by fsOriginSeq";
                    seqList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                    packNum = KDSUtils.queryDelNumByPackage(seq);
                } else {
                    seqList = new ArrayList<>();
                    seqList.add(seq);
                }
                if (ListUtil.isEmpty(seqList)) {
                    return null;
                }

                List<String> opt = new ArrayList<>();
                for (String fsSeq : seqList) {
                    String sql = "" +
                            "select fsSeq\n" +
                            "from tbKdsMenuItemState\n" +
                            "where fsOriginSeq = '" + fsSeq + "'\n" +
                            "  and fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "')\n" +
                            "order by fiState asc ";

                    BigDecimal limit = null;
                    if (isPkgHeader && packNum != null) {
                        limit = packNum.get(fsSeq);
                    }
                    if (limit == null) {
                        limit = num;
                    }

                    if (limit != null && limit.compareTo(BigDecimal.ZERO) > 0) {
                        sql += "limit " + limit.intValue();
                    }
                    List<String> var = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                    if (ListUtil.isEmpty(var)) {
                        continue;
                    }
                    opt.addAll(var);
                }

                if (ListUtil.isEmpty(opt)) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsManager#backMenu 待退菜品[" + seq + "], 未能从KDS系统中找到菜品");
                    return null;
                }
                KdsAlgorithm.getInstance().retreated(opt);
                // 更新本地数据
                String sqlUpdate = "update tbKdsMenuItemState set fiState = '" + KdsMakeState.Retired + "', fsUpdateHostId = '" + hostID + "', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserId = '" + user.fsUserId + "', fsUpdateUserName = '" + user.fsUserName + "' where fsSeq in (" + ListUtil.optSqlParams(opt) + ")";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlUpdate);

                NotifyToClient.refreshKds();
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 转菜
     *
     * @param menuSeq
     * @param target
     * @param hostID
     * @param user
     */
    public void transferMenu(List<String> menuSeq, OrderCache target, String hostID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                if (ListUtil.isEmpty(menuSeq)) {
                    return null;
                }

                String strSeq = ListUtil.optSqlParams(menuSeq);
                String sql = "" +
                        "update tbKdsMenuItemState\n" +
                        "set fsSellNo         = '" + target.orderID + "',\n" +
                        "    fsUpdateHostId   = '" + hostID + "',\n" +
                        "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                        "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                        "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                        "where fsOriginSeq in (" + strSeq + ") or fsOriginSeq_M in (" + strSeq + ")";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

                String sql2 = "select fsSeq from tbKdsMenuItemState where fsOriginSeq in (" + ListUtil.optSqlParams(menuSeq) + ") or fsOriginSeq_M in (" + strSeq + ")";
                List<String> optMenuSeq = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql2);
                if (ListUtil.isEmpty(optMenuSeq)) {
                    return null;
                }
                KdsAlgorithm.getInstance().menuTransfer(optMenuSeq, target);
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 换桌
     *
     * @param origin
     * @param target
     */
    public void transferTable(String origin, String target, String hostID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                if (TextUtils.isEmpty(origin) || TextUtils.isEmpty(target)) {
                    return null;
                }

                KdsAlgorithm.getInstance().tableTransfer(origin, target);
                String sql = "" +
                        "update tbKdsMenuItemState\n" +
                        "set fsSellNo         = '" + target + "',\n" +
                        "    fsUpdateHostId   = '" + hostID + "',\n" +
                        "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                        "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                        "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                        "where fsSellNo = '" + origin + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 菜品拆分
     * 拆分的操作会导致kds表中记录关联的原菜品 seq 变更
     *
     * @param originSeq String | 原菜品 seq
     * @param newSeq    String | 拆分出去新生成的菜品 seq
     * @param newNum    BigDecimal | 拆分出去新生成的菜品数量
     * @param type      int | 导致菜品拆分的操作(1: 部分赠菜, 2: 买减, 3: 部分转菜)
     */
    public void splitMenu(String originSeq, String newSeq, BigDecimal newNum, int type) {
        if (TextUtils.isEmpty(originSeq) || TextUtils.isEmpty(newSeq)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsManager#splitMenu 菜品信息为空");
            return;
        }
        String sql = "update tbKdsMenuItemState set fsOriginSeq = '" + newSeq + "' where fsSeq in (select fsSeq from tbKdsMenuItemState where fsOriginSeq = '" + originSeq + "' and fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "') order by fiState limit " + newNum.intValue() + ")";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 划菜(仅支持 KDS 站点划菜操作)
     *
     * @param barCode
     * @param deptId  String | 制作部门
     * @param name    String | 菜品名称
     * @param foodId  String | {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiItemCd}
     * @param num     BigDecimal | 划菜数量
     */
    public synchronized void delimit(String barCode, String deptId, String name, String foodId, BigDecimal num, boolean isUnAssign, String hostID, UserDBModel user) {
        try {
            KdsAlgorithm.getInstance().delimit(deptId, name, foodId, num, isUnAssign, hostID, user, barCode);
            NotifyToClient.refreshKds();
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
    }

    /**
     * 取消划菜
     *
     * @param deptId
     * @param hostID
     * @param user
     */
    public synchronized void cancelDelimit(String deptId, String hostID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            try {
                KdsAlgorithm.getInstance().unDelimit(deptId, hostID, user);
                NotifyToClient.refreshKds();
            } catch (Exception ex) {
                LogUtil.logError(ex);
            }
            return null;
        });
    }

    /**
     * 加载档口相关菜品
     *
     * @param depID
     * @param state
     * @param pageSize
     * @param pageNum
     * @return
     */
    public Pair<Integer, List<KdsMenuViewBean>> query(String depID, int state, int pageSize, int pageNum) {
//        return KdsAlgorithm.getInstance().query(depID, state, pageSize, pageNum);
        return KdsAlgorithm.getInstance().queryDishByDept(depID, state, pageSize, pageNum);
    }

    public Pair<Integer, Map<String, List<KdsMenuViewBean>>> queryByMaking(String hostId) {
        if (TextUtils.isEmpty(hostId)) {
            return null;
        }
        List<DeptDBModel> deptList = KDSUtils.queryDeptByHostId(hostId);
        if (ListUtil.isEmpty(deptList)) {
            return null;
        }

        int count = 0;
        Map<String, List<KdsMenuViewBean>> result = new HashMap<>();
        for (DeptDBModel dept : deptList) {
            List<KdsMenuViewBean> dishList = KdsAlgorithm.getInstance().queryByMaking(dept.fsDeptId);
            if (ListUtil.isEmpty(dishList)) {
                continue;
            }
            count += dishList.size();
            result.put(dept.fsDeptName, dishList);
        }
        return new Pair<>(count, result);
    }

    /**
     * 结账
     *
     * @param orderID
     */
    public void payFinish(String orderID) {
        try {
            KdsAlgorithm.getInstance().payFinish(orderID);
            NotifyToClient.refreshKds();
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
    }

    /**
     * 菜品是否进入kds系统
     *
     * @param fsSeq String | 需要查询的菜品唯一标识
     * @return
     */
    public boolean inKdsSys(String fsSeq) {
        String sql = "select count(*) from tbKdsMenuItemState where fsOriginSeq = '" + fsSeq + "'";
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), 0);
        return count > 0;
    }

    /**
     * 菜品是否进入kds系统
     *
     * @param seqList List<String> | 需要查询的菜品唯一标识
     * @return
     */
    public String inKdsSys(List<String> seqList) {
        String sql = "" +
                "select fsitemname\n" +
                "from (select fsOriginSeq\n" +
                "      from tbKdsMenuItemState\n" +
                "      where fsOriginSeq in (" + ListUtil.optSqlParams(seqList) + ") or fsOriginSeq_M in (" + ListUtil.optSqlParams(seqList) + ")) m\n" +
                "       left join tbsellorderitem on m.fsOriginSeq = tbsellorderitem.fsseq";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 修改配料菜信息
     * TODO:点了10个菜，一半进入kds制作中，一半还在等待制作中
     *
     * @param fsSeq 菜品唯一标识
     * @return
     */
    public boolean changeDishIngredient(String fsSeq, String newFoodName) {
        String sql = "" +
                "select fsSeq\n" +
                "from tbKdsMenuItemState\n" +
                "where fsOriginSeq = '" + fsSeq + "'\n" +
                "  and fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "')\n" +
                "order by fiState asc ";
        List<String> var = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (ListUtil.isEmpty(var)) {
            LogUtil.log("KdsManager#changeDishIngredient 配料菜修改[" + fsSeq + "], 未能从KDS系统中找到菜品");
            return false;
        }
        return KdsAlgorithm.getInstance().changeDishIngredient(var, newFoodName);
    }

    public void refresh() {
        KdsGeneral.getInstance().refresh();
        KdsAlgorithm.getInstance().refresh();
    }

    /**
     * 释放kds相关资源
     */
    public void release() {
        // 清空缓存的数据
        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            String sql = "DELETE FROM tbKdsMenuItemState";
            db.execSQL(sql);
            String sql2 = "DELETE FROM tbKdsBarcode";
            db.execSQL(sql2);
            return null;
        });

        // 重置标识位
        DBMetaUtil.updateSettingsValueByKey(META.KDS_LOAD_SNAPSHOT, "0");
    }
}
