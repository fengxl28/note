package com.mwee.android.pos.businesscenter.air.driver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.advertising.AirWelcomeAdvertisingRequest;
import com.mwee.android.air.connect.business.advertising.AirWelcomeAdvertisingResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.tools.LogUtil;

/**
 * created by 2018/8/21
 *
 * @author lxd
 * Description:启动页广告Driver
 */
@SuppressWarnings("unused")
public class AirAdvertisingDriver implements IDriver {
    public static final String DRIVER_TAG = "advertising";

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    /**
     * 启动页广告接口
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/startUpImage")
    public SocketResponse loopMenuImportResult(SocketHeader head, String param) {
        SocketResponse<AirWelcomeAdvertisingResponse> socketResponse = new SocketResponse();

        JSONObject paramsObject = JSON.parseObject(param);
        String dimension = paramsObject.getString("dimension");
        AirWelcomeAdvertisingRequest request = new AirWelcomeAdvertisingRequest();
        request.dimension = dimension;

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof AirWelcomeAdvertisingResponse) {
                    AirWelcomeAdvertisingResponse response = (AirWelcomeAdvertisingResponse) responseData.responseBean;
                    socketResponse.data = response;
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.responseBean.errmsg;
                    LogUtil.logError("----advertising--1--responseBean.errno=" + responseData.responseBean.errno + "   responseBean.errmsg=" + responseData.responseBean.errmsg);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData.responseBean.errno == 100015) {
                    socketResponse.code = SocketResultCode.SUCCESS;
                    socketResponse.message = responseData.responseBean.errmsg;
                }else {
                    socketResponse.code = SocketResultCode.EXCEPTION;
                    socketResponse.message = responseData.resultMessage;
                }

                LogUtil.logError("----advertising--2--responseBean.errno=" + responseData.responseBean.errno + "   responseBean.errmsg=" + responseData.responseBean.errmsg);
                return false;
            }
        }, false);
        return socketResponse;
    }
}
