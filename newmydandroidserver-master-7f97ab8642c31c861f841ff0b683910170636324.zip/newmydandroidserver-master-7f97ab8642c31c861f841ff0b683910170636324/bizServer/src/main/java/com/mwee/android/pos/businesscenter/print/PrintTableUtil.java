package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 桌台相关的打印
 * Created by virgil on 2017/2/4.
 */

public class PrintTableUtil {


    /**
     * 开台单
     *
     * @param orderCache OrderCache | 订单
     */
    public static List<Integer>  openTableReport(OrderCache orderCache, String hostId) {
        if (orderCache.shareShopOrder()){
            return new ArrayList<>();
        }
        String sectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
       return openTableReport(orderCache.orderID, orderCache.personNum, orderCache.businessDate, orderCache.fsmtablename, sectionName, orderCache.waiterName, hostId);
    }

    /**
     * 开台单
     *
     * @param orderID      String | 订单号
     * @param personNum    String | 人数
     * @param businessDate String | 营业日期，yyyyMMdd格式
     * @param tableName    String | 桌台名称
     * @param sectionName  String | 餐段名称
     * @param waiterName   String | 服务员名称
     */
    public static List<Integer> openTableReport(final String orderID, final int personNum, final String businessDate, final String tableName, final String sectionName, final String waiterName, final String hostId) {
        // FIXME: 2017/6/5 new
        if (TextUtils.isEmpty(orderID)) {
            return new ArrayList<>(0);
        }
        List<Integer> printTaskIds = new ArrayList<>();
        if (!TextUtils.equals("1", CommonDBUtil.getConfig(DBPrintConfig.OPENT_TABLE_PRINTER))) {
            return printTaskIds;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                JSONObject datas = new JSONObject();
                datas.put("date", businessDate);
                datas.put("time", DateUtil.getCurrentDateTime("HH:mm"));
                datas.put("type", sectionName);
                datas.put("count", personNum);
                datas.put("fsCreateUserName", waiterName);
                datas.put("fssellno", orderID);
                datas.put("mealNO", tableName);
                datas.put("PrintTime", DateUtil.getCurrentTime());
                String fsPrinterName = "";
                if (!TextUtils.isEmpty(hostId)) {
                    fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
                }
                PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                        orderID, tableName, businessDate,
                        PrintJSONBuilder.generatePrintNO(),
                        waiterName,
                        "0",
                        PrintReportId.TABLE_OPEN_RECEIPT, hostId, true);
                task.uri = "table/open";
                task.fsPrnData = datas.toJSONString();
                task.fsPrinterName = fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                return null;
            }
        });

        return printTaskIds;
    }


    /**
     * 换桌单
     *
     * @param userName     String | 服务员名称
     * @param oldTableName String |  旧桌台名称
     * @param newTableName String |  新桌台名称
     * @param orderID      String |  订单号
     * @param newSeqList   List<String> |  需要换桌的菜品单序列表
     * @param hostId       String |  站点ID
     */
    public static List<Integer> changeTableReport(final String userName, final String oldTableName, final String newTableName, final String orderID, final List<Integer> newSeqList,
                                         final String hostId) {
        List<Integer> printTaskIds = new ArrayList<>();

        StringBuilder sb = new StringBuilder();
        sb.append("(");
        if (newSeqList.size() > 0) {
            for (Integer seqNO : newSeqList) {
                sb.append("'").append(seqNO).append("'").append(",");
            }
            sb.deleteCharAt(sb.length() - 1);
        } else {
            return printTaskIds;
        }
        sb.append(")");
        String tempDate = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsselldate from tbsell where fssellno='" + orderID + "'");

        String seqList = sb.toString();
        String sql = "select *,fsOrderUint,fsItemName,fsNote,  (fdSaleQty-fdBackQty) as fdSaleQty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                " where fsSellNo = '" + orderID + "'" +
                " and fiOrderItemKind <> '3'" +
                " and fiOrderMode in (1,3)" +
                " and fdSaleQty>fdBackQty" +
                " and fiOrderSeq in " + seqList + "";

        String sql2 = "select *,fsOrderUint,fsSeq_M, fsItemName, (fdSaleQty-fdBackQty) as fdSaleQty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                " where fsSellNo = '" + orderID + "'" +
                " and fiOrderItemKind = '3' " +
                " and fiOrderMode in (1,3)" +
                " and fdSaleQty>fdBackQty" +
                " and fiOrderSeq in " + seqList + "";

        List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        }

        List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintItemDataBean.class);

        if (SLITList == null) {
            SLITList = new ArrayList<>();
        }

        for (PrintItemDataBean parent : sellOrderItemDBModels) {
            for (PrintItemDataBean son : SLITList) {
                if (TextUtils.equals(son.fsSeq_M, parent.fsseq)) {
                    if (parent.SLIT == null) {
                        parent.SLIT = new ArrayList<>();
                    }
                    parent.SLIT.add(son);
                }
            }
        }

        JSONObject datas = new JSONObject();
        datas.put("targetTableNo", newTableName);
        datas.put("startTableNo", oldTableName);
        datas.put("fsCreateUserName", userName);
        datas.put("fssellno", orderID);
        JSONObject sell = new JSONObject();
        String fsCreateTime = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCreateTime from tbSell where fsSellNo =  '" + orderID + "'");
        sell.put("fsCreateTime", fsCreateTime);
        datas.put("Sell", sell);

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemDBModels)
                .setWithCurrentHost(false)
                .setWithDeptMake(true)
                .setWithDeptTransfer(true)
                .setCurrentHostId(hostId)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String deptID = entry.getKey();
            List<PrintItemDataBean> list = entry.getValue();
            DeptDBModel dept = processor.deptInfo.get(deptID);
            /**
             * 如果是制作部门，但是不能打印转桌单，则continue
             */
            if (dept.fiDeptCls == 2 && dept.fiIsChangeBill != 1) {
                continue;
            }
            datas.put("Dept", dept.fsDeptName);

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    orderID, oldTableName, tempDate,
                    PrintJSONBuilder.generatePrintNO(),
                    userName,
                    dept.fsDeptId,
                    PrintReportId.TABLE_CHANGE_RECEIPT,
                    hostId, true);
            task.uri = "table/change";
            task.fsPrnData = datas.toJSONString();
            task.fsPrinterName = dept.fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if(!task.printAtOnce){
                printTaskIds.add(task.fiPrintNo);
            }                }
        return printTaskIds;
    }
}
