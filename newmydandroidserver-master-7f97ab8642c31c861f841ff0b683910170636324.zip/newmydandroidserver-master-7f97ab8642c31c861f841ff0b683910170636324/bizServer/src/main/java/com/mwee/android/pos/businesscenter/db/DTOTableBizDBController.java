package com.mwee.android.pos.businesscenter.db;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by qinwei on 2019/3/11 8:55 PM
 * email: qin.wei@mwee.cn
 */
public class DTOTableBizDBController {
    /**
     * 根据id查询 桌台业务信息
     *
     * @param fsmtableid
     * @return
     */
    public TableBizModel queryById(String fsmtableid) {
        String sql = "select * from tableBiz where fsmtableid='" + fsmtableid + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, TableBizModel.class);
    }
}
