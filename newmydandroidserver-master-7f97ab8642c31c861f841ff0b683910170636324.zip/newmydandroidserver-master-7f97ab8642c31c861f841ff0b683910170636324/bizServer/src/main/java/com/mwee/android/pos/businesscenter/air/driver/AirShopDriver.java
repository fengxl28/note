package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.shop.GetDeptModelResonse;
import com.mwee.android.air.connect.business.shop.GetHostExteralModelResponse;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.MetaDBController;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by zhangmin on 2017/10/25.
 */

public class AirShopDriver implements IDriver {

    public static final String TAG = "airTShop";

    @Override
    public String getModuleName() {
        return TAG;
    }


    @DrivenMethod(uri = TAG + "/replaceTHostexternal")
    public SocketResponse replaceTHostexternal(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            HostexternalDBModel hostexternalDBModel = request.getObject("tHostexternal", HostexternalDBModel.class);
            hostexternalDBModel.fsUpdateUserId = (userDBModel == null ? "" : userDBModel.fsUserId);
            hostexternalDBModel.fsUpdateUserName = (userDBModel == null ? "" : userDBModel.fsUserName);
            hostexternalDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            hostexternalDBModel.sync = 1;
            hostexternalDBModel.replaceNoTrans();

            MetaDBController.updateSyncTime();
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/replaceTShopInfo")
    public SocketResponse replaceTShopInfo(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ShopDBModel shopDBModel = request.getObject("shopDBModel", ShopDBModel.class);
            shopDBModel.fsUpdateUserId = (userDBModel == null ? "" : userDBModel.fsUserId);
            shopDBModel.fsUpdateUserName = (userDBModel == null ? "" : userDBModel.fsUserName);
            shopDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            shopDBModel.sync = 1;
            shopDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/queryTHostexternal")
    public SocketResponse queryTHostexternal(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            GetHostExteralModelResponse hostExteralModelResponse = new GetHostExteralModelResponse();
            response.data = hostExteralModelResponse;

            int fiCls = request.getObject("fiCls", Integer.class);
            String sql = "select * from tbhostexternal where fiStatus = '1'" +
                    " and fsHostId = '" + head.hd +
                    "' and fiCls = '" + fiCls +
                    "' and  fsShopGUID = '" + head.shopid + "'";
            HostexternalDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, HostexternalDBModel.class);
            if (model == null) {
                response.message = "没有查询到外接设备信息";
                response.code = SocketResultCode.EXCEPTION;
                return response;
            }

            hostExteralModelResponse.model = model;
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/queryTDeptModel")
    public SocketResponse queryTDeptModel(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            GetDeptModelResonse deptModelResonse = new GetDeptModelResonse();
            response.data = deptModelResonse;

            String fsDeptId = request.getObject("fsDeptId", String.class);
            //todo 因为放开了多部门 小易的切单方式 所有的部门一致 所以可以随意拿一个
            DeptDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbDept where fiStatus = '1'", DeptDBModel.class);
            if (model == null) {
                response.message = "没有查询到厨房出菜点";
                response.code = SocketResultCode.EXCEPTION;
                return response;
            }

            deptModelResonse.deptDBModel = model;
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


}
