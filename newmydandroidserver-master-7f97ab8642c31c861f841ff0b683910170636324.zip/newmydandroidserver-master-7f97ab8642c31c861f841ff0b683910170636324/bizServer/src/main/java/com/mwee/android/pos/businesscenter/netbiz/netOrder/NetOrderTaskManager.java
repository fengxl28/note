package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by liuxiuxiu on 2018/1/22.
 */

public class NetOrderTaskManager {

    public final static int MAX_TASK_SIZE = 3;
    private static NetOrderTaskManager instance = new NetOrderTaskManager();


    //保存执行的任务队列
    public LinkedBlockingQueue<String> mDownloadWaitQueues;
    //保存正在下载的任务
    public HashMap<String, NetOrderTask> mDownloadingTasks;

    public static NetOrderTaskManager getInstance() {
        return instance;
    }

    private NetOrderTaskManager() {
        mDownloadWaitQueues = new LinkedBlockingQueue<>();
        mDownloadingTasks = new HashMap<>();
    }

    public NetOrderTask.OnNetOrderTaskOver onNetOrderTaskOver = new NetOrderTask.OnNetOrderTaskOver() {
        @Override
        public void over(String orderId) {
            executeNext(orderId);
        }
    };

    public void addOrderTask(String orderId) {
        if (mDownloadingTasks.size() >= MAX_TASK_SIZE) {
            addQueues(orderId);
        } else {
            start(orderId);
        }
    }

    private void addQueues(String orderId) {
        mDownloadWaitQueues.offer(orderId);
    }

    private void start(String orderId) {
        NetOrderTask task = new NetOrderTask(orderId, onNetOrderTaskOver);
        mDownloadingTasks.put(orderId, task);
        task.excute();
    }

    public void executeNext(String orderId) {
        mDownloadingTasks.remove(orderId);
        String entity = mDownloadWaitQueues.poll();
        if (entity != null) {
            addOrderTask(entity);
        }

    }


}
