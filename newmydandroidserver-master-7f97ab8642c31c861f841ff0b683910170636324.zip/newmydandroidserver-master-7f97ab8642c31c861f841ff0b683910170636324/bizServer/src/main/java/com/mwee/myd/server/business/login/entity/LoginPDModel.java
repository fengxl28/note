package com.mwee.myd.server.business.login.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * Created by zhangmin on 2018/7/9.
 */

public class LoginPDModel extends BusinessBean {

    public String SessionID = "";
    public String UserID = "";
    public String ShopID = "";
    public String ShopName = "";
    public String Tel = "";
    public String AD = "";
    public String NowAD = "";
    public String Notice = "";
    public String now = "";
    public String QR = "";
    public int PhoneQueue = 0;
    public int ForceMobile = 0;// 自助取号时，强制输入手机号
    public int QueueDisplayConf = 0;
    public int TVDisplayConf = 0;
    public int TotalDisplay = 0;// 打印订单是否显示价格
    public int BookEn = 0;// 是否可预订0否1可
    public int Mem = 0;// 是否支持会员 0关闭 1开启
    public String BookOP = "";// 最后一次预订操作时间
    public String QLogo = "";// 排号单logo
    public String CustVoice = "";// 自定义叫号语音
    public String OrderNotice = "";
    public String Specify = "";// 排号单备注
    public String SpecifyMore = "";// 排号单备注b64编码
    public String TVRemark = "";// 电视字幕
    public int Barcode = 0;// 条形码
    public String[] AP = new String[]{};// 自定义叫号语音
    public String ADNew = "";// 广告64编码
    public String TopImg = "";// 二维码上方img
    public String RightImg = "";// 二维码右方img
    public String active = "";// 二维码下方活动
    public String WxName = "";// 商家微信公众账号
    public String QueryPref = "";// 微信编号前缀
    public String PMStart = "";// 午市晚市分界点
    public int Bbox = 0;// 强制上传日志
    public String BookVersion = "";
    public String[] AM = new String[]{};// 午市
    public String[] UnLuckN = new String[]{};
    public String[] ReserveNum = new String[]{};
    public String CallWave = "";
    public String CallPrefix = "";
//    public Wave[] Wave = new Wave[]{};
//    public Wave[] CD = new Wave[]{};
//    public WaitDisc[] WaitDiscount = new WaitDisc[]{};
//    public WaitDisc2[] NewWaitDis = new WaitDisc2[]{};

    public String QueueVersion = "";
    public int CallType = 0;// 叫号方式0：平板叫号；1：取号终端叫号；2电视叫号
    public int PrintType = 0;// 打印方式0：平板打印；1：终端打印；2：就近打印
    public int Style = 0;
    public int Pause = 0;// 可以手动暂停手机取号
    public int checkcode = 0;// 校验码位数
    public String offQr = "";
    public int shopQr = 0;
    public int totalMsg = 0;// 消息总数
    public int KuaiCan = 0;// 快餐模式
    public int waiterPraise = 0;// 1/0
    public String shopWxQr = "";
    public String shopWxQrNotice = "";
    public int[] Services = new int[]{};
    public int[] PopedomInfo = new int[]{};// 账号类别

    public int shopVip = 0;//TODO （0未开通  1开通）
}
