package com.mwee.android.pos.businesscenter.business.message;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.driver.cashier.CashierPayProcessor;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lxx on 17/2/13.
 */

public class MessageOrderUtil {

    /**
     * 新增预定秒点信息
     *
     * @param rapidBookOrder
     * @param buinessDate
     */
    public static void addBookOrderMessage(RapidBookOrder rapidBookOrder, String buinessDate) {
        LogUtil.log("新增秒点预订单" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        MessageBiz.addBookOrderMsg(rapidBookOrder, buinessDate);
        NotifyToClient.addOrderMessage(MessageConstance.TYPE_BOOK, "-");
    }

    /**
     * 新增微信快餐---未处理消息
     *
     * @param tempOrderDishesCache
     * @param rapidPayment
     */
    public static void addUnDealFastFoodMsg(TempOrderDishesCache tempOrderDishesCache, RapidPayment rapidPayment) {
        addFastFoodMsg(tempOrderDishesCache, rapidPayment, "", "", MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.NONE);
    }

    /**
     * 新增预定秒点信息
     *
     * @param tempOrderDishesCache
     * @param rapidPayment
     */
    public static void addFastFoodMsg(TempOrderDishesCache tempOrderDishesCache, RapidPayment rapidPayment, String sellno, String number, int status) {
        if (tempOrderDishesCache == null || rapidPayment == null) {
            return;
        }
        LogUtil.logBusiness("新增秒点快餐单 " + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "; " + JSON.toJSONString(tempOrderDishesCache) + "; " + JSON.toJSONString(rapidPayment) + ";" +
                " " + sellno + "; " + number + " ; " + status);
        MessageBiz.addUnDealFastFoodMsg(tempOrderDishesCache, rapidPayment,
                HostUtil.getHistoryBusineeDate(DBMetaUtil.getSettingsValueByKey(META.SHOPID)), sellno, number, status);
        NotifyToClient.addFastFoodMessage(MessageDBUtil.getMsgType());
    }

    public static void updateFastFoodMsg(String orderId, String sellno, String number, int status) {
        LogUtil.logBusiness("更新秒点快餐单" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "; orderId = " + orderId + "; sellno = " + sellno + "; number = " + number + "; status = " + status);
        MessageBiz.updateFastFoodMsg(orderId, sellno, number, status);
        NotifyToClient.updateWechatFastFood(orderId);
    }

    /**
     * 新增秒点信息
     *
     * @param order
     * @param msgCategory
     * @param buinessStatus
     */
    public static void addRapidOrderMessage(TempOrderDishesCache order, int msgCategory,
                                            int buinessStatus) {
        addRapidOrderMessage(order, msgCategory, buinessStatus, "");
    }

    /**
     * 新增秒点信息
     *
     * @param order
     * @param msgCategory
     * @param buinessStatus 详细状态
     * @param reason        原因，理由，备注等
     */
    public static void addRapidOrderMessage(TempOrderDishesCache order, int msgCategory,
                                            int buinessStatus, String reason) {
        MessageBiz.addRapidOrderMsg(order, msgCategory, buinessStatus, reason);

        NotifyToClient.addOrderMessage(MessageConstance.TYPE_RAPID, order.fsmareaid, order.fsmtablename);
    }

    /**
     * 新增秒点单支付消息
     *
     * @param paySessrion
     * @param msgType
     */
    public static void addRapidPayMessage(final PaySession paySessrion, final OrderCache orderCache, String payAmt, int msgType, int buinessStatus) {
        if (paySessrion == null) {
            return;
        }
        if (orderCache == null) {
            return;
        }
        Map<String, String> map = new HashMap<>();
        map.put("tableName", orderCache.fsmtablename);  //桌台名称
        map.put("payAmt", payAmt);  //已支付金额
        map.put("allAmt", Calc.format(orderCache.priceTotalOriginAfterGift, RoundConfig.ROUND_SINGLE_PRICE).toString());  //订单总金额

        MessageBiz.addPayMsg(JSON.toJSONString(paySessrion), msgType,
                JSON.toJSONString(map), orderCache.fsmtableid,
                orderCache.fsmareaid, paySessrion.billNO,
                buinessStatus, paySessrion.businessDate,
                paySessrion.waiterName, orderCache.orderID);

        NotifyToClient.addPayMessage(msgType, orderCache.fsmareaid, orderCache.fsmtablename);

    }

    /**
     * 添加纯收银的消息
     *
     * @param payment        RapidPayment
     * @param businessStatus int
     */
    public static void addRapidOnlyPayMessage(RapidPayment payment, String fsSellNO, int businessStatus) {
        MessageBiz.addRapidOnlyPay(payment, fsSellNO, HostUtil.getHistoryBusineeDate(""), businessStatus);
        NotifyToClient.addPayMessage(MessageConstance.TYPE_ONLY_PAY, "-");
        if (APPConfig.isCasiher()) {
            CashierPayProcessor.msyRapidOnlyPay(payment.orderId);
        }
    }

    /**
     * 获取已支付金额
     *
     * @param payModels
     * @return
     */
    public static String getPayedAmt(List<PayModel> payModels) {
        BigDecimal payAmt = BigDecimal.ZERO;
        if (payModels != null && !payModels.isEmpty()) {
            for (PayModel model : payModels) {
                if (model.status != PayTypeStatus.DELETE) {
                    payAmt = payAmt.add(model.payAmount);
                }
            }
        }
        return Calc.formatShow(payAmt);
    }

    public static void saveRelation(String fssellNo, String outerOrderId) {

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where key = '" + outerOrderId + "' and type = '" + IOCache.TYPE_WECHAT_ORDER_SELLNO_MAPPING + "'");
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where value = '" + fssellNo + "' and type = '" + IOCache.TYPE_WECHAT_ORDER_SELLNO_MAPPING + "'");

        CacheModel cacheModel = new CacheModel();
        cacheModel.key = outerOrderId;
        cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.info = "";
        cacheModel.value = fssellNo;
        cacheModel.type = IOCache.TYPE_WECHAT_ORDER_SELLNO_MAPPING;
        cacheModel.updatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.replaceNoTrans();

    }

    public static String getWechatFastfoodOrder(RapidActionModel resultData, String outerOrderId, String fsSellNo, String mealNumber) {
        MessageFastFoodBean messageFastFoodBean = MessageDBUtil.getMessageFastfood(outerOrderId);
        if (messageFastFoodBean == null) {
            return "未找到快餐消息";
        }

        if (TextUtils.isEmpty(messageFastFoodBean.msgBody) || TextUtils.isEmpty(messageFastFoodBean.msgDes)) {
            return "订单信息异常";
        }

        RapidPayment rapidPayment = JSON.parseObject(messageFastFoodBean.msgDes, RapidPayment.class);
        TempOrderDishesCache tempOrderDishesCache = JSON.parseObject(messageFastFoodBean.msgBody, TempOrderDishesCache.class);
        if (tempOrderDishesCache == null || rapidPayment == null) {
            return "订单信息异常";
        }

        RapidPrePayFastfoodBiz.getWechatFastfood(resultData, tempOrderDishesCache, rapidPayment, fsSellNo, mealNumber);

        if (resultData.result != RapidResult.SUCCESS) {
            return resultData.errorInfo;
        }
        return "";
    }

}
