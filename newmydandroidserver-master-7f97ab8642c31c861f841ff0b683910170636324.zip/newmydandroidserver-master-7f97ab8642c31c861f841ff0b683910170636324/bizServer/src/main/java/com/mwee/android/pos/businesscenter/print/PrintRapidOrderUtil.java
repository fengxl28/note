package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookDishInfo;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookItemSimples;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrderInfo;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidApi;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/7/12.
 */

public class PrintRapidOrderUtil {

    /**
     * 打印秒点确认单
     *
     * @param tempOrderDishesCache OrderCache
     */
    public static List<Integer> printRapidConfirmMenuList(final TempOrderDishesCache tempOrderDishesCache, final String printUser, String hostId) {

        JSONObject datas = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsMTableName", tempOrderDishesCache.fsmtablename);
        sell.put("fiCustSum", tempOrderDishesCache.personNum);
        sell.put("fsSellDate", tempOrderDishesCache.businessDate);
        datas.put("Sell", sell);
        String waiterName = tempOrderDishesCache.waiterName;
        datas.put("PrintUser", printUser);
        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);
        int count = 0;
        List<JSONObject> sellOrderItemDBModels = new ArrayList<>();
        for (MenuItem temp : tempOrderDishesCache.tempSelectedMenuList) {
            if (temp.hasAllVoid()) {
                continue;
            }
            JSONObject ob = new JSONObject();
            ob.put("fsItemName", temp.name);
            ob.put("fdSaleQty", temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum));
            ob.put("fsOrderUint", temp.currentUnit.fsOrderUint);
            ob.put("fiOrderItemKind", 1);
            String fsNote = "";
            if (!temp.supportPackage()) {
                fsNote = !TextUtils.isEmpty(temp.menuBiz.selectedExtraStr) ? (temp.menuBiz.selectedExtraStr + ";" + temp.menuBiz.note) : temp.menuBiz.note;
            } else {
                fsNote = temp.menuBiz.note;
            }
            ob.put("fsnote", fsNote);
            BigDecimal itemCount = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
            if (temp.supportWeight()) {
                itemCount = BigDecimal.ONE;
            }
            if (temp.supportPackage()) {
                ob.put("fiOrderItemKind", 2);
                if (!ListUtil.isEmpty(temp.menuBiz.selectedPackageItems)) {
                    List<JSONObject> SLIT = new ArrayList<JSONObject>();
                    for (MenuItem packageItem : temp.menuBiz.selectedPackageItems) {
                        if (packageItem != null) {

                            JSONObject obpack = new JSONObject();
                            obpack.put("fiOrderItemKind", 3);
                            obpack.put("fsItemName", packageItem.name);
                            obpack.put("fdSaleQty", packageItem.menuBiz.buyNum);
                            count += packageItem.menuBiz.buyNum.intValue();
                            SLIT.add(obpack);

                        }
                    }
                    ob.put("SLIT", SLIT);
                }
            } else if (temp.supportIngredient()) {
                if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                    List<JSONObject> ingredientList = new ArrayList<>();
                    int modifierCount = 0;
                    for (MenuItem tempModifier : temp.menuBiz.selectedModifier) {
                        JSONObject obModifier = new JSONObject();
                        obModifier.put("fiOrderItemKind", 4);
                        obModifier.put("fsItemName", tempModifier.name);
                        BigDecimal tempCount = tempModifier.menuBiz.buyNum.subtract(tempModifier.menuBiz.voidNum);
                        obModifier.put("fdSaleQty", tempCount);
                        obModifier.put("fsOrderUint", tempModifier.currentUnit.fsOrderUint);
                        ingredientList.add(obModifier);
                        modifierCount += tempCount.intValue();
                    }
                    count += 1 + modifierCount;
                    ob.put("ingredientList", ingredientList);
                    if (!temp.supportWeight()) {
                        ob.put("fdSaleQty", 1);
                        while (itemCount.compareTo(BigDecimal.ONE) >= 1) {
                            count += 1 + modifierCount;
                            JSONObject obClone = (JSONObject) ob.clone();
                            obClone.put("ingredientList", ingredientList);
                            sellOrderItemDBModels.add(obClone);
                            itemCount = itemCount.subtract(BigDecimal.ONE);
                        }
                    }
                }
            } else {
                count += itemCount.intValue();
            }

            sellOrderItemDBModels.add(ob);
        }

        String phone = tempOrderDishesCache.phone;
        if (!TextUtils.isEmpty(phone) && phone.length() == 11) {
            phone = phone.substring(7, 11);
        }
        datas.put("phone", phone);

        datas.put("SellOrders", sellOrderItemDBModels);
        datas.put("Sub", count);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", tempOrderDishesCache.fsmtablename, tempOrderDishesCache.businessDate,
                printNO,
                waiterName,
                "0",
                PrintReportId.RAPID_ORDERED_CONFIRM_MENU, hostId, true);
        task.uri = "rapidOrder/rapid_menulist";
        task.fsPrnData = JSON.toJSONString(datas, SerializerFeature.DisableCircularReferenceDetect);
        task.fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
        List<Integer> printTaskIds = new ArrayList<>();
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

    /**
     * 打印秒点预定单
     *
     * @param rapidBookOrder RapidBookOrder
     */
    public static List<Integer> printRapidBookOrder(RapidBookOrder rapidBookOrder) {

        JSONObject datas = new JSONObject();
        String businessDate = HostUtil.getHistoryBusineeDate("");
        String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);

        String customName = rapidBookOrder.orderInfo.name;
        datas.put("customName", customName);

        String arriveTime = rapidBookOrder.orderInfo.orderTime;
        datas.put("arriveTime", arriveTime);

        String phone = rapidBookOrder.orderInfo.phone;
        if (!TextUtils.isEmpty(phone) && phone.length() == 11) {
            phone = phone.substring(7, 11);
        }
        datas.put("phone", phone);

        String deposit = Calc.formatShow(rapidBookOrder.orderInfo.deposit);
        datas.put("deposit", deposit);

        datas.put("peopleCount", rapidBookOrder.orderInfo.peopleCount);

        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);

        List<RapidBookItemSimples> itemSimples = rapidBookOrder.dishInfo.get(0).itemSimples;

        datas.put("SellOrders", itemSimples);

        BigDecimal count = BigDecimal.ZERO;
        for (RapidBookItemSimples rapidBookItemSimples : itemSimples) {
            if (rapidBookItemSimples != null && rapidBookItemSimples.itemQty != null) {
                count = count.add(rapidBookItemSimples.itemQty);
            }
        }

        datas.put("count", count);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "", businessDate,
                printNO,
                "秒点",
                "0",
                PrintReportId.RAPID_BOOK_ORDERED, hostId, true);
        task.uri = "rapidOrder/rapidBookOrder";
        task.fsPrnData = JSON.toJSONString(datas, SerializerFeature.DisableCircularReferenceDetect);
        task.fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
        List<Integer> printTaskIds = new ArrayList<>();
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }


    /**
     * 创建一个秒点预定单
     *
     * @return
     */
    public static RapidBookOrder optRapidBookOrder() {
        RapidBookOrder rapidBookOrder = new RapidBookOrder();
        RapidBookOrderInfo orderInfo = new RapidBookOrderInfo();  //订单头
        orderInfo.name = "张老板" + DateUtil.getCurrentDateTime("ss");
        orderInfo.deposit = new BigDecimal(DateUtil.getCurrentDateTime("mmss"));
        orderInfo.orderTime = DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm");
        orderInfo.peopleCount = 12;
        orderInfo.phone = "13789768976";

        List<RapidBookDishInfo> dishInfo = new ArrayList<>();  //订单菜品明细
        RapidBookDishInfo rapidBookDishInfo = new RapidBookDishInfo();
        rapidBookDishInfo.printNumber = 13;
        rapidBookDishInfo.itemSimples = new ArrayList<>();
        RapidBookItemSimples rapidBookItemSimples = new RapidBookItemSimples();
        rapidBookItemSimples.itemName = "小炒肉";
        rapidBookItemSimples.itemPrice = BigDecimal.TEN;
        rapidBookItemSimples.itemQty = new BigDecimal(9);
        rapidBookDishInfo.itemSimples.add(rapidBookItemSimples);

        RapidBookItemSimples rapidBookItemSimples2 = new RapidBookItemSimples();
        rapidBookItemSimples2.itemName = "红烧肉";
        rapidBookItemSimples2.itemPrice = new BigDecimal(38);
        rapidBookItemSimples2.itemQty = new BigDecimal(1);
        rapidBookDishInfo.itemSimples.add(rapidBookItemSimples2);

        RapidBookItemSimples rapidBookItemSimples3 = new RapidBookItemSimples();
        rapidBookItemSimples3.itemName = "粉蒸肉";
        rapidBookItemSimples3.itemPrice = new BigDecimal(39.99);
        rapidBookItemSimples3.itemQty = new BigDecimal(3);
        rapidBookDishInfo.itemSimples.add(rapidBookItemSimples3);

        dishInfo.add(rapidBookDishInfo);
        rapidBookOrder.dishInfo = dishInfo;
        rapidBookOrder.orderInfo = orderInfo;
        return rapidBookOrder;
    }


    /**
     * 新秒点预定消息----开发者模式下模拟有预定信息的新订单来
     */
    public static void newBookOrder() {
        if (!BaseConfig.isProduct()) {
            RapidBookOrder rapidBookOrder = optRapidBookOrder();
            RapidApi.newBookOrder(rapidBookOrder);
        }
    }

}
