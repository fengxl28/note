package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderProcess;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.component.datasync.net.GetNetOrderByIdRequest;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.tools.LogUtil;

/**
 * Created by liuxiuxiu on 2018/1/22.
 */

public class NetOrderTask {

    private String orderId = "";
    private OnNetOrderTaskOver onNetOrderTaskOver;

    public NetOrderTask(String orderId, OnNetOrderTaskOver onNetOrderTaskOver) {
        this.orderId = orderId;
        this.onNetOrderTaskOver = onNetOrderTaskOver;
    }

    public void excute() {
        //获取订单不重试
        getNetworkOrderById(orderId, 4);
    }

    /**
     * 根据订单号拉取订单
     * 外卖单 暂时仅仅接入了美团和饿了么
     *
     * @param appOrderId
     * @return
     */
    private String getNetworkOrderById(final String appOrderId, final int retrySeq) {
        BusinessCallback callback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                // 解析拉取到的数据
                int result = NetOrderProcess.parseNetworkData(responseData);
                TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(appOrderId);
                if (result == 1 && tempAppOrder != null && tempAppOrder.newOrder()) {
                    LogUtil.log("拉取单条外卖订单，发现是新单，弹窗提醒");
                    NotifyToClient.addNewTempAppOrder(appOrderId, tempAppOrder.bizType, tempAppOrder.orderTakeawaySource, tempAppOrder.date);
                }
                NetOrderApi.autoGetNetOrder(appOrderId, 0);

                if (onNetOrderTaskOver != null) {
                    onNetOrderTaskOver.over(appOrderId);
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动拉单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            TempAppOrder appOrder = NetOrderDBUtil.getTempAppOrderById(appOrderId);
                            if (appOrder == null) {
                                getNetworkOrderById(appOrderId, retrySeq + 1);
                            }
                        }
                    }, 2000);

                } else {
                    if (onNetOrderTaskOver != null) {
                        onNetOrderTaskOver.over(appOrderId);
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, "推送来了新订单消息，拉取网络订单详情：失败（网络获取失败）");
                return false;
            }
        };
        GetNetOrderByIdRequest getDataRequest = new GetNetOrderByIdRequest();
        getDataRequest.orderId = appOrderId;
        return BusinessExecutor.execute(getDataRequest, null, callback);
    }


    public interface OnNetOrderTaskOver {
        void over(String orderId);
    }

}
