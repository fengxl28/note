package com.mwee.android.pos.businesscenter.driver.cashier;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.GenIDPosRequest;
import com.mwee.android.cashier.connect.bean.http.GenIDPosResponse;
import com.mwee.android.cashier.connect.bean.http.GetCachedOrderPosRequest;
import com.mwee.android.cashier.connect.bean.http.GetCachedOrderPosResponse;
import com.mwee.android.cashier.connect.bean.http.SaveCachedOrderPosRequest;
import com.mwee.android.cashier.connect.bean.socket.GenTempOrderResponse;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.sync.ZipUtils;
import com.mwee.android.tools.StringUtil;

/**
 * 美收银相关的业务处理类
 * Created by virgil on 2018/2/1.】
 *
 * @author virgil
 */

public class CashierOrderProcessor {
    /**
     * 临时单号和真实单号的的映射
     */
    private static ArrayMap<String, String> tempOrderIDMap = new ArrayMap<>();

    /**
     * 判断订单号是否是临时订单号
     *
     * @param orderID String
     * @return String
     */
    public static String checkOrderIDValid(String orderID) {
        if (TextUtils.isEmpty(orderID)) {
            return orderID;
        }
        String mappingOrderID = tempOrderIDMap.get(orderID);
        if (TextUtils.isEmpty(mappingOrderID)) {
            return orderID;
        } else {
            return mappingOrderID;
        }
    }

    public static String submitCacheOrder(final OrderCache orderCache,
                                          PaySession session, UserDBModel user, String hostID) {
        final StringBuilder error = new StringBuilder();
        StringBuilder sb = new StringBuilder();
        String billNo = "";
        if (orderCache.checkTempOrder()) {
            GenIDPosRequest request = new GenIDPosRequest();
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GenIDPosResponse) {
                        GenIDPosResponse response = (GenIDPosResponse) responseData.responseBean;
                        if (response.data != null && !TextUtils.isEmpty(response.data.orderNum)) {
                            String originalOrderId = orderCache.orderID;
                            orderCache.orderID = response.data.orderNum;
                            tempOrderIDMap.put(originalOrderId, orderCache.orderID);
                            //5分钟之后，移除这个订单号的映射
                            GlobalLooper.postDelayed(() -> tempOrderIDMap.remove(originalOrderId), 1000 * 60 * 50);
                            orderCache.decreaseConfig(2);
                            sb.append(response.data.payNum);
                            OrderSession.getInstance().clearOrder(originalOrderId);
                            OrderSaveDBUtil.delete(originalOrderId);
                            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false,"submitCacheOrder");
                            PaySaveDBUtil.delete(originalOrderId);
                            return;
                        }
                    }
                    error.append("出现异常");
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    error.append(responseData.resultMessage);
                    return false;
                }
            }, false);
            if (sb.length() > 0) {
                billNo = sb.toString();
            }
        } else if (session != null) {
            billNo = session.billNO;
        }
        if (error.length() > 0) {
            return error.toString();
        }

        if (error.length() > 0) {
            return error.toString();
        }
        session = OrderUtil.buildPayCache(session, orderCache, billNo, hostID, user.fsUserId, user.fsUserName);
        session.orderID = orderCache.orderID;
        OrderSession.getInstance().writePay(session.orderID, session);
        //填充字段
        SaveCachedOrderPosRequest posRequest = new SaveCachedOrderPosRequest();
        posRequest.orderId = orderCache.orderID;
        posRequest.mealNumber = orderCache.mealNumber;
        posRequest.sellTime = orderCache.createTime;
        posRequest.sellDate = orderCache.businessDate;
        posRequest.orderStatus = orderCache.orderStatus;
        posRequest.userId = orderCache.waiterID;
        posRequest.hostId = orderCache.currentHostID;
        posRequest.expAmt = session.priceLeftToPay;
        posRequest.saleAmt = orderCache.optTotalPrice().add(orderCache.totalDiscountAmount);
        posRequest.person = orderCache.personNum;
        posRequest.sellType = orderCache.fiSellType;
        if (session != null) {
            posRequest.checkBillNo = session.billNO;
        }
        posRequest.orderInfo = ZipUtils.gzip(JSON.toJSONString(orderCache));
        if (session != null) {
            posRequest.payInfo = ZipUtils.gzip(JSON.toJSONString(session));
        }
        BusinessExecutor.execute(posRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                error.append(responseData.resultMessage);
                return false;
            }
        }, false);
        return error.toString();
    }

    /**
     * 获取缓存单
     *
     * @param orderID
     */
    public static SocketResponse<GenTempOrderResponse> getCachedOrderPos(String orderID) {
        SocketResponse<GenTempOrderResponse> socketResponse = new SocketResponse<>();
        GetCachedOrderPosRequest posRequest = new GetCachedOrderPosRequest();
        posRequest.orderID = orderID;
        final GenTempOrderResponse response = new GenTempOrderResponse();
        BusinessExecutor.execute(posRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetCachedOrderPosResponse) {
                    GetCachedOrderPosResponse posResponse = (GetCachedOrderPosResponse) responseData.responseBean;
                    OrderCache orderCache = null;
                    if (!TextUtils.isEmpty(posResponse.data.orderInfo)) {
                        orderCache = JSON.parseObject(ZipUtils.unGzip(posResponse.data.orderInfo), OrderCache.class);
                        if (orderCache != null) {
                            orderCache.reCalcAllByAll();
                            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "getCachedOrderPos");
                            response.updateOrderCache(orderCache);
                        }
                    }
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "未获取到订单";
                        return;
                    }
                    if (!TextUtils.isEmpty(posResponse.data.payInfo)) {
                        PaySession session = JSON.parseObject(ZipUtils.unGzip(posResponse.data.payInfo), PaySession.class);
                        response.realPrice = session.priceLeftToPay;
                        OrderSession.getInstance().writePay(session.orderID, session);
                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, false);
        socketResponse.data = response;
        if (socketResponse.data != null)
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "获取缓存单：" + socketResponse.data.toString());
        return socketResponse;
    }
}
