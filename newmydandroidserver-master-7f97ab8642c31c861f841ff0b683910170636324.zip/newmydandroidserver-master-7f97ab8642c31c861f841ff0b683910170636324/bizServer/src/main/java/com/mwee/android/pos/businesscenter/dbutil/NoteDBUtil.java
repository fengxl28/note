package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.NoteModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/11/17.
 */

public class NoteDBUtil {

    /**
     * 查询单个菜品的所有要求
     *
     * @param itemID 菜品ID
     * @return List<NoteModel>
     */
    public static List<NoteModel> getRequestByMenuItem(final String itemID, String fsMenuClsId, final String fsShopGUID) {
        String askGpIdsSql = "select distinct fsAskGpId from (select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '3' and fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fiItemCd = '" + itemID + "' " +
                "union all " +
                "select fsAskGpId from tbaskgp  where fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fiUseAllMenuCls = '1' " +
                "union all " +
                "select fsAskGpId from tbaskgpmenucls  where fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fsMenuClsId = '" + fsMenuClsId + "' )  as AskGpIds ";

//        askGpIdsSql = "select distinct fsAskGpId from (select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '1' and fistatus = '1' and fsshopguid = '" + fsShopGUID + "' " +
//                "union all " +
//                "select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '2' and fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fsMenuClsId = '" + fsMenuClsId + "' " +
//                "union all " +
//                "select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '3' and fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fiItemCd = '" + itemID + "' )  as AskGpIds ";
        return queryAsk(askGpIdsSql);
    }

    /**
     * 根据选中的菜品列表获取共有要求要求
     *
     * @param menuItemList 菜品列表
     * @param fsShopGUID   店铺id
     * @return List<NoteModel>
     */
    public static List<NoteModel> optNoteListByMenuList(List<MenuItem> menuItemList, String fsShopGUID) {

        StringBuilder itemIdsBuilder = new StringBuilder();
        StringBuilder clsIdsBuilder = new StringBuilder();
        itemIdsBuilder.append("select fsAskGpId from (");
        clsIdsBuilder.append("select fsAskGpId from (");

        String itemIdsSqlCommon = "select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '3' and fistatus = '1' and fsshopguid = '" + fsShopGUID + "'";
        String clsIdsSqlCommon = "select fsAskGpId from tbaskgpmenucls  where fistatus = '1' and fsshopguid = '" + fsShopGUID + "'";

        int size = menuItemList.size();
        for (int i = 0; i < size; i++) {
            MenuItem menuItem = menuItemList.get(i);
            if (menuItem == null) {
                continue;
            }
            itemIdsBuilder.append(itemIdsSqlCommon);
            itemIdsBuilder.append(" and fiItemCd = ");
            itemIdsBuilder.append("'");
            itemIdsBuilder.append(menuItem.itemID);
            itemIdsBuilder.append("'");

            clsIdsBuilder.append(clsIdsSqlCommon);
            clsIdsBuilder.append(" and fsMenuClsId = ");
            clsIdsBuilder.append("'");
            clsIdsBuilder.append(menuItem.categoryCode);
            clsIdsBuilder.append("'");

            if (i != size - 1) {
                itemIdsBuilder.append(" intersect ");
                clsIdsBuilder.append(" intersect ");
            }
        }
        itemIdsBuilder.append(") ");
        clsIdsBuilder.append(") ");

//        builder.toString的样子:
//        select fsAskGpId from  (
//        select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '3' and fistatus = '1' and fsshopguid = '215966' and fiItemCd = '1807170020'
//        intersect
//        select fsAskGpId from tbmenuitemaskgp  where fiRelationtype = '3' and fistatus = '1' and fsshopguid = '215966' and fiItemCd = '1807310002'
//        )

        String askGpIdsSql = "select distinct fsAskGpId from (" +
                itemIdsBuilder.toString() +
                "union all " +
                "select fsAskGpId from tbaskgp  where fistatus = '1' and fsshopguid = '" + fsShopGUID + "' and fiUseAllMenuCls = '1' and fsAskGpId != '1' " +
                "union all " +
                clsIdsBuilder.toString() + " ) as AskGpIds ";

        return queryAsk(askGpIdsSql);
    }

    /**
     * 执行要求组及要求明细查询操作
     *
     * @param askGpIdsSql
     * @return
     */
    private static List<NoteModel> queryAsk(String askGpIdsSql) {
        List<NoteModel> result = new ArrayList<>();
        List<String> askGpIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, askGpIdsSql);
        if (ListUtil.isEmpty(askGpIds)) {
            return result;
        }
        //过滤掉'做法'
        int index = askGpIds.indexOf("-1");
        if (index >= 0) {
            askGpIds.remove(index);
        }

        String askgpIdParam = ListUtil.optSqlParams(askGpIds);

        String askGpSql = "select * from tbaskgp where fsAskGpId in (" + askgpIdParam + ") and fistatus = 1";
        result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, askGpSql, NoteModel.class);
        if (ListUtil.isEmpty(result)) {
            return new ArrayList<>();
        }

        String askSql = "select * from tbask where fsAskGpId in (" + askgpIdParam + ") and fistatus = 1";
        List<AskDBModel> askDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, askSql, AskDBModel.class);

        if (!ListUtil.isEmpty(askDBModelList)) {
            for (AskDBModel askDBModel : askDBModelList) {
                for (NoteModel noteModel : result) {
                    if (TextUtils.equals(noteModel.groupID, askDBModel.fsAskGpId)) {
                        List<NoteItemModel> noteItemModels = noteModel.itemList;
                        if (ListUtil.isEmpty(noteItemModels)) {
                            noteItemModels = new ArrayList<>();
                            noteModel.itemList = noteItemModels;
                        }
                        NoteItemModel noteItemModel = new NoteItemModel();
                        noteItemModel.groupIDFather = askDBModel.fsAskGpId;
                        noteItemModel.id = askDBModel.fiId;
                        noteItemModel.name = askDBModel.fsAskName;
                        noteItemModel.fiIsShow = noteModel.fiIsShow;
                        if (askDBModel.fdAddPrice != null) {
                            noteItemModel.price = askDBModel.fdAddPrice;
                        }
                        noteItemModels.add(noteItemModel);

                        break;
                    }
                }
            }
        }
        return result;
    }

}
