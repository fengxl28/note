package com.mwee.android.pos.businesscenter.module.member.net;

import com.mwee.android.pos.businesscenter.business.koubei.future.ResultCallback;
import com.mwee.android.pos.businesscenter.netbiz.member.ServerMemberApi;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.callback.IResponse;

import java.util.List;

/**
 * 会员数据服务
 * Created by qinwei on 2019/3/12 11:29 AM
 * email: qin.wei@mwee.cn
 */
public class MemberHttpExecutor {
    /**
     * current thread running
     * 根据卡号查询详情
     *
     * @param companyId 公司id
     * @param shopId    门店id
     * @param cardNo    卡号
     * @param callback  回调
     */
    public static void loadMemberCardDetailsByCardNo(String companyId, String shopId, String cardNo, ResultCallback<NewMemberCardDetailsModel> callback) {
        ServerMemberApi.loadMemberCardDetailsByCardNo(companyId, shopId, cardNo, new IResponse<NewMemberCardDetailsModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }


    /**
     * 根据手机号查询会员卡列表
     *
     * @param companyId      公司id
     * @param shopId         门店id
     * @param mobile         手机号
     * @param verifyCode     验证码
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     * @param callback
     */
    public static void loadMemberCardListByMobile(String companyId, String shopId, String mobile, String verifyCode, int verifyCodeType, ResultCallback<List<NewMemberCardListItemModel>> callback) {
        ServerMemberApi.loadMemberCardListByMobile(companyId, shopId, mobile, verifyCode, verifyCodeType, new IResponse<List<NewMemberCardListItemModel>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<NewMemberCardListItemModel> info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }

    /**
     * 储值记录
     *
     * @param brandId
     * @param cardNoOrMobile
     * @param pageNo
     * @param callback
     */
    public static void loadMemberTradeDetail(String brandId, String cardNoOrMobile, int pageNo, ResultCallback<MemberTradeDetailModel> callback) {
        ServerMemberApi.queryMemberTradeDetail(brandId, cardNoOrMobile, pageNo, new IResponse<MemberTradeDetailModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, MemberTradeDetailModel info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }

    /**
     * 会员积分明细
     *
     * @param brandId
     * @param cardNoOrMobile
     * @param pageNo
     * @param callback
     */
    public static void loadMemberScore(String brandId, String cardNoOrMobile, int pageNo, ResultCallback<MemberScoreDetailModel> callback) {
        ServerMemberApi.queryMemberScore(brandId, cardNoOrMobile, pageNo, new IResponse<MemberScoreDetailModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, MemberScoreDetailModel info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }

    /**
     * 优惠券列表
     *
     * @param brandId
     * @param cardNo
     * @param pageNo
     * @param callback
     */
    public static void loadMemberCoupons(String brandId, String cardNo, int pageNo, ResultCallback<MemberCouponsDetailModel> callback) {
        ServerMemberApi.queryMemberCoupons(brandId, cardNo, pageNo, new IResponse<MemberCouponsDetailModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, MemberCouponsDetailModel info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }


    public static void loadMemberPrivate(String brandId, String csId, int memberLevel, String storeId, String cardNo, ResultCallback<MemberPrivateDetailModel> callback) {
        ServerMemberApi.queryMemberPrivate(brandId, csId, memberLevel, storeId, cardNo, new IResponse<MemberPrivateDetailModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, MemberPrivateDetailModel info) {
                if (result) {
                    callback.onSuccess(info);
                } else {
                    callback.onFailure(code, msg);
                }
            }
        });
    }

}
