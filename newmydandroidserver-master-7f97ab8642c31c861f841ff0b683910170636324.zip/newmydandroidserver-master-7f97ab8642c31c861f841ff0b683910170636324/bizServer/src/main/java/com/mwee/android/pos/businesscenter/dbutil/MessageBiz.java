package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrderInfo;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.util.RapidUtil;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidOnlyPay;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MessageDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lxx on 17/2/9.
 */

public class MessageBiz {

    /**
     * 新增美小二支付消息
     *
     * @param session
     * @param order
     */
    public static void addNamePayMsg(PaySession session, OrderCache order) {
        int buinessStatus;
        if (session.priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
            buinessStatus = MessageConstance.MessagePayBuinessStatus.RAPID.PAYED;
        } else {
            buinessStatus = MessageConstance.MessagePayBuinessStatus.RAPID.NONE;
        }

        Map<String, String> map = new HashMap<>();
        map.put("tableName", order.fsmtablename);
        map.put("payAmt", MessageOrderUtil.getPayedAmt(session.selectPayListFull));
        map.put("allAmt", Calc.format(order.priceTotalOriginAfterGift, RoundConfig.ROUND_SINGLE_PRICE).toString());  //订单总金额
        String mapStr = JSON.toJSONString(map);

        MessageBiz.addPayMsg(JSON.toJSONString(session), MessageConstance.TYPE_SMART,
                mapStr, order.fsmtableid,
                order.fsmareaid, session.billNO,
                buinessStatus, order.businessDate,
                session.waiterName, order.orderID);
        NotifyToClient.addPayMessage(MessageConstance.TYPE_SMART, order.fsmareaid);
    }

    /**
     * 新增消息--秒点单支付消息
     * 若该桌台已有未处理的秒点单消息,则删除就数据
     *
     * @param paySessrion
     * @param msgType       消息来源
     * @param standBy1      桌台名称、支付金额
     * @param fsmtableid
     * @param fsmareaid
     * @param billNo
     * @param buinessStatus
     * @param businessDate
     * @param waiterName
     */
    public static void addPayMsg(String paySessrion, int msgType,
                                 String standBy1, String fsmtableid,
                                 String fsmareaid, String billNo,
                                 int buinessStatus, String businessDate,
                                 String waiterName, String fsSellNO) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = waiterName;
        msg.businessStatus = buinessStatus;
        if (buinessStatus == MessageConstance.MessagePayBuinessStatus.RAPID.NONE) {
            msg.dealStatus = 0;
        } else {
            msg.dealStatus = 1;
        }
        msg.msgType = msgType;
        msg.msgCategory = 2;
        msg.msgHead = billNo;
        msg.msgBody = paySessrion;
        msg.standBy1 = standBy1; //桌台名称
        msg.mtableId = fsmtableid;   //桌台ID
        msg.mareaId = fsmareaid; //区域ID
        msg.sellNo = fsSellNO; //区域ID
        msg.replace();
    }

    /**
     * 新增纯收银的消息
     *
     * @param payment
     * @param fsSellNO
     * @param businessDate
     * @param businessStatus
     */
    public static void addRapidOnlyPay(RapidPayment payment, String fsSellNO, String businessDate, int businessStatus) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = UserCache.getInstance().getCloudUser().fsUserId;
        msg.businessStatus = businessStatus;
        msg.dealStatus = 0;
        msg.msgType = MessageConstance.TYPE_ONLY_PAY;
        msg.msgCategory = MessageConstance.CATEGORY_PAY;

        if (businessStatus != MessageConstance.MessagePayBuinessStatus.RAPID_ONLY_PAY.NONE) {
            msg.updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            msg.updateUser = "云收银";
        }

        //POS页面展示使用
        ArrayList<PayModel> payModelArrayList = RapidOnlyPay.optPayModelListByRapidPay(payment);
        msg.msgHead = JSON.toJSONString(payModelArrayList);

        msg.msgDes = payment.orderId; //账单号
        msg.msgBody = JSON.toJSONString(payment);

        Map<String, String> map = new HashMap<>();
        if (TextUtils.isEmpty(payment.tableNo)) {
            map.put("tableName", "");
        } else {
            map.put("tableName", TableDBUtil.getTableNameById(payment.tableNo));
        }
        map.put("payAmt", Calc.formatShow(RapidUtil.parseRapidPayTotalAmt(payment)));
        map.put("allAmt", Calc.formatShow(BigDecimal.ZERO));  //订单总金额

        msg.standBy1 = JSON.toJSONString(map); //桌台名称、支付金额、订单总额
        msg.mtableId = payment.tableNo;
        msg.sellNo = fsSellNO;
        msg.replaceNoTrans();
    }

    public static synchronized void checkAndAddRapidPayConfirmMessage(String orderId) {
        String sql = "select msgId from message where msgType = '" + MessageConstance.TYPE_PAY_CONFIRM + "' and msgCategory = '" + MessageConstance.CATEGORY_PAY + "' and sellNo = '" + orderId + "' and businessStatus = '" + MessageConstance.MessagePayBuinessStatus.RAPID_PAY_CONFIRM.NONE + "'";
        String msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(msgId)) {
            addRapidPayConfirm(orderId);
        } else { //更新时间
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update message set createTime = '" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "' where msgId = '" + msgId + "'");
        }
        msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        NotifyToClient.addRapidPayConfirm(DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), msgId);
    }

    /**
     * 新增秒付拉单确认的消息
     *
     * @param fsSellNO
     */
    public static void addRapidPayConfirm(String fsSellNO) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = HostUtil.getHistoryBusineeDate("");
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = UserCache.getInstance().getCloudUser().fsUserId;
        msg.businessStatus = MessageConstance.MessagePayBuinessStatus.RAPID_PAY_CONFIRM.NONE;
        msg.dealStatus = 0;
        msg.msgType = MessageConstance.TYPE_PAY_CONFIRM;
        msg.msgCategory = MessageConstance.CATEGORY_PAY;

        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNO);
        msg.mareaId = orderCache.fsmareaid;
        msg.mtableId = orderCache.fsmtableid;

        msg.msgDes = fsSellNO; //账单号

        Map<String, String> map = new HashMap<>();
        map.put("tableName", orderCache.fsmtablename);
        map.put("allAmt", Calc.formatShow(orderCache.optTotalPrice()));  //订单总金额

        msg.standBy1 = JSON.toJSONString(map); //桌台名称、订单总额
        msg.sellNo = fsSellNO;
        msg.replaceNoTrans();
    }

    /**
     * 新增消息--美小二下单消息
     *
     * @param
     */
    public static void addSmartOrderMsg(List<MenuItem> list, String createUser, int msgCategory,
                                        String fsmareaid, String fsmtablename, String fsmtableid, String businessDate) {
        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = createUser;
        msg.businessStatus = MessageConstance.MessageOrderBuinessStatus.SMART.AUTO_ORDER;
        msg.dealStatus = 1;
        msg.msgType = 2;
        msg.msgCategory = msgCategory;
        msg.msgHead = "";
        msg.mareaId = fsmareaid; //区域ID
        msg.msgBody = JSON.toJSONString(list);
        msg.standBy1 = fsmtablename;
        msg.mtableId = fsmtableid;
        msg.replace();

    }

    /**
     * 新增XMPP登录失败的消息
     *
     * @param content
     * @param content
     */
    public static void addXMPPLoginErrorMsg(String content) {
        MessageDBModel msg = new MessageDBModel();
        msg.msgBody = content;
        msg.msgType = MessageConstance.TYPE_XMPP_LOGIN;
        msg.businessDate = HostUtil.getHistoryBusineeDate("");
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "系统";
        msg.msgCategory = MessageConstance.CATEGORY_SYSTEM;
        msg.dealStatus = 1;
        msg.replace();
    }

    /**
     * 中控登录失败的消息
     *
     * @param content
     */
    public static void addPDLoginErrorMsg(String content) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from message where msgType=" + MessageConstance.TYPE_PD_LOGIN);
        MessageDBModel msg = new MessageDBModel();
        msg.msgBody = content;
        msg.msgType = MessageConstance.TYPE_PD_LOGIN;
        msg.businessDate = HostUtil.getHistoryBusineeDate("");
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "系统";
        msg.msgCategory = MessageConstance.CATEGORY_SYSTEM;
        msg.dealStatus = 0;
        msg.replace();
    }

    /**
     * 中控登录成功的消息
     */
    public static void addPDLoginSuccessMsg() {
        MessageDBModel msg = new MessageDBModel();
        msg.delete("msgType = " + MessageConstance.TYPE_PD_LOGIN);
        LogUtil.log("中控登录成功，移除中控登录系统消息");
    }

    public static void addAccountConfigMsg(String content) {
        //todo  http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9636172
        MessageDBModel msg = new MessageDBModel();
        msg.msgBody = content;
        msg.msgType = MessageConstance.TYPE_XMPP_LOGIN;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "系统";
        msg.msgCategory = MessageConstance.CATEGORY_SYSTEM;
        msg.dealStatus = 1;
        msg.replace();
    }


    /**
     * 新增消息--秒点单点菜消息
     * 若该桌台已有未处理的秒点单消息,则删除就数据
     *
     * @param tempDishes
     */
    public static void addRapidOrderMsg(TempOrderDishesCache tempDishes, int msgCategory,
                                        int buinessStatus) {
        addRapidOrderMsg(tempDishes, msgCategory, buinessStatus, "");
    }

    public static void addRapidOrderMsg(TempOrderDishesCache tempDishes, int msgCategory,
                                        int buinessStatus, String reason) {
        MessageDBUtil.deleteUnDealOrderMessage(tempDishes.fsmtableid);

        LogUtil.log("lxd", "----2-----新增消息--秒点单点菜消息");
        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = tempDishes.businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = tempDishes.waiterName;
        msg.businessStatus = buinessStatus;
        if (buinessStatus == MessageConstance.MessageOrderBuinessStatus.RAPID.NONE) {
            msg.dealStatus = 0;
        } else {
            msg.dealStatus = 1;
        }
        msg.msgType = 1;
        msg.msgDes = reason;
        msg.msgCategory = msgCategory;
        msg.msgHead = tempDishes.phone;
        msg.msgBody = JSON.toJSONString(tempDishes);
        msg.standBy1 = tempDishes.fsmtablename; //桌台名称
        msg.mtableId = tempDishes.fsmtableid;   //桌台ID
        msg.mareaId = tempDishes.fsmareaid; //区域ID
        msg.correlationId = MessageDBUtil.optBookMsgIdByPhone(tempDishes.phone);
        msg.replace();
    }

    /**
     * 新增消息--预定单消息
     *
     * @param
     */
    public static void addBookOrderMsg(RapidBookOrder rapidBookOrder, String businessDate) {
        if (rapidBookOrder == null) {
            return;
        }

        RapidBookOrderInfo orderInfo = rapidBookOrder.orderInfo;
        if (orderInfo == null) {
            return;
        }

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = orderInfo.name;
        msg.businessStatus = MessageConstance.MessageOrderBuinessStatus.BOOK.NONE;
        msg.dealStatus = MessageConstance.MessageOrderBuinessStatus.BOOK.NONE;
        msg.msgType = MessageConstance.TYPE_BOOK;
        msg.msgCategory = 1;
        msg.msgHead = orderInfo.phone;
        msg.msgDes = ""; //区域ID
        msg.msgBody = JSON.toJSONString(rapidBookOrder.dishInfo);
        msg.standBy1 = JSON.toJSONString(orderInfo);
        msg.standBy2 = "";
        msg.replace();
    }

    /**
     * 更新消息--微信快餐
     *
     * @param
     */
    public static void updateFastFoodMsg(String orderId, String sellno, String number, int status) {
        MessageFastFoodBean messageDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from message where msgHead = '" + orderId + "'", MessageFastFoodBean.class);
        if (messageDBModel == null) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder("update message set ");
        if (!TextUtils.isEmpty(sellno)) {
            stringBuilder.append(" sellNo = '").append(sellno).append("', ");
        }
        if (!TextUtils.isEmpty(number)) {
            JSONObject jsonObject = JSON.parseObject(messageDBModel.standBy1);
            jsonObject.put("number", number);

            stringBuilder.append(" standBy1 = '").append(jsonObject.toJSONString()).append("', ");
        }
        stringBuilder.append(" businessStatus = '").append(status).append("' where msgId = '").append(messageDBModel.msgId).append("'");

        String sql = stringBuilder.toString();
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

    }

    /**
     * 获取微信快餐单业务状态
     *
     * @param orderId
     * @return
     */
    public static int optFastFoodMsgBusinessStatus(String orderId) {
        MessageFastFoodBean messageDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from message where msgHead = '" + orderId + "'", MessageFastFoodBean.class);
        if (messageDBModel == null) {
            return -1;
        }

        return messageDBModel.businessStatus;
    }

    /**
     * 新增消息--微信快餐
     *
     * @param
     */
    public static void addUnDealFastFoodMsg(TempOrderDishesCache tempOrderDishesCache, RapidPayment rapidPayment, String businessDate, String sellno, String number, int status) {
        addFastFoodMsg(tempOrderDishesCache, rapidPayment, businessDate, sellno, number, status);
    }

    /**
     * 新增消息--微信快餐
     *
     * @param
     */
    public static void addFastFoodMsg(TempOrderDishesCache tempOrderDishesCache, RapidPayment rapidPayment, String businessDate, String sellNo, String number, int businessStatus) {
        if (tempOrderDishesCache == null) {
            return;
        }

        if (rapidPayment == null) {
            return;
        }

        LogUtil.log("lxd", "-------新增消息--微信快餐==eatTime=" + tempOrderDishesCache.eatTime);
        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "云收银";
        msg.businessStatus = MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.NONE;
        msg.businessStatus = businessStatus;
        if (businessStatus == MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.NONE) {
            msg.dealStatus = 0;
        } else {
            msg.dealStatus = 1;
        }

        msg.msgType = MessageDBUtil.getMsgType();
        msg.msgCategory = MessageDBUtil.getMsgCategory();

        msg.msgHead = tempOrderDishesCache.optFirstThirdOrderID();
        if (TextUtils.isEmpty(msg.msgHead)) {
            msg.msgHead = rapidPayment.orderId;
        }

        msg.msgDes = JSON.toJSONString(rapidPayment); //支付信息
        msg.msgBody = JSON.toJSONString(tempOrderDishesCache);  //订单信息
        msg.sellNo = sellNo;

        String payAmtStr = Calc.formatShow(RapidUtil.parseRapidPayTotalAmt(rapidPayment));
        Map<String, String> map = new HashMap<>();
        map.put("number", number);
        map.put("eatTime", tempOrderDishesCache.eatTime);//用餐时间
        map.put("payAmt", Calc.formatShow(RapidUtil.parseRapidPayTotalAmt(rapidPayment)));  //支付金额

        msg.standBy1 = JSON.toJSONString(map); //牌号，支付金额
        msg.standBy2 = payAmtStr + "_" + rapidPayment.userId;
        msg.replaceNoTrans();

        //addFastFoodMsg
    }

}
