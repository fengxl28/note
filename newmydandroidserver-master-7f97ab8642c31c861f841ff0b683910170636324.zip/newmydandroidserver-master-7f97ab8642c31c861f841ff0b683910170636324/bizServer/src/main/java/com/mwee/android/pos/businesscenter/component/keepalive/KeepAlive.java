package com.mwee.android.pos.businesscenter.component.keepalive;


import android.content.Context;
import android.os.SystemClock;

import com.mwee.android.alp.PushServer;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.framework.BizCenterApplication;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.socket.SocketServer;
import com.mwee.android.pos.component.push.XMPPPushManager;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.component.udp.UDPReceiverServer;
import com.mwee.android.pos.db.APPConfig;

/**
 * 保活的处理类
 * Created by virgil on 16/8/31.
 */
public class KeepAlive {

    /**
     * 上一次检测订单上送的时间
     */
    private static volatile long lastUploadOrderTime = 0L;

    public static void keep(final Context context) {
        if (!BizCenterApplication.inited) {
            BizCenterApplication.init(context);
        }
        BusinessExecutor.executeNoWait(() -> {
            //业务中心的服务保活
            SocketServer.getInstance().checkAlive();
            if (!APPConfig.isCasiher()) {
                //UDP监听的保活
                checkUdp(context);
                //美小二服务端的保活
                DriverBus.call("waiter/checkAlive");
            }
            //报表数据上送的保活
            checkOrderUpload();
            return null;
        });

    }

    public static void checkUdp(final Context context) {
        UDPReceiverServer.getInstance().checkAlive();
    }

    /**
     * 检测订单上送
     */
    private static void checkOrderUpload() {
        if (!BindProcessor.isCurrentHostMain()) {
            return;
        }
        long current = SystemClock.elapsedRealtime();
        if (lastUploadOrderTime == 0) {
            lastUploadOrderTime = current;
            return;
        }
        if ((current - lastUploadOrderTime) > 10 * 60 * 1000) {
            lastUploadOrderTime = SystemClock.elapsedRealtime();
//            UploadDataProcessor.doUploadOrderWithBaseData();
            UploadDataHelper.uploadAllData(null, null);
        }
    }

    public static void checkFinish(Context context) {
        if (BindProcessor.isActived()) {
            if (!BindProcessor.isCurrentHostMain()) {
                forceFinish();
            }
        }
    }

    /**
     * 强制结束
     */
    public static void forceFinish() {
        BizCenterApplication.destroy();
        APPConfig.closeAllDBInstance();

        //结束XMPP的服务器
        XMPPPushManager.destoryAll();
        //结束站点推送服务器
        PushServer.getInstance().finishServer();
        //结束UDPServer的监听
        UDPReceiverServer.getInstance().stop();
        //结束美小二的监听
        DriverBus.call("waiter/finishServer");
        SocketServer.getInstance().destory();
        ServerCache.getInstance().destroy();
        MwLog.release();
        //结束设备信息上报
        BizInfoCollect.destroy();
        GlobalLooper.destroy();
    }
}
