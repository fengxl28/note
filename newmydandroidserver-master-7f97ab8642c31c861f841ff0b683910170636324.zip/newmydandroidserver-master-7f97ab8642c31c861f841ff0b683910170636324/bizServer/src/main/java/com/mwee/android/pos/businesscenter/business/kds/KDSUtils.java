package com.mwee.android.pos.businesscenter.business.kds;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.kds.entry.DishItem;
import com.mwee.android.kds.entry.DishesInfo;
import com.mwee.android.kds.entry.MenusItem;
import com.mwee.android.kds.entry.OutletItem;
import com.mwee.android.kds.entry.TableItem;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.businesscenter.business.kds.algorithm.KdsAlgorithm;
import com.mwee.android.pos.businesscenter.business.kds.algorithm.bean.AMenuDataBean;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.kds.bean.KdsDutyViewBean;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.kds.KdsBarcodeDBModel;
import com.mwee.android.pos.db.business.kds.KdsBarcodeState;
import com.mwee.android.pos.db.business.kds.KdsMakeState;
import com.mwee.android.pos.db.business.kds.KdsMenuItemStateDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @ClassName: KDSUtils
 * @Description:
 * @author: Cannan
 * @date: 2018/11/12 下午7:40
 */
public class KDSUtils {

    /**
     * 构建kds智能算法菜品名称时的分隔符
     * eg. 酸菜土豆丝_少盐
     */
    public static String KDS_MENU_NAME_SEPARATOR = "%_#";

    /**
     * 做法根据 fiId 排序
     */
    public static Comparator<AskDBModel> sAskComparator = (o1, o2) -> {
//        if (o1.fiId > o2.fiId) {
        if (o1.fiId.compareTo(o2.fiId) > 0) {
            return 1;
//        } else if (o1.fiId == o2.fiId) {
        } else if (TextUtils.equals(o1.fiId, o2.fiId)) {
            return 0;
        } else {
            return -1;
        }
    };

    public static List<KdsDutyViewBean> queryDutyMembersStatus(String hostId) {
        //    查询站点所有的档口id
        String queryDepetIdSql = "select fsDeptId from tbHostPrintDepart where fsHostId = '" + hostId + "' and fiStatus = '1'";
        String queryUserDepartBindSql = "select fsUserId,fsDeptId from tbUserPrintDepart where fiStatus = '1' and fsDeptId in (" + queryDepetIdSql + ")";
//            //判断厨师与档口的绑定关系是否已存在于datacache，不存在则插入
        List<JSONObject> queryUserDepartBindResult = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, queryUserDepartBindSql);
        for (JSONObject jsonObject : queryUserDepartBindResult) {
            String userId = jsonObject.getString("fsUserId");
            String deptId = jsonObject.getString("fsDeptId");
            if (DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from datacache where type = " + IOCache.KDS_DUTY_MEMBERS_STATUS
                    + " and value = '" + userId + "'"
                    + " and biz_key='" + deptId + "'", CacheModel.class) == null) {
                //新插入数据
                CacheModel cacheModel = new CacheModel();
                cacheModel.type = IOCache.KDS_DUTY_MEMBERS_STATUS;
                cacheModel.key = UUID.randomUUID().toString();
                cacheModel.value = userId;
                cacheModel.biz_key = deptId;
                cacheModel.info = String.valueOf(1); //默认该档口是当班状态
                cacheModel.replaceNoTrans();
            }
        }
        //查询当前站定对应的厨师当班状态
        List<KdsDutyViewBean> result = new ArrayList<>();
        String queryMembersStatusSql = "select value as userId,biz_key as deptId,info as dutyStatus,tbdept.fsdeptname as deptName,tbuser.fsusername as userName from datacache,tbuser,tbdept "
                + "where datacache.type = 32 and tbdept.fsdeptid=datacache.biz_key and tbuser.fsuserid=datacache.value";
        for (JSONObject jsonObject : DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, queryMembersStatusSql)) {
            KdsDutyViewBean kdsDutyViewBean = new KdsDutyViewBean();
            kdsDutyViewBean.userId = jsonObject.getString("userId");
            kdsDutyViewBean.deptId = jsonObject.getString("deptId");
            kdsDutyViewBean.dutyStatus = Integer.parseInt(jsonObject.getString("dutyStatus"));
            kdsDutyViewBean.userName = jsonObject.getString("userName");
            kdsDutyViewBean.deptName = jsonObject.getString("deptName");
            result.add(kdsDutyViewBean);
        }
        return result;
    }

    public static List<KdsDutyViewBean> updateDutyMembers(String hostId, List<KdsDutyViewBean> dutyViewBeans) {
        for (KdsDutyViewBean kdsDutyViewBean : dutyViewBeans) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update datacache set info = '" + kdsDutyViewBean.dutyStatus + "'"
                    + " where type = " + IOCache.KDS_DUTY_MEMBERS_STATUS
                    + " and value = '" + kdsDutyViewBean.userId + "'"
                    + " and biz_key='" + kdsDutyViewBean.deptId + "'");
        }
        return queryDutyMembersStatus(hostId);
    }

    /**
     * 配料根据 itemId 排序
     */
    public static Comparator<MenuItem> sMenuComparator = (o1, o2) -> {
//        if (o1.itemID > o2.itemID) {
        if (o1.itemID.compareTo(o2.itemID) > 0) {
            return 1;
//        } else if (o1.itemID == o2.itemID) {
        } else if (TextUtils.equals(o1.itemID, o2.itemID)) {
            return 0;
        } else {
            return -1;
        }
    };

    /**
     * 备注根据优先 id 排序，其次根据内容排序
     */
    public static Comparator<NoteItemModel> sNoteComparator = (o1, o2) -> {
//        if (o1.id > o2.id) {
        if (o1.id.compareTo(o2.id) > 0) {
            return 1;
//        } else if (o1.id == o2.id) {
        } else if (TextUtils.equals(o1.id, o2.id)) {
            return o1.name.compareTo(o2.name);
        } else {
            return -1;
        }
    };

    /**
     * 算法模型初始化菜品数据
     *
     * @return
     */
    public static Map<String, MenusItem.MenuItemInner> initAMenu() {
        String sql = "" +
                "select fiItemCd as foodId, fsItemName as foodName, fiMaxTogetherMenu as mergeNum, fiRetireMenuTime as lifeTime\n" +
                "from tbmenuitem\n" +
                "where fsShopGUID = '" + HostUtil.getShopID() + "'\n" +
                "  and fiStatus = '1'\n" +
                "  and fiItemKind in (1, 3)\n" +
                "  and fiIsSet <> 1\n" +
                "  and fiIsOut = '0'\n" +
                "order by fsMenuClsId asc, fiSortOrder asc;";
        List<AMenuDataBean> data = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AMenuDataBean.class);
        if (ListUtil.isEmpty(data)) {
            return null;
        }

        Map<String, MenusItem.MenuItemInner> result = new HashMap<>();
        for (AMenuDataBean bean : data) {
            if (bean == null) {
                continue;
            }
            MenusItem.MenuItemInner item = bean.convert();
            result.put(bean.foodId, item);
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "initAMenu, 构建初始化信息：\n" + JSON.toJSONString(result));
        return result;
    }

    /**
     * 算法模型初始化档口信息
     *
     * @return
     */
    public static List<OutletItem> initADept() {
        String sql = "" +
                "select tbHostPrintDepart.fsDeptId as fsDeptId, tbdept.fiMakeNumber as fiMakeNumber, m.dutyNum as dutyNum\n" +
                "from tbHostPrintDepart\n" +
                "       left join tbdept on tbHostPrintDepart.fsDeptId = tbdept.fsDeptId\n" +
                "       left join (select biz_key as deptId, count(*) as dutyNum\n" +
                "                  from datacache\n" +
                "                  where type = '32' and info = '1'\n" +
                "                  group by biz_key) m on tbHostPrintDepart.fsDeptId = m.deptId\n" +
                "where tbHostPrintDepart.fiStatus = '1'\n" +
                "  and tbdept.fiStatus = '1';";
        List<JSONObject> deptList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
        if (ListUtil.isEmpty(deptList)) {
            return null;
        }

        List<OutletItem> result = new ArrayList<>();
        for (JSONObject info : deptList) {
            if (info == null) {
                continue;
            }
            String deptId = info.getString("fsDeptId");
            if (TextUtils.isEmpty(deptId)) {
                continue;
            }
            OutletItem item = new OutletItem(deptId);

            // 档口当班厨师人数
            int dutyNum = StringUtil.toInt(info.getString("dutyNum"), 1);
            item.setCookerNum(dutyNum);

            // 档口支持同时最大制作数量
            int makeNum = StringUtil.toInt(info.getString("fiMakeNumber"), 20);
            item.setTicketNum(makeNum);

            result.add(item);
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "initADept, 构建初始化信息：\n" + JSON.toJSONString(result));
        return result;
    }

    /**
     * 外卖下单菜品构造
     *
     * @return
     */
    public static DishesInfo buildAlgorithmData(TempAppOrder tempAppOrder, List<PrintItemDataBean> sellOrderItemDBModels, int beforeTime) {
        TableItem table = new TableItem(tempAppOrder.restNum, "", tempAppOrder.person);

        List<DishItem> dishItemList = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (PrintItemDataBean detail : sellOrderItemDBModels) {

            String createTime = detail.fsCreateTime;
            if (beforeTime > 0 && tempAppOrder.distributionType != 1) {
                try {
                    Date date = dateFormat.parse(detail.fsCreateTime);

                    long time = date.getTime() - beforeTime * 60 * 1000;
                    date.setTime(time);
                    createTime = dateFormat.format(date);
                } catch (ParseException e) {
                    LogUtil.logBusiness("----KDS----解析时间错误-----buildAlgorithmData------");
                }
            }

            //todo 退菜也会进KDS，但是退菜数量居然没变化
            if (!TextUtils.isEmpty(detail.fsDeptId) && !detail.fsItemName.startsWith("(退)")) {
                List<DishItem> singleDishItems = convertWMDish(tempAppOrder, detail, createTime);
                if (singleDishItems != null) {
                    dishItemList.addAll(singleDishItems);
                }
            }
        }

        if (!ListUtil.isEmpty(dishItemList)) {
            DishesInfo result = new DishesInfo(table, dishItemList);
            LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->完成构建算法所需数据");
            return result;
        } else {
            return null;
        }
    }

    /**
     * OderCache 构建算法所需数据
     *
     * @param orderCache
     * @return
     */
    public static DishesInfo buildAlgorithmData(OrderCache orderCache, List<SellOrderItemDBModel> menuList, ArrayMap<String, List<String>> deptMapping) {
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->开始构建算法所需数据");
        if (orderCache == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#buildAlgorithmData 订单信息为空");
            return null;
        }
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->开始构建算法桌台");
        TableItem table = buildATable(orderCache);
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->完成构建算法桌台");
        if (table == null) {
            return null;
        }
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->开始构建算法菜品");
        List<DishItem> dishItemList = buildAMenu(orderCache, menuList, deptMapping);
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->完成构建算法菜品");
        if (ListUtil.isEmpty(dishItemList)) {
            return null;
        }
        DishesInfo result = new DishesInfo(table, dishItemList);
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法下单->完成构建算法所需数据");
        return result;
    }

    /**
     * 构建算法所需桌台信息
     *
     * @param orderCache
     * @return
     */
    public static TableItem buildATable(OrderCache orderCache) {
        TableItem aTableBean = new TableItem(orderCache.orderID, orderCache.fsmtablename, orderCache.personNum);
        return aTableBean;
    }

    /**
     * 构建算法所需的菜品信息
     *
     * @param orderCache
     * @return
     */
    public static ArrayList<DishItem> buildAMenu(OrderCache orderCache, List<SellOrderItemDBModel> menuList, ArrayMap<String, List<String>> deptMapping) {
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 转换构建算法菜品开始");
        if (ListUtil.isEmpty(menuList)) {
            return null;
        }
        ArrayList<DishItem> result = new ArrayList<>();
        for (SellOrderItemDBModel model : menuList) {
            if (model == null) {
                continue;
            }
            if (model.fiOrderItemKind == 2) {
                continue;
            }
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (menuItem == null) {
                    continue;
                }
                if (TextUtils.equals(model.fsseq, menuItem.menuBiz.uniq) || (model.fiOrderItemKind == 3 && TextUtils.equals(model.fsSeq_M, menuItem.menuBiz.uniq))) {
                    result.addAll(convertAMenu(orderCache, menuItem, model, deptMapping.get(String.valueOf(model.fiItemCd))));
                }
            }
        }
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 转换构建算法菜品结束");
        return result;
    }

    /**
     * 构建算法所需要的菜品名称
     * 1.菜品名称、2.规格、3.做法、4.配料、5.要求、6.显著要求、排序组合, 7.称重重量
     * eg. #1鱼香肉丝_#2份_#3做法1;做法2_#4配料1*2份_#4配料2*1_#5要求_#6显著要求
     *
     * @param orderDetail
     * @return
     */
    private static String buildAMenuName(PrintItemDataBean orderDetail) {
        if (orderDetail == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#buildAMenuName 菜品信息为空");
            return "";
        }

        StringBuilder result = new StringBuilder();

        // 名称
        result.append("#1");
        result.append(orderDetail.fsItemName);

        // 规格
        if (!TextUtils.isEmpty(orderDetail.fsOrderUint)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#2");
            result.append(orderDetail.fsOrderUint);
        }

        // 做法 todo 需要排序，先空一空
        if (!TextUtils.isEmpty(orderDetail.fsNote)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#3");
            result.append(orderDetail.fsNote);
        }

        //#4配料
        if (!TextUtils.isEmpty(orderDetail.ingredientNotes)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#4");
            result.append(orderDetail.ingredientNotes);
        }

        //#5要求
        if (!TextUtils.isEmpty(orderDetail.fsGeneralNote)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#5");
            result.append(orderDetail.fsGeneralNote);
        }

        //#6要求
        if (!TextUtils.isEmpty(orderDetail.fsSpecialNote)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#6");
            result.append(orderDetail.fsSpecialNote);
        }

        // 称重
        if (orderDetail.fiIsEditQty == 1) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#7");
            result.append(orderDetail.fdSaleQty);
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#buildAMenuName 构建的算法使用菜品名称: "
                + result.toString() + "\n菜品信息: " + JSON.toJSONString(orderDetail));
        return result.toString();
    }

    /**
     * 外卖菜品转换
     *
     * @param bean
     * @return
     */
    private static List<DishItem> convertWMDish(TempAppOrder tempAppOrder, PrintItemDataBean bean, String createTime) {
        if (bean == null) {
            return null;
        }

        List<DishItem> result = new ArrayList<>();

        // 购买数量
        int buyNum;
        // 制作状态
        int state;

        buyNum = bean.fdSaleQty.intValue() - bean.fdBackQty.intValue();
        state = KdsMakeState.ToBeProduced;

        List<String> outletList = queryDeptIdByMenu(bean);
        if (!ListUtil.isEmpty(outletList)) {
            LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "------outletList----" +
                    outletList.size() + "------" + outletList.toString());
        } else {
            LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "------outletList----" +
                    0 + "------" + outletList.toString());
            return null;
        }
        String name = buildAMenuName(bean);
        LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "------name----" + name);

        StringBuilder sb = new StringBuilder();
        sb.append("" +
                "replace into tbKdsMenuItemState (fsSeq, fiItemCd, name, fsMenuClsId,fsOriginSeq, fsOriginSeq_M, fiItemKind, fiState, " +
                "fsSellNo, fiSellType,fsRestNum,fsShopGUID, fsUpdateHostId, fsUpdateTime, fsUpdateUserId, fsUpdateUserName, fsDeptId)\n" +
                "VALUES ");

        for (int num = 0; num < buyNum; num++) {
            StringBuilder temp = new StringBuilder();
            if (num > 0) {
                temp.append(", ");
            }

            String fsSeq = UUID.randomUUID().toString();

            temp.append("(");
            temp.append("'").append(fsSeq).append("', ");
            temp.append("'").append(bean.fiItemCd).append("', ");//todo 这个fsItemId表示什么，fiItemCd 表示什么，
            temp.append("'").append(name).append("', ");
            temp.append("'").append(bean.fsMenuClsId).append("', ");
            temp.append("'").append(bean.fsseq).append("', ");
            temp.append("'").append(bean.fsSeq_M).append("', ");//外卖的uniq关联不上
            temp.append("'").append(bean.fiOrderItemKind).append("', ");
            temp.append("'").append(state).append("', ");
            temp.append("'").append(tempAppOrder.orderId).append("', ");
            temp.append("'").append(2).append("', ");
            temp.append("'").append(tempAppOrder.restNum).append("', ");
            temp.append("'").append(tempAppOrder.shopId).append("', ");
            temp.append("'").append("").append("', ");

            temp.append("'").append(createTime).append("', ");
            temp.append("'").append("").append("', ");
            temp.append("'").append(bean.fsDeptId).append("', ");

            if (!ListUtil.isEmpty(outletList)) {
                for (int index = 0; index < outletList.size(); index++) {
                    String deptId = outletList.get(index);
                    if (TextUtils.isEmpty(deptId)) {
                        continue;
                    }
                    StringBuilder deptTemp = new StringBuilder(temp);
                    deptTemp.append("'").append(deptId).append("'");
                    deptTemp.append(")");
                    if (index < outletList.size() - 1 && !temp.toString().startsWith(",")) {
                        deptTemp.append(", ");
                    }
                    sb.append(deptTemp);
                }
            }

            // 未称重菜品暂不下单
            if (state == KdsMakeState.NotWeighed) {
                continue;
            }

            // 数据结构转换，交互算法
            DishItem aMenuBean = new DishItem();
            aMenuBean.setTableId(tempAppOrder.restNum);
            aMenuBean.setDishId(fsSeq);
            aMenuBean.setFiSellType(2);//外卖
            aMenuBean.setFoodId(bean.fiItemCd);
            aMenuBean.setFoodName(name);
//            aMenuBean.setPriLevel(detail.fiUpMenuOrder);
            aMenuBean.setPause(false);
            aMenuBean.setOutlets(outletList);
            result.add(aMenuBean);
        }

        LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "------下单构建信息SQL----" + sb.toString());
        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            db.execSQL(sb.toString());
            return null;
        });

        return result;
    }

    /**
     * 将菜品信息转换成算法所需的 model
     *
     * @param orderCache
     * @param menuItem
     * @return
     */
    public static List<DishItem> convertAMenu(OrderCache orderCache, MenuItem menuItem, SellOrderItemDBModel model, List<String> deptIdList) {
        if (menuItem == null || model == null) {
            return null;
        }

        MenuItem var = menuItem;
        if (model.fiOrderItemKind == 3) {
            for (MenuItem packageItem : menuItem.menuBiz.selectedPackageItems) {
                if (packageItem == null) {
                    continue;
                }
                if (!TextUtils.equals(packageItem.menuBiz.uniq, model.fsseq)) {
                    continue;
                }
                var = packageItem;
            }
        }

        List<DishItem> result = new ArrayList<>();

        // 购买数量
        int buyNum;
        // 制作状态
        int state;

        if (var.supportWeight()) {
            buyNum = 1;
            if (model.fdSaleQty.subtract(model.fdBackQty).compareTo(BigDecimal.ZERO) == 0) {
                state = KdsMakeState.NotWeighed;
            } else if (menuItem.menuBiz.isWait()) {
                state = KdsMakeState.Wait;
            } else {
                state = KdsMakeState.ToBeProduced;
            }
        } else {
            buyNum = model.fdSaleQty.subtract(model.fdBackQty).intValue();
            if (menuItem.menuBiz.isWait()) {
                state = KdsMakeState.Wait;
            } else {
                state = KdsMakeState.ToBeProduced;
            }
        }

        List<String> outletList = queryDeptIdByMenu(model, orderCache.fsmareaid);
        String name = buildAMenuName(var);

        StringBuilder sb = new StringBuilder();
        sb.append("" +
                "replace into tbKdsMenuItemState (fsSeq, fiItemCd, name, fsMenuClsId,fsOriginSeq, fsOriginSeq_M, fiItemKind, fiState, " +
                "fsSellNo, fiSellType,fsRestNum,fsShopGUID, fsUpdateHostId, fsUpdateTime, fsUpdateUserId, fsUpdateUserName, fsDeptId)\n" +
                "VALUES ");

        for (int num = 0; num < buyNum; num++) {
            StringBuilder temp = new StringBuilder();
            if (num > 0) {
                temp.append(", ");
            }

            String fsSeq = UUID.randomUUID().toString();

            temp.append("(");
            temp.append("'").append(fsSeq).append("', ");
            temp.append("'").append(var.itemID).append("', ");
            temp.append("'").append(name).append("', ");
            temp.append("'").append(model.fsMenuClsId).append("', ");
            temp.append("'").append(model.fsseq != null ? model.fsseq : "").append("', ");
            temp.append("'").append(model.fsSeq_M != null ? model.fsSeq_M : "").append("', ");
            temp.append("'").append(model.fiOrderItemKind).append("', ");
            temp.append("'").append(state).append("', ");
            temp.append("'").append(orderCache.orderID).append("', ");
            temp.append("'").append(orderCache.fiSellType).append("', ");
            temp.append("'").append(orderCache.mealNumber).append("', ");
            temp.append("'").append(orderCache.shopID).append("', ");
            temp.append("'").append(orderCache.currentHostID).append("', ");
            temp.append("'").append(DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT)).append("', ");
            temp.append("'").append(orderCache.waiterID).append("', ");
            temp.append("'").append(orderCache.waiterName).append("', ");

            if (!ListUtil.isEmpty(deptIdList)) {
                for (int index = 0; index < deptIdList.size(); index++) {
                    String deptId = deptIdList.get(index);
                    if (TextUtils.isEmpty(deptId)) {
                        continue;
                    }
                    StringBuilder deptTemp = new StringBuilder(temp);
                    deptTemp.append("'").append(deptId).append("'");
                    deptTemp.append(")");
                    if (index < deptIdList.size() - 1 && !temp.toString().startsWith(",")) {
                        deptTemp.append(", ");
                    }
                    sb.append(deptTemp);
                }
            }

            // 未称重菜品暂不下单
            if (state == KdsMakeState.NotWeighed) {
                continue;
            }

            // 数据结构转换，交互算法
            DishItem aMenuBean = new DishItem();
            aMenuBean.setTableId(orderCache.orderID);
            aMenuBean.setDishId(fsSeq);
            aMenuBean.setFoodId(String.valueOf(var.itemID));
            aMenuBean.setFiSellType(orderCache.fiSellType);
            aMenuBean.setFoodName(name);
            aMenuBean.setPriLevel(var.fiUpMenuOrder);
            aMenuBean.setPause(menuItem.menuBiz.isWait());
            aMenuBean.setOutlets(outletList);
            result.add(aMenuBean);
        }

        LogUtil.log(RunTimeLog.KDS_RUNTIME, "下单构建信息SQL: " + sb.toString());
        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            db.execSQL(sb.toString());
            return null;
        });

        return result;
    }

    public static List<DishItem> buildAMenu(OrderCache orderCache, MenuItem menuItem, SellOrderItemDBModel model, KdsMenuItemStateDBModel kdsMenu) {
        if (menuItem == null || model == null) {
            return null;
        }

        List<DishItem> result = new ArrayList<>();

        // 购买数量
        int buyNum = (menuItem.supportWeight() ? 1 : menuItem.menuBiz.buyNum.intValue());
        for (int num = 0; num < buyNum; num++) {
            // 数据结构转换，交互算法
            DishItem aMenuBean = new DishItem();
            aMenuBean.setTableId(orderCache.orderID);
            aMenuBean.setDishId(kdsMenu.fsSeq);
            aMenuBean.setFoodId(menuItem.itemID);
            aMenuBean.setFoodName(kdsMenu.name);
            aMenuBean.setPriLevel(menuItem.fiUpMenuOrder);
            aMenuBean.setPause(menuItem.menuBiz.isWait());
            aMenuBean.setOutlets(queryDeptIdByMenu(model, orderCache.fsmareaid));
            result.add(aMenuBean);
        }
        return result;
    }

    /**
     * 构建算法所需要的菜品名称
     * 1.菜品名称、2.规格、3.做法、4.配料、5.要求、6.显著要求、排序组合, 7.称重重量
     * eg. #1鱼香肉丝_#2份_#3做法1;做法2_#4配料1*2份_#4配料2*1_#5要求_#6显著要求
     *
     * @param menuItem
     * @return
     */
    public static String buildAMenuName(MenuItem menuItem) {
        if (menuItem == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#buildAMenuName 菜品信息为空");
            return "";
        }
        StringBuilder result = new StringBuilder();

        // 名称
        result.append("#1");
        result.append(menuItem.name);

        // 规格
        if (menuItem.currentUnit != null) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#2");
            result.append(menuItem.currentUnit.fsOrderUint);
        }

        // 做法
        if (!ListUtil.isEmpty(menuItem.menuBiz.selectMulProcedure)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#3");

            StringBuilder info = new StringBuilder();
            // 排序
            AskDBModel[] askArr = new AskDBModel[menuItem.menuBiz.selectMulProcedure.size()];
            askArr = menuItem.menuBiz.selectMulProcedure.toArray(askArr);
            Arrays.sort(askArr, sAskComparator);
            for (AskDBModel model : askArr) {
                if (model == null || TextUtils.isEmpty(model.fsAskName)) {
                    continue;
                }
                info.append(model.fsAskName);
                info.append(";");
            }
            if (info.length() > 0) {
                info.deleteCharAt(info.length() - 1);
            }
            result.append(info);
        }

        // 由于美易点配料作为备注打印，此处构建算法要求的菜品名称，需拼接配料
        if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
            StringBuilder info = new StringBuilder();
            // 排序
            MenuItem[] menuArr = new MenuItem[menuItem.menuBiz.selectedModifier.size()];
            menuArr = menuItem.menuBiz.selectedModifier.toArray(menuArr);
            Arrays.sort(menuArr, sMenuComparator);
            for (MenuItem model : menuArr) {
                if (model == null || TextUtils.isEmpty(model.name)) {
                    continue;
                }
                info.append(KDS_MENU_NAME_SEPARATOR);
                info.append("#4");
                info.append(model.name);
                info.append("*");
                info.append(model.menuBiz.buyNum.subtract(model.menuBiz.voidNum));
                info.append("/");
                info.append(model.currentUnit.fsOrderUint);
            }
            result.append(info);
        }

        // 称重
        if (menuItem.supportWeight()) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#7");
            result.append(menuItem.menuBiz.buyNum);
        }

        // 要求
        List<NoteItemModel> allNote = new ArrayList<>();
        if (!ListUtil.isEmpty(menuItem.menuBiz.selectNote)) {
            allNote.addAll(menuItem.menuBiz.selectNote);
        }
        if (!ListUtil.isEmpty(menuItem.menuBiz.selectOrderNote)) {
            allNote.addAll(menuItem.menuBiz.selectOrderNote);
        }
        if (ListUtil.isEmpty(allNote)) {
            return result.toString();
        }

        NoteItemModel[] noteArr = new NoteItemModel[allNote.size()];
        noteArr = allNote.toArray(noteArr);
        Arrays.sort(noteArr, sNoteComparator);

        StringBuilder general = new StringBuilder();
        StringBuilder special = new StringBuilder();
        for (NoteItemModel model : noteArr) {
            if (model == null) {
                continue;
            }
            if (model.num == null) {
                model.num = BigDecimal.ZERO;
            }
            if (model.num.compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            if (model.fiIsShow == 1) {
                special.append(model.name);
                if (model.num.compareTo(BigDecimal.ONE) > 0) {
                    special.append("x").append(Calc.formatShow(model.num, 0));
                }
                special.append(";");
            } else {
                general.append(model.name);
                if (model.num.compareTo(BigDecimal.ONE) > 0) {
                    general.append("x").append(Calc.formatShow(model.num, 0));
                }
                general.append(";");
            }
        }
        if (general.length() > 0) {
            general.deleteCharAt(general.length() - 1);
        }
        if (special.length() > 0) {
            special.deleteCharAt(special.length() - 1);
        }
        if (!TextUtils.isEmpty(general)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#5");
            result.append(general);
        }
        if (!TextUtils.isEmpty(special)) {
            result.append(KDS_MENU_NAME_SEPARATOR);
            result.append("#6");
            result.append(special);
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#buildAMenuName 构建的算法使用菜品名称: " + result.toString() + "\n菜品信息: " + JSON.toJSONString(menuItem));
        return result.toString();
    }

    /**
     * 查询外卖菜品制作部门
     *
     * @param detail
     * @return
     */
    private static List<String> queryDeptIdByMenu(PrintItemDataBean detail) {
        if (detail == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 菜品信息为空");
            return null;
        }

        List<String> makeDeptList = new ArrayList<>();

        //判断是否多部门打印
        if (detail.fiIsMulDept == 1) {
            makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + detail.fiItemCd + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' ) ");
        } else {
            DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + detail.fsDeptId + "'", DeptDBModel.class);
            if (dept != null) {
                makeDeptList.add(dept.fsDeptId);
            } else {
                List<String> deptIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1'");
                if (!ListUtil.isEmpty(deptIds)) {
                    makeDeptList.addAll(deptIds);
                }
            }
        }

        //根据菜品分类查询制作部门
        if (ListUtil.isEmpty(makeDeptList)) {
            String fsMenuClsId = detail.fsMenuClsId;
            if (detail.fiIsMulDept == 1) {
                makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')");
            } else {
                DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + detail.fsDeptId + "'", DeptDBModel.class);
                if (dept != null) {
                    makeDeptList.add(dept.fsDeptId);
                } else {
                    List<String> deptIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1' ");
                    if (!ListUtil.isEmpty(deptIds)) {
                        makeDeptList.addAll(deptIds);
                    }
                }
            }
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 菜品[" + detail.fiItemCd + ", " + detail.fsItemName + "]查询制作部门信息[" + JSON.toJSONString(makeDeptList) + "]");
        if (ListUtil.isEmpty(makeDeptList)) {
            return null;
        }

        /* 过滤算法有效的档口 */
        List<String> result = new ArrayList<>();
        for (String deptId : makeDeptList) {
            if (KdsAlgorithm.getInstance().mDeptIdList.contains(deptId)) {
                result.add(deptId);
            }
        }
        return result;
    }

    /**
     * 查询菜品制作部门
     *
     * @param model
     * @param fsMAreaId
     * @return
     */
    public static List<String> queryDeptIdByMenu(SellOrderItemDBModel model, String fsMAreaId) {
        if (model == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 菜品信息为空");
            return null;
        }

        List<String> makeDeptList = new ArrayList<>();

        //判断是否多部门打印
        if (model.fiIsMulDept == 1) {
            if (!TextUtils.isEmpty(fsMAreaId)) {
                makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + model.fiItemCd + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMAreaId + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')");
            } else {
                makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + model.fiItemCd + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' ) ");
            }
        } else {
            DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + model.fsDeptId + "'", DeptDBModel.class);
            if (dept != null) {
                makeDeptList.add(dept.fsDeptId);
            } else {
                List<String> deptIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1'");
                if (!ListUtil.isEmpty(deptIds)) {
                    makeDeptList.addAll(deptIds);
                }
            }
        }

        //根据菜品分类查询制作部门
        if (ListUtil.isEmpty(makeDeptList)) {
            String fsMenuClsId = model.fsMenuClsId;
            if (model.fiIsMulDept == 1) {
                if (!TextUtils.isEmpty(fsMAreaId)) {
                    makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMAreaId + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' )");
                } else {
                    makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')");
                }
            } else {
                DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + model.fsDeptId + "'", DeptDBModel.class);
                if (dept != null) {
                    makeDeptList.add(dept.fsDeptId);
                } else {
                    List<String> deptIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1' ");
                    if (!ListUtil.isEmpty(deptIds)) {
                        makeDeptList.addAll(deptIds);
                    }
                }
            }
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 根据餐区[" + fsMAreaId + "], 菜品[" + model.fiItemCd + ", " + model.fsItemName + "]查询制作部门信息[" + JSON.toJSONString(makeDeptList) + "]");
        if (ListUtil.isEmpty(makeDeptList)) {
            return null;
        }

        /* 过滤算法有效的档口 */
        List<String> result = new ArrayList<>();
        for (String deptId : makeDeptList) {
            if (KdsAlgorithm.getInstance().mDeptIdList.contains(deptId)) {
                result.add(deptId);
            }
        }
        return result;
    }

    /**
     * 查询菜品制作部门
     *
     * @param model
     * @param fsMAreaId
     * @return
     */
    public static List<DeptDBModel> queryDeptByMenu(SellOrderItemDBModel model, String fsMAreaId) {
        if (model == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 菜品信息为空");
            return null;
        }

        List<DeptDBModel> makeDeptList = new ArrayList<>();

        //判断是否多部门打印
        if (model.fiIsMulDept == 1) {
            if (!TextUtils.isEmpty(fsMAreaId)) {
                makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + model.fiItemCd + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMAreaId + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')", DeptDBModel.class);
            } else {
                makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + model.fiItemCd + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' ) ", DeptDBModel.class);
            }
        } else {
            DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + model.fsDeptId + "'", DeptDBModel.class);
            if (dept != null) {
                makeDeptList.add(dept);
            } else {
                List<DeptDBModel> deptIds = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1'", DeptDBModel.class);
                if (!ListUtil.isEmpty(deptIds)) {
                    makeDeptList.addAll(deptIds);
                }
            }
        }

        //根据菜品分类查询制作部门
        if (ListUtil.isEmpty(makeDeptList)) {
            String fsMenuClsId = model.fsMenuClsId;
            if (model.fiIsMulDept == 1) {
                if (!TextUtils.isEmpty(fsMAreaId)) {
                    makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMAreaId + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' )", DeptDBModel.class);
                } else {
                    makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')", DeptDBModel.class);
                }
            } else {
                DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + model.fsDeptId + "'", DeptDBModel.class);
                if (dept != null) {
                    makeDeptList.add(dept);
                } else {
                    List<DeptDBModel> deptIds = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1' ", DeptDBModel.class);
                    if (!ListUtil.isEmpty(deptIds)) {
                        makeDeptList.addAll(deptIds);
                    }
                }
            }
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#queryDeptIdByMenu 根据餐区[" + fsMAreaId + "], 菜品[" + model.fiItemCd + ", " + model.fsItemName + "]查询制作部门信息[" + JSON.toJSONString(makeDeptList) + "]");
        return makeDeptList;
    }

    /**
     * 保存每条记录对应拼菜后的一锅
     *
     * @param name String | KDS算法中的菜品名称
     * @return String | 菜品名称对应的条形码内容
     */
    public static String saveKdsMenuCodeMapping(String name, BigDecimal num) {
        CacheModel cacheModel = new CacheModel();
        String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.key = UUID.randomUUID().toString();
        cacheModel.type = IOCache.KDS_MENU_NAME_BAR_MAPPING;
        cacheModel.value = name;
        cacheModel.info = num.toPlainString();
        cacheModel.createtime = time;
        cacheModel.updatetime = time;
        cacheModel.replaceNoTrans();
        return cacheModel.key;
    }

    /**
     * 从算法返回的菜品名称中拆解菜品信息
     * 1.菜品名称、2.规格、3.做法、4.配料、5.要求、6.显著要求、排序组合
     * * eg. #1鱼香肉丝_#2份_#3做法1;做法2_#4配料1*2份_#4配料2*1_#5要求_#6显著要求
     * {@link KDSUtils#buildAMenuName(MenuItem)}
     *
     * @param var1 String | 算法返回的菜品名称
     * @return JSONObject | 解析的菜品信息
     */
    public static JSONObject buildMenuFromAlgorithm(String var1) {
        if (TextUtils.isEmpty(var1)) {
            return null;
        }

        JSONObject result = new JSONObject();

        // 名称不包含分隔符，则直接认为是菜品名称
        if (!var1.contains(KDS_MENU_NAME_SEPARATOR)) {
            result.put("itemName", var1);
            return result;
        }

        String[] info = var1.split(KDS_MENU_NAME_SEPARATOR);
        if (info == null || info.length == 0) {
            return null;
        }

        for (String var : info) {
            if (TextUtils.isEmpty(var)) {
                continue;
            }
            if (var.contains("#1")) {
                var = var.replaceAll("#1", "");
                result.put("itemName", var);
            } else if (var.contains("#2")) {
                var = var.replaceAll("#2", "");
                result.put("itemUnit", var);
            } else if (var.contains("#3")) {
                var = var.replaceAll("#3", "");
                result.put("itemProcedure", var);
            } else if (var.contains("#4")) {
                var = var.replaceAll("#4", "");
                List<String> modifier;
                if (result.containsKey("itemModifier")) {
                    modifier = (List<String>) result.get("itemModifier");
                    if (modifier == null) {
                        modifier = new ArrayList<>();
                    }
                } else {
                    modifier = new ArrayList<>();
                }
                modifier.add(var);
                result.put("itemModifier", modifier);
            } else if (var.contains("#5")) {
                var = var.replaceAll("#5", "");
                result.put("itemGeneralNote", var);
            } else if (var.contains("#6")) {
                var = var.replaceAll("#6", "");
                result.put("itemSpecialNote", var);
            }
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "根据名称拆解菜品信息\n名称: " + var1 + "\n解析结果: " + JSON.toJSONString(result));
        return result;
    }

    public static KdsMenuViewBean buildMenuBeanFromA(String var1, BigDecimal num) {
        if (TextUtils.isEmpty(var1)) {
            return null;
        }

        KdsMenuViewBean result = new KdsMenuViewBean();
        result.num = num;

        // 名称不包含分隔符，则直接认为是菜品名称
        if (!var1.contains(KDS_MENU_NAME_SEPARATOR)) {
            result.name = var1;
            return result;
        }

        String[] info = var1.split(KDS_MENU_NAME_SEPARATOR);
        if (info == null || info.length == 0) {
            return null;
        }

        for (String var : info) {
            if (TextUtils.isEmpty(var)) {
                continue;
            }
            if (var.contains("#1")) {
                var = var.replaceAll("#1", "");
                result.name = var;
            } else if (var.contains("#2")) {
                var = var.replaceAll("#2", "");
                result.unit = var;
            } else if (var.contains("#3")) {
                var = var.replaceAll("#3", "");
                result.procedure = var;
            } else if (var.contains("#4")) {
                var = var.replaceAll("#4", "");
                result.modifier.add(var);
            } else if (var.contains("#5")) {
                var = var.replaceAll("#5", "");
                result.note = var;
            } else if (var.contains("#6")) {
                var = var.replaceAll("#6", "");
                result.note += var;
            } else if (var.contains("#7")) {
                var = var.replaceAll("#7", "");
                try {
                    result.num = new BigDecimal(var);
                } catch (Exception ex) {
                    LogUtil.logError(ex);
                }
            }
        }

        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "根据名称拆解菜品信息\n名称: " + var1 + "\n解析结果: " + JSON.toJSONString(result));
        return result;
    }

    /**
     * 通过站点id查询绑定的部门
     *
     * @param hostID
     * @return
     */
    public static List<DeptDBModel> queryDeptByHostId(String hostID) {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fsDeptId in (select fsDeptId from tbHostPrintDepart where fsHostId = '" + hostID + "' and fiStatus = '1')", DeptDBModel.class);
    }

    public static List<String> queryDeptIdByHostId(String hostID) {
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fsDeptId in (select fsDeptId from tbHostPrintDepart where fsHostId = '" + hostID + "' and fiStatus = '1')");
    }

    /**
     * 通过制作部门id查找绑定的站点id
     *
     * @param deptId
     * @return
     */
    public static String queryHostIdByDeptId(String deptId) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsHostId from tbHostPrintDepart where fsDeptId = '" + deptId + "' and fiStatus = '1'");
    }

    /**
     * 通过制作部门id查找绑定的站点model
     *
     * @param deptId
     * @return
     */
    public static HostDBModel queryHostByDeptId(String deptId) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbHost where fsHostId in (select fsHostId from tbHostPrintDepart where fsDeptId = '" + deptId + "' and fiStatus = '1') and fiStatus = '1' ", HostDBModel.class);
    }

    /**
     * 构建菜品信息
     *
     * @param dishID String | {@link KdsMenuItemStateDBModel#fsSeq}
     * @param num
     * @return
     */
    public static KdsMenuViewBean buildMenuByDishId(String dishID, int state, BigDecimal num, String deptId) {
        String sql = "select *, sum(fiHurryCount) as fiHurryCount\n" +
                "from tbKdsMenuItemState\n" +
                "where fsDeptId = '" + deptId + "' and fsPotSeq in (select fsPotSeq from tbKdsMenuItemState where fsSeq = '" + dishID + "')";
        KdsMenuItemStateDBModel menu = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
        if (menu == null) {
            return null;
        }
        KdsMenuViewBean result = menu.convert(state, num);
        return result;
    }

    /**
     * 通过并菜后的标识查询菜品信息
     *
     * @param potId
     * @return
     */
    public static List<KdsMenuItemStateDBModel> queryDishByPotId(String potId) {
        if (TextUtils.isEmpty(potId)) {
            return null;
        }
        String sql = "select * from " + DBModel.getTableName(KdsMenuItemStateDBModel.class) + " where fsPotSeq = '" + potId + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
    }

    public static List<KdsMenuItemStateDBModel> queryDishByPotId(String potId, String deptId, int state) {
        if (TextUtils.isEmpty(potId)) {
            return null;
        }
        String sql = "select * from " + DBModel.getTableName(KdsMenuItemStateDBModel.class) + " where fiState = '" + state + "' AND fsPotSeq = '" + potId + "' AND fsDeptId = '" + deptId + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
    }

    /**
     * 查询制作中的菜品dishId
     *
     * @param potId
     * @return
     */
    public static List<String> queryUnServedDishIdListByPotId(String potId) {
        if (TextUtils.isEmpty(potId)) {
            return null;
        }
        List<String> unServedResult = new ArrayList<>();
        String normalSql = "select dishId from tbKdsBarcode where barcode='" + potId + "' and state not in  ("
                + KdsAlgorithm.optSqlParams(Arrays.asList(KdsBarcodeState.Served, KdsBarcodeState.Trashed), new KdsAlgorithm.StringFormatter<Integer>() {
            @Override
            public String toString(Integer entry) {
                return String.valueOf(entry);
            }
        }) + ")";
        unServedResult.addAll(DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, normalSql));
        if (ListUtil.isEmpty(unServedResult)) {
            String unAssignResultSql = "select fsSeq from " + DBModel.getTableName(KdsMenuItemStateDBModel.class)
                    + " where fsPotSeq = '" + potId + "' and fiState in ('" + KdsMakeState.Making + "','" + KdsMakeState.Retired + "','" + KdsMakeState.PendingAllocation + "')";
            unServedResult.addAll(DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, unAssignResultSql));
        }
        return unServedResult;
    }

    /**
     * 查询条形码划掉的菜品
     *
     * @param barcode
     * @return
     */
    public static List<KdsMenuItemStateDBModel> queryDishByBarcode(String barcode) {
        if (TextUtils.isEmpty(barcode)) {
            return null;
        }
        String sql = "select * from " + DBModel.getTableName(KdsMenuItemStateDBModel.class) + " where fsBarCode = '" + barcode + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
    }

    public static boolean isBarcodeWithinStateExist(String barcode, @KdsBarcodeState int kdsBarcodeState) {
        String totalSql = "select state from " + DBModel.getTableName(KdsBarcodeDBModel.class) + " where barcode  = '" + barcode + "' AND state = '" + kdsBarcodeState + "'";
        int totalCount = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, totalSql).size();
        return totalCount > 0;
    }

    /**
     * 判断tbKdsBarcode中是否所有的dishid状态一致
     *
     * @param barcode
     * @return
     */
    public static boolean isAllMatchedStateWithinBarcode(String barcode, @KdsBarcodeState int kdsBarcodeState) {
        if (TextUtils.isEmpty(barcode)) {
            return false;
        }
        String totalSql = "select state from " + DBModel.getTableName(KdsBarcodeDBModel.class) + " where barcode  = '" + barcode + "' ";
        int totalCount = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, totalSql).size();
        if (totalCount <= 0) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KDSUtils#isAllMatchedStateWithinBarcode 不存在Barcode对应的记录:" + barcode);
            return false;
        }

        String sql = "select state from " + DBModel.getTableName(KdsBarcodeDBModel.class) + " where barcode  = '" + barcode + "' AND state != '" + kdsBarcodeState + "'";
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql).size() <= 0;
    }

    /**
     * barcode对应拼锅是否存在部分划菜
     *
     * @param barcode
     * @return
     */
    public static boolean isPartMatchedStateWithBarcode(String barcode, @KdsBarcodeState int kdsBarcodeState) {
        if (TextUtils.isEmpty(barcode)) {
            return false;
        }
        //已经划掉的
        String hasExistServedSql = "select state from " + DBModel.getTableName(KdsBarcodeDBModel.class) + " where barcode  = '" + barcode + "' AND state = '" + kdsBarcodeState + "'";
        boolean hasExistServed = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, hasExistServedSql).size() > 0;
        //未划掉的
        String noServedSql = "select state from " + DBModel.getTableName(KdsBarcodeDBModel.class) + " where barcode  = '" + barcode + "' AND state != '" + kdsBarcodeState + "'";
        boolean noServed = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, noServedSql).size() > 0;
        return hasExistServed && noServed;
    }


    public static List<KdsMenuItemStateDBModel> queryDishByBarcode(String barcode, String deptId, int state) {
        if (TextUtils.isEmpty(barcode)) {
            return null;
        }
        String sql = "select * from " + DBModel.getTableName(KdsMenuItemStateDBModel.class) + " where fiState = '" + state + "' AND fsBarCode = '" + barcode + "' AND fsDeptId = '" + deptId + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
    }

    public static String queryBarcodeByDishId(String dishId) {
        if (TextUtils.isEmpty(dishId)) {
            return "";
        }
        String sql = "select fsPotSeq from tbKdsMenuItemState where fsSeq = '" + dishId + "'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 更新制作单印号
     *
     * @param potId
     * @param deptId
     * @param printNo
     */
    public static void updateMakePrintNoByPotId(String potId, String deptId, int printNo) {
        if (TextUtils.isEmpty(potId)) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "更新部门[" + deptId + "]拼菜标识[" + potId + "]制作单印号[" + printNo + "]");
        String sql = "update tbKdsMenuItemState set fiMakePrintNo = '" + printNo + "' where fsPotSeq = '" + potId + "' AND fsDeptId = '" + deptId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 更新传菜单印号
     *
     * @param dishId
     * @param deptId
     * @param printNo
     */
    public static void updatePassPrintNoByDishId(List<String> dishId, String deptId, int printNo) {
        if (ListUtil.isEmpty(dishId)) {
            return;
        }
        String seqList = ListUtil.optSqlParams(dishId);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "更新菜品标识[" + dishId + "]传菜单印号[" + printNo + "]");
        String sql = "update tbKdsMenuItemState set fiPassPrintNo = '" + printNo + "' where fsOriginSeq in (" + seqList + ") AND fsDeptId = '" + deptId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 订单中进入KDS菜品是否已上齐
     *
     * @param sellNo String | 订单号
     * @return boolean | true: 全部完成或已退; false: 有菜品待制作或正在制作
     */
    public static boolean isOrderServed(String sellNo) {
        if (!DBOrderConfig.useKdsService()) {
            return true;
        }
        String sql = "select * from tbKdsMenuItemState where fsSellNo = '" + sellNo + "' and fiState in ('" + KdsMakeState.Wait + "' ,'" + KdsMakeState.ToBeProduced + "', '" + KdsMakeState.Making + "')";
        KdsMenuItemStateDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
        if (model == null) {
            return true;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "订单[" + sellNo + "]中菜品[" + model.fsOriginSeq + "]仍在KDS队列中，状态[" + model.fiState + "]");
        return false;
    }

    /**
     * 查询kds系统中的相关状态的菜品的数量
     * todo 这个写法其实效率低，但是项目不少这种写法
     *
     * @return JSONObject
     */
    public static List<JSONObject> queryKdsProgressByOrderId() {
        String sql = "select kdsDish.fsSellNo, sum(case when fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "') then 1 else 0 end) as total, " +
                "sum(case when fiState in ('" + KdsMakeState.NotWeighed + "', '" + KdsMakeState.Wait + "', '" + KdsMakeState.ToBeProduced + "') then 1 else 0 end) as wait, " +
                "sum(case when fiState = '" + KdsMakeState.Making + "' then 1 else 0 end) as making, " +
                "sum(case when fiState = '" + KdsMakeState.Completed + "' then 1 else 0 end) as complete " +
                "from tableBiz " +
                "LEFT JOIN tbKdsMenuItemState as kdsDish on tableBiz.fsSellNo=kdsDish.fsSellNo " +
                "where tableBiz.fsSellNo != '' and tableBiz.fsmtablesteid=2 and fiItemKind = '1' or fiItemKind = '3' " +
                "GROUP BY kdsDish.fsSellNo";
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
    }

    /**
     * 查询kds系统中的相关状态的菜品
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static ArrayMap<String, JSONObject> queryKdsMenuByState(String orderId) {
        if (TextUtils.isEmpty(orderId)) {
            return null;
        }
        try {
            ArrayMap<String, JSONObject> result = new ArrayMap<>();
            String sql = "" +
                    "select fsOriginSeq,\n" +
                    "       sum(case when fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "') then 1 else 0 end) as total,\n" +
                    "       sum(case when fiState in ('" + KdsMakeState.NotWeighed + "', '" + KdsMakeState.Wait + "', '" + KdsMakeState.ToBeProduced + "') then 1 else 0 end) as wait,\n" +
                    "       sum(case when fiState = '" + KdsMakeState.Making + "' then 1 else 0 end) as making,\n" +
                    "       sum(case when fiState = '" + KdsMakeState.Completed + "' then 1 else 0 end) as complete\n" +
                    "from tbKdsMenuItemState\n" +
                    "where fsSellNo = '" + orderId + "'\n" +
                    "  and fiItemKind = '1'\n" +
                    "group by fsOriginSeq";
            List<JSONObject> all = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);

            String sql2 = "" +
                    "select fsOriginSeq_M as fsOriginSeq,\n" +
                    "       sum(case when fiState not in ('" + KdsMakeState.PendingAllocation + "', '" + KdsMakeState.Retired + "') then 1 else 0 end) as total,\n" +
                    "       sum(case when fiState in ('" + KdsMakeState.NotWeighed + "', '" + KdsMakeState.Wait + "', '" + KdsMakeState.ToBeProduced + "') then 1 else 0 end) as wait,\n" +
                    "       sum(case when fiState = '" + KdsMakeState.Making + "' then 1 else 0 end) as making,\n" +
                    "       sum(case when fiState = '" + KdsMakeState.Completed + "' then 1 else 0 end) as complete\n" +
                    "from tbKdsMenuItemState\n" +
                    "where fsSellNo = '" + orderId + "'\n" +
                    "  and fiItemKind = '3'\n" +
                    "group by fsOriginSeq_M";
            List<JSONObject> dtl = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql2);

            if (all == null) {
                all = new ArrayList<>();
            }
            if (!ListUtil.isEmpty(dtl)) {
                all.addAll(dtl);
            }
            if (ListUtil.isEmpty(all)) {
                return result;
            }

            for (JSONObject jsonObject : all) {
                if (jsonObject == null) {
                    continue;
                }
                result.put(jsonObject.getString("fsOriginSeq"), jsonObject);
            }
            return result;
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return null;
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static void serveByKds(String dishId, String hostId, UserDBModel user) {
        if (TextUtils.isEmpty(dishId)) {
            return;
        }
        KdsMenuItemStateDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbKdsMenuItemState where fsSeq = '" + dishId + "'", KdsMenuItemStateDBModel.class);
        if (model == null) {
            return;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(model.fsSellNo);
        String uniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "划菜锁桌");
        try {
            if (orderCache.orderStatus == OrderStatus.PAIED || orderCache.orderStatus == OrderStatus.ANTI_BACK || orderCache.orderStatus == OrderStatus.CANCEL) {
                return;
            }
            ArrayMap<String, BigDecimal> dishDelimit = new ArrayMap<>();

            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                for (MenuItem menuItem : orderCache.originMenuList) {
                    if (menuItem == null) {
                        continue;
                    }

                    if (model.fiItemKind == 3 && TextUtils.equals(model.fsOriginSeq_M, menuItem.menuBiz.uniq)) {
                        // 原始划菜数量
                        BigDecimal origin = menuItem.menuBiz.delimitNum;
                        // 此次划菜数量
                        BigDecimal current = calcPackNum(dishId);
                        // 计算此次划菜差量
                        BigDecimal differ = current.subtract(origin);
                        dishDelimit.put(menuItem.menuBiz.uniq, differ);
                        // 修改菜品菜品
                        menuItem.menuBiz.delimitNum = current;
                        menuItem.menuBiz.fiMenuProgress = current.compareTo(BigDecimal.ZERO) > 0 ? 1 : 0;
                    } else {
                        if (!TextUtils.equals(model.fsOriginSeq, menuItem.menuBiz.uniq)) {
                            continue;
                        }
                        // 原始划菜数量
                        BigDecimal origin = menuItem.menuBiz.delimitNum;
                        // 计算此次划菜差量
                        BigDecimal differ = BigDecimal.ONE;
                        // 此次划菜数量
                        BigDecimal current = origin.add(differ);

                        dishDelimit.put(menuItem.menuBiz.uniq, differ);

                        // 修改菜品菜品
                        menuItem.menuBiz.delimitNum = current;
                        menuItem.menuBiz.fiMenuProgress = current.compareTo(BigDecimal.ZERO) > 0 ? 1 : 0;
                    }
                }

                OrderSaveDBUtil.replacePaddleData(hostId, user, orderCache, dishDelimit);
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "KDSUtil serveByKds 划菜");
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(uniq, orderCache.fsmtableid, orderCache.orderID, "划菜解锁");
        }
    }

    /**
     * 计算本次划菜
     *
     * @param dishId
     * @return
     */
    public static BigDecimal calcPackNum(String dishId) {
        String sql1 = "select fsOriginSeq, sum(case when fiState = '3' then 1 else 0 end) as complete\n" +
                "from tbKdsMenuItemState\n" +
                "where fsOriginSeq_M in (select fsOriginSeq_M from tbKdsMenuItemState where fsSeq = '" + dishId + "')\n" +
                "  and fiItemKind = '3'\n" +
                "group by fsOriginSeq";
        List<JSONObject> hasCompleted = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql1);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "已完成的套餐明细: " + JSON.toJSONString(hasCompleted));

        String sql2 = "\n" +
                "select fsseq, fdsaleqty, fiOrderItemKind\n" +
                "from tbsellorderitem\n" +
                "where fsseq in (select fsOriginSeq_M from tbKdsMenuItemState where fsSeq = '" + dishId + "')\n" +
                "   or fsseq_m in (select fsOriginSeq_M from tbKdsMenuItemState where fsSeq = '" + dishId + "') ";
        List<JSONObject> origin = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql2);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "原始的套餐明细: " + JSON.toJSONString(origin));

        if (ListUtil.isEmpty(origin) || ListUtil.isEmpty(hasCompleted)) {
            return BigDecimal.ZERO;
        }

        BigDecimal titleQty = BigDecimal.ZERO;
        Map<String, BigDecimal> onePotQty = new HashMap<>();
        for (JSONObject object : origin) {
            if (object == null) {
                continue;
            }
            if (object.getIntValue("fiOrderItemKind") == 2) {
                titleQty = object.getBigDecimal("fdSaleQty");
                continue;
            }
            onePotQty.put(object.getString("fsSeq"), object.getBigDecimal("fdSaleQty"));
        }

        if (titleQty == null || titleQty.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        BigDecimal minPot = titleQty;
        for (JSONObject object : hasCompleted) {
            if (object == null) {
                continue;
            }
            BigDecimal completeNum = object.getBigDecimal("complete");
            BigDecimal originNum = onePotQty.get(object.get("fsOriginSeq"));
            if (originNum == null) {
                continue;
            }
            originNum = originNum.divide(titleQty);
            if (originNum.compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            BigDecimal hasPot = completeNum.divide(originNum);
            if (minPot.compareTo(hasPot) < 0) {
                continue;
            }
            minPot = hasPot;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "计算已上套餐数量: " + minPot.toPlainString());
        return minPot;
    }

    public static Map<String, BigDecimal> queryDelNumByPackage(String fsSeq_M) {
        Map<String, BigDecimal> result = new HashMap<>();
        List<JSONObject> data = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select fsSeq, fiOrderItemKind, fdSaleQty from tbSellOrderItem");
        if (ListUtil.isEmpty(data)) {
            return result;
        }
        BigDecimal qty = BigDecimal.ZERO;
        for (JSONObject object : data) {
            if (object.getIntValue("fiOrderItemKind") == 2) {
                qty = object.getBigDecimal("fdSaleQty");
                continue;
            }
            result.put(object.getString("fsSeq"), object.getBigDecimal("fdSaleQty"));
        }
        if (qty == null || qty.compareTo(BigDecimal.ZERO) == 0) {
            return result;
        }
        if (result != null && result.size() > 0) {
            for (String uniq : result.keySet()) {
                BigDecimal num = result.get(uniq);
                if (num == null) {
                    num = BigDecimal.ZERO;
                }
                result.put(uniq, num.divideToIntegralValue(qty));
            }
        }
        return result;
    }
}
