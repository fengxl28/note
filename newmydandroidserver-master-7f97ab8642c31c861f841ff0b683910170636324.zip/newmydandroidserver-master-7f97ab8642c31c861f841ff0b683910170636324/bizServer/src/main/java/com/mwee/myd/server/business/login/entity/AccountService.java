package com.mwee.myd.server.business.login.entity;

import com.mwee.android.base.net.BusinessBean;

/**
 * AccountService
 * Created by virgil on 16/6/8.
 */
public class AccountService extends BusinessBean {
//    1-排队
//    2-菜单
//    3-点餐
//    4-云POS
//    5-外卖
//    6-预定
//    7-厨房配菜
//    8-支付
//    9-取餐柜
//    10-预点打单
//    11-菜单查看
//    12-卡券服务
//    13-POS收款
//    14-弹幕
//    15-预约
//    16-快餐
//    17-会员
//    18-餐饮接入
//    19-404电话
//    20-手持点菜宝

    public boolean bMemEn = false;// 是否支持会员 0关闭 1开启
    public boolean bOrderEn = false;// 预点单打印
    public boolean bQueueEn = false;//是否支持排队
    public boolean bBookEn;// 是否可预订0否1可
    public boolean bCouponEn = false;//是否支持卡券
    public boolean bCashEn = false;//是否支持收款
    public boolean bDanmuEn = false;//是否支持弹幕
    public boolean bPreOrderEn = false;// 是否支持预约取号
    public boolean bDishEn = false;//是否支持显示菜单
    public boolean bShopVip = false;//侧边栏是否支持会员
    public boolean member = false;//是否开通会员功能(侧边栏)
    public boolean bTableSearch = false;
    public boolean dianCai = false;//是否支持手持点菜宝
    public boolean pay = false;//是否支持收银

    public AccountService() {
    }
}
