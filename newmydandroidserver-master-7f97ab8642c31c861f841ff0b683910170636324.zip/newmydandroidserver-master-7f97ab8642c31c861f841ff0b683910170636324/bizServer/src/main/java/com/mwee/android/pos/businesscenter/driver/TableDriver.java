package com.mwee.android.pos.businesscenter.driver;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.air.dao.ITableService;
import com.mwee.android.pos.businesscenter.module.table.TableServiceImpl;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.TableQRProcess;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintTableUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.message.GetAllBusinessTableResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.PayVoidResponse;
import com.mwee.android.pos.connect.business.table.AreaBizResponse;
import com.mwee.android.pos.connect.business.table.ChangeDiningStandardResponse;
import com.mwee.android.pos.connect.business.table.ChangeTableResponse;
import com.mwee.android.pos.connect.business.table.LockTableResponse;
import com.mwee.android.pos.connect.business.table.MareaInfoResponse;
import com.mwee.android.pos.connect.business.table.OpenParamMenuRespose;
import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.business.table.PrePayResponse;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataResponse;
import com.mwee.android.pos.connect.business.table.RefreshTableBizDataSimpleResponse;
import com.mwee.android.pos.connect.business.table.ShareTableResponse;
import com.mwee.android.pos.connect.business.table.TableActionRespose;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AreaBizDBModel;
import com.mwee.android.pos.db.business.MSectionDBModel;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.db.business.table.TableSteDBModel;
import com.mwee.android.pos.db.business.table.TableUnlockType;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/9/18.
 * //桌台
 * 2、获取所有桌台业务
 * 4、查询桌台是否开台
 * 5、桌台开台
 * 6、桌台关台
 * 7、拼桌
 * 8、换桌
 */
@SuppressWarnings("unused")
public class TableDriver implements IDriver {

    private static final String TAG = "table";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 站点请求最新的桌台业务状态以及拼桌情况、各个区域的微信消息数量
     * 获取所有桌台业务需返回:
     * 1、桌台业务集合
     * 2、临时桌台集合
     * 3、区域消息集合
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/refreshTableBizData")
    public SocketResponse refreshTableBizData(SocketHeader head, String param) {

        LogUtil.logOnlineDebug("table--finish", "业务中心收到拉桌台状态请求：" + JSON.toJSONString(param));
        SocketResponse response = new SocketResponse();
        RefreshTableBizDataResponse responseData = new RefreshTableBizDataResponse();
        response.data = responseData;

        try {
            response.code = SocketResultCode.SUCCESS;
            TableBusinessUtil.getRefreshTableBizDataResponse(responseData);
        } catch (Exception e) {
            LogUtil.logError("业务中心收到拉桌台状态请求 处理异常 ", e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 站点请求最新的桌台业务状态以及拼桌情况、各个区域的微信消息数量
     * 获取所有桌台业务需返回:
     * 1、桌台业务集合
     * 2、临时桌台集合
     * 3、区域消息集合
     * 返回数据为简化版
     */
    @DrivenMethod(uri = TAG + "/refreshTableBizDataSimple")
    public SocketResponse refreshTableBizDataSimple(SocketHeader head, String param) {

        LogUtil.logBusiness("table--finish", "业务中心收到拉桌台状态请求(simple)："+ JSON.toJSONString(param));

        SocketResponse response = new SocketResponse();
        RefreshTableBizDataSimpleResponse responseData = new RefreshTableBizDataSimpleResponse();
        response.data = responseData;

        try {
            response.code = SocketResultCode.SUCCESS;
            TableBusinessUtil.getRefreshTableBizDataSimpleResponse(responseData);
        } catch (Exception e) {
            LogUtil.logError("业务中心收到拉桌台状态请求(simple) 处理异常 ",e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/changePersonCount")
    public SocketResponse changePersonCount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            //ChengePersonCountRequest request = JSON.parseObject(param, ChengePersonCountRequest.class);
            JSONObject request = JSON.parseObject(param);
            OrderSession.getInstance().getOrder(request.getString("orderId")).personNum = request.getIntValue("count");
            OrderSaveDBUtil.updatePersonNum(request.getString("orderId"), request.getIntValue("count"));
            NotifyToClient.refreshTableOrOrders();
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/changeDiningStandard")
    public SocketResponse changeDiningStandard(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        ChangeDiningStandardResponse responseData = new ChangeDiningStandardResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            BigDecimal amt = request.getBigDecimal("amt");

            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            orderCache.diningStandardAmt = amt;
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().writeOrder(orderId, true, "changeDiningStandard");
            NotifyToClient.refreshTableOrOrders();

            responseData.newOrderCache = orderCache;
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @DrivenMethod(uri = TAG + "/openAndCheckToOrder")
    public SocketResponse openAndCheckToOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse<OpenTableAndCheckToOrderRespose> response = new SocketResponse<OpenTableAndCheckToOrderRespose>();
        try {
            //OpenTableAndCheckToOrderRequest request = JSON.parseObject(param, OpenTableAndCheckToOrderRequest.class);
            JSONObject request = JSON.parseObject(param);
            LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--开始");
            TableBusinessUtil.openTableAndOrder(response, head.hd, request);
            LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--结束--code" + response.code);
            if (response.data != null && response.code == SocketResultCode.SUCCESS) {
                NotifyToClient.orderChange(response.data.orderCache.orderID);
                LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--结束--步骤-orderChange" );
                Boolean isPrinter = request.getBoolean("isPrinter");// 是否打印，默认true
                if (response.code == SocketResultCode.SUCCESS && (isPrinter == null ? true : isPrinter)) {
                    final ArrayList<Integer> printTaskIds = new ArrayList<>();
                    OrderCache orderCache = response.data.orderCache;
                    //交给业务中心打印

                    List<Integer> printIDs = PrintTableUtil.openTableReport(orderCache, request.getString("hostID"));
                    if (!ListUtil.isEmpty(printIDs)) {
                        printTaskIds.addAll(printIDs);
                    }
                    LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--结束--步骤-openTableReport" );

                    printIDs = PrintOrderUtil.printMenuList(orderCache, null, request.getString("hostID"));
                    if (!ListUtil.isEmpty(printIDs)) {
                        printTaskIds.addAll(printIDs);
                    }
                    LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--结束--步骤-printMenuList" );

                    if (DBOrderConfig.useKdsService()) {
                        KdsManager.getInstance().order(orderCache, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", request.getString("hostID"), HostUtil.getUserModelBySession(head.us));
                    } else {
                        printIDs = PrintOrderUtil.printPassTo(orderCache, request.getString("hostID"));
                        if (!ListUtil.isEmpty(printIDs)) {
                            printTaskIds.addAll(printIDs);
                        }
                        PrintOrderUtil.printMakeOrder(orderCache, request.getString("hostID"), orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", null);
                    }
                    LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--结束--步骤-printPassTo" );

                    //不能打印的任务交给站点打印
                    response.data.printTaskIds = printTaskIds;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--外层-结束-返回");

        return response;
    }

    @DrivenMethod(uri = TAG + "/tableAction")
    public SocketResponse tableAction(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            LogUtil.logBusiness("业务中心 tableAction()异常 head = " + JSON.toJSONString(head) + "; param = "+JSON.toJSONString(param));
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int action = request.getInteger("action");
//            String fsuserId = request.getString("fsuserId");
            String tableId = request.getString("tableId");
            String orderId = request.getString("orderId");
            boolean getToken = request.getBoolean("getToken");

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            switch (action) {
                case TableConstans.TABLE_ACTION_STATUS:

                    TableDBUtil.unlocakAllTableByUser(userDBModel.fsUserId);
                    TableDBUtil.unlockTableByHostId(head.hd);

                    TableBusinessUtil.checkTableStatus(response, tableId, userDBModel.fsUserId, userDBModel.fsUserName);
                    if (response.code == SocketResultCode.SUCCESS) {
                        String errorInfo = TableBusinessUtil.checkTableLock(head.hd, userDBModel.fsUserId, tableId);
                        if (!TextUtils.isEmpty(errorInfo)) {
                            response.code = -1;
                            response.message = errorInfo;
                        } else if (response.data != null && response.data instanceof TableActionRespose) {
                            TableActionRespose responseData = (TableActionRespose) response.data;
                            if (responseData.orderCache != null) {
                                // 更新订单最低消费金额
                                DinnerStandardUtil.minStandardChanged(responseData.orderCache, responseData.tableStatusBean.fsmareaid, userDBModel);

                                BigDecimal totalPrice = responseData.orderCache.totalPrice;
                                responseData.orderCache.reCalcAllByAll();
                                if (totalPrice.compareTo(responseData.orderCache.totalPrice) != 0) {
                                    OrderSession.getInstance().writeOrder(responseData.orderCache.orderID, true, "tableAction");
                                    NotifyToClient.refreshTableOrOrders();
                                }
                                TableQRProcess.checkTableQRSortLink(tableId);

                                //已开台的订单未被锁定，是否需要token?
                                if (!TextUtils.equals(responseData.tableStatusBean.fsmtablesteid, TableConstans.TABLE_STATUS_FREE) && getToken) {
                                    responseData.orderToken = ServerCache.getInstance().generateNewToken(responseData.orderCache.orderID);
                                }

                            }

                            // KDS信息返回
                            if (responseData.orderCache != null) {
                                responseData.kdsMenuSeqByState = KDSUtils.queryKdsMenuByState(responseData.orderCache.orderID);
                            }
                        }
                    }
                    /* 查看桌台状态不广播刷新 */
                    break;
                case TableConstans.TABLE_ACTION_CLOSE:
                    TableBusinessUtil.closeTable(response, tableId, orderId);
                    NotifyToClient.refreshTableOrOrders();
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 开台预点菜品
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/openParamMenu")
    public SocketResponse openParamMenu(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        OpenParamMenuRespose openParamMenuRespose = new OpenParamMenuRespose();
        response.data = openParamMenuRespose;
        try {
            JSONObject request = JSON.parseObject(param);

            String fsUserId = request.getString("fsuserId");
            String fsmareaid = request.getString("fsmareaid");
            int personNum = request.getInteger("personNum");
            String sql = "select * from tbUser where fsUserId = '" + fsUserId + "' and fiStatus <> '13' order by fiStatus desc ";
            UserDBModel userDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, UserDBModel.class);
            if (userDBModel == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.msg(R.string.ser_pay_no_user);
                return response;
            }
            openParamMenuRespose.openParamMenuList = OrderBizUtil.getOpenParamOrderMenu(fsmareaid, personNum, userDBModel.fsUserId, userDBModel.fsUserName);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 换桌
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/changeTable")
    public SocketResponse changeTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();
        try {
            /*ChangeTableRequest request = JSON.parseObject(param, ChangeTableRequest.class);*/
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }

            if (!ServerCache.getInstance().verifyToken(request.getString("originOrderID"), head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            TableBusinessUtil.doChangeTable(head.ot, request, socketResponse, userDBModel, head.hd);

            //打印换桌小票
            if (socketResponse.code == SocketResultCode.SUCCESS) {
                if (socketResponse.data instanceof ChangeTableResponse) {
                    //KDS服务下不打印换桌单
                    if(!DBOrderConfig.useKdsService()){
                        ChangeTableResponse changeTableResponse = (ChangeTableResponse) socketResponse.data;
                        List<Integer> printNoList = PrintTableUtil.changeTableReport(request.getString("operateWaiterName"), request.getString("originTableName"),
                                request.getString("targetTableName"), changeTableResponse.newOrderCache.orderID,
                                changeTableResponse.newSeqList, request.getString("operateHostID"));
                        if (!ListUtil.isEmpty(printNoList)) {
                            ((ChangeTableResponse) socketResponse.data).printNo = printNoList;
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 拼桌
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/shareTable")
    public SocketResponse shareTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse socketResponse = new SocketResponse();
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            JSONObject request = JSON.parseObject(param);
            MtableDBModel mtableDBModel = TableBusinessUtil.shareTable(request.getString("tableId"), userDBModel);
            if (mtableDBModel == null) {
                socketResponse.code = -1;
                socketResponse.msg(R.string.ser_no_table);
                return socketResponse;
            }

            ShareTableResponse response = new ShareTableResponse();
            response.fsmtableid = mtableDBModel.fsmtableid;
            response.newTableName = mtableDBModel.fsmtablename;
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "拼桌成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 拼桌
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/airShareTable")
    public SocketResponse airShareTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        JSONObject request = JSON.parseObject(param);
        String tableId = request.getString("tableId");
        ITableService tableService = new TableServiceImpl();
        return tableService.doShareTable(tableId, userDBModel);
    }

    /**
     * 预结单打印,修改桌台预结单打印状态
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/change_pre_status")
    public SocketResponse changePreStatus(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            //ChangePreStatusRequest request = JSON.parseObject(param, ChangePreStatusRequest.class);
            JSONObject request = JSON.parseObject(param);
            TableBusinessUtil.modifyPrePrint(response, request.getString("tableId"), request.getString("sellNo"), request.getIntValue("status"));
            NotifyToClient.refreshTableOrOrders();
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 更改网络标志状态
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/update_wxmsgflag")
    public SocketResponse updateWxMsg(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsmtableid = request.getString("fsmtableid");
            String extra_order = request.getString("extra_order");
            int flag = request.getInteger("flag");
            int fiwxmsgflag = request.getInteger("fiwxmsgflag");
            TableBusinessUtil.updateRapidOrder(fsmtableid, flag, fiwxmsgflag, extra_order);
            NotifyToClient.refreshTableOrOrders();
            NotifyToClient.refreshRapidbell(fsmtableid, ((flag & 2) == 2) ? "0" : "1", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/lockTable")
    public SocketResponse lockTable(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse socketResponse = new SocketResponse();
        try {
            //LockTableRequest request = JSON.parseObject(param, LockTableRequest.class);
            JSONObject request = JSON.parseObject(param);
            LockTableResponse response = new LockTableResponse();
            String errorInfo = TableBusinessUtil.lockTable(request.getString("targetTableID"), request.getString("requestHostID"), request.getString("requestUserID"), request.getString("requestUserName"));
            if (TextUtils.isEmpty(errorInfo)) {
                socketResponse.code = SocketResultCode.SUCCESS;
                if (!TextUtils.isEmpty(request.getString("orderID"))) {
                    response.orderOptToken = ServerCache.getInstance().generateNewToken(request.getString("orderID"));
                    socketResponse.data = response;
                }
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = errorInfo;
            }
            NotifyToClient.refreshTableLock();//刷新桌台状态
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }

        return socketResponse;
    }

    /**
     * 释放指定站点的所有锁
     *
     * @param requestHostID String
     */
    @DrivenMethod(uri = "table/releaseHostLock")
    public static void releaseHostLock(String requestHostID) {
        TableBusinessUtil.unlockTableByHost(requestHostID);
        FastFoodBusinessUtil.unLockOrderByHostId(requestHostID);
        NotifyToClient.refreshTableLock();
        NotifyToClient.refreshFastFoodOrdersLock();
    }

    /**
     * 解除指定站点锁定的桌台和订单
     *
     * @param requestHostID String
     */
    @DrivenMethod(uri = "table/unlockTableByHost")
    public static void unlockTableByHost(String requestHostID) {
        TableBusinessUtil.unlockTableByHost(requestHostID);
        FastFoodBusinessUtil.unLockOrderByHostId(requestHostID);
        NotifyToClient.refreshTableLock();
        ServerCache.getInstance().delNewMemberWithHost(requestHostID);
    }

    @DrivenMethod(uri = "table/unlockTable")
    public SocketResponse unlockTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int unlockType = request.getInteger("unlockType");
            if (unlockType == TableUnlockType.BY_USER) {
                TableBusinessUtil.unlockTableByUser(request.getString("currentUserID"));
            } else if (unlockType == TableUnlockType.BY_TABLEID_AND_HOSTID) {
                TableBusinessUtil.unlockTable(request.getString("targetTableID"), head.hd);
            } else if (unlockType == TableUnlockType.BY_HOSTID) {
                TableDriver.releaseHostLock(head.hd);
            } else if (unlockType == TableUnlockType.BY_TABLEID) {
                TableBusinessUtil.unlockTargetTable(request.getString("targetTableID"));
            }
            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.refreshTableLock();//刷新桌台状态，解锁桌台

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = "table/unlockTableAndShotOff")
    public SocketResponse unlockTableAndShotOff(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            String unLockTableId = request.getString("unLockTableId");
            if (TextUtils.isEmpty(unLockTableId)) {
                response.msg(R.string.ser_error_tableid);
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            //构建桌台信息
            TableBusinessUtil.checkTableStatus(response, unLockTableId, userDBModel.fsUserId, userDBModel.fsUserName);
            if (response.code == SocketResultCode.SUCCESS) {
                //查询锁桌站点
                String shotOffHostId = TableBusinessUtil.findHostIdByTableId(unLockTableId);
                String orderId = TableBusinessUtil.getOrderIDByTableID(unLockTableId);
                //解锁桌台
                TableBusinessUtil.unlockTargetTable(unLockTableId);
                //删除点菜token
                if (!TextUtils.isEmpty(orderId)) {
                    ServerCache.getInstance().releaseToken(orderId);
                }
                //踢出锁定桌台的服务员所在站点
                NotifyToClient.shotOffByHostId(shotOffHostId);
                //刷新桌台信息
                NotifyToClient.refreshTableLock();
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取所有已开台桌子的简讯
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/getOpenedTableSimpInfo")
    public SocketResponse getOpenedTableSimpInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllBusinessTableResponse tableResponse = new GetAllBusinessTableResponse();
        response.data = tableResponse;
        try {
            //GetAllBusinessTableRequest request = JSONObject.parseObject(param, GetAllBusinessTableRequest.class);
            tableResponse.tableBizSimpInfoList = TableBusinessUtil.getAllTablesBizInfo();
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 获取所有已开台桌子的简讯
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/loadAllMarea")
    public SocketResponse loadAllMarea(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        MareaInfoResponse mareaInfoResponse = new MareaInfoResponse();
        response.data = mareaInfoResponse;
        try {
            List<MareaDBModel> temps = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbmarea where fiStatus = '1'", MareaDBModel.class);
            if (ListUtil.isEmpty(temps)) {
                temps = new ArrayList<>();
            }
            mareaInfoResponse.mareaInfoResponseList = temps;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 更新登录站点的班别信息
     *
     * @param hostid  String | 站点ID
     * @param shiftID String | 班别ID
     */
    @DrivenMethod(uri = "table/updateHostShift")
    public void updateHostShift(String hostid, String shiftID) {
        if (TextUtils.isEmpty(hostid)) {
            return;
        }
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set shiftid='" + shiftID + "' where hostid='" + hostid + "'");
    }

    /**
     * 加载预付金页面
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/startPrePay")
    public SocketResponse startPrePay(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PrePayResponse prePayResponse = new PrePayResponse();
        response.data = prePayResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSONObject.parseObject(param);
            String tableID = request.getString("tableID");
            if (TextUtils.isEmpty(tableID)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "桌台号不能为空";
                return response;
            }

            String orderID = request.getString("orderID");
            String sellNo = TableBusinessUtil.getOrderIDByTableID(tableID);
            if (!TextUtils.isEmpty(sellNo) && !TextUtils.equals(orderID, sellNo)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已发生变化";
                return response;
            }

            if (!TextUtils.isEmpty(orderID)) {
                prePayResponse.mPayedList = OrderUtil.getPrePayModel(orderID);
            }
            prePayResponse.mPayOriginModelList = PayCache.getInstance().getDefaultPayModelForPrePay();
            BigDecimal totalPre = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(prePayResponse.mPayedList)) {
                for (PayModel payModel : prePayResponse.mPayedList) {
                    totalPre = totalPre.add(payModel.payAmount);
                }
            }
            prePayResponse.mPrePayAmt = totalPre;

            TableBusinessUtil.modifyPrePay(null, tableID, ListUtil.isEmpty(prePayResponse.mPayedList) ? TableStatusBean.NOMAL : TableStatusBean.PRE_PAYED);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 预付金收款
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/prepay")
    public SocketResponse prepay(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PrePayResponse prePayResponse = new PrePayResponse();
        response.data = prePayResponse;
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSONObject.parseObject(param);
            String tableID = request.getString("tableID");
            String orderID = request.getString("orderID");
            TempOrderDishesCache temp = request.getObject("orderDishesCache", TempOrderDishesCache.class);
            PayOriginModel payOriginModel = request.getObject("payMethod", PayOriginModel.class);
            BigDecimal amt = request.getBigDecimal("amt");

            if (TextUtils.isEmpty(tableID)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "桌台号不能为空";
                return response;
            }

            String sellNo = TableBusinessUtil.getOrderIDByTableID(tableID);
            if (TextUtils.isEmpty(sellNo)) {
                // 查询桌台状态
                SocketResponse<TableActionRespose> tableActionRespose = new SocketResponse<>();
                userDBModel.fsUserName = temp.waiterName;
                userDBModel.fsUserId = temp.waiterID;
                TableBusinessUtil.checkTableStatus(tableActionRespose, temp.fsmtableid, userDBModel.fsUserId, userDBModel.fsUserName);
                if (tableActionRespose.code == SocketResultCode.SUCCESS) {
                    OrderCache orderCache = null;
                    if ((TextUtils.equals(TableConstans.TABLE_STATUS_FREE, tableActionRespose.data.tableStatusBean.fsmtablesteid) && tableActionRespose.data.orderCache == null)) {
                        orderCache = OrderDriver.generateNewOrder();
                        sellNo = orderCache.orderID;
                        String newId = sellNo.substring(8, 12);
                        // 桌台开台
                        TableBusinessUtil.doOpenTable(response, head.hd, tableID, sellNo, userDBModel);
                        if (response.code == SocketResultCode.SUCCESS) {
                            RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金收款 -> 桌台[" + tableID + "]开台成功, 订单[" + sellNo + "]");
                            orderCache.thirdOrderType = temp.thirdBizType;
                            // 订单保存
                            orderCache.fsmareaid = temp.fsmareaid;
                            orderCache.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + temp.fsmareaid + "'");
                            orderCache.fsmtableid = tableID;
                            orderCache.fsmtablename = TableDBUtil.getTableNameById(tableID);
                            orderCache.personNum = temp.personNum;
                            orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
                            orderCache.waiterID = temp.waiterID;
                            orderCache.waiterName = temp.waiterName;
                            orderCache.shopID = head.shopid;
                            orderCache.currentHostID = temp.currentHostID;
                            orderCache.currentSectionID = OrderUtil.getSectionId();
                            orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
                            orderCache.orderID = sellNo;
                            orderCache.mealNumber = newId + "";
                            orderCache.orderStatus = OrderStatus.NORMAL;
                            //构建餐段
                            MSectionDBModel section = OrderUtil.getSection();
                            if (section != null) {
                                orderCache.currentSectionID = section.fsMSectionId;
                            }
                            OrderSession.getInstance().writeOrder(sellNo, orderCache, true, "table/prepay");
//                            OrderProcessor.saveOrder(orderCache, null);

                            // 是否下单前已绑定会员
                            if (temp.isMember && (temp.mMemberCardModel != null || temp.mNewMemberCardModel != null)) {
                                if (temp.mNewMemberCardModel != null) { // 会员重构对接，优先使用新的
                                    orderCache.setMember(temp.mNewMemberCardModel);
                                } else { // 兼容老的
                                    orderCache.setMember(temp.mMemberCardModel);
                                }
//                                if (DBMetaUtil.autoUseMemberPrice()) {
//                                    orderCache.updateAllMenuToMemberPrice();
//                                }
                                MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, userDBModel.fsUserId);
                                orderCache.reCalcAllByAll();
                                OrderSession.getInstance().writeOrder(sellNo, orderCache, true, "table/prepay 2");
//                                OrderProcessor.saveOrder(orderCache, null);
                                if (orderCache.dinnerModel()) {
                                    MemberBizUtil.requestMemberComents(orderCache.memberInfoS.card_no);
                                }
                            }

                            // 打印开台单
                            PrintTableUtil.openTableReport(orderCache, head.hd);
                        } else {
                            RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金收款 -> 桌台[" + tableID + "]开台失败, 订单[" + sellNo + "]");
                            return response;
                        }
                    }
                    // 未开台情况下，收取预付金需要开台，生成ot, 并返回, 已保证后续操作的可能
                    prePayResponse.mOrderToken = ServerCache.getInstance().generateNewToken(sellNo);
                    head.ot = prePayResponse.mOrderToken;
                } else {
                    response.code = tableActionRespose.code;
                    response.message = tableActionRespose.message;
                    return response;
                }
            }

            if (OrderSession.getInstance().getPay(sellNo) == null) {
                OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(sellNo), userDBModel, head.hd);
            }

            // 收款
            String fsmtableId = OrderSaveDBUtil.getTableIDByOrderID(sellNo);
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 预付金收款 ");
            try {
                SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
                if (!PayType.isAliWeixin(payOriginModel)) {
                    socketResponse = BillUtil.selectPayType(head.ot, sellNo, payOriginModel, amt, userDBModel, head.hd, true, true);
                    if (socketResponse.code != SocketResultCode.SUCCESS) {
                        RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金收款 -> 订单[" + sellNo + "]收款失败。MESSAGE: " + socketResponse.message);
                        response.code = socketResponse.code;
                        response.message = socketResponse.message;
                        return response;
                    }
                    RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金收款 -> 订单[" + sellNo + "]收款成功。收取的支付 seq: " + JSON.toJSONString(socketResponse.data.seqList));
                    prePayResponse.seqList = socketResponse.data.seqList;
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 预付金收款 ");
            }

            PaySession session = OrderSession.getInstance().getPay(sellNo);
            if (session != null) {
                prePayResponse.billNO = session.billNO;
            }
            prePayResponse.mOrderCache = OrderSession.getInstance().getOrder(sellNo);
            prePayResponse.mPayOriginModelList = PayCache.getInstance().getDefaultPayModelForPrePay();
            prePayResponse.mPayedList = OrderUtil.getPrePayModel(sellNo);
            BigDecimal totalPre = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(prePayResponse.mPayedList)) {
                for (PayModel payModel : prePayResponse.mPayedList) {
                    totalPre = totalPre.add(payModel.payAmount);
                }
            }
            prePayResponse.mPrePayAmt = totalPre;

            TableBusinessUtil.modifyPrePay(null, temp.fsmtableid, ListUtil.isEmpty(prePayResponse.mPayedList) ? TableStatusBean.NOMAL : TableStatusBean.PRE_PAYED);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 打印预付金小票
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/printPrePay")
    public SocketResponse printPrePay(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PrePayResponse prePayResponse = new PrePayResponse();
        response.data = prePayResponse;
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSONObject.parseObject(param);
            String tableID = request.getString("tableID");
            String orderID = request.getString("orderID");
            List<Integer> seqList = JSON.parseArray(request.getString("seqList"), Integer.class);
            int seq = request.getIntValue("seq");

            String sellNo = TableBusinessUtil.getOrderIDByTableID(tableID);
            if (!TextUtils.isEmpty(sellNo) && !TextUtils.equals(orderID, sellNo)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已发生变化";
                return response;
            }

            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            if (orderCache == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单不存在";
                return response;
            }
            RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金 -> 桌台[" + tableID + "], 订单[" + orderID + "], 打印预付金小票. " + JSON.toJSONString(seq));
            PrintBillUtil.printPrePay(HostUtil.getHistoryBusineeDate(""), orderCache.fsmtablename, orderCache.orderID, orderCache.currentSectionID, userDBModel.fsUserName, orderCache.personNum, head.hd, seqList);

            prePayResponse.mPayOriginModelList = PayCache.getInstance().getDefaultPayModelForPrePay();
            prePayResponse.mPayedList = OrderUtil.getPrePayModel(orderID);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 预付金退款
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "table/cancelPrePay")
    public SocketResponse cancelPrePay(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PrePayResponse prePayResponse = new PrePayResponse();
        response.data = prePayResponse;
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSONObject.parseObject(param);
            String tableID = request.getString("tableID");
            String orderID = request.getString("orderID");
            int seq = request.getIntValue("seq");

            String sellNo = TableBusinessUtil.getOrderIDByTableID(tableID);
            if (!TextUtils.isEmpty(sellNo) && !TextUtils.equals(orderID, sellNo)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已发生变化";
                return response;
            }

            SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(head.ot, userDBModel.fsUserId, orderID);
            if (!checkResponse.success()) {
                response.code = checkResponse.code;
                response.message = checkResponse.message;
                return response;
            }

            RunTimeLog.addLog(RunTimeLog.PRE_PAY, "预付金收款 -> 订单[" + sellNo + "]退款。退款的支付 seq: " + seq);
            SocketResponse<PayVoidResponse> resVoid = BillUtil.startVoidPay(head.ot, orderID, userDBModel, head.hd, seq);
            if (!resVoid.success()) {
                response.code = checkResponse.code;
                response.message = checkResponse.message;
                return response;
            }

            prePayResponse.mPayOriginModelList = PayCache.getInstance().getDefaultPayModelForPrePay();
            prePayResponse.mPayedList = OrderUtil.getPrePayModel(orderID);

            if (!ListUtil.isEmpty(prePayResponse.mPayedList)) {
                BigDecimal totalPre = BigDecimal.ZERO;
                for (PayModel payModel : prePayResponse.mPayedList) {
                    totalPre = totalPre.add(payModel.payAmount);
                }
                prePayResponse.mPrePayAmt = totalPre;
                TableBusinessUtil.modifyPrePay(null, tableID, TableStatusBean.PRE_PAYED);
            } else {
                TableBusinessUtil.modifyPrePay(null, tableID, TableStatusBean.NOMAL);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取桌台"已印单"启用状态
     */
    @DrivenMethod(uri = TAG + "/getPrintedSte")
    public SocketResponse getPrintedSte(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            response.data = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbMTableSte where fsMTableSteId='4'", TableSteDBModel.class);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAllAreaBiz")
    public SocketResponse loadAllAreaBiz(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();
        if (TextUtils.isEmpty(params)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            return socketResponse;
        }
        AreaBizResponse response = new AreaBizResponse();
        List<AreaBizDBModel> areaBizList = null;
        try {
            areaBizList = TableDBUtil.getAllAreaBiz();
            if (areaBizList == null) {
                areaBizList = new ArrayList<>();
            }
            response.areaBizList = areaBizList;
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/updateMinStandard")
    public SocketResponse updateMinStandard(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSONObject.parseObject(params);
            List<AreaBizDBModel> areaBizList = JSONArray.parseArray(request.getString("areaBizList"), AreaBizDBModel.class);
            UserDBModel operator = HostUtil.getUserModelBySession(header.us);
            if (!ListUtil.isEmpty(areaBizList)) {
                for (AreaBizDBModel areaBiz : areaBizList) {
                    if (areaBiz == null) {
                        continue;
                    }
                    areaBiz.fsUpdateTime = DateTimeUtil.getCurrentDateTime();
                    if (operator != null) {
                        areaBiz.fsUpdateUserId = operator.fsUserId;
                        areaBiz.fsUpdateUserName = operator.fsUserName;
                    }
                    areaBiz.replaceNoTrans();
                }
            }
            // 通知站点刷新桌台
            NotifyToClient.refreshTableOrOrders();
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }
}
