package com.mwee.android.pos.businesscenter.module.order.service;

import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.order.OrderCache;

/**
 * 订单业务接口
 * Created by qinwei on 2019/3/13 1:47 PM
 * email: qin.wei@mwee.cn
 */
public interface IOrderService {

    /**
     * 订单绑定会员
     *
     * @param orderCache 订单业务数据
     * @param newMember  会员信息
     * @param userId     操作人员id
     * @return
     */
    SocketResponse<OrderCache> loadBindMember(OrderCache orderCache, NewMemberCardDetailsModel newMember, String userId);

    /**
     * 解绑会员信息
     *
     * @param orderCache 订单信息
     * @param userId     操作人员id
     * @return
     */
    SocketResponse<OrderCache> loadUnBindMember(OrderCache orderCache, String userId);
}
