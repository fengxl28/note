package com.mwee.android.pos.businesscenter.business.kds.algorithm.bean;

import com.mwee.android.base.net.BusinessBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: AMenuBean
 * @Description: kds 算法 api 接口入参菜品信息
 * @author: Cannan
 * @date: 2018/11/12 下午4:22
 */
public class AMenuBean extends BusinessBean {

    /**
     * 餐桌对应的Id编号
     * {@link ATableBean#tableId}
     */
    public String tableId = "";

    /**
     * 每道菜对应的Id编号（一天之中是唯一的）
     * {@link com.mwee.android.pos.db.business.SellOrderItemDBModel#fsseq}
     */
    public String dishId = "";

    /**
     * 菜的编号
     * 同种菜对应一个编号，酸菜土豆丝_少盐和酸辣土豆丝_微辣对应相同的foodId
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiItemCd}
     */
    public String foodId = "";

    /**
     * 菜名
     * 此处菜名包含具体口味，比如：酸菜土豆丝_少盐,酸辣土豆丝_微辣
     */
    public String foodName = "";

    /**
     * 预设优先级
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiUpMenuOrder}
     */
    public int priLevel = 0;

    /**
     * 等起菜标识（1表示等菜状态，即先不着急上菜，0表示正常上菜）
     * {@link com.mwee.android.pos.db.business.SellOrderItemDBModel#fiItemMakeSte}
     */
    public int pause = 0;

    /**
     * 档口
     * {@link com.mwee.android.pos.db.business.DeptDBModel#fsDeptId}
     */
    public List<String> outlet = new ArrayList<>();

    public AMenuBean() {
    }
}
