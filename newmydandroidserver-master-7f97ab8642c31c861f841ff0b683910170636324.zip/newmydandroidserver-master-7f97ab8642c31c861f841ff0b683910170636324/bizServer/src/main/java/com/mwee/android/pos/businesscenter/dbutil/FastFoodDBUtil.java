package com.mwee.android.pos.businesscenter.dbutil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.order.FastFoodOrderBizDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/4/10.
 */

public class FastFoodDBUtil {

    /**
     * 存储订单信息
     *
     * @param cache     OrderCache
     * @param bizStatus 业务状态
     */
    public static void save(final OrderCache cache, int bizStatus) {
        save(cache, bizStatus, 0, false);
    }

    /**
     * 存储订单信息
     *
     * @param cache OrderCache
     */
    public static void save(final OrderCache cache) {
        save(cache, 0, 0, false);
    }

    /**
     * 存储订单信息
     *
     * @param cache OrderCache
     */
    public static void save(int lockedStatus, final OrderCache cache) {
        save(cache, 0, lockedStatus, false);
    }

    /**
     * 存储订单信息--并锁单
     *
     * @param cache OrderCache
     */
    public static void save(final OrderCache cache, int bizStatus, int lockedStatus, boolean newThread) {
        IDBOperate op = new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("opentime", DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT));
                contentValues.put("order_id", cache.orderID);
                contentValues.put("fastfood_biz_status", bizStatus);
                contentValues.put("lockedStatus", lockedStatus);
                contentValues.put("lockedUserID", cache.waiterID);
                contentValues.put("lockedUserName", cache.waiterName);
                contentValues.put("lockedHostId", cache.currentHostID);
                contentValues.put("business_date", cache.businessDate);
                db.replace("fastfood_order_biz", null, contentValues);
                return null;
            }
        };
        if (newThread) {
            DBManager.getInstance().executeInTransaction(op);
        } else {
            DBManager.getInstance().executeInTransactionWithOutThread(op);
        }
    }

    /**
     * 更新快餐订单业务状态
     *
     * @param orderID
     * @param status  0： 新开单；1：已有下单菜；2：已完成
     */
    public static void updateOrderBizStatus(final String orderID, final int status) {
        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                String sqlOrderCache = "update fastfood_order_biz set fastfood_biz_status='" + status + "' where order_id='" + orderID + "'";
                db.execSQL(sqlOrderCache);
                return null;
            }
        });
    }

    /**
     * 查询订单业务信息
     *
     * @param orderId 订单ID
     * @return
     */
    public static FastFoodOrderBizDBModel optFastFoodOrderBizById(String orderId) {
        String sql = "select * from fastfood_order_biz where order_id = '" + orderId + "'";
        FastFoodOrderBizDBModel fastFoodOrderBizDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, FastFoodOrderBizDBModel.class);
        return fastFoodOrderBizDBModel;
    }

    /**
     * 获取所有的锁定的快餐订单ID列表
     * ----未结账的和反结账的快餐单
     *
     * @return List<String>
     */
    public static List<String> getLockedOrdersIDList() {
        List<String> idList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select order_id from fastfood_order_biz where lockedStatus='1' and fastfood_biz_status in ('0','1','3')");
        if (idList == null) {
            idList = new ArrayList<>();
        }
        return idList;
    }


    /**
     * 获取订单来源名称
     *
     * @param fsBillSourceId
     * @return
     */
    public static String getBillSourceName(String fsBillSourceId) {
        String billSourceName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsBillSourceName from tbBillSource where fsBillSourceId = '" + fsBillSourceId + "'");
        if (TextUtils.isEmpty(billSourceName)) {
            return "";
        }
        return billSourceName;
    }

}
