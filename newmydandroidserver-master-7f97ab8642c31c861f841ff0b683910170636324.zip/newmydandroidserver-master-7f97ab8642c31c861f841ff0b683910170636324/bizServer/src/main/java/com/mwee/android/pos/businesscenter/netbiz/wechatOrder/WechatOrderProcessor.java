package com.mwee.android.pos.businesscenter.netbiz.wechatOrder;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.component.datasync.net.GetAllWeChatResponse;
import com.mwee.android.pos.component.datasync.net.GetWechatOrderByNoResponse;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.WechatOrderItemDBModel;
import com.mwee.android.pos.db.business.WechatPayDetailDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * Created by lxx on 17/1/16.
 */

public class WechatOrderProcessor {

    /**
     * 解析获取所有网络订单
     *
     * @param responseData
     * @return -1：解析异常
     * 0：没有新数据
     * 1：解析成功 ---没有未同步订单
     * 2:解析成功,并且还有未同步订单
     */
    public static int parseGetAllWechatData(ResponseData responseData) {
        if (responseData.responseBean != null) {
            try {
                if (responseData.responseBean instanceof GetAllWeChatResponse) {
                    GetAllWeChatResponse getDataResponse = (GetAllWeChatResponse) responseData.responseBean;
                    List<WechatOrderModel> wechatOrderModelList = getDataResponse.data;
                    if (wechatOrderModelList != null && wechatOrderModelList.size() > 0) {

                        String lastNo = IOCache.getCacheStr(META.ONLINE_ORDER_WECHAT_LAST_NO, "0");

                        for (WechatOrderModel wechatOrderModel : wechatOrderModelList) {
                            parseWechatOrder(wechatOrderModel);
                            if (compare(lastNo, wechatOrderModel.fssettlement)) {
                                lastNo = wechatOrderModel.fssettlement;
                            }
                        }

                        //更新批量拉到的最后一个订单号
                        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "获取到的最后一个微信外卖订单号:" + lastNo, "");
                        IOCache.writeCache(META.ONLINE_ORDER_WECHAT_LAST_NO, lastNo);

                        if (getDataResponse.tag == 1) {
                            return 2;
                        } else {
                            return 1;
                        }
                    }
                    return 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return -1;
            }
        }
        return -1;
    }

    /**
     * 解析单条网络订单
     *
     * @param responseData
     * @return -1：解析异常
     * -2:数据已存在
     * 1：解析成功
     */
    public static int parseWechatOrderData(ResponseData responseData) {
        if (responseData.responseBean != null) {
            try {
                if (responseData.responseBean instanceof GetWechatOrderByNoResponse) {
                    GetWechatOrderByNoResponse getDataResponse = (GetWechatOrderByNoResponse) responseData.responseBean;
                    WechatOrderModel wechatOrderModel = getDataResponse.data;
                    if (wechatOrderModel != null) {
                        return parseWechatOrder(wechatOrderModel);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "根据订单号拉取微信外卖异常", e.getMessage());
                return -1;
            }
        }
        return -1;
    }

    /**
     * 订单入库
     *
     * @param wechatOrderModel
     * @return
     */
    private static int parseWechatOrder(WechatOrderModel wechatOrderModel) {
        if (wechatOrderModel == null) {
            return -1;
        }
        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖订单开始入库 fsorderno = " + wechatOrderModel.fsorderno, JSON.toJSONString(wechatOrderModel));
        try {
            wechatOrderModel.replaceNoTrans();

            if (!ListUtil.isEmpty(wechatOrderModel.orderitem)) {
                for (WechatOrderItemDBModel wechatOrderItemDBModel : wechatOrderModel.orderitem) {
                    wechatOrderItemDBModel.replace();
                }
            } else {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖订单没拿到菜品明细 fsorderno = " + wechatOrderModel.fsorderno, "");
            }

            if (!ListUtil.isEmpty(wechatOrderModel.paydetail)) {
                for (WechatPayDetailDBModel wechatPayDetailDBModel : wechatOrderModel.paydetail) {
                    wechatPayDetailDBModel.replace();
                }
            } else {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖订单没拿到支付明细 fsorderno = " + wechatOrderModel.fsorderno, "");
            }

            RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖订单成功入库 fsorderno = " + wechatOrderModel.fsorderno, "");
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖订单入库异常-->err:" + e.getMessage(), JSON.toJSONString(wechatOrderModel));
            return -1;
        }
        return 1;
    }

    /**
     * 微信点餐--接单
     *
     * @param host
     * @param wechatOrderModel
     * @param iResult
     */
    /*
    public static void takeWechatOrder(final Host host, final WechatOrderModel wechatOrderModel, final IResult iResult) {
        if (wechatOrderModel == null || wechatOrderModel.fistatus == 1
                || wechatOrderModel.fistatus == 3
                || wechatOrderModel.fistatus == 4
                ) {
            return;
        }
        final Progress progress = ProgressManager.showProgress(host, "接单...");
        String key = BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                WechatOrderApi.updateNetworkOrderStatus(wechatOrderModel.fsorderno, 1, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        *//*if (TextUtils.isEmpty(wechatOrderModel.localOrderId)) {
                            OrderManager.getInstace().sendGetOrderID(new SocketCallback<GetNumOrderIDResponse>() {
                                @Override
                                public void callback(SocketResponse<GetNumOrderIDResponse> socketResponse) {
                                    LogBiz.log("去业务中心获取订单号结果" + JSON.toJSONString(socketResponse));
                                    if (socketResponse.code == SocketResultCode.SUCCESS) {
                                        long num = StringUtil.toLong(AppCache.getInstance().businessDate + "0000", 0);
                                        wechatOrderModel.localOrderId = socketResponse.data.id + "";
                                        updateLocalDB(wechatOrderModel, 1);


                                        NetWorkPrintUtil.printWechatKDSReceipt(wechatOrderModel, false);
                                        NetWorkPrintUtil.printWechatReceipt(wechatOrderModel);
                                        DriverBus.call("onlineOrder/updateWechatOrder", wechatOrderModel);
                                    } else {
                                        ToastUtil.showToast("获取订单号失败:" + socketResponse.message);
                                        if (iResult != null) {
                                            iResult.callBack(false, "获取订单号失败:" + socketResponse.message);
                                        }
                                    }
                                }
                            });
                        } else {*//*

                        updateLocalDB(wechatOrderModel, 1);
                        NetWorkPrintUtil.printWechatKDSReceipt(wechatOrderModel, false);
                        NetWorkPrintUtil.printWechatReceipt(wechatOrderModel);
                        DriverBus.call("onlineOrder/updateWechatOrder", wechatOrderModel);
                       *//* }*//*
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        ToastUtil.showToast("接单订单失败:" + responseData.resultMessage);
                        if (iResult != null) {
                            iResult.callBack(false, responseData.resultMessage);
                        }
                        return false;
                    }
                });
                return null;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                if (progress != null) {
                    progress.dismiss();
                }
            }
        });

        progress.setServiceKey(key);
    }
*/
    /*
    public static void upOrder(final Host host, final WechatOrderModel wechatOrderModel, final IResult iResult) {
        if (wechatOrderModel == null || wechatOrderModel.fistatus == 1
                || wechatOrderModel.fistatus == 3
                || wechatOrderModel.fistatus == 4
                ) {
            return;
        }
        final Progress progress = ProgressManager.showProgress(host, "接单...");
        String key = BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
               *//* if (TextUtils.isEmpty(wechatOrderModel.localOrderId)) {
                    OrderManager.getInstace().sendGetOrderID(new SocketCallback<GetNumOrderIDResponse>() {
                        @Override
                        public void callback(SocketResponse<GetNumOrderIDResponse> socketResponse) {
                            LogBiz.log("去业务中心获取订单号结果" + JSON.toJSONString(socketResponse));
                            if (socketResponse.code == SocketResultCode.SUCCESS) {
                                long num = StringUtil.toLong(AppCache.getInstance().businessDate + "0000", 0);
                                wechatOrderModel.localOrderId = socketResponse.data.id + "";
                                updateLocalDB(wechatOrderModel, 1);
                                NetWorkPrintUtil.printWechatKDSReceipt(wechatOrderModel, false);
                                NetWorkPrintUtil.printWechatReceipt(wechatOrderModel);
                                DriverBus.call("onlineOrder/updateWechatOrder", wechatOrderModel);
                            } else {
                                ToastUtil.showToast("获取订单号失败:" + socketResponse.message);
                                if (iResult != null) {
                                    iResult.callBack(false, "获取订单号失败:" + socketResponse.message);
                                }
                            }
                        }
                    });
                } else {*//*
                updateLocalDB(wechatOrderModel, 1);
                NetWorkPrintUtil.printWechatKDSReceipt(wechatOrderModel, false);
                NetWorkPrintUtil.printWechatReceipt(wechatOrderModel);
                DriverBus.call("onlineOrder/updateWechatOrder", wechatOrderModel);
             *//*   }*//*
                return null;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                if (progress != null) {
                    progress.dismiss();
                }
            }
        });

        progress.setServiceKey(key);
    }
*/

    /**
     * 微信点餐--取消订单
     */
    /*
    public static void cancelOrder(final Host host, final WechatOrderModel wechatOrderModel, final IResult iResult) {
        if (wechatOrderModel == null || wechatOrderModel.fistatus == 3
                || wechatOrderModel.fistatus == 4
                || wechatOrderModel.fistatus == 5
                || wechatOrderModel.fistatus == 6
                ) {
            return;
        }
        final Progress progress = ProgressManager.showProgress(host, "取消订单...");
        String key = BusinessExecutor.executeAsyncExcute(new ASyncExecute<Boolean>() {
            @Override
            public Boolean execute() {
                WechatOrderApi.updateNetworkOrderStatus(wechatOrderModel.fsorderno, 4, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        updateDBAndUI(wechatOrderModel, 4);
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        ToastUtil.showToast("取消订单失败:" + responseData.resultMessage);
                        if (iResult != null) {
                            iResult.callBack(false, responseData.resultMessage);
                        }
                        return false;
                    }
                });
                return null;
            }
        }, new SyncCallback<Boolean>() {
            @Override
            public void callback(Boolean aBoolean) {
                if (progress != null) {
                    progress.dismiss();
                }
            }
        });

        progress.setServiceKey(key);
    }
*/
    private static void updateLocalDB(WechatOrderModel wechatOrderModel, int fiStatus) {
        if (wechatOrderModel != null) {
            wechatOrderModel.fistatus = fiStatus;
            wechatOrderModel.replace();
        }
    }

    public static void updateDBAndUI(String orderNo, int fiStatus) {
        WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(orderNo);
        updateDBAndUI(wechatOrderModel, fiStatus);
    }

    public static void updateDBAndUI(WechatOrderModel wechatOrderModels, int fiStatus) {
        if (wechatOrderModels == null) {
            return;
        }
        boolean printVoid = false;
        if (wechatOrderModels.fistatus == NetworkConstans.WECHAT_STATUS_GET) {
            printVoid = true;
        }
        updateLocalDB(wechatOrderModels, fiStatus);
        if (printVoid) {
//            NetWorkPrintUtil.printWechatKDSReceipt(wechatOrderModels, true);
        }
        DriverBus.call("onlineOrder/updateWechatOrder", wechatOrderModels);
    }


    /**
     * 比较大小
     *
     * @param lastNo
     * @param newNo
     * @return true : newNo > lastNo
     */
    public static boolean compare(String lastNo, String newNo) {
        long lastN = StringUtil.toLong(lastNo, 0l);
        long newN = StringUtil.toLong(newNo, 0l);
        if (lastN < newN) {
            return true;
        }
        return false;
    }

}
