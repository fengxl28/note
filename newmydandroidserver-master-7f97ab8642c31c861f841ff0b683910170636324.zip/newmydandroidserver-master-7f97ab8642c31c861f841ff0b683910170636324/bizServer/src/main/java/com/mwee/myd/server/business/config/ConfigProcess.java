package com.mwee.myd.server.business.config;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.configuration.constant.ConfigurationBizType;
import com.mwee.android.configuration.core.ConfigurationProcess;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.List;

/**
 * @ClassName: ConfigProcess
 * @Description:
 * @author: SugarT
 * @date: 2017/8/24 上午10:49
 */
public class ConfigProcess {

    private volatile static ConfigProcess instance;

    private ConfigurationProcess process;

    public static ConfigProcess getInstance() {
        if (instance == null) {
            synchronized (ConfigProcess.class) {
                if (instance == null)
                    instance = new ConfigProcess();
            }
        }
        return instance;
    }

    public synchronized void checkInit() {
        if (process == null) {
            process = new ConfigurationProcess.Builder()
                    .setPresenter(new ConfigurationPresenter())
                    .setProduct(BaseConfig.isProduct())
                    .setBizType(ConfigurationBizType.MYD_DINNER)
                    .setShopId(ClientMetaUtil.getSettingsValueByKey(META.SHOPID))
                    .setDeviceId(ServerHardwareUtil.getHardWareSymbol())
                    .build();
        }
    }

    public void refresh() {
        checkInit();
        process.refresh(ClientMetaUtil.getSettingsValueByKey(META.SHOPID));
    }

    /**
     * 校验缓存中，是否有新版本
     *
     * @return
     */
    public boolean checkCache() {
        checkInit();
        return process.start(GlobalCache.getContext());
    }

    /**
     * 获取所有配置文件数据
     *
     * @return
     */
    public String getAllData(String fileName) {
        String path = ConfigConstant.getConfigDirPath(GlobalCache.getContext()) + fileName;
        if (TextUtils.isEmpty(path)) {
            return "";
        }
        return FileUtil.readFile(path);
    }

    /**
     * 获取默认配置文件中相关信息
     *
     * @param clz
     * @param <T>
     * @return
     */
    public <T> List<T> getConfigList(Class<T> clz) {
        String key = clz.getSimpleName();
        ConfigField anno = clz.getAnnotation(ConfigField.class);
        if (anno != null) {
            key = anno.name();
        }
        return getConfigList(ConfigConstant.ConfigFileName, key, clz);
    }

    /**
     * 获取默认配置文件中相关信息
     *
     * @param key
     * @param clz
     * @param <T>
     * @return
     */
    public <T> List<T> getConfigList(String key, Class<T> clz) {
        if (TextUtils.isEmpty(key)) {
            return getConfigList(clz);
        }
        return getConfigList(ConfigConstant.ConfigFileName, key, clz);
    }

    /**
     * 获取配置文件中相关信息
     *
     * @param clz
     * @param key
     * @param <T>
     * @return
     */
    public <T> List<T> getConfigList(String fileName, String key, Class<T> clz) {
        try {
            String data = getAllData(fileName);
            if (TextUtils.isEmpty(data)) {
                return null;
            }

            String element = JsonUtil.getValueByName(JSONObject.parseObject(data), key, String.class);
            if (TextUtils.isEmpty(element)) {
                return null;
            }
            return JSON.parseArray(element, clz);
        } catch (Exception ex) {
            // do nothing
        }
        return null;

    }
}
