package com.mwee.android.pos.businesscenter.dbutil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.CreditaccountDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/9.
 */
public class CreditaccountDBUtil {

//    public static CreditaccountDBModel queryById(String fsCreditAccountId) {
//        String sql = "select * from tbcreditaccount where fsCreditAccountId='" + fsCreditAccountId + "'";
//        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, CreditaccountDBModel.class);
//    }

    /**
     * 更新挂账账户信用额度和可用额度
     *
     * @param fsCreditAccountId
     * @param creditAmt
     * @param fdDebtAmt
     */
//    public static void updateCreditaccount(String fsCreditAccountId, BigDecimal creditAmt, BigDecimal fdDebtAmt) {
//        CreditaccountDBModel account = queryById(fsCreditAccountId);
//        //更新信用额度
//        account.fdCreditAmt = creditAmt;
//        if (fdDebtAmt.compareTo(BigDecimal.ZERO) < 0) {
//            fdDebtAmt = BigDecimal.ZERO;
//        }
//        //更新可用额度
//        account.fdDebtAmt = fdDebtAmt;
//        account.replaceNoTrans();
//    }

//    public static void resetCanUseAmt() {
//        String sql = "update tbcreditaccount set fdDebtAmt=0 where fiStatus='1' and fdDebtAmt<0";
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
//    }
}
