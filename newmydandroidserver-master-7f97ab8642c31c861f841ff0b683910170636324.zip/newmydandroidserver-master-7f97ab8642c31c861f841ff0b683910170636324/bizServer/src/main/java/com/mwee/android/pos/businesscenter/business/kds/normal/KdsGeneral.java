package com.mwee.android.pos.businesscenter.business.kds.normal;

import android.support.v4.util.ArrayMap;
import android.util.Pair;

import com.mwee.android.kds.utils.ListUtils;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.businesscenter.business.kds.IKds;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @ClassName: KdsGeneral
 * @Description: kds - 不使用智能算法
 * @author: Cannan
 * @date: 2018/11/12 下午5:08
 */
public class KdsGeneral implements IKds {

    private volatile static KdsGeneral instance;

    private KdsGeneral() {
    }

    public static KdsGeneral getInstance() {
        if (instance == null) {
            synchronized (KdsGeneral.class) {
                if (instance == null) {
                    instance = new KdsGeneral();
                }
            }
        }
        return instance;
    }

    @Override
    public void init() {

    }

    //外卖不使用KDS算法，干脆就不进KDS
    @Override
    public void wmOrder(TempAppOrder tempAppOrder, List<PrintItemDataBean> sellOrderItemDBModels, int beforeTime) {

    }

    /**
     * 站点不使用智能算法，则直接打印制作单
     *
     * @param orderCache OrderCache | 订单相关信息
     * @param data       ArrayMap | key: 打印部门id, value: 部门相关菜品信息
     * @param hostID     String | 站点id
     * @param user
     */
    @Override
    public void order(OrderCache orderCache, ArrayMap<String, Set<SellOrderItemDBModel>> data, ArrayMap<String, List<String>> deptMapping, String hostID, UserDBModel user) {
        for (String deptId : data.keySet()) {
            Set<SellOrderItemDBModel> menuList = data.get(deptId);
            if (ListUtils.isEmpty(menuList)) {
                continue;
            }
            List<SellOrderItemDBModel> menuByDept = new ArrayList<>(menuList);
            List<String> seqList = new ArrayList<>();
            for (SellOrderItemDBModel model : menuByDept) {
                seqList.add(model.fsseq);
            }
            PrintOrderUtil.printKdsGeneralPassTo(orderCache, hostID, seqList);
            PrintOrderUtil.kdsGMakeOrder(orderCache, hostID, deptId, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", seqList);
        }
    }

    @Override
    public void weigh(OrderCache order, String fsSeq, String hostId, UserDBModel user) {
    }

    @Override
    public void serving(List<String> optSeqList, String hostID, UserDBModel user) {

    }

    @Override
    public void retreated(List<String> optSeqList) {

    }

    @Override
    public void hurry(String orderID, List<String> optSeqList) {

    }

    @Override
    public void delimit(String deptID, String menu, String foodId, BigDecimal num, boolean isUnAssign, String hostID, UserDBModel user, String barCode) {

    }

    @Override
    public void unDelimit(String deptId, String hostID, UserDBModel user) {

    }

    @Override
    public void menuTransfer(List<String> optMenuSeq, OrderCache target) {

    }

    @Override
    public void tableTransfer(String origin, String target) {

    }

    @Override
    public void load(String deptID, int num) {

    }

    @Override
    public boolean changeDishIngredient(List<String> dishIds, String foodName) {
        return false;
    }

    @Override
    public Pair<Integer, List<KdsMenuViewBean>> query(String depID, int state, int pageSize, int pageNum) {
        return null;
    }

    @Override
    public void payFinish(String orderId) {

    }

    @Override
    public void refresh() {

    }
}
