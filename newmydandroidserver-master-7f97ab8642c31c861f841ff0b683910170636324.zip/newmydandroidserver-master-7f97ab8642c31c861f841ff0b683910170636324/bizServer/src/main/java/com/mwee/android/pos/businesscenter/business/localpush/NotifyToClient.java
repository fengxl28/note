package com.mwee.android.pos.businesscenter.business.localpush;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.alp.Ack;
import com.mwee.android.alp.PushServer;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.alp.ServerAction;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * 推送到客户端的工厂类
 * Created by virgil on 2016/12/16.
 */

public class NotifyToClient {

    /**
     * 推送所有客户端刷新桌台状态-或快餐的订单状态
     */
    public static void refreshTableOrOrders() {
        LogUtil.logOnlineDebug("table--finish", "刷新桌台、快餐列表状态 业务中心开始广播");
        broadcast("login/refreshTablesFromBiz");
    }

    /**
     * 推送所有客户端 服务铃变动
     * tableNo:桌台ID
     * actCode: 0:呼叫服务铃；1：取消服务铃
     * time:时间戳 yyyy-MM-dd HH:mm:ss
     */
    public static void refreshRapidbell(String tableNo, String actCode, String timeTag) {
        broadcast("login/rapidbell", tableNo, actCode, timeTag);
    }

    /**
     * 推送所有客户端刷新消息列表
     */
    public static void refrehMessageData() {
        broadcast("login/callRefrehMessageData");
    }

    /**
     * 推送到业务中心站点，提示有新的预定订单
     */
    public static void newBookOrderTips(String hostID, String tipMsg) {
        sendTo(hostID, "login/newBookOrderTips", tipMsg);
    }

    /**
     * 推送所有客户端刷新点菜消息列表
     * <p>
     * msgType  //消息来源(1:秒付; 2: 美小二; 3:预定)
     */
    public static void addOrderMessage(int msgType, String areaId) {
        // 长链接消息推送不推荐使用空字符[""]作为参数，解析消息时使用 String.split 方法，可能报错
        // 使用空字符串消息[#@%2#@%5#@%]解析出来 2 个参数[2, 5], 使用空格消息[#@%2#@%5#@% ]解析出来 3 个参数[2, 5, " "]
        addOrderMessage(msgType, areaId, " ");
    }

    public static void addOrderMessage(int msgType, String areaId, String tableName) {
        broadcast("login/newOrderMessage", "" + msgType, areaId, tableName);
    }

    /**
     * 推送所有客户端刷新快餐消息列表
     * <p>
     * msgType  //消息来源(1:秒付; 2: 美小二; 3:预定， 4：微信快餐)
     */
    public static void addFastFoodMessage(int msgType) {
        broadcast("login/addFastFoodMessage", "" + msgType);
    }

    /**
     * 推送所有客户端刷新支付消息列表
     * msgType  //消息来源(1:秒付; 2: 美小二)
     */
    public static void addPayMessage(int msgType, String areaId) {
        // 这里不能传""，否则会广播失败
        addPayMessage(msgType, areaId, " ");
    }

    public static void addPayMessage(int msgType, String areaId, String tableName) {
        broadcast("login/newPayMessage", "" + msgType, areaId, tableName);
    }

    /**
     * 推送所有客户端刷新异常订单
     */
    public static void addAbnormalOrderMessage(int msgType, String billNo) {
        broadcast("login/addAbnormalOrderMessage", String.valueOf(msgType), billNo);
    }

    /**
     * 推送所有客户端刷新异常订单
     */
    public static void optAbnormalOrderInfo(String msgId, String billNo) {
        if (TextUtils.isEmpty(billNo)) {
            billNo = "-1";
        }
        broadcast("login/optAbnormalOrderInfo", msgId, billNo);
    }

    /**
     * 登录中控消息通知
     *
     * @param msgType
     */
    public static void addSystemLoginPDMessage(int msgType, String sessionId) {
        if (TextUtils.isEmpty(sessionId)) {
            sessionId = "-1";
        }
        broadcast("login/newSystemMessage", "" + msgType, sessionId);
    }

    /**
     * 通知原登录设备，该服务员已在其他 '设备/站点' 登录了
     *
     * @param target    原HOSTID或者原device
     * @param userName  服务员名称
     * @param newHostId 新登录的设备、站点
     */
    public static void userRelogin(String target, String userName, String newHostId) {
        if (TextUtils.isEmpty(target)) {
            return;
        }
        sendTo(target, "login/userRelogin", userName, newHostId);
    }

    /**
     * 有新的秒付拉单确认消息 发送到业务中心站点
     */
    public static void addRapidPayConfirm(String hostID, String msgId) {
        sendTo(hostID, "login/addRapidPayConfirm", msgId);
    }

    /**
     * 推送所有客户端刷新消息未处理数量
     */
    public static void refreshUndealMessage() {
        broadcast("login/refreshUndealMessage");
    }

    /**
     * 外卖单未映射菜品提示
     */
    public static void thirdOrderMappingTip(String count) {
        broadcast("login/thirdOrderMappingTip", count);
    }

    /**
     * 推送所有客户端刷新网络订单消息列表
     *
     * @param appOrderId 订单Id
     */
    public static void updateTempApporder(String appOrderId) {
        broadcast("login/updateTempApporder", appOrderId);
    }

    /**
     * 自动配送失败
     *
     * @param appOrderId 订单Id
     */
    public static void autoDeliveryFail(String appOrderId, String reason) {
        broadcast("login/autoDeliveryFail", appOrderId, reason);
    }

    public static void addNewTempAppOrder(String appOrderId, int bizType, String source, String date) {
        broadcast("login/addNewTempAppOrder", appOrderId, bizType + "", source, date);
    }

    /**
     * 收到新点的  口碑预点单
     *
     * @param appOrderId
     */
    public static void addNewKBPreOrder(String appOrderId) {
        broadcast("login/addNewKBPreOrder", appOrderId);
    }



    /**
     * 收到新点的  口碑后付款订单
     *
     * @param tableName 桌台名称
     */
    public static void addNewKBFutureOrder(String tableName) {
        broadcast("login/addNewKBFutureOrder",tableName);
    }



    /**
     * 收到新点的不能匹配的口碑预点单  口碑预点单但是本地菜品匹配不上 需要手动接单
     *
     * @param appOrderId
     * @param pay_before ture/表示先付款订单  false后付款订单
     */
    public static void KBOrderException(String appOrderId, boolean pay_before) {
        broadcast("login/KBOrderException", appOrderId, pay_before ? KBConstants.PAY_BEFORE : KBConstants.PAY_FUTURE);
    }


    /**
     * 收到  口碑用户发起退款
     *
     * @param appOrderId
     */
    public static void kbOrderApplyRefund(String appOrderId) {
        broadcast("login/kbOrderApplyRefund", appOrderId);
    }


    /**
     * 口碑堂食预点单退款0元结账 需要清除桌台信息
     *
     * @param
     */
    public static void clearDishCache() {
        broadcast("login/clearDishCache");
    }

    /**
     * 刷新口碑订单数据 美易点主辅机需要使用
     */
    public static void refreshKBOrderItem(KBPreOrderUpdateResponse data) {
        broadcast("login/refreshKBOrderItem", JSON.toJSONString(data));
    }


    /**
     * 刷新口碑后付款订单数据 美易点主辅机需要使用
     */
    public static void refreshKBOrderItem(String id, String status) {
        broadcast("login/refreshKBFutureOrderItem", id, status);
    }


    /**
     * 收到  商家同意退款[REFUNDED]   口碑退款[REFUND]  两个行为 需要刷新口碑订单列表
     *
     * @param appOrderId
     */
    public static void kbRefreshOrder(String appOrderId) {
        broadcast("login/kbRefreshOrder", appOrderId);
    }




    /**
     * 推送所有客户端刷新微信外卖列表
     *
     * @param fsorderno 订单Id
     */
    public static void updateWechatOrder(String fsorderno) {
        broadcast("login/updateWechatOrder", fsorderno);
    }

    /**
     * 推送所有客户端刷新微信外卖列表
     *
     * @param outerOrderId 订单Id
     */
    public static void updateWechatFastFood(String outerOrderId) {
        broadcast("login/updateWechatFastFood", outerOrderId);
    }

    /**
     * 新增微信外卖
     *
     * @param fsorderno
     * @param date
     */
    public static void addNewWechatOrder(String fsorderno, String date) {
        broadcast("login/addNewWechatOrder", fsorderno, date);
    }

    /**
     * 推送所有客户端刷新打印机配置
     */
    public static void refreshAllPrinterStatus() {
        broadcast("login/refreshAllPrinterStatus");
    }

    /**
     * 推送所有客户端：刷新估清
     */
    public static void refreshSellOut() {
        broadcast("login/refresh_menu_unit");
    }

    /**
     * 骑手取消配送
     */
    public static void orderChangeWithinDeliveryCancel() {
        broadcast("login/orderChangeWithinDeliveryCancel");
    }

    /**
     * 订单数据发生了变化
     */
    public static void orderChange(String orderID) {
        broadcast("login/orderChange", orderID);
    }

    /**
     * 订单数据发生了变化--美小二
     */
    public static void orderChangeForSmart(String orderID, String tableID) {
        broadcast("login/orderChangeForSmart", orderID, tableID);
    }

    /**
     * 通知所有站点副站点打烊
     */
    public static void callFinish() {
        broadcast("login/closeDoor");
    }

    /**
     * 通知所有站点站点更新交班列表
     */
    public static void refreshShift() {
        broadcast("login/refresh_shift");
    }

    /**
     * 推送所有客户端刷新桌台锁定
     */
    public static void refreshTableLock(String target) {
        List<String> idList = TableBusinessUtil.getLockedTableIDList();
        String info = "";
        if (!ListUtil.isEmpty(idList)) {
            info = TextUtils.join(",", idList);
            info = "[" + info + "]";
        }
        if (TextUtils.isEmpty(info)) {
            info = "[]";
        }
        sendTo(target, "login/dinnerTablesRefreshLockState", info);
    }

    /**
     * 推送所有客户端刷新快餐订单锁定
     */
    public static void refreshFastFoodOrderLock(String target) {
        List<String> idList = FastFoodDBUtil.getLockedOrdersIDList();
        String info = "";
        if (!ListUtil.isEmpty(idList)) {
            info = TextUtils.join(",", idList);
            info = "[" + info + "]";
        }

        if (TextUtils.isEmpty(info)) {
            info = "[]";
        }
        sendTo(target, "login/fastfoodOrdersRefreshLockState", info);
    }

    public static void refreshTableLock() {
        refreshTableLock(null);
    }

    /**
     * 通知所有站点刷新订单锁定状态
     */
    public static void refreshFastFoodOrdersLock() {
        refreshFastFoodOrderLock(null);
    }

    /**
     * 通知正餐打烊
     *
     * @param | 新的营业日期
     */
    public static void callDinnerFinish() {
        broadcast("login/closeDoor");
    }

    /**
     * 通知指定站点打印小票
     *
     * @param hostID  String | 站点ID
     * @param printNo String | 打印任务编号
     */
    public static void printReceipt(String printNo, String hostID) {
        sendTo(hostID, "login/printReceipt", printNo);
    }

    public static void printReceipt(String hostID, PrintTaskDBModel task) {
        sendTo(hostID, "login/printReceipt", JSON.toJSONString(task));
    }

    public static void rePrintReceipt(String hostID, PrintTaskDBModel task) {
        sendTo(hostID, "login/rePrintReceipt", JSON.toJSONString(task));
    }

    /**
     * 通知主站点中控登录失败
     *
     * @param error String
     */
    public static void loingPDError(String error) {
        sendTo(DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), "login/loginPDError", error);
    }

    /**
     * 通知站点未匹配到的菜
     *
     * @param tips hostId
     * @param tips String
     */
    public static void unMatchMenuItems(String hostId, String tips) {
        if (TextUtils.isEmpty(hostId)) {
            hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        }
        sendTo(hostId, "login/unMatchMenuItems", tips);
    }

    /**
     * 通知所有站点上送日志
     */
    public static void uploadLog() {
        broadcast("login/uploadLog");
    }


    /**
     * 通知副站点更新餐厅设置
     */
    public static void refreshSetting(String type, String value) {
        broadcast("login/refreshClientSetting", type, value);
    }

    /**
     * 通知副站点批量更新餐厅设置
     */
    public static void refreshBatchSetting(List<DataModel> modelList) {
        broadcast("login/refreshBatchSetting", JSON.toJSONString(modelList));
    }

    /**
     * 外卖菜品映射关系更新
     */
    public static void updateMappingRelation() {
        broadcast("login/updateMappingRelation");
    }

    public static void refreshDBConfig(String type, String value) {
        broadcast("login/refreshClientDBConfig", type, value);
    }

    /**
     * 收到秒点订单
     *
     * @param tableID String | 桌台ID
     */
    public static void refreshReceiveRapidOrder(String tableID) {
        broadcast("login/rapidorderchange", tableID);
    }


    /**
     * 收到秒点订单并已被拒绝
     *
     * @param fsmareaid String | 餐区ID
     * @param tableName String | 桌台名称
     */
    public static void receiveRapidOrderAndRefresh(String fsmareaid, String tableName) {
        broadcast("login/receiveRapidOrderAndRefresh", fsmareaid, tableName);
    }

    /**
     * 收到秒点订单
     *
     * @param tableID   String 桌台ID
     * @param tableName 桌台名称
     */
    public static void refreshkborderchange(String tableID, String tableName) {
        broadcast("login/kborderchange", tableID, tableName);
    }

    /**
     * 收到秒点订单
     *
     * @param tableID   String 桌台ID
     * @param tableName 桌台名称
     */
    public static void kbFutureOrderPay(String tableID, String tableName) {
        broadcast("login/kbFutureOrderPay", tableID, tableName);
    }

    /**
     * 收到共享餐厅退款信息
     *
     * @param tableID String | 桌台ID
     */
    public static void refreshShareShopOrderChange(String tableID) {
        broadcast("login/shareShopOrderChange", tableID);
    }

    /**
     * 广播消息
     *
     * @param uri uri   String
     */
    public static void broadcast(String uri) {
        PushServer.getInstance().pushMsg(uri);
        if (TextUtils.equals("login/refreshTablesFromBiz", uri)){
            LogUtil.logOnlineDebug("table--finish", "刷新桌台、快餐列表状态 业务中心已广播完毕");
        }
    }

    /**
     * 广播消息
     *
     * @param uri   String
     * @param param String... | 各种参数
     */
    public static void broadcast(String uri, String... param) {
        PushServer.getInstance().pushMsg(uri + ServerAction.SYMBOL_SPLIT + buildParam(param).toString());
    }

    /**
     * 发送消息到指定的目标
     *
     * @param target String | 接收者，目前使用站点ID
     * @param uri    uri
     * @param param  String... | 各种参数
     */
    public static void sendTo(String target, String uri, String... param) {
        if (TextUtils.isEmpty(target)) {
            broadcast(uri, param);
        } else {
            PushServer.getInstance().pushMsgTo(target, uri + ServerAction.SYMBOL_SPLIT + buildParam(param).toString());
        }
    }

    public static void sendTo(Ack ack, String target, String uniq, String uri, String... param) {
        if (TextUtils.isEmpty(target)) {
            broadcast(uri, param);
        } else {
            PushServer.getInstance().pushMsgNeedAck(target, uniq, uri + ServerAction.SYMBOL_SPLIT + buildParam(param)
                    .toString(), ack);
        }
    }

    public static StringBuilder buildParam(String... param) {
        StringBuilder sb = new StringBuilder();
        if (param != null && param.length > 0) {
            for (int i = 0; i < param.length; i++) {
                String temp = param[i];
                sb.append(temp);
                if (i != (param.length - 1)) {
                    sb.append(ServerAction.SYMBOL_SPLIT);
                }
            }
        }
        return sb;
    }

    public static void shotOffByHostId(String shotOffHostId) {
        String uri = "login/be_forced_exist";
        sendTo(shotOffHostId, uri);
    }

    /**
     * 通知业务中心站点，有数据更新了
     */
    public static void cloudShopInfoChange() {
        NotifyToClient.sendTo(DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID),
                "login/cloudShopInfoChange");
    }

    public static void syncBillStatusComplete(String errMsg) {
        broadcast("login/synComplete", errMsg);
    }

    public static void meituanPhoneDowngrade(String orderID, String realPhoneNumber) {
        broadcast("login/meituanPhoneDowngrade", orderID, realPhoneNumber);
    }

    public static void hideSyncUpdate() {
        sendTo(DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), "login/hideSyncUpdate");
    }

    public static void addTakeOutMenuNoMapperMessage() {
        broadcast("login/addTakeOutMenuNoMapperMessage", "1");
    }

    /**
     * 收到菜品自动匹配优化推送
     */
    public static void mappingMenuAuto(String msgBody) {
        broadcast("login/mappingMenuAuto", msgBody);
    }

    public static void clearConn() {
        PushServer.getInstance().removeFistConn();
    }

    /**
     * 通知排队客户端刷新桌台状态
     *
     * @param tableId
     */
    public static void refreshTableBizQueue(String tableId) {
        JSONObject result = buildQueueBiz(tableId);
        broadcast("queue/tableBizChanged", tableId, result.toJSONString());
    }

//    /**
//     * 已下厨状态更新，刷新UI
//     *
//     * @param kbPreOrderCache
//     * @return
//     */
////    public static void refreshCooking(KBPreOrderCache kbPreOrderCache) {
////        String cookingJson = JSONObject.toJSONString(kbPreOrderCache);
////        broadcast("kbOrderFragment/cooking", cookingJson);
////    }

    @NonNull
    private static JSONObject buildQueueBiz(String tableId) {
        JSONArray resultArr = new JSONArray();
        JSONObject ext_info = new JSONObject();
        TableBizModel tableBizModel = TableDBUtil.getTableBizModelById(tableId);
        if (tableBizModel != null) {
            switch (tableBizModel.fsmtablesteid) {
                case TableConstans.TABLE_STATUS_FREE:
                    ext_info.put("status", 100);
                    break;
                case TableConstans.TABLE_STATUS_OPEN:
                case TableConstans.TABLE_STATUS_BUSY:
                    if (TextUtils.isEmpty(tableBizModel.fssellno)) {
                        ext_info.put("status", 100);
                    } else {
                        String sql = "SELECT count(*) FROM tbSellReceive WHERE fssellno = '" + tableBizModel.fssellno + "' AND fiStatus <> '13' AND isCouponMoney <> '1'";
                        String hasPayInfo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                        if (StringUtil.toInt(hasPayInfo, 0) > 0) {
                            ext_info.put("status", 300);
                        } else if (tableBizModel.fioccupyflag == TableStatusBean.PRINT_COMPLETE) {
                            ext_info.put("status", 301);
                        } else {
                            ext_info.put("status", 200);
                        }

                        String sqlNumber = "SELECT value FROM datacache WHERE type = '" + IOCache.TYPE_QUEUE_OPEN_TABLE + "' AND key = '" + tableBizModel.fssellno + "'";
                        String number = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlNumber);
                        if (!TextUtils.isEmpty(number)) {
                            ext_info.put("number", number);
                        }

                        ext_info.put("create_time", tableBizModel.fsopenhstime);
                    }
                    break;
                case TableConstans.TABLE_STATUS_RESERVATION:
                    ext_info.put("status", 400);
                    break;
                case TableConstans.TABLE_STATUS_INVALID:
                    ext_info.put("status", 402);
                    break;
                default:
                    ext_info.put("status", 100);
                    break;
            }
        } else {
            ext_info.put("status", 100);
        }

        resultArr.add(ext_info);
        JSONObject result = new JSONObject();
        result.put("ext_info", resultArr);
        return result;
    }

    /**
     * 通知排队桌台配置变更
     */
    public static void refreshTableQueue() {
        broadcast("queue/tableConfigChanged");
    }

    /**
     * 通知排队指定桌台配置变更
     *
     * @param tableID
     * @param status
     */
    public static void refreshTableQueueByID(String tableID, int status) {
        broadcast("queue/tableConfigChangedById", tableID, String.valueOf(status));
    }

    /**
     * KDS退菜待分配，分配通知
     *
     * @param hostId
     * @param deptName
     * @param info
     */
    public static void kdsRetreated(String hostId, String deptName, String info) {
        if (TextUtils.isEmpty(hostId)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "站点信息为空，待分配退菜信息不推送");
        }
        sendTo(hostId, "login/kdsRetreated", deptName, info);
    }

    /**
     * KDS催菜
     *
     * @param sellNo
     */
    public static void kdsUrge(String sellNo, List<String> seqList) {
        if (ListUtil.isEmpty(seqList)) {
            return;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(sellNo);
        if (orderCache == null) {
            return;
        }
        for (MenuItem menuItem : orderCache.originMenuList) {
            if (menuItem == null) {
                continue;
            }
            if (seqList.contains(menuItem.menuBiz.uniq)) {
                broadcast("login/kdsUrge", orderCache.fsmtablename, menuItem.name);
            }
        }
    }

    /**
     * 刷新KDS菜品
     */
    public static void refreshKds() {
        broadcast("login/refreshKds");
    }
}
