package com.mwee.android.pos.businesscenter.module.table;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.air.dao.ITableDao;
import com.mwee.android.pos.businesscenter.air.dao.impl.TableDaoImpl;
import com.mwee.android.pos.businesscenter.air.dao.ITableService;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.table.ShareTableResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;

/**
 * Created by qinwei on 2018/8/17.
 */

public class TableServiceImpl implements ITableService {
    private ITableDao tableDao = new TableDaoImpl();

    @Override
    public SocketResponse<ShareTableResponse> doShareTable(String tableId, UserDBModel userDBModel) {
        RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, "->开始拼桌 tableId=" + tableId);
        SocketResponse<ShareTableResponse> response = null;
        try {
            response = new SocketResponse<>();
            MtableDBModel mainTable = tableDao.queryById(tableId);
            if (mainTable == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "桌台信息不存在";
                RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, response.message);
                return response;
            }
            if (!TextUtils.isEmpty(mainTable.fshint)) {
                //操作桌台为拼桌桌台 找到主桌台
                mainTable = tableDao.queryById(mainTable.fshint);
            }
            MtableDBModel shareTable = tableDao.insertShareTable(mainTable, userDBModel);
            if (shareTable == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "拼桌失败";
                RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, response.message);
                return response;
            }
            ShareTableResponse shareTableResponse = new ShareTableResponse();
            shareTableResponse.fsmtableid = shareTable.fsmtableid;
            shareTableResponse.newTableName = shareTable.fsmtablename;

            response.data = shareTableResponse;
            response.code = SocketResultCode.SUCCESS;
            response.message = "拼桌成功";
            RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, response.message + " info " +
                    shareTable.fsmareaid + ",name=" + shareTable.fsmtablename);
            //拼桌成功，通知各站点刷新桌台页面
            NotifyToClient.refreshTableOrOrders();
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.EXCEPTION;
            RunTimeLog.addLog(RunTimeLog.DINNER_TABLE, e.getMessage());
        }
        return response;
    }
}
