package com.mwee.android.pos.businesscenter.air.dao;

/**
 * Created by qinwei on 2018/10/17.
 */

public interface ISellDao {
    /**
     * 订单是否已经结账
     *
     * @param fssellno   pos订单号
     * @param thirdOrderId 第三方订单号
     * @return
     */
    boolean querySellIsDone(String fssellno, String thirdOrderId);

    /**
     * 订单是否已经结账
     *
     * @param fssellno pos订单号
     * @return
     */
    boolean querySellIsDone(String fssellno);
}
