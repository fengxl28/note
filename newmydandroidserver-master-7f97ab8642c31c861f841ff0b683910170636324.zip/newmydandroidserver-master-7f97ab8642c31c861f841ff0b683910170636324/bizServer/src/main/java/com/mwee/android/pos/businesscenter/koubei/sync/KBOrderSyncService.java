package com.mwee.android.pos.businesscenter.koubei.sync;

import android.text.TextUtils;

import com.mwee.android.pos.component.log.RunTimeLog;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * 口碑订单同步服务
 * Created by qinwei on 2018/10/22.
 */

public class KBOrderSyncService implements OrderSyncTask.OnOrderSyncTaskListener {
    private static KBOrderSyncService mInstance;
    private static final int MAX_ORDER_SYNC_TASK_SIZE = 1;
    private ExecutorService mExecutors;
    private LinkedBlockingDeque<String> mOrderSyncWaitQueues;
    private HashMap<String, OrderSyncTask> mOrderSyncingTasks;

    private KBOrderSyncService() {
        mOrderSyncWaitQueues = new LinkedBlockingDeque<>();
        mExecutors = Executors.newCachedThreadPool();
        mOrderSyncingTasks = new HashMap<>();
    }

    public static KBOrderSyncService getInstance() {
        if (mInstance == null) {
            mInstance = new KBOrderSyncService();
        }
        return mInstance;
    }

    public void add(String orderId) {
        trace(orderId + "：添加一个口碑订单数据同步任务");
        if (mOrderSyncingTasks.size() >= MAX_ORDER_SYNC_TASK_SIZE) {
            trace(orderId + "：当前已有任务在执行");
            if (!mOrderSyncWaitQueues.contains(orderId)) {
                trace(orderId + "：添加到同步队列 size=" + mOrderSyncWaitQueues.size());
                mOrderSyncWaitQueues.offer(orderId);
            }
        } else {
            start(orderId);
        }
    }

    private void start(String orderId) {
        OrderSyncTask task = new OrderSyncTask(orderId, mExecutors);
        task.setOnOrderSyncTaskListener(this);
        mOrderSyncingTasks.put(orderId, task);
        trace(orderId + "：开启口碑订单数据同步任务");
        task.start();
    }

    public void stopAll() {
    }

    @Override
    public void onCompleted(String id) {
        mOrderSyncingTasks.remove(id);
        doNextTask();
    }

    private void doNextTask() {
        String orderId = mOrderSyncWaitQueues.poll();
        if (!TextUtils.isEmpty(orderId)) {
            add(orderId);
        }
    }

    @Override
    public void onError(String id, String msg) {
        mOrderSyncingTasks.remove(id);
        doNextTask();
    }

    private void trace(String msg) {
        RunTimeLog.addLog(RunTimeLog.KB_ORDER_SYNC, "KBOrderSyncService:" + msg);
    }
}
