package com.mwee.myd.server.slave;

import android.text.TextUtils;

/**
 * @ClassName: SlaveConstant
 * @Description:
 * @author: SugarT
 * @date: 2018/5/4 下午8:12
 */
public class SlaveConstant {

    /**
     * 从库的数据库名称格式
     */
    public static final String SLAVE_DATABASE_FORMAT = "slave_%s.sqlite";

    /**
     * 表是否使用 fsSellNo 作为主键
     *
     * @param tableName
     * @return
     */
    public static boolean usePrimaryKeySellNo(String tableName) {
        if (TextUtils.isEmpty(tableName)) {
            return false;
        }
        if (tableName.equalsIgnoreCase("tbSell") ||
                tableName.equalsIgnoreCase("tbSellOrder") ||
                tableName.equalsIgnoreCase("tbSellOrderItem") ||
                tableName.equalsIgnoreCase("tbSellReceive") ||
                tableName.equalsIgnoreCase("tbSellCheck") ||
                tableName.equalsIgnoreCase("tbSellCoupon") ||
                tableName.equalsIgnoreCase("tbSellOrderItemNote") ||
                tableName.equalsIgnoreCase("tbSellPickMenuitem")) {
            return true;
        }
        return false;
    }

    /**
     * 使用 business_date 作为营业日期标识
     *
     * @param tableName
     * @return
     */
    public static boolean useDateKeyBusinessDate(String tableName) {
        if (TextUtils.isEmpty(tableName)) {
            return false;
        }
        if (tableName.equalsIgnoreCase("order_cache") ||
                tableName.equalsIgnoreCase("order_pay_cache")) {
            return true;
        }
        return false;
    }
}
