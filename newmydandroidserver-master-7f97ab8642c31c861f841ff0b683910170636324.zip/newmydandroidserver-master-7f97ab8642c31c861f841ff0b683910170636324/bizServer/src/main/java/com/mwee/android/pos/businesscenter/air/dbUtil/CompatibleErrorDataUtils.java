package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.database.SQLException;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.NetResultType;
import com.mwee.android.base.net.component.Result;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.datasync.net.DownloadPageRequest;
import com.mwee.android.pos.component.datasync.net.DownloadPageResponse;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.TempAskgpMenuClsDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/5.
 */

public class CompatibleErrorDataUtils {

    private static JSONObject downloadData = new JSONObject();

    /**
     * 清洗tbAskGpMenucls 错误数据
     * <p>
     * 1 调用downLoad接口 下载数据
     * 2 比对数据 清洗掉错误数据
     * <p>
     * 3 tbAskGpMenucls重命名为tbAskGpMenuclsTemp
     * 4 创建tbAskGpMenucl和后台一致的表结构
     * 5 tbAskGpMenucl中插入清洗过后的数据
     * 6 删除临时表
     * Over
     */
    public static void startCleanSyncError(SocketResponse response) {

        LogUtil.log("startCleanSyncError--->start");

        String aa = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sql from sqlite_master where type='table' and name='tbaskgpmenucls'");

        if (TextUtils.isEmpty(aa)) {
            response.code = SocketResultCode.EXCEPTION;
            response.message = "处理失败";
            return;
        }

        if (aa.toLowerCase().contains("constraint") && aa.toLowerCase().contains("unique")) {
            response.code = SocketResultCode.SUCCESS;
            response.message = "已经处理成功";

            return;
        }

        download(response, 1, 100);

//        GetDataRequest getDataRequest = new GetDataRequest();
//
//        getDataRequest.tag = "-1";
//
//        BusinessExecutor.execute(getDataRequest, new IExecutorCallback() {
//            @Override
//            public void success(ResponseData responseData) {
//                response.code = SocketResultCode.SUCCESS;
//                response.message = "处理成功";
//            }
//
//            @Override
//            public boolean fail(ResponseData responseData) {
//                response.code = SocketResultCode.EXCEPTION;
//                response.message = "处理异常请联系客服";
//                return false;
//            }
//        }, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                try {
//                    if (responseData.responseBean != null) {
//                        if (responseData.responseBean instanceof GetDataResponse) {
//                            GetDataResponse getDataResponse = (GetDataResponse) responseData.responseBean;
//                            if (TextUtils.isEmpty(getDataResponse.data) || "{}".equals(getDataResponse.data) || getDataResponse.data.length() < 5) {
//                                return true;
//                            }
//
//                            boolean isCleanSuccess = cleanSyncError(JSON.parseObject(getDataResponse.data));
//                            if (isCleanSuccess) {
//                                response.code = SocketResultCode.SUCCESS;
//                                response.message = "处理成功";
//                            } else {
//                                response.code = SocketResultCode.EXCEPTION;
//                                response.message = "处理失败";
//                            }
//
//                            LogUtil.log("startCleanSyncError--->end");
//                        }
//                    }
//                } catch (Exception e) {
//                    LogUtil.logError(e);
//                    responseData.result = Result.FAIL;
//                    responseData.netResult = NetResultType.WRONG_FORMAT;
//                } catch (Error e) {
//                    LogUtil.logError(e);
//                    responseData.result = Result.FAIL;
//                    responseData.netResult = NetResultType.WRONG_FORMAT;
//                }
//                return true;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                return false;
//            }
//        }, false);

    }

    private static void download(SocketResponse response, int page, int pagesize) {
        String tbName = "tbaskgpmenucls";
        DownloadPageRequest request = new DownloadPageRequest(tbName);
        if (page > 0) {
            request.pageNum = page + "";
        }
        if (pagesize > 0) {
            request.pageSize = pagesize + "";
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "处理成功";
            }

            @Override
            public boolean fail(ResponseData responseData) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "处理异常请联系客服";
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    if (responseData.responseBean != null) {
                        DownloadPageResponse response1 = (DownloadPageResponse) responseData.responseBean;
                        JSONObject data = response1.data;
                        int pageSize = data.getInteger("pageSize");
                        int pages = data.getInteger("pages");
                        int pageNum = data.getInteger("pageNum");
                        if (TextUtils.isEmpty(data.toJSONString()) || "{}".equals(data.toJSONString()) || data.toJSONString().length() < 5) {
                            return true;
                        }

                        downloadData.put(tbName, data.get("list"));

                        if (pages > pageNum) {
                            download(response, pageNum + 1, pageSize);
                        } else if (pages == pageNum){
                            boolean isCleanSuccess = cleanSyncError(downloadData);
                            if (isCleanSuccess) {
                                response.code = SocketResultCode.SUCCESS;
                                response.message = "处理成功";
                            } else {
                                response.code = SocketResultCode.EXCEPTION;
                                response.message = "处理失败";
                            }

                            LogUtil.log("startCleanSyncError--->end");
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                } catch (Error e) {
                    LogUtil.logError(e);
                    responseData.result = Result.FAIL;
                    responseData.netResult = NetResultType.WRONG_FORMAT;
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
    }

    /**
     * todo 1、先判断数据是否已迁移过
     * 未迁移过才执行此方法
     *
     * @return
     */
    private static boolean cleanSyncError(JSONObject ob) {


        LogUtil.log("startCleanSyncError--->starting");


        List<TempAskgpMenuClsDBModel> cloudDataList = JSON.parseArray(ob.getString("tbaskgpmenucls"), TempAskgpMenuClsDBModel.class);

        //1、从本地表中抽取有效数据------如果唯一约束存在多条记录，取fistatus = 1的，如果 fistatus=13一致，去fsupdatetime最大的
        List<TempAskgpMenuClsDBModel> askgpMenuClsDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbaskgpmenucls group by fsMenuClsId, fsAskGpId,fsShopGUID order by fistatus asc,fsUpdateTime desc ", TempAskgpMenuClsDBModel.class);

        if (ListUtil.isEmpty(askgpMenuClsDBModelList)) {
            askgpMenuClsDBModelList = new ArrayList<>();
        }

        //2、拿到云端所有数据  --- cloudDataList

        //3、比较云端数据和本地有效数据
        //3-1)、本地没有云端的记录
        //3-2)、本地数据与云端数据完全一致
        //3-3)、本地数据与云端数据guid不一致--->改本地guid

        //仅云端存在的数据集
        List<TempAskgpMenuClsDBModel> onlyCloudExsitsList = new ArrayList<>();

        if (!ListUtil.isEmpty(cloudDataList)) {
            boolean mapping = false;
            for (TempAskgpMenuClsDBModel cloudDataModel : cloudDataList) {
                if (cloudDataModel == null) {
                    continue;
                }
                mapping = false;
                for (TempAskgpMenuClsDBModel localDataModel : askgpMenuClsDBModelList) {
                    if (localDataModel == null) {
                        continue;
                    }
                    if (TextUtils.equals(cloudDataModel.fsAskGpId, localDataModel.fsAskGpId)
                            && TextUtils.equals(cloudDataModel.fsShopGUID, localDataModel.fsShopGUID)
                            && TextUtils.equals(cloudDataModel.fsMenuClsId, localDataModel.fsMenuClsId)
                            ) {
                        mapping = true;

                        if (!TextUtils.equals(cloudDataModel.fsGuid, localDataModel.fsGuid)) {
                            localDataModel.fsGuid = cloudDataModel.fsGuid;
                        }

                        break;
                    }
                }

                if (!mapping) {
                    onlyCloudExsitsList.add(cloudDataModel);
                }
            }
        }

        //4、所有有效数据
        askgpMenuClsDBModelList.addAll(onlyCloudExsitsList);

        //5、创建临时表
        if (!createTempTable()) {
            //创建表失败
            RunTimeLog.addLog(RunTimeLog.TV_DB, "创建临时表失败(tbaskgpmenuclsTemp)");
            //LogUtil.log("创建临时表失败(tbaskgpmenuclsTemp)");
            return false;
        }
        //6、将所有有效数据插入主键、外键都健全的临时表
        for (TempAskgpMenuClsDBModel localDataModel : askgpMenuClsDBModelList) {
            if (localDataModel == null) {
                continue;
            }
            localDataModel.replaceNoTrans();
        }

        String tempTableCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from (select fsguid from tbaskgpmenuclsTemp group by fsMenuClsId, fsAskGpId,fsShopGUID)");
        String oldTableCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from (select fsguid from tbaskgpmenucls group by fsMenuClsId, fsAskGpId,fsShopGUID)");
        int tempCount = StringUtil.toInt(tempTableCount, 0);
        int oldCount = StringUtil.toInt(oldTableCount, 0);
        if (tempCount < oldCount) {
            //数据迁移有异常
            RunTimeLog.addLog(RunTimeLog.TV_DB, "数据迁移有异常(tbaskgpmenuclsTemp)  tempCount-->" + tempCount + "---->" + oldCount);
            //LogUtil.log("数据迁移有异常(tbaskgpmenuclsTemp)");
            return false;
        }

        //8、删原表并改临时表名称
        return cleanDB();
    }

    /**
     * 创建临时表
     *
     * @return
     */
    private static boolean createTempTable() {
        try {
            //TODO sql待验证
            return DBManager.getInstance().executeInTransactionWithOutThread((db) -> {
                db.execSQL("CREATE TABLE IF NOT EXISTS tbaskgpmenuclsTemp (\n" +
                        "  fsGuid           char(36)    NOT NULL,\n" +
                        "  fsMenuClsId      VARCHAR(10) NOT NULL,\n" +
                        "  fsAskGpId        VARCHAR(6)  NOT NULL,\n" +
                        "  fsUpdateTime     VARCHAR(20) NOT NULL,\n" +
                        "  fsUpdateUserId   VARCHAR(20)          DEFAULT NULL,\n" +
                        "  fsUpdateUserName VARCHAR(30)          DEFAULT NULL,\n" +
                        "  fsShopGUID       VARCHAR(80) NOT NULL,\n" +
                        "  fiStatus         INT(11)     NOT NULL DEFAULT '1',\n" +
                        "  fiDataSource     TINYINT(4)           DEFAULT '0',\n" +
                        "  sync int(2) DEFAULT 0,\n" +
                        "  PRIMARY KEY (fsGuid),\n" +
                        "  CONSTRAINT idx_tbAskGpMenuCls_1 UNIQUE (fsShopGUID, fsAskGpId, fsMenuClsId)\n" +
                        ");");
                return true;
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 创建临时表
     *
     * @return
     */
    private static boolean cleanDB() {
        RunTimeLog.addLog(RunTimeLog.TV_DB, "清除(tbaskgpmenuclsTemp)   drop table tbaskgpmenucls");
        RunTimeLog.addLog(RunTimeLog.TV_DB, "清除(tbaskgpmenuclsTemp)   alter table tbaskgpmenuclsTemp rename to tbaskgpmenucls");
        try {
            return DBManager.getInstance().executeInTransactionWithOutThread((db) -> {
                db.execSQL("drop table tbaskgpmenucls");
                db.execSQL("alter table tbaskgpmenuclsTemp rename to tbaskgpmenucls");
                return true;
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
