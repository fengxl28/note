package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.air.util.DBPrimaryKeyUtil;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.DiscountMenuClsDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/18.
 */

public class AirDiscountDBUtil {

    public static List<DiscountManagerInfo> optAllDiscountManagerInfoList() {
        String sql = "select fiDiscountRate, fsDiscountId, fsDiscountName, fiStatus, ficouponid from tbdiscount where fistatus = '1' and ficouponid <> '1' and fsDiscountId!='" + DiscountType.CASH + "' order by fistatus ";
        List<DiscountManagerInfo> discountManagerInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DiscountManagerInfo.class);

        String discountMneuclsSql = "select tbdiscountmenucls.fsDiscountId id, tbdiscountmenucls.fsMenuClsId value, tbmenucls.fsMenuClsName name from tbdiscountmenucls left join tbmenucls on tbdiscountmenucls.fsMenuClsId = tbmenucls.fsMenuClsId where tbmenucls.fistatus = '1' and tbdiscountmenucls.fistatus = '1' ";
        List<DataModel> discountMenuClsDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, discountMneuclsSql, DataModel.class);

        if (!ListUtil.isEmpty(discountManagerInfos)) {
            for (DiscountManagerInfo discountManagerInfo : discountManagerInfos) {
                if (discountManagerInfo == null) {
                    continue;
                }

                if (discountManagerInfo.ficouponid == 2) {
                    discountManagerInfo.discountClsNameTag = "全部";
                    continue;
                }

                if (!ListUtil.isEmpty(discountMenuClsDBModelList)) {
                    for (DataModel dataModel : discountMenuClsDBModelList) {
                        if (dataModel == null) {
                            continue;
                        }
                        if (TextUtils.equals(discountManagerInfo.fsDiscountId, dataModel.id)) {
                            ArrayList<String> menuclsList = discountManagerInfo.menuclsList;
                            if (menuclsList == null) {
                                menuclsList = new ArrayList<>();
                            }
                            menuclsList.add(dataModel.value);

                            if (TextUtils.isEmpty(discountManagerInfo.discountClsNameTag)) {
                                discountManagerInfo.discountClsNameTag = dataModel.name;
                            } else {
                                discountManagerInfo.discountClsNameTag = discountManagerInfo.discountClsNameTag + "," + dataModel.name;
                            }
                        }
                    }
                } else {
                    discountManagerInfo.discountClsNameTag = "无";
                }
            }

            for (DiscountManagerInfo discountManagerInfo : discountManagerInfos) {
                if (discountManagerInfo != null && discountManagerInfo.ficouponid != 2) {
                    if (TextUtils.isEmpty(discountManagerInfo.discountClsNameTag)) {
                        discountManagerInfo.discountClsNameTag = "无";
                    }
                    continue;
                }
            }
        }


        if (ListUtil.isEmpty(discountManagerInfos)) {
            discountManagerInfos = new ArrayList<>();
        }
        return discountManagerInfos;

    }

    /**
     * 修改折扣
     *
     * @param discountManagerInfo
     * @param userDBModel
     * @return
     */
    public static synchronized String updateDiscount(DiscountManagerInfo discountManagerInfo, UserDBModel userDBModel) {
        if (TextUtils.isEmpty(discountManagerInfo.fsDiscountId)) {
            return "折扣信息异常，请重试";
        }
        String checkSql = "select * from tbdiscount where fsDiscountId = '" + discountManagerInfo.fsDiscountId + "'";
        DiscountDBModel discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, DiscountDBModel.class);
        if (discountDBModel == null) {
            return "未找到该折扣";
        } else {
            discountDBModel.fsDiscountName = discountManagerInfo.fsDiscountName;
            discountDBModel.fiStatus = discountManagerInfo.fiStatus;
            discountDBModel.fiDiscountRate = discountManagerInfo.fiDiscountRate;
            discountDBModel.ficouponid = discountManagerInfo.ficouponid;
            discountDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                discountDBModel.fsUpdateUserId = userDBModel.fsUserId;
                discountDBModel.fsUpdateUserName = userDBModel.fsUserName;
            }
            discountDBModel.sync = 1;
            discountDBModel.replaceNoTrans();
            updateDiscountMenuClsRelation(discountManagerInfo, userDBModel);
            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 新增折扣
     *
     * @param discountManagerInfo
     * @param userDBModel
     * @return
     */
    public static synchronized String addDiscount(DiscountManagerInfo discountManagerInfo, UserDBModel userDBModel) {
        String checkSql = "select * from tbdiscount where fsDiscountName = '" + discountManagerInfo.fsDiscountName + "' and fiStatus = '1'";
        DiscountDBModel discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, DiscountDBModel.class);
        if (discountDBModel != null) {
            return "折扣已存在";
        } else {
            discountDBModel = new DiscountDBModel();
            discountDBModel.fsDiscountId = IDHelper.generateDiscountId();
            discountDBModel.fiStatus = discountManagerInfo.fiStatus;
            discountDBModel.ficouponid = discountManagerInfo.ficouponid;
            discountDBModel.fsDiscountName = discountManagerInfo.fsDiscountName;
            discountDBModel.fiDiscountRate = discountManagerInfo.fiDiscountRate;
            discountDBModel.sync = 1;
            discountDBModel.fiDataKind = 2;
            discountDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            discountDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            discountDBModel.fiDataSource = 1;
            if (userDBModel != null) {
                discountDBModel.fsUpdateUserId = userDBModel.fsUserId;
                discountDBModel.fsUpdateUserName = userDBModel.fsUserName;
            }
            discountDBModel.replaceNoTrans();
            discountManagerInfo.fsDiscountId = discountDBModel.fsDiscountId;
            updateDiscountMenuClsRelation(discountManagerInfo, userDBModel);
            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 更新折扣与菜品关联关系表
     *
     * @param discountManagerInfo
     * @param userDBModel
     */
    private static void updateDiscountMenuClsRelation(DiscountManagerInfo discountManagerInfo, UserDBModel userDBModel) {
        if (discountManagerInfo == null) {
            return;
        }
        String fsUpdateUserName = "", fsUpdateUserId = "";
        if (userDBModel != null) {
            fsUpdateUserName = userDBModel.fsUserName;
            fsUpdateUserId = userDBModel.fsUserId;
        }

        if (discountManagerInfo.ficouponid == 2 || ListUtil.isEmpty(discountManagerInfo.menuclsList)) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscountmenucls set fistatus = '13', sync = '1', fsUpdateTime == '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + fsUpdateUserName + "', fsUpdateUserId = '" + fsUpdateUserId + "' where fsDiscountId = '" + discountManagerInfo.fsDiscountId + "' and fistatus= '1'");
        } else {
            String menuClsParam = ListUtil.optSqlParams(discountManagerInfo.menuclsList);
            //删除不在最新要求和菜品组关联关系范围内的数据
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscountmenucls set fistatus = '13', sync = '1', fsUpdateTime == '" +
                    DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + fsUpdateUserName +
                    "', fsUpdateUserId = '" + fsUpdateUserId + "' where fsDiscountId = '" + discountManagerInfo.fsDiscountId +
                    "' and fistatus= '1' and fsMenuClsId not in (" + menuClsParam + ") ");

            //更新折扣率 fiDiscountRate
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscountmenucls set sync = '1', fsUpdateTime == '" +
                    DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + fsUpdateUserName +
                    "', fsUpdateUserId = '" + fsUpdateUserId + "', fiDiscountRate = '" + discountManagerInfo.fiDiscountRate + "' where fsDiscountId = '" + discountManagerInfo.fsDiscountId +
                    "' and fistatus= '1' ");
            //查出当前已存的有效关系
            List<String> fsMenuClsIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsMenuClsId from tbdiscountmenucls where fistatus = '1' and fsDiscountId = '" + discountManagerInfo.fsDiscountId + "' ");
            //过滤出DB中缺少的关系
            if (!ListUtil.isEmpty(fsMenuClsIdList)) {
                for (String savedMenuClsId : fsMenuClsIdList) {
                    if (discountManagerInfo.menuclsList.contains(savedMenuClsId)) {
                        discountManagerInfo.menuclsList.remove(savedMenuClsId);
                    }
                }
            }

            String shopguid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

            //存储关系
            DiscountMenuClsDBModel discountMenuClsDBModel;
            if (!ListUtil.isEmpty(discountManagerInfo.menuclsList)) {
                for (String fsMenuClsId : discountManagerInfo.menuclsList) {
                    discountMenuClsDBModel = new DiscountMenuClsDBModel();
                    discountMenuClsDBModel.fsGuid = DBPrimaryKeyUtil.optPrimaryKey();
                    discountMenuClsDBModel.fsMenuClsId = fsMenuClsId;
                    discountMenuClsDBModel.fsDiscountId = discountManagerInfo.fsDiscountId;
                    discountMenuClsDBModel.fiDiscountRate = discountManagerInfo.fiDiscountRate;
                    discountMenuClsDBModel.fiDataSource = 1;
                    discountMenuClsDBModel.fsShopGUID = shopguid;
                    discountMenuClsDBModel.sync = 1;
                    discountMenuClsDBModel.fiStatus = 1;

                    discountMenuClsDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                    if (userDBModel != null) {
                        discountMenuClsDBModel.fsUpdateUserName = fsUpdateUserName;
                        discountMenuClsDBModel.fsUpdateUserId = fsUpdateUserId;
                    }
                    discountMenuClsDBModel.replaceNoTrans();
                }
            }
        }

    }

    /**
     * 删除折扣
     *
     * @param tableIdList
     * @param userDBModel
     * @return
     */
    public static synchronized String batchDeleteDiscount(ArrayList<String> tableIdList, UserDBModel userDBModel) {

        String fsDiscountIdParam = parsListToSQLParam(tableIdList);

        String fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        String fsUpdateUserName = userDBModel == null ? "" : userDBModel.fsUserName;
        String fsUpdateUserId = userDBModel == null ? "" : userDBModel.fsUserId;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscount set fistatus = '13', sync = '1', fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fsDiscountId in (" + fsDiscountIdParam + ") ");
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscountitem set fistatus = '13', sync = '1', fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fsDiscountId in (" + fsDiscountIdParam + ") and fistatus = '1'");
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbdiscountmenucls set fistatus = '13', sync = '1', fsUpdateTime == '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + fsUpdateUserName + "', fsUpdateUserId = '" + fsUpdateUserId + "' where fsDiscountId in (" + fsDiscountIdParam + ") and fistatus= '1'");
        return "";
    }

    public static String parsListToSQLParam(List<String> params) {
        StringBuilder stringBuilder = new StringBuilder();

        if (!ListUtil.isEmpty(params)) {
            for (String str : params) {
                stringBuilder.append("'").append(str).append("'").append(",");
            }
            String str = stringBuilder.toString();
            if (stringBuilder.length() > 1) {
                str = str.substring(0, str.length() - 1);
            }
            return str;
        }
        return "";
    }


}
