package com.mwee.android.pos.businesscenter.driver;

import com.mwee.android.pos.business.print.PrintCountModel;
import com.mwee.android.pos.business.print.PrintIncomeFindModel;
import com.mwee.android.pos.business.print.PrintPaymentModel;
import com.mwee.android.pos.business.print.PrintPaymentSettlementModel;
import com.mwee.android.pos.business.print.PrintSalesFindsModel;
import com.mwee.android.pos.business.print.PrintShiftDetailModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.db.business.report.model.PrintDeptDetlModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by virgil on 2016/10/25.
 */

public class PreparePrintUtil {

    /**
     * 交班表
     *
     * @param shop         ShopDBModel | 门店信息
     * @param businessDate String | 营业日期，要求格式为：yyyyMMdd
     * @param waiterID     String | 收银员ID
     * @param waiterName   String | 收银员账户名称
     * @param shiftID      String | 班别ID
     * @param shiftName    String | 班别名称
     * @param hostid       String | 站点ID
     * @param orderID      String | 订单号列表，","间隔
     * @param printConfig : 0 :不打印交班表 1：打印全部 2：不打印档口明细
     * @return String
     */
    public static HashMap<String, Object> prepareShiftPrintValue(ShopDBModel shop, String businessDate, String waiterID, String waiterName, String shiftID, String shiftName, String hostid, String orderID, boolean isAuthorize, String authorizeUsername, String authorizeUserId,int printConfig) {
        if (orderID.isEmpty()) {
            return new HashMap<>();//没有任何记录
        }
        HashMap<String, Object> valueMap = new HashMap<String, Object>();
        final String date = businessDate.contains("-") ? businessDate : DateUtil.formartDateStrToTarget(businessDate, "yyyyMMdd", "yyyy-MM-dd");
        valueMap.put("Shop", shop);
        valueMap.put("Businessdate", date);
        valueMap.put("SUserName", waiterName);
        valueMap.put("shiftName", shiftName);
        valueMap.put("fsHostId", hostid);

        if (isAuthorize) {//授权交班
            valueMap.put("isAuthorize", isAuthorize);
            valueMap.put("authorizeUsername", authorizeUsername);
            valueMap.put("authorizeUserId", authorizeUserId);
        }

        /**
         * 打印时间
         */
        String printTime = DateUtil.getCurrentTime();
        HashMap<String, Object> times = new HashMap<>();
        times.put("PrintTime", printTime);
        valueMap.put("SysMode", times);

        /**
         * 结算方式统计数据
         */
        String sql = "select tbSellReceive.fsPaymentName as fspaymentname, sum(tbSellReceive.fdReceMoney) as recemoney, sum(tbSellReceive.fdReceMoney) as fdrecemoney " +
                "from tbSellReceive inner join tbSellCheck on tbSellReceive.fsSellNo=tbSellCheck.fsSellNo " +
                "where tbSellCheck.fsSellNo in (" + orderID + ") " +
                "and  tbSellReceive.fsSellDate = '" + date + "' " +
                "and tbSellCheck.fsShiftId='" + shiftID + "' " +
                "and tbSellCheck.fsUpdateUserId='" + waiterID + "'  " +
                "and tbSellReceive.fiStatus='1' " +
                "group by fsPaymentId ";

        List<PrintPaymentSettlementModel> paymentSettlementModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintPaymentSettlementModel.class);
        BigDecimal total = BigDecimal.ZERO;
        for (PrintPaymentSettlementModel paymentSettlementModel : paymentSettlementModels) {
            /**
             * 合计总金额
             */
            total = total.add(paymentSettlementModel.recemoney);
        }
        PrintCountModel countModel = new PrintCountModel();
        countModel.fdrecemoney = total;

        PrintPaymentModel paymentModel = new PrintPaymentModel();
        List<PrintPaymentModel> paymentModels = new ArrayList<PrintPaymentModel>();

        paymentModel.fsshiftname = shiftName;
        paymentModel.HJ = countModel;
        paymentModel.MX = paymentSettlementModels;
        paymentModels.add(paymentModel);
        valueMap.put("ShiftList", paymentModels);

        //明细
        String sqlDetail = "SELECT " +
                "sum(fiCustSum) fiCustSum, " +          //人数
                "count(fsSellNo) qty, " +               //单数
                "sum(fdSaleAmt) fdSaleAmt, " +          //销售金额
                "sum(fdExpAmt) fdExpAmt, " +            //营业金额
                "sum(fdDiscountAmt) fdDiscountAmt, " +  //折扣金额
                "sum(fdRealAmt) fdRealAmt, " +          //实收金额
                "sum(fdExpAmt)/sum(fiCustSum) RJ, " +   //人均
                "sum(fdExpAmt)/count(fsSellNo) DJ " +   //单均
                "FROM tbsell " +
                "WHERE fsSellNo IN (" +
                "SELECT tbSell.fsSellNo " +
                "FROM tbSell INNER JOIN tbSellCheck " +
                "ON tbSell.fsSellNo = tbSellCheck.fsSellNo " +
                "WHERE tbSell.fiBillStatus NOT IN (0, 1, 2, 6) " +
                "AND tbSell.fsSellDate = '" + date + "' " +
                "AND tbSellCheck.fsShiftId = '" + shiftID + "' " +
                "AND tbSellCheck.fsUpdateUserId = '" + waiterID + "' " +
                "AND tbSellCheck.fsSellNo in (" + orderID + "))";
        PrintShiftDetailModel detailModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlDetail, PrintShiftDetailModel.class);
        valueMap.put("detail", detailModel);

        //销售分类
        String sql1 = "select b.fsExpClsName fsexpclsname, (a.total-a.backqty) fdsaleqty, a.amount fdsaleamt from " +
                "(select fsExpClsId id, sum((case fiIsEditQty when '1' then '1' else (fdSaleQty) end)) total," +
                "sum((case fdbackQty when '0' then '0' else (case fiIsEditQty when '1' then '1' else (fdbackQty) end) end)) backqty," +
                " sum(fdSaleAmt) amount from "
                + " (select * from tbSellOrderItem a where  fsSellNo in (select tbSell.fsSellNo from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fiBillStatus not in (0,1,2, 6) and tbSell.fsSellDate='" + date + "' and tbSellCheck.fsShiftId='" + shiftID + "' and tbSellCheck.fsUpdateUserId='" + waiterID + "' and tbSellCheck.fsSellNo in (" + orderID + ") ))"
                + " where   fsSellDate='" + date + "' and fiOrderItemKind != '3' group by fsExpClsId) a left join tbexpcls b on a.id = b.fsExpClsId";
        List<PrintSalesFindsModel> salesFindsModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql1, PrintSalesFindsModel.class);
        valueMap.put("XSFL", salesFindsModels);

        //收入分类
        String sql2 = "select b.fsRevenueTypeName fsrevenuetypename, a.total fdsaleqty, a.amount fdsaleamt from " +
                "(select fsRevenueTypeId id, sum(fdSaleQty) total, sum(fdSaleAmt) amount from " +
                " (select * from tbSellOrderItem a where  fsSellNo in (select tbSell.fsSellNo from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fiBillStatus not in (0,1,2, 6) and tbSell.fsSellDate='" + date + "' and tbSellCheck.fsShiftId='" + shiftID + "' and tbSellCheck.fsUpdateUserId='" + waiterID + "' and tbSellCheck.fsSellNo in (" + orderID + ") ))"
                + " where " + "  fsSellDate='" + date + "'" + " and fiOrderItemKind != '3' group by fsRevenueTypeId) a " +
                "left join tbrevenuetype b on a.id = b.fsRevenueTypeId ";
        List<PrintIncomeFindModel> incomeFindModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintIncomeFindModel.class);
        valueMap.put("SRFL", incomeFindModels);

        if(printConfig != 2){
            List<PrintDeptDetlModel> dtl = new ArrayList<>(DailyReportDBUtil.statisticDeptDetl(date, 0, "1", waiterID, shiftID, null).values());
            valueMap.put("DTL", dtl);
        }

        return valueMap;
    }
}
