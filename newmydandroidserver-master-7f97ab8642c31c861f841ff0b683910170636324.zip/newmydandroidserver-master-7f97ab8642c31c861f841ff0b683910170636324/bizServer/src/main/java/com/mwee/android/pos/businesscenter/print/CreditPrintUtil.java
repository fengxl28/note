package com.mwee.android.pos.businesscenter.print;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/1/8.
 */

public class CreditPrintUtil {
    public static ArrayList<Integer> printCrossPay(CrossPayPrintInfo printInfo) {
        ArrayList<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String printName = PrintConnector.getInstance().getCurrentHostPrinterName();
        JSONObject datas = new JSONObject();
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class);
        datas.put("shop", shopDBModel.fsShopName);
        datas.put("crossPayInfo", printInfo);
        datas.put("fiPrintNo", printNO + "");
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MEMBER_CHARGE);
        task.uri = "order/crossPay";
        task.fsPrinterName = printName;
        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();
        task.fiPrintNo = printNO;
        task.fsPrnData = value;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }
}
