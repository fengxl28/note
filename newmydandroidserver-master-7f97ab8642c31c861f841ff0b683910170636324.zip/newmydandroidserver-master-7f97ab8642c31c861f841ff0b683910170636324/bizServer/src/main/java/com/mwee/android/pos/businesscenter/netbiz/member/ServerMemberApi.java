package com.mwee.android.pos.businesscenter.netbiz.member;

import android.os.SystemClock;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.base.task.net.NetJob;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberProcessResult;
import com.mwee.android.pos.business.member.MemberRechargePayTypeDefined;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.pay.IMemberBalance;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.GetMemberCardByCardNoRequest;
import com.mwee.android.pos.component.member.net.GetMemberCardResponse;
import com.mwee.android.pos.component.member.net.MemberConsumePreSearchResponse;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeResponse;
import com.mwee.android.pos.component.member.net.model.MemberCardInfoModel;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.component.member.net.model.MemberPreConsumeModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewGroupTicketUseModel;
import com.mwee.android.pos.component.member.newInterface.net.NewGroupTicketUseRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewGroupTicketUseResponse;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.component.member.newInterface.model.NewPayCodeModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponsDetailRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponsDetailResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberPayStoreRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberPayStoreResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberPrePayCheckRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberPrePayCheckResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberPrivateDetailRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberPrivateDetailResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberScoreDetailRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberScoreDetailResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberTradeDetailRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberTradeDetailResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewGetPayCodeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewGetPayCodeResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberCardDetailsRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberCardDetailsResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberCardListRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberCardListResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberVerifyCodeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberVerifyCodeResponse;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

import com.mwee.android.pos.component.member.newInterface.model.MemberRechargePackageModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberChangePswRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargePackageRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargePackageResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargeRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargeResultRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargeResultResponse;
import com.mwee.android.pos.db.business.common.Calc;

import java.math.RoundingMode;

/**
 * Created by virgil on 2016/10/11.
 *
 * @author virgil
 */

public class ServerMemberApi {

    private static final String ERROR_MSG = "业务异常，请重新操作";
    private static final int ERROR_CODE = -1;

    /**
     * 预消费查询
     *
     * @param payList
     * @param amount
     * @param cannotDiscount 订单不可折扣金额（不可折扣菜品金额合计+服务费）
     * @param cardNO
     * @param serverCallback
     */
    public static void sendPreSearchConsume(List<PayModel> payList, BigDecimal amount, BigDecimal cannotDiscount, String cardNO, final BusinessCallback serverCallback) {
        final MemberPrePayCheckRequest request = new MemberPrePayCheckRequest();
        request.brandId = ServerCache.getInstance().fsCompanyGUID;
        request.amount = amount;
        request.cardNo = cardNO;
        request.couponCode = PayUtil.getMemberTicketCodeList(payList);
        StringBuilder sb = new StringBuilder();
        if (!ListUtil.isEmpty(request.couponCode)) {
            sb.append("3,");
        }
        if (PayUtil.hasMemberPoint(payList)) {
            sb.append("4,");
        }
        if (PayUtil.hasMemberBalance(payList)) {
            sb.append("5,");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }

        request.dropAmount = cannotDiscount;
        if (request.dropAmount.compareTo(BigDecimal.ZERO) < 0) {
            request.dropAmount = BigDecimal.ZERO;
        }
        request.usePreferential = sb.toString();

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "MemberApi#sendPreSearchConsume ------会员回调-- 支付业务中心-");

                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberPrePayCheckResponse) {
                    MemberPrePayCheckResponse response = (MemberPrePayCheckResponse) responseData.responseBean;
                    if (!request.usePreferential.contains("4") && response.data != null && response.data.no_use_score != null) {
                        response.data.user_all_score = response.data.no_use_score.user_all_score;
                        response.data.use_score = response.data.no_use_score.use_score;
                        response.data.score_money = response.data.no_use_score.score_money;
                        response.data.cost_bonus_unit = response.data.no_use_score.cost_bonus_unit;
                    }
                    processMemberPreConsumeResponse(responseData);
                }
                if (serverCallback != null) {
                    serverCallback.success(i, responseData);
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (serverCallback != null) {
                    serverCallback.fail(i, responseData);
                }
                return false;
            }
        });
        job.execute();
    }

    /**
     * 会员储值消费
     *
     * @param orderCache
     * @param thirdOrderID
     * @param password
     * @param amount
     * @param pay_code
     * @param memberBalance
     */
    public static void sendConsumeBalance(final OrderCache orderCache, final String thirdOrderID, final String password, final BigDecimal amount, final String pay_code, final IMemberBalance memberBalance) {
        MemberPayStoreRequest request = new MemberPayStoreRequest();
        request.amount = amount;
        request.brandId = ServerCache.getInstance().fsCompanyGUID;
//        request.cardNo = pay_code;
        request.cardNo = orderCache.memberInfoS.card_no;
        request.password = password;
        request.outTradeNo = thirdOrderID;
        request.deviceId = ServerHardwareUtil.getHardWareSymbol();

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "OrderBizUtil#sendConsumeBalance ------会员回调-- 支付业务中心-");
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberPayStoreResponse) {
                    memberBalance.process("", (MemberPayStoreResponse) responseData.responseBean, false);
                } else {
                    memberBalance.process("支付失败，请重试", null, false);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null) {
                    if (responseData.responseBean.status == 203 || responseData.responseBean.errno == 203) {
                        memberBalance.process("需要输入储值密码", null, true);
                    } else if (responseData.responseBean.status == 500 || responseData.responseBean.errno == 500) {
                        RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付结果 会员payCode已过期，开始自动刷新 cardNO=" + orderCache.memberInfoS.card_no, orderCache.orderID, orderCache.fsmtableid, responseData, pay_code);
                        // TODO: 2018/9/24 异步
                        sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                if (result) {
                                    sendConsumeBalance(orderCache, thirdOrderID, password, amount, orderCache.memberInfoS.pay_code, memberBalance);
                                } else {
                                    memberBalance.process(info, null, false);
                                }
                            }
                        });
                    } else {
                        memberBalance.process(responseData.resultMessage, null, false);
                    }
                } else {
                    memberBalance.process(responseData.resultMessage, null, false);
                }
                return false;
            }
        });
        job.execute();
    }

    /**
     * 会员重构---已废弃
     *
     * @param orderCache
     * @param cardNo
     * @param callBack
     */
    public static void sendRefreshMemberSession(final OrderCache orderCache, final String cardNo, final IResult callBack) {
        GetMemberCardByCardNoRequest getMemberCardByCardNoRequest = new GetMemberCardByCardNoRequest();
        getMemberCardByCardNoRequest.card_no = cardNo;

        NetJob job = new NetJob(getMemberCardByCardNoRequest);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息", orderCache.orderID, orderCache.fsmtableid, responseData);
                if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                    GetMemberCardResponse response = (GetMemberCardResponse) responseData.responseBean;
                    orderCache.refreshMember(response.data);
                    OrderSaveDBUtil.upateMemberInfo(orderCache.orderID, JSON.toJSONString(orderCache.memberInfoS));
                    if (callBack != null) {
                        callBack.callBack(true, "");
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (callBack != null) {
                    callBack.callBack(false, responseData.resultMessage);
                }
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息失败", orderCache.orderID, orderCache.fsmtableid, responseData);
                return false;
            }
        });
        job.execute();
    }


    private static void processMemberPreConsumeResponse(ResponseData responseData) {
        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
            MemberPreConsumeModel data = ((MemberConsumePreSearchResponse) responseData.responseBean).data;
            if (!TextUtils.isEmpty(data.checkTicketCanUse())) {
                data.coupons_list = null;
            }
            if (!TextUtils.isEmpty(data.checkBalanceCanUse())) {
                data.is_pay_can_use = 0;
            }
            if (!TextUtils.isEmpty(data.checkPointCanUse())) {
                data.use_score = 0;
                data.score_money = BigDecimal.ZERO;
            }
            filterMemberCoupon(data);
        }

    }

    /**
     * 过滤会员的券
     *
     * @param data MemberPreConsumeModel
     * @return MemberPreConsumeModel
     */
    private static MemberPreConsumeModel filterMemberCoupon(MemberPreConsumeModel data) {
        if (data == null) {
            return null;
        }

        if (!ListUtil.isEmpty(data.coupons_list)) {
            String sql = "select fsNote from tbPayment where fsPaymentTypeId in ('30','31','32') and fiStatus = '1'";
            List<String> noteList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
            for (int i = 0; i < data.coupons_list.size(); i++) {
                MemberCouponModel temp = data.coupons_list.get(i);
                boolean exist = false;
                for (String tempCouponID : noteList) {
                    if (TextUtils.equals(temp.coupon_id, tempCouponID)) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    data.coupons_list.remove(i);
                    i--;
                }
            }
        }
        return data;
    }

    /**
     * 会员积分
     *
     * @param brandId
     * @param cardNoOrMobile
     * @param pageNo
     * @param callback
     */
    public static void queryMemberScore(String brandId, String cardNoOrMobile, int pageNo, IResponse<MemberScoreDetailModel> callback) {
        MemberScoreDetailRequest request = new MemberScoreDetailRequest();
        request.brandId = brandId;
        request.cardNoOrMobile = cardNoOrMobile;
        request.pageNo = pageNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberScoreDetailResponse) {
                    MemberScoreDetailResponse response = (MemberScoreDetailResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 储值记录
     *
     * @param brandId
     * @param cardNoOrMobile
     * @param pageNo
     * @param callback
     */
    public static void queryMemberTradeDetail(String brandId, String cardNoOrMobile, int pageNo, IResponse<MemberTradeDetailModel> callback) {
        MemberTradeDetailRequest request = new MemberTradeDetailRequest();
        request.brandId = brandId;
        request.cardNoOrMobile = cardNoOrMobile;
        request.pageNo = pageNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberTradeDetailResponse) {
                    MemberTradeDetailResponse response = (MemberTradeDetailResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void queryMemberCoupons(String brandId, String cardNo, int pageNo, IResponse<MemberCouponsDetailModel> callback) {
        MemberCouponsDetailRequest request = new MemberCouponsDetailRequest();
        request.brandId = brandId;
        request.cardNo = cardNo;
        request.pageNo = pageNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberCouponsDetailResponse) {
                    MemberCouponsDetailResponse response = (MemberCouponsDetailResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void queryMemberPrivate(String brandId, String csId, int memberLevel, String storeId, String cardNo, IResponse<MemberPrivateDetailModel> callback) {
        MemberPrivateDetailRequest request = new MemberPrivateDetailRequest();
        request.brandId = brandId;
        request.csId = csId;
        request.level = memberLevel;
        request.storeId = storeId;
        request.cardNo = cardNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberPrivateDetailResponse) {
                    MemberPrivateDetailResponse response = (MemberPrivateDetailResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 获取单个会员卡详情，通过卡号
     *
     * @param companyGUID 总店ID
     * @param shopGUID    门店GUID，如果传递，就进行门店校验，不传就不进行门店校验
     * @param cardNo      卡号
     */
    public static void loadMemberCardDetailsByCardNo(String companyGUID, String shopGUID, String cardNo, IResponse<NewMemberCardDetailsModel> callback) {
        NewMemberCardDetailsRequest request = new NewMemberCardDetailsRequest();
        request.brandId = StringUtil.toInt(companyGUID);
        request.storeId = shopGUID;
        request.cardNo = cardNo;
        request.storeId = shopGUID;
        request.checkOutCard = 1;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberCardDetailsResponse) {
                    NewMemberCardDetailsResponse response = (NewMemberCardDetailsResponse) responseData.responseBean;
                    if (response.data != null) {
                        response.data.addConfig(1);
                    }
                    buildErrorMsg(responseData);
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                buildErrorMsg(responseData);
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    private static void buildErrorMsg(ResponseData responseData) {
        if (responseData.responseBean != null &&
                (responseData.responseBean.errno == 200 || responseData.responseBean.errno == 201 ||
                        responseData.responseBean.errno == 501 || responseData.responseBean.errno == 502) &&
                !TextUtils.isEmpty(responseData.responseBean.errmsg)) {
            responseData.resultMessage = "该卡号不能识别";
        }
    }

    /**
     * 获取会员卡列表，通过手机号
     *
     * @param companyGUID    总店ID
     * @param mobile         手机号
     * @param verifyCode     手机验证码，没有时传空
     * @param verifyCodeType 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
     */
    public static void loadMemberCardListByMobile(String companyGUID, String shopGUID, String mobile, String verifyCode, int verifyCodeType, IResponse<List<NewMemberCardListItemModel>> callback) {
        NewMemberCardListRequest request = new NewMemberCardListRequest();
        request.brandId = StringUtil.toInt(companyGUID);
        request.mobile = mobile;
        request.storeId = shopGUID;
        request.verifyCode = verifyCode;
        request.checkOutCard = 1;
        if (!TextUtils.isEmpty(request.verifyCode)) {
            request.type = verifyCodeType;
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberCardListResponse) {
                    NewMemberCardListResponse response = (NewMemberCardListResponse) responseData.responseBean;
                    List<NewMemberCardListItemModel> cardList = response.data.cardList;
                    if (!ListUtil.isEmpty(cardList)) {
                        for (NewMemberCardListItemModel cardItem : cardList) {
                            cardItem.cardSize = cardList.size();
                        }
                    }
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, processCardListSort(cardList));
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                int errNo = responseData.responseBean == null ? responseData.result : responseData.responseBean.errno;
                callback.callBack(false, errNo, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 处理卡列表的排序，默认卡放到最前面
     *
     * @param originalCardList 原卡列表
     * @return 处理后的卡列表
     */
    private static List<NewMemberCardListItemModel> processCardListSort(List<NewMemberCardListItemModel> originalCardList) {
        if (ListUtil.isEmpty(originalCardList) || originalCardList.size() == 1) {
            return originalCardList;
        }
        List<NewMemberCardListItemModel> newCardList = new ArrayList<>();
        for (int i = 0; i < originalCardList.size(); i++) {
            NewMemberCardListItemModel cardItem = originalCardList.get(i);
            // 默认卡放到最前面
            if (cardItem.isDefault == 1) {
                newCardList.add(cardItem);
                originalCardList.remove(i);
                i--;
            }
        }
        if (!ListUtil.isEmpty(originalCardList)) {
            newCardList.addAll(originalCardList);
        }
        return newCardList;
    }

    /**
     * 将会员绑定到订单上
     *
     * @param dataResponse NewQueryMemberInfoAndBindToOrderResponse
     * @param fsHostId     站点id
     * @param member       会员卡详情
     * @param orderCache   订单
     */
    public static void bindMemberToOrder(NewQueryMemberInfoAndBindToOrderResponse dataResponse,
                                         String fsHostId, NewMemberCardDetailsModel member, OrderCache orderCache, UserDBModel user) {
        if (dataResponse == null) {
            return;
        }
        dataResponse.memberCardModel = member;
        if (member == null || orderCache == null || TextUtils.isEmpty(fsHostId)) {
            return;
        }
        // ServerCache 中缓存 MemberCardModel。下单前绑定会员，使用优惠折扣需要判断是否会员及会员等级等信息
        ServerCache.getInstance().putNewMemberWithHost(fsHostId, member.cardInfo);
        boolean refreshPrice = true;
        if (orderCache.memberInfoS != null && !orderCache.memberInfoS.refreshPrice){
            refreshPrice = false;
        }

        orderCache.setMember(member);

        if (refreshPrice) {
            MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, user == null ? "" : user.fsUserId);
            orderCache.reCalcAllByAll();
        }

        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "ServerMemberApi bindMemberToOrder 将会员绑定到订单");
        //快餐开台绑定会员，没有点菜下单，此时应拦截将订单信息写入tbsell表，不然在账单管理页面可以看到此订单
        if (orderCache.fastFoodModel()) {
            String status = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                    "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderCache.orderID + "'");
            if (!TextUtils.equals("0", status)) {
                OrderProcessor.saveOrder(orderCache, null);
            }
        } else {
            OrderProcessor.saveOrder(orderCache, null);
        }
        if (orderCache.dinnerModel()) {
            dataResponse.orderCache = orderCache;
            // TODO 换接口
            MemberBizUtil.requestMemberComents(member.cardInfo.card_no);
        } else {
            dataResponse.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
            dataResponse.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(orderCache);
            dataResponse.menuItemList.addAll(orderCache.originMenuList);
        }
    }

    /**
     * 旧CardInfo转为新CardInfo
     *
     * @param model 旧CardInfo
     * @return 新CardInfo
     */
    public static NewMemberCardInfoModel convertToNewCardInfoModel(MemberCardInfoModel model) {
        if (model == null) {
            return null;
        }
        NewMemberCardInfoModel memberCardInfo = new NewMemberCardInfoModel();
        memberCardInfo.level = model.level;
        memberCardInfo.image = model.image;
        memberCardInfo.mobile = model.mobile;
        memberCardInfo.gender = model.gender;
        memberCardInfo.birthday = model.birthday;
        memberCardInfo.nick = model.nick;
        memberCardInfo.cs_id = model.cs_id;
        memberCardInfo.card_no = model.card_no;
        memberCardInfo.user_id = model.user_id;
        memberCardInfo.m_shopid = model.m_shopid;
        memberCardInfo.openid = model.openid;
        memberCardInfo.appid = model.appid;
        memberCardInfo.real_name = model.real_name;
        memberCardInfo.add_time = model.add_time;
        memberCardInfo.fmt_cardno = model.fmt_cardno;
        memberCardInfo.level_image = model.level_image;
        memberCardInfo.level_name = model.level_name;
        return memberCardInfo;
    }

    /**
     * 将会员与订单解绑
     *
     * @param orderCache 订单
     */
    public static void unBindMemberFromOrder(OrderCache orderCache, UserDBModel userDBModel) {
        if (orderCache == null) {
            return;
        }
        LogUtil.logBusiness("将订单和会员解绑，订单号：" + orderCache.orderID + "，会员：" + JSON.toJSONString(orderCache.memberInfoS) +
                "，操作人[" + userDBModel.fsUserId + ", " + userDBModel.fsUserName + "]");
        if (orderCache.memberInfoS != null) {
            ServerCache.getInstance().releaseMemberComments(orderCache.memberInfoS.card_no);
        }
        orderCache.clearMember();

        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "ServerMemberApi unBindMemberFromOrder 将会员与订单解绑");
    }

    /**
     * 发送手机验证码
     *
     * @param companyGUID 总店ID
     * @param mobile      手机号
     * @param type        验证码使用场景，1:实体卡激活（只限实体卡激活验证码使用）；2:普通验证码
     */
    public static void sendVerifyCode(String companyGUID, String mobile, int type, IResponse<Boolean> callback) {
        IExecutorCallback iExecutorCallback = new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberVerifyCodeResponse) {
                    NewMemberVerifyCodeResponse response = (NewMemberVerifyCodeResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        };
        NewMemberVerifyCodeRequest request = new NewMemberVerifyCodeRequest();
        request.brandId = StringUtil.toInt(companyGUID);
        request.mobile = mobile;
        request.type = type;
        BusinessExecutor.execute(request, iExecutorCallback, false);
    }

    /**
     * 根据会员卡号获取payCode
     *
     * @param companyGUID 总店GUID
     * @param cardNo      会员卡号
     * @param callback
     */
    public static void getPayCode(String companyGUID, String cardNo, IResponse<NewPayCodeModel> callback) {
        NewGetPayCodeRequest request = new NewGetPayCodeRequest();
        request.brandId = StringUtil.toInt(companyGUID);
        request.cardNo = cardNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof NewGetPayCodeResponse) {
                    NewGetPayCodeResponse response = (NewGetPayCodeResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 根据会员卡号获取payCode，并刷新订单中信息
     * 方法前身--MemberApi.sendRefreshMemberSession，原方法更新了整个会员信息，这里只更新payCode
     *
     * @param orderCache 订单
     * @param cardNo     会员卡号
     * @param callBack
     */
    public static void sendRefreshMemberPayCodeSessionNew(final OrderCache orderCache, final String cardNo, final IResult callBack) {
        NewGetPayCodeRequest request = new NewGetPayCodeRequest();
        request.brandId = StringUtil.toInt(ServerCache.getInstance().fsCompanyGUID);
        request.cardNo = cardNo;

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息", orderCache.orderID, orderCache.fsmtableid, responseData);
                if (responseData.responseBean != null && responseData.responseBean instanceof NewGetPayCodeResponse) {
                    NewGetPayCodeResponse response = (NewGetPayCodeResponse) responseData.responseBean;
                    if (response.errno == SocketResultCode.SUCCESS) {
                        orderCache.updateMemberPayCode(response.data.payCode);
                        OrderSaveDBUtil.upateMemberInfo(orderCache.orderID, JSON.toJSONString(orderCache.memberInfoS));
                    }
                    if (callBack != null) {
                        callBack.callBack(response.errno == SocketResultCode.SUCCESS, response.errmsg);
                    }
                } else {
                    if (callBack != null) {
                        callBack.callBack(false, ERROR_MSG);
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (responseData == null) {
                    if (callBack != null) {
                        callBack.callBack(false, ERROR_MSG);
                    }
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (callBack != null) {
                    callBack.callBack(false, responseData.resultMessage);
                }
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息失败", orderCache.orderID, orderCache.fsmtableid, responseData);
                return false;
            }
        });
        job.execute();
    }

    /**
     * 会员验券
     * 功能：核销美团团购券
     * 只有会员绑定上了美团，才能使用到该功能，故没有方法测试，先不对接
     *
     * @param sn
     * @param num
     * @param type
     */
    public static void checkGroupTicket(String sn, int num, String type, IResponse<NewGroupTicketUseModel> callback) {
        NewGroupTicketUseRequest request = new NewGroupTicketUseRequest();
        request.device_id = BizConstant.DEVICE_ID;
        request.sn = sn;
        request.num = num;
        request.type = type;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof NewGroupTicketUseResponse) {
                    NewGroupTicketUseResponse response = (NewGroupTicketUseResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        });
    }

    /**
     * 会员修改密码
     */
    public static void changeMemberPsw(String brandId, String cardNo, String password, IResponse<Boolean> callback) {
        MemberChangePswRequest request = new MemberChangePswRequest();
        request.brandId = brandId;
        request.password = password;
        request.cardNo = cardNo;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, false);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null) {
                    callback.callBack(responseData.responseBean.errno == SocketResultCode.SUCCESS, responseData.responseBean.errno, responseData.responseBean.msg, true);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, false);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, false);
                return false;
            }
        }, false);
    }

    public static void queryRechargePackage(String brandId, String cardNo, String csId, int level, IResponse<MemberRechargePackageModel> callback) {
        MemberRechargePackageRequest request = new MemberRechargePackageRequest();
        request.brandId = brandId;
        request.cardNo = cardNo;
        request.csId = csId;
        request.level = level;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberRechargePackageResponse) {
                    MemberRechargePackageResponse response = (MemberRechargePackageResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 会员充值
     *
     * @param companyGuid
     * @param cardNo
     * @param payMicro
     * @param ruleId
     * @param buyAmount
     * @param payType
     * @param callback
     */
    public static void memberRecharge(String companyGuid, String cardNo, String payMicro, String ruleId, BigDecimal buyAmount, int payType, IResponse<MemberRechargeResultModel> callback) {

        final NewPayCodeModel payCodeModel = new NewPayCodeModel();

        getPayCode(companyGuid, cardNo, new IResponse<NewPayCodeModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, NewPayCodeModel info) {
                if (result && info != null && !TextUtils.isEmpty(info.payCode)) {
                    payCodeModel.payCode = info.payCode;
                } else {
                    callback.callBack(false, code, msg, null);
                }
            }
        });

        List<BaseRequest> list = new ArrayList<>();
        MemberRechargeRequest request = new MemberRechargeRequest();
        request.cardNo = payCodeModel.payCode;
        request.paySourceId = 105;
        request.payName = "Android-" + DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsshopName from tbshop ");
        request.deviceId = ServerHardwareUtil.getHardWareSymbol();
        request.payMicro = payMicro;
        request.ruleId = ruleId;
        request.buyAmount = Calc.format(buyAmount, 0, RoundingMode.DOWN).floatValue();
        request.payClass = payType;
        request.payType = MemberRechargePayTypeDefined.getPayTypeStr(payType);

        list.add(request);

        MemberRechargeResultRequest resultRequest = new MemberRechargeResultRequest();
        resultRequest.companyGuid = companyGuid;
        list.add(resultRequest);

        for (int i = 0; i < 18; i++) {
            list.add(resultRequest.clone());
        }

        final String[] trade_no = {""};
        final long start = SystemClock.elapsedRealtime();

        BusinessExecutor.execute(list, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                boolean shouldContinue = false;
                if (responseData.responseBean != null) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值:" + responseData.responseBean.toString());

                    MemberRechargeResultResponse response = (MemberRechargeResultResponse) responseData.responseBean;
                    if (response.data != null) {

                        if (TextUtils.isEmpty(trade_no[0])) {
                            trade_no[0] = response.data.trade_no;
                            MemberRechargeResultRequest request;
                            for (int j = 1; j < list.size(); j++) {
                                request = (MemberRechargeResultRequest) list.get(j);
                                request.trade_no = trade_no[0];
                            }
                        }
                        //101=>发起交易  102=>等待确认   103=>等待付款    104=>交易/支付完成   105=>退款
                        if (response.data.status == 105) {
                            shouldContinue = false;
                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 失败" + response.data.toString());
                            if (callback != null) {
                                callback.callBack(false, 2, "充值失败", null);
                            }
                            updateMemberRechargeJob(trade_no[0]);
                        } else if (response.data.status == 104) {
                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 成功," + response.data.toString());
                            shouldContinue = false;
                            if (callback != null) {
                                if (response.data != null && TextUtils.isEmpty(response.data.trade_no)) {
                                    response.data.trade_no = trade_no[0];
                                }
                                callback.callBack(true, 0, "", response.data);
                            }
                            updateMemberRechargeJob(trade_no[0]);
                        } else {
                            //充值中
                            addMemberRechargeJob(trade_no[0], companyGuid);
                            if (i == list.size() - 1) {
                                shouldContinue = false;
                                if (callback != null) {
                                    if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                        response.data.trade_no = trade_no[0];
                                    }
                                    callback.callBack(true, 0, "支付中,请点击[重试]", response.data);
                                }
                            } else {
                                shouldContinue = true;
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 进行中。。。" + response.data.toString());
                                if (i != 0) {
                                    SystemClock.sleep(i * 400);
                                }
                            }
                        }
                    }

                }
                return shouldContinue;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                long out = SystemClock.elapsedRealtime() - start;
                //耗时超过3.5秒，则报警
                if (out > 3500) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, String.valueOf(out) + responseData.responseBean);
                }
                if (i == 0) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值" + responseData);
                } else {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "查询充值结果" + responseData);
                }
                if (i == list.size() - 1) {
                    if (callback != null) {
                        String msg = responseData.responseBean == null ? "充值失败" : responseData.responseBean.errmsg;
                        callback.callBack(false, 2, msg, null);
                    }
                } else {
                    if (i != 0) {
                        SystemClock.sleep(i * 400);
                    }
                    return true;
                }

                return false;
            }
            //此处，需要明确传false进行阻塞
        }, false);
    }

    private static void addMemberRechargeJob(String tradeNo, String companyGuid) {
        if (android.text.TextUtils.isEmpty(tradeNo)) {
            return;
        }
        //  会员充值添加Job
        Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType.MEMBER_RECHARGE_QUERY_RESULT + "' AND biz_key = '" + tradeNo + "'", Job.class);
        if (job == null) {
            job = new Job();
            job.type = JobType.NEW_MEMBER_RECHARGE_QUERY_RESULT;
            job.biz_key = tradeNo;
            job.info = companyGuid;
            job.cycle = 3;
            job.cycle_count = 2;
            JobScheudler.newJob(job);
        } else {
            job.updateJobPrepared();
        }
    }

    /**
     * 更新会员充值Job
     *
     * @param tradeNo 交易号
     */
    public static void updateMemberRechargeJob(String tradeNo) {
        if (android.text.TextUtils.isEmpty(tradeNo)) {
            return;
        }
        Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType.NEW_MEMBER_RECHARGE_QUERY_RESULT + "' AND biz_key = '" + tradeNo + "'", Job.class);
        if (job != null) {
            job.updateJobFinished();
        }
    }

    public static void queryPayResult(String tradeNo, String companyGuid, IResponse<MemberRechargeResultModel> callback) {
        MemberRechargeResultRequest resultRequest = new MemberRechargeResultRequest();
        resultRequest.companyGuid = companyGuid;
        resultRequest.trade_no = tradeNo;
        BusinessExecutor.execute(resultRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberRechargeResultResponse) {
                    MemberRechargeResultResponse response = (MemberRechargeResultResponse) responseData.responseBean;
                    callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.msg, response.data);
                } else {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 开始处理会员相关的抵扣，包括：
     * 1，抵扣消费券
     */
    public static void memberConsumeTickets(OrderCache orderCache, PaySession session, IResponse<NewMemberOrderConsumeRequest> callback) {
        if (orderCache == null || orderCache.memberInfoS == null) {
            return;
        }
        // 检查payCode
        if (TextUtils.isEmpty(orderCache.memberInfoS.pay_code)) {
            ServerMemberApi.sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        memberConsumeTickets(orderCache, session, callback);
                    } else {
                        if (callback != null) {
                            callback.callBack(false, ERROR_CODE, info, null);
                        }
                    }
                }
            });
            return;
        }

        // 优惠券列表
        final List<PayModel> memberTicketList = new ArrayList<>();
        // 会员订单号
        String memberOrderID = "";

        //秒付里包含的会员储值总额
        BigDecimal balanceAmt = BigDecimal.ZERO;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "开始处理会员券相关的抵扣");
        try {
            if (!ListUtil.isEmpty(session.selectPayListFull)) {
                for (PayModel temp : session.selectPayListFull) {
                    if (temp.status != PayTypeStatus.DELETE) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            if (temp.checkMemberConsumed()) {
                                LogUtil.logBusiness(orderCache.orderID + " 积分已抵扣过:" + JSON.toJSONString(temp));
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (temp.checkMemberConsumed()) {
                                LogUtil.logBusiness(orderCache.orderID + " 美味会员的优惠券已抵扣过:" + JSON.toJSONString(temp));
                            } else {
                                memberTicketList.add(temp);
                                if (TextUtils.isEmpty(temp.memberOrderID)) {
                                    memberOrderID = temp.memberOrderID;
                                }
                            }
                        }
                        if (PayType.isMWMemberBalance(temp.data)) {
                            balanceAmt = balanceAmt.add(temp.payAmount);
                        }
                    }
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "开始处理会员券相关的抵扣");
        }

        if (ListUtil.isEmpty(memberTicketList)) {
            if (callback != null) {
                callback.callBack(true, SocketResultCode.SUCCESS, "", null);
            }
            return;
        }

        if (TextUtils.isEmpty(memberOrderID)) {
            memberOrderID = OrderUtil.buildNetOrderID(orderCache.shopID, session.billNO);
        }

        BigDecimal totalCalc = PayUtil.calcPayCalc(session);

        NewMemberOrderConsumeRequest request = buildMemberOrderConsumeRequest(session, orderCache,
                memberOrderID, balanceAmt, BigDecimal.ZERO, 0, BigDecimal.ZERO,
                PayUtil.getMemberTicketCodeList(memberTicketList), PayUtil.getMemberTicketInfoList(memberTicketList),
                null);

        session.memberCardNO = orderCache.memberInfoS.card_no;
        session.memberRealAmt = totalCalc;

        String finalMemberOrderID = memberOrderID;
        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "OrderBizUtil#startMemberConsume----" + session.orderID + "----------会员回调-- 支付业务中心-");

                if (responseData == null) {
                    if (callback != null) {
                        callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    }
                    return false;
                }

                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_SUCCESS, "会员券抵扣成功", session.orderID, "", responseData.resultMessage);

                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    int fatherSeq = -1;
                    for (PayModel temp : memberTicketList) {
                        if (fatherSeq == -1) {
                            fatherSeq = temp.seq;
                        } else {
                            temp.seq_M = fatherSeq;
                        }
                        temp.writeMemberConsumed();
                        temp.memberOrderID = finalMemberOrderID;
                        temp.ticketCode = temp.data.memberCouponModel.code;
                    }
                    if (response.data != null) {
                        session.memberGiftScore = response.data.incr_score;
                    }
                    OrderSession.getInstance().writePay(orderCache.orderID, session);
                    if (callback != null) {
                        callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, request);
                    }
                } else {
                    if (callback != null) {
                        callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    //如果是明确的业务失败，则清除掉缓存的订单号
                    if (response.status != 0) {
                        for (PayModel temp : memberTicketList) {
                            temp.memberOrderID = "";
                        }
                    }
                }
                if (callback != null) {
                    callback.callBack(false, responseData.result, responseData.resultMessage, request);
                }
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_FAIL, "会员券抵扣失败", session.orderID, "", responseData.resultMessage);
                return false;
            }
        });
        job.execute();
    }

    /**
     * 开始处理会员相关的抵扣，包括：
     * 1，抵扣积分
     * 2，抵扣消费券
     */
    public static void memberConsume(OrderCache orderCache, PaySession session, PayModel selectPay, IResponse<NewMemberOrderConsumeRequest> callback) {
        if (selectPay == null || orderCache == null || session == null) {
            return;
        }

        // 检查payCode
        if (TextUtils.isEmpty(orderCache.memberInfoS.pay_code)) {
            ServerMemberApi.sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        memberConsume(orderCache, session, selectPay, callback);
                    } else {
                        if (callback != null) {
                            callback.callBack(false, ERROR_CODE, info, null);
                        }
                    }
                }
            });
            return;
        }

        boolean noConsume = selectPay.memberCostScore == 0 && TextUtils.isEmpty(selectPay.ticketCode);
        if (noConsume) {
            selectPay.writeMemberConsumed();
            if (callback != null) {
                callback.callBack(true, SocketResultCode.SUCCESS, "", null);
            }
            return;
        }

        //秒付里包含的会员储值总额
        BigDecimal balanceAmt = BigDecimal.ZERO;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的抵扣");
        try {
            if (!ListUtil.isEmpty(session.selectPayListFull)) {
                for (PayModel temp : session.selectPayListFull) {
                    if (temp.status != PayTypeStatus.DELETE) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            if (temp.checkMemberConsumed()) {
                                LogUtil.logBusiness(orderCache.orderID + " 积分已抵扣过:" + JSON.toJSONString(temp));
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (temp.checkMemberConsumed()) {
                                LogUtil.logBusiness(orderCache.orderID + " 美味会员的优惠券已抵扣过:" + JSON.toJSONString(temp));
                            }
                        }
                        if (PayType.isMWMemberBalance(temp.data)) {
                            balanceAmt = balanceAmt.add(temp.payAmount);
                        }
                    }
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的抵扣");
        }

        if (TextUtils.isEmpty(selectPay.memberOrderID)) {
            selectPay.memberOrderID = OrderUtil.buildNetOrderID(orderCache.shopID, session.billNO);
        }
        String memberOrderID = selectPay.memberOrderID;

        BigDecimal totalCalc = PayUtil.calcPayCalc(session);

        // 是否使用积分
        int useScore = 0;
        // 积分抵扣金额
        BigDecimal scoreMoney = BigDecimal.ZERO;
        // 积分支付
        if (PayType.isMWMemberPoint(selectPay.data) && selectPay.checkMemberLoginPay() && !selectPay.checkMemberConsumed()) {
            useScore = selectPay.memberCostScore;
            scoreMoney = selectPay.payAmount;
        }

        NewMemberOrderConsumeRequest request = buildMemberOrderConsumeRequest(session, orderCache,
                memberOrderID, balanceAmt, BigDecimal.ZERO, useScore, scoreMoney,
                PayUtil.getMemberTicketCodeList(selectPay), PayUtil.getMemberTicketInfoList(selectPay),
                null);

        session.memberCardNO = orderCache.memberInfoS.card_no;
        session.memberRealAmt = totalCalc;

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "OrderBizUtil#startMemberConsume----" + session.orderID + "----------会员回调-- 支付业务中心-");

                if (responseData == null) {
                    if (callback != null) {
                        callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    }
                    return false;
                }

                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_SUCCESS, "会员抵扣成功", session.orderID, "", responseData.resultMessage);

                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    selectPay.writeMemberConsumed();
                    selectPay.memberOrderID = memberOrderID;
//                    session.memberConsumed = true;
                    OrderSession.getInstance().writePay(orderCache.orderID, session);
                    if (callback != null) {
                        callback.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, request);
                    }
                } else {
                    if (callback != null) {
                        callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (responseData == null) {
                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    //如果是明确的业务失败，则清除掉缓存的订单号
                    if (response.status != 0) {
                        selectPay.memberOrderID = "";
                    }
                }
                if (callback != null) {
                    callback.callBack(false, responseData.result, responseData.resultMessage, request);
                }
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_FAIL, "会员抵扣失败", session.orderID, "", responseData.resultMessage);
                return false;
            }
        });
        job.execute();
    }

    /**
     * 开始处理会员相关的赠送，包括：
     * 1，赠送积分
     * 2，赠送消费券
     */
    public static void memberGift(final PaySession session, OrderCache orderCache, final MemberProcessResult resultListener) {
        if (!orderCache.isMember) {
            if (resultListener != null) {
                resultListener.callBack(true, "", true, null);
            }
            return;
        }

        // 检查payCode
        if (TextUtils.isEmpty(orderCache.memberInfoS.pay_code)) {
            OrderCache finalOrderCache = orderCache;
            ServerMemberApi.sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        memberGift(session, finalOrderCache, resultListener);
                    } else {
                        resultListener.callBack(false, info, true, null);
                    }
                }
            });
            return;
        }

        //订单号
        String memberOrderID = "";
        //实收金额
        BigDecimal totalCalc = BigDecimal.ZERO;
        //秒付里包含的会员储值总额
        BigDecimal balanceAmt = BigDecimal.ZERO;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的赠送");
        try {
            orderCache = OrderSession.getInstance().getOrder(orderCache.orderID);

            if (!ListUtil.isEmpty(session.selectPayListFull)) {
                totalCalc = PayUtil.calcPayCalc(session);
                for (PayModel temp : session.selectPayListFull) {
                    if (temp.status != PayTypeStatus.DELETE) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            if (!temp.checkMemberConsumed()) {
                                if (TextUtils.isEmpty(temp.memberOrderID)) {
                                    memberOrderID = temp.memberOrderID;
                                }
                            } else {
                                LogUtil.logBusiness(orderCache.orderID + " 积分已抵扣过:" + JSON.toJSONString(temp));
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (!temp.checkMemberConsumed()) {
                                if (TextUtils.isEmpty(temp.memberOrderID)) {
                                    memberOrderID = temp.memberOrderID;
                                }
                            } else {
                                LogUtil.logBusiness(orderCache.orderID + " 美味会员的优惠券已抵扣过:" + JSON.toJSONString(temp));
                            }
                        }
                        if (PayType.isMWMemberBalance(temp.data)) {
                            balanceAmt = balanceAmt.add(temp.payAmount);
                        }
                    }
                }
            } else {
                if (resultListener != null) {
                    resultListener.callBack(true, "", true, null);
                }
                return;
            }
            if (TextUtils.isEmpty(memberOrderID)) {
                memberOrderID = session.memberOrderID;
            }
            if (!TextUtils.isEmpty(session.memberOrderID) && session.memberConsumed) {
                if (resultListener != null) {
                    resultListener.callBack(true, "订单已抵扣过", true, null);
                }
                return;
            }
            if (TextUtils.isEmpty(memberOrderID)) {
                memberOrderID = OrderUtil.buildNetOrderID(orderCache.shopID, session.billNO);
                session.memberOrderID = memberOrderID;
            }
            session.memberCardNO = orderCache.memberInfoS.card_no;
            session.memberRealAmt = totalCalc;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的赠送");
        }

        NewMemberOrderConsumeRequest request = buildMemberOrderConsumeRequest(session, orderCache,
                memberOrderID, balanceAmt, PayUtil.checkForMemberCalcPaid(session), 0, BigDecimal.ZERO,
                null, null, buildActualPayType(session.selectPayListFull));

        resultListener.callBack(true, "", true, request);
    }

    /**
     * 构建会员积分/优惠券消费请求
     *
     * @param session       PaySession
     * @param orderCache    OrderCache
     * @param memberOrderID String | 会员订单Id
     * @param balanceAmt    BigDecimal | 秒付里包含的会员储值总额
     * @param realAmt       BigDecimal | 订单实收
     * @param useScore      int | 使用的积分
     * @param scoreMoney    BigDecimal | 积分抵扣金额
//     * @param selectPayList List<PayModel> | 选择的支付方式，用来获取 使用的优惠券code列表
     * @return
     */
    private static NewMemberOrderConsumeRequest buildMemberOrderConsumeRequest(PaySession session, OrderCache orderCache,
                                                                               String memberOrderID, BigDecimal balanceAmt,
                                                                               BigDecimal realAmt, int useScore, BigDecimal scoreMoney,
                                                                               List<String> ticketCodeList, List<JSONObject> ticketInfoList,
                                                                               List<Integer> actualPayType) {
        NewMemberOrderConsumeRequest request = new NewMemberOrderConsumeRequest();
        request.brandId = ServerCache.getInstance().fsCompanyGUID;
        request.cardNo = orderCache.memberInfoS.pay_code;
        //新增外部订单字段 存储订单id
        request.outerOrderId = orderCache.orderID;
        request.secOrderId = OrderBizUtil.optValiedRapidPayId(session);
        request.antiPaied = orderCache.inAntiPaied();
        request.payType = 1;
        request.orderId = memberOrderID;

        request.orderAmount = orderCache.optTotalPrice();
        BigDecimal totalCalc = PayUtil.calcPayCalc(session);
        request.dropAmount = totalCalc.subtract(PayUtil.getDiscountAmtByLeftToPay(session, orderCache));
        if (request.dropAmount.compareTo(BigDecimal.ZERO) < 0) {
            request.dropAmount = BigDecimal.ZERO;
        }
        request.spayCardAmount = balanceAmt;

        request.useScore = useScore;
        request.scoreMoney = scoreMoney;
        request.coupons = ticketCodeList;
        request.amount = realAmt;
        if (request.amount.compareTo(BigDecimal.ZERO) < 0) {
            request.amount = BigDecimal.ZERO;
            request.orderActualAmount = BigDecimal.ZERO;
        }else {
            request.orderActualAmount = PayUtil.checkForMemberCalcPaidNotContainMember(session);
        }

        // ----- 3.5.2.546新增字段赋值 start -----
        request.orderTotalAmount = orderCache.optTotalPrice();


        request.actualPayType = actualPayType;
        request.useCouponList = ticketInfoList;
        // ----- 3.5.2.546新增字段赋值 end -----

        return request;
    }

    /**
     * 构建实付使用方式
     * 只算除了优惠券、会员储值、积分抵扣以外的支付方式，且不读后台"是否计入实收"的配置
     *
     * @param payModelList 支付方式列表
     * @return 实付使用方式列表
     */
    private static List<Integer> buildActualPayType(List<PayModel> payModelList) {
        // 实付使用方式，1 微信 2 支付宝 3 现金 4 银行卡 5 其他
        List<Integer> payTypeList = new ArrayList<>();
        if (ListUtil.isEmpty(payModelList)) {
            return payTypeList;
        }
        for (PayModel payModel : payModelList) {
            if (payModel == null) {
                continue;
            }
            PayOriginModel payData = payModel.data;
            // 优惠券、会员储值、积分抵扣除外
            if (PayType.isMWMemberTicket(payData) || PayType.isMWMemberPoint(payData) || PayType.isMWMemberBalance(payData)) {
                continue;
            }
            if (PayType.isWeixin(payData)) {
                if (!payTypeList.contains(1)) {
                    payTypeList.add(1);
                }
            } else if (PayType.isAli(payData)) {
                if (!payTypeList.contains(2)) {
                    payTypeList.add(2);
                }
            } else if (PayType.isCash(payData)) {
                if (!payTypeList.contains(3)) {
                    payTypeList.add(3);
                }
            } else if (PayType.isCard(payData)) {
                if (!payTypeList.contains(4)) {
                    payTypeList.add(4);
                }
            } else {
                if (!payTypeList.contains(5)) {
                    payTypeList.add(5);
                }
            }
        }
        return payTypeList;
    }
}
