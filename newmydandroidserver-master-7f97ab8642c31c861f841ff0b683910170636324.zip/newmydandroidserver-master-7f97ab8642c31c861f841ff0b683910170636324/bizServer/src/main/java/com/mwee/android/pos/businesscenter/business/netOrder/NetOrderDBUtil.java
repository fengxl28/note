package com.mwee.android.pos.businesscenter.business.netOrder;

import android.text.TextUtils;
import android.util.Pair;
import android.util.SparseArray;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderMappingInfo;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/3/22.
 */

public class NetOrderDBUtil {

    /**
     * 获取所有网络订单
     * strftime('%Y%m%d', date)
     *
     * @param date 日期yyyy-MM-dd
     * @return
     */
    public static List<TempAppOrder> getAllOrdersForKDS(int currentPage, String date, String source) {
        List<TempAppOrder> tempAppOrderList = new ArrayList<>();
        String params = "";

        if (!TextUtils.isEmpty(date)) {
            params = " and date like '" + date + "%'";
        }
        if (!TextUtils.isEmpty(source)) {
            if (TextUtils.isEmpty(params)) {
                if (source.startsWith(TakeAwaySource.ELEME) || source.startsWith(TakeAwaySource.MEITUAN)) {
                    params = " and orderTakeawaySource like '%" + source + "%' ";
                } else {
                    params = " and orderTakeawaySource not in ('ELEME', 'ELEME2', 'MEITUAN', 'MEITUAN2', 'MWMEITUAN') ";
                }
            } else {
                if (source.startsWith(TakeAwaySource.ELEME) || source.startsWith(TakeAwaySource.MEITUAN)) {
                    params = params + " and orderTakeawaySource like '%" + source + "%' ";
                } else {
                    params = params + " and orderTakeawaySource not in ('ELEME','ELEME2', 'MEITUAN', 'MEITUAN2', 'MWMEITUAN') ";
                }
            }
        }
        params = " where bizType <> '-1' " + params + " order by date desc ";
        String sql = "select * from " + DBModel.getTableName(TempAppOrder.class) + params;
        int offset = (currentPage - 1) * 30;//偏移量
        sql = sql + " limit 30 offset " + offset;
        LogUtil.logBusiness("--------getAllOrdersForKDS--------" + sql + "------------");
        List<TempAppOrder> tempAppOrders = DBSimpleUtil.queryList(APPConfig.DB_NET_ORDER, sql, TempAppOrder.class);

        String inKdsState = "select DISTINCT fssellno from tbKdsMenuItemState where fistate not in ('3', '4', '5') ";
        List<String> stateSellNos = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, inKdsState);

        List<TempAppOrder> orderList = new ArrayList<>();
        for (TempAppOrder order : tempAppOrders) {
            if (order.orderStatus == NetworkConstans.ORDER_STATUS_CHECK
                    || order.orderStatus == NetworkConstans.ORDER_STATUS_KDS
                    || order.diningStatus == NetworkConstans.DINING_STATUS_KOT
                    || order.diningStatus == NetworkConstans.DINING_STATUS_GET) {
                for (String sellNo : stateSellNos) {
                    if (order.orderId.equals(sellNo)) {
                        TempAppOrder appOrder = JSON.parseObject(order.body, TempAppOrder.class);
                        if (appOrder != null) {
                            order.restNum = appOrder.restNum;
                        }

                        orderList.add(order);
                        break;
                    }
                }
            }
        }

        return orderList;
    }

    /**
     * 获取所有网络订单
     * strftime('%Y%m%d', date)
     *
     * @param date 日期yyyy-MM-dd
     * @return
     */
    public static Pair<Integer, List<TempAppOrder>> getAllOrders(int currentPage, String date, String source) {
        List<TempAppOrder> tempAppOrderList = new ArrayList<>();
        String params = "";

        if (!TextUtils.isEmpty(date)) {
            params = " and date like '" + date + "%'";
        }
        if (!TextUtils.isEmpty(source)) {
            if (TextUtils.isEmpty(params)) {
                if (source.startsWith(TakeAwaySource.ELEME) || source.startsWith(TakeAwaySource.MEITUAN)) {
                    params = " and orderTakeawaySource like '%" + source + "%' ";
                } else {
                    params = " and orderTakeawaySource not in ('ELEME', 'ELEME2', 'MEITUAN', 'MEITUAN2', 'MWMEITUAN') ";
                }
            } else {
                if (source.startsWith(TakeAwaySource.ELEME) || source.startsWith(TakeAwaySource.MEITUAN)) {
                    params = params + " and orderTakeawaySource like '%" + source + "%' ";
                } else {
                    params = params + " and orderTakeawaySource not in ('ELEME','ELEME2', 'MEITUAN', 'MEITUAN2', 'MWMEITUAN') ";
                }
            }
        }
        params = " where bizType <> '-1' " + params + " order by date desc ";
        String sql = "select * from " + DBModel.getTableName(TempAppOrder.class) + params;
        int offset = (currentPage - 1) * 30;//偏移量
        sql = sql + " limit 30 offset " + offset;
        List<TempAppOrder> tempAppOrders = DBSimpleUtil.queryList(APPConfig.DB_NET_ORDER, sql, TempAppOrder.class);
        if (tempAppOrders == null) {
            return new Pair<>(0, tempAppOrderList);
        }
        for (TempAppOrder appOrder : tempAppOrders) {
            try {
                if (appOrder == null) {
                    continue;
                }
                if (APPConfig.isCasiher()) {
                    appOrder = parsingNetOrder(appOrder);
                } else {
                    appOrder = parsingSimpleNetOrder(appOrder);
                }
                if (appOrder != null) {
                    tempAppOrderList.add(appOrder);
                }
            } catch (Exception e) {
                LogUtil.logError("网络订单转化异常：" + JSON.toJSONString(appOrder) + "   ----   错误信息：" + e.getMessage());
            }
        }

        List<String> turnErrOrders = optTurnErrOrderIdList();
        if (!ListUtil.isEmpty(turnErrOrders)) {
            for (String id : turnErrOrders) {
                for (TempAppOrder appOrder : tempAppOrderList) {
                    if (TextUtils.equals(String.valueOf(appOrder.orderId), id)) {
                        appOrder.turnToReportErrStatus = -1;
                        continue;
                    }
                }
            }
        }

        String countStr = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select count(*) from tempapporder " + params);
        int dataCount = StringUtil.toInt(countStr, 0);
        return new Pair<>(dataCount, tempAppOrderList);
    }

    public static List<String> optTurnErrOrderIdList() {
        String sql = "select key from datacache where info <> '1' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "'";
        List<String> orderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (orderIdList == null) {
            orderIdList = new ArrayList<>();
        }
        return orderIdList;
    }


    /**
     * @param date
     * @param source
     * @return
     */
    public static Pair<Integer, List<TempAppOrderSimpleInfo>> getElemeAndMeituanAllOrders(int currentPage, String date, String source, String sellNo) {
        String params = "";

        if (!TextUtils.isEmpty(date)) {
            params = " and date like '" + date + "%'";
        }
        if (TextUtils.isEmpty(source) || TextUtils.equals("-1", source) || TextUtils.equals("all", source)) {
            params = params + " and orderTakeawaySource in ('ELEME', 'ELEME2', 'MEITUAN', 'MEITUAN2', 'MWEE', 'MWMEITUAN') ";
        } else {
            params = params + " and orderTakeawaySource like '%" + source + "%' ";
        }

        if (!TextUtils.isEmpty(sellNo)) {
            params = params + " and orderId='" + sellNo + "' ";
        }
        params = "where bizType = '4' " + params + " order by date desc ";

        String sql = "select * from tempapporder  " + params;
        int offset = (currentPage - 1) * 20;//偏移量
        sql = sql + " limit 20 offset " + offset;
        List<TempAppOrderSimpleInfo> tempAppOrders = DBSimpleUtil.queryList(APPConfig.DB_NET_ORDER, sql, TempAppOrderSimpleInfo.class);
        if (tempAppOrders == null) {
            return new Pair<>(0, new ArrayList<>());
        }

        String countStr = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select count(*) from tempapporder " + params);
        int dataCount = StringUtil.toInt(countStr, 0);
        return new Pair<>(dataCount, tempAppOrders);
    }

    /**
     * 根据订单号搜索网络订单列表 -- 纯拉取本地库里的网络订单
     *
     * @param date
     * @param source
     * @return
     */
    public static List<TempAppOrderSimpleInfo> getSearchElemeAndMeituanAllOrders(String date, String source, String sellNo) {
        String params = "";

        if (!TextUtils.isEmpty(date)) {
            params = " and date like '" + date + "%'";
        }
        if (TextUtils.isEmpty(source) || TextUtils.equals("-1", source) || TextUtils.equals("all", source)) {
            params = params + " and orderTakeawaySource in ('ELEME', 'ELEME2', 'MEITUAN', 'MEITUAN2', 'MWEE', 'MWMEITUAN') ";
        } else {
            params = params + " and orderTakeawaySource like '%" + source + "%' ";
        }

        if (!TextUtils.isEmpty(sellNo)) {
            params = params + " and orderId like '%" + sellNo + "%'";
        }

        String sql = "select * from tempapporder  where bizType = '4' " + params + " order by createTime desc ";
        List<TempAppOrderSimpleInfo> tempAppOrders = DBSimpleUtil.queryList(APPConfig.DB_NET_ORDER, sql, TempAppOrderSimpleInfo.class);
        if (tempAppOrders == null) {
            return new ArrayList<>();
        }
        return tempAppOrders;
    }

//    /**
//     * 获取未匹配成功的订单数据
//     *
//     * @return
//     */
//    public static LinkedHashMap<String, String> optUnMappingOrderMap() {
//        LinkedHashMap<String, String> unMappingOrders = new LinkedHashMap<>();
//        // 未结账的外卖订单
//        String sqlNotPayed = "SELECT thirdOrderId key, order_id info FROM order_cache WHERE fiSellType = '2' AND " +
//                "order_status = '1' AND business_date = '" + HostUtil.getHistoryBusineeDate("") + "'";
//        List<CacheModel> orderCacheList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlNotPayed, CacheModel.class);
//        if (!ListUtil.isEmpty(orderCacheList)) {
//            for (CacheModel model : orderCacheList) {
//                if (model != null && !TextUtils.isEmpty(model.key) && !TextUtils.isEmpty(model.info)) {
//                    unMappingOrders.put(model.key, model.info);
//                }
//            }
//        }
//
//        return unMappingOrders;
//    }

    /**
     * 获取未匹配成功的订单数据
     *
     * @return
     */
    public static LinkedHashMap<String, TempAppOrderMappingInfo> optUnMappingOrderMapV2() {
        LinkedHashMap<String, TempAppOrderMappingInfo> unMappingOrders = new LinkedHashMap<>();

        String querySql = "select cache.value unMappingCount, orderCache.* from (select key, value from datacache where value > 0 and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "') cache left join " +
                " (SELECT thirdOrderId , order_id orderId, order_status orderStatus, 1 mappingStatus FROM order_cache WHERE fiSellType = '2' " +
                "AND business_date = '" + HostUtil.getHistoryBusineeDate("") + "') orderCache on orderCache.thirdOrderId = cache.key";

        List<TempAppOrderMappingInfo> mappingInfoList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, querySql, TempAppOrderMappingInfo.class);
        if (!ListUtil.isEmpty(mappingInfoList)) {

            for (TempAppOrderMappingInfo model : mappingInfoList) {
                unMappingOrders.put(model.thirdOrderId, model);
            }
        }
        return unMappingOrders;
    }

//    /**
//     * 获取未匹配成功的订单数据
//     *
//     * @return
//     */
//    public static LinkedHashMap<String, String> optUnMappingOrderMapV2() {
//        LinkedHashMap<String, String> unMappingOrders = new LinkedHashMap<>();
//
//        String sql = "select key from datacache where value > 0 and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "'";
//        List<String> thirdOrderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
//        if (ListUtil.isEmpty(thirdOrderIdList)) {
//            return unMappingOrders;
//        }
//        String sqlParam = ListUtil.optSqlParams(thirdOrderIdList);
//
//        String sqlNotPayed = "SELECT thirdOrderId key, order_id info FROM order_cache WHERE fiSellType = '2' " +
//                "AND business_date = '" + HostUtil.getHistoryBusineeDate("") + "'" +
//                "AND thirdOrderId in (" + sqlParam + ")";
//
//        List<CacheModel> orderCacheList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlNotPayed, CacheModel.class);
//        if (!ListUtil.isEmpty(orderCacheList)) {
//            for (CacheModel model : orderCacheList) {
//                if (model != null && !TextUtils.isEmpty(model.key) && !TextUtils.isEmpty(model.info)) {
//                    unMappingOrders.put(model.key, model.info);
//                }
//            }
//        }
//
//        return unMappingOrders;
//    }

    /**
     * 获取不能成功如报表的的订单数据
     *
     * @return
     */
    public static LinkedHashMap<String, TempAppOrderMappingInfo> optUnTurnedOrderList() {
        LinkedHashMap<String, TempAppOrderMappingInfo> unMappingOrders = new LinkedHashMap<>();
        String querySql = "select key thirdOrderId, 0 mappingStatus from datacache where type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "' and info <> '1' ";
        List<TempAppOrderMappingInfo> mappingInfoList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, querySql, TempAppOrderMappingInfo.class);
        if (!ListUtil.isEmpty(mappingInfoList)) {

            for (TempAppOrderMappingInfo model : mappingInfoList) {
                unMappingOrders.put(model.thirdOrderId, model);
            }
        }
        return unMappingOrders;
    }

    /**
     * 获取映射成功的订单数据
     *
     * @param date   日期(自然日)
     * @param source
     * @return
     */
    public static LinkedHashMap<String, String> optMappingOrderMap(String date, String source) {
        LinkedHashMap<String, String> mappingOrdersMap = new LinkedHashMap<>();


        String params = "";

        if (!TextUtils.isEmpty(date)) {
            params = " and date like '" + date + "%'";
        }
        if (TextUtils.isEmpty(source) || TextUtils.equals("-1", source) || TextUtils.equals("all", source)) {
            params = params + " and orderTakeawaySource in ('ELEME', 'ELEME2', 'MEITUAN', 'MEITUAN2', 'MWEE', 'MWMEITUAN') ";
        } else {
            params = params + " and orderTakeawaySource like '%" + source + "%' ";
        }

        String sql = "select orderId from tempapporder  where bizType = '4' " + params + " order by createTime desc ";
        List<String> tempAppOrderIds = DBSimpleUtil.queryStringList(APPConfig.DB_NET_ORDER, sql);
        if (ListUtil.isEmpty(tempAppOrderIds)) {
            return mappingOrdersMap;
        }

        String orderIdParams = ListUtil.optSqlParams(tempAppOrderIds);

        String mappingOrders = "select order_Id, thirdOrderId from order_cache where thirdOrderId in (" + orderIdParams + ")  and fiSellType = '2'";

        List<JSONObject> jsonObjectList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, mappingOrders);

        if (!ListUtil.isEmpty(jsonObjectList)) {
            for (JSONObject jsonObject : jsonObjectList) {
                if (jsonObject != null) {
                    mappingOrdersMap.put(jsonObject.getString("thirdOrderId"), jsonObject.getString("order_id"));
                }
            }
        }
        return mappingOrdersMap;
    }

    /**
     * 解析订单
     *
     * @param appOrder
     * @return
     */
    public static TempAppOrder parsingSimpleNetOrder(TempAppOrder appOrder) {
        if (appOrder != null) {
            try {
                String body = appOrder.body;
                int diningStatus = appOrder.diningStatus;
                int orderStatus = appOrder.orderStatus;
                int payStatus = appOrder.payStatus;
                int deliveryStatus = appOrder.deliveryStatus;
                long updateTime = appOrder.updateTime;
                String orderTakeawaySource = appOrder.orderTakeawaySource;
                String appOrderDate = appOrder.date;
                appOrder = JSON.parseObject(body, TempAppOrder.class);
                if (appOrder != null) {
                    appOrder.body = "";
                    appOrder.diningStatus = diningStatus;
                    appOrder.orderStatus = orderStatus;
                    appOrder.payStatus = payStatus;
                    appOrder.orderTakeawaySource = orderTakeawaySource;
                    appOrder.date = appOrderDate;
                    appOrder.deliveryStatus = deliveryStatus;
                    appOrder.updateTime = updateTime;
                }
            } catch (Exception e) {
                LogUtil.logError("网络订单转化异常：" + JSON.toJSONString(appOrder) + "   ----   错误信息：" + e.getMessage());
            }
        }

        return appOrder;
    }

    /**
     * 解析订单
     *
     * @param appOrder
     * @return
     */
    public static TempAppOrder parsingNetOrder(TempAppOrder appOrder) {
        if (appOrder != null) {
            try {
                String body = appOrder.body;
                int diningStatus = appOrder.diningStatus;
                int orderStatus = appOrder.orderStatus;
                int payStatus = appOrder.payStatus;
                int deliveryStatus = appOrder.deliveryStatus;
                long updateTime = appOrder.updateTime;
                String orderTakeawaySource = appOrder.orderTakeawaySource;
                String appOrderDate = appOrder.date;
                appOrder = JSON.parseObject(body, TempAppOrder.class);
                if (appOrder != null) {
                    appOrder.orderDetailList = getTempAppOrderDetailList(String.valueOf(appOrder.orderId));
                    appOrder.orderDetailSparseArray = parseAparseArrayDetail(appOrder.orderDetailList);
                    appOrder.body = "";
                    appOrder.diningStatus = diningStatus;
                    appOrder.orderStatus = orderStatus;
                    appOrder.payStatus = payStatus;
                    appOrder.orderTakeawaySource = orderTakeawaySource;
                    appOrder.date = appOrderDate;
                    appOrder.deliveryStatus = deliveryStatus;
                    appOrder.updateTime = updateTime;
                }
            } catch (Exception e) {
                LogUtil.logError("网络订单转化异常：" + JSON.toJSONString(appOrder) + "   ----   错误信息：" + e.getMessage());
            }
        }

        return appOrder;
    }

    /**
     * 查找指定订单详情
     *
     * @param orderId 订单号
     * @return
     */
    public static TempAppOrder getTempAppOrderById(String orderId) {
        String sql = "select * from tempapporder where orderId = '" + orderId + "'";
        TempAppOrder tempAppOrder = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, sql, TempAppOrder.class);
        if (tempAppOrder != null) {
            tempAppOrder = parsingNetOrder(tempAppOrder);
        }
        return tempAppOrder;
    }

    public static List<List<TempAppOrderDetail>> parseAparseArrayDetail(List<TempAppOrderDetail> orderDetailList) {
        SparseArray<List<TempAppOrderDetail>> orderDetailSparseArray = new SparseArray<>();
        if (!ListUtil.isEmpty(orderDetailList)) {
            for (TempAppOrderDetail detail : orderDetailList) {
                if (detail == null) {
                    continue;
                }

                List<TempAppOrderDetail> tempAppOrderDetails = orderDetailSparseArray.get(detail.pokeNo);
                if (ListUtil.isEmpty(tempAppOrderDetails)) {
                    tempAppOrderDetails = new ArrayList<>();
                    orderDetailSparseArray.append(detail.pokeNo, tempAppOrderDetails);
                }
                tempAppOrderDetails.add(detail);
            }
        }

        List<List<TempAppOrderDetail>> result = new ArrayList<>();
        for (int i = 0; i < orderDetailSparseArray.size(); i++) {
            result.add(orderDetailSparseArray.valueAt(i));
        }
        return result;
    }

    /**
     * 获取网络订单的菜品列表
     *
     * @param orderId String  订单ID
     * @return List<TempAppOrderDetail>
     */
    public static List<TempAppOrderDetail> getTempAppOrderDetailList(final String orderId) {
        List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_NET_ORDER, "select * from tempapporderdetails where orderId='" + orderId + "' and type = '1' order by pokeNo , itemName ");
        List<TempAppOrderDetail> itemList = new ArrayList<>();
        if (list != null && !ListUtil.isEmpty(list)) {
            for (JSONObject temp : list) {
                TempAppOrderDetail tempAppOrderDetail = JSON.parseObject(temp.getString("body"), TempAppOrderDetail.class);
                if (tempAppOrderDetail != null) {
                    tempAppOrderDetail.seqNo = temp.getString("orderDetailId");
                    tempAppOrderDetail.itemName = temp.getString("itemName");
                    tempAppOrderDetail.itemNum = temp.getIntValue("itemNum");
                    tempAppOrderDetail.parentId = temp.getString("parentID");
                    itemList.add(tempAppOrderDetail);
                }
            }

            List<JSONObject> tempModifierDetaiList;

            if (!ListUtil.isEmpty(itemList)) {
                for (TempAppOrderDetail tempAppOrderDetail : itemList) {
                    if (tempAppOrderDetail != null) {
                        list = DBSimpleUtil.queryJsonList(APPConfig.DB_NET_ORDER, "select * from tempapporderdetails where orderId='" + orderId + "' and parentID = '" + tempAppOrderDetail.uniq + "' and type in ('2','3') ");
                        if (list != null && !ListUtil.isEmpty(list)) {
                            for (JSONObject temp : list) {
                                TempAppOrderModifier tempAppOrderModifier = JSON.parseObject(temp.getString("body"), TempAppOrderModifier.class);
                                if (tempAppOrderModifier != null) {
                                    tempModifierDetaiList = DBSimpleUtil.queryJsonList(APPConfig.DB_NET_ORDER, "select * from tempapporderdetails where orderId='" + orderId + "' and parentID = '" + tempAppOrderModifier.uniq + "' and type = '4' ");
                                    if (tempModifierDetaiList != null && !ListUtil.isEmpty(tempModifierDetaiList)) {
                                        for (JSONObject detailTemp : tempModifierDetaiList) {
                                            TempModifierDetail tempModifierDetail = JSON.parseObject(detailTemp.getString("body"), TempModifierDetail.class);
                                            if (tempModifierDetail != null) {
                                                tempAppOrderModifier.modifiers.add(tempModifierDetail);
                                            }
                                        }
                                    }
                                    tempAppOrderDetail.modifiertypes.add(tempAppOrderModifier);
                                }
                            }
                        }
                    }
                }
            }
        }
        return itemList;
    }

    /**
     * 获取未处理网络订单数量
     *
     * @return
     */

    public static int getUnDealNetOrderCount() {
        String newOrderSQL = "select count(*) as netordercount from tempapporder where orderStatus in ('0') ";
        Integer count = DBSimpleUtil.queryInfo(APPConfig.DB_NET_ORDER, newOrderSQL, "netordercount", Integer.class);
        int newCount = 0;
        if (count != null) {
            newCount = count;
        }
        String sql = "select count(*) as netordercount from tempapporder where orderStatus in ('1', '2') and deliveryStatus in ('-2') ";

        String deliverCount = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql);

        return newCount + StringUtil.toInt(deliverCount, 0);
    }

    /**
     * 获取未处理网络不正常入库的数量
     *
     * @return
     */
    public static int getUnTurnedrderCount() {
        String newOrderSQL = "select count(*) as netordercount from datacache where info <> '1' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "' ";
        Integer count = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, newOrderSQL, "netordercount", Integer.class);
        int newCount = 0;
        if (count != null) {
            newCount = count;
        }

        return newCount;
    }

    /**
     * 检测订单是否已存在
     *
     * @param orderId
     * @return true:已存在
     */
    public static boolean isExist(String orderId) {
        String id = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select orderId from tempAppOrder where orderId = '" + orderId + "'");
        if (TextUtils.isEmpty(id)) {
            return false;
        }
        return true;
    }

    /**
     * 检测订单是否已存在
     *
     * @param orderId
     * @return true:已存在
     */
    public static TempAppOrder optTempappOrderHeaderInfo(String orderId) {
        return DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempAppOrder where orderId = '" + orderId + "'", TempAppOrder.class);
    }

    /**
     * 完成订单
     *
     * @param orderId
     * @return true:已存在
     */
    public static void finishOrder(String orderId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempAppOrder set diningStatus = '" + NetworkConstans.DINING_STATUS_USER_GET + "', orderstatus = '" + NetworkConstans.ORDER_STATUS_OVER + "' where orderId = '" + orderId + "'");
    }

    /**
     * 接单订单
     *
     * @param orderId
     * @return true:已存在
     */
    public static void doGetOrder(String orderId, int bizType) {
        if (bizType == 4) {
            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_KDS + "', diningStatus = '" + NetworkConstans.DINING_STATUS_KOT + "' where orderId = '" + orderId + "'");
        } else {
            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_OVER + "', diningStatus = '" + NetworkConstans.DINING_STATUS_USER_GET + "' where orderId = '" + orderId + "'");
        }
    }

    /**
     * 取消订单
     *
     * @param orderId
     * @return true:已存在
     */
    public static void cancelOrder(String orderId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempAppOrder set diningStatus = '" + NetworkConstans.DINING_STATUS_USER_CANCEL + "', orderstatus = '" + NetworkConstans.ORDER_STATUS_CANCEL + "' where orderId = '" + orderId + "'");
    }

    /**
     * 查询订单状态
     *
     * @param orderId
     * @return true:已存在
     */
    public static String getOrderStatus(int orderId) {
        return DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select orderStatus from tempAppOrder where orderId='" + orderId + "'");
    }

    /**
     * 获取网络订单数量
     *
     * @return int
     */
    public static int getNetOrderCount() {
        String sql = "select count(*) from tempapporder";
        String count = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql);
        return StringUtil.toInt(count, 0);
    }

}
