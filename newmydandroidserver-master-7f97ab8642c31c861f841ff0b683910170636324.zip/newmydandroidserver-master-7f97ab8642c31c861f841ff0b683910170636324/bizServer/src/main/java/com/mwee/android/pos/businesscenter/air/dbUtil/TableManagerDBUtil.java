package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.air.db.business.table.AirAreaManagerInfo;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.air.util.DBPrimaryKeyUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/14.
 */

public class TableManagerDBUtil {

    /**
     * 获取餐区信息---餐区ID，餐区名称，餐区下所有桌台数据，餐区下所有被占用桌台数量
     *
     * @return
     */
    public static List<AirAreaManagerInfo> optAreaManagerInfo() {
        String sql = "select a.fsMAreaId fsMAreaId,a.fsMAreaName fsMAreaName, b.tableCount allTables, c. businessCount allTableInUse " +
                "from (select fsMAreaId, fsMAreaName from tbmarea where fistatus = 1) a " +
                "left join (select fsMAreaId , count(*) tableCount from tbmtable where fistatus = 1 group by fsMAreaId) b " +
                "on a. fsMAreaId = b. fsMAreaId " +
                "left join (select fsmareaId, count(*) businessCount from tableBiz where fsmtablesteid = '2' or (extra_order <>'' and extra_order <>'null') group by fsmareaId) c " +
                "on a. fsMAreaId = c. fsMAreaId";
        List<AirAreaManagerInfo> airAreaManagerInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirAreaManagerInfo.class);
        if (ListUtil.isEmpty(airAreaManagerInfos)) {
            return new ArrayList<>();
        }
        AirAreaManagerInfo airAreaManagerInfo = optDefaultAirAreaManagerInfo();
        for (AirAreaManagerInfo areaManagerInfo : airAreaManagerInfos) {
            airAreaManagerInfo.allTableInUse += areaManagerInfo.allTableInUse;
            airAreaManagerInfo.allTables += areaManagerInfo.allTables;
        }
        airAreaManagerInfos.add(0, airAreaManagerInfo);
        return airAreaManagerInfos;
    }

    private static AirAreaManagerInfo optDefaultAirAreaManagerInfo() {
        AirAreaManagerInfo airAreaManagerInfo = new AirAreaManagerInfo();
        airAreaManagerInfo.fsMAreaName = "全部桌台";
        return airAreaManagerInfo;
    }

    /**
     * 获取餐桌信息
     *
     * @return
     */
    public static List<AirTableManageInfo> optTableManagerInfo() {
        String sql = "select a.*, b.fisharebillsInUse fisharebillsInUse,b. fsmtablesteid fsmtablesteid from (select fsmtableid, fsmtableName,fsmareaid, fiseats,fisharebills,fisortorder from tbmtable where fistatus = '1' and fsmareaId in (select fsmareaId from tbmarea where fistatus = '1')) a left join (select  fsmtableId,fsmtablesteid, count(*) fisharebillsInUse from tableBiz where fsmtablesteid = '2' group by fsmtableId) b on a.fsmtableId = b.fsmtableId";
        List<AirTableManageInfo> airAreaManagerInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirTableManageInfo.class);
        if (ListUtil.isEmpty(airAreaManagerInfos)) {
            return new ArrayList<>();
        }
        return airAreaManagerInfos;
    }

    /**
     * 新增餐区
     *
     * @param data
     * @param areaName
     * @param userDBModel
     * @return
     */
    public static synchronized String addArea(GetAllAreaAndTableResponse data, String areaName, boolean batchAddTable, int tableCount, int person, UserDBModel userDBModel) {
        String checkSql = "select * from tbmarea where fsmareaName = '" + areaName + "'";
        MareaDBModel mareaDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, MareaDBModel.class);
        if (mareaDBModel != null) {
            if (mareaDBModel.fiStatus == 13) {

                mareaDBModel.fiStatus = 1;
                mareaDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                if (userDBModel != null) {
                    mareaDBModel.fsUpdateUserName = userDBModel.fsUserName;
                    mareaDBModel.fsUpdateUserId = userDBModel.fsUserId;
                }
                mareaDBModel.sync = 1;
                data.mareaDBModel = mareaDBModel;
                mareaDBModel.replaceNoTrans();
                if (batchAddTable) {
                    batchAddTale(data.newTableDBModels, mareaDBModel.fsMAreaId, mareaDBModel.fsMAreaName, tableCount, person, userDBModel);
                }
                return "";
            } else {
                return "'" + areaName + "'已存在";
            }
        }

        mareaDBModel = new MareaDBModel();
        mareaDBModel.fsMAreaId = DBPrimaryKeyUtil.optPrimaryKey();
        mareaDBModel.fiStatus = 1;
        mareaDBModel.fsMAreaName = areaName;
        mareaDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        mareaDBModel.fiDataSource=1;
        mareaDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        if (userDBModel != null) {
            mareaDBModel.fsUpdateUserName = userDBModel.fsUserName;
            mareaDBModel.fsUpdateUserId = userDBModel.fsUserId;
        }
        mareaDBModel.sync = 1;
        mareaDBModel.replaceNoTrans();
        MetaDBController.updateSyncTime();
        data.mareaDBModel = mareaDBModel;
        if (batchAddTable) {
            batchAddTale(data.newTableDBModels, mareaDBModel.fsMAreaId, mareaDBModel.fsMAreaName, tableCount, person, userDBModel);
        }
        return "";
    }

    /**
     * 批量新增桌台
     *
     * @param mtableDBModels
     * @param fsmareaId      餐区ID
     * @param fsMAreaName    餐区名称
     * @param tableCount     桌台数
     * @param person         座位数
     */
    public static void batchAddTale(ArrayList<MtableDBModel> mtableDBModels, String fsmareaId, String fsMAreaName, int tableCount, int person, UserDBModel userDBModel) {
        int errcount = 0;  //新增桌台遇到错误次数
        String errMsg;
        for (int i = 1; i <= tableCount + errcount; i++) {
            errMsg = addTable(mtableDBModels, fsmareaId, fsMAreaName + i, person, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                errcount++;
            }
        }
    }

    /**
     * 修改餐区名称
     *
     * @param areaId
     * @param areaName
     * @param userDBModel
     * @return
     */
    public static synchronized String updateAreaName(String areaId, String areaName, UserDBModel userDBModel) {
        String checkSql = "select * from tbmarea where fsmareaId = '" + areaId + "'";
        MareaDBModel mareaDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, MareaDBModel.class);
        if (mareaDBModel == null || mareaDBModel.fiStatus == 13) {
            return "未找到该餐区";
        } else {
            String oldAreaId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, " select fsmareaId from tbmarea where fsMAreaName = '" + areaName + "' and fistatus = '1'");
            if (!TextUtils.isEmpty(oldAreaId)) {
                return areaName + " 餐区已存在";
            }
            mareaDBModel.fsMAreaName = areaName;
            mareaDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                mareaDBModel.fsUpdateUserName = userDBModel.fsUserName;
                mareaDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            mareaDBModel.sync = 1;
            mareaDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 删除餐区
     *
     * @param areaId
     * @param userDBModel
     * @return
     */
    public static synchronized String deleteArea(String areaId, UserDBModel userDBModel) {


        String checkTable = "select count(*) from tbmtable where fiStatus = '1'and fsMAreaId = '" + areaId + "'";
        String chirdCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, checkTable);
        if (Integer.valueOf(chirdCount) > 0) {
            return "请先删除该区域下所有桌台";
        }

        String checkSql = "select * from tbmarea where fsmareaId = '" + areaId + "'";
        MareaDBModel mareaDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, MareaDBModel.class);
        if (mareaDBModel == null || mareaDBModel.fiStatus == 13) {
            return "";
        } else {

            //判断该餐区下是否还有正在使用的桌台
            int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tableBiz where fsmareaId = '" + areaId + "' and ( fsmtablesteid = '2' or (extra_order <>'' and extra_order <>'null') )"), 0);
            if (count > 0) {
                return "该餐区下有桌台正在被占用";
            }
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tableBiz where fsmareaId = '" + areaId + "' or fshint = '" + areaId + "'");
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbmtable set fistatus = '13', sync = '1' where fsmareaId = '" + areaId + "' or fshint = '" + areaId + "'");
            mareaDBModel.fiStatus = 13;
            mareaDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                mareaDBModel.fsUpdateUserName = userDBModel.fsUserName;
                mareaDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            mareaDBModel.sync = 1;
            mareaDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 新增桌台
     *
     * @param mtableDBModels
     * @param areaId         餐区ID
     * @param tableName      桌台名称
     * @param seats          座位数
     * @param userDBModel
     * @return
     */
    public static synchronized String addTable(ArrayList<MtableDBModel> mtableDBModels, String areaId, String tableName, int seats, UserDBModel userDBModel) {
        String checkAreaSql = "select * from tbmarea where fsmareaId = '" + areaId + "'";
        MareaDBModel mareaDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkAreaSql, MareaDBModel.class);
        if (mareaDBModel == null || mareaDBModel.fiStatus == 13) {
            return "餐区无效";
        }
        String checkTableSql = "select * from tbmTable where fsmtableName = '" + tableName + "'";
        MtableDBModel mtableDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkTableSql, MtableDBModel.class);
        if (mtableDBModel != null) {
            if (mtableDBModel.fistatus == 13) {
                mtableDBModel.fistatus = 1;
                mtableDBModel.fiseats = seats;
                mtableDBModel.fsmareaid = areaId;
                mtableDBModel.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                mtableDBModel.sync = 1;
                if (userDBModel != null) {
                    mtableDBModel.fsupdateusername = userDBModel.fsUserName;
                    mtableDBModel.fsupdateuserid = userDBModel.fsUserId;
                }
                mtableDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();
            } else {
                return tableName + " 桌台已存在";
            }
        } else {
            mtableDBModel = new MtableDBModel();

            mtableDBModel.fsmtableid = DBPrimaryKeyUtil.optPrimaryKey();
            mtableDBModel.fistatus = 1;
            mtableDBModel.fsmtablename = tableName;
            mtableDBModel.fsmtableclsid = "1";
            mtableDBModel.fsmareaid = areaId;
            mtableDBModel.fiseats = seats;
            mtableDBModel.fiDataSource=1;
            mtableDBModel.fsshopguid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            mtableDBModel.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            mtableDBModel.sync = 1;
            if (userDBModel != null) {
                mtableDBModel.fsupdateusername = userDBModel.fsUserName;
                mtableDBModel.fsupdateuserid = userDBModel.fsUserId;
            }
            mtableDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
        }
        if (mtableDBModels != null) {
            mtableDBModels.add(mtableDBModel);
        }
        return "";
    }

    /**
     * 修改桌台信息
     *
     * @param areaId      餐区ID
     * @param tableName   桌台名称
     * @param seats       座位数
     * @param userDBModel
     * @return
     */
    public static synchronized String updateTable(String areaId, String fsmtableId, String tableName, int seats, UserDBModel userDBModel) {
        String checkAreaSql = "select * from tbmarea where fsmareaId = '" + areaId + "'";
        MareaDBModel mareaDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkAreaSql, MareaDBModel.class);
        if (mareaDBModel == null || mareaDBModel.fiStatus == 13) {
            return "餐区无效";
        }

        MtableDBModel currentTableDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmtable where fsmtableId = '" + fsmtableId + "'", MtableDBModel.class);
        if (currentTableDBModel == null) {
            return "桌台不存在";
        }

        if (TableDBUtil.checkTableInBusiness(fsmtableId)) {
            return "桌台正在被占用";
        }

        String checkTableSql = "select * from tbmTable where fsmtableName = '" + tableName + "' and fsmtableId <> '" + fsmtableId + "'";
        MtableDBModel mtableDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkTableSql, MtableDBModel.class);
        if (mtableDBModel != null) {
            if (mtableDBModel.fistatus == 13) {
                currentTableDBModel.fistatus = 1;
                currentTableDBModel.fiseats = seats;
                currentTableDBModel.fsmareaid = areaId;
                currentTableDBModel.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                currentTableDBModel.sync = 1;
                if (userDBModel != null) {
                    currentTableDBModel.fsupdateusername = userDBModel.fsUserName;
                    currentTableDBModel.fsupdateuserid = userDBModel.fsUserId;
                }
                currentTableDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();
            } else {
                return tableName + " 桌台已存在";
            }
        } else {
            currentTableDBModel.fistatus = 1;
            currentTableDBModel.fsmtablename = tableName;
            currentTableDBModel.fsmareaid = areaId;
            currentTableDBModel.fiseats = seats;
            currentTableDBModel.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            currentTableDBModel.sync = 1;
            if (userDBModel != null) {
                currentTableDBModel.fsupdateusername = userDBModel.fsUserName;
                currentTableDBModel.fsupdateuserid = userDBModel.fsUserId;
            }
            currentTableDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
        }
        return "";
    }


    /**
     * 删除桌台
     *
     * @param tableIdList
     * @param userDBModel
     * @return
     */
    public static synchronized String batchDeleteTable(ArrayList<String> tableIdList, UserDBModel userDBModel) {

        String tableIds = parsListToSQLParam(tableIdList);
        //判断是否还有正在使用的桌台
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tableBiz where fsmtableId in (" + tableIds + ") and ( fsmtablesteid = '2' or (extra_order <>'' and extra_order <>'null') )"), 0);
        if (count > 0) {
            return "删除桌台失败,有桌台正在被占用";
        }
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tableBiz where fsmtableId in (" + tableIds + ") or fshint in (" + tableIds + ")");
        String fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        String fsUpdateUserName = userDBModel == null ? "" : userDBModel.fsUserName;
        String fsUpdateUserId = userDBModel == null ? "" : userDBModel.fsUserId;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbmtable set fistatus = '13', sync = '1', fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fsmtableId in (" + tableIds + ") or fshint in (" + tableIds + ")");
        MetaDBController.updateSyncTime();
        return "";
    }

    public static String parsListToSQLParam(List<String> params) {
        StringBuilder stringBuilder = new StringBuilder();

        if (!ListUtil.isEmpty(params)) {
            for (String str : params) {
                stringBuilder.append("'").append(str).append("'").append(",");
            }
            String str = stringBuilder.toString();
            if (stringBuilder.length() > 1) {
                str = str.substring(0, str.length() - 1);
            }
            return str;
        }
        return "";
    }


    /*--------换桌的逻辑---------*/

    /**
     * 获取所有区域信息-----加入"全部区域"
     *
     * @return
     */
    public static List<MareaDBModel> getArea() {
        String sql = "select * from " + DBModel.getTableName(MareaDBModel.class) + " where fiStatus = '1' order by fiSortOrder ";//根据fiSortOrder（后台可配置）字段进行排序
        List<MareaDBModel> mareaDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MareaDBModel.class);
        if (mareaDBModelList == null) {
            mareaDBModelList = new ArrayList<>();
        }

        if (mareaDBModelList.size() > 0) {

            MareaDBModel mareaDBModel = new MareaDBModel();
            mareaDBModel.fsMAreaId = "all";
            mareaDBModel.fsMAreaName = "全部";
            mareaDBModel.wxMsgCount = 0;
            mareaDBModelList.add(0, mareaDBModel);
        }
        return mareaDBModelList;
    }


    /**
     * 获取桌台
     * 当不给区域ID时默认查询所有有效桌台
     *
     * @param fsmareaid 区域ID
     * @return
     */
    public static List<MtableDBModel> getTable(String fsmareaid) {
        String params = "";
        if (!TextUtils.isEmpty(fsmareaid)) {
            params = "and fsmareaid = '" + fsmareaid + "'";
        }
        String sql = "select fsmtablename, fsmtableid, " +  //桌台名称, 桌台ID
                " fiseats, fsmareaid " + // 座位数, 所在区域
                "from tbmtable where fiStatus = '1' " + params + " and fsmareaid not in (" +
                " select fsmareaid from tbmarea where fiStatus <> '1'  )" +
                " order by fsMAreaId, fiSortOrder, fsMTableName";
        List<MtableDBModel> statusBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        if (statusBeanList == null) {
            statusBeanList = new ArrayList<>();
        }

        return statusBeanList;
    }


    /**
     * 将两个桌台集合按顺序合并
     *
     * @param localMtableDBModels 本地数据库中的原生桌台
     * @param hintMtableDBModels  业务中心返回的拼桌
     * @return
     */
    public static List<MtableDBModel> getAllTables(List<MtableDBModel> localMtableDBModels, List<MtableDBModel> hintMtableDBModels) {
        List<MtableDBModel> allTables = new ArrayList<>();
        for (MtableDBModel mtableDBModel : localMtableDBModels) {
            allTables.add(mtableDBModel);
            for (MtableDBModel hintTable : hintMtableDBModels) {
                if (TextUtils.equals(hintTable.fshint, mtableDBModel.fsmtableid)) {
                    allTables.add(hintTable);
                }
            }
        }
        return allTables;
    }


    /**
     * 将桌台按照餐区分组 --- 指定桌台集合
     *
     * @param allTables
     * @return Map<餐区ID, List<桌台>>
     */
    public static ArrayMap<String, List<MtableDBModel>> groupTables(List<MtableDBModel> allTables) {
        if (ListUtil.isEmpty(allTables)) {
            return new ArrayMap<>();
        }
        ArrayMap<String, List<MtableDBModel>> areaTable = new ArrayMap<>();
        for (MtableDBModel temp : allTables) {
            List<MtableDBModel> list = areaTable.get(temp.fsmareaid);
            if (list == null) {
                list = new ArrayList<>();
                areaTable.put(temp.fsmareaid, list);
            }
            list.add(temp);
        }
        return areaTable;

    }


}
