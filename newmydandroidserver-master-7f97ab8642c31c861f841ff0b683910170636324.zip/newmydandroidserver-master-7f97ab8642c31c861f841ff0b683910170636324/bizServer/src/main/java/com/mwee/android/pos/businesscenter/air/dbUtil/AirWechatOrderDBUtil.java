package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.Map;
import java.util.Set;


/**
 * Created by liuxiuxiu on 2017/10/17.
 */

public class AirWechatOrderDBUtil {

    /**
     * 获取所有微信外卖设置
     *
     * @return
     */
    public static ArrayMap<String, String> optWechatOrderSettings() {
        ArrayMap<String, String> stringStringArrayMap = new ArrayMap<>();
        stringStringArrayMap.put("chat1", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat1'"));
        stringStringArrayMap.put("chat2", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat2'"));
        stringStringArrayMap.put("chat3", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat3'"));
        stringStringArrayMap.put("chat4", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat4'"));
        stringStringArrayMap.put("chat4fsStr1", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsStr1 from tbparamValue where fsparamId = 'chat4'"));
        stringStringArrayMap.put("chat5", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat5'"));
        stringStringArrayMap.put("chat6", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbparamValue where fsparamId = 'chat6'"));
        return stringStringArrayMap;
    }

    /**
     * 更新所有微信外卖设置
     *
     * @return
     */
    public static void updateWechatOrderSetting(ArrayMap<String, String> stringStringArrayMap, String shopId, String fsUpdateUserId, String fsUpdateUserName) {
        if (stringStringArrayMap == null || stringStringArrayMap.size() <= 0) {
            return;
        }

        Set<Map.Entry<String, String>> entrySet = stringStringArrayMap.entrySet();
        String fsupdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        String key, value;
        for (Map.Entry<String, String> entry : entrySet) {
            key = entry.getKey();
            value = entry.getValue();

            if (TextUtils.equals(key, "longitude") || TextUtils.equals(key, "latitude")) {
                continue;
            }

            if (TextUtils.equals(key, "address")) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbshop set fsAddr = '" + value + "', fsUpdateUserId = '" + fsUpdateUserId + "', fsUpdateTime = '" + fsupdateTime + "', fsUpdateUserName = '" + fsUpdateUserName + "', sync = '1' where fsShopGUID = '" + shopId + "'");
                continue;
            }

            String paramId = key;
            if (TextUtils.equals(key, "chat4fsStr1")) {
                paramId = "chat4";
            }
            String sqlExist = "SELECT * FROM tbparamvalue WHERE fsParamId = '" + paramId + "'";
            ParamvalueDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, ParamvalueDBModel.class);
            if (model == null) {
                model = buildNewParamValue(paramId);
            }
            model.fsUpdateTime = DateUtil.getCurrentTime();
            model.fsUpdateUserId = fsUpdateUserId;
            model.fsUpdateUserName = fsUpdateUserName;
            if (TextUtils.equals(key, "chat4fsStr1")) {
                model.fsStr1 = value;
            } else {
                model.fsParamValue = value;
            }
            model.sync = 1;
            model.replaceNoTrans();
        }
    }

    private static ParamvalueDBModel buildNewParamValue(String paramId) {
        ParamvalueDBModel result = new ParamvalueDBModel();
        result.fsparamid = paramId;
        result.fsshopguid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        return result;
    }
}
