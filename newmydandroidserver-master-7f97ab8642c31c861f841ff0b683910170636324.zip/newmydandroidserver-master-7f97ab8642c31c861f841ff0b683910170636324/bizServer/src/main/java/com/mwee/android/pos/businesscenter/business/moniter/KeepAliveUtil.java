package com.mwee.android.pos.businesscenter.business.moniter;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.keppalive.KeepAliveRequest;
import com.mwee.android.pos.business.keppalive.KeepAliveResponse;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by liuxiuxiu on 2018/5/11.
 */

public class KeepAliveUtil {

    /**
     * 默认（最小）保活周期 -----> 1个GlobalLooper周期
     * GlobalLooper 轮询周期为30秒一次，所以这里的保活是最少30秒一次
     */
    private static final int DEFAULT_TIME_GAP = 1;
    /**
     * 最长保活周期 ---> 60个GlobalLooper周期
     * GlobalLooper 轮询周期为30秒一次，所以这里的保活是最长为30分钟一次
     */
    private static final int MAX_TIME_GAP = 60;

    /**
     * 云端返回下次保活时长 (单位s)
     */
    private static int CLOUD_TIME = DEFAULT_TIME_GAP;
    /**
     * 当前保活周期 ---> GlobalLooper
     */
    private static int CURRENT_TIME_GAP = DEFAULT_TIME_GAP;

    /**
     * 保活入口
     */
    public static void initKeepAliveLoop() {
        ILoopCall loopCall = new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询，如果还没有激活则停止该任务，待激活主站点后再注册该任务
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                keepAliveReqest(this);
            }
        };
        GlobalLooper.registBasedOn30Seconds(loopCall, DEFAULT_TIME_GAP);
    }

    /**
     * 发送保活请求
     *
     * @param loopCall
     */
    private static void keepAliveReqest(ILoopCall loopCall) {
        KeepAliveRequest request = new KeepAliveRequest();

        request.token = DBMetaUtil.getConfig(META.XMPP_SESSION_ID, "");
        request.deviceid = DeviceUtil.getDeviceID(GlobalCache.getContext());
        request.app_version = BizConstant.VERSION_NAME;
        request.clientType = APPConfig.getClientType();
        String fsshopguid = DBMetaUtil.getConfig(META.SHOPID, "");
        if (TextUtils.isEmpty(fsshopguid)) {
            RunTimeLog.addLog(RunTimeLog.SYS_KEEP_ALIVE_FAILED, "保活 -- 未找到门店ID,延迟保活时长为2分钟");
            GlobalLooper.registBasedOn30Seconds(loopCall, DEFAULT_TIME_GAP * 4);
            return;
        }
        request.shopid = StringUtil.toInt(fsshopguid, 0);

        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    if (responseData.responseBean != null && responseData.responseBean instanceof KeepAliveResponse) {
                        KeepAliveResponse response = (KeepAliveResponse) responseData.responseBean;
                        if (response.data != null) {
                            CLOUD_TIME = response.data.interval;
                            CURRENT_TIME_GAP = cacuIntervalCycle(CLOUD_TIME);
                            if (CURRENT_TIME_GAP > MAX_TIME_GAP) {
                                CURRENT_TIME_GAP = MAX_TIME_GAP;
                            } else if (CURRENT_TIME_GAP < DEFAULT_TIME_GAP) {
                                CURRENT_TIME_GAP = DEFAULT_TIME_GAP;
                            }
                        } else {
                            CURRENT_TIME_GAP = DEFAULT_TIME_GAP;
                            LogUtil.logBusiness("保活 -- 返回错误 response.data 为空");
                        }
                    } else {
                        CURRENT_TIME_GAP = DEFAULT_TIME_GAP;
                        LogUtil.logBusiness("保活 -- 返回错误 responseData.responseBean is not instanceof KeepAliveResponse");
                    }
                } catch (Exception e) {
                    CURRENT_TIME_GAP = DEFAULT_TIME_GAP;
                    RunTimeLog.addLog(RunTimeLog.SYS_KEEP_ALIVE_FAILED, "保活 -- 解析网络返回异常 responseData = " + JSON.toJSONString(responseData), "", e);
                    LogUtil.logError(e);
                } finally {
                    GlobalLooper.registBasedOn30Seconds(loopCall, CURRENT_TIME_GAP);
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                GlobalLooper.registBasedOn30Seconds(loopCall, DEFAULT_TIME_GAP);
                RunTimeLog.addLog(RunTimeLog.SYS_KEEP_ALIVE_FAILED, "保活 -- 网络返回错误 responseData = " + JSON.toJSONString(responseData));
                LogUtil.logBusiness("保活 -- 网络返回错误 responseData = " + JSON.toJSONString(responseData));
                return false;
            }
        }, true);
    }

    /**
     * 计算周期
     * 30秒为一个周期， 不足30秒算一个周期
     *
     * @param interval
     * @return
     */
    private static int cacuIntervalCycle(int interval) {
        int cycle = 1;
        if (interval < 0) {
            return cycle;
        }
        cycle = interval / 30;
        if (cycle < 1) {
            return 1;
        }
        return cycle;
    }

}
