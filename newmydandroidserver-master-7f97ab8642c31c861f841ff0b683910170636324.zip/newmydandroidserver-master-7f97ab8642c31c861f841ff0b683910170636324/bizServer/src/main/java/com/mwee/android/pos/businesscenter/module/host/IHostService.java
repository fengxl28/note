package com.mwee.android.pos.businesscenter.module.host;

import com.mwee.android.pos.connect.business.bind.bean.ActiveHostAndLoginResponse;

/**
 * host相关业务接口
 * Created by qinwei on 2018/7/17.
 */

public interface IHostService {
    /**
     * 激活站点成功后用admin账号登录
     *
     * @param hostId 激活的站点id
     * @param device 激活的设备id
     * @return 激活登录相关信息
     */
    ActiveHostAndLoginResponse loadActiveHostAndLoginForAdmin(String hostId, String device);
}
