package com.mwee.android.pos.businesscenter.business.koubei.future;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.shop.KouBeiShopInfo;
import com.mwee.android.pos.business.shop.KoubeiShopInfoRequest;
import com.mwee.android.pos.business.shop.KoubeiShopInfoResponse;
import com.mwee.android.pos.businesscenter.air.dao.impl.TableDaoImpl;
import com.mwee.android.pos.businesscenter.module.koubei.service.impl.KBOrderServiceImpl;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderDBUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.component.koubei.KBPayQrCodeRequest;
import com.mwee.android.pos.component.koubei.KBPayQrCodeResponse;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;


/**
 * Created by zhangmin on 2018/10/13.
 */

public class KBFutureProcessor {


    /*---------------------推送的行为----------------------*/
    //推送后付款新订单
    public static String pushFutureNewOrder(RapidGetModel data) {

        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理-->推送新订单 ： ", JSON.toJSONString(data));
            return "";
        }
        KBAfterPayOrder kbAfterPayOrder = JSON.parseObject(data.fstdata, KBAfterPayOrder.class);
        String tableName = kbAfterPayOrder.table_no;
        MtableDBModel mtableDBModel = new TableDaoImpl().queryByTableNoAndTableQRConfig(kbAfterPayOrder.table_no);
        if (mtableDBModel != null && mtableDBModel.fistatus == 1) {
            tableName = mtableDBModel.fsmtablename;
        }
        if (KBPreOrderDBUtils.isAutoAccept()) {
            //未营业门店不可以自动接单
            if (HostUtil.isShopFinished()) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "餐厅已打烊", data.fsid, data);
                KBFutureProcessor.rejectFutureOrder(kbAfterPayOrder.order_id, kbAfterPayOrder.batch_no, "店铺已打烊");
                return "店铺已打烊";
            }
            SocketResponse<ScannerTableOrderAcceptResponse> response = new KBOrderServiceImpl().acceptAfterPayOrder(kbAfterPayOrder, HostUtil.getCurrentHost());
            if (!response.success()) {
                RunTimeLog.addLog(RunTimeLog.KB_AFTER_PAY_ORDER, "自动接单失败:" + response.message, JSONObject.toJSONString(kbAfterPayOrder));
                //口碑下单校验主单是否一致，若不一致，则要拒单。（测试场景：口碑A下单B菜品。口碑掌柜清台，口碑B下单C菜品。要拒单。）
                //C端提交加菜单，pos端已结账——若已通知给ISV，则ISV直接拒单；——已有主单场景,不应该合单
                if (response.code == SocketResultCode.KB_LOCAL_ORDER_ALREADY_DONE) {
                    RunTimeLog.addLog(RunTimeLog.KB_AFTER_PAY_ORDER, "code:" + response.code + ",开始拒单 口碑下单校验主单是否一致，若不一致，则要拒单。" +
                            "（测试场景：口碑A下单B菜品。口碑掌柜清台，口碑B下单C菜品。要拒单。C端提交加菜单，" +
                            "pos端已结账——若已通知给ISV，则ISV直接拒单；——已有主单场景,不应该合单", kbAfterPayOrder.order_id);
                    //自动拒单
                    String msg = rejectFutureOrder(kbAfterPayOrder.order_id, kbAfterPayOrder.batch_no, "其他原因");
                    if (TextUtils.isEmpty(msg)) {
                        RunTimeLog.addLog(RunTimeLog.KB_AFTER_PAY_ORDER, "拒单成功", kbAfterPayOrder.order_id);
                    } else {
                        RunTimeLog.addLog(RunTimeLog.KB_AFTER_PAY_ORDER, "拒单失败：" + msg, kbAfterPayOrder.order_id);
                    }
                } else {
                    NotifyToClient.KBOrderException(kbAfterPayOrder.order_id, false);
                }
                return "";
            }
        }
        NotifyToClient.addNewKBFutureOrder(tableName);
        return "";
    }


    public static void loadKBShopInfo(ResultCallback<KouBeiShopInfo> callback) {
        KoubeiShopInfoRequest request = new KoubeiShopInfoRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof KoubeiShopInfoResponse) {
                    KoubeiShopInfoResponse posResponse = (KoubeiShopInfoResponse) responseData.responseBean;
                    callback.onSuccess(posResponse.data);
                } else {
                    callback.onFailure(-1, "");
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                callback.onFailure(i, responseData.resultMessage);
                return false;
            }
        }, false);
    }


    //接单
    public static String acceptFutureOrder(String orderId, String batchNo, String outBizNo) {
        String[] msg = new String[1];
        KBFutureUserActionApi futureUserActionApi = new KBFutureUserActionApi();
        futureUserActionApi.acceptFutureOrder(orderId, batchNo, outBizNo, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                msg[0] = responseData.resultMessage;
                return false;
            }
        });
        return msg[0];
    }

    //拒单
    public static String rejectFutureOrder(String order_id, String batchNo, String rejectReason) {
        KBFutureUserActionApi futureUserActionApi = new KBFutureUserActionApi();
        final String[] str = new String[1];
        futureUserActionApi.rejectFutureOrder(order_id, batchNo, rejectReason, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                str[0] = responseData.resultMessage;
                return false;
            }
        });
        return str[0];
    }


    public static void loadFutureTempOrderHeader(int pageIndex, String orderId, String status, BusinessCallback resultCallback) {
        KBFutureUserActionApi futureUserActionApi = new KBFutureUserActionApi();
        futureUserActionApi.loadFutureTempOrderHeader(pageIndex, orderId, status, resultCallback);
    }

    public static String loadPayQRInfo(String orderId) {
        KBPayQrCodeRequest request = new KBPayQrCodeRequest();
        request.request_id = System.currentTimeMillis() + "";
        request.out_order_no = orderId;
        String[] code = new String[1];
        code[0] = "";
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof KBPayQrCodeResponse) {
                    KBPayQrCodeResponse posResponse = (KBPayQrCodeResponse) responseData.responseBean;
                    code[0] = posResponse.data.qr_code;
                } else {
                    code[0] = "";
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
        return code[0];
    }
}
