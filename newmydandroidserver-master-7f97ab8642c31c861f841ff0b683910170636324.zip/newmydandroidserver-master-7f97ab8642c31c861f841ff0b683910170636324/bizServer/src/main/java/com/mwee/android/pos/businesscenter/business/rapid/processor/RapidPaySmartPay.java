package com.mwee.android.pos.businesscenter.business.rapid.processor;

/**
 * 全能pos收款
 * Created by virgil on 2017/7/31.
 */

public class RapidPaySmartPay {
}
