package com.mwee.android.pos.businesscenter.print.koubei;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.List;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/6/6
 */
public abstract class KoubeiBasePrint {



    /**
     *
     * @return 构建通用打印task
     */
    protected abstract PrintTaskDBModel buildInitPrintTaskModel();

    /**
     *
     * @return 构建打印数据
     */
    protected abstract com.alibaba.fastjson.JSONObject buildPrintJSONData();

    /**
     * 1构建数据 2构建task 3打印 打印
     */
    public abstract void print();

    /**
     * 中断打印条件
     *
     * @return  是否中断打印
     */
    protected  boolean interruptPrint(){
        return false;
    }

    /**
     *
     * @return 构建最后需要打印的task 只构建task不打印
     */
    public List<PrintTaskDBModel> buildShouldPrintTasks() {
        return null;
    }



    /**
     *
     * @param data 数据
     * @param task 任务
     * @return 需要打印的任务集合
     */
    protected abstract List<PrintTaskDBModel> onBuildTasks(JSONObject data, PrintTaskDBModel task);


    ///////////////////////////////////////////////////////////////////////////
    //  一些通用方法
    ///////////////////////////////////////////////////////////////////////////
    protected  String getDefaultHostId(){
        return DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
    }

    protected  String getDefaultBusinessDate(){
        return HostUtil.getHistoryBusineeDate("");
    }

    protected ShopDBModel getDefaultShopModel(){
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);
    }
}
