package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.util.Log;

import com.mwee.android.air.util.TicketTempletConstants;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.connect.business.print.model.ReceiptTempletModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPrivateDBModel;
import com.mwee.myd.server.dbmodel.print.PrintTempletPublicDBModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 小票模版数据管理工具
 * Created by qinwei on 2018/8/29.
 */

public class PrintTempletPrivateDBUtils {

    /**
     * 根据模版id查询模版数据
     *
     * @param id
     * @return
     */
    public static PrintTempletPrivateDBModel queryById(String id) {
        String sql = "select * from tbPrintTempletPrivate where fsTempletId='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrintTempletPrivateDBModel.class);
    }

    /**
     * 根据小票打印uri 查询当前使用的模版数据
     *
     * @param fsTempletKey 处理小票打印的uri
     * @return
     */
    public static PrintTempletPrivateDBModel queryUsedTempletByTempletKey(String fsTempletKey) {
        String sql = "select * from tbPrintTempletPrivate where fiSelected=1 and fsTempletKey='" + fsTempletKey + "'";
        PrintTempletPrivateDBModel dbModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrintTempletPrivateDBModel.class);
        if (dbModel == null) {
            dbModel = queryById(TicketTempletUtils.findDefultTempletId(fsTempletKey));
            if (dbModel != null) {
                //选中生效的模版
                dbModel.fiSelected = 1;
                dbModel.fsUpdateTime = DateUtil.getCurrentTime();
                dbModel.sync = 1;
                dbModel.replace();
            }
        }
        return dbModel;
    }

    /**
     * 查询一组正在使用的小票模版
     *
     * @param fsTempletKeys
     * @return
     */
    public static ArrayList<PrintTempletPrivateDBModel> queryUsedTempletByTempletKeys(ArrayList<String> fsTempletKeys) {
        ArrayList<PrintTempletPrivateDBModel> printTempletPrivateDBModels = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(");
        for (int i = 0; i < fsTempletKeys.size(); i++) {
            if (i == fsTempletKeys.size() - 1) {
                stringBuilder.append("'" + fsTempletKeys.get(i) + "'");
            } else {
                stringBuilder.append("'" + fsTempletKeys.get(i) + "',");
            }
        }
        stringBuilder.append(")");
        String sql = "select * from tbPrintTempletPrivate where fiSelected=1 and fsTempletKey in " + stringBuilder.toString() + "";
        List<PrintTempletPrivateDBModel> list = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintTempletPrivateDBModel.class);
        if (!ListUtil.isEmpty(list)) {
            printTempletPrivateDBModels.addAll(list);
        }
        return printTempletPrivateDBModels;
    }

    public static ReceiptTempletModel copyTo(PrintTempletPrivateDBModel printTempletPrivateDBModel) {
        ReceiptTempletModel model = new ReceiptTempletModel();
        model.fiSelected = printTempletPrivateDBModel.fiSelected;
        model.templet = printTempletPrivateDBModel.fsTempletFile;
        model.templeteData = PrintTempletPublicDBUtils.queryTempleDataById(printTempletPrivateDBModel.fsTempletId);
        model.templetBizKey = printTempletPrivateDBModel.fsTempletKey;
        model.templetName = printTempletPrivateDBModel.fsTempletName;
        model.templetID = printTempletPrivateDBModel.fsTempletId;
        return model;
    }

    public static void updateUsedTempletById(String fsTempletId) {
        PrintTempletPrivateDBModel model = queryById(fsTempletId);
        String time = DateUtil.getCurrentTime();
        String resetSql = "update tbPrintTempletPrivate set fiSelected=0,fsUpdateTime='" + time + "',sync = 1 where fsTempletKey='" + model.fsTempletKey + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, resetSql);
        model.fiSelected = 1;
        model.fsUpdateTime = time;
        model.sync = 1;
        model.replaceNoTrans();
    }

    /**
     * 小票模版是否存在
     *
     * @param fsTempletId
     * @return
     */
    public static boolean isExist(String fsTempletId) {
        String sql = "select count(*) from tbPrintTempletPrivate where fsTempletId='" + fsTempletId + "'";
        return StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), 0) > 0;
    }

    public static HashMap<String, String> queryTempletUsedMap() {
        HashMap<String, String> templetUsedMap = new HashMap<>();
        ArrayList<String> templetUris = new ArrayList<>();
        templetUris.add(TicketTempletConstants.URI_DINNER_BILL);
        templetUris.add(TicketTempletConstants.URI_FAST_BILL);
        templetUris.add(TicketTempletConstants.URI_DINNER_PRE_BILL);
        templetUris.add(TicketTempletConstants.URI_TAKE_CUSTOM_BILL);
        templetUris.add(TicketTempletConstants.URI_TAKE_SHOP_BILL);
        templetUris.add(TicketTempletConstants.URI_KB_ORDER_MAKE);
        templetUris.add(TicketTempletConstants.URI_KB_CUSTOM_BILL);
        templetUris.add(TicketTempletConstants.URI_KB_SHOP_BILL);
        templetUris.add(TicketTempletConstants.URI_MEIXIAODIAN_BILL);
        for (String uri : templetUris) {
            templetUsedMap.put(uri, "");
        }
        ArrayList<PrintTempletPrivateDBModel> usedTemplets = queryUsedTempletByTempletKeys(templetUris);
        for (PrintTempletPrivateDBModel usedTemplet : usedTemplets) {
            templetUsedMap.put(usedTemplet.fsTempletKey, usedTemplet.fsTempletId);
        }
        return templetUsedMap;
    }
}
