package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.MenuItemMulDeptDBModel;
import com.mwee.android.pos.db.business.TransferprnDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 设备Util
 * Created by lxx on 16/7/5.
 */
public class DeviceDBUtil {

    /**
     * 制作部门+传菜部门
     *
     * @return
     */
    public static List<DeptDBModel> getAllDeptDBModels() {
        String sql = "select * from " + DBModel.getTableName(DeptDBModel.class);
        // " where fiDeptCls <> 1";
        List<DeptDBModel> deptDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, DeptDBModel.class);
        if (deptDBModelList == null) {
            deptDBModelList = new ArrayList<>();
        }
        return deptDBModelList;
    }

    /**
     * 获取所有打印机
     *
     * @return
     */
    public static List<PrinterDBModel> getAllPrinterDBModel() {
        String sql = "select * from " + DBModel.getTableName(PrinterDBModel.class) + " where fiStatus = '1'";
        List<PrinterDBModel> printerDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, PrinterDBModel.class);
        if (printerDBModelList == null) {
            printerDBModelList = new ArrayList<>();
        }
        return printerDBModelList;
    }

    /**
     * 获取所有站点
     *
     * @return List<HostDBModel>
     */
    public static List<HostDBModel> getAllHostDBModel(String shopiD) {
        String sql = "where fsShopGUID='" + shopiD + "' and fiStatus='1' order by fiHostCls desc";
        List<HostDBModel> hostDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, HostDBModel.class);
        if (hostDBModelList == null) {
            hostDBModelList = new ArrayList<>();
        }
        return hostDBModelList;
    }

    /**
     * 获得可用站点。
     * 先匹配收银站点,如果匹配到了,则check对应站点有没有配置打印机。
     * 如果没有配置打印机,则寻找其他站点。
     *
     * @param shopiD String
     * @return HostDBModel
     */
    public static HostDBModel getCurrentHost(String shopiD) {
        String sql = "where fsShopGUID='" + shopiD + "' and fiStatus='1' and fiHostCls='12'";
        List<HostDBModel> hostList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, HostDBModel.class);
        HostDBModel finalHost = null;
        if (hostList != null && hostList.size() > 0) {
            for (HostDBModel temp : hostList) {
                if (!TextUtils.isEmpty(temp.fsPrinterName)) {
                    finalHost = temp;
                    break;
                }
            }
        }
        if (finalHost == null) {
            sql = "where fsShopGUID='" + shopiD + "' and fiStatus='1' ";
            hostList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, HostDBModel.class);
            for (HostDBModel temp : hostList) {
                if (!TextUtils.isEmpty(temp.fsPrinterName)) {
                    finalHost = temp;
                    break;
                }
            }
        }
        return finalHost;
    }

    /**
     *
     * @param shopID
     * @param id
     * @return
     */
    public static HostDBModel getHostByID(String shopID,String id) {
        String sql = "where fsShopGUID='" + shopID + "' and fsHostId='"+id+"'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN,sql, HostDBModel.class);
    }

    /**
     * 传菜部门
     *
     * @return
     */
    public static List<DeptDBModel> getDeptDBModelsFromTransfer() {
        String sql = "select * from " + DBModel.getTableName(DeptDBModel.class) +
                " where fiDeptCls = '1' and fiStatus = '1'";

        List<DeptDBModel> deptDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, DeptDBModel.class);
        if (deptDBModelList == null) {
            deptDBModelList = new ArrayList<>();
        }
        return deptDBModelList;
    }


    /**
     * 传菜表
     *
     * @return
     */
    public static List<TransferprnDBModel> getTransferprnDBModels() {
        String sql = "select * from " + DBModel.getTableName(TransferprnDBModel.class) + "where fiStatus = '1'";

        List<TransferprnDBModel> transferprnDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, TransferprnDBModel.class);
        if (transferprnDBModelList == null) {
            transferprnDBModelList = new ArrayList<>();
        }
        return transferprnDBModelList;
    }

    public static List<DeptDBModel> getTransferprnDBModelsByfsDeptId_Make(String fsDeptId_Make) {
        String sql = "select b.* from ( select * from " + DBModel.getTableName(TransferprnDBModel.class)
                + " where fsDeptId_Transfer = '" + fsDeptId_Make + "' ) a left join ( select * from " + DBModel.getTableName(DeptDBModel.class)
                + " where fiStatus = '1' ) b on b.fsDeptId = a.fsDeptId_Make";

        List<DeptDBModel> deptDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, DeptDBModel.class);
        if (deptDBModels == null) {
            deptDBModels = new ArrayList<>();
        }
        return deptDBModels;
    }

    /**
     * 获取传菜部门数据
     *
     * @return 传菜部门名称---》 制作部门列表
     */
    public static Map<String, List<PrinterDBModel>> getTransferData() {
        Map<String, List<PrinterDBModel>> result = new HashMap<>();
        List<DeptDBModel> deptDBModelsForTransfer = getDeptDBModelsFromTransfer();
        for (DeptDBModel deptDBModel : deptDBModelsForTransfer) {
            List<PrinterDBModel> printerDBModels = new ArrayList<>();
            List<DeptDBModel> deptDBModels = getTransferprnDBModelsByfsDeptId_Make(deptDBModel.fsDeptId);
            for (DeptDBModel dbModels : deptDBModels) {
                if (!TextUtils.isEmpty(dbModels.fsDeptName)) {
                    PrinterDBModel printerDBModel = new PrinterDBModel();
                    printerDBModel.fsPrinterName = dbModels.fsDeptName;
                    printerDBModel.fsIP = dbModels.fsPrinterName;
                    printerDBModels.add(printerDBModel);
                }
            }
            result.put(deptDBModel.fsDeptName, printerDBModels);
        }
        return result;
    }

    /**
     * 根据部门ID获取部门名称
     *
     * @param deptID String
     * @return String
     */
    public static String getDeptNameByDeptID(String deptID) {
        if (TextUtils.isEmpty(deptID)) {
            return "";
        }
        String sql = " SELECT fsDeptName FROM "
                + DBModel.getTableName(DeptDBModel.class)
                + " where fsDeptId='" + deptID + "' and fiStatus = '1'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
    }

    /**
     * 根据部门ID获取打印机
     *
     * @param deptid String
     * @return PrinterDBModel
     */
    public static PrinterDBModel getPrinterByDeptID(String deptid) {
        if (TextUtils.isEmpty(deptid)) {
            return null;
        }
        String sql = "select * from " + DBModel.getTableName(PrinterDBModel.class)
                + "  where "
                + " fsPrinterName="
                + " (SELECT fsPrinterName FROM "
                + DBModel.getTableName(DeptDBModel.class)
                + " where fsDeptId='" + deptid + "' and fiStatus = '1') and fiStatus = '1'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN,sql, PrinterDBModel.class);
    }

    /**
     * 根据部门ID获取打印机名称
     *
     * @param deptid String
     * @return String
     */
    public static String getPrinterNameByDeptID(String deptid) {
        if (TextUtils.isEmpty(deptid)) {
            return null;
        }
        String sql = "select fsPrinterName from tbPrinter  where "
                + " fsPrinterName="
                + " (SELECT fsPrinterName FROM tbdept where fsDeptId='" + deptid + "' and fiStatus = '1') and fiStatus = '1'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 获取当前站点的打印机名称
     *
     * @return String
     */
    public static String getCurrentHostPrinterName() {
        String sql = "select fsPrinterName from tbPrinter  where "
                + " fsPrinterName="
                + " (SELECT fsPrinterName FROM tbhost where fshostid=(select value from meta where key='802') ) and fiStatus = '1'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
    }

    /**
     * 根据部门Model获取打印机
     *
     * @param deptDBModel DeptDBModel
     * @return PrinterDBModel
     */
    public static PrinterDBModel getPrinterByDept(DeptDBModel deptDBModel) {
        if (deptDBModel == null) {
            return null;
        }
        return getPrinterByPrinterName(deptDBModel.fsPrinterName);
    }

    public static PrinterDBModel getPrinterByHostID(String hostID) {
        if (TextUtils.isEmpty(hostID)) {
            return null;
        }
        String sql = "select * from tbPrinter  where "
                + " fsPrinterName="
                + " (SELECT fsPrinterName FROM tbhost where fshostid='" + hostID + "') and fiStatus = '1'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
    }

    /**
     *  返回站点打印机
     * @param hostID String
     * @return String
     */
    public static String getPrinterNameByHostID(String hostID) {
        if (TextUtils.isEmpty(hostID)) {
            return "";
        }
        String sql = "select fsPrinterName from tbPrinter  where "
                + " fsPrinterName="
                + " (SELECT fsPrinterName FROM tbhost where fshostid='" + hostID + "') and fiStatus = '1'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }
    /**
     * 根据打印机名称获取打印机
     *
     * @return PrinterDBModel
     */
    public static PrinterDBModel getPrinterByPrinterName(String printerName) {
        String sql = "where fsPrinterName='" + printerName + "' and fiStatus = '1'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN,sql, PrinterDBModel.class);
    }

    /**
     * 根据菜品Id获取关联的打印部门的关联关系数据
     *
     * @param menuItemCd 菜品ID
     * @return
     */
    public static List<MenuItemMulDeptDBModel> getAllDeptIdByMenuItemCd(String menuItemCd) {
        String sql = "where fiStatus = '1' and fiItemCd = '" + menuItemCd + "'";
        List<MenuItemMulDeptDBModel> result = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, MenuItemMulDeptDBModel.class);
        if (result == null) {
            result = new ArrayList<>();
        }
        return result;
    }

    /**
     * 通过站点名称 获取到该站点关联的电子秤
     *
     * @param fshostid 站点id
     * @return
     */
    public static HostexternalDBModel getHostexternalDBModel(String fshostid) {

        String sql = "select * from tbhostexternal where fiStatus = '1' and fsparamvalue = '2' and fiCls = '5'  and  fshostid = '" + fshostid + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN,sql, HostexternalDBModel.class);

    }

}
