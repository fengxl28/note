package com.mwee.myd.server.business.print;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.util.TempletIdManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 获取小票的模版
 */
public class CheckPrintTemplet {
    public static String checkKeyTemplet(String key) {
        if (DBMetaUtil.useTemplet()) {
//            return DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsTempletId,fsTempletFile from tbPrintTempletPrivate where fsTempletKey='" + key + "' and fiStatus='1' and fiSelected='1'");
            JSONObject obj = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsTempletId,fsTempletFile from tbPrintTempletPrivate where fsTempletKey='" + key + "' and fiStatus='1' and fiSelected='1'");
            if(obj != null){
                //小票模版如果是结账单-单序排序模版/预结单-单序排序模版，则要判断下是否开启了菜品合并开关,如果开启了，就不能使用此模版，使用原始样式
                if(TempletIdManager.isBill_2OrBill_4(obj.getString("fsTempletId"))){
                    if(PayConfig.PRINT_COMBINE_DISHES){
                        return null;
                    }
                }
                return obj.getString("fsTempletFile");
            }
            return null;
        } else {
            return null;
        }
    }
}
