package com.mwee.android.pos.businesscenter.netbiz.wechatfastfood;

import android.text.TextUtils;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.component.datasync.net.GetNetOrderByIdRequest;
import com.mwee.android.pos.component.datasync.net.GetNetOrderByIdResponse;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by lxx on 17/1/16.
 * 微信外卖
 */
public class WechatFastFoodApi {

    /**
     * 根据订单号拉取订单
     *
     * @param appOrderId
     * @return
     */
    public static String optWechatFastFoodOrderById(final String appOrderId, final IResponse<TempAppOrder> iResponse) {
        BusinessCallback callback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean instanceof GetNetOrderByIdResponse) {
                    GetNetOrderByIdResponse getDataResponse = (GetNetOrderByIdResponse) responseData.responseBean;
                    TempAppOrder tempAppOrder = getDataResponse.data;
                    if (iResponse != null) {
                        iResponse.callBack(true, 0, "", tempAppOrder);
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (iResponse != null) {
                    iResponse.callBack(false, 0, "", null);
                }
                return false;
            }
        };
        GetNetOrderByIdRequest getDataRequest = new GetNetOrderByIdRequest();
        getDataRequest.orderId = appOrderId;
        return BusinessExecutor.execute(getDataRequest, null, callback);
    }

    /**
     * 接单 -- 重试三次
     *
     * @param orderId
     * @param retrySeq
     * @param iResponse
     */
    public static void getOrderRequest(final String orderId, final String outerOrderId, final String mealNumber, final int retrySeq, final IResponse<String> iResponse, final boolean forceMainThread) {
        NetOrderApi.updateNetworkOrderStatus(orderId + "", "10", outerOrderId, "商家接单", mealNumber, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (NetOrderApi.class) {

                        if (TextUtils.equals(responseData.responseBean.errmsg, "订单已取消")) {

                            MessageOrderUtil.updateFastFoodMsg(orderId, "", "", MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
                            if (iResponse != null) {
                                iResponse.callBack(false, 0, "接单异常，请稍后重试", orderId + "");
                            }

                        } else {
                            if (iResponse != null) {
                                iResponse.callBack(true, 0, "", orderId + "");
                            }
                        }
                    }
                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "接单异常，请稍后重试", orderId + "");
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String orderStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select businessStatus from message where msgHead = '" + orderId + "'");
                            if (TextUtils.equals(orderStatus, "0")) {
                                getOrderRequest(orderId, outerOrderId, mealNumber, retrySeq + 1, iResponse, forceMainThread);
                            } else {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", orderId);
                                }
                            }
                        }
                    }, 2000);
                } else {
                    if (responseData != null && responseData.responseBean != null && TextUtils.equals(responseData.responseBean.errmsg, "订单已取消")) {
                        MessageOrderUtil.updateFastFoodMsg(orderId, "", "", MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
                    }
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, responseData.resultMessage, orderId);
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, retrySeq + "微信快餐订单自动接单异常，订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                return false;
            }
        }, forceMainThread);
    }

    /**
     * 取消订单 -- 重试三次
     *
     * @param orderId
     * @param retrySeq
     * @param iResponse
     */
    public static void updateWechatFastFoodStatus(final String orderId, final String diningStatus, final String outerOrderId, final String mealNumber, final int retrySeq, final IResponse<String> iResponse) {

        NetOrderApi.updateNetworkOrderStatus(orderId, diningStatus, outerOrderId, "更新订单状态", mealNumber, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (NetOrderApi.class) {
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", orderId);
                        }
                    }
                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "操作失败，请稍后重试", orderId);
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String orderStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select businessStatus from message where msgHead = '" + orderId + "'");
                            if ((TextUtils.equals("-2", diningStatus) && TextUtils.equals(orderStatus, "3")) ||
                                    (TextUtils.equals("30", diningStatus) && TextUtils.equals(orderStatus, "4"))) {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", orderId);
                                }
                            } else {
                                updateWechatFastFoodStatus(orderId, diningStatus, outerOrderId, mealNumber, retrySeq + 1, iResponse);
                            }
                        }
                    }, 2000);
                } else {

                    if (responseData != null && responseData.responseBean != null && TextUtils.equals(responseData.responseBean.errmsg, "订单已取消")) {
                        MessageOrderUtil.updateFastFoodMsg(orderId, "", "", MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
                    }

                    if (iResponse != null) {
                        iResponse.callBack(false, 0, responseData.resultMessage, orderId);
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "微信外卖订单拒绝异常，订单号：" + orderId + "；异常信息：" + responseData.resultMessage);
                return false;
            }
        }, false);
    }


}
