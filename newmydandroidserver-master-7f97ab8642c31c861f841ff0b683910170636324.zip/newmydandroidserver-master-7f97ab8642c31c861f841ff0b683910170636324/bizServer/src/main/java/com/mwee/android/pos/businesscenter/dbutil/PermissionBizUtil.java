package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permission.PermissionCheckDinner;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.permission.MenuSimpleInfo;
import com.mwee.android.pos.connect.business.permission.CheckPermissionResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.UserMenuItemRoleDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.permission.PermissionUserSimpInfo;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 */

public class PermissionBizUtil {

    /**
     * 获取到退菜  赠菜 打折 反结账 理由
     *
     * @param fsProgDtlId
     */
    public static List<String> getReasonsForProg(String fsProgDtlId, String discountId) {

        List<String> listReasons = new ArrayList<>();
        String fsFieldItem = "";

        switch (fsProgDtlId) {
            case Permission.DINNER_vBackAuth://退菜
                fsFieldItem = "BackReason";
                //1 当前是退菜操作 并且 退菜理由按钮打开 弹出退菜理由选择 否则不弹
                if (TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.REASON_VOID, "1"), "0")) {
                    return listReasons;
                }
                break;
            case Permission.DINNER_vGiftAuth://赠送
                fsFieldItem = "GiftReason";
                // 2 当前是赠送操作 并且 赠送理由按钮打开 弹出赠送理由选择 否则不弹
                if (TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.REASON_GIFT, "1"), "0")) {
                    return listReasons;
                }
                break;
            case Permission.DINNER_vDiscount://折扣 特殊情况
                fsFieldItem = "DiscountReason";
                // 3 当前是折扣操作 并且 折扣理由按钮打开 弹出折扣理由选择 否则不弹
                String sql = "select fiDiscReason from tbdiscount where fsDiscountId = '" + discountId + "' and fiStatus = '1'";
                if (TextUtils.equals(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), "0")) {
                    return listReasons;
                }
                break;
            case Permission.DINNER_vReCheckAuth://反结账
                fsFieldItem = "ReCheckReason";
                // 4 当前是反结账操作 并且 反结账理由按钮打开 弹出反结账理由选择 否则不弹
                if (TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.REASON_RECHECKAUTH, "1"), "0")) {
                    return listReasons;
                }
                break;
        }
        if (TextUtils.isEmpty(fsFieldItem)) {
            return listReasons;
        }

        String sql = "select fsWord from tbwordhouse where fiStatus = '1' and fsFieldItem = '" + fsFieldItem + "'";
        listReasons = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        return listReasons;
    }

    /**
     * 获取拥有fsProgDtlId权限的所有的用户
     *
     * @param fsProgDtlId 功能代码 (e.g. 反结账,赠菜...)
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllUserByProgdtlId(String fsProgDtlId) {
        String sql = "select * from tbuser where fiStatus = '1' and fsUserId in (  " +
                " select fsUserId from tbuserrole where fsRoleId in  (select fsRoleId from tbauthoritydtl where fsProgDtlId = '" + fsProgDtlId + "' and fiStatus = '1' and fiUsable = '1' and fsProgId = '" + Permission.PRD_DINNER + "' ) " +
                " and fistatus = '1' )";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:没查询到任何有权限的员工; fsProgDtlId = " + fsProgDtlId);
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }

    /**
     * 获取拥有报表查看权限的所有的用户
     *
     * @param fsProgDtlId 功能代码 (e.g. 反结账,赠菜...)
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllReportUserByProgdtlId(String fsProgDtlId) {
        String sql = "select * from tbuser where fiStatus = '1' and fsUserId in (  " +
                " select fsUserId from tbuserrole where fsRoleId in  (select fsRoleId from tbauthoritydtl where fsProgDtlId = '" + fsProgDtlId + "' and fiStatus = '1' and fiUsable = '1' and fsProgId = '" + Permission.PRD_PRINT + "' ) " +
                " and fistatus = '1' )";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:没查询到任何有权限的员工; fsProgDtlId = " + fsProgDtlId);
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }

    /**
     * 获取拥有站点维护权限的所有的用户
     *
     * @param fsProgDtlId 功能代码 (e.g. 反结账,赠菜...)
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllHostManageUserByProgdtlId(String fsProgDtlId) {
        String sql = "select * from tbuser where fiStatus = '1' and fsUserId in (  " +
                " select fsUserId from tbuserrole where fsRoleId in  (select fsRoleId from tbauthoritydtl where fsProgDtlId = '" + fsProgDtlId + "' and fiStatus = '1' and fiUsable = '1' and fsProgId = '" + Permission.PRD_HOST + "' ) " +
                " and fistatus = '1' )";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:没查询到任何有权限的员工; fsProgDtlId = " + fsProgDtlId);
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }


    /**
     * 获取拥有fsDiscountId 所有的用户
     *
     * @param fsDiscountId 功能代码 (e.g. 反结账,赠菜...)
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllUserByDiscountId(String fsDiscountId) {

        String sql = "select * from tbuser where fiStatus = '1' and fsUserId in " +
                "(select fsuserId from tbuserDiscount where fiStatus = '1' and fsDiscountId =  '" + fsDiscountId + "')";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:没查询到任何有权限的员工; fsProgDtlId = " + fsDiscountId);
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }

    /**
     * 获取拥有fsDiscountId, 且拥有允许折扣率 所有的用户
     *
     * @param fsDiscountId
     * @param discountRate
     * @return
     */
    public static List<PermissionUserSimpInfo> getAllUserByDiscountId(String fsDiscountId, int discountRate) {
        String sql = "SELECT * FROM tbuser WHERE fiStatus = '1' AND fsUserId IN (SELECT fsUserId FROM tbuserdiscount WHERE fsDiscountId = '" + fsDiscountId + "' AND fistatus = '1') AND fiUserDiscount >= '" + discountRate + "';";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:没查询到任何有权限的员工; fsProgDtlId = " + fsDiscountId + ", rate = " + discountRate);
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }

    /**
     * 小散模式--获取所有有打折权限的用户
     *
     * @return
     */
    public static List<PermissionUserSimpInfo> getAllDiscountUserForAirShop() {

        String sql = "select * from tbuser where fiStatus = '1' and fiIsDiscount = '0'";
        List<PermissionUserSimpInfo> userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (userDBModels == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "小散商户打折权限验证:没查询到任何有权限的员工; ");
            userDBModels = new ArrayList<>();
        }
        return userDBModels;
    }

    /**
     * 获取拥有XX权限的所有用户 所有的用户
     *
     * @param fiType       权限类型 ： 0 ：退菜， 1：赠菜
     * @param menuInfoList 被授权菜品列表
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllUserByType(int fiType, List<MenuSimpleInfo> menuInfoList) {
        if (ListUtil.isEmpty(menuInfoList)) {
            return new ArrayList<>();
        }
        //1、查出所有有且仅有某些特定菜品操作权限的用户
        List<PermissionUserSimpInfo> userDBModelsLimit = getUsers(fiType, menuInfoList);
        if (userDBModelsLimit == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:查出所有有且仅有某些特定菜品操作权限的用户 --> 结果为空 （fiType = " + fiType + "）");
            userDBModelsLimit = new ArrayList<>();
        }

        //2、查询所有有权限又不受限制的用户
        String sqlSuperParam = " and fsProgDtlId = 'vBackAuth')) and  fiIsRetreatFood = '0' ";
        if (fiType == 1) {
            sqlSuperParam = " and fsProgDtlId = 'vGiftAuth')) and  fiisgift = '0' ";
        }
        String sqlSuper = "select fsUserId, fsUserName, fsiccardcode, fiIsRetreatFood from tbUser where " +
                " fiStatus = '1' and fsUserId in (select distinct fsUserId from tbUserRole where fiStatus='1' and fsRoleId in (select fsRoleID from tbAuthorityDtl where fsProgId='fmMealPos' and fiusable='1' " + sqlSuperParam;

        List<PermissionUserSimpInfo> userDBModelsSuper = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlSuper, PermissionUserSimpInfo.class);
        if (userDBModelsSuper == null) {
            RunTimeLog.addLog(RunTimeLog.PERMISSION, "权限验证:查询所有有权限又不受限制的用户-->结果为空（fiType = " + fiType + "）");
            userDBModelsSuper = new ArrayList<>();
        }

        //3、合并
        userDBModelsSuper.addAll(userDBModelsLimit);

        return userDBModelsSuper;
    }

    private static List<PermissionUserSimpInfo> getUsers(int fiType, List<MenuSimpleInfo> menuInfoList) {
        List<String> idList = getItemCdAndUnitCd(menuInfoList);
        if (ListUtil.isEmpty(idList)) {
            return new ArrayList<>();
        }
        String idStr;
        StringBuilder finduserIdsqlParams = new StringBuilder();
        for (String id : idList) {
            finduserIdsqlParams.append("'").append(id).append("'").append(",");
        }
        idStr = finduserIdsqlParams.toString();
        if (idStr.length() > 0) {
            idStr = idStr.substring(0, idStr.length() - 1);
        }
        String finduserIdsql = "select count(*) count, fsuserId, fiItemCd||'_'||fiorderUintCd as cds from tbuserMenuItemRole where fiType = '" + fiType + "'  and fistatus = '1' and cds in (" + idStr + ") group by fsuserId ";
        String sqlFilterAuth = " AND " + (fiType == 0 ? "tbUser.fiIsRetreatFood" : "tbUser.fiisgift") + " = '1' ";
        String sql = "select * from tbuser left join (" + finduserIdsql + ") userIds on tbuser.fsuserId = userIds.fsuserId where userIds.count = " + idList.size() + " and tbuser.fistatus = '1'" + sqlFilterAuth;
        List<PermissionUserSimpInfo> userDBModelsLimit = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PermissionUserSimpInfo.class);
        if (ListUtil.isEmpty(userDBModelsLimit)) {
            return new ArrayList<>();
        }
        return userDBModelsLimit;
    }

    private static List<String> getItemCdAndUnitCd(List<MenuSimpleInfo> menuInfoList) {
        List<String> idList = new ArrayList<>();
        if (!ListUtil.isEmpty(menuInfoList)) {
            for (MenuSimpleInfo menuSimpleInfo : menuInfoList) {
                if (menuSimpleInfo == null) {
                    continue;
                }
                idList.add(menuSimpleInfo.fiItemCd + "_" + menuSimpleInfo.fiOrderUintCd);
            }
        }
        return idList;
    }


    /**
     * 获取某用户名下某权限的所有有效菜品
     *
     * @param fsUserId 服务员ID
     * @param fiType   退菜/赠菜(0:退菜，1:赠菜)
     * @return
     */
    public static List<String> getUsersByPermission(String fsUserId, int fiType) {
        List<String> itemsInfoList = new ArrayList<>();
        String sql = "select * from tbuserMenuItemRole where fsUserId = '" + fsUserId + "' and fiType = '" + fiType + "'  and fiStatus = '1' ";
        List<UserMenuItemRoleDBModel> userMenuItemRoleDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, UserMenuItemRoleDBModel.class);
        if (ListUtil.isEmpty(userMenuItemRoleDBModelList)) {
            return itemsInfoList;
        }

        for (UserMenuItemRoleDBModel userMenuItemRoleDBModel : userMenuItemRoleDBModelList) {
            if (userMenuItemRoleDBModel == null) {
                continue;
            }
            itemsInfoList.add(userMenuItemRoleDBModel.fiItemCd + "_" + userMenuItemRoleDBModel.fiOrderUintCd);
        }
        return itemsInfoList;
    }

    public static boolean checkMenuOptPermissionByUser(String fsUserId, List<MenuSimpleInfo> menuList, int fiType) {
        if (TextUtils.isEmpty(fsUserId)) {
            return false;
        }
        if (ListUtil.isEmpty(menuList)) {
            return true;
        }
        boolean result = false;

        StringBuilder sb = new StringBuilder();
        for (MenuSimpleInfo info : menuList) {
            sb.append("'").append(info.fiItemCd).append("_").append(info.fiOrderUintCd).append("'").append(",");
        }
        String param = sb.toString();
        if (!TextUtils.isEmpty(param) && param.length() > 1) {
            param = param.substring(0, param.length() - 1);
        }

        String sql = "SELECT count(*)\n" +
                "FROM (SELECT fiItemCd || '_' || fiOrderUintCd AS menuinfo\n" +
                "      FROM tbuserMenuItemRole\n" +
                "      WHERE fsUserId = '" + fsUserId + "'\n" +
                "        AND fitype = '" + fiType + "'\n" +
                "        AND fiStatus = '1') m\n" +
                "WHERE m.menuinfo IN (" + param + ")";
        int match = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), 0);
        return match == menuList.size();
    }

    /**
     * 校验授权用户
     *
     * @param waiterId     用户ID
     * @param pwd          用户密码
     * @param hostId       操作站点ID
     * @param fsiccardcode IC 卡
     * @return
     */
    public static String checkPermissionAuthor(String waiterId, String pwd, String hostId, String fsiccardcode) {
        UserDBModel loginUser;
        if (TextUtils.isEmpty(pwd)) { //校验IC卡号是否正确
            loginUser = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbUser where fsiccardcode = '" + fsiccardcode + "' and fiStatus <> '13' order by fiStatus desc ", UserDBModel.class);
            if (loginUser == null) {
                return "卡号不正确。";
            }
        } else { //校验账户密码登录的场景
            //判断服务员重复登录的状况
            if (TextUtils.isEmpty(waiterId)) {
                return "用户名为空";
            }

            /**
             * 校验账号信息是否有效
             */
            String validSql = "select * from tbUser where fsUserId = '" + waiterId + "' and fiStatus <> '13' order by fiStatus desc ";
            loginUser = DBSimpleUtil.query(APPConfig.DB_MAIN, validSql, UserDBModel.class);

            if (loginUser == null) {
                return "未查到该账户";
            }

            if (!TextUtils.equals(loginUser.fsPwd, pwd)) { //校验密码是否正确
                return "密码不正确。";
            }
        }

        if (loginUser.fiStatus != 1) {
            return "该账户已被停用";
        }

        return "";
    }

    public static String checkPermission(CheckPermissionResponse responseData, String waiterId, String fsProgDtlId, String permissionType, String fsDiscountId, List<MenuSimpleInfo> menuInfoLists) {
        return checkPermission(responseData, waiterId, fsProgDtlId, permissionType, fsDiscountId, menuInfoLists, -1);
    }

    /**
     * 验证权限
     *
     * @param responseData
     * @param waiterId       服务员iD
     * @param fsProgDtlId    操作ID
     * @param permissionType 权限类型
     * @param fsDiscountId   折扣ID
     * @param menuInfoLists  菜品列表
     * @return
     */
    public static String checkPermission(CheckPermissionResponse responseData, String waiterId, String fsProgDtlId, String permissionType, String fsDiscountId, List<MenuSimpleInfo> menuInfoLists, int rate) {

        boolean hasPermission;
        switch (permissionType) {
            case Permission.DINNER_vBackAuth: {  //退菜权限
                if (ListUtil.isEmpty(menuInfoLists)) {
                    return "请选择退菜菜品";
                }

                UserDBModel user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbUser where fsUserId = '" + waiterId + "' and fiStatus = '1' order by fiStatus asc ", UserDBModel.class);
                if (user == null) {
                    return "服务员账号无效";
                }
                hasPermission = PermissionCheckDinner.hasPermission(waiterId, fsProgDtlId);
                if (hasPermission && user.fiIsRetreatFood != 0) {  //有部分退菜权限---校验菜品是否在退菜范围内
//                    //1、查出所有有权限的菜品 A集合
//                    //2、校验申请权限的菜品B集合是否是A集合的子集
//                    List<String> validmenuItems = PermissionBizUtil.getUsersByPermission(waiterId, 0);
//
//                    if (ListUtil.isEmpty(validmenuItems)) {
//                        hasPermission = false;
//                    } else {
//                        for (MenuSimpleInfo menuIfo : menuInfoLists) {
//                            if (!validmenuItems.contains(menuIfo.fiItemCd + "_" + menuIfo.fiOrderUintCd)) {
//                                hasPermission = false;
//                                break;
//                            }
//                        }
//                    }
                    hasPermission = PermissionBizUtil.checkMenuOptPermissionByUser(waiterId, menuInfoLists, 0);
                }

                if (!hasPermission) {
                    responseData.permissionUserList = PermissionBizUtil.getAllUserByType(0, menuInfoLists);
                }
            }
            break;
            case Permission.DINNER_vGiftAuth: { //赠送权限

                if (ListUtil.isEmpty(menuInfoLists)) {
                    return "请选择赠菜菜品";
                }

                UserDBModel user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbUser where fsUserId = '" + waiterId + "' and fiStatus = '1' order by fiStatus asc ", UserDBModel.class);
                if (user == null) {
                    return "服务员账号无效";
                }
                hasPermission = PermissionCheckDinner.hasPermission(waiterId, fsProgDtlId);
                if (hasPermission && user.fiisgift != 0) {  //有部分赠菜权限---校验菜品是否在退菜范围内
//                    //1、查出所有有权限的菜品 A集合
//                    //2、校验申请权限的菜品B集合是否是A集合的子集
//                    List<String> validmenuItems = PermissionBizUtil.getUsersByPermission(waiterId, 1);
//
//                    if (ListUtil.isEmpty(validmenuItems)) {
//                        hasPermission = false;
//                    } else {
//                        for (MenuSimpleInfo menuIfo : menuInfoLists) {
//                            if (!validmenuItems.contains(menuIfo.fiItemCd + "_" + menuIfo.fiOrderUintCd)) {
//                                hasPermission = false;
//                                break;
//                            }
//                        }
//                    }
                    hasPermission = PermissionBizUtil.checkMenuOptPermissionByUser(waiterId, menuInfoLists, 1);
                }

                if (!hasPermission) {
                    responseData.permissionUserList = PermissionBizUtil.getAllUserByType(1, menuInfoLists);
                }
            }
            break;
            case Permission.DINNER_vDiscount: //折扣权限

                UserDBModel user = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbUser where fsUserId = '" + waiterId + "' and fiStatus = '1' order by fiStatus asc ", UserDBModel.class);
                if (user == null) {
                    return "服务员账号无效";
                }

                //小散商户只判断用户是否
                if (APPConfig.isAir()) {
                    hasPermission = user.fiIsDiscount != 1;
                    if (!hasPermission) {
                        responseData.permissionUserList = PermissionBizUtil.getAllDiscountUserForAirShop();
                    }
                } else if (rate > -1) {
                    hasPermission = PermissionCheckDinner.canDiscountAuth(waiterId, fsDiscountId, rate);
                    if (!hasPermission) {
                        responseData.permissionUserList = PermissionBizUtil.getAllUserByDiscountId(fsDiscountId, rate);
                    }
                } else {
                    hasPermission = PermissionCheckDinner.canDiscountAuth(waiterId, fsDiscountId);
                    if (!hasPermission) {
                        responseData.permissionUserList = PermissionBizUtil.getAllUserByDiscountId(fsDiscountId);
                    }
                }
                break;
            case "report":  //报表查看权限
                hasPermission = Permission.hasPermissionPrint(waiterId, fsProgDtlId);
                if (!hasPermission) {//没有权限
                    responseData.permissionUserList = PermissionBizUtil.getAllReportUserByProgdtlId(fsProgDtlId);
                }
                break;
            case Permission.DINNER_vMaintain:  //站点维护
                hasPermission = Permission.hasPermissionDinnerHost(waiterId, fsProgDtlId);
                if (!hasPermission) {//没有权限
                    responseData.permissionUserList = PermissionBizUtil.getAllHostManageUserByProgdtlId(fsProgDtlId);
                }
                break;
            default:
                hasPermission = PermissionCheckDinner.hasPermission(waiterId, fsProgDtlId);
                if (!hasPermission) {//没有权限
                    responseData.permissionUserList = PermissionBizUtil.getAllUserByProgdtlId(fsProgDtlId);
                }
                break;
        }
        responseData.hasPermission = hasPermission;
        //理由
        responseData.listReasons = PermissionBizUtil.getReasonsForProg(fsProgDtlId, fsDiscountId);
        return "";
    }


    /**
     * 获取拥有XX权限的所有用户 所有的用户
     *
     * @param molingAmt 最高支付金额
     * @return 有权限的员工集合
     */
    public static List<PermissionUserSimpInfo> getAllUserMoLing(BigDecimal molingAmt) {
        if (molingAmt == null || molingAmt.compareTo(BigDecimal.ZERO) < 0) {
            molingAmt = BigDecimal.ZERO;
        }
        String amt = molingAmt.stripTrailingZeros().toPlainString();
        String sql = "select * from tbuser where fistatus = '1' and fsUserId <> 'cash' and (fiIsMaxReduce == '0' or (fiIsMaxReduce == '1' and fdMaxReducePrice >= '%s'))";
        List<PermissionUserSimpInfo> userDBModelsLimit = DBSimpleUtil.queryList(APPConfig.DB_MAIN, String.format(sql, amt), PermissionUserSimpInfo.class);
        if (ListUtil.isEmpty(userDBModelsLimit)) {
            return new ArrayList<>();
        }
        return userDBModelsLimit;
    }


}
