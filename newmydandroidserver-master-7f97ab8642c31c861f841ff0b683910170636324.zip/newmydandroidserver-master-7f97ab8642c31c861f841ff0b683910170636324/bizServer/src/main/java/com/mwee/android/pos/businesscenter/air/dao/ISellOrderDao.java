package com.mwee.android.pos.businesscenter.air.dao;

import com.mwee.android.pos.db.business.SellOrderDBModel;

/**
 * Created by qinwei on 2018/10/29.
 */

public interface ISellOrderDao extends IBaseDao<SellOrderDBModel> {
    boolean isExistByThirdSeq(String fsThirdBatchNo);
}
