package com.mwee.android.pos.businesscenter.air.driver;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.wechatorder.GetWechatSettingResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AirWechatOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadChangeDataProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by liuxiuxiu on 2017/6/16.
 * 桌台管理相关操作
 */
@SuppressWarnings("unused")
public class AirWechatOrderManagerDriver implements IDriver {

    private static final String TAG = "airWechatOrderManager";

    /**
     * 获取所有微信外卖设置
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadWechatOrderSetting")
    public SocketResponse loadWechatOrderSetting(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetWechatSettingResponse responseData = new GetWechatSettingResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayMap<String, String> stringArrayMap = AirWechatOrderDBUtil.optWechatOrderSettings();
            String address = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsAddr from tbshop where fsShopGUID = '" + head.shopid + "'");
            if (TextUtils.isEmpty(address)) {
                address = "";
            }
            stringArrayMap.put("address", address);
            responseData.stringList = stringArrayMap;

            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 更新外卖设置
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateWechatOrderSetting")
    public SocketResponse updateWechatOrderSetting(final SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            final ArrayMap<String, String> stringStringArrayMap = JSONObject.parseObject(request.getString("settings"), ArrayMap.class);
            if (stringStringArrayMap == null) {
                response.message = "数据异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            double longitude = 0d;
            double latitude = 0d;
            try {
                longitude = Double.valueOf(stringStringArrayMap.get("longitude"));
                latitude = Double.valueOf(stringStringArrayMap.get("latitude"));
            } catch (Exception ex) {
                response.message = "餐厅定位失败，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (longitude == 0d && latitude == 0d) {
                AirWechatOrderDBUtil.updateWechatOrderSetting(stringStringArrayMap, head.shopid, userDBModel.fsUserId, userDBModel.fsUserName);
                response.code = SocketResultCode.SUCCESS;
                response.message = "更新成功";
            } else {
                UploadChangeDataProcessor.doEditShop(head.shopid, longitude, latitude, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        AirWechatOrderDBUtil.updateWechatOrderSetting(stringStringArrayMap, head.shopid, userDBModel.fsUserId, userDBModel.fsUserName);
                        response.code = SocketResultCode.SUCCESS;
                        response.message = "更新成功";
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "餐厅定位上传失败";
                        return false;
                    }
                });
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}
