package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.print.PrintBillMenuItemMode;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/12/4.
 */

public class MenuPrinterTaskUtil {
    /**
     * 构建菜品相关小票打印任务
     *
     * @param printTaskIds
     * @param task
     * @param printData
     */
    public static void buildMenuPrinterTaskAndPrint(List<Integer> printTaskIds, PrintTaskDBModel task, JSONObject printData) {
        ArrayList<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        if (task.uri.equals("bill/orderbill") || task.uri.equals("fastFoodBill/orderbill") || task.uri.equals("bill/prebill")) {
//            结账单读打印配置
            String fsParamValue = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_LANGUAGE, "-1");
            printData.put("print_language",fsParamValue);
            switch (fsParamValue) {
                case "0":
                case "-1":
                    //只打印第一语言
                    task.fsPrnData = printData.toJSONString();
                    printTaskDBModels.add(task);
                    break;
                case "1":
                    //只打印第二语言
                    buildSecondLanguageData(task.uri, printData);
                    task.fsPrnData = printData.toJSONString();
                    printTaskDBModels.add(task);
                    break;
                case "2":
                    //两者都打印-3.3需求-将两张合为一张（仅支持代码构建）
                    task.fsPrnData = printData.toJSONString();
                    printTaskDBModels.add(task);

//                    PrintTaskDBModel two = task.clone();
//                    JSONObject secondLanguageData = (JSONObject) printData.clone();
//                    // printData 已经转为 String 赋值给第一语言的 task, 这里 clone 没有意义
////                    List<PrintBillMenuItemMode> sellorders = JSONObject.parseArray(JSON.toJSONString(printData.get("sellorder")),PrintBillMenuItemMode.class);
////                    List<PrintBillMenuItemMode> sellorder = ListUtil.cloneList(sellorders);
////                    printData.put("sellorder", sellorder);
//                    buildSecondLanguageData(task.uri, secondLanguageData);
//                    int printNO = PrintJSONBuilder.generatePrintNO();
//                    secondLanguageData.put("fiPrintNo", printNO);
//                    two.fiPrintNo = printNO;
//                    two.fsPrnData = secondLanguageData.toJSONString();
//                    printTaskDBModels.add(two);
                    break;
                default:
                    break;
            }
        } else {
            //其他走正常打印
            task.fsPrnData = printData.toJSONString();
            printTaskDBModels.add(task);
        }
        if (TextUtils.isEmpty(task.fsPrnData)) {
            RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印出现异常，没有fsPrnData数据", JSON.toJSONString(task), printData);
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildMenuPrinterTaskAndPrint--79" );
        for (PrintTaskDBModel printTaskDBModel : printTaskDBModels) {
            CheckAndPrintUtil.buildTaskEnvAndPrint(printTaskDBModel);
            if (!printTaskDBModel.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildMenuPrinterTaskAndPrint--end" );
    }

    public static void buildSecondLanguageData(String uri, JSONObject printData) {
        switch (uri) {
//            case "order/menulist":
//            case "fastFoodorder/menulist":
//                //点菜单第二语言构建
//                List<PrintItemDataBean> sellOrderItemDBModels = (List<PrintItemDataBean>) printData.get("SellOrder");
//                for (PrintItemDataBean sellOrderItemDBModel : sellOrderItemDBModels) {
//                    if (!TextUtils.isEmpty(sellOrderItemDBModel.fsItemName2)) {
//                        sellOrderItemDBModel.fsItemName = sellOrderItemDBModel.fsItemName2;
//                    }
//                }
//                printData.put("SellOrder", sellOrderItemDBModels);
//                break;
//            case "order/makesingleTSC":
//            case "order/makesingle":
//            case "fastFoodorder/makesingleTSC":
//            case "fastFoodorder/makesingle":
//                //一菜一切
//                PrintItemDataBean printItemDataBean = (PrintItemDataBean) printData.get("SellOrder");
//                if (!TextUtils.isEmpty(printItemDataBean.fsItemName2)) {
//                    printItemDataBean.fsItemName = printItemDataBean.fsItemName2;
//                }
//                printData.put("SellOrder", printItemDataBean);
//                break;
//            case "order/make":
//            case "fastFoodorder/make":
//                //制作单第二语言构建
//                List<PrintItemDataBean> sellOrders = (List<PrintItemDataBean>) printData.get("SellOrders");
//                for (PrintItemDataBean sellOrderItemDBModel : sellOrders) {
//                    if (!TextUtils.isEmpty(sellOrderItemDBModel.fsItemName2)) {
//                        sellOrderItemDBModel.fsItemName = sellOrderItemDBModel.fsItemName2;
//                    }
//                }
//                printData.put("SellOrders", sellOrders);
//                break;
            case "bill/prebill":
            case "bill/orderbill":
            case "fastFoodBill/orderbill":
                //结账单
                //制作单第二语言构建

                // 修改原菜品第二语言
                List<PrintBillMenuItemMode> sellorders = JSONObject.parseArray(JSON.toJSONString(printData.get("sellorder")), PrintBillMenuItemMode.class);
                for (PrintBillMenuItemMode sellOrderItemDBModel : sellorders) {
                    if (!TextUtils.isEmpty(sellOrderItemDBModel.fsItemName2)) {
                        sellOrderItemDBModel.fsItemName = sellOrderItemDBModel.fsItemName2 + "(" + sellOrderItemDBModel.fsOrderUint + ")";
                    }
                }
                printData.put("sellorder", sellorders);

                // 修改「分类排序」第二语言
                printData.put("sellorderGroupByCls", processDataByTime(printData.getJSONArray("sellorderGroupByCls")));

                // 修改「单序排序」第二语言
                printData.put("sellorderGroupByTime", processDataByTime(printData.getJSONArray("sellorderGroupByTime")));
                break;
            default:
                break;
        }
    }

    /**
     * 「单序排序」菜品处理第二语言
     * 「分类排序」结构类似「单序排序」，同样使用此方法处理
     *
     * @param data
     * @return
     */
    private static JSONArray processDataByTime(JSONArray data) {
        JSONArray result = new JSONArray();

        if (data == null || data.size() == 0) {
            return result;
        }

        for (int index = 0; index < data.size(); index++) {
            JSONObject sellOrder = data.getJSONObject(index);
            if (sellOrder == null) {
                continue;
            }
            List<PrintBillMenuItemMode> menuItemList = JSONObject.parseArray(JSON.toJSONString(sellOrder.get("menuItemList")), PrintBillMenuItemMode.class);
            if (ListUtil.isEmpty(menuItemList)) {
                continue;
            }
            for (PrintBillMenuItemMode itemMode : menuItemList) {
                if (!TextUtils.isEmpty(itemMode.fsItemName2)) {
                    itemMode.fsItemName = itemMode.fsItemName2 + "(" + itemMode.fsOrderUint + ")";
                }
            }
            sellOrder.put("menuItemList", menuItemList);
            result.add(sellOrder);
        }

        return result;
    }
}
