package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.udp.UDPBroadcastSender;
import com.mwee.android.pos.udp.Pack;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;

/**
 * UDP广播的相关Driver
 * Created by virgil on 16/9/6.
 */
public class UdpPushDriver implements IDriver {
    @Override
    public String getModuleName() {
        return "udppush";
    }

    public static void doBroadCast() {
        String ip = DeviceUtil.getLocalIpAddress();
        String shopID = HostUtil.getShopID();
        if (!TextUtils.isEmpty(shopID) && !TextUtils.isEmpty(ip)) {
            doBroadCast(ip, shopID);
        }
    }

    public static void doBroadCast(String ip, String shopID) {
        Pack pack = Pack.build();
        pack.method = "receiveip";
        JSONObject ob = new JSONObject();
        ob.put("ip", ip);
        ob.put("shopid", shopID);
        ob.put("ips",DeviceUtil.getLocalIpList());
        pack.value = ob.toString();

        UDPBroadcastSender.sendToHost(JSON.toJSONString(pack));
    }

    @DrivenMethod(uri = "udppush/broad")
    public void a(String ip, String shopID) {
        doBroadCast(ip, shopID);
    }

    @DrivenMethod(uri = "udppush/search")
    public void b(String value) {
        LogUtil.log("UdpPushDriver receive 'udppush/search' start doBroadCast");
        JSONObject ob = null;
        try {
            ob = JSON.parseObject(value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (BindProcessor.isCurrentHostMain()) {
            if (ob != null) {
                String shopID = ob.getString("shopid");
                String currentShopid = HostUtil.getShopID();
                if (TextUtils.isEmpty(shopID)) {
                    doBroadCast();
                } else if (!TextUtils.isEmpty(shopID) && TextUtils.equals(shopID, currentShopid)) {
                    doBroadCast();
                }
            } else {
                doBroadCast();
            }
        }
    }


}
