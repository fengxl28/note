package com.mwee.android.pos.businesscenter.db;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by qinwei on 2019/3/15 2:27 PM
 * email: qin.wei@mwee.cn
 */
public class DTOPrinterDBController {
    /**
     * @param fsMAreaId
     * @return
     */
    public static String queryPrinterNameByFsMAreaId(String fsMAreaId) {
        String sql = "select fsPrinterName from tbPrinter where fsPrinterName in (select fsPrinterName from tbmarea where fsMAreaId='" + fsMAreaId + "');";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }
}
