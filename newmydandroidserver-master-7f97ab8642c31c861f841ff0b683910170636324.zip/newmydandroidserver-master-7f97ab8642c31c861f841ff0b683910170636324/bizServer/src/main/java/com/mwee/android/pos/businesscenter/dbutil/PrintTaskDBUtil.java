package com.mwee.android.pos.businesscenter.dbutil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.order.Order;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/5/11.
 */

public class PrintTaskDBUtil {

    /**
     * 获取指定打印任务
     *
     * @param printNoparam
     * @param hostId
     * @return
     */
    public static List<PrintTaskDBModel> getPrintTaskList(String printNoparam, String hostId) {
        String sql = "select * from tbPrintTask where fiPrintNo in (" + printNoparam + ") and fsHostId = '" + hostId + "'";
        List<PrintTaskDBModel> printTaskDBModels = DBSimpleUtil.queryList(APPConfig.DB_PRINT, sql, PrintTaskDBModel.class);
        if (ListUtil.isEmpty(printTaskDBModels)) {
            return new ArrayList<>();
        }
        return printTaskDBModels;
    }

    /**
     * 获取未打印任务printNo
     *
     * @param hostId
     * @return
     */
    public static List<Integer> getUnPrintTaskNoList(String hostId) {
        String sql = "select fiPrintNo from tbPrintTask where fsHostId = '" + hostId + "' and fiStatus = '1'";
        List<Integer> unPrintNoList = DBSimpleUtil.queryElementList(APPConfig.DB_PRINT, sql,Integer.class);
        if (ListUtil.isEmpty(unPrintNoList)) {
            return new ArrayList<>();
        }
        return unPrintNoList;
    }

    /**
     * 获取433打印机打印失败和未打印的task
     * @return
     */
    public static List<PrintTaskDBModel> get433PrintErrorTask(){
        List<String> printerNameList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN,"select fsPrinterName from tbPrinter where fiPrinterCls = '"+ PrinterType.P433+"'");
        if (ListUtil.isEmpty(printerNameList)) {
            return new ArrayList<>();
        }
        String sqlParam = ListUtil.optSqlParams(printerNameList);
        //获取打印失败或未打印 且创建时间不超过12分钟的打印任务
        String sql = "select * from tbPrintTask where fiStatus in ('1','3') and fsPrinterName in ("+sqlParam+") and (strftime('%s','"+ DateUtil.getCurrentTime()+"') - strftime('%s',fsCreateTime)) < 720";
        List<PrintTaskDBModel> P433PrintErrorList = DBSimpleUtil.queryList(APPConfig.DB_PRINT, sql,PrintTaskDBModel.class);
        if (ListUtil.isEmpty(P433PrintErrorList)) {
            return new ArrayList<>();
        }
        return P433PrintErrorList;
    }

    public static void updateHostIdOfTask(String printID,String hostID){
        DBSimpleUtil.excuteSql(APPConfig.DB_PRINT,"update tbPrintTask set fsHostId = '"+hostID+"' where fiPrintNo = '"+printID+"'");
    }
}
