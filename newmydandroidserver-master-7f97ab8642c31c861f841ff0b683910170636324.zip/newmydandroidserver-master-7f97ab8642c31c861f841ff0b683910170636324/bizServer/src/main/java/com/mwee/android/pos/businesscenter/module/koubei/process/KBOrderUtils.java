package com.mwee.android.pos.businesscenter.module.koubei.process;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBDishMenuItem;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.db.business.kbbean.bean.PosBillPayChannel;
import com.mwee.android.pos.business.constants.BillSourceValue;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/8/20.
 */

public class KBOrderUtils {

    /**
     * 口碑预点单转本地订单
     *
     * @param preOrderCache  口碑订单
     * @param isDinnnerTable 是否是正餐桌台
     * @return 本地订单
     */
    //todo 目前的只有两个扫码桌台调用  以及分配桌台调用 后期扩展需要重写
    public static OrderCache newOrderCache(KBPreOrderCache preOrderCache, boolean isDinnnerTable) {


        UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
        String shopID = HostUtil.getShopID();
        String date = HostUtil.getHistoryBusineeDate(shopID);
        String orderID = OrderDriver.generateNewOrderID(true);
        OrderCache orderCache = OrderDriver.generateNewOrder(orderID);
        orderCache.thirdOrderType = NetOrderType.KB_ORDER;
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = userDBModel.fsUserId;
        orderCache.waiterName = userDBModel.fsUserName;
        orderCache.shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        orderCache.businessDate = date;

        if (isDinnnerTable) {
            orderCache.fsmtableid = preOrderCache.take_no;
            //orderCache.fsmtablename = orderCache.fsmtableid;
            //口碑预点单[正餐类型]
            orderCache.fiSellType = 0;
        } else {
            orderCache.mealNumber = preOrderCache.take_no;
            orderCache.fiSellType = 4;
        }
//        switch (preOrderCache.business_type) {
//            case "DINNER":
//                orderCache.fsmtableid = preOrderCache.take_no;
//                //orderCache.fsmtablename = orderCache.fsmtableid;
//                //口碑预点单[正餐类型]
//                orderCache.fiSellType = 0;
//                break;
//            case "SNACK":
//                orderCache.mealNumber = preOrderCache.take_no;
//                orderCache.fiSellType = 4;
//                break;
//            default:
//                break;
//        }

        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.currentSeq = 1;
        orderCache.whetherRound = false;
        orderCache.kbOrderId = preOrderCache.order_id;
        //orderCache.eatTime = preOrderCache.table_time;
        //先付打小票  根据thirdOrderId找口碑订单信息
        orderCache.thirdOrderId = preOrderCache.order_id;
        orderCache.fsBillSourceId = BillSourceValue.BILL_KB;//KOUBEI-口碑
        // 当日已上传账单，后续账单默认隐藏
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0") || TextUtils.equals(status, "1")) {
            orderCache.hidden = 1;
        }
        orderCache.fsAccountBook = ",1,";
        orderCache.personNum = StringUtil.toInt(preOrderCache.people_num);
        orderCache.totalService = preOrderCache.service_amount;
        orderCache.serviceRate = 0;
        orderCache.totalPrice = preOrderCache.receipt_amount;
        orderCache.totalCount = calculateTotalCount(orderCache);
        return orderCache;
    }

    /**
     * 口碑后付款订单转本地订单
     *
     * @param afterPayOrder 口碑后付款订单
     * @param orderId       指定本地订单号
     * @param userDBModel   操作用户
     * @return 本地订单
     */
    public static OrderCache newOrderCache(KBAfterPayOrder afterPayOrder, String orderId, UserDBModel userDBModel) {
        String shopID = HostUtil.getShopID();
        String date = HostUtil.getHistoryBusineeDate(shopID);
        String orderID = orderId;
        OrderCache orderCache = OrderDriver.generateNewOrder(orderID);
        orderCache.thirdOrderType = NetOrderType.KB_AFTER_PAY_ORDER;
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = userDBModel.fsUserId;
        orderCache.waiterName = userDBModel.fsUserName;
        orderCache.shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        orderCache.businessDate = date;
        switch (afterPayOrder.business_type) {
            case "DINNER":
                //table_no 代表桌台名称
                orderCache.fsmtablename = afterPayOrder.table_no;
                //口碑预点单[正餐类型]
                orderCache.fiSellType = 0;
                break;
            case "SNACK":
                //口碑预点单[快餐类型]
                orderCache.mealNumber = afterPayOrder.table_no;
                orderCache.fiSellType = 4;
                break;
            default:
                break;
        }
        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.currentSeq = 1;
        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, userDBModel, HostBiz.cloudsite);
        //圆整读本地配置
        orderCache.whetherRound = true;
//        orderCache.thirdOrderId = afterPayOrder.order_id;
        orderCache.kbOrderId = afterPayOrder.order_id;
        orderCache.kbTableNo = afterPayOrder.table_no;
        orderCache.fsBillSourceId = BillSourceValue.BILL_KB;//KOUBEI-口碑
        // 当日已上传账单，后续账单默认隐藏
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0") || TextUtils.equals(status, "1")) {
            orderCache.hidden = 1;
        }
        orderCache.fsAccountBook = ",1,";
        orderCache.personNum = StringUtil.toInt(afterPayOrder.people_num, 1);
        return orderCache;
    }

    /**
     * 计算菜品总数量
     *
     * @param orderCache
     * @return
     */
    public static BigDecimal calculateTotalCount(OrderCache orderCache) {
        BigDecimal totalCount = BigDecimal.ZERO;
        for (MenuItem menuItem : orderCache.originMenuList) {
            totalCount = totalCount.add(menuItem.menuBiz.buyNum);
        }
        return totalCount;
    }

    /**
     * 构建菜品业务数据
     *
     * @param dish_details 口碑菜品数据
     * @param memo
     * @return 本地菜品业务数据
     */
    public static ArrayList<MenuItem> copyTo(List<KBDishMenuItem> dish_details, String memo) {
//<<<<<<< HEAD
        return KBMenuItemUtils.copyTo(dish_details, memo);
//=======
//        ArrayList<MenuItem> menuItems = new ArrayList<>();
//        for (KBDishMenuItem item : dish_details) {
//            MenuitemDBModel itemDB = null;
//            if (!TextUtils.isEmpty(item.out_dish_id)) {
//                itemDB = MenuDBUtil.getUsefulMenuDBModelBy(item.out_dish_id);
//            }
//            if (itemDB == null) {
//                itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_KB_TEMP);
//                itemDB.fsItemName = item.dish_name + "[口碑]";
//                itemDB.fsItemName2 = item.dish_name + "[口碑]";
//            }
//            MenuItemUnitDBModel unitDBModel = null;
//            if (!TextUtils.isEmpty(item.out_sku_id)) {
//                unitDBModel = MenuDBUtil.queryMenuItemUnit(item.out_sku_id);
//            }
//            if (unitDBModel == null) {
//                //临时菜的fiOrderUintCd 99995 必须内置数据
//                unitDBModel = MenuDBUtil.queryMenuItemUnit(DBConstants.MENU_UNIT_ID_KB_TEMP);
//            }
//            //匹配到本地菜品
//            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
//            menuItem.thirdMenuId = item.dish_id;
//            menuItem.thirdMenuName = item.dish_name;
//            menuItem.thirdUnitId = item.sku_id;
//            menuItem.thirdUnitName = item.unit;
//            menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
//            if (menuItem.currentUnit == null) {
//                menuItem.currentUnit = new UnitModel();
//            }
//            if (menuItem.menuBiz == null) {
//                menuItem.menuBiz = new MenuBiz();
//            }
//            menuItem.menuBiz.generateUniq();
//            menuItem.menuBiz.addConfig(8);
//            menuItem.menuBiz.selectOrderNote.clear();
//
//             /* 口碑做法 */
//            if (item.out_dish_infos != null) {
//                NoteItemModel note = new NoteItemModel();
//                note.selected = true;
//                note.num = BigDecimal.ONE;
//                note.name = item.out_dish_infos.PRACTICE;
//                note.uniq = UUIDUtil.optUUID();
//                menuItem.addNote(note);
//                JSONObject object = new JSONObject();
//                object.put("out_dish_infos", item.out_dish_infos);
//                menuItem.menuBiz.extInfo = object.toJSONString();
//            }
//            //口碑备注加到菜上
//            if (!TextUtils.isEmpty(memo)) {
//                NoteItemModel note = new NoteItemModel();
//                note.selected = true;
//                note.num = BigDecimal.ONE;
//                note.name = memo;
//                note.uniq = UUIDUtil.optUUID();
//                menuItem.addNote(note);
//            }
//
//            //价格
//            menuItem.price = item.price;
//            menuItem.currentUnit.fdOriginPrice = item.price;
//            menuItem.currentUnit.fdSalePrice = item.price;
//            menuItem.currentUnit.fdVIPPrice = item.price;
//            menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
//            menuItem.menuBiz.totalPrice = item.price.multiply(item.num);
//            menuItem.menuBiz.buyNum = item.num;
//            if (!ListUtil.isEmpty(item.selected_meal_info)) {
//                //拼接一个套餐属性
//                menuItem.config = menuItem.config | 256;
//                //处理套餐
//                menuItem.menuBiz.selectedPackageItems = copyTo(item.selected_meal_info, "");
//            }
//            menuItems.add(menuItem);
//
//        }
//        return menuItems;
//>>>>>>> master
    }

    /**
     * 构建菜品业务数据
     *
     * @param dish_details 口碑菜品数据
     * @param memo         口碑整单备注
     * @return 本地菜品业务数据
     */
    public static ArrayList<MenuItem> copyTo(ArrayList<KBPreMenuItemModel> dish_details, String memo) {
//<<<<<<< HEAD
        return KBMenuItemUtils.copyTo(dish_details, memo);
//=======
//        NoteItemModel noteOrder = NoteItemModel.createCustomeNote(memo, 1, BigDecimal.ZERO);
//        ArrayList<MenuItem> menuItems = new ArrayList<>();
//        for (KBPreMenuItemModel item : dish_details) {
//            MenuitemDBModel itemDB = null;
//            if (!TextUtils.isEmpty(item.fiItemCd)) {
//                itemDB = MenuDBUtil.getUsefulMenuDBModelBy(item.fiItemCd);
//            }
//            if (itemDB == null) {
//                itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_KB_TEMP);
//                itemDB.fsItemName = item.dish_name + "[口碑]";
//                itemDB.fsItemName2 = item.dish_name + "[口碑]";
//            }
//            MenuItemUnitDBModel unitDBModel = null;
//            if (!TextUtils.isEmpty(item.fiOrderUintCd)) {
//                unitDBModel = MenuDBUtil.queryMenuItemUnit(item.fiOrderUintCd);
//            }
//            if (unitDBModel == null) {
//                //临时菜的fiOrderUintCd 99995 必须内置数据
//                unitDBModel = MenuDBUtil.queryMenuItemUnit(DBConstants.MENU_UNIT_ID_KB_TEMP);
//            }
//            //匹配到本地菜品
//            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
//            menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
//            if (menuItem.currentUnit == null) {
//                menuItem.currentUnit = new UnitModel();
//            }
//            if (menuItem.menuBiz == null) {
//                menuItem.menuBiz = new MenuBiz();
//            }
//            menuItem.menuBiz.generateUniq();
//            menuItem.menuBiz.addConfig(8);
//            menuItem.menuBiz.selectOrderNote.clear();
//            menuItem.addOrderNote(noteOrder);
//            /* 口碑做法 */
//            if (!TextUtils.isEmpty(item.practice_info)) {
//                NoteItemModel note = new NoteItemModel();
//                note.selected = true;
//                note.num = BigDecimal.ONE;
//                note.name = item.practice_info;
//                note.uniq = UUIDUtil.optUUID();
//                menuItem.addNote(note);
//            }
//            //价格
//            menuItem.price = item.sell_price;
//            menuItem.currentUnit.fdOriginPrice = item.sell_price;
//            menuItem.currentUnit.fdSalePrice = item.sell_price;
//            menuItem.currentUnit.fdVIPPrice = item.member_price;
//            menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
//            menuItem.menuBiz.totalPrice = item.sell_price.multiply(item.dish_num);
//            menuItem.menuBiz.buyNum = item.dish_num;
//            //去掉时价 称重属性
//            if (menuItem.supportTimes()) {
//                menuItem.decreasConfig(512);
//            }
//            if (menuItem.supportWeight()) {
//                menuItem.decreasConfig(32);
//            }
//            if (!ListUtil.isEmpty(item.packageMenuItemDetails)) {
//                //拼接一个套餐属性
//                menuItem.config = menuItem.config | 256;
//                //处理套餐
//                menuItem.menuBiz.selectedPackageItems = copyTo(item.packageMenuItemDetails, memo);
//            }
//
//            menuItems.add(menuItem);
//        }
//        return menuItems;
//>>>>>>> master
    }

    /**
     * 构建支付方式
     *
     * @param preOrderCache
     * @param orderCache
     * @param userDBModel
     */
    public static PaySession newPaySession(KBPreOrderCache preOrderCache, OrderCache orderCache, UserDBModel userDBModel) {
        PaySession paySession = OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.cloudsite);
        for (PosBillPayChannel pay_channel : preOrderCache.pay_channels) {
            for (RapidPayModel rapidPayModel : pay_channel.rapidPayModels) {
                PayModel payModel = new PayModel(userDBModel.fsUserId, userDBModel.fsUserName);
                payModel.updateTime = DateUtil.getCurrentTime();
                payModel.updateWaiterID = userDBModel.fsUserId;
                payModel.updateWaiterName = userDBModel.fsUserName;
                payModel.hostID = HostBiz.cloudsite;
                payModel.status = PayTypeStatus.ENABLE;
                payModel.changeAmount = BigDecimal.ZERO;
                payModel.seq = 1;
                payModel.payAmount = rapidPayModel.fdReceMoney;
                payModel.data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
                if (payModel.data == null) {
                    payModel.data = OrderUtil.buildPayModelByPaymentID(PayType.RMB);
                }
                //切换为第三方订单支付
                payModel.writeThirdOrder();
                paySession.selectPayListFull.add(payModel);
            }
        }
        return paySession;
    }

    /**
     * 口碑C端用户退款
     * 仅支付宝违约金使用
     * <p>
     * <p>
     * 构建违约金临时菜
     *
     * @param tempDishName
     * @param penalty
     * @param currentSeq
     * @return
     */
    public static MenuItem generatePenaltyTempMenu(String tempDishName, BigDecimal penalty, int currentSeq) {
        MenuitemDBModel itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_TEMP);
        itemDB.fsItemName = tempDishName;
        itemDB.fsItemName2 = tempDishName;
        //临时菜的fiOrderUintCd 99995 必须内置数据
        MenuItemUnitDBModel unitDBModel = MenuDBUtil.queryMenuItemUnit(DBConstants.MENU_ITEM_UNIT_ID_TEMP);
        //匹配到本地菜品
        MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
        menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
        if (menuItem.currentUnit == null) {
            menuItem.currentUnit = new UnitModel();
        }
        if (menuItem.menuBiz == null) {
            menuItem.menuBiz = new MenuBiz();
        }
        menuItem.menuBiz.generateUniq();
        menuItem.menuBiz.addConfig(8);
        menuItem.menuBiz.orderSeqID = currentSeq;
        //价格
        menuItem.price = penalty;
        menuItem.currentUnit.fdOriginPrice = penalty;
        menuItem.currentUnit.fdSalePrice = penalty;
        menuItem.currentUnit.fdVIPPrice = penalty;
        menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
        menuItem.menuBiz.totalPrice = penalty;
        menuItem.menuBiz.buyNum = BigDecimal.ONE;
        return menuItem;
    }

    /**
     * 加菜逻辑
     *
     * @param orderCache
     * @param tempSelectedMenuList
     * @param userDBModel
     */
    public static void addMenuItems(OrderCache orderCache, ArrayList<MenuItem> tempSelectedMenuList, UserDBModel userDBModel) {
        //每个菜生成指定批次数据
        for (MenuItem menuItem : tempSelectedMenuList) {
            menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
        }
        //下单
        orderCache.originMenuList.addAll(0, tempSelectedMenuList);
        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
        orderCache.currentSeq++;
        //重新计算订单业务数据
        orderCache.reCalcAllByAll();
    }
}
