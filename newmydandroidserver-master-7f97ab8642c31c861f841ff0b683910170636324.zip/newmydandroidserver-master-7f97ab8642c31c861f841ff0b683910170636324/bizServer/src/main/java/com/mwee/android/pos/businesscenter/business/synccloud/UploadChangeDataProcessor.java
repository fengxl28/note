package com.mwee.android.pos.businesscenter.business.synccloud;

import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.WorkerThread;
import android.support.v4.util.ArrayMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.businesscenter.driver.BizSyncDriver;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.MWMeituanProcessor;
import com.mwee.android.pos.component.datasync.net.EditShopRequest;
import com.mwee.android.pos.component.datasync.net.PingBashUploadRequest;
import com.mwee.android.pos.component.datasync.net.PingBashUploadResponse;
import com.mwee.android.pos.component.datasync.net.QueryBashUploadRequest;
import com.mwee.android.pos.component.datasync.net.QueryBashUploadResponse;
import com.mwee.android.pos.component.datasync.net.UploadChangeDataRequest;
import com.mwee.android.pos.component.datasync.net.UploadNetOrderMappingRelationRequest;
import com.mwee.android.pos.component.datasync.net.UploadPingBashRequest;
import com.mwee.android.pos.component.datasync.net.model.NetorderItemMappingRelationshipDBModel;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.AskgpDBModel;
import com.mwee.android.pos.db.business.AskgpMenuClsDBModel;
import com.mwee.android.pos.db.business.BargainDBModel;
import com.mwee.android.pos.db.business.CardRelationDBModel;
import com.mwee.android.pos.db.business.CutmoneyDBModel;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.DiscountitemDBModel;
import com.mwee.android.pos.db.business.ExpclsDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MenuClsMuldeptDBModel;
import com.mwee.android.pos.db.business.MenuItemMulDeptDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MenuitemaskgpDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsideDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsidedtlDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.RevenuetypeDBModel;
import com.mwee.android.pos.db.business.PaymenttypeDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.UserroleDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ProgressCalcUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPrivateDBModel;

import java.util.ArrayList;
import java.util.List;

/**
 * 数据上送的工具类
 * Created by liuxiuxiu on 17/10/18.
 */
public class UploadChangeDataProcessor {
    public final static String KEY_STATUS = "0x99";
    public final static String KEY_ERROR = "0x98";
    public final static int STATUS_LOADING = 1;
    public final static int STATUS_FREE = 2;
    /**
     * 当前是否有线程在上送数据
     */
    private static volatile boolean uploading = false;

    private static synchronized void uploadFinish(String errorMsg) {
        uploading = false;
    }

    /**
     * 当前是否已经可以在唤起一个线程进行上送
     *
     * @return boolean | true：可以发起上送；false：已经有线程在上送了。
     */
    private static synchronized boolean canUpload() {
        if (!allowUpload()) {
            return false;
        }
        boolean c = false;
        if (uploading) {
            c = false;
        } else {
            c = true;
        }
        LogUtil.logBusiness("UploadChangeDataProcessor canUpload: set uploading to true");
        uploading = true;
        return c;
    }

    public static boolean allowUpload() {
        if (!BindProcessor.isCurrentHostMain()) {
            return false;
        }
        return true;
    }

    private static int totalDataCount, curDataCount;

    private static int calcProgress(int step) {
        curDataCount += step;
        return ProgressCalcUtil.calcProgress(totalDataCount, curDataCount);
    }

    private static void onProgress(IProgressCallback progressCB, int step) {
        if (progressCB != null) {
            int progress = calcProgress(step);
            LogUtil.log("UploadChangeDataProcessor", IProgressCallback.TAG_UPLOAD_BASE_DATA + " progress-> " + progress);
            progressCB.onProgress(progress, IProgressCallback.TAG_UPLOAD_BASE_DATA);
        }
    }

    /**
     * 开始上送订单，每张表读取20条数据,菜单表读取４０条数据上送，上送成功之后，再循环读取上送
     *
     * @return boolean | 是否执行异步上送数据
     */
    @Deprecated
    public static boolean startUploadAllLocalChageData(final IExecutorCallback iExecutorCallback) {
        return startUploadAllLocalChageData(iExecutorCallback, null);
    }

    @Deprecated
    public static boolean startUploadAllLocalChageData(final IExecutorCallback iExecutorCallback, IProgressCallback progressCB) {
        boolean can = canUpload();
        LogUtil.logBusiness("UploadChangeDataProcessor startUploadAllLocalChageData 准备上送，判断是否允许上送：" + can + ", uploading->" + uploading);
        if (!can) {
            if (progressCB != null) {
                curDataCount = totalDataCount;
                onProgress(progressCB, 0);
            }
            return false;
        }

        if (curDataCount == 0 && totalDataCount == 0) {
            totalDataCount = calcUnfinishedDataCount();
        }
        onProgress(progressCB, 0);

        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                IExecutorCallback checkLeft = new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        LogUtil.log("UploadChangeDataProcessor 批量上送成功，开始检测待上送的数据");

                        if (hasMoreUnFinishedData()) {
                            startUploadAllLocalChageData(iExecutorCallback, progressCB);
                        } else {
                            LogUtil.log("UploadChangeDataProcessor startUploadAllLocalChageData 成功");
                            curDataCount = totalDataCount;
                            onProgress(progressCB, 0);
                            totalDataCount = 0;
                            curDataCount = 0;
                            if (iExecutorCallback != null) {
                                iExecutorCallback.success(responseData);
                            }
                        }
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        curDataCount = -totalDataCount;
                        onProgress(progressCB, 0);
                        totalDataCount = 0;
                        curDataCount = 0;
                        if (iExecutorCallback != null) {
                            iExecutorCallback.fail(responseData);
                        }
                        return false;
                    }
                };

                String shopGUID = HostUtil.getShopID();
                String sql = "where sync = '1' and fsShopGUID='" + shopGUID + "' limit 5";

                List<MenuClsMuldeptDBModel> menuClsMuldeptDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuClsMuldeptDBModel.class);

                List<ShopDBModel> shopDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ShopDBModel.class);

                List<HostDBModel> hostDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, HostDBModel.class);
                List<HostexternalDBModel> hostexternalDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, HostexternalDBModel.class);

                List<MareaDBModel> mareaDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MareaDBModel.class);
                List<MtableDBModel> mtableDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);

                List<MenuclsDBModel> menuclsModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuclsDBModel.class);
                List<MenuitemDBModel> menuitemDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuitemDBModel.class);

                List<MenuItemUnitDBModel> menuItemUnitDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemUnitDBModel.class);
                List<MenuitemsetsideDBModel> menuitemsetsideDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuitemsetsideDBModel.class);
                List<MenuitemsetsidedtlDBModel> menuitemsetsidedtlDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuitemsetsidedtlDBModel.class);

                List<DiscountDBModel> discountDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DiscountDBModel.class);
                List<DiscountitemDBModel> discountitemDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DiscountitemDBModel.class);

                List<AskgpDBModel> askgpDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AskgpDBModel.class);
                List<AskDBModel> askDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AskDBModel.class);

                List<MenuitemaskgpDBModel> menuitemaskgpDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuitemaskgpDBModel.class);

                List<PaymentDBModel> paymentDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymentDBModel.class);
                List<PaymenttypeDBModel> paymenttypeDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymenttypeDBModel.class);

                List<DeptDBModel> deptDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DeptDBModel.class);

                List<UserDBModel> userDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, UserDBModel.class);

                List<UserroleDBModel> userroleDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, UserroleDBModel.class);


                List<PrinterDBModel> printerDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrinterDBModel.class);

                List<MenuItemMulDeptDBModel> menuItemMulDeptDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemMulDeptDBModel.class);
                List<CardRelationDBModel> cardRelationDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, CardRelationDBModel.class);
                List<AskgpMenuClsDBModel> askgpMenuClsDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AskgpMenuClsDBModel.class);
                List<PrintTempletPrivateDBModel> templist = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintTempletPrivateDBModel.class);

                List<ExpclsDBModel> expclsDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ExpclsDBModel.class);
                List<RevenuetypeDBModel> revenuetypeDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, RevenuetypeDBModel.class);

                List<ParamvalueDBModel> paramList = new ArrayList<>();

                String sqlWechat = "SELECT * FROM tbparamvalue WHERE (fsParamId LIKE 'chat%' OR fsParamId = 'a01') AND sync = 1 and fsShopGUID='" + shopGUID + "' ";
                List<ParamvalueDBModel> wechatList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlWechat, ParamvalueDBModel.class);
                if (ListUtil.isEmpty(wechatList)) {
                    paramList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ParamvalueDBModel.class);
                } else {
                    paramList.addAll(wechatList);
                }

                List<BargainDBModel> bargainDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, BargainDBModel.class);
                List<CutmoneyDBModel> cutmoneyDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, CutmoneyDBModel.class);

                List<NetorderItemMappingRelationshipDBModel> mappingRelationshipDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, NetorderItemMappingRelationshipDBModel.class);

                doUpload(checkLeft, progressCB, shopDBModels, hostDBModelList, hostexternalDBModelList, mareaDBModelList, mtableDBModelList,
                        menuclsModelList, menuitemDBModelList, menuItemUnitDBModelList, menuitemsetsideDBModelList, menuitemsetsidedtlDBModelList,
                        discountDBModelList, discountitemDBModelList, askgpDBModelList, askDBModelList, menuitemaskgpDBModelList, paymentDBModelList, paymenttypeDBModelList, deptDBModelList,
                        userDBModelList, userroleDBModelList, printerDBModelList, menuItemMulDeptDBModelList, paramList, menuClsMuldeptDBModels, cardRelationDBModels,
                        askgpMenuClsDBModelList, templist, bargainDBModelList, cutmoneyDBModelList, expclsDBModelList, revenuetypeDBModelList, mappingRelationshipDBModels);
                return null;
            }
        });
        return true;
    }

    @WorkerThread
    private synchronized static void doUpload(final IExecutorCallback mainCallBack, final List<ShopDBModel> shopDBModels,
                                              final List<HostDBModel> hostDBModelList,
                                              final List<HostexternalDBModel> hostexternalDBModelList,
                                              final List<MareaDBModel> mareaDBModels,
                                              final List<MtableDBModel> mtableDBModelList,
                                              final List<MenuclsDBModel> menuclsModelList,
                                              final List<MenuitemDBModel> menuitemDBModelList,
                                              final List<MenuItemUnitDBModel> menuItemUnitDBModelList,
                                              final List<MenuitemsetsideDBModel> menuitemsetsideDBModelList,
                                              final List<MenuitemsetsidedtlDBModel> menuitemsetsidedtlDBModelList,
                                              final List<DiscountDBModel> discountDBModelList,
                                              final List<DiscountitemDBModel> discountitemDBModelList,
                                              final List<AskgpDBModel> askgpDBModelList,
                                              final List<AskDBModel> askDBModelList,
                                              final List<MenuitemaskgpDBModel> menuitemaskgpDBModelList,
                                              final List<PaymentDBModel> paymentDBModelList,
                                              final List<PaymenttypeDBModel> paymenttypeDBModelList,
                                              final List<DeptDBModel> deptDBModelList,
                                              final List<UserDBModel> userDBModelList,
                                              final List<UserroleDBModel> userroleDBModelList,
                                              final List<PrinterDBModel> printerDBModelList,
                                              final List<MenuItemMulDeptDBModel> menuItemMulDeptDBModelList,
                                              final List<ParamvalueDBModel> paramList,
                                              final List<MenuClsMuldeptDBModel> menuClsMuldeptDBModels,
                                              final List<CardRelationDBModel> cardRelationDBModels,
                                              final List<AskgpMenuClsDBModel> askgpMenuClsDBModelList,
                                              final List<PrintTempletPrivateDBModel> templist,
                                              final List<BargainDBModel> bargainDBModelList,
                                              final List<CutmoneyDBModel> cutmoneyDBModelList,
                                              final List<ExpclsDBModel> expclsDBModelList,
                                              final List<RevenuetypeDBModel> revenuetypeDBModelList,
                                              final List<NetorderItemMappingRelationshipDBModel> mappingRelationshipDBModels) {
        doUpload(mainCallBack, null, shopDBModels, hostDBModelList, hostexternalDBModelList, mareaDBModels, mtableDBModelList,
                menuclsModelList, menuitemDBModelList, menuItemUnitDBModelList, menuitemsetsideDBModelList, menuitemsetsidedtlDBModelList,
                discountDBModelList, discountitemDBModelList, askgpDBModelList, askDBModelList, menuitemaskgpDBModelList, paymentDBModelList, paymenttypeDBModelList, deptDBModelList,
                userDBModelList, userroleDBModelList, printerDBModelList, menuItemMulDeptDBModelList, paramList, menuClsMuldeptDBModels, cardRelationDBModels,
                askgpMenuClsDBModelList, templist, bargainDBModelList, cutmoneyDBModelList, expclsDBModelList, revenuetypeDBModelList, mappingRelationshipDBModels);
    }

    @WorkerThread
    private synchronized static void doUpload(final IExecutorCallback mainCallBack,
                                              IProgressCallback progressCB,
                                              final List<ShopDBModel> shopDBModels,
                                              final List<HostDBModel> hostDBModelList,
                                              final List<HostexternalDBModel> hostexternalDBModelList,
                                              final List<MareaDBModel> mareaDBModels,
                                              final List<MtableDBModel> mtableDBModelList,
                                              final List<MenuclsDBModel> menuclsModelList,
                                              final List<MenuitemDBModel> menuitemDBModelList,
                                              final List<MenuItemUnitDBModel> menuItemUnitDBModelList,
                                              final List<MenuitemsetsideDBModel> menuitemsetsideDBModelList,
                                              final List<MenuitemsetsidedtlDBModel> menuitemsetsidedtlDBModelList,
                                              final List<DiscountDBModel> discountDBModelList,
                                              final List<DiscountitemDBModel> discountitemDBModelList,
                                              final List<AskgpDBModel> askgpDBModelList,
                                              final List<AskDBModel> askDBModelList,
                                              final List<MenuitemaskgpDBModel> menuitemaskgpDBModelList,
                                              final List<PaymentDBModel> paymentDBModelList,
                                              final List<PaymenttypeDBModel> paymenttypeDBModelList,
                                              final List<DeptDBModel> deptDBModelList,
                                              final List<UserDBModel> userDBModelList,
                                              final List<UserroleDBModel> userroleDBModelList,
                                              final List<PrinterDBModel> printerDBModelList,
                                              final List<MenuItemMulDeptDBModel> menuItemMulDeptDBModelList,
                                              final List<ParamvalueDBModel> paramList,
                                              final List<MenuClsMuldeptDBModel> menuClsMuldeptDBModels,
                                              final List<CardRelationDBModel> cardRelationDBModels,
                                              final List<AskgpMenuClsDBModel> askgpMenuClsDBModelList,
                                              final List<PrintTempletPrivateDBModel> templist,
                                              final List<BargainDBModel> bargainDBModelList,
                                              final List<CutmoneyDBModel> cutmoneyDBModelList,
                                              final List<ExpclsDBModel> expclsDBModelList,
                                              final List<RevenuetypeDBModel> revenuetypeDBModelList,
                                              final List<NetorderItemMappingRelationshipDBModel> mappingRelationshipDBModels
    ) {

        UploadChangeDataRequest request = new UploadChangeDataRequest();
        ArrayMap<String, Object> data = new ArrayMap<String, Object>();

        boolean empty = true;
        int tempDataCount = 0;

        if (!ListUtil.isEmpty(menuClsMuldeptDBModels)) {
            empty = false;
            data.put(DBModel.getTableName(MenuClsMuldeptDBModel.class), menuClsMuldeptDBModels);
            tempDataCount += menuClsMuldeptDBModels.size();
        }

        if (shopDBModels != null && shopDBModels.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(ShopDBModel.class), shopDBModels);
            tempDataCount += shopDBModels.size();
        }
        if (hostDBModelList != null && hostDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(HostDBModel.class), hostDBModelList);
            tempDataCount += hostDBModelList.size();
        }

        if (hostexternalDBModelList != null && hostexternalDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(HostexternalDBModel.class), hostexternalDBModelList);
            tempDataCount += hostexternalDBModelList.size();
        }
        if (mareaDBModels != null && mareaDBModels.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MareaDBModel.class), mareaDBModels);
            tempDataCount += mareaDBModels.size();
        }

        if (mtableDBModelList != null && mtableDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MtableDBModel.class), mtableDBModelList);
            tempDataCount += mtableDBModelList.size();
        }

        if (menuclsModelList != null && menuclsModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuclsDBModel.class), menuclsModelList);
            tempDataCount += menuclsModelList.size();
        }

        if (menuitemDBModelList != null && menuitemDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuitemDBModel.class), menuitemDBModelList);
            tempDataCount += menuitemDBModelList.size();
        }

        if (menuItemUnitDBModelList != null && menuItemUnitDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuItemUnitDBModel.class), menuItemUnitDBModelList);
            tempDataCount += menuItemUnitDBModelList.size();
        }

        if (menuitemsetsideDBModelList != null && menuitemsetsideDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuitemsetsideDBModel.class), menuitemsetsideDBModelList);
            tempDataCount += menuitemsetsideDBModelList.size();
        }
        if (menuitemsetsidedtlDBModelList != null && menuitemsetsidedtlDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuitemsetsidedtlDBModel.class), menuitemsetsidedtlDBModelList);
            tempDataCount += menuitemsetsidedtlDBModelList.size();
        }

        if (discountDBModelList != null && discountDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(DiscountDBModel.class), discountDBModelList);
            tempDataCount += discountDBModelList.size();
        }

        if (discountitemDBModelList != null && discountitemDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(DiscountitemDBModel.class), discountitemDBModelList);
            tempDataCount += discountitemDBModelList.size();
        }

        if (askgpDBModelList != null && askgpDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(AskgpDBModel.class), askgpDBModelList);
            tempDataCount += askgpDBModelList.size();
        }

        if (askDBModelList != null && askDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(AskDBModel.class), askDBModelList);
            tempDataCount += askDBModelList.size();
        }

        if (menuitemaskgpDBModelList != null && menuitemaskgpDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuitemaskgpDBModel.class), menuitemaskgpDBModelList);
            tempDataCount += menuitemaskgpDBModelList.size();
        }

        if (paymentDBModelList != null && paymentDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(PaymentDBModel.class), paymentDBModelList);
            tempDataCount += paymentDBModelList.size();
        }

        if (paymenttypeDBModelList != null && paymenttypeDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(PaymenttypeDBModel.class), paymenttypeDBModelList);
            tempDataCount += paymenttypeDBModelList.size();
        }

        if (deptDBModelList != null && deptDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(DeptDBModel.class), deptDBModelList);
            tempDataCount += deptDBModelList.size();
        }

        if (userDBModelList != null && userDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(UserDBModel.class), userDBModelList);
            tempDataCount += userDBModelList.size();
        }

        if (userroleDBModelList != null && userroleDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(UserroleDBModel.class), userroleDBModelList);
            tempDataCount += userroleDBModelList.size();
        }

        if (printerDBModelList != null && printerDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(PrinterDBModel.class), printerDBModelList);
            tempDataCount += printerDBModelList.size();
        }

        if (menuItemMulDeptDBModelList != null && menuItemMulDeptDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(MenuItemMulDeptDBModel.class), menuItemMulDeptDBModelList);
            tempDataCount += menuItemMulDeptDBModelList.size();
        }
        if (cardRelationDBModels != null && cardRelationDBModels.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(CardRelationDBModel.class), cardRelationDBModels);
            tempDataCount += cardRelationDBModels.size();
        }

        if (askgpMenuClsDBModelList != null && askgpMenuClsDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(AskgpMenuClsDBModel.class), askgpMenuClsDBModelList);
            tempDataCount += askgpMenuClsDBModelList.size();
        }

        if (paramList != null && paramList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(ParamvalueDBModel.class), paramList);
            tempDataCount += paramList.size();
        }
        if (templist != null && templist.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(PrintTempletPrivateDBModel.class), templist);
            tempDataCount += templist.size();
        }

        if (bargainDBModelList != null && bargainDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(BargainDBModel.class), bargainDBModelList);
            tempDataCount += bargainDBModelList.size();
        }

        if (cutmoneyDBModelList != null && cutmoneyDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(CutmoneyDBModel.class), cutmoneyDBModelList);
            tempDataCount += cutmoneyDBModelList.size();
        }
        if (expclsDBModelList != null && expclsDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(ExpclsDBModel.class), expclsDBModelList);
            tempDataCount += expclsDBModelList.size();
        }
        if (revenuetypeDBModelList != null && revenuetypeDBModelList.size() > 0) {
            empty = false;
            data.put(DBModel.getTableName(RevenuetypeDBModel.class), revenuetypeDBModelList);
            tempDataCount += revenuetypeDBModelList.size();
        }
        List<BaseRequest> requestList = new ArrayList<>();

        if (!empty) {
            requestList.add(request);
        }

        //美团外卖菜品映射走单独接口
        if (mappingRelationshipDBModels != null && mappingRelationshipDBModels.size() > 0) {
            empty = false;
            tempDataCount += mappingRelationshipDBModels.size();

            UploadNetOrderMappingRelationRequest mappingRelationRequest = new UploadNetOrderMappingRelationRequest();
            mappingRelationRequest.tbNetorderItemMappingRelationship = JSON.toJSON(mappingRelationshipDBModels);
            requestList.add(mappingRelationRequest);
        }
//
//        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadChangeDataProcessor 上送数据:\n" +
//                "[桌台表]=" + (mtableDBModelList == null ? 0 : mtableDBModelList.size()) + "条" + "\n" +
//                "[餐区表]=" + (mareaDBModels == null ? 0 : mareaDBModels.size()) + "条" + "\n" +
//                "[营业日期表]=" + (paramList == null ? 0 : paramList.size()) + "条");

        if (!empty) {
            request.data = JSON.toJSON(data);
            int finalTempDataCount = tempDataCount;
            BusinessCallback callback = new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    if (i == requestList.size() - 1) {
                        IDBOperate op = new IDBOperate<Boolean>() {
                            @Override
                            public Boolean doJob(SQLiteDatabase db) {
                                if (shopDBModels != null && shopDBModels.size() > 0) {

                                    for (ShopDBModel shopDBModel : shopDBModels) {
                                        db.execSQL("update " + DBModel.getTableName(ShopDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + shopDBModel.fsUpdateTime + "' and fsShopGUID = '" + shopDBModel.fsShopGUID + "'");

                                    }

                                }

                                if (hostDBModelList != null && hostDBModelList.size() > 0) {
                                    for (HostDBModel temp : hostDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(HostDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsHostId = '" + temp.fsHostId + "'");
                                    }
                                }

                                if (hostexternalDBModelList != null && hostexternalDBModelList.size() > 0) {
                                    for (HostexternalDBModel temp : hostexternalDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(HostexternalDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsHostId = '" + temp.fsHostId + "' and fiCls = '" + temp.fiCls + "' ");
                                    }
                                }

                                if (mareaDBModels != null && mareaDBModels.size() > 0) {
                                    for (MareaDBModel temp : mareaDBModels) {
                                        db.execSQL("update " + DBModel.getTableName(MareaDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsMAreaId = '" + temp.fsMAreaId + "'");
                                    }
                                }

                                if (mtableDBModelList != null && mtableDBModelList.size() > 0) {
                                    for (MtableDBModel temp : mtableDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MtableDBModel.class) + " set sync = '0' where fsupdatetime <= '" + temp.fsupdatetime + "' and fsmtableid = '" + temp.fsmtableid + "'");
                                    }
                                }
                                if (menuclsModelList != null && menuclsModelList.size() > 0) {
                                    for (MenuclsDBModel temp : menuclsModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuclsDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsMenuClsId = '" + temp.fsMenuClsId + "'");
                                    }
                                }
                                if (menuitemDBModelList != null && menuitemDBModelList.size() > 0) {
                                    for (MenuitemDBModel temp : menuitemDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuitemDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiItemCd = '" + temp.fiItemCd + "'");
                                    }
                                }


                                if (menuItemUnitDBModelList != null && menuItemUnitDBModelList.size() > 0) {
                                    for (MenuItemUnitDBModel temp : menuItemUnitDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuItemUnitDBModel.class) + " set sync = '0' where  fiOrderUintCd = '" + temp.fiOrderUintCd + "'");
                                    }
                                }
                                if (menuitemsetsideDBModelList != null && menuitemsetsideDBModelList.size() > 0) {
                                    for (MenuitemsetsideDBModel temp : menuitemsetsideDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuitemsetsideDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiSetFoodCd = '" + temp.fiSetFoodCd + "' and fiItemCd_M = '" + temp.fiItemCd_M + "'");
                                    }
                                }

                                if (menuitemsetsidedtlDBModelList != null && menuitemsetsidedtlDBModelList.size() > 0) {
                                    for (MenuitemsetsidedtlDBModel temp : menuitemsetsidedtlDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuitemsetsidedtlDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiSetFoodCd = '" + temp.fiSetFoodCd + "' and fiItemCd_M = '" + temp.fiItemCd_M + "' and fiOrderUintCd = '" + temp.fiOrderUintCd + "' and fiItemCd = '" + temp.fiItemCd + "'");
                                    }
                                }

                                if (discountDBModelList != null && discountDBModelList.size() > 0) {
                                    for (DiscountDBModel temp : discountDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(DiscountDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsDiscountId = '" + temp.fsDiscountId + "'");
                                    }
                                }

                                if (discountitemDBModelList != null && discountitemDBModelList.size() > 0) {
                                    for (DiscountitemDBModel temp : discountitemDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(DiscountitemDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsDiscountId = '" + temp.fsDiscountId + "' and fiOrderUintCd = '" + temp.fiOrderUintCd + "'");
                                    }
                                }

                                if (askgpDBModelList != null && askgpDBModelList.size() > 0) {
                                    for (AskgpDBModel temp : askgpDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(AskgpDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsAskGpId = '" + temp.fsAskGpId + "'");
                                    }
                                }

                                if (askDBModelList != null && askDBModelList.size() > 0) {
                                    for (AskDBModel temp : askDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(AskDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiId = '" + temp.fiId + "'");
                                    }
                                }

                                if (askgpMenuClsDBModelList != null && askgpMenuClsDBModelList.size() > 0) {
                                    for (AskgpMenuClsDBModel temp : askgpMenuClsDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(AskgpMenuClsDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsGuid = '" + temp.fsGuid + "'");
                                    }
                                }

                                if (menuitemaskgpDBModelList != null && menuitemaskgpDBModelList.size() > 0) {
                                    for (MenuitemaskgpDBModel temp : menuitemaskgpDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuitemaskgpDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsAskGpId = '" + temp.fsAskGpId + "' and fiItemCd = '" + temp.fiItemCd + "'");
                                    }
                                }

                                if (paymentDBModelList != null && paymentDBModelList.size() > 0) {
                                    for (PaymentDBModel temp : paymentDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(PaymentDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsPaymentId = '" + temp.fsPaymentId + "'");
                                    }
                                }

                                if (paymenttypeDBModelList != null && paymenttypeDBModelList.size() > 0) {
                                    for (PaymenttypeDBModel temp : paymenttypeDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(PaymenttypeDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsPaymentTypeId = '" + temp.fsPaymentTypeId + "'");
                                    }
                                }

                                if (deptDBModelList != null && deptDBModelList.size() > 0) {
                                    for (DeptDBModel temp : deptDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(DeptDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsDeptId = '" + temp.fsDeptId + "'");
                                    }
                                }

                                if (userDBModelList != null && userDBModelList.size() > 0) {
                                    for (UserDBModel temp : userDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(UserDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsUserId = '" + temp.fsUserId + "'");
                                    }
                                }


                                if (userroleDBModelList != null && userroleDBModelList.size() > 0) {
                                    for (UserroleDBModel temp : userroleDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(UserroleDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsUserId = '" + temp.fsUserId + "' and fsRoleId = '" + temp.fsRoleId + "'");
                                    }
                                }

                                if (printerDBModelList != null && printerDBModelList.size() > 0) {
                                    for (PrinterDBModel temp : printerDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(PrinterDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiID = '" + temp.fiID + "'");
                                    }
                                }

                                if (menuItemMulDeptDBModelList != null && menuItemMulDeptDBModelList.size() > 0) {
                                    for (MenuItemMulDeptDBModel temp : menuItemMulDeptDBModelList) {
                                        db.execSQL("update " + DBModel.getTableName(MenuItemMulDeptDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fiMulDeptCd = '" + temp.fiMulDeptCd + "'");
                                    }
                                }

                                if (cardRelationDBModels != null && cardRelationDBModels.size() > 0) {
                                    for (CardRelationDBModel temp : cardRelationDBModels) {
                                        db.execSQL("update " + DBModel.getTableName(CardRelationDBModel.class) + " set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsGuid = '" + temp.fsGuid + "' ");
                                    }
                                }

                                if (paramList != null && paramList.size() > 0) {
                                    for (ParamvalueDBModel temp : paramList) {
                                        db.execSQL("update tbParamValue set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsparamid = '" + temp.fsparamid + "'");
                                    }
                                }
                                if (!ListUtil.isEmpty(menuClsMuldeptDBModels)) {
                                    for (MenuClsMuldeptDBModel temp : menuClsMuldeptDBModels) {
                                        db.execSQL("update tbmenuClsMuldept set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsGuid = '" + temp.fsGuid + "'");
                                    }
                                }
                                if (!ListUtil.isEmpty(templist)) {
                                    for (PrintTempletPrivateDBModel temp : templist) {
                                        db.execSQL("update tbPrintTempletPrivate set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsTempletId = '" + temp.fsTempletId + "'");
                                    }
                                }

                                if (!ListUtil.isEmpty(bargainDBModelList)) {
                                    for (BargainDBModel temp : bargainDBModelList) {
                                        db.execSQL("update tbbargain set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsBargainId = '" + temp.fsBargainId + "'");
                                    }
                                }

                                if (!ListUtil.isEmpty(cutmoneyDBModelList)) {
                                    for (CutmoneyDBModel temp : cutmoneyDBModelList) {
                                        db.execSQL("update tbcutmoney set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsBargainId = '" + temp.fsBargainId + "'");
                                    }
                                }

                                if (!ListUtil.isEmpty(expclsDBModelList)) {
                                    for (ExpclsDBModel temp : expclsDBModelList) {
                                        db.execSQL("update tbexpcls set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsExpClsId = '" + temp.fsExpClsId + "'");
                                    }
                                }

                                if (!ListUtil.isEmpty(revenuetypeDBModelList)) {
                                    for (RevenuetypeDBModel temp : revenuetypeDBModelList) {
                                        db.execSQL("update tbrevenuetype set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsRevenueTypeId = '" + temp.fsRevenueTypeId + "'");
                                    }
                                }

                                if (!ListUtil.isEmpty(mappingRelationshipDBModels)) {
                                    for (NetorderItemMappingRelationshipDBModel temp : mappingRelationshipDBModels) {
                                        db.execSQL("update tbNetorderItemMappingRelationship set sync = '0' where fsUpdateTime <= '" + temp.fsUpdateTime + "' and fsNetorderItemName = '" + temp.fsNetorderItemName + "' and fsNetorderUintName = '"+temp.fsNetorderUintName+"'");
                                    }
                                }

                                onProgress(progressCB, finalTempDataCount);
                                return true;
                            }
                        };
                        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadChangeDataProcessor 上送数据成功；写入数据库");
                        DBManager.getInstance().executeInTransactionWithOutThread(op);

                        uploadFinish("");
                        BizSyncDriver.checkNeedReload();
                    }
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    uploadFinish(responseData.resultMessage);
                    RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadChangeDataProcessor 上送数据失败,resultMessage" +
                            "=" + responseData.resultMessage);
                    return false;
                }
            };
            BusinessExecutor.execute(requestList, mainCallBack, callback, true);
        } else {
            uploadFinish("没有待上送的数据");
            if (mainCallBack != null) {
                ResponseData res = new ResponseData();
                mainCallBack.success(res);
            }
        }
    }

    /**
     * 判断是否还有需要上送的数据
     *
     * @return boolean | true:还有需要上送的数据；false：没有了
     */
    public static boolean hasMoreUnFinishedData() {
        int count = calcUnfinishedDataCount();
        if (count > 0) {
            return true;
        }
        return false;
    }

    private static int calcUnfinishedDataCount() {
        List<String> tableList = new ArrayList<>();

        tableList.add("tbshop");

        tableList.add("tbHost");
        tableList.add("tbHostExternal");


        tableList.add("tbMArea");
        tableList.add("tbMtable");

        tableList.add("tbMenuCls");
        tableList.add("tbMenuItem");
        tableList.add("tbMenuItemUint");
        tableList.add("tbMenuItemSetSide");
        tableList.add("tbMenuItemSetSideDtl");

        tableList.add("tbDiscount");
        tableList.add("tbDiscountItem");

        tableList.add("tbAskGp");
        tableList.add("tbAsk");
        tableList.add("tbMenuItemAskGp");

        tableList.add("tbPayment");
        tableList.add("tbPaymentType");

        tableList.add("tbDept");

        tableList.add("tbUser");
        tableList.add("tbUserRole");

        tableList.add("tbPrinter");
        tableList.add("tbMenuItemMulDept");
        tableList.add("tbmenuClsMuldept");
        tableList.add("tbparamValue");
        tableList.add("tbCardRelation");
        tableList.add("tbaskgpmenucls");

        tableList.add("tbbargain");
        tableList.add("tbcutmoney");
        tableList.add("tbexpcls");
        tableList.add("tbrevenuetype");

        tableList.add("tbNetorderItemMappingRelationship");

        String shopGUID = HostUtil.getShopID();
        String sql = "SELECT count(*) as count FROM %1$s where sync = '1' and fsShopGUID='" + shopGUID + "' ";
        int count = 0;
        for (String temp : tableList) {
            int i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, temp)));
            count += i;
            LogUtil.log("UploadChangeDataProcessor 上送检测 表[" + temp + "]待上送的数据为：" + i);
        }
        return count;
    }

    public static void doEditShop(String shopId, double longitude, double latitude, IExecutorCallback callback) {
        EditShopRequest request = new EditShopRequest();
        request.shopId = shopId;
        request.longitude = longitude;
        request.latitude = latitude;
        BusinessExecutor.execute(request, callback, true);
    }

    public static void doPingBashUpload(IExecutorCallback callback) {
        UploadPingBashRequest request = new UploadPingBashRequest();
        BusinessExecutor.execute(request, callback, true);
    }

    /**
     * 对接新的菜品同步接口
     *
     * @param callback
     */
    public static void doPingBashUploadV2(IExecutorCallback callback) {
        List<BaseRequest> requestList = new ArrayList<>();

        // 默认类型为美小易普通版
        int type = 1;
        if (APPConfig.isAirKouBei()) {
            type = 2;
        }
        if (APPConfig.isCasiher()) {
            type = 3;
        }

        // 发起菜品同步
        PingBashUploadRequest uploadRequest = new PingBashUploadRequest();
        uploadRequest.type = type;
        requestList.add(uploadRequest);
        LogUtil.log("客户端类型type=" + type + ",workMode=" + APPConfig.fiWorkMode);
        // 尝试查询 20 次结果
        QueryBashUploadRequest queryRequest = new QueryBashUploadRequest();
        queryRequest.type = type;
        for (int count = 0; count < 20; count++) {
            requestList.add(queryRequest.clone());
        }

        BusinessExecutor.execute(requestList, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean instanceof PingBashUploadResponse) {
                    PingBashUploadResponse response = (PingBashUploadResponse) responseData.responseBean;

                    // 查询接口 uuid 赋值
                    for (BaseRequest request : requestList) {
                        if (request instanceof QueryBashUploadRequest) {
                            ((QueryBashUploadRequest) request).uuid = response.data;
                        }
                    }
                }

                if (responseData.responseBean instanceof QueryBashUploadResponse) {
                    QueryBashUploadResponse response = (QueryBashUploadResponse) responseData.responseBean;
                    JSONObject jsonObject = JSON.parseObject(response.data);

                    boolean resultKB = true;
                    boolean resultPos = true;
                    boolean resultNet = true;

                    // 已和后台沟通，如果没有相关的 key, 默认为 true, 同步完成
                    if (jsonObject.containsKey("menuKB") && !jsonObject.getBoolean("menuKB")) {
                        resultKB = false;
                    }
                    if (jsonObject.containsKey("posmessage") && !jsonObject.getBoolean("posmessage")) {
                        resultPos = false;
                    }
                    if (jsonObject.containsKey("uploadMesg") && !jsonObject.getBoolean("uploadMesg")) {
                        resultNet = false;
                    }

                    if (resultPos && resultNet) {
                        if (callback == null) {
                            return true;
                        }
                        if (resultKB) {
                            responseData.responseBean.errno = SocketResultCode.SUCCESS;
                            responseData.responseBean.errmsg = "菜品数据同步成功";
                        } else {
                            responseData.responseBean.errno = SocketResultCode.SUCCESS;
                            responseData.responseBean.errmsg = "菜品数据同步云端成功，正在将菜品数据同步至口碑中，请稍后";
                        }
                        callback.success(responseData);
                        return false;
                    } else {
                        // 最后一次查询请求
                        if (i == requestList.size() - 1) {
                            if (callback != null) {
                                responseData.responseBean.errno = SocketResultCode.BUSINESS_FAILED;
                                responseData.responseBean.errmsg = "菜品数据同步云端失败，请重新点击同步按钮进行同步";
                                callback.fail(responseData);
                            }
                        }

                        try {
                            Thread.sleep(10 * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (callback != null) {
                    callback.fail(responseData);
                }
                return false;
            }
        });
    }
}

