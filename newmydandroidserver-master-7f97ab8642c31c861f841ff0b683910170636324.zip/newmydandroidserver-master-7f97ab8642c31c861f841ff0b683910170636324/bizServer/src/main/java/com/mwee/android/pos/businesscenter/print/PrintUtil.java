package com.mwee.android.pos.businesscenter.print;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.db.business.config.DBPrintConfig;

import java.util.Map;

/**
 * Created by huangming on 2018/11/1.
 *
 */

public class PrintUtil {

    /**
     * 打印美味广告
     * @param originalData
     */
    public static void printMWAD(Map<String,Object> originalData){
        if(originalData == null){
            return;
        }
        if (DBPrintConfig.needPrintMWAD()) {
            originalData.put("reportTail", "本服务由美味不用等提供");
            originalData.put("mwPhone", "电话：4008-166-477");
        } else {
            originalData.put("reportTail", "");
            originalData.put("mwPhone", "");
        }
    }
}
