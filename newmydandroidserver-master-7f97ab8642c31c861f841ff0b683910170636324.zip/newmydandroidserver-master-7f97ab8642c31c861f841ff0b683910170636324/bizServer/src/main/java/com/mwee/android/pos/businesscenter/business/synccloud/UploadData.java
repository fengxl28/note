package com.mwee.android.pos.businesscenter.business.synccloud;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ProgressCalcUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadData {

    private static final String TAG = "UploadData";

    private static int totalDataCount, curDataCount;

    /**
     * 当前是否有线程在上送数据
     */
    private static volatile boolean uploading = false;

    private static volatile List<UploadTask> sTaskList = new ArrayList<>();

    private static volatile Thread asyncThread;

    private static synchronized void uploadFinish(String msg) {
        if (!TextUtils.isEmpty(msg)) {
            LogUtil.logBusiness(TAG, msg);
        }
        uploading = false;
    }

    /**
     * 当前是否已经可以在唤起一个线程进行上送
     *
     * @return boolean | true：可以发起上送；false：已经有线程在上送了。
     */
    private static synchronized boolean canUpload() {
        boolean c = false;
        if (uploading) {
            c = false;
        } else {
            c = true;
        }
        LogUtil.logBusiness(TAG, " canUpload: set uploading to true");
        uploading = true;
        return c;
    }

    public static synchronized void pushToTaskList(UploadTask task) {
        if (task == null) {
            return;
        }
        sTaskList.add(task);
        LogUtil.logBusiness(TAG, "将上送Task添加到任务列表，size=" + sTaskList.size());
    }

    public static boolean startUpload(UploadTask uploadTask) {
        LogUtil.logBusiness(TAG, "开始上送数据");
        if (!canUpload()) {
            LogUtil.logBusiness(TAG, "当前有线程正在上送，取消本次上送");
            return false;
        }

        pushToTaskList(uploadTask);
        if (ListUtil.isEmpty(sTaskList)) {
            LogUtil.logBusiness(TAG, "上送任务列表为空，结束上送");
            return true;
        }

        boolean result = true;
        for (int i = 0; i < sTaskList.size(); i++) {
            LogUtil.logBusiness(TAG, "本次任务(index=" + i + ")开始，size=" + sTaskList.size());
            UploadTask task = sTaskList.get(i);
            if (task.basicTask != null) {
                LogUtil.logBusiness(TAG, "开始上送基础数据");
                result = doUpload(task.basicTask, "上送基础数据");
                LogUtil.logBusiness(TAG, "上送基础数据 result=" + result);
            }
            if (!result) {
                break;
            }
            if (task.orderTask != null) {
                LogUtil.logBusiness(TAG, "开始上送报表数据");
                result = doUpload(task.orderTask, "上送报表数据");
                LogUtil.logBusiness(TAG, "上送报表数据 result=" + result);
            }
            if (!result) {
                break;
            }
            if (task.otherBasicTask != null || task.netOrderTask != null) {
                if (asyncThread == null || !asyncThread.isAlive()) {
                    asyncThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            LogUtil.logBusiness(TAG, "开始上送报表不依赖的基础数据和外卖数据");
                            doUpload(task.otherBasicTask, "上送报表不依赖的基础数据");
                            doUpload(task.netOrderTask, "上送外卖数据");
                        }
                    });
                    asyncThread.start();
                }
            }
            sTaskList.remove(i);
            LogUtil.logBusiness(TAG, "本次任务(index=" + i + ")结束，从任务列表中移除，size=" + sTaskList.size());
            i--;
        }

        uploadFinish("");
        LogUtil.logBusiness(TAG, "上送数据结束，size=" + sTaskList.size());
        return result;
    }

    private static <T> boolean doUpload(IUploadDataCallback<T> uploadCallback, String tag) {
        if (uploadCallback == null) {
            LogUtil.logBusiness(TAG, "doUpload IUploadDataCallback 为空，结束" + " ***** " + tag);
            return true;
        }

        if (!uploadCallback.allowUpload()) {
            LogUtil.logBusiness(TAG, "doUpload 不允许上送数据，结束" + " ***** " + tag);
            uploadCallback.processProgress(100);
            uploadCallback.uploadSuccess(new ResponseData());
            return true;
        }
        if (totalDataCount == 0 && curDataCount == 0) {
            totalDataCount = uploadCallback.calcUnfinishedDataCount();
            LogUtil.logBusiness(TAG, "doUpload totalDataCount=" + totalDataCount + " ***** " + tag);
            if (totalDataCount <= 0) {
                uploadCallback.processProgress(100);
                uploadCallback.uploadSuccess(new ResponseData());
                return true;
            }
        }
        LogUtil.logBusiness(TAG, "doUpload 准备上送，本次上送数据总量：" + totalDataCount +
                "，当前已上送数据量：" + curDataCount + " ***** " + tag);

        T data = uploadCallback.buildData();
        if (!checkData(data)) {
            LogUtil.logBusiness(TAG, "doUpload 构建数据为空，结束" + " ***** " + tag);
            uploadCallback.processProgress(100);
            uploadCallback.uploadSuccess(new ResponseData());
            return true;
        }

        List<? extends BaseRequest> buildRequests = uploadCallback.buildRequest(data);
        if (ListUtil.isEmpty(buildRequests)) {
            LogUtil.logBusiness(TAG, "doUpload 构建请求为空，结束" + " ***** " + tag);
            uploadCallback.processProgress(100);
            uploadCallback.uploadSuccess(new ResponseData());
            return true;
        }

        final boolean[] result = new boolean[1];
        List<BaseRequest> requests = new ArrayList<>(buildRequests);

        IExecutorCallback requestExeCallback = new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                int dataCount = uploadCallback.calcUnfinishedDataCount();
                LogUtil.logBusiness(TAG, "doUpload 检测剩余上送数据量：" + dataCount + "***** " + tag);
                if (dataCount > 0) {
                    result[0] = doUpload(uploadCallback, tag);
                } else {
                    LogUtil.logBusiness(TAG, "doUpload 上送成功 ***** " + tag);
                    uploadCallback.processProgress(100);
                    totalDataCount = 0;
                    curDataCount = 0;
                    uploadCallback.uploadSuccess(responseData);
                    result[0] = true;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "doUpload 上送失败 ***** " + tag);
                uploadCallback.processProgress(100);
                totalDataCount = 0;
                curDataCount = 0;
                uploadCallback.uploadFail(responseData);
                result[0] = false;
                return false;
            }
        };

        BusinessCallback requestBizCallback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (i == requests.size() - 1) {
                    int updateDataCount = uploadCallback.updateDataSyncStatus(data);
                    LogUtil.logBusiness(TAG, "doUpload 上送成功，更新数据状态结束，更新数量：" + updateDataCount +
                            "，当前已上送数据量：" + curDataCount + " ***** " + tag);
                    curDataCount += updateDataCount;
                    uploadCallback.processProgress(ProgressCalcUtil.calcProgress(totalDataCount, curDataCount));
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        };
        BusinessExecutor.execute(requests, requestExeCallback, requestBizCallback, false);
        LogUtil.logBusiness(TAG, "doUpload 完成，result=" + result[0] + " ***** " + tag);
        return result[0];
    }

    private static <T> boolean checkData(T data) {
        if (data == null) {
            return false;
        }
        if (data instanceof List && ListUtil.isEmpty((List<?>) data)) {
            return false;
        }
        if (data instanceof Map && ListUtil.mapIsEmpty((Map<?, ?>) data)) {
            return false;
        }
        return true;
    }
}
