package com.mwee.android.pos.businesscenter.driver.cashier;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;

import java.util.List;

/**
 * Created by qinwei on 2018/2/26.
 */

public class CashierMenuItemManagerDriver implements IDriver {
    public static final String CASHIER_TAG = "cashierMenuItemManager";

    @DrivenMethod(uri = CASHIER_TAG + "/loadAddMenuPackageBean")
    public SocketResponse loadAddMenuPackageBean(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuItemBean menuPackageBean = request.getObject("menuPackageBean", MenuItemBean.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            MenuItemDBUtils.addMenuPackage(menuPackageBean, head.shopid, userDBModel);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "添加成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = CASHIER_TAG + "/loadUpdatePackageMenu")
    public SocketResponse loadUpdatePackageMenu(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            String name = request.getString("name");
            String price = request.getString("price");
            List<MenuPackageSetSideBean> menuPackageSetSideBeanList = JSONArray.parseArray(request.getString("beans"), MenuPackageSetSideBean.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            MenuItemDBUtils.updateMenuPackageMsy(fiItemCd, name, price, menuPackageSetSideBeanList, head.shopid, userDBModel);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    @Override
    public String getModuleName() {
        return CASHIER_TAG;
    }

}
