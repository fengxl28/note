package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.ask.AskListResponse;
import com.mwee.android.air.connect.business.ask.GetAllAskGPAndAskResponse;
import com.mwee.android.air.connect.business.menu.UploadDishTypeBean;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AskManagerDBUtil;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuClsDBUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 * 要求管理相关操作
 */
@SuppressWarnings("unused")
public class AirAskManagerDriver implements IDriver {

    private static final String TAG = "airAskManagerDriver";

    /**
     * 获取所有要求，要求分组等信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAllAsk")
    public SocketResponse optAllAsk(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAskListByGroupId")
    public SocketResponse loadAskListByGroupId(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject jsonObject = JSONObject.parseObject(param);
            String fsAskGpId = jsonObject.getString("fsAskGpId");
            if (fsAskGpId == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "非法请求";
                return response;
            }
            AskListResponse data = new AskListResponse();
            if ("".equals(fsAskGpId)) {
                //所有要求
                data.askList = (ArrayList<AirAskManageInfo>) AskManagerDBUtil.findAskListAll();
            } else {
                //按fsAskGpId搜索的要求
                data.askList = (ArrayList<AirAskManageInfo>) AskManagerDBUtil.findAskListByGpId(fsAskGpId);
            }
            response.data = data;
            response.message = "";
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 新增要求分组
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doAddAskGp")
    public SocketResponse doAddAskGp(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String askGpName = request.getString("askGpName");
            boolean all = request.getBoolean("all");
            List<String> menuClsIdList = JSON.parseArray(request.getString("menuClsIdList"), String.class);
            if (TextUtils.isEmpty(askGpName)) {
                response.message = "名称无效";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AskManagerDBUtil.doAddAskGp(askGpName, all, menuClsIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增要求分组成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 修改要求分类名称
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doUpdateAskGp")
    public SocketResponse doUpdateAskGp(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String askgpId = request.getString("askgpId");
            String askGpName = request.getString("askGpName");
            boolean all = request.getBoolean("all");
            List<String> menuClsIdList = JSON.parseArray(request.getString("menuClsIdList"), String.class);

            if (TextUtils.isEmpty(askgpId)) {
                response.message = "分组信息异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (TextUtils.isEmpty(askGpName)) {
                response.message = "分组名称无效";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
//            air3.9菜品要求-缓存菜品分类id case 6.更新之前先查出已关联的菜品分类ids暂存
            List<String> previousAssociatedList = AskManagerDBUtil.findAssociatedMenuClsIdByAskGpId(askgpId);

            String errMsg = AskManagerDBUtil.updateAskGpName(askgpId, askGpName, all, menuClsIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改分组成功";
//            air3.9菜品要求-缓存菜品分类id case 6.查出更新后的数据
            List<String> nowAssociatedList = AskManagerDBUtil.findAssociatedMenuClsIdByAskGpId(askgpId);

//            http://wiki.mwbyd.cn/display/diancaiandroid/lsh-3.9
            List<String> variesMenuClsIds = new ArrayList<>();
            for (int i = 0; i < previousAssociatedList.size(); i++) {
                String previousAssociated = previousAssociatedList.get(i);
                if (!nowAssociatedList.contains(previousAssociated)) {
                    variesMenuClsIds.add(previousAssociated);
                }
            }
            for (int j = 0; j < nowAssociatedList.size(); j++) {
                String nowAssociated = nowAssociatedList.get(j);
                if (!previousAssociatedList.contains(nowAssociated)) {
                    variesMenuClsIds.add(nowAssociated);
                }
            }

            MenuClsDBUtils.cacheMenuClsIdsAfterCompare(UploadDishTypeBean.IDishType.ASK_GP, UploadDishTypeBean.IActionType.UPDATE, variesMenuClsIds);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 删除分组
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doDeleteAskGp")
    public SocketResponse doDeleteAskGp(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String askgpId = request.getString("askgpId");
            if (TextUtils.isEmpty(askgpId)) {
                response.message = "分组信息异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AskManagerDBUtil.deleteAskGp(askgpId, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增分组成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    /**
     * 新增要求
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/addAsk")
    public SocketResponse addAsk(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String askGpId = request.getString("askGpId");
            String fsaskName = request.getString("fsaskName");
            BigDecimal price = request.getBigDecimal("price");

            if (TextUtils.isEmpty(askGpId)) {
                response.message = "请选择一个有效分组";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (TextUtils.isEmpty(fsaskName)) {
                response.message = "请输入有效要求名称";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (price == null) {
                price = BigDecimal.ZERO;
            }

            String errMsg = AskManagerDBUtil.addAsk(askGpId, fsaskName, price, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增要求成功";
//            air3.9菜品要求-缓存菜品分类id case 1.
            MenuClsDBUtils.cacheMenuIdsByAskGpId(UploadDishTypeBean.IDishType.ASK_DETAIL, UploadDishTypeBean.IActionType.ADD, askGpId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 更新要求
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateAsk")
    public SocketResponse updateAsk(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsaskId = request.getString("fsaskId");
            String askGpId = request.getString("askGpId");
            String fsaskName = request.getString("fsaskName");
            BigDecimal price = request.getBigDecimal("price");

            if (TextUtils.isEmpty(fsaskId)) {
                response.message = "数据异常,请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (TextUtils.isEmpty(askGpId)) {
                response.message = "请选择一个有效分组";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (TextUtils.isEmpty(fsaskName)) {
                response.message = "请输入有效要求名称";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (price == null) {
                price = BigDecimal.ZERO;
            }

            String errMsg = AskManagerDBUtil.updateAsk(fsaskId, askGpId, fsaskName, price, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "更新要求成功";
//            air3.9菜品要求-缓存菜品分类id case 3.
            MenuClsDBUtils.cacheMenuIdsByAskGpId(UploadDishTypeBean.IDishType.ASK_DETAIL, UploadDishTypeBean.IActionType.UPDATE, askGpId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 批量删除要求
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/batchDeleteAsk")
    public SocketResponse batchDeleteAsk(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayList<String> askIdLsit = (ArrayList<String>) JSON.parseArray(request.getString("askIdLsit"), String.class);
            if (ListUtil.isEmpty(askIdLsit)) {
                response.message = "请选择要删除的要求";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
//            air3.9菜品要求-缓存菜品分类id case 2.删除之前先查询askgpid暂存
//            批量删除是删除该要求分组下选中的要求,因此对每个要被删除的要求来说分组id是一样的,所以取askIdLsit.get(0)即可;
            String askGpId = AskManagerDBUtil.findAskGpIdByAskId(askIdLsit.get(0));
            String errMsg = AskManagerDBUtil.batchDeleteAsk(askIdLsit, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除要求成功";
//            air3.9菜品要求-缓存菜品分类id case 2.
            MenuClsDBUtils.cacheMenuIdsByAskGpId(UploadDishTypeBean.IDishType.ASK_DETAIL, UploadDishTypeBean.IActionType.DELETE, askGpId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 要求分类置顶
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadAskGroupToTop")
    public SocketResponse loadAskGroupToTop(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAskGPAndAskResponse responseData = new GetAllAskGPAndAskResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsAskGpId = request.getString("fsAskGpId");

            if (TextUtils.isEmpty(fsAskGpId)) {
                response.message = "请选择需要置顶的分类";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AskManagerDBUtil.doAskgpToTop(fsAskGpId);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.airAskManageInfos = AskManagerDBUtil.optAllAskList();
            responseData.airAskGroupManagerInfos = AskManagerDBUtil.optAllAskGroupList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "置顶成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAskSort")
    public SocketResponse loadAskSort(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        JSONObject jsonObject = JSON.parseObject(param);
        ArrayList<AirAskManageInfo> askList = (ArrayList<AirAskManageInfo>) JSON.parseArray(jsonObject.getString("askList"), AirAskManageInfo.class);
        AskManagerDBUtil.doSortAskList(askList);
        return response;
    }

//    /**
//     * 要求排序
//     *
//     * @param askList
//     */
//    @SocketParam(uri = "dishes/loadAskSort", response = SocketResponse.class)
//    void loadAskSort(@SF("askList") ArrayList<AirAskManageInfo> askList);

    //    @SocketParam(uri = "airAskManagerDriver/loadAskGroupToTop", response = GetAllAskGPAndAskResponse.class)
//    String loadAskGroupToTop(@SF("loadAskGroupToTop") String askGpId);
    @Override
    public String getModuleName() {
        return TAG;
    }
}
