package com.mwee.android.pos.businesscenter.module.host.service;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permission.PermissionCheckDinner;
import com.mwee.android.pos.businesscenter.air.dbUtil.ParamvalueDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.ShiftDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.component.HostStatusDBUtils;
import com.mwee.android.pos.businesscenter.module.host.IHostService;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.bind.bean.ActiveHostAndLoginResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 站点相关业务处理
 * Created by qinwei on 2018/7/17.
 */

public class HostServiceImpl implements IHostService {
    @Override
    public ActiveHostAndLoginResponse loadActiveHostAndLoginForAdmin(String hostId, String device) {
        HostStatusDBUtils.bindHost(hostId, device);
        ActiveHostAndLoginResponse response = new ActiveHostAndLoginResponse();
        //admin账号登录
        UserDBModel userDBModel = UserDBUtils.queryById("admin");
        String shopID = HostUtil.getShopID();
        String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
        JSONObject ob = buildData(hostId, "");
        response.datas = ob.toJSONString();
        response.newTimeTag = currentDataVersion;

        //校验登录账户
        response.loginUser = userDBModel;
        response.collectMoney = PermissionCheckDinner.hasPermission(userDBModel.fsUserId, Permission.DINNER_bnSellCheck);
        response.businessDate = HostUtil.getHistoryBusineeDate(shopID);
        response.currentSectionId = OrderUtil.getSectionId();
        //进行登录
        response.session = HostUtil.hostLogin(userDBModel.fsUserId, hostId, response.currentSectionId);
        //保存主站点id
        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, hostId);
        //需求，写死的全天班别id
        String shiftID = "Z";
        HostStatusDBUtils.updateShiftId(hostId, shiftID);
        //同步餐厅配置
        List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL);
        if (ListUtil.isEmpty(list)) {
            list = new ArrayList<>();
        }
        response.dinnerLocalSettings = list;
        response.dinnerDBSettings = ParamvalueDBUtils.queryDinnerSettings();
        response.couponBargainList = OrderUtil.initBarginList(response.businessDate);
        response.shiftList = ShiftDBUtils.getShiftList();
        return response;
    }

    public JSONObject buildData(String hostID, String lastTime) {
        if (HostUtil.needSyncAll(hostID)) {
            lastTime = "0";
        }
        String[] tableList = new String[]{
                "tbask", "tbaskgp",
                "tbmenucls", "tbmenuingredgprel", "tbmenuitem", "tbmenuitemaskgp", "tbmenuitemaskgp", "tbmenuitemsetside", "tbmenuitemsetsidedtl", "tbmenuitemuint",
                "tbmarea", "tbmtable", "tbmtablecls",
                "tbpayment", "tbpaymenttype",
                "tbshop",
                "tbCutMoney", "tbbargain",
                "tbBillSource", "tbhostexternal", "tbparamvalue"};
        com.alibaba.fastjson.JSONObject ob = new com.alibaba.fastjson.JSONObject();
        if (TextUtils.isEmpty(lastTime)) {
            lastTime = "0";
        }
        String sql = "select * from %s where fsUpdateTime > '" + lastTime + "' or fsUpdateTime='' or fsUpdateTime isnull";
        for (String temp : tableList) {
            ob.put(temp, DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, temp)));
        }
        List<JSONObject> printerList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, "tbPrinter"));
        if (!ListUtil.isEmpty(printerList)) {
            ob.put("tbPrinter", printerList);
        }

        ob.put("tbhost", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbHost where fsHostID='" + hostID + "'"));
        ob.put("meta", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL));

        // tbshopservice 表 fsUpdateTime 存储的内容为时间戳
        long timestamp;

        // 不依赖于 try-catch 判断业务, 如果位数不等于格式化的位数，则直接置为 0
        if (lastTime.length() == DateUtil.DATE_VISUAL14FORMAT.length()) {
            // DateUtil#date2TimeStamp 方法内部存在 try-catch, 如果位数相等情况下的进行格式化错误，则返回 0
            timestamp = DateUtil.date2TimeStamp(lastTime, DateUtil.DATE_VISUAL14FORMAT);
        } else {
            timestamp = 0;
        }
        String sqlShopService = "SELECT * FROM tbshopservice WHERE fsUpdateTime > " + timestamp + "  or fsUpdateTime='' or fsUpdateTime isnull";
        ob.put("tbshopservice", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sqlShopService));
        HostUtil.updateHostPullIncrement(hostID);
        return ob;
    }
}
