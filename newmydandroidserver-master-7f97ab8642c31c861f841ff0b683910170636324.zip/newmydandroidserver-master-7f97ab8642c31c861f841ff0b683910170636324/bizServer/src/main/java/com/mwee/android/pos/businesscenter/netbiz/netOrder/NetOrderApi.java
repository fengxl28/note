package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderProcess;
import com.mwee.android.pos.businesscenter.business.netOrder.ThirdOrderTurnToLocalReportProcess;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.GetAllNetOrderRequest;
import com.mwee.android.pos.component.datasync.net.GetNetOrderByIdRequest;
import com.mwee.android.pos.component.datasync.net.UpdateNetOrderRequest;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Created by liuxiuxiu on 2017/3/27.
 */

public class NetOrderApi {
    /**
     * 更新订单diningStatus状态
     *
     * @param orderId
     * @param diningStatus
     * @param reason
     * @return
     */
    public static String updateNetworkOrderStatus(final String orderId, final String diningStatus, final String outerOrderId, String reason, String orderNum, @NonNull IExecutorCallback callback, BusinessCallback businessCallback, boolean forceMainThread) {
        if (TextUtils.isEmpty(orderNum)) {
            orderNum = "";
        }
        if (TextUtils.isEmpty(reason)) {
            reason = "商家拒绝接单";
        }
        UpdateNetOrderRequest request = new UpdateNetOrderRequest(orderId, diningStatus, reason, orderNum, outerOrderId);
        return BusinessExecutor.execute(request, callback, businessCallback, forceMainThread);
    }

    public static void getAllNetOrderDatasIExecutorCallback(String businessDate, boolean forceMainThread, final IResponse<String> iResponse) {
        getAllNetOrderDatasIExecutorCallback(businessDate, forceMainThread, "-1,-2,0,10,20,30,35", iResponse);
    }

    public static void getAllNetOrderDatasIExecutorCallback(String businessDate, boolean forceMainThread, String status, final IResponse<String> iResponse) {

        LogUtil.log("RapidLoop开始轮询网络订单" + DateUtil.getCurrentDateTime());
        NetOrderApi.getAllDataByDiningStatus(businessDate, forceMainThread, status, new BusinessCallback() {
            @Override
            public boolean success(int index, ResponseData responseData) {

                LogUtil.log("RapidLoop开始解析网络订单 " + DateUtil.getCurrentDateTime());
                int result = NetOrderProcess.parseGetAllNetworkData(responseData);
                if (iResponse != null) {
                    String message = "";
                    if (result < 0) {
                        message = "获取所有网络订单解析失败";
                    } else if (result == 0) {
                        message = "没有更多数据";
                    } else {
                        message = "获取成功";
                    }
                    iResponse.callBack(true, 0, message, "");
                }
                return true;
            }

            @Override
            public boolean fail(int index, ResponseData responseData) {
                if (iResponse != null) {
                    iResponse.callBack(false, -1, "获取所有网络订单失败, 请稍后重试（" + responseData.resultMessage + ")", "");
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, "获取所有网络订单失败, 请稍后重试（" + responseData.resultMessage + ")");
                return false;
            }
        });
    }

    /**
     * 获取所有订单---指定就餐状态
     *
     * @param date
     * @param diningStatus 订单状态
     * @param bizCallBack
     * @return
     */
    public static String getAllDataByDiningStatus(String date, boolean forceMainThread, final String diningStatus, final BusinessCallback bizCallBack) {
        GetAllNetOrderRequest getDataRequest = new GetAllNetOrderRequest();
        getDataRequest.diningStatus = diningStatus;
        return BusinessExecutor.execute(getDataRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_REMOTE_ORDER_STATUS, responseData.httpStatus == 200 ? "0" : "1");
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_REMOTE_ORDER_STATUS, responseData.httpStatus == 200 ? "0" : "1");
                return false;
            }
        }, bizCallBack, forceMainThread);
    }
//
//    /**
//     * 根据订单号拉取订单
//     *
//     * @param appOrderId
//     * @return
//     */
//    public static String updateNetworkOrderById(final String appOrderId) {
//        BusinessCallback callback = new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_REMOTE_ORDER_STATUS, responseData.httpStatus == 200 ? "0" : "1");
//                //解析拉取到的数据
//                int result = NetOrderProcess.parseNetworkData(responseData);
//                if (result == 1) {
//                    NotifyToClient.updateTempApporder(appOrderId);
//                }
//                return true;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                RunTimeLog.addLog(RunTimeLog.NETORDER, "更新订单信息，拉取网络订单详情：失败（网络获取失败）");
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_REMOTE_ORDER_STATUS, responseData.httpStatus == 200 ? "0" : "1");
//                return false;
//            }
//        };
//        GetNetOrderByIdRequest getDataRequest = new GetNetOrderByIdRequest();
//        getDataRequest.orderId = appOrderId;
//        return BusinessExecutor.execute(getDataRequest, null, callback);
//    }

    /**
     * 判断是否可以自动接单
     *
     * @param tempAppOrder
     * @return
     */
    public static boolean isAutoGetNetOrder(TempAppOrder tempAppOrder) {

        if (tempAppOrder.bizType == 4 && !TextUtils.isEmpty(tempAppOrder.orderTakeawaySource) && tempAppOrder.orderTakeawaySource.startsWith(TakeAwaySource.ELEME) && TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_ELEME, "0"), "1")) {
            return true;
        } else if (tempAppOrder.bizType == 4 && !TextUtils.isEmpty(tempAppOrder.orderTakeawaySource) && tempAppOrder.orderTakeawaySource.startsWith(TakeAwaySource.MEITUAN) && TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_MEITUAN, "0"), "1")) {
            return true;
        } else if ((!tempAppOrder.orderTakeawaySource.startsWith(TakeAwaySource.ELEME) &&
                !tempAppOrder.orderTakeawaySource.startsWith(TakeAwaySource.MEITUAN) &&
                (TextUtils.equals(ClientMetaUtil.getConfig(META.NET_AUTO_ORDER_OTHER, "0"), "1"))) || ((tempAppOrder.bizType == 0 && tempAppOrder.readyFoodMode == NetworkConstans.READY_FOOD_MODE_NOW))) {
            return true;
        }

        return false;

    }

    /**
     * 网络订单自动接单
     * 订单自动接单的条件
     * 1、外卖单（bizType == 4）:订单来源是饿了么或美团外卖 并且客户打开了自动接单按钮
     * 2、堂食单（bizTypa != 4）:备餐模式是自动接单的订单
     *
     * @param appOrderId
     */
    public static TempAppOrder autoGetNetOrder(final String appOrderId, final int retrySeq) {
        final TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(appOrderId);
        RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "尝试自动接单 appOrderId = " + appOrderId + "  订单信息：" + (tempAppOrder == null ? "没找到订单" : "【" + tempAppOrder.bizType + "，" + tempAppOrder.orderTakeawaySource + "，" + tempAppOrder.readyFoodMode + "】新单状态 = " + tempAppOrder.newOrder()), appOrderId);

        if (tempAppOrder != null && tempAppOrder.newOrder() && isAutoGetNetOrder(tempAppOrder)) {
            String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            getOrderRequest(tempAppOrder, retrySeq, new IResponse<String>() {
                @Override
                public void callBack(boolean result, int code, String msg, String info) {
                    //通知各站点刷新网络订单，
                    NotifyToClient.updateTempApporder(tempAppOrder.orderId + "");
                }
            }, false,hostId);
        }
        return tempAppOrder;
    }

    /**
     * 接单并且打印制作单和结账单小票 -- 重试三次
     *
     * @param tempAppOrder
     * @param retrySeq
     * @param iResponse
     */
    public static void getOrderRequest(final TempAppOrder tempAppOrder, final int retrySeq, final IResponse<String> iResponse, final boolean forceMainThread,String hostId) {
        int diningStatus = NetworkConstans.DINING_STATUS_KOT;
        if (tempAppOrder.bizType != 4) {
            diningStatus = NetworkConstans.DINING_STATUS_USER_GET;
        }
        NetOrderApi.updateNetworkOrderStatus(tempAppOrder.orderId + "", diningStatus + "", "", "自动接单", "", new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (NetOrderApi.class) {
                        if (tempAppOrder.bizType == 4) {
                            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_KDS + "', diningStatus = '" + NetworkConstans.DINING_STATUS_KOT + "' where orderId = '" + tempAppOrder.orderId + "'");
                        } else {
                            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_OVER + "', diningStatus = '" + NetworkConstans.DINING_STATUS_USER_GET + "' where orderId = '" + tempAppOrder.orderId + "'");
                        }

                        if (!ServerCache.getInstance().netOrderCache.checkNetOrderPrint(tempAppOrder.orderId + "")) {
                            RunTimeLog.addLog(RunTimeLog.NETORDER_PRINT, "开始打印外卖小票", tempAppOrder.orderId + "");
                            /*//业务中心站点打印制作单
                            String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);*/
                            PrintNetOrderUtil.printNetworkTackOutReceipt(tempAppOrder, hostId, "自动接单");
                            PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, hostId, "自动接单");
                            PrintNetOrderUtil.printNetworkCustomerReceipt(tempAppOrder, hostId, "自动接单", false);
                            ServerCache.getInstance().netOrderCache.putNetOrderPrint(tempAppOrder.orderId + "");
                        }
                        if (tempAppOrder.bizType == 4) {
                            tempAppOrder.orderStatus = NetworkConstans.ORDER_STATUS_KDS;
                            tempAppOrder.diningStatus = NetworkConstans.DINING_STATUS_KOT;
                        } else {
                            tempAppOrder.orderStatus = NetworkConstans.ORDER_STATUS_OVER;
                            tempAppOrder.diningStatus = NetworkConstans.DINING_STATUS_USER_GET;
                        }

                        ThirdOrderTurnToLocalReportProcess.dealThirdOrder(tempAppOrder, true);

                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                        }
                    }


                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "接单异常，请稍后重试", tempAppOrder.orderId + "");
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String orderStatus = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select orderStatus from tempapporder where orderId = '" + tempAppOrder.orderId + "'");
                            if (tempAppOrder.newOrder(orderStatus)) {
                                getOrderRequest(tempAppOrder, retrySeq + 1, iResponse, forceMainThread,hostId);
                            } else {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                                }
                            }
                        }
                    }, 2000);
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, responseData.resultMessage, tempAppOrder.orderId + "");
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, retrySeq + "网络订单自动接单异常，订单号：" + tempAppOrder.orderId, "异常信息：" + responseData.resultMessage);
                return false;
            }
        }, forceMainThread);
    }

    /**
     * 取消订单 -- 重试三次
     *
     * @param tempAppOrder
     * @param retrySeq
     * @param iResponse
     */
    public static void cancelOrderRequest(final TempAppOrder tempAppOrder, final int retrySeq, final IResponse<String> iResponse, final String currentHostId, final String fsUserName) {

        NetOrderApi.updateNetworkOrderStatus(tempAppOrder.orderId + "", NetworkConstans.DINING_STATUS_USER_CANCEL + "", "", "商家拒绝", "", new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (NetOrderApi.class) {
                        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_CANCEL + "', diningStatus = '" + NetworkConstans.DINING_STATUS_USER_CANCEL + "' where orderId = '" + tempAppOrder.orderId + "'");

                        boolean printVoid = false;
                        if (tempAppOrder.orderStatus == NetworkConstans.ORDER_STATUS_KDS
                                || tempAppOrder.diningStatus == NetworkConstans.DINING_STATUS_KOT) {
                            printVoid = true;
                        }

                        tempAppOrder.orderStatus = NetworkConstans.ORDER_STATUS_CANCEL;
                        tempAppOrder.diningStatus = NetworkConstans.DINING_STATUS_USER_CANCEL;

                        if (printVoid) {
                            PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, currentHostId, fsUserName);
                            PrintNetOrderUtil.printNetworkTackOutReceipt(tempAppOrder, currentHostId, fsUserName);
                        }

                        ThirdOrderTurnToLocalReportProcess.dealThirdOrder(tempAppOrder);
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                        }
                    }
                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "操作失败，请稍后重试", tempAppOrder.orderId + "");
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String diningStatus = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select diningStatus from tempapporder where orderId = '" + tempAppOrder.orderId + "'");
                            if (!TextUtils.equals(diningStatus, NetworkConstans.DINING_STATUS_USER_CANCEL + "") && !TextUtils.equals(diningStatus, NetworkConstans.DINING_STATUS_USER_VOID + "")) {
                                cancelOrderRequest(tempAppOrder, retrySeq + 1, iResponse, currentHostId, fsUserName);
                            } else {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                                }
                            }
                        }
                    }, 2000);
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, responseData.resultMessage, tempAppOrder.orderId + "");
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "网络订单拒绝异常，订单号：" + tempAppOrder.orderId + "；异常信息：" + responseData.resultMessage);
                return false;
            }
        }, false);
    }

    /**
     * 请取餐订单 -- 重试三次
     *
     * @param tempAppOrder
     * @param retrySeq
     * @param iResponse
     */
    public static void takeOrderRequest(final TempAppOrder tempAppOrder, final int retrySeq, final IResponse<String> iResponse) {

        NetOrderApi.updateNetworkOrderStatus(tempAppOrder.orderId + "", NetworkConstans.DINING_STATUS_READ + "", "", "请取餐", "", new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (NetOrderApi.class) {
                        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set orderStatus = '" + NetworkConstans.ORDER_STATUS_KDS + "', diningStatus = '" + NetworkConstans.DINING_STATUS_READ + "' where orderId = '" + tempAppOrder.orderId + "'");

                        tempAppOrder.diningStatus = NetworkConstans.DINING_STATUS_READ;

                        ThirdOrderTurnToLocalReportProcess.dealThirdOrder(tempAppOrder);
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                        }
                    }
                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "操作失败，请稍后重试", tempAppOrder.orderId + "");
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String diningStatus = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select diningStatus from tempapporder where orderId = '" + tempAppOrder.orderId + "'");
                            if (!TextUtils.equals(diningStatus, NetworkConstans.DINING_STATUS_READ + "")) {
                                takeOrderRequest(tempAppOrder, retrySeq + 1, iResponse);
                            } else {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", tempAppOrder.orderId + "");
                                }
                            }
                        }
                    }, 2000);
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, responseData.resultMessage, tempAppOrder.orderId + "");
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "网络订单请取餐异常，订单号：" + tempAppOrder.orderId + "；异常信息：" + responseData.resultMessage);
                return false;
            }
        }, false);
    }

}
