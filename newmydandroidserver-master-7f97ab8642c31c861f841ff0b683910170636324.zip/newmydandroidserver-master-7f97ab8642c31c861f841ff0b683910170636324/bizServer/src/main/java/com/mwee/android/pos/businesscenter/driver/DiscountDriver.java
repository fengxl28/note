package com.mwee.android.pos.businesscenter.driver;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.DiscountBizUtil;
import com.mwee.android.pos.businesscenter.business.order.MenuItemCouponProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.discount.AllDiscountResponse;
import com.mwee.android.pos.connect.business.discount.DiscountMenuItem;
import com.mwee.android.pos.connect.business.discount.DiscountRepSubCode;
import com.mwee.android.pos.connect.business.discount.DoDiscountResponse;
import com.mwee.android.pos.connect.business.discount.FastFoodDoDiscountResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.discount.CouponUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/6/16.
 * 业务中心折扣相关操作
 */
@SuppressWarnings("unused")
public class DiscountDriver implements IDriver {

    private static final String TAG = "discount";

    /**
     * 获取所有折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/allDiscount")
    public SocketResponse allDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        AllDiscountResponse responseData = new AllDiscountResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String waiterId = userDBModel.fsUserId;
            String hostId = head.hd;
            String fsSellNo = request.getString("fsSellNO");
            //菜品集合---单个菜品优惠时，集合里只有单个菜品，整单优惠时，集合里包含已下单菜品和未下单菜品
            List<DiscountMenuItem> discountMenuItemList = JSONArray.parseArray(request.getString("discountMenuItemList"), DiscountMenuItem.class);
            // 配料集合---单个菜品优惠时，只有单个菜品的配料，批量优惠时，集合里包含已下单配料和未下单配料
            List<DiscountMenuItem> discountIngredientList = JSONArray.parseArray(request.getString("discountIngredientList"), DiscountMenuItem.class);
            String fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

            // 菜品和配料放到一个list
            List<DiscountMenuItem> allDiscountMenuList = new ArrayList<>();
            if (!ListUtil.isEmpty(discountMenuItemList)) {
                allDiscountMenuList.addAll(discountMenuItemList);
            }
            if (!ListUtil.isEmpty(discountIngredientList)) {
                allDiscountMenuList.addAll(discountIngredientList);
            }

            if (ListUtil.isEmpty(allDiscountMenuList)) {
                response.message = "请选择折扣菜品";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String csId = "";

            //是否可使用会员价
            JSONObject jsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select is_member, member_info from order_cache where order_id = '" + fsSellNo + "'");

            responseData.isMember = TextUtils.equals("1", jsonObject.getString("is_member"));
            JSONObject memberOnfoJson = jsonObject.getJSONObject("member_info");
            if (memberOnfoJson != null) {
                csId = memberOnfoJson.getString("cs_id");
            }

            // 兼容未下单绑定会员，使用会员价及会员适用折扣
            if (ServerCache.getInstance().getNewMemberWithHost(head.hd) != null) {
                responseData.isMember = true;
                if (TextUtils.isEmpty(csId)) {
                    csId = ServerCache.getInstance().getNewMemberWithHost(head.hd).cs_id;
                }
            }

            //允许的最大折扣率(打九折折扣率为10%)
            responseData.discountRateMax = new BigDecimal(userDBModel.fiUserDiscount);

            //获取所有的折扣
            responseData.discountList = DiscountBizUtil.optDiscountList(fsShopGUID, csId);

            //已下单订单可以使用整单立减
            if (!TextUtils.isEmpty(fsSellNo)) {
                //整单立减折扣集合
                responseData.discountCutList = DiscountBizUtil.optDiscountCutList(fsShopGUID);
            }

            //金额折
            responseData.discountCash = DiscountBizUtil.optDiscountCash(fsShopGUID);
            //自定义折扣
            responseData.mDiscountCustom = DiscountBizUtil.optDiscountCustom(fsShopGUID);

            //查询每个菜品/配料对应的折扣ID列表
            responseData.menuItemAndDiscountMap = DiscountBizUtil.getAllMenuItemAndDiscountIDs(allDiscountMenuList);

            //所有买减
            responseData.buyGiftModelList = OrderUtil.optBuyGiftList(HostUtil.getHistoryBusineeDate(""));

            for (DiscountMenuItem discountMenuItem : allDiscountMenuList) {
                if (discountMenuItem == null) {
                    continue;
                }
                //判断菜品是否可赠送
                if ((discountMenuItem.config & 8) == 8) {  //有一个菜品可赠送，赠送按钮就可点击
                    responseData.canGift = true;
                    break;
                }
            }

            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache != null && orderCache.selectOrderDiscountCut != null) {
                responseData.dicountCutId = orderCache.selectOrderDiscountCut.fsDiscountId;
            }

            responseData.canUseMemPriceWithoutMem = DiscountBizUtil.canUseMemPriceWithoutMem();

            response.code = SocketResultCode.SUCCESS;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 设置菜品优惠
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/menuitemCoupon")
    public SocketResponse menuitemCoupon(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        DoDiscountResponse responseData = new DoDiscountResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            /*
            Map<菜品seq, MenuItemCouponModel>   menuCouponMap

            List<MenuItem> tempMenuList      未下单菜品

            tableId, orderId,

            MenuItemCouponBean orderCutModel   整单立减信息
             */

            JSONObject request = JSONObject.parseObject(param);

            //订单号
            String orderId = request.getString("orderId");

            //桌台号
            String tableId = request.getString("tableId");


            //已下单菜品优惠信息
            String menuCouponMapInfo = request.getString("menuCouponMap");
            /*
             * key: seq  菜品唯一标识符号
             * value: MenuItemCouponModel 菜品优惠信息
             */
            Map<String, MenuItemCouponModel> menuCouponMap = JSON.parseObject(menuCouponMapInfo, new TypeReference<ArrayMap<String, MenuItemCouponModel>>() {});

            //买减信息
            String buygiftRelationStr = request.getString("buygiftRelation");

            /*
             * key:fsBargainId  买减ID
             * value: Map<菜品fiitemCd_规格Cd, 菜品uniq集合>
             */
            Map<String, Map<String, List<String>>> buygiftRelation = JSON.parseObject(buygiftRelationStr, new TypeReference<ArrayMap<String, Map<String, List<String>>>>() {
            });

            //未下单菜品列表
            List<MenuItem> tempMenuList = JSONArray.parseArray(request.getString("tempMenuList"), MenuItem.class);

            //整单立减信息
            MenuItemCouponBean orderCutModel = JSONArray.parseObject(request.getString("orderCutModel"), MenuItemCouponBean.class);

            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache != null && !ListUtil.isEmpty(orderCache.originMenuList)) {
                //去重
                if (!ListUtil.isEmpty(tempMenuList)) {
                    for (int i = 0; i < tempMenuList.size(); i++) {
                        MenuItem item = tempMenuList.get(i);
                        if (item == null) {
                            continue;
                        }
                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (TextUtils.equals(menuItem.menuBiz.uniq, item.menuBiz.uniq)) {
                                tempMenuList.remove(i);
                                i--;
                            }
                        }
                    }
                }
                tempMenuList.addAll(orderCache.originMenuList);
            }

            String[] errMessage = new String[1];
            responseData.failedWriteoffCouponList = new ArrayList<>();
            responseData.failedRefundCouponList = new ArrayList<>();
            responseData.sub_code = MenuItemCouponProcessor.dealCoupon(tableId, orderId, menuCouponMap, buygiftRelation,
                   tempMenuList, orderCutModel, userDBModel, head.hd, responseData.failedWriteoffCouponList, responseData.failedRefundCouponList, errMessage);
            if (responseData.failedWriteoffCouponList.size() == 0 ) {
                responseData.failedWriteoffCouponList = null;
            }
            if (responseData.failedRefundCouponList.size() == 0 ) {
                responseData.failedRefundCouponList = null;
            }
            if (!TextUtils.isEmpty(errMessage[0])) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMessage[0];
                return response;
            }

            if (orderCache != null) {
                tempMenuList.removeAll(orderCache.originMenuList);
            }

            responseData.orderCache = orderCache;
            responseData.tempMenu = tempMenuList;
            if (orderCache != null && orderCache.fastFoodModel()) {
                responseData.fastOrder = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                responseData.orderCache = null;
                if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                    responseData.tempMenu.addAll(orderCache.originMenuList);
                }
            }

            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError("设置菜品优惠 menuitemCoupon 异常", e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 正餐执行打折 ----- pro3.5 版本开始已弃用
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doDiscount")
    public SocketResponse doDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        DoDiscountResponse responseData = new DoDiscountResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSONObject.parseObject(param);
            //订单号
            String fsSellNo = request.getString("fsSellNo");
            //赠送、折扣理由
            String reason = request.getString("reason");


            //整单立减--ID
            String fsDiscountCutId = request.getString("fsDiscountCutId");
            //折扣ID
            String fsDiscountId = request.getString("fsDiscountId");

            //桌台ID
            String tableID = request.getString("tableID");
            //是否使用会员价
            boolean useMemberPrice = request.getBoolean("useMemberPrice");
            //是否赠送
            boolean gift = request.getBoolean("gift");
            //非会员使用会员价
            boolean useMemPriceWithoutMem = request.getBoolean("useMemPriceWithoutMem");

            //自定义折扣---折扣率
            BigDecimal customRate = request.getBigDecimal("customRate");
            //金额折---折扣金额
            BigDecimal customAmt = request.getBigDecimal("customAmt");
            if (customAmt == null) {
                customAmt = BigDecimal.ZERO;
            }

            //买减映射关系
            String buygiftRelationStr = request.getString("buygiftRelation");
            /*
             * key:fsBargainId  买减ID
             * value: Map<菜品fiitemCd_规格Cd, 菜品uniq集合>
             */
            Map<String, Map<String, List<String>>> buygiftRelation = (Map<String, Map<String, List<String>>>) JSON.parse(buygiftRelationStr);

            //选中的菜品Uniq集合
            List<String> uniqList = JSONArray.parseArray(request.getString("uniqList"), String.class);

            //未下单菜品列表
            List<MenuItem> menuList = JSONArray.parseArray(request.getString("menuList"), MenuItem.class);

            ArrayMap<String, BigDecimal> giftInfo = new ArrayMap<>();
            try {
                //赠送信息 MAP《菜品seq, 赠送数量》------单个菜品操作场景使用
                giftInfo = JSON.parseObject(request.getString("giftInfo"), new TypeReference<ArrayMap<String, BigDecimal>>() {
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 配料对应关系，Map<主菜uniq，List<配料uniq>>
            String ingredientsMappingStr = request.getString("ingredientsMapping");
            Map<String, List<String>> ingredientsMapping = (Map<String, List<String>>) JSON.parse(ingredientsMappingStr);

            // 清除优惠对应关系，Map<菜品uniq，List<优惠类型>>
            String cleanCouponMappingStr = request.getString("cleanCouponMapping");
            Map<String, List<String>> cleanCouponMapping = (Map<String, List<String>>) JSON.parse(cleanCouponMappingStr);

            //是否清空所有优惠信息
            boolean cleanAllDiscount = request.getBoolean("cleanAllDiscount");


            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache != null && !ListUtil.isEmpty(orderCache.originMenuList)) {
                //去重
                if (!ListUtil.isEmpty(menuList)) {
                    for (int i = 0; i < menuList.size(); i++) {
                        MenuItem item = menuList.get(i);
                        if (item == null) {
                            continue;
                        }
                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (TextUtils.equals(menuItem.menuBiz.uniq, item.menuBiz.uniq)) {
                                menuList.remove(i);
                                i--;
                            }
                        }
                    }
                }
                menuList.addAll(orderCache.originMenuList);
            }

            // 兼容下单前绑定会员，并使用会员价的情况。判断 ServerCache 中是否缓存有会员信息
            int level = 0;
            NewMemberCardInfoModel model = ServerCache.getInstance().getNewMemberWithHost(head.hd);
            if (model != null) {
                level = model.level;
                //TODO 还要取csId和plusId
            }

            int rate = -1;
            if (customRate != null) {
                if (TextUtils.isEmpty(fsDiscountId)) {
                    if (customRate.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CUTSOME_DISOUNT;
                        rate = BigDecimal.TEN.subtract(customRate).multiply(BigDecimal.TEN).intValue();
                    } else if (customAmt.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CASH;
                    }
                }
            }

            String errMessage = DiscountBizUtil.doDiscount(menuList, fsSellNo, tableID, cleanAllDiscount, fsDiscountCutId,
                    gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, rate,
                    null, customAmt, giftInfo, buygiftRelation, ingredientsMapping, cleanCouponMapping);


            if (!TextUtils.isEmpty(errMessage)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMessage;
                return response;
            }


            if (orderCache != null) {
                menuList.removeAll(orderCache.originMenuList);
            }

            responseData.orderCache = orderCache;
            responseData.tempMenu = menuList;
            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(fsSellNo);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 正餐执行打折 -----pro3.5 版本开始已弃用 ----- 备份方法，可删除
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doDiscountCopy")
    public SocketResponse doDiscountCopy(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        DoDiscountResponse responseData = new DoDiscountResponse();
        response.data = responseData;
        try {
            JSONObject request = JSONObject.parseObject(param);
            String fsSellNo = request.getString("fsSellNo");
            String reason = request.getString("reason");
            String fsDiscountCutId = request.getString("fsDiscountCutId");
            String fsDiscountId = request.getString("fsDiscountId");
            String tableID = request.getString("tableID");
            boolean useMemberPrice = request.getBoolean("useMemberPrice");
            boolean gift = request.getBoolean("gift");
            boolean useMemPriceWithoutMem = request.getBoolean("useMemPriceWithoutMem");

            BigDecimal customRate = request.getBigDecimal("customRate");
            BigDecimal customAmt = request.getBigDecimal("customAmt");

            String buygiftRelationStr = request.getString("buygiftRelation");
            Map<String, Map<String, List<String>>> buygiftRelation = (Map<String, Map<String, List<String>>>) JSON.parse(buygiftRelationStr);
            if (customAmt == null) {
                customAmt = BigDecimal.ZERO;
            }

            List<String> uniqList = JSONArray.parseArray(request.getString("uniqList"), String.class);
            List<MenuItem> menuList = JSONArray.parseArray(request.getString("menuList"), MenuItem.class);
            ArrayMap<String, BigDecimal> giftInfo = new ArrayMap<>();
            try {
                giftInfo = JSON.parseObject(request.getString("giftInfo"), new TypeReference<ArrayMap<String, BigDecimal>>() {
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 配料对应关系，Map<主菜uniq，List<配料uniq>>
            String ingredientsMappingStr = request.getString("ingredientsMapping");
            Map<String, List<String>> ingredientsMapping = (Map<String, List<String>>) JSON.parse(ingredientsMappingStr);

            // 清除优惠对应关系，Map<菜品uniq，List<优惠类型>>
            String cleanCouponMappingStr = request.getString("cleanCouponMapping");
            Map<String, List<String>> cleanCouponMapping = (Map<String, List<String>>) JSON.parse(cleanCouponMappingStr);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache != null && !ListUtil.isEmpty(orderCache.originMenuList)) {
                //去重
                if (!ListUtil.isEmpty(menuList)) {
                    for (int i = 0; i < menuList.size(); i++) {
                        MenuItem item = menuList.get(i);
                        if (item == null) {
                            continue;
                        }
                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (TextUtils.equals(menuItem.menuBiz.uniq, item.menuBiz.uniq)) {
                                menuList.remove(i);
                                i--;
                            }
                        }
                    }
                }
                menuList.addAll(orderCache.originMenuList);
            }
            boolean cleanAllDiscount = request.getBoolean("cleanAllDiscount");

            // 兼容下单前绑定会员，并使用会员价的情况。判断 ServerCache 中是否缓存有会员信息
            int level = 0;
            NewMemberCardInfoModel model = ServerCache.getInstance().getNewMemberWithHost(head.hd);
            if (model != null) {
                level = model.level;
            }

            int rate = -1;
            if (customRate != null) {
                if (TextUtils.isEmpty(fsDiscountId)) {
                    if (customRate.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CUTSOME_DISOUNT;
                        rate = BigDecimal.TEN.subtract(customRate).multiply(BigDecimal.TEN).intValue();
                    } else if (customAmt.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CASH;
                    }
                }
            }

            String errMessage = DiscountBizUtil.doDiscount(menuList, fsSellNo, tableID, cleanAllDiscount, fsDiscountCutId,
                    gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, rate,
                    null, customAmt, giftInfo, buygiftRelation, ingredientsMapping, cleanCouponMapping);
            if (!TextUtils.isEmpty(errMessage)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMessage;
                return response;
            }
            if (orderCache != null) {
                menuList.removeAll(orderCache.originMenuList);
            }
            responseData.orderCache = orderCache;
            responseData.tempMenu = menuList;
            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(fsSellNo);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 快餐打折-----pro3.5 版本开始已弃用
     *
     * @param param
     * @return
     */
    @Deprecated
    @DrivenMethod(uri = TAG + "/doDiscountForFastFood")
    public SocketResponse doDiscountForFastFood(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        FastFoodDoDiscountResponse responseData = new FastFoodDoDiscountResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");

            if (TextUtils.isEmpty(orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单信息异常，请回到桌台页重试";
                return response;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未找到该订单，请回到桌台页重试";
                return response;
            }

            if (orderCache.orderStatus == OrderStatus.PAIED) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已被结账";
                return response;
            }

            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return response;
            }

            String reason = request.getString("reason");

            String fsDiscountId = request.getString("fsDiscountId");
            boolean useMemberPrice = request.getBoolean("useMemberPrice");
            boolean gift = request.getBoolean("gift");
            List<String> uniqList = JSON.parseArray(request.getString("uniqList"), String.class);

            String buygiftRelationStr = request.getString("buygiftRelation");
            Map<String, Map<String, List<String>>> buygiftRelation = (Map<String, Map<String, List<String>>>) JSON.parse(buygiftRelationStr);

            BigDecimal customRate = request.getBigDecimal("customRate");
            BigDecimal customAmt = request.getBigDecimal("customAmt");
            if (customAmt == null) {
                customAmt = BigDecimal.ZERO;
            }
            ArrayMap<String, BigDecimal> giftInfo = new ArrayMap<>();
            try {
                giftInfo = JSON.parseObject(request.getString("giftInfo"), new TypeReference<ArrayMap<String, BigDecimal>>() {
                });
                LogUtil.log("开始执行折扣 userMap  = " + giftInfo.size());
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 配料对应关系，Map<主菜uniq，List<配料uniq>>
            String ingredientsMappingStr = request.getString("ingredientsMapping");
            Map<String, List<String>> ingredientsMapping = (Map<String, List<String>>) JSON.parse(ingredientsMappingStr);

            // 清除优惠对应关系，Map<菜品uniq，List<优惠类型>>
            String cleanCouponMappingStr = request.getString("cleanCouponMapping");
            Map<String, List<String>> cleanCouponMapping = (Map<String, List<String>>) JSON.parse(cleanCouponMappingStr);

            int rate = -1;
            if (customRate != null) {
                if (TextUtils.isEmpty(fsDiscountId)) {
                    if (customRate.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CUTSOME_DISOUNT;
                        rate = BigDecimal.TEN.subtract(customRate).multiply(BigDecimal.TEN).intValue();
                    } else if (customAmt.compareTo(BigDecimal.ZERO) > 0) {
                        fsDiscountId = DiscountType.CASH;
                    }
                }
            }

            //清空所有优惠--会员价、折扣、赠送
            boolean cleanAllDiscount = request.getBoolean("cleanAllDiscount");
            if (cleanAllDiscount) {
                DiscountBizUtil.cleanAllDiscount(orderCache.originMenuList);
            }

            //整单立减折扣
            String fsDiscountCutId = request.getString("fsDiscountCutId");
            DiscountDBModel discountDBModelCut = null;
            if (!TextUtils.isEmpty(fsDiscountCutId)) {
                discountDBModelCut = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + fsDiscountCutId + "' and fiStatus = '1' ", DiscountDBModel.class);
                if (discountDBModelCut != null && !DiscountBizUtil.dataIsEffectiveDate(discountDBModelCut)) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "整单立减折扣[" + discountDBModelCut.fsDiscountName + "]未生效";
                    return response;
                }
            }

            orderCache.selectOrderDiscountCut = CouponUtil.convertToDiscountBizModel(discountDBModelCut);

            //如果要执行赠送、菜品会员价、菜品折扣， 必须指定菜品
            //TODO 整单立减、清空所有优惠操作不需要选中菜品
            if ((ListUtil.isEmpty(uniqList) && ListUtil.mapIsEmpty(ingredientsMapping)) && (gift || useMemberPrice || !TextUtils.isEmpty(fsDiscountId))) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请选择菜品";
                return response;
            }

            DiscountDBModel discountDBModel = null;
            if (!TextUtils.isEmpty(fsDiscountId)) {
                discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + fsDiscountId + "' and fiStatus = '1' ", DiscountDBModel.class);
                if (rate > 0) {
                    discountDBModel.fiDiscountRate = rate;
                }
                if (discountDBModel != null && !DiscountBizUtil.dataIsEffectiveDate(discountDBModel)) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "折扣[" + discountDBModel.fsDiscountName + "]未生效";
                    return response;
                }
            }

            int memberLevel = -1;
            String csId = "";
            String plusId = "";
            if (orderCache.isMember && orderCache.memberInfoS != null && orderCache.memberInfoS.level > 0) {
                memberLevel = orderCache.memberInfoS.level;
                csId = orderCache.memberInfoS.cs_id;
                plusId = orderCache.memberInfoS.plusId;
            }

            if (useMemberPrice || gift || (giftInfo != null && giftInfo.size() > 0)) {
                //清除菜品的买减信息
                DiscountBizUtil.cleanBuyGift(uniqList, giftInfo, orderCache.originMenuList);
            }

            if (!useMemberPrice && !gift && buygiftRelation != null && buygiftRelation.size() > 0) {
                DiscountBizUtil.doBuyGift(orderCache.originMenuList, uniqList, orderCache, buygiftRelation);
            }

            if (customAmt != null && customAmt.compareTo(BigDecimal.ZERO) > 0) {
                DiscountBizUtil.discount(orderCache.originMenuList, uniqList, gift, userDBModel.fsUserId, userDBModel.fsUserName, reason, useMemberPrice, false, discountDBModel, fsDiscountId, null, memberLevel, customAmt, csId, plusId, ingredientsMapping, cleanCouponMapping);
            } else {
                DiscountBizUtil.discount(orderCache.originMenuList, uniqList, gift, userDBModel.fsUserId, userDBModel.fsUserName, reason, useMemberPrice, false, discountDBModel, fsDiscountId, null, memberLevel, giftInfo, orderCache, csId, plusId, ingredientsMapping, cleanCouponMapping);
            }

            //重新计算价格
            orderCache.plusAllMenuAmount();
            //存入报表
            OrderSession.getInstance().writeOrder(orderId, true, "doDiscountForFastFood");
//            OrderProcessor.saveOrder(orderCache, null);

            responseData.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                responseData.menuItemList.addAll(orderCache.originMenuList);
            }

            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}
