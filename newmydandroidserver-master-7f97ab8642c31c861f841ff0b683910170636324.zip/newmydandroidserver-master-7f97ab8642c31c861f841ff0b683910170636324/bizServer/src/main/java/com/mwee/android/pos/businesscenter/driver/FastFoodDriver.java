package com.mwee.android.pos.businesscenter.driver;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.DishesBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintFastFoodOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.fastfood.BactchReturnDishesForFastFoodResponse;
import com.mwee.android.pos.connect.business.fastfood.ChangeFastFoodMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.FastFoodOperationConstant;
import com.mwee.android.pos.connect.business.fastfood.FastFoodOrderListResponse;
import com.mwee.android.pos.connect.business.fastfood.OnlyOrderMenuItemsResponse;
import com.mwee.android.pos.connect.business.fastfood.StartFastFoodOrderResponse;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/4/10.
 * 快餐业务
 * 1、开单 {@link FastFoodDriver#startFastFoodOrder}
 * 3、根据订单ID获取OrderCache{@link FastFoodDriver#optOrderCacheById}
 * 4、获取所有快餐订单简讯 {@link FastFoodDriver#fastFoodOrderList}
 * 5、解锁站点锁单的所有订单 {@link FastFoodDriver#unlockOrderByHost}
 * 6、修改快餐牌号 {@link FastFoodDriver#changeMealNumber}
 * 7、修改快餐来源 {@link FastFoodDriver#changeBillSource}
 */

@SuppressWarnings("unused")
public class FastFoodDriver implements IDriver {

    private static final String TAG = "fastfood";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 开单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/startFastFoodOrder")
    public SocketResponse startFastFoodOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            StartFastFoodOrderResponse responseData = new StartFastFoodOrderResponse();
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String userId = userDBModel.fsUserId;
            String userName = userDBModel.fsUserName;
            String hostId = head.hd;
            String fsBillSourceId = request.getString("fsBillSourceId");
            int personNum = 0;
            if (request.getInteger("personNum") != null) {
                personNum = request.getInteger("personNum");
            }
            synchronized (ServerCache.getInstance().tableLockCache.optFastFoodOrderLock) {
                // 取单前，优先释放本站点锁的所有订单。(小易快餐单是首页，强杀进程，可能导致订单被锁，直接取单会跳过订单)
                FastFoodBusinessUtil.unLockOrderByHostId(head.hd);

                OrderCache orderCache = null;
                if (personNum > 0) {
                    orderCache = FastFoodBusinessUtil.startFastFoodOrder(userId, userName, hostId, fsBillSourceId, personNum);
                } else {
                    orderCache = FastFoodBusinessUtil.startFastFoodOrder(userId, userName, hostId, fsBillSourceId);
                }

                responseData.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(orderCache);
                if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                    responseData.menuItems.addAll(orderCache.originMenuList);
                }

                //锁单
                FastFoodBusinessUtil.lockedOrder(orderCache.orderID, userId, userName, hostId);
                responseData.orderOptToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            }

            LogUtil.logBusiness("===startFastFoodOrder===",
                    "----" + responseData.fastOrderModel.orderId + "---hostId-userName--订单重复的日志------:");

            // 通知各个站点刷新锁单信息
            NotifyToClient.refreshFastFoodOrdersLock();
            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 根据ID查订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optOrderCacheById")
    public SocketResponse optOrderCacheById(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            StartFastFoodOrderResponse responseData = new StartFastFoodOrderResponse();

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String orderId = request.getString("orderId");
            String userId = userDBModel.fsUserId;
            String userName = userDBModel.fsUserName;
            String hostId = head.hd;

            // 判断是否已锁单
            String checkOrderLock = FastFoodBusinessUtil.checkOrderLock(hostId, userId, orderId);
            if (!TextUtils.isEmpty(checkOrderLock)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = checkOrderLock;
                return response;
            }

            //查询订单
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "未查到订单";
                return response;
            }

            //重新计算订单金额及优惠信息
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().refreshCacheOrder(orderCache);

            responseData.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(orderCache);
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                responseData.menuItems.addAll(orderCache.originMenuList);
            }
            //锁单
            FastFoodBusinessUtil.lockedOrder(orderCache.orderID, userId, userName, hostId);
            responseData.orderOptToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            responseData.orderStatus = orderCache.orderStatus;
            // 通知各个站点刷新锁单信息
            NotifyToClient.refreshFastFoodOrdersLock();

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取所有快餐订单简讯
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/fastFoodOrderList")
    public SocketResponse fastFoodOrderList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            FastFoodOrderListResponse responseData = new FastFoodOrderListResponse();
            responseData.fastFoodSimpInfoList = FastFoodBusinessUtil.qurySimpOrderInfos(request.getString("businessDate"), request.getString("fsBillSourceId"));

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 解锁站点下的所有订单
     *
     * @param requestHostID
     */
    @DrivenMethod(uri = TAG + "/unlockOrderByHost")
    public void unlockOrderByHost(String requestHostID) {
        FastFoodBusinessUtil.unLockOrderByHostId(requestHostID);
        // 推锁单信息
        NotifyToClient.refreshFastFoodOrdersLock();
    }

    /**
     * 修改快餐牌号
     */
    @DrivenMethod(uri = TAG + "/changeMealNumber")
    public SocketResponse changeMealNumber(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            String mealNumber = request.getString("mealNumber");
            OrderSession.getInstance().getOrder(orderId).mealNumber = mealNumber;
            OrderSaveDBUtil.updateMealNumber(orderId, mealNumber);
            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 修改快餐来源
     */
    @DrivenMethod(uri = TAG + "/changeBillSource")
    public SocketResponse changeBillSource(SocketHeader header, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            String fsBillSourceId = request.getString("fsBillSourceId");
            String str = "修改前的订单来源  fsBillSourceId-->" + OrderSession.getInstance().getOrder(orderId).fsBillSourceId + "     修改后的订单来源---->fsBillSourceId = " + fsBillSourceId;
            RunTimeLog.addLog(RunTimeLog.ORDER_DELETE, str, orderId);
            OrderSession.getInstance().getOrder(orderId).fsBillSourceId = fsBillSourceId;
            OrderSaveDBUtil.updateBillSourceId(orderId, fsBillSourceId);
            response.code = SocketResultCode.SUCCESS;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 修改快餐点菜信息
     */
    @DrivenMethod(uri = TAG + "/changeFastFoodMenuItems")
    public SocketResponse changeFastFoodMenuItems(SocketHeader header, String param) {
        SocketResponse response = new SocketResponse();
        ChangeFastFoodMenuItemsResponse responseData = new ChangeFastFoodMenuItemsResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            String uniq = request.getString("uniq");
            int operationType = request.getInteger("operationType");
            List<MenuItem> menuItemList = JSON.parseArray(request.getString("menuItemList"), MenuItem.class);
            if (TextUtils.isEmpty(orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单信息异常，请回到桌台页重试";
                return response;
            }

            String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", orderId, "修改快餐点菜信息");
            try {
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请回到桌台页重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (operationType != FastFoodOperationConstant.CLEAN_TABLE && (TextUtils.isEmpty(uniq) && ListUtil.isEmpty(menuItemList))) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "菜品异常，请回到桌台页重试";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }

                if (operationType == FastFoodOperationConstant.CLEAN_TABLE) {
                    // 检查订单中是否包含菜品券
                    boolean existDishCoupon = false;
                    for (MenuItem item : orderCache.originMenuList) {
                        if (item.usedMbCouponSucc() && item.memberDishCoupon != null) {
                            existDishCoupon = true;
                            break;
                        }
                    }
                    if (existDishCoupon) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "订单中包含菜品券，请先手动退回菜品券再清台";
                        return response;
                    }
                } else if (operationType == FastFoodOperationConstant.DELETE) {
                    // 检查条目中是否包含菜品券
                    boolean existDishCoupon = false;
                    for (MenuItem item : orderCache.originMenuList) {
                        if (item != null && !item.hasAllVoid() && TextUtils.equals(item.menuBiz.uniq, uniq)) {
                            if (item.usedMbCouponSucc() && item.memberDishCoupon != null) {
                                existDishCoupon = true;
                            }
                            break;
                        }
                    }
                    if (existDishCoupon) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "请先手动退回菜品券再删除菜品";
                        return response;
                    }
                }
                boolean neadSyncToDB = false;

                boolean refreshMenuList = false;
                switch (operationType) {
                    case FastFoodOperationConstant.ADD:
                        //更新多等级会员价
                        if (orderCache.memberInfoS != null && orderCache.memberInfoS.level > 0 && TextUtils.equals("1", DBMetaUtil.getConfig(META.AUTO_USE_MEMBER_PRICE, "1"))) {
                            BigDecimal vipPrice;
                            for (MenuItem item : menuItemList) {
                                if (item != null) {
                                    vipPrice = MenuItemVipPriceUtil.getMemberVipPrice(item.itemID, item.currentUnit.fiOrderUintCd, orderCache.memberInfoS.level, orderCache.memberInfoS.cs_id, orderCache.memberInfoS.plusId);
                                    if (item.currentUnit.fdVIPPrice.compareTo(BigDecimal.ZERO) != 0 && item.currentUnit.fdVIPPrice.compareTo(vipPrice) != 0) {
                                        item.currentUnit.fdVIPPrice = vipPrice;
                                        responseData.changedItemList.add(item);
                                    }
                                }
                            }
                        }

                        orderCache.originMenuList.addAll(0, menuItemList);
                        break;
                    case FastFoodOperationConstant.DELETE:

                        String menuInfo = "";
                        for (MenuItem item : orderCache.originMenuList) {
                            if (item != null && !item.hasAllVoid() && TextUtils.equals(item.menuBiz.uniq, uniq)) {
                                if (item.menuBiz.bugGiftItem != null) {
                                    refreshMenuList = true;
                                    menuInfo = item.itemID + "_" + item.currentUnit.fiOrderUintCd;
                                }
                                orderCache.originMenuList.remove(item);
                                break;
                            }
                        }

                        if (!TextUtils.isEmpty(menuInfo)) {
                            for (MenuItem item : orderCache.originMenuList) {
                                if (item != null && TextUtils.equals(item.itemID + "_" + item.currentUnit.fiOrderUintCd, menuInfo)) {
                                    item.cleanBuyGiftInfo();
                                }
                            }
                        }
                        break;
                    case FastFoodOperationConstant.CHANGE:
                        if (!ListUtil.isEmpty(menuItemList) && !ListUtil.isEmpty(orderCache.originMenuList)) {
                            for (MenuItem tempItem : menuItemList) {
                                for (MenuItem menuItem : orderCache.originMenuList) {
                                    if (TextUtils.equals(tempItem.menuBiz.uniq, menuItem.menuBiz.uniq)) {
                                        int index = orderCache.originMenuList.indexOf(menuItem);
                                        orderCache.originMenuList.remove(menuItem);
                                        orderCache.originMenuList.add(index, tempItem);
                                        if (orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            neadSyncToDB = true;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    case FastFoodOperationConstant.CLEAN_TABLE:
                        //清台
                        for (int i = 0; i < orderCache.originMenuList.size(); i++) {
                            MenuItem item = orderCache.originMenuList.get(i);
                            if (item != null && !orderCache.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                                orderCache.originMenuList.remove(i);
                                i--;
                                neadSyncToDB = true;
                            }
                        }
                        break;
                    default:
                        break;
                }

                orderCache.reCalcAllByAll();
                OrderSession.getInstance().writeOrder(orderId, neadSyncToDB, "changeFastFoodMenuItems");
                responseData.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                if (refreshMenuList) {
                    responseData.changedItemList = orderCache.originMenuList;
                }
                response.code = SocketResultCode.SUCCESS;
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", orderId, "修改快餐点菜信息");
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 仅下单
     *
     * @param param String
     * @return SocketResponse
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @DrivenMethod(uri = TAG + "/onlyOrderMenuItems")
    public SocketResponse onlyOrderMenuItems(SocketHeader head, String param) {
        final SocketResponse<OnlyOrderMenuItemsResponse> response = new SocketResponse<>();
        OnlyOrderMenuItemsResponse resposeData = new OnlyOrderMenuItemsResponse();
        response.data = resposeData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");

            if (TextUtils.isEmpty(orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单信息异常，请回到订单页重试";
                return response;
            }

            String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", orderId, "仅下单");
            try {
                final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请回到订单页重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }

                //前端所有未下单的菜
                List<MenuItem> itemList = JSON.parseArray(request.getString("menuItemList"), MenuItem.class);

                // 清除缓存中未下单的菜
                for (int i = 0; i < orderCache.originMenuList.size(); i++) {
                    MenuItem item = orderCache.originMenuList.get(i);
                    if (item != null && !item.hasAllVoid() && !orderCache.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                        orderCache.originMenuList.remove(i);
                        i--;
                    }
                }

                //去重的逻辑
                List<MenuItem> currentOrderMenu = new ArrayList<>();
                currentOrderMenu.addAll(orderCache.originMenuList);
                for (int i = 0; i < currentOrderMenu.size(); i++) {
                    MenuItem tempMenu = currentOrderMenu.get(i);
                    if (!orderCache.isOrderedSeqNo(tempMenu.menuBiz.orderSeqID)) {
                        itemList.add(tempMenu);
                        orderCache.originMenuList.remove(tempMenu);
                        continue;
                    }
                    for (int j = 0; j < itemList.size(); j++) {
                        MenuItem temp = itemList.get(j);
                        if (!TextUtils.isEmpty(tempMenu.menuBiz.uniq) && TextUtils.equals(tempMenu.menuBiz.uniq, temp.menuBiz.uniq)) {
                            //只要有一个菜是重复下的，就认为是重复订单
                            response.code = SocketResultCode.DUPLICATE;
                            response.message = "该订单已处理，请勿重复提交";
                            return response;
                        }
                    }
                }

                if (itemList.size() > 0) {
//                    response.code = SocketResultCode.DUPLICATE;
//                    response.message = "该订单已处理，请勿重复提交";
//                    return response;
//                }
                    List<MenuItem> unOrderItems = new ArrayList<>();     //所有未下单的菜
                    List<Integer> normalOrderSeqModel = new ArrayList<>();   //所有未下单的单序ID

                    //给未下单的菜赋值下单时间，拆分配料菜
                    for (int i = 0; i < itemList.size(); i++) {
                        MenuItem menuItem = itemList.get(i);
                        if (menuItem != null && !orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                            menuItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                            if (!menuItem.supportWeight() && menuItem.supportIngredient() && menuItem.menuBiz.selectedModifier.size() > 0 && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ONE) > 0) {
                                unOrderItems.addAll(menuItem.splitIngredientItem());
                            } else {
                                unOrderItems.add(menuItem);
                            }
                            normalOrderSeqModel.add(menuItem.menuBiz.orderSeqID);
                        }
                    }

                    if (!ListUtil.isEmpty(unOrderItems)) {
                        if (DBMetaUtil.autoUseMemberPrice()) {
                            //开启自动使用会员价 后加菜的菜品自动使用会员价
                            for (MenuItem menuItem : unOrderItems) {
                                // 会员价不覆盖已赠菜品
                                if (orderCache.isMember && !menuItem.hasAlreadyGift()) {
                                    menuItem.useVipPrice(userDBModel.fsUserId, "");
                                }
                            }
                        }

                        orderCache.originMenuList.addAll(unOrderItems);
                        //先检查估清
                        SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(unOrderItems);
                        if (!result.success) {
                            response.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                            response.message = result.errorMsg;
                            return response;
                        }

                        for (Integer i : normalOrderSeqModel) {
                            orderCache.updateSeqStatus(i, OrderSeqStatus.ORDERED, userDBModel, head.hd);
                        }

                        //更新单序前先打印小票
                        orderCache.currentSeq++;
                        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, null, head.hd);
                        String mealNumber = request.getString("mealNumber");
                        if (!TextUtils.isEmpty(mealNumber)) {
                            orderCache.mealNumber = mealNumber;
                        }
                        orderCache.reCalcAllByAll();
                        OrderSession.getInstance().writeOrder(orderCache.orderID, false, "onlyOrderMenuItems");
                        OrderProcessor.saveOrder(orderCache, null);

                        //打印点菜单
                        List<Integer> printNoList = PrintFastFoodOrderUtil.printMenuList(orderCache, userDBModel, orderCache.currentSeq - 1, "", head.hd);
                        if (!ListUtil.isEmpty(printNoList)) {
                            response.data.printTaskIds.addAll(printNoList);
                        }

                        //打印制作单
                        if (DBOrderConfig.useKdsService() && DBOrderConfig.fastUseKdsService()) {//快餐KDS
                            KdsManager.getInstance().order(orderCache, String.valueOf(orderCache.currentSeq - 1), head.hd, userDBModel);
                        } else {
                            //打印传菜单
                            printNoList = PrintFastFoodOrderUtil.printPassTo(orderCache, userDBModel, "" + (orderCache.currentSeq - 1), head.hd,
                                    false, null,null);
                            if (!ListUtil.isEmpty(printNoList)) {
                                response.data.printTaskIds.addAll(printNoList);
                            }
                            printNoList = PrintFastFoodOrderUtil.printMake(orderCache, userDBModel, orderCache.currentSeq - 1, head.hd);
                            if (!ListUtil.isEmpty(printNoList)) {
                                response.data.printTaskIds.addAll(printNoList);
                            }
                        }
                    } else if (ListUtil.isEmpty(orderCache.originMenuList)) {  //空单不能下单、挂账
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "请选择下单菜品";
                        return response;
                    }
                }
                //更新快餐订单业务状态
                FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 1);

                //解锁订单
                FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);

                boolean newOrderCache = request.getBoolean("newOrderCache");
                if (newOrderCache) {
                    OrderCache newCache = FastFoodBusinessUtil.startFastFoodOrder(userDBModel.fsUserId, userDBModel.fsUserName, head.hd, orderCache.fsBillSourceId);

                    orderCache.reCalcAllByAll();

                    resposeData.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(newCache);
                    resposeData.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(newCache);
                    if (!ListUtil.isEmpty(newCache.originMenuList)) {
                        resposeData.menuItemList.addAll(newCache.originMenuList);
                    }
                    FastFoodBusinessUtil.lockedOrder(newCache.orderID, userDBModel.fsUserId, userDBModel.fsUserName, head.hd);
                    resposeData.orderOptToken = ServerCache.getInstance().generateNewToken(newCache.orderID);
                }

                // 通知各个站点刷新桌台页面
                NotifyToClient.refreshFastFoodOrdersLock();

                response.code = SocketResultCode.SUCCESS;
                response.message = "同步成功";
                NotifyToClient.orderChange(orderCache.orderID); // 同步订单后，可能影响到桌台页显示的订单相关信息，如订单总价
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", orderId, "仅下单");
            }
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 菜品入库
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/menuItemsInsertToSellDB")
    public SocketResponse menuItemsInsertToSellDB(SocketHeader head, String param) {
        final SocketResponse<OnlyOrderMenuItemsResponse> response = new SocketResponse<>();
        OnlyOrderMenuItemsResponse resposeData = new OnlyOrderMenuItemsResponse();
        response.data = resposeData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");

            if (TextUtils.isEmpty(orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单信息异常，请回到快餐列表页重试";
                return response;
            }

            String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", orderId, "快餐菜品入库");
            try {
                final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请回到桌台页重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }

                //前端所有未下单的菜
                List<MenuItem> itemList = JSON.parseArray(request.getString("menuItemList"), MenuItem.class);

                // 清除缓存中未下单的菜
                for (int i = 0; i < orderCache.originMenuList.size(); i++) {
                    MenuItem item = orderCache.originMenuList.get(i);
                    if (item != null && !item.hasAllVoid() && !orderCache.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                        orderCache.originMenuList.remove(i);
                        i--;
                    }
                }


                List<MenuItem> unOrderItems = new ArrayList<>();     //所有未下单的菜

                //给未下单的菜赋值下单时间，拆分配料菜
                if (!ListUtil.isEmpty(itemList)) {
                    for (int i = 0; i < itemList.size(); i++) {
                        MenuItem menuItem = itemList.get(i);
                        if (menuItem != null && !orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                            menuItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                            if (!menuItem.supportWeight() && menuItem.supportIngredient() && menuItem.menuBiz.selectedModifier.size() > 0 && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ONE) > 0) {
                                unOrderItems.addAll(menuItem.splitIngredientItem());
                            } else {
                                unOrderItems.add(menuItem);
                            }
                        }
                    }
                }

                if (!ListUtil.isEmpty(unOrderItems)) {
                    orderCache.originMenuList.addAll(0, unOrderItems);
                    //先检查估清
                    SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(unOrderItems, false);
                    if (!result.success) {
                        response.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                        response.message = result.errorMsg;
                        return response;
                    }

                    String mealNumber = request.getString("mealNumber");
                    if (!TextUtils.isEmpty(mealNumber)) {
                        orderCache.mealNumber = mealNumber;
                    }
                    orderCache.reCalcAllByAll();
//                    OrderSession.getInstance().writeOrder(orderId, false, "menuItemsInsertToSellDB");
                    OrderSaveDBUtil.saveOnly(orderId, orderCache, true);  //未下单菜品入库
                    OrderProcessor.saveOrder(orderCache, null, true);   //未下单菜品入库
                }

                //更新快餐订单业务状态
                FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 1);

                // 通知各个站点刷新桌台页面
                NotifyToClient.refreshFastFoodOrdersLock();

                response.code = SocketResultCode.SUCCESS;
                response.message = "同步成功";
                NotifyToClient.orderChange(orderCache.orderID); // 同步订单后，可能影响到桌台页显示的订单相关信息，如订单总价
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", orderId, "快餐菜品入库");
            }
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return response;
    }


    /**
     * 快餐退菜，支持单个和批量
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/batchReturnDishesForFastFood")
    public static SocketResponse batchReturnDishesForFastFood(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        response.code = SocketResultCode.SUCCESS;
        response.message = "";
        final BactchReturnDishesForFastFoodResponse responseData = new BactchReturnDishesForFastFoodResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");


            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return response;
            }

            String hostId = head.hd;
            List<VoidMenuItemModel> voidMenuItemModels = JSON.parseArray(request.getString("voidMenuItemModels"), VoidMenuItemModel.class);


            int result = DishesBizUtil.returnMenuItem(orderId, head.hd, "", userDBModel, voidMenuItemModels, responseData.printNoList);
            if (result == 0) {
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                responseData.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                    responseData.menuItemList.addAll(orderCache.originMenuList);
                }
                response.code = SocketResultCode.SUCCESS;
                response.message = "退菜成功";
            } else if (result == -1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已不存在，请稍后重试";
            } else if (result == -2) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单号异常";
            } else if (result == -3) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已被结账";
            } else if (result == -4) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "退菜中包含菜品券，不允许退菜";
            }

        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return response;
    }


}
