package com.mwee.android.pos.businesscenter.print.air;

import android.text.TextUtils;

import com.mwee.android.air.util.TicketTempletConstants;
import com.mwee.android.pos.business.print.StatementSellReceiveModel;
import com.mwee.android.pos.businesscenter.print.DeviceDBUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.FormatUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;

import java.math.BigDecimal;
import java.util.List;

/**
 * Description: 小易这边打印需求会影响到美易点
 * 考虑到项目进度先把 不同点放到这里
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/6/12
 */
public class AirPrinterSelect {
    boolean isAir;

    public AirPrinterSelect() {
        isAir = APPConfig.isAir();
    }

    /**
     * 小易产品要求
     * 获取外卖打印机 名字
     *
     * @param hostId
     * @param defaultName
     * @return
     */
    public String getNetCustomPrinterName(String hostId, String defaultName) {
        String fsPrinterName = "";
        if (!isAir) {
            return defaultName;
        }
        PrinterDBModel printer = DeviceDBUtil.getPrinterByHostID(hostId);
        if (printer == null) {
            fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
        } else {
            fsPrinterName = printer.fsPrinterName;
        }
        return fsPrinterName;
    }

    /**
     * 小易产品要求 会员号超过8位 前4后4之间用*
     *
     * @param cardNo
     * @return
     */
    public String getMemberCardPrintFormat(String cardNo) {
        if (!isAir) {
            return cardNo;
        }
        if (cardNo != null && cardNo.length() > 8) {
            cardNo = cardNo.substring(0, 4) + "****" + cardNo.substring(cardNo.length() - 4, cardNo.length());
        }
        return cardNo;
    }

    public String getAirDeptIDNotFound(String deptId, String info) {
        if (!isAir) {
            return info;
        }
        //原来小易写死的部门
        if (TextUtils.equals(deptId, "2") || TextUtils.equals(deptId, "3")) {
            return "";
        }
        return info;
    }

    /**
     * 快餐单构建打印数据的一些操作放到了打印进程 导致小票模版没正确打印
     *
     * @param sellorder
     * @return
     */
    public List<StatementSellReceiveModel> buildFastSellOrderPrintData(List<StatementSellReceiveModel> sellorder) {
        if (!isAir) {
            return sellorder;
        }
        //与正餐构建相同数据  参照FastFoodBillCommandProcessor.procssBill修改
        for (int i = 0; i < sellorder.size(); i++) {
            StatementSellReceiveModel temp = sellorder.get(i);
            temp.paymentname = temp.paymentname + ":";
            String memberScoreCostStr = temp.fsbackup2;
            String cardInfo = "(卡号:" + FormatUtil.formatMemberCardNo(temp.fsMemCardNo) + ")";
            if (!TextUtils.isEmpty(temp.fsMemCardNo)) {
                if (TextUtils.equals("95002", temp.fspaymentid)) {
                    if (TextUtils.isEmpty(memberScoreCostStr) || TextUtils.equals("0", memberScoreCostStr)) {
                        temp.paymentname = temp.paymentname + "抵扣";
                        temp.fsNote = "元" + cardInfo;
                    } else {
                        temp.paymentname = temp.paymentname + "使用" + memberScoreCostStr + "积分,抵扣";
                        temp.fsNote = "元" + cardInfo;
                    }
                } else if (TextUtils.equals("95001", temp.fspaymentid)) {
                    temp.fsNote = cardInfo;
                }
            }
            BigDecimal change = temp.fdPayMoney.subtract(temp.fdReceMoney);
            if (change.compareTo(BigDecimal.ZERO) > 0) {
                StatementSellReceiveModel changeReceive = new StatementSellReceiveModel();
                changeReceive.paymentname = "找零:";
                //小票模板使用这个字段
                changeReceive.fspaymentname = "找零:";
                temp.fdPayMoney = temp.fdReceMoney;
                changeReceive.fdPayMoney = change;
                sellorder.add(i, changeReceive);
            }
        }
        return sellorder;
    }
}
