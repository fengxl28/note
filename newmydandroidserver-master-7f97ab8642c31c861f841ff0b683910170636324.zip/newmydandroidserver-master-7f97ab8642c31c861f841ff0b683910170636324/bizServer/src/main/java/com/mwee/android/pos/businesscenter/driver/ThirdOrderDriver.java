package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.netOrder.ThirdOrderTurnToLocalReportProcess;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.takeout.TakeOutMappedUploadListRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.thirdorder.ThirdMappingResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by liuxiuxiu on 2017/12/12.
 */

@SuppressWarnings("unused")
public class ThirdOrderDriver implements IDriver {

    private static final String TAG = "thirdOrder";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 外卖菜品映射
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/mappingThirdOrderMenu")
    public SocketResponse startFastFoodOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        response.code = SocketResultCode.SUCCESS;
        try {
            JSONObject request = JSON.parseObject(param);
            ThirdMappingResponse responseData = new ThirdMappingResponse();
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String userId = userDBModel.fsUserId;
            String userName = userDBModel.fsUserName;
            String hostId = head.hd;

            String orderId = request.getString("orderId");
            String uniq = request.getString("uniq");
            boolean uploadMapping = request.getBoolean("uploadMapping");
            MenuItem menuItem = JSON.parseObject(request.getString("menuItem"), MenuItem.class);

            if (TextUtils.isEmpty(orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单信息异常，请回到快餐列表页重试";
                return response;
            }

            if (menuItem == null || TextUtils.isEmpty(uniq)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "操作异常，请回到快餐列表页重试";
                return response;
            }

            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return response;
            }

            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未找到该订单，请退出重试";
                return response;
            }

               /* if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }*/

            if (uploadMapping) {
                String errMsg = uploadMapping(orderCache, uniq, menuItem);
                if (!TextUtils.isEmpty(errMsg)) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = errMsg;
                    return response;
                }
                doMapping(orderId, head.ot, uniq, head.hd, menuItem, userDBModel, responseData);
            } else {
                doMapping(orderId, head.ot, uniq, head.hd, menuItem, userDBModel, responseData);
            }
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    private static String uploadMapping(OrderCache orderCache, String uniq, MenuItem menuItem) {
        if (ListUtil.isEmpty(orderCache.originMenuList)) {
            return "订单异常，请退出重试";
        }
        TakeOutMenuItem takeOutMenuItem = null;

        for (MenuItem item : orderCache.originMenuList) {
            if (item != null && !item.hasAllVoid() && TextUtils.equals(item.menuBiz.uniq, uniq)) {
                takeOutMenuItem = new TakeOutMenuItem();

                takeOutMenuItem.takeawayItemId = item.thirdMenuId;
                takeOutMenuItem.takeawaySpecId = item.thirdUnitId;
                takeOutMenuItem.takeawayPrice = item.currentUnit.fdSalePrice.toPlainString();

                takeOutMenuItem.itemId = menuItem.itemID;
                takeOutMenuItem.itemName = menuItem.name;
                takeOutMenuItem.specId = menuItem.currentUnit.fiOrderUintCd;
                takeOutMenuItem.specName = menuItem.currentUnit.fsOrderUint;
                takeOutMenuItem.price = menuItem.currentUnit.fdSalePrice.toPlainString();
                break;
            }
        }

        if (takeOutMenuItem == null) {
            return "未找到指定菜品，请退出重试";
        }
        if (TextUtils.isEmpty(takeOutMenuItem.takeawayItemId) || TextUtils.isEmpty(takeOutMenuItem.takeawaySpecId)) {
            return "此菜品不支持将关联关系同步至云端";
        }

        final String[] errMsg = {""};
        loadMapper(findTakeOutSource(orderCache.fsBillSourceId), takeOutMenuItem, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                if (!result) {
                    errMsg[0] = TextUtils.isEmpty(info) ? "同步至云端失败" : info;
                }
            }
        });
        return errMsg[0];
    }

    private static String findTakeOutSource(String fsBillSourceId) {
        if (!TextUtils.isEmpty(fsBillSourceId)) {
            if (fsBillSourceId.startsWith("22")) {
                return "MEITUAN";
            } else if (fsBillSourceId.startsWith("21")) {
                return "MWEE";
            } else if (fsBillSourceId.startsWith("2")) {
                return "ELEME";
            } else if (fsBillSourceId.startsWith("4")) {
                return "BAIDU";
            }
        }
        return "";
    }


    /**
     * 手动上传映射菜品
     *
     * @param source          外卖渠道来源
     * @param takeOutMenuItem
     * @param callback
     */
    public static void loadMapper(String source, TakeOutMenuItem takeOutMenuItem, IResult callback) {
        TakeOutMappedUploadListRequest request = new TakeOutMappedUploadListRequest();
        request.request_id = UUID.randomUUID().toString();
        request.shop_guid = ServerCache.getInstance().shopID;
        request.takeaway_source = source;
        List<TakeOutMenuItem> items = new ArrayList<>();
        items.add(takeOutMenuItem);
        request.items = items;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness("绑定外卖菜品成功：" + JSON.toJSON(responseData));
                if (responseData.responseBean != null) {
                    callback.callBack(true, responseData.responseBean.msg);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.callBack(false, responseData.resultMessage);
                LogUtil.logBusiness("绑定外卖菜品失败：" + JSON.toJSON(responseData));
                return false;
            }
        }, false);

    }

    /**
     * 关联本地订单的映射关系
     *
     * @param orderId
     * @param ot
     * @param uniq
     * @param hd
     * @param menuItem
     * @param userDBModel
     * @param responseData
     */
    private static void doMapping(String orderId, String ot,
                                  String uniq, String hd, MenuItem menuItem, UserDBModel userDBModel, ThirdMappingResponse responseData) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", orderId, "外卖菜品映射");
        try {
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

            int orderSeqID = -1;
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                for (MenuItem item : orderCache.originMenuList) {
                    if (item != null && !item.hasAllVoid() && TextUtils.equals(item.menuBiz.uniq, uniq)) {
                        menuItem.menuBiz.selectOrderNote.clear();
                        menuItem.menuBiz.selectOrderNote = item.menuBiz.selectOrderNote;

                        if (menuItem.supportTimes()) {
                            menuItem.changeTimesPrice(item.price);
                        }

                        //价格
                        menuItem.price = item.price;
                        menuItem.menuBiz.totalPrice = item.menuBiz.totalPrice;
                        menuItem.menuBiz.buyNum = item.menuBiz.buyNum;
                        menuItem.menuBiz.priceExtraTotal = item.menuBiz.priceExtraTotal;

                        //menuItem.currentPractice = item.currentPractice;
                        //pro 2.5多做法需求
                        if (item.menuBiz.selectMulProcedure.size() > 0) {
                            menuItem.menuBiz.updateSelectMulPractice(item.menuBiz.selectMulProcedure);
                        }

                        menuItem.menuBiz.selectNote.addAll(item.menuBiz.selectNote);
                        menuItem.menuBiz.selectedExtraStr = item.menuBiz.selectedExtraStr;
                        menuItem.menuBiz.addConfig(8);
                        menuItem.menuBiz.uniq = uniq;
                        menuItem.menuBiz.orderSeqID = item.menuBiz.orderSeqID;
                        orderSeqID = item.menuBiz.orderSeqID;
                        menuItem.currentUnit.fdOriginPrice = item.currentUnit.fdOriginPrice;
                        menuItem.currentUnit.fdSalePrice = item.currentUnit.fdSalePrice;
                        menuItem.currentUnit.fdVIPPrice = item.currentUnit.fdVIPPrice;
                        menuItem.currentUnit.fdBargainPrice = item.currentUnit.fdBargainPrice;
                        menuItem.menuBiz.decreasConfig(1);
                        menuItem.menuBiz.pokeNo = item.menuBiz.pokeNo;
                        menuItem.terminal_id = item.terminal_id;
                        menuItem.fsBillSourceNo = item.fsBillSourceNo;
                        menuItem.thirdMenuId = item.thirdMenuId;
                        menuItem.thirdMenuName = item.thirdMenuName;
                        menuItem.thirdUnitId = item.thirdUnitId;
                        menuItem.thirdUnitName = item.thirdUnitName;
                        orderCache.originMenuList.remove(item);
                        orderCache.originMenuList.add(menuItem);
                        break;
                    }
                }

                int count = 0;
                for (MenuItem item : orderCache.originMenuList) {
                    if (item != null && !item.menuBiz.itemMapping()) {
                        count++;
                    }
                }

                ThirdOrderTurnToLocalReportProcess.updateThirdOrderToIO(orderCache.thirdOrderId, count, orderId);
            }

            if (orderSeqID != -1) {
                OrderSeqModel model = orderCache.optSeqModel(orderSeqID);
                if (model == null) {
                    model = new OrderSeqModel();
                    model.createTime = DateUtil.getCurrentTime();

                    model.seqNo = orderSeqID;
                    orderCache.seqList.add(model);
                }

                model.createWaiterID = userDBModel.fsUserId;
                model.createWaiterName = userDBModel.fsUserName;
                model.createHostID = hd;
                model.seqStatus = OrderSeqStatus.ORDERED;
            }

//            OrderSession.getInstance().writeOrder(orderId, orderCache);
            OrderSession.getInstance().writeOrder(orderId, true, "doMapping");

            PaySession paySession = OrderSession.getInstance().getPay(orderId);
            OrderUtil.recalcPaySessionLeftToPay(paySession, orderCache);
            OrderSession.getInstance().writePay(orderId, true);
            if (orderCache.orderStatus == OrderStatus.PAIED && paySession.payed == 1){
                OrderSession.getInstance().clearOrder(orderId);
            }
            responseData.menuItem = menuItem;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", orderId, "外卖菜品映射");
        }
    }

}
