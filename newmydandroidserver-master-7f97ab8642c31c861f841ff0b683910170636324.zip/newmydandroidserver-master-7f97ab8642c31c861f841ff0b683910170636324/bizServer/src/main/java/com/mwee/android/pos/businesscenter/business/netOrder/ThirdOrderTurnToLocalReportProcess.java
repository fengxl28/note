package com.mwee.android.pos.businesscenter.business.netOrder;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrderModifier;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemForThirdOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderMappingLocalOrderRelation;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.MenuTerminal;
import com.mwee.android.pos.db.NetOrderConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/12/6.
 * 第三方外卖转本地报表
 */
public class ThirdOrderTurnToLocalReportProcess {

    /**
     * 查询第三方订单是否已被转入本地报表
     *
     * @param thirdOrderId true： 本地库已有 | false: 本地库没有
     */
    public static boolean checkTurned(String thirdOrderId) {
        return !TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdorderid = '" + thirdOrderId + "'"));
    }

    /**
     * 查询第三方订单是否转入本地报表有异常记录
     *
     * @param thirdOrderId true： 有入库异常记录 | false: 无记录
     */
    public static boolean checkTurnedErrInfo(String thirdOrderId) {
        return !TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select key from datacache where key = '" + thirdOrderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "'"));
    }

    /**
     * 处理网络订单入报表问题
     *
     * @param tempAppOrder
     */
    public static void dealThirdOrder(final TempAppOrder tempAppOrder) {
        dealThirdOrder(tempAppOrder, false);
    }

    public static void dealThirdOrder(final TempAppOrder tempAppOrder, final boolean notifiyClient) {
        if (tempAppOrder == null) {
            return;
        }
        //美团外卖虚拟打印机来源 不落报表
        if (TextUtils.equals(tempAppOrder.orderTakeawaySource, TakeAwaySource.MWMEITUAN)) {
            return;
        }
        //新单不处理
        if (tempAppOrder.newOrder()) {
            return;
        }

        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {

                if (tempAppOrder.cancelStatus()) {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where key = '" + tempAppOrder.orderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "' ");
                    if (checkTurnedErrInfo(tempAppOrder.orderId)) {
                        updateThirdOrderUnTurnedTips(tempAppOrder.orderId, true);
                        return null;
                    } else if (!checkTurned(tempAppOrder.orderId)) {
                        return null;
                    } else {
                        cancelThirdOrder(tempAppOrder);
                    }
                } else {
                    if (checkTurned(tempAppOrder.orderId)) {
                        return null;
                    } else if (checkTurnedErrInfo(tempAppOrder.orderId)) {
                        return null;
                    } else {
                        //没开入库开关的不处理 (美收银默认入报表，不判断开关)
                        if (!APPConfig.isCasiher() && !NetOrderConfig.netOrderTurnToLocalReport()) {
                            return null;
                        }
                        if (HostUtil.getShopBizStatus() == HostStatus.FINISH) {
                            //未营业时不处理
                            return null;
                        }
                        //开入库开关的不处理 (美收银,美小易默认入报表，不判断开关)
                        if (NetOrderConfig.netOrderTurnToLocalReport() || APPConfig.isCasiher() || APPConfig.isAir()) {
                            saveThirdOrder(tempAppOrder, notifiyClient);
                        }
                    }
                }
                return null;
            }
        });
    }

    /**
     * 第三方外卖未匹配上的数量
     *
     * @param thirdOrderId 第三方订单号
     * @param count        未匹配上的菜品数量
     * @param fssellno     本地订单号
     */
    public synchronized static void updateThirdOrderToIO(String thirdOrderId, int count, String fssellno) {
        if (count <= 0) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where key = '" + thirdOrderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "'");
        } else {
            CacheModel cacheModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from datacache where key = '" + thirdOrderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "'", CacheModel.class);
            if (cacheModel == null) {
                cacheModel = new CacheModel();
                cacheModel.key = thirdOrderId;
                cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            }
            cacheModel.info = fssellno;
            cacheModel.value = String.valueOf(count);
            cacheModel.type = IOCache.TYPE_THIRD_ORDER_UNMAPPING;
            cacheModel.updatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            cacheModel.replaceNoTrans();
        }

        //通知站点刷新消息显示
        NotifyToClient.refreshUndealMessage();
    }

    /**
     * 记录第三方外卖不能入库
     *
     * @param orderId 第三方订单号
     * @param isRead  是否已读
     */
    public synchronized static void updateThirdOrderUnTurnedTips(String orderId, boolean isRead) {
        if (isRead) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update datacache set info = '1' where key = '" + orderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "'");
        } else {
            CacheModel cacheModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from datacache where key = '" + orderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNPROCESSOR + "'", CacheModel.class);
            if (cacheModel == null) {
                cacheModel = new CacheModel();
                cacheModel.key = String.valueOf(orderId);
                cacheModel.value = DateUtil.getCurrentDate("yyyy-MM-dd");
                cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                cacheModel.type = IOCache.TYPE_THIRD_ORDER_UNPROCESSOR;
                cacheModel.updatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                cacheModel.replaceNoTrans();
            }

        }

        //通知站点刷新消息显示
        NotifyToClient.refreshUndealMessage();
    }

    /**
     * 外卖订单取消
     *
     * @param tempAppOrder
     */
    private static void cancelThirdOrder(TempAppOrder tempAppOrder) {
        if (tempAppOrder == null) {
            return;
        }
        Object lock = ServerCache.getInstance().netOrderCache.optTurnToReportPoolLock(tempAppOrder.orderId);
        synchronized (lock) {
            String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdorderId = '" + tempAppOrder.orderId + "'");
            if (TextUtils.isEmpty(orderId)) {
                return;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                return;
            }

            //重拿一遍ordertoken，防止其他站点再操作此订单
            ServerCache.getInstance().generateNewToken(orderCache.orderID);
            UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
            if (userDBModel == null) {
                userDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fistatus = '1' limit 1", UserDBModel.class);
                if (userDBModel == null) {
                    userDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser limit 1", UserDBModel.class);
                }
            }

            if (userDBModel == null) {
                userDBModel = new UserDBModel();
                userDBModel.fsCreateUserId = "cache";
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "没有找到可用的服务员", "");
                return;
            }

            for (MenuItem item : orderCache.originMenuList) {
                if (item != null) {
                    item.doVoid(item.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "订单被取消");
                }
            }

            orderCache.personNum = 0;
            orderCache.orderStatus = OrderStatus.PAIED;
            //更新快餐订单业务状态
            FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 2);

            //OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache);
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "cancelThirdOrder");
            PaySession paySession = OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.cloudsite);
            paySession.payed = 1;
            paySession.waiterID = userDBModel.fsUserId;
            paySession.waiterName = userDBModel.fsUserName;
            paySession.currentShiftID = HostUtil.getShiftIDByHost(HostBiz.cloudsite);
            paySession.payed = 1;
            paySession.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);

            for (PayModel payModel : paySession.selectPayListFull) {
                if (payModel != null) {
                    payModel.status = PayTypeStatus.DELETE;
                }
            }

            OrderSession.getInstance().writePay(orderCache.orderID, paySession);
            OrderSession.getInstance().writePay(orderCache.orderID, true);
            OrderSession.getInstance().refreshCacheOrder(orderCache);
            updateThirdOrderToIO(tempAppOrder.orderId, 0, orderCache.orderID);
//            UploadDataProcessor.doUploadSingleOrderWithBaseData(orderCache.orderID);
            UploadDataHelper.uploadOrderData(orderCache.orderID, true);
        }
    }

    /**
     * 检查第三方订单帐是否平
     *
     * @param tempAppOrder 订单
     * @return boolean | true:帐平； false:帐不平
     */
    private static boolean checkPriceValide(TempAppOrder tempAppOrder) {
        if (tempAppOrder != null && !tempAppOrder.cancelStatus() && !ListUtil.isEmpty(tempAppOrder.orderDetailList)) {
            BigDecimal totalPrice = BigDecimal.ZERO;
            for (TempAppOrderDetail tempAppOrderDetail : tempAppOrder.orderDetailList) {
                if (tempAppOrderDetail == null || tempAppOrderDetail.totalItemPrice.compareTo(BigDecimal.ZERO) <= 0) {
                    continue;
                }
                totalPrice = totalPrice.add(tempAppOrderDetail.totalItemPrice);
            }

            if (tempAppOrder.boxFee != null && tempAppOrder.boxFee.compareTo(BigDecimal.ZERO) > 0) {
                totalPrice = totalPrice.add(tempAppOrder.boxFee);
            }
            if (tempAppOrder.deliveryFee != null && tempAppOrder.deliveryFee.compareTo(BigDecimal.ZERO) > 0) {
                totalPrice = totalPrice.add(tempAppOrder.deliveryFee);
            }

            boolean compare = false;

            if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                compare = tempAppOrder.total.compareTo(totalPrice) == 0;
            } else {
                compare = tempAppOrder.subTotal.compareTo(totalPrice) == 0;
            }

            if (!compare) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_PRICE_ERROR, "第三方订单入报表失败，原因：金额对不上 orderId = " + tempAppOrder.orderId + "; totalPrice = " + totalPrice, tempAppOrder.orderId, "", tempAppOrder);
            }
            return compare;

        }
        return false;
    }

    /**
     * 第三方订单入库
     *
     * @param tempAppOrder
     */
    private static void saveThirdOrder(TempAppOrder tempAppOrder, boolean notifiyClient) {

        if (tempAppOrder == null) {
            return;
        }
        Object lock = ServerCache.getInstance().netOrderCache.optTurnToReportPoolLock(tempAppOrder.orderId);
        synchronized (lock) {

            //当订单菜品金额和支付金额不一致时，订单不能如报表
            if (!checkPriceValide(tempAppOrder)) {
                updateThirdOrderUnTurnedTips(tempAppOrder.orderId, false);
                RunTimeLog.addLog(RunTimeLog.NETORDER_PRICE_ERROR, "第三方订单入报表失败，原因：金额对不上 orderId = " + tempAppOrder.orderId);
                return;
            }
            //外卖单是否已被取消
            boolean canceled = tempAppOrder.cancelStatus();

            UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
            if (userDBModel == null) {
                userDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser where fistatus = '1' limit 1", UserDBModel.class);
                if (userDBModel == null) {
                    userDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbuser limit 1", UserDBModel.class);
                }
            }

            if (userDBModel == null) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "没有找到可用的服务员", "");
                return;
            }

            String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdorderid = '" + tempAppOrder.orderId + "'");
            OrderCache orderCache = null;
            if (!TextUtils.isEmpty(orderId)){
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖订单已转化过" +  orderId, tempAppOrder.orderId);
                orderCache = OrderSession.getInstance().getOrder(tempAppOrder.orderId);
            }

            if (orderCache == null) {
                if (canceled) {
                    //订单已取消，且本地库里找不到对应订单，则不处理
                    return;
                } else {
                    //创建订单orderCache及paySession
                    orderCache = optNewOrderCache(tempAppOrder.orderId, tempAppOrder.orderTakeawaySource, userDBModel);

                    //插入外卖映射关系
                    updateTempappOrderMappingLocalOrder(tempAppOrder, orderCache);
                    if (orderCache != null) {
                        RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：已生成映射订单 " + orderCache.orderID, tempAppOrder.orderId);
                    }
                }
            }

            if (orderCache == null) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "获取网络订单失败", tempAppOrder.orderId);
                return;
            }

            orderCache.personNum = tempAppOrder.person;
            String orderToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);

            //整单备注
            NoteItemModel noteOrder = NoteItemModel.createCustomeNote(tempAppOrder.orderRemark, 1, BigDecimal.ZERO);
            //菜品未成功匹配上的数量
            int unMappingItemCount = 0;
            orderCache.originMenuList.clear();
            //临时菜
            MenuitemDBModel bizTempMenu = null;
            MenuItemUnitDBModel bizTempUnit = null;
            if (APPConfig.isAir()) {
                bizTempMenu = MenuItemDBUtils.queryById(DBConstants.MENU_ITEM_ID_TEMP);
            } else {
                bizTempMenu = MenuItemForThirdOrderDBUtil.getTemporaryMenuDBModel();
            }
            if (bizTempMenu == null) {
                //添加一个临时菜
                MenuItemForThirdOrderDBUtil.addTempMenu2NetOrderMapping(ServerCache.getInstance().shopID, userDBModel);
                bizTempMenu = MenuItemForThirdOrderDBUtil.getTemporaryMenuDBModel();
            }
            bizTempUnit = MenuDBUtil.getMenuUnit(bizTempMenu.fiItemCd, true);

            String terminal_id = optMenuTerminalId(tempAppOrder.orderTakeawaySource);
            String fsBillSourceNo = tempAppOrder.orderId;
            RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：开始映射菜品 " + orderCache.orderID, tempAppOrder.orderId);
            for (TempAppOrderDetail item : tempAppOrder.orderDetailList) {

                MenuitemDBModel itemDB = null;
                MenuItemUnitDBModel unitDBModel = null;
                MenuItem menuItem = null;

                String itemId = item.itemCode;
                if (TextUtils.equals(tempAppOrder.orderTakeawaySource, TakeAwaySource.MWEE) && !TextUtils.isEmpty(item.outerItemId)) {
                    itemId = item.outerItemId;
                }
                itemDB = MenuDBUtil.getUsefulMenuDBModelBy(itemId);

                if (!TextUtils.isEmpty(item.specId)) {
                    unitDBModel = MenuDBUtil.queryMenuItemUnit(item.specId);
                }

                //匹配到本地菜品
                if (itemDB != null) {
                    menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
                    if (unitDBModel != null) {
                        menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
                    }
                    if (menuItem.currentUnit == null) {
                        menuItem.currentUnit = new UnitModel();
                    }
                    if (menuItem.menuBiz == null) {
                        menuItem.menuBiz = new MenuBiz();
                    }
                    if (menuItem.supportTimes()) {
                        menuItem.changeTimesPrice(item.itemPrice);
                    }
                    menuItem.menuBiz.generateUniq();
                    menuItem.menuBiz.addConfig(8);
                } else {
                    //未匹配到本地菜品

                    /**
                     * 后台开启自动使用临时菜入库开关或者是美收银模式,未映射菜品自动使用临时菜入库
                     */
                    if ((TextUtils.equals(PrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU, "1") || APPConfig.isCasiher() || APPConfig.isAir()) && bizTempMenu != null) {
                        /* 构建菜品信息 */
                        menuItem = MenuDBUtil.buildMenuByDBModel(bizTempMenu.clone(), null, true);
                        if (menuItem.currentUnit == null) {
                            if (bizTempUnit != null) {
                                menuItem.currentUnit = UnitModel.copyTo(bizTempUnit);
                            } else {
                                menuItem.currentUnit = new UnitModel();
                            }
                        }
                        menuItem.name = item.itemName + "（外卖映射）";
                        menuItem.name2 = item.itemName + "（外卖映射）";

                    } else {
                        //未匹配到本地菜品
                        menuItem = new MenuItem();
                        if (unitDBModel == null) {
                            unitDBModel = new MenuItemUnitDBModel();
//                            unitDBModel.fiOrderUintCd = 0;
                            unitDBModel.fiOrderUintCd = "0";
                            unitDBModel.fsOrderUint = item.unit;
                        }
                        menuItem.currentUnit = UnitModel.copyTo(unitDBModel);
                        menuItem.name = item.itemName;
                        menuItem.name2 = item.itemName;
                    }

                    if (menuItem.menuBiz == null) {
                        menuItem.menuBiz = new MenuBiz();
                    }
                    menuItem.menuBiz.generateUniq();

                    menuItem.menuBiz.createTime = DateUtil.getCurrentTime();
                    //菜品自动映射失败
                    RunTimeLog.addLog(RunTimeLog.NETORDER_MAP_FAIL, "第三方订单入报表失败，原因：映射失败 orderId = " + tempAppOrder.orderId);
                    if (!APPConfig.isCasiher()) {
                        unMappingItemCount++;
                    }
                }
                menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
                orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
                orderCache.currentSeq++;

                initItemModifiers(item.modifiertypes, menuItem);

                menuItem.menuBiz.selectOrderNote.clear();
                menuItem.addOrderNote(noteOrder);
                //为兼容外卖菜品总价!=单价X数量的问题，POS入库时做兼容
                if (item.totalItemPrice.compareTo(item.itemPrice.multiply(new BigDecimal(item.itemNum))) != 0) {
                    item.itemPrice = item.totalItemPrice;
                    item.itemNum = 1;
                }

                //为兼容外卖菜品总价!=单价X数量的问题，POS入库时做兼容
                if (item.totalItemPrice.compareTo(item.itemPrice.multiply(new BigDecimal(item.itemNum))) != 0) {
                    item.itemPrice = item.totalItemPrice;
                    item.itemNum = 1;
                }

                menuItem.thirdMenuId = item.takeawayItemId;
                menuItem.thirdMenuName = item.itemName;
                menuItem.thirdUnitId = item.takeawaySpecId;
                menuItem.thirdUnitName = "";

                if (menuItem.supportTimes()) {
                    menuItem.changeTimesPrice(item.itemPrice);
                }

                //价格
                menuItem.price = item.itemPrice;
                menuItem.currentUnit.fdOriginPrice = item.itemPrice;
                menuItem.currentUnit.fdSalePrice = item.itemPrice;
                menuItem.currentUnit.fdVIPPrice = item.itemPrice;
                menuItem.currentUnit.fdBargainPrice = item.itemPrice;
                menuItem.menuBiz.decreasConfig(1);
                // 2017/12/26 itemPrice 即菜品最终价格, 不需额外计算 modifierPrice
//                menuItem.menuBiz.priceExtraTotal = item.modifierPrice;
                menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
                menuItem.menuBiz.totalPrice = item.totalItemPrice;
                menuItem.menuBiz.buyNum = new BigDecimal(item.itemNum);
                menuItem.menuBiz.pokeNo = item.pokeNo;
                menuItem.terminal_id = terminal_id;
                menuItem.fsBillSourceNo = fsBillSourceNo;
                orderCache.originMenuList.add(menuItem);
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：已映射菜品 " + menuItem.name + " orderId = "+ orderCache.orderID, tempAppOrder.orderId);

            }

            //餐盒费
            if (tempAppOrder.boxFee != null && tempAppOrder.boxFee.compareTo(BigDecimal.ZERO) > 0) {
                String itemId = NetOrderConfig.optBoxFeeMappingItemCd();
                String unitId = NetOrderConfig.optBoxFeeMappingUnitCd();
                MenuItem menuItem = optMenuItemd(bizTempMenu, bizTempUnit, itemId, unitId, tempAppOrder.boxFee, "餐盒费");
                //未映射菜品
                if (!TextUtils.equals(itemId, menuItem.itemID) && !APPConfig.isCasiher()) {
                    unMappingItemCount++;
                    menuItem.menuBiz.decreasConfig(8);
                } else {
                    menuItem.menuBiz.addConfig(8);
                }
                menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
                orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
                orderCache.currentSeq++;
                if (menuItem.supportTimes()) {
                    menuItem.changeTimesPrice(tempAppOrder.boxFee);
                }
                menuItem.thirdMenuName = "餐盒费";

                menuItem.terminal_id = terminal_id;
                menuItem.fsBillSourceNo = fsBillSourceNo;
                orderCache.originMenuList.add(menuItem);
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：餐盒费 " + tempAppOrder.boxFee + " orderId = "+ orderCache.orderID, tempAppOrder.orderId);

            }

            //配送费
            if (tempAppOrder.deliveryFee != null && tempAppOrder.deliveryFee.compareTo(BigDecimal.ZERO) > 0) {
                //TODO 这里是取配送费对应的菜品ID和规格ID，小易使用固定的ID，可以不去配置表里取
                String itemId = NetOrderConfig.optDeliveryFeeMappingItemCd();
                String unitId = NetOrderConfig.optDeliveryFeeMappingUnitCd();
                MenuItem menuItem = optMenuItemd(bizTempMenu, bizTempUnit, itemId, unitId, tempAppOrder.deliveryFee, "配送费");
                //未映射菜品
                if (!TextUtils.equals(itemId, menuItem.itemID) && !APPConfig.isCasiher()) {
                    unMappingItemCount++;
                    menuItem.menuBiz.decreasConfig(8);
                } else {
                    menuItem.menuBiz.addConfig(8);
                }
                menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
                orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
                orderCache.currentSeq++;
                if (menuItem.supportTimes()) {
                    menuItem.changeTimesPrice(tempAppOrder.deliveryFee);
                }
                menuItem.thirdMenuName = "配送费";

                menuItem.terminal_id = terminal_id;
                menuItem.fsBillSourceNo = fsBillSourceNo;
                orderCache.originMenuList.add(menuItem);
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：配送费 " + tempAppOrder.deliveryFee + " orderId = "+ orderCache.orderID, tempAppOrder.orderId);

            }

            if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                orderCache.totalPrice = tempAppOrder.total;
            } else {
                orderCache.totalPrice = tempAppOrder.subTotal;
            }

            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, null, HostBiz.cloudsite);
            //OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache);
            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache,true, "ThirdOrderTurnToLocalReportProcess saveThirdOrder");

            RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：菜品已处理完毕 orderId = "+ orderCache.orderID, tempAppOrder.orderId);

            buildPay(orderCache, userDBModel, tempAppOrder, orderToken);
            RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：支付信息已处理完毕 orderId = "+ orderCache.orderID, tempAppOrder.orderId);

            if (unMappingItemCount > 0 && !APPConfig.isCasiher() && !APPConfig.isAir() && !TextUtils.equals(PrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU, "1")) {
                orderCache.orderStatus = OrderStatus.NORMAL;
                //更新快餐订单业务状态
                FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 1);
                updateThirdOrderToIO(tempAppOrder.orderId, unMappingItemCount, orderCache.orderID);
                if (notifiyClient) {
                    sendNoticeMsg();
                }
                NotifyToClient.refreshTableOrOrders();
                OrderSession.getInstance().refreshCacheOrder(orderCache);

                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：有为映射菜品导致订单不能自动结账 orderId = "+ orderCache.orderID + " unMappingItemCount = " +unMappingItemCount, tempAppOrder.orderId);

            } else {
                orderCache.orderStatus = OrderStatus.PAIED;
                //OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache);
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache,true, "ThirdOrderTurnToLocalReportProcess saveThirdOrder 2");

                PaySession session = OrderSession.getInstance().getPay(orderCache.orderID);
                session.payed = 1;

                updateThirdOrderToIO(tempAppOrder.orderId, unMappingItemCount, orderCache.orderID);
                PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, "", userDBModel, HostBiz.cloudsite);

                //更新快餐订单业务状态
                FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 2);
//                UploadDataProcessor.doUploadSingleOrderWithBaseData(orderCache.orderID);
                UploadDataHelper.uploadOrderData(orderCache.orderID, true);
                OrderSession.getInstance().clearOrder(orderCache.orderID);
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：订单已自动结账 orderId = "+ orderCache.orderID + " unMappingItemCount = " +unMappingItemCount, tempAppOrder.orderId);

            }
            if (unMappingItemCount > 0) {
                NotifyToClient.addTakeOutMenuNoMapperMessage();
            }

//            OrderSession.getInstance().refreshCacheOrder(orderCache);
        }
    }

    private static MenuItem optMenuItemd(MenuitemDBModel bizTempMenu, MenuItemUnitDBModel bizTempUnit,
                                         String itemId, String unitId,
                                         BigDecimal price, String name) {
        MenuitemDBModel itemDB;
        MenuItemUnitDBModel unitDBModel = null;

        if (APPConfig.isCasiher() && bizTempMenu != null) {
            itemDB = bizTempMenu.clone();
            if (bizTempUnit != null) {
                unitDBModel = bizTempUnit.clone();
            }
        } else {
            itemDB = MenuDBUtil.getUsefulMenuDBModelBy(itemId);
            if (!TextUtils.isEmpty(unitId)) {
                unitDBModel = MenuDBUtil.queryMenuItemUnit(unitId);
            }
            if (itemDB == null && bizTempMenu != null && TextUtils.equals(PrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU, "1")) {
                itemDB = bizTempMenu.clone();
                if (bizTempUnit != null) {
                    unitDBModel = bizTempUnit.clone();
                }
            }
        }

        MenuItem menuItem = optMenuItem(itemDB, unitDBModel, price);
        //未匹配到本地菜品
        if (APPConfig.isCasiher()) {
            menuItem.name = name;
            menuItem.name2 = name;
        } else {
            //未匹配到本地菜品
            if (itemDB == null) {
                menuItem.name = name + "（外卖映射）";
                menuItem.name2 = name + "（外卖映射）";
            }
        }

        return menuItem;
    }

    private static MenuItem optMenuItem(MenuitemDBModel itemDB, MenuItemUnitDBModel unitDBModel, BigDecimal fee) {
        MenuItem menuItem;
        if (unitDBModel == null) {
            unitDBModel = new MenuItemUnitDBModel();
//            unitDBModel.fiOrderUintCd = 0;
            unitDBModel.fiOrderUintCd = "0";
            unitDBModel.fsOrderUint = "";
        }
        //匹配到本地菜品
        if (itemDB != null) {
            menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
            menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));

            if (menuItem.currentUnit == null) {
                menuItem.currentUnit = new UnitModel();
            }
            if (menuItem.menuBiz == null) {
                menuItem.menuBiz = new MenuBiz();
            }

            if (menuItem.supportTimes()) {
                menuItem.changeTimesPrice(fee);
            }

            menuItem.menuBiz.generateUniq();
            menuItem.menuBiz.addConfig(8);
        } else {
            //未匹配到本地菜品
            menuItem = new MenuItem();
            if (menuItem.menuBiz == null) {
                menuItem.menuBiz = new MenuBiz();
            }
            menuItem.menuBiz.generateUniq();

            menuItem.name = "餐盒费";
            menuItem.name2 = "餐盒费";
            menuItem.currentUnit = UnitModel.copyTo(unitDBModel);

            RunTimeLog.addLog(RunTimeLog.NETORDER_MAP_FAIL, "第三方订单入报表失败，原因：映射失败 name = " + menuItem.name);
        }

        menuItem.menuBiz.selectOrderNote.clear();

        if (menuItem.supportTimes()) {
            menuItem.changeTimesPrice(fee);
        }

        //价格
        menuItem.price = fee;
        menuItem.currentUnit.fdOriginPrice = fee;
        menuItem.currentUnit.fdSalePrice = fee;
        menuItem.currentUnit.fdVIPPrice = fee;
        menuItem.currentUnit.fdBargainPrice = fee;
        menuItem.menuBiz.decreasConfig(1);
        menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
        menuItem.menuBiz.totalPrice = fee;
        menuItem.menuBiz.buyNum = BigDecimal.ONE;
        menuItem.menuBiz.pokeNo = 0;

        return menuItem;
    }

    /**
     * 构建支付方式
     *
     * @param orderCache
     * @param userDBModel
     * @param tempAppOrder
     * @param orderToken
     */
    private static void buildPay(OrderCache orderCache, UserDBModel userDBModel, TempAppOrder tempAppOrder, String orderToken) {

        PaySession paySession = OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.cloudsite);
        String payTypeID;
        //配送费
        BigDecimal deliveryFee = tempAppOrder.deliveryFee == null ? BigDecimal.ZERO : tempAppOrder.deliveryFee;
        payTypeID = PayType.RMB;
        if (deliveryFee.compareTo(BigDecimal.ZERO) > 0) {
            if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                payTypeID = PayType.ELEME_DELIVERY;
            } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                payTypeID = PayType.MEITUAN_DELIVERY;
            }
            PayModel payModelDeliveryFee = optPayModel(userDBModel, payTypeID, deliveryFee, ++paySession.lastSeq);
            paySession.selectPayListFull.add(payModelDeliveryFee);
        }

        if (tempAppOrder.isOnlinePaid != 1) {
            //货到付款
            payTypeID = PayType.RMB;
            if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                payTypeID = PayType.ELEME_ARRIVE_PAY;
            } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                payTypeID = PayType.MEITUAN_ARRIVE_PAY;
            } else if (tempAppOrder.orderTakeawaySource.startsWith("MWEE")) {
                payTypeID = PayType.MWEE_ARRIVE_PAY;
            }

            BigDecimal payAmt = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(paySession.selectPayListFull)) {
                for (PayModel payModel : paySession.selectPayListFull) {
                    if (payModel != null) {
                        payAmt = payAmt.add(payModel.payAmount);
                    }
                }
            }

            PayModel payModelPayTatal = optPayModel(userDBModel, payTypeID, orderCache.totalPrice.subtract(payAmt), ++paySession.lastSeq);
            paySession.selectPayListFull.add(payModelPayTatal);
        } else {
            if (tempAppOrder.orderTakeawaySource.startsWith("MWEE")) {
                paySession.selectPayListFull.clear();
                paySession.lastSeq = 0;
                buildMweePay(paySession, orderCache, tempAppOrder, userDBModel, orderToken);
            } else {
                payTypeID = PayType.RMB;
                BigDecimal realPaymentAmount = tempAppOrder.earnestMoney;
                //实付
                if (tempAppOrder.realPaymentAmount != null && tempAppOrder.realPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
                    realPaymentAmount = tempAppOrder.realPaymentAmount;
                }

                //替用户承担的配送费
                BigDecimal merchantDeliverySubsidy = tempAppOrder.merchantDeliverySubsidy == null ? BigDecimal.ZERO : tempAppOrder.merchantDeliverySubsidy;
                payTypeID = PayType.RMB;
                if (merchantDeliverySubsidy.compareTo(BigDecimal.ZERO) > 0) {
                    payTypeID = PayType.ELEME_SHOP_PAY_DELIVERY;

                    PayModel payModelShopDiscount = optPayModel(userDBModel, payTypeID, merchantDeliverySubsidy, ++paySession.lastSeq);
                    paySession.selectPayListFull.add(payModelShopDiscount);
                }

                //商家优惠
                BigDecimal shopDiscountAmt = tempAppOrder.platformShopDiscount == null ? BigDecimal.ZERO : tempAppOrder.platformShopDiscount;
                payTypeID = PayType.RMB;
                if (shopDiscountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                        payTypeID = PayType.ELEME_SHOP_PAY;
                    } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                        payTypeID = PayType.MEITUAN_SHOP_PAY;
                    }

                    //商家优惠中包含了"替用户承担的配送费"，入库时要减去
                    if (shopDiscountAmt.compareTo(merchantDeliverySubsidy) >= 0) {
                        shopDiscountAmt = shopDiscountAmt.subtract(merchantDeliverySubsidy);
                    }

                    PayModel payModelShopDiscount = optPayModel(userDBModel, payTypeID, shopDiscountAmt, ++paySession.lastSeq);
                    paySession.selectPayListFull.add(payModelShopDiscount);
                }

                //平台优惠
                BigDecimal platDiscountAmt = tempAppOrder.platformDiscount == null ? BigDecimal.ZERO : tempAppOrder.platformDiscount;
                payTypeID = PayType.RMB;
                if (platDiscountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                        payTypeID = PayType.ELEME_APP_PAY;
                    } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                        payTypeID = PayType.MEITUAN_APP_PAY;
                    }
                    PayModel payModelPlatDiscount = optPayModel(userDBModel, payTypeID, platDiscountAmt, ++paySession.lastSeq);
                    paySession.selectPayListFull.add(payModelPlatDiscount);
                }

                //平台服务费
                BigDecimal serviceAmt = tempAppOrder.fdServiceAmt == null ? BigDecimal.ZERO : tempAppOrder.fdServiceAmt;
                payTypeID = PayType.RMB;
                if (serviceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                        payTypeID = PayType.ELEME_SERVICE;
                    } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                        payTypeID = PayType.MEITUAN_SERVICE;
                    }
                    PayModel payModelServiceAmt = optPayModel(userDBModel, payTypeID, serviceAmt, ++paySession.lastSeq);
                    paySession.selectPayListFull.add(payModelServiceAmt);
                }

                //其他优惠
                BigDecimal otherDiscountAmt = orderCache.totalPrice.subtract(realPaymentAmount).subtract(shopDiscountAmt).subtract(serviceAmt);

                payTypeID = PayType.RMB;
                if (otherDiscountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                        payTypeID = PayType.ELEME_OTHER_PAY;
                    } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                        payTypeID = PayType.MEITUAN_OTHER_PAY;
                    }
                    PayModel payModelOtherDiscount = optPayModel(userDBModel, payTypeID, otherDiscountAmt, ++paySession.lastSeq);
                    paySession.selectPayListFull.add(payModelOtherDiscount);
                }

                //实收金额
                BigDecimal payAmt = BigDecimal.ZERO;
                for (PayModel payModel : paySession.selectPayListFull) {
                    if (payModel != null) {
                        payAmt = payAmt.add(payModel.payAmount);
                    }
                }

                realPaymentAmount = orderCache.totalPrice.subtract(payAmt);
                payTypeID = PayType.RMB;
                //在线付款
                if (tempAppOrder.orderTakeawaySource.startsWith("ELEME")) {
                    payTypeID = PayType.ELEME_ONLINE_PAY;
                } else if (tempAppOrder.orderTakeawaySource.startsWith("MEITUAN")) {
                    payTypeID = PayType.MEITUAN_ONLINE_PAY;
                }

                PayModel payModelPayTatal = optPayModel(userDBModel, payTypeID, realPaymentAmount, ++paySession.lastSeq);
                paySession.selectPayListFull.add(payModelPayTatal);
            }
        }

        RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "外卖入报表：支付方式已增加完毕 orderId = "+ orderCache.orderID, tempAppOrder.orderId);

        OrderUtil.recalcPaySessionLeftToPay(paySession, orderCache);
        OrderSession.getInstance().writePay(orderCache.orderID, paySession);
        OrderSession.getInstance().writePay(orderCache.orderID, true);

    }

    private static PayModel optPayModel(UserDBModel userDBModel, String payTypeID, BigDecimal amt, int seq) {
        PayModel payModelServiceAmt = optPayModel(userDBModel, seq);
        payModelServiceAmt.payAmount = amt;
        //切换为第三方订单支付
        payModelServiceAmt.writeThirdOrder();
        payModelServiceAmt.seq = seq;
        payModelServiceAmt.data = OrderUtil.forceBuildPayModelByPaymentID(payTypeID);
        return payModelServiceAmt;
    }

    /**
     * 构建微信外卖支付方式
     *
     * @param originSession
     * @param orderCache
     * @param tempAppOrder
     * @param userDBModel
     */
    private static void buildMweePay(PaySession originSession, OrderCache orderCache, TempAppOrder tempAppOrder, UserDBModel userDBModel, String orderToken) {

        //刷新订单的满减的相关的待支付
        OrderUtil.recalcCouponCutWithPay(originSession, orderCache, false);
        PayModel parentPay = null;
        //构建支付明细
        for (RapidPayModel rapidPayModel : tempAppOrder.wposPayments) {
            if (TextUtils.isEmpty(rapidPayModel.fsPaymentId)) {
                continue;
            }
            if (rapidPayModel.fdReceMoney == null || rapidPayModel.fdReceMoney.compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            if (TextUtils.equals(PayType.REWART, rapidPayModel.fsPaymentId)) {
                orderCache.rewardinfo = "支付金额包含顾客打赏：" + rapidPayModel.fdReceMoney.toPlainString() + " [" + rapidPayModel.empNo + "]";
                OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, orderCache.rewardinfo);
                continue;
            }
            PayOriginModel data = null;
            if (OrderUtil.isMWMemberTicketByPayID(rapidPayModel.fsPaymentId)) {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            } else if (!TextUtils.isEmpty(rapidPayModel.fsMemberNo) && !TextUtils.isEmpty(rapidPayModel.fsCoupon_id)) {
                data = OrderUtil.buildPayModelByMemberTicketID(rapidPayModel.fsCoupon_id);
            } else {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            }

            //如果没有找到支付方式，则使用默认的卡券
            if (data == null) {
                data = PayUtil.addDefaultCoupon();
            }
            if (data == null) {
                data = OrderUtil.buildPayModelByPaymentID(PayType.RMB);
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "未找到可用支付方式使用人民币代替");
            }
            PayModel currentSelectPay = new PayModel(userDBModel.fsUserId, userDBModel.fsUserName);
            currentSelectPay.data = data;
            currentSelectPay.payAmount = rapidPayModel.fdReceMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
            currentSelectPay.status = 1;
            currentSelectPay.showNote = rapidPayModel.fsNote;
            currentSelectPay.createTime = DateUtil.getCurrentTime();
            currentSelectPay.businessInfo = tempAppOrder.orderId;
            //切换为第三方订单支付
            currentSelectPay.writeThirdOrder();

            if (OrderUtil.isMWMemberTicket(data.payTypeGroupID)) {
                currentSelectPay.data.memberCouponModel = new MemberCouponModel();
                currentSelectPay.data.memberCouponModel.code = rapidPayModel.fsMiscno;
            }
            if (!TextUtils.isEmpty(rapidPayModel.fsMemberNo)) {
                currentSelectPay.memberCardNO = rapidPayModel.fsMemberNo;
            }
            if (parentPay == null) {
                parentPay = currentSelectPay;
            } else {
                if (parentPay.secondPayList == null) {
                    parentPay.secondPayList = new ArrayList<>();
                }
                parentPay.secondPayList.add(currentSelectPay);
            }
        }

        //将支付明细进行落帐
        if (parentPay != null) {
            SocketResponse<PayResultResponse> socketResponse = BillUtil.addPayDetail(orderToken, orderCache.orderID, userDBModel, HostBiz.cloudsite, parentPay);
            if (socketResponse.success()) {
                orderCache.receiptName = tempAppOrder.receiptName;
                orderCache.receiptType = tempAppOrder.receiptType;
                orderCache.taxNo = tempAppOrder.taxNo;
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false,"after addPayDetail");
                OrderSaveDBUtil.updateTax(orderCache.orderID, tempAppOrder.receiptType, tempAppOrder.receiptName, tempAppOrder.taxNo);
            } else {
                RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "微信外卖支付方式落帐失败", JSON.toJSONString(tempAppOrder));
                return;
            }
        }
    }

    private static PayModel optPayModel(UserDBModel userDBModel, int seq) {
        PayModel payModelPayTatal = new PayModel(userDBModel.fsUserId, userDBModel.fsUserName);
        payModelPayTatal.updateTime = DateUtil.getCurrentTime();
        payModelPayTatal.updateWaiterID = userDBModel.fsUserId;
        payModelPayTatal.updateWaiterName = userDBModel.fsUserName;
        payModelPayTatal.hostID = HostBiz.cloudsite;
        payModelPayTatal.status = PayTypeStatus.ENABLE;
        payModelPayTatal.changeAmount = BigDecimal.ZERO;

        payModelPayTatal.seq = seq;
        payModelPayTatal.writeThirdOrder();

        return payModelPayTatal;
    }

    /**
     * 通知各站点  有XX条外卖单菜品映射错误
     */
    private static void sendNoticeMsg() {
        int count = MessageDBUtil.getUnMappingOrderCount("");
        NotifyToClient.thirdOrderMappingTip(String.valueOf(count));
    }

    public static void initItemModifiers(List<TempAppOrderModifier> modifiertypes, MenuItem menuItem) {
        if (!ListUtil.isEmpty(modifiertypes) && menuItem != null) {
            menuItem.menuBiz.selectNote.clear();
            menuItem.menuBiz.selectedExtraStr = "";

            for (TempAppOrderModifier modifierType : modifiertypes) {
                if (modifierType == null) {
                    continue;
                }
                if (!ListUtil.isEmpty(modifierType.modifiers)) {
                    for (TempModifierDetail modifier : modifierType.modifiers) {
                        //(0: 通用， 1：规格，2：口味，3：做法，4：要求 5：自定义备注)
                        if (RapidOrderModifier.PRACTICE == modifier.groupType) {
                            /* 做法 */
                            AskDBModel askDBModel = new AskDBModel();
                            askDBModel.fdAddPrice = BigDecimal.ZERO;
                            askDBModel.fsAskName = modifier.modifierName;

//                            menuItem.updateCurrentPractice(askDBModel);
                            menuItem.menuBiz.selectMulProcedure.add(askDBModel);
                            menuItem.menuBiz.buildSelectMulProcedureString(menuItem.menuBiz.selectMulProcedure);
                        } else if (RapidOrderModifier.GENERAL == modifier.groupType
                                || RapidOrderModifier.TASTE == modifier.groupType
                                || RapidOrderModifier.ASK == modifier.groupType
                                || RapidOrderModifier.NOTE_CUSTOME == modifier.groupType
                                ) {
                            /* 口味、要求，自定义备注 */
                            NoteItemModel note = new NoteItemModel();
                            note.selected = true;
                            note.num = modifier.modifierNum;
                            note.name = modifier.modifierName;
                            note.uniq = UUIDUtil.optUUID();
                            menuItem.addNote(note);
                        }
                    }
                }

            }
        }
    }

    /**
     * 网络订单转化本地订单，服务员、站点等都使用云收银
     *
     * @param tempAppOrder 第三方订单ID
     * @param orderCache   第三方订单ID
     * @return
     */
    public static void updateTempappOrderMappingLocalOrder(TempAppOrder tempAppOrder, OrderCache orderCache) {
        if (tempAppOrder == null || orderCache == null) {
            return;
        }
        TempAppOrderMappingLocalOrderRelation relation = new TempAppOrderMappingLocalOrderRelation();
        relation.businessDate = orderCache.businessDate;
        relation.fsShopGUID = orderCache.shopID;
        relation.localOrderId = orderCache.orderID;
        relation.orderTime = tempAppOrder.date;
        relation.tempAppOrderId = tempAppOrder.orderId;
        relation.mappintTime = DateUtil.getCurrentTime();
        relation.replaceNoTrans();

    }

    /**
     * 网络订单转化本地订单，服务员、站点等都使用云收银
     *
     * @param thirdOrderId 第三方订单ID
     * @return
     */
    public static synchronized OrderCache optNewOrderCache(String thirdOrderId, String orderTakeawaySource, UserDBModel userDBModel) {
        if (checkTurned(thirdOrderId)) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_TURN_TO_REPORT, "不能重复映射同一个外卖单", thirdOrderId);
            return null;
        }
        String shopID = HostUtil.getShopID();
        String date = HostUtil.getHistoryBusineeDate(shopID);
        String orderID = OrderDriver.generateNewOrderID(true);
        OrderCache orderCache = OrderDriver.generateNewOrder(orderID);
        orderCache.thirdOrderType = NetOrderType.NET_ORDER;
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = userDBModel.fsUserId;
        orderCache.waiterName = userDBModel.fsUserName;
        orderCache.shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        orderCache.businessDate = date;
        orderCache.mealNumber = orderID.substring(8);
        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.fiSellType = 2;
        orderCache.currentSeq = 1;
        orderCache.whetherRound = false;
        orderCache.thirdOrderId = thirdOrderId;
        orderCache.fsBillSourceId = optThirdOrderBillSourceId(orderTakeawaySource);
        // 当日已上传账单，后续账单默认隐藏
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0") || TextUtils.equals(status, "1")) {
            orderCache.hidden = 1;
        }
        orderCache.fsAccountBook = ",1,";
        orderCache.updateSeqStatus(1, OrderSeqStatus.NORMAL, userDBModel, HostBiz.cloudsite);
        //保存订单
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false,"optNewOrderCache");
        //锁死订单，不允许该订单被站点捡到
        FastFoodDBUtil.save(orderCache, 1);
        return orderCache;
    }

    /**
     * 获取订单来源ID
     *
     * @param orderTakeawaySource
     * @return
     */
    public static String optThirdOrderBillSourceId(String orderTakeawaySource) {
        if (!TextUtils.isEmpty(orderTakeawaySource)) {
            if (orderTakeawaySource.startsWith("ELEME")) {
                return "2";
            } else if (orderTakeawaySource.startsWith("MEITUAN")) {
//                update from 3 to 22 and ignore local past order in db
                return "22";
            } else if (orderTakeawaySource.startsWith("BAIDU")) {
                return "4";
            } else if (orderTakeawaySource.startsWith("MWEE")) {
                return "21";
            }
        }
        return "1";
    }

    /**
     * 获取点菜终端ID
     *
     * @param orderTakeawaySource
     * @return
     */
    public static String optMenuTerminalId(String orderTakeawaySource) {
        if (!TextUtils.isEmpty(orderTakeawaySource)) {
            if (orderTakeawaySource.startsWith("ELEME")) {
                return MenuTerminal.ELEME;
            } else if (orderTakeawaySource.startsWith("MEITUAN")) {
                return MenuTerminal.MEITUAN;
            } else if (orderTakeawaySource.startsWith("BAIDU")) {
                return MenuTerminal.BAIDU;
            } else if (orderTakeawaySource.startsWith("MWEE")) {
                return MenuTerminal.MWEE;
            } else {
                return MenuTerminal.TAKEOUT;
            }
        }
        return MenuTerminal.TAKEOUT;
    }

}
