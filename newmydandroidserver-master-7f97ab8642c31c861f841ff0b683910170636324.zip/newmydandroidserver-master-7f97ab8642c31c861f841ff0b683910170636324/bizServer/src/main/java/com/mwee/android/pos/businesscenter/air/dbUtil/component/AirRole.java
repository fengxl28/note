package com.mwee.android.pos.businesscenter.air.dbUtil.component;

import android.support.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleAdmin;
import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleBill;
import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleCashBox;
import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleDefault;
import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleRefund;
import static com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole.RoleReport;

/**
 * @ClassName: AirRole
 * @Description: 小散角色
 * @author: SugarT
 * @date: 2017/10/21 下午3:57
 */
@StringDef({RoleDefault, RoleCashBox, RoleBill, RoleRefund, RoleReport, RoleAdmin})
@Retention(RetentionPolicy.SOURCE)
public @interface AirRole {

    String RoleDefault = "100";

    String RoleCashBox = "101";

    String RoleBill = "102";

    String RoleRefund = "103";

    String RoleReport = "104";

    String RoleAdmin = "99";
}
