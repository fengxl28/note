package com.mwee.android.pos.businesscenter.driver;

import android.annotation.TargetApi;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.future.KBOrderRefundRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.member.GroupTicketUseRequest;
import com.mwee.android.pos.business.member.GroupTicketUseResponse;
import com.mwee.android.pos.business.member.IMemberRefund;
import com.mwee.android.pos.business.member.IMemberRefundNew;
import com.mwee.android.pos.business.member.MemberProcessResult;
import com.mwee.android.pos.business.member.entity.GroupTicket;
import com.mwee.android.pos.business.member.entity.GroupTicketUse;
import com.mwee.android.pos.business.netpay.NetPayProcessor;
import com.mwee.android.pos.business.netpay.model.GoodDetailModel;
import com.mwee.android.pos.business.netpay.model.NetPayModel;
import com.mwee.android.pos.business.permission.PermissionCheckDinner;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundRequest;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.mallprotocol.MallProtocolBizUtil;
import com.mwee.android.pos.businesscenter.business.message.MessageAbnormalOrderBizProcessor;
import com.mwee.android.pos.businesscenter.business.pay.IMemberBalance;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayBiz;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobWorker;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.cashier.CashierPayProcessor;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.netbiz.member.ServerMemberApi;
import com.mwee.android.pos.businesscenter.print.CheckAndPrintUtil;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintFastFoodOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintJSONBuilder;
import com.mwee.android.pos.businesscenter.print.PrintReportId;
import com.mwee.android.pos.businesscenter.utils.StringTool;
import com.mwee.android.pos.component.cross.net.HungOnLineRequest;
import com.mwee.android.pos.component.datasync.net.GetABBillStateRequest;
import com.mwee.android.pos.component.datasync.net.GetABBillStateResponse;
import com.mwee.android.pos.component.datasync.net.model.BillStateModel;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.MemberConsumePreSearchResponse;
import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberPayStoreResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberPrePayCheckResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBalanceRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundRequest;
import com.mwee.android.pos.connect.business.bill.entity.BillOptModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.GetPayMemberTicketResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.PayVoidResponse;
import com.mwee.android.pos.connect.business.pay.PreparePaySessionResponse;
import com.mwee.android.pos.connect.business.pay.model.PayViewBaseData;
import com.mwee.android.pos.connect.business.pay.model.PayViewBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.FeeAreaType;
import com.mwee.android.pos.db.business.pay.NetPayCallback;
import com.mwee.android.pos.db.business.pay.NetPayResult;
import com.mwee.android.pos.db.business.pay.OrderConfig;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeGroup;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType.KB_ORDER;

/**
 * Created by qinwei on 2017/2/8.
 */

public class BillUtil {

    private static final String TAG = "BillUtil";

    /**
     * 根据支付账单号查询 收银账单号
     *
     * @param fsmiscno
     * @return
     */
    public static String getSellnoByThirdPayInfo(String fsmiscno) {
        if (TextUtils.isEmpty(fsmiscno)) return null;
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tbSellReceive where fsmiscno='" + fsmiscno + "'");
    }

    /**
     * 将支付数据同步到订单表里
     *
     * @param orderID String
     */
    public static void updateOrderPayInfo(String orderID) {
        String sql = "update tbsell set fdDiffAmt='0',lver=lver+5,fdPayAmt=(select fdReceAmt from tbsellcheck where fssellno='$1s'),fdRealAmt=(select fdRealAmt from tbsellcheck where fssellno='$1s'),fdDiffAmt='0',fsCheckEndTime=(select subStr(tbsellcheck.fsCheckTime,11,6) from tbsellcheck where fssellno='$1s')  where tbsell.fssellno='$1s' ";
        sql = String.format(sql, orderID);
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    public static String checkOrderStatus(String orderID) {
        int orderStatus = OrderSaveDBUtil.getOrderStatus(orderID);
        if (orderStatus == OrderStatus.PAIED) {
            return StringTool.getString(R.string.ser_pay_already_paied);
        }
        return "";
    }

    public static SocketBaseResponse checkCanOperateOrder(String orderToken, String userID, String orderID) {
        SocketBaseResponse response = new SocketBaseResponse();
        if (TextUtils.isEmpty(orderID)) {
            response.msg(R.string.ser_pay_empty_orderid);
            return response;
        }
        //token校验
        if (!ServerCache.getInstance().verifyToken(orderID, orderToken)) {
            response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
            response.msg(R.string.ser_order_token_invalid);
            return response;
        }
        if (!PermissionCheckDinner.hasPayPermission(userID)) {
            response.msg(R.string.ser_pay_no_permission, userID);
            return response;
        }

        int orderStatus = OrderSession.getInstance().getOrder(orderID).orderStatus;
        if (orderStatus == OrderStatus.PAIED || orderStatus == OrderStatus.ANTI_BACK || orderStatus == OrderStatus.CANCEL) {
            response.msg(R.string.ser_pay_order_processed);
            return response;
        }
        String locked = PaySaveDBUtil.getLocked(orderID);
        if (TextUtils.equals(locked, "1")) {
            response.msg(R.string.ser_pay_shifted);
            return response;
        }
        return response;
    }

    public static SocketBaseResponse checkCanPay(String orderToken, String userID, String orderID, PayOriginModel... selectPay) {
        return checkCanPay(orderToken, userID, orderID, false, selectPay);
    }

    public static SocketBaseResponse checkCanPay(String orderToken, String userID, String orderID, boolean allowZero, PayOriginModel... selectPay) {
        SocketBaseResponse response;

        response = checkCanOperateOrder(orderToken, userID, orderID);
        if (!response.success()) {
            return response;
        }
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (session == null) {
            response.code = SocketResultCode.EXCEPTION;
            response.msg(R.string.ser_pay_invalid_order);
            return response;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        //重新计算待支付
        OrderUtil.recalcPaySessionLeftToPay(session, orderCache);
        if (!allowZero) {
            if (session.priceLeftToPay.compareTo(BigDecimal.ZERO) <= 0) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.msg(R.string.ser_pay_zero_amt);
                return response;
            }
        }
        // 预付金不做相同支付方式的校验
        if (!allowZero) {
            if (selectPay != null && selectPay.length > 0) {
                for (PayOriginModel temp : selectPay) {
                    //检测重复支付
                    String checkError = PayType.checkDuplicate(session.selectPayListFull, temp);
                    if (!TextUtils.isEmpty(checkError)) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = checkError;
                        return response;
                    }
                }
            }
        }
        return response;
    }

    public static String checkBarCode(String orderID, BigDecimal payAmount, String barCode) {

        if (payAmount == null || payAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return StringTool.getString(R.string.ser_pay_invalid_amt);
        }
        if (TextUtils.isEmpty(orderID)) {
            return StringTool.getString(R.string.ser_pay_empty_orderid);
        }
        if (TextUtils.isEmpty(barCode)) {
            return StringTool.getString(R.string.ser_pay_faild_scancode);
        }
        // 和 winpos 沟通，保持一致，去掉位数限制
//        if (barCode.length() < 17) {
//            return ServerCache.getString(R.string.ser_pay_faild_scancode);
//        }
        return "";
    }

    public static PayViewBaseData buildPayBase(String orderID) {
        return buildPayBase(orderID, true);
    }

    /**
     * 构建订单待支付的信息类
     *
     * @return PayViewBaseData
     */
    public static PayViewBaseData buildPayBase(String orderID, boolean withPayTypeList) {
        PayViewBaseData model = new PayViewBaseData();
        model.allowOverPay = PayUtil.supportOverPay();
        model.orderID = orderID;

        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (withPayTypeList) {
            model.payTypeList = buildPayTypeList(orderCache);
        }

        model.isAutoPay = PayUtil.supportAutoPay(orderCache.fiSellType);
        model.tableID = orderCache.fsmtableid;
        model.billNO = session.billNO;
        model.tableName = orderCache.fsmtablename;
        model.isMember = orderCache.isMember;
        model.thirdOrderId = orderCache.thirdOrderId;
        model.thirdOrderType = orderCache.thirdOrderType;
        model.rewardInfo = orderCache.rewardinfo;
        model.amtTotalNeedPay = orderCache.optTotalPrice();
        model.amtDiscounted = orderCache.totalDiscountAmount;
        model.amtOrigin = orderCache.priceTotalOriginAfterGift;
        model.amtTotalCanDiscount = PayUtil.getDiscountAmtByOrderTotal(orderCache);
        model.amtService = orderCache.totalService;
        model.orderStatus = orderCache.orderStatus;
        if (orderCache.fiSellType != 0) {
            model.hasFee = 0;
        } else if (orderCache.checkFreeFee()) {
            model.hasFee = 1;
        } else {
            if (OrderConfig.needServiceByMenu()) {
                model.hasFee = 1;
            } else if (OrderConfig.needServiceByArea()) {
                int serviceType = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiServiceType from tbmarea where fsmareaid='" + orderCache.fsmareaid + "'"));
                if (serviceType < FeeAreaType.NO || serviceType > FeeAreaType.FIX) {
                    model.hasFee = 0;
                } else {
                    model.hasFee = 1;
                }
            } else {
                model.hasFee = 0;
            }
        }
        if (orderCache.isMember && orderCache.memberInfoS != null) {
            model.memberCardNo = orderCache.memberInfoS.card_no;
            model.isMember = true;
        }
        return model;
    }

    public static List<PayOriginModel> buildPayTypeList(OrderCache orderCache) {
        List<PayOriginModel> payTypeList = new ArrayList<>();
        if (orderCache != null && orderCache.isMember && orderCache.memberInfoS != null) {
            if (PayCache.getInstance().payTypeMemberPoint != null) {
                PayOriginModel model = PayCache.getInstance().payTypeMemberPoint.clone();
                payTypeList.add(model);
            }
            if (PayCache.getInstance().payTypeMemberBalance != null) {
                payTypeList.add(PayCache.getInstance().payTypeMemberBalance);
            }
            if (APPConfig.isMyd()) {
                //air2.6 只有美易点显示优惠券
                payTypeList.add(getMemberPayType());
            }
        }
//        payTypeList.addAll(PayCache.getInstance().payTypeList);
        for (PayOriginModel payModel : PayCache.getInstance().payTypeList) {
            if (payModel == null) {
                continue;
            }
            //美易点普通版不需要展示口碑商品券支付方式
            if (PayType.isKoubeiTicket(payModel)) {
                if (APPConfig.isMyd()) {
                    if (APPConfig.isMydKouBei()) {
                        payTypeList.add(payModel);
                    }
                } else {
                    payTypeList.add(payModel);
                }
                continue;
            }
            payTypeList.add(payModel);
        }
        sortPayModel(payTypeList);
        return payTypeList;
    }

    private static PayOriginModel getMemberPayType() {
        PayOriginModel payOriginModel = new PayOriginModel();
        payOriginModel.payTypeGroupID = "-1001";
        payOriginModel.payName = "美会员优惠券";
        payOriginModel.payTypeID = "-1001";
        payOriginModel.color = Color.parseColor("#ff553a");
        payOriginModel.fsPayHelpCode = "MHYYHQ";
        return payOriginModel;
    }

    /**
     * 支付列表排序
     * 将无效支付方式排在最后面
     *
     * @return
     */
    private static void sortPayModel(List<PayOriginModel> payTypeList) {

        if (!ListUtil.isEmpty(payTypeList)) {
            for (int i = 0; i < payTypeList.size(); i++) {
                PayOriginModel payOriginModel = payTypeList.get(i);
                if (payOriginModel == null) {
                    payTypeList.remove(i);
                    i--;
                    continue;
                }
                if (!payOriginModel.dataIsEffectiveDate()) {
                    payTypeList.remove(i);
                    payTypeList.add(payOriginModel);
                }
            }
        }
    }

    /**
     * 构建订单待支付的信息类
     *
     * @return PayViewBaseData
     */
    public static PayViewBean buildPayViewData(String orderID) {
        PayViewBean model = new PayViewBean();
        model.orderID = orderID;

        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        PaySession session = OrderSession.getInstance().getPay(orderID);
        model.waiterID = session.waiterID;
        model.waiterName = session.waiterName;
        model.payTime = session.payTime;
        model.freeServiceFee = orderCache.checkFreeFee() ? 1 : 0;
        model.mealNo = orderCache.mealNumber;
        if (session != null) {
            OrderUtil.recalcPaySessionLeftToPay(session, orderCache);
            model.amtLeftToPay = session.priceLeftToPay;
            if (model.amtLeftToPay.compareTo(BigDecimal.ZERO) < 0) {
                model.isOverPay = 1;
                model.amtNeedChange = model.amtLeftToPay.negate();
                model.amtLeftToPay = BigDecimal.ZERO;
            } else {
                model.amtLeftCanDiscount = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);
            }
            if (!ListUtil.isEmpty(session.selectPayListFull)) {
                for (PayModel temp : session.selectPayListFull) {
                    if (temp.checkEnable()) {
                        if (model.amtNeedChange.compareTo(BigDecimal.ZERO) == 0 && temp.changeAmount.compareTo(BigDecimal.ZERO) > 0) {
                            model.amtNeedChange = temp.changeAmount;
                        }
                        model.payListToShow.add(temp);
                    }
                }
            }
        }
        return model;
    }

    /**
     * 进行挂帐
     *
     * @param orderToken String | 订单操作的Token
     * @param orderID    String | 订单ID
     * @param user       String | 操作的用户
     * @param hostID     String | 站点ID
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PreparePaySessionResponse> serviceFee(String orderToken, String orderID, UserDBModel user, String hostID, String permissionUserID, boolean doFree) {

        SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(orderToken, user.fsUserId, orderID);
        final SocketResponse<PreparePaySessionResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        PaySession session = OrderSession.getInstance().getPay(orderID);
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        String fsmtableid = OrderSession.getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 进行挂帐 ");
        try {

            if (doFree) {
                //免去服务费
                orderCache.writeConfig(1);
                orderCache.feeFreeOperUID = user.fsUserId;
                orderCache.feeFreeUID = permissionUserID;
                orderCache.feeFreeUName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsusername from tbuser where fsuserid='" + permissionUserID + "'");
            } else {
                orderCache.decreaseConfig(1);
                orderCache.feeFreeOperUID = "";
                orderCache.feeFreeUID = "";
                orderCache.feeFreeUName = "";
            }
            orderCache.plusAllMenuAmount();
            OrderSession.getInstance().writeOrder(orderID, true, "serviceFee");
            socketResponse.data = new PreparePaySessionResponse();
            socketResponse.data.orderID = orderID;
            socketResponse.data.baseData = BillUtil.buildPayBase(orderID);
            socketResponse.data.viewData = BillUtil.buildPayViewData(orderID);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 进行挂帐 ");
        }
        return socketResponse;
    }

    /**
     * 进行挂帐
     *
     * @param orderToken String | 订单操作的Token
     * @param orderID    String | 订单ID
     * @param user       String | 操作的用户
     * @param hostID     String | 站点ID
     * @param accountId  String | 挂帐的账户ID
     * @param amt        BigDecimal | 挂帐金额
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> selectHung(String orderToken, String orderID, UserDBModel user, String hostID, String accountId, String accountName, BigDecimal amt, UserDBModel certigierUser) {
        final PayModel currentSelectPay = new PayModel();
        currentSelectPay.data = OrderUtil.buildPayModelByPaymentID(PayType.HUNG);
        currentSelectPay.payAmount = amt;
        if (certigierUser != null) {
            currentSelectPay.certigierUserId = certigierUser.fsUserId;
            currentSelectPay.certigierUserName = certigierUser.fsUserName;
        }
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, currentSelectPay.data);
        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        PaySession session = OrderSession.getInstance().getPay(orderID);
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        //重新计算待支付
        OrderUtil.recalcPaySessionLeftToPay(session, orderCache);

        if (session.priceLeftToPay.compareTo(amt) < 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "挂账金额不能大于待支付金额";
            return socketResponse;
        }

        String fsmtableid = OrderSession.getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 进行挂帐: accountId = " + accountId + "; amt = " + amt);
        try {
            String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            String hungOrder = OrderUtil.buildNetOrderID(shopID, String.valueOf(session.billNO));

            HungOnLineRequest hungOnLineRequest = new HungOnLineRequest();
            hungOnLineRequest.cashierId = user.fsUserId;
            hungOnLineRequest.creditAccountName = accountName;
            hungOnLineRequest.cashierName = user.fsUserName;
            hungOnLineRequest.creditAccountId = accountId;
            hungOnLineRequest.sellDate = orderCache.businessDate;
            hungOnLineRequest.sellNo = orderID;
            hungOnLineRequest.checkBillNo = session.billNO;
            hungOnLineRequest.saleAmt = orderCache.totalPrice;
            hungOnLineRequest.debtAmt = amt;
            hungOnLineRequest.receiveSeq = hungOrder;

            BusinessExecutor.execute(hungOnLineRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null) {

                        RunTimeLog.addLog(RunTimeLog.PAY_HUNG, "在线挂账成功", orderID, orderCache.fsmtableid, hungOnLineRequest);

                        currentSelectPay.creditAccountID = accountId;
                        currentSelectPay.creditAccountName = accountName;
                        // 挂账人需作为备注打印在结账单上
                        currentSelectPay.showNote = currentSelectPay.creditAccountName;
                        currentSelectPay.businessInfo = hungOrder;
                        SocketResponse<PayResultResponse> addPayResponse = addPayDetail(orderToken, orderID, user, hostID, currentSelectPay);
                        if (addPayResponse.success()) {
                            RunTimeLog.addLog(RunTimeLog.PAY_HUNG, "在线挂账成功,添加到订单中成功", orderID, orderCache.fsmtableid, addPayResponse);

                            socketResponse.code = SocketResultCode.SUCCESS;
                            PayResultResponse payResultResponse = new PayResultResponse();
                            payResultResponse.payData = buildPayViewData(orderID);
                            socketResponse.data = payResultResponse;
                        } else {
                            RunTimeLog.addLog(RunTimeLog.PAY_HUNG, "在线挂账成功,添加到订单中失败,自动还原额度", orderID, orderCache.fsmtableid, JSON.toJSONString(hungOnLineRequest), addPayResponse);
                            //自动还原额度
                            BillUtil.doVoidPay(false, true, orderCache, session, orderToken, hostID, user, currentSelectPay, null);
                            socketResponse.code = addPayResponse.code;
                            socketResponse.message = addPayResponse.message;
                        }
                    } else {
                        RunTimeLog.addLog(RunTimeLog.PAY_HUNG, "在线挂账异常，response == null", orderID, orderCache.fsmtableid, hungOnLineRequest);
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "挂账异常，请重试";
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    RunTimeLog.addLog(RunTimeLog.PAY_HUNG, "在线挂账失败", orderID, orderCache.fsmtableid, hungOnLineRequest);

                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData == null ? "挂账异常，请重试" : responseData.resultMessage;
                    return false;
                }
            }, false);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 进行挂帐: accountId = " + accountId + "; amt = " + amt);
        }
        return socketResponse;
    }

    /**
     * 发起秒付的自动退款
     *
     * @param fsSellno     String | 关联订单号
     * @param thirdOrderID String | 第三方订单号
     */
    public static void autoVoidRapidPay(String fsSellno, String thirdOrderID) {
        Job job = new Job();
        job.type = JobType.REFUND_RAPID;
        RapidRefundRequest refundRequest = new RapidRefundRequest();
        refundRequest.orderId = thirdOrderID;
        job.info = JSON.toJSONString(refundRequest);
        job.finished = 3;
        job.biz_key = fsSellno;
        JobScheudler.newJob(job);
        JobWorker worker = new JobWorker();
        worker.work(job);
    }

    /**
     * 开始退款流程，匹配支付明细，并调用{@link #doVoidPay(boolean, boolean, OrderCache, PaySession, String, String, UserDBModel, PayModel, List)}
     *
     * @param orderToken String | 订单操作的Token
     * @param orderID    String | 订单ID
     * @param user       String | 操作的用户
     * @param hostID     String | 站点ID
     * @return SocketResponse<PayVoidResponse>
     */
    @TargetApi(Build.VERSION_CODES.ECLAIR)
    public static SocketResponse<PayVoidResponse> startCashierVoidPay(final String orderToken, final String orderID, final UserDBModel user, final String hostID) {
        SocketResponse<PayVoidResponse> socketResponse = new SocketResponse<PayVoidResponse>();
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (session == null) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "订单出现异常，不能再支付";
            return socketResponse;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        //待退款的支付明细，需要从list遍历seq
        PayModel payModel = null;
        //将待退款的支付明细和其关联的支付明细插入到这个list里
        List<PayModel> needVoidList = new ArrayList<>();

        PayVoidResponse response = new PayVoidResponse();

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 开始退款流程，匹配支付明细 ");
        try {

            for (int i = 0; i < session.selectPayListFull.size(); i++) {
                final PayModel temp = session.selectPayListFull.get(i);
                if (temp.checkEnable()) {
                    //命中则终止
                    payModel = temp;
                    OrderUtil.deletePayType(temp);
                    needVoidList.add(temp);
                }
            }
            if (payModel == null) {
                socketResponse.code = SocketResultCode.ORDER_CHANGED;
                return socketResponse;
            }
            for (int i = 0; i < session.selectPayListFull.size(); i++) {
                final PayModel temp = session.selectPayListFull.get(i);
                if (temp.checkEnable()) {
                    if (temp.checkIsRelative(payModel)) {
                        OrderUtil.deletePayType(temp);
                        needVoidList.add(temp);
                    } else if (!payModel.readRapid() && (PayType.isMWMemberPoint(payModel.data) || PayType.isMWMemberTicket(payModel.data)) && payModel.checkMemberConsumed()) {
                        if (!temp.readRapid() && (PayType.isMWMemberPoint(temp.data) || PayType.isMWMemberTicket(temp.data)) && temp.checkMemberConsumed()) {
                            OrderUtil.deletePayType(temp);
                            needVoidList.add(temp);
                        }
                    }
                }
            }
            OrderSession.getInstance().writePay(session.orderID, session);
            OrderProcessor.savePayOnly(session);
            Pair<List<Integer>, String> result = CashierPayProcessor.doCashierVoidPay(true, true, orderCache, session, orderToken, hostID, user, payModel, needVoidList);
            if (!ListUtil.isEmpty(result.first)) {
                response.printTaskIds.addAll(result.first);
            }
            if (!TextUtils.isEmpty(result.second)) {
                socketResponse.message = result.second;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            }

        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 开始退款流程，匹配支付明细 ");
        }
        socketResponse.data = response;
        return socketResponse;
    }

    /**
     * 开始退款流程，匹配支付明细，并调用{@link #doVoidPay(boolean, boolean, OrderCache, PaySession, String, String, UserDBModel, PayModel, List)}
     *
     * @param orderToken String | 订单操作的Token
     * @param orderID    String | 订单ID
     * @param user       String | 操作的用户
     * @param hostID     String | 站点ID
     * @param seq        int | 支付序号
     * @return SocketResponse<PayVoidResponse>
     */
    public static SocketResponse<PayVoidResponse> startVoidPay(final String orderToken, final String orderID, final UserDBModel user, final String hostID, int seq) {
        SocketResponse<PayVoidResponse> socketResponse = new SocketResponse<PayVoidResponse>();
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (session == null) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "订单出现异常，不能再支付";
            return socketResponse;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        //待退款的支付明细，需要从list遍历seq
        PayModel payModel = null;
        //将待退款的支付明细和其关联的支付明细插入到这个list里
        List<PayModel> needVoidList = new ArrayList<>();

        PayVoidResponse response = new PayVoidResponse();
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 开始退款流程，匹配支付明细2 ");
        try {
            String error = checkCanVoid(session, seq);
            if (!TextUtils.isEmpty(error)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = error;
                return socketResponse;
            }

            String kbPayOrderId = "";
            for (int i = 0; i < session.selectPayListFull.size(); i++) {
                final PayModel temp = session.selectPayListFull.get(i);
                if (temp.checkEnable() && (temp.seq == seq)) {
                    //命中则终止
                    payModel = temp;
                    OrderUtil.deletePayType(temp);
                    needVoidList.add(temp);
                    if (temp.kbAfterPay()) {
                        kbPayOrderId = temp.businessInfo;
                    }
                    break;

                }
            }

            List<PayModel> payModelList = new ArrayList<>();
            if (payModel != null && payModel.kbAfterPay()) {
                for (int i = 0; i < session.selectPayListFull.size(); i++) {
                    final PayModel temp = session.selectPayListFull.get(i);
                    if (temp.checkEnable() && (temp.seq != seq) && ((!TextUtils.isEmpty(kbPayOrderId) && TextUtils.equals(temp.businessInfo, kbPayOrderId)))) {
                        payModelList.add(temp);
                        OrderUtil.deletePayType(temp);
                        needVoidList.add(temp);
                    }
                }
            }
            payModelList.add(payModel);

            if (ListUtil.isEmpty(payModelList)) {
                socketResponse.code = SocketResultCode.ORDER_CHANGED;
                return socketResponse;
            }

            for (int i = 0; i < session.selectPayListFull.size(); i++) {
                final PayModel temp = session.selectPayListFull.get(i);
                if (temp.checkEnable()) {
                    for (PayModel tempModel : payModelList) {
                        if (temp.checkIsRelative(tempModel)) {
                            OrderUtil.deletePayType(temp);
                            needVoidList.add(temp);
                        } else if (!tempModel.readRapid() && ((PayType.isMWMemberPoint(tempModel.data) || PayType.isMWMemberTicket(tempModel.data)) && TextUtils.equals(temp.memberOrderID, tempModel.memberOrderID)) && tempModel.checkMemberConsumed()) {
                            OrderUtil.deletePayType(temp);
                            needVoidList.add(temp);
                        }
                    }
                }
            }
            //如果删除的是满减或整单立减，则需更新ordercache以及tbsell几张表
            if(payModel != null){
                if(payModel.readOrderCut()){
                    orderCache.clearCouponCut();
                    OrderSession.getInstance().writeOrder(orderID, true, "clearCouponCut");
                }else if(payModel.readPayCut()){
                    orderCache.clearOrderDiscountCut();
                    OrderSession.getInstance().writeOrder(orderID, true, "clearOrderDiscountCut");
                }
            }
            OrderSession.getInstance().writePay(session.orderID, session);
            OrderProcessor.savePayOnly(session);
            List<Integer> printNoList = BillUtil.doVoidPay(true, true, orderCache, session, orderToken, hostID, user, payModelList.get(0), needVoidList);
            if (!ListUtil.isEmpty(printNoList)) {
                response.printTaskIds.addAll(printNoList);
            }

            response.payViewBean = BillUtil.buildPayViewData(orderID);
            response.mPrePayAmt = OrderUtil.getPrePayAmt(orderID);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderID, user.fsUserName + " 站点：" + hostID + " 开始退款流程，匹配支付明细2 ");
        }
        socketResponse.data = response;
        return socketResponse;
    }

    /**
     * 校验是否可退款
     *
     * @param session PaySession
     * @param seq     int
     * @return String | 错误信息
     */
    private static String checkCanVoid(PaySession session, int seq) {
        PayModel payModel = null;
        for (int i = 0; i < session.selectPayListFull.size(); i++) {
            PayModel temp = session.selectPayListFull.get(i);
            if (temp.checkEnable() && temp.seq == seq) {
                payModel = temp;
                break;
            }
        }
        for (int i = 0; i < session.selectPayListFull.size(); i++) {
            PayModel temp = session.selectPayListFull.get(i);
            if (temp.checkEnable() && temp.checkIsRelative(payModel)) {
                if (PayType.isGroupTicket(temp.data)) {
                    return "团购券已被核销，不支持退款！";
                }
            }
        }
        return "";
    }


    /**
     * 开始退款
     *
     * @param refreshOrderInfo boolean | 是否刷新订单信息
     * @param needPrint        boolean | 是否需要打印"退款回执单"
     * @param orderCache       OrderCache | 关联的订单信息
     * @param session          PaySession | 关联的支付信息
     * @param orderToken       String | 订单操作的Token
     * @param hostID           String | 站点ID
     * @param user             String | 操作的用户
     * @param payModel         PayModel | 选择的退款model
     * @param needVoidList     List<PayModel> | 关联的退款model
     * @return ist<Integer> | 打印的printno序列
     */
    private static List<Integer> doVoidPay(final boolean refreshOrderInfo, final boolean needPrint, final OrderCache orderCache, final PaySession session, String orderToken, String hostID, UserDBModel user, PayModel payModel, List<PayModel> needVoidList) {

        if (ListUtil.isEmpty(needVoidList)) {
            if (needVoidList == null) {
                needVoidList = new ArrayList<>();
            }
            needVoidList.add(payModel);
            if (!ListUtil.isEmpty(payModel.secondPayList)) {
                needVoidList.addAll(payModel.secondPayList);
            }
            if (!ListUtil.isEmpty(payModel.subPayList)) {
                needVoidList.addAll(payModel.subPayList);
            }
        }
        BigDecimal totalVoidAmt = OrderUtil.recalTotalPaiedAmount(needVoidList, true);
        Job job = null;
        String thirdOrderID = "";
        if (payModel.readRapid()) {
            job = new Job();
            job.type = JobType.REFUND_RAPID;
            RapidRefundRequest refundRequest = new RapidRefundRequest();
            refundRequest.orderId = payModel.businessInfo;
            thirdOrderID = payModel.businessInfo;
            job.info = JSON.toJSONString(refundRequest);
            if (refreshOrderInfo) {
                orderCache.rewardinfo = "";
                OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, "");
            }
        } else if (payModel.kbAfterPay()) {
            //口碑后付
            job = new Job();
            job.type = JobType.REFUND_KOUBEI_AFTER_PAY;
            KBOrderRefundRequest refundRequest = new KBOrderRefundRequest();
            refundRequest.orderId = payModel.businessInfo;
            refundRequest.outBizNo = orderCache.orderID;
            refundRequest.requestId = UUIDUtil.optUUID();
            refundRequest.amount = totalVoidAmt;
            thirdOrderID = payModel.businessInfo;
            job.info = JSON.toJSONString(refundRequest);
            if (refreshOrderInfo) {
                orderCache.rewardinfo = "";
                OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, "");
            }
        } else if (PayType.isAliWeixin(payModel.data)) {
            job = new Job();
            job.type = JobType.REFUND_NET;
            thirdOrderID = payModel.businessInfo;
            job.info = payModel.businessInfo;
        } else if (PayType.isMWMemberBalance(payModel.data)) {
            job = new Job();
            job.type = JobType.REFUND_MEMBER_BALANCE_NEW;
            final NewMemberBalanceRefundRequest refundRequest = new NewMemberBalanceRefundRequest();
            //这里需要传所有的金额
            refundRequest.amount = totalVoidAmt;
            refundRequest.card_no = payModel.memberCardNO;
            refundRequest.trade_no = payModel.memberOrderID;
            refundRequest.companyGuid = ServerCache.getInstance().fsCompanyGUID;
            thirdOrderID = payModel.memberOrderID;
            refundRequest.reason = "";
            refundRequest.device_id = ServerHardwareUtil.getHardWareSymbol();
            job.info = JSON.toJSONString(refundRequest);
        } else if (PayType.isMWMemberPoint(payModel.data) || PayType.isMWMemberTicket(payModel.data)) {
            NewMemberOrderRefundRequest refundRequest = startDoMemberRefundNew(needVoidList, session, false, payModel, new IMemberRefundNew() {
                @Override
                public void callBack(boolean result, String msg, NewMemberOrderRefundRequest request, boolean containsMemberDiscountFinal) {
                    if (refreshOrderInfo && containsMemberDiscountFinal) {
                        OrderUtil.recalcCouponCutWithPay(session, orderCache, false);
                    }
                }
            });
            if (refundRequest != null) {
                job = new Job();
                job.type = JobType.REFUND_MEMBER_NEW;
                job.info = JSON.toJSONString(refundRequest);
                thirdOrderID = refundRequest.order_id;
            }
        } else if (PayType.isHung(payModel.data)) {
//            selectHung(orderToken, orderCache.orderID, user, hostID, true, payModel.creditAccountID, "", payModel.payAmount);
            job = new Job();
            job.type = JobType.REFUND_ONLINE_HUNG;
            thirdOrderID = payModel.businessInfo;
            job.info = payModel.businessInfo;
        }

        if (job != null) {
            job.finished = 3;
            job.biz_key = orderCache.orderID;
            JobScheudler.newJob(job);
            JobWorker worker = new JobWorker();
            worker.work(job);
            //打印小票
            if (needPrint) {
                return PrintBillUtil.printPayVoid(orderCache.orderID, thirdOrderID, "", needVoidList, hostID);
            } else {
                return null;
            }
        }
        return null;
    }

    /**
     * 仅美收银使用
     *
     * @param needVoidLIst
     * @param session
     * @param refundOrder
     * @param selectPay
     * @param resultListener
     * @return
     */
    @Deprecated
    public static MemberOrderRefundRequest startDoMemberRefund(final List<PayModel> needVoidLIst, final PaySession session, boolean refundOrder, final PayModel selectPay, final IMemberRefund resultListener) {
        if (!refundOrder && (!selectPay.checkMemberConsumed() || TextUtils.isEmpty(selectPay.memberOrderID))) {
            if (resultListener != null) {
                resultListener.callBack(true, "", null, PayType.isMWMemberCouponDiscount(selectPay.data));
            }
            return null;
        }

        return PayUtil.processMemberRefund(needVoidLIst, session, refundOrder, resultListener);
    }

    /**
     * 会员重构
     *
     * @param needVoidLIst
     * @param session
     * @param refundOrder
     * @param selectPay
     * @param resultListener
     * @return
     */
    public static NewMemberOrderRefundRequest startDoMemberRefundNew(final List<PayModel> needVoidLIst, final PaySession session, boolean refundOrder, final PayModel selectPay, final IMemberRefundNew resultListener) {
        if (!refundOrder && (!selectPay.checkMemberConsumed() || TextUtils.isEmpty(selectPay.memberOrderID))) {
            if (resultListener != null) {
                resultListener.callBack(true, "", null, PayType.isMWMemberCouponDiscount(selectPay.data));
            }
            return null;
        }

        return PayUtil.processMemberRefundNew(needVoidLIst, session, refundOrder, resultListener);
    }

    /**
     * 使用会员抵用券
     *
     * @param orderToken   String | 订单操作的Token
     * @param orderID      String | 订单ID
     * @param user         String | 操作的用户
     * @param hostID       String | 站点ID
     * @param selectTicket PayOriginModel
     * @return
     */
    public static SocketResponse<PayResultResponse> selectMemberTicket(final String orderToken, final String orderID, final UserDBModel user, final String hostID, final PayOriginModel selectTicket) {
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, selectTicket);
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        final PaySession session = OrderSession.getInstance().getPay(orderID);
        PayModel selectPay = new PayModel();
        selectPay.data = selectTicket;
        String error = MemberApi.useMemberCoupon(session, orderCache, orderCache.memberInfoS.card_no, selectPay);
//        SocketResponse<PayResultResponse> finalSocketResponse = socketResponse;
//        ServerMemberApi.memberConsume(orderCache, session, selectPay, new IResponse<NewMemberOrderConsumeRequest>() {
//            @Override
//            public void callBack(boolean result, int code, String msg, NewMemberOrderConsumeRequest info) {
//                if (result) {
//                    finalSocketResponse.code = SocketResultCode.SUCCESS;
//                } else {
//                    finalSocketResponse.code = code;
//                    finalSocketResponse.message = msg;
//                }
//            }
//        });
//        socketResponse = finalSocketResponse;
//        if (!socketResponse.success()) {
//            error = socketResponse.message;
//        }
        if (TextUtils.isEmpty(error)) {
            socketResponse = addPayDetail(orderToken, orderID, user, hostID, selectPay);
            if (PayType.isMWMemberCouponDiscount(selectPay.data)) {
                OrderUtil.recalcCouponCutWithPay(session, orderCache, false);
                OrderSession.getInstance().writePay(session.orderID, session);
                socketResponse.data.payData = buildPayViewData(orderID);
            }
        } else {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = error;
        }
        return socketResponse;
    }

//TODO 会员重构---已废弃

    /**
     * 查询会员的优惠券列表
     *
     * @param orderID String
     * @return SocketResponse<GetPayMemberTicketResponse>
     */
    @Deprecated
    public static SocketResponse<GetPayMemberTicketResponse> searchMemberTicketOld(final String orderID) {
        final SocketResponse<GetPayMemberTicketResponse> socketResponse = new SocketResponse<>();
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        final PaySession session = OrderSession.getInstance().getPay(orderID);
        final GetPayMemberTicketResponse ticketResponse = new GetPayMemberTicketResponse();
        socketResponse.data = ticketResponse;
        if (ticketResponse.ticketList == null) {
            ticketResponse.ticketList = new ArrayList<>();
        }
        //1、查询可用积分
        MemberApi.sendPreSearchConsume(session.selectPayListFull, orderCache.optTotalPrice(), PayUtil.getCannnotDiscAmtByOrderTotal(orderID), orderCache.memberInfoS.card_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
                    MemberConsumePreSearchResponse response = (MemberConsumePreSearchResponse) responseData.responseBean;
                    // 对该List进行筛选
//                    String sql = "select * from tbPayment where fsPaymentTypeId in " + PayTypeGroup.SQL_MEMBER_TICKET + " and fiStatus = '1'";
                    String sql = "SELECT payment.*, paymenttype.fsPaymentTypeName FROM tbpayment AS payment LEFT OUTER JOIN tbpaymenttype paymenttype ON payment.fsPaymentTypeId = paymenttype.fsPaymentTypeId WHERE payment.fsPaymentTypeId IN " + PayTypeGroup.SQL_MEMBER_TICKET + " AND payment.fiStatus = '1'";
                    List<PaymentDBModel> paymentDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymentDBModel.class);
                    ticketResponse.score_money = response.data.score_money;
                    ticketResponse.use_score = response.data.use_score;
                    ticketResponse.user_all_score = response.data.user_all_score;
                    if (!ListUtil.isEmpty(response.data.coupons_list) && !ListUtil.isEmpty(paymentDBModelList)) {
                        for (MemberCouponModel memberCouponModel : response.data.coupons_list) {
                            for (PaymentDBModel paymentDBModel : paymentDBModelList) {
                                if (TextUtils.equals(memberCouponModel.coupon_id, paymentDBModel.fsNote)) {
                                    ticketResponse.ticketList.add(OrderUtil.buildPayOriginModel(paymentDBModel, memberCouponModel));
                                    break;
                                }
                            }
                        }
                    } else {
                        String error = response.data.checkTicketCanUse();
                        if (!TextUtils.isEmpty(error)) {
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = error;
                        }
                    }
                } else {
                    socketResponse.code = SocketResultCode.DESERIALIZE_FAILED;
                    socketResponse.message = "获取会员数据异常";
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                socketResponse.message = responseData.resultMessage;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });
        return socketResponse;
    }

    /**
     * 使用会员积分支付。
     * 需要先预查询会员信息
     *
     * @param orderToken String
     * @param orderID    String
     * @param user       String
     * @param hostID     String
     * @param inputAmt   BigDecimal
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> selectMemberPoint(final String orderToken, final String orderID, final UserDBModel user, final String hostID, final BigDecimal inputAmt) {
        final PayOriginModel model = OrderUtil.buildPayModelByPaymentID(PayType.MW_MEMBER_POINT);
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, model);
        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        final PaySession session = OrderSession.getInstance().getPay(orderID);
        //1、查询可用积分
        ServerMemberApi.sendPreSearchConsume(session.selectPayListFull, orderCache.optTotalPrice(), PayUtil.getCannnotDiscAmtByOrderTotal(orderID), orderCache.memberInfoS.card_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberPrePayCheckResponse) {
                    MemberPrePayCheckResponse response = (MemberPrePayCheckResponse) responseData.responseBean;
                    // 实际可抵扣的积分
                    final PayModel currentSelectPay = new PayModel();
                    currentSelectPay.data = model;
                    currentSelectPay.payAmount = inputAmt;
                    int scoreCanUse;
                    BigDecimal canPayAmount;
                    if (response.data.score_money.compareTo(session.priceLeftToPay) > 0) {
                        canPayAmount = new BigDecimal(session.priceLeftToPay.intValue());
                        scoreCanUse = canPayAmount.multiply(response.data.cost_bonus_unit).intValue();
                    } else {
                        scoreCanUse = response.data.use_score;
                        canPayAmount = response.data.score_money;
                    }
                    String checkCanUseError = response.data.checkPointCanUse();
                    if (!TextUtils.isEmpty(checkCanUseError) || canPayAmount.compareTo(BigDecimal.ZERO) <= 0) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = checkCanUseError;
                        if (TextUtils.isEmpty(socketResponse.message)) {
                            socketResponse.msg(R.string.ser_pay_no_member_score);
                        }
                    } else {
                        currentSelectPay.payAmount = canPayAmount;
                        currentSelectPay.memberCostScore = scoreCanUse;
                        currentSelectPay.memberCardNO = orderCache.memberInfoS.card_no;

                        if (socketResponse.success()) {
                            ServerMemberApi.memberConsume(orderCache, session, currentSelectPay, new IResponse<NewMemberOrderConsumeRequest>() {
                                @Override
                                public void callBack(boolean result, int code, String msg, NewMemberOrderConsumeRequest info) {
                                    if (result) {
                                        socketResponse.code = SocketResultCode.SUCCESS;
                                    } else if (!TextUtils.isEmpty(msg)) {
                                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                        socketResponse.message = msg;
                                    }
                                }
                            });
                        }

                        if (socketResponse.success()) {
                            SocketResponse<PayResultResponse> addPayResponse = addPayDetail(orderToken, orderID, user, hostID, currentSelectPay);
                            socketResponse.data = addPayResponse.data;
                            socketResponse.code = addPayResponse.code;
                            socketResponse.message = addPayResponse.message;
                        }
                    }
                } else {
                    socketResponse.code = SocketResultCode.DESERIALIZE_FAILED;
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                socketResponse.message = responseData.resultMessage;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });
        return socketResponse;
    }

    /**
     * 使用会员储值
     *
     * @param orderToken   String | 订单操作的Token
     * @param orderID      String | 订单ID
     * @param user         String | 操作的用户
     * @param hostID       String | 站点ID
     * @param thirdOrderID String | 生成的会员储值抵扣的订单号
     * @param password     String | 储值消费的密码
     * @param amount       BigDecimal | 储值抵扣的金额
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> selectMemberBalance(final String orderToken, final String orderID, UserDBModel user, String hostID, String thirdOrderID, final String password, final BigDecimal amount, SocketResponse<PayResultResponse> socketResponse) {
        final PayModel currentSelectPay = new PayModel();
        currentSelectPay.data = OrderUtil.buildPayModelByPaymentID(PayType.MW_MEMBER_BALANCE);
        currentSelectPay.payAmount = amount;
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, currentSelectPay.data);
//        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        final PaySession session = OrderSession.getInstance().getPay(orderID);
        if (TextUtils.isEmpty(thirdOrderID)) {
            thirdOrderID = OrderUtil.buildNetOrderID(ServerCache.getInstance().shopID, session.billNO);
        }

        final String memberOrderID = thirdOrderID;
        final PayResultResponse resultResponse = new PayResultResponse();
        resultResponse.thirdPayOrderID = memberOrderID;

        RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付 会员payCode为空，自动刷新 cardNO=" + orderCache.memberInfoS.card_no, orderCache.orderID, orderCache.fsmtableid, orderCache, "paycode = ''");
        if (TextUtils.isEmpty(orderCache.memberInfoS.pay_code)) {
            ServerMemberApi.sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        selectMemberBalance(orderToken, orderID, user, hostID, memberOrderID, password, amount, socketResponse);
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = info;
                    }
                }
            });
        } else {
//        final CountDownLatch latch = new CountDownLatch(1);
            LogUtil.log("储值支付", "开始查询预消费");
            ServerMemberApi.sendPreSearchConsume(session.selectPayListFull, orderCache.optTotalPrice(), PayUtil.getCannnotDiscAmtByOrderTotal(orderID), orderCache.memberInfoS.card_no, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    LogUtil.log("储值支付", "开始查询预消费--成功");
                    if (responseData.responseBean != null && responseData.responseBean instanceof MemberPrePayCheckResponse) {
                        MemberPrePayCheckResponse response = (MemberPrePayCheckResponse) responseData.responseBean;
                        if (TextUtils.isEmpty(response.data.checkBalanceCanUse())) {

                            LogUtil.log("储值支付", "开始扣储值");
                            ServerMemberApi.sendConsumeBalance(orderCache, memberOrderID, password, amount, orderCache.memberInfoS.pay_code, new IMemberBalance() {
                                @Override
                                public void process(String errorMsg, MemberPayStoreResponse response, boolean needPwd) {

                                    LogUtil.log("储值支付", "开始扣储值--接口反回");
                                    RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付结果", orderCache.orderID, orderCache.fsmtableid, response);
                                    resultResponse.thirdPayStatus = NetPayResult.FAIL;
                                    if (TextUtils.isEmpty(errorMsg) && response != null) {

                                        LogUtil.log("储值支付", "开始扣储值--接口反回 errorMsg is empty ");
                                        resultResponse.thirdPayStatus = NetPayResult.SUCCESS;
                                        currentSelectPay.memberOrderID = response.data.trade_no;
                                        currentSelectPay.businessInfo = response.data.trade_no;
                                        currentSelectPay.memberCardNO = orderCache.memberInfoS.card_no;
                                        resultResponse.thirdPayOrderID = response.data.trade_no;

                                        if (response.data.amount_use_reward != null && response.data.amount_use_reward.compareTo(BigDecimal.ZERO) > 0) {
                                            currentSelectPay.payAmount = response.data.amount_use_reality;
                                            PayModel memberGift = new PayModel();
                                            memberGift.data = OrderUtil.buildPayModelByPaymentID(PayType.MW_MEMBER_BALANCE_GIFT);
                                            memberGift.payAmount = response.data.amount_use_reward;
                                            memberGift.memberOrderID = response.data.trade_no;
                                            memberGift.businessInfo = response.data.trade_no;
                                            memberGift.memberCardNO = orderCache.memberInfoS.card_no;
                                            currentSelectPay.addSecondPay(memberGift);
                                        }
                                    } else {

                                        LogUtil.log("储值支付", "开始扣储值--接口反回 errorMsg = " + errorMsg + "; needPwd = " + needPwd);
                                        if (needPwd) {
                                            resultResponse.needMemberPwd = true;
                                            RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付结果 需要密码 cardNO=" + orderCache.memberInfoS.card_no, orderCache.orderID, orderCache.fsmtableid, response, orderCache.memberInfoS.pay_code);
                                        } else {
                                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                        }
                                        socketResponse.message = errorMsg;
                                    }

                                    LogUtil.log("储值支付", "扣储值业务结束，将 resultResponse 赋值" + JSON.toJSONString(resultResponse));
                                    socketResponse.data = resultResponse;
//                                latch.countDown();
                                }
                            });
                        } else {

                            LogUtil.log("储值支付", "扣储值业务结束，异常1" + JSON.toJSONString(resultResponse));
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.msg(R.string.ser_pay_no_member_blance);
//                        latch.countDown();
                        }
                    } else {

                        LogUtil.log("储值支付", "扣储值业务结束，异常2" + JSON.toJSONString(resultResponse));
                        socketResponse.code = SocketResultCode.DESERIALIZE_FAILED;
//                    latch.countDown();
                    }
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    LogUtil.log("储值支付", "开始查询预消费---失败");
                    socketResponse.message = responseData.resultMessage;
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
//                latch.countDown();
                    return false;
                }
            });
//        while (latch.getCount() > 0) {
//            try {
//                latch.await();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }

            LogUtil.log("储值支付", "接口结束" + JSON.toJSONString(socketResponse));
            if (socketResponse.success() && socketResponse.data != null && !socketResponse.data.needMemberPwd) {
                SocketResponse<PayResultResponse> addPayResponse = addPayDetail(orderToken, orderID, user, hostID, currentSelectPay);
                if (addPayResponse.code == SocketResultCode.SUCCESS) {

                    LogUtil.log("储值支付", "接口结束------1");
                    socketResponse.code = SocketResultCode.SUCCESS;
                    if (socketResponse.success() && PayUtil.supportAutoPay(orderCache.fiSellType) && PayType.isOnlinePay(currentSelectPay)) {

                        LogUtil.log("储值支付", "接口结束------2");
                        SocketResponse<PayResultResponse> socketAutoResponse = checkAutoFinishAndStart(orderToken, orderID, true, null, user, hostID);
                        socketResponse.message = socketAutoResponse.message;
                        if (socketAutoResponse.code == SocketResultCode.SUCCESS) {

                            LogUtil.log("储值支付", "接口结束------3");
                            socketResponse.data = socketAutoResponse.data;
                            socketResponse.data.thirdPayOrderID = thirdOrderID;
                            socketResponse.data.thirdPayStatus = NetPayResult.SUCCESS;
                        } else {

                            LogUtil.log("储值支付", "接口结束------4");
                            socketResponse.data.payFinished = false;
                        }
                    }
                } else {
                    LogUtil.log("储值支付", "接口结束------5");
                    PaySession session2 = OrderSession.getInstance().getPay(orderID);
                    RunTimeLog.addLog(RunTimeLog.PAY_FAILE, "在线支付扣款成功，但是订单已经结账，将开始自动退款", orderID, "", currentSelectPay);
                    doVoidPay(false, false, orderCache, session2, orderToken, hostID, user, currentSelectPay, null);
                    socketResponse.code = addPayResponse.code;
                    socketResponse.message = addPayResponse.message;
                }
                LogUtil.log("储值支付", "接口结束------6");
                socketResponse.data.payData = buildPayViewData(orderID);
            }
            LogUtil.log("储值支付", "接口结束------7");
        }
        LogUtil.log("储值支付", "接口结束------8" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    public static SocketResponse<PayResultResponse> selectNetPay(final String orderToken, final String orderID, boolean onlySearch, String thirdOrderID, final BigDecimal amount, String barCode, final UserDBModel user, final String hostID) {
        return selectNetPay(orderToken, orderID, onlySearch, thirdOrderID, amount, barCode, user, hostID, false);
    }

    /**
     * 网络支付的相关方法
     *
     * @param orderToken   String | 订单操作的Token
     * @param orderID      String | 美易点订单号
     * @param user         UserDBModel | 发起的服务员
     * @param hostID       String | 发起的站点
     * @param onlySearch   boolean | 是否仅查询不支付
     * @param thirdOrderID String  | 第三方支付的订单号
     * @param amount       BigDecimal | 待支付金额，仅查询时，不传这个字段
     * @param barCode      String | 扫的码，仅查询时，不传这个字段
     * @param allowZero    allowZero | 待支付金额为 0 时，是否允许支付
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> selectNetPay(final String orderToken, final String orderID, boolean onlySearch, String thirdOrderID, final BigDecimal amount, String barCode, final UserDBModel user, final String hostID, boolean allowZero) {
//        long timePay = System.currentTimeMillis();
//        LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay----" + orderID + "----支付业务中心开始=" + timePay);

        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        if (!onlySearch) {
            String error = checkBarCode(orderID, amount, barCode);
            if (!TextUtils.isEmpty(error)) {
                socketResponse.message = error;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
        }
        //快餐单可以先不经过准备支付的阶段，所以需要校验PaySession是否已经生成
        if (OrderSession.getInstance().getPay(orderID) == null) {
            OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(orderID), user, hostID);
        }
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, allowZero, OrderUtil.buildPayModelByPaymentID(PayType.ALI));

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }
        final PayResultResponse response = new PayResultResponse();
        socketResponse.data = response;
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);

        final PaySession session = OrderSession.getInstance().getPay(orderID);

        BigDecimal discountAmount = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);

        List<GoodDetailModel> goods_detail = new ArrayList<>();
        for (MenuItem menuItem : orderCache.originMenuList) {
            if (menuItem.hasAllVoid() || menuItem.isGift()) {
                continue;
            }
            GoodDetailModel detailModel = new GoodDetailModel();
            detailModel.goods_id = menuItem.itemID;
            detailModel.goods_name = menuItem.name;
            detailModel.quantity = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
            detailModel.price = menuItem.price.multiply(new BigDecimal(100));//元转换成分
            goods_detail.add(detailModel);
        }

        final PayModel currentSelectPay = new PayModel();
        if (allowZero) {
            currentSelectPay.writePrePay();
        }

        NetPayProcessor processor = new NetPayProcessor(orderID, StringUtil.toInt(session.billNO, 0), amount, discountAmount, goods_detail, new NetPayCallback() {
            @Override
            public void call(int status, String msg, int netPayType, String thirdOrderID, NetPayModel netPayModel) {
                long callTime = System.currentTimeMillis();
                LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay----" + orderID + "----processor.call--支付业务中心开始------");
                Thread.currentThread().setPriority(10);
                response.thirdPayOrderID = thirdOrderID;
                response.thirdPayStatus = status;
                if (status == NetPayResult.SUCCESS) {
                    switch (netPayType) {
                        case 1:
                            currentSelectPay.data = OrderUtil.buildPayModelByPaymentID(PayType.WEIXIN);
                            break;
                        case 2:
                            currentSelectPay.data = OrderUtil.buildPayModelByPaymentID(PayType.ALI);
                            break;
                        default:
                            break;
                    }
                    currentSelectPay.businessInfo = thirdOrderID;

                    String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, user.fsUserName + " 站点：" + hostID + " 网络支付的相关方法 ");
                    try {

                        // 如果该支付订单号的支付明细已存在支付明细列表，不再执行插入明细等操作
                        if (!checkOnlinePayExist(thirdOrderID, orderID)) {
                            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                                currentSelectPay.payAmount = new BigDecimal(netPayModel.pay_price).divide(BizConstant.HUNDREND, 2, BigDecimal.ROUND_HALF_UP);

                            } else {
                                currentSelectPay.payAmount = amount;
                            }
                            PayProcessor.buildNetPayExtra(currentSelectPay, netPayModel);

                            SocketResponse<PayResultResponse> addPayResponse = addPayDetail(orderToken, orderID, user, hostID, allowZero, currentSelectPay);
                            long addPayTime = System.currentTimeMillis() - callTime;
                            LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay----" + orderID + "----processor.call---addPayDetail--- 支付业务中心结束------:" + addPayTime);
                            if (addPayResponse.success()) {
                                socketResponse.code = SocketResultCode.SUCCESS;
                                response.seqList = addPayResponse.data.seqList;
                                // 预付金不要自动清台
                                if (!allowZero) {
//                                if (socketResponse.success() && PayUtil.supportAutoPay() && PayType.isOnlinePay(currentSelectPay)) {
                                    if (socketResponse.success() && PayUtil.supportAutoPay(orderCache.fiSellType) && PayType.isOnlinePay(currentSelectPay)) {
                                        SocketResponse<PayResultResponse> socketAutoResponse = checkAutoFinishAndStart(orderToken, orderID, true, null, user, hostID);
                                        socketResponse.message = socketAutoResponse.message;
                                        if (socketAutoResponse.code == SocketResultCode.SUCCESS) {
                                            socketResponse.data = socketAutoResponse.data;
                                            socketResponse.data.thirdPayOrderID = thirdOrderID;
                                            socketResponse.data.thirdPayStatus = status;
                                        } else {
                                            socketResponse.data.payFinished = false;
                                        }
                                    }
                                }
                            } else {
                                RunTimeLog.addLog(RunTimeLog.PAY_FAILE, "在线支付扣款成功，但是订单已经结账，将收入异常订单中 --> " + addPayResponse.message, orderID, "",
                                        netPayModel);
//                                doVoidPay(false, false, orderCache, session, orderToken, hostID, user, currentSelectPay, null);
                                MessageAbnormalOrderBizProcessor.addScanPayAbnormalMsg(currentSelectPay, amount, user.fsUserName, orderCache.fsmtableid, orderCache.fsmareaid, orderID, currentSelectPay.businessInfo, orderCache.fiSellType, addPayResponse.message);

                                socketResponse.code = addPayResponse.code;
                                socketResponse.message = addPayResponse.message;
                            }
                        }
                        socketResponse.data.payData = buildPayViewData(orderID);

                    } finally {
                        ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, user.fsUserName + " 站点：" + hostID + " 网络支付的相关方法 ");
                    }

                } else {
                    if (status == NetPayResult.PROCESSING) {
                        socketResponse.code = SocketResultCode.SUCCESS;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    }
                    socketResponse.message = msg;
                    socketResponse.data.payData = buildPayViewData(orderID);
                }

                callTime = System.currentTimeMillis() - callTime;
                LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay----" + orderID + "----processor.call-- 支付业务中心结束------:" + callTime);
//                synchronized (lock) {
//                    lock.notify();
//                }
            }
        });
        if (onlySearch) {
            LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay ----" + orderID + "----processor.startSearch-- 支付业务中心开始");
            processor.startSearch(thirdOrderID);
        } else {
            LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay ----" + orderID + "----processor.startPay-- 支付业务中心开始");
            processor.startPay(barCode, thirdOrderID);
        }
//        synchronized (lock) {
//            try {
//                lock.wait();
//            } catch (InterruptedException e) {
//                LogUtil.logError(e);
//            }
//        }

//        timePay = System.currentTimeMillis() - timePay;
//        LogUtil.logBusiness("===SCAN=PAY===", "BillUtil#selectNetPay----" + orderID + "----支付业务中心结束=" + timePay);

        return socketResponse;
    }

    /**
     * 校验线上支付是否已存在于支付列表
     *
     * @param thirdOrderID
     * @param orderID
     * @return
     */
    @NonNull
    private static boolean checkOnlinePayExist(String thirdOrderID, String orderID) {
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (!ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel model : session.selectPayListFull) {
                if (TextUtils.equals(model.businessInfo, thirdOrderID)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static SocketResponse<PayResultResponse> selectPayType(String orderToken, String orderid, PayOriginModel data, BigDecimal amount, final UserDBModel user, final String hostID) {
        return selectPayType(orderToken, orderid, data, amount, user, hostID, false, false);
    }

    /**
     * 进行普通支付
     *
     * @param orderToken String
     * @param orderid    String
     * @param data       PayOriginModel
     * @param amount     BigDecimal
     * @param user       UserDBModel
     * @param hostID     String
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> selectPayType(String orderToken, String orderid, PayOriginModel data, BigDecimal amount, final UserDBModel user, final String hostID, boolean isPrePay, boolean allowZero) {
        return selectPayType(orderToken, orderid, data, amount, user, hostID, isPrePay, allowZero, null);
    }

    /**
     * @param orderToken    订单Token
     * @param orderid       订单号
     * @param data          支付Data
     * @param amount        支付金额
     * @param user          操作员
     * @param hostID        操作站点
     * @param isPrePay
     * @param allowZero
     * @param certigierUser 授权用户信息,null表示没有授权人
     * @return
     */
    public static SocketResponse<PayResultResponse> selectPayType(String orderToken, String orderid, PayOriginModel data, BigDecimal amount, final UserDBModel user, final String hostID, boolean isPrePay, boolean allowZero, UserDBModel certigierUser) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        PayModel currentSelectPay = new PayModel();
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderid);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, user.fsUserName + " 站点：" + hostID + " 进行普通支付 ");
        try {

            if (isPrePay) {
                currentSelectPay.writePrePay();
            }
            currentSelectPay.data = data;
            PaySession paySession = OrderSession.getInstance().getPay(orderid);

            currentSelectPay.payAmount = amount;
            //授权人信息
            if (certigierUser != null) {
                currentSelectPay.certigierUserId = certigierUser.fsUserId;
                currentSelectPay.certigierUserName = certigierUser.fsUserName;
            }

            // 预付金不做任何找零、金额的处理
            if (!isPrePay) {
                if (PayUtil.canHasChange(data)) {
                    //这里计算现金找零
                    BigDecimal remainTotalAfterRound = paySession.priceLeftToPay;
                    BigDecimal changeNum = amount.subtract(remainTotalAfterRound);
                    if (changeNum.compareTo(BigDecimal.ZERO) > 0) {
                        currentSelectPay.changeAmount = changeNum;
                    } else {
                        currentSelectPay.changeAmount = BigDecimal.ZERO;
                    }
                } else if (PayType.isCoupon(data)) {
                    BigDecimal discountLeftToPayAmt = PayUtil.getDiscountAmtByLeftToPay(paySession, orderCache);
                    BigDecimal leftToPay = PayUtil.getLeftToPayIgnoreService(paySession, orderCache);
                    String checkError = PayUtil.useShopCouponModel(currentSelectPay, leftToPay, discountLeftToPayAmt);
                    if (!TextUtils.isEmpty(checkError)) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = checkError;
                        return socketResponse;
                    } else {
                        socketResponse.code = SocketResultCode.SUCCESS;
                    }
                } else {
                    if (amount.compareTo(paySession.priceLeftToPay) > 0) {
                        currentSelectPay.payAmount = paySession.priceLeftToPay;
                    }
                }
            }
            socketResponse = addPayDetail(orderToken, orderid, user, hostID, allowZero, currentSelectPay);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, user.fsUserName + " 站点：" + hostID + " 进行普通支付 ");
        }
        return socketResponse;
    }

    public static SocketResponse<PayResultResponse> addPayDetail(String orderToken, String orderID, UserDBModel user, String hostID, PayModel... payDetailOriginList) {
        List<PayModel> payModelList = Arrays.asList(payDetailOriginList);
        return addPayDetail(orderToken, orderID, user, hostID, payModelList);
    }

    public static SocketResponse<PayResultResponse> addPayDetail(String orderToken, String orderID, UserDBModel user, String hostID, boolean allowZero, PayModel... payDetailOriginList) {
        List<PayModel> payModelList = Arrays.asList(payDetailOriginList);
        return addPayDetail(orderToken, orderID, user, hostID, payModelList, allowZero);
    }

    public static SocketResponse<PayResultResponse> addPayDetail(String orderToken, String orderID, UserDBModel user, String hostID, List<PayModel> payDetailOriginList) {
        return addPayDetail(orderToken, orderID, user, hostID, payDetailOriginList, false);
    }

    /**
     * 将支付明细写入到PaySession
     *
     * @param orderToken          String | Token
     * @param orderID             String | 订单号
     * @param user                UserDBModel | 发起操作的User
     * @param hostID              String | 站点ID
     * @param payDetailOriginList PayModel... | 需要写入的支付明细
     * @param allowZero           boolean | 是否允许待支付金额为0时收款
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> addPayDetail(String orderToken, String orderID, UserDBModel user, String hostID, List<PayModel> payDetailOriginList, boolean allowZero) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        PayResultResponse response = new PayResultResponse();
        socketResponse.data = response;
        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        if (!(payDetailOriginList != null && payDetailOriginList.size() > 0)) {
            socketResponse.msg(R.string.ser_pay_no_payinfo);
            return socketResponse;
        }
        if (user == null || TextUtils.isEmpty(user.fsUserId)) {
            socketResponse.msg(R.string.ser_pay_no_user);
            return socketResponse;
        }
        if (TextUtils.isEmpty(hostID)) {
            socketResponse.msg(R.string.ser_pay_no_host);
            return socketResponse;
        }
        List<PayModel> payDetailResult = new ArrayList<>();
        String fsmtableId = OrderSession.getTableID(orderID);
        PaySession session = null;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "将支付明细写入到PaySession");
        try {
            List<PayOriginModel> selectList = new ArrayList<>();
            if (payDetailOriginList.size() > 0) {
                for (PayModel selectPay : payDetailOriginList) {
                    selectList.add(selectPay.data);
                }
            }
            //快餐单可以先不经过准备支付的阶段，所以需要校验PaySession是否已经生成
            if (OrderSession.getInstance().getPay(orderID) == null) {
                OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(orderID), user, hostID);
            }
            SocketBaseResponse checkResponse = BillUtil.checkCanPay(orderToken, user.fsUserId, orderID, allowZero, selectList.toArray(new PayOriginModel[selectList.size()]));

            if (!checkResponse.success()) {
                RunTimeLog.addLog(RunTimeLog.ORDER_CONFLICT_PAY, checkResponse.message, orderID, "", null);
                socketResponse.code = checkResponse.code;
                socketResponse.message = checkResponse.message;
                return socketResponse;
            }
            session = OrderSession.getInstance().getPay(orderID);
            String error = checkOrderStatus(session.orderID);
            if (!TextUtils.isEmpty(error)) {
                RunTimeLog.addLog(RunTimeLog.ORDER_CONFLICT, error, orderID, "", null);

                socketResponse.message = error;
                return socketResponse;
            }
            for (PayModel temp : payDetailOriginList) {
                temp.waiterID = user.fsUserId;
                temp.waiterName = user.fsUserName;
                temp.hostID = hostID;
                temp.seq = ++session.lastSeq;
                payDetailResult.add(temp);
                if (ListUtil.isEmpty(response.seqList)) {
                    response.seqList = new ArrayList<>();
                }
                response.seqList.add(temp.seq);
                if (!ListUtil.isEmpty(temp.subPayList)) {
                    for (PayModel tempSub : temp.subPayList) {
                        tempSub.waiterID = user.fsUserId;
                        tempSub.waiterName = user.fsUserName;
                        tempSub.hostID = hostID;
                        tempSub.seq = ++session.lastSeq;
                        tempSub.seq_M = temp.seq;
                        payDetailResult.add(tempSub);
                    }
                    temp.subPayList.clear();
                }
                if (!ListUtil.isEmpty(temp.secondPayList)) {
                    for (PayModel tempSub : temp.secondPayList) {
                        tempSub.waiterID = user.fsUserId;
                        tempSub.waiterName = user.fsUserName;
                        tempSub.hostID = hostID;
                        tempSub.seq = ++session.lastSeq;
                        tempSub.seq_M = temp.seq;
                        payDetailResult.add(tempSub);
                        if (ListUtil.isEmpty(response.seqList)) {
                            response.seqList = new ArrayList<>();
                        }
                        response.seqList.add(tempSub.seq);
                    }
                    temp.secondPayList.clear();
                }

            }
            session.selectPayListFull.addAll(payDetailResult);
            response.payData = buildPayViewData(orderID);
            LogUtil.log("BillUtil", "支付明细添加成功");
            OrderSession.getInstance().writePay(session.orderID, session);
            socketResponse.code = SocketResultCode.SUCCESS;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "将支付明细写入到PaySession");
        }
        OrderProcessor.savePayOnly(session);
        // 添加支付明细，需同步状态到排队客户端
        NotifyToClient.refreshTableBizQueue(fsmtableId);
        OrderProcessor.notifyOrderChanged(orderID);
        return socketResponse;
    }

    public static SocketResponse<PayResultResponse> checkAutoFinishAndStart(String orderToken, String orderID, boolean forceOnlne, PayModel selectPay, UserDBModel user, String hostID) {
        return checkAutoFinishAndStart(orderToken, orderID, forceOnlne, selectPay, user, hostID, true);
    }

    /**
     * 判断是否需要自动结账
     */
    public static SocketResponse<PayResultResponse> checkAutoFinishAndStart(String orderToken, String orderID, boolean forceOnlne, PayModel selectPay, UserDBModel user, String hostID, boolean printBill) {
        String fsmtableId = OrderSaveDBUtil.getTableIDByOrderID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "判断是否需要自动结账");
        try {
            PaySession paySession = OrderSession.getInstance().getPay(orderID);
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            OrderUtil.recalcPaySessionLeftToPay(paySession, orderCache);

            //已完成支付，或者已经溢收
            if (paySession.priceLeftToPay.compareTo(BigDecimal.ZERO) <= 0) {
                //在线支付处理是否自动结账
                if ((PayType.isOnlinePay(selectPay) && PayUtil.supportAutoPay(orderCache.fiSellType)) || forceOnlne) {
                    //已支付完成
                    if (paySession.priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {

                        long time = System.currentTimeMillis();
                        LogUtil.logBusiness("===SCAN=PAY===",
                                "BillUtil#selectNetPay ----" + orderID + "--processor.call---startFinalPayProcess--完成- 支付业务中心开始------:");

                        SocketResponse<PayResultResponse> socketResponse = startFinalPayProcess(orderToken, orderID, user, hostID, false, printBill);

                        time = System.currentTimeMillis() - time;
                        LogUtil.logBusiness("===SCAN=PAY===",
                                "BillUtil#selectNetPay ----" + orderID + "--processor.call---startFinalPayProcess--完成- 支付业务中心结束------:" + time);
                        return socketResponse;
                    } else {
                        //已溢收
                        if (PayUtil.supportOverPay()) {
                            return startFinalPayProcess(orderToken, orderID, user, hostID, true, printBill);
                        }
                    }
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "判断是否需要自动结账");
        }
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        socketResponse.data = new PayResultResponse();
        socketResponse.data.payFinished = false;
        return socketResponse;
    }

    public static SocketResponse<PayResultResponse> startFinalPayProcess(String orderToken, String orderID, UserDBModel user, String hostID, boolean autoChange, boolean printBill) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(orderToken, user.fsUserId, orderID);

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        } else {

            String errMsg = TableBusinessUtil.canCloseTable(orderID);
            if (!TextUtils.isEmpty(errMsg)) {
                socketResponse.code = -2;
                socketResponse.message = errMsg;
                return socketResponse;
            }

            long time = System.currentTimeMillis();
            LogUtil.logOnlineDebug("===SCAN=PAY===",
                    "BillUtil#startFinalPayProcess----" + orderID + "----processor.call---preProcessMember--- 支付业务中心开始------:");
            socketResponse = preProcessMember(orderID);
            time = System.currentTimeMillis() - time;
            LogUtil.logBusiness("===SCAN=PAY===",
                    "BillUtil#startFinalPayProcess----" + orderID + "----processor.call---preProcessMember--- 支付业务中心结束------:" + time);
            OrderSession.getInstance().writeOrder(orderID, false, "startFinalPayProcess");
            OrderSession.getInstance().writePay(orderID);
        }
        if (!socketResponse.success()) {
            if (socketResponse.data == null) {
                socketResponse.data = new PayResultResponse();
            }
            socketResponse.data.payData = buildPayViewData(orderID);
            RunTimeLog.addLog(RunTimeLog.PAY_FAILE, "支付失败", "", socketResponse);
            return socketResponse;
        }
        long time = System.currentTimeMillis();
        LogUtil.logOnlineDebug("===SCAN=PAY===",
                "BillUtil#startFinalPayProcess----" + orderID + "----processor.call---doFinalPay--- 支付业务中心开始------:");

        socketResponse = doFinalPay(orderToken, orderID, user, hostID, autoChange, printBill);

        time = System.currentTimeMillis() - time;
        LogUtil.logBusiness("===SCAN=PAY===",
                "BillUtil#startFinalPayProcess----" + orderID + "----processor.call---doFinalPay--- 支付业务中心结束------:" + time);
        if (!socketResponse.success()) {
            RunTimeLog.addLog(RunTimeLog.PAY_FAILE, "支付失败", "", socketResponse);
        } else {
            OrderProcessor.notifyOrderChanged(orderID);
            RunTimeLog.addLog(RunTimeLog.PAY_SUCCESS, "支付成功", "", socketResponse);
        }
        return socketResponse;
    }

    /**
     * 处理会员相关的抵扣
     * 注意：这里的会员回掉是回到了新的线程，需要考虑锁的问题
     *
     * @param orderID String
     * @return SocketResponse<CashierPayResultResponse>
     */
    public static SocketResponse<PayResultResponse> preProcessMember(final String orderID) {
        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        final PaySession session = OrderSession.getInstance().getPay(orderID);

        // 处理券抵扣，单独处理，与积分抵扣和会员赠送分开
        ServerMemberApi.memberConsumeTickets(orderCache, session, new IResponse<NewMemberOrderConsumeRequest>() {
            @Override
            public void callBack(boolean result, int code, String msg, NewMemberOrderConsumeRequest info) {
                if (result) {
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else if (!TextUtils.isEmpty(msg)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = msg;
                }
            }
        });

        if (!socketResponse.success()) {
            return socketResponse;
        }

//        final CountDownLatch latch = new CountDownLatch(1);
        // 处理券/积分赠送
        ServerMemberApi.memberGift(session, orderCache, new MemberProcessResult() {
            @Override
            public void callBack(boolean memberResult, String errorInfo, boolean onlyGift, NewMemberOrderConsumeRequest requestBuild) {
                if (memberResult) {
                    if (onlyGift) {
                        PayUtil.startJobMemberGiftNew(requestBuild, orderID);
                    }
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else if (!TextUtils.isEmpty(errorInfo)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = errorInfo;
                }
//                latch.countDown();

            }
        });
//        if (latch.getCount() >= 1) {
//            try {
//                latch.await();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }

        return socketResponse;
    }

    /**
     * 开始结账流程：
     * 1，会员抵扣
     * 2，会员赠送
     * 3，美易点的支付成功操作
     */
    private static SocketResponse<PayResultResponse> doFinalPay(String orderToken, String orderID, UserDBModel user, String hostID, boolean autoChange, boolean printBill) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        PayResultResponse response = new PayResultResponse();
        socketResponse.data = response;
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderID, user.fsUserName + "开始结账流程" + hostID);
        try {
            //正在反结账?
            boolean inAntiPay = orderCache.inAntiPaied();

            //锁同步之后，再获取一次订单
            orderCache = OrderSession.getInstance().getOrder(orderID);
            PaySession session = OrderSession.getInstance().getPay(orderID);
            OrderUtil.recalcPaySessionLeftToPay(session, orderCache);
            if (session.priceLeftToPay.compareTo(BigDecimal.ZERO) > 0) {
                response.payFinished = false;
                //更新tbSell表里的已支付的金额字段
                BillUtil.updateOrderPayInfo(orderID);
            } else if (session.priceLeftToPay.compareTo(BigDecimal.ZERO) < 0) {
                if (autoChange) {

                    //实收总额
                    BigDecimal allCalcPaidAmt = BigDecimal.ZERO;
                    //非实收总额
                    BigDecimal allUnCalcPaidAmt = BigDecimal.ZERO;
                    for (PayModel payModel : session.selectPayListFull) {
                        if (payModel == null || payModel.payAmount == null || payModel.status == PayTypeStatus.DELETE) {
                            continue;
                        }
                        //--是否计入收入(实收)
                        if (payModel.data.isCalcPaid) {
                            allCalcPaidAmt = allCalcPaidAmt.add(payModel.payAmount);
                        } else {
                            allUnCalcPaidAmt = allUnCalcPaidAmt.add(payModel.payAmount);
                        }
                    }

                    BigDecimal chargeAmt = session.priceLeftToPay;
                    BigDecimal excessiveChargeAmt = BigDecimal.ZERO;

                    if (session.priceLeftToPay.abs().compareTo(allCalcPaidAmt) > 0) {
                        chargeAmt = allCalcPaidAmt.multiply(new BigDecimal(-1));
                        excessiveChargeAmt = session.priceLeftToPay.abs().subtract(allCalcPaidAmt);
                        excessiveChargeAmt = excessiveChargeAmt.multiply(new BigDecimal(-1));
                    }

                    int seq_M = -1;
                    //兼容未更新数据的门店
                    PayOriginModel excessiveChange = OrderUtil.forceBuildPayModelByPaymentID(PayType.EXCESSIVE_CHARGE);
                    if (excessiveChange != null && allCalcPaidAmt.compareTo(BigDecimal.ZERO) > 0) {
                        excessiveChange.isCalcPaid = true;
                        PayModel excessivePayModel = new PayModel();
                        excessivePayModel.data = excessiveChange;
                        excessivePayModel.waiterID = user.fsUserId;
                        excessivePayModel.waiterName = user.fsUserName;
                        excessivePayModel.hostID = hostID;
                        excessivePayModel.seq = ++session.lastSeq;
                        seq_M = excessivePayModel.seq;
                        excessivePayModel.payAmount = chargeAmt;
                        session.selectPayListFull.add(excessivePayModel);
                    } else {
                        excessiveChargeAmt = session.priceLeftToPay;
                    }

                    if (excessiveChargeAmt.compareTo(BigDecimal.ZERO) != 0) {
                        PayOriginModel change = OrderUtil.buildPayModelByPaymentID(PayType.CHANGE);
                        if (!change.payTypeGroupID.equals(PayTypeGroup.OTHER)) {
                            //调账找零强制处理为其他支付类型
                            change.payTypeGroupID = PayTypeGroup.OTHER;
                            change.payTypeGroupName = "其他支付";
                        }
                        change.isCalcPaid = false;
                        PayModel payModel = new PayModel();
                        payModel.data = change;
                        payModel.waiterID = user.fsUserId;
                        payModel.waiterName = user.fsUserName;
                        payModel.hostID = hostID;
                        payModel.seq = ++session.lastSeq;
                        payModel.seq_M = seq_M;
                        payModel.payAmount = excessiveChargeAmt;
                        session.selectPayListFull.add(payModel);
                    }

                    return doFinalPay(orderToken, orderID, user, hostID, true, printBill);
                } else {
                    response.payFinished = false;
                }
                //更新tbSell表里的已支付的金额字段
                BillUtil.updateOrderPayInfo(orderID);
            } else {
                session.waiterID = user.fsUserId;
                session.waiterName = user.fsUserName;
                session.currentShiftID = HostUtil.getShiftIDByHost(hostID, user.fsUserId);
                session.payed = 1;
                session.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                session.currentHostID = hostID;

                checkPerson(orderCache);

                if (orderCache.dinnerModel()) {
                    OrderSession.getInstance().writeOrder(orderCache.orderID, false, "doFinalPay");
                    boolean antiPay = orderCache.orderStatus == OrderStatus.ANTI_PAIED;
                    // TODO: 2018/9/24 上传订单
                    if (!PayProcessor.paySuccess(session, orderCache.fsmtableid)) {
                        socketResponse.code = SocketResultCode.ORDER_CHANGED;
                        OrderProcessor.saveOrder(orderCache, null);
                        return socketResponse;
                    }
                    response.payFinished = true;
                    SocketResponse closeTableResponse = new SocketResponse();
                    TableBusinessUtil.closeTable(closeTableResponse, orderCache.fsmtableid, orderID);
                    //清除秒点先付款缓存的订单
                    RapidPrePayBiz.clearOrderByTableID(orderCache.fsmtableid);

//                    List<Integer> printTaskIds;
                    OrderCache finalOrderCache = orderCache;
                    BusinessExecutor.executeNoWait(new ASyncExecute() {
                        @Override
                        public Object execute() {
                            if (printBill) {
                                //重新查询会员信息
                                MemberInfo memberInfo = null;
                                if (finalOrderCache.memberInfoS != null && ServerSettingHelper.isBillPrintBalanceAndScore()) {
                                    memberInfo = MemberApi.queryMemberInfo(finalOrderCache.memberInfoS.card_no);
                                }
                                PrintBillUtil.printDinnerBill(orderID, memberInfo, null, hostID, antiPay, user, APPConfig.DB_MAIN);
                                PrintBillUtil.printRemainBill(orderID, null, hostID, antiPay, user.fsUserName, APPConfig.DB_MAIN);
                            }
                            processMoneyBoxAfterPay(session, finalOrderCache.fsmtablename, hostID, user);
                            return null;
                        }
                    });
//<<<<<<< HEAD
//                        printTaskIds = PrintBillUtil.printRemainBill(orderID,null, hostID, antiPay, user.fsUserName, APPConfig.DB_MAIN);
//                        if (!ListUtil.isEmpty(printTaskIds)) {
//                            response.printTaskIds.addAll(printTaskIds);
//                        }
//                    }
//                    printTaskIds = processMoneyBoxAfterPay(session, orderCache.fsmtablename, hostID, user);
//                    if (!ListUtil.isEmpty(printTaskIds)) {
//                        response.printTaskIds.addAll(printTaskIds);
//                    }
//=======
//                    });
//>>>>>>> origin/pro2.9.1.361
                } else {
//                    long time = System.currentTimeMillis();
//                    LogUtil.logBusiness("===SCAN=PAY===",
//                            "BillUtil#doFinalPay----"+orderID+"----processor.call---PayProcessor.paySuccessForFast--- 支付业务中心开始------:");

                    String seqsNo = PayProcessor.paySuccessForFast(user, hostID, session, orderCache);

//                    time = System.currentTimeMillis() - time;
//                    LogUtil.logBusiness("===SCAN=PAY===",
//                            "BillUtil#doFinalPay----"+orderID+"----processor.call---PayProcessor.paySuccessForFast--- 支付业务中心结束------:" + time);

                    if (!PayProcessor.checkOrderValid(orderID)) {
                        OrderProcessor.saveOrder(orderCache, null);
                        socketResponse.code = SocketResultCode.ORDER_CHANGED;
                        return socketResponse;
                    }
                    response.payFinished = true;

                    /**
                     * 纯收银模式不打印任何单子
                     */
//                    LogUtil.logBusiness("===SCAN=PAY===",
//                            "BillUtil#doFinalPay----"+orderID+"----processor.call---PrintFastFoodOrderUtil--- 支付业务中心开始------:");
//                    long printTime = System.currentTimeMillis();
                    if (orderCache.fiSellType != 3 && KB_ORDER != orderCache.thirdOrderType) {
                        OrderCache finalOrderCache1 = orderCache;
                        BusinessExecutor.executeNoWait(new ASyncExecute() {
                            @Override
                            public Object execute() {
                                //打印未下单的菜制作单
                                if (DBOrderConfig.useKdsService() && DBOrderConfig.fastUseKdsService()) {//快餐KDS
                                    KdsManager.getInstance().order(finalOrderCache1, seqsNo, finalOrderCache1.currentHostID, user);
                                } else {
                                    //打印未下单的菜传菜单
                                    PrintFastFoodOrderUtil.printPassTo(finalOrderCache1, user, seqsNo, finalOrderCache1.currentHostID, false, null, null);
                                    PrintFastFoodOrderUtil.printMake(finalOrderCache1, user, seqsNo, finalOrderCache1.currentHostID);
                                }

                                //打印未下单的菜点菜单
                                PrintFastFoodOrderUtil.printMenuList(finalOrderCache1, user, finalOrderCache1.currentSeq - 1, "", finalOrderCache1.currentHostID);
//                                LogUtil.logBusiness("===SCAN=PAY===",
//                                        "BillUtil#doFinalPay----"+orderID+
//                                                "----processor.call---PrintFastFoodOrderUtil-----打印点菜单完成---- 支付业务中心开始------:");
                                if (printBill) {
                                    //重新查询会员信息
                                    MemberInfo memberInfo = null;
                                    if (finalOrderCache1.memberInfoS != null && ServerSettingHelper.isBillPrintBalanceAndScore()) {
                                        memberInfo = MemberApi.queryMemberInfo(finalOrderCache1.memberInfoS.card_no);
                                    }
//                                    LogUtil.logBusiness("===SCAN=PAY===",
//                                            "BillUtil#doFinalPay----"+orderID+
//                                                    "----processor.call---PrintFastFoodOrderUtil-----重新查询会员信息完成---- 支付业务中心开始------:");

//<<<<<<< HEAD
//                        //打印未下单的菜传菜单
//                        List<Integer> printTaskIds = PrintFastFoodOrderUtil.printPassTo(orderCache, user, seqsNo, orderCache.currentHostID);
//                        if (!ListUtil.isEmpty(printTaskIds)) {
//                            response.printTaskIds.addAll(printTaskIds);
//                        }
//                        //打印未下单的菜制作单
//                        printTaskIds = PrintFastFoodOrderUtil.printMake(orderCache, user, seqsNo, orderCache.currentHostID);
//                        if (!ListUtil.isEmpty(printTaskIds)) {
//                            response.printTaskIds.addAll(printTaskIds);
//                        }
//                        //打印未下单的菜点菜单
//                        printTaskIds = PrintFastFoodOrderUtil.printMenuList(orderCache, user, orderCache.currentSeq - 1, "", orderCache.currentHostID);
//                        if (!ListUtil.isEmpty(printTaskIds)) {
//                            response.printTaskIds.addAll(printTaskIds);
//                        }
//
//                        if (printBill) {
//                            //重新查询会员信息
//                            MemberInfo memberInfo = null;
//                            if (orderCache.memberInfoS != null && ServerSettingHelper.isBillPrintBalanceAndScore()) {
//                                memberInfo = MemberApi.queryMemberInfo(orderCache.memberInfoS.card_no);
//                            }
//
//                            //打印结帐单
//                            printTaskIds = PrintBillUtil.printFastFoodBill(orderCache.orderID, memberInfo, hostID, user.fsUserName, APPConfig.DB_MAIN);
//                            if (!ListUtil.isEmpty(printTaskIds)) {
//                                response.printTaskIds.addAll(printTaskIds);
//=======
                                    //打印结帐单
                                    PrintBillUtil.printFastFoodBill(finalOrderCache1.orderID, memberInfo, hostID, user.fsUserName, APPConfig.DB_MAIN);
                                }
//                                LogUtil.logBusiness("===SCAN=PAY===",
//                                        "BillUtil#doFinalPay----"+orderID+
//                                                "----processor.call---PrintFastFoodOrderUtil-----打印结帐单完成---- 支付业务中心开始------:");
                                processMoneyBoxAfterPay(session, finalOrderCache1.fsmtablename, hostID, user);
                                return null;
//>>>>>>> origin/pro2.9.1.361
                            }
                        });

                    }
//                    printTime = System.currentTimeMillis() - printTime;
//                    LogUtil.logBusiness("===SCAN=PAY===",
//                            "BillUtil#doFinalPay----"+orderID+"----processor.call---PrintFastFoodOrderUtil--- 支付业务中心结束------:" + printTime);
                }
            }
            response.payData = buildPayViewData(orderID);
            OrderSession.getInstance().clearOrder(orderID);

            // 食宝街 订单上传
            MallProtocolBizUtil.doForShibaojie(orderID, orderCache.shopID, inAntiPay?2:1, session.payTime, HostUtil.getDeviceIdByHostId(session.currentHostID), 0);

            // 通知KDS服务结账
            if (DBOrderConfig.useKdsService() && orderCache.fiSellType == 0) {
                LogUtil.logBusiness("---KDS----" + "----orderID----" + orderID + "----" + orderCache.fiSellType);
                KdsManager.getInstance().payFinish(orderID);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderID, user.fsUserName + "开始结账流程 " + hostID);
        }
        NotifyToClient.orderChange(orderID);
        return socketResponse;
    }

    /**
     * 如果订单中的菜品全退了，人数要清零
     *
     * @param orderCache
     */
    private static void checkPerson(OrderCache orderCache) {
        if (DinnerStandardUtil.isOrderAllVoid(orderCache)) {
            orderCache.personNum = 0;
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "checkPerson");
        }
    }


    /**
     * 支付结束要打开钱箱
     *
     * @param paySession PaySession
     * @param tableName  String
     * @param hostID     String
     * @param user       UserDBModel
     * @return List<Integer>
     */
    private static List<Integer> processMoneyBoxAfterPay(final PaySession paySession,
                                                         final String tableName, String hostID, UserDBModel user) {
        if (PayConfig.PAY_OPEN_BOX && !APPConfig.isCasiher()) {
            if (paySession != null) {
                for (PayModel temp : paySession.selectPayListFull) {
                    //开钱箱要求：现金、门店券、非秒付、非全能pos
                    // 门店券需读开关"纸质代金券是否自动开钱箱"，开关为开才开钱箱
                    if ((PayType.isCash(temp.data) || (PayType.isCoupon(temp.data) && DBMetaUtil.isConfigOpen(META.OPEN_BOX_WHEN_USE_COUPON, "1", "1")))
                            && temp.checkEnable() && !temp.readRapid() && !temp.readSmarPayPos()) {
                        return sendOpenMoneyBox(paySession.orderID, tableName, paySession.businessDate, hostID, user);
                    }
                }
            }
        }
        return null;
    }

    /**
     * 开钱箱
     *
     * @param orderID      String
     * @param tabelName    String
     * @param businessDate String
     * @param hostID       String
     * @param user         UserDBModel
     * @return List<Integer> | 打印任务
     */
    public static List<Integer> sendOpenMoneyBox(String orderID, String tabelName, String
            businessDate, String hostID, UserDBModel user) {
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderID, tabelName, businessDate,
                PrintJSONBuilder.generatePrintNO(),
                user.fsUserName,
                "0",
                PrintReportId.ORDERED_MENU, hostID, true);
        task.uri = "device/openmoneybox";
        task.fiTaskType = 2;

        task.fsPrinterName = PrintConnector.getInstance().getPrinterNameByHost(hostID);

        List<Integer> printNO = new ArrayList<>();
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (task.printAtOnce) {
            printNO.add(task.fiPrintNo);
        }
        return printNO;

    }

    /**
     * 订单优化页-筛选订单
     *
     * @param businessDate    营业日期
     * @param payTypeList     支付方式
     * @param checkAllPayment 是否选中全部支付方式(0,否; 1,是)
     * @param percent         账单数量
     * @return
     */
    public static List<BillOptModel> billOptFilter(String businessDate, List<String> payTypeList, int checkAllPayment, BigDecimal percent) {
        List<BillOptModel> result = new ArrayList<>();
        if (TextUtils.isEmpty(businessDate)) {
            return result;
        }
        if (ListUtil.isEmpty(payTypeList)) {
            return result;
        }
        if (percent.compareTo(BigDecimal.ZERO) <= 0) {
            return result;
        }

        StringBuilder strPayment = new StringBuilder();
        for (int index = 0; index < payTypeList.size(); index++) {
            strPayment.append("'");
            strPayment.append(payTypeList.get(index));
            strPayment.append("'");
            if (index < payTypeList.size() - 1) {
                strPayment.append(", ");
            }
        }

        String sqlNum = "SELECT count(*) AS count FROM (SELECT tbsell.fsSellNo, tbsell.fdExpAmt, tbsell.fdRealAmt, tbsell.fiSelected, tbsellcheck.fsCheckTime, tbsellcheck.fsUpdateUserName, tbsellcheck.fsUpdateTime FROM tbsell INNER JOIN tbsellcheck ON tbsell.fsSellNo = tbsellcheck.fsSellNo WHERE tbsell.fsSellDate = '" + businessDate + "' AND tbsell.fiBillStatus = 3" + (checkAllPayment == 1 ? "" : " AND (tbsell.fsSellNo IN (SELECT fsSellNo FROM tbsellreceive WHERE fsPaymentId IN (" + strPayment.toString() + ")) OR tbsell.fsSellNo IN (SELECT fsSellNo FROM (SELECT tbsell.fsSellNo AS fsSellNo, tbsellreceive.fspaymentname AS fspaymentname FROM tbsell LEFT JOIN tbsellreceive ON tbsell.fsSellNo = tbsellreceive.fsSellNo WHERE tbsell.fiBillStatus = 3 GROUP BY tbsell.fsSellNo) WHERE fspaymentname IS NULL))") + ")";
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlNum));
        LogUtil.log("筛选账单, 账单总数:\nSQL: " + sqlNum + "\n总数: " + count);

        count = new BigDecimal(count).multiply(percent).divide(new BigDecimal(10)).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
        LogUtil.log("筛选账单, 即将抽取的账单数量: [" + count + "]");

        String sqlFilter = "SELECT * FROM (SELECT tbsell.fsSellNo, tbsell.fdExpAmt, tbsell.fdRealAmt, tbsell.fiSelected, tbsell.fsAccountBook, tbsellcheck.fsCheckTime, tbsellcheck.fsUpdateUserName, tbsellcheck.fsUpdateTime FROM tbsell INNER JOIN tbsellcheck ON tbsell.fsSellNo = tbsellcheck.fsSellNo WHERE tbsell.fsSellDate = '" + businessDate + "' AND tbsell.fiBillStatus = 3" + (checkAllPayment == 1 ? "" : " AND (tbsell.fsSellNo IN (SELECT fsSellNo FROM tbsellreceive WHERE fsPaymentId IN (" + strPayment.toString() + ")) OR tbsell.fsSellNo IN (SELECT fsSellNo FROM (SELECT tbsell.fsSellNo AS fsSellNo, tbsellreceive.fspaymentname AS fspaymentname FROM tbsell LEFT JOIN tbsellreceive ON tbsell.fsSellNo = tbsellreceive.fsSellNo WHERE tbsell.fiBillStatus = 3 GROUP BY tbsell.fsSellNo) WHERE fspaymentname IS NULL))") + ") ORDER BY fsUpdateTime DESC LIMIT " + count;
        result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlFilter, BillOptModel.class);

        if (!ListUtil.isEmpty(result)) {
            for (BillOptModel billOptModel : result) {
                List<String> payNameList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "SELECT fspaymentname FROM tbsellreceive WHERE fsSellNo = '" + billOptModel.fsSellNo + "' AND fiStatus='1' ");
                StringBuilder payName = new StringBuilder();
                for (int index = 0; index < payNameList.size(); index++) {
                    payName.append(payNameList.get(index));
                    if (index < payNameList.size() - 1) {
                        payName.append(", ");
                    }
                }
                billOptModel.payment = payName.toString();

                if (!TextUtils.isEmpty(billOptModel.fsAccountBook)) {
                    String[] split = billOptModel.fsAccountBook.split(",");
                    for (String accountBookId : split) {
                        if (TextUtils.isEmpty(accountBookId)) {
                            continue;
                        }
                        if (billOptModel.accountBookIdList == null) {
                            billOptModel.accountBookIdList = new ArrayList<>();
                        }
                        billOptModel.accountBookIdList.add(accountBookId);
                    }
                }
            }
        }
        return result;
    }

    public static JSONObject billStatistics(String businessDate) {
        String sqlCount = "SELECT count(*) AS num FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3";
        int num = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlCount, "num", Integer.class);
        String sqlAmt = "SELECT sum(fdRealAmt) AS amt FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3";
        BigDecimal amt = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlAmt, "amt", BigDecimal.class);
        JSONObject result = new JSONObject();
        result.put("totalNum", num);
        result.put("totalAmt", amt);
        return result;
    }

    public static JSONObject billHiddenStatistics(String businessDate, String accountBookId) {
//        String sqlCount = "SELECT count(*) AS num FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3 AND fiSelected = 1";
        String sqlCount = "SELECT count(*) AS num FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3 AND fsAccountBook like '%," + accountBookId + ",%' ";
        int num = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlCount, "num", Integer.class);
//        String sqlAmt = "SELECT sum(fdRealAmt) AS amt FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3 AND fiSelected = 1";
        String sqlAmt = "SELECT sum(fdRealAmt) AS amt FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3 AND fsAccountBook like '%," + accountBookId + ",%' ";
        BigDecimal amt = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlAmt, "amt", BigDecimal.class);
        JSONObject result = new JSONObject();
        result.put("hiddenNum", num);
        result.put("hiddenAmt", amt);
        return result;
    }

    /**
     * 隐藏/取消隐藏账单
     *
     * @param businessData  营业日期
     * @param orderIdList   待操作的账单id
     * @param hidden        是否隐藏(0, 取消隐藏; 1, 隐藏)
     * @param accountBookId 账套id
     * @return
     */
    public static String optimize(String businessData, List<String> orderIdList, int hidden,
                                  String accountBookId) {
        if (ListUtil.isEmpty(orderIdList)) {
            return "";
        }
        if (hidden < 0 || hidden > 1) {
            return "状态异常";
        }
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                StringBuilder sb = new StringBuilder();
                for (int index = 0; index < orderIdList.size(); index++) {
                    sb.append("'");
                    sb.append(orderIdList.get(index));
                    sb.append("'");
                    if (index < orderIdList.size() - 1) {
                        sb.append(", ");
                    }
                }
                // 1. 修改 order_cache
                String sqlCache = "UPDATE order_cache SET hidden = " + hidden + ", " +
                        " fsAccountBook = " + (hidden == 1 ? "replace(fsAccountBook, '," + accountBookId + ",', '') " : "CASE WHEN fsAccountBook is null THEN '," + accountBookId + ",' WHEN fsAccountBook LIKE '%," + accountBookId + ",%' THEN fsAccountBook ELSE fsAccountBook||'," + accountBookId + ",' END") +
                        " WHERE order_id IN (" + sb.toString() + ")";
                db.execSQL(sqlCache);
                // 2. 修改 tbsell
                String sqlSell = "UPDATE tbsell SET fiSelected = " + hidden + ", " +
                        " fsAccountBook = " + (hidden == 1 ? "replace(fsAccountBook, '," + accountBookId + ",', '') " : "CASE WHEN fsAccountBook is null THEN '," + accountBookId + ",' WHEN fsAccountBook LIKE '%," + accountBookId + ",%' THEN fsAccountBook ELSE fsAccountBook||'," + accountBookId + ",' END") + ", " +
                        " lver = lver + 1 WHERE fsSellNo IN (" + sb.toString() + ")";
                db.execSQL(sqlSell);
                return null;
            }
        });

        // 修改历史账单，需重新统计B账报表并保存
        String currentDate = HostUtil.getHistoryBusineeDate("");
        if (!TextUtils.equals(businessData, currentDate)) {
            String naturalDate = DateUtil.getCurrentDate("yyyy-MM-dd");
//            BizSyncDriver.saveReport(businessData, naturalDate, 1, false);
            BizSyncDriver.saveReport(businessData, naturalDate, 1, accountBookId, false);
        }
        return "";
    }

    public static List<BillOptModel> getBillOptWithOrderId(List<String> orderIdList) {
        List<BillOptModel> result = new ArrayList<>();
        if (ListUtil.isEmpty(orderIdList)) {
            return result;
        }
        StringBuilder orderId = new StringBuilder();
        for (int index = 0; index < orderIdList.size(); index++) {
            orderId.append("'");
            orderId.append(orderIdList.get(index));
            orderId.append("'");
            if (index < orderIdList.size() - 1) {
                orderId.append(", ");
            }
        }
        String sql = "SELECT tbsell.fsSellNo, tbsell.fdExpAmt, tbsell.fdRealAmt, tbsell.fiSelected, tbsell.fsAccountBook, tbsellcheck.fsCheckTime, tbsellcheck.fsUpdateUserName, tbsellcheck.fsUpdateTime FROM tbsell INNER JOIN tbsellcheck ON tbsell.fsSellNo = tbsellcheck.fsSellNo WHERE tbsell.fsSellNo IN (" + orderId.toString() + ") ORDER BY tbsellcheck.fsUpdateTime DESC";
        result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, BillOptModel.class);

        if (!ListUtil.isEmpty(result)) {
            for (BillOptModel billOptModel : result) {
                List<String> payNameList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "SELECT fspaymentname FROM tbsellreceive WHERE fsSellNo = '" + billOptModel.fsSellNo + "' AND fiStatus = '1' ");
                StringBuilder payName = new StringBuilder();
                for (int index = 0; index < payNameList.size(); index++) {
                    payName.append(payNameList.get(index));
                    if (index < payNameList.size() - 1) {
                        payName.append(", ");
                    }
                }
                billOptModel.payment = payName.toString();

                if (!TextUtils.isEmpty(billOptModel.fsAccountBook)) {
                    String[] split = billOptModel.fsAccountBook.split(",");
                    for (String accountBookId : split) {
                        if (TextUtils.isEmpty(accountBookId)) {
                            continue;
                        }
                        if (billOptModel.accountBookIdList == null) {
                            billOptModel.accountBookIdList = new ArrayList<>();
                        }
                        billOptModel.accountBookIdList.add(accountBookId);
                    }
                }
            }
        }
        return result;
    }

    /**
     * 修改账单上传状态
     *
     * @param businessDate
     * @param failModels
     */
    public static void updateBillUploadStatus(final String businessDate,
                                              final List<BillStateModel> failModels) {
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                String sql = "UPDATE tbsell SET fiUploadStatus = 1 WHERE fiSelected = 0 AND fsSellDate = '" + businessDate + "'";
                db.execSQL(sql);

                if (!ListUtil.isEmpty(failModels)) {
                    for (BillStateModel model : failModels) {
                        String sqlFail = "UPDATE tbsell SET fiUploadStatus = 2, fsUploadMsg = '" + model.errmsg + "' WHERE fsSellNo = '" + model.selno + "'";
                        db.execSQL(sqlFail);
                    }
                }
                return null;
            }
        });
    }

    /**
     * 查询账单上传操作日志
     *
     * @return
     */
    public static List<CacheModel> queryBillOptLog(String accountBookId) {
        String sql = "SELECT * FROM datacache WHERE key LIKE '" + CacheKey.BILL_UPLOAD_DATE_STATUS + "%' AND key like '%_" + accountBookId + "' ORDER BY key DESC";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, CacheModel.class);
    }

    /**
     * 同步账单上传状态
     *
     * @param businessDate
     * @return int | -1,同步失败; 0,全部上传完成; 1,部分未上传成功; 2,未上传
     */
    public static String syncBillUploadState(final String businessDate) {
        final String[] result = {""};
        GetABBillStateRequest getABBillStateRequest = new GetABBillStateRequest();
        getABBillStateRequest.selldate = businessDate;
        getABBillStateRequest.shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        BusinessExecutor.execute(getABBillStateRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean instanceof GetABBillStateResponse) {
                    result[0] = String.valueOf(((GetABBillStateResponse) responseData.responseBean).data.state);
                }
                NotifyToClient.syncBillStatusComplete(result[0]);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                result[0] = responseData.resultMessage;
                NotifyToClient.syncBillStatusComplete(result[0]);
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean instanceof GetABBillStateResponse) {
                    saveBillUploadState(businessDate, ((GetABBillStateResponse) responseData.responseBean).data.state, true);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        });
        return result[0];
    }

    /**
     * 保存账单上传状态
     *
     * @param date    营业日期
     * @param status  状态
     * @param isQuery 是否是查询结果
     */
    public static void saveBillUploadState(String date, int status, boolean isQuery) {
        if (isQuery) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "UPDATE datacache SET value = '" + status + "' WHERE type = 0 AND key = '" + (CacheKey.BILL_UPLOAD_DATE_STATUS + date) + "'");
        } else {
            CacheModel cache = new CacheModel();
            cache.type = 0;
            cache.key = CacheKey.BILL_UPLOAD_DATE_STATUS + date;
            cache.info = statisticExpAmt(date).toPlainString();
            cache.biz_key = date;
            cache.createtime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            cache.updatetime = cache.createtime;
            cache.replaceNoTrans();
        }
    }

    /**
     * 根据营业日期统计应收金额
     * 1. 已结账的账单
     * 2. 显示的账单
     *
     * @param businessDate
     * @return
     */
    public static BigDecimal statisticExpAmt(String businessDate) {
        String sqlAmt = "SELECT sum(fdExpAmt) AS amt FROM tbsell WHERE fsSellDate = '" + businessDate + "' AND fiBillStatus = 3 AND fiSelected = 0";
        return DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlAmt, "amt", BigDecimal.class);
    }

    /**
     * 团购券核销
     *
     * @param head           请求头
     * @param orderId        订单号id
     * @param sn             团购券码
     * @param num            核销数量
     * @param payOriginModel 券支付方式
     * @return 订单号相关支付数据
     */
    public static SocketResponse doUseGroupTicket(SocketHeader head, String orderId, String sn,
                                                  int num, PayOriginModel payOriginModel) {
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        SocketBaseResponse checkResponse = BillUtil.checkCanPay(head.ot, user.fsUserId, orderId, payOriginModel);
        final SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

        // 处理团购券验券 并插入支付明细
        final PaySession session = OrderSession.getInstance().getPay(orderId);
        if (PayUtil.getLeftToPayIgnoreService(session, orderCache).compareTo(BigDecimal.ZERO) <= 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "待支付金额小于等于服务费，不能使用券";
            return socketResponse;
        }
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderId, user.fsUserName + " 团购券核销:" + sn);
        try {
            orderCache = OrderSession.getInstance().getOrder(orderId);
            final ArrayList<GroupTicketUse> couponList = new ArrayList<>();
            GroupTicketUseRequest request = new GroupTicketUseRequest();
            request.num = num;
            request.type = payOriginModel.fiVoucherPlatform + "";
            request.sn = sn;
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof GroupTicketUseResponse) {

                        GroupTicketUseResponse response = ((GroupTicketUseResponse) responseData.responseBean);
                        if (!ListUtil.isEmpty(response.data.list)) {
                            couponList.clear();
                            couponList.addAll(response.data.list);
                        }
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);

            if (socketResponse.code != SocketResultCode.SUCCESS) {
                return socketResponse;
            }

            if (ListUtil.isEmpty(couponList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "核销券数量为0";
                return socketResponse;
            }

            // 处理团购券验券 并插入支付明细
//            final PaySession session = OrderSession.getInstance().getPay(orderId);
            List<PayModel> selectPayList = new ArrayList<>();
            for (GroupTicketUse groupTicketUse : couponList) {
                PayModel selectPay = new PayModel();
                PayOriginModel selectModel = payOriginModel.clone();
                if (selectModel.groupTicket == null) {
                    selectModel.groupTicket = new GroupTicket();
                }
                selectModel.groupTicket.deal_title = groupTicketUse.deal_title;
                selectModel.groupTicket.sn = groupTicketUse.sn;
                selectModel.groupTicket.price = groupTicketUse.price;
                //验券平台1:美团点评'1:美团 2:口碑
                if (payOriginModel.fiVoucherPlatform == 2 && groupTicketUse.payed_amount != null) {
                    selectModel.fdDiscountRate = BigDecimal.ONE.subtract(groupTicketUse.payed_amount.divide(groupTicketUse.price, 4, BigDecimal.ROUND_HALF_UP));
                    if (selectModel.fdDiscountRate.compareTo(BigDecimal.ZERO) <= 0) {
                        selectModel.fdDiscountRate = BigDecimal.ZERO;
                    }
                    selectModel.fdDiscountRate = selectModel.fdDiscountRate.multiply(BizConstant.HUNDREND);
                    selectModel.fsDiscountPaymentId = PayType.KOUBEI_TICKER_COUPON;
                    selectPay.writeKBQuanPay();
                }
                selectPay.data = selectModel;
                selectPay.payAmount = selectModel.groupTicket.price;
                selectPay.businessInfo = selectModel.groupTicket.sn;
                selectPayList.add(selectPay);
            }
            for (PayModel payModel : selectPayList) {
                String error = useGroupCoupon(session, orderCache, payModel);
                if (!TextUtils.isEmpty(error)) {
                    RunTimeLog.addLog(RunTimeLog.PAY_GROUP_TICKET, "使用团购券: " + error);
                    continue;
                }
                // 急速验券可能导致待支付为 0 的情况下，多核销券，这里添加支付明细允许 0 元继续添加
                SocketResponse<PayResultResponse> res = addPayDetail(head.ot, orderId, user, head.hd, true, payModel);
                RunTimeLog.addLog(RunTimeLog.PAY_GROUP_TICKET, "团购券->添加支付明细", JSON.toJSONString(res));
                if (res.success()) {
                    socketResponse.code = SocketResultCode.SUCCESS;
                    PayResultResponse payResultResponse = new PayResultResponse();
                    payResultResponse.payData = buildPayViewData(orderId);
                    payResultResponse.payData.showKoBeiHint = DataCacheDBUtil.isShowKoBeiHintDialog(user.fsUserId);
                    socketResponse.data = payResultResponse;
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderId, user.fsUserName + " 团购券核销:" + sn);
        }
        return socketResponse;
    }

    /**
     * 使用团购券
     *
     * @param session          PaySession
     * @param orderCache       OrderCache
     * @param currentSelectPay List<PayModel>
     * @return
     */
    public static String useGroupCoupon(final PaySession session,
                                        final OrderCache orderCache, PayModel currentSelectPay) {
        BigDecimal inputAmount = currentSelectPay.payAmount;
        BigDecimal priceLeftToPay = PayUtil.getLeftToPayIgnoreService(session, orderCache);
        BigDecimal discountAmtLeftToPay = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);

        if (currentSelectPay.data.checkForDiscount()) {
            priceLeftToPay = discountAmtLeftToPay;
            if (priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
                RunTimeLog.addLog(RunTimeLog.PAY_GROUP_TICKET, "可折扣金额为0，使用团购券[" + currentSelectPay.businessInfo + "]");
            }
        }

        if (priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
            RunTimeLog.addLog(RunTimeLog.PAY_GROUP_TICKET, "待支付金额为0，使用团购券[" + currentSelectPay.businessInfo + "]");
        }

        //计算券的折扣率
        if (currentSelectPay.data.fdDiscountRate.compareTo(BigDecimal.ZERO) > 0 && !TextUtils.isEmpty(currentSelectPay.data.fsDiscountPaymentId)) {
            PayOriginModel payTypeDiscount = OrderUtil.buildPayModelByPaymentID(currentSelectPay.data.fsDiscountPaymentId);
            if (payTypeDiscount != null) {
                PayModel model = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                model.data = payTypeDiscount;
                if (currentSelectPay.isKBQuanPay()) {
                    model.writeKBQuanPay();
                }
                model.payAmount = currentSelectPay.payAmount.multiply(currentSelectPay.data.fdDiscountRate).divide(BizConstant.HUNDREND, 2, BigDecimal.ROUND_HALF_UP);
                if (currentSelectPay.secondPayList == null) {
                    currentSelectPay.secondPayList = new ArrayList<>();
                }
                currentSelectPay.secondPayList.add(model);
                currentSelectPay.payAmount = currentSelectPay.payAmount.subtract(model.payAmount);
            }
        }

        //计算是否需要进行免找
        BigDecimal subValue = inputAmount.subtract(priceLeftToPay);
        if (subValue.compareTo(BigDecimal.ZERO) > 0) {
            if (currentSelectPay.subPayList == null) {
                currentSelectPay.subPayList = new ArrayList<>();
            }
            PayOriginModel payTypeCouponGiven = null;
            payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_GROUP_TICKET_FREE);
            if (payTypeCouponGiven != null) {
                PayModel model = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                model.data = payTypeCouponGiven;
                model.payAmount = subValue.negate();
                if (currentSelectPay.isKBQuanPay()) {
                    model.writeKBQuanPay();
                }
                currentSelectPay.subPayList.add(model);
            }
        }
        return "";
    }

    /**
     * 生成支付订单号
     *
     * @param orderId 订单id
     * @param user    用户model
     * @param hostId  站点id
     * @return
     */
    public static String buildPayOrder(String orderId, UserDBModel user, String hostId) {
        if (TextUtils.isEmpty(orderId)) {
            throw new IllegalArgumentException("订单号不能为空");
        }
        if (user == null) {
            throw new IllegalArgumentException("登录信息已过期");
        }

        if (OrderSession.getInstance().getPay(orderId) == null) {
            OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(orderId), user, hostId);
        }
        PaySession session = OrderSession.getInstance().getPay(orderId);

        String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        return OrderUtil.buildNetOrderID(shopId, session.billNO);
    }

    /**
     * 反结账修改订单相关的数据
     *
     * @param orderCache  OrderCache
     * @param userDBModel UserDBModel
     * @param orderid     String
     * @param reason      String
     */
    public static void antiPayOrderStatus(OrderCache orderCache, UserDBModel
            userDBModel, String orderid, String reason) {
        orderCache.antiPayCount++;
        PaySession antiBackSession = OrderSession.getInstance().getPay(orderid).clone();

        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                OrderCache orderCache1 = orderCache.clone();
                orderCache1.orderID = orderCache1.orderID + "_" + orderCache1.antiPayCount;
                for (MenuItem menuItem : orderCache1.originMenuList) {
                    menuItem.updateUniqByAntiCount(orderCache1.antiPayCount);
                }

                if (antiBackSession != null) {
                    antiBackSession.orderID = orderCache1.orderID;
                    antiBackSession.billNO = antiBackSession.billNO + "_" + orderCache1.antiPayCount;
                }
                orderCache1.antiPayReason = reason;
                orderCache1.antiPayWaiterID = userDBModel.fsUserId;
                orderCache1.antiPayWaiterName = userDBModel.fsUserName;
                orderCache1.orderStatus = OrderStatus.ANTI_BACK;
                OrderProcessor.saveOrder(orderCache1, null);
                OrderProcessor.submit(orderCache1, antiBackSession);
//                UploadDataProcessor.doUploadSingleOrderWithBaseData(orderCache1.orderID);
                UploadDataHelper.uploadOrderData(orderCache1.orderID, false);
                LogUtil.logBusiness(TAG, "antiPayOrderStatus UploadDataProcessor.doUploadSingleOrderWithBaseData(orderCache1.orderID)" + orderCache1.orderID);
                return null;
            }
        });

        orderCache.orderStatus = OrderStatus.ANTI_PAIED;
        orderCache.updateAllSeqStatus(OrderSeqStatus.ANTIPAY);
        OrderSession.updateAntiCount(orderid);
        OrderSession.updateOrderStatus(orderid, OrderStatus.ANTI_PAIED);
        OrderSession.setPayed(orderid, 0);
        OrderSession.getInstance().writeOrder(orderid, false, "antiPayOrderStatus");
        PaySession session = OrderSession.getInstance().getPay(orderid);
        OrderUtil.recalcPaySessionLeftToPay(session, orderCache);
    }


/*************************************************一下方法为会员重构添加**************************************************/
    /**
     * 查询会员的优惠券列表---预消费查询
     *
     * @param orderID String
     * @return SocketResponse<GetPayMemberTicketResponse>
     */
    public static SocketResponse<GetPayMemberTicketResponse> searchMemberTicket(final String orderID) {
        final SocketResponse<GetPayMemberTicketResponse> socketResponse = new SocketResponse<>();
        final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        PaySession session = OrderSession.getInstance().getPay(orderID);
        final GetPayMemberTicketResponse ticketResponse = new GetPayMemberTicketResponse();
        socketResponse.data = ticketResponse;

        if (ticketResponse.ticketList == null) {
            ticketResponse.ticketList = new ArrayList<>();
        }
        // 如果积分支付了，然后端上会员解绑，然后再退积分，会重新触发这里的操作，导致下面取卡号时报空指针，这里容个错
        if (orderCache.memberInfoS == null) {
            return socketResponse;
        }
        //1、查询可用积分
        ServerMemberApi.sendPreSearchConsume(session.selectPayListFull, orderCache.optTotalPrice(), PayUtil.getCannnotDiscAmtByOrderTotal(orderID), orderCache.memberInfoS.card_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberPrePayCheckResponse) {
                    MemberPrePayCheckResponse response = (MemberPrePayCheckResponse) responseData.responseBean;
                    // 对该List进行筛选
//                    String sql = "select * from tbPayment where fsPaymentTypeId in " + PayTypeGroup.SQL_MEMBER_TICKET + " and fiStatus = '1'";
                    String sql = "SELECT payment.*, paymenttype.fsPaymentTypeName FROM tbpayment AS payment LEFT OUTER JOIN tbpaymenttype paymenttype ON payment.fsPaymentTypeId = paymenttype.fsPaymentTypeId WHERE payment.fsPaymentTypeId IN " + PayTypeGroup.SQL_MEMBER_TICKET + " AND payment.fiStatus = '1'";
                    List<PaymentDBModel> paymentDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymentDBModel.class);
                    ticketResponse.score_money = response.data.score_money;
                    ticketResponse.use_score = response.data.use_score;
                    ticketResponse.user_all_score = response.data.user_all_score;
                    if (!ListUtil.isEmpty(response.data.coupons_list) && !ListUtil.isEmpty(paymentDBModelList)) {
                        for (MemberCouponModel memberCouponModel : response.data.coupons_list) {
                            for (PaymentDBModel paymentDBModel : paymentDBModelList) {
                                if (TextUtils.equals(memberCouponModel.coupon_id, paymentDBModel.fsNote)) {
                                    ticketResponse.ticketList.add(OrderUtil.buildPayOriginModel(paymentDBModel, memberCouponModel));
                                    break;
                                }
                            }
                        }
                    } else {
                        String error = response.data.checkTicketCanUse();
                        if (!TextUtils.isEmpty(error)) {
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = error;
                        }
                    }
                } else {
                    socketResponse.code = SocketResultCode.DESERIALIZE_FAILED;
                    socketResponse.message = "获取会员数据异常";
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                socketResponse.message = responseData.resultMessage;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });
        return socketResponse;
    }

}
