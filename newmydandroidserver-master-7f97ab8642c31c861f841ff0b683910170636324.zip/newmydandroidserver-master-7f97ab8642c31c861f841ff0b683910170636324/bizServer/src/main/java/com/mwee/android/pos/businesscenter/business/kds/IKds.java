package com.mwee.android.pos.businesscenter.business.kds;

import android.support.v4.util.ArrayMap;
import android.util.Pair;

import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.kds.KdsMakeState;
import com.mwee.android.pos.db.business.order.OrderCache;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * @ClassName: IKds
 * @Description:
 * @author: Cannan
 * @date: 2018/11/6 上午11:17
 */
public interface IKds {

    void init();

    void wmOrder(TempAppOrder tempAppOrder, List<PrintItemDataBean> sellOrderItemDBModels,int beforeTime);

    /**
     * 下单
     *
     * @param orderCache OrderCache | 订单相关信息
     * @param data       ArrayMap | key: 打印部门id, value: 部门相关菜品信息
     * @param hostID     String | 站点id
     */
    void order(OrderCache orderCache, ArrayMap<String, Set<SellOrderItemDBModel>> data, ArrayMap<String, List<String>> deptMapping, String hostID, UserDBModel user);

    /**
     * 称重
     *
     * @param order
     * @param fsSeq
     */
    void weigh(OrderCache order, String fsSeq, String hostId, UserDBModel user);

    /**
     * 起菜
     *
     * @param optSeqList List<String> | 待操作的菜品 seq
     */
    void serving(List<String> optSeqList, String hostID, UserDBModel user);

    /**
     * 退菜
     *
     * @param optSeqList List<String> | 待操作的菜品 seq
     */
    void retreated(List<String> optSeqList);

    /**
     * 催菜
     *
     * @param orderID    String | 订单号
     * @param optSeqList List<String> | 待操作的菜品 seq
     */
    void hurry(String orderID, List<String> optSeqList);

    /**
     * 划菜
     */
    void delimit(String deptID, String menu, String foodId, BigDecimal num, boolean isUnAssign, String hostID, UserDBModel user, String barCode);

    /**
     * 撤销最后一次划菜
     */
    void unDelimit(String deptId, String hostID, UserDBModel user);

    /**
     * 转菜
     *
     * @param optMenuSeq
     * @param target
     */
    void menuTransfer(List<String> optMenuSeq, OrderCache target);

    /**
     * 换桌
     *
     * @param origin 原始桌台
     * @param target 目标桌台
     */
    void tableTransfer(String origin, String target);

    /**
     * 加载菜品，变更菜品状态从「等待制作」变更为「制作中」
     *
     * @param deptID String | 档口id
     * @param num    int | 菜品数量
     */
    void load(String deptID, int num);

    /**
     * 修改配料菜信息
     */
    boolean changeDishIngredient(List<String> dishIds, String foodName);

    /**
     * 查询菜品队列
     *
     * @param depID
     * @param state
     * @param pageSize
     * @param pageNum
     * @return
     */
    Pair<Integer, List<KdsMenuViewBean>> query(String depID, @KdsMakeState int state, int pageSize, int pageNum);

    /**
     * 结账
     *
     * @param orderId
     */
    void payFinish(String orderId);

    /**
     * 刷新配置
     */
    void refresh();
}
