package com.mwee.android.pos.businesscenter.dbutil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 管理shop表
 * Created by qinwei on 2019/2/12 11:13 AM
 * email: qin.wei@mwee.cn
 */
public class ShopDBUtil {
    public static String queryShopId() {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGUID from tbShop order by fiStatus asc");
    }

    public static String queryCompanyGUID() {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbShop order by fiStatus asc");
    }
}
