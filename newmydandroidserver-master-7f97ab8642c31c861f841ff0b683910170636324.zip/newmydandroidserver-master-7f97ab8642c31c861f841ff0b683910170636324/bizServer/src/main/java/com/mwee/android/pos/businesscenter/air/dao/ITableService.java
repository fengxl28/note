package com.mwee.android.pos.businesscenter.air.dao;

import com.mwee.android.pos.connect.business.table.ShareTableResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;

/**
 * 处理桌台业务
 * Created by qinwei on 2018/8/17.
 */

public interface ITableService {
    /**
     * 拼桌
     *
     * @param tableId     原桌台id
     * @param userDBModel
     */
    SocketResponse<ShareTableResponse> doShareTable(String tableId, UserDBModel userDBModel);
}
