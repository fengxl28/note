package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.print.CustomSellDBModel;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.business.rapid.api.bean.model.EatType;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberComments;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.SymbolUtils;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/4/17.
 */

public class PrintFastFoodOrderUtil {
    public static List<Integer> printMake(final OrderCache orderCache, final UserDBModel userDBModel, final int seq, String hostId) {
        return printMake(orderCache, userDBModel, seq + "", hostId);
    }

    public static List<Integer> printMake(final OrderCache orderCache, final UserDBModel userDBModel, final String seq, String hostId) {
        return printMake(orderCache, userDBModel, seq, "", hostId);
    }

    /**
     * 格式化牌号
     *
     * @param sell
     * @return
     */
    private static String formatCallNum(SellDBModel sell) {
        int num = 0;
        boolean isNumber = RegexUtil.checkNumber(sell.fsMealNumber);
        if (!isNumber) {
            if (TextUtils.equals(sell.fsMealNumber, "无")) {
                num = StringUtil.toInt(sell.fssellno.substring(8), 0);
            } else {
                return sell.fsMealNumber;
            }
        } else {
            if (TextUtils.isEmpty(sell.fsMealNumber)) {
                num = StringUtil.toInt(sell.fssellno.substring(8), 0);
            } else {
                num = StringUtil.toInt(sell.fsMealNumber);
            }
        }
        return RegexUtil.formatNumber(num, 3);

    }


    /**
     * 制作单
     *
     * @param orderCache 订单的基本信息
     * @param seq        String | 要打印的菜品单序，打印所有单序则传-1
     * @param menuUniq   String | 要打印指定的菜，则传菜品的uniq
     */
    public static List<Integer> printMake(final OrderCache orderCache, final UserDBModel userDBModel, final String seq,
                                          final String menuUniq, final String hostId) {
        List<Integer> printTaskIds = new ArrayList<>();
        JSONObject data = new JSONObject();

        ArrayList<PrintItemDataBean> printItems = PrintOrderUtil.buildPrintItemsByOrderSeq(orderCache.orderID, seq, menuUniq);//构建小票内菜品信息

        SellDBModel sellDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", SellDBModel.class);

        String printTime = DateUtil.getCurrentTime();
        JSONObject times = new JSONObject();
        data.put("Sell", sellDBModel);
        if (!TextUtils.isEmpty(seq)) {
            data.put("orderSeq", seq);//将单序存到打印数据里，打印制作单时，需要根据单序来控制是否显示加菜标识
            if (seq.contains(",")) {
            } else {
                data.put("addMenuLabel", PrintOrderUtil.getAddMenuLabel(seq));//将加菜标识存到打印数据里，打印制作单时，需要根据它是否显示加菜标识
                String waiterName = orderCache.optSeqModel(StringUtil.toInt(seq, 0)).createWaiterName;
                if (TextUtils.isEmpty(waiterName)) {
                    waiterName = userDBModel.fsUserName;
                }
                data.put("fsCreateUserName", waiterName);
            }
        } else {
            data.put("fsCreateUserName", orderCache.waiterName);
        }
        times.put("PrintTime", printTime);
        data.put("SysMode", times);
        data.put("mealNumber", orderCache.mealNumber);

        if (TextUtils.equals("99", orderCache.fsBillSourceId)) {
            data.put("eatType", orderCache.eatType == EatType.EAT_IN ? "(堂食)" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "(外带)" : "");
        }
        //美小店订单
        if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
            data.put("eatType", orderCache.eatType == EatType.EAT_IN ? "堂食" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "外带" : "");
            data.put("eatTime", orderCache.eatTime);
        }

        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);

        if (TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.PRINT_BAR_CODE), "1")) {
            String callNo = formatCallNum(sellDBModel);
            if (!TextUtils.isEmpty(callNo) && !TextUtils.equals("000", callNo)) {
                String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                String mspId = MessageDBUtil.optMsgId(sellDBModel.fssellno);
                if (!TextUtils.isEmpty(mspId)) {
                    data.put("barCode", callNo + "*1" + shopId + "*2" + mspId);
                } else {
                    data.put("barCode", callNo + "*1" + shopId);
                }
            }
        }

        String billSourceName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsBillSourceName from tbBillSource where fsBillSourceId='" + orderCache.fsBillSourceId + "'");
        data.put("billSourceName", billSourceName);

        if (printItems.size() > 0) {
            GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                    .setItemList(printItems)
                    .setWithCurrentHost(false)
                    .setWithDeptMake(true)
                    .setWithDeptTransfer(false)
                    .setCheckArea(true)
                    .setTableAreaID(orderCache.fsmareaid)
                    .setCurrentHostId(hostId)
                    .build();
            for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                String fsDeptId = entry.getKey();
                DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
                if (deptDBModel == null) {
                    continue;
                }

                data.put("Dept", deptDBModel);

                /**
                 * 打印份数
                 */
                int fiPrintCopies = deptDBModel.fiPrintCopies;
                if (fiPrintCopies == 0) {
                    fiPrintCopies = 1;
                }

                PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                if (printer == null) {
                    String info = "打印制作单失败,没有找到启用的打印机。部门ID[" + fsDeptId + "]";
                    //ToastUtil.showToast(info);
                    RunTimeLog.addLog(RunTimeLog.PRINT_FAILED, info);
                    continue;
                }
                List<PrintItemDataBean> list = entry.getValue();
                if (ListUtil.isEmpty(list)) {
                    continue;
                }

                data.remove("SellOrder");
                data.remove("SellOrders");

                boolean isTsc = "TSC".equalsIgnoreCase(printer.fsCommandType);
                if (isTsc) {//拦截TSC打印
                    boolean printerTscSingleMake = TextUtils.equals(ClientMetaUtil.getConfig(META.T_TSC_PRINTER, "1"), "1");//标签是否打印        0/不打印 1 打印
                    if (!printerTscSingleMake) {
                        break;
                    }
                } else {//拦截厨房打印
                    boolean isPrinterMakeOrder = TextUtils.equals(ClientMetaUtil.getConfig(META.T_KITCHEN_PRINTER, "1"), "1");
                    if (!isPrinterMakeOrder) {
                        break;
                    }
                }
                for (int i = 0; i < fiPrintCopies; i++) {

                    data.remove("SellOrder");
                    data.remove("SellOrders");
                    data.remove("beep");

                    if (isTsc) {
                        printSingleMake(true, data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds, processor.tscCount, beep);
                    } else {
                        /**
                         * 制作单一菜一切
                         */
                        if (deptDBModel.fiIsOneItemCut == 1) {
                            printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds, processor.tscCount, beep);
                        } else if (deptDBModel.fiIsOneItemCut == 2) {
                            data.put("beep", beep);
                            printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds);
                        } else if (deptDBModel.fiIsOneItemCut == 3) {
                            printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds, processor.tscCount, beep);
                            data.remove("SellOrder");
                            data.remove("SellOrders");
                            data.put("beep", beep);
                            printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds);
                        } else if (deptDBModel.fiIsOneItemCut == 4) {//1份1切
                            printSingle(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, (ArrayList<Integer>) printTaskIds, processor.tscCount, beep);
                        } else {
                            data.put("beep", beep);
                            printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, list, hostId, printTaskIds);
                        }
                    }
                }
            }
        }
        return printTaskIds;
    }

    /**
     * 一份一切
     *
     * @param isTsc
     * @param valueMap
     * @param orderCache
     * @param fsDeptId
     * @param fsPrinterName
     * @param hostId
     * @param list
     * @param printTaskIds
     * @param tscCount
     * @param beep          蜂鸣
     */
    private static void printSingle(boolean isTsc, JSONObject valueMap, OrderCache orderCache,
                                    String fsDeptId, String fsPrinterName, String hostId,
                                    List<PrintItemDataBean> list, ArrayList<Integer> printTaskIds, int tscCount, String beep) {
        int fiPrintNo = 0;
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_SINGLE, hostId, true);
        task.fsPrinterName = fsPrinterName;
        List<PrintItemDataBean> tempList = new ArrayList<>();
        tempList.addAll(list);
        for (int x = 0; x < tempList.size(); x++) {
            PrintItemDataBean temp = tempList.get(x).clone();

            int count = temp.fiIsEditQty == 1 ? 1 : temp.fdSaleQty.intValue();
            if (isTsc) {
                for (int i = 1; i <= count; i++) {

                    JSONObject printDatas = new JSONObject();

                    String shopName = "";
                    if (shopDBModel != null) {
                        shopName = shopDBModel.fsShopName;
                    }
                    printDatas.put("shopname", shopName);
                    String id = "台号:" + orderCache.fsmtablename;
                    printDatas.put("id", id);
                    if (temp.fiIsEditQty == 1) {
                        printDatas.put("num", PrintUtil.optBuyNumAndUnit(temp.fdSaleQty, temp.fsOrderUint));
                    } else {
                        printDatas.put("num", PrintUtil.optBuyNumAndUnit(BigDecimal.ONE, temp.fsOrderUint));
                    }

                    printDatas.put("itemname", temp.fsItemName);
                    printDatas.put("price", Calc.formatShow(temp.fdSettlePrice) + "元");
                    String sequence = (temp.lastTscIndex + i) + "/" + tscCount;
                    LogUtil.log("sequence = " + sequence + " -->" + temp.fsItemName);
                    printDatas.put("sequence", sequence);
                    printDatas.put("itemnote", temp.fsNote + "");  //备注

                    String tel = "";
                    if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
                        tel = shopDBModel.fsTel;
                    }
                    String time;
                    if (!TextUtils.isEmpty(tel)) {
                        printDatas.put("phone", "电话：" + tel);
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                    } else {
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm");
                    }
                    printDatas.put("time", time);

                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    printDatas.put("fiPrintNo", fiPrintNo);
                    if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                        task.uri = "meixiaodianOrder/makesingleTSC";
                    } else {
                        task.uri = "fastFoodorder/makesingleTSC";
                    }
//                    task.fsPrnData = printDatas.toJSONString();
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
                }
            } else {
                for (int j = 0; j < count; j++) {
                    if (x == (tempList.size() - 1) && j == (count - 1)) {  //同一个批次只蜂鸣一次
                        valueMap.put("beep", beep);
                    }
                    task.fsPrnData = null;
                    task = task.clone();
                    if (temp.fiIsEditQty != 1) {
                        temp.fdSaleQty = BigDecimal.ONE;
                    }
                    valueMap.put("SellOrder", temp);
                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    valueMap.put("fiPrintNo", fiPrintNo);
                    if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                        task.uri = "meixiaodianOrder/makesingle";
                    } else {
                        task.uri = "fastFoodorder/makesingle";
                    }
//                    task.fsPrnData = JSON.toJSONString(valueMap, SerializerFeature.DisableCircularReferenceDetect);
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
                }
            }
//            if (!task.printAtOnce) {
//                printTaskIds.add(task.fiPrintNo);
//            }
        }
    }


    /**
     * 打印单品制作单
     *
     * @param isTsc      boolean | 是否是标签打印机
     * @param valueMap   HashMap<String, Object> | 模板的value信息
     * @param orderCache OrderCache |  订单信息
     * @param fsDeptId   String | 部门ID
     * @param list       List<SellOrderItemDBModel> | 菜品列表
     */
    private static void printSingleMake(boolean isTsc, JSONObject valueMap, OrderCache orderCache, String fsDeptId, String printerName,
                                        List<PrintItemDataBean> list, String hostId, List<Integer> printTaskIds, int tscCount, String beep) {
        int fiPrintNo = 0;
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_TOTAL_LIST_SINGLE, hostId, true);
        task.fsPrinterName = printerName;
        for (int x = 0; x < list.size(); x++) {
            PrintItemDataBean temp = list.get(x);
            if (x == list.size() - 1) {
                valueMap.put("beep", beep);
            }
            task.fsPrnData = null;
            task = task.clone();
            valueMap.put("SellOrder", temp);

            if (isTsc) {
                int count = temp.fiIsEditQty == 1 ? 1 : temp.fdSaleQty.intValue();
                for (int i = 1; i <= count; i++) {
                    JSONObject printDatas = new JSONObject();
                    String shopName = "";
                    String time;
                    String id;
                    if (shopDBModel != null) {
                        shopName = shopDBModel.fsShopName;
                    }
                    printDatas.put("shopname", shopName);

                    if (!TextUtils.equals("无", orderCache.mealNumber)) {
                        id = "牌号:" + orderCache.mealNumber;
                    } else {
                        id = "单号:" + orderCache.orderID.substring(orderCache.orderID.length() - 4, orderCache.orderID.length());
                    }

                    printDatas.put("id", id);
                    printDatas.put("num", PrintUtil.optBuyNumAndUnit(temp.fdSaleQty, temp.fsOrderUint));
                    printDatas.put("itemname", temp.fsItemName);
                    printDatas.put("price", Calc.formatShow(temp.fdSettlePrice) + "元");
                    String sequence = (temp.lastTscIndex + i) + "/" + tscCount;
                    printDatas.put("sequence", sequence);
                    printDatas.put("itemnote", temp.fsNote + "");  //备注

                    String tel = "";
                    if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
                        tel = shopDBModel.fsTel;
                    }
                    if (!TextUtils.isEmpty(tel)) {
                        printDatas.put("phone", "电话：" + tel);
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                    } else {
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm");
                    }
                    printDatas.put("time", time);
                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    valueMap.put("fiPrintNo", fiPrintNo);
                    task.fsPrnData = printDatas.toJSONString();
                    if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                        task.uri = "meixiaodianOrder/makesingleTSC";
                    } else {
                        task.uri = "fastFoodorder/makesingleTSC";
                    }
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//                    if (!task.printAtOnce) {
//                        printTaskIds.add(task.fiPrintNo);
//                    }
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, printDatas);
                }
            } else {
                fiPrintNo = PrintJSONBuilder.generatePrintNO();
                task.fiPrintNo = fiPrintNo;
                valueMap.put("fiPrintNo", fiPrintNo);
                if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                    task.uri = "meixiaodianOrder/makesingle";
                } else {
                    task.uri = "fastFoodorder/makesingle";
                }
                task.fsPrnData = JSON.toJSONString(valueMap, SerializerFeature.DisableCircularReferenceDetect);
//                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//                if (!task.printAtOnce) {
//                    printTaskIds.add(task.fiPrintNo);
//                }
                //控制第二语言小票打印
                MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
            }
        }
    }


    /**
     * 打印总制作单
     *
     * @param valueMap   HashMap<String, Object> | 模板的value信息
     * @param orderCache OrderCache | 订单信息
     * @param fsDeptId   String | 部门ID
     * @param list       List<SellOrderItemDBModel> | 菜品列表
     */
    private static void printAllMake(JSONObject valueMap, OrderCache orderCache, String fsDeptId, String printerName,
                                     List<PrintItemDataBean> list, String hostId, List<Integer> printTaskIds) {
        int fiPrintNo = PrintJSONBuilder.generatePrintNO();
        valueMap.put("SellOrders", list);
        valueMap.put("fiPrintNo", fiPrintNo);
        valueMap.put("menuItemCount", PrintOrderUtil.getIngredientListCount(list).intValue() + sumQty(list, false, true));
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_TOTAL_LIST,
                hostId, true);
        if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
            task.uri = "meixiaodianOrder/make";
        } else {
            task.uri = "fastFoodorder/make";
        }
        task.fsPrnData = valueMap.toJSONString();
        task.fsPrinterName = printerName;
        //控制第二语言小票打印
        MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
//        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//        if (!task.printAtOnce) {
//            printTaskIds.add(task.fiPrintNo);
//        }
    }

    /**
     * 打印点菜单
     *
     * @param orderCache OrderCache
     * @param seq        int
     */
    public static List<Integer> printMenuList(final OrderCache orderCache, final UserDBModel userDBModel, final int seq, final String printerName,
                                              final String hostId) {
        List<Integer> printTaskIds = new ArrayList<>();
        if (!TextUtils.equals("1", CommonDBUtil.getConfig(DBPrintConfig.STATEMENT_PRINTER))) {
            LogUtil.log("不打印点菜单");
            return printTaskIds;
        }

        String fsPrinterName = printerName;
        if (TextUtils.isEmpty(fsPrinterName) && !TextUtils.isEmpty(hostId)) {
            fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
        }
        JSONObject datas = new JSONObject();
        CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", CustomSellDBModel.class);
        sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
        datas.put("Sell", sell);
        String waiterName = orderCache.optSeqModel(orderCache.optLastSeq()).createWaiterName;
        if (TextUtils.isEmpty(waiterName)) {
            waiterName = userDBModel.fsUserName;
        }
        datas.put("PrintUser", waiterName);
        String date = orderCache.businessDate;

        String sql = "select fsseq,fsOrderUint,fsSeq_M,(case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName fsItemName, (case fdGiftQty when 0 then '' else '[Gift]' end)||fsItemName2 fsItemName2,fsNote, (fdSaleQty-fdBackQty) as fdSaleQty, fiOrderItemKind, fiIsEditQty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                " where fsSellNo = '" + orderCache.orderID + "'" +
                " and fiOrderMode in (1,3)" +
                " and fsSellDate='" + date + "'";

        if (seq >= 0) {
            sql = sql + " and fiOrderSeq='" + seq + "'";
        }
        //普通菜品，套餐头
        String nomalItemsSql = sql + " and fiOrderItemKind in ('1','2') ";
        //配料菜
        String ingredientSql = sql + " and fiOrderItemKind = '4' ";
        //套餐菜
        String mackageDetailItemsSql = sql + " and fiOrderItemKind = '3' ";

        List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, nomalItemsSql, PrintItemDataBean.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        }
        List<PrintItemDataBean> ingredientItemsList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, ingredientSql, PrintItemDataBean.class);
        if (ingredientItemsList == null) {
            ingredientItemsList = new ArrayList<>();
        }
        List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, mackageDetailItemsSql, PrintItemDataBean.class);
        if (SLITList == null) {
            SLITList = new ArrayList<>();
        }
        BigDecimal ingredientCount = BigDecimal.ZERO;
        for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {
            for (PrintItemDataBean itemExModel : SLITList) {
                if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                    if (statementSellItemModel.SLIT == null) {
                        statementSellItemModel.SLIT = new ArrayList<>();
                    }
                    statementSellItemModel.SLIT.add(itemExModel);
                }
            }

            for (PrintItemDataBean ingredientModel : ingredientItemsList) {
                if (ingredientModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                    ingredientCount = ingredientCount.add(ingredientModel.fdSaleQty);
                    statementSellItemModel.ingredientList.add(ingredientModel);
                }
            }
        }
        if (ListUtil.isEmpty(sellOrderItemDBModels)) {
            return printTaskIds;
        }
        datas.put("SellOrder", sellOrderItemDBModels);
        datas.put("Sub", ingredientCount.intValue() + sumQty(sellOrderItemDBModels, true, false));

        if (TextUtils.equals("99", orderCache.fsBillSourceId) || TextUtils.equals("910", orderCache.fsBillSourceId)) {
            datas.put("eatType", orderCache.eatType == EatType.EAT_IN ? "(堂食)" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "(外带)" : "");
        }
        datas.put("mealNumber", orderCache.mealNumber);
        String billSourceName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsBillSourceName from tbBillSource where fsBillSourceId='" + orderCache.fsBillSourceId + "'");
        datas.put("billSourceName", billSourceName);

        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                printNO,
                waiterName,
                "0",
                PrintReportId.ORDERED_MENU, hostId, true);
        if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
            task.uri = "meixiaodianOrder/menulist";
        } else {
            task.uri = "fastFoodorder/menulist";
        }
        task.fsPrnData = datas.toJSONString();
        task.fsPrinterName = TextUtils.isEmpty(fsPrinterName) ? DeviceDBUtil.getCurrentHostPrinterName() : fsPrinterName;
        MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);

//        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//        if (!task.printAtOnce) {
//            printTaskIds.add(task.fiPrintNo);
//        }
        return printTaskIds;
    }


    /**
     * 计算总数
     *
     * @param list            数据源
     * @param addCategoryHead 是否算套餐头
     * @param addCategoryBody 是否算套餐体
     * @return
     */
    public static int sumQty(List<? extends PrintItemDataBean> list, boolean addCategoryHead, boolean addCategoryBody) {
        int sumQty = 0;
        try {
            for (int i = 0; i < list.size(); i++) {
                PrintItemDataBean sellOrderItemDBModel = list.get(i);
                if (sellOrderItemDBModel.fiOrderItemKind == 2 && !addCategoryHead) {
                    continue;
                } else if (sellOrderItemDBModel.fiOrderItemKind == 3 && !addCategoryBody) {
                    continue;
                }

                if (sellOrderItemDBModel.fiIsEditQty == 1) { //称重菜算一份
                    sumQty = sumQty + 1;
                } else {
                    sumQty = sumQty + sellOrderItemDBModel.fdSaleQty.intValue();
                }

            }
        } catch (Exception e) {
            LogUtil.log(e.getMessage());
        }
        return sumQty;
    }

    /**
     * 打印退菜单--支持批量退菜
     *
     * @param orderCache   OrderCache
     * @param menuItemList MenuItem
     */
    public static List<Integer> printBatchVoid(final OrderCache orderCache, final List<MenuItem> menuItemList, final String waiterName, final String hostId) {
        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        sell.put("fsMTableName", orderCache.fsmtablename);
        valueMap.put("mealNumber", orderCache.mealNumber);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        if (!ListUtil.isEmpty(menuItemList) && menuItemList.size() > 0) {
            valueMap.put("orderTime", menuItemList.get(0).menuBiz.createTime);
        }

        String billSourceName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsBillSourceName from tbBillSource where fsBillSourceId='" +
                orderCache.fsBillSourceId + "'");
        valueMap.put("billSourceName", billSourceName);
        List<PrintItemDataBean> sellOrderItemBeanList = new ArrayList<>();

        for (int i = 0; i < menuItemList.size(); i++) {
            MenuItem item = menuItemList.get(i);
            sellOrderItemBeanList.addAll(formatVoidItem(item));
        }

        boolean hostPrintVoid = DBPrintConfig.needPrintHostVoid();
        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemBeanList)
                .setWithCurrentHost(hostPrintVoid)
                .setWithDeptMake(true)
                .setWithDeptTransfer(false)
                .setCurrentHostId(hostId)
                .build();
        int printNO = 0;
        PrintTaskDBModel task;

        List<Integer> printTaskIds = new ArrayList<>();

        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1) {
                continue;
            }
            if (!TextUtils.equals(fsDeptId, "0")) {//过滤掉后厨出菜点 没有配置打印机的退菜单
                PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                if (printer == null) {
                    continue;
                }
            }
            valueMap.put("Dept", deptDBModel);
            List<PrintItemDataBean> list = entry.getValue();

            for (int i = 0; i < list.size(); i++) {
                PrintItemDataBean sellOrderItemDBModel = list.get(i);
                valueMap.put("SellOrder", sellOrderItemDBModel);
                printNO = PrintJSONBuilder.generatePrintNO();
                valueMap.put("fiPrintNo", printNO);

                valueMap.put("ingredientNote", sellOrderItemDBModel.ingredientNotes);

                task = PrintJSONBuilder.buildPrintTask(
                        orderCache.orderID,
                        orderCache.fsmtablename,
                        orderCache.businessDate,
                        printNO,
                        waiterName,
                        fsDeptId,
                        PrintReportId.RETURN_THE_MENU,
                        hostId,
                        true
                );
                if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                    task.uri = "meixiaodianOrder/void";
                } else {
                    task.uri = "fastFoodorder/void";
                }
                task.fsPrnData = valueMap.toJSONString();
                task.fsPrinterName = deptDBModel.fsPrinterName;


                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                if (!task.printAtOnce) {
                    printTaskIds.add(task.fiPrintNo);
                }
            }
        }
        return printTaskIds;
    }

    private static List<PrintItemDataBean> formatVoidItem(MenuItem menuItem) {
        List<PrintItemDataBean> item = null;
        String fiIsPrn = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiIsPrn from tbmenuitem where fiItemCd='" + menuItem.itemID + "'");
        if (TextUtils.equals(fiIsPrn, "1")) {
            String sql = "select * from tbSellOrderItem where fsSeq = '" + menuItem.menuBiz.uniq + "' and fiOrderItemKind = '1'";
            if (menuItem.supportPackage()) {
                sql = "select * from tbSellOrderItem where fsSeq_M = '" + menuItem.menuBiz.uniq + "' and fiOrderItemKind = '3' ";
            }
            item = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        } else {
            return new ArrayList<>();
        }
        if (ListUtil.isEmpty(item)) {
            return new ArrayList<>();
        }
        if (item.size() == 1) {
            PrintItemDataBean printItem = item.get(0);
            printItem.fdBackQty = menuItem.menuBiz.voidNum;
            printItem.fsBackReason = menuItem.menuBiz.voidReson;
            /**
             * 配料
             */
            StringBuilder stringBuilder = new StringBuilder("");
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                    if(modifier.menuBiz.buyNum.compareTo(modifier.menuBiz.voidNum) > 0) {
                        if ((menuItem.config & 32) == 32) {//称重菜仅计算一份
                            stringBuilder.append(modifier.name).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.menuBiz.buyNum.subtract(modifier.menuBiz.voidNum), modifier.currentUnit.fsOrderUint)).append(";");
                        } else {
                            stringBuilder.append(modifier.name).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.menuBiz.buyNum.subtract(modifier.menuBiz.voidNum).multiply(menuItem.menuBiz.voidNum), modifier.currentUnit.fsOrderUint)).append(";");
                        }
                    }
                }
                printItem.ingredientNotes = stringBuilder.toString();
            }
        } else if (item.size() > 0) {
            for (MenuItem tempExtra : menuItem.menuBiz.selectedPackageItems) {
                for (int i = 0; i < item.size(); i++) {
                    PrintItemDataBean extraItem = item.get(i);
                    if (TextUtils.equals(extraItem.fsseq, tempExtra.menuBiz.uniq)) {
                        //如果明细之前退过了，就不在打印了
                        if(tempExtra.menuBiz.buyNum.compareTo(tempExtra.menuBiz.voidNum) > 0){
                            extraItem.fdBackQty = (tempExtra.menuBiz.buyNum.subtract(tempExtra.menuBiz.voidNum)).multiply(menuItem.menuBiz.voidNum);
                            extraItem.parentItemName = menuItem.name;
                            extraItem.fsBackReason = menuItem.menuBiz.voidReson;
                        }else{
                            item.remove(extraItem);
                        }
                        break;
                    }
                }
            }
        }
        return item;
    }

    /**
     * 打印传菜单
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printPassTo(final OrderCache orderCache, UserDBModel userDBModel, final String seq, final String hostId,
                                            boolean kds, List<String> fastDishIdList, List<String> kdsFastDishIds) {
        List<Integer> printTaskIds = new ArrayList<>();
        //是否打印传菜单
        if (!PrintConfig.FASTFOOD_PRINT_PASSTO) {
            return printTaskIds;
        }
        if (orderCache.shareShopOrder()) {
            return printTaskIds;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {

                JSONObject datas = new JSONObject();

                int lastSeq = orderCache.optLastSeq();
                OrderSeqModel model = orderCache.optSeqModel(lastSeq);
                datas.put("PrintUser", orderCache.waiterName);


                String date = orderCache.businessDate;
                String sql = "select fsseq, fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsNote,fsDeptId, " +
                        "fiIsMulDept,fiItemCd,fiIsEditQty,(fdSaleQty-fdBackQty) as fdSaleQty," +
                        " (case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState," +
                        " fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind <> '3'" +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'";

                if (!TextUtils.isEmpty(seq)) {
                    sql += " and fiOrderSeq in (" + seq + ")";
                }

                String sql2 = "select fsseq,fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsDeptId,fiIsMulDept,fiItemCd,fiIsEditQty, (fdSaleQty-fdBackQty) as fdSaleQty," +
                        "(case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState, fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind = '3' " +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'";
                if (!TextUtils.isEmpty(seq)) {
                    sql2 += " and fiOrderSeq in (" + seq + ")";
                }

                List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
                if (sellOrderItemDBModels == null) {
                    sellOrderItemDBModels = new ArrayList<>();
                }

                List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintItemDataBean.class);
                if (SLITList == null) {
                    SLITList = new ArrayList<>();
                }

                for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {

                    for (PrintItemDataBean itemExModel : SLITList) {
                        if (itemExModel.fiOrderItemKind == 3 && itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                            itemExModel.parentItemName = statementSellItemModel.fsItemName;
                        }
                    }
                }

                sellOrderItemDBModels.addAll(SLITList);

                /**
                 * 去除套餐头--套餐头不打印
                 */
                for (int i = 0; i < sellOrderItemDBModels.size(); i++) {
                    if (sellOrderItemDBModels.get(i).fiOrderItemKind == 2) {
                        sellOrderItemDBModels.remove(i);
                        i--;
                    }
                }

                CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo =" + orderCache.orderID, CustomSellDBModel.class);
                sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                        "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
                datas.put("Sell", sell);


                String printPassto = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_PASSTO, "0");
                if (TextUtils.equals("0", printPassto) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null) {
                        if (!TextUtils.isEmpty(memberComments.memberLevel)) {
                            datas.put("memberLevel", memberComments.memberLevel);
                        }
                        if (!TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("sex", memberComments.sex);
                        }
                        if (memberComments.cardBalance.compareTo(BigDecimal.ZERO) >= 0 && !TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("cardBalance", memberComments.cardBalance);
                        }
                    }
                }

                String cloudBuffet = CommonDBUtil.getConfigWithDefault(DBPrintConfig.MWBYD_CLOUD_BUFFET, "0");
                if (TextUtils.equals("1", cloudBuffet) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null && memberComments.verifyComments()) {
                        if (memberComments.service_score > 0) {
                            datas.put("serviceScore", SymbolUtils.queryPentagram(memberComments.service_score));
                        }
                        if (!TextUtils.isEmpty(memberComments.messages)) {
                            datas.put("commentsMessages", memberComments.messages);
                        }
                        if (!TextUtils.isEmpty(memberComments.tags)) {
                            datas.put("tags", memberComments.tags);
                        }
                    }
                }

                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(sellOrderItemDBModels)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(false)
                        .setWithDeptTransfer(true)
                        .build();
                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                    String deptID = entry.getKey();
                    List<PrintItemDataBean> list = entry.getValue();

                    // 过滤打印指定菜品
                    List<PrintItemDataBean> tarMenu = new ArrayList<>();
                    if (kds && !ListUtil.isEmpty(fastDishIdList)) {//KDS需要过滤，只能打印已经划菜的那些菜品
                        for (PrintItemDataBean bean : list) {
                            if (bean == null) {
                                continue;
                            }
                            if (fastDishIdList.contains(bean.fsseq)) {
                                tarMenu.add(bean);
                            }
                        }

                        if (ListUtil.isEmpty(tarMenu)) {
                            continue;
                        }
                    } else {
                        tarMenu.addAll(list);
                    }

                    DeptDBModel deptDBModel = processor.deptInfo.get(deptID);

                    int printNO = PrintJSONBuilder.generatePrintNO();//生成打印
                    if (kds) {
                        KDSUtils.updatePassPrintNoByDishId(kdsFastDishIds, deptID, printNO);
                    }

                    datas.put("fiPrintNo", printNO);
                    datas.put("mealNumber", orderCache.mealNumber);
                    datas.put("sellorder", tarMenu);
                    datas.put("Sub", sumQty(tarMenu, false, true));
                    datas.put("Dept", deptDBModel.fsDeptName);

                    if (!TextUtils.isEmpty(seq)) {
                        if (seq.contains(",")) {
                            datas.put("fsCreateUserName", orderCache.waiterName);
                        } else {
                            String waiterName = orderCache.optSeqModel(StringUtil.toInt(seq, 1)).createWaiterName;
                            if (TextUtils.isEmpty(waiterName)) {
                                waiterName = userDBModel.fsUserName;
                            }
                            datas.put("fsCreateUserName", waiterName);
                        }
                    } else {
                        datas.put("fsCreateUserName", orderCache.waiterName);
                    }

                    PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                            orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                            printNO,
                            model.createWaiterName,
                            deptID,
                            PrintReportId.THE_MENU,
                            hostId,
                            true);
                    if (TextUtils.equals("910", orderCache.fsBillSourceId)) {
                        task.uri = "meixiaodianOrder/passto";
                    } else {
                        task.uri = "fastFoodorder/passto";
                    }
                    task.fsPrnData = datas.toJSONString();
                    task.fsPrinterName = deptDBModel.fsPrinterName;

                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    if (!task.printAtOnce) {
                        printTaskIds.add(task.fiPrintNo);
                    }
                }
                return null;
            }
        });
        return printTaskIds;
    }
}