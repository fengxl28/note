package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.GenIDPosRequest;
import com.mwee.android.cashier.connect.bean.http.GenIDPosResponse;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.IMemberRefund;
import com.mwee.android.pos.business.netpay.RefundRequest;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundRequest;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.component.cross.net.CancelHungRequest;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.MemberBalanceRefundRequest;
import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessagePayBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Created by virgil on 2018/2/24.
 *
 * @author virgil
 */

public class CashierPayProcessor {
    public static final String TAG = CashierPayProcessor.class.getSimpleName();

    /**
     * 开始退款
     *
     * @param refreshOrderInfo boolean | 是否刷新订单信息
     * @param needPrint        boolean | 是否需要打印"退款回执单"
     * @param orderCache       OrderCache | 关联的订单信息
     * @param session          PaySession | 关联的支付信息
     * @param orderToken       String | 订单操作的Token
     * @param hostID           String | 站点ID
     * @param user             String | 操作的用户
     * @param payModel         PayModel | 选择的退款model
     * @param needVoidList     List<PayModel> | 关联的退款model
     * @return ist<Integer> | 打印的printno序列
     */
    public static Pair<List<Integer>, String> doCashierVoidPay(final boolean refreshOrderInfo, final boolean needPrint, final OrderCache orderCache, final PaySession session, String orderToken, String hostID, UserDBModel user, PayModel payModel, List<PayModel> needVoidList) {

        if (ListUtil.isEmpty(needVoidList)) {
            needVoidList.add(payModel);
            if (!ListUtil.isEmpty(payModel.secondPayList)) {
                needVoidList.addAll(payModel.secondPayList);
            }
            if (!ListUtil.isEmpty(payModel.subPayList)) {
                needVoidList.addAll(payModel.subPayList);
            }
        }
        BigDecimal totalVoidAmt = OrderUtil.recalTotalPaiedAmount(needVoidList, true);
        String thirdOrderID = "";
        StringBuilder sb = new StringBuilder();
        if (payModel.readRapid()) {
            RapidRefundRequest refundRequest = new RapidRefundRequest();
            refundRequest.orderId = payModel.businessInfo;
            if (refreshOrderInfo) {
                orderCache.rewardinfo = "";
                OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, "");
            }
            BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {

                }

                @Override
                public boolean fail(ResponseData responseData) {
                    sb.append(responseData.resultMessage);
                    return false;
                }
            }, false);

        } else if (PayType.isAliWeixin(payModel.data)) {
            RefundRequest refundRequest = new RefundRequest();
            refundRequest.pay_order = payModel.businessInfo;
            BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {

                }

                @Override
                public boolean fail(ResponseData responseData) {
                    sb.append(responseData.resultMessage);
                    return false;
                }
            }, false);
        } else if (PayType.isMWMemberBalance(payModel.data)) {
            final MemberBalanceRefundRequest refundRequest = new MemberBalanceRefundRequest();
            //这里需要传所有的金额
            refundRequest.amount = totalVoidAmt;
            refundRequest.card_no = payModel.memberCardNO;
            refundRequest.trade_no = payModel.memberOrderID;
            thirdOrderID = payModel.memberOrderID;
            refundRequest.reason = "";
            refundRequest.device_id = ServerHardwareUtil.getHardWareSymbol();
            BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {

                }

                @Override
                public boolean fail(ResponseData responseData) {
                    sb.append(responseData.resultMessage);
                    return false;
                }
            }, false);
        } else if (PayType.isMWMemberPoint(payModel.data) || PayType.isMWMemberTicket(payModel.data)) {
            MemberOrderRefundRequest refundRequest = BillUtil.startDoMemberRefund(needVoidList, session, false, payModel, new IMemberRefund() {
                @Override
                public void callBack(boolean result, String msg, MemberOrderRefundRequest request, boolean containsMemberDiscountFinal) {
                    if (refreshOrderInfo && containsMemberDiscountFinal) {
                        OrderUtil.recalcCouponCutWithPay(session, orderCache, false);
                    }
                }
            });
            if (refundRequest != null) {
                BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");

                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");

                        if (responseData.netResult == 0) {
                            if (responseData.resultMessage.contains("重复退款") || responseData.resultMessage.contains("重复的回调")) {
                                return false;
                            }
                        }
                        sb.append(responseData.resultMessage);
                        return false;
                    }
                }, false);
            }

        } else if (PayType.isHung(payModel.data)) {
            CancelHungRequest cancelHungRequest = new CancelHungRequest();
            cancelHungRequest.creditOrderId = payModel.businessInfo;
            BusinessExecutor.execute(cancelHungRequest, null, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {

                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    RunTimeLog.addLog(RunTimeLog.PAY_HUNG, responseData.resultMessage, "取消在线挂账 任务执行失败", cancelHungRequest);
                    sb.append(responseData.resultMessage);
                    return false;
                }
            }, true);
//            BillUtil.selectHung(orderToken, orderCache.orderID, user, hostID, true, payModel.creditAccountID, "", payModel.payAmount);
        }
        List<Integer> printNoList = null;
        if (needPrint) {
            printNoList = PrintBillUtil.printPayVoid(orderCache.orderID, thirdOrderID, "", needVoidList, hostID);
        }
        String error = "";
        return new Pair<>(printNoList, error);
    }

    /**
     * 纯收银扫码构建菜品支付 ，上报
     *
     * @param msgDes
     */
    public static void msyRapidOnlyPay(String msgDes) {
        try {
            MessagePayBean messagePayBean = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from message " +
                    "where msgDes = '" + msgDes + "'", MessagePayBean.class);
            if (messagePayBean == null) {
                LogUtil.logBusiness(TAG, "未查询到收银记录");
                return;
            }

            if (!messagePayBean.isUnDeal()) {
                LogUtil.logBusiness(TAG, "该消息已被处理");
                return;
            }
            RapidPayment rapidPayment = JSON.parseObject(messagePayBean.msgBody, RapidPayment.class);
            if (rapidPayment == null || ListUtil.isEmpty(rapidPayment.paymentList)) {
                LogUtil.logBusiness(TAG, "秒付信息异常");
                return;
            }

            BigDecimal payAmt = new BigDecimal(messagePayBean.payAmt());
            MenuItem menuItem = getMsyCashierMenu(payAmt);

            GenIDPosRequest genIDRequest = new GenIDPosRequest();
            BusinessExecutor.execute(genIDRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GenIDPosResponse) {
                        GenIDPosResponse response = (GenIDPosResponse) responseData.responseBean;
                        if (response.data != null && !TextUtils.isEmpty(response.data.orderNum)) {

                            UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
                            OrderCache orderCache = FastFoodBusinessUtil.createNewOrderCache(response.data.orderNum, userDBModel.fsUserId, userDBModel.fsUserName, HostBiz.CASHIER, "1");
                            orderCache.fiSellType = 3;//表示纯收银
                            orderCache.mealNumber = "1";
                            orderCache.originMenuList.add(menuItem);
                            orderCache.whetherRound = false;
                            orderCache.reCalcAllByAll();

                            //重新生成Token
                            String token = ServerCache.getInstance().generateNewToken(response.data.orderNum);
                            RapidActionModel rapidActionModel = new RapidActionModel();
                            PayModel parentPay = RapidBiz.buildRapidPayModel(orderCache, rapidPayment, new RapidActionModel());
                            if (parentPay == null) {
                                LogUtil.logBusiness(TAG, rapidActionModel.errorInfo);
                                return;
                            }

                            SocketResponse<PayResultResponse> socketResponse = BillUtil.addPayDetail(token, orderCache.orderID, userDBModel, HostBiz.CASHIER, parentPay);
                            if (!socketResponse.success()) {
                                LogUtil.logBusiness(TAG, socketResponse.message);
                                return;
                            }

                            orderCache.receiptName = rapidPayment.receiptName;
                            orderCache.receiptType = rapidPayment.receiptType;
                            orderCache.taxNo = rapidPayment.taxNo;
                            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "msyRapidOnlyPay");
                            OrderSaveDBUtil.updateTax(orderCache.orderID, rapidPayment.receiptType, rapidPayment.receiptName, rapidPayment.taxNo);

                            SocketResponse<PayResultResponse> resultResponse = BillUtil.startFinalPayProcess(token, orderCache.orderID, userDBModel, HostBiz.CASHIER, false, true);
                            PaySession paySession = OrderSession.getInstance().getPay(orderCache.orderID);
                            CashierOrderProcessor.submitCacheOrder(orderCache, paySession, userDBModel, HostBiz.CASHIER);
                            if (resultResponse.success()) {
                                Map<String, String> map = new HashMap<>();
                                map.put("tableName", orderCache.fsmtablename);  //桌台名称
                                map.put("payAmt", Calc.formatShow(payAmt));  //已支付金额
                                map.put("allAmt", Calc.formatShow(orderCache.optTotalPrice()));  //订单总金额
                                //将秒付纯收银消息置为已处理
                                MessageDBUtil.updateRapidOnlyPayMessageByMsgDes(msgDes, MessageConstance.MessagePayBuinessStatus
                                        .RAPID_ONLY_PAY.DOWN, userDBModel, orderCache.orderID, orderCache.fsmtableid, JSON
                                        .toJSONString(map));
                            }
                            return;
                        }
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "纯收银 GenIDPosRequest请求失败", "", responseData.responseBean);
                    return false;
                }
            }, false);
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    /**
     * 获取美收银纯收银菜品
     *
     * @param price
     * @return
     */
    public static MenuItem getMsyCashierMenu(BigDecimal price) {
        /**
         * 纯收银的菜品
         */
        MenuItem cashierMenu = MenuItemDBUtils.buildCashierMenu();
        if (cashierMenu == null) {
            return null;
        }
        cashierMenu.menuBiz.uniq = UUIDUtil.optUUID();
        cashierMenu.menuBiz.buyNum = BigDecimal.ONE;
        cashierMenu.menuBiz.orderSeqID = 1;
        //改变菜品售价为应收金额  挂到订单上
        cashierMenu.currentUnit.fdSalePrice = price;
        cashierMenu.currentUnit.fdVIPPrice = price;
        cashierMenu.calcTotal(false);

        return cashierMenu;
    }

}
