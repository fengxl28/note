package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.discount.GetAllDiscountManagerInfoResponse;
import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AirDiscountDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2017/10/18.
 * <p>
 * 折扣管理相关操作
 */
@SuppressWarnings("unused")
public class AirDiscountManagerDriver implements IDriver {

    private static final String TAG = "airDiscountManagerDriver";

    /**
     * 获取所有折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAllDiscount")
    public SocketResponse optAllDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 修改折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateDiscount")
    public SocketResponse updateDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            DiscountManagerInfo discountManagerInfo = JSON.parseObject(request.getString("discountManagerInfo"), DiscountManagerInfo.class);

            if (discountManagerInfo == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.updateDiscount(discountManagerInfo, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改餐区成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 新增折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/addDiscount")
    public SocketResponse addDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            DiscountManagerInfo discountManagerInfo = JSON.parseObject(request.getString("discountManagerInfo"), DiscountManagerInfo.class);

            if (discountManagerInfo == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.addDiscount(discountManagerInfo, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 批量删除折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/batchDeleteDiscount")
    public SocketResponse batchDeleteDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayList<String> discountIdList = (ArrayList<String>) JSON.parseArray(request.getString("discountIdList"), String.class);
            if (ListUtil.isEmpty(discountIdList)) {
                response.message = "请选择要删除的折扣";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.batchDeleteDiscount(discountIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除折扣成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}

