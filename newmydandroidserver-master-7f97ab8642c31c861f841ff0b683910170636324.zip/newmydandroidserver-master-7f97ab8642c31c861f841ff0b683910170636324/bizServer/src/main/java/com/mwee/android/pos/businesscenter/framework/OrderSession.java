package com.mwee.android.pos.businesscenter.framework;

import android.os.SystemClock;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.LruCache;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.alp.Ack;
import com.mwee.android.alp.AckStatus;
import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.businesscenter.business.order.MenuItemCouponProcessor;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderCacheImmutable;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 订单缓存，所有订单操作需要加锁，锁通过这个方法获得{@link }
 * Created by virgil on 2017/7/11.
 */
public class OrderSession extends Cache {

    public static final String TAG = OrderSession.class.getSimpleName();

    private final static OrderSession instance = new OrderSession();
    /**
     * use {@link OrderSession#mOrderMap}
     */
//    @Deprecated
//    private ArrayMap<String, OrderCache> orderMap = new ArrayMap<>();
    /**
     * use {@link OrderSession#mPayMap}
     */
    @Deprecated
    private ArrayMap<String, PaySession> payMap = new ArrayMap<>();

    /**
     * 缓存最大数量
     */
    private final static int MAX_CACHE_SIZE = 60;

    private LinkedHashMap<String, OrderCache> mOrderMap = new LinkedHashMap<String, OrderCache>(0, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Entry<String, OrderCache> eldest) {
            if (size() > MAX_CACHE_SIZE) {
                StringBuilder sb = new StringBuilder("order map 超出缓存上限, 删除缓存中的 orderCache. ");
                if (eldest.getValue() == null) {
                    sb.append("orderCache is NULL.");
                } else {
                    sb.append("\n" + JSON.toJSONString(eldest.getValue()));
                    // 移出缓存后，立即写入数据库，避免数据丢失
                    OrderSaveDBUtil.saveOnly(eldest.getValue().orderID, eldest.getValue(), false);
                }
                LogUtil.logBusiness(TAG, sb.toString());
                return true;
            }
            return false;
        }
    };

    private LinkedHashMap<String, PaySession> mPayMap = new LinkedHashMap<String, PaySession>(0, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Entry<String, PaySession> eldest) {
            if (size() > MAX_CACHE_SIZE) {
                StringBuilder sb = new StringBuilder("pay map 超出缓存上限, 删除缓存中的 paySession. ");
                if (eldest.getValue() == null) {
                    sb.append("paySession is NULL.");
                } else {
                    sb.append("\n" + JSON.toJSONString(eldest.getValue()));
                    // 移出缓存后，立即写入数据库，避免数据丢失
                    PaySaveDBUtil.save(eldest.getValue().orderID, eldest.getValue());
                }
                LogUtil.logBusiness(TAG, sb.toString());
                return true;
            }
            return false;
        }
    };

    /**
     * 订单最后操作时间
     * key - orderID
     * value - timestamp
     */
    private ArrayMap<String, Long> optTimeMap = new ArrayMap<>();

    private ILoopCall mCall = () -> {
        if (optTimeMap != null && optTimeMap.size() > 0) {
            for (String orderId : optTimeMap.keySet()) {
                Long optTime = optTimeMap.get(orderId);//todo 为null
                if (optTime != null) {
                    long timestamp = optTimeMap.get(orderId);
                    if (SystemClock.elapsedRealtime() - timestamp > 5 * 60 * 1000) {

                        OrderCache cache = mOrderMap.get(orderId);
                        if (cache != null && OrderStatus.PAIED == cache.orderStatus) {
                            mOrderMap.remove(orderId);
                        }

                        PaySession session = mPayMap.get(orderId);
                        if (session != null && session.payed == 1) {
                            mPayMap.remove(orderId);
                        }

                        if (!mOrderMap.containsKey(orderId) && !mPayMap.containsKey(orderId)) {
                            optTimeMap.remove(orderId);
                        }
                    }
                }
            }
        }
        LogUtil.log("OrderSession Loop Clear[" + SystemClock.elapsedRealtime() + "]:\nOrder Size: " + mOrderMap.size() + "\nPay Size: " + mPayMap.size());
    };

    private OrderSession() {
        GlobalLooper.registBasedOn2Minutes(mCall, 1);
    }

    public static OrderSession getInstance() {
        return instance;
    }

    public static String getTableID(String orderID) {
        OrderCache orderCache = getInstance().getOrder(orderID);
        if (orderCache != null) {
            return orderCache.fsmtableid;
        }
        return "";
    }

    public static void updateOrderStatus(final String orderID, final int status) {
        String fsmtableId = instance.getTableId(orderID);

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 更新订单状态 " + status);
        try {
            OrderCache orderCache = instance.getOrder(orderID);
            if (orderCache != null) {
                orderCache.orderStatus = status;
            }
            OrderSaveDBUtil.updateOrderStatus(orderID, status);
            LogUtil.logBusiness("orderSession-updateOrderStatus-orderID:" + orderID + ",status:" + status);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 更新订单状态 " + status);
        }
    }

    /**
     * 更新order_cache表里的反结数量
     * 更新tbsell表里的订单状态，同时lver+1
     *
     * @param orderID String | 订单号
     */
    public static void updateAntiCount(final String orderID) {
        String fsmtableId = getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 更新order_cache表里的反结数量 ");
        try {

            OrderCache orderCache = instance.getOrder(orderID);
            if (orderCache != null) {
                OrderSaveDBUtil.updateAntiCount(orderID, orderCache.antiPayCount);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 更新order_cache表里的反结数量 ");
        }
    }

    public static void setPayed(String orderID, int payed) {
        String fsmtableId = getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 设置支付状态 " + payed);
        try {

            PaySession session = instance.getPay(orderID);
            if (session != null) {
                session.payed = payed;
            }
            PaySaveDBUtil.setPayed(orderID, payed);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 设置支付状态 " + payed);
        }
    }

    @Override
    public void refresh() {

    }

    @Override
    public void clean() {

    }

//    private Object getLock(String orderID) {
//        OrderCache orderCache = orderMap.get(orderID);
//        String tableID = "";
//        if (orderCache == null) {
//            tableID = OrderSaveDBUtil.getTableIDByOrderID(orderID);
//        } else {
//            tableID = orderCache.fsmtableid;
//        }
//        return ServerCache.getLock(tableID);
//
//    }

    private String getTableId(String orderID) {
        OrderCache orderCache = mOrderMap.get(orderID);
        String tableID = "";
        if (orderCache == null) {
            tableID = OrderSaveDBUtil.getTableIDByOrderID(orderID);
        } else {
            tableID = orderCache.fsmtableid;
        }
        return tableID;

    }

    public OrderCache getOrder(String orderID) {
        OrderCache orderCache = mOrderMap.get(orderID);
        String fsmtableid = getTableId(orderID);
        if (TextUtils.isEmpty(fsmtableid)) {
//            LogUtil.logError("--order--getOrder--fsmtableid:" + fsmtableid + "--orderID:" + orderID);
        }
        if (orderCache == null) {
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableid, orderID, " 获取订单 ");
            try {

                orderCache = mOrderMap.get(orderID);
                if (orderCache == null) {
                    orderCache = OrderSaveDBUtil.get(orderID);
                    if (orderCache != null) {
                        MenuItemCouponProcessor.checkMemberCouponWriteoffStat(orderCache.originMenuList, null, null);
                        orderCache.reCalcAllByAll();
                        LogUtil.logBusiness("OrderSession 获取订单: " + orderID + ", totalPrice=" + orderCache.totalPrice);
                    }
                    mOrderMap.put(orderID, orderCache);
                }
                optTimeMap.put(orderID, SystemClock.elapsedRealtime());
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableid, orderID, " 获取订单 ");
            }
        }

        return orderCache;
    }

    public PaySession getPay(String orderID) {
        PaySession paySession = mPayMap.get(orderID);
        if (paySession == null) {
            String fsmtableId = getTableId(orderID);
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 获取支付信息 ");
            try {
                paySession = mPayMap.get(orderID);
                if (paySession == null) {
                    paySession = PaySaveDBUtil.get(orderID);
                    mPayMap.put(orderID, paySession);
                }
                optTimeMap.put(orderID, SystemClock.elapsedRealtime());
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 获取支付信息 ");
            }
        }
        return paySession;
    }

    /**
     * 更新缓存中的订单
     *
     * @param orderCache
     */
    public void refreshCacheOrder(OrderCache orderCache) {

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, " 更新缓存中的订单 ");
        try {

            mOrderMap.put(orderCache.orderID, orderCache);
            optTimeMap.put(orderCache.orderID, SystemClock.elapsedRealtime());
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, " 更新缓存中的订单 ");
        }
    }

    /**
     * @param orderID
     * @param withReport
     */
    public void writeOrder(String orderID, boolean withReport, String operation) {
        String fsmtableId = getTableID(orderID);

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "writeOrder by " + operation);
        try {
            OrderCache orderCache = mOrderMap.get(orderID);
            if (orderCache != null) {
                LogUtil.logBusiness("OrderSession 写订单: " + orderID + ", totalPrice=" + orderCache.totalPrice);
                OrderSaveDBUtil.saveOnly(orderID, orderCache, false);
                if (withReport) {
                    OrderProcessor.saveOrder(orderCache, null);
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "writeOrder by " + operation);
        }
    }

    /**
     * refresh 缓存 并 存储数据库
     **/
    public void writeOrder(String orderID, OrderCache orderCache, boolean withReport, String operation) {

        String fsmtableId = getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "writeOrder by " + operation);
        try {
            mOrderMap.put(orderID, orderCache);
            optTimeMap.put(orderID, SystemClock.elapsedRealtime());

            if (orderCache != null) {
                LogUtil.logBusiness("OrderSession 写订单: " + orderID + ", totalPrice=" + orderCache.totalPrice);
                OrderSaveDBUtil.saveOnly(orderID, orderCache, false);
                if (withReport) {
                    OrderProcessor.saveOrder(orderCache, null);
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "writeOrder by " + operation);
        }
    }

    /**
     * 生成PaySession
     *
     * @param order       OrderCache | 订单
     * @param userDBModel UserDBModel | 服务员
     * @param hostID      String | 站点ID
     */
    public PaySession generatePaySession(OrderCache order, UserDBModel userDBModel, String hostID, String billNO) {

        PaySession paySession;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(order.fsmtableid, order.orderID, " 生成PaySession ");
        try {

            paySession = getPay(order.orderID);
            if (paySession == null) {
                paySession = OrderUtil.buildPayCache(null, order, billNO, hostID, userDBModel.fsUserId, userDBModel.fsUserName);
                PaySaveDBUtil.save(order.orderID, paySession);
            } else {
                paySession = OrderUtil.buildPayCache(paySession, order, paySession.billNO, hostID, userDBModel.fsUserId, userDBModel.fsUserName);
            }
            mPayMap.put(order.orderID, paySession);
            optTimeMap.put(order.orderID, SystemClock.elapsedRealtime());
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, order.fsmtableid, order.orderID, " 生成PaySession ");
        }
        return paySession;
    }

    /**
     * 生成PaySession
     *
     * @param order       OrderCache | 订单
     * @param userDBModel UserDBModel | 服务员
     * @param hostID      String | 站点ID
     */
    public PaySession generatePaySession(OrderCache order, UserDBModel userDBModel, String hostID) {
        PaySession paySession;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(order.fsmtableid, order.orderID, " 生成PaySession ");
        try {
            paySession = getPay(order.orderID);
            if (paySession == null) {

                String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                String billNO = OrderDriver.generateNewID(shopId, OrderDriver.KEY_BILL);
                paySession = OrderUtil.buildPayCache(null, order, billNO, hostID, userDBModel.fsUserId, userDBModel.fsUserName);
                PaySaveDBUtil.save(order.orderID, paySession);
            } else {
                paySession = OrderUtil.buildPayCache(paySession, order, paySession.billNO, hostID, userDBModel.fsUserId, userDBModel.fsUserName);
            }
            mPayMap.put(order.orderID, paySession);
            optTimeMap.put(order.orderID, SystemClock.elapsedRealtime());

        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, order.fsmtableid, order.orderID, " 生成PaySession ");
        }
        return paySession;
    }

    public void writePay(String orderID, PaySession session) {
        String fsmtableId = getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 写报表 ");
        try {
            mPayMap.put(orderID, session);
            optTimeMap.put(orderID, SystemClock.elapsedRealtime());
            if (session != null) {
                PaySaveDBUtil.save(orderID, session);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 写报表 ");
        }
    }

    public void writePay(String orderID) {
        writePay(orderID, false);
    }

    public void writePay(String orderID, boolean withReport) {
        String fsmtableId = getTableID(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 写报表 ");
        try {
            PaySession session = mPayMap.get(orderID);
            if (session != null) {
                PaySaveDBUtil.save(orderID, session);
                if (withReport) {
                    OrderProcessor.savePayOnly(session);
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 写报表 ");
        }
    }

    /**
     * 移除缓存
     *
     * @param orderID String
     */
    public void clearOrder(String orderID) {
        String fsmtableId = getTableId(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 移除缓存 ");
        try {
            mPayMap.remove(orderID);
            mOrderMap.remove(orderID);
            optTimeMap.remove(orderID);
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 移除缓存 ");
        }
    }

    public void clearAll() {
        mPayMap.clear();
        mOrderMap.clear();
        optTimeMap.clear();
    }

    /**
     * 添加打印结账单次数
     */
    public void updatePrintBillTimes(String databaseName, String orderID) {
        String fsmtableId = getTableID(orderID);
        PaySession paySession = mPayMap.get(orderID);
        if (paySession != null) {
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, " 添加打印结账单次数 ");
            try {
                paySession.printbill++;
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, " 添加打印结账单次数 ");
            }
        }
        OrderSaveDBUtil.updatePrintBillTimes(databaseName, orderID);
    }

    /**
     * 添加打印预结账单次数
     */
    public void updatePrintPreBillTimes(String orderID) {

        OrderCache orderCache = mOrderMap.get(orderID);
        if (orderCache != null) {
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderID, " 添加打印预结账单 ");
            try {

                orderCache.printPre++;
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderID, " 添加打印预结账单 ");
            }
        }
        OrderSaveDBUtil.updatePrintPreBillTimes(orderID);
    }

    public void processOrder(String orderId, IOrderExecute execute) {
        processOrder(orderId, execute, false);
    }

    /**
     * 处理订单
     *
     * @param orderId    订单号
     * @param execute
     * @param withReport 是否写入报表
     */
    public void processOrder(String orderId, IOrderExecute execute, boolean withReport) {
        OrderCache orderCache = getOrder(orderId);
        try {
            if (execute != null) {
                execute.execute(orderCache);
            }
        } finally {
            writeOrder(orderId, orderCache, withReport, "processOrder");
        }
    }

    public <T> T processOrderWithResult(String orderId, IOrderExecute<T> execute, boolean withReport) {
        OrderCache orderCache = getOrder(orderId);
        T result = null;
        try {
            if (execute != null) {
                result = execute.execute(orderCache);
            }
        } finally {
            writeOrder(orderId, orderCache, withReport, "processOrderWithResult");
        }
        return result;
    }

    /**
     * 获取一个只读的 OrderCache
     *
     * @param orderId 订单号
     * @return
     */
    public OrderCacheImmutable getOrderReadOnly(String orderId) {
        OrderCache orderCache = getOrder(orderId);
        if (orderCache == null) {
            return null;
        }
        return new OrderCacheImmutable(orderCache);
    }

    public void processOrderByTable(String tableNo, IOrderExecute execute, boolean withReport) {
        TableBizModel table = TableDBUtil.getTableBizModelById(tableNo);
        if (table == null) {
            return;
        }
        OrderCache orderCache = getOrder(table.fssellno);
        try {
            if (execute != null) {
                execute.execute(orderCache);
            }
        } finally {
            writeOrder(table.fssellno, orderCache, withReport, "processOrderByTable");
        }
    }

    public OrderCacheImmutable getOrderReadOnlyByTable(String tableNo) {
        TableBizModel table = TableDBUtil.getTableBizModelById(tableNo);
        if (table == null) {
            return null;
        }
        OrderCache orderCache = getOrder(table.fssellno);
        if (orderCache == null) {
            return null;
        }
        return new OrderCacheImmutable(orderCache);
    }
}
