package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.businesscenter.dbutil.ManualIEnvoiceDBUtil;
import com.mwee.android.pos.businesscenter.print.EInvoicePrintUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.setting.GetAllManualIEnvoiceResponse;
import com.mwee.android.pos.connect.business.setting.PrintManualIEnvoiceResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.ManualInvoicingDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * 电子发票--手动纯开票
 */

@SuppressWarnings("unused")
public class ManualEInvoiceDriver implements IDriver {
    public final static Object saveRapidLock = new Object();
    private static final String TAG = "manualEInvoiceDriver";

    /**
     * 获取所有的手动开发票数据
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "manualEInvoiceDriver/optDataFromServer")
    public static SocketResponse optDataFromServer(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            long time = System.currentTimeMillis();
            JSONObject request = JSON.parseObject(param);

            int currentPage = request.getIntValue("currentPage");
            String date = request.getString("date");

            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            if (TextUtils.isEmpty(date)) {
                date = DateUtil.getCurrentDate("yyyy-MM-dd");
            }

            if (currentPage <= 0) {
                currentPage = 1;
            }
            //一页数据条数
            int messageConuntOnePage = 10;

            GetAllManualIEnvoiceResponse respone = new GetAllManualIEnvoiceResponse();

            if (currentPage == 1){
                //第一页数据，需要刷新所有发票的开票状态
                EInvoiceProcess.updateManualEInvoceingStatus(date);
            }

            respone.manualInvoicingDBModels = ManualIEnvoiceDBUtil.optManualInvoicingDBModeList(currentPage, messageConuntOnePage, date);
            respone.allCount = ManualIEnvoiceDBUtil.optCount(-101, date);
            respone.finishedCount = ManualIEnvoiceDBUtil.optCount(20, date);
            respone.pageCount = (respone.allCount == 0 ? 0 : respone.allCount + messageConuntOnePage - 1) / messageConuntOnePage;

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "发票列表获取成功";
            socketResponse.data = respone;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError("手动开票 获取列表异常", e);
        }
        return socketResponse;
    }

    /**
     * 手动开发票
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "manualEInvoiceDriver/addManualEInvoice")
    public static SocketResponse addManualEInvoice(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            long time = System.currentTimeMillis();
            JSONObject request = JSON.parseObject(param);

            String amt = request.getString("amt");
            String date = request.getString("date");

            if (TextUtils.isEmpty(amt)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请输入开票金额";
                return socketResponse;
            }
            BigDecimal amount = null;
            try {
                amount = new BigDecimal(amt);
            } catch (NumberFormatException exception) {
                LogUtil.logError("手动开发票 开票金额异常 amt = " + amt, exception);
            }

            if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "开票金额要大于0元";
                return socketResponse;
            }

            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            if (TextUtils.isEmpty(date)) {
                date = DateUtil.getCurrentDate("yyyy-MM-dd");
            }
            PrintManualIEnvoiceResponse response = new PrintManualIEnvoiceResponse();

            ManualInvoicingDBModel manualInvoicingDBModel = ManualIEnvoiceDBUtil.addManualInvoicing(amount, user);
            response.printNoList = EInvoicePrintUtil.printManualEInvoice(manualInvoicingDBModel, head.hd, user );

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "纯手动开票成功";
            socketResponse.data = request;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError("手动开票 开票", e);
        }
        return socketResponse;
    }

    /**
     * 重印小票
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "manualEInvoiceDriver/reprintManualEInvoice")
    public static SocketResponse reprintManualEInvoice(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            long time = System.currentTimeMillis();
            JSONObject request = JSON.parseObject(param);

            String orderId = request.getString("orderId");

            if (TextUtils.isEmpty(orderId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "重印失败，请退出重试";
                return socketResponse;
            }

            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            PrintManualIEnvoiceResponse response = new PrintManualIEnvoiceResponse();

            response.printNoList = EInvoicePrintUtil.printManualEInvoice(orderId, head.hd, user);

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "重印发票成功";
            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError("手动开票 重印发票", e);
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}
