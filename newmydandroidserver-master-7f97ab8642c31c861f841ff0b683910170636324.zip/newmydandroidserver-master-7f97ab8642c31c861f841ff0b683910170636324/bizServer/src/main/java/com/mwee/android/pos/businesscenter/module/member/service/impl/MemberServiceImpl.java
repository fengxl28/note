package com.mwee.android.pos.businesscenter.module.member.service.impl;

import com.mwee.android.pos.businesscenter.business.koubei.future.ResultCallback;
import com.mwee.android.pos.businesscenter.module.member.net.MemberHttpExecutor;
import com.mwee.android.pos.businesscenter.module.member.service.IMemberService;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.List;

/**
 * 会员业务实现
 * Created by qinwei on 2019/3/12 2:10 PM
 * email: qin.wei@mwee.cn
 */
public class MemberServiceImpl implements IMemberService {
    @Override
    public SocketResponse<NewMemberCardDetailsModel> loadMemberDetailByCardNo(String companyId, String shopId, String cardNo) {
        SocketResponse<NewMemberCardDetailsModel> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberCardDetailsByCardNo(companyId, shopId, cardNo, new ResultCallback<NewMemberCardDetailsModel>() {
            @Override
            public void onSuccess(NewMemberCardDetailsModel data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }

    @Override
    public SocketResponse<List<NewMemberCardListItemModel>> loadMemberCardListByMobile(String companyId, String shopId, String mobile, String verifyCode, int verifyCodeType) {
        SocketResponse<List<NewMemberCardListItemModel>> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberCardListByMobile(companyId, shopId, mobile, verifyCode, verifyCodeType, new ResultCallback<List<NewMemberCardListItemModel>>() {
            @Override
            public void onSuccess(List<NewMemberCardListItemModel> data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }

    @Override
    public SocketResponse<MemberTradeDetailModel> loadMemberTradeDetail(String companyId, String cardNoOrMobile, int pageNo) {
        SocketResponse<MemberTradeDetailModel> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberTradeDetail(companyId, cardNoOrMobile, pageNo, new ResultCallback<MemberTradeDetailModel>() {
            @Override
            public void onSuccess(MemberTradeDetailModel data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }

    @Override
    public SocketResponse<MemberScoreDetailModel> loadMemberScore(String brandId, String cardNoOrMobile, int pageNo) {
        SocketResponse<MemberScoreDetailModel> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberScore(brandId, cardNoOrMobile, pageNo, new ResultCallback<MemberScoreDetailModel>() {
            @Override
            public void onSuccess(MemberScoreDetailModel data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }

    @Override
    public SocketResponse<MemberCouponsDetailModel> loadMemberCoupons(String brandId, String cardNo, int pageNo) {
        SocketResponse<MemberCouponsDetailModel> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberCoupons(brandId, cardNo, pageNo, new ResultCallback<MemberCouponsDetailModel>() {
            @Override
            public void onSuccess(MemberCouponsDetailModel data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }

    @Override
    public SocketResponse<MemberPrivateDetailModel> loadMemberPrivate(String brandId, String csId, int memberLevel, String storeId, String cardNo) {
        SocketResponse<MemberPrivateDetailModel> response = new SocketResponse<>();
        MemberHttpExecutor.loadMemberPrivate(brandId, csId, memberLevel, storeId, cardNo, new ResultCallback<MemberPrivateDetailModel>() {
            @Override
            public void onSuccess(MemberPrivateDetailModel data) {
                response.code = SocketResultCode.SUCCESS;
                response.data = data;
            }

            @Override
            public void onFailure(int code, String msg) {
                response.code = code;
                response.message = msg;
            }
        });
        return response;
    }
}
