package com.mwee.android.pos.businesscenter.print;

import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Pair;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.constants.CouponId;
import com.mwee.android.pos.business.constants.CouponType;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.print.*;
import com.mwee.android.pos.business.rapid.api.bean.model.EatType;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.einvoice.PrintBillFrom;
import com.mwee.android.pos.businesscenter.air.dbUtil.component.HostStatusDBUtils;
import com.mwee.android.pos.businesscenter.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.businesscenter.business.koubei.future.KBFutureProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.TableQRProcess;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.print.air.AirPrinterSelect;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.order.InvoiceState;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.report.model.AllDiscountReportTempModel;
import com.mwee.android.pos.db.business.report.model.DishCouponReportModel;
import com.mwee.android.pos.util.FormatUtil;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 结账相关的打印数据构造类
 * Created by virgil on 2017/1/22.
 *
 * @author virgil
 */

public class PrintBillUtil {

    public static List<Integer> printDinnerBill(final String orderID, final String printerName, final String hostId, boolean fromAntiPay, final UserDBModel user) {
        return printDinnerBill(orderID, null, printerName, hostId, fromAntiPay, user, APPConfig.DB_MAIN);
    }

    /**
     * 打印正餐结账单
     *
     * @param orderID      订单id
     * @param memberInfo   结账单会员信息
     * @param printerName  打印机名称
     * @param hostId       站点id
     * @param fromAntiPay  是否是反结账
     * @param user         用户
     * @param databaseName 从库/主库
     * @return
     */
    public static List<Integer> printDinnerBill(final String orderID, MemberInfo memberInfo, final String printerName, final String hostId, boolean fromAntiPay, final UserDBModel user, String databaseName) {

        //加入打印开关，适用于正餐和快餐的结账单
        if (!isAllowToPrint(orderID)) {
            return Collections.emptyList();
        }
        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }

        OrderSession.getInstance().updatePrintBillTimes(databaseName, orderID);
        List<Integer> printTaskIds = new ArrayList<>();

//
//        JSONObject datas = new JSONObject();
//
//        CustomSellDBModel sell = DBSimpleUtil.query(databaseName, "select tbSell.*,(tbSell.fdSaleAmt+tbSell.fdRoundAmt)as fdSaleAmt,tbSellCheck.fiPrintTimes,tbSellCheck.fsUpdateUserName as cashiername,tbSellCheck.fsShiftName as shiftname from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fsSellNo ='" + orderID + "'", CustomSellDBModel.class);
//        if (sell != null) {
//            if (TextUtils.isEmpty(sell.shiftname)) {
//                String fsShiftId = DBSimpleUtil.queryString(databaseName, "select fsShiftId from  tbSellCheck where fsSellNo='" + sell.fssellno + "'");
//                sell.shiftname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftName from tbshift where fsShiftId='"+fsShiftId+"' and fiStatus='1'");
//            }
//            datas.put("Shop", DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class));
//            datas.put("Sell", sell);
//            //会员卡信息
//            if (memberInfo != null) {
//                datas.put("memberInfo", memberInfo);
//            }
//
//            JSONObject map = new JSONObject();
//
//            String date = sell.fsSellDate;
//            datas.put("titleSubFix", fromAntiPay ? "(反结单)" : "");
//            map.put("total", sell.fdSaleAmt.subtract(sell.fdRoundAmt));
//            datas.put("Sub", map);
//
//            String statisticsDiscountSql = "select fsDiscountName,sum(fdDiscountAmt) as discountamt  from tbsellorderitem " +
//                    " where fsSellNo='" + orderID +
//                    "' and fsSellDate='" + date +
//                    "' and fiOrderMode=1" +
//                    "  and fiOrderItemKind!=3" +
//                    "  and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0))" +
//                    "  and fiIsDiscount=1" +
//                    "  and fsDiscountId!=''  group by fsDiscountId having discountamt>0";
//            List<JSONObject> statisticsDiscounts = DBSimpleUtil.queryJsonList(databaseName, statisticsDiscountSql);
//            if (statisticsDiscounts != null && statisticsDiscounts.size() > 0) {
//                datas.put("statisticsDiscount", statisticsDiscounts);
//            }
//            datas.put("fddiscountamt", sell.fdDiscountAmt);
//            if (sell.fdRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
//                datas.put("fdroundamt", "" + sell.fdRoundAmt);
//            }
//
////                    fsPaymentName
//            List<StatementSellReceiveModel> sellorder = DBSimpleUtil.queryList(databaseName, "select *, fsPaymentName paymentname from tbSellReceive where fsSellNo = '" + orderID + "' and fsSellDate='" + date + "'" + " and fiStatus<>'13' ", StatementSellReceiveModel.class);
//            if (sellorder == null) {
//                sellorder = new ArrayList<>();
//            }
//            for (int i = 0; i < sellorder.size(); i++) {
//                StatementSellReceiveModel temp = sellorder.get(i);
//                temp.paymentname=temp.paymentname+":";
//                String memberScoreCostStr = temp.fsbackup2;
//                String cardInfo = "(卡号:" + FormatUtil.formatMemberCardNo(temp.fsMemCardNo) + ")";
//                if (!TextUtils.isEmpty(temp.fsMemCardNo)) {
//                    if (TextUtils.equals("95002", temp.fspaymentid)) {
//                        if (TextUtils.isEmpty(memberScoreCostStr) || TextUtils.equals("0", memberScoreCostStr)) {
//                            temp.paymentname=temp.paymentname+ "抵扣" ;
//                            temp.fsNote="元" + cardInfo ;
//                        } else {
//                            temp.paymentname=temp.paymentname+ "使用" + memberScoreCostStr + "积分,抵扣"  ;
//                            temp.fsNote="元" + cardInfo ;
//                        }
//                    } else if (TextUtils.equals("95001", temp.fspaymentid)) {
//                        temp.fsNote=cardInfo;
//                    }
//                }
//                BigDecimal change = temp.fdPayMoney.subtract(temp.fdReceMoney);
//                if (change.compareTo(BigDecimal.ZERO) > 0) {
//                    StatementSellReceiveModel changeReceive = new StatementSellReceiveModel();
//                    changeReceive.paymentname = "找零:";
//                    temp.fdPayMoney = temp.fdReceMoney;
//                    changeReceive.fdPayMoney = change;
//                    sellorder.add(i, changeReceive);
//                }
//                //添加预付金到备注里
//                if ((temp.fiThirdType & 2) == 2) {
//                    temp.fsNote = temp.fsNote + "," + "预付金";
//                }
//            }
//            datas.put("SellReceive", sellorder);
//            JSONObject SysMode = new JSONObject();
//            SysMode.put("PrintTime", DateUtil.getCurrentTime());
//            datas.put("SysMode", SysMode);
//
//            String sql = "select *, (case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName  || '(' || fsOrderUint || ')' as fsItemName, " +
//                    "(case fdGiftQty when 0 then '' else '[Free]' end)|| (case fsItemName2 when '' then fsItemName else fsItemName2 end) as fsItemName2," +
//                    "(fdSaleQty-fdBackQty) as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
//                    " where fsSellNo = '" + orderID + "'" +
//                    " and fiOrderItemKind <> '3'" +
//                    " and fiOrderMode in (1,3)" +
//                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
//                    " and fsSellDate='" + date + "'";
//
//            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName, (fdSaleQty-fdBackQty) as  qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
//                    " where fsSellNo = '" + orderID + "'" +
//                    " and fiOrderItemKind = '3' " +
//                    " and fiOrderMode in (1,3)" +
//                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
//                    " and fsSellDate='" + date + "'";
//
//            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
//            if (sellOrderItemDBModels == null) {
//                sellOrderItemDBModels = new ArrayList<>();
//            }
//
//            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
//            if (SLITList == null) {
//                SLITList = new ArrayList<>();
//            }
//
//            BigDecimal qty = BigDecimal.ZERO;
//            for (StatementSellItemModel statementSellItemModel : sellOrderItemDBModels) {
//
//                if (statementSellItemModel.fiIsEditQty == 1) { //称重菜算一份
//                    qty = qty.add(BigDecimal.ONE);
//                } else {
//                    qty = qty.add(statementSellItemModel.qty);
//                }
//
//                for (StatementSellItemModel itemExModel : SLITList) {
//                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
//                        statementSellItemModel.SLIT.add(itemExModel);
//                    }
//                }
//            }
//
//            map.put("qty", qty);
//            datas.put("printUserName", printUserName);
//            List<StatementSellItemModel> allVoidSellItems = findAllVoidCompletedSellItems(orderID, date,databaseName);
//            if (!ListUtil.isEmpty(allVoidSellItems)) {
//                sellOrderItemDBModels.addAll(allVoidSellItems);
//            }
//
//            if (ListUtil.isEmpty(sellOrderItemDBModels)) {
//                RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "终止打印结账单，没有查到有效菜品, orderID = " + orderID);
//                return printTaskIds;
//            }
//
//            datas.put("sellorder", turnToPrintMode(mergeMenuItem(sellOrderItemDBModels)));
//            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
//            String printBillCut = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_CUT, "0");
//            if (!TextUtils.equals(printBillCut, "0")) {
//                printBillCut = "1";
//            }
//            datas.put("printBillCut", printBillCut);
//
//            if (DBPrintConfig.needPrintMWAD()) {
//                datas.put("reportTail", "本服务由美味不用等提供");
//            } else {
//                datas.put("reportTail", "");
//            }
//
//            //处理结账单的打印份数
//            String printCountConfig = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbhostexternal where fiCls = '4' and fsHostId = '" + hostId + "'");
//            int printCountNum = StringUtil.toInt(printCountConfig, 1);
//            if (printCountNum < 1) {
//                printCountNum = 1;
//            }
//            String fsPrinterName = printerName;
//            if (TextUtils.isEmpty(fsPrinterName) && !TextUtils.isEmpty(hostId)) {
//                if (TextUtils.equals(hostId, HostBiz.mealorder)) {
//                    fsPrinterName = PrintConnector.getInstance().getCurrentHostPrinterName();
//                } else {
//                    fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
//                }
//            }
//            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, sell.fsMTableName, sell.fsSellDate, 0, sell.cashiername, "0", PrintReportId.STATEMENT, hostId, true);
//            task.uri = "bill/orderbill";
//            task.fsPrinterName = fsPrinterName;
//            for (int i = 0; i < printCountNum; i++) {
//                if (i > 0) {
//                    OrderSession.getInstance().updatePrintBillTimes(databaseName,orderID);
//                    sell.fiPrintTimes++;
//                    datas.put("Sell", sell);
//                }
//                task.fsPrnData = null;
//                task = task.clone();
//                task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
//                datas.put("fiPrintNo",task.fiPrintNo);
//
//                task.fsPrnData = datas.toJSONString();
//                task.fsPrinterName = fsPrinterName;
//                MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
//    //                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//    //                if (!task.printAtOnce) {
//    //                    printTaskIds.add(task.fiPrintNo);
//    //                }
//            }
//        }
//        return printTaskIds;


        PrintTaskDBModel task = getDinnerBillData(orderID, memberInfo, printerName, hostId, fromAntiPay, user, databaseName);
        if (task == null) {
            return printTaskIds;
        }

        //处理结账单的打印份数
        String printCountConfig = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbhostexternal where fiCls = '4' and fsHostId = '" + hostId + "'");
        int printCountNum = StringUtil.toInt(printCountConfig, 1);
        if (printCountNum < 1) {
            printCountNum = 1;
        }
        JSONObject datas = JSON.parseObject(task.fsPrnData);
        CustomSellDBModel sell = JSONObject.parseObject(datas.getString("Sell"), CustomSellDBModel.class);

        for (int i = 0; i < printCountNum; i++) {
            if (i > 0) {
                OrderSession.getInstance().updatePrintBillTimes(databaseName, orderID);
                if (sell != null) {
                    sell.fiPrintTimes++;
                    datas.put("Sell", sell);
                }
            }
            task.fsPrnData = null;
            task = task.clone();
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);

            task.fsPrnData = datas.toJSONString();
            MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
        }
        return printTaskIds;
    }

    /**
     * 获取正餐结账单数据
     *
     * @param orderID      订单id
     * @param memberInfo   结账单会员信息
     * @param printerName  打印机名称
     * @param hostId       站点id
     * @param fromAntiPay  是否是反结账
     * @param user         用户
     * @param databaseName 从库/主库
     * @return
     */
    public static PrintTaskDBModel getDinnerBillData(final String orderID, MemberInfo memberInfo, final String printerName, final String hostId, boolean fromAntiPay, final UserDBModel user, String databaseName) {

        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }
        JSONObject datas = new JSONObject();

        CustomSellDBModel sell = DBSimpleUtil.query(databaseName, "select tbSell.*,(tbSell.fdSaleAmt+tbSell.fdRoundAmt)as fdSaleAmt,tbSellCheck.fiPrintTimes,tbSellCheck.fsUpdateUserName as cashiername,tbSellCheck.fsShiftName as shiftname from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fsSellNo ='" + orderID + "'", CustomSellDBModel.class);
        if (sell != null) {
            if (TextUtils.isEmpty(sell.shiftname)) {
                String fsShiftId = DBSimpleUtil.queryString(databaseName, "select fsShiftId from  tbSellCheck where fsSellNo='" + sell.fssellno + "'");
                sell.shiftname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftName from tbshift where fsShiftId='" + fsShiftId + "' and fiStatus='1'");
            }
            datas.put("Shop", DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class));
            datas.put("Sell", sell);
            //会员卡信息
            if (memberInfo != null) {
                datas.put("memberInfo", memberInfo);
            }

            JSONObject map = new JSONObject();

            String date = sell.fsSellDate;
            datas.put("titleSubFix", fromAntiPay ? "(反结单)" : "");
            map.put("total", sell.fdSaleAmt.subtract(sell.fdRoundAmt));
            datas.put("Sub", map);

            String statisticsDiscountSql = "select fsDiscountName,sum(fdDiscountAmt) as discountamt  from tbsellorderitem " +
                    " where fsSellNo='" + orderID +
                    "' and fsSellDate='" + date +
                    "' and fiOrderMode=1" +
                    "  and fiOrderItemKind!=3" +
                    "  and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0))" +
                    //不可折扣的菜 也可能打折（3.0需求）
//                    "  and fiIsDiscount=1" +
                    "  and fsDiscountId!=''  group by fsDiscountId having discountamt>0";
            List<JSONObject> statisticsDiscounts = DBSimpleUtil.queryJsonList(databaseName, statisticsDiscountSql);
            if (statisticsDiscounts != null && statisticsDiscounts.size() > 0) {
                datas.put("statisticsDiscount", statisticsDiscounts);
            }
            datas.put("fddiscountamt", sell.fdDiscountAmt);
            if (sell.fdRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
                datas.put("fdroundamt", "" + sell.fdRoundAmt);
            }

            // 优惠明细，2.9小票模版用
            Pair<BigDecimal, List<JSONObject>> pair = getSellCouponDetails(databaseName, orderID, date, false);
            List<JSONObject> sellCouponDetails = pair.second;
            if (sellCouponDetails != null && sellCouponDetails.size() > 0) {
                datas.put("sellCouponDetails", sellCouponDetails);
            }
            // 优惠合计，2.9小票模版用
            datas.put("sellCouponAmt", pair.first);

            // 应收，2.9小票模版用
            datas.put("shouldPay", getShouldPayAmt(sell, pair.first));

            // 支付明细（包含非实收）
            datas.put("SellReceive", getSellPaymentDetails(orderID, databaseName, date, false));
            // 支付明细（不包含非实收），2.9小票模版用
            datas.put("SellReceive2", getSellPaymentDetails(orderID, databaseName, date, true));
            JSONObject SysMode = new JSONObject();
            SysMode.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("SysMode", SysMode);

            // 这里fdBackQty直接取0，退菜信息在findAllVoidCompletedSellItems中取,第一语言和第二语言合并一张小票打印，此时第二语言为空，就不打印
            String sql = "select *, (case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName  || '(' || fsOrderUint || ')' as fsItemName, " +
                    "(case fsItemName2 when '' then  '' else (case fdGiftQty when 0 then '' else '[Free]' end) || fsItemName2 end) as fsItemName2," +
                    "(fdSaleQty-fdBackQty) as qty, 0 as fdBackQty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind <> '3'" +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";

            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName, (fdSaleQty-fdBackQty) as  qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind = '3' " +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";


            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
            if (sellOrderItemDBModels == null) {
                sellOrderItemDBModels = new ArrayList<>();
            }

            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
            if (SLITList == null) {
                SLITList = new ArrayList<>();
            }
            //餐标模式下不打印金额开关
            String dinnerStandardPrintConfig = DBMetaUtil.getConfig(META.DINNERSTANDARD_PRINT_CONFIG, "1");

            BigDecimal qty = BigDecimal.ZERO;
            for (int i = sellOrderItemDBModels.size() - 1; i >= 0; i--) {
                StatementSellItemModel statementSellItemModel = sellOrderItemDBModels.get(i);

                if (statementSellItemModel == null) {
                    continue;
                }
                //餐标服务费和低消服务费
                if (DinnerStandardUtil.isStandardMenu(statementSellItemModel.fiItemCd)) {
                    //餐标服务费和低消服务费金额为0则过滤掉
                    if (BigDecimal.ZERO.compareTo(statementSellItemModel.fdSaleAmt) == 0) {
                        sellOrderItemDBModels.remove(i);
                        continue;
                    }
                    //餐标模式下不打印金额开关开启的话，则不打印餐标服务费
                    if (TextUtils.equals(dinnerStandardPrintConfig, "1") && TextUtils.equals(statementSellItemModel.fiItemCd, DinnerStandardUtil.DS_MENU_ID)) {
                        sellOrderItemDBModels.remove(i);
                        continue;
                    }
                }

                if (statementSellItemModel.fiIsEditQty == 1) { //称重菜算一份
                    qty = qty.add(BigDecimal.ONE);
                } else {
                    qty = qty.add(statementSellItemModel.qty);
                }

                for (StatementSellItemModel itemExModel : SLITList) {
                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                        statementSellItemModel.SLIT.add(itemExModel);
                    }
                }
            }

            map.put("qty", qty);
            datas.put("printUserName", user == null ? "" : user.fsUserName);
            //结账单是否打印退菜信息
            if (PrintConfig.BILL_PRINT_VOIDMENU) {
                List<StatementSellItemModel> allVoidSellItems = findAllVoidCompletedSellItems(orderID, date, databaseName);
                if (!ListUtil.isEmpty(allVoidSellItems)) {
                    sellOrderItemDBModels.addAll(allVoidSellItems);
                }
            }

            if (ListUtil.isEmpty(sellOrderItemDBModels)) {
                RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "终止打印结账单，没有查到有效菜品, orderID = " + orderID);
                return null;
            }
//            List<StatementSellItemModel> tempData = mergeMenuItem(sellOrderItemDBModels);
//            datas.put("sellorder", PrintDataProcessUtil.turnToPrintMode(tempData, false));//普通小票
//            datas.put("sellorderGroupByCls", PrintDataProcessUtil.groupSellItemByCls(tempData));//按菜品分类排序小票
//            datas.put("sellorderGroupByTime", PrintDataProcessUtil.groupSellItemByTime(sellOrderItemDBModels));//按单序排序小票
//            datas.put("sellorderGroupByTable", PrintDataProcessUtil.groupSellItemByTable(sellOrderItemDBModels, sell.fsMTableId, sell.fsMTableName));//按桌台排序小票

            //构建小票的菜品数据
            PrintDataProcessUtil.buildBillData(datas, mergeMenuList(sell, sellOrderItemDBModels), sell, "bill/orderbill");

            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
            String printBillCut = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_CUT, "0");
            if (!TextUtils.equals(printBillCut, "0")) {
                printBillCut = "1";
            }
            datas.put("printBillCut", printBillCut);

            //结账单是否打印实收
            if (PrintConfig.BILL_PRINT_REALMONEY) {
                JSONObject realMoneyData = new JSONObject();
                realMoneyData.put("realMoney", sell.fdRealAmt);
                realMoneyData.put("unRealMoney", sell.fdPayAmt.subtract(sell.fdRealAmt));
                datas.put("realMoneyData", realMoneyData);
            }

            //结账单是否打印电子发票
            String printBillFrom = ClientMetaUtil.getSettingsValueByKey(META.PRINT_BILL_FROM);
            if (TextUtils.equals(printBillFrom, PrintBillFrom.FROM_PAY)) {
                //来自结账时
                String printInvoiceQRAuto = DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "");
                //解决meta表key冲突问题。当线上所有版本都升级到pro2.8.2后，这段代码就可以拿掉了
                if (TextUtils.isEmpty(printInvoiceQRAuto)) {
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "0"));
                    printInvoiceQRAuto = "0";
                }

                if (TextUtils.equals(printInvoiceQRAuto, "1")) {
                    addEInvoiceQRPrintData(datas, orderID, sell.fdRealAmt, sell.fsCreateTime);
                } else {
                    String logStr = "结账时 打印电子发票二维码开关 关闭状态";
                    LogUtil.log(logStr);
                    RunTimeLog.addLog(RunTimeLog.PRINT_EINVOICE_QR, logStr);
                }

            } else if (TextUtils.equals(printBillFrom, PrintBillFrom.FROM_BILL_MANAGE)) {
                //来自账单管理
                String printInvoiceQR = DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "");
                //解决meta表key冲突问题。当线上所有版本都升级到pro2.8.2后，这段代码就可以拿掉了
                if (TextUtils.isEmpty(printInvoiceQR)) {
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "0"));
                    printInvoiceQR = "0";
                }
                if (TextUtils.equals(printInvoiceQR, "1")) {
                    addEInvoiceQRPrintData(datas, orderID, sell.fdRealAmt, sell.fsCreateTime);
                } else {
                    String logStr = "账单管理 打印电子发票二维码开关 关闭状态";
                    LogUtil.log(logStr);
                    RunTimeLog.addLog(RunTimeLog.PRINT_EINVOICE_QR, logStr);
                }

            }

            //打印美味广告
            PrintUtil.printMWAD(datas);
            //点菜单、预结单、结账单是否显示用餐标准内菜品金额 0：显示 1：不显示，默认1
            if (BigDecimal.ZERO.compareTo(sell.fdDiningStandardAmt) < 0) {
                datas.put("diningStandardPrintConfig", dinnerStandardPrintConfig);
            }

            String fsPrinterName = printerName;
            if (TextUtils.isEmpty(fsPrinterName) && !TextUtils.isEmpty(hostId)) {
                if (TextUtils.equals(hostId, HostBiz.mealorder)) {
                    fsPrinterName = PrintConnector.getInstance().getCurrentHostPrinterName();
                } else {
                    fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
                }
            }
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, sell.fsMTableName, sell.fsSellDate, 0, sell.cashiername, "0", PrintReportId.STATEMENT, hostId, true);
            task.uri = TicketTempletUtils.getDinnerBillUri("bill/orderbill");
            task.fsPrinterName = fsPrinterName;

            //读美小二结账单打印配置：美小二出结账单，端上不出小票
            if (TextUtils.equals(hostId, HostBiz.mealorder) && user != null) {
                if (TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_BILL_ON_WAITER, "0"), "1")) {
                    HostStatusModel waiter = HostStatusDBUtils.queryWaiter(user.fsUserId);
                    //printConfig：打印配置 0：不可打印，1可打印，默认0
                    if (waiter != null && waiter.printConfig == 1 && !TextUtils.isEmpty(waiter.device)) {
                        task.fsHostId = waiter.device;//美小二硬件标志
                    } else {
                        LogUtil.logBusiness("美小二打印结账单开关为开，但不可打印：" + (waiter == null ? "" : "printConfig:" + waiter.printConfig + ",device:" + waiter.device));
                    }
                }
            }
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);
            task.fsPrnData = datas.toJSONString();

            return task;
        }
        return null;
    }

    /**
     * 菜品合并的时候，如果是餐标模式下，计入餐标的菜品和不计入餐标的菜品要分开合并
     *
     * @param sell
     * @param originalData
     * @return
     */
    private static List<StatementSellItemModel> mergeMenuList(CustomSellDBModel sell, List<StatementSellItemModel> originalData) {
        if (!PayConfig.PRINT_COMBINE_DISHES) {
            return originalData;//不需要合并
        }
        List<StatementSellItemModel> tempData = null;
        //餐标模式
        if (BigDecimal.ZERO.compareTo(sell.fdDiningStandardAmt) < 0) {
            List<StatementSellItemModel> dinnerStandardMenuList = new ArrayList<>();
            List<StatementSellItemModel> menuList = new ArrayList<>();
            for (StatementSellItemModel model : originalData) {
                if (model != null) {
                    if (model.fiWithinDiningStandard == 1) {
                        dinnerStandardMenuList.add(model);
                    } else {
                        menuList.add(model);
                    }
                }
            }
            tempData = mergeMenuItem(dinnerStandardMenuList);
            if (tempData != null) {
                tempData.addAll(mergeMenuItem(menuList));
            } else {
                tempData = mergeMenuItem(menuList);
            }
        } else {
            tempData = mergeMenuItem(originalData);
        }
        return tempData;
    }

    /**
     * 获取应收金额
     *
     * @param sell          订单
     * @param sellCouponAmt 优惠合计
     * @return 应收金额
     */
    private static BigDecimal getShouldPayAmt(CustomSellDBModel sell, BigDecimal sellCouponAmt) {
        // 应收 = 消费合计-优惠合计+圆整+服务费+免掉的服务费，2.9小票模版用，由于消费合计定为折前金额，这里新增字段保存
        return sell.fdOriginalAmt.add(sell.fdFreeSveAmt).subtract(sellCouponAmt).add(sell.fdRoundAmt).add(sell.fdServiceAmt);
    }

    /**
     * 获取优惠明细
     * 优惠明细包括：
     * 赠送金额 fdGiftAmt ，折扣金额 fdDiscountAmt ，特价优惠 fdOriginalAmt-fdCouponSpecialAmt，会员价优惠 fdOriginalAmt-fdCouponVipAmt，
     * 非实收结算（满减和整单立减 ）tesellReceive表中fiSourceType 值为 2-整单立减、3-满减，买减 fdReceMoney，免服务费 fdFreeSveAmt
     *
     * @param databaseName 库名
     * @param orderId      订单号
     * @param date         营业日期
     * @param isPreBill    是否是预结单，用来约束整单立减、满减从何处取
     * @return Pair《优惠合计,优惠明细列表》
     */
    private static Pair<BigDecimal, List<JSONObject>> getSellCouponDetails(String databaseName, String orderId, String date, boolean isPreBill) {
        // 赠送金额，折扣金额，买减，特价优惠，会员价优惠
        String sql = "select sum(fdGiftAmt) fdGiftAmt," +
                "sum(fdDiscountAmt) fdDiscountAmt," +
                "sum(case when fdBuyGiftName <> '' then (fdOriginalAmt-fdBuyGiftAmt) else '0' end) fdBuyGiftAmt," +
                "sum(case when fiOrderMode<>'3' and fiPriceTag='2' and fdCouponSpecialAmt >= 0 then (fdOriginalAmt-fdCouponSpecialAmt) else '0' end) fdCouponSpecialAmt," +
                "sum(case when fiOrderMode<>'3' and fiPriceTag='3' and fdCouponVipAmt >= 0 then (fdOriginalAmt-fdCouponVipAmt) else '0' end) fdCouponVipAmt " +
                "from tbSellOrderItem where fdSaleQty > fdBackQty and fiOrderItemKind<>'3' " +
                "and fsSellNo ='" + orderId + "' and fsSellDate = '" + date + "'";
        // 整单立减、满减
        String sqlReduce = "select sum(fdreceMoney) discountAmt," +
                "(case fsNote when '' then (case fiSourceType when 2 then '整单立减' else (case fiSourceType when 3 then '满减' else fspaymentname end) end) else fsNote end) discountName " +
                "from tbSellReceive where fiStatus = 1 and fsSellNo = '" + orderId + "' and fsSellDate = '" + date + "' " +
                "and fiSourceType in ('2','3') group by fiSourceType";
        // 免服务费
        String sqlFreeSve = "select fdFreeSveAmt from tbsell where fsSellNo='" + orderId + "' AND fsSellDate = '" + date + "'";
        // 菜品券
        String sqlDishCoupon = "select couponName,couponAmt from billItemCouponDetail where sellNo='" + orderId + "' and couponType='" + CouponType.MEMBER_COUPON+ "' and couponId='" + CouponId.MEMBER_COUPON + "'";

        List<DishCouponReportModel> dishCouponReportModels = DBSimpleUtil.queryList(databaseName, sqlDishCoupon, DishCouponReportModel.class);

        AllDiscountReportTempModel discountData = DBSimpleUtil.query(databaseName, sql, AllDiscountReportTempModel.class);
        BigDecimal freeSveAmt = new BigDecimal(StringUtil.toInt(DBSimpleUtil.queryString(databaseName, sqlFreeSve)));

        // 优惠合计
        BigDecimal allAmt = BigDecimal.ZERO;
        // 优惠明细
        List<JSONObject> couponList = new ArrayList<>();

        if (discountData != null) {
            if (discountData.fdGiftAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject gift = new JSONObject();
                gift.put("discountName", "赠送金额");
                gift.put("discountAmt", discountData.fdGiftAmt);
                allAmt = allAmt.add(discountData.fdGiftAmt);
                couponList.add(gift);
            }
            if (discountData.fdDiscountAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdDiscountAmt = new JSONObject();
                fdDiscountAmt.put("discountName", "折扣总金额");
                fdDiscountAmt.put("discountAmt", discountData.fdDiscountAmt);
                allAmt = allAmt.add(discountData.fdDiscountAmt);
                couponList.add(fdDiscountAmt);
                //TODO Call huangming wangting
//<<<<<<< HEAD
                String discountDetail = "select fsDiscountName discountName,sum(fdDiscountAmt) discountAmt from tbSellOrderItem where " +
                        "fdSaleQty > fdBackQty and fsSellNo ='" + orderId + "' and fsSellDate = '" + date + "' and fsDiscountId != '' group by fsdiscountid";
                List<JSONObject> detailList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN,discountDetail);
                if (detailList != null) {
                    fdDiscountAmt.put("discountDetail",detailList);
//=======
//                String discountDetail = "select fsDiscountId, fsDiscountName discountName, fiDiscountRate discountRate,sum(fdDiscountAmt) discountAmt from tbSellOrderItem where " +
//                        "fdSaleQty > fdBackQty and fsSellNo ='" + orderId + "' and fsSellDate = '" + date + "' and fsDiscountId != '' group by fiDiscountRate";
//                List<JSONObject> detailList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN,discountDetail);
//                for (JSONObject temp : detailList) {
//                    if(temp != null){
//                        if (TextUtils.equals(temp.getString("fsDiscountId"), CouponType.MEMBER_COUPON)) {
//                            continue;
//                        }
//                        String discountRate = temp.getString("discountRate");
//                        if(!TextUtils.isEmpty(discountRate)){
//                            BigDecimal rate = Calc.format(new BigDecimal((100 - StringUtil.toInt(discountRate,0)) / 10f), 1, RoundingMode.HALF_UP);
//                            BigDecimal rate0 = Calc.format(rate, 0, RoundingMode.HALF_UP);
//                            if (rate.compareTo(rate0) == 0) {
//                                temp.put("discountName",rate0.toString() + "折");
//                            } else {
//                                temp.put("discountName",rate.toString() + "折");
//                            }
//                        }
//                    }
//>>>>>>> origin/master
                }
            }
            if (discountData.fdCouponVipAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdCouponVipAmt = new JSONObject();
                fdCouponVipAmt.put("discountName", "会员价优惠");
                fdCouponVipAmt.put("discountAmt", discountData.fdCouponVipAmt);
                allAmt = allAmt.add(discountData.fdCouponVipAmt);
                couponList.add(fdCouponVipAmt);
            }
            if (discountData.fdCouponSpecialAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdCouponSpecialAmt = new JSONObject();
                fdCouponSpecialAmt.put("discountName", "特价优惠");
                fdCouponSpecialAmt.put("discountAmt", discountData.fdCouponSpecialAmt);
                allAmt = allAmt.add(discountData.fdCouponSpecialAmt);
                couponList.add(fdCouponSpecialAmt);
            }
            if (discountData.fdBuyGiftAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdBuyGiftAmt = new JSONObject();
                fdBuyGiftAmt.put("discountName", "买减优惠");
                fdBuyGiftAmt.put("discountAmt", discountData.fdBuyGiftAmt);
                allAmt = allAmt.add(discountData.fdBuyGiftAmt);
                couponList.add(fdBuyGiftAmt);
            }
        }
        if (freeSveAmt.compareTo(BigDecimal.ZERO) > 0) {
            JSONObject fdFreeSveAmt = new JSONObject();
            fdFreeSveAmt.put("discountName", "免服务费");
            fdFreeSveAmt.put("discountAmt", freeSveAmt);
            allAmt = allAmt.add(freeSveAmt);
            couponList.add(fdFreeSveAmt);
        }

        /*
         整单立减、满减，预结单从order_cache中取，结账单从tbSellReceive表中取，
        因为这两种只有在构建支付方式后才会写入tbSellReceive，所以在未构建支付方式时tbSellReceive中取不到
          */
        if (isPreBill) {
            OrderCache orderCache = OrderSaveDBUtil.get(orderId);
            if (orderCache != null) {
                if (orderCache.couponCut != null) {
                    JSONObject cutAmt = new JSONObject();
                    cutAmt.put("discountName", "满减");
                    cutAmt.put("discountAmt", orderCache.couponCut.fdCutmoney);
                    allAmt = allAmt.add(orderCache.couponCut.fdCutmoney);
                    couponList.add(cutAmt);
                }
                if (orderCache.selectOrderDiscountCut != null) {
                    JSONObject orderCutAmt = new JSONObject();
                    orderCutAmt.put("discountName", orderCache.selectOrderDiscountCut.fsDiscountName);
                    orderCutAmt.put("discountAmt", orderCache.selectOrderDiscountCut.fdddv);
                    allAmt = allAmt.add(orderCache.selectOrderDiscountCut.fdddv);
                    couponList.add(orderCutAmt);
                }
            }
        } else {
            List<JSONObject> reduces = DBSimpleUtil.queryJsonList(databaseName, sqlReduce);
            if (!ListUtil.isEmpty(reduces)) {
                for (JSONObject obj : reduces) {
                    if (obj != null) {
                        BigDecimal amt = obj.getBigDecimal("discountAmt");
                        if (amt != null && amt.compareTo(BigDecimal.ZERO) > 0) {
                            allAmt = allAmt.add(amt);
                            couponList.add(obj);
                        }
                    }
                }
            }
        }
        return new Pair<>(allAmt, couponList);
    }

    /**
     * 获取订单支付明细
     *
     * @param orderID          订单ID
     * @param databaseName     从库/主库
     * @param date             营业日期
     * @param withoutReceMoney 是否计算非实收结算，用来兼容旧版本及小票模版
     */
    @NonNull
    private static List<StatementSellReceiveModel> getSellPaymentDetails(String orderID, String databaseName, String date, boolean withoutReceMoney) {
        // 非实收结算（满减和整单立减 ）tesellReceive表中fiSourceType 值为 2，整单立减；3，满减 的fdReceMoney，统计到优惠明细
        String sql = "select *, fsPaymentName paymentname from tbSellReceive where fsSellNo = '" + orderID + "' and fsSellDate='" + date + "'" + " and fiStatus<>'13' ";
        if (withoutReceMoney) {
            sql = sql + "AND fiSourceType NOT IN ('2', '3')";
        }
        List<StatementSellReceiveModel> sellorder = DBSimpleUtil.queryList(databaseName, sql, StatementSellReceiveModel.class);
        if (sellorder == null) {
            sellorder = new ArrayList<>();
        }
        BigDecimal changeMoney = BigDecimal.ZERO;
        for (int i = 0; i < sellorder.size(); i++) {
            StatementSellReceiveModel temp = sellorder.get(i);
            temp.paymentname = temp.paymentname + ":";
            String memberScoreCostStr = temp.fsbackup2;
            String cardInfo = "卡号:" + FormatUtil.formatMemberCardNo(temp.fsMemCardNo);
            if (!TextUtils.isEmpty(temp.fsMemCardNo)) {
                if (TextUtils.equals("95002", temp.fspaymentid)) {
                    if (TextUtils.isEmpty(memberScoreCostStr) || TextUtils.equals("0", memberScoreCostStr)) {
                        temp.paymentname = temp.paymentname + "抵扣";
                        temp.fsNote = cardInfo;
                    } else {
                        temp.paymentname = temp.paymentname + "使用" + memberScoreCostStr + "积分,抵扣";
                        temp.fsNote = cardInfo;
                    }
                } else if (TextUtils.equals("95001", temp.fspaymentid)) {
                    temp.fsNote = cardInfo;
                }
            }
            changeMoney = changeMoney.add(temp.fdPayMoney.subtract(temp.fdReceMoney));
//            if (change.compareTo(BigDecimal.ZERO) > 0) {
//                StatementSellReceiveModel changeReceive = new StatementSellReceiveModel();
//                changeReceive.paymentname = "找零:";
//                //小票模板使用这个字段
//                changeReceive.fspaymentname = "找零:";
//                temp.fdPayMoney = temp.fdReceMoney;
//                changeReceive.fdPayMoney = change;
//                sellorder.add(i, changeReceive);
//            }
            //添加预付金到备注里
            if ((temp.fiThirdType & 2) == 2) {
                if (!TextUtils.isEmpty(temp.fsNote)) {
                    temp.fsNote = temp.fsNote + ",";
                }
                temp.fsNote = temp.fsNote + "预付金";
            }
        }
        if (changeMoney.compareTo(BigDecimal.ZERO) > 0) {
            StatementSellReceiveModel changeReceive = new StatementSellReceiveModel();
            changeReceive.paymentname = "找零:";
            //小票模板使用这个字段
            changeReceive.fspaymentname = "找零:";
            changeReceive.fdPayMoney = changeMoney;
            sellorder.add(changeReceive);
        }
        return sellorder;
    }

    /**
     * 获取订单待支付金额
     *
     * @param shouldPay 应收金额
     * @param payList   支付明细列表
     * @return 订单待支付金额
     */
    private static BigDecimal getSellLeftToPay(BigDecimal shouldPay, List<StatementSellReceiveModel> payList) {
        if (shouldPay == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal alreadyPaid = BigDecimal.ZERO;
        if (!ListUtil.isEmpty(payList)) {
            for (StatementSellReceiveModel model : payList) {
                alreadyPaid = alreadyPaid.add(model.fdPayMoney);
            }
        }

        BigDecimal leftToPay = shouldPay.subtract(alreadyPaid);
        return leftToPay.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : leftToPay;
    }

    /**
     * @param datas   电子发票二维码所需要的数据集
     * @param orderID 实付金额
     * @param payTime 支付时间
     */
    private static void addEInvoiceQRPrintData(JSONObject datas, String orderID, BigDecimal payMoney, String payTime) {
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", orderID, "结账打印电子发票二维码");
        try {
            // 是否有反结备份的订单,
            SellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderID + "'", SellDBModel.class);
            SellDBModel sellBack = DBSimpleUtil.query(APPConfig.DB_MAIN, "WHERE fsSellNo LIKE '" + orderID + "%' AND fiBillStatus = '" + OrderStatus.ANTI_BACK + "' ORDER BY fsSellNo DESC", SellDBModel.class);
            RunTimeLog.addLog(RunTimeLog.ELECTRONIC_INVOICE, "订单[" + sell.fssellno + "]第[" + sell.antiPayCount + "]次结账, 打印电子发票二维码");
            StringBuilder businessNo = new StringBuilder();

            if (sellBack != null) {
                // 如果反结账，且已开过票，且金额不一致, 旧有发票作废，重开发票
                if (sellBack.fiInvoiceState == InvoiceState.INVOICE_SUCCESS && sell.fdExpAmt.compareTo(sellBack.fdExpAmt) != 0) {
                    businessNo.append(sell.fsshopguid);
                    businessNo.append(sell.fssellno);
                    businessNo.append("_");
                    businessNo.append(sell.antiPayCount);

                    // 新开票，当前 OrderCache 开票状态字段还原
                    orderCache.invoiceState = InvoiceState.NEED_INVOICE;
                    orderCache.invoiceDetailBean = null;

                    // 添加 Job, 旧发票冲红
                    Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM unfinish_task WHERE type = '" + JobType.INVOICE_DEPRECATED + "' AND biz_key = '" + sellBack.invoiceBusinessNo + "'", Job.class);
                    if (job == null) {
                        job = new Job();
                        job.type = JobType.INVOICE_DEPRECATED;
                        job.biz_key = sellBack.invoiceBusinessNo;
                        job.info = "订单反结账";
                        job.cycle = 3;
                        job.cycle_count = 2;
                        JobScheudler.newJob(job);
                    } else {
                        job.updateJobPrepared();
                    }
                    RunTimeLog.addLog(RunTimeLog.ELECTRONIC_INVOICE, "订单[" + sell.fssellno + "]反结账且金额改变, 使用当前订单[" + sell.fssellno + "]生成电子发票二维码, 流水号[" + businessNo.toString() + "]");
                } else {
                    businessNo.append(sellBack.invoiceBusinessNo);

                    // 反结账金额未变，延用反结备份的开票状态
                    orderCache.invoiceState = sellBack.fiInvoiceState;

                    RunTimeLog.addLog(RunTimeLog.ELECTRONIC_INVOICE, "订单[" + sell.fssellno + "]反结账但金额未改变, 使用备份订单[" + sellBack.fssellno + "]生成电子发票二维码, 流水号[" + businessNo.toString() + "]");
                }
            } else {
                businessNo.append(sell.fsshopguid);
                businessNo.append(sell.fssellno);

                // 首次开票，添加状态'需要开票'
                orderCache.invoiceState = InvoiceState.NEED_INVOICE;

                RunTimeLog.addLog(RunTimeLog.ELECTRONIC_INVOICE, "订单[" + sell.fssellno + "]未反结账, 使用当前订单生成电子发票二维码, 流水号[" + businessNo.toString() + "]");
            }
            payTime = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsCheckTime FROM tbSellCheck WHERE fsSellNo = '" + orderID + "'");

            // 更新电子发票业务流水号
            orderCache.invoiceBusinessNo = businessNo.toString();

            String eInvoiceQR = EInvoiceProcess.optEInvoiceQR(businessNo.toString(), payMoney, payTime);
            if (!TextUtils.isEmpty(eInvoiceQR)) {
                datas.put("eInvoiceQRTitle", "扫描二维码开具电子发票");
                datas.put("eInvoiceQRDescription", "请输入“邮箱地址”接收发票");
                datas.put("eInvoiceQRDescription1", "或者开票成功后添加至“微信卡包”");
                datas.put("eInvoiceQR", eInvoiceQR);
                datas.put("eInvoiceQRNote", "扫码开票有效期3天");

                EInvoiceProcess.recordEInvoiceStatus(orderID, orderCache.invoiceState, "");
            }
            // 此处 writeOrder 不能再写入报表，会导致 tbSell 中已付金额、实收金额等为0
            OrderSession.getInstance().writeOrder(orderID, false, "addEInvoiceQRPrintData");
            // 更新 tbSell 中电子发票业务流水号字段
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "UPDATE tbSell SET invoiceBusinessNo = '" + orderCache.invoiceBusinessNo + "',fiInvoiceState = '" + orderCache.invoiceState + "' WHERE fsSellNo = '" + orderCache.orderID + "'");
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", orderID, "结账打印电子发票二维码");
        }
    }

    public static List<StatementSellItemModel> findAllVoidCompletedSellItems(String orderId, String date, String databaseName) {
        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }
        //,第一语言和第二语言合并一张小票打印，此时第二语言为空，就不打印
        String sql = "select *,0 as fdSaleAmt,0 as fdOriginalAmt,0 as fdCouponVipAmt,0 as fdCouponSpecialAmt,0 as fdBuyGiftAmt,0 as fdDiscountAmt," +
                " '[退]'||fsItemName || '(' || fsOrderUint || ')' as fsItemName," +
                " (case fsItemName2 when '' then  '' else (case fdGiftQty when 0 then '' else '[Recede]' end) || fsItemName2 end) as fsItemName2," +
                " fdBackQty as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                " where fsSellNo = '" + orderId + "'" +
                " and fiOrderItemKind <> '3'" +
                " and fiOrderMode in (1,3)" +
                " and fdBackQty > 0 " +
                " and fsSellDate='" + date + "'";

        String sql2 = "select *, fdBackQty as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                " where fsSellNo = '" + orderId + "'" +
                " and fiOrderItemKind = '3' " +
                " and fiOrderMode in (1,3)" +
                " and fdBackQty > 0 " +
                " and fsSellDate='" + date + "'";

        List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        }

        List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
        if (SLITList == null) {
            SLITList = new ArrayList<>();
        }

        for (StatementSellItemModel statementSellItemModel : sellOrderItemDBModels) {
            for (StatementSellItemModel itemExModel : SLITList) {
                if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                    statementSellItemModel.SLIT.add(itemExModel);
                }
            }
        }
        return sellOrderItemDBModels;
    }

    public static List<Integer> printFastFoodBill(final String orderID, final String hostId, final String printUserName) {
        return printFastFoodBill(orderID, null, hostId, printUserName, APPConfig.DB_MAIN);
    }

    /**
     * 打印快餐结账单
     *
     * @param orderID String
     */
    public static List<Integer> printFastFoodBill(final String orderID, MemberInfo memberInfo, final String hostId, final String printUserName, String databaseName) {

        //加入打印开关，适用于正餐和快餐的结账单
        if (!isAllowToPrint(orderID)) {
            return Collections.emptyList();
        }

        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }

        OrderSession.getInstance().updatePrintBillTimes(databaseName, orderID);
        List<Integer> printTaskIds = new ArrayList<>();
//        JSONObject datas = new JSONObject();
//        CustomSellDBModel sell = DBSimpleUtil.query(databaseName, "select tbSell.*,(tbSell.fdSaleAmt+tbSell.fdRoundAmt)as fdSaleAmt,tbSellCheck.fiPrintTimes,tbSellCheck.fsUpdateUserName as cashiername,tbSellCheck.fsShiftName as shiftname from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fsSellNo ='" + orderID + "'", CustomSellDBModel.class);
//        if (sell != null) {
//            if (TextUtils.isEmpty(sell.shiftname)) {
//                String fsShiftId = DBSimpleUtil.queryString(databaseName, "select fsShiftId from  tbSellCheck where fsSellNo='" + sell.fssellno + "'");
//                sell.shiftname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftName from tbshift where fsShiftId='"+fsShiftId+"' and fiStatus='1'");
//            }
//            datas.put("Shop", DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class));
//            datas.put("Sell", sell);
//
//            //会员卡信息
//            if (memberInfo != null) {
//                datas.put("memberInfo", memberInfo);
//            }
//
//            JSONObject map = new JSONObject();
//            String date = sell.fsSellDate;
//
//            map.put("total", sell.fdSaleAmt);
//            datas.put("Sub", map);
//            datas.put("fsMealNumber", sell.fsMealNumber);
//            datas.put("printUserName", printUserName);
//            String statisticsDiscountSql = "select fsDiscountName,sum(fdDiscountAmt) as discountamt  from tbsellorderitem " +
//                    " where fsSellNo='" + orderID + "' and fsSellDate='" + date + "' and fiOrderMode=1 and fiOrderItemKind!=3 and fdsaleqty!=fdbackqty and fiIsDiscount=1 and fsDiscountId!=''  group by fsDiscountId having discountamt>0";
//            List<JSONObject> statisticsDiscounts = DBSimpleUtil.queryJsonList(databaseName, statisticsDiscountSql);
//            if (statisticsDiscounts != null && statisticsDiscounts.size() > 0) {
//                datas.put("statisticsDiscount", statisticsDiscounts);
//            }
//
//            datas.put("fddiscountamt", sell.fdDiscountAmt);
//            if (sell.fdRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
//                datas.put("fdroundamt", "" + sell.fdRoundAmt);
//            }
//
////                    fsPaymentName
//            List<StatementSellReceiveModel> sellorder = DBSimpleUtil.queryList(databaseName, "select *, fsPaymentName paymentname from " + DBModel.getTableName(SellreceiveDBModel.class) + " where fsSellNo = '" + orderID + "' and fsSellDate='" + date + "'" + " and fiStatus<>'13' ", StatementSellReceiveModel.class);
//            if (sellorder == null) {
//                sellorder = new ArrayList<>();
//            }
//            datas.put("SellReceive", sellorder);
//            JSONObject SysMode = new JSONObject();
//            SysMode.put("PrintTime", DateUtil.getCurrentTime());
//            datas.put("SysMode", SysMode);
//
//            String sql = "select *, (case fdGiftQty when 0 then '' else '(赠)' end)||fsItemName || '(' || fsOrderUint || ')'  as fsItemName," +
//                    "(case fdGiftQty when 0 then '' else '(Free)' end)|| (case fsItemName2 when '' then fsItemName else fsItemName2 end) as fsItemName2," +
//                    " (fdSaleQty-fdBackQty) as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
//                    " where fsSellNo = '" + orderID + "'" +
//                    " and fiOrderItemKind <> '3'" +
//                    " and fiOrderMode in (1,3)" +
//                    " and fdSaleQty<>fdBackQty" +
//                    " and fsSellDate='" + date + "'";
//
//            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName, (fdSaleQty-fdBackQty) as  qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
//                    " where fsSellNo = '" + orderID + "'" +
//                    " and fiOrderItemKind = '3' " +
//                    " and fiOrderMode in (1,3)" +
//                    " and fdSaleQty<>fdBackQty" +
//                    " and fsSellDate='" + date + "'";
//
//            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
//            if (sellOrderItemDBModels == null) {
//                sellOrderItemDBModels = new ArrayList<>();
//            }
//
//            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
//            if (SLITList == null) {
//                SLITList = new ArrayList<>();
//            }
//            BigDecimal qty = BigDecimal.ZERO;
//            for (StatementSellItemModel statementSellItemModel : sellOrderItemDBModels) {
//
//                if (statementSellItemModel.fiIsEditQty == 1) { //称重菜算一份
//                    qty = qty.add(BigDecimal.ONE);
//                } else {
//                    qty = qty.add(statementSellItemModel.qty);
//                }
//
//                for (StatementSellItemModel itemExModel : SLITList) {
//                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
//                        statementSellItemModel.SLIT.add(itemExModel);
//                    }
//                }
//            }
//
//            map.put("qty", qty);
//            List<StatementSellItemModel> allVoidSellItems = findAllVoidCompletedSellItems(orderID, date,databaseName);
//            if (!ListUtil.isEmpty(allVoidSellItems)) {
//                sellOrderItemDBModels.addAll(allVoidSellItems);
//            }
//
//            if (ListUtil.isEmpty(sellOrderItemDBModels)) {
//                RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "终止打印结账单，没有查到有效菜品, orderID = " + orderID);
//                return printTaskIds;
//            }
//
//            datas.put("sellorder", turnToPrintMode(mergeMenuItem(sellOrderItemDBModels)));
//            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
//            datas.put("printBillCut", CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_CUT, "0"));
//
//            if (DBPrintConfig.needPrintMWAD()) {
//                datas.put("reportTail", "本服务由美味不用等提供");
//            } else {
//                datas.put("reportTail", "");
//            }
//            //处理结账单的打印份数
//            String printCountConfig = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbhostexternal where fiCls = '4' and fsHostId = '" + hostId + "'");
//            int printCountNum = StringUtil.toInt(printCountConfig, 1);
//            if (printCountNum < 1) {
//                printCountNum = 1;
//            }
//            String fsPrinterName = "";
//            if (!TextUtils.isEmpty(hostId)) {
//                fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
//            }
//            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, sell.fsMTableName, sell.fsSellDate, 0, sell.cashiername, "0", PrintReportId.STATEMENT, hostId, true);
//            task.uri = "fastFoodBill/orderbill";
//            task.fsPrinterName = fsPrinterName;
//
//            for (int i = 0; i < printCountNum; i++) {
//                if (i > 0) {
//                    OrderSession.getInstance().updatePrintBillTimes(databaseName,orderID);
//                    sell.fiPrintTimes++;
//                    datas.put("Sell", sell);
//                }
//                task.fsPrnData = null;
//                task = task.clone();
//                task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
//                datas.put("fiPrintNo",task.fiPrintNo);
//
//                task.fsPrnData = datas.toJSONString();
//                MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
////                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
////                if (!task.printAtOnce) {
////                    printTaskIds.add(task.fiPrintNo);
////                }
//            }
//        }
//        return printTaskIds;

        PrintTaskDBModel task = getFastFoodBillData(orderID, memberInfo, hostId, printUserName, databaseName);
        if (task == null) {
            return printTaskIds;
        }

        //处理结账单的打印份数
        String printCountConfig = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbhostexternal where fiCls = '4' and fsHostId = '" + hostId + "'");
        int printCountNum = StringUtil.toInt(printCountConfig, 1);
        if (printCountNum < 1) {
            printCountNum = 1;
        }

        JSONObject datas = JSON.parseObject(task.fsPrnData);
        CustomSellDBModel sell = JSONObject.parseObject(datas.getString("Sell"), CustomSellDBModel.class);

        for (int i = 0; i < printCountNum; i++) {
            if (i > 0) {
                OrderSession.getInstance().updatePrintBillTimes(databaseName, orderID);
                if (sell != null) {
                    sell.fiPrintTimes++;
                    datas.put("Sell", sell);
                }
            }
            task.fsPrnData = null;
            task = task.clone();
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);

            task.fsPrnData = datas.toJSONString();
            MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
        }
        return printTaskIds;

    }

    /**
     * 获取快餐结账单数据
     *
     * @param orderID String
     */
    public static PrintTaskDBModel getFastFoodBillData(final String orderID, MemberInfo memberInfo, final String hostId, final String printUserName, String databaseName) {

        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }

        JSONObject datas = new JSONObject();
        CustomSellDBModel sell = DBSimpleUtil.query(databaseName, "select tbSell.*,(tbSell.fdSaleAmt+tbSell.fdRoundAmt)as fdSaleAmt,tbSellCheck.fiPrintTimes,tbSellCheck.fsUpdateUserName as cashiername,tbSellCheck.fsShiftName as shiftname from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fsSellNo ='" + orderID + "'", CustomSellDBModel.class);
        if (sell != null) {
            if (TextUtils.isEmpty(sell.shiftname)) {
                String fsShiftId = DBSimpleUtil.queryString(databaseName, "select fsShiftId from  tbSellCheck where fsSellNo='" + sell.fssellno + "'");
                sell.shiftname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftName from tbshift where fsShiftId='" + fsShiftId + "' and fiStatus='1'");
            }
            datas.put("Shop", DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class));
            datas.put("Sell", sell);
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            boolean isMeiXiaoDianOrder = orderCache != null && "910".equals(orderCache.fsBillSourceId);
            if (isMeiXiaoDianOrder) {
                JSONObject meixiaodianOrder = new JSONObject();
                meixiaodianOrder.put("eatType", orderCache.eatType == EatType.EAT_IN ? "堂食" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "外带" : "");
                if (!TextUtils.isEmpty(orderCache.eatTime) && !(orderCache.eatTime.contains("立即用餐") || orderCache.eatTime.contains("尽早用餐"))) {
                    meixiaodianOrder.put("eatTime", orderCache.eatTime);
                }
                datas.put("meiXiaoDianOrder", meixiaodianOrder);
            }
            //会员卡信息
            if (memberInfo != null) {
                datas.put("memberInfo", memberInfo);
            }

            JSONObject map = new JSONObject();
            String date = sell.fsSellDate;

            map.put("total", sell.fdSaleAmt);
            datas.put("Sub", map);
            datas.put("fsMealNumber", sell.fsMealNumber);
            datas.put("printUserName", printUserName);
            String statisticsDiscountSql = "select fsDiscountName,sum(fdDiscountAmt) as discountamt  from tbsellorderitem " +
                    " where fsSellNo='" + orderID + "' and fsSellDate='" + date + "' and fiOrderMode=1 and fiOrderItemKind!=3 and fdsaleqty!=fdbackqty and fiIsDiscount=1 and fsDiscountId!=''  group by fsDiscountId having discountamt>0";
            List<JSONObject> statisticsDiscounts = DBSimpleUtil.queryJsonList(databaseName, statisticsDiscountSql);
            if (statisticsDiscounts != null && statisticsDiscounts.size() > 0) {
                datas.put("statisticsDiscount", statisticsDiscounts);
            }

            datas.put("fddiscountamt", sell.fdDiscountAmt);
            if (sell.fdRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
                datas.put("fdroundamt", "" + sell.fdRoundAmt);
            }

            List<StatementSellReceiveModel> sellorder = getSellPaymentDetails(orderID, databaseName, date, false);
            if (sellorder == null) {
                sellorder = new ArrayList<>();
            }
            datas.put("SellReceive", sellorder);
//            datas.put("changeMoney", changeMoney);
            JSONObject SysMode = new JSONObject();
            SysMode.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("SysMode", SysMode);

            String sql = "select *, (case fdGiftQty when 0 then '' else '(赠)' end)||fsItemName || '(' || fsOrderUint || ')'  as fsItemName," +
                    "(case fdGiftQty when 0 then '' else '(Free)' end)|| (case fsItemName2 when '' then fsItemName else fsItemName2 end) as fsItemName2," +
                    " (fdSaleQty-fdBackQty) as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind <> '3'" +
                    " and fiOrderMode in (1,3)" +
                    " and fdSaleQty<>fdBackQty" +
                    " and fsSellDate='" + date + "'";

            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName, (fdSaleQty-fdBackQty) as  qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind = '3' " +
                    " and fiOrderMode in (1,3)" +
                    " and fdSaleQty<>fdBackQty" +
                    " and fsSellDate='" + date + "'";

            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
            if (sellOrderItemDBModels == null) {
                sellOrderItemDBModels = new ArrayList<>();
            }

            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
            if (SLITList == null) {
                SLITList = new ArrayList<>();
            }

            BigDecimal qty = BigDecimal.ZERO;
            for (StatementSellItemModel statementSellItemModel : sellOrderItemDBModels) {

                if (statementSellItemModel.fiIsEditQty == 1) { //称重菜算一份
                    qty = qty.add(BigDecimal.ONE);
                } else {
                    qty = qty.add(statementSellItemModel.qty);
                }

                for (StatementSellItemModel itemExModel : SLITList) {
                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                        statementSellItemModel.SLIT.add(itemExModel);
                    }
                }
            }

            map.put("qty", qty);
            //结账单是否打印退菜信息
            if (PrintConfig.BILL_PRINT_VOIDMENU) {
                List<StatementSellItemModel> allVoidSellItems = findAllVoidCompletedSellItems(orderID, date, databaseName);
                if (!ListUtil.isEmpty(allVoidSellItems)) {
                    sellOrderItemDBModels.addAll(allVoidSellItems);
                }
            }
            if (ListUtil.isEmpty(sellOrderItemDBModels)) {
                RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "终止打印结账单，没有查到有效菜品, orderID = " + orderID);
                return null;
            }
            List<StatementSellItemModel> tempData = mergeMenuItem(sellOrderItemDBModels);
//            datas.put("sellorder", PrintDataProcessUtil.turnToPrintMode(tempData, false));//普通小票
//            datas.put("sellorderGroupByCls", PrintDataProcessUtil.groupSellItemByCls(tempData));//按菜品分类排序小票
//            datas.put("sellorderGroupByTime", PrintDataProcessUtil.groupSellItemByTime(sellOrderItemDBModels));//按单序排序小票

            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
            datas.put("printBillCut", CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_CUT, "0"));

            //结账单是否打印电子发票
            String printBillFrom = ClientMetaUtil.getSettingsValueByKey(META.PRINT_BILL_FROM);
            // 外卖手动映射菜品后结账，走快餐结账流程，外卖暂不支持打印电子发票二维码
            if (sell.fiselltype != 2 && TextUtils.equals(printBillFrom, PrintBillFrom.FROM_PAY)) {
                //来自结账时
                String printInvoiceQRAuto = DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "");
                //解决meta表key冲突问题。当线上所有版本都升级到pro2.8.2后，这段代码就可以拿掉了
                if (TextUtils.isEmpty(printInvoiceQRAuto)) {
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "0"));
                    printInvoiceQRAuto = "0";
                }

                if (TextUtils.equals(printInvoiceQRAuto, "1")) {
                    addEInvoiceQRPrintData(datas, orderID, sell.fdRealAmt, sell.fsCreateTime);
                } else {
                    String logStr = "结账时 打印电子发票二维码开关 关闭状态";
                    LogUtil.log(logStr);
                    RunTimeLog.addLog(RunTimeLog.PRINT_EINVOICE_QR, logStr);
                }

            } else if (TextUtils.equals(printBillFrom, PrintBillFrom.FROM_BILL_MANAGE)) {
                //来自账单管理
                String printInvoiceQR = DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "");
                //解决meta表key冲突问题。当线上所有版本都升级到pro2.8.2后，这段代码就可以拿掉了
                if (TextUtils.isEmpty(printInvoiceQR)) {
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "0"));
                    printInvoiceQR = "0";
                }
                if (TextUtils.equals(printInvoiceQR, "1")) {
                    addEInvoiceQRPrintData(datas, orderID, sell.fdRealAmt, sell.fsCreateTime);
                } else {
                    String logStr = "账单管理 打印电子发票二维码开关 关闭状态";
                    LogUtil.log(logStr);
                    RunTimeLog.addLog(RunTimeLog.PRINT_EINVOICE_QR, logStr);
                }
            }

//            //处理结账单的打印份数
//            String printCountConfig = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsParamValue from tbhostexternal where fiCls = '4' and fsHostId = '" + hostId + "'");
//            int printCountNum = StringUtil.toInt(printCountConfig, 1);
//            if (printCountNum < 1) {
//                printCountNum = 1;
//            }
            //打印美味广告
            PrintUtil.printMWAD(datas);

            //构建小票的菜品数据
            PrintDataProcessUtil.buildBillData(datas, tempData, sell, "fastFoodBill/orderbill");

            String fsPrinterName = "";
            if (!TextUtils.isEmpty(hostId)) {
                fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
            }
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, sell.fsMTableName, sell.fsSellDate, 0, sell.cashiername, "0", PrintReportId.STATEMENT, hostId, true);
            task.uri = TicketTempletUtils.getFastBillUri("fastFoodBill/orderbill", orderCache != null ? orderCache.fsBillSourceId : "");
            task.fsPrinterName = fsPrinterName;
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);
            task.fsPrnData = datas.toJSONString();

            return task;
        }
        return null;
    }

    public static void printRapidDinnerBill(final OrderCache orderCache, final UserDBModel user) {
        printRapidDinnerBill(orderCache, null, user);
    }

    /**
     * 打印 秒付结账单按区域打印
     * 仅限秒点单和美小二使用
     */
    public static void printRapidDinnerBill(final OrderCache orderCache, MemberInfo memberInfo, final UserDBModel user) {

        BusinessExecutor.executeNoWait(new ASyncExecute<String>() {
            @Override
            public String execute() {
                final String centerHostID = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);

                //如果开关没有打开，则依然使用业务中心的打印机
                if (!TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.RAPID_PRINT_BILL, "1"), "0")) {
                    printDinnerBill(orderCache.orderID, memberInfo, "", centerHostID, false, user, APPConfig.DB_MAIN);
                    printRemainBill(orderCache.orderID, "", centerHostID, false, user.fsUserName, APPConfig.DB_MAIN);
                    return "";
                }

                //先处理餐区打印机
                String sql = "select fiPrinterCls,fsPrinterName from tbPrinter where fsPrinterName in (select fsPrinterName from tbmarea where fsMAreaId='" + orderCache.fsmareaid + "');";
                PrinterDBModel printerArea = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
                if (printerArea == null) {
                    printDinnerBill(orderCache.orderID, memberInfo, "", centerHostID, false, user, APPConfig.DB_MAIN);
                    printRemainBill(orderCache.orderID, "", centerHostID, false, user.fsUserName, APPConfig.DB_MAIN);
                    return "";
                } else {
                    printDinnerBill(orderCache.orderID, memberInfo, printerArea.fsPrinterName, centerHostID, false, user, APPConfig.DB_MAIN);
                    printRemainBill(orderCache.orderID, printerArea.fsPrinterName, centerHostID, false, user.fsUserName, APPConfig.DB_MAIN);
                }
                return "";
            }
        });
    }


    /**
     * 打印秒点的预结账单
     * 仅限秒点单和美小二使用
     */
    public static void printRapidDinnerPreBill(final OrderCache orderCache, final UserDBModel user) {
        BusinessExecutor.executeNoWait(new ASyncExecute<String>() {
            @Override
            public String execute() {
                //业务中心hostID
                String centerHostId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select value from meta where key='802'");
                //如果开关没有打开，则依然使用业务中心的打印机
                if (TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.WAITER_PRE_PRINT, "1"), "1")) {
                    printPreBill(orderCache.orderID, centerHostId, null, user);
                    return "";
                }

                //先处理餐区打印机
                String sql = "select fsPrinterName from tbPrinter where fsPrinterName in (select fsPrinterName from tbmarea where fsMAreaId='" + orderCache.fsmareaid + "');";
                String printerArea = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                if (!TextUtils.isEmpty(printerArea)) {
                    printPreBill(orderCache.orderID, centerHostId, printerArea, user);
                } else {
                    printPreBill(orderCache.orderID, centerHostId, null, user);
                }
                return "";
            }
        });
    }

    /**
     * 构建预结单的PrintTaskDbModel
     *
     * @return
     */
    public static List<Integer> printPreBill(final String orderId, final String hostId, final String printerName, final UserDBModel user) {
        OrderSession.getInstance().updatePrintPreBillTimes(orderId);
        List<Integer> printTaskIds = new ArrayList<>();

        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = printerName;
        if (TextUtils.isEmpty(printerName) && !TextUtils.isEmpty(hostId)) {
            fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");
        }

        JSONObject datas = new JSONObject();
        CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "select *, (fdSaleAmt+fdRoundAmt) as fdSaleAmt FROM tbSell where fsSellNo = '" + orderId + "'", CustomSellDBModel.class);
        if (sell != null) {
            sell.cashiername = "";
            sell.shiftname = "";
            datas.put("Shop", DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop", ShopDBModel.class));
            datas.put("Sell", sell);
            JSONObject map = new JSONObject();
            String date = sell.fsSellDate;
            map.put("total", sell.fdSaleAmt.subtract(sell.fdRoundAmt));
            // 消费合计（折前），2.9小票模版用
            map.put("originalAmt", sell.fdOriginalAmt);

            datas.put("fddiscountamt", sell.fdDiscountAmt);
            if (sell.fdRoundAmt.compareTo(BigDecimal.ZERO) != 0) {
                datas.put("fdroundamt", "" + sell.fdRoundAmt);
            }

            /*
             * 是否显示可折扣金额
             */
            if (TextUtils.equals(DBMetaUtil.getConfig(META.PRE_BILL_PRINT_DISCOUNT_INFO, "0"), "1")) {
                BigDecimal nonDiscountAmt = PayUtil.getCannnotDiscAmtByOrderTotal(orderId);
                map.put("NonDisAmt", nonDiscountAmt);
            }

            datas.put("Sub", map);

            OrderCache orderCache = OrderSaveDBUtil.get(orderId);

            if (orderCache.couponCut != null) {
                datas.put("Coupon", orderCache.couponCut);
            }
            JSONObject SysMode = new JSONObject();
            SysMode.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("SysMode", SysMode);

            // 这里fdBackQty直接取0，退菜信息在findAllVoidCompletedSellItems中取,第一语言和第二语言合并一张小票打印，此时第二语言为空，就不打印
            String sql = "select *, (case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName || '(' || fsOrderUint || ')' as fsItemName," +
                    "(case fsItemName2 when '' then  '' else (case fdGiftQty when 0 then '' else '[Free]' end) || fsItemName2 end) as fsItemName2," +
                    " (fdSaleQty-fdBackQty) as qty, 0 fdBackQty from tbSellOrderItem " +
                    " where fsSellNo = '" + orderCache.orderID + "'" +
                    " and fiOrderItemKind <> '3'" +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";

            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName , (fdSaleQty-fdBackQty) as qty from tbSellOrderItem " +
                    " where fsSellNo = '" + orderCache.orderID + "'" +
                    " and fiOrderItemKind = '3' " +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";

            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, StatementSellItemModel.class);
            if (sellOrderItemDBModels == null) {
                sellOrderItemDBModels = new ArrayList<>();
            }

            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, StatementSellItemModel.class);
            if (SLITList == null) {
                SLITList = new ArrayList<>();
            }

            String qty = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select sum((case fiIsEditQty when '1' then '1' else (fdSaleQty-fdBackQty) end)) as qty from tbSellOrderItem where fsSellNo='" + sell.fssellno + "' and fiOrderItemKind <> '3' " +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'");
            datas.put("printUserName", user == null ? "" : user.fsUserName);

            BigDecimal qtyNum = BigDecimal.ZERO;
            if (!TextUtils.isEmpty(qty)) {
                qtyNum = new BigDecimal(qty);
            }
            //餐标模式下不打印金额开关
            String dinnerStandardPrintConfig = DBMetaUtil.getConfig(META.DINNERSTANDARD_PRINT_CONFIG, "1");

            for (int i = sellOrderItemDBModels.size() - 1; i >= 0; i--) {
                StatementSellItemModel statementSellItemModel = sellOrderItemDBModels.get(i);

                if (statementSellItemModel == null) {
                    continue;
                }
                //餐标服务费和低消服务费
                if (DinnerStandardUtil.isStandardMenu(statementSellItemModel.fiItemCd)) {
                    //餐标服务费和低消服务费金额为0则过滤掉
                    if (BigDecimal.ZERO.compareTo(statementSellItemModel.fdSaleAmt) == 0) {
                        sellOrderItemDBModels.remove(i);
                        if (qtyNum.compareTo(BigDecimal.ZERO) > 0) {
                            qtyNum = qtyNum.subtract(BigDecimal.ONE);
                        }
                        continue;
                    }
                    //餐标模式下不打印金额开关开启的话，则不打印餐标服务费
                    if (TextUtils.equals(dinnerStandardPrintConfig, "1") && TextUtils.equals(statementSellItemModel.fiItemCd, DinnerStandardUtil.DS_MENU_ID)) {
                        sellOrderItemDBModels.remove(i);
                        if (qtyNum.compareTo(BigDecimal.ZERO) > 0) {
                            qtyNum = qtyNum.subtract(BigDecimal.ONE);
                        }
                        continue;
                    }
                }

                for (StatementSellItemModel itemExModel : SLITList) {
                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                        statementSellItemModel.SLIT.add(itemExModel);
                    }
                }
            }
            map.put("qty", qtyNum.toPlainString());

            List<StatementSellItemModel> allVoidSellItems = findAllVoidCompletedSellItems(orderId, date, APPConfig.DB_MAIN);
            if (!ListUtil.isEmpty(allVoidSellItems)) {
                sellOrderItemDBModels.addAll(allVoidSellItems);
            }
            if (ListUtil.isEmpty(sellOrderItemDBModels)) {
                RunTimeLog.addLog(RunTimeLog.PRINTER_ERROR, "终止打印预结账单，没有查到有效菜品, orderID = " + orderCache.orderID);
                return printTaskIds;
            }

//            List<StatementSellItemModel> tempData = mergeMenuItem(sellOrderItemDBModels);
//            datas.put("sellorder", PrintDataProcessUtil.turnToPrintMode(tempData, false));//普通小票
//            datas.put("sellorderGroupByCls", PrintDataProcessUtil.groupSellItemByCls(tempData));//按菜品分类排序小票
//            datas.put("sellorderGroupByTime", PrintDataProcessUtil.groupSellItemByTime(sellOrderItemDBModels));//按单序排序小票
//            datas.put("sellorderGroupByTable", PrintDataProcessUtil.groupSellItemByTable(sellOrderItemDBModels, sell.fsMTableId, sell.fsMTableName));//按桌台排序小票

            // 优惠明细，2.9小票模版用
            Pair<BigDecimal, List<JSONObject>> pair = getSellCouponDetails(APPConfig.DB_MAIN, orderId, date, true);
            List<JSONObject> sellCouponDetails = pair.second;
            if (sellCouponDetails != null && sellCouponDetails.size() > 0) {
                datas.put("sellCouponDetails", sellCouponDetails);
            }
            // 优惠合计，2.9小票模版用
            datas.put("sellCouponAmt", pair.first);

            // 应收，2.9小票模版用
            BigDecimal shouldPay = getShouldPayAmt(sell, pair.first);
            datas.put("shouldPay", shouldPay);

            // 矫正预结单应收为负的情况
            if (shouldPay.compareTo(BigDecimal.ZERO) < 0) {
                datas.put("sellCouponAmt", pair.first.add(shouldPay));
                if (orderCache != null && orderCache.selectOrderDiscountCut != null && pair.second != null) {
                    // 负值落到整单立减上
                    for (JSONObject jsonObj : pair.second) {
                        if (TextUtils.equals(jsonObj.getString("discountName"), orderCache.selectOrderDiscountCut.fsDiscountName)) {
                            jsonObj.put("discountAmt", orderCache.selectOrderDiscountCut.fdddv.add(shouldPay));
                        }
                    }
                    datas.put("sellCouponDetails", sellCouponDetails);
                }
                datas.put("shouldPay", BigDecimal.ZERO);
            }

            // 支付明细，2.9小票模版用
            List<StatementSellReceiveModel> sellPaymentDetails = getSellPaymentDetails(orderId, APPConfig.DB_MAIN, date, true);
            datas.put("SellReceive2", sellPaymentDetails);

            // 待支付，2.9小票模版用
            BigDecimal sellLeftToPay = getSellLeftToPay(shouldPay, sellPaymentDetails);
            datas.put("leftToPay", sellLeftToPay);

            if (DBPrintConfig.needPrintRapidQR()) {
                String tableQR = "";
                //根据配置读取付款码信息
                String qrType = ServerSettingHelper.getPreBillPayQrCodeType();
                if (APPConfig.isMydKouBei() && TextUtils.equals(qrType, META.VALUE_PAY_QR_CODE_KB)) {
                    tableQR = KBFutureProcessor.loadPayQRInfo(orderId);
                }
                if (TextUtils.isEmpty(tableQR)) {
                    tableQR = TableQRProcess.optTableQR(sell.fsMTableId);
                }
                datas.put("tableQR", tableQR);
                String note = DBPrintConfig.optRapidQRNote();
                if (TextUtils.isEmpty(note)) {
                    note = "请扫码买单";
                }
                datas.put("note", note);
            }
            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
            //打印美味广告
            PrintUtil.printMWAD(datas);

            //点菜单、预结单、结账单是否显示用餐标准内菜品金额 0：显示 1：不显示，默认1
            if (BigDecimal.ZERO.compareTo(sell.fdDiningStandardAmt) < 0) {
                datas.put("diningStandardPrintConfig", dinnerStandardPrintConfig);
            }

            //构建小票的菜品数据
            PrintDataProcessUtil.buildBillData(datas, mergeMenuList(sell, sellOrderItemDBModels), sell, "bill/prebill");

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    orderCache.orderID,
                    orderCache.fsmtablename,
                    orderCache.businessDate,
                    printNO,
                    orderCache.waiterName,
                    "0",
                    PrintReportId.PRELIMINARY_STATEMENT,
                    hostId,
                    true);
            task.uri = TicketTempletUtils.getDinnerPreBillUri("bill/prebill");
            datas.put("fiPrintNo", task.fiPrintNo);

            task.fsPrnData = datas.toJSONString();
            task.fsPrinterName = TextUtils.isEmpty(fsPrinterName) ? DeviceDBUtil.getCurrentHostPrinterName() : fsPrinterName;

            //读美小二预结单打印配置：美小二出预结单，端上不出小票
            if (user != null) {
                if (TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_BILL_ON_WAITER, "0"), "1")) {
                    HostStatusModel waiter = HostStatusDBUtils.queryWaiter(user.fsUserId);
                    //printConfig：打印配置 0：不可打印，1可打印，默认0
                    if (waiter != null && TextUtils.equals(waiter.hostid, HostBiz.mealorder) && waiter.printConfig == 1 && !TextUtils.isEmpty(waiter.device)) {
                        task.fsHostId = waiter.device;//美小二硬件标志
                    } else {
                        LogUtil.logBusiness("美小二打印预结单开关为开，但不可打印：" + (waiter == null ? "" : "printConfig:" + waiter.printConfig + ",device:" + waiter.device));
                    }
                }
            }

            MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);

//            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//            if (!task.printAtOnce) {
//                printTaskIds.add(task.fiPrintNo);
//            }

        }
        return printTaskIds;
    }

    private static List<PrintBillMenuItemMode> turnToPrintMode(List<StatementSellItemModel> items, boolean isOtherBillData) {
        List<PrintBillMenuItemMode> result = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            StatementSellItemModel item = items.get(i);
            if (item == null) {
                continue;
            }
            PrintBillMenuItemMode mode;
            if (isOtherBillData) {
                mode = PrintBillMenuItemMode.createOtherBillMode(item, "" + (i + 1));
            } else {
                mode = PrintBillMenuItemMode.create(item);
            }
            result.add(mode);
        }
        return result;
    }

    /**
     * 获取此订单的所有优惠明细，此方法提供给结账单小票模块使用，需求改动：结账单上菜品明细下部分先不做改动，此方法废弃
     *
     * @param datas
     * @param databaseName
     * @param orderId
     */
    private static void getDiscountItem(JSONObject datas, String databaseName, String orderId) {
        //赠送金额、特价优惠、会员价优惠
        String discountSql = "select sum(fdGiftAmt) fdGiftAmt,sum(case when fdCouponVipAmt > 0 then (fdOriginalAmt-fdCouponVipAmt) else '0' end) fdCouponVipAmt,"
                + "sum(case when fdCouponSpecialAmt > 0 then (fdOriginalAmt-fdCouponSpecialAmt) else '0' end) fdCouponSpecialAmt from tbsellorderitem where fdSaleQty > fdBackQty "
                + " and fsSellNo ='" + orderId + "'";
        //减价、整单立减、满减
        String lessSql = "select sum(fdreceMoney) discountamt,(case fiSourceType when 0 then fspaymentname else " +
                "(case fiSourceType when 2 then '整单立减' else " +
                "(case fiSourceType when 3 then '满减' else fspaymentname end) end) end) fsDiscountName from tbsellreceive where fiStatus = 1 and fsSellNo = '" + orderId +
                "' and fsPaymentId = '" + PayType.LESS + "' and fiSourceType in ('0','2','3') and fdreceMoney > 0 group by fiSourceType";

        List<JSONObject> lessData = DBSimpleUtil.queryJsonList(databaseName, lessSql);
        AllDiscountReportTempModel discountData = DBSimpleUtil.query(databaseName, discountSql, AllDiscountReportTempModel.class);
        List<JSONObject> statisticsDiscount = null;
        //折扣明细
        if (datas.containsKey("statisticsDiscount")) {
            statisticsDiscount = JSONObject.parseArray(datas.getString("statisticsDiscount"), JSONObject.class);
        }
        if (statisticsDiscount == null) {
            statisticsDiscount = new ArrayList<>();
        }
        //折扣合计
        BigDecimal discountAllAmt = BigDecimal.ZERO;
        if (datas.containsKey("fddiscountamt")) {
            discountAllAmt = discountAllAmt.add(new BigDecimal(datas.getString("fddiscountamt")));
        }
        //折扣明细
        if (discountData != null) {
            if (discountData.fdGiftAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject gift = new JSONObject();
                gift.put("fsDiscountName", "赠送金额");
                gift.put("discountamt", discountData.fdGiftAmt);
                discountAllAmt = discountAllAmt.add(discountData.fdGiftAmt);
                statisticsDiscount.add(gift);
            }
            if (discountData.fdCouponVipAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdCouponVipAmt = new JSONObject();
                fdCouponVipAmt.put("fsDiscountName", "会员价");
                fdCouponVipAmt.put("discountamt", discountData.fdCouponVipAmt);
                discountAllAmt = discountAllAmt.add(discountData.fdCouponVipAmt);
                statisticsDiscount.add(fdCouponVipAmt);
            }
            if (discountData.fdCouponSpecialAmt.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject fdCouponSpecialAmt = new JSONObject();
                fdCouponSpecialAmt.put("fsDiscountName", "特价");
                fdCouponSpecialAmt.put("discountamt", discountData.fdCouponSpecialAmt);
                discountAllAmt = discountAllAmt.add(discountData.fdCouponSpecialAmt);
                statisticsDiscount.add(fdCouponSpecialAmt);
            }
        }
        if (lessData != null && lessData.size() > 0) {
            for (JSONObject obj : lessData) {
                if (obj != null) {
                    BigDecimal amt = obj.getBigDecimal("discountamt");
                    if (amt != null && amt.compareTo(BigDecimal.ZERO) > 0) {
                        discountAllAmt = discountAllAmt.add(amt);
                        statisticsDiscount.add(obj);
                    }
                }
            }
        }
        datas.put("statisticsDiscount", statisticsDiscount);
        datas.put("fddiscountamt", discountAllAmt);
    }

    private static List<StatementSellItemModel> mergeMenuItem(List<StatementSellItemModel> originalMenuItems) {
        List<StatementSellItemModel> menuItems = new ArrayList<>(originalMenuItems);

        if (!PayConfig.PRINT_COMBINE_DISHES) {
            return menuItems;//不需要合并
        }
        List<StatementSellItemModel> result = new ArrayList<>();
        if (ListUtil.isEmpty(menuItems)) {
            return result;
        }
        //合并菜品
        for (int i = 0; i < menuItems.size(); i++) {
            StatementSellItemModel menuItem = menuItems.get(i);
            if (menuItem == null || menuItem.isMerge) {
                continue;
            }
            menuItem.isMerge = true;
            if (menuItem.fdBackQty.compareTo(BigDecimal.ZERO) > 0) {//退菜加后面
                result.add(menuItem);
            } else {
                result.add(0, menuItem);//普通菜排前面
            }
            for (int j = i + 1; j < menuItems.size(); j++) {
                StatementSellItemModel temp = menuItems.get(j);
                if (temp == null || temp.isMerge) {
                    continue;
                }
                // 同一个菜品不进行合并
                if (TextUtils.equals(menuItem.fsseq, temp.fsseq)) {
                    continue;
                }

                if (menuItem.fiOrderItemKind == 2) {//套餐
                    if (temp.fiOrderItemKind != 2) {
                        continue;
                    }
                    // 套餐头不能仅判断 itemCd, 退赠菜的情况记录在套餐头
//                    if (menuItem.fiItemCd == temp.fiItemCd) {
                    if (canMergeMenu(menuItem, temp)) {
                        if (canMergePackage(menuItem.SLIT, temp.SLIT)) {
                            mergeAmt(menuItem, temp);
                            mergePackageItem(menuItem.SLIT, temp.SLIT);
                            temp.isMerge = true;
                        }
                    }
                } else {
                    if (temp.fiOrderItemKind == 2) {
                        continue;
                    }
                    if (canMergeMenu(menuItem, temp)) {
                        temp.isMerge = true;
                        mergeAmt(menuItem, temp);
                    }
                }

//                if (menuItem.fdBackQty.compareTo(BigDecimal.ZERO) > 0) {//退菜
//                    if (temp.fdBackQty.compareTo(BigDecimal.ZERO) <= 0) {
//                        continue;
//                    }
//                    if (menuItem.fiOrderItemKind == 2) {//套餐
//                        if (temp.fiOrderItemKind != 2) continue;
//                        if (menuItem.fiItemCd == temp.fiItemCd) {
//                            if (canMergePackage(menuItem.SLIT, temp.SLIT)) {
//                                menuItem.qty = menuItem.qty.add(temp.qty);
//                                menuItem.fdSaleAmt = menuItem.fdSaleAmt.add(temp.fdSaleAmt);
//                                mergePackageItem(menuItem.SLIT, temp.SLIT);
//                                temp.isMerge = true;
//                            }
//                        }
//                    } else {
//                        if (temp.fiOrderItemKind == 2) continue;
//                        if (canMergeMenu(menuItem, temp)) {
//                            temp.isMerge = true;
//                            menuItem.qty = menuItem.qty.add(temp.qty);
//                            menuItem.fdSaleAmt = menuItem.fdSaleAmt.add(temp.fdSaleAmt);
//                        }
//                    }
//                } else {//普通菜
//                    if (temp.fdBackQty.compareTo(BigDecimal.ZERO) > 0) {
//                        continue;
//                    }
//                    if (menuItem.fiOrderItemKind == 2) {//套餐
//                        if (temp.fiOrderItemKind != 2) continue;
//                        if (menuItem.fiItemCd == temp.fiItemCd) {
//                            if (canMergePackage(menuItem.SLIT, temp.SLIT)) {
//                                menuItem.qty = menuItem.qty.add(temp.qty);
//                                menuItem.fdSaleAmt = menuItem.fdSaleAmt.add(temp.fdSaleAmt);
//                                mergePackageItem(menuItem.SLIT, temp.SLIT);
//                                temp.isMerge = true;
//                            }
//                        }
//                    } else {
//                        if (temp.fiOrderItemKind == 2) continue;
//                        if (canMergeMenu(menuItem, temp)) {
//                            temp.isMerge = true;
//                            menuItem.qty = menuItem.qty.add(temp.qty);
//                            menuItem.fdSaleAmt = menuItem.fdSaleAmt.add(temp.fdSaleAmt);
//                        }
//                    }
//                }
            }
        }
        return result;
    }

    private static void mergeAmt(StatementSellItemModel originalMenu, StatementSellItemModel tempMenu) {
        originalMenu.qty = originalMenu.qty.add(tempMenu.qty);
        originalMenu.fdSaleAmt = originalMenu.fdSaleAmt.add(tempMenu.fdSaleAmt);
        if (originalMenu.fdBackQty.compareTo(BigDecimal.ZERO) > 0) {
            originalMenu.fdOriginalAmt = BigDecimal.ZERO;
            originalMenu.fdCouponVipAmt = BigDecimal.ZERO;
            originalMenu.fdCouponSpecialAmt = BigDecimal.ZERO;
            originalMenu.fdBuyGiftAmt = BigDecimal.ZERO;
            originalMenu.fdDiscountAmt = BigDecimal.ZERO;
        } else {
            originalMenu.fdOriginalAmt = originalMenu.fdOriginalAmt.add(tempMenu.fdOriginalAmt);
            originalMenu.fdCouponVipAmt = originalMenu.fdCouponVipAmt.add(tempMenu.fdCouponVipAmt);
            originalMenu.fdCouponSpecialAmt = originalMenu.fdCouponSpecialAmt.add(tempMenu.fdCouponSpecialAmt);
            originalMenu.fdBuyGiftAmt = originalMenu.fdBuyGiftAmt.add(tempMenu.fdBuyGiftAmt);
            originalMenu.fdDiscountAmt = originalMenu.fdDiscountAmt.add(tempMenu.fdDiscountAmt);
        }
    }

    private static void mergePackageItem(List<StatementSellItemModel> originalList, List<StatementSellItemModel> list2) {
        for (StatementSellItemModel menuItem : originalList) {
            for (StatementSellItemModel temp : list2) {
                if (TextUtils.equals(menuItem.fiItemCd, temp.fiItemCd)) {
                    menuItem.qty = menuItem.qty.add(temp.qty);
                }
            }
        }
    }

    private static boolean canMergePackage(List<StatementSellItemModel> list1, List<StatementSellItemModel> list2) {
        if (ListUtil.isEmpty(list1) && ListUtil.isEmpty(list2)) {
            return true;
        }
        if (ListUtil.isEmpty(list1) && !ListUtil.isEmpty(list2)) {
            return false;
        }
        if (!ListUtil.isEmpty(list1) && ListUtil.isEmpty(list2)) {
            return false;
        }
        if (list1.size() != list2.size()) {
            return false;
        }
        for (StatementSellItemModel menuItem : list1) {
            boolean canMerge = false;
            for (StatementSellItemModel temp : list2) {
                canMerge = canMergeMenu(menuItem, temp);
                if (canMerge) {
                    break;
                }
            }
            if (!canMerge) {
                return false;
            }
        }
        return true;
    }

    private static boolean canMergeMenu(SellOrderItemDBModel menuItem1, SellOrderItemDBModel menuItem2) {
        if (menuItem1 == null || menuItem2 == null) {
            return false;
        }
        if (!TextUtils.equals(menuItem1.fiItemCd, menuItem2.fiItemCd)) {
            return false;
        }
        if (!TextUtils.equals(menuItem1.fsItemName, menuItem2.fsItemName)) {
            return false;
        }
        if (menuItem1.fiOrderItemKind != menuItem2.fiOrderItemKind) {
            return false;
        }
        if (menuItem1.fiOrderItemKind == 4) {//配料菜
            if (menuItem1.fdSaleAmt != null && menuItem1.fdSalePrice.compareTo(menuItem2.fdSalePrice) == 0) {//配料菜价格相同合并
                return true;
            }
            return false;
        } else if (menuItem1.fiOrderItemKind == 3) {
            // 套餐明细
            if (menuItem1.fdSaleQty.compareTo(menuItem2.fdSaleQty) != 0) {
                return false;
            }
            if (!TextUtils.equals(menuItem1.fsNote, menuItem2.fsNote)) {
                return false;
            }
            return true;
        } else {
            if (menuItem1.fiIsTemporaryMenu == 1) {//是否是临时菜：0=false/1=true
                if (menuItem2.fiIsTemporaryMenu != 1) {
                    return false;
                }
                if (TextUtils.equals(menuItem1.fsItemName, menuItem2.fsItemName) && menuItem1.fdSalePrice.compareTo(menuItem2.fdSalePrice) == 0) {//临时菜价格和名称相同合并
                    return true;
                }
                return false;
            }
            if (menuItem1.fiIsEditPrice == 1) {//时价菜
                if (menuItem2.fiIsEditPrice != 1) {
                    return false;
                }
                if (!TextUtils.equals(menuItem1.fsItemName, menuItem2.fsItemName) || menuItem1.fdSalePrice.compareTo(menuItem2.fdSalePrice) != 0) {
                    return false;
                }
            }
            if (menuItem1.fiIsEditQty == 1 || menuItem1.fiIsEditQty != menuItem2.fiIsEditQty) {//称重菜不合并
                return false;
            }
            if (!TextUtils.equals(menuItem1.fsNote, menuItem2.fsNote)) {//做法要求不一样不合并
                return false;
            }
            if (!TextUtils.equals(menuItem1.fiOrderUintCd, menuItem2.fiOrderUintCd)) {//规格不同不合并
                return false;
            }
            return true;
        }
    }

    /**
     * 打印在线退款小票
     *
     * @param orderID      订单号
     * @param extraOrderID String
     * @param tradeNo      String
     * @param models       支付方式
     * @param hostId       站点ID
     */
    public static List<Integer> printPayVoid(final String orderID, final String extraOrderID, final String tradeNo,
                                             final List<PayModel> models, final String hostId) {
        if (ListUtil.isEmpty(models)) {
            return new ArrayList<>(0);
        }
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");
        JSONObject datas = new JSONObject();
        JSONObject order = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsMTableName,fsSellDate from tbSell where fsSellno='" + orderID + "'");
        datas.put("fsShopName", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbshop"));
        JSONArray sellReceive = new JSONArray();
        String prefix = "";
        if (!ListUtil.isEmpty(models)) {
            for (PayModel temp : models) {
                JSONObject object = new JSONObject();
                object.put("paymentname", temp.data.payName);
                object.put("fdpaymoney", temp.payAmount);
                sellReceive.add(object);
                if (temp.readSmarPayPos()) {
                    if (TextUtils.isEmpty(prefix)) {
                        prefix = "请在收款pos机上确认退款";
                    }
                }
            }
        }
        datas.put("SellReceive", sellReceive);
        datas.put("fsSellNo", orderID);
        datas.put("prefix", prefix);

        datas.put("voidTime", DateUtil.getCurrentTime());
        datas.put("extraOrderID", extraOrderID);
        datas.put("SellReceive", sellReceive);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, order.getString("fsMTableName"), order.getString("fsSellDate"), printNO, "", "0", PrintReportId.RECEIPT_PAY_VOID, hostId, true);
        task.fsReportName = "退款回执";
        task.uri = "bill/doVoidPay";
        task.fsPrinterName = fsPrinterName;
        for (int i = 0; i < 2; i++) {
            task.fsPrnData = null;
            task = task.clone();
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);

            task.fsPrnData = datas.toJSONString();
            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;
    }

    /**
     * 打印在线退款小票
     *
     * @param orderID      订单号
     * @param extraOrderID String
     * @param tradeNo      String
     * @param models       支付方式
     * @param hostId       站点ID
     */
    public static List<Integer> printPayVoid(final String orderID, String tableName, String date, final String extraOrderID, final String tradeNo,
                                             final List<PayModel> models, final String hostId) {
        if (ListUtil.isEmpty(models)) {
            return new ArrayList<>(0);
        }
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");
        JSONObject datas = new JSONObject();
        JSONObject order = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsMTableName,fsSellDate from tbSell where fsSellno='" + orderID + "'");
        datas.put("fsShopName", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbshop"));
        JSONArray sellReceive = new JSONArray();
        String prefix = "";
        if (!ListUtil.isEmpty(models)) {
            for (PayModel temp : models) {
                JSONObject object = new JSONObject();
                object.put("paymentname", temp.data.payName);
                object.put("fdpaymoney", temp.payAmount);
                sellReceive.add(object);
                if (temp.readSmarPayPos()) {
                    if (TextUtils.isEmpty(prefix)) {
                        prefix = "请在收款pos机上确认退款";
                    }
                }
            }
        }
        datas.put("SellReceive", sellReceive);
        datas.put("fsSellNo", orderID);
        datas.put("prefix", prefix);

        datas.put("voidTime", DateUtil.getCurrentTime());
        datas.put("extraOrderID", extraOrderID);
        datas.put("SellReceive", sellReceive);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, tableName, date, printNO, "", "0", PrintReportId.RECEIPT_PAY_VOID, hostId, true);
        task.fsReportName = "退款回执";
        task.uri = "bill/doVoidPay";
        task.fsPrinterName = fsPrinterName;
        for (int i = 0; i < 2; i++) {
            task.fsPrnData = null;
            task = task.clone();
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);

            task.fsPrnData = datas.toJSONString();
            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;
    }

    public static List<Integer> printPrePay(String businessDate, String tableName, String orderID, String section, String userName, int personNum, String hostID, List<Integer> seqList) {
        OrderSession.getInstance().updatePrintBillTimes(APPConfig.DB_MAIN, orderID);
        List<Integer> printTaskIds = new ArrayList<>();
        JSONObject datas = new JSONObject();
        datas.put("fsShopName", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')"));
        datas.put("time", DateUtil.getCurrentDate("yyyy-MM-dd"));
        datas.put("fsmtablename", tableName);
        datas.put("fssellno", orderID);
        datas.put("section", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMSectionName from tbmsection where fsMSectionId='" + section + "'"));
        datas.put("fsCreateUserName", userName);
        datas.put("count", personNum);

        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (session == null || ListUtil.isEmpty(session.selectPayListFull)) {
            return printTaskIds;
        }
        JSONArray payArr = new JSONArray();
        if (!ListUtil.isEmpty(seqList)) {
            for (PayModel payModel : session.selectPayListFull) {
                if (seqList.contains(payModel.seq)) {
                    JSONObject model = new JSONObject();
                    model.put("payName", payModel.data.payName);
                    model.put("payAmt", payModel.payAmount.toPlainString());
                    payArr.add(model);
                }
            }
        }
        datas.put("paymentArr", payArr);
        //打印美味广告
        PrintUtil.printMWAD(datas);

        String fsPrinterName = "";
        if (!TextUtils.isEmpty(hostID)) {
            fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostID + "'");
        }

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderID,
                tableName,
                businessDate,
                PrintJSONBuilder.generatePrintNO(),
                userName,
                "0",
                PrintReportId.PRE_PAY,
                hostID,
                true);
        task.uri = "bill/printPrePayReceipt";
        datas.put("fiPrintNo", task.fiPrintNo);

        task.fsPrnData = datas.toJSONString();
        task.fsPrinterName = TextUtils.isEmpty(fsPrinterName) ? DeviceDBUtil.getCurrentHostPrinterName() : fsPrinterName;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }

        return printTaskIds;

    }

    private static boolean isAllowToPrint(String orderID) {
        boolean allowToPay = PayConfig.PRINT_BILL_MARK;
        if (!allowToPay) {
            RunTimeLog.addLog(RunTimeLog.PRINT_FAILED_NOT_SET, orderID + "打印中断，原因：商户设置不打印结账单" + DateUtil.getCurrentDateTime());
        }
        return allowToPay;
    }

    /**
     * 打印留存单
     */
    public static List<Integer> printRemainBill(final String orderID, final String printerName, final String hostId, boolean fromAntiPay, final String printUserName, String databaseName) {

        List<Integer> printTaskIds = new ArrayList<>();
        //是否打印留存单
        if (!PrintConfig.PRINT_REMAIN_BILL) {
            return printTaskIds;
        }

        if (TextUtils.isEmpty(databaseName)) {
            databaseName = APPConfig.DB_MAIN;
        }
        JSONObject datas = new JSONObject();

        CustomSellDBModel sell = DBSimpleUtil.query(databaseName, "select tbSell.*,(tbSell.fdSaleAmt+tbSell.fdRoundAmt)as fdSaleAmt,tbSellCheck.fiPrintTimes,tbSellCheck.fsUpdateUserName as cashiername,tbSellCheck.fsShiftName as shiftname from tbSell inner join tbSellCheck on tbSell.fsSellNo=tbSellCheck.fsSellNo where tbSell.fsSellNo ='" + orderID + "'", CustomSellDBModel.class);
        if (sell != null) {
            if (TextUtils.isEmpty(sell.shiftname)) {
                String fsShiftId = DBSimpleUtil.queryString(databaseName, "select fsShiftId from  tbSellCheck where fsSellNo='" + sell.fssellno + "'");
                sell.shiftname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftName from tbshift where fsShiftId='" + fsShiftId + "' and fiStatus='1'");
            }
            datas.put("fsShopName", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')"));
            datas.put("hostId", hostId);
            datas.put("Sell", sell);

            JSONObject map = new JSONObject();

            String date = sell.fsSellDate;
            datas.put("titleSubFix", fromAntiPay ? "(反结单)" : "");
            map.put("total", sell.fdSaleAmt.subtract(sell.fdRoundAmt));
            datas.put("Sub", map);

            //支付明细
            List<StatementSellReceiveModel> sellReceive = DBSimpleUtil.queryList(databaseName, "select *, fsPaymentName paymentname from tbSellReceive where fsSellNo = '" + orderID + "' and fsSellDate='" + date + "'" + " and fiStatus<>'13' ", StatementSellReceiveModel.class);
            if (sellReceive == null) {
                sellReceive = new ArrayList<>();
            }
            BigDecimal changeMoney = BigDecimal.ZERO;
            List<JSONObject> sellReceiveList = new ArrayList<>();
            for (int i = 0; i < sellReceive.size(); i++) {
                StatementSellReceiveModel temp = sellReceive.get(i);
                temp.paymentname = temp.paymentname + ":";
                String memberScoreCostStr = temp.fsbackup2;
                String cardInfo = "卡号:" + FormatUtil.formatMemberCardNo(temp.fsMemCardNo);
                if (!TextUtils.isEmpty(temp.fsMemCardNo)) {
                    if (TextUtils.equals("95002", temp.fspaymentid)) {
                        if (TextUtils.isEmpty(memberScoreCostStr) || TextUtils.equals("0", memberScoreCostStr)) {
                            temp.paymentname = temp.paymentname + "抵扣";
                            temp.fsNote = "元" + cardInfo;
                        } else {
                            temp.paymentname = temp.paymentname + "使用" + memberScoreCostStr + "积分,抵扣";
                            temp.fsNote = "元" + cardInfo;
                        }
                    } else if (TextUtils.equals("95001", temp.fspaymentid)) {
                        temp.fsNote = cardInfo;
                    }
                }
                changeMoney = changeMoney.add(temp.fdPayMoney.subtract(temp.fdReceMoney));

                //添加预付金到备注里
                if ((temp.fiThirdType & 2) == 2) {
                    if (!TextUtils.isEmpty(temp.fsNote)) {
                        temp.fsNote = temp.fsNote + ",";
                    }
                    temp.fsNote = temp.fsNote + "预付金";
                }
                JSONObject receive = new JSONObject();
                receive.put("paymentName", temp.paymentname);
                receive.put("fsNote", temp.fsNote);
                receive.put("fdPayMoney", temp.fdPayMoney);
                sellReceiveList.add(receive);
            }
            if (changeMoney.compareTo(BigDecimal.ZERO) > 0) {
                JSONObject receive = new JSONObject();
                receive.put("paymentName", "找零:");
                receive.put("fdPayMoney", changeMoney);
                sellReceiveList.add(receive);
            }
            datas.put("SellReceive", sellReceiveList);
            JSONObject SysMode = new JSONObject();
            SysMode.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("SysMode", SysMode);

            String sql = "select *, (case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName  || '(' || fsOrderUint || ')' as fsItemName, " +
                    "(case fdGiftQty when 0 then '' else '[Free]' end)|| (case fsItemName2 when '' then fsItemName else fsItemName2 end) as fsItemName2," +
                    "(fdSaleQty-fdBackQty) as qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind <> '3'" +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";

            String sql2 = "select *, fsItemName || '(' || fsOrderUint || ')'  as fsItemName, (fdSaleQty-fdBackQty) as  qty from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                    " where fsSellNo = '" + orderID + "'" +
                    " and fiOrderItemKind = '3' " +
                    " and fiOrderMode in (1,3)" +
                    " and ((fdSaleQty<>fdBackQty) or (fdSaleQty == 0)) " +
                    " and fsSellDate='" + date + "'";


            List<StatementSellItemModel> sellOrderItemDBModels = DBSimpleUtil.queryList(databaseName, sql, StatementSellItemModel.class);
            if (sellOrderItemDBModels == null) {
                sellOrderItemDBModels = new ArrayList<>();
            }

            List<StatementSellItemModel> SLITList = DBSimpleUtil.queryList(databaseName, sql2, StatementSellItemModel.class);
            if (SLITList == null) {
                SLITList = new ArrayList<>();
            }

            BigDecimal qty = BigDecimal.ZERO;
            for (int i = sellOrderItemDBModels.size() - 1; i >= 0; i--) {
                StatementSellItemModel statementSellItemModel = sellOrderItemDBModels.get(i);

                if (statementSellItemModel == null) {
                    continue;
                }
                //餐标服务费和低消服务费
                if (DinnerStandardUtil.isStandardMenu(statementSellItemModel.fiItemCd)) {
                    //餐标服务费和低消服务费金额为0则过滤掉
                    if (BigDecimal.ZERO.compareTo(statementSellItemModel.fdSaleAmt) == 0) {
                        sellOrderItemDBModels.remove(i);
                        continue;
                    }
                }

                if (statementSellItemModel.fiIsEditQty == 1) { //称重菜算一份
                    qty = qty.add(BigDecimal.ONE);
                } else {
                    qty = qty.add(statementSellItemModel.qty);
                }

                for (StatementSellItemModel itemExModel : SLITList) {
                    if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                        statementSellItemModel.SLIT.add(itemExModel);
                    }
                }
            }

            map.put("qty", qty);
            datas.put("printUserName", printUserName);

            datas.put("sellorder", dealSellClsData(sellOrderItemDBModels));

            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);
            String printBillCut = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_BILL_CUT, "0");
            if (!TextUtils.equals(printBillCut, "0")) {
                printBillCut = "1";
            }
            datas.put("printBillCut", printBillCut);

            //打印美味广告
            PrintUtil.printMWAD(datas);

            String fsPrinterName = printerName;
            if (TextUtils.isEmpty(fsPrinterName) && !TextUtils.isEmpty(hostId)) {
                if (TextUtils.equals(hostId, HostBiz.mealorder)) {
                    fsPrinterName = PrintConnector.getInstance().getCurrentHostPrinterName();
                } else {
                    fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
                }
            }
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderID, sell.fsMTableName, sell.fsSellDate, 0, sell.cashiername, "0", PrintReportId.BILL_REMAIN, hostId, true);
            task.uri = "bill/orderRemainBill";
            task.fsPrinterName = fsPrinterName;
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);
            task.fsPrnData = datas.toJSONString();

            MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
        } else {
            LogUtil.logError("orderId:" + orderID + ",sell is null,不打印留存单");
        }
        return printTaskIds;
    }

    private static List<JSONObject> dealSellClsData(List<StatementSellItemModel> data) {
        List<JSONObject> menuItemClsData = PrintDataProcessUtil.groupSellItemByCls(data);
        List<JSONObject> result = new ArrayList<>();
        for (JSONObject tempData : menuItemClsData) {
            if (tempData == null) {
                continue;
            }
            JSONObject menuItemCls = new JSONObject();
            menuItemCls.put("menuClsName", tempData.get("menuClsName"));
            BigDecimal qty = BigDecimal.ZERO;
            BigDecimal price = BigDecimal.ZERO;
            if (tempData.containsKey("menuItemList")) {
                JSONArray menuItemList = tempData.getJSONArray("menuItemList");
                for (int i = 0; i < menuItemList.size(); i++) {
                    JSONObject menuItem = menuItemList.getJSONObject(i);
                    if (menuItem == null) {
                        continue;
                    }
                    qty = qty.add(menuItem.getBigDecimal("qty"));
                    price = price.add(menuItem.getBigDecimal("fdsaleamt"));
                }
            }
            menuItemCls.put("qty", qty);
            menuItemCls.put("amount", price);
            result.add(menuItemCls);
        }
        return result;
    }
}
