package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.DeliveryApi;
import com.mwee.android.pos.component.datasync.net.model.CreateDeliveryDataBean;
import com.mwee.android.pos.component.datasync.net.model.DeliveryStatusDataConfigListBean;
import com.mwee.android.pos.component.datasync.net.model.TempAppDeliveryInfo;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.connect.business.delivery.CreatedeliveryResponse;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.connect.business.delivery.OptAllDeliveryChannelResponse;
import com.mwee.android.pos.connect.business.delivery.OptDeliveryStatusResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by lxx on 17/11/24.
 * 配送
 */
@SuppressWarnings("unused")
public class DeliveryDriver implements IDriver {

    private static final String TAG = "delivery";

    /**
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/createDelivery")
    public SocketResponse createDelivery(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final CreatedeliveryResponse responseData = new CreatedeliveryResponse();
            response.data = responseData;
            final String orderId = request.getString("orderId");
            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            final String areaIds = request.getString("areaIds");
            final String deliveryChannel = request.getString("deliveryChannel");
            TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);

            String orderNo = orderId;
            if (tempAppOrder.deliveryInfo != null && tempAppOrder.deliveryInfo.mwDeliveryStatus == -2 && !TextUtils.isEmpty(tempAppOrder.deliveryInfo.updateTime)) {
                orderNo = orderId + "_" + DateUtil.formartDateStrToTarget(tempAppOrder.deliveryInfo.updateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss");
            }
            final String sfOrderNo = orderNo;

            DeliveryApi.createDelivery(orderId, orderNo, deliveryChannel, new IResponse<CreateDeliveryDataBean>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, final CreateDeliveryDataBean info) {
                    BusinessExecutor.executeAsyncExcute(new ASyncExecute<String>() {
                        @Override
                        public String execute() {
                            responseData.tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
                            LogUtil.logBusiness("网络订单", "配送成功：result:: " + result + ", order:: " + JSON.toJSONString(responseData.tempAppOrder));
                            if (result) {
                                //创建假配送中状态
                                responseData.tempAppOrder = createDeliveryInfo(responseData.tempAppOrder, sfOrderNo, deliveryChannel, info);
                            }
                            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                            return "";
                        }
                    }, new SyncCallback<String>() {
                        @Override
                        public void callback(String s) {
                            if (result) {
                                response.code = SocketResultCode.SUCCESS;
                                NotifyToClient.updateTempApporder(orderId);
                            } else {
                                response.code = SocketResultCode.BUSINESS_FAILED;
                                response.message = msg;
                            }
                        }
                    });
                }
            });

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/cancelDelivery")
    public SocketResponse cancelDelivery(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final CreatedeliveryResponse responseData = new CreatedeliveryResponse();
            response.data = responseData;
            final String orderId = request.getString("orderId");
            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            final String areaIds = request.getString("areaIds");
            final String expressCompany = request.getString("expressCompany");

            TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
            String orderNo = orderId;
            if (tempAppOrder.deliveryInfo != null && !TextUtils.isEmpty(tempAppOrder.deliveryInfo.deliveryNo)) {
                orderNo = tempAppOrder.deliveryInfo.deliveryNo;
            } else if (tempAppOrder.deliveryInfo != null && tempAppOrder.deliveryInfo.mwDeliveryStatus == -2 && !TextUtils.isEmpty(tempAppOrder.deliveryInfo.updateTime)) {
                orderNo = orderId + "_" + DateUtil.formartDateStrToTarget(tempAppOrder.deliveryInfo.updateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss");
            }

            DeliveryApi.cancelDelivery(orderId, orderNo, expressCompany, new IResponse<CreateDeliveryDataBean>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, final CreateDeliveryDataBean info) {
                    BusinessExecutor.executeAsyncExcute(new ASyncExecute<String>() {
                        @Override
                        public String execute() {
                            responseData.tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
                            if (result) {
                                //创建假取消配送状态
                                responseData.tempAppOrder = createCancelDeliveryInfo(responseData.tempAppOrder, expressCompany);
                            }

                            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                            return "";
                        }
                    }, new SyncCallback<String>() {
                        @Override
                        public void callback(String s) {
                            if (result) {
                                NotifyToClient.updateTempApporder(orderId);
                                response.code = SocketResultCode.SUCCESS;
                            } else {
                                response.code = SocketResultCode.BUSINESS_FAILED;
                                response.message = msg;
                            }
                        }
                    });
                }
            });

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    public static TempAppOrder createDeliveryInfo(TempAppOrder appOrder, String deliveryNo, String deliveryChannel, CreateDeliveryDataBean createDeliveryDataBean) {
        if (appOrder != null) {
            TempAppDeliveryInfo deliveryInfo = appOrder.deliveryInfo;
            if (deliveryInfo == null) {
                deliveryInfo = new TempAppDeliveryInfo();
            }

            if (deliveryInfo.mwDeliveryStatus == -10000 || deliveryInfo.mwDeliveryStatus == -2) {
                deliveryInfo.mwDeliveryStatus = 0;
                deliveryInfo.deliveryCompany = deliveryChannel;
                deliveryInfo.deliveryMobile = "";
                deliveryInfo.orderId = appOrder.orderId;
                deliveryInfo.deliveryNo = deliveryNo;
                if (createDeliveryDataBean != null) {
                    deliveryInfo.thirdOrderNo = createDeliveryDataBean.sfOrderNo;
                    deliveryInfo.createTime = createDeliveryDataBean.opTime;
                }
            }
            List<TempAppOrderDetail> items = new ArrayList();
            items.addAll(appOrder.orderDetailList);
            appOrder.orderDetailList.clear();

            appOrder.body = JSONObject.toJSONString(appOrder);
            appOrder.deliveryInfo = deliveryInfo;
            appOrder.deliveryStatus = 0;
            appOrder.replaceNoTrans();
//            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set deliveryStatus = '0' and body = '" + JSONObject.toJSONString(appOrder) + "' where orderid = '" + appOrder.orderId + "'");
            appOrder.orderDetailList.addAll(items);
        }

        return appOrder;
    }

    private static TempAppOrder createCancelDeliveryInfo(TempAppOrder appOrder, String deliveryChannel) {
        if (appOrder != null) {
            TempAppDeliveryInfo deliveryInfo = appOrder.deliveryInfo;
            if (deliveryInfo == null) {
                deliveryInfo = new TempAppDeliveryInfo();
            }

            if (deliveryInfo.mwDeliveryStatus != -2) {
                deliveryInfo.mwDeliveryStatus = -2;
                deliveryInfo.deliveryCompany = deliveryChannel;
                deliveryInfo.deliveryMobile = "";
                deliveryInfo.orderId = appOrder.orderId;
                deliveryInfo.updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            }

            List<TempAppOrderDetail> items = new ArrayList();
            items.addAll(appOrder.orderDetailList);
            appOrder.orderDetailList.clear();
            DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set body = '" + JSONObject.toJSONString(appOrder) + "' where orderid = '" + appOrder.orderId + "'");
            appOrder.orderDetailList.addAll(items);

        }

        return appOrder;
    }

    /**
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optDeliveryStatus")
    public SocketResponse optDeliveryStatus(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final OptDeliveryStatusResponse responseData = new OptDeliveryStatusResponse();
            response.data = responseData;

            String orderId = request.getString("orderId");
            DeliveryApi.optDeliveryStatus(new IResponse<List<DeliveryStatusDataConfigListBean>>() {
                @Override
                public void callBack(boolean result, int code, String msg, List<DeliveryStatusDataConfigListBean> info) {
                    if (result) {
                        responseData.deliveryStatusDataConfigListBeanList = info;
                        response.code = SocketResultCode.SUCCESS;
                    } else {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.data = msg;
                    }
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取所有外卖配送方式
     */
    @DrivenMethod(uri = TAG + "/optAllDeliveryChannel")
    public SocketResponse optAllDeliveryChannel(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            OptAllDeliveryChannelResponse response = new OptAllDeliveryChannelResponse();
            socketResponse.data = response;

            DeliveryApi.optDeliveryStatusForLoop();

            LinkedHashMap<String, List<DeliveryChannelBean>> deliverySettings = ServerCache.getInstance().netOrderCache.optDeliverySettings();
            if (deliverySettings == null || deliverySettings.size() == 0) {
                return socketResponse;
            }

            for (String key : deliverySettings.keySet()) {
                List<DeliveryChannelBean> valueList = deliverySettings.get(key);
                if (ListUtil.isEmpty(valueList)) {
                    continue;
                }
                for (DeliveryChannelBean value : valueList) {
                    if (value == null) {
                        continue;
                    }
                    if (ListUtil.isEmpty(response.deliveryChannelList)) {
                        response.deliveryChannelList.add(value);
                    } else {
                        boolean hasExist = false;
                        for (int i = 0; i < response.deliveryChannelList.size(); i++) {
                            DeliveryChannelBean existChannel = response.deliveryChannelList.get(i);
                            if (existChannel == null || TextUtils.equals(existChannel.channel, value.channel)) {
                                hasExist = true;
                            }
                        }
                        if (!hasExist) {
                            response.deliveryChannelList.add(value);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
