package com.mwee.android.pos.businesscenter.business.rapid.api;

/**
 * 秒点/秒付的结果
 * <p>
 * Created by virgil on 2017/1/17.
 */

public class RapidResult {
    /**
     * 成功
     */
    public final static int SUCCESS = 2;
    /**
     * 常规失败
     */
    public final static int ERROR = 4;
    /**
     * 秒付重复支付，目前和{@link #ERROR}保持一致
     */
    public final static int ERROR_DUPLICATE_RAPID_PAY = 4;
    /**
     * 未查询到订单，目前和{@link #ERROR}保持一致
     */
    public final static int ERROR_NO_ORDER = 4;

    /**
     * 反结账
     */
    public final static int ERROR_ANTI_PAY = 20;
    /**
     * 菜品已估清或者数量不足
     */
    public final static int ERROR_SELL_OUT = 20001;

}
