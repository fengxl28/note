package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * Created by qinwei on 2017/12/20.
 */

public class DeptDBUtils {

    /**
     * 查打印机是否被 部门使用
     *
     * @param fsDeptId    部门id
     * @param printerName 打印机名称
     * @return
     */
    public static boolean isExist(String fsDeptId, String printerName) {
        String sql = "select count(*) from tbdept where fsPrinterName='" + printerName + "' and fistatus=1 AND fsDeptId='" + fsDeptId + "'";
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(count, 0) > 0;
    }

    public static DeptDBModel queryById(String fsDeptId) {
        String sql = "select * from tbdept where fistatus=1 and fsDeptId='" + fsDeptId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, DeptDBModel.class);
    }

    /**
     * 修改普通制作部门 关联打印机名称
     *
     * @param name        打印机名称
     * @param userDBModel
     */
    public static void updateMakeDeptPrinterName(String name, UserDBModel userDBModel) {
        DeptDBModel deptDBModel = queryById("2");
        if (deptDBModel != null) {
            deptDBModel.fsPrinterName = name;
            deptDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            if (userDBModel != null) {
                deptDBModel.fsUpdateUserId = userDBModel.fsUpdateUserId;
                deptDBModel.fsUpdateUserName = userDBModel.fsUpdateUserName;
            }
            deptDBModel.sync = 1;
            deptDBModel.replaceNoTrans();
        }
    }

    /**
     * 修改标签部门 关联打印机名称
     *
     * @param name        打印机名称
     * @param userDBModel
     */
    public static void updateTagDeptPrinterName(String name, UserDBModel userDBModel) {
        DeptDBModel deptDBModel = queryById("3");
        if (deptDBModel != null) {
            deptDBModel.fsPrinterName = name;
            deptDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            if (userDBModel != null) {
                deptDBModel.fsUpdateUserId = userDBModel.fsUpdateUserId;
                deptDBModel.fsUpdateUserName = userDBModel.fsUpdateUserName;
            }
            deptDBModel.sync = 1;
            deptDBModel.replaceNoTrans();
        }
    }

    public static DeptDBModel queryByPrinterName(String printerName) {
        String sql = "select * from tbdept where fistatus=1 and fsPrinterName='" + printerName + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, DeptDBModel.class);
    }


    public static void removeDept(String deptId) {
        String time = DateUtil.getCurrentTime();
        String sql = " update tbdept set sync='1',fiStatus='13',fsUpdateTime='" + time + "' where   fsDeptId='" + deptId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    public static List<DeptDBModel> queryAll() {
        String sql = "select * from tbDept where fiStatus='1'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DeptDBModel.class);

    }

    /**
     * 修改部门 关联打印机名称
     *
     * @param printerItem        打印机信息
     * @param userDBModel
     */
    public static void updateDeptPrinterName(PrinterItem printerItem, String deptId, UserDBModel userDBModel) {
        DeptDBModel deptDBModel = queryById(deptId);
        if (deptDBModel != null) {
            deptDBModel.fsPrinterName = printerItem.name;
            deptDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            deptDBModel.fiIsOneItemCut = printerItem.fiIsOneItemCut;
            if (userDBModel != null) {
                deptDBModel.fsUpdateUserId = userDBModel.fsUpdateUserId;
                deptDBModel.fsUpdateUserName = userDBModel.fsUpdateUserName;
            }
            deptDBModel.sync = 1;
            deptDBModel.replaceNoTrans();
        }
    }

}
