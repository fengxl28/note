package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by qinwei on 2018/10/9.
 */

public class BillSourceDBUtils {

    public static boolean isExist(String fsBillSourceId) {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbBillSource where fsBillSourceId = '" + fsBillSourceId + "'");
        return StringUtil.toInt(count, -1) > 0;
    }
}
