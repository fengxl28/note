package com.mwee.android.pos.businesscenter.driver;

import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.alp.Ack;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.ICallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.AliHotFix;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.mall.UpdatePushToMallResultRequest;
import com.mwee.android.pos.business.mall.model.UploadToMallModel;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.business.active.ActiveUtil;
import com.mwee.android.pos.businesscenter.business.active.ReceiptTempletUtil;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.washdata.WashDataProcessor;
import com.mwee.android.pos.businesscenter.component.keepalive.KeepAlive;
import com.mwee.android.pos.businesscenter.dbutil.MenuClsPrintSortDBUtil;
import com.mwee.android.pos.businesscenter.framework.BizCenterApplication;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.GetDataResponse;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketHttpResponse;
import com.mwee.android.pos.connect.business.DownLoadDataProcessor;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.util.DownloadFileUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UploadFileUtil;
import com.mwee.android.pos.util.ZipUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.business.config.ConfigProcess;
import com.mwee.myd.server.business.config.lua.LuaConfigProcess;
import com.mwee.myd.server.business.data.ModifyVersionProcessor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * 一些业务类的Driver
 * Created by virgil on 2017/7/11.
 *
 * @author virgil
 */

@SuppressWarnings("unused")
public class BizDriver implements IDriver {

    private static final String TAG = "BizDriver";

    @Override
    public String getModuleName() {
        return "biz";
    }

    @DrivenMethod(uri = "biz/refreshcacheorder")
    public void refreshCacheOrder(OrderCache orderCache) {
        OrderSession.getInstance().refreshCacheOrder(orderCache);
    }

    @DrivenMethod(uri = "biz/callUdpBroad")
    public void callUdpBroad() {
        UdpPushDriver.doBroadCast();
    }

    /**
     * 回掉执行外部的接口和方法
     *
     * @param method String
     * @param param  String[]
     */
    @DrivenMethod(uri = "biz/callBackOuter")
    public void callBackOuter(String method, String... param) {
        if (param != null && param.length > 0) {
            Object[] finalParam = new Object[param.length];
            System.arraycopy(param, 0, finalParam, 0, param.length);
            BizCenterApplication.invoke(method, finalParam);
        } else {
            BizCenterApplication.invoke(method);
        }
    }

    /**
     * 检测新插件
     */
    @DrivenMethod(uri = "biz/checkNewPlugin")
    public void checkNewPlugin() {
        BizCenterApplication.invoke("abcdefg");
    }

    /**
     * 强制切换为新插件
     */
    @DrivenMethod(uri = "biz/loadNew")
    public void loadNew() {
        BizCenterApplication.invoke("hijklmn");
    }

    /**
     * 激活中
     */
    private volatile boolean isActiving = false;

    /**
     * 是否激活中
     *
     * @return boolean
     */
    @DrivenMethod(uri = "biz/isActiving")
    public boolean active() {
        return isActiving;
    }

    /**
     * 激活门店，跨进程调用，需明确返回值
     *
     * @param shopID String
     * @return String
     */
    @DrivenMethod(uri = "biz/active")
    public ResponseData active(String shopID) {
        isActiving = true;
        final StringBuilder sb = new StringBuilder();
        ResponseData response = new ResponseData();
        DBMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
        ActiveUtil.bindAndDownload(shopID, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                isActiving = false;
                response.netResult = responseData.netResult;
                response.responseBean = responseData.responseBean;

                response.resultMessage = responseData.resultMessage;
                response.result = responseData.result;
                response.httpStatus = responseData.httpStatus;
                response.netCost = responseData.netCost;

                if (responseData.responseBean instanceof GetDataResponse) {
                    GetDataResponse response1 = (GetDataResponse) responseData.responseBean;
                    if (!TextUtils.isEmpty(response1.data) && response1.data.length() > 5) {
                        response.responseBean = null;
                    }
                }

               /* if (responseData.responseBean instanceof DownloadTableCountResponse) {
                    DownloadTableCountResponse response1 = (DownloadTableCountResponse) responseData.responseBean;
                    if (!TextUtils.isEmpty(response1.data.toJSONString()) && response1.data.toJSONString().length() > 5) {
                        response.responseBean = null;
                    }
                }*/
            }

            @Override
            public boolean fail(ResponseData responseData) {
                isActiving = false;
                response.netResult = responseData.netResult;
                response.responseBean = responseData.responseBean;

                response.resultMessage = responseData.resultMessage;
                response.result = responseData.result;
                response.httpStatus = responseData.httpStatus;
                response.netCost = responseData.netCost;
                return false;
            }
        });
        return response;
    }

    @DrivenMethod(uri = "biz/onlyActive")
    public ResponseData onlyActive(String shopID) {
        isActiving = true;
        ResponseData response = new ResponseData();
        ActiveUtil.onlyActive(shopID, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                isActiving = false;
                copyResponse(responseData, response);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                isActiving = false;
                copyResponse(responseData, response);
                return false;
            }
        });
        return response;
    }

    private void copyResponse(ResponseData from, ResponseData to) {
        to.netResult = from.netResult;
        to.responseBean = from.responseBean;
        to.result = from.result;
        to.resultMessage = from.resultMessage;
        to.httpStatus = from.httpStatus;
        to.netCost = from.netCost;
    }

    @DrivenMethod(uri = "biz/onlyDownload")
    public ResponseData onlyDownload() {
        ResponseData response = new ResponseData();
        ActiveUtil.onlyDownload(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                copyResponse(responseData, response);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 0);
                copyResponse(responseData, response);
                return false;
            }
        });
        return response;
    }

    @DrivenMethod(uri = "biz/loadDataFromCenter")
    public String loadDataFromCenter() {
        LogUtil.logBusiness(TAG, "loadDataFromCenter no hostId");
        return loadDataFromCenterWithHostId(HostUtil.getCurrentHost());
    }

    @DrivenMethod(uri = "biz/loadDataFromCenterWithHostId")
    public String loadDataFromCenterWithHostId(String hostId) {
        LogUtil.logBusiness(TAG, "loadDataFromCenter hostId=" + hostId);

        String result = "";
        final JSONObject ob = new JSONObject();
        CountDownLatch latch = new CountDownLatch(1);
        IProgressCallback progressCB = new IProgressCallback() {
            @Override
            public void onProgress(int progress, String tag) {
                if (!TextUtils.isEmpty(hostId)) {
                    NotifyToClient.sendTo(hostId, "login/dataSyncProgress", progress + "", tag);
                }
            }
        };

        boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                loadData(latch, ob, progressCB);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (!TextUtils.isEmpty(hostId)) {
                    NotifyToClient.sendTo(hostId, "login/dataSyncFailed", responseData.result + "", responseData.resultMessage);
                }
                ob.put("error", responseData.resultMessage);
                latch.countDown();
                return false;
            }
        }, progressCB);

        if (!doAsyn) {
            LogUtil.logBusiness("BizDriver 正在同步数据");
            return "正在同步数据";
        }

        if (latch.getCount() > 0) {
            try {
                latch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        result = ob.getString("error");
        return result;
    }

    private void loadData(CountDownLatch latch, JSONObject ob, IProgressCallback progressCB) {
        DownLoadDataProcessor.downloadData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness("loadDataFromCenter 下载数据完成，消除同步小黄点");
                ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "0");
                // 同步之后洗数据
                if (!WashDataProcessor.washAfterSync(progressCB)) {
                    ob.put("error", "更新数据失败，请重试");
                }
                NotifyToClient.hideSyncUpdate();
                latch.countDown();
                ServerCache.getInstance().refresh();
                NotifyToClient.broadcast("login/dataChanged");
                ServerCache.getInstance().releaseAllTableQR();
                // 更新小票模板打印排序表
                MenuClsPrintSortDBUtil.forceUpdate();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness("loadDataFromCenter 下载数据失败");
                NotifyToClient.broadcast("login/dataSyncFailed", responseData.result + "", responseData.resultMessage);
                ob.put("error", responseData.resultMessage);
                latch.countDown();
                return false;
            }
        }, progressCB, "", new com.mwee.android.pos.connect.callback.ICallback<List<String>>() {
            @Override
            public void onSuccess(List<String> var1) {
                if (ListUtil.isEmpty(var1)) {
                    return;
                }
                if (var1.contains(DBModel.getTableName(MtableDBModel.class)) || var1.contains(DBModel.getTableName(MareaDBModel.class))) {
                    NotifyToClient.refreshTableQueue();
                }
            }

            @Override
            public void onFailure(int code, String msg) {

            }

            @Override
            public void onExecuteSubThread(List<String> strings) {

            }
        });
    }

    @DrivenMethod(uri = "biz/loadDataFromCenterForAir")
    public String loadDataFromCenterForAir() {
        String result = loadDataFromCenter();
        // Fix Bug <a>http://jira.mwbyd.cn/browse/DINNER-901</a>
        // 小易每次从后台成功获取数据后,客户端都需要拉取一次业务中心全量数据
        if (TextUtils.isEmpty(result)) {
            HostUtil.updateHostPullAll();
            ReceiptTempletUtil.saveReceiptTemplete();
        }
        return result;
    }

    @DrivenMethod(uri = "biz/killprocess")
    public void killingProcess() {
        KeepAlive.forceFinish();
        AliHotFix.killSelf();
    }

    /**
     * 检查阿里热修复的补丁
     */
    @DrivenMethod(uri = "biz/checkAliHotFix")
    public void checkHotFix() {
        NotifyToClient.broadcast("login/checkAliHotFix");
    }

    /**
     * 激活结束
     */
    @DrivenMethod(uri = "biz/finishActive")
    public void finishActiev() {
        if (!BindProcessor.isCurrentHostMain()) {
            KeepAlive.checkFinish(GlobalCache.getContext());
            return;
        }

        MenuItemDBUtils.associateMenuItemWithAskGp();

        refreshCache();

        //矫正一下营业日期
        String historyBusinessDate = HostUtil.getHistoryBusineeDate("");

//        String businessDate = DBMetaUtil.getSettingsValueByKey(META.BUSINESS_DATE);//main表中营业日期 为空
//        if (TextUtils.isEmpty(businessDate)) {
//            DBMetaUtil.updateSettingsValueByKey(META.BUSINESS_DATE, DateUtil.getCurrentDate("yyyy-MM-dd"));
//        }

        if (TextUtils.isEmpty(historyBusinessDate)) {
            //如果历史营业日期为空，则
            HostUtil.updateBusinessDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
        } else {
            HostUtil.updateShopBizStatus();
        }
        refreshFromView();
    }


    /**
     * 刷新缓存
     */
    @DrivenMethod(uri = "biz/refreshCache")
    public void refreshCache() {
        ServerCache.getInstance().refresh();
    }

    /**
     * UI层发起的刷新配置
     */
    @DrivenMethod(uri = "biz/refreshFromView")
    public void refreshFromView() {
        //美易点配置文件检测更新
        ConfigProcess.getInstance().checkCache();
    }

    /**
     * 刷新lua脚本配置
     */
    @DrivenMethod(uri = "biz/refreshLuaConfig")
    public void refreshLuaConfig() {
        LuaConfigProcess.getInstance().checkCache();
    }

    /**
     * 重新激活
     *
     * @param hostID String
     */
    @DrivenMethod(uri = "biz/reActive")
    public void reActive(String hostID) {
        DBMetaUtil.deleteSettingsValueByKey(META.SHOPID);
        DBMetaUtil.deleteSettingsValueByKey(META.TOKEN);
        DBMetaUtil.deleteSettingsValueByKey(META.SEED);
        //清除所有的登录Session
        HostUtil.clearAllSession();
        HostUtil.clearAllHostBindStatus();
        //释放所有的订单锁
        ServerCache.getInstance().releaseAllToken();
    }

    @DrivenMethod(uri = "biz/getAllPrinter")
    public SocketResponse getTableData(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();
        List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbPrinter");
        socketResponse.data = JSON.toJSONString(list);
        return socketResponse;
    }

    @DrivenMethod(uri = "biz/uploadLog")
    public void uploadLog() {
        MwLog.manualCallUploadLog();
    }

    @DrivenMethod(uri = "biz/devDeleteAllOrder")
    public void devDeleteAllOrder() {
        if (!BaseConfig.isProduct()) {
            DBManager.getInstance(APPConfig.DB_MAIN).executeInTransaction(new IDBOperate<Boolean>() {
                @Override
                public Boolean doJob(SQLiteDatabase db) {
                    db.execSQL("delete from tbsell");
                    db.execSQL("delete from tbSellOrderItem");
                    db.execSQL("delete from tbSellOrder");
                    db.execSQL("delete from tbSellReceive");
                    db.execSQL("delete from tbSellCheck");
                    db.execSQL("delete from order_cache");
                    db.execSQL("delete from order_pay_cache");
                    db.execSQL("delete from order_menu_cache");
                    db.execSQL("update tableBiz set fssellno='',fsmtablesteid='1'");
                    OrderSession.getInstance().clearAll();
                    return null;
                }
            });
        }
    }

    @DrivenMethod(uri = "biz/dbUpload")
    public void dbUpload() {
        DriverBus.call("dev/uploadDB", GlobalCache.getContext());
    }

    @DrivenMethod(uri = "biz/httpRequest")
    public SocketResponse dbUpload(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            BaseRequest httpRequest = JSON.parseObject(request.getString("request"), BaseRequest.class);
//            BusinessExecutor.execute(httpRequest, new I)
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid=''," +
                    "biz_status='" + HostStatus.CLOSE + "',current_user_id='',sectionid='' where hostid='" + head.hd
                    + "'");

            socketResponse.code = 0;
            socketResponse.message = "更新成功";
            socketResponse.data = null;
            return socketResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        return socketResponse;
    }

    /**
     * 上送门店版本
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "biz/uploadVersion")
    public SocketResponse uploadVersion(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            BaseSocketHttpResponse response = new BaseSocketHttpResponse();
            CountDownLatch latch = new CountDownLatch(1);
            ModifyVersionProcessor.modifyVersionProcessor(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    response.httpResponse = responseData;
                    latch.countDown();
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    response.httpResponse = responseData;
                    latch.countDown();
                    return false;
                }
            });
            if (latch.getCount() > 0) {
                latch.await();
            }
            socketResponse.code = 0;
            socketResponse.message = "更新成功";
            socketResponse.data = response;
            return socketResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        return socketResponse;
    }

    /**
     * 是否允许上送日志
     *
     * @param state 0，不允许；1，允许
     */
    @DrivenMethod(uri = "biz/allowUpload")
    public void uploadLog(String state) {
        DBMetaUtil.updateSettingsValueByKey(META.DEV_UPLOAD, state);
    }

    /**
     * 设置灾备站点id
     *
     * @param hostId
     */
    @DrivenMethod(uri = "biz/disaster_control")
    public void disasterControl(String hostId) {
        DBMetaUtil.updateSettingsValueByKey(META.DISASTER_CONTROL, hostId);
    }

    /**
     * 更新营业日期
     *
     * @param date
     * @param shopID
     */
    @DrivenMethod(uri = "biz/updateBusinessDate")
    public void updateBusinessDate(String date, String shopID) {
        if (TextUtils.isEmpty(shopID)) {
            shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        }
        ParamvalueDBModel paramvalueDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsParamId = '001' and " +
                "fsShopGUID =(select value from meta where key='104')", ParamvalueDBModel.class);

        if (paramvalueDBModel == null) {
            paramvalueDBModel = new ParamvalueDBModel();
            paramvalueDBModel.lver = 0;
            paramvalueDBModel.fsshopguid = shopID;
            paramvalueDBModel.fsparamid = "001";
        }
        if (!date.contains("-")) {
            paramvalueDBModel.fsParamValue = DateUtil.formartDateStrToTarget(date, "yyyyMMdd", "yyyy-MM-dd");
        } else {
            paramvalueDBModel.fsParamValue = date;
        }
        paramvalueDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        paramvalueDBModel.lver++;
        paramvalueDBModel.replaceNoTrans();
    }

    @DrivenMethod(uri = "biz/updateEnv")
    public void updateEnv(String url) {
        DBMetaUtil.updateSettingsValueByKey(META.DEV_URL, url);
        Constant.setUrlRootTest(url);
    }

    @DrivenMethod(uri = "biz/modifyWorkMode")
    public void modifyWorkMode(String mode) {
        ShopDBModel shop = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop where fiStatus='1'", ShopDBModel.class);
        shop.fiWorkMode = StringUtil.toInt(mode, 0);
        shop.fsUpdateTime = DateUtil.getCurrentTime();
        shop.replaceNoTrans();
        DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, shop.fsUpdateTime);
    }

    @DrivenMethod(uri = "biz/pushMsg")
    public void pushMsg(String hostId, String uniq, String uri) {
        LogUtil.log("发送消息[" + uniq + "]");
        NotifyToClient.sendTo(new Ack() {
            @Override
            public void callback(String uniq, int status) {
                LogUtil.log("消息[" + uniq + "]回执状态[" + status + "]");
            }
        }, hostId, uniq, uri);
    }

    @DrivenMethod(uri = "biz/remove_conn")
    public void remove_conn() {
        NotifyToClient.clearConn();
    }

    /**
     * 商场内网透传
     */
    @DrivenMethod(uri = "biz/uploadDataToMall")
    public void uploadDataToMall(String msgBody) {
        UploadToMallModel model = JSON.parseObject(msgBody, UploadToMallModel.class);
        if (model == null) {
            return;
        }
        String url = model.fileurl;
        String saveDir = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator +
                Environment.DIRECTORY_DOWNLOADS + File.separator + "MWBYD" + File.separator;
        RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 开始下载账单数据：url->" + url + ", 保存到: " + saveDir);
        DownloadFileUtil.downloadFile(url, saveDir, new ICallback<String>() {
            @Override
            public void success(String s) {
                RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 下载账单zip成功：" + s);
                if (model.accessmode == 2) {
                    String zipDir = saveDir + DownloadFileUtil.getSimpleNameFromUrl(url) + File.separator;
                    boolean zipRes = ZipUtil.unZipFolder(s, zipDir);
                    if (zipRes) {
                        FileUtil.deleteAllFile(s);
                        doUploadToMall(model, zipDir);
                    }
                }
            }

            @Override
            public boolean fail(String s) {
                RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 下载账单zip失败：" + s);
                updatePushToMallResult(JSON.parseObject(model.requestparameter), false);
                return false;
            }
        });
    }

    public void doUploadToMall(UploadToMallModel model, String filePath) {
        File file = new File(filePath);
        if (file.isFile()) {
            return;
        }
        File[] files = file.listFiles();
        if (files == null || files.length == 0) {
            return;
        }
        List<String> fileNames = new ArrayList<>();
        for (File f : files) {
            fileNames.add(f.getAbsolutePath());
        }
        LogUtil.log("fileNames:: " + fileNames);
        JSONObject requestParam = JSON.parseObject(model.requestparameter);
        if (requestParam == null) {
            return;
        }
        if (model.accessmode == 0) {
            // TODO Http部分尚未测试，服务端暂不支持
            JSONObject headers = requestParam.getJSONObject("headers");
            LogUtil.log(TAG, "headers: " + headers);
            UploadFileUtil.uploadFiles(model.serveraddress, headers, fileNames, new ICallback<String>() {
                @Override
                public void success(String s) {
                    RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 上传文件到http(" + model.serveraddress + ") 成功");
                    FileUtil.deleteAllFile(filePath);
                    updatePushToMallResult(requestParam, true);
                }

                @Override
                public boolean fail(String s) {
                    RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 上传文件到http(" + model.serveraddress + ") 失败");
                    FileUtil.deleteAllFile(filePath);
                    updatePushToMallResult(requestParam, false);
                    return false;
                }
            });
        } else if (model.accessmode == 2) {
            String port = requestParam.getString("port");
            String userName = requestParam.getString("userName");
            String pwd = requestParam.getString("pwd");
            boolean upload = UploadFileUtil.uploadFilesFTP(model.serveraddress, port, userName, pwd, filePath);
            RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 上传文件到ftp(" + model.serveraddress + ")" + (upload ? "成功" : "失败"));
            // 没有上传成功的，后面会再重复推送，所以这里直接删除
            FileUtil.deleteAllFile(filePath);

            updatePushToMallResult(requestParam, upload);
        }
    }

    private void updatePushToMallResult(JSONObject requestParam, boolean upload) {
        UpdatePushToMallResultRequest request = new UpdatePushToMallResultRequest();
        request.id = requestParam.getString("id") == null ? "" : requestParam.getString("id");
        request.upLoadMsg = new JSONObject();
        request.upLoadMsg.put("status", upload);
        request.upLoadMsg.put("msg", upload ? "Success" : "Failed");
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 反馈上传结果成功：" + JSON.toJSONString(responseData));
            }

            @Override
            public boolean fail(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NET, "商场内网透传 反馈上传结果失败：" + JSON.toJSONString(responseData));
                return false;
            }
        });
    }
}