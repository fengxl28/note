package com.mwee.android.pos.businesscenter.koubei;

import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Created by qinwei on 2018/5/16.
 */

public class PreOrderManager implements PreOrderTakeTask.OnPreOrderAutoTakeTaskListener {
    public LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
    public HashMap<String, PreOrderTakeTask> tasks = new HashMap<>();
    public int MAX_TASK = 3;

    public void handlerNewPreOrder(String orderMessage) {
        if (tasks.size() == MAX_TASK) {
            queue.offer(orderMessage);
        } else {
            PreOrderTakeTask task = new PreOrderTakeTask(orderMessage);
            task.setOnPreOrderAutoTakeTaskListener(this);
            task.start();
            tasks.put("", task);
        }
    }

    @Override
    public void onCompleted(String orderId) {
        tasks.remove(orderId);
        doNext();
    }

    private void doNext() {
        if (queue.size() > 0) {
            handlerNewPreOrder(queue.poll());
        }
    }
}
