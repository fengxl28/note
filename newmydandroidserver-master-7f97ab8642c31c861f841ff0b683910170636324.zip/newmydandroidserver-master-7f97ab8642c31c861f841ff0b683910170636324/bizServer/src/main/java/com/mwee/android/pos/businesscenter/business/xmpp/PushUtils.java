package com.mwee.android.pos.businesscenter.business.xmpp;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.datasync.net.MessageReceivedRequest;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by lxx on 16/8/8.
 */
public class PushUtils {

    /**
     * 收到网络订单推送相关的消息
     * 1、先查看缓存中是否已存在若已存在，表示是重复消息，不再处理
     * 2、去查看DB中是否存在，已存在的不处理
     * 3、若都不存在，表示是新消息，插入到DB中
     *
     * @param msgId
     * @return 已处理过的消息  true: 已处理过； false: 未处理过
     */
    public static boolean recivePushOrderMessage(String msgId) {
        if (ServerCache.getInstance().netOrderCache.checkNetOrderMsgId(msgId)) {
            return true;
        }

        DataModel dataModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select msg name, msgResult value from push_msg_stack where msg = '" + msgId + "' and msgBizValue = '1000'", DataModel.class);
        if (dataModel != null) {
            return true;
        } else {
            addNewPushMessage(msgId);
            return false;
        }
    }

    /**
     * 新增推送消息
     *
     * @param msgId
     */
    public static void addNewPushMessage(String msgId) {
        String time = DateUtil.getCurrentTime();
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "insert into push_msg_stack ('msg', 'updateTime', 'msgResult', 'msgBizValue') values ('" + msgId + "','" + time + "', '0','1000')");
    }

    /**
     * 更新推送回执消息
     *
     * @param msgId
     */
    public static void updatePushMessage(String msgId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update push_msg_stack set msgResult = '1' where  msgBizValue = '1000' and msg = '" + msgId + "'");
    }

    /**
     * 两分钟回执一条
     * CALL ME 两分钟会不会时间太久
     */
    public static synchronized void notifyServiceLoop() {
        GlobalLooper.registBasedOn2Minutes(iLoopCall, 5);
    }

    private final static ILoopCall iLoopCall = new ILoopCall() {
        @Override
        public void call() {
            String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            //删除超过10分钟缓存的推送消息
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from push_msg_stack where msgBizValue = '1000' and ((strftime('%s','" + currentTime + "') - strftime('%s',updateTime))>600) ");
            GlobalLooper.unRegist(this);

        }
    };

    /**
     * 发送网络请求
     * <p>
     * 请求成功后把DB中消息标为已回执
     * 请求失败也会有轮询机制补偿
     *
     * @param msgID
     */
    private static void executRequest(final String msgID) {
        if (!TextUtils.isEmpty(msgID)) {
            MessageReceivedRequest getDataRequest = new MessageReceivedRequest();
            getDataRequest.msgId = msgID;
            BusinessExecutor.execute(getDataRequest, null, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    LogUtil.log("消息回执成功：" + msgID);
                    updatePushMessage(msgID);
                    ServerCache.getInstance().netOrderCache.releaseNetOrderMsgId(msgID + "");
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    LogUtil.log("消息回执失败：" + msgID);
                    return false;
                }
            });
        }
    }
}
