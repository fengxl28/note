package com.mwee.android.pos.businesscenter.db;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Table表数据管理工具
 * Created by qinwei on 2019/3/11 8:54 PM
 * email: qin.wei@mwee.cn
 */
public class DTOTableDBController {
    /**
     * 根据桌台id查询桌台信息
     *
     * @param id
     * @return
     */
    public static MtableDBModel queryById(String id) {
        String sql = "select * from tbmtable where fsmtableid='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    /**
     * 根据桌台名称查询桌台信息
     *
     * @param mTableName
     * @return
     */
    public static MtableDBModel queryByMTableName(String mTableName) {
        String sql = "select * from tbmtable where fsmtablename='" + mTableName + "' AND fiStatus=1";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }


    /**
     * 根据配置找桌台信息
     *
     * @param table_no
     * @return
     */
    public static MtableDBModel queryByTableNoAndTableQRConfig(String table_no) {
        String qr_code_type = ServerSettingHelper.getTableQrCodeType();
        if (TextUtils.equals(qr_code_type, META.VALUE_TABLE_QR_CODE_MW)) {
            //美味码走桌台名
            return queryByMTableName(table_no);
        } else {
            //口碑码走桌台名称
            return queryById(table_no);
        }
    }

    /**
     * 查询所有桌台信息
     *
     * @return
     */
    public static List<MtableDBModel> queryAll() {
        String sql = "select * from tbmtable";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }


    /**
     * 根据主桌台id查询所有拼桌信息
     *
     * @param tableId 主桌id
     * @return 所有拼桌信息
     */
    public static List<MtableDBModel> queryShareTablesByMainTableId(String tableId) {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fshint = '" + tableId + "'", MtableDBModel.class);
    }


    /**
     * 添加拼桌信息
     *
     * @param mtableDBModel 主桌信息
     * @param userDBModel   操作用户
     * @return 拼桌信息
     */
    public static MtableDBModel addShareTable(MtableDBModel mtableDBModel, UserDBModel userDBModel) {
        List<MtableDBModel> mtableDBModels = queryShareTablesByMainTableId(mtableDBModel.fsmtableid);
        List<String> mTableIds = new ArrayList<>();
        if (!ListUtil.isEmpty(mtableDBModels)) {
            for (MtableDBModel dbModel : mtableDBModels) {
                mTableIds.add(dbModel.fsmtableid);
            }
        }
        int key = generateKey(1, mtableDBModel.fsmtableid, mTableIds);
        MtableDBModel shareTable = mtableDBModel.clone();
        shareTable.fsmtablename = shareTable.fsmtablename + "+" + key;
        shareTable.fsmtableid = mtableDBModel.fsmtableid + "_" + key;
        shareTable.fshint = mtableDBModel.fsmtableid;
        shareTable.fistatus = 2;
        shareTable.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        shareTable.fsupdateuserid = userDBModel.fsUserId;
        shareTable.fsupdateusername = userDBModel.fsUserName;
        shareTable.replaceNoTrans();
        return shareTable;
    }

    /**
     * 获取拼桌的后缀名称
     *
     * @param mainTableId
     * @param index
     * @param fsmtableid
     * @return
     */
    private static int generateKey(int index, String mainTableId, List<String> fsmtableid) {
        if (fsmtableid.contains(mainTableId + "_" + index)) {
            index++;
            return generateKey(index, mainTableId, fsmtableid);
        }
        return index;
    }

    public static long update(MtableDBModel mtableDBModel) {
        mtableDBModel.replaceNoTrans();
        return 0;
    }

    public static long delete(String id) {
        MtableDBModel mtableDBModel = queryById(id);
        mtableDBModel.delete();
        return 1;
    }
}
