package com.mwee.android.pos.businesscenter.utils;

import android.support.annotation.StringRes;

import com.mwee.android.base.GlobalCache;

/**
 * Created by qinwei on 2019/2/12 11:01 AM
 * email: qin.wei@mwee.cn
 */
public class StringTool {
    public static String getString(@StringRes int resId) {
        return GlobalCache.getContext().getResources().getString(resId);
    }

    /**
     * Returns a localized formatted string from the application's package's
     * default string table, substituting the format arguments as defined in
     * {@link java.util.Formatter} and {@link java.lang.String#format}.
     *
     * @param resId      Resource id for the format string
     * @param formatArgs The format arguments that will be used for
     *                   substitution.
     * @return The string data associated with the resource, formatted and
     * stripped of styled text information.
     */
    public static String getString(@StringRes int resId, Object... formatArgs) {
        return GlobalCache.getContext().getResources().getString(resId, formatArgs);
    }
}
