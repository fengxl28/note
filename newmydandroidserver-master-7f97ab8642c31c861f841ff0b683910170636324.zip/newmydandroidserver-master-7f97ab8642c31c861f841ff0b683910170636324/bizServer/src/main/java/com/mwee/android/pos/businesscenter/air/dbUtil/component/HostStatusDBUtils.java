package com.mwee.android.pos.businesscenter.air.dbUtil.component;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

/**
 * 站点状态数据表管理
 * Created by qinwei on 2018/7/17.
 */

public class HostStatusDBUtils {
    /**
     * 查询host状态信息
     *
     * @param hostId
     * @return
     */
    public static HostStatusModel queryByHostId(String hostId) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "where hostid='" + hostId + "'", HostStatusModel.class);
    }

    /**
     * 根据hostId进行激活站点
     *
     * @param hostId 站点id
     * @param device 设备id
     */
    public static boolean bindHost(String hostId, String device) {
        HostStatusModel host = HostStatusDBUtils.queryByHostId(hostId);
        if (host == null) {
            host = new HostStatusModel();
        }
        host.device = device;
        host.hostid = hostId;
        host.bind_time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        host.bind_count++;
        host.bind_status = 1;
        host.biz_status = HostStatus.FINISH;
        host.current_user_id = "";
        host.replaceNoTrans();
        return true;
    }

    public static void updateShiftId(String hostId, String shiftID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set shiftid='" + shiftID + "' where hostid='" + hostId + "'");
    }

    public static HostStatusModel queryWaiter(String userId){
        return DBSimpleUtil.query(APPConfig.DB_MAIN,"select * from host_status where hostid = '"+ HostBiz.mealorder+"' and current_user_id = '" +userId+ "'",HostStatusModel.class);
    }
}
