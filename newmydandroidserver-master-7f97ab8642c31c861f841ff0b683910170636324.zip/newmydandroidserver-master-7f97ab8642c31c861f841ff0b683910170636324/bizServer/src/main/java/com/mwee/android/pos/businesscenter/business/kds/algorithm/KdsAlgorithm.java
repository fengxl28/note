package com.mwee.android.pos.businesscenter.business.kds.algorithm;


import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.kds.ICallback;
import com.mwee.android.kds.ILoadCallBack;
import com.mwee.android.kds.IServeCallback;
import com.mwee.android.kds.IUnAssignCallback;
import com.mwee.android.kds.SmartKDS;
import com.mwee.android.kds.SnapshotReadConfig;
import com.mwee.android.kds.SnapshotWriteConfig;
import com.mwee.android.kds.entry.DishItem;
import com.mwee.android.kds.entry.DishServeStatus;
import com.mwee.android.kds.entry.DishesInfo;
import com.mwee.android.kds.entry.FoodItem;
import com.mwee.android.kds.entry.LoadCallResult;
import com.mwee.android.kds.entry.LookupResult;
import com.mwee.android.kds.entry.MenusItem;
import com.mwee.android.kds.entry.OutletItem;
import com.mwee.android.kds.entry.ReviseConfigManager;
import com.mwee.android.kds.entry.ServeResult;
import com.mwee.android.kds.entry.TableItem;
import com.mwee.android.kds.entry.UnAssignResult;
import com.mwee.android.kds.entry.UndoResult;
import com.mwee.android.kds.inner.ServeTableInnerEntry;
import com.mwee.android.kds.utils.ListUtils;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.businesscenter.business.kds.IKds;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.delayqueue.DelayQueue;
import com.mwee.android.pos.component.delayqueue.IDQWorker;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.kds.KdsBarcodeState;
import com.mwee.android.pos.db.business.kds.KdsMakeState;
import com.mwee.android.pos.db.business.kds.KdsMenuItemMergeModel;
import com.mwee.android.pos.db.business.kds.KdsMenuItemStateDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName: KdsAlgorithm
 * @Description: kds - 使用智能算法
 * @author: Cannan
 * @date: 2018/11/6 上午11:25
 */
public class KdsAlgorithm implements IKds {

    /**
     * 算法返回的退菜待分配的dishId前缀
     */
    public static final String ALGORITHM_RETREATED_PREFIX = "retreated";

    /**
     * 算法模型快照基础配置存储文件地址
     */
    public static String FILE_SNAPSHOT_MENU = GlobalCache.getContext().getCacheDir() + "/ALGORITHM/SNAPSHOT/MENU_" + HostUtil.getHistoryBusineeDate("");

    /**
     * 算法模型快照信息存储文件地址
     */
    public static String FILE_SNAPSHOT_INFO = GlobalCache.getContext().getCacheDir() + "/ALGORITHM/SNAPSHOT/INFO_" + HostUtil.getHistoryBusineeDate("");

    /**
     * 算法模型
     */
    private SmartKDS mSmartKDS;

    /**
     * 缓存算法模型快照内容
     */
    private String mSnapshot = "";

    /**
     * 延时刷新任务
     */
    private IDQWorker mWorker = o -> BusinessExecutor.executeNoWait(() -> {
        RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "写入模型快照信息，数据大小：" + (mSnapshot == null ? 0 : mSnapshot.length()));
        FileUtil.writeToFile(GlobalCache.getContext(), mSnapshot, FILE_SNAPSHOT_INFO, false);
        KdsAlgorithm.getInstance().mDelayQueue.done(KDS_SNAPSHOT_TASK);
        return null;
    });

    private static final String KDS_SNAPSHOT_TASK = "WriteSnapshot";

    private DelayQueue mDelayQueue;

    private volatile static KdsAlgorithm instance;

    /**
     * 算法初始化的档口id
     */
    public List<String> mDeptIdList = new ArrayList<>();

    /**
     * 跑马灯(退菜待分配)回调
     */
    private IUnAssignCallback mMarqueeListener = map -> {
        for (String deptId : map.keySet()) {
            String hostId = KDSUtils.queryHostIdByDeptId(deptId);
            if (TextUtils.isEmpty(hostId)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "站点信息为空，待分配退菜信息不推送");
                continue;
            }
            List<UnAssignResult.UnAssignResultInner> info = map.get(deptId);
            if (ListUtil.isEmpty(info)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "站点[" + hostId + "]绑定档口[" + deptId + "]待分配退菜信息为空");
                continue;
            }
            String deptName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsDeptName from tbdept where fsDeptId = '" + deptId + "'");
            NotifyToClient.kdsRetreated(hostId, deptName, JSON.toJSONString(info));
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "站点[" + hostId + "]绑定档口[" + deptId + ", " + deptName + "]刷新退菜分配信息：" + JSON.toJSONString(info));
        }
    };

    /**
     * 操作记录回调
     */
    private ICallback mOperateListener = new ICallback() {

        @Override
        public void dishQuietOverTime(String foodName, String foodCode) {
            LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "待分配退菜[" + foodName + ", " + foodCode + "]状态变更至已退");
        }

        @Override
        public boolean isDebugMode() {
            return !BaseConfig.isProduct();
        }
    };

    /**
     * 菜品加载回调
     */
    private ILoadCallBack mLoadCallBack = map -> {
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调数据: " + JSON.toJSONString(map));
        parseLoadCallback(map);
    };

    /**
     * 处理菜品加载回调
     *
     * @param map
     */
    private void parseLoadCallback(Map<String, List<LoadCallResult>> map) {
        if (map == null || map.size() == 0) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调异常，数据为空 -- " + JSON.toJSONString(map));
            return;
        }
        for (String deptId : map.keySet()) {
            if (TextUtils.isEmpty(deptId)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调异常，档口id为空 -- " + JSON.toJSONString(map));
                continue;
            }
            List<LoadCallResult> foodByPot = map.get(deptId);
            if (ListUtil.isEmpty(foodByPot)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调异常，档口[" + deptId + "]对应菜品为空 -- " + JSON.toJSONString(map));
                continue;
            }
            for (LoadCallResult pot : foodByPot) {
                if (pot == null) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调异常，档口[" + deptId + "]对应拼锅菜品为空 -- " + JSON.toJSONString(map));
                    continue;
                }
                List<ServeTableInnerEntry> dishIdByPot = pot.getdCell();
                if (ListUtil.isEmpty(dishIdByPot)) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "菜品加载回调异常，档口[" + deptId + "]下菜品对应 dishId 为空 -- " + JSON.toJSONString(map));
                    continue;
                }

                // 每一锅并菜生成唯一seq
                String seqPot = UUIDUtil.generateShortUuid();

                // 打印制作单
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "下单->档口[" + deptId + "]加载菜品->打印制作单: " + seqPot);
                String hostId = KDSUtils.queryHostIdByDeptId(deptId);

                DBManager.getInstance().executeInTransactionWithOutThread(db -> {
                    String sql = "" +
                            "update tbKdsMenuItemState\n" +
                            "set fiState          = '" + KdsMakeState.Making + "',\n" +
                            "    fsPotSeq         = '" + seqPot + "',\n" +
                            "    fsUpdateHostId   = '" + hostId + "',\n" +
                            "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "'\n" +
                            "where fsSeq in (" + optSqlParams(dishIdByPot, new StringFormatter<ServeTableInnerEntry>() {
                        @Override
                        public String toString(ServeTableInnerEntry entry) {
                            return entry.dishId;
                        }
                    }) + ") AND fsDeptId = '" + deptId + "' ";
                    db.execSQL(sql);

                    for (ServeTableInnerEntry entry : dishIdByPot) {
                        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "处理菜品加载回调[parseLoadCallback] -> 更新tbKdsBarcode为Printed[" + seqPot + "]: " + entry.dishId);
                        db.execSQL("REPLACE INTO tbKdsBarcode (dishId, barcode, deptId, state) VALUES ('" + entry.dishId + "', '" + seqPot + "', '" + deptId + "', '" + KdsBarcodeState.Printed + "')");
                    }
                    return null;
                });

                //制作单打印 todo 都是坑！！！seqPot是new 出来的，放在update tbKdsMenuItemState之前查个毛
                PrintOrderUtil.kdsAMakeOrder(deptId, seqPot, new BigDecimal(dishIdByPot.size()), hostId);
            }
        }
    }

    private KdsAlgorithm() {
        mDelayQueue = new DelayQueue<>("KdsSnapshot");
        mDelayQueue.setWorker(mWorker);
    }

    public static KdsAlgorithm getInstance() {
        if (instance == null) {
            synchronized (KdsAlgorithm.class) {
                if (instance == null) {
                    instance = new KdsAlgorithm();
                }
            }
        }
        instance.checkAlgorithm();
        return instance;
    }

    private synchronized void checkAlgorithm() {
        if (mSmartKDS == null) {
            LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#checkAlgorithm--" + System.currentTimeMillis() + "--准备进入Smarkds模块实例化");
            long startTime = System.currentTimeMillis();
            if (BaseConfig.isDEV()) {
                initByBaseData();
                LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#checkAlgorithm--initByBaseData--耗时--" + (System.currentTimeMillis() - startTime) + "--");
            } else if (DBMetaUtil.loadKdsBySnapshot()) {
                initBySnapshot();
                LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#checkAlgorithm--initBySnapshot--耗时--" + (System.currentTimeMillis() - startTime) + "--");
            } else {
                initByBaseData();
                LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#checkAlgorithm--initByBaseData--耗时--" + (System.currentTimeMillis() - startTime) + "--");
            }
        }
    }

    /**
     * 通过基础数据构建算法模型
     */
    private void initByBaseData() {
        Map<String, MenusItem.MenuItemInner> menuResult = KDSUtils.initAMenu();
        if (menuResult == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "构建菜品数据为空，停止加载算法模型");
            menuResult = new HashMap<>();
        }

        List<OutletItem> deptResult = KDSUtils.initADept();
        if (deptResult == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "构建档口数据为空，停止加载算法模型");
            deptResult = new ArrayList<>();
        }

        mSmartKDS = new SmartKDS(menuResult, deptResult, new SnapshotWriteConfig() {
            @Override
            public void writeSnapshot(String var) {
                mSnapshot = var;
                mDelayQueue.addTask(KDS_SNAPSHOT_TASK);
            }

            @Override
            public void writeMenuData(String var) {
                RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "写入菜品快照信息，数据大小：" + (var == null ? 0 : var.length()));
                FileUtil.writeToFile(GlobalCache.getContext(), var, FILE_SNAPSHOT_MENU, false);
            }
        }, mOperateListener, mMarqueeListener, mLoadCallBack);

        this.mDeptIdList.clear();
        for (OutletItem outletItem : deptResult) {
            if (outletItem == null) {
                continue;
            }
            this.mDeptIdList.add(outletItem.getOutletId());
        }

        // 第一次加载后，修改标识位，之后从快照回复算法模型
        DBMetaUtil.updateSettingsValueByKey(META.KDS_LOAD_SNAPSHOT, "1");
    }

    /**
     * 从快照中回复算法模型
     */
    private void initBySnapshot() {
        mSmartKDS = new SmartKDS(new SnapshotReadConfig() {
            @Override
            public String getSnapshotResource() {
                // 恢复快照信息
                String var = FileUtil.readFile(FILE_SNAPSHOT_INFO);
                RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "读取模型快照信息，数据大小：" + (var == null ? 0 : var.length()));
                return var;
            }

            @Override
            public String getMenuData() {
                String var = FileUtil.readFile(FILE_SNAPSHOT_MENU);
                RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "读取菜品快照信息，数据大小：" + (var == null ? 0 : var.length()));
                return var;
            }

            @Override
            public void writeSnapshot(String var) {
                // 存储快照信息
                RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "写入模型快照信息，数据大小：" + (var == null ? 0 : var.length()));
                mSnapshot = var;
                mDelayQueue.addTask(KDS_SNAPSHOT_TASK);
            }

            @Override
            public void writeMenuData(String var) {
                RunTimeLog.addLog(RunTimeLog.KDS_SNAPSHOT, "写入菜品快照信息，数据大小：" + (var == null ? 0 : var.length()));
                FileUtil.writeToFile(GlobalCache.getContext(), var, FILE_SNAPSHOT_MENU, false);
            }
        }, mOperateListener, mMarqueeListener, mLoadCallBack);
    }

    @Override
    public void init() {

    }

    /**
     * 下单后进入智能算法的菜品，暂不打印，待算法队列处理后，从「等待制作」变更为「制作中」打印制作单
     *
     * @param orderCache OrderCache | 订单相关信息
     * @param data       ArrayMap | key: 打印部门id, value: 部门相关菜品信息
     * @param hostID     String | 站点id
     */
    @Override
    public void order(OrderCache orderCache, ArrayMap<String, Set<SellOrderItemDBModel>> data, ArrayMap<String, List<String>> deptMapping, String hostID, UserDBModel user) {
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法开始下单");
        if (data == null || data.size() == 0) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#order 菜品列表为空");
            return;
        }
        Collection<SellOrderItemDBModel> defaultMenu = data.get("default");
        if (ListUtils.isEmpty(defaultMenu)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#order 默认菜品列表为空");
            return;
        }
        List<SellOrderItemDBModel> originMenuList = new ArrayList<>(defaultMenu);

        // 数据结构转化
        DishesInfo info = KDSUtils.buildAlgorithmData(orderCache, originMenuList, deptMapping);
        if (info == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#KdsAlgorithmorder 算法下单数据为空");
            return;
        }
        List<DishesInfo> dishesInfoList = new ArrayList<>();
        dishesInfoList.add(info);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "算法下单数据:\n" + JSON.toJSONString(dishesInfoList));
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型开始下单");

        if (orderCache.fiSellType == 2 || orderCache.fiSellType == 1) {//快餐/外卖
            mSmartKDS.packaged(dishesInfoList);
        } else {
            mSmartKDS.order(dishesInfoList);
        }

        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型结束下单");
    }

    /**
     * 外卖下单后进入智能算法的菜品，暂不打印，待算法队列处理后，从「等待制作」变更为「制作中」打印制作单
     * <p>
     * 外卖包括 美团外卖、饿了么外卖、口碑外卖
     */
    @Override
    public void wmOrder(TempAppOrder tempAppOrder, List<PrintItemDataBean> sellOrderItemDBModels, int beforeTime) {
        LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "--wmOrder--" +
                DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 智能算法开始下单");

        if (sellOrderItemDBModels == null) {
            return;
        }

        // 数据结构转化
        DishesInfo info = KDSUtils.buildAlgorithmData(tempAppOrder, sellOrderItemDBModels, beforeTime);
        if (info == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#KdsAlgorithmorder 算法下单数据为空");
            return;
        }
        List<DishesInfo> dishesInfoList = new ArrayList<>();
        dishesInfoList.add(info);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "算法下单数据:\n" + JSON.toJSONString(dishesInfoList));
        LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型开始下单");
        mSmartKDS.packaged(dishesInfoList);
        LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型结束下单");
    }


    @Override
    public void weigh(OrderCache order, String fsSeq, String hostId, UserDBModel user) {
        String sql = "select * from tbKdsMenuItemState where fsOriginSeq = '" + fsSeq + "' ";
        KdsMenuItemStateDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, KdsMenuItemStateDBModel.class);
        if (model == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#weigh 未能找到菜品[" + fsSeq + "]");
            return;
        }
        MenuItem menuItem = OrderSaveDBUtil.getMenuByUniq(fsSeq);
        String sql2 = "select * from tbSellOrderItem where fsSeq = '" + fsSeq + "'";
        SellOrderItemDBModel sellOrderItemDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql2, SellOrderItemDBModel.class);
        List<DishItem> dishList = KDSUtils.buildAMenu(order, menuItem, sellOrderItemDBModel, model);
        TableItem table = KDSUtils.buildATable(order);

        DishesInfo info = new DishesInfo(table, dishList);
        List<DishesInfo> dishesInfoList = new ArrayList<>();
        dishesInfoList.add(info);
        LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法(称重)下单数据:\n" + JSON.toJSONString(dishesInfoList));

//        load(hostId, user);
        if (order.fiSellType == 1 || order.fiSellType == 2) {//快餐/外卖
            mSmartKDS.packaged(dishesInfoList);
        } else {
            mSmartKDS.order(dishesInfoList);
        }
    }

    @Override
    public void serving(List<String> optSeqList, String hostID, UserDBModel user) {
        if (ListUtil.isEmpty(optSeqList)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#wakeUp 菜品列表为空");
            return;
        }

        // 从本地KDS数据库中读取菜品拆分出来的所有单份菜品
        String strSeq = ListUtil.optSqlParams(optSeqList);
        String sql = "" +
                "select fsSeq\n" +
                "from tbKdsMenuItemState\n" +
                "where fsOriginSeq in (" + strSeq + ")\n" +
                "   or fsOriginSeq_M in (" + strSeq + ")";
        List<String> data = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (data != null) {
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始算法模型起菜");
            for (String seq : data) {
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法起菜[" + seq + "]");
                mSmartKDS.start(seq);
            }
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成算法模型起菜");
        }

        // 起菜后，需要加载菜品
//        load(hostID, user);
    }

    @Override
    public void hurry(String orderID, List<String> optSeqList) {
        if (ListUtil.isEmpty(optSeqList)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#hurry 菜品列表为空");
            return;
        }

        // 从本地KDS数据库中读取菜品拆分出来的所有单份菜品
        String strSeq = ListUtil.optSqlParams(optSeqList);
        String sql = "" +
                "select fsSeq\n" +
                "from tbKdsMenuItemState\n" +
                "where (fsOriginSeq in (" + strSeq + ") or fsOriginSeq_M in (" + strSeq + "))\n" +
                "  and fiState in ('" + KdsMakeState.ToBeProduced + "', '" + KdsMakeState.Making + "')";
        List<String> data = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (data != null) {
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始通知算法模型催菜");
            for (String seq : data) {
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法催菜[" + orderID + ", " + seq + "]");
                mSmartKDS.urge(orderID, seq);
            }
            LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成通知算法模型催菜");
        }
    }

    @Override
    public void delimit(String deptID, String menu, String foodId, BigDecimal num, boolean isUnAssign, String hostID, UserDBModel user, String barCode) {
        if (TextUtils.isEmpty(deptID)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--划菜操作部门为空");
            return;
        }
        if (TextUtils.isEmpty(menu)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--待划菜菜品名称为空");
            return;
        }
        if (num == null || num.compareTo(BigDecimal.ZERO) == 0) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--待划菜菜品数量为空");
            return;
        }

        // 通知算法划菜
        FoodItem foodItem = new FoodItem();
        foodItem.setFoodName(menu);
        foodItem.setFoodId(String.valueOf(foodId));
        foodItem.setNum(num.intValue());
        List<String> unServedDishs = KDSUtils.queryUnServedDishIdListByPotId(barCode);
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit 查询barCode[" + barCode + "]对应的dishId:", unServedDishs != null ? JSON.toJSONString(unServedDishs) : "[None]");
        if (unServedDishs != null && unServedDishs.size() >= num.intValue()) {
            foodItem.setDishCell(unServedDishs.subList(0, num.intValue()));
        } else {
            LogUtil.logError("KdsAlgorithm#delimit 读取未划菜DishId集合异常:" + barCode);
            return;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit 调用算法：档口[" + deptID + "]划菜[" + menu + "], 数量[" + num.toPlainString() + "],小票标识[" + barCode + "],是否退菜[" + isUnAssign + "]");

        final Object lock = new Object();
        IServeCallback callback = new IServeCallback() {
            @Override
            public void onSuccess(ServeResult serveResult) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--IServeCallback#onSuccess--" + System.currentTimeMillis() + "--准备解析划菜结果");
                long startParseTime = System.currentTimeMillis();
                parseServerResult(deptID, menu, foodId, hostID, user, barCode, foodItem.getDishCell(), serveResult);
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--IServeCallback#onSuccess--耗时--" + (System.currentTimeMillis() - startParseTime) + "--解析划菜结果完成");
            }

            @Override
            public void onError(Throwable throwable) {
                LogUtil.logError(throwable);
            }

            @Override
            public void onFinally() {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--IServeCallback#onFinally--" + System.currentTimeMillis() + "--准备对lock添加同步锁");
                synchronized (lock) {
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--IServeCallback#onFinally--" + System.currentTimeMillis() + "--准备唤醒lock锁");
                    long startNotifyLock = System.currentTimeMillis();
                    lock.notify();
                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--IServeCallback#onFinally--耗时--" + (System.currentTimeMillis() - startNotifyLock) + "--唤醒lock锁完成");
                }
            }
        };
        BusinessExecutor.executeNoWait(() -> {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--mSmartKDS.serve--" + System.currentTimeMillis() + "--准备调用算法划菜方法：" + "[" + JSON.toJSONString(deptID) + "][" + JSON.toJSONString(foodItem) + "]");
            long startServeTime = System.currentTimeMillis();
            mSmartKDS.serve(deptID, foodItem, isUnAssign, callback);
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--mSmartKDS.serve--耗时--" + (System.currentTimeMillis() - startServeTime) + "--调用算法划菜完成");
            return null;
        });
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--lock.wait()--" + System.currentTimeMillis() + "--准备lock同步锁");
        synchronized (lock) {
            try {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--lock.wait()--" + System.currentTimeMillis() + "--准备进入lock等待");
                lock.wait();
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#delimit--lock.wait()--" + System.currentTimeMillis() + "--lock等待结束，继续主流程");
            } catch (InterruptedException e) {
                LogUtil.logError(e);
            }
        }
    }

    /**
     * 处理划菜结果
     *
     * @param deptID      部门did
     * @param menu        菜品名称
     * @param foodId      {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiItemCd}
     * @param hostID      站点id
     * @param user        操作用户
     * @param serveResult
     */
    private void parseServerResult(String deptID, String menu, String foodId, String hostID, UserDBModel user, String barCode, List<String> dishCell, ServeResult serveResult) {
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型划菜Callback");
        if (serveResult == null) {
            LogUtil.logBusiness(RunTimeLog.KDS_RUNTIME, "划菜异常，ServeResult 为空");
            return;
        }
        Map<String, List<ServeTableInnerEntry>> dishByOrder = serveResult.getTableDict();
        if (dishByOrder == null || dishByOrder.size() == 0) {
            LogUtil.logBusiness(RunTimeLog.KDS_RUNTIME, "划菜异常，ServeResult#getTableDict() 为空 ---- " + JSON.toJSONString(serveResult));
            return;
        }
        LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#parseServerResult--" + System.currentTimeMillis() + "--开始循环处理算法划菜结果");

        for (String orderId : dishByOrder.keySet()) {
            if (TextUtils.isEmpty(orderId)) {
                LogUtil.logBusiness(RunTimeLog.KDS_RUNTIME, "划菜异常，ServeResult#getTableDict() 订单号为空 ---- " + JSON.toJSONString(serveResult));
                continue;
            }
            if (orderId.startsWith(ALGORITHM_RETREATED_PREFIX)) {
                // 退菜待分配
                optRetreated(dishByOrder.get(orderId), hostID, deptID, foodId, menu, user, barCode);
                // 划菜后，将对应的条码标为已划菜(由于制作中退菜后，dishId丢失，以"retreated_"表示，因此直接标记整张小票的状态)
                String sql = "UPDATE tbKdsBarcode SET state = '" + KdsBarcodeState.Trashed + "' WHERE dishId IN (SELECT dishId FROM tbKdsBarcode WHERE barcode = '" + barCode + "')";
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#parseServerResult 退菜待分配菜品-更新tbKdsBarcode状态为Trashed-[barcode]:" + barCode);
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            } else {
                // 划掉的菜品
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "划菜->打印传菜单: " + JSON.toJSONString(dishByOrder.get(orderId)));
                optServe(barCode, orderId, dishByOrder.get(orderId), hostID, deptID, user);

                //若传入的是以retreated开始的，则解析回传的传入的元素，否则解析算法回传的元素
                String checkDishCellSql = dishCell.get(0).startsWith(ALGORITHM_RETREATED_PREFIX) ? optSqlParams(dishByOrder.get(orderId), new StringFormatter<ServeTableInnerEntry>() {
                    @Override
                    public String toString(ServeTableInnerEntry entry) {
                        return entry.dishId;
                    }
                }) : optSqlParams(dishCell, new StringFormatter<String>() {
                    @Override
                    public String toString(String entry) {
                        return entry;
                    }
                });

                // 根据算法分配结果，更新本地数据(此处与产品沟通，菜品关联的任意档口划菜，即菜品标识为划菜状态)
                String sql2 = "" +
                        "update tbKdsMenuItemState\n" +
                        "set fiState          = '" + KdsMakeState.Completed + "',\n" +
                        "    fsBarCode        = '" + barCode + "',\n" +
                        "    fsServedUniq   = '" + UUIDUtil.generateShortUuid() + "',\n" +
                        "    fsUpdateHostId   = '" + hostID + "',\n" +
                        "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                        "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                        "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                        "where fsSeq in (" + checkDishCellSql + ")";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql2);

                // 划菜后，将对应的条码标为已划菜(注意：划菜时给定的dishCell会从serving_look移除，但是实际算法返回的dishCell并不是当初给定的)
                String sql = "UPDATE tbKdsBarcode SET state = '" + KdsBarcodeState.Served + "' WHERE dishId IN (" + checkDishCellSql + ")";
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#parseServerResult 正常菜品-更新tbKdsBarcode状态为Served[barcode]：" + barCode);
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

                //检查队列是否正常
                List<JSONObject> jsonObjects = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select barcode,dishId from tbKdsBarcode where dishId IN (" + checkDishCellSql + ")");
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "更新划掉的菜品状态为Served:" + JSON.toJSONString(jsonObjects));
            }
        }
        LogUtil.logOnlineDebug("==KDS-TimeOut[" + Thread.currentThread().hashCode() + "]==", "KdsAlgorithm#parseServerResult--" + System.currentTimeMillis() + "--循环处理算法划菜结果完成");
    }

    public static <T> String optSqlParams(List<T> paramList, StringFormatter<T> formatter) {
        if (ListUtil.isEmpty(paramList)) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();

        for (T entry : paramList) {
            stringBuilder.append("'").append(formatter.toString(entry)).append("'").append(",");
        }

        String result = stringBuilder.toString();
        if (!TextUtils.isEmpty(result) && result.length() > 1) {
            result = result.substring(0, result.length() - 1);
        }

        return result;
    }

    public static interface StringFormatter<T> {
        String toString(T entry);
    }

    /**
     * 待分配退菜单
     *
     * @param retreatedIdList
     * @param hostID
     * @param deptID
     * @param foodId
     * @param menu
     * @param user
     */
    private void optRetreated(List<ServeTableInnerEntry> retreatedIdList, String hostID, String deptID, String foodId, String menu, UserDBModel user, String barCode) {
        if (ListUtil.isEmpty(retreatedIdList)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "退菜待分配单解析错误，Retreated id 为空");
            return;
        }
        for (ServeTableInnerEntry entry : retreatedIdList) {
            if (TextUtils.isEmpty(entry.dishId)) {
                continue;
            }
            String seqPot = UUIDUtil.generateShortUuid();
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "划菜 -> 打印退菜待分配单[" + seqPot + "]: " + entry.dishId);
            // 待分配菜品记录，后续扫码划菜需用到
            KdsMenuItemStateDBModel target = new KdsMenuItemStateDBModel();
            target.fsSeq = entry.dishId;
            target.fiItemCd = foodId;
            target.fsDeptId = deptID;
            target.fsPotSeq = seqPot;
            target.fiState = KdsMakeState.PendingAllocation;
            target.name = menu;
            target.fsUpdateHostId = hostID;
            target.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            target.fsUpdateUserId = user.fsUserId;
            target.fsUpdateUserName = user.fsUserName;
            target.replaceNoTrans();
            PrintOrderUtil.kdsARetreated(menu, entry.dishId, target.fsPotSeq, deptID, hostID, user);
        }
        //
        String sql = "" +
                "update tbKdsMenuItemState\n" +
                "set fsBarCode        = '" + barCode + "',\n" +
                "    fsServedUniq   = '" + UUIDUtil.generateShortUuid() + "',\n" +
                "    fsUpdateHostId   = '" + hostID + "',\n" +
                "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                "where name = '" + menu + "' AND fiState = '" + KdsMakeState.Retired + "' AND fsPotSeq = '" + barCode + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 传菜单解析
     *
     * @param dishList
     * @param hostID
     * @param deptID
     */
    private void optServe(String barCode, String orderId, List<ServeTableInnerEntry> dishList, String hostID, String deptID, UserDBModel user) {
        BusinessExecutor.executeNoWait(() -> {
            if (ListUtil.isEmpty(dishList)) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "传菜单解析错误，dishIdList 为空");
                return null;
            }

            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "划菜->订单[" + orderId + "]打印传菜单: " + JSON.toJSONString(dishList));
            // TODO: 2019/3/18 菜单

            // 原逻辑划菜
            List<String> dinnerDishIdList = new ArrayList<>();
            List<String> fastDishIdList = new ArrayList<>();
            if (!ListUtil.isEmpty(dishList)) {
                for (ServeTableInnerEntry entry : dishList) {
                    if (entry.fiSellType == 1) {
                        fastDishIdList.add(entry.dishId);
                    } else if (entry.fiSellType == 0) {
                        dinnerDishIdList.add(entry.dishId);
                    }
                }
            }

            if (!ListUtil.isEmpty(dinnerDishIdList)) {
                PrintOrderUtil.printKdsPassTo(hostID, deptID, orderId, dinnerDishIdList);
            }
            
            if (!ListUtil.isEmpty(fastDishIdList)) {
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                PrintOrderUtil.printFastKdsPassTo(orderCache, user, hostID, fastDishIdList);
            }

            if (!ListUtil.isEmpty(dishList)) {
                for (ServeTableInnerEntry entry : dishList) {
                    if (entry.fiSellType == 0 || entry.fiSellType == 1) {
                        KDSUtils.serveByKds(entry.dishId, hostID, user);
                    }
                }
            }

            return null;
        });
    }

    @Override
    public void unDelimit(String deptId, String hostID, UserDBModel user) {
        if (TextUtils.isEmpty(deptId)) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "部门[" + deptId + "]撤销算法最后一次划菜操作");
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型开始撤销划菜");
        UndoResult result = mSmartKDS.undo(deptId);
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 算法模型完成撤销划菜");

        // 更新本地数据
        if (result == null) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "撤销划菜结果：" + JSON.toJSONString(result));

        List<String> optSeqList = result.getDishIds();
        if (ListUtil.isEmpty(optSeqList)) {
            return;
        }

//        // 本次撤销的 dishId
//        List<String> dishIdByNormal = new ArrayList<>();
//        List<String> dishIdByRetreated = new ArrayList<>();
//
//        for (String dishId : optSeqList) {
//            if (TextUtils.isEmpty(dishId)) {
//                continue;
//            }
//            if (dishId.startsWith(KdsAlgorithm.ALGORITHM_RETREATED_PREFIX)) {
//                List<String> ids = result.getFoodItem().getDishCell();
//                if (ListUtil.isEmpty(ids)) {
//                    continue;
//                }
//                dishIdByRetreated.addAll(ids);
//            } else {
//                dishIdByNormal.add(dishId);
//            }
//        }
//        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "即将撤销划菜的 dishId：" + JSON.toJSONString(dishIdList));

        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            // 1. 还原小票
            // 撤销划菜，需要将 dishId 对应到 barcode，因为多档口的原因，barcode 对应原 dishId 所有档口需要重新标记为未划菜
            String sql2 = "UPDATE tbKdsBarcode SET state = '" + KdsBarcodeState.Printed + "' WHERE dishId IN (" + ListUtil.optSqlParams(result.getFoodItem().getDishCell()) + ")";
//                    "      (SELECT dishId\n" +
//                    "       FROM tbKdsBarcode\n" +
//                    "       WHERE barcode IN (SELECT fsPotSeq FROM tbKdsMenuItemState WHERE fsSeq IN (" + ) + ")))";
            db.execSQL(sql2);

            //检查队列是否正常
            List<JSONObject> jsonObjects = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select barcode,dishId from tbKdsBarcode where dishId IN (" + ListUtil.optSqlParams(result.getFoodItem().getDishCell()) + ")");
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "撤销划菜，更新菜品状态为Printed:" + JSON.toJSONString(jsonObjects));

            // 2. 还原菜品
            // 删除已划菜对应的条形码
            String sql = "" +
                    "update tbKdsMenuItemState\n" +
                    "set fiState          = '" + KdsMakeState.Making + "',\n" +
                    "    fsBarCode        = '',\n" +
                    "    fsUpdateHostId   = '" + hostID + "',\n" +
                    "    fsUpdateTime     = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "',\n" +
                    "    fsUpdateUserId   = '" + user.fsUserId + "',\n" +
                    "    fsUpdateUserName = '" + user.fsUserName + "'\n" +
                    "where fsSeq in (" + ListUtil.optSqlParams(result.getDishIds()) + ")";
            db.execSQL(sql);
            return null;
        });
    }

    @Override
    public void retreated(List<String> optSeqList) {
        if (ListUtil.isEmpty(optSeqList)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#retreated 菜品列表为空");
            return;
        }
        for (String seq : optSeqList) {
            LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法退菜[" + seq + "]");
            mSmartKDS.retreat(seq);
        }
    }

    @Override
    public void menuTransfer(List<String> optMenuSeq, OrderCache target) {
        if (ListUtil.isEmpty(optMenuSeq)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#menuTransfer 菜品列表为空");
            return;
        }

        for (String seq : optMenuSeq) {
            LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法转菜[" + seq + "]至订单[" + target.orderID + "]");
            mSmartKDS.dishTransfer(seq, KDSUtils.buildATable(target));
        }
    }

    @Override
    public void tableTransfer(String origin, String target) {
        if (TextUtils.isEmpty(origin)) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#tableTransfer 原始订单号为空");
            return;
        }
        OrderCache orderCache = OrderSaveDBUtil.get(target);
        if (orderCache == null) {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsAlgorithm#tableTransfer 未查询到目标订单[" + target + "]");
            return;
        }
        TableItem tableItem = KDSUtils.buildATable(orderCache);
        List<String> originList = new ArrayList<>();
        originList.add(origin);
        LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "算法换桌, 原桌台[" + origin + "], 目标桌台[" + target + "]");
        mSmartKDS.tableTransfer(originList, tableItem);
    }

    @Override
    public void load(String deptID, int num) {
    }

    @Override
    public boolean changeDishIngredient(List<String> dishIds, String foodName) {
        if (ListUtil.isEmpty(dishIds)) {
            LogUtil.log("KDS#KdsAlgorithm#changeDishIngredient 无菜品需要修改配料菜");
            return false;
        }
        boolean changeDishIngredientStatus = true;
        LogUtil.log("KDS#KdsAlgorithm#changeDishIngredient 算法修改配料菜[" + JSON.toJSONString(dishIds) + "]");
        if (!mSmartKDS.changeDishIngredient(dishIds, foodName)) {
            LogUtil.log("KDS#KdsAlgorithm#changeDishIngredient 算法修改配料菜[" + JSON.toJSONString(dishIds) + "]失败");
            changeDishIngredientStatus = false;
        } else {
            //算法返回修改配料菜成功
            String sql = "update tbKdsMenuItemState set name='" + foodName + "' where fsSeq in (" + ListUtil.optSqlParams(dishIds) + ")";
            LogUtil.log("KdsAlgorithm#changeDishIngredient 修改配料菜：" + sql);
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        }
        return changeDishIngredientStatus;
    }

    /**
     * @param deptId
     * @param state
     * @return
     */
    public Pair<Integer, List<KdsMenuViewBean>> queryDishByDept(String deptId, int state, int pageSize, int pageNum) {
        if (TextUtils.isEmpty(deptId)) {
            return null;
        }

        switch (state) {
            case KdsMakeState.Wait:
            case KdsMakeState.ToBeProduced: {
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + deptId + "]等待制作菜品列表");
                LookupResult result = mSmartKDS.lookupData(deptId, DishServeStatus.Waiting);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + deptId + "]等待制作菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + deptId + "]查询算法待制作菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);

                    int min = (pageNum - 1) * pageSize;
                    if (min > result.getDishCellList().size() || min < 0) {
                        min = 0;
                    }
                    int max = pageNum * pageSize;
                    if (max > result.getDishCellList().size()) {
                        max = result.getDishCellList().size();
                    }

                    return new Pair<>(result.getDishCellList().size(), convertAlgorithmResult(deptId, result.getDishCellList().subList(min, max), state));
                }
            }
            break;
            case KdsMakeState.PendingAllocation: {
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + deptId + "]退菜待分配菜品列表");
                LookupResult result = mSmartKDS.lookupData(deptId, DishServeStatus.UnAssign);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + deptId + "]退菜待分配菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + deptId + "]查询算法退菜待分配菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);

                    int min = (pageNum - 1) * pageSize;
                    if (min > result.getDishCellList().size() || min < 0) {
                        min = 0;
                    }
                    int max = pageNum * pageSize;
                    if (max > result.getDishCellList().size()) {
                        max = result.getDishCellList().size();
                    }

                    return new Pair<>(result.getDishCellList().size(), convertAlgorithmResult(deptId, result.getDishCellList().subList(min, max), state));
                }
            }
            break;
            case KdsMakeState.Completed:
            case KdsMakeState.Retired:
                String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fiState = '" + state + "' AND fsDeptID = '" + deptId + "' GROUP BY fsBarCode ORDER BY fsUpdateTime DESC";
                List<KdsMenuItemMergeModel> menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemMergeModel.class);

                if (!ListUtil.isEmpty(menuList)) {

                    int min = (pageNum - 1) * pageSize;
                    if (min > menuList.size() || min < 0) {
                        min = 0;
                    }
                    int max = pageNum * pageSize;
                    if (max > menuList.size()) {
                        max = menuList.size();
                    }
                    List<KdsMenuItemMergeModel> tar = menuList.subList(min, max);

                    List<KdsMenuViewBean> result = new ArrayList<>();
                    for (KdsMenuItemMergeModel model : tar) {
                        if (model == null) {
                            continue;
                        }
                        KdsMenuViewBean bean = model.convert(state, model.mergeNum);
                        if (bean == null) {
                            continue;
                        }
                        bean.fsDeptId = deptId;
                        result.add(bean);
                    }
                    return new Pair<>(menuList.size(), result);
                }
                break;
            default:
                break;
        }
        return null;
    }

    /**
     * @param deptId
     * @param state
     * @return
     */
    public Pair<Integer, List<List<String>>> queryDishIdByAlg(String deptId, int state) {
        if (TextUtils.isEmpty(deptId)) {
            return null;
        }

        switch (state) {
            case KdsMakeState.Wait:
            case KdsMakeState.ToBeProduced: {
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + deptId + "]等待制作菜品列表");
                LookupResult result = mSmartKDS.lookupData(deptId, DishServeStatus.Waiting);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + deptId + "]等待制作菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + deptId + "]查询算法待制作菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return new Pair<>(result.getDishCellList().size(), result.getDishCellList());
                }
            }
            break;
            case KdsMakeState.PendingAllocation: {
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + deptId + "]退菜待分配菜品列表");
                LookupResult result = mSmartKDS.lookupData(deptId, DishServeStatus.UnAssign);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + deptId + "]退菜待分配菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + deptId + "]查询算法退菜待分配菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return new Pair<>(result.getDishCellList().size(), result.getDishCellList());
                }
            }
            break;
            default:
                break;
        }
        return null;
    }

    public Pair<Integer, List<KdsMenuViewBean>> queryDishIdByLocal(String hostId, int state, int pageSize, int pageNum) {
        if (TextUtils.isEmpty(hostId)) {
            return null;
        }
        List<String> deptIdList = KDSUtils.queryDeptIdByHostId(hostId);
        if (ListUtil.isEmpty(deptIdList)) {
            return null;
        }

        List<KdsMenuItemMergeModel> origin = new ArrayList<>();
        for (String deptId : deptIdList) {
            String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fiState = '" + state + "' AND fsDeptID = '" + deptId + "' GROUP BY " + (KdsMakeState.Completed == state ? "fsServedUniq" : "fsPotSeq") + " ORDER BY fsUpdateTime DESC";
            List<KdsMenuItemMergeModel> menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemMergeModel.class);
            if (ListUtil.isEmpty(menuList)) {
                continue;
            }
            origin.addAll(menuList);
        }
        if (ListUtil.isEmpty(origin)) {
            return null;
        }

        List<KdsMenuViewBean> result = new ArrayList<>();

        int min = (pageNum - 1) * pageSize;
        if (min > origin.size() || min < 0) {
            min = 0;
        }
        int max = pageNum * pageSize;
        if (max > origin.size()) {
            max = origin.size();
        }
        List<KdsMenuItemMergeModel> tar = origin.subList(min, max);

        for (KdsMenuItemMergeModel model : tar) {
            if (model == null) {
                continue;
            }
            KdsMenuViewBean bean = model.convert(state, model.mergeNum);
            if (bean == null) {
                continue;
            }
            bean.fsDeptId = model.fsDeptId;
            result.add(bean);
        }
        return new Pair<>(origin.size(), result);
    }

    @Override
    public Pair<Integer, List<KdsMenuViewBean>> query(String depID, int state, int pageSize, int pageNum) {
        if (TextUtils.isEmpty(depID)) {
            return null;
        }
        switch (state) {
            case KdsMakeState.Wait:
                // 等叫
            case KdsMakeState.ToBeProduced: {
                // 待制作
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + depID + "]等待制作菜品列表");
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.Waiting);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + depID + "]等待制作菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法待制作菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    // 更新数据
                    parseAlgorithmResult(result, state);
                    // 数据转换
                    return new Pair<>(result.getDishCellList().size(), convertAlgorithmResult(depID, result, state));
                }
            }
            break;
            case KdsMakeState.Making: {
                // 制作中
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + depID + "]制作中菜品列表");
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.Serving);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + depID + "]制作中菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法制作中菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return new Pair<>(result.getDishCellList().size(), convertAlgorithmResult(depID, result, state));
                }
            }
            break;
            case KdsMakeState.PendingAllocation: {
                // 退菜待分配
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + depID + "]退菜待分配菜品列表");
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.UnAssign);
                LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + depID + "]退菜待分配菜品列表");
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法退菜待分配菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return new Pair<>(result.getDishCellList().size(), convertAlgorithmResult(depID, result, state));
                }
            }
            break;
            case KdsMakeState.Completed:
                // 已完成
            case KdsMakeState.Retired: {
                // 已退
                String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fiState = '" + state + "' AND fsDeptID = '" + depID + "' GROUP BY fsBarCode ORDER BY fsUpdateTime DESC";
                List<KdsMenuItemMergeModel> menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemMergeModel.class);

                if (!ListUtil.isEmpty(menuList)) {
                    List<KdsMenuViewBean> result = new ArrayList<>();
                    for (KdsMenuItemMergeModel model : menuList) {
                        if (model == null) {
                            continue;
                        }
                        KdsMenuViewBean bean = model.convert(state, model.mergeNum);
                        if (bean == null) {
                            continue;
                        }
                        bean.fsDeptId = depID;
                        result.add(bean);
                    }
                    return new Pair<>(menuList.size(), result);
                }
            }
            break;
            default:
                break;
        }
        LogUtil.log("KDS", "结束查询档口[" + depID + "]菜品状态[" + state + "]列表：" + DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS"));
        return null;
    }

    /**
     * 制作中查询
     *
     * @param deptId 制作部门id
     * @return
     */
    public List<KdsMenuViewBean> queryByMaking(String deptId) {
//        if (TextUtils.isEmpty(deptId)) {
//            return null;
//        }
//        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始查询档口[" + deptId + "]制作中菜品列表");
//        LookupResult result = mSmartKDS.lookupData(deptId, DishServeStatus.Serving);
//        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 完成查询档口[" + deptId + "]制作中菜品列表");
//        LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + deptId + "]查询算法制作中菜品：\n" + JSON.toJSONString(result));
//        if (result == null) {
//            return null;
//        }
//        parseAlgorithmResult(result, KdsMakeState.Making);
//        return convertAlgorithmResult(deptId, result);

        // 按未打印小票显示
//        String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fiState IN ('" + KdsMakeState.Making + "', '" + KdsMakeState.Completed + "', '" + KdsMakeState.Retired + "') AND fsDeptID = '" + deptId + "' AND fsPotSeq NOT IN (SELECT fsBarCode FROM tbKdsMenuItemState WHERE fsDeptID = '" + deptId + "' GROUP BY fsBarCode) GROUP BY fsPotSeq ORDER BY fsUpdateTime ASC";
        String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fsDeptID = '" + deptId
                + "' AND fsSeq IN (SELECT dishId FROM tbKdsBarcode WHERE state not in ("
                + "'" + KdsBarcodeState.Served + "',"
                + "'" + KdsBarcodeState.Trashed + "'" +
                ")) GROUP BY fsPotSeq ORDER BY fsUpdateTime ASC";
        List<KdsMenuItemMergeModel> menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemMergeModel.class);
        List<KdsMenuViewBean> result = new ArrayList<>();
        if (!ListUtil.isEmpty(menuList)) {
            for (KdsMenuItemMergeModel model : menuList) {
                if (model == null) {
                    continue;
                }
                KdsMenuViewBean bean = model.convert(KdsMakeState.Making, model.mergeNum);
                if (bean == null) {
                    continue;
                }
                bean.fsDeptId = deptId;
                result.add(bean);
            }
        }
        return result;
    }

    /**
     * 查询dishId
     *
     * @param depID
     * @param state
     * @return
     */
    public Map<String, BigDecimal> query(String depID, int state) {
        if (TextUtils.isEmpty(depID)) {
            return null;
        }
        switch (state) {
            case KdsMakeState.Wait:
                // 等叫
            case KdsMakeState.ToBeProduced: {
                // 待制作
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.Waiting);
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法待制作菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    // 更新数据
                    parseAlgorithmResult(result, state);
                    // 数据转换
                    return convertPotByResult(result);
                }
            }
            break;
            case KdsMakeState.Making: {
                // 制作中
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.Serving);
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法制作中菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return convertPotByResult(result);
                }
            }
            break;
            case KdsMakeState.PendingAllocation: {
                // 退菜待分配
                LookupResult result = mSmartKDS.lookupData(depID, DishServeStatus.UnAssign);
                LogUtil.logOnlineDebug(RunTimeLog.KDS_RUNTIME, "档口[" + depID + "]查询算法退菜待分配菜品：\n" + JSON.toJSONString(result));
                if (result != null) {
                    parseAlgorithmResult(result, state);
                    return convertPotByResult(result);
                }
            }
            break;
            case KdsMakeState.Completed:
                // 已完成
            case KdsMakeState.Retired: {
                // 已退
                String sql = "SELECT *, count(*) AS mergeNum FROM tbKdsMenuItemState WHERE fiState = '" + state + "' AND fsDeptID = '" + depID + "' GROUP BY fsBarCode ORDER BY fsUpdateTime DESC";
                List<KdsMenuItemMergeModel> menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KdsMenuItemMergeModel.class);
                if (!ListUtil.isEmpty(menuList)) {
                    List<KdsMenuViewBean> result = new ArrayList<>();
                    for (KdsMenuItemMergeModel model : menuList) {
                        if (model == null) {
                            continue;
                        }
                        KdsMenuViewBean bean = model.convert(state, model.mergeNum);
                        if (bean == null) {
                            continue;
                        }
                        bean.fsDeptId = depID;
                        result.add(bean);
                    }
                    return null;
                }
            }
            break;
            default:
                break;
        }
        return null;
    }

    @Override
    public void payFinish(String orderId) {
        mSmartKDS.eatUp(orderId);
    }

    @Override
    public void refresh() {
        ReviseConfigManager config = mSmartKDS.getReviseConfigManager();
        List<OutletItem> deptResult = KDSUtils.initADept();

        this.mDeptIdList.clear();

        if (!ListUtil.isEmpty(deptResult)) {
            config.updateOutlet(deptResult);

            for (OutletItem outletItem : deptResult) {
                if (outletItem == null) {
                    continue;
                }
                this.mDeptIdList.add(outletItem.getOutletId());
            }
        } else {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "构建档口数据为空，停止刷新算法模型");
        }

        Map<String, MenusItem.MenuItemInner> menuResult = KDSUtils.initAMenu();
        if (menuResult != null && menuResult.size() != 0) {
            config.updateMenusData(menuResult);
        } else {
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "构建菜品数据为空，停止刷新算法模型");
        }
    }

    /**
     * 解析算法返回的查看结果
     *
     * @param result
     * @param state
     */
    public void parseAlgorithmResult(LookupResult result, int state) {
        if (result == null) {
            return;
        }
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始同步算法 Lookup 结果");
        // 更新菜品信息
        if (ListUtil.isEmpty(result.getDishCellList())) {
            return;
        }
        DBManager.getInstance().executeInTransactionWithOutThread(db -> {
            for (List<String> pot : result.getDishCellList()) {
                if (ListUtil.isEmpty(pot)) {
                    continue;
                }
                // 每一锅并菜生成唯一seq
                String seqPot = UUIDUtil.generateShortUuid();
                // 更新菜品对应的并菜数据
                db.execSQL("UPDATE tbKdsMenuItemState SET fsPotSeq = '" + seqPot + "' WHERE fsSeq IN (" + ListUtil.optSqlParams(pot) + ") AND (fiState = '" + KdsMakeState.Wait + "' OR fiState = '" + KdsMakeState.ToBeProduced + "' OR fsPotSeq IS NULL OR fsPotSeq = '')");
            }
            return null;
        });
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 结束同步算法 Lookup 结果");
        return;
    }

    public List<KdsMenuViewBean> convertAlgorithmResultByPot(String deptID, List<String> dishByPot, int state) {
        if (ListUtil.isEmpty(dishByPot)) {
            return null;
        }
        List<List<String>> dish = new ArrayList<>();
        dish.add(dishByPot);
        return convertAlgorithmResult(deptID, dish, state);
    }

    public List<KdsMenuViewBean> convertAlgorithmResult(String deptID, LookupResult result, int state) {
        if (result == null) {
            return null;
        }
        return convertAlgorithmResult(deptID, result.getDishCellList(), state);
    }

    /**
     * 算法结果转换
     *
     * @param deptID
     * @param potList
     * @return
     */
    public List<KdsMenuViewBean> convertAlgorithmResult(String deptID, List<List<String>> potList, int state) {
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 开始转换算法查询结果");
        if (ListUtil.isEmpty(potList)) {
            return null;
        }

        List<KdsMenuViewBean> resultMenu = new ArrayList<>();
        for (List<String> pot : potList) {
            if (ListUtil.isEmpty(pot)) {
                continue;
            }
            // 可以拼菜，则菜品信息相同，所以取任意一个 dishId 获取菜品信息
            String dishId = pot.get(0);
            if (TextUtils.isEmpty(dishId)) {
                continue;
            }

            KdsMenuViewBean bean;
            if (dishId.startsWith(KdsAlgorithm.ALGORITHM_RETREATED_PREFIX)) {
                BigDecimal num = BigDecimal.ONE;
                try {
                    num = new BigDecimal(pot.get(1));
                } catch (Exception ex) {
                    LogUtil.logError(ex);
                }
                dishId = dishId.replace(KdsAlgorithm.ALGORITHM_RETREATED_PREFIX + "_", "");
                bean = KDSUtils.buildMenuBeanFromA(dishId, num);
            } else {
                bean = KDSUtils.buildMenuByDishId(dishId, state, new BigDecimal(pot.size()), deptID);
            }

            if (bean == null) {
                continue;
            }
            bean.fsDeptId = deptID;
            resultMenu.add(bean);
        }
        LogUtil.log("KDS", DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss SSS") + " >>>> 结束转换算法查询结果");
        return resultMenu;
    }

    /**
     * 解析算法模型查询结果
     *
     * @param result
     * @return Map | key: dishId, value: 并菜数量
     */
    private Map<String, BigDecimal> convertPotByResult(LookupResult result) {
        if (result == null) {
            return null;
        }
        List<List<String>> potList = result.getDishCellList();
        if (ListUtil.isEmpty(potList)) {
            return null;
        }
        Map<String, BigDecimal> resultMenu = new HashMap<>();
        for (List<String> pot : potList) {
            if (ListUtil.isEmpty(pot)) {
                continue;
            }
            // 可以拼菜，则菜品信息相同，所以取任意一个 dishId 获取菜品信息
            String dishId = pot.get(0);
            if (TextUtils.isEmpty(dishId)) {
                continue;
            }

            BigDecimal num = BigDecimal.ONE;
            if (dishId.startsWith(KdsAlgorithm.ALGORITHM_RETREATED_PREFIX)) {
                try {
                    num = new BigDecimal(pot.get(1));
                } catch (Exception ex) {
                    LogUtil.logError(ex);
                }
            } else {
                num = new BigDecimal(pot.size());
            }
            resultMenu.put(dishId, num);
        }
        return resultMenu;
    }
}
