package com.mwee.android.pos.businesscenter.business.pay;

import com.mwee.android.pos.component.member.newInterface.net.MemberPayStoreResponse;

/**
 * Created by virgil on 2017/7/20.
 */

public interface IMemberBalance {
    void process(String errorMsg, MemberPayStoreResponse response, boolean needPwd);
}
