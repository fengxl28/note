package com.mwee.android.pos.businesscenter.business.koubei;

import com.mwee.android.air.db.business.kbbean.KBPartRefundReturnResponse;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.businesscenter.koubei.PreOrderCallback;
import com.mwee.android.pos.db.business.UserDBModel;

/**
 * Created by zhangmin on 2018/5/17.
 */

public interface IKBPreOrderListener {


    /**
     * 拉取先付款订单详情
     * @param pageNo
     * @param searchParam
     * @param queryType
     * @param callback
     */
    void loadOrderList(int pageNo, String searchParam,int queryType,String status, BusinessCallback callback);




    /**
     * 根据订单号拉取订单
     *
     * @param order_Id
     * @param callback
     */
    void loadOrder(String order_Id, String merchantPid, BusinessCallback callback);

    /**
     * 接单
     *
     * @param order_id
     * @param merchantId
     * @param tableNo          取餐号
     * @param businessCallback
     */
    void acceptOrder(String order_id, String businessType, String orderStyle, String merchantId, String tableNo, BusinessCallback businessCallback);


    /**
     * 拒单
     *
     * @param order_id
     * @param merchantId
     * @param no
     * @param reason
     * @param businessCallback
     */
    void rejectOrder(String order_id, String merchantId, String no, String reason, BusinessCallback businessCallback);


    /**
     * 备餐
     *
     * @param order_id
     * @param merchantId
     * @param no
     * @param businessCallback
     */
    void prepareOrder(String order_id, String businessType, String merchantId, String no, BusinessCallback businessCallback);


    /**
     * 商户退款
     *
     * @param order_id         口碑订单号
     * @param fsSellNo         美味订单号
     * @param merchantId
     * @param no
     * @param userDBModel
     * @param businessCallback
     */
    void refundOrder(String order_id, String fsSellNo, String merchantId, String no, String reason, UserDBModel userDBModel, BusinessCallback businessCallback);


    /**
     * * 商户部分退款
     *
     * @param order_id         口碑订单号
     * @param fsSellNo         美味订单号
     * @param merchantId
     * @param no
     * @param reason
     * @param refundAmount     退款金额
     * @param userDBModel
     * @param callback
     */
    void partRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String reason, String refundAmount, UserDBModel userDBModel, PreOrderCallback<KBPartRefundReturnResponse> callback);


    /**
     * C端用户发起退款  商户拒绝退款
     *
     * @param order_id         口碑订单号
     * @param fsSellNo         美味订单号
     * @param merchantId
     * @param no
     * @param userDBModel
     * @param businessCallback
     */
    void rejectRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String rejectReason, UserDBModel userDBModel, BusinessCallback businessCallback);


    /**
     * C端用户发起退款 商户同意退款
     *
     * @param order_id          口碑订单号
     * @param fsSellNo          美味订单号
     * @param merchantId
     * @param no
     * @param userDBModel
     * @param agreeRefundReason 商户同意退款的原因
     * @param businessCallback
     */
    void agreenRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String agreeRefundReason, UserDBModel userDBModel, BusinessCallback businessCallback);


    /**
     * 分配桌台
     *
     * @param order_id
     * @param businessType
     * @param merchantId
     * @param tableNo          分配的桌台名称
     * @param businessCallback
     */
    void allocationTable(String order_id, String businessType, String merchantId, String tableNo, BusinessCallback businessCallback);


    /**
     * 已下厨
     *
     * @param order_id
     * @param merchantId
     * @param businessCallback
     */
    void cooking(String order_id, String merchantId, BusinessCallback businessCallback);

}
