package com.mwee.myd.server;

import android.content.Context;
import android.support.annotation.Keep;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.AppEnv;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.exception.DriverBusException;
import com.mwee.android.pos.businesscenter.component.keepalive.KeepAlive;
import com.mwee.android.pos.businesscenter.driver.UdpPushDriver;
import com.mwee.android.pos.businesscenter.framework.BizCenterApplication;
import com.mwee.android.pos.db.APPConfig;

/**
 * Created by virgil on 2018/2/28.
 *
 * @author virgil
 */

@SuppressWarnings("unused")
@Keep
public class ServerProxy {
    @Keep
    public static void work(Context context,Object serverInterface, String envStr) {
        AppEnv env = JSON.parseObject(envStr, AppEnv.class);
        BizCenterApplication.initEnv(context,serverInterface, env);
        BizCenterApplication.init(context);
    }

    @Keep
    public static void keep(Context context) {
        KeepAlive.keep(context);
    }

    @Keep
    public static void doBroadCast() {
        UdpPushDriver.doBroadCast();
    }

    @Keep
    public static void checkFinish(Context context) {
        KeepAlive.checkFinish(context);
    }

    @Keep
    public static void forceFinish() {
        KeepAlive.forceFinish();
    }

    @Keep
    public static <T> T call(String uri, Object... params) throws DriverBusException {
        return DriverBus.call(uri, params);
    }

    @Keep
    public static <T> T call(String uri) throws DriverBusException {
        return DriverBus.call(uri);
    }

    @Keep
    public static void updateEnv(Context context, String currentVersionName, String cachedVersionName) {
        APPConfig.currentVersionName = currentVersionName;
        APPConfig.cachedVersionName = cachedVersionName;
    }
}
