package com.mwee.android.pos.businesscenter.business.shareshop.api;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.shareshop.been.ChangeTableRequest;
import com.mwee.android.pos.business.shareshop.been.UpdateOrderAckStatusRequest;
import com.mwee.android.pos.business.shop.SNIsKBRequest;
import com.mwee.android.pos.business.shop.SNIsKBResponse;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.HardwareUtil;

/**
 * Created by liuxiuxiu on 2018/3/29.
 */

public class ShareShopApi {

    /**
     * 通知云端已处理结束
     *
     * @param orderId
     */
    public static void notifyServerDealSuccess(String orderId, final int retrySeq, int ackStatus) {

        UpdateOrderAckStatusRequest request = new UpdateOrderAckStatusRequest(orderId, ackStatus);

        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {
                    //自动重试三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            notifyServerDealSuccess(orderId, retrySeq + 1, ackStatus);
                        }
                    }, 2000);
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "退款通知回执确认 异常，订单号：" + orderId + "；异常信息：" + JSON.toJSON(responseData));
                return false;
            }
        });
    }

    /**
     * 通知云端换桌
     *
     * @param sourceOuterOrderId | 换桌前的(原)账单号
     * @param sourceTableNo      | 换桌前的(原)桌号
     * @param targetOuterOrderId | 换桌后的（新）账单号
     * @param targetTableNo      | 换桌后的(新)桌号
     * @param retrySeq           | 第X次尝试
     * @param iResult            |  回调
     */
    public static void notifyServerchangeTable(String sourceOuterOrderId, String sourceTableNo, String targetOuterOrderId, String targetTableNo, int retrySeq, IResult iResult) {

        ChangeTableRequest request = new ChangeTableRequest();
        request.sourceOuterOrderId = sourceOuterOrderId;
        request.sourceTableNo = sourceTableNo;
        request.targetOuterOrderId = targetOuterOrderId;
        request.targetTableNo = targetTableNo;

        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(true, "");
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {
                    //自动重试三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            notifyServerchangeTable(sourceOuterOrderId, sourceTableNo, targetOuterOrderId, targetTableNo, retrySeq + 1, iResult);
                        }
                    }, 2000);
                } else {
                    if (iResult != null) {
                        iResult.callBack(false, (responseData != null && responseData.responseBean != null && !TextUtils.isEmpty(responseData.responseBean.errmsg)) ? responseData.responseBean.errmsg : "换桌失败");
                    }
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER, retrySeq + "通知云端换桌 异常，【原订单号，原桌台】-->【新订单号，新桌台】= 【" + sourceOuterOrderId + "," + sourceTableNo + "】--> 【" + targetOuterOrderId + "," + targetTableNo + "】"
                        + sourceOuterOrderId + "；异常信息：" + JSON.toJSON(responseData));
                return false;
            }
        });
    }

    /**
     * 缓存设备售卖渠道
     */
    public static void loadSnIsKBInfo() {
        SNIsKBRequest request = new SNIsKBRequest();
        request.sn = HardwareUtil.getHardWareSymbol();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof SNIsKBResponse) {
                    SNIsKBResponse response = (SNIsKBResponse) responseData.responseBean;
                    DBMetaUtil.updateSettingsValueByKey(META.KEY_SN_DEVICE_CHANNEL, response.data ? META.VALUE_SN_KB : META.VALUE_SN_MW);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }


}
