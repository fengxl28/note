package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;

/**
 * Created by qinwei on 2017/12/15.
 *
 * @author qinwei
 */

public class DataCacheDBUtil {
    /**
     * 添加自定义备注
     *
     * @param note String
     */
    public static void addCustomPayNote(String note) {
        note = note.trim();
        String sql = "select  value from datacache where type='%d' and value='%s'";
        String history = DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sql, IOCache.TYPE_CUSTOME_PAY_NOTE, note));
        if (!TextUtils.equals(history, note)) {
            CacheModel cacheModel = new CacheModel();
            String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            cacheModel.key = note;
            cacheModel.type = IOCache.TYPE_CUSTOME_PAY_NOTE;
            cacheModel.value = note;
            cacheModel.createtime = time;
            cacheModel.updatetime = time;
            cacheModel.replaceNoTrans();
            String sqlClean = "delete from datacache where createtime<(select min(createtime) from (select createtime from datacache where type='%d' order by createtime desc limit 20)) and type='%d'";

            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sqlClean, IOCache.TYPE_CUSTOME_PAY_NOTE, IOCache.TYPE_CUSTOME_PAY_NOTE));
        }
    }

    /**
     * 获取自定义备注列表
     *
     * @return List<String>
     */
    public static List<String> getCustomPayNote() {
        String sql = "select  value from datacache where type='%d'order by createtime desc limit 10";
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sql, IOCache.TYPE_CUSTOME_PAY_NOTE));
    }

    /**
     * 获取自动牌号
     *
     * @return
     */
    public synchronized static CacheModel getAutoMealNumber() {
        String sql = "select  * from datacache where type=" + IOCache.TYPE_AUTO_MEAL_NUMBER;
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, CacheModel.class);
    }

    /**
     * 存储自定牌号序列
     */
    public static String generateNewMealNumber() {
        CacheModel cacheModel = getAutoMealNumber();
        String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        if (cacheModel == null) {
            cacheModel = new CacheModel();
            cacheModel.type = IOCache.TYPE_AUTO_MEAL_NUMBER;
            cacheModel.value = "1";
            cacheModel.createtime = time;
        } else {
            //牌号自动+1 存储
            cacheModel.value = (StringUtil.toInt(cacheModel.value, 1) + 1) + "";
        }
        cacheModel.updatetime = time;
        cacheModel.replaceNoTrans();
        return cacheModel.value;
    }


    /**
     * 存储自定牌号序列
     */
    public static String generateNewKBNO() {

        CacheModel cacheModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select  * from datacache where type=" + IOCache.TYPE_AUTO_KB_N0, CacheModel.class);
        String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        if (cacheModel == null) {
            cacheModel = new CacheModel();
            cacheModel.type = IOCache.TYPE_AUTO_KB_N0;
            cacheModel.value = "KB0001";
            cacheModel.createtime = time;
        } else {

            if (TextUtils.isEmpty(cacheModel.value) || cacheModel.value.length() != 6) {//todo 容错
                cacheModel.value = "KB0001";
            } else {
                int num = Integer.parseInt(cacheModel.value.substring(2, 6)) + 1;
                cacheModel.value = new DecimalFormat("KB0000").format(num);
            }
        }
        cacheModel.updatetime = time;
        cacheModel.replaceNoTrans();
        return cacheModel.value;
    }


    /**
     * 删除牌号
     */
    public static void resetMealNumber() {
        String sql = "update datacache set value='0' where type=" + IOCache.TYPE_AUTO_MEAL_NUMBER;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

        String sqlKB = "update datacache set value='KB0000' where type=" + IOCache.TYPE_AUTO_KB_N0;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlKB);


        String sql1 = "select order_id from fastfood_order_biz where fastfood_biz_status = '0' and lockedStatus = '0' and business_date = '" + HostUtil.getHistoryBusineeDate("") + "' and order_id not in (select order_id from order_pay_cache where business_date = '" + HostUtil.getHistoryBusineeDate("") + "' and payed = '0') ";
        List<String> orderIds = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql1);
        //日切的时候将开单未下单的订单缓存的牌号清空
        if (!ListUtil.isEmpty(orderIds)) {
            for (String orderId : orderIds) {
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                orderCache.mealNumber = "";
                OrderSession.getInstance().writeOrder(orderId, false, "resetMealNumber");
            }
        }
    }

    public static boolean isShowKoBeiHintDialog(String userId){
        String sql = "select value from dataCache where type ='"+ IOCache.TYPE_KB_HINT+"'";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN,sql);
        if(TextUtils.isEmpty(value)){
            return true;
        }
        return !value.contains(userId);
    }

    public static void addUserIdOfKBHintDialog(String userId){
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select value from dataCache where type ='"+ IOCache.TYPE_KB_HINT+"'");
        if(TextUtils.isEmpty(value)){
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,String.format("replace into dataCache(key,biz_key,value,info,type) values('%s','%s','%s','%s','%s')",IOCache.TYPE_KB_HINT,"",userId,"",IOCache.TYPE_KB_HINT));
        }else{
            value = value + "#" + userId;
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,"update dataCache set value = '"+value+"' where type ='"+ IOCache.TYPE_KB_HINT+"' and key = '"+IOCache.TYPE_KB_HINT+"'");
        }
    }

    /**
     * 存储kds算法快照
     *
     * @param var String | 快照数据
     */
    public static void saveKdsAlgorighmSnapshot(String var) {
        if (TextUtils.isEmpty(var)) {
            return;
        }
        String sql = "SELECT * FROM datacache WHERE type = '" + IOCache.KDS_ALGORITHM_SNAPSHOT + "' ";
        CacheModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, CacheModel.class);
        if (model == null) {
            model = new CacheModel();
            String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            model.key = time;
            model.type = IOCache.KDS_ALGORITHM_SNAPSHOT;
            model.createtime = time;
            model.updatetime = time;
        }
        model.value = var;
        model.replaceNoTrans();
    }

    /**
     * 获取kds算法快照数据
     *
     * @return String | 快照数据
     */
    public static String queryKdsAlgorighmSnapshot() {
        String sql = "SELECT value FROM datacache WHERE type='" + IOCache.KDS_ALGORITHM_SNAPSHOT + "' ";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }
    /**
     * 查询今日营业目标
     * @return
     */
    public static String getSalesTarget() {
        String sql = "select value from datacache where type= '" + IOCache.SALES_TARGET + "' and key = 'sales_target'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 更新或插入今日营业目标数据
     * @param value
     */
    public static void saveSalesTarget(String value) {
        if (TextUtils.isEmpty(value)) {
            return;
        }
        String sql = "select * from datacache where type= '" + IOCache.SALES_TARGET + "' and key = 'sales_target'";
        CacheModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, CacheModel.class);
        if (model == null) {
            model = new CacheModel();
            String time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            model.key = "sales_target";
            model.type = IOCache.SALES_TARGET;
            model.createtime = time;
            model.updatetime = time;
        }
        model.value = value;
        model.replaceNoTrans();
    }
}
