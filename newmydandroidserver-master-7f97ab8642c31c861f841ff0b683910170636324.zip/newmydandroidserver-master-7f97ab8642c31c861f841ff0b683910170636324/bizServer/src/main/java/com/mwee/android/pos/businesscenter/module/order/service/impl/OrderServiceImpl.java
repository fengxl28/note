package com.mwee.android.pos.businesscenter.module.order.service.impl;

import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.module.order.service.IOrderService;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.order.OrderCache;

/**
 * Created by qinwei on 2019/3/13 1:52 PM
 * email: qin.wei@mwee.cn
 */
public class OrderServiceImpl implements IOrderService {

    @Override
    public SocketResponse<OrderCache> loadBindMember(OrderCache orderCache, NewMemberCardDetailsModel newMember, String userId) {
        SocketResponse<OrderCache> response = new SocketResponse<>();
        orderCache.setMember(newMember);
        MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, userId);
        orderCache.reCalcAllByAll();
        OrderSession.getInstance().writeOrder(orderCache.orderID, true, "loadBindMember");
        response.set(SocketResultCode.SUCCESS, "绑定成功");
        response.data = orderCache;
        return response;
    }

    @Override
    public SocketResponse<OrderCache> loadUnBindMember(OrderCache orderCache, String userId) {
        SocketResponse<OrderCache> response = new SocketResponse<>();
        if (orderCache.memberInfoS != null) {
            ServerCache.getInstance().releaseMemberComments(orderCache.memberInfoS.card_no);
        }
        orderCache.clearMember();
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "loadUnBindMember");
        response.set(SocketResultCode.SUCCESS, "绑定成功");
        response.data = orderCache;
        return response;
    }
}
