package com.mwee.android.pos.businesscenter.business.xmpp;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by virgil on 2017/3/29.
 */

public class AlertActivity extends AppCompatActivity {
}
