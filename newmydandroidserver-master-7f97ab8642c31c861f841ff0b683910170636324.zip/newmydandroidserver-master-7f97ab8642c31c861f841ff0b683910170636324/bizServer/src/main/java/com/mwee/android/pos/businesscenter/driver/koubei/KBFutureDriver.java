package com.mwee.android.pos.businesscenter.driver.koubei;

import com.mwee.android.drivenbus.IDriver;

/**
 * Created by zhangmin on 2018/10/13.
 */

public class KBFutureDriver implements IDriver {

    private final static String TAG = "kb_future_driver";

    @Override
    public String getModuleName() {
        return TAG;
    }





}
