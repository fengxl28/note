package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.dbutil.ManualIEnvoiceDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ManualInvoicingDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * 电子发票打印的数据构造
 */
public class EInvoicePrintUtil {

    /**
     * 打印小票
     *
     * @param hostId  站点ID
     * @param orderId 小票ID
     */
    public static List<Integer> printManualEInvoice(String orderId, String hostId, UserDBModel userDBModel) {
        if (TextUtils.isEmpty(orderId)) {
            return new ArrayList<>();
        }

        return printManualEInvoice(ManualIEnvoiceDBUtil.optManualInvoicingDBModeById(orderId), hostId, userDBModel);
    }

    /**
     * 打印小票
     *
     * @param manualInvoicingDBModel
     * @param hostId
     * @return
     */
    public static List<Integer> printManualEInvoice(ManualInvoicingDBModel manualInvoicingDBModel, String hostId, UserDBModel userDBModel) {

        List<Integer> printTaskIds = new ArrayList<>();

        if (manualInvoicingDBModel == null) {
            return printTaskIds;
        }

        int printNO = PrintJSONBuilder.generatePrintNO();

        String printName = PrintConnector.getInstance().getPrinterNameByHost(hostId);

        JSONObject datas = new JSONObject();
        datas.put("shopName", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsshopName from tbShop where fsShopGuid='" + ServerCache.getInstance().shopID + "'"));
        datas.put("orderId", manualInvoicingDBModel.orderId);
        datas.put("amt", Calc.format(manualInvoicingDBModel.amt, 2, RoundingMode.HALF_UP).toPlainString());
        datas.put("status", manualInvoicingDBModel.status == 0 ? "未开票" : "已开票");
        datas.put("code", manualInvoicingDBModel.code);
        datas.put("time", manualInvoicingDBModel.createTime);
        datas.put("fiPrintNo", printNO);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MANUAL_E_INVOICE, hostId, true);
        task.uri = "einvoice/manualEInvoice";
        task.fsPrinterName = printName;

        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();

        task.fiPrintNo = printNO;
        task.fsPrnData = value;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }

        ManualIEnvoiceDBUtil.updatePrintTimes(manualInvoicingDBModel.orderId, manualInvoicingDBModel.printTimes + 1, userDBModel.fsUserId, userDBModel.fsUserName);
        return printTaskIds;

    }


}
