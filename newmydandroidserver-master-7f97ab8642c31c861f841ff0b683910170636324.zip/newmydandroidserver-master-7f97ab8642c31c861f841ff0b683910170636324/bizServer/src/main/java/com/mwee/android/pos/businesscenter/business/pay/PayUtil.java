package com.mwee.android.pos.businesscenter.business.pay;

import android.support.annotation.WorkerThread;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.member.IMemberRefund;
import com.mwee.android.pos.business.member.IMemberRefundNew;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobWorker;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundRequest;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeGroup;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2017/3/1.
 */

public class PayUtil {

    /**
     * 生成默认的券Model
     *
     * @return PayOriginModel
     */
    public static PayOriginModel addDefaultCoupon() {
        PayOriginModel model = OrderUtil.buildPayModelByPaymentID(PayType.COUPON_DEFAULT);
        return model;
    }

    /**
     * 是否需要进行会员扣款
     *
     * @return boolean | true：需要会员扣款；false：不需要会员扣款
     */
    public static boolean needConsumMember(PaySession session) {
        if (!ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel temp : session.selectPayListFull) {
                if (temp.status != PayTypeStatus.DELETE) {
                    if (PayType.isMWMemberPoint(temp.data) || PayType.isMWMemberTicket(temp.data)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 获取订单中可参与折扣的金额
     *
     * @param orderCache OrderCache
     * @return BigDecimal
     */
    public static BigDecimal getDiscountAmtByOrderTotal(OrderCache orderCache) {

        BigDecimal amt = BigDecimal.ZERO;
        if (orderCache != null) {
            amt = getDiscountAmtByOrderTotal(orderCache.originMenuList, orderCache.optTotalMenuPrice());
        }
        if (amt.compareTo(BigDecimal.ZERO) <= 0) {
            amt = BigDecimal.ZERO;
        }

        return amt;
    }

    /**
     * 获取订单中可参与折扣的金额
     *
     * @return BigDecimal
     */
    public static BigDecimal getDiscountAmtByOrderTotal(TempOrderDishesCache tempOrder) {

        BigDecimal amt = BigDecimal.ZERO;
        if (tempOrder != null) {
            amt = getDiscountAmtByOrderTotal(tempOrder.tempSelectedMenuList, tempOrder.tempTotalMenuPrice);
        }
        if (amt.compareTo(BigDecimal.ZERO) <= 0) {
            amt = BigDecimal.ZERO;
        }

        return amt;
    }

    private static BigDecimal getDiscountAmtByOrderTotal(List<MenuItem> menuItems, BigDecimal totalMenuPrice) {

        BigDecimal amt = BigDecimal.ZERO;
        if (!ListUtil.isEmpty(menuItems)) {
            for (MenuItem menuItem : menuItems) {
                if (menuItem.hasAllVoid()) {
                    continue;
                }
                if (menuItem.supportDiscount()) {
                    amt = amt.add(menuItem.menuBiz.totalPrice);
                    if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                            if (modifier.hasAllVoid()) {
                                continue;
                            }
                            amt = amt.add(modifier.calcRealMofierPrice(menuItem));
                        }
                    }
                }

            }
            if (amt.compareTo(totalMenuPrice) > 0) {
                amt = totalMenuPrice;
            }
        }
        if (amt.compareTo(BigDecimal.ZERO) <= 0) {
            amt = BigDecimal.ZERO;
        }

        return amt;
    }

    /**
     * 返回待支付金额，不包含服务费
     *
     * @param session    PaySession
     * @param orderCache OrderCache
     * @return BigDecimal
     */
    public static BigDecimal getLeftToPayIgnoreService(PaySession session, OrderCache orderCache) {
        BigDecimal leftToPay = session.priceLeftToPay;
        if (orderCache.totalService != null && !orderCache.checkFreeFee()) {
            leftToPay = leftToPay.subtract(orderCache.totalService);
        }
        return leftToPay;
    }

    /**
     * 获取订单待支付金额中，可参与折扣的金额---不包含服务费
     *
     * @param session    PaySession
     * @param orderCache OrderCache
     * @return BigDecimal
     */
    public static BigDecimal getDiscountAmtByLeftToPayIgnoreService(PaySession session, OrderCache orderCache) {
        BigDecimal discountAmt = getDiscountAmtByLeftToPay(session, orderCache);
        if (orderCache.totalService != null && !orderCache.checkFreeFee()) {
            discountAmt = discountAmt.subtract(orderCache.totalService);
        }
        return discountAmt;
    }

    /**
     * 获取订单待支付金额中，可参与折扣的金额
     *
     * @param session    PaySession
     * @param orderCache OrderCache
     * @return BigDecimal
     */
    public static BigDecimal getDiscountAmtByLeftToPay(PaySession session, OrderCache orderCache) {

        BigDecimal priceLeftToPay = getDiscountAmtByOrderTotal(orderCache);
        if (session != null) {
            BigDecimal alreayPayedAmount = BigDecimal.ZERO;
            for (PayModel temp : session.selectPayListFull) {
                //check所有可折扣的门店券和会员券的支付方式的综合
                if (temp.data != null && temp.checkEnable() && temp.data.checkForDiscount() && temp.seq_M == -1 && (PayType.isCoupon(temp.data) || PayType.isMWMemberTicket(temp.data))) {
                    alreayPayedAmount = alreayPayedAmount.add(temp.payAmount).subtract(temp.changeAmount);
                    for (PayModel subTemp : session.selectPayListFull) {
                        if (subTemp.data != null && subTemp.seq_M == temp.seq) {
                            alreayPayedAmount = alreayPayedAmount.add(subTemp.payAmount).subtract(subTemp.changeAmount);
                        }
                    }
//                    alreayPayedAmount = alreayPayedAmount.add(OrderUtil.recalPaiedAmount(temp));
//                    BigDecimal payed = OrderUtil.recalPaiedAmount(temp).divide(BizConstant.HUNDREND.subtract(temp.data.fdDiscountRate), 2, BigDecimal.ROUND_HALF_UP)
//                            .multiply(BizConstant.HUNDREND);
//                    alreayPayedAmount = alreayPayedAmount.add(payed);
                }
            }
            //总可折扣金额减去已抵扣的可折扣的金额
            priceLeftToPay = priceLeftToPay.subtract(alreayPayedAmount);

            //如果订单总待支付金额已经小于剩下的可折扣金额，则可折扣金额为订单总待支付的金额
            if (session.priceLeftToPay.compareTo(priceLeftToPay) < 0) {
                priceLeftToPay = session.priceLeftToPay;
            }
        }

        if (priceLeftToPay.compareTo(BigDecimal.ZERO) <= 0) {
            priceLeftToPay = BigDecimal.ZERO;
        }
        return priceLeftToPay;
    }

    /**
     * 计算实收部分的金额
     *
     * @param session PaySession
     * @return BigDecimal
     */
    public static BigDecimal calcPayCalc(PaySession session) {
        //实收金额
        BigDecimal totalCalc = BigDecimal.ZERO;
        if (session != null && !ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel temp : session.selectPayListFull) {
                if (temp.status != PayTypeStatus.DELETE) {
                    if (temp.data.checkCalcPaid()) {
                        totalCalc = totalCalc.add(temp.payAmount).subtract(temp.changeAmount);
                    }
                    if (!ListUtil.isEmpty(temp.subPayList)) {
                        for (PayModel tempSub : temp.subPayList) {
                            if (tempSub.data.checkCalcPaid()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                    if (!ListUtil.isEmpty(temp.secondPayList)) {
                        for (PayModel tempSub : temp.secondPayList) {
                            if (tempSub.data.checkCalcPaid()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                }
            }
        }
        return totalCalc;
    }

    /**
     * 计算实收部分的金额---含储值奖励金，不含积分、不含券核销
     * <p>
     * isMWMemberPoint(temp.data)
     *
     * @param session PaySession
     * @return BigDecimal
     */
    public static BigDecimal checkForMemberCalcPaid(PaySession session) {
        //实收金额
        BigDecimal totalCalc = BigDecimal.ZERO;
        if (session != null && !ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel temp : session.selectPayListFull) {
                if (temp.status != PayTypeStatus.DELETE) {
//                    if ((temp.data.checkCalcPaid()
//                            && !isCoupon(temp.data)
//                            && !isMWMemberTicket(temp.data))
//                            || isMWMemberBalance(temp.data)
//                            ) {
                    if (temp.data.checkForMemberCalcPaid()) {
                        totalCalc = totalCalc.add(temp.payAmount).subtract(temp.changeAmount);
                    }

                    if (!ListUtil.isEmpty(temp.subPayList)) {
                        for (PayModel tempSub : temp.subPayList) {
                            if (tempSub.data.checkForMemberCalcPaid()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                    if (!ListUtil.isEmpty(temp.secondPayList)) {
                        for (PayModel tempSub : temp.secondPayList) {
                            if (tempSub.data.checkForMemberCalcPaid()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                }
            }
        }
        return totalCalc;
    }

    /**
     * 计算实收部分的金额---不含储值奖励金，不含积分、不含券核销
     * <p>
     * isMWMemberPoint(temp.data)
     *
     * @param session PaySession
     * @return BigDecimal
     */
    public static BigDecimal checkForMemberCalcPaidNotContainMember(PaySession session) {
        //实收金额
        BigDecimal totalCalc = BigDecimal.ZERO;
        if (session != null && !ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel temp : session.selectPayListFull) {
                if (temp.status != PayTypeStatus.DELETE) {
//                    if ((temp.data.checkCalcPaid()
//                            && !isCoupon(temp.data)
//                            && !isMWMemberTicket(temp.data))
//                            || isMWMemberBalance(temp.data)
//                            ) {
                    if (temp.data.checkForMemberCalcPaidNotContainMember()) {
                        totalCalc = totalCalc.add(temp.payAmount).subtract(temp.changeAmount);
                    }

                    if (!ListUtil.isEmpty(temp.subPayList)) {
                        for (PayModel tempSub : temp.subPayList) {
                            if (tempSub.data.checkForMemberCalcPaidNotContainMember()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                    if (!ListUtil.isEmpty(temp.secondPayList)) {
                        for (PayModel tempSub : temp.secondPayList) {
                            if (tempSub.data.checkForMemberCalcPaidNotContainMember()) {
                                totalCalc = totalCalc.add(tempSub.payAmount).subtract(temp.changeAmount);
                            }
                        }
                    }
                }
            }
        }
        return totalCalc;
    }

    /**
     * 获取使用的会员优惠券
     *
     * @param session PaySession
     * @return PayModel
     */
    public static PayModel getMemberTicket(PaySession session) {
        if (session != null && !ListUtil.isEmpty(session.selectPayListFull)) {
            for (PayModel temp : session.selectPayListFull) {
                if (temp.status != PayTypeStatus.DELETE) {
                    if (PayType.isMWMemberTicket(temp.data)) {
                        return temp;
                    }
                }
            }
        }
        return null;
    }

    /**
     * 是否使用了积分抵扣
     *
     * @param ticketList List<PayModel>
     * @return String
     */
    public static boolean hasMemberPoint(List<PayModel> ticketList) {
        if (!ListUtil.isEmpty(ticketList)) {
            for (PayModel temp : ticketList) {
                if (temp.checkEnable() && PayType.isMWMemberPoint(temp.data)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 是否使用了储值支付
     *
     * @param ticketList List<PayModel>
     * @return String
     */
    public static boolean hasMemberBalance(List<PayModel> ticketList) {
        if (!ListUtil.isEmpty(ticketList)) {
            for (PayModel temp : ticketList) {
                if (temp.checkEnable() && PayType.isMWMemberBalance(temp.data)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 拼接会员抵用券的code，用于抵扣
     *
     * @param ticketList List<PayModel>
     * @return String
     */
    public static String getMemberTicketCode(List<PayModel> ticketList) {
        StringBuilder sb = new StringBuilder();
        if (!ListUtil.isEmpty(ticketList)) {
            for (PayModel temp : ticketList) {
                if (temp.checkEnable() && PayType.isMWMemberTicket(temp.data)) {
                    if (temp.data.memberCouponModel != null && !temp.checkMemberConsumed() && temp.checkMemberLoginPay()) {
                        sb.append(temp.data.memberCouponModel.code).append(",");
                    }
                }
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
        }
        return sb.toString();
    }

    /**
     * 拼接会员抵用券的code，用于抵扣
     *
     * @param ticketList List<PayModel>
     * @return List<String>
     */
    public static List<String> getMemberTicketCodeList(List<PayModel> ticketList) {
        List<String> codeList = new ArrayList<>();
        if (!ListUtil.isEmpty(ticketList)) {
            for (PayModel temp : ticketList) {
                if (temp.checkEnable() && PayType.isMWMemberTicket(temp.data)) {
                    if (temp.data.memberCouponModel != null && !temp.checkMemberConsumed() && temp.checkMemberLoginPay()) {
                        codeList.add(temp.data.memberCouponModel.code);
                    }
                }
            }
        }
        return codeList;
    }

    /**
     * 拼接会员抵用券的code，用于抵扣
     *
     * @return List<String>
     */
    public static List<String> getMemberTicketCodeList(PayModel payModel) {
        if (payModel == null) {
            return new ArrayList<>();
        }
        List<PayModel> ticketList = new ArrayList<>();
        ticketList.add(payModel);
        return getMemberTicketCodeList(ticketList);
    }

    /**
     * 拼接会员抵用券的code，用于抵扣
     * JSONObject包含以下字段：
     * coupon_code---String|优惠券code
     * coupon_discount_amount---float|券抵扣金额
     *
     * @return List<JSONObject>
     */
    public static List<JSONObject> getMemberTicketInfoList(PayModel payModel) {
        List<PayModel> payModelList = new ArrayList<>();
        payModelList.add(payModel);
        return getMemberTicketInfoList(payModelList);
    }

    public static List<JSONObject> getMemberTicketInfoList(List<PayModel> payModelList) {
        List<JSONObject> couponList = new ArrayList<>();
        if (ListUtil.isEmpty(payModelList)) {
            return couponList;
        }
        for (PayModel payModel : payModelList) {
            if (payModel == null) {
                continue;
            }
            if (payModel.checkEnable() && PayType.isMWMemberTicket(payModel.data)) {
                if (payModel.data.memberCouponModel != null && !payModel.checkMemberConsumed() && payModel.checkMemberLoginPay()) {
                    JSONObject info = new JSONObject();
                    // 优惠券code
                    info.put("coupon_code", payModel.data.memberCouponModel.code);
                    // 券抵扣金额
                    info.put("coupon_discount_amount", payModel.payAmount);
                    couponList.add(info);
                }
            }
        }
        return couponList;
    }

    /**
     * 使用门店券
     *
     * @param currentSelectPay     PayModel | 支付明细Model
     * @param totalLeftToPay       待支付金额，不含服务费
     * @param discountAmtLeftToPay 待支付金额中可折扣金额
     */
    @WorkerThread
    public static String useShopCouponModel(PayModel currentSelectPay, BigDecimal totalLeftToPay, BigDecimal discountAmtLeftToPay) {
//        currentSelectPay.payAmount = data.defaultPrice;
        BigDecimal inputAmount = currentSelectPay.payAmount;

        //待支付金额
        BigDecimal priceLeftToPay = totalLeftToPay;

        //检查是否仅用于打折菜品
        if (currentSelectPay.data.checkForDiscount()) {
            priceLeftToPay = discountAmtLeftToPay;
            if (priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
                return "可抵扣金额为0，不能使用此券";
            }
        }
        if (priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
            return "待支付金额为0，不能使用此券";
        }

        PayModel secondPayModel = null;

        if (TextUtils.equals(currentSelectPay.data.payTypeGroupID, PayTypeGroup.FIXED_COUPON)) {
            //固定代金券面值为固定值
            BigDecimal fdDefaultPrice = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, "select fdDefaultPrice from tbpayment where fspaymentId = '"+currentSelectPay.data.payTypeID+"' ","fdDefaultPrice", BigDecimal.class);
            if (fdDefaultPrice != null){
                currentSelectPay.payAmount = fdDefaultPrice;
                inputAmount = fdDefaultPrice;
            }

            if (currentSelectPay.data.fdCardRealAmt.compareTo(BigDecimal.ZERO) <= 0 && !TextUtils.isEmpty(currentSelectPay.data.fsDiscountPaymentId)) {
                //券面额全部非实收
                PayOriginModel payTypeDiscount = OrderUtil.buildPayModelByPaymentID(currentSelectPay.data.fsDiscountPaymentId);
                if (payTypeDiscount != null) {
                    secondPayModel = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                    secondPayModel.data = payTypeDiscount;
                    secondPayModel.payAmount = currentSelectPay.payAmount;
                    secondPayModel.certigierUserId = currentSelectPay.certigierUserId;
                    secondPayModel.certigierUserName = currentSelectPay.certigierUserName;
                    if (currentSelectPay.secondPayList == null) {
                        currentSelectPay.secondPayList = new ArrayList<>();
                    }
                    currentSelectPay.secondPayList.add(secondPayModel);
                }
            } else if (currentSelectPay.data.fdCardRealAmt.compareTo(currentSelectPay.payAmount) < 0 && !TextUtils.isEmpty(currentSelectPay.data.fsDiscountPaymentId)) {
                //券面额部分非实收
                PayOriginModel payTypeDiscount = OrderUtil.buildPayModelByPaymentID(currentSelectPay.data.fsDiscountPaymentId);
                if (payTypeDiscount != null) {
                    secondPayModel = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                    secondPayModel.data = payTypeDiscount;
                    secondPayModel.payAmount = currentSelectPay.payAmount.subtract(currentSelectPay.data.fdCardRealAmt);
                    secondPayModel.certigierUserId = currentSelectPay.certigierUserId;
                    secondPayModel.certigierUserName = currentSelectPay.certigierUserName;
                    if (currentSelectPay.secondPayList == null) {
                        currentSelectPay.secondPayList = new ArrayList<>();
                    }
                    currentSelectPay.secondPayList.add(secondPayModel);
                }
            }
        } else {
            //计算券的折扣率
            if (currentSelectPay.data.fdDiscountRate.compareTo(BigDecimal.ZERO) > 0 && !TextUtils.isEmpty(currentSelectPay.data.fsDiscountPaymentId)) {

                PayOriginModel payTypeDiscount = OrderUtil.buildPayModelByPaymentID(currentSelectPay.data.fsDiscountPaymentId);
                if (payTypeDiscount != null) {
                    secondPayModel = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                    secondPayModel.data = payTypeDiscount;
                    secondPayModel.payAmount = currentSelectPay.payAmount.multiply(currentSelectPay.data.fdDiscountRate).divide(BizConstant.HUNDREND, 2, BigDecimal.ROUND_HALF_UP);

                    secondPayModel.certigierUserId = currentSelectPay.certigierUserId;
                    secondPayModel.certigierUserName = currentSelectPay.certigierUserName;

                    if (currentSelectPay.secondPayList == null) {
                        currentSelectPay.secondPayList = new ArrayList<>();
                    }
                    currentSelectPay.secondPayList.add(secondPayModel);
                }
            }
        }

        if (secondPayModel != null) {
            currentSelectPay.payAmount = currentSelectPay.payAmount.subtract(secondPayModel.payAmount);
        }

        //计算是否需要进行免找
        BigDecimal subValue = inputAmount.subtract(priceLeftToPay);
        if (subValue.compareTo(BigDecimal.ZERO) > 0){
            if (currentSelectPay.subPayList == null) {
                currentSelectPay.subPayList = new ArrayList<>();
            }
            PayOriginModel payTypeCouponGiven = null;
            if (TextUtils.equals(currentSelectPay.data.payTypeGroupID, PayTypeGroup.COUPON)) {
                payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_FREE);
            } else if (TextUtils.equals(currentSelectPay.data.payTypeGroupID, PayTypeGroup.GIVE_COUPON)) {
                payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_GIVEN_FREE);
            } else if (TextUtils.equals(currentSelectPay.data.payTypeGroupID, PayTypeGroup.FIXED_COUPON)) {
                payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_FIXED);
            } else {
                payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_FREE);
            }
            if (payTypeCouponGiven != null) {
                PayModel model = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                model.data = payTypeCouponGiven;
                model.payAmount = subValue.negate();
                model.certigierUserId = currentSelectPay.certigierUserId;
                model.certigierUserName = currentSelectPay.certigierUserName;
                currentSelectPay.subPayList.add(model);
            }
        }
        return "";
    }


    /**
     * 处理门店券的免找
     *
     * @param currentSelectPay  PayModel | 选择的券
     * @param payAmoun          BigDecimal
     * @param canDiscountAmount BigDecimal
     */
    public static void checkMemberCouponForChange(PayModel currentSelectPay, BigDecimal payAmoun, BigDecimal canDiscountAmount) {
        //计算是否需要进行免找
        BigDecimal subValue = payAmoun.subtract(canDiscountAmount);
        if (subValue.compareTo(BigDecimal.ZERO) > 0) {
            if (currentSelectPay.subPayList == null) {
                currentSelectPay.subPayList = new ArrayList<>();
            }
            PayOriginModel payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_FREE);
            if (payTypeCouponGiven != null) {
                PayModel model = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                model.seq = currentSelectPay.seq;
                model.seq_M = currentSelectPay.seq;
                model.data = payTypeCouponGiven;
                model.payAmount = subValue.negate();
                currentSelectPay.subPayList.add(model);
            }
        }
    }

    /**
     * TODO 会员重构---    已废弃
     * 退款,退掉：
     * 1，买单时抵扣的金额；
     * 2，买单时核销的券
     * 3，买单后赠送的积分
     * 4，买单后赠送的优惠券
     *
     * @param session        PaySession
     * @param refundOrder    boolean | 是否是退掉订单的单独赠送的积分或者会员
     * @param resultListener IMemberRefund
     */
    @Deprecated
    public static MemberOrderRefundRequest processMemberRefund(final List<PayModel> voidList, final PaySession session, boolean refundOrder, final IMemberRefund resultListener) {
        String orderID = "";
        int useScore = 0;
        String couponCode = "";
        boolean containsMemberDiscount = false;
        if (refundOrder) {
             /*if (!ListUtil.isEmpty(session.selectPayListFull)) {
                StringBuilder sb = new StringBuilder();
                for (PayModel temp : session.selectPayListFull) {
                   if (temp.checkEnable() && temp.checkMemberConsumed()) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            useScore = temp.memberCostScore;
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (PayType.isMWMemberCouponDiscount(temp.data)) {
                                containsMemberDiscount = true;
                            }
                            sb.append(temp.data.memberCouponModel.code).append(",");
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        }
                    }
                }
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
                couponCode = sb.toString();
            }*/
        } else {
            if (!ListUtil.isEmpty(voidList)) {
                StringBuilder sb = new StringBuilder();
                for (PayModel temp : voidList) {
                    if (temp.checkMemberConsumed()) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            useScore = temp.memberCostScore;
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (PayType.isMWMemberCouponDiscount(temp.data)) {
                                containsMemberDiscount = true;
                            }
                            sb.append(temp.data.memberCouponModel.code).append(",");
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        }
                    }
                }
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
                couponCode = sb.toString();
            }
        }
        /*if (refundOrder && (!TextUtils.isEmpty(couponCode) || useScore > 0)) {
            if (resultListener != null) {
                resultListener.callBack(false, "需要指定积分或者优惠券进行退款", null, false);
            }
            return null;
        }*/
        if (TextUtils.isEmpty(orderID)) {
            orderID = session.memberOrderID;
        }
        if (refundOrder && TextUtils.isEmpty(session.memberOrderID)) {
            if (resultListener != null) {
                resultListener.callBack(true, "订单号为空，不需要退款", null, false);
            }
            return null;
        }
        if (TextUtils.isEmpty(orderID) && TextUtils.isEmpty(couponCode) && useScore <= 0) {
            if (resultListener != null) {
                resultListener.callBack(true, "", null, false);
            }
            return null;
        }

        final MemberOrderRefundRequest request = new MemberOrderRefundRequest();
        request.amount = session.memberRealAmt;
        request.card_no = session.memberCardNO;
        request.use_score = useScore;
        request.order_id = orderID;
        request.outer_order_id = session.orderID;
        request.coupon_code = couponCode;
        request.is_give = 1;
        request.present_score = session.memberGiftScore;
        final boolean containsMemberDiscountFinal = containsMemberDiscount;
        session.memberOrderID = "";
        session.memberConsumed = false;
        session.memberRealAmt = BigDecimal.ZERO;
        if (resultListener != null) {
            resultListener.callBack(true, "", request, containsMemberDiscountFinal);
        }
        return request;
    }

    /**
     * 会员重构
     * 退款,退掉：
     * 1，买单时抵扣的金额；
     * 2，买单时核销的券
     * 3，买单后赠送的积分
     * 4，买单后赠送的优惠券
     *
     * @param session        PaySession
     * @param refundOrder    boolean | 是否是退掉订单的单独赠送的积分或者会员
     * @param resultListener IMemberRefund
     */
    public static NewMemberOrderRefundRequest processMemberRefundNew(final List<PayModel> voidList, final PaySession session, boolean refundOrder, final IMemberRefundNew resultListener) {
        String orderID = "";
        int useScore = 0;
        List<String> couponCode = new ArrayList<>();
        boolean containsMemberDiscount = false;
        if (refundOrder) {
             /*if (!ListUtil.isEmpty(session.selectPayListFull)) {
                StringBuilder sb = new StringBuilder();
                for (PayModel temp : session.selectPayListFull) {
                   if (temp.checkEnable() && temp.checkMemberConsumed()) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            useScore = temp.memberCostScore;
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (PayType.isMWMemberCouponDiscount(temp.data)) {
                                containsMemberDiscount = true;
                            }
                            sb.append(temp.data.memberCouponModel.code).append(",");
                            if (TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        }
                    }
                }
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
                couponCode = sb.toString();
            }*/
        } else {
            if (!ListUtil.isEmpty(voidList)) {

                for (PayModel temp : voidList) {
                    if (temp.checkMemberConsumed()) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            useScore = temp.memberCostScore;
                            if (!TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (PayType.isMWMemberCouponDiscount(temp.data)) {
                                containsMemberDiscount = true;
                            }
                            couponCode.add(temp.data.memberCouponModel.code);
                            if (!TextUtils.isEmpty(temp.memberOrderID)) {
                                orderID = temp.memberOrderID;
                            }
                        }
                    }
                }

            }
        }
        /*if (refundOrder && (!TextUtils.isEmpty(couponCode) || useScore > 0)) {
            if (resultListener != null) {
                resultListener.callBack(false, "需要指定积分或者优惠券进行退款", null, false);
            }
            return null;
        }*/
        if (TextUtils.isEmpty(orderID)) {
            orderID = session.memberOrderID;
        }
        if (refundOrder && TextUtils.isEmpty(session.memberOrderID)) {
            if (resultListener != null) {
                resultListener.callBack(true, "订单号为空，不需要退款", null, false);
            }
            return null;
        }
        if (TextUtils.isEmpty(orderID) && ListUtil.isEmpty(couponCode) && useScore <= 0) {
            if (resultListener != null) {
                resultListener.callBack(true, "", null, false);
            }
            return null;
        }

        final NewMemberOrderRefundRequest request = new NewMemberOrderRefundRequest();
        request.amount = session.memberRealAmt;
        request.card_no = session.memberCardNO;
        request.use_score = useScore;
        request.order_id = orderID;
        request.outer_order_id = session.orderID;
        request.coupon_code = couponCode;
        request.is_give = 1;
        request.companyGuid = ServerCache.getInstance().fsCompanyGUID;
        request.present_score = session.memberGiftScore;
        final boolean containsMemberDiscountFinal = containsMemberDiscount;
        session.memberOrderID = "";
        session.memberConsumed = false;
        session.memberRealAmt = BigDecimal.ZERO;
        if (resultListener != null) {
            resultListener.callBack(true, "", request, containsMemberDiscountFinal);
        }
        return request;
    }

    /**
     * 立即执行积分赠送的业务，如果失败，则写入JobScheudler
     *
     * @param giftRequest MemberOrderConsumeRequest
     * @param fsSellNo    String
     */
    public static void startJobMemberGift(final MemberOrderConsumeRequest giftRequest, final String fsSellNo) {
        if (giftRequest == null || TextUtils.isEmpty(fsSellNo)) {
            return;
        }
        giftRequest._timestamp = String.valueOf(DateUtil.getCurrentTimeInMills() / 1000);
        final Job job = JobScheudler.newMemberGiftWithProcessing(giftRequest, fsSellNo);

        JobWorker worker = new JobWorker();
        worker.work(job);
    }

    /**
     * 立即执行积分赠送的业务，如果失败，则写入JobScheudler---会员重构
     *
     * @param giftRequest MemberOrderConsumeRequest
     * @param fsSellNo    String
     */
    public static void startJobMemberGiftNew(final NewMemberOrderConsumeRequest giftRequest, final String fsSellNo) {
        if (giftRequest == null || TextUtils.isEmpty(fsSellNo)) {
            return;
        }
        final Job job = JobScheudler.newMemberGiftNewWithProcessing(giftRequest, fsSellNo);

        JobWorker worker = new JobWorker();
        worker.work(job);
    }

    /**
     * 当前支付方式是否可以找零
     *
     * @param data PayOriginModel
     * @return boolean
     */
    public static boolean canHasChange(PayOriginModel data) {
        return PayType.isCash(data) && (TextUtils.equals(data.payTypeID, PayType.RMB) || TextUtils.equals(data.payTypeID, PayConfig.NEED_CHANGE));
    }

    public static boolean supportOverPay() {
        return TextUtils.equals("1", DBMetaUtil.getConfig(META.ALLOW_PAY_OVERFLOW, "1"));
    }

    public static boolean supportAutoPay() {
        return TextUtils.equals("1", CommonDBUtil.getConfigWithDefault(DBPayConfig.AUTO_PAY, "0"));
    }

    /**
     * 接入小散的需求
     * 1 正餐保留自动结账开关功能
     * 2 小散  快餐不读取自动结账功能 默认开启  小散正餐读取自动配置
     * update 陈仁敏产品需求 快餐也需要读取自动结账开关
     */
    public static boolean supportAutoPay(int fiSellType) {
//        //口碑，小易 快餐模式 在线付款满额之后自动结账
//        if((APPConfig.isAir()||APPConfig.isAirKouBei()) && fiSellType == 1){
//            return true;
//        }
        return supportAutoPay();
    }

    /**
     * 秒付先付款自动清台 0／false不清台    1/true清台 默认为不清台
     */
    public static boolean supportPreRapidAutoPay() {
        return TextUtils.equals("1", DBMetaUtil.getConfig(META.PRE_RAPID_CLEAN_TABLE, "0"));
    }

    /**
     * 获取订单中不可参与折扣的金额
     * 不可折扣额：不可折扣菜品金额合计+服务费
     *
     * @param orderID String | 订单id
     * @return BigDecimal
     */
    public static BigDecimal getCannnotDiscAmtByOrderTotal(String orderID) {
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        return getCannotDiscAmtByOrderTotal(orderCache);
    }

    /**
     * 获取订单中不可参与折扣的金额
     * 不可折扣额：不可折扣菜品金额合计+服务费
     *
     * @param orderCache String | 订单
     * @return BigDecimal
     */
    public static BigDecimal getCannotDiscAmtByOrderTotal(OrderCache orderCache) {
        BigDecimal amt = BigDecimal.ZERO;
        if (orderCache != null) {
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (menuItem.hasAllVoid()) {
                    continue;
                }
                if (!menuItem.supportDiscount()) {
                    amt = amt.add(menuItem.menuBiz.totalPrice);
                    if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                            if (modifier.hasAllVoid()) {
                                continue;
                            }
                            amt = amt.add(modifier.calcRealMofierPrice(menuItem));
                        }
                    }
                }

            }
            if (amt.compareTo(orderCache.optTotalMenuPrice()) > 0) {
                amt = orderCache.optTotalMenuPrice();
            }
            if (!orderCache.checkFreeFee()) {
                amt = amt.add(orderCache.totalService);
            }
        }
        if (amt.compareTo(BigDecimal.ZERO) <= 0) {
            amt = BigDecimal.ZERO;
        }

        return amt;
    }
}
