package com.mwee.myd.server.business.login.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.tools.StringUtil;

/**
 * 登录中控账号
 */
@HttpParam(
        method = "encryptLogin",
        response = LoginPDResponse.class,
        httpType = HttpType.POST,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8
)
public class LoginPDRequest extends BasePosRequest {

    /**
     * 账号
     */
    public String UserName = "";
    /**
     * 密码
     */
    public String Password = "";
    /**
     * 设备号
     */
    public String DeviceID = "";
    /**
     * 软件类型
     */
    public String appType = "";
    public int V = 0;
    public String AP = "";
    public String apiVersion = "V5";
    public String token = "";

    public LoginPDRequest() {
    }

    @Override
    public String optBaseUrl() {
        return Constant.getLoginPDUrl();
    }

}
