package com.mwee.android.pos.businesscenter.business.member;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberQueryByMobileAndCodeRequest;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.GetMemberCardByCardNoRequest;
import com.mwee.android.pos.component.member.net.GetMemberCardByMobileRequest;
import com.mwee.android.pos.component.member.net.GetMemberCommentsRequest;
import com.mwee.android.pos.component.member.net.GetMemberCommentsResponse;
import com.mwee.android.pos.component.member.net.model.MemberComments;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Created by liuxiuxiu on 2017/7/10.
 */

public class MemberBizUtil {

    /**
     * 查询会员信息
     *
     * @param number
     * @param callback
     */
    public static void getMemberCardRequest(String number, IExecutorCallback callback) {
        if (RegexUtil.checkIsPhoneNumber(number)) {
            sendGetMemberCardByMobileRequest(number, callback);
        } else {
            sendGetMemberCardByCardNoRequest(number, callback);
        }
    }

    public static void getMemberCardByMobileAndCode(String number, String code, IExecutorCallback callback) {
        if (RegexUtil.checkIsPhoneNumber(number)) {
            MemberQueryByMobileAndCodeRequest request = new MemberQueryByMobileAndCodeRequest();
            request.sms_code = code;
            request.mobile = number;
            request.device_id = ServerHardwareUtil.getHardWareSymbol();
//            request.m_shopid = Integer.valueOf(DBMetaUtil.getSettingsValueByKey(META.SHOPID));
            BusinessExecutor.execute(request, callback, false);
        } else {
            RunTimeLog.addLog(RunTimeLog.MEMBER, "手机号输入错误");
        }
    }

    /**
     * 通过手机号登录会员
     *
     * @param mobile
     * @param callback
     */
    public static void sendGetMemberCardByMobileRequest(String mobile, IExecutorCallback callback) {
        GetMemberCardByMobileRequest getMemberCardByMobileRequest = new GetMemberCardByMobileRequest();
        getMemberCardByMobileRequest.mobile = mobile;
        BusinessExecutor.execute(getMemberCardByMobileRequest, callback, false);
    }

    /**
     * 通过会员卡号登录会员
     *
     * @param cardNo
     * @param callback
     */
    public static void sendGetMemberCardByCardNoRequest(String cardNo, IExecutorCallback callback) {
        GetMemberCardByCardNoRequest getMemberCardByCardNoRequest = new GetMemberCardByCardNoRequest();
        getMemberCardByCardNoRequest.card_no = cardNo;
        BusinessExecutor.execute(getMemberCardByCardNoRequest, callback, false);
    }

    /**
     * 请求会员最后一条评论
     *
     * @param cardNo 会员卡号
     */
    public static void requestMemberComents(String cardNo, IExecutorCallback callback) {
        GetMemberCommentsRequest getMemberCommentsRequest = new GetMemberCommentsRequest();
        getMemberCommentsRequest.card_no = cardNo;
        BusinessExecutor.execute(getMemberCommentsRequest, callback);
    }

    /**
     * 请求会员最后一条评论
     *
     * @param cardNo 会员卡号
     */
    public static void requestMemberComents(final String cardNo) {
        requestMemberComents(cardNo, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.MEMBER, "获取评论成功" + JSON.toJSONString(responseData));
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCommentsResponse) {
                    GetMemberCommentsResponse responseBean = (GetMemberCommentsResponse) responseData.responseBean;
                    if (!ListUtil.isEmpty(responseBean.data)) {
                        if (responseBean.data.get(0) == null || responseBean.data.get(0).comment == null) {
                            ServerCache.getInstance().putMemberComments(cardNo, new MemberComments("-1001"));
                        } else {
                            ServerCache.getInstance().putMemberComments(cardNo, responseBean.data.get(0).comment);
                        }

                    }
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.MEMBER, "获取评论失败" + JSON.toJSONString(responseData));
                //3009  没有数据 3008  评分不小于4
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCommentsResponse
                        && (responseData.result == 3009 || responseData.result == 3008)) {
                    ServerCache.getInstance().putMemberComments(cardNo, new MemberComments("-1001"));
                }
                return false;
            }
        });
    }

}
