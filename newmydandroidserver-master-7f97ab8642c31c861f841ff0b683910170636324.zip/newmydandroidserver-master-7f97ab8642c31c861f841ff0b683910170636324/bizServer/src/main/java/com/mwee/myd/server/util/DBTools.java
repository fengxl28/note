package com.mwee.myd.server.util;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.mwee.android.tools.LogUtil;

public class DBTools {

    /**
     * 带捕获异常的SQL执行方法
     * 保证SQL语句可以逐个执行，忽略异常，缩小影响面
     **/
    public static void exeSqlWithoutException(SQLiteDatabase db, String sql) {
        try {
            db.execSQL(sql);
        } catch (SQLException e) {
            LogUtil.logError("DBTools | exeSqlWithoutException | " + sql, e);
        } catch (Exception e) {
            LogUtil.logError("DBTools | exeSqlWithoutException | " + sql, e);
        }
    }

}
