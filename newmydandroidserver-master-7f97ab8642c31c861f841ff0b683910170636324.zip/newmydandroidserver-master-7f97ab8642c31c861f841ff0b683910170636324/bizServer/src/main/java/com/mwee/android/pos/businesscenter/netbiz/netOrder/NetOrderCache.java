package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import android.os.SystemClock;
import android.support.v4.util.ArrayMap;

import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.util.ListUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by liuxiuxiu on 2017/8/15.
 */

public class NetOrderCache extends Cache {

    /**
     * 配送模式：0：手动配送；1：自动配送
     */
    private int deliveryModle = -1;

    /**
     * 立即就餐单 时间
     */
    private String immediateTime = "";

    /**
     * 预约单 时间
     */
    private String reservationsTime = "";


    /**
     * 清空缓存间隔时长
     */
    private final long CLEAN_CACHE_TIME = 10 * 60 * 1000;
    /************************网络订单推送消息缓存****************************/

    private Map<String, Long> netOrderMsgIdPool = new ArrayMap<>();
    /************************网络订单打印（自动接单）缓存****************************/

    private Map<String, Long> netOrderPrintPool = new ArrayMap<>();

    /**
     * 订单入库锁
     */
    private HashMap<String, Object> lockPool = new HashMap<>();

    /**
     * 订单入报表库锁
     */
    private HashMap<String, Object> lockTurnToReportPool = new HashMap<>();

    /**
     * 外卖开台配置信息
     * ELEME --> [SF, EMS]
     */
    private LinkedHashMap<String, List<DeliveryChannelBean>> deliverSettingMap = new LinkedHashMap<>();

    public NetOrderCache() {
    }

    public void init() {
    }

    public void checkCacheExpired() {
        releaseNetOrderMsgIdPool();
        releaseNetOrderPrintPool();
    }

    /**
     * 更新外卖配送方式
     *
     * @param deliveryModle
     * @param immediateTime
     * @param reservationsTime
     */
    public void updateDeliveryInfo(int deliveryModle, String immediateTime, String reservationsTime) {
        this.deliveryModle = deliveryModle;
        this.immediateTime = immediateTime;
        this.reservationsTime = reservationsTime;
    }

    /**
     * 获取配送方式
     *
     * @return
     */
    public int optDeliveryModel() {
        return deliveryModle;
    }

    /**
     * 获取立即就餐订单的配送时间
     *
     * @return
     */
    public String optImmediateTime() {
        return immediateTime;
    }

    /**
     * 获取预约单配送时间
     *
     * @return
     */
    public String optReservationsTime() {
        return reservationsTime;
    }


    /**
     * 网络订单入库锁
     *
     * @param orderId
     * @return
     */
    public synchronized Object optLock(String orderId) {
        Object lock = lockPool.get(orderId);
        if (lock == null) {
            lock = new Object();
            lockPool.put(orderId, lock);
        }
        return lock;
    }

    /**
     * 网络订单入报表锁
     *
     * @param orderId
     * @return
     */
    public synchronized Object optTurnToReportPoolLock(String orderId) {
        Object lock = lockTurnToReportPool.get(orderId);
        if (lock == null) {
            lock = new Object();
            lockTurnToReportPool.put(orderId, lock);
        }
        return lock;
    }

    /**
     * 缓存网络订单ID
     *
     * @param msgId
     */
    public synchronized void putNetOrderMsgId(String msgId) {
        netOrderMsgIdPool.put(msgId, SystemClock.elapsedRealtime());
    }

    /**
     * 释放网络订单ID
     *
     * @param msgId
     */
    public synchronized void releaseNetOrderMsgId(String msgId) {
        netOrderMsgIdPool.remove(msgId);
    }

    /**
     * 检查msgId是否已存在
     *
     * @param msgId
     * @return boolean | true : 已存在； FALSE：不存在
     */
    public synchronized boolean checkNetOrderMsgId(String msgId) {
        boolean msgIdPushed = netOrderMsgIdPool.get(msgId) != null;
        netOrderMsgIdPool.put(msgId, SystemClock.elapsedRealtime());
        return msgIdPushed;
    }

    /**
     * 缓存网络订单打印
     *
     * @param orderId
     */
    public synchronized void putNetOrderPrint(String orderId) {
        netOrderPrintPool.put(orderId, SystemClock.elapsedRealtime());
    }

    /**
     * 释放网络订单打印
     *
     * @param orderId
     */
    public synchronized void releaseNetOrderPrint(String orderId) {
        netOrderPrintPool.remove(orderId);
    }

    /**
     * 获取所有外卖配送开通配置信息
     *
     * @return
     */
    public LinkedHashMap<String, List<DeliveryChannelBean>> optDeliverySettings() {
        if (deliverSettingMap == null) {
            deliverSettingMap = new LinkedHashMap<>();
        }
        return deliverSettingMap;
    }

    /**
     * 检查门店是否有配送开通配置信息
     *
     * @return boolean true : 有配送配置 ； false : 没有配送配置
     */
    public boolean checkDeliverySetting() {
        if (deliverSettingMap == null || deliverSettingMap.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * 缓存网络订单ID
     */
    public synchronized void putDeliverySettings(LinkedHashMap<String, List<DeliveryChannelBean>> map) {
        if (map != null) {
            deliverSettingMap.clear();
            deliverSettingMap.putAll(map);
        }
    }


    /**
     * 检查订单是否已打印
     *
     * @param orderId
     * @return
     */
    public synchronized boolean checkNetOrderPrint(String orderId) {
        boolean print = netOrderPrintPool.get(orderId) != null;
        netOrderPrintPool.put(orderId, SystemClock.elapsedRealtime());
        return print;
    }

    @Override
    public void refresh() {

    }

    @Override
    public synchronized void clean() {
        netOrderMsgIdPool.clear();
        netOrderPrintPool.clear();
        if (lockPool != null) {
            lockPool.clear();
        }
        if (deliverSettingMap != null) {
            deliverSettingMap.clear();
        }
    }

    /**
     * 删除十分钟前的外卖推送数据
     */
    private synchronized void releaseNetOrderMsgIdPool() {
        if (netOrderMsgIdPool == null || netOrderMsgIdPool.isEmpty()) {
            return;
        }
        long timeTag = SystemClock.elapsedRealtime();
        Map<String, Long> tempMap = new HashMap<>();
        tempMap.putAll(netOrderMsgIdPool);
        Set<Map.Entry<String, Long>> set = tempMap.entrySet();
        for (Map.Entry<String, Long> entry : set) {
            if ((timeTag - entry.getValue()) > CLEAN_CACHE_TIME) {
                releaseNetOrderMsgId(entry.getKey());
            }
        }
    }

    /**
     * 删除十分钟前的外卖打印数据
     */
    private synchronized void releaseNetOrderPrintPool() {
        if (netOrderPrintPool == null || netOrderPrintPool.isEmpty()) {
            return;
        }
        long timeTag = SystemClock.elapsedRealtime();
        Map<String, Long> tempMap = new HashMap<>();
        tempMap.putAll(netOrderPrintPool);
        Set<Map.Entry<String, Long>> set = tempMap.entrySet();
        for (Map.Entry<String, Long> entry : set) {
            if ((timeTag - entry.getValue()) > CLEAN_CACHE_TIME) {
                releaseNetOrderPrint(entry.getKey());
            }
        }
    }
}
