package com.mwee.android.pos.businesscenter.driver;

import android.os.SystemClock;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.businesscenter.business.localpush.MessageBean;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.localpush.PushMsgManager;
import com.mwee.android.pos.businesscenter.business.localpush.PushMsgManager.MessageType;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created by huangming on 2018/6/14.
 */

public class P433DataManager {

    private static final String TAG = "P433DataManager";
    private static final long UPLOAD_P433DATA_TIMEOUT = 12*1000;
    private static P433DataManager mInstance;

    private List<String> mNeedP433DataHostList = new ArrayList<>();
    private String mP433Data;
    private long mUploadP433DataTime;
    private TimeoutCheckThread mTimeoutCheckThread;
    private String mCenterHostID;


    public static P433DataManager getInstance(){
        if(mInstance == null){
            synchronized (P433DataManager.class){
                if(mInstance == null){
                    mInstance = new P433DataManager();
                }
            }
        }
        return mInstance;
    }

    public synchronized void setP433Data(String p433Data){
        mP433Data = p433Data;
        mUploadP433DataTime = System.currentTimeMillis();
    }

    public synchronized int getRegistedHostSize(){
        return mNeedP433DataHostList.size();
    }

    public synchronized void registerHost(String hostId){
        if(!mNeedP433DataHostList.contains(hostId)){
            mNeedP433DataHostList.add(hostId);
        }
        LogUtil.log(TAG,"registerHost--注册站点："+hostId);
        if(mTimeoutCheckThread == null || mTimeoutCheckThread.isFinished()){
            //通知有基站的站点上送数据
            sendRequestDataUploadMsg();
            mTimeoutCheckThread = new TimeoutCheckThread();
            mTimeoutCheckThread.start();
            LogUtil.log(TAG,"registerHost:通知有基站的站点上送数据,开启线程");
        }
    }

    public synchronized void unregisterHost(String hostId){
        LogUtil.log(TAG,"unregisterHost--反注册站点:"+hostId);
        if(mNeedP433DataHostList.contains(hostId)){
            mNeedP433DataHostList.remove(hostId);
        }
        //没有需要433数据的时候，将超时线程结束
        if(getRegistedHostSize() <= 0){
            if(mTimeoutCheckThread != null){
                mTimeoutCheckThread.FinishThread();
                LogUtil.log(TAG,"unregisterHost:"+hostId+",And FinishThread");
            }
        }
    }

    public synchronized List<String> getRegisterHostList(){
        return new ArrayList<>(mNeedP433DataHostList);
    }

    public void dealTimeout(){
        sendP433DataForAllHost("NoData");
    }

    public void sendP433DataForAllHost(String p433Data){
        for (String host : mNeedP433DataHostList) {
            sendP433Data(host,p433Data);
        }
    }

    public void sendP433Data(String hostId,String p433Data){
//        NotifyToClient.sendTo(hostId,"printerlist/updateP433Data",p433Data);
        //发送超时处理，重试3次，不成功，则移除此站点
        PushMsgManager.getInstance().send(new MessageBean(MessageType.TPYE_P433STATUSDATA,hostId, "printerlist/updateP433Data", p433Data));
        LogUtil.log(TAG,"sendP433Data:"+hostId+","+p433Data);
    }

    /**
     * 要求有基站的站点上送433打印机信息
     */
    private void sendRequestDataUploadMsg(){
        String hostID = PrintConnector.getHostIdOfP433();
        if(TextUtils.isEmpty(hostID)){
            return;
        }
        //有基站的站点是否是主站点
        if(TextUtils.isEmpty(mCenterHostID)){
            mCenterHostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        }
        if(TextUtils.equals(mCenterHostID,hostID)){
            PrintConnector.getInstance().uploadP433Data();
        }else{
            //"0"：占坑，暂时没用
            PushMsgManager.getInstance().send(new MessageBean(MessageType.TPYE_NORMAL,hostID, "login/uploadP433Data", "0"));
        }
    }

    class TimeoutCheckThread extends LowThread {

        private boolean finishThread = false;
        private int mTimeoutCount = 0;

        public boolean isFinished(){
            return finishThread;
        }

        public void FinishThread(){
            finishThread = true;
        }

        @Override
        public void run() {
            super.run();
            while(!finishThread){
                SystemClock.sleep(UPLOAD_P433DATA_TIMEOUT);
                if(System.currentTimeMillis() - mUploadP433DataTime > UPLOAD_P433DATA_TIMEOUT){
                    //timeout
                    dealTimeout();
                    mTimeoutCount ++;
                    //超时次数大于6次，重新发送 "要求有基站的站点上送433打印机信息"
                    if(mTimeoutCount > 6){
                        sendRequestDataUploadMsg();
                        mTimeoutCount = 0;
                        LogUtil.log(TAG,"有基站站点上送超时次数大于6次，要求有基站的站点上送433打印机信息");
                    }
                }else{
                    //上送成功则超时次数清零
                    mTimeoutCount = 0;
                }
            }

        }
    }

}
