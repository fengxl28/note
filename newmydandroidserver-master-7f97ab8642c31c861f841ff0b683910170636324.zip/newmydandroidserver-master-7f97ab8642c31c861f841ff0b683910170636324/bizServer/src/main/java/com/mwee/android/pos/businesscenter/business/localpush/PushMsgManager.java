package com.mwee.android.pos.businesscenter.business.localpush;

import android.text.TextUtils;

import com.mwee.android.alp.Ack;
import com.mwee.android.alp.AckStatus;
import com.mwee.android.alp.PushServer;
import com.mwee.android.pos.businesscenter.driver.P433DataManager;
import com.mwee.android.pos.component.alp.ServerAction;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * Created by huangming on 2018/6/20.
 */

public class PushMsgManager {

    private static final String TAG = "PushMsgManager";

    private static PushMsgManager mInstance;

    private final Map<String,MessageBean> mMessagesMap = new HashMap<>();
    private MessageCallback mMessageCallback = new MessageCallback();
//    private long mPrintErrorToastTime = 0;
    private Timer mRetryTimer;

    public static PushMsgManager getInstance(){
        if(mInstance == null){
            synchronized (PushMsgManager.class){
                if(mInstance == null){
                    mInstance = new PushMsgManager();
                }
            }
        }
        return mInstance;
    }

    public synchronized void send(MessageBean messageBean) {
        if (messageBean == null) {
            return;
        }
        if (TextUtils.isEmpty(messageBean.getTarget())) {
            RunTimeLog.addLog(RunTimeLog.NOTIFYSENDER, "发送消息到指定的目标,目标为空，uri：" + messageBean.getUri());
            return;
        }
        putMessage(messageBean);
        LogUtil.log(TAG, "消息发送:" + messageBean.getMessageId() + "," + messageBean.getUri());
        send(messageBean.getTarget(), messageBean.getMessageId(), messageBean.getUri(), messageBean.getParams());
    }

    private void send(String target, String messageId,String uri, String param){
        PushServer.getInstance().pushMsgNeedAck(target, messageId,uri + ServerAction.SYMBOL_SPLIT + param,mMessageCallback);
    }

    private synchronized void putMessage(MessageBean messageBean){
        if(messageBean != null){
            mMessagesMap.put(messageBean.getMessageId(),messageBean);
        }
    }

    private synchronized MessageBean getMessage(String messageID){
        return mMessagesMap.get(messageID);
    }

    private synchronized void removeMessage(String messageID){
        mMessagesMap.remove(messageID);
    }

    class MessageCallback extends Ack{

        @Override
        public void callback(String messageID, int status) {
            MessageBean messageBean = getMessage(messageID);
            if(messageBean == null){
                return;
            }

            if(status == AckStatus.Success){
                removeMessage(messageID);
                LogUtil.log(TAG,"消息发送成功:"+messageID);
                return;
            }

            //如果设置了最大超时时长，就以超时时长判断超时
            if(messageBean.getMaxRetryTimeLen() > 0){
                if(System.currentTimeMillis() - messageBean.getCreateTime() >= messageBean.getMaxRetryTimeLen()){
                    removeMessage(messageID);
                    LogUtil.log(TAG,"消息重试已超时："+messageBean.toString());
                    RunTimeLog.addLog(RunTimeLog.SOCKET_PUSHMSG,"消息重试已超时",messageBean.toString());
                    processTimeout(messageBean);
                    return;
                }
            }else if(messageBean.getRetryCount() >= messageBean.getMaxRetryCount()){
                removeMessage(messageID);
                LogUtil.log(TAG,"消息重试已超时："+messageBean.toString());
                RunTimeLog.addLog(RunTimeLog.SOCKET_PUSHMSG,"消息重试已超时",messageBean.toString());
                processTimeout(messageBean);
                return;
            }
            //重试
            messageBean.setRetryCount(messageBean.getRetryCount()+1);
            addRetryTask(messageBean);
            if(messageBean.getMessageType() == MessageType.TPYE_PRINTTASK){
                //3：打印失败
                PrintConnector.getInstance().printTaskSendError(messageBean.getParams(),"3");
            }
            LogUtil.log(TAG,"消息重试："+messageBean.toString());
            RunTimeLog.addLog(RunTimeLog.SOCKET_PUSHMSG,"消息重试:"+status,messageBean.toString());
        }
    }

    private void addRetryTask(final MessageBean messageBean){
        if(mRetryTimer == null){
            mRetryTimer = new Timer();
        }
        mRetryTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                send(messageBean.getTarget(),messageBean.getMessageId(),messageBean.getUri(),messageBean.getParams());
            }
        }, messageBean.getRetryDelay());
    }

    private void processTimeout(MessageBean messageBean){
        if(messageBean == null){
            return;
        }
        switch (messageBean.getMessageType()){
            case MessageType.TPYE_P433STATUSDATA:
                //p433打印机信号数据发送超时处理，重试3次，不成功，则移除此站点
                P433DataManager.getInstance().unregisterHost(messageBean.getTarget());
                break;
            case MessageType.TPYE_PRINTTASK:
                //8:逾期
                PrintConnector.getInstance().printTaskSendError(messageBean.getParams(),"8");
//                if(System.currentTimeMillis() - mPrintErrorToastTime > 10*1000){
//                    ToastUtil.showToast("打印失败！站点（"+messageBean.target+")已离线，请检查网络或者重启该站点");
//                    PrintConnector.getInstance().printTaskSendError(messageBean.params);
//                    mPrintErrorToastTime = System.currentTimeMillis();
//                }
                break;
        }
    }

    public static class MessageType{
        public final static int TPYE_NORMAL = 0;//    普通类型，不关心超时
        public final static int TPYE_P433STATUSDATA = 1;//    发送433打印机信号数据
        public final static int TPYE_PRINTTASK = 2;//    发送给站点发送打印任务
    }
}
