package com.mwee.myd.server.slave;

import android.content.Context;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.List;

/**
 * @ClassName: ReplicationProcessor
 * @Description:
 * @author: SugarT
 * @date: 2018/5/3 下午4:02
 */
public class ReplicationProcessor {

    public static final String TAG = ReplicationProcessor.class.getSimpleName();

    private final ILoopCall mLoopCall = () -> BusinessExecutor.executeNoWait(() -> {
        RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationProcessor#mLoopCall [" + DateUtil.getCurrentTime() + "]启动轮询任务，尝试迁移数据");
        // 获取主库内所有的7日以上的订单日期
        String currentDate = HostUtil.getHistoryBusineeDate("");
        List<String> dateList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "SELECT fsSellDate FROM tbSell WHERE (julianday('" + currentDate + "') - julianday(fsSellDate)) > 7 GROUP BY fsselldate");
        if (ListUtil.isEmpty(dateList)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationProcessor#mLoopCall [" + DateUtil.getCurrentTime() + "]没有7日以上的订单数据，终止迁移数据");
            return null;
        }
        for (String oldDate : dateList) {
            checkReplication(GlobalCache.getContext(), currentDate, oldDate);
        }
        return null;
    });

    private volatile static ReplicationProcessor instance;

    public static ReplicationProcessor getInstance() {
        if (instance == null) {
            synchronized (ReplicationProcessor.class) {
                if (instance == null) {
                    instance = new ReplicationProcessor();
                }
            }
        }
        return instance;
    }

    public void start() {
        if (BaseConfig.isDEV()) {
            GlobalLooper.registBasedOn2Minutes(mLoopCall, 1);
        } else {
            GlobalLooper.registBasedOn2Minutes(mLoopCall, 30);
        }
    }

    /**
     * 校验主库数据并将数据迁往从库
     *
     * @param context
     * @param currentDate 当前营业日期
     * @param oldDate     历史日期
     */
    private void checkReplication(Context context, String currentDate, String oldDate) {
        if (!ReplicationDBUtil.needReplication(oldDate)) {
            return;
        }
        if (!ReplicationDBUtil.canReplication(context, currentDate, oldDate)) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationProcessor#checkReplication 营业日期[" + oldDate + "]校验通过，即将从 master 库中迁出数据");
        ReplicationDBUtil.replication(context, APPConfig.DB_MAIN, SlaveDBUtils.buildDatabaseName(oldDate), oldDate);
    }

    /**
     * 从库数据回迁
     *
     * @param businessDate 营业日期
     */
    public void slaveMoveBack(String businessDate) {
        if (!ReplicationDBUtil.needMoveBack(GlobalCache.getContext(), businessDate)) {
            return;
        }
        RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationProcessor#slaveMoveBack 营业日期[" + businessDate + "]校验通过，即将迁回数据到 master 库");
        ReplicationDBUtil.replication(GlobalCache.getContext(), SlaveDBUtils.buildDatabaseName(businessDate), APPConfig.DB_MAIN, businessDate);
    }
}
