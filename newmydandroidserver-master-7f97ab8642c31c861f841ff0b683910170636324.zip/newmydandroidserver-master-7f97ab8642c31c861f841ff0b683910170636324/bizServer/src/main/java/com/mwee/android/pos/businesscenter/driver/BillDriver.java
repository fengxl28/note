package com.mwee.android.pos.businesscenter.driver;

import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.member.IMemberRefundNew;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.business.netpay.RapidPaySearchRequest;
import com.mwee.android.pos.business.netpay.RapidPaySearchResponse;
import com.mwee.android.pos.business.netpay.model.BillOnlineModel;
import com.mwee.android.pos.business.rapid.api.bean.SaveRapidPayToOrderResponse;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.util.RapidUtil;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.business.report.processor.ReportProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobStatus;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.UploadBillRequest;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundRequest;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.GetUnPrintTaskNoResponse;
import com.mwee.android.pos.connect.business.bill.BillOnlineResponse;
import com.mwee.android.pos.connect.business.bill.BillOptFilterResponse;
import com.mwee.android.pos.connect.business.bill.BillOptLogResponse;
import com.mwee.android.pos.connect.business.bill.BillOptViewResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.monitor.report.LoadAccountBookResponse;
import com.mwee.android.pos.connect.business.pay.GetPayMemberTicketResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.PreparePaySessionResponse;
import com.mwee.android.pos.connect.business.pay.StartRepayResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.ShopServiceUtil;
import com.mwee.android.pos.db.business.fastfood.FastFoodBizStatus;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessagePayBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 结账相关的Driver
 * Created by qinwei on 2017/2/7.
 */

@SuppressWarnings("unused")
public class BillDriver implements IDriver {
    public final static Object saveRapidLock = new Object();
    private static final String TAG = "billDriver";

    /**
     * 准备支付，返回一个PaySession
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/preparePay")
    public static SocketResponse getPay(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            long time = System.currentTimeMillis();
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            PreparePaySessionResponse respone = new PreparePaySessionResponse();
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            respone.orderID = orderID;

            SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(head.ot, user.fsUserId, orderID);
            if (!checkResponse.success()) {
                socketResponse.code = checkResponse.code;
                socketResponse.message = checkResponse.message;
                return socketResponse;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在，请重试";
                return socketResponse;
            }
            //订单金额异常的触发保存机制
            BigDecimal originPrice = orderCache.totalPrice;
            String dbPriceStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fdexpAmt from tbsell where fssellno='" + orderID + "'");
            BigDecimal dbPrice = BizConstant.NEGATIVE;
            if (!TextUtils.isEmpty(dbPriceStr)) {
                dbPrice = new BigDecimal(dbPriceStr);
            }
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "准备支付，返回一个PaySession ");
            try {
                //比较餐标金额是否变化了，是，重新赋值并计算
                DinnerStandardUtil.minStandardChanged(orderCache, orderCache.fsmareaid, user);
                //订单金额重新计算
                orderCache.reCalcAllByAll();
               /* //如果金额不一致，则触发重新保存
                if (originPrice.compareTo(orderCache.totalPrice) != 0 || dbPrice.compareTo(orderCache.totalPrice) != 0) {
                    OrderSession.getInstance().writeOrder(orderID, true);
                }*/
                OrderSession.getInstance().writeOrder(orderID, true, "billDriver/preparePay");

                PaySession session = OrderSession.getInstance().getPay(orderID);
                OrderSession.getInstance().generatePaySession(orderCache, user, head.hd);
                respone.baseData = BillUtil.buildPayBase(orderID);
                respone.viewData = BillUtil.buildPayViewData(orderID);
                respone.viewData.showKoBeiHint = DataCacheDBUtil.isShowKoBeiHintDialog(user.fsUserId);
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "准备支付，返回一个PaySession ");
            }
            if (APPConfig.isAirKouBei() || APPConfig.isAir()) {
                respone.orderCache = orderCache;
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            socketResponse.data = respone;
            LogUtil.logBusiness(TAG, "preparePay cost:" + (System.currentTimeMillis() - time));

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 某个服务员下口碑提示框，已显示，则将服务员id存起来,下次不在提示
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/addUserIdOfKBHintDialog")
    public static SocketResponse addUserIdOfKBHintDialog(SocketHeader head, String param) {
        final SocketResponse socketResponse = new SocketResponse();
        try {
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            DataCacheDBUtil.addUserIdOfKBHintDialog(user.fsUserId);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取在线支付订单
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/loadOnlineBillList")
    public static SocketResponse loadOnlineBillList(SocketHeader head, String param) {
        final SocketResponse socketResponse = new SocketResponse();
        JSONObject socketRequest = JSON.parseObject(param);
        //构造网络请求request
        RapidPaySearchRequest request = new RapidPaySearchRequest();
        request.bizType = socketRequest.getString("bizType");
        request.itemsPerPage = socketRequest.getString("itemsPerPage");
        request.page = socketRequest.getString("page");
        request.payStatus = socketRequest.getString("payStatus");
        request.qryDate = socketRequest.getString("qryDate");

        final BillOnlineResponse billOnlineResponse = new BillOnlineResponse();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                RapidPaySearchResponse response = (RapidPaySearchResponse) responseData.responseBean;
                if (response.errno == 0) {
                    //支付信息列表json解析为obj
                    responseData.responseBean = JSON.parseObject(response.data, RapidPaySearchResponse.class);
                    ArrayList<BillOnlineModel> boms = ((RapidPaySearchResponse) responseData.responseBean).orders;
                    if (boms != null && boms.size() > 0) {
                        for (int j = 0; j < boms.size(); j++) {
                            //接口数据结合本地数据库拼装数据满足 产品需求
                            boms.get(j).tableName = TableDBUtil.getTableNameById(boms.get(j).tableNo);
                            boms.get(j).sellno = BillUtil.getSellnoByThirdPayInfo(boms.get(j).id + "");
                        }
                    }
                    billOnlineResponse.response = (RapidPaySearchResponse) responseData.responseBean;//处理后的数据返回给请求方
                    socketResponse.data = billOnlineResponse;
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else {
                    fail(responseData);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.data = billOnlineResponse;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, null, false);
        LogUtil.log("loadOnlineBillList execute result:" + (socketResponse.code == SocketResultCode.SUCCESS));
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/doVoidPay")
    public static SocketResponse voidPay(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");
        int seq = request.getInteger("seq");

        UserDBModel user = HostUtil.getUserModelBySession(head.us);

        SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(head.ot, user.fsUserId, orderID);
        if (!checkResponse.success()) {
            socketResponse.code = checkResponse.code;
            socketResponse.message = checkResponse.message;
            return socketResponse;
        }

        socketResponse = BillUtil.startVoidPay(head.ot, orderID, user, head.hd, seq);

        // 更新预付金状态
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);;
        TableBusinessUtil.modifyPrePay(null, orderCache.fsmtableid, ListUtil.isEmpty(OrderUtil.getPrePayModel(orderID)) ? TableStatusBean.NOMAL : TableStatusBean.PRE_PAYED);

        return socketResponse;
    }

    /**
     * 获取挂账对象
     *
     * @param param String
     * @return SocketResponse
     */
//    @DrivenMethod(uri = "billDriver/getHung")
//    public static SocketResponse getHung(SocketHeader head, String param) {
//        SocketResponse socketResponse = new SocketResponse();
//        socketResponse.code = SocketResultCode.SUCCESS;
//        //将可用额度<0的账户 可用额度归零
////        CreditaccountDBUtil.resetCanUseAmt();
//        List<CreditaccountDBModel> dataList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsCreditAccountId," +
//                "fsCreditAccountName,fdCreditAmt,fdDebtAmt from tbCreditAccount where fiStatus='1' order by " +
//                "fsCreditAccountId asc", CreditaccountDBModel.class);
//        GetHungInfoResponse response = new GetHungInfoResponse();
//        if (!ListUtil.isEmpty(dataList)) {
//            response.dataList = dataList;
//        }
//        socketResponse.data = response;
//        socketResponse.message = "";
//        return socketResponse;
//    }

    /**
     * 免收服务费
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/freeServiceFee")
    public static SocketResponse freeServiceFee(SocketHeader head, String param) {
        JSONObject request = JSON.parseObject(param);
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        String orderID = request.getString("orderid");
        String permissionUser = request.getString("permissionUser");

        if (TextUtils.isEmpty(permissionUser)) {
            permissionUser = user.fsUserId;
        }
        SocketResponse socketResponse = BillUtil.serviceFee(head.ot, orderID, user, head.hd, permissionUser, true);
        if (socketResponse.success()) {
            NotifyToClient.refreshTableOrOrders();
        }
        return socketResponse;
    }

    /**
     * 取消”免服务费“
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/cancelFreeServiceFee")
    public static SocketResponse cancelFreeServiceFee(SocketHeader head, String param) {
        JSONObject request = JSON.parseObject(param);
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        String orderID = request.getString("orderid");

        SocketResponse socketResponse = BillUtil.serviceFee(head.ot, orderID, user, head.hd, "", false);
        if (socketResponse.success()) {
            NotifyToClient.refreshTableOrOrders();
        }
        return socketResponse;
    }

    /**
     * 使用挂账
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/payHung")
    public static SocketResponse s(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            JSONObject request = JSON.parseObject(param);

            String orderID = request.getString("orderid");
            String accountID = request.getString("accountID");
            String accountName = request.getString("accountName");
            BigDecimal payAmount = request.getBigDecimal("payAmount");

            UserDBModel certigierUser = request.getObject("certigierUser", UserDBModel.class);

            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            //如果授权人和登录人一致，就不需要记录授权人了
            if (TextUtils.equals(user.fsUserId, certigierUser.fsUserId)) {
                certigierUser = null;
            }

            socketResponse = BillUtil.selectHung(head.ot, orderID, user, head.hd, accountID, accountName, payAmount, certigierUser);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 网络支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/netPay")
    public static SocketResponse netPay(SocketHeader head, String param) {

        long timePay = System.currentTimeMillis();
        LogUtil.logBusiness("===SCAN=PAY===", "billDriver#netPay  -- 支付业务中心开始=" + timePay);

        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");
        String barCode = request.getString("barcode");
        BigDecimal amount = request.getBigDecimal("payAmount");
        boolean isPrePay = request.getBooleanValue("isPrePay"); //是否预付金
        String thirdOrderID = request.getString("thirdOrderID");
        String payType = request.getString("payType");

        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }

        String error = NetPayUtil.checkSuooprt(payType, barCode);
        if (!TextUtils.isEmpty(error)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = error;
            return socketResponse;
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "金额不合法";
            return socketResponse;
        }
        if (TextUtils.isEmpty(thirdOrderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "第三方订单号为空";
            return socketResponse;
        }

        long userTime = System.currentTimeMillis();
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        socketResponse = BillUtil.selectNetPay(head.ot, orderID, false, thirdOrderID, amount, barCode, user, head.hd, isPrePay);
        userTime = System.currentTimeMillis() - userTime;
        LogUtil.logBusiness("===SCAN=PAY===", "billDriver#netPay ------BillUtil.selectNetPay-- 支付业务中心耗时=" + userTime);

        // 更新预付金状态
        long orderTime = System.currentTimeMillis();
        OrderCache orderCache = OrderSaveDBUtil.get(orderID);
        TableBusinessUtil.modifyPrePay(null, orderCache.fsmtableid, ListUtil.isEmpty(OrderUtil.getPrePayModel(orderID)) ? TableStatusBean.NOMAL : TableStatusBean.PRE_PAYED);
        orderTime = System.currentTimeMillis() - orderTime;
        LogUtil.logBusiness("===SCAN=PAY===", "billDriver#netPay ------TableBusinessUtil.modifyPrePay-- 支付业务中心耗时=" + orderTime);

        timePay = System.currentTimeMillis() - timePay;
        LogUtil.logBusiness("===SCAN=PAY===", "billDriver#netPay  -- 支付业务中心总耗时：" + timePay);
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/memberbalance")
    public static SocketResponse memberbalance(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");
        String thirdOrderID = request.getString("thirdPayOrderID");
        String pwd = request.getString("pwd");

        BigDecimal amount = request.getBigDecimal("payAmount");
        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "金额不合法";
            return socketResponse;
        }
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        socketResponse = BillUtil.selectMemberBalance(head.ot, orderID, user, head.hd, thirdOrderID, pwd, amount, socketResponse);

        LogUtil.log("储值支付", "返回" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/memberpoint")
    public static SocketResponse memberpoint(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");

        BigDecimal amount = request.getBigDecimal("payAmount");
        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "金额不合法";
            return socketResponse;
        }
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        socketResponse = BillUtil.selectMemberPoint(head.ot, orderID, user, head.hd, amount);
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/memberticket")
    public static SocketResponse memberticket(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();

        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");
        PayOriginModel selectTicket = request.getObject("selectTicket", PayOriginModel.class);

        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        socketResponse = BillUtil.selectMemberTicket(head.ot, orderID, user, head.hd, selectTicket);
        return socketResponse;
    }

    /**
     * 重新查询条码支付的结果
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/reSearchpay")
    public static SocketResponse reSearchpay(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderid");
        String thirdPayOrderID = request.getString("thirdPayOrderID");
        boolean isPrePay = request.getBooleanValue("isPrePay"); //是否预付金
        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        if (TextUtils.isEmpty(thirdPayOrderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "第三方支付的订单号为空";
            return socketResponse;
        }
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        socketResponse = BillUtil.selectNetPay(head.ot, orderID, true, thirdPayOrderID, BigDecimal.ZERO, "", user,
                head.hd, isPrePay);
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/selectPayType")
    public static SocketResponse selectPay(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        try {

            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            PayOriginModel selectPay = request.getObject("seletpay", PayOriginModel.class);
            BigDecimal inputAmt = request.getBigDecimal("inputAmt");
            //授权人信息
            String certigierUserId = request.getString("certigierUserId");
            String certigierUserName = request.getString("certigierUserName");

            if (inputAmt.compareTo(BigDecimal.ZERO) <= 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请输入支付金额";
                return socketResponse;
            }
            if (selectPay == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "支付方式不正确";
                return socketResponse;
            }

            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            UserDBModel certigierUser = null;
            //如果授权人和登录人一致，就不需要记录授权人了
            if (!TextUtils.equals(user.fsUserId, certigierUserId)) {
                certigierUser = new UserDBModel();
                certigierUser.fsUserId = certigierUserId;
                certigierUser.fsUserName = certigierUserName;
            }

            String fsmtableId = OrderSaveDBUtil.getTableIDByOrderID(orderID);

            PaySession session;
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderID, "billDriver/selectPayType");
            try {
                socketResponse = BillUtil.selectPayType(head.ot, orderID, selectPay, inputAmt, user, head.hd, false, false, certigierUser);
                if (socketResponse.data != null) {
                    socketResponse.data.payFinished = false;
                }
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
                if (socketResponse.code == SocketResultCode.SUCCESS && PayUtil.supportAutoPay(orderCache.fiSellType) && PayType.isOnlinePay(selectPay)) {
                    SocketResponse<PayResultResponse> socketFinishResponse = BillUtil.checkAutoFinishAndStart(head.ot, orderID, false, socketResponse.data.payData.payListToShow.get(0), user, head.hd);
                    if (socketFinishResponse.code == SocketResultCode.SUCCESS) {
                        if (socketFinishResponse.data.payFinished) {
                            socketResponse.data.payFinished = true;
                        }
                    } else {
                        socketResponse.data.payFinished = false;
                        socketResponse.code = socketFinishResponse.code;
                        socketResponse.message = socketFinishResponse.message;
                        return socketResponse;
                    }
                } else {
                    return socketResponse;
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderID, "billDriver/selectPayType");
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "billDriver/payFinish")
    public static SocketResponse payFinish(SocketHeader head, String param) {
        SocketResponse<PayResultResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");


            UserDBModel user = HostUtil.getUserModelBySession(head.us);

            SocketBaseResponse checkResponse = BillUtil.checkCanOperateOrder(head.ot, user.fsUserId, orderID);

            if (!checkResponse.success()) {
                socketResponse.code = checkResponse.code;
                socketResponse.message = checkResponse.message;
                return socketResponse;
            }
            boolean printBill = TextUtils.equals(ClientMetaUtil.getConfig(META.T_CASHIER_PRINTER, "1"), "1");
            socketResponse = BillUtil.startFinalPayProcess(head.ot, orderID, user, head.hd, true, printBill);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 开钱箱
     *
     * @return String
     */
    @DrivenMethod(uri = "billDriver/openMoneybox")
    public static SocketResponse openMoneybox(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        GetUnPrintTaskNoResponse response = new GetUnPrintTaskNoResponse();
        UserDBModel user = HostUtil.getUserModelBySession(head.us);

        response.printTaskNoList = BillUtil.sendOpenMoneyBox("", "", "", head.hd, user);
        socketResponse.data = response;
        return socketResponse;
    }

    /**
     * 将秒付信息落入到指定的桌台中
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/saveRapid")
    public static SocketResponse saveRapidPay(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String tableID = request.getString("tableID");
            int msgID = request.getInteger("msgID");
            int confirmBind = request.getInteger("confirmBind");
            if (TextUtils.isEmpty(tableID)) {
                socketResponse.message = "桌台ID为空";
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }

            synchronized (saveRapidLock) {  //避免消息同时被关联到多订单

                String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableID, String.valueOf(msgID), "将秒付信息落入到指定的桌台中");
                try {  //避免多业务同时操作一个订单
                    String orderID = TableBusinessUtil.getOrderIDByTableID(tableID);
                    if (TextUtils.isEmpty(orderID)) {
                        socketResponse.msg(R.string.serr_no_order);
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    }

                    OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
                    if (orderCache == null) {
                        socketResponse.msg(R.string.serr_invalid_order);
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    }

                    MessagePayBean messagePayBean = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from message " +
                            "where msgId = '" + msgID + "'", MessagePayBean.class);
                    if (messagePayBean == null) {
                        socketResponse.message = "未查询到收银记录";
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    }

                    if (!messagePayBean.isUnDeal()) {
                        socketResponse.message = "该消息已被处理";
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    }
                    RapidPayment rapidPayment = JSON.parseObject(messagePayBean.msgBody, RapidPayment.class);
                    if (rapidPayment == null || ListUtil.isEmpty(rapidPayment.paymentList)) {
                        socketResponse.message = "秒付信息异常";
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    }
                    BigDecimal orderNeedPay;

                    PaySession session = OrderSession.getInstance().getPay(orderID);
                    if (session != null) {
                        BigDecimal totalPrice = OrderSaveDBUtil.getOrderTotalPrice(orderID);
                        //重新计算待支付
                        OrderUtil.recalcPaySessionLeftToPay(session, totalPrice);
                        orderNeedPay = session.priceLeftToPay;
                    } else {
                        orderNeedPay = orderCache.optTotalPrice();
                        if (orderCache.couponCut != null) {
                            orderNeedPay = orderNeedPay.subtract(orderCache.couponCut.fdCutmoney);
                        }
                        if (orderCache.selectOrderDiscountCut != null) {
                            orderNeedPay = orderNeedPay.subtract(orderCache.selectOrderDiscountCut.fdddv);
                        }
                    }

                    BigDecimal rapidTotalAmt = RapidUtil.parseRapidPayTotalAmt(rapidPayment);
                    //如果金额完美的匹配上，则直接进行秒付
                    boolean save = false;

                    SaveRapidPayToOrderResponse response = new SaveRapidPayToOrderResponse();
                    if (orderNeedPay.compareTo(rapidTotalAmt) > 0) {
                        response.payAmountNotRight = 2;
                    } else if (orderNeedPay.compareTo(rapidTotalAmt) < 0) {
                        response.payAmountNotRight = 1;
                    } else {
                        response.payAmountNotRight = 0;
                        save = true;
                    }
                    response.orderId = orderID;
                    socketResponse.data = response;

                    if (confirmBind != 0) {
                        save = true;
                    }

                    if (save) {
                        rapidPayment.tableNo = tableID;
                        rapidPayment.outerOrderId = orderID;
                        RapidActionModel actionModel = new RapidActionModel();
                        RapidBiz.buildPayment(actionModel, rapidPayment);
                        if (actionModel.result != RapidResult.SUCCESS) {
                            socketResponse.message = actionModel.errorInfo;
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            return socketResponse;
                        } else {
                            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);

                            Map<String, String> map = new HashMap<>();
                            map.put("tableName", orderCache.fsmtablename);  //桌台名称
                            map.put("payAmt", Calc.formatShow(rapidTotalAmt));  //已支付金额
                            map.put("allAmt", Calc.formatShow(orderCache.optTotalPrice()));  //订单总金额
                            //将秒付纯收银消息置为已处理
                            MessageDBUtil.updateRapidOnlyPayMessage(msgID, MessageConstance.MessagePayBuinessStatus
                                    .RAPID_ONLY_PAY.DOWN, userDBModel, orderID, orderCache.fsmtableid, JSON
                                    .toJSONString(map));
                            NotifyToClient.refreshUndealMessage();
                            NotifyToClient.refrehMessageData();
                        }
                    } else {
                        OrderSession.getInstance().writePay(orderID, session);
                    }
                } finally {
                    ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableID, String.valueOf(msgID), "将秒付信息落入到指定的桌台中");
                }
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取会员的优惠券的列表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/getmemberticket")
    public static SocketResponse getMemberTicket(SocketHeader head, String param) {
        SocketResponse<GetPayMemberTicketResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.serr_invalid_orderid);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            socketResponse = BillUtil.searchMemberTicket(orderID);

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 开始反结账
     * 需要原始桌台不处于开台状态。
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/startRePay")
    public SocketResponse startRePay(SocketHeader head, final String param) {
        SocketResponse socketResponse = new SocketResponse();
        StartRepayResponse data = new StartRepayResponse();
        socketResponse.data = data;
        try {
            final JSONObject request = JSON.parseObject(param);
            final String orderid = request.getString("orderid");
            int fiSellType = request.getInteger("fiSellType");
            String tableID = request.getString("tableID");
            final UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderid);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在，请重试";
                return socketResponse;
            }
            if (fiSellType == 0) {
                String lockError = TableBusinessUtil.lockTable(tableID, head.hd, userDBModel.fsUserId, userDBModel
                        .fsUserName);
                if (!TextUtils.isEmpty(lockError)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = lockError;
                    return socketResponse;
                }
                socketResponse = TableBusinessUtil.doOpenTable(socketResponse, head.hd, tableID, orderid, userDBModel);
                if (socketResponse.code != SocketResultCode.SUCCESS) {
                    return socketResponse;
                }
                data.amtPrePay = OrderUtil.getPrePayAmt(orderid);
            } else {
                String error = FastFoodBusinessUtil.checkOrderLock(head.hd, userDBModel.fsUserId, orderid);
                if (TextUtils.isEmpty(error)) {
                    FastFoodBusinessUtil.lockedOrder(orderid, userDBModel.fsUserId, userDBModel.fsUserName, head.hd);
                    OrderSaveDBUtil.updateOrderBizStatus(orderid, FastFoodBizStatus.ANTI_PAIED);
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                    return socketResponse;
                }
                //生成点菜token
                data.orderToken = ServerCache.getInstance().generateNewToken(orderid);
                // 通知各个站点刷新锁单信息
                NotifyToClient.refreshFastFoodOrdersLock();
            }

            //如果订单有轮询的赠送会员积分的任务，则在此取消掉
            JobScheudler.updateJobStatus(JobType.MEMBER_GIFT, orderid, JobStatus.CANCELED);
            JobScheudler.updateJobStatus(JobType.MEMBER_GIFT_NEW, orderid, JobStatus.CANCELED);
            //如果当前订单关联着会员
            String isMember = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select is_member from order_cache where " +
                    "order_id='" + orderid + "'");
            if (TextUtils.equals(isMember, "1")) {
                final PaySession session = OrderSession.getInstance().getPay(orderid);
                //处理订单的已赠送积分，   memberGiftScore
                if (session != null) {
                    String memberGiftResponse = JobScheudler.getTrace2ByTrace1AndBizKey(orderid, session
                            .memberOrderID, JobType.MEMBER_GIFT);
                    String memberGiftNewResponse = JobScheudler.getTrace2ByTrace1AndBizKey(orderid, session
                            .memberOrderID, JobType.MEMBER_GIFT_NEW);
                    int giftScore = 0;
                    if (!TextUtils.isEmpty(memberGiftNewResponse)) { // 先处理新的
                        try {
                            MemberOrderConsumeResponse response = JSON.parseObject(memberGiftNewResponse,
                                    MemberOrderConsumeResponse.class);
                            if (response != null && response.data != null) {
                                giftScore = response.data.incr_score;
                            }
                        } catch (Exception e) {
                            LogUtil.logError("反结账退积分时遇到异常", e);
                        }
                    } else if (!TextUtils.isEmpty(memberGiftResponse)) {
                        try {
                            MemberOrderConsumeResponse response = JSON.parseObject(memberGiftResponse,
                                    MemberOrderConsumeResponse.class);
                            if (response != null && response.data != null) {
                                giftScore = response.data.incr_score;
                            }
                        } catch (Exception e) {
                            LogUtil.logError("反结账退积分时遇到异常", e);
                        }
                    } else {
                        giftScore = session.memberGiftScore;
                    }

                    session.memberGiftScore = giftScore;
                    PayUtil.processMemberRefundNew(null, session, true, new IMemberRefundNew() {
                        @Override
                        public void callBack(boolean result, String msg, final NewMemberOrderRefundRequest request,
                                             boolean containsMemberDiscountFinal) {
                            if (request != null) {
                                OrderSession.getInstance().writePay(session.orderID, session);
                                BusinessExecutor.execute(request, null, new BusinessCallback() {
                                            @Override
                                            public boolean success(int i, ResponseData responseData) {
                                                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                                                return false;
                                            }

                                            @Override
                                            public boolean fail(int i, ResponseData responseData) {
                                                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                                                JobScheudler.newJob(JobType.REFUND_MEMBER_NEW, session.orderID, JSON
                                                        .toJSONString(request));
                                                return false;
                                            }
                                        }
                                        , true);
                            }
                        }
                    });
                }
            }
            BillUtil.antiPayOrderStatus(orderCache, userDBModel, orderid, request.getString("antiPayReason"));
            NotifyToClient.orderChange(orderid);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 处理异常订单
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/dealErrorOrder")
    public static SocketResponse dealErrorOrder(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            String tableID = request.getString("tableid");
            int sellType = request.getInteger("fiSellType");
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.serr_invalid_orderid);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            //快餐：1 ；正餐： 0
            if (sellType == 0) {
                TableBizModel tableBiz = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tableBiz where fsmtableid = '" + tableID + "'", TableBizModel.class);
                if (tableBiz == null) {
                    socketResponse.msg(R.string.serr_invalid_orderid);
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }
                if (tableBiz.lockedStatus == 1) {//锁桌状态 0：正常 1：被锁住
                    socketResponse.message = "此桌台正在被" + tableBiz.lockedHostId + "占用";
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }
                //fsmtablesteid餐桌狀態代號;1空闲 / 2开台 / 3占用 / 8预订 / 9停用
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set fsmtablesteid = '2',fssellno = '" + orderID + "' where fsmtableid = '" + tableID + "'");
            } else if (sellType == 1) {
                String status = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderID + "'");
                if (TextUtils.isEmpty(status)) {
                    FastFoodDBUtil.save(OrderSession.getInstance().getOrder(orderID));
                    FastFoodDBUtil.updateOrderBizStatus(orderID, FastFoodBizStatus.ORDER);
                } else {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set fastfood_biz_status = '1' where order_id = '" + orderID + "'");
                }
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 启动订单优化页
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/startOptBill")
    public static SocketResponse startOptBill(SocketHeader head, String param) {
        SocketResponse<BillOptViewResponse> response = new SocketResponse<>();
        BillOptViewResponse data = new BillOptViewResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            data.payTypeList = PayCache.getInstance().payTypeList;
            data.config = DBMetaUtil.getConfig(META.SHOP_SERVICE_BILL_OPT, "");
            data.accountBookList = AccountBookUtil.optAllAccountBook(false);
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 筛选订单
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/filterBill")
    public static SocketResponse filterBill(SocketHeader head, String param) {
        final SocketResponse<BillOptFilterResponse> response = new SocketResponse<>();
        final BillOptFilterResponse data = new BillOptFilterResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            final String businessDate = request.getString("businessDate");
            if (TextUtils.isEmpty(businessDate)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }

            // 筛选的支付方式
            List<String> payTypeList = JSON.parseArray(request.getJSONArray("payTypeList").toString(), String.class);
            // 是否全选支付方式
            int checkAllPayment = request.getInteger("checkAllPayment");
            // 筛选比例
            BigDecimal percent = request.getBigDecimal("percent");
            // 账套id
            String accountBookId = request.getString("accountBookId");

            data.sellCheckList = BillUtil.billOptFilter(businessDate, payTypeList, checkAllPayment, percent);

            JSONObject objTotal = BillUtil.billStatistics(businessDate);
            data.totalNum = objTotal.getInteger("totalNum");
            data.totalAmt = objTotal.getBigDecimal("totalAmt");

            JSONObject objHidden = BillUtil.billHiddenStatistics(businessDate, accountBookId);
            data.hiddenNum = objHidden.getInteger("hiddenNum");
            data.hiddenAmt = objHidden.getBigDecimal("hiddenAmt");

//            String state = BillUtil.syncBillUploadState(businessDate);
//            if (!TextUtils.equals(state, "0") && !TextUtils.equals(state, "1") && !TextUtils.equals(state, "2")) {
//                response.code = SocketResultCode.BUSINESS_FAILED;
//                response.message = state;
//                return response;
//            }
//            data.hasUpload = StringUtil.toInt(state);

            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 优化账单
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/optimize")
    public static SocketResponse optimize(SocketHeader head, String param) {
        SocketResponse<BillOptFilterResponse> response = new SocketResponse<>();
        BillOptFilterResponse data = new BillOptFilterResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            if (!ShopServiceUtil.billOptimize()) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "门店未开启账单优化";
                return response;
            }
            if (userDBModel.fiBillAuthority == 1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = String.format("服务员[%s]没有账单优化权限", userDBModel.fsUserName);
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            List<String> orderIdList = JSON.parseArray(request.getJSONArray("sellNoList").toString(), String.class);
            if (ListUtil.isEmpty(orderIdList)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请先选择需要操作的订单";
                return response;
            }

            int hidden = request.getInteger("hidden");
            if (hidden < 0 || hidden > 1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }

            // 营业日期
            String businessDate = request.getString("businessDate");
            List<String> all = JSON.parseArray(request.getJSONArray("allOrder").toString(), String.class);
            // 要处理的账套id
            String accountBookId = request.getString("accountBookId");

            String errMsg = BillUtil.optimize(businessDate, orderIdList, hidden, accountBookId);

            if (!TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMsg;
                return response;
            }

            data.sellCheckList = BillUtil.getBillOptWithOrderId(all);

            JSONObject objTotal = BillUtil.billStatistics(businessDate);
            data.totalNum = objTotal.getInteger("totalNum");
            data.totalAmt = objTotal.getBigDecimal("totalAmt");

            JSONObject objHidden = BillUtil.billHiddenStatistics(businessDate, accountBookId);
            data.hiddenNum = objHidden.getInteger("hiddenNum");
            data.hiddenAmt = objHidden.getBigDecimal("hiddenAmt");

            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 上传账单
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/uploadBill")
    public synchronized static SocketResponse uploadBill(SocketHeader head, String param) {
        final SocketResponse<BaseSocketResponse> response = new SocketResponse<>();
        BaseSocketResponse data = new BaseSocketResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            final String businessDate = request.getString("businessDate");
            if (TextUtils.isEmpty(businessDate)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }

            final JSONObject ob = new JSONObject();

            boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    UploadBillRequest uploadBillRequest = new UploadBillRequest();
                    uploadBillRequest.shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                    uploadBillRequest.selldate = businessDate;
                    BusinessExecutor.execute(uploadBillRequest, new IExecutorCallback() {
                        @Override
                        public void success(ResponseData responseData) {
                            BillUtil.syncBillUploadState(businessDate);
                            BillUtil.saveBillUploadState(businessDate, 0, false);
                            ob.put("code", SocketResultCode.SUCCESS);
                            ob.put("error", "数据已上送");
                            synchronized (ob) {
                                ob.notify();
                            }
                        }

                        @Override
                        public boolean fail(ResponseData responseData) {
                            ob.put("code", SocketResultCode.BUSINESS_FAILED);
                            ob.put("error", responseData.resultMessage);
                            synchronized (ob) {
                                ob.notify();
                            }
                            return false;
                        }
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    ob.put("code", SocketResultCode.BUSINESS_FAILED);
                    ob.put("error", responseData.resultMessage);
                    synchronized (ob) {
                        ob.notify();
                    }
                    return false;
                }
            }, null);

            if (!doAsyn) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "正在同步数据,请稍后重试";
                return response;
            }

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    ob.put("code", SocketResultCode.BUSINESS_FAILED);
                    ob.put("error", "正在同步数据,请稍后重试");
                    synchronized (ob) {
                        ob.notify();
                    }
                }
            }, 30 * 1000);

            synchronized (ob) {
                try {
                    ob.wait();
                    response.code = ob.getInteger("code");
                    response.message = ob.getString("error");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 获取账单上传操作日志
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/uploadLog")
    public static SocketResponse uploadLog(SocketHeader head, String param) {
        SocketResponse<BillOptLogResponse> response = new SocketResponse<>();
        BillOptLogResponse data = new BillOptLogResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            // 账套id
            String accountBookId = request.getString("accountBookId");

            data.logs = AccountBookUtil.queryBillOptLog(accountBookId);
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 保存上传设置
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "billDriver/saveSetting")
    public synchronized static SocketResponse saveSetting(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> response = new SocketResponse<>();
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            JSONObject obj = JSONObject.parseObject(request.getString("config"));
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_SAVE_CONFIG, "保存账单上传设置[" + obj.toJSONString() + "]");
            DBMetaUtil.updateSettingsValueByKey(META.SHOP_SERVICE_BILL_OPT, obj.toJSONString());
            NotifyToClient.refreshSetting(String.valueOf(META.SHOP_SERVICE_BILL_OPT), obj.toJSONString());

            JobScheudler.deleteJobByType(JobType.BILL_UPLOAD);
            JobScheudler.deleteJobByType(JobType.BILL_HIDDEN);

            if (obj.getInteger("type") == 1) {
                // 添加Job，闹钟上传账单
                Job job = new Job();
                job.type = JobType.BILL_UPLOAD;
                job.typeLoop = 2;
                job.driver_uri = "billDriver/timingUpload";
                job.loopDestTime = DateUtil.formartDateStrToTarget(obj.getString("time"), "HH:mm", "HH:mm:ss");
                JobScheudler.newJob(job);

                // 添加Job, 轮询处理订单
                Job jobHidden = new Job();
                jobHidden.type = JobType.BILL_HIDDEN;
                jobHidden.typeLoop = 0;
                jobHidden.driver_uri = "billDriver/batchProcessBillHidden";
                jobHidden.cycle = BaseConfig.isProduct() ? 2 : 1;
                JobScheudler.newJob(jobHidden);
            }

            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 批量处理隐藏账单
     */
    @DrivenMethod(uri = "billDriver/batchProcessBillHidden")
    public synchronized static void batchProcessBillHidden() {
        RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_BATCH_PROCESS, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]为自动上传处理账单");

        JSONObject obj = JSONObject.parseObject(DBMetaUtil.getConfig(META.SHOP_SERVICE_BILL_OPT, ""));
        if (obj == null) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_BATCH_PROCESS, "账单优化配置为空，退出优化账单处理");
            return;
        }
        // 手动上传、关闭自动筛选，都不进行后台批处理
        if (obj.getInteger("type") == 0) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_BATCH_PROCESS, "账单上传设置为手动上传，退出优化账单处理");
            return;
        }
        if (obj.getInteger("autoFilter") == 0) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_BATCH_PROCESS, "账单上传设置关闭自动筛选，退出优化账单处理");
            return;
        }

        BigDecimal percent = obj.getBigDecimal("percent");

        final String businessDate = HostUtil.getHistoryBusineeDate("");

        String exclude = "";
        List<String> payment = JSON.parseArray(obj.getJSONArray("payment").toJSONString(), String.class);
        final StringBuilder paramPayment = new StringBuilder();
        if (!ListUtil.isEmpty(payment)) {
            for (int index = 0; index < payment.size(); index++) {
                paramPayment.append("'");
                paramPayment.append(payment.get(index));
                paramPayment.append("'");
                if (index < payment.size() - 1) {
                    paramPayment.append(", ");
                }
            }
            exclude = " AND fsSellNo NOT IN (SELECT fsSellNo FROM tbsellreceive WHERE fsPaymentId IN (" + paramPayment.toString() + "))";
        }

        // 不包含支付方式的当前营业日期的订单总数
        String sqlTotalCount = "SELECT count(*) AS count FROM tbsell WHERE fiBillStatus = 3 AND fsSellDate = '" + businessDate + "'" + exclude;
        int totalNum = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlTotalCount, "count", Integer.class);
        LogUtil.log("自动批处理筛选账单, 不包含排除支付方式的账单总数:\nSQL: " + sqlTotalCount + "\n总数: " + totalNum);

        // 当前符合条件的显示的账单
        String sqlShow = "SELECT count(*) AS count FROM tbsell WHERE fiBillStatus = 3 AND fsSellDate = '" +
                businessDate + "'" + exclude + " AND fiSelected = 0";
        int showNum = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlShow, "count", Integer.class);
        LogUtil.log("自动批处理筛选账单, 当前显示的账单数量:\nSQL: " + sqlShow + "\n总数: " + showNum);

        // 需要隐藏的账单数量
        final int limit = new BigDecimal(showNum).subtract(new BigDecimal(totalNum).multiply(percent).divide
                (BigDecimal.TEN).setScale(0, BigDecimal.ROUND_HALF_UP)).intValue();
        LogUtil.log("自动批处理筛选账单, 需要隐藏的账单数量:" + limit);

        if (limit <= 0) {
            LogUtil.log("自动批处理筛选账单, 需要隐藏的数量小于0, 退出处理");
            return;
        }

        final String finalExclude = exclude;
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {

                // 1. 将含有排除的支付方式先隐藏
                String sqlPayExclude = "UPDATE tbsell SET fiSelected = 1 WHERE fiBillStatus = 3 AND fsSellDate = '" +
                        businessDate + "' AND fsSellNo IN (SELECT fsSellNo FROM tbsellreceive WHERE fsPaymentId IN ("
                        + paramPayment.toString() + "))";
                db.execSQL(sqlPayExclude);
                LogUtil.log("自动批处理筛选账单, 所有排除的支付方式隐藏, SQL: " + sqlPayExclude);

                // 1. 修改 order_cache
                String sqlOrderCache = "UPDATE order_cache SET hidden = 1 WHERE order_id IN (SELECT fsSellNo FROM " +
                        "tbsell WHERE fsSellDate = '" + businessDate + "'" + finalExclude + " AND fiBillStatus = 3 " +
                        "AND fiSelected = 0 ORDER BY random() LIMIT " +
                        "" + limit + ")";
                db.execSQL(sqlOrderCache);
                // 2. 修改 tbsell
                String sqlTbSell = "UPDATE tbsell SET fiSelected = 1, lver = lver + 1 WHERE fsSellNo IN (SELECT " +
                        "fsSellNo FROM tbsell WHERE fsSellDate = '" + businessDate + "'" + finalExclude + " AND " +
                        "fiBillStatus = 3 AND fiSelected = 0 ORDER BY " +
                        "random() LIMIT " + limit + ")";
                db.execSQL(sqlTbSell);
                LogUtil.log("自动批处理筛选账单\n修改 order_cache SQL: " + sqlOrderCache + "\n修改 tbsell SQL: " + sqlTbSell);
                return null;
            }
        });
    }

    /**
     * 定时上传账单至商场
     */
    @DrivenMethod(uri = "billDriver/timingUpload")
    public synchronized static void timingUpload() {
        RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]启动定时上传账单");

        // 1.校验配置是否自动上传
        final JSONObject config = JSON.parseObject(ClientMetaUtil.getConfig(META.SHOP_SERVICE_BILL_OPT, ""));
        if (!config.containsKey("type")) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "账单自动上传设置项为空，退出自动上传");
            return;
        }
        if (config.getInteger("type") != 1) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "账单上传设置为手动上传，退出自动上传");
            return;
        }

        // 2. 是否已上传
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0")) {
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "全部上传完成，退出自动上传");
            return;
        }

        // 3. 上传前，处理一次订单
        batchProcessBillHidden();

        // 2.上传本地订单至后台
        boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]本地账单上传后台完成，即将上传至商场");

                final String businessDate = HostUtil.getHistoryBusineeDate("");
                String date = businessDate;
                if (config.getInteger("next") == 1) {
                    date = ReportProcessor.getPreDate(businessDate);
                }
                RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "系统日期[" + DateUtil.getCurrentDate("yyyy-MM-dd") + "], 营业日期[" + businessDate + "], 即将上传的账单日期[" + date + "], 是否开启次日上传[" + config.getInteger("next") + "]");

                String state = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + date);
                if (TextUtils.equals(state, "0") && BaseConfig.isProduct()) {
                    RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDate("yyyy-MM-dd") + "]账单已全部上传完成，退出自动上传");
                    return;
                }

                UploadBillRequest uploadBillRequest = new UploadBillRequest();
                uploadBillRequest.shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                uploadBillRequest.selldate = date;
                final String finalDate = date;
                BusinessExecutor.execute(uploadBillRequest, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]定时上传[" + finalDate + "]账单成功");
                        BillUtil.saveBillUploadState(businessDate, 0, false);
                        BillUtil.syncBillUploadState(businessDate);
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        JobScheudler.updateJobWorkTimeByType(JobType.BILL_UPLOAD, "");
                        RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]定时上传账单失败，错误信息");
                        return false;
                    }
                });
            }

            @Override
            public boolean fail(ResponseData responseData) {
                JobScheudler.updateJobWorkTimeByType(JobType.BILL_UPLOAD, "");
                RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]本地账单上传后台失败，退出自动上传");
                return false;
            }
        }, null);
        if (!doAsyn) {
            JobScheudler.updateJobWorkTimeByType(JobType.BILL_UPLOAD, "");
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_AUTO, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "]正在同步账单至后台，稍后重试");
        }
    }

    /**
     * 同步账单上传状态
     *
     * @return int | 0, 未上传; 1,已上传; -1,同步失败
     */
    @DrivenMethod(uri = "billDriver/syncBillUploadState")
    public static void syncBillUploadState() {
        String businessDate = HostUtil.getHistoryBusineeDate("");
//        BillUtil.syncBillUploadState(businessDate);
        AccountBookUtil.loadBillUploadStatus(businessDate);
    }

    /**
     * 团购券验券
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = "billDriver/groupTicket")
    public static SocketResponse groupTicket(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String orderId = request.getString("orderId");
        if (TextUtils.isEmpty(orderId)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        int num = request.getInteger("num");
        PayOriginModel payOriginModel = request.getObject("selectTicket", PayOriginModel.class);
        return BillUtil.doUseGroupTicket(head, orderId, payOriginModel.groupTicket.sn, num, payOriginModel);
    }

    @DrivenMethod(uri = "billDriver/buildPayOrder")
    public static SocketResponse buildPayOrder(SocketHeader head, String param) {
//        long timeSer = System.currentTimeMillis();

        SocketResponse<PayResultResponse> socketResponse = new SocketResponse();
        PayResultResponse data = new PayResultResponse();
        socketResponse.data = data;

        JSONObject request = JSON.parseObject(param);
        String orderId = request.getString("orderId");
        if (TextUtils.isEmpty(orderId)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }

        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            socketResponse.message = "登录信息已过期";
            return socketResponse;
        }

        data.thirdPayOrderID = BillUtil.buildPayOrder(orderId, userDBModel, head.hd);
//        timeSer = System.currentTimeMillis() - timeSer;
//        LogUtil.logBusiness("===SCAN=PAY===", "BillDriver#buildPayOrder 业务中心 -- 支付订单生成耗时=" + timeSer);
        return socketResponse;
    }

    /**
     * 保存上传设置
     */
    @DrivenMethod(uri = "billDriver/saveAccountBookConfig")
    public synchronized static SocketResponse saveAccountBookConfig(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> response = new SocketResponse<>();
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            String accountBookStr = request.getString("accountBook");
            RunTimeLog.addLog(RunTimeLog.BILL_UPLOAD_SAVE_CONFIG, "保存账单上传设置[" + accountBookStr + "]");
            AccountBookDBModel accountBook = JSONObject.parseObject(accountBookStr, AccountBookDBModel.class);
            String error = AccountBookUtil.saveAccountBook(accountBook, userDBModel);
            if (!TextUtils.isEmpty(error)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = error;
                return response;
            }

            // 清除老版本配置
            DBMetaUtil.updateSettingsValueByKey(META.SHOP_SERVICE_BILL_OPT, "");
            NotifyToClient.refreshSetting(String.valueOf(META.SHOP_SERVICE_BILL_OPT), "");

            JobScheudler.deleteJobByType(JobType.BILL_HIDDEN);

            // 非手动上传
            if (accountBook != null && accountBook.uploadType != 2) {
                // 添加Job, 轮询处理订单
                Job jobHidden = new Job();
                jobHidden.type = JobType.BILL_HIDDEN;
                jobHidden.typeLoop = 0;
                jobHidden.driver_uri = "billDriver/batchProcessBillAccountBook";
                jobHidden.cycle = BaseConfig.isProduct() ? 2 : 1;
                JobScheudler.newJob(jobHidden);
            }

            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 批量处理订单账套
     */
    @DrivenMethod(uri = "billDriver/batchProcessBillAccountBook")
    public synchronized static void batchProcessBillAccountBook() {
        // 处理订单账套
        AccountBookUtil.processAccountBookAuto(null);
    }

    /**
     * 手动上传，通知云端上传账单
     */
    @DrivenMethod(uri = "billDriver/uploadBillManual")
    public synchronized static SocketResponse uploadBillManual(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> response = new SocketResponse<>();
        BaseSocketResponse data = new BaseSocketResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            if (TextUtils.isEmpty(param)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }
            JSONObject request = JSON.parseObject(param);

            String businessDate = request.getString("businessDate");
            if (TextUtils.isEmpty(businessDate)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "内部异常,请稍后重试";
                return response;
            }

            String accountBookId = request.getString("accountBookId");
            if (TextUtils.isEmpty(businessDate)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请指定账套后重试";
                return response;
            }

            JSONObject ob = new JSONObject();

            boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    AccountBookUtil.commitAccountBookBillWithNotify(accountBookId, businessDate, new IResult() {
                        @Override
                        public void callBack(boolean result, String info) {
                            if (result) {
                                ob.put("code", SocketResultCode.SUCCESS);
                                ob.put("error", "");
                            } else {
                                ob.put("code", SocketResultCode.BUSINESS_FAILED);
                                ob.put("error", info);
                            }
                            synchronized (ob) {
                                ob.notify();
                            }
                        }
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    ob.put("code", SocketResultCode.BUSINESS_FAILED);
                    ob.put("error", responseData.resultMessage);
                    synchronized (ob) {
                        ob.notify();
                    }
                    return false;
                }
            }, null);

            if (!TextUtils.isEmpty(ob.getString("error"))) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = ob.getString("error");
                return response;
            }

            if (!doAsyn) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "正在同步数据,请稍后重试";
                return response;
            }

            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 根据用户获取账套列表
     */
    @DrivenMethod(uri = "billDriver/loadAccountBook")
    public SocketResponse loadAccountBook(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        LoadAccountBookResponse response = new LoadAccountBookResponse();
        socketResponse.data = response;

        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            socketResponse.message = "登录信息已过期";
            return socketResponse;
        }

        JSONObject request = JSON.parseObject(param);
        Boolean checkUser = request.getBoolean("checkUser");
        if (checkUser == null) {
            checkUser = false;
        }

        List<AccountBookDBModel> accountBookList = AccountBookUtil.optAllAccountBook(true);

        if (checkUser) {
            response.accountBookList = new ArrayList<>();
            String fsBillClass2 = userDBModel.fsBillClass2;
            if (!TextUtils.isEmpty(fsBillClass2)) {
                String[] split = fsBillClass2.split(",");
                if (split != null && split.length > 0) {
                    List<String> idList = Arrays.asList(split);
                    for (AccountBookDBModel accountBook : accountBookList) {
                        if (accountBook == null) {
                            continue;
                        }
                        if (idList.contains(accountBook.accountBookId)) {
                            response.accountBookList.add(accountBook);
                        }
                    }
                }
            }
        } else {
            response.accountBookList = accountBookList;
        }

        socketResponse.code = SocketResultCode.SUCCESS;
        return socketResponse;
    }
}
