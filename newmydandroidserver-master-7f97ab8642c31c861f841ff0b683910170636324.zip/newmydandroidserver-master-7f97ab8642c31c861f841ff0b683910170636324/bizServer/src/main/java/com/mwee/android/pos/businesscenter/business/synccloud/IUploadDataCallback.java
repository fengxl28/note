package com.mwee.android.pos.businesscenter.business.synccloud;

import android.support.v4.util.ArrayMap;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.tools.LogUtil;

import java.util.List;

public abstract class IUploadDataCallback<T> {

    private static final String TAG = "IUploadDataCallback";

    /**
     * 是否允许上送
     *
     * @return true-允许，false-不允许
     */
    abstract boolean allowUpload();

    /**
     * 计算未上送数据条数
     *
     * @return 数量
     */
    abstract int calcUnfinishedDataCount();

    /**
     * 构建需上送的数据
     */
    abstract T buildData();

    /**
     * 构建请求
     *
     * @param data 需上送的数据，要放到请求参数里的
     * @return 请求列表
     */
    abstract List<? extends BaseRequest> buildRequest(T data);

    /**
     * 上送成功
     */
    void uploadSuccess(ResponseData responseData) {
        LogUtil.logBusiness(TAG, " 本次上送数据成功");
    }

    /**
     * 上送失败
     */
    void uploadFail(ResponseData responseData) {
        LogUtil.logBusiness(TAG, "本次上送数据失败--" + JSON.toJSONString(responseData));
    }

    /**
     * 更新数据上送状态
     *
     * @param data 上送的数据
     * @return 更新的数据条数
     */
    abstract int updateDataSyncStatus(T data);

    /**
     * 处理进度
     *
     * @param progress 进度，0-100
     */
    void processProgress(int progress) {

    }
}
