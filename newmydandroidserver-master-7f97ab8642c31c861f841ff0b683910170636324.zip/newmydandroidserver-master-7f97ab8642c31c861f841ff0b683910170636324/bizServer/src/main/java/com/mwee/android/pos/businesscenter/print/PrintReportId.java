package com.mwee.android.pos.businesscenter.print;

/**
 * Created by Zun on 16/7/7.
 * <p/>
 * 小票单据编码  -- 打印小票对应的ID
 */
public class PrintReportId {

    public static final String OPERATING_INCOME_TABLE = "R01";          // 营业收入表
    public static final String RECEIVING_REPORT = "R02";                // 收款表
    public static final String SALES_VOLUME_TABLE = "R03";              // 销售数量表
    public static final String STATISTICS_OF_ARCHIVES_MOUTHS = "R04";   // 档口统计表
    public static final String HINGHEST_SALES_TABLE = "R06";            // 最高销售额表
    public static final String HINGHEST_SALES_SCALE = "R07";            // 最高销售量表
    public static final String SALES_TABLE_PER_HOUR = "R08";            // 每小时销售表
    public static final String SCHEDULE_OF_FOOD_BACK = "R10";           // 退菜明细表
    public static final String GIVE_FOOD_LIST = "R11";                  // 赠菜明细表
    public static final String BILL_CATEGORIES_TABLE = "R15";           // 账单类别统计表
    public static final String DISCOUNT_REPORT = "R16";           // 折扣报表
    public static final String SALES_TARGET = "R17";                        //销售统计报表


    public static final String ALL_DISCOUNT_REPORT = "DiscountSummary";           // 折扣汇总表
    public static final String STATEMENT = "S01";                       // 结账单
    public static final String BILL_REMAIN = "S26";                       // 结账单留存单
    public static final String LOG_TABLE = "S02";                       // 交班表
    public static final String DAILY_TABLE = "S03";                     // 日结表
    public static final String PRELIMINARY_STATEMENT = "S04";           // 预结单
    public static final String MAKE_THE_TOTAL_LIST = "S05";             // 制作单总单
    public static final String MAKE_THE_TOTAL_LIST_SINGLE = "S06";      // 制作单一菜一切
    public static final String RETURN_THE_MENU = "S07";                 // 退菜单
    public static final String THE_MENU = "S08";                        // 传菜单

    public static final String TABLE_OPEN_RECEIPT = "S10";              // 开台
    public static final String ORDERED_MENU = "S11";                    // 点菜单
    public static final String REMIND_THE_MENU = "S12";                 //催菜单
    public static final String TABLE_CHANGE_RECEIPT = "S13";            //换桌
    public static final String TRANSFER = "S18";                        //转菜
    public static final String WAITCALL = "S21";                        //起菜
    public static final String ORDERED_MENU_PRE = "S25";                // 点菜预览单



    /**
     * 自定义
     */
    public static final String NETWORK_TAKEOUT_RECEIPT = "N01";                        // 网络订单--外卖小票
    public static final String NETWORK_EAT_IN_RECEIPT = "N02";                        //网络订单--堂食小票
    public static final String NETWORK_KDS_RECEIPT = "N03";                        // 网络订单--厨房小票
    public static final String NETWORK_PASSTO_RECEIPT = "N04";                        // 网络订单--传菜小票
    public static final String NETWORK_CUSTOM_RECEIPT = "N05";                        // 网络订单--客户联

    public static final String TABLE_MERGE_RECEIPT = "N06";                        // 并桌
    public static final String CUSTOMER_FEEDBACK_RECEIPT = "N07";                        // 用户反馈
    public static final String RETURN_THE_MENU_BILL = "N08";            // 退账单(所有已退菜的明细)
    public static final String SALES_TIME_REPORT = "N09";            // 销售时段表
    public static final String RAPID_ORDERED_CONFIRM_MENU = "N29";  // 秒点确认单
    public static final String RECEIPT_PAY_VOID = "N30"; //退款明细单
    public static final String MEMBER_CHARGE = "N31"; //会员充值小票
    public static final String MEMBER_PRIVILEGE = "N32"; //会员特权小票
    public static final String RAPID_BOOK_ORDERED = "N33"; //秒点预定单小票
    public static final String AB_REPORT = "N35"; //AB账
    public static final String TIME_REPORT = "N36"; //时段统计表
    public static final String WECHAT_ORDER_ORDER = "N37"; //微信外卖--厨房小票
    public static final String WECHAT_ORDER_RECEIPT = "N38"; //微信外卖--外卖小票
    public static final String WECHAT_REPORT = "N39"; //微信外卖--报表
    public static final String NET_ORDER_REPORT = "N40"; //网络订单--报表
    public static final String WECHAT_FAST_FOOD = "N41"; //网络订单--报表
    //收款明细表
    public static final String CHECK_BY_DAY = "N42";
    // 沽清明细
    public static final String SELLOUT_DETAIL = "N43";
    // 预付金小票
    public static final String PRE_PAY = "N44";
    // 制作单一份一切
    public static final String MAKE_THE_SINGLE = "N45";
    //口碑预点单
    public static final String KOBEI_PRE_ORDER_CUSTOMER = "N46";
    //口碑预点单制作单
    public static final String KOBEI_PRE_ORDER_MAKE = "N47";
    //口碑预点单
    public static final String KOBEI_PRE_ORDER_SHOP = "N48";
    //加配料单
    public static final String INGREDIENT = "N49";
    //加套餐子项
    public static final String PACKAGE_ITEM = "N50";
    //美团外卖报表
    public static final String MEITUAN_NET_ORDER = "N51";


    //手动纯开票小票
    public static final String MANUAL_E_INVOICE = "N52";

    //套餐销量
    public static final String BUNDLE_NUM = "N53";

    //销售分类统计
    public static final String SALE_CLS_NUM = "N54";

    //收入分类统计
    public static final String INCOME_CLS_NUM = "N55";

    //溢收明细统计
    public static final String SURCHARGE_DETAIL = "N56";

    //会员储值汇总
    public static final String MEMBER_CHARGE_DATA = "N57";


}
