package com.mwee.myd.server.business.data;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.component.datasync.net.ModifyVersionRequest;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ClientType;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

/**
 * Created by virgil on 2016/12/7.
 *
 * @author virgil
 */

public class ModifyVersionProcessor {

    public static String modifyVersionProcessor(IExecutorCallback callback) {
        return modifyVersionProcessor(callback, true);
    }

    public static String modifyVersionProcessor(IExecutorCallback callback, boolean forceMainThread) {
        if (!BindProcessor.isCurrentHostMain()) {
            return "";
        }
        ModifyVersionRequest modifyVersionRequest = new ModifyVersionRequest();
        modifyVersionRequest.fssoftversion = BizConstant.VERSION_NAME;
       // modifyVersionRequest.fsdriver = DeviceUtil.getDeviceID(GlobalCache.getContext());
        modifyVersionRequest.fsdriver = ServerHardwareUtil.getHardWareSymbol();
        if (APPConfig.isMyd()) {
            modifyVersionRequest.ficlienttype = ClientType.MYD_ANDROID;
        } else if (APPConfig.isAir()) {
            modifyVersionRequest.ficlienttype = ClientType.AIR;
        } else if (APPConfig.isCasiher()) {
            modifyVersionRequest.ficlienttype = ClientType.CASIHER;
        } else if (APPConfig.isAirKouBei()) {
            modifyVersionRequest.ficlienttype = ClientType.AIR_KOUBEI;
        }
        return BusinessExecutor.execute(modifyVersionRequest, callback, forceMainThread);
    }
}
