package com.mwee.android.pos.businesscenter.netbiz.wechatfastfood;

import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;

/**
 * Created by liuxiuxiu on 2018/2/1.
 */

public class WechatFastFoodProcessor {
    /**
     * 通知云端微信快餐已备餐
     *
     * @param msgId 本地订单号
     */
    public static void notifiyServerMenuPrepared(String msgId) {

        MessageFastFoodBean fastFoodBean = MessageDBUtil.getMessageFastfoodByMsgId(msgId);
        if (fastFoodBean == null) {
            return;
        }
        if (fastFoodBean.businessStatus == MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.PREPARED) {
            return;
        }
        final String outerOrderId = fastFoodBean.msgHead;
        final String fsSellNo = fastFoodBean.sellNo;
        final String number = fastFoodBean.number();

        IResponse<String> iResponse = new IResponse<String>() {
            @Override
            public void callBack(final boolean result, int code, final String msg, String info) {
                if (result) {
                    RapidPrePayFastfoodBiz.releaseBusyMealNumber(number);  //释放牌号
                    MessageOrderUtil.updateFastFoodMsg(outerOrderId, fsSellNo, number, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.PREPARED);
                }
            }
        };

        WechatFastFoodApi.updateWechatFastFoodStatus(outerOrderId, "30", fsSellNo, number, 1, iResponse);
    }
}
