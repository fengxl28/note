package com.mwee.android.pos.businesscenter.business.netOrder;


import android.text.TextUtils;

import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.datasync.net.model.PhoneDowngradeModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

public class PhoneDowngradeDBUtil {

    /**
     * 新增美团外卖隐私号降级消息
     */
    public static void addMessageMeituanDowngrade(String orderId, String realPhoneNumber){
        if (TextUtils.isEmpty(orderId)) return;

        PhoneDowngradeModel model = new PhoneDowngradeModel();
        model.orderId = orderId;
        model.phone = realPhoneNumber;
        model.status = 0;
        model.createTime = DateUtil.getCurrentTime();
        model.updateTime = DateUtil.getCurrentTime();
        model.updateUserId = TakeAwaySource.MEITUAN;
        model.replaceNoTrans();
    }

    public static int getMessageMeituanDowngradeUnDealCount() {
        String sql = "select count(*) from " + DBModel.getTableName(PhoneDowngradeModel.class) +
                " where updateUserId = '" + TakeAwaySource.MEITUAN +
                "' and status = '0'" +
                " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql);
        return StringUtil.toInt(countStr, 0);
    }

    public static void updateMessageMeituanDowngradeDealStatus(){
        String sql = "update " + DBModel.getTableName(PhoneDowngradeModel.class) +
                " set status = '1'" +
                ", updateTime = '" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "'" +
                " where updateUserId = '" + TakeAwaySource.MEITUAN + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, sql);
    }
}
