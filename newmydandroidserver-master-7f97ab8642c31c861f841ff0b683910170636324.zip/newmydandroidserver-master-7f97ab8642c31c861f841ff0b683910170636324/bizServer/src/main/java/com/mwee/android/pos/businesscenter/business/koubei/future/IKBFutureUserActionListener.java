package com.mwee.android.pos.businesscenter.business.koubei.future;

import com.mwee.android.base.task.callback.BusinessCallback;

/**
 * Created by zhangmin on 2018/10/13.
 */

public interface IKBFutureUserActionListener {

    /**
     * 获取订单详情
     * @param pageIndex
     * @param orderId
     * @param businessCallback
     */
    void loadFutureTempOrderHeader(int pageIndex, String orderId,String status,BusinessCallback businessCallback);


    /**
     * 接单
     *
     * @param businessCallback
     */
    void acceptFutureOrder(String orderId, String batchNo, String outBizNo,BusinessCallback businessCallback);


    /**
     * 拒单
     * @param orderId
     * @param batchNo
     * @param rejectReason
     * @param businessCallback
     */
    void rejectFutureOrder( String orderId, String batchNo, String rejectReason, BusinessCallback businessCallback);

}
