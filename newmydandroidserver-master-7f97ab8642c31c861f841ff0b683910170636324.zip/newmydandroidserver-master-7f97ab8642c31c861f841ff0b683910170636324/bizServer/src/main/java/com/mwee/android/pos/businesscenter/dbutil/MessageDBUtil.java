package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MessageDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.db.business.message.MessageOrderBean;
import com.mwee.android.pos.db.business.message.MessagePayBean;
import com.mwee.android.pos.db.business.message.MessageSystemBean;
import com.mwee.android.pos.db.business.message.PayConfirmBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 17/2/13.
 */

public class MessageDBUtil {

    /**
     * 查询点餐相关的消息
     *
     * @param businessDate
     * @return
     */
    public static List<MessageOrderBean> getMessageOrders(String businessDate) {
        String time = DBMetaUtil.getSettingsValueByKey(META.MESSAGE_RECEVIE);
        String areaIds = DBMetaUtil.getSettingsValueByKey(META.MESSAGE_AREA);
        return getMessageOrders(businessDate, time, areaIds);
    }

    /**
     * 查询点菜相关的消息
     *
     * @param businessDate 营业日期
     * @param time         时间节点
     * @param areaIds      不接受区域
     * @return
     */
    public static List<MessageOrderBean> getMessageOrders(String businessDate, String time, String areaIds) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and message.createTime < '" + time + "' ";
        }
        if (!TextUtils.isEmpty(areaIds)) {
            areaIds = checkSQLParam(areaIds);
            params += " and message.mareaId not in (" + areaIds + ") ";
        }

        String sql = "select * from message left join (select standBy1 bookOrderContent, msgId id from message where msgCategory = '1' and msgHead <> '' and msgType = '3') bookMsg " +
                "on message.correlationId = bookMsg.id " +
                "where message.msgCategory = '1' and message.businessDate = '" + businessDate + "' " + params + " order by createTime desc ";
        List<MessageOrderBean> messageOrderBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageOrderBean.class);
        if (messageOrderBeanList == null || messageOrderBeanList.isEmpty()) {
            messageOrderBeanList = new ArrayList<>();
        }
        return messageOrderBeanList;
    }

    /**
     * 查询支付相关的消息
     *
     * @param businessDate 营业日期
     * @param time         时间节点
     * @param areaIds      不接受区域
     * @return
     */
    public static List<MessagePayBean> getMessagePay(String businessDate, String time, String areaIds) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and createTime < '" + time + "' ";
        }
        if (!TextUtils.isEmpty(areaIds)) {
            areaIds = checkSQLParam(areaIds);
            params += " and mareaId not in (" + areaIds + ") ";
        }

        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '2' and businessDate = '" + businessDate + "' " + params + " order by createTime desc ";
        List<MessagePayBean> MessagePayBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessagePayBean.class);
        if (MessagePayBeanList == null || MessagePayBeanList.isEmpty()) {
            MessagePayBeanList = new ArrayList<>();
        }
        return MessagePayBeanList;
    }

    public static List<MessageSystemBean> getMessageSystem(String businessDate, String time, String areaIds) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and createTime < '" + time + "' ";
        }
        if (!TextUtils.isEmpty(areaIds)) {
            areaIds = checkSQLParam(areaIds);
            params += " and mareaId not in (" + areaIds + ") ";
        }

        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '" + MessageConstance.CATEGORY_SYSTEM + "' and businessDate = '" + businessDate + "' " + params + " order by createTime desc ";
        List<MessageSystemBean> messageSystemBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageSystemBean.class);
        if (messageSystemBeanList == null || messageSystemBeanList.isEmpty()) {
            messageSystemBeanList = new ArrayList<>();
        }
        return messageSystemBeanList;
    }

    /**
     * 美小二获取所有秒点数据
     *
     * @param businessDate 营业日期
     * @return
     */
    public static List<JSONObject> getRapidMessageOrdersForSmart(String businessDate) {
        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '1' and msgType = '1' and businessDate = '" + businessDate + "' order by createTime desc ";
        List<MessageOrderBean> messageOrderBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageOrderBean.class);
        if (messageOrderBeanList == null || messageOrderBeanList.isEmpty()) {
            messageOrderBeanList = new ArrayList<>();
        }
        List<JSONObject> obtList = new ArrayList<>();
        for (MessageOrderBean messageOrder : messageOrderBeanList) {
            JSONObject object = new JSONObject();
            object.put("msgId", messageOrder.msgId);
            object.put("tableName", messageOrder.tableName);
            object.put("createTime", DateUtil.formartDateStrToTarget(messageOrder.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm"));
            object.put("businessStatus", messageOrder.businessStatus);
            obtList.add(object);
        }

        return obtList;
    }

    /**
     * 美小二获取所有秒付数据
     *
     * @param businessDate 营业日期
     * @return
     */
    public static List<JSONObject> getRapidMessagePayForSmart(String businessDate) {
        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '2' and msgType = '1' and businessDate = '" + businessDate + "' order by createTime desc ";
        List<MessagePayBean> messagePayBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessagePayBean.class);
        if (messagePayBeanList == null || messagePayBeanList.isEmpty()) {
            messagePayBeanList = new ArrayList<>();
        }
        List<JSONObject> obtList = new ArrayList<>();
        for (MessagePayBean messagePay : messagePayBeanList) {
            JSONObject object = new JSONObject();
            object.put("msgId", messagePay.msgId);
            object.put("tableName", messagePay.tableName());
            object.put("createTime", DateUtil.formartDateStrToTarget(messagePay.createTime, "yyyy-MM-dd HH:mm:ss", "HH:mm"));
            object.put("businessStatus", messagePay.businessStatus);
            object.put("payAmt", messagePay.payAmt());
            object.put("allAmt", messagePay.allAmt());

            obtList.add(object);
        }

        return obtList;
    }

    /**
     * 查询未处理的点菜消息数量
     *
     * @param businessDate 营业日期
     * @param time         时间节点
     * @param areaIds      不接受区域
     * @return
     */
    public static int getMessageOrdersUnDealCount(String businessDate, String time, String areaIds) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and createTime < '" + time + "' ";
        }
        if (!TextUtils.isEmpty(areaIds)) {
            areaIds = checkSQLParam(areaIds);
            params += " and mareaId not in (" + areaIds + ") ";
        }

        if (!TextUtils.isEmpty(businessDate)) {
            params += " and businessDate = '" + businessDate + "' ";
        }

        String sql = "select count(*) from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '1' and businessStatus = '0' " + params + " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 查询未处理的点菜消息数量
     *
     * @param businessDate 营业日期
     * @param time         时间节点
     * @param areaIds      不接受区域
     * @return
     */
    public static int getMessagePayUnDealCount(String businessDate, String time, String areaIds) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and createTime < '" + time + "' ";
        }


        if (!TextUtils.isEmpty(areaIds)) {
            areaIds = checkSQLParam(areaIds);
            params += " and mareaId not in (" + areaIds + ") ";
        }

        if (!TextUtils.isEmpty(businessDate)) {
            params += " and businessDate = '" + businessDate + "' ";
        }

        String sql = "select count(*) from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '2' and businessStatus = '0' " + params + " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 检查sql是否正确
     *
     * @param areaIds
     * @return
     */
    private static String checkSQLParam(String areaIds) {
        if (TextUtils.isEmpty(areaIds)) {
            return "";
        }
        StringBuffer buffer = new StringBuffer("");
        String[] idArr = areaIds.split(",");
        if (idArr.length > 0) {
            for (String id : idArr) {
                if (!TextUtils.isEmpty(id) && !id.contains("'")) {
                    buffer.append("'").append(id).append("'").append(",");
                } else {
                    buffer.append(id).append(",");
                }
            }
            areaIds = buffer.toString();
            if (!TextUtils.isEmpty(areaIds)) {
                areaIds = areaIds.substring(0, areaIds.length() - 1);
            }
            return areaIds;
        } else {
            return areaIds;
        }
    }

    /**
     * 更新消息
     *
     * @param msgId
     * @param businessStatus
     * @return
     */
    public static synchronized String updateMessageOrder(int msgId, int businessStatus, UserDBModel updateUser) {
        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgId = '" + msgId + "'";
        MessageDBModel messageDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageDBModel.class);

        if (messageDBModel == null) {
            return "没找到消息记录msgId = " + msgId;
        }

        if (messageDBModel.businessStatus != MessageConstance.MessageOrderBuinessStatus.RAPID.NONE) {
            return "该消息已被处理了";
        }

        String userName = "";
        if (updateUser != null) {
            userName = updateUser.fsUserName;
        }

        String updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set businessStatus = " + businessStatus + ", updateTime = '" + updateTime + "', updateUser = '" + userName + "' where msgId = '" + msgId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
        return "";
    }

    /**
     * 更新秒点纯收银消息
     *
     * @param msgId          消息ID
     * @param businessStatus 业务状态
     * @param updateUser     服务员
     * @param fsSellNo       订单ID--被绑定的订单
     * @param tableId        桌台ID
     * @param standBy1       桌台名称，支付金额
     * @return
     */
    public static synchronized String updateRapidOnlyPayMessage(int msgId, int businessStatus, UserDBModel updateUser, String fsSellNo, String tableId, String standBy1) {
        String userName = "";
        if (updateUser != null) {
            userName = updateUser.fsUserName;
        }

        String updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set " +
                "businessStatus = " + businessStatus + ", updateTime = '" + updateTime + "', updateUser = '" + userName + "', " +
                "sellNo = '" + fsSellNo + "', standBy1 = '" + standBy1 + "', standBy2 = '" + tableId + "' where msgId = '" + msgId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
        return "";
    }

    /**
     * 更新秒点纯收银消息
     *
     * @param msgDes         订单号
     * @param businessStatus 业务状态
     * @param updateUser     服务员
     * @param fsSellNo       订单ID--被绑定的订单
     * @param tableId        桌台ID
     * @param standBy1       桌台名称，支付金额
     * @return
     */
    public static synchronized String updateRapidOnlyPayMessageByMsgDes(String msgDes, int businessStatus, UserDBModel updateUser, String fsSellNo, String tableId, String standBy1) {
        String userName = "";
        if (updateUser != null) {
            userName = updateUser.fsUserName;
        }

        String updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set " +
                "businessStatus = " + businessStatus + ", updateTime = '" + updateTime + "', updateUser = '" + userName + "', " +
                "sellNo = '" + fsSellNo + "', standBy1 = '" + standBy1 + "', standBy2 = '" + tableId + "' where msgDes = '" + msgDes + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
        return "";
    }

    /**
     * 更新秒点拉单确认消息
     *
     * @param msgId          消息ID
     * @param businessStatus 业务状态
     * @param updateUser     服务员
     * @return
     */
    public static synchronized String updateRapidPayConfirmMessage(int msgId, int businessStatus, UserDBModel updateUser) {
        String userName = "";
        if (updateUser != null) {
            userName = updateUser.fsUserName;
        }

        String updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set " +
                "businessStatus = " + businessStatus + ", updateTime = '" + updateTime + "', updateUser = '" + userName + "' where msgId = '" + msgId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
        return "";
    }

    /**
     * 获取所有未处理秒付拉单确认消息
     *
     * @return
     */
    public static List<PayConfirmBean> getUnDealPayConfirmMessage() {
        String sql = "select * from message where msgType = '5' and msgCategory = '2' and businessStatus = '0' order by createTime desc";
        List<PayConfirmBean> payConfirmBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PayConfirmBean.class);
        if (ListUtil.isEmpty(payConfirmBeanList)) {
            return new ArrayList<>();
        }
        return payConfirmBeanList;
    }

    /**
     * 更新消息
     *
     * @param tableID        桌台ID
     * @param businessStatus
     * @return
     */
    public static synchronized String updateMessageOrderByTableId(String tableID, int businessStatus, UserDBModel updateUser) {
        String sql = "select msgId from " + DBModel.getTableName(MessageDBModel.class) + " where mtableid = '" + tableID
                + "' and businessStatus = '" + MessageConstance.MessageOrderBuinessStatus.RAPID.NONE + "' ";
        String msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);

        if (TextUtils.isEmpty(msgId)) {
            return "没找到消息记录tableID = " + tableID;
        }

        String userName = "";
        if (updateUser != null) {
            userName = updateUser.fsUserName;
        }

        String updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set businessStatus = " + businessStatus + ", updateTime = '" + updateTime + "', updateUser = '" + userName + "' where msgId = '" + msgId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
        return "";
    }

    /**
     * 更新支付消息状态
     *
     * @param billNo
     */
    public static void updatePayMessageStatus(String billNo) {
        if (TextUtils.isEmpty(billNo)) {
            return;
        }
        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " set businessStatus = '" + MessageConstance.MessagePayBuinessStatus.SMART.PAYED + "' where msgHead = '" + billNo + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
    }

    /**
     * 更新秒付拉单确认消息状态
     * 结账自动更新秒付拉单确认消息为已忽略
     *
     * @param fsSellNo 订单号
     */
    public static void updatePayConfirmMessageStatus(String fsSellNo) {
        if (TextUtils.isEmpty(fsSellNo)) {
            return;
        }
        String updateSql = "update " + DBModel.getTableName(MessageDBModel.class) + " " +
                "set businessStatus = '" + MessageConstance.MessagePayBuinessStatus.RAPID_PAY_CONFIRM.IGNORE + "'," +
                " updateTime = '" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "'," +
                " updateUser = '结账自动忽略' " +
                "where sellNo = '" + fsSellNo + "' and msgType = '" + MessageConstance.TYPE_PAY_CONFIRM + "' and businessStatus = '" + MessageConstance.MessagePayBuinessStatus.RAPID_PAY_CONFIRM.NONE + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
    }

    /**
     * 删除fsmtableid 桌台上未处理的点菜消息
     *
     * @param fsmtableid
     * @return
     */
    public static void deleteUnDealOrderMessage(String fsmtableid) {
        String sql = "delete from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '1' and businessStatus = '0' and mtableid = '" + fsmtableid + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 查询手机号为phone的预定单ID
     *
     * @param phone 手机号码
     * @return
     */
    public static String optBookMsgIdByPhone(String phone) {
        if (TextUtils.isEmpty(phone)) {
            return "";
        }
        String sql = "select msgId from " + DBModel.getTableName(MessageDBModel.class) + " where msgHead = '" + phone + "' and msgType = '3' order by createTime desc limit 1";
        String msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(msgId)) {
            return "";
        }

        return msgId;
    }

    /**
     * 查看秒付请求是否被允许过
     *
     * @param orderId 订单ID
     * @return boolean | true : 已被允许过  false: 未被允许过
     */
    public static boolean checkRapidPayConfirmStatus(String orderId) {
        String sql = "select msgId from message where msgType = '" + MessageConstance.TYPE_PAY_CONFIRM + "' and msgCategory = '" + MessageConstance.CATEGORY_PAY + "' and sellNo = '" + orderId + "' and businessStatus = '" + MessageConstance.MessagePayBuinessStatus.RAPID_PAY_CONFIRM.ALLOW + "'";
        String msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return !TextUtils.isEmpty(msgId);
    }

    public static int getMessageSystemUnDealCount(String businessDate, String time) {
        String params = "";
        if (!TextUtils.isEmpty(time)) {
            params = " and createTime < '" + time + "' ";
        }

        if (!TextUtils.isEmpty(businessDate)) {
            params += " and businessDate = '" + businessDate + "' ";
        }

        String sql = "select count(*) from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '" + MessageConstance.CATEGORY_SYSTEM + "' and dealStatus = " + MessageConstance.MessageSystemStatus.NONE + params + " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 微信快餐未处理数量
     *
     * @return
     */
    public static int getMessageFastfoodUnDealCount(String businessDate) {
        String params = "";
        if (!TextUtils.isEmpty(businessDate)) {
            params += " and businessDate = '" + businessDate + "' ";
        }
        String sql = "select count(*) from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '" + getMsgCategory() + "' and businessStatus = " + MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.NONE + params + " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 含有为映射菜品的订单数
     *
     * @return
     */
    public static int getUnMappingOrderCount(String businessDate) {
        String params = "";
        if (!TextUtils.isEmpty(businessDate)) {
            params += " and businessDate = '" + businessDate + "' ";
        }
        String sql = "select count(*) from datacache where type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "' and value > '0' ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 微信快餐未处理数量
     *
     * @return
     */
    public static List<MessageFastFoodBean> getMessageFastfoodList(String businessDate) {

        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '" + getMsgCategory() + "' and businessDate = '" + businessDate + "' " + " order by createTime desc ";
        List<MessageFastFoodBean> messageSystemBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageFastFoodBean.class);
        if (messageSystemBeanList == null || messageSystemBeanList.isEmpty()) {
            messageSystemBeanList = new ArrayList<>();
        }
        return messageSystemBeanList;
    }

    /**
     * 微信快餐
     *
     * @return
     */
    public static MessageFastFoodBean getMessageFastfood(String outerOrderId) {

        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where msgHead = '" + outerOrderId + "' ";
        MessageFastFoodBean messageFastFoodBean = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageFastFoodBean.class);
        return messageFastFoodBean;
    }

    /**
     * 微信快餐
     *
     * @return
     */
    public static MessageFastFoodBean getMessageFastfoodBySellNo(String fssellNo) {
        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class) + " where sellNo = '" + fssellNo + "' ";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageFastFoodBean.class);
    }

    /**
     * 获取消息
     *
     * @param msgId
     * @return
     */
    public static MessageFastFoodBean getMessageFastfoodByMsgId(String msgId) {
        if (!TextUtils.isEmpty(msgId)) {
            return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from message where msgId = '" + msgId + "' and msgCategory = '" + getMsgCategory() + "' and msgType = '" + getMsgType() + "' ", MessageFastFoodBean.class);
        }
        return null;
    }

    /**
     * 获取消息ID
     *
     * @param fssellno
     * @return
     */
    public static String optMsgId(String fssellno) {
        if (!TextUtils.isEmpty(fssellno)) {

            String sql = "select msgId from message where msgCategory = '" + getMsgCategory() + "' and msgType = '" + getMsgType() + "'" +
                    " and  msgHead = ( select key from datacache where value = '" + fssellno + "') ";
            return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        }
        return "";
    }


    /**
     * 查询订单是否存在
     *
     * @param orderId
     * @param userId
     * @param payAmtStr
     * @return
     */
    public static MessageFastFoodBean checkFastExist(String orderId, String userId, String payAmtStr) {
        String sql = "select * from " + DBModel.getTableName(MessageDBModel.class)
                + " where msgHead = '" + orderId
                + "' and standBy2 = '" + payAmtStr + "_" + userId
                + "' and  msgType = '" + getMsgType()
                + "' and msgCategory = '" + getMsgCategory() + "' ";

        MessageFastFoodBean messageFastFoodBean = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageFastFoodBean.class);
        return messageFastFoodBean;
    }

    /**
     * 美小店取消订单修改本地订单
     *
     * @param orderId 订单id
     * @return
     */
    public static void messageCancelOrder(String orderId, int status) {
        MessageFastFoodBean fastFoodBean = getMessageFastfood(orderId);
        if (fastFoodBean == null) {
            LogUtil.logBusiness("美小店取消订单失败：" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "; 订单异常，没有找到该订单   orderId=" + orderId);
            return;
        }
        UserDBModel userDBModel = HostUtil.getHostUser();
        ServerCache.getInstance().wechatFastfoodCache.doLock(orderId, userDBModel.fsUserName + " 操作更新订单状态 diningStatus=" + status + "， 站点：" + HostUtil.getCurrentHost());
        final String fsOrderNo = fastFoodBean.sellNo;
        final String number = fastFoodBean.number();
        MessageOrderUtil.updateFastFoodMsg(orderId, fsOrderNo, number, status);
        ServerCache.getInstance().wechatFastfoodCache.unLock(orderId, userDBModel.fsUserName + " 操作更新订单状态结束 diningStatus=" + status + "， 站点：" + HostUtil.getCurrentHost() + ";[" + fsOrderNo + "," + number + "]");
    }

    /**
     * 获取 msgType
     *
     * @return
     */
    public static int getMsgType() {
        int msgType;
        if (APPConfig.isAir(GlobalCache.getContext())) {
            msgType = MessageConstance.TYPE_MEI_XIAO_DIAN;
        } else {
            msgType = MessageConstance.TYPE_FAST_FOOD;
        }
        return msgType;
    }

    /**
     * 获取 msgCategory
     *
     * @return
     */
    public static int getMsgCategory() {
        int msgCategory;
        if (APPConfig.isAir(GlobalCache.getContext())) {
            msgCategory = MessageConstance.CATEGORY_MEI_XIAO_DIAN;
        } else {
            msgCategory = MessageConstance.CATEGORY_FAST_FOOD;
        }
        return msgCategory;
    }

}
