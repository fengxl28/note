package com.mwee.myd.server;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.common.DBTools;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.business.data.ChannelRule;
import com.mwee.myd.server.business.data.ModifyVersionProcessor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * Created by virgil on 2018/3/1.
 *
 * @author virgil
 */

public class LocalDataManager {


    /**
     * 需要物理删除大于7天的fistatus = '13'的数据的表
     */
    public final static String[] needDeleteTables = new String[]{
            "tbMenuItemVipPrice",
            "tbMenuIngredgpRel",
//            "tbParamValue",
            "tbDept",
            "tbRole",
            "tbAuthority",
            "tbAuthorityDtl",
            "tbUser",
            "tbUserRole",
            "tbUserDiscount",
            "tbUserAuthData",
            "tbMSection",
            "tbShift",
            "tbMArea",
            "tbMTableCls",
            "tbMTableSte",
            "tbMTable",
            //创建 外卖分类的菜品销售分类ID，菜品收入分类ID，菜品分类ID 的数据 状态：13
//            "tbExpCls",
//            "tbRevenueType",
//            "tbMenuCls",
            "tbMenuItem",
            "tbMenuItemUint",
            "tbMenuItemAskGp",
            "tbAskGp",
            "tbAsk",
            "tbMenuItemSetSide",
            "tbMenuItemSetSideDtl",
            "tbBuygiftItem",
            "tbCutMoney",
            "tbPaymentType",
            "tbPayment",
            "tbWordhouse",
            "tbReport",
            "tbReportTemplet",
            "tbDiscount",
            "tbDiscountItem",
            "tbPrinter",
            "tbTransferPrn",
            "tbHost",
            "tbShop",
            "tbBargain",
            "tbBargainItem",
            "tbVIPDiscount",
            "tbCreditAccount",
            "tbDeliverer",
            "tbMenuItemMulDept",
            "tbHostExternal",
            "tbopenparam",
            "tbuserMenuItemRole",
            // tbpaymentfullcut中没有fiStatus，这里先拿掉
//            "tbpaymentfullcut",
            "tbbillsource",
            "tbshopservice",
            "tbaskgpmenucls",
            "tbcardrelation",
            "tbprinttempletprivate"};

    /**
     * 上送门店的各种环境信息
     */
    public static void uploadShopEnv() {
        if (!BindProcessor.isActived()) {
            return;
        }
        //上报各种信息
        GlobalLooper.postDelayed(() -> {
            ModifyVersionProcessor.modifyVersionProcessor(null);
            ChannelRule.uploadShopProductInfo();
        }, 5000);
    }

    public static void cleanExpiredData(String currentBusinessDate) {
        BusinessExecutor.executeNoWait(() -> {
            cleanLocalExpiredOrder(currentBusinessDate);
            return null;
        });
    }

    /**
     * 删除本地已同步到服务端且大于当前营业日期7天以上的订单
     *
     * @param currentBusinessDate String
     */
    private static void cleanLocalExpiredOrder(final String currentBusinessDate) {
        if (TextUtils.isEmpty(currentBusinessDate)) {
            return;
        }

        final String time = DateUtil.getCurrentTime();
        RunTimeLog.addLog(RunTimeLog.ORDER_DELETE, "删除本地已同步到服务端且大于当前营业日期7天以上的订单");
        IDBOperate op = new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                String destBusinessData = currentBusinessDate.contains("-") ? currentBusinessDate : DateUtil.formartDateStrToTarget(currentBusinessDate, "yyyyMMdd", "yyyy-MM-dd");
                // 备份库的升级需要对接动态升级数据库。这里先注释掉，并将报表数据删除改回 7 天，待数据库配置升级部分完成，开放备份库，将报表删除日期改为 30 天
//                SlaveDBUtils.slaveDelete(GlobalCache.getContext(), destBusinessData);

                String deleteSql = "delete from %s where lver=pver and lver!=0 and fssellno in (" +
                        "select distinct id from (select %s.fssellno id, tbsell .fsselldate date from %s left join tbsell on %s.fssellno = tbsell.fssellno where date is NULL or (julianday('" + destBusinessData + "')-julianday(date))>7)" +
                        ")";

                // 保护措施。当订单数据未能迁移至slave库时，也要能够从主库删除
                String sql = "lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7";
                db.delete("tbSell", sql, null);
                db.delete("tbSellOrder", sql, null);
                db.delete("tbSellOrderItem", sql, null);
                db.delete("tbSellCheck", sql, null);
                db.delete("tbSellReceive", sql, null);
                db.delete("tbSellPickMenuitem", sql, null);
                db.delete("tbSellOrderItemNote", sql, null);
                db.delete("tbSellOrderItemBonus", sql, null);
                db.delete("tbSellPickMenuitem", sql, null);

                db.delete("billItemCouponDetail", "lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(sellDate))>7", null);
                db.delete("billSurchargeDetail" , "lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(sellDate))>7", null);
/*
                DBTools.exeSqlWithoutException(db,"delete from tbSell where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellOrder where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellOrderItem where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellCheck where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellReceive where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellPickMenuitem where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellOrderItemNote where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellOrderItemBonus where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                DBTools.exeSqlWithoutException(db,"delete from tbSellPickMenuitem where lver=pver and lver!=0 and (julianday('" + destBusinessData + "')-julianday(fsSellDate))>7");
                */

                DBTools.exeSqlWithoutException(db, String.format(deleteSql, "tbchangetable", "tbchangetable", "tbchangetable", "tbchangetable"));
                DBTools.exeSqlWithoutException(db, String.format(deleteSql, "tbitemchangetable", "tbitemchangetable", "tbitemchangetable", "tbitemchangetable"));

                //清除消息历史的表
                db.delete("push_msg_stack", " (julianday('" + time + "')-julianday(updateTime))>4", null);

                db.delete("order_pay_cache", "payed=1 and locked=1 and ((julianday('" + currentBusinessDate + "')-julianday(business_date))>" + 7 + ")", null);
                db.delete("order_cache", " ((julianday('" + currentBusinessDate + "')-julianday(business_date))>" + 7 + ")", null);
                db.delete("fastfood_order_biz", " ((julianday('" + currentBusinessDate + "')-julianday(business_date))>" + 7 + ")", null);
                db.delete("order_menu_cache", " order_id not in (select order_id from order_cache)", null);

                //删除Job中，type不是5或者6的，已完成且完成时间大于2两天的，或者未完成的但创建时间大于5天的
                db.delete("unfinish_task", "type not in('5','6') and  (finished='1' and (julianday('" + time + "')-julianday(update_time))>2) or " + "( finished='0' and (julianday('" + time + "')-julianday(create_time))>5)", null);

                // 2018/5/14 修改固化报表保存两个月
                db.delete("dailyReport", "  (julianday('" + time + "')-julianday(businessdate))> "+ ReportConsrance.SAVE_DAYS, null);
                // 美易点3.4.2重新建了报表，防止数据丢失，老表没有删除，故这里删一下老报表数据
                db.delete("dailyReportTemp", "  (julianday('" + time + "')-julianday(businessdate))>60", null);


                db.execSQL("DELETE FROM datacache where type in ('8','3','4') ");
                db.execSQL("DELETE FROM datacache where type = '10' and (julianday('" + time + "')-julianday(value))>3");

                //删除消息中心非当前营业日期的消息（不删除异常订单消息）
                db.execSQL("delete from message where businessDate <> '" + currentBusinessDate + "' and msgCategory <> '6' ");
                //删除消息中心七天前的异常订单消息
                db.execSQL("delete from message where msgCategory = '6' and (julianday('" + currentBusinessDate + "')-julianday(businessDate))> 7 ");

                //删除大于七天的口碑预点单数据
                db.delete("kbOrder", " (julianday('" + time + "')-julianday(table_time))>7", null);

                //删除大于七天的手动纯开票数据
                db.delete("manualInvoicing", " (julianday('" + currentBusinessDate + "')-julianday(date))>7", null);
                
                String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                //删除超过10分钟缓存的推送消息
                db.execSQL("delete from push_msg_stack where msgBizValue = '1000' and ((strftime('%s','" + currentTime + "') - strftime('%s',updateTime))>600) ");

                // AB账上传日志保存30天
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(DateUtil.formatDate(currentBusinessDate));
                calendar.add(Calendar.DATE, -30);
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                String date = format.format(calendar.getTime());
                db.execSQL("DELETE FROM datacache where key LIKE 'UPLOAD_STATUS%' AND key < 'UPLOAD_STATUS" + date + "'");
                db.execSQL("DELETE from datacache where type='7'");

                //删除超过三十天的'已删除'数据，由于美小易需要使用已删除数据，所以此操作仅针对美易点
                if (APPConfig.isMyd()) {
                    for (String tableName : needDeleteTables) {
                        try {
                            db.execSQL("DELETE FROM " + tableName + " where fistatus = '13' and (julianday('" + currentBusinessDate + " 00:00:00" + "')-julianday(fsupdateTime))> 30 ");
                        } catch (Exception e) {
                            LogUtil.logError("删除数据异常", e);
                        }
                    }
                }
                return null;
            }
        };

        DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(op);

        //网络订单保存3天
        //当前营业日期中的外卖单不可以被删除
        List<String> tempApprderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select thirdorderid from order_cache where fiselltype = '2' and business_date = '" + currentBusinessDate + "'");
        String orderIdParams = "";
        if (!ListUtil.isEmpty(tempApprderIdList)) {
            orderIdParams = ListUtil.optSqlParams(tempApprderIdList);
        }

        String orderSQLParam = " and orderId not in (" + orderIdParams + " )";

        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from tempapporderdetails where orderId in (select orderId from tempapporder where (julianday('" + time + "')-julianday(date))>3  " + orderSQLParam + " ) ");
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from TempAppOrderPrintInfo where orderId in (select orderId from tempapporder where (julianday('" + time + "')-julianday(date))>3  " + orderSQLParam + " ) ");
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from tempapporder where (julianday('" + time + "')-julianday(date))>3 " + orderSQLParam);
        //外卖订单和本地订单的关联关系只留31天:为保证数据完整性既要判断营业日期又要判断自然日
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from tempAppOrderMappingLocalOrderRelation where (julianday('" + currentBusinessDate + "')-julianday(businessDate))>31 and (julianday('" + time + "')-julianday(orderTime))>31");

        //删除超过三天的配送信息
        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from deliveryRecord where (julianday('" + time + "')-julianday(orderTime))>3");

        DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from phoneDowngrade where (julianday('" + time + "')-julianday(createTime))> 3 ");
    }


}
