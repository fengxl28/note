package com.mwee.android.pos.businesscenter.koubei;

/**
 * 预点单相关接口服务
 * Created by qinwei on 2018/5/16.
 */

public class PreOrderApi {

    /**
     * 接单
     * @param orderMessage
     * @param preOrderCallback
     */
    public static void loadPreOrderTake(String orderMessage, PreOrderCallback preOrderCallback) {

    }
}
