package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.pos.businesscenter.air.dbUtil.component.AirRole;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * @ClassName: AccountManageDBUtils
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午8:32
 */
public class AccountManageDBUtils {

    public static List<AccountManageInfo> queryAllAccount() {
        String sql = "SELECT fsUserId,fsStaffId, fsUserName, fsPwd,fsCellphone FROM tbuser WHERE fiStatus = 1 AND fsUserId <> 'cash'";
        List<AccountManageInfo> result = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AccountManageInfo.class);
        if (result == null) {
            result = new ArrayList<>();
        }
        return result;
    }

    public static AccountManageInfo queryAccountDetailByID(String fsUserId) {
        String sqlExist = "SELECT * from tbuser WHERE fsUserId = '" + fsUserId + "'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model == null) {
            return null;
        }

        int config = 0;
        String sqlAuthor = "SELECT fsRoleId FROM tbuserrole WHERE fsUserId = '" + fsUserId + "' AND fiStatus = 1";
        List<String> roles = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sqlAuthor);
        if (!ListUtil.isEmpty(roles)) {
            for (String role : roles) {
                if (TextUtils.equals(role, AirRole.RoleAdmin)) {
                    // 管理员角色拥有所有权限
                    config |= 1;
                    config |= 2;
                    config |= 4;
                    config |= 8;
                    break;
                } else if (TextUtils.equals(role, AirRole.RoleCashBox)) {
                    config = config | 1;
                } else if (TextUtils.equals(role, AirRole.RoleBill)) {
                    config = config | 2;
                } else if (TextUtils.equals(role, AirRole.RoleRefund)) {
                    config = config | 4;
                } else if (TextUtils.equals(role, AirRole.RoleReport)) {
                    config = config | 8;
                }
            }
        }
        AccountManageInfo result = buildAccount(model, config);
        return result;
    }


    /**
     * 根据手机号(fsCellphone)查询员工表（tbuser）
     *
     * @param fsCellphone
     * @return
     */
    public static UserDBModel queryUserDBModelByPhone(String fsCellphone) {
        String sqlExist = "SELECT * from tbuser WHERE fsCellphone = '" + fsCellphone + "' and fiStatus<>'13'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model == null) {
            return null;
        }
        return model;
    }

    /**
     * 根据手机号(fsCellphone)和员工id(fsUserId)查询员工表（tbuser）
     *
     * @param fsCellphone
     * @return
     */
    public static UserDBModel queryUserDBModelByPhoneAndUid(String fsCellphone,String fsUserId) {
        String sqlExist = "SELECT * from tbuser WHERE fsCellphone = '" + fsCellphone + "' and fsUserId<>'"+fsUserId+"' and fiStatus<>'13'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model == null) {
            return null;
        }
        return model;
    }

    /**
     * 新增用户
     *
     * @param data
     * @param opt
     * @return
     */
    public static synchronized String add(AccountManageInfo data, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbuser WHERE fsUserId = '" + data.fsUserId + "'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model != null) {
            if (model.fiStatus == 1) {
                return "登录账号[" + model.fsUserId + "]已存在";
            }
            model.fiStatus = 1;
            translate(model, data);
            model.fsUpdateTime = DateUtil.getCurrentTime();
            model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
            model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
            model.sync = 1;
            model.fiDataSource = 1;
            model.replaceNoTrans();
            insertRole(data);
            MetaDBController.updateSyncTime();
            return "";
        }
        model = new UserDBModel();
        buildNewUser(model, opt);
        translate(model, data);
        model.replaceNoTrans();
        insertRole(data);
        MetaDBController.updateSyncTime();
        return "";
    }

    /**
     * 更新用户
     *
     * @param data
     * @param opt
     * @return
     */
    public static synchronized String update(AccountManageInfo data, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbuser WHERE fsUserId = '" + data.fsUserId + "'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model == null) {
            return "用户不存在";
        }
        if (model.fiStatus == 13) {
            return "用户已删除";
        }
        model.fsUserName = data.fsUserName;
        model.fsPwd = data.fsPwd;
        translate(model, data);
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.sync = 1;
        model.replaceNoTrans();
        insertRole(data);
        MetaDBController.updateSyncTime();
        return "";
    }

    /**
     * 删除用户
     *
     * @param fsUserId
     * @param opt
     * @return
     */
    public static synchronized String delete(String fsUserId, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbuser WHERE fsUserId = '" + fsUserId + "'";
        UserDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, UserDBModel.class);
        if (model == null) {
            return "";
        }
        if (model.fiStatus == 13) {
            return "";
        }

        String sqlLogin = "SELECT hostid FROM host_status WHERE current_user_id = '" + fsUserId + "'";
        String hostId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlLogin);
        if (!TextUtils.isEmpty(hostId)) {
            return "用户已在[" + hostId + "]登录，请退出后操作";
        }

        model.fiStatus = 13;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.sync = 1;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
        return "";
    }

    private static AccountManageInfo buildAccount(UserDBModel model, int config) {
        AccountManageInfo result = new AccountManageInfo();
        result.fsUserId = model.fsUserId;
        result.fsUserName = model.fsUserName;
        result.fsPwd = model.fsPwd;
        result.fsCellphone = model.fsCellphone;
        if (model.fiIsDiscount == 0) {
            config = config | 16;
        }
        result.config = config;
        return result;
    }

    public static String buildNewUser(UserDBModel model, UserDBModel opt) {
        if (model == null) {
            return "内部错误，请稍后重试";
        }

        String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        String sqlCompany = "SELECT fsCompanyGUID from tbshop where fsShopGUID = '" + shopID + "'";
        String fsCompanyGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlCompany);

        model.fsDeptId = "1";
        model.fsCompanyGUID = fsCompanyGUID;
        model.fsShopGUID = shopID;
        model.fsCreateTime = DateUtil.getCurrentTime();
        model.fsCreateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsCreateUserName = (opt == null ? "" : opt.fsUserName);
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.fiStatus = 1;
        model.fsiccardcode = "";
        model.fsPID = "";
        model.fsCellphone = "";
        model.fsNote = "";
        model.fiIsSales = 0;
        model.fiIsRetreatFood = 0;
        model.fiisgift = 0;
        model.fiIsDiscount = 0;
        model.sync = 1;
        model.fiDataSource = 1;
        return "";
    }

    private static void translate(UserDBModel model, AccountManageInfo data) {
        model.fsUserId = data.fsUserId;
        model.fsUserName = data.fsUserName;
        model.fsPwd = data.fsPwd;
        if (!TextUtils.isEmpty(data.fsCellphone)) {
            model.fsCellphone = data.fsCellphone;
        }
        // fsStaffId 目前在数据库中作为主键存在，需赋唯一值
        if (TextUtils.isEmpty(model.fsStaffId)) {
            model.fsStaffId = data.fsUserId;
        }
        if (data.supportDiscount()) {
            model.fiIsDiscount = 0;
        } else {
            model.fiIsDiscount = 1;
        }
    }

    private static void insertRole(final AccountManageInfo model) {
        DBManager.getInstance().executeInTransaction(new IDBOperate() {
            @Override
            public Object doJob(SQLiteDatabase db) {
                String updateTime = DateUtil.getCurrentTime();
                String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                String sqlDefault = "REPLACE INTO tbuserrole (fsUserId, fsRoleId, fsShopGUID, fiStatus, fsUpdateTime, sync) VALUES ('" + model.fsUserId + "', '" + AirRole.RoleDefault + "', '" + shopId + "', 1, '" + updateTime + "', 1)";
                db.execSQL(sqlDefault);
                String sqlCashBox = "REPLACE INTO tbuserrole (fsUserId, fsRoleId, fsShopGUID, fiStatus, fsUpdateTime, sync) VALUES ('" + model.fsUserId + "', '" + AirRole.RoleCashBox + "', '" + shopId + "', " + (model.supportCashBox() ? 1 : 13) + ", '" + updateTime + "', 1)";
                db.execSQL(sqlCashBox);
                String sqlBill = "REPLACE INTO tbuserrole (fsUserId, fsRoleId, fsShopGUID, fiStatus, fsUpdateTime, sync) VALUES ('" + model.fsUserId + "', '" + AirRole.RoleBill + "', '" + shopId + "', " + (model.supportBill() ? 1 : 13) + ", '" + updateTime + "', 1)";
                db.execSQL(sqlBill);
                String sqlRefund = "REPLACE INTO tbuserrole (fsUserId, fsRoleId, fsShopGUID, fiStatus, fsUpdateTime, sync) VALUES ('" + model.fsUserId + "', '" + AirRole.RoleRefund + "', '" + shopId + "', " + (model.supportRefund() ? 1 : 13) + ", '" + updateTime + "', 1)";
                db.execSQL(sqlRefund);
                String sqlReport = "REPLACE INTO tbuserrole (fsUserId, fsRoleId, fsShopGUID, fiStatus, fsUpdateTime, sync) VALUES ('" + model.fsUserId + "', '" + AirRole.RoleReport + "', '" + shopId + "', " + (model.supportReport() ? 1 : 13) + ", '" + updateTime + "', 1)";
                db.execSQL(sqlReport);
                return null;
            }
        });
    }
}
