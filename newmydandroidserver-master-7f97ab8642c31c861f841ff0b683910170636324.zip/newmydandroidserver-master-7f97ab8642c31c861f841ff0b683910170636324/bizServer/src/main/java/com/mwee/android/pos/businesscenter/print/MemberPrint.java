package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.util.FormatUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 会员打印的数据构造
 * Created by virgil on 16/8/18.
 */
public class MemberPrint {

    /**
     * 打印会员特权
     *
     * @param cardNo          String | 会员卡号
     * @param memberPrivilege MemberPrivateModel | 会员特权
     */
    public static List<Integer> printPrivilege(final String cardNo, final MemberPrivateModel memberPrivilege) {

        List<Integer> printTaskIds = new ArrayList<>();

        int printNO = PrintJSONBuilder.generatePrintNO();

        String printName = PrintConnector.getInstance().getCurrentHostPrinterName();

        JSONObject datas = new JSONObject();
        datas.put("cardno", FormatUtil.formatMemberCardNo(cardNo));
        datas.put("privilege", memberPrivilege.title);
        datas.put("privilegedesc", memberPrivilege.directions);
        datas.put("fiPrintNo", printNO);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MEMBER_PRIVILEGE);
        task.uri = "member/privilege";
        task.fsPrinterName = printName;

        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();

        task.fiPrintNo = printNO;
        task.fsPrnData = value;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;

    }

    /**
     * 打印会员特权
     *
     * @param cardNo          String | 会员卡号
     * @param memberPrivilege MemberPrivateModel | 会员特权
     */
    public static List<Integer> printPrivilege(final String cardNo, final MemberPrivateDetailModel.CardPrivilege memberPrivilege) {

        List<Integer> printTaskIds = new ArrayList<>();

        int printNO = PrintJSONBuilder.generatePrintNO();

        String printName = PrintConnector.getInstance().getCurrentHostPrinterName();

        JSONObject datas = new JSONObject();
        datas.put("cardno", FormatUtil.formatMemberCardNo(cardNo));
        datas.put("privilege", memberPrivilege.title);
        datas.put("privilegedesc", memberPrivilege.directions);
        datas.put("fiPrintNo", printNO);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MEMBER_PRIVILEGE);
        task.uri = "member/privilege";
        task.fsPrinterName = printName;

        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();

        task.fiPrintNo = printNO;
        task.fsPrnData = value;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;

    }

    /**
     * 打印会员充值
     *
     * @param orderModel String | 会员卡号
     * @param payType    String|支付类型
     * @param memberName String|会员姓名
     */
    public static List<Integer> printCharge(final MemberRechargeOrderModel orderModel, final String payType, final String memberName, String hostId) {

        List<Integer> printTaskIds = new ArrayList<>();

        int printNO = PrintJSONBuilder.generatePrintNO();

        String printName = PrintConnector.getInstance().getPrinterNameByHost(hostId);
        if (TextUtils.isEmpty(printName)) {
            printName = PrintConnector.getInstance().getCurrentHostPrinterName();
        }

        JSONObject datas = new JSONObject();
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class);
        datas.put("shop", shopDBModel.fsShopName);
        datas.put("cardno", FormatUtil.formatMemberCardNo(orderModel.card_no));

        datas.put("orderno", orderModel.trade_no);
        datas.put("chargetime", DateUtil.getCurrentTime());
        datas.put("chargeamount", orderModel.amount);
        datas.put("fiPrintNo", printNO + "");

        datas.put("memberName", memberName);
        datas.put("payType", payType);
        datas.put("content", orderModel.content);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MEMBER_CHARGE);
        task.uri = "member/charge";
        task.fsPrinterName = printName;

        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();

        task.fiPrintNo = printNO;
        task.fsPrnData = value;

        if (TextUtils.isEmpty(printName)) {
            LogUtil.logBusiness("打印会员充值", "未找到打印机:" + JSON.toJSONString(task));
        }

        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

    /**
     * 打印会员充值
     *
     * @param orderModel String | 会员卡号
     * @param payType    String|支付类型
     * @param memberName String|会员姓名
     */
    public static List<Integer> printCharge(final MemberRechargeResultModel orderModel, final String payType, final String memberName, String hostId) {

        List<Integer> printTaskIds = new ArrayList<>();

        int printNO = PrintJSONBuilder.generatePrintNO();

        String printName = PrintConnector.getInstance().getPrinterNameByHost(hostId);
        if (TextUtils.isEmpty(printName)) {
            printName = PrintConnector.getInstance().getCurrentHostPrinterName();
        }

        JSONObject datas = new JSONObject();
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class);
        datas.put("shop", shopDBModel.fsShopName);
        datas.put("cardno", FormatUtil.formatMemberCardNo(orderModel.card_no));

        datas.put("orderno", orderModel.trade_no);
        datas.put("chargetime", DateUtil.getCurrentTime());
        datas.put("chargeamount", orderModel.amount);
        datas.put("fiPrintNo", printNO + "");

        datas.put("memberName", memberName);
        datas.put("payType", payType);
        datas.put("content", orderModel.content);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask("", "", "", printNO, "", "0", PrintReportId.MEMBER_CHARGE);
        task.uri = "member/charge";
        task.fsPrinterName = printName;

        datas.put("printTime", task.fsCreateTime);
        String value = datas.toJSONString();

        task.fiPrintNo = printNO;
        task.fsPrnData = value;

        if (TextUtils.isEmpty(printName)) {
            LogUtil.logBusiness("打印会员充值", "未找到打印机:" + JSON.toJSONString(task));
        }

        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

}
