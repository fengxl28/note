package com.mwee.android.pos.businesscenter.framework;

import com.mwee.android.pos.db.business.order.OrderCache;

/**
 * @ClassName: IOrderExecute
 * @Description:
 * @author: SugarT
 * @date: 2018/7/19 下午8:23
 */
public interface IOrderExecute<T> {

    /**
     * 订单处理
     *
     * @param orderCache
     */
    T execute(OrderCache orderCache);
}
