package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.air.util.DBPrimaryKeyUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.CardRelationDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2018/1/11.
 */

public class CardRelationDBUtil {

    /**
     * 绑定会员卡
     * <p>
     * 第三方会员卡号与美味会员卡号绑定
     *
     * @param cardNo      会员卡号
     * @param phone       手机号
     * @param userDBModel
     * @return
     */
    public static String bindCard(String cardNo, String phone, UserDBModel userDBModel) {
        if (TextUtils.isEmpty(cardNo)) {
            return "请输入会员卡号";
        }

        if (TextUtils.isEmpty(phone)) {
            return "请输入手机号";
        }

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbCardRelation set fistatus = '13'," +
                " sync = '1', lver = lver+5, " +
                " fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "' " +
                " where fsRelValue = '" + phone + "'");

        CardRelationDBModel cardRelationDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbCardRelation where fsRelKey = '" + cardNo + "' ", CardRelationDBModel.class);
        if (cardRelationDBModel == null) {
            cardRelationDBModel = new CardRelationDBModel();
            cardRelationDBModel.fsGuid = DBPrimaryKeyUtil.optPrimaryKey();
            cardRelationDBModel.fsRelKey = cardNo;
            cardRelationDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            cardRelationDBModel.fiStatus = 1;
            cardRelationDBModel.fsCreateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                cardRelationDBModel.fsUpdateUserName = userDBModel.fsUserName;
                cardRelationDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            cardRelationDBModel.fiDataSource = 1;
            cardRelationDBModel.lver = 1;
        } else {
            if (!TextUtils.equals(phone, cardRelationDBModel.fsRelValue) || cardRelationDBModel.fiStatus != 1) {
                cardRelationDBModel.fsRemark = cardRelationDBModel.fsRemark + " 上一次记录[" + cardRelationDBModel.fsUpdateTime + ";" + cardRelationDBModel.fsUpdateUserId + ";" + cardRelationDBModel.fsRelValue + ";" + cardRelationDBModel.fiStatus + "] ";
                if (!TextUtils.isEmpty(cardRelationDBModel.fsRemark) && cardRelationDBModel.fsRemark.length() >= 500) {
                    cardRelationDBModel.fsRemark = cardRelationDBModel.fsRemark.substring(cardRelationDBModel.fsRemark.length() - 400, cardRelationDBModel.fsRemark.length());
                }
            }
            if (cardRelationDBModel.fiStatus != 1) {
                cardRelationDBModel.fiStatus = 1;
                cardRelationDBModel.fsCreateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            }
        }

        cardRelationDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cardRelationDBModel.fsRelValue = phone;
        cardRelationDBModel.sync = 1;
        cardRelationDBModel.lver = cardRelationDBModel.lver + 5;

        cardRelationDBModel.replaceNoTrans();
        return "";
    }

    /**
     * 获取第三方卡号对应的美味卡号
     *
     * @param thirdOrderNumber
     * @return
     */
    public static String optMWNumber(String thirdOrderNumber) {
        String mwNumber = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsRelValue from tbCardrelation where fsRelKey = '" + thirdOrderNumber + "' and fistatus = '1' ");
        if (!TextUtils.isEmpty(mwNumber)) {
            return mwNumber;
        }
        return "";
    }
}
