package com.mwee.android.pos.businesscenter.business.order;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseArray;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.base.task.net.NetJob;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberProcessResult;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.ServerMemberApi;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeResponse;
import com.mwee.android.pos.component.member.newInterface.model.NewPayCodeModel;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.OpenParamDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 开台业务业务相关的处理类
 */
public class OrderBizUtil {

    /**
     * 开台预设的订单关联的菜品
     *
     * @param fsmareaid  餐区
     * @param personNum  人数
     * @param fsUserId   用户ID
     * @param fsUserName 用户name
     * @return List<MenuItem>
     */
    public static List<MenuItem> getOpenParamOrderMenu(String fsmareaid, int personNum, String fsUserId, String fsUserName) {

        List<OpenParamDBModel> openParamDBModels = optOpenParamDBModel(fsmareaid);
        List<MenuItem> tempSelectedMenuList = new ArrayList<>();
        if (ListUtil.isEmpty(openParamDBModels)) {
            return tempSelectedMenuList;
        }
        for (int i = 0; i < openParamDBModels.size(); i++) {
            OpenParamDBModel openParamDBModel = openParamDBModels.get(i);
            MenuItem menuItem = MenuDBUtil.buildMenuItem(openParamDBModel);

            if (menuItem == null) {
                continue;
            }
            if (menuItem.menuBiz == null) {
                menuItem.menuBiz = new MenuBiz();
            }
            //当前菜品 数量类型(1:固定数量，0:按人数)
            if (openParamDBModel.fiNumberType == 1) {
                menuItem.menuBiz.buyNum = new BigDecimal(openParamDBModel.fiSaleQty);
            } else {
                //如果人数选择的是0，则直接continue
                if (personNum <= 0) {
                    continue;
                }
                menuItem.menuBiz.buyNum = new BigDecimal(personNum);
            }
            //设置菜品的规格 预设的份数 是否赠送
            if (openParamDBModel.fiIsGift == 1) {
                menuItem.doGift(fsUserId, "", "开台预置赠菜");
            }
            menuItem.menuBiz.generateUniq();
            menuItem.calcTotal(false);
            tempSelectedMenuList.add(menuItem);
        }
        return tempSelectedMenuList;
    }

    /**
     * 判断餐区是否有预点菜品
     *
     * @param fsmareaid 餐区ID
     * @return
     */
    public static boolean hasOpenParam(String fsmareaid) {
        if (ListUtil.isEmpty(optOpenParamDBModel(fsmareaid))) {
            return false;
        }
        return true;
    }

    /**
     * 获取餐区预点菜品配置
     *
     * @param fsmareaid 餐区ID
     * @return
     */
    public static List<OpenParamDBModel> optOpenParamDBModel(String fsmareaid) {
        String sql = "select * from tbopenparam where fiStatus = '1'  and fsMAreaId = '" + fsmareaid + "'";
        List<OpenParamDBModel> openParamDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, OpenParamDBModel.class);
        if (ListUtil.isEmpty(openParamDBModels)) {
            return new ArrayList<>();
        }
        return openParamDBModels;
    }

    public static boolean isOpenMenuItem(String uintCd) {
        String sql = "select fiOrderUintCd from tbopenparam where fiStatus = '1'  and fiOrderUintCd ='" + uintCd + "'";
        String fiOrderUintCd = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return !TextUtils.isEmpty(fiOrderUintCd);
    }

    /**
     * 检查订单中的开台预设数据
     *
     * @param orderCache
     * @return String
     */
    public static String checkOrderOpenParam(OrderCache orderCache, String userid, String userName) {

        if (orderCache.shareShopOrder()) {
            //共享餐厅订单不校验开台预点菜
            return "";
        }

        StringBuilder sb = new StringBuilder();
        List<MenuItem> openParamMenu = OrderBizUtil.getOpenParamOrderMenu(orderCache.fsmareaid, orderCache.personNum, userid, userName);

        //校验当前订单中含有开台预设菜品
        if (!openParamMenu.isEmpty()) {

            boolean isPassMenu = false;//当前已点菜包含所有的预制数据
            int isPassMenuCount = 0;//检验是当期订单时候包含全部预设开台菜品
//            SparseArray<List<MenuItem>> compareMenu = new SparseArray<>();
            ArrayMap<String, List<MenuItem>> compareMenu = new ArrayMap<>();

            /*List<MenuItem> selectMenuList = new ArrayList<>();//当前订单的菜品 不包含退菜
            for (int i = 0; i < orderCache.originMenuList.size(); i++) {
                if (!orderCache.originMenuList.get(i).isAllVoid()) {
                    selectMenuList.add(orderCache.originMenuList.get(i));
                }
            }*/

            List<MenuItem> selectMenuList = orderCache.originMenuList;//当前订单的菜品 包含退菜
            for (int i = 0; i < openParamMenu.size(); i++) {
                MenuItem item = openParamMenu.get(i);
                int isContainMenuNumber = 0;//校验当期订单中不包含的预设开台菜品
                for (int j = 0; j < selectMenuList.size(); j++) {
                    MenuItem menuItem = selectMenuList.get(j);
                   /* if (menuItem.isAllVoid()) {
                        continue;
                    }*/
                    if (TextUtils.equals(menuItem.itemID, item.itemID)) {
                        isPassMenuCount++;
                        List<MenuItem> list = compareMenu.get(menuItem.itemID);
                        if (list == null) {
                            list = new ArrayList<>();
                        }
                        list.add(menuItem);
                        compareMenu.put(menuItem.itemID, list);
                    } else {
                        isContainMenuNumber++;
                    }
                }

                if (isContainMenuNumber == selectMenuList.size()) {//表明当前订单中没有该开台预设菜品
                    //sb.append("预置菜品 [" + item.name +"] 没有选中,您确定跳过？");
                    sb.append(" [" + item.name + "];");
                }
            }

            if (!TextUtils.isEmpty(sb.toString())) {
                sb.deleteCharAt(sb.length() - 1);
                String remindStr = String.format("开台预置菜品%s没有选中，您确定跳过吗?", sb.toString());
                sb.setLength(0);
                sb.append(remindStr);
                //sb.append("预置菜品%s没有选中，您确定跳过");
            }

            if (isPassMenuCount >= openParamMenu.size()) {
                isPassMenu = true;
            }

            //当前订单包含所有的预订菜品 再比较数量
            /**
             *  1 比较数量有两种   第一种是比较开台预制菜品的数量和选中对应该菜品的数目
             *                   第二种是比较开台预制菜品的数量根据开台人数走   开台预制非固定菜品对应的选中的菜品的数量 大于等于开台人数
             */
            if (isPassMenu) {
                for (int i = 0; i < openParamMenu.size(); i++) {
                    MenuItem item = openParamMenu.get(i);
                    List<MenuItem> tempList = compareMenu.get(item.itemID);
                    BigDecimal compareBuyNum = BigDecimal.ZERO;//订单与预制菜品匹配菜品的数据
                    if (tempList == null) {
                        continue;
                    }
                    for (int k = 0; k < tempList.size(); k++) {
                        MenuItem temp = tempList.get(k);
                        if (temp.hasAlreadyGift()) {
                            compareBuyNum = compareBuyNum.add(temp.menuBiz.giftNum);
                        } else {
                            compareBuyNum = compareBuyNum.add(temp.menuBiz.buyNum);
                        }
                    }
                   /* if(compareBuyNum.compareTo(item.menuBiz.buyNum) < 0){
                        sb.append("开台预置 ["+item.name+"] 数量必须大于等于"+item.menuBiz.buyNum);
                        break;
                    }*/

                    String sql = "select fiNumberType from tbopenparam where fiStatus = '1'"
                            + " and fsMAreaId = '" + orderCache.fsmareaid + "'"
                            + " and fiItemCd = '" + item.itemID + "'";
                    int fiNumberType = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql));
                    if (fiNumberType == 1) {//开台预置菜品为固定菜  比较购买数量 否则与订单中人数比较
                        if (compareBuyNum.compareTo(item.menuBiz.buyNum) < 0) {
                            sb.append(" [" + item.name + "] 数量应该大于等于" + item.menuBiz.buyNum + ";");
                            continue;
                        }
                    } else {
                        if (compareBuyNum.compareTo(new BigDecimal(orderCache.personNum)) < 0) {
                            sb.append(" [" + item.name + "] 数量应该大于等于" + item.menuBiz.buyNum + ";");
                            continue;
                        }
                    }
                }
                if (!TextUtils.isEmpty(sb.toString())) {
                    sb.deleteCharAt(sb.length() - 1);
                    String remindStr = String.format("开台预置菜品%s,您确定跳过吗？", sb.toString());
                    sb.setLength(0);
                    sb.append(remindStr);
                }
            }
        }

        return sb.toString();
    }

    /**
     * 会员重构---已废弃
     * 开始处理会员相关的抵扣，包括4个部分：
     * 1，抵扣积分
     * 2，抵扣消费券
     * 3，赠送积分
     * 4，赠送消费券
     * 这个方法统一处理抵扣和赠送，如果没有抵扣过，则只处理赠送。
     */
    public static void startMemberConsume(final PaySession session, OrderCache orderCache, final MemberProcessResult resultListener) {
        if (!orderCache.isMember) {
            if (resultListener != null) {
                resultListener.callBack(true, "", true, null);
            }
            return;
        }
        //积分的相关的Model
        PayModel memberPoint = null;
        //优惠券
        final List<PayModel> memberTicketList = new ArrayList<>();
        //订单号
        String memberOrderID = "";
        //实收金额
        BigDecimal totalCalc = BigDecimal.ZERO;
        //是否存在已抵扣的会员积分或者优惠券
        boolean consumedMemberOrder = false;
        //秒付里包含的会员储值总额
        BigDecimal balanceAmt = BigDecimal.ZERO;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的抵扣");
        try {
            orderCache = OrderSession.getInstance().getOrder(orderCache.orderID);

            if (!ListUtil.isEmpty(session.selectPayListFull)) {
                totalCalc = PayUtil.calcPayCalc(session);
                for (PayModel temp : session.selectPayListFull) {
                    if (temp.status != PayTypeStatus.DELETE) {
                        if (PayType.isMWMemberPoint(temp.data) && temp.checkMemberLoginPay()) {
                            if (!temp.checkMemberConsumed()) {
                                memberPoint = temp;
                                if (TextUtils.isEmpty(temp.memberOrderID)) {
                                    memberOrderID = temp.memberOrderID;
                                }
                            } else {
                                LogUtil.logBusiness(orderCache.orderID + " 积分已抵扣过:" + JSON.toJSONString(temp));
//                                consumedMemberOrder = true;
                            }
                        } else if (PayType.isMWMemberTicket(temp.data) && temp.checkMemberLoginPay()) {
                            if (!temp.checkMemberConsumed()) {
                                memberTicketList.add(temp);
                                if (TextUtils.isEmpty(temp.memberOrderID)) {
                                    memberOrderID = temp.memberOrderID;
                                }
                            } else {
                                LogUtil.logBusiness(orderCache.orderID + " 美味会员的优惠券已抵扣过:" + JSON.toJSONString(temp));
//                                consumedMemberOrder = true;
                            }
                        }
                        if (PayType.isMWMemberBalance(temp.data)) {
                            balanceAmt = balanceAmt.add(temp.payAmount);
                        }
                    }
                }
            } else {
                if (resultListener != null) {
                    resultListener.callBack(true, "", true, null);
                }
                return;
            }
            if (TextUtils.isEmpty(memberOrderID)) {
                memberOrderID = session.memberOrderID;
            }
            if (!TextUtils.isEmpty(session.memberOrderID) && session.memberConsumed) {
                if (resultListener != null) {
                    resultListener.callBack(true, "订单已抵扣过", false, null);
                }
                return;
            }
            if (consumedMemberOrder) {
                if (resultListener != null) {
                    resultListener.callBack(true, "支付明细已抵扣过", false, null);
                }
                return;
            }
            if (TextUtils.isEmpty(memberOrderID)) {
                memberOrderID = OrderUtil.buildNetOrderID(orderCache.shopID, session.billNO);
                session.memberOrderID = memberOrderID;
            }
            session.memberCardNO = orderCache.memberInfoS.card_no;
            session.memberRealAmt = totalCalc;
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "开始处理会员相关的抵扣");
        }

        final boolean onlyGift = (memberPoint == null && ListUtil.isEmpty(memberTicketList));
        final PayModel memberPointFinal = memberPoint;
        final String memberOrderIDFinal = memberOrderID;

        // 会员重构对接---已废弃
//        final MemberOrderConsumeRequest request = new MemberOrderConsumeRequest();
//        request.card_no = orderCache.memberInfoS.card_no;
//        //新增外部订单字段 存储订单id
//        request.outer_order_id = orderCache.orderID;
//        request.sec_order_id = optValiedRapidPayId(session);
//        request.antiPaied = orderCache.inAntiPaied();
//        request.pay_type = 1;
//        if (memberPoint != null) {
//            request.use_score = memberPoint.memberCostScore;
//            request.score_money = memberPoint.payAmount;
//        }
//        request.order_id = memberOrderID;
//        request.coupons = PayUtil.getMemberTicketCode(memberTicketList);
//
//        request.amount = PayUtil.checkForMemberCalcPaid(session);
//        if (request.amount.compareTo(BigDecimal.ZERO) < 0) {
//            request.amount = BigDecimal.ZERO;
//        }
//        request.order_amount = orderCache.optTotalPrice();
//        request.drop_amount = totalCalc.subtract(PayUtil.getDiscountAmtByLeftToPay(session, orderCache));
//        if (request.drop_amount.compareTo(BigDecimal.ZERO) < 0) {
//            request.drop_amount = BigDecimal.ZERO;
//        }
//        request.spay_card_amount = balanceAmt;

        if (TextUtils.isEmpty(orderCache.memberInfoS.pay_code)) {
            OrderCache finalOrderCache = orderCache;
            ServerMemberApi.sendRefreshMemberPayCodeSessionNew(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        startMemberConsume(session, finalOrderCache, resultListener);
                    } else {
                        resultListener.callBack(false, info, onlyGift, null);
                    }
                }
            });
            return;
        }

        NewMemberOrderConsumeRequest request = new NewMemberOrderConsumeRequest();
        request.brandId = ServerCache.getInstance().fsCompanyGUID;
        request.cardNo = orderCache.memberInfoS.pay_code;
        //新增外部订单字段 存储订单id
        request.outerOrderId = orderCache.orderID;
        request.secOrderId = optValiedRapidPayId(session);
        request.antiPaied = orderCache.inAntiPaied();
        request.payType = 1;
        if (memberPoint != null) {
            request.useScore = memberPoint.memberCostScore;
            request.scoreMoney = memberPoint.payAmount;
        }
        request.orderId = memberOrderID;
        request.coupons = PayUtil.getMemberTicketCodeList(memberTicketList);

        request.amount = PayUtil.checkForMemberCalcPaid(session);
        if (request.amount.compareTo(BigDecimal.ZERO) < 0) {
            request.amount = BigDecimal.ZERO;
        }
        request.orderAmount = orderCache.optTotalPrice();
        request.dropAmount = totalCalc.subtract(PayUtil.getDiscountAmtByLeftToPay(session, orderCache));
        if (request.dropAmount.compareTo(BigDecimal.ZERO) < 0) {
            request.dropAmount = BigDecimal.ZERO;
        }
        request.spayCardAmount = balanceAmt;

        if (onlyGift) {
            session.memberConsumed = true;
            resultListener.callBack(true, "", true, request);
            return;
        }

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "OrderBizUtil#startMemberConsume----" + session.orderID + "----------会员回调-- 支付业务中心-");

                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_SUCCESS, "会员抵扣成功", session.orderID, "", responseData.resultMessage);

                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    int fatherSeq = -1;
                    if (memberPointFinal != null) {
                        memberPointFinal.writeMemberConsumed();
                        fatherSeq = memberPointFinal.seq;
                        memberPointFinal.memberOrderID = memberOrderIDFinal;
                    }
                    if (!ListUtil.isEmpty(memberTicketList)) {
                        for (PayModel temp : memberTicketList) {
                            if (fatherSeq == -1) {
                                fatherSeq = temp.seq;
                            } else {
                                temp.seq_M = fatherSeq;
                            }
                            temp.writeMemberConsumed();
                            temp.memberOrderID = memberOrderIDFinal;
                            temp.ticketCode = temp.data.memberCouponModel.code;
                        }

                    }
                    session.memberConsumed = true;
                    if (response.data != null) {
                        session.memberGiftScore = response.data.incr_score;
                    }
                    if (resultListener != null) {
                        resultListener.callBack(true, "", false, request);
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
                    //如果是明确的业务失败，则清除掉缓存的订单号
                    if (response.status != 0) {
                        session.memberOrderID = "";
                    }
                }
                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_FAIL, "会员抵扣失败", session.orderID, "", responseData.resultMessage);
                if (resultListener != null) {
                    resultListener.callBack(false, responseData.resultMessage, onlyGift, request);
                }
                return false;
            }
        });
        job.execute();

//        BusinessExecutor.execute(request, new IExecutorCallback() {
//            @Override
//            public void success(ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_SUCCESS, "会员抵扣成功", session.orderID, "", responseData.resultMessage);
//
//                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
//                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
//                    int fatherSeq = -1;
//                    if (memberPointFinal != null) {
//                        memberPointFinal.writeMemberConsumed();
//                        fatherSeq = memberPointFinal.seq;
//                        memberPointFinal.memberOrderID = memberOrderIDFinal;
//                    }
//                    if (!ListUtil.isEmpty(memberTicketList)) {
//                        for (PayModel temp : memberTicketList) {
//                            if (fatherSeq == -1) {
//                                fatherSeq = temp.seq;
//                            } else {
//                                temp.seq_M = fatherSeq;
//                            }
//                            temp.writeMemberConsumed();
//                            temp.memberOrderID = memberOrderIDFinal;
//                            temp.ticketCode = temp.data.memberCouponModel.code;
//                        }
//
//                    }
//                    session.memberConsumed = true;
//                    if (response.data != null) {
//                        session.memberGiftScore = response.data.incr_score;
//                    }
//                    if (resultListener != null) {
//                        resultListener.callBack(true, "", false, request);
//                    }
//                }
//            }
//
//            @Override
//            public boolean fail(ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
//                    MemberOrderConsumeResponse response = (MemberOrderConsumeResponse) responseData.responseBean;
//                    //如果是明确的业务失败，则清除掉缓存的订单号
//                    if (response.status != 0) {
//                        session.memberOrderID = "";
//                    }
//                }
//                RunTimeLog.addLog(RunTimeLog.PAY_MEM_ORDER_FAIL, "会员抵扣失败", session.orderID, "", responseData.resultMessage);
//                if (resultListener != null) {
//                    resultListener.callBack(false, responseData.resultMessage, onlyGift, request);
//                }
//                return false;
//            }
//        }, null, true);
    }

    /**
     * 挑选出通用要求
     * @param tempSelectedMenuList
     */
    public static void pickGeneralNotes(List<MenuItem> tempSelectedMenuList) {

        if (ListUtil.isEmpty(tempSelectedMenuList)) {
            return;
        }
        //只有一个菜默认是单品备注
        if (tempSelectedMenuList.size() == 1) {
            tempSelectedMenuList.get(0).menuBiz.selectNote.addAll(tempSelectedMenuList.get(0).menuBiz.selectOrderNote);
            tempSelectedMenuList.get(0).menuBiz.selectOrderNote.clear();
            return;
        }

        MenuItem menuItem = tempSelectedMenuList.get(0);

        MenuItem item = null;

        List<NoteItemModel> menuItemNoteList = new ArrayList<>();
        menuItemNoteList.addAll(menuItem.menuBiz.selectOrderNote);
        menuItemNoteList.addAll(menuItem.menuBiz.selectNote);

        //通用要求
        List<NoteItemModel> generalNotes = new ArrayList<>();

        boolean meet = false;
        for (NoteItemModel noteItemModel : menuItemNoteList) {
            meet = false;
            for (int i = 1; i < tempSelectedMenuList.size(); i++) {
                item = tempSelectedMenuList.get(i);
                meet = false;
                for (NoteItemModel note : item.menuBiz.selectOrderNote) {
                    if (TextUtils.equals(note.name, noteItemModel.name)
                            && noteItemModel.num.compareTo(note.num) == 0
                            && note.price.compareTo(noteItemModel.price) == 0) {
                        meet = true;
                        break;
                    }
                }

                if (meet) {
                    continue;
                }

                for (NoteItemModel note : item.menuBiz.selectNote) {
                    if (TextUtils.equals(note.name, noteItemModel.name)
                            && noteItemModel.num.compareTo(note.num) == 0
                            && note.price.compareTo(noteItemModel.price) == 0) {
                        meet = true;
                        break;
                    }
                }

                if (!meet) {
                    break;
                }
            }

            //所有菜品都存在此要求
            if (meet){
                generalNotes.add(noteItemModel);
            }
        }

        if (!ListUtil.isEmpty(generalNotes)) {
            //删除每个菜品里的通用要求
            for (NoteItemModel noteItemModel : generalNotes) {
                for (MenuItem menu : tempSelectedMenuList) {
                    menu.menuBiz.selectNote.addAll(menu.menuBiz.selectOrderNote);
                    menu.menuBiz.selectOrderNote.clear();
                    for (NoteItemModel note : menu.menuBiz.selectNote) {
                        if (TextUtils.equals(note.name, noteItemModel.name)
                                && noteItemModel.num.compareTo(note.num) == 0
                                && note.price.compareTo(noteItemModel.price) == 0) {
                            menu.menuBiz.selectNote.remove(note);
                            break;
                        }
                    }
                }
            }

            for (MenuItem menu : tempSelectedMenuList) {
                menu.menuBiz.selectOrderNote.addAll(generalNotes);
                menu.calcTotal(menu.useMemberPrice);
            }
        }

    }


    /**
     * @param session
     * @return
     */
    public static String optValiedRapidPayId(PaySession session) {
        if (session == null || ListUtil.isEmpty(session.selectPayListFull)) {
            return "";
        }
        String result = "";

        StringBuilder stringBuilder = new StringBuilder();
        for (PayModel payModel : session.selectPayListFull) {
            if (payModel == null || !payModel.checkEnable()) {
                continue;
            }

            if (payModel.readRapid() && !TextUtils.isEmpty(payModel.businessInfo) && payModel.seq_M == -1) {
                stringBuilder.append(payModel.businessInfo).append(",");
            }

            if (stringBuilder.length() > 0) {
                result = stringBuilder.toString();
                result = result.substring(0, result.length() - 1);
            }
        }

        RunTimeLog.addLog(RunTimeLog.DOMAN_MEMBER_SCORE, session.orderID + "订单对应的有效秒付订单号：" + result);
        return result;
    }

    /**
     * 根据桌台id查询是否有开台参数
     *
     * @param tableNo
     * @return
     */
    public static boolean hasOpenParamByTableId(String tableNo) {
        MtableDBModel mtableDBModel = TableDBUtil.getMTableById(tableNo);
        if (mtableDBModel != null) {
            return hasOpenParam(mtableDBModel.fsmareaid);
        }
        return false;
    }
}
