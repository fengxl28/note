package com.mwee.myd.server.business.login.entity;


import com.mwee.android.base.net.BaseResponse;

/**
 */
public class LoginPDResponse extends BaseResponse {

//    public LoginPDModel data = new LoginPDModel();
    public String data = "";

    public LoginPDResponse() {
    }

    /**
     * 判断登录结果是否一致
     *
     * @param target LoginPDResponse
     * @return boolean | true: 一致;false:不一致
     */
    public boolean same(LoginPDResponse target) {
//        if (target != null) {
//            return Arrays.equals(data.Services, data.Services) &&
//                    Arrays.equals(data.PopedomInfo, data.PopedomInfo);
//        }
        return false;
    }
}
