package com.mwee.myd.server;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.IDBCreate;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.DBTools;

/**
 * 网络订单数据库
 *
 * @author 刘秀秀
 */
public class NetOrderDBInit {

    protected final static int DBVERSION = 10;

    protected static void initDB(Context context) {
        DBManager.init(context, R.raw.mwnetorder, APPConfig.DB_NET_ORDER, DBVERSION, new IDBCreate() {
            @Override
            public void onCreate(SQLiteDatabase db) {
                RunTimeLog.addLog(RunTimeLog.DB, "NetOrderDBInit initDB onCreate version " + NetOrderDBInit.DBVERSION);
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                RunTimeLog.addLog(RunTimeLog.DB, "NetOrderDBInit initDB onUpgrade oldVersion " + oldVersion + ",newVersion" + newVersion);
                try {
                    if (oldVersion < 2) {
                        // pro2.2.5
                        updateV2(db);
                    }

                    if (oldVersion < 3) {
                        // pro2.6
                        updateV3(db);
                    }
                    if (oldVersion < 4) {
                        // pro2.7
                        updateV4(db);
                    }

                    if (oldVersion < 5) {
                        LogUtil.logBusiness("网络订单数据库升级", "5");
                        // pro2.7.1
                        updateV5(db);
                    }
                    if (oldVersion < 6) {
                        LogUtil.logBusiness("网络订单数据库升级", "6");
                        // pro2.7.6
                        updateV6(db);
                    }
                    if (oldVersion < 7) {
                        LogUtil.logBusiness("网络订单数据库升级", "7");
                        // pro2.8
                        updateV7(db);
                    }

                    if (oldVersion < 9) {
                        LogUtil.logBusiness("网络订单数据库升级", "9");
                        // pro3.0.2美团外卖上送
                        updateV9(db);
                    }

                    if (oldVersion < 10) {
                        LogUtil.logBusiness("网络订单数据库升级", "10");
                        // pro3.3
                        updateV10(db);
                    }

                } catch (Exception e) {
                    LogUtil.logError("网络订单数据库升级异常 ", e);
                }
            }
        });
    }

    /**
     * pro3.3   对接饿了么活动：商家替用户承担配送费
     *
     * @param db
     */
    private static void updateV10(SQLiteDatabase db) {
        /*
         * merchantDeliverySubsidy
         */
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN merchantDeliverySubsidy DECIMAL(18, 2) DEFAULT 0");

        //配送类型 1，立即送达；2，预约送达；3，7日内送达(只有虾搞虾弄使用)
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN distributionType int(4) DEFAULT 0");
        //预约配送时间
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN distributionStartTime vachar(32) DEFAULT ''");

        //外卖配送记录
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS deliveryRecord (\n" +
                "orderId varchar(40) NOT NULL,\n" +
                "orderTime varchar(40),\n" +
                "channel varchar(40),\n" +
                "deliveryStatus varchar(40),\n" +
                "reason varchar(40),\n" +
                "updateTime varchar(40),\n" +
                "fsShopGUID varchar(128),\n" +
                "PRIMARY KEY (orderId, fsShopGUID)\n" +
                ")");
    }

    /**
     * pro3.0.2
     *
     * @param db
     */
    private static void updateV9(SQLiteDatabase db) {
        /*
         * 是否需要上送状态
         */
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN sync INT DEFAULT 0");
    }

    /**
     * pro2.8
     * 外卖订单落入报表，映射数据保留30天
     *
     * @param db
     */
    private static void updateV7(SQLiteDatabase db) {
        /*
         * 新增外卖订单和本地订单关联关系表---最多存31天：businessDate+orderTime
         */
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tempAppOrderMappingLocalOrderRelation (\n" +
                "tempAppOrderId varchar(40) NOT NULL,\n" +  //外卖订单ID
                "localOrderId varchar(40),\n" +             //本地订单ID
                "orderTime varchar(40),\n" +                //外卖订单的创建时间
                "mappintTime varchar(40),\n" +              //订单映射时间
                "businessDate varchar(40),\n" +             //映射的本地订单的营业日期
                "fsShopGUID varchar(128),\n" +              //门店ID
                "PRIMARY KEY (tempAppOrderId, fsShopGUID)\n" +
                ")");

        //修正 '网络订单菜品明细库'表结构
        DBTools.exeSqlWithoutException(db, "alter table tempapporderdetails rename to tempapporderdetailsTemp");
        String sql = "CREATE TABLE IF NOT EXISTS tempapporderdetails\n" +
                "(\n" +
                "  orderId        VARCHAR(36) NOT NULL,\n" +
                "  orderDetailId  VARCHAR(30),\n" +
                "  parentID       INT(11)        DEFAULT 0,\n" +
                "  itemName       VARCHAR(100) ,\n" +
                "  itemNum        DECIMAL(18, 2) DEFAULT 0,\n" +
                "  itemPrice      DECIMAL(18, 2) DEFAULT 0,\n" +
                "  totalItemPrice DECIMAL(18, 2) DEFAULT 0,\n" +
                "  type           INT(11),\n" +
                "  body           VARCHAR(30),\n" +
                "  pokeNo INT(11) DEFAULT 0,\n" +
                "  PRIMARY KEY (orderId, orderDetailId)\n" +
                ");";
        DBTools.exeSqlWithoutException(db, sql);
        DBTools.exeSqlWithoutException(db, "INSERT INTO tempapporderdetails SELECT orderId,orderDetailId,parentID,itemName,itemNum,itemPrice,totalItemPrice,type,body,pokeNo FROM tempapporderdetailsTemp");
        DBTools.exeSqlWithoutException(db, "drop table tempapporderdetailsTemp");

    }

    /**
     * pro2.7.6  隐私号降级通知记录
     *
     * @param db
     */
    private static void updateV6(SQLiteDatabase db) {
        //网络订单库新增 隐私号降级通知记录
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS phoneDowngrade(\n" +
                "    orderId       VARCHAR(20) PRIMARY KEY NOT NULL,\n" +
                "    phone      VARCHAR(80),\n" +
                "    status      int,\n" +
                "    createTime      VARCHAR(20),\n" +
                "    updateTime      VARCHAR(20),\n" +
                "    updateUserId    VARCHAR(20),\n" +
                "    param1  VARCHAR(30),\n" +
                "    param2    VARCHAR(80))");

    }

    private static void updateV2(SQLiteDatabase db) {
        //网络订单库新增 配送状态、更新时间，创建时间等字段
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD deliveryStatus INT DEFAULT -10000");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN updateTime VARCHAR(20)");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN createTime VARCHAR(20)");

    }

    private static void updateV3(SQLiteDatabase db) {
        //商品所在的口袋，0为1号口袋，1为2号口袋，以此类推
        if (!DBInit.isFieldExist(db, "tempapporderDetails", "pokeNo")) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporderDetails ADD COLUMN pokeNo INT(11) DEFAULT 0 ");
        }
    }

    /**
     * pro2.7
     * 2018-04-17日新增
     *
     * @param db
     */
    private static void updateV4(SQLiteDatabase db) {
        /*
        * pro2.6.5新增字段
        */
        //实付金额
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN realPaymentAmount NUMERIC DEFAULT 0;");
        //定金/外卖实收金额
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN earnestMoney NUMERIC DEFAULT 0;");
        //商家补贴
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN platformShopDiscount NUMERIC DEFAULT 0;");
        //平台补贴
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN platformDiscount NUMERIC DEFAULT 0;");
        //订单来源类型
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN sourceType INT DEFAULT 0;");
        //备餐方式 立即备餐、稍后备餐
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN readyFoodMode INT DEFAULT 0;");
        //是否在线支付（0 否1是）
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN isOnlinePaid INT DEFAULT 0;");
        //就餐类型(1到店堂吃，2自提带走)
        DBTools.exeSqlWithoutException(db, " ALTER TABLE tempapporder ADD COLUMN eatType INT DEFAULT 0;");
        //发票类型(0 - 无，1 - 个人, 2 - 单位)
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN receiptType INT DEFAULT 0;");
        //'发票内容'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN receiptName Text DEFAULT '';");
        //'税号'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN taxNo Text DEFAULT '';");
        //积分抵扣
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN memberDiscount NUMERIC DEFAULT 0;");
        //储值卡使用金额
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN valueCardDiscount NUMERIC DEFAULT 0;");
        //合计---实付价格
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN total NUMERIC DEFAULT 0;");


        /*pro2.7
         * 2018-03-12日新增
         * 新增打印记录表，标志小票是否被打印过
         */
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS TempAppOrderPrintInfo (\n" +
                "  guid varchar(80) PRIMARY KEY NOT NULL,\n" +
                "  orderId varchar(40) NOT NULL,\n" +
                "  printTime varchar(40),\n" +
                "  printType int(11) default 0,\n" +
                "  receptType int(11) default 0,\n" +
                "  userId varchar(128),\n" +
                "  userName varchar(128), " +
                "  fsShopGUID varchar(128)" +
                ")");
    }


    /**
     * pro2.7.1
     * 2018-04-19日新增
     * ---- 检查库是否全
     *
     * @param db
     */
    private static void updateV5(SQLiteDatabase db) {
        if (!DBInit.isFieldExist(db, "tempapporder", "realPaymentAmount")) {
            /*
            * pro2.6.5新增字段
            */
            //实付金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN realPaymentAmount NUMERIC DEFAULT 0;");
            //定金/外卖实收金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN earnestMoney NUMERIC DEFAULT 0;");
            //商家补贴
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN platformShopDiscount NUMERIC DEFAULT 0;");
            //平台补贴
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN platformDiscount NUMERIC DEFAULT 0;");
            //订单来源类型
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN sourceType INT DEFAULT 0;");
            //备餐方式 立即备餐、稍后备餐
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN readyFoodMode INT DEFAULT 0;");
            //是否在线支付（0 否1是）
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN isOnlinePaid INT DEFAULT 0;");
            //就餐类型(1到店堂吃，2自提带走)
            DBTools.exeSqlWithoutException(db, " ALTER TABLE tempapporder ADD COLUMN eatType INT DEFAULT 0;");
            //发票类型(0 - 无，1 - 个人, 2 - 单位)
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN receiptType INT DEFAULT 0;");
            //'发票内容'
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN receiptName Text DEFAULT '';");
            //'税号'
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN taxNo Text DEFAULT '';");
            //积分抵扣
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN memberDiscount NUMERIC DEFAULT 0;");
            //储值卡使用金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN valueCardDiscount NUMERIC DEFAULT 0;");
            //合计---实付价格
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN total NUMERIC DEFAULT 0;");
        }
    }

}
