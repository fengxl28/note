package com.mwee.myd.server;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.IntDef;
import android.text.TextUtils;

import com.mwee.android.log.constans.MwLogDBConstants;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Environment;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by virgil on 2018/2/28.
 */

public class ServerLog {
    public final static int LOG_ACTION = 1;
    public final static int LOG_APP = 2;
    public final static int LOG_BIZ = 3;

    public static void initConfig(final Context context) {
        String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        String fsCompanyGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop");

        String shopname = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbshop");
        String hostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        int clientType = LogClientType.MYD_ANDROID;
        if (APPConfig.isMyd()) {
            clientType = LogClientType.MYD_ANDROID;
        } else if (APPConfig.isAir()) {
            clientType = LogClientType.AIR;
        }
        if (APPConfig.isCasiher()) {
            clientType = LogClientType.CAISHER;
        }
        MwLog.setInsertProcessName(context.getPackageName());
        MwLog.init(context, shopID, fsCompanyGUID, shopname, hostID, ServerHardwareUtil.getHardWareSymbol(), clientType);
        if (BaseConfig.ENV == Environment.PRODUCT) {
            MwLog.setTest(false);
        } else {
            boolean prd = TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_URL), Constant.URL_ROOT_PRODUCT);
            MwLog.setTest(!prd);
            MwLog.setShowLog(true);
        }


        new Handler(Looper.getMainLooper()).postDelayed(() -> DBManager.init(context, MwLogDBConstants.DB_NAME, MwLogDBConstants.CURRENT_VERSION, null), 1000 * 60 * 2);
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
    @IntDef(value = {LogClientType.MYD_ANDROID, LogClientType.MYD_WINDOWS, LogClientType.WAITER, LogClientType.CAISHER, LogClientType.AIR})
    public @interface LogClientType {
        /**
         * 美易点Android;
         */
        int MYD_ANDROID = 1;
        /**
         * 美易点Windows
         */
        int MYD_WINDOWS = 2;
        /**
         * 美小二
         */
        int WAITER = 3;
        /**
         * 美收银
         */
        int CAISHER = 4;
        /**
         * 美小易
         */
        int AIR = 5;

    }
}
