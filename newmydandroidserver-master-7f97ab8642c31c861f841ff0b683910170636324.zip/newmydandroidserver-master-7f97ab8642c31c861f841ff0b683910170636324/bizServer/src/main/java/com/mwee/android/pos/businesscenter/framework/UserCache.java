package com.mwee.android.pos.businesscenter.framework;

import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.db.business.UserDBModel;

/**
 * 用户信息缓存
 * Created by qinwei on 2019/2/12 11:16 AM
 * email: qin.wei@mwee.cn
 */
public class UserCache extends Cache {
    private UserCache() {
    }

    //fixme 这里可以改成弱引用
    private UserDBModel cloudUser;
    private static UserCache mInstance = new UserCache();

    public static UserCache getInstance() {
        return mInstance;
    }

    public UserDBModel getCloudUser() {
        if (cloudUser == null) {
            cloudUser = UserDBUtils.queryCloudUser();
        }
        return cloudUser;
    }

    @Override
    public void refresh() {

    }

    @Override
    public void clean() {

    }
}
