package com.mwee.myd.server.dbmodel.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

/**
 * 小票打印模版，门店自定义
 *
 * @author virgil
 */
@TableInf(name = "tbPrintTempletPrivate")
public class PrintTempletPrivateDBModel extends DBModel {
    @ColumnInf(name = "fsTempletId", primaryKey = true)
    public String fsTempletId = "";
    @ColumnInf(name = "fsTempletKey", primaryKey = true)
    public String fsTempletKey = "";
    @ColumnInf(name = "fsTempletName")
    public String fsTempletName = "";
    @ColumnInf(name = "fsTempletFile")
    public String fsTempletFile = "";
    @ColumnInf(name = "fsShopGUID", primaryKey = true)
    public String fsShopGUID = "";
    @ColumnInf(name = "fiSelected")
    public int fiSelected = 0;
    @ColumnInf(name = "fiStatus")
    public int fiStatus = 1;

    @ColumnInf(name = "fsCreateTime")
    public String fsCreateTime = "";
    @ColumnInf(name = "fsCreateUserId")
    public String fsCreateUserId = "";
    @ColumnInf(name = "fsCreateUserName")
    public String fsCreateUserName = "";
    @ColumnInf(name = "fsUpdateTime")
    public String fsUpdateTime = "";
    @ColumnInf(name = "fsUpdateUserId")
    public String fsUpdateUserId = "";
    @ColumnInf(name = "fsUpdateUserName")
    public String fsUpdateUserName = "";
    @ColumnInf(name = "sync")
    public int sync;

    /**
     * 模版类型：0：美易点，1：美小易，2：美收银
     */
    @ColumnInf(name = "fiTempletType")
    public int fiTempletType;

    /**
     * 模版最低支持版本
     */
    @ColumnInf(name = "fiMinSupportVersion")
    public int fiMinSupportVersion;

    public PrintTempletPrivateDBModel() {

    }

    @Override
    public PrintTempletPrivateDBModel clone() {
        PrintTempletPrivateDBModel cloneObj = null;
        try {
            cloneObj = (PrintTempletPrivateDBModel) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}