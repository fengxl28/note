package com.mwee.android.pos.businesscenter.business.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.KBPartRefundReturnResponse;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBPartRefundExtInfo;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.base.Constants;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.businesscenter.module.koubei.service.IKBOrderService;
import com.mwee.android.pos.businesscenter.module.koubei.service.impl.KBOrderServiceImpl;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.koubei.PreOrderCallback;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by zhangmin on 2018/5/17.
 */

public class KBPreOrderProcessor {

    /*---------------------推送的行为----------------------*/

    /**
     * 推送新订单
     *
     * @param
     */
    public static synchronized String pushNewOrder(RapidGetModel data) {

        LogUtil.log("推送取消订单-->" + JSON.toJSONString(JSON.toJSONString(data)));
        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理-->推送新订单 ： ", JSON.toJSONString(data));
            return "";
        }

        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);
        KBPreOrderDBUtils.insert(preOrderCache, false);
        //是否自动接单
        if (KBPreOrderDBUtils.isAutoAccept()) {
            //未营业门店不可以自动接单
            if (HostUtil.isShopFinished()) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "餐厅已打烊,开始自动拒单", data.fsid, data);
                KBPreOrderProcessor.rejectOrder(preOrderCache.order_id, preOrderCache.merchant_id, preOrderCache.take_no, Constants.SHOP_CLOSE);
                return "餐厅已打烊";
            }
            //大前提应该是桌台模式（是否是桌台模式）
            if (KBPreOrderDBUtils.isTableDinner(preOrderCache.business_type)) {//todo business_type = DINNER
                //点餐方式
                switch (preOrderCache.order_style) {
                    case KBConstants.ORDER_STYLE_LATFORM://扫码点 //todo     order_style = PLATFORM
                        if (KBPreOrderDBUtils.isTableForHere(preOrderCache.dinner_type)) {//todo dinner_type = 堂食
                            //口碑堂食模式   接单
                            KBPreOrderTableProcessor.acceptTableOrder(preOrderCache, 0);
                        } else {
                            //口碑外卖模式  接单
                            KBPreOrderProcessor.acceptOrder(preOrderCache, preOrderCache.take_no, 0);
                        }
                        break;
                    case KBConstants.ORDER_STYLE_SCAN:
                        IKBOrderService service = new KBOrderServiceImpl();
                        SocketResponse<ScannerTableOrderAcceptResponse> resonpse = service.acceptPreOrder(preOrderCache);
                        if (resonpse.code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                            NotifyToClient.KBOrderException(preOrderCache.order_id, true);
                            return "";
                        }
                        break;
                    default:
                        break;
                }
            } else {
                //todo business_type = SNACK
                KBPreOrderProcessor.acceptOrder(preOrderCache, preOrderCache.take_no, 0);
            }
        }
        NotifyToClient.addNewKBPreOrder(preOrderCache.order_id);
        return "";
    }


    /**
     * 推送取消订单
     */
    public static synchronized String pushCancelOrder(RapidGetModel data) {

        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理-->推送取消订单 ： ", JSON.toJSONString(data));
            return "";
        }

        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);
        LogUtil.log("推送取消订单-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送取消订单失败", JSON.toJSONString(preOrderCache));
        //todo 只需要改变数据库订单状态为CANCEL 无需其他处理
        KBPreOrderDBUtils.insert(preOrderCache, false);
        return "";
    }


    /**
     * 推送 口碑拒单
     * 5分钟不接单超时行为
     */
    public static synchronized String pushRejuctOrder(RapidGetModel data) {

        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理--> 推送 口碑拒单 ： ", JSON.toJSONString(data));
            return "";
        }

        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);

        LogUtil.log("推送口碑拒单-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送取消订单", JSON.toJSONString(preOrderCache));
        //todo 只需要改变数据库订单状态为CLOSE 无需其他处理
        KBPreOrderDBUtils.insert(preOrderCache, false);
        return "";
    }


    /**
     * 推送 口碑用户发起退款
     */
    public static synchronized String pushApplyRefund(RapidGetModel data) {


        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理--> 推送 口碑用户发起退款 ： ", JSON.toJSONString(data));
            return "";
        }
        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);
        LogUtil.log("推送口碑用户发起退款-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送口碑用户发起退款", JSON.toJSONString(preOrderCache));
        KBPreOrderDBUtils.insert(preOrderCache, false);
        NotifyToClient.kbOrderApplyRefund(preOrderCache.order_id);
        return "";
    }


    /**
     * 推送 商家同意退款
     */
    /*public static synchronized String pushAgreeRefund(RapidGetModel data) {

        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);
        LogUtil.log("推送口碑 商家同意退款-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送口碑  商家同意退款", JSON.toJSONString(preOrderCache));
        KBPreOrderDBUtils.insert(preOrderCache);
        NotifyToClient.kbRefreshOrder(preOrderCache.order_id);
        return "";
    }*/

    /**
     * 推送 口碑退款
     */
    public static synchronized String pushRefund(RapidGetModel data) {

        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理--> 推送 口碑退款 ： ", JSON.toJSONString(data));
            return "";
        }
        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);
        LogUtil.log("推送口碑  口碑退款-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送口碑  口碑退款", JSON.toJSONString(preOrderCache));

        KBPreOrderDBUtils.insert(preOrderCache, false);
        //todo 暂时隐藏不需要及时刷新
        //NotifyToClient.kbRefreshOrder(preOrderCache.order_id);
        return "";
    }




    /*---------------------用户的行为----------------------*/

    /**
     * 接单
     *
     * @param preOrderCache
     * @param retrySeq
     * @param
     */
    public static String acceptOrder(final KBPreOrderCache preOrderCache, String no, int retrySeq) {
        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];
        //接单的时候需要生成 取餐号
        if (TextUtils.isEmpty(no) || no.length() != 6) {
            no = DataCacheDBUtil.generateNewKBNO();
            preOrderCache.take_no = no;
        }

//        orderApi.acceptOrder(preOrderCache.order_id + "", KBConstants.BUSINESS_TYPE_SNACK, KBConstants.ORDER_STYLE_LATFORM, preOrderCache.merchant_id, preOrderCache.take_no, new BusinessCallback() {
        orderApi.acceptOrder(preOrderCache.order_id + "", preOrderCache.business_type, preOrderCache.order_style, preOrderCache.merchant_id, preOrderCache.take_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "接单成功", "订单详情" + JSON.toJSONString(preOrderCache));
                /**
                 *  1 改变本地订单的状态
                 *
                 *  2 接单成功以后生成牌号
                 *
                 *  3 打印外卖单
                 *
                 *  4 处理报表
                 *
                 */

                String status = "RECEIPT";//订单状态
                //如果是扫码快餐，接单后订单状态改为订单完成
                /*if (TextUtils.equals(preOrderCache.business_type, "SNACK") && TextUtils.equals(preOrderCache.order_style, "SCAN")) {
                    status = "FINISH";
                } else {
                    status = "RECEIPT";
                }*/
                KBPreOrderDBUtils.update(preOrderCache.order_id + "", status);
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set take_no = '" + preOrderCache.take_no + "' where  order_id = '" + preOrderCache.order_id + "'");
                String sql = "select order_id from order_cache where thirdOrderId = '" + preOrderCache.order_id + "'";
                String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                if (!TextUtils.isEmpty(local_order_id)) {
                    LogUtil.log("bill", "已经落报表并且已经打印了 无需重复");
                    return true;
                }
                KBPreOrderDBUtils.saveBill(preOrderCache);
                KBMakePrinter.treatPrinter(preOrderCache.order_id, preOrderCache.table_time);
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                //todo 接单失败 连续处理三次
                if (retrySeq < 0 && retrySeq < 3) {
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            acceptOrder(preOrderCache, preOrderCache.take_no, retrySeq + 1);
                        }
                    }, 2000);
                } else {
                    result[0] = responseData.resultMessage;
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, retrySeq + "接单  口碑预点单，订单号：" + preOrderCache.order_id, "异常信息：" + responseData.resultMessage);

                return false;
            }
        });
        return result[0];
    }

    //拒单
    public static String rejectOrder(String orderId, String merchant_id, String no, String reason) {

        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];
        orderApi.rejectOrder(orderId, merchant_id, no, reason, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("拒单成功").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  拒单理由---->" + reason);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString());

                KBPreOrderDBUtils.update(orderId + "", "REJECT");
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "拒单 口碑预点单，拒单订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                result[0] = responseData.resultMessage;
                return false;
            }
        });
        return result[0];
    }


    //备餐
    public static String prepareOrder(String orderId, String businessType, String merchant_id, String no) {
        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];
        orderApi.prepareOrder(orderId, businessType, merchant_id, no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("备餐成功").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  取餐号---->" + no);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString());

                KBPreOrderDBUtils.update(orderId + "", "PREPARE");
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 备餐异常，订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                //todo 吴丽丽产品的特殊需求
                result[0] = "[请核销此订单]" + responseData.resultMessage;
                return false;
            }
        });
        return result[0];
    }


    /**
     * 商户退款
     *
     * @param orderId
     * @param fsSellNo
     * @param merchant_id
     * @param no
     * @param reason
     * @param userDBModel
     * @return
     */
    public static String refundOrder(String orderId, String fsSellNo, String merchant_id, String no, String reason, UserDBModel userDBModel) {

        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];

        orderApi.refundOrder(orderId, fsSellNo, merchant_id, no, reason, userDBModel, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("退款成功").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  取餐号---->" + no);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString(), "退款用户" + JSON.toJSONString(userDBModel));
                KBPreOrderDBUtils.update(orderId + "", "REFUND");//修改本地订单为退款状态
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑预点单 退款异常，订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                result[0] = responseData.resultMessage;
                return false;
            }
        });
        return result[0];
    }

    /**
     * 商户部分退款
     *
     * @param orderId
     * @param fsSellNo
     * @param merchant_id
     * @param no
     * @param reason
     * @param refundAmount
     * @param userDBModel
     * @return
     */
    public static KBPartRefundExtInfo partRefundOrder(String orderId, String fsSellNo, String merchant_id, String no, String reason, final String refundAmount, UserDBModel userDBModel) {
        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final KBPartRefundExtInfo extInfo = new KBPartRefundExtInfo();

        orderApi.partRefundOrder(orderId, fsSellNo, merchant_id, no, reason, refundAmount, userDBModel, new PreOrderCallback<KBPartRefundReturnResponse>() {
            @Override
            public void onSuccess(KBPartRefundReturnResponse refundReturnResponse) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("部分退款成功").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  取餐号---->" + no + "    退款金额(refundAmount)=" + refundAmount);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString(), "退款用户" + JSON.toJSONString(userDBModel));
                if (refundReturnResponse.errno == 0 && refundReturnResponse.data != null && !TextUtils.isEmpty(refundReturnResponse.data.ext_info)) {
                    JSONObject jsonObject = JSONObject.parseObject(refundReturnResponse.data.ext_info);
                    extInfo.buyer_real_amount = jsonObject.getString("buyer_real_amount");
                    extInfo.out_refund_no = jsonObject.getString("out_refund_no");
                    extInfo.refund_amount = jsonObject.getString("refund_amount");
                    extInfo.refund_real_amount = jsonObject.getString("refund_real_amount");
                    extInfo.errmsg = refundReturnResponse.errmsg;
                } else {
                    RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑预点单 部分退款异常，订单号：" + orderId, "异常信息：" + refundReturnResponse.errmsg);

                }
                KBPreOrderDBUtils.update(orderId + "", "PARTIAL_REFUND");//修改本地订单为退款状态
                extInfo.errmsg = refundReturnResponse.errmsg;
                extInfo.errno = refundReturnResponse.errno;

            }

            @Override
            public void onFailure(int code, String message) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑预点单 部分退款异常，订单号：" + orderId, "异常信息：" + message);
                extInfo.errmsg = message;
                extInfo.errno = code;

            }
        });
        return extInfo;
    }


    //C端用户发起退款  商户拒绝退款
    public static String rejectRefundOrder(String orderId, String fsSellNo, String merchant_id, String no, String rejectReason, UserDBModel userDBModel) {

        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];

        orderApi.rejectRefundOrder(orderId, fsSellNo, merchant_id, no, rejectReason, userDBModel, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("商户拒绝退款").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  取餐号---->" + no);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString(), "商户拒绝退款" + JSON.toJSONString(userDBModel));

                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set payStatus = 'REJECT_REFUND' where  order_id = '" + orderId + "'");
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑预点单 退款异常，订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                result[0] = responseData.resultMessage;
                return false;
            }
        });
        return result[0];
    }


    // C端用户发起退款 商户同意退款
    public static String agreenRefundOrder(String orderId, String fsSellNo, String merchant_id, String no, String agreeRefundReason, UserDBModel userDBModel) {

        KBPreOrderApi orderApi = new KBPreOrderApi();
        //改变订单的状态
        final String[] result = new String[1];

        orderApi.agreenRefundOrder(orderId, fsSellNo, merchant_id, no, agreeRefundReason, userDBModel, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("商户同意退款").append("订单详情 orderId-->" + orderId).append("   商户ID-->" + merchant_id).append("  取餐号---->" + no);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, stringBuilder.toString(), "商户同意退款" + JSON.toJSONString(userDBModel));

                //KBPreOrderDBUtils.update(orderId + "", "REFUND");
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set payStatus = 'ACCEPT_REFUND' where  order_id = '" + orderId + "'");
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑预点单 退款异常，订单号：" + orderId, "异常信息：" + responseData.resultMessage);
                result[0] = responseData.resultMessage;
                return false;
            }
        });
        return result[0];
    }

    /**
     * 超时打款口碑自动驳回退款
     *
     * @param data RapidGetModel
     */
    public static String pushRejectRefund(RapidGetModel data) {
        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "当前模式不是口碑美小易店铺 不做处理--> 推送 超时打款口碑自动驳回退款 ： ", JSON.toJSONString(data));
            return "";
        }

        JSONObject object = JSONObject.parseObject(data.fstdata);
        KBPreOrderCache preOrderCache = JSON.parseObject(object.getString("data"), KBPreOrderCache.class);

        LogUtil.log("推送超时打款口碑自动驳回退款-->" + JSON.toJSONString(preOrderCache));
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送超时打款口碑自动驳回退款", JSON.toJSONString(preOrderCache));
        //todo checkOperation luoshenghua.
        KBPreOrderDBUtils.insert(preOrderCache, false);
        return "";
    }

}