package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideDtlBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuitemsetsideDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/22.
 */

public class MenuPackageSetSideDBUtils {

    public static List<MenuPackageSetSideBean> queryMenuPackageSetSidesByMenuId(String fiItemCd) {
        String sql = "select fiSetFoodCd,fsSetFoodName,fiSetFoodQty,fiStatus from tbmenuitemsetside where fistatus=1 AND fiItemCd_M='" + fiItemCd + "'";
        List<MenuPackageSetSideBean> menuitemsetsideDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuPackageSetSideBean.class);
        if (!ListUtil.isEmpty(menuitemsetsideDBModels)) {
            for (int i = 0; i < menuitemsetsideDBModels.size(); i++) {
                //todo  陈仁敏产品要求 预点单餐盒费不做显示
                String choiceMenuItemIdsSql = "SELECT tbmenuitemsetsidedtl.fiSetFoodCd,tbmenuitemsetsidedtl.fiItemCd_M,tbmenuitem.fiItemCd,tbmenuitem.fsItemName,tbmenuitemsetsidedtl.fiOrderUintCd,tbmenuitemsetsidedtl.fdSaleQty  from   tbmenuitemsetsidedtl  INNER JOIN tbmenuitem ON tbmenuitem.fiItemCd=tbmenuitemsetsidedtl.fiItemCd where tbmenuItem.fsItemName != '预点单餐盒费' and tbmenuitemsetsidedtl.fiStatus=1  and fiSetFoodCd='" + menuitemsetsideDBModels.get(i).fiSetFoodCd + "' and fiItemCd_m='" + fiItemCd + "'";
                menuitemsetsideDBModels.get(i).choiceMenuItems = DBSimpleUtil.queryList(APPConfig.DB_MAIN, choiceMenuItemIdsSql, MenuPackageSetSideDtlBean.class);
                if (menuitemsetsideDBModels.get(i).choiceMenuItems == null) {
                    menuitemsetsideDBModels.get(i).choiceMenuItems = new ArrayList<>();
                } else {
                    menuitemsetsideDBModels.get(i).fsSetFoodNameMenuItemDtal = buildName(menuitemsetsideDBModels.get(i).choiceMenuItems);
                }
            }
        }
        return menuitemsetsideDBModels;
    }


    /**
     * 构建套餐分组  菜品名称
     *
     * @param choiceItems
     * @return
     */
    private static String buildName(List<MenuPackageSetSideDtlBean> choiceItems) {
        StringBuilder name = new StringBuilder();
        if (choiceItems != null) {
            for (int i = 0; i < choiceItems.size(); i++) {
                name.append(choiceItems.get(i).fsItemName);
                if (i != choiceItems.size() - 1) {
                    name.append(",");
                }
            }
        }
        return name.toString();
    }


    public static void deleteMenuItemSetSide(String fiSetFoodCd) {
        //先删菜品组成项菜品关联
        MenuPackageSetSideDtlDBUtils.deleteBySetSideCd(fiSetFoodCd);
        MenuitemsetsideDBModel menuitemsetsideDBModel = queryById(fiSetFoodCd);
        menuitemsetsideDBModel.fiStatus = 13;
        menuitemsetsideDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemsetsideDBModel.sync = 1;
        menuitemsetsideDBModel.replaceNoTrans();
        MetaDBController.updateSyncTime();
    }

    public static MenuitemsetsideDBModel queryById(String fiSetFoodCd) {
        String sql = "select * from tbmenuitemsetside where fiSetFoodCd='" + fiSetFoodCd + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuitemsetsideDBModel.class);
    }

    /**
     * 批量添加套餐组
     *
     * @param ds
     * @param userDBModel
     * @param shopId
     */
    public static void addMenuPackageSetSide(ArrayList<MenuPackageSetSideBean> ds, UserDBModel userDBModel, String shopId) {
        if (!ListUtil.isEmpty(ds)) {
            for (MenuPackageSetSideBean d : ds) {
                addMenuPackageSetSide(d, userDBModel, shopId);
            }
        }
    }

    /**
     * 新增套餐组成项
     *
     * @param d
     * @param userDBModel
     * @param shopId
     */
    public static void addMenuPackageSetSide(MenuPackageSetSideBean d, UserDBModel userDBModel, String shopId) {
        d.fiSetFoodCd = String.valueOf(IDHelper.generateFiSetFoodCd());
        MenuitemsetsideDBModel menuitemsetsideDBModel = new MenuitemsetsideDBModel();
        menuitemsetsideDBModel.fiItemCd_M = d.fiItemCd_M;
        menuitemsetsideDBModel.fiSetFoodCd = d.fiSetFoodCd;
        menuitemsetsideDBModel.fiIsRequired = d.fiIsRequired;
        menuitemsetsideDBModel.fiSetFoodType = d.fiSetFoodType;
        menuitemsetsideDBModel.fsSetFoodName = d.fsSetFoodName;
        menuitemsetsideDBModel.fiSetFoodQty = d.fiSetFoodQty;
        menuitemsetsideDBModel.fsShopGUID = shopId;
        menuitemsetsideDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            menuitemsetsideDBModel.fsUpdateUserId = userDBModel.fsUserId;
            menuitemsetsideDBModel.fsUpdateUserName = userDBModel.fsUserName;
        }
        menuitemsetsideDBModel.fiStatus = 1;
        menuitemsetsideDBModel.fiDataSource = 1;
        menuitemsetsideDBModel.sync = 1;
        menuitemsetsideDBModel.replaceNoTrans();
        //存套餐组成项内菜品
        if (!ListUtil.isEmpty(d.choiceMenuItems)) {
            for (MenuPackageSetSideDtlBean choiceMenuItem : d.choiceMenuItems) {
                choiceMenuItem.fiSetFoodCd = d.fiSetFoodCd;
                choiceMenuItem.fiItemCd_M = d.fiItemCd_M;
                MenuPackageSetSideDtlDBUtils.addMenuPackageSetSideDtl(choiceMenuItem, userDBModel, shopId);
            }
        }
    }

    public static void updateMenuPackageSetSide(String fiSetFoodCd, int fiSetFoodQty, String fsSetFoodName) {
        MenuitemsetsideDBModel menuitemsetsideDBModel = queryById(fiSetFoodCd);
        menuitemsetsideDBModel.fiSetFoodQty = fiSetFoodQty;
        menuitemsetsideDBModel.fsSetFoodName = fsSetFoodName;
        menuitemsetsideDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemsetsideDBModel.sync = 1;
        menuitemsetsideDBModel.replaceNoTrans();
    }

    public static void deleteMenuItemSetSideByPackageId(String packageId) {
        String deleteSetSideDtl = "update  tbmenuitemsetside set fiStatus=13, fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1  WHERE fiItemCd_M='" + packageId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, deleteSetSideDtl);
        MenuPackageSetSideDtlDBUtils.deleteByPackageId(packageId);
    }
}
