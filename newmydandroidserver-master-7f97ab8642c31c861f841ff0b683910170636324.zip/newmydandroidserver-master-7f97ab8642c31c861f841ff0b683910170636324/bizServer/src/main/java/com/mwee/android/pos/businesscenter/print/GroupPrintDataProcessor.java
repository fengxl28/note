package com.mwee.android.pos.businesscenter.print;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/5/10.
 */
public class GroupPrintDataProcessor {
    /**
     * 制作部门对应的传菜部门列表，临时缓存用
     */
    ArrayMap<String, List<DeptDBModel>> makeToTans = new ArrayMap<>();
    /**
     * 餐区对应的传菜部门列表，临时缓存用
     */
    ArrayMap<String, List<DeptDBModel>> areaToTans = new ArrayMap<>();
    /**
     * 数据源，菜品列表
     */
    private List<PrintItemDataBean> itemList = new ArrayList<>();
    /**
     * 查询部门的时候，是否查询制作部门
     */
    private boolean withDeptMake = false;
    /**
     * 查询部门的时候，是否将当前站点也构建为一个部门并put到结果集里。
     */
    private boolean withCurrentHost = false;

    /**
     * 站点ID
     */
    private String currentHostID = "";
    /**
     * 查询部门的时候，是否查询传菜部门
     */
    private boolean withDeptTransfer = false;
    /**
     * 结果集：当前对应的部门
     */
    public Map<String, DeptDBModel> deptInfo = new ArrayMap<>();
    /**
     * 结果集：当前对应的部门-菜品集合
     */
    public Map<String, List<PrintItemDataBean>> result = new ArrayMap<>();
    /**
     * 餐区ID
     */
    private String fsMareaID = "";
    /**
     * 判断餐区
     */
    private boolean withArea = false;

    /**
     * 一个订单中需要标签打印机打印的总份数
     */
    public int tscCount = 0;  //标签打印菜品总数

    private GroupPrintDataProcessor() {

    }

    public static Builder createBuilder() {
        return new Builder();
    }

    public static class Builder {
        private GroupPrintDataProcessor instance;

        private Builder() {
            instance = new GroupPrintDataProcessor();
        }

        /**
         * 是否查询制作部门
         *
         * @param withDeptMake boolean
         * @return Builder
         */
        public Builder setWithDeptMake(boolean withDeptMake) {
            instance.withDeptMake = withDeptMake;
            return this;
        }

        /**
         * 是否包含当前站点
         *
         * @param withCurrentHost boolean
         * @return Builder
         */
        public Builder setWithCurrentHost(boolean withCurrentHost) {
            instance.withCurrentHost = withCurrentHost;
            return this;
        }

        /**
         * 是否包含当前站点
         *
         * @param currentHostId String | 站点ID
         * @return Builder
         */
        public Builder setCurrentHostId(String currentHostId) {
            instance.currentHostID = currentHostId;
            return this;
        }

        /**
         * 是否包含传菜部门
         *
         * @param withCurrentHost boolean
         * @return Builder
         */
        public Builder setWithDeptTransfer(boolean withCurrentHost) {
            instance.withDeptTransfer = withCurrentHost;
            return this;
        }

        /**
         * 设置数据列表
         *
         * @param itemList List<PrintItemDataBean>
         * @return Builder
         */
        public Builder setItemList(List<PrintItemDataBean> itemList) {
            instance.itemList.addAll(itemList);
            return this;
        }

        /**
         * 添加一个菜品
         *
         * @param item PrintItemDataBean
         * @return Builder
         */
        public Builder addItem(PrintItemDataBean item) {
            instance.itemList.add(item);
            return this;
        }

        /**
         * 设置当前对应的餐区
         *
         * @param areaID String
         * @return Builder
         */
        public Builder setTableAreaID(String areaID) {
            instance.fsMareaID = areaID;
            return this;
        }

        /**
         * 是否跟随餐区一起判断
         *
         * @param checkArea boolean
         * @return Builder
         */
        public Builder setCheckArea(boolean checkArea) {
            instance.withArea = checkArea;
            return this;
        }

        /**
         * 开始归集数据
         *
         * @return GroupPrintItemProcessor
         */
        public GroupPrintDataProcessor build() {
            instance.groupMenuList(instance.itemList);
            return instance;
        }
    }

    /**
     * 归集单个菜品。
     * 需要处理菜品里的SLIT列表，通常，这个列表表示的是套餐的套餐类菜品
     *
     * @param sellOrderItemDBModel PrintItemDataBean
     */
    private void groupMenuItem(PrintItemDataBean sellOrderItemDBModel) {
        if (sellOrderItemDBModel == null) {
            return;
        }
        List<DeptDBModel> deptList = new ArrayList<>();
        List<DeptDBModel> makeDeptList = new ArrayList<>();

        //先归集套餐类菜品
        if (!ListUtil.isEmpty(sellOrderItemDBModel.SLIT)) {
            for (PrintItemDataBean temp : sellOrderItemDBModel.SLIT) {
                groupMenuItem(temp);
            }
        }
        String itemCd = sellOrderItemDBModel.fiItemCd;
        if (sellOrderItemDBModel.fiOrderItemKind == 4 &&
                !TextUtils.isEmpty(sellOrderItemDBModel.ingredientFatherItemCd) && StringUtil.toInt(sellOrderItemDBModel.ingredientFatherItemCd, 0) > 0) {
            itemCd = sellOrderItemDBModel.ingredientFatherItemCd;
        }
        //判断是否多部门打印
        if (sellOrderItemDBModel.fiIsMulDept == 1) {
            if (withArea && !TextUtils.isEmpty(fsMareaID)) {
                makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + itemCd + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMareaID + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')", DeptDBModel.class);
            } else {
                makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + itemCd + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' ) ", DeptDBModel.class);
            }
        } else {
            DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + sellOrderItemDBModel.fsDeptId + "'", DeptDBModel.class);
            if (dept != null) {
                makeDeptList.add(dept);
            } else {
                List<DeptDBModel> dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fistatus = '1' and fiPrintDishes = '1' ", DeptDBModel.class);
                if (!ListUtil.isEmpty(dbModels)) {
                    makeDeptList.addAll(dbModels);
                }
            }
        }

        //air2.1需求 根据菜品分类查询制作部门
        if (ListUtil.isEmpty(makeDeptList)) {
            String fsMenuClsId = sellOrderItemDBModel.fsMenuClsId;
            if (sellOrderItemDBModel.fiIsMulDept == 1) {
                if (withArea && !TextUtils.isEmpty(fsMareaID)) {
                    makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' and (fsMareaID=''  or fsMareaID is null or fsMareaID='" + fsMareaID + "') union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' )", DeptDBModel.class);
                } else {
                    makeDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fiStatus = '1' and fsDeptId in (select fsDeptId from tbmenuClsMuldept where fiStatus = '1' and fsMenuClsId = '" + fsMenuClsId + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1')", DeptDBModel.class);
                }
            } else {
                DeptDBModel dept = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fiStatus = '1' and fsDeptId='" + sellOrderItemDBModel.fsDeptId + "'", DeptDBModel.class);
                if (dept != null) {
                    makeDeptList.add(dept);
                } else {
                    List<DeptDBModel> dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fistatus = '1' and fiPrintDishes = '1' ", DeptDBModel.class);
                    if (!ListUtil.isEmpty(dbModels)) {
                        makeDeptList.addAll(dbModels);
                    }
                }
            }
        }
        if (makeDeptList == null) {
            makeDeptList = new ArrayList<>();
        }

        //处理传菜部门
        List<DeptDBModel> transDeptList = null;
        List<DeptDBModel> areaDeptList = null;

        if (withDeptTransfer) {
            transDeptList = makeToTans.get(sellOrderItemDBModel.fsDeptId);
            if (transDeptList == null) {
                StringBuilder sbMake = new StringBuilder();
                for (DeptDBModel temp : makeDeptList) {
                    if (temp == null) {
                        continue;
                    }
                    sbMake.append(temp.fsDeptId).append(",");
                }
                if (sbMake.length() > 0) {
                    sbMake.deleteCharAt(sbMake.length() - 1);
                }
                String sql = "select * from tbDept where fiStatus = '1' and fiTransferSource = '0' and fsDeptId in (select fsDeptId_Transfer from  tbTransferPrn where fsDeptId_Make in(" + sbMake.toString() + ") and fiStatus='1' and fiDeptCls in (0,1))";
                transDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DeptDBModel.class);
                if (!ListUtil.isEmpty(transDeptList)) {
                    makeToTans.put(sellOrderItemDBModel.fsDeptId, transDeptList);
                }
            }

            areaDeptList = areaToTans.get(fsMareaID);
            if(areaDeptList == null){
                String sql = "select * from tbDept where fiStatus = '1' and fiTransferSource = '1' and fsDeptId in (select fsDeptId_Transfer from  tbtransferarea where fiStatus='1' and fsMAreaId_Make = '"+fsMareaID+"')";
                areaDeptList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DeptDBModel.class);
                if (!ListUtil.isEmpty(areaDeptList)) {
                    areaToTans.put(fsMareaID, areaDeptList);
                }
            }
        }

        /**
         * 如果不需要处理制作部门，这里将原来的制作部门清空
         */
        if (withDeptMake && !ListUtil.isEmpty(makeDeptList)) {
            deptList.addAll(makeDeptList);
            numbringTcsMenu(makeDeptList, sellOrderItemDBModel);
        }
        if (withDeptTransfer) {
            if(!ListUtil.isEmpty(transDeptList)){
                deptList.addAll(transDeptList);
            }
            if(!ListUtil.isEmpty(areaDeptList)){
                deptList.addAll(areaDeptList);
            }
        }
        for (DeptDBModel temp : deptList) {
            deptInfo.put(temp.fsDeptId, temp);
            putItemToMap(temp.fsDeptId, result, sellOrderItemDBModel);
        }
    }

    /**
     * 标签菜品计数
     *
     * @param deptList
     * @param sellOrderItemDBModel
     */
    private void numbringTcsMenu(List<DeptDBModel> deptList, PrintItemDataBean sellOrderItemDBModel) {
        for (DeptDBModel deprecated : deptList) {
            if (deprecated == null) {
                continue;
            }
            PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(deprecated.fsDeptId);
            if (printer == null) {
                continue;
            }

            if ("TSC".equalsIgnoreCase(printer.fsCommandType)) {  //是标签打印机才会给菜品编号
                try {
                    sellOrderItemDBModel.lastTscIndex = tscCount;
                    //是否可改数(称重);0/1;为1=ture时,份数为1
                    int count = sellOrderItemDBModel.fiIsEditQty == 1 ? 1 : sellOrderItemDBModel.fdSaleQty.intValue();
                    tscCount += count;
                } catch (Exception e) {
                    tscCount += 1;
                }

                break;
            }
        }
    }


    /**
     * 将数据分组
     *
     * @param sellOrderItemDBModels 数据源---下单菜品
     */
    private void groupMenuList(List<PrintItemDataBean> sellOrderItemDBModels) {
        for (PrintItemDataBean sellOrderItemDBModel : sellOrderItemDBModels) {
            groupMenuItem(sellOrderItemDBModel);
        }
        if (withCurrentHost) {
            result.put("0", sellOrderItemDBModels);
            //根据站点ID，构造一个特殊的部门，
            DeptDBModel model = new DeptDBModel();
            model.fsDeptId = "0";
            //站点部门默认打总单
            model.fiIsOneItemCut = 2;
            if (TextUtils.isEmpty(currentHostID)) {
                currentHostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            }
            model.fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsPrinterName FROM tbhost where fsHostId='" + currentHostID + "'");
            model.fiStatus = 1;
            model.fsDeptName = "站点[" + currentHostID + "]";
            deptInfo.put("0", model);
        }
    }


    public static void putItemToMap(String deptId, Map<String, List<PrintItemDataBean>> result, PrintItemDataBean sellOrderItemDBModel) {
        if (!TextUtils.isEmpty(deptId)) {
            List<PrintItemDataBean> sellOrderItemDBModelList = result.get(deptId);
            if (sellOrderItemDBModelList == null) {
                sellOrderItemDBModelList = new ArrayList<>();
                result.put(deptId, sellOrderItemDBModelList);
            }
            sellOrderItemDBModelList.add(sellOrderItemDBModel);
        }
    }
}
