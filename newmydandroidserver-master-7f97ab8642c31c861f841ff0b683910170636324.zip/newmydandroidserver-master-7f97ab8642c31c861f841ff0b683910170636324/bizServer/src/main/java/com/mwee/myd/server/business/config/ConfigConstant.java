package com.mwee.myd.server.business.config;

import android.content.Context;

import java.io.File;

/**
 * @ClassName: ConfigConstant
 * @Description:
 * @author: SugarT
 * @date: 2017/8/24 上午11:10
 */
public class ConfigConstant {

    /**
     * 配置文件夹名称
     */
    public static final String ConfigDirName = "MwConfig";

    /**
     * 默认的配置文件名
     */
    public static final String ConfigFileName = "MydConfig";

    /**
     * Lua 脚本文件夹
     */
    public static final String LuaDirName = "MwLua";

    /**
     * 支持开卡功能的门店列表文件名
     */
    public static final String CONFIG_FILE_NAME_BIND_CARD = "BindCardShopInfo";

    /**
     * 获取配置文件的文件路径
     *
     * @param context
     * @return
     */
    public static String getConfigDirPath(Context context) {
        return context.getExternalCacheDir().getPath() + File.separator + ConfigDirName + File.separator;
    }

    /**
     * Lua 脚本文件路径
     *
     * @param context
     * @return
     */
    public static String getLuaDirPath(Context context) {
        return context.getExternalCacheDir().getPath() + File.separator + LuaDirName + File.separator;
    }
}
