package com.mwee.android.pos.businesscenter.business.koubei.future;

import com.mwee.android.air.db.business.kbbean.future.KBFuturePushSignRequest;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.db.APPConfig;

/**
 * Created by zhangmin on 2018/10/13.
 */

public class KBFutureUserActionApi implements IKBFutureUserActionListener {

    @Override
    public void loadFutureTempOrderHeader(int pageIndex, String orderId, String status, BusinessCallback businessCallback) {

        KBFutureTempDataRequest request = new KBFutureTempDataRequest();
        request.pageIndex = pageIndex;
        request.orderId = orderId;
        request.pageSize = 20;
        //todo 接口空的时候 不能传空字符串 需要传null
        request.status = status;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);

    }


    @Override
    public void acceptFutureOrder(String orderId, String batchNo, String outBizNo, BusinessCallback businessCallback) {
        KBFuturePushSignRequest request = new KBFuturePushSignRequest();
        request.orderId = orderId;
        request.batchNo = batchNo;
        request.outBizNo = outBizNo;
        request.receiptCode = "RECEIPT";
        if (APPConfig.isMyd()) {
            request.sourceType = KBFuturePushSignRequest.SourceType.MYD;
        } else {
            request.sourceType = KBFuturePushSignRequest.SourceType.MXY;
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);


    }

    @Override
    public void rejectFutureOrder(String order_id, String batchNo, String rejectReason, BusinessCallback businessCallback) {

        KBFuturePushSignRequest request = new KBFuturePushSignRequest();
        request.orderId = order_id;
        request.batchNo = batchNo;
        request.receiptCode = "REJECT";
        switch (rejectReason.trim()) {
            case "桌号不存在,请联系服务员":
                request.rejectReasonCode = "TABLE_NOT_EXIST";
                break;
            case "店铺太忙,无法接待":
                request.rejectReasonCode = "BUSY";
                break;
            case "重复订单":
                request.rejectReasonCode = "DUPLICATE_ORDER";
                break;
            case "店铺已打烊":
                request.rejectReasonCode = "SHOP_CLOSE";
                break;
            case "菜品售完":
                request.rejectReasonCode = "SELL_OUT";
                break;
            case "其他原因":
                request.rejectReasonCode = "OTHER_REASON";
                break;
            default:
                request.rejectReasonCode = "OTHER_REASON";
                break;
        }

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);

    }
}
