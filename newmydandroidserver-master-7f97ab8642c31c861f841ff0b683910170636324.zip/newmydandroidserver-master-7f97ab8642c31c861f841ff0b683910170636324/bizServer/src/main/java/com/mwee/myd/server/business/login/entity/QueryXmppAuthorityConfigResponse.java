package com.mwee.myd.server.business.login.entity;


import com.mwee.android.base.net.BaseResponse;
import com.mwee.android.base.net.BusinessBean;

/**
 * Created by hm on 2018/7/16.
 *
 */
public class QueryXmppAuthorityConfigResponse extends BaseResponse {

    public long elapsedMilliseconds;
    public String traceId;
    public boolean success;
    public ConfigData data;

    public class ConfigData extends BusinessBean {

        public ConfigData(){}

        public String lastTime;
        public String shellEnable;
        public String createTime;
    }

}
