package com.mwee.myd.server.business.login.entity;

import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.tools.StringUtil;

/**
 * Created by me2 on 2016/12/13.
 */

@HttpParam(httpType = HttpType.POST,
        method = "modifyXmppState",
        response = BasePosResponse.class,
        contentType = "application/json",
        serializeType = SerializeType.Json,
        encodeType = StringUtil.CHARSET_UTF8)
public class UploadXmppStateRequest extends BasePosRequest {

    public String state = "0";

    public UploadXmppStateRequest() {
    }

}
