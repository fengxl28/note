package com.mwee.android.pos.businesscenter.print;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by virgil on 2017/1/22.
 */

public class PrintJSONBuilder {

    public static PrintTaskDBModel buildPrintTask(String orderID, String mealNO, String businessDate, int printNO, String userName, String deptID, String reportID) {
        return buildPrintTask(orderID, mealNO, businessDate, printNO, userName, deptID, reportID, DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID), true);
    }

    /**
     * @param orderID      订单号
     * @param mealNO
     * @param businessDate 营业日期
     * @param printNO      印号
     * @param userName     服务员名称
     * @param deptID       部门ID
     * @param reportID
     * @param hostId       站点ID
     * @param printAtOnce  是否立即打印 | Boolean true: 立即打印； false:不打印
     * @return
     */
    public static PrintTaskDBModel buildPrintTask(String orderID, String mealNO, String businessDate, int printNO, String userName, String deptID, String reportID,
                                                  @NonNull String hostId, boolean printAtOnce) {
        PrintTaskDBModel taskDBModel = PrintTaskDBModel.Creater.newInstance()
                .setCreateUserName(userName)
                .setHostId(hostId)
                .setDeptId(deptID)
                .setDeptName(TextUtils.isEmpty(deptID) ? "" : DeviceDBUtil.getDeptNameByDeptID(deptID))
                .setCreateTime(DateUtil.getCurrentTime())
                .setSellNo(orderID)
                .setOtherNo(mealNO)
                .setDate(!businessDate.contains("-") ? DateUtil.formartDateStrToTarget(businessDate, "yyyyMMdd", "yyyy-MM-dd") : businessDate)
                .setPrintNo(printNO)
                .setReportId(reportID)
                .setPrintAtOnce(printAtOnce)
                .setReportName(getReportNameByID(reportID))
                .build();
        taskDBModel.fiTaskType = 1;
        taskDBModel.fiPrnDataType = 2;
        return taskDBModel;
    }

    public static String getReportNameByID(String reportID) {
        if (TextUtils.isEmpty(reportID)) {
            return "";
        }
        String reportName = "";
        switch (reportID) {
            case PrintReportId.RAPID_ORDERED_CONFIRM_MENU:
                reportName = "秒点确认单";
                break;
            case PrintReportId.NETWORK_TAKEOUT_RECEIPT:
                reportName = "外卖结账单";
                break;
            case PrintReportId.NETWORK_KDS_RECEIPT:
                reportName = "外卖制作单";
                break;
            case PrintReportId.NETWORK_PASSTO_RECEIPT:
                reportName = "外卖传菜单";
                break;
            case PrintReportId.NETWORK_CUSTOM_RECEIPT:
                reportName = "外卖客户联";
                break;
            case PrintReportId.RAPID_BOOK_ORDERED:
                reportName = "秒点预定单";
                break;
            case PrintReportId.WECHAT_ORDER_ORDER:
                reportName = "微信外卖制作单";
                break;
            case PrintReportId.WECHAT_ORDER_RECEIPT:
                reportName = "微信外卖结账单";
                break;
            case PrintReportId.WECHAT_REPORT:
                reportName = "微信外卖报表";
                break;
            case PrintReportId.NET_ORDER_REPORT:
                reportName = "外卖报表";
                break;
            case PrintReportId.WECHAT_FAST_FOOD:
                reportName = "微信快餐";
                break;
            case PrintReportId.CHECK_BY_DAY:
                reportName = "收款明细表";
                break;
            case PrintReportId.TIME_REPORT:
                reportName = "时段统计表";
                break;
            case PrintReportId.ORDERED_MENU_PRE:
                reportName = "点菜预览单";
                break;
            case PrintReportId.SELLOUT_DETAIL:
                reportName = "沽清明细";
                break;
            case PrintReportId.PRE_PAY:
                reportName = "预付金小票";
                break;
            case PrintReportId.KOBEI_PRE_ORDER_CUSTOMER:
                reportName = "口碑点餐客户联";
                break;
            case PrintReportId.KOBEI_PRE_ORDER_MAKE:
                reportName = "口碑点餐制作单";
                break;
            case PrintReportId.KOBEI_PRE_ORDER_SHOP:
                reportName = "口碑点餐商户联";
                break;
            case PrintReportId.MAKE_THE_SINGLE:
                reportName = "制作单一份一切";
                break;
            case PrintReportId.ALL_DISCOUNT_REPORT:
                reportName = "折扣汇总表";
                break;
            case PrintReportId.INGREDIENT:
                reportName = "配料单";
                break;
            case PrintReportId.PACKAGE_ITEM:
                reportName = "套餐子项单";
                break;
            case PrintReportId.BILL_REMAIN:
                reportName = "结账单(留存)";
                break;
            case PrintReportId.MEITUAN_NET_ORDER:
                reportName = "美团外卖订单报表";
                break;
            case PrintReportId.MANUAL_E_INVOICE:
                reportName = "手动纯开票";
                break;
            case PrintReportId.BUNDLE_NUM:
                reportName = GlobalCache.getContext().getString(R.string.bundle_all_sale);
                break;
            case PrintReportId.SALE_CLS_NUM:
                reportName = GlobalCache.getContext().getString(R.string.sale_class_num);
                break;
            case PrintReportId.INCOME_CLS_NUM:
                reportName = GlobalCache.getContext().getString(R.string.income_class_num);
                break;
            case PrintReportId.SURCHARGE_DETAIL:
                reportName = GlobalCache.getContext().getString(R.string.surcharge_detail);
                break;
            case PrintReportId.MEMBER_CHARGE_DATA:
                reportName = GlobalCache.getContext().getString(R.string.member_charge_data);
                break;
            default:
                reportName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsReportName FROM tbreport where fsReportId='" + reportID + "'");
        }
        return reportName;
    }

    /**
     * 拿一个PrintNO出来
     *
     * @return int
     */
    public synchronized static int generatePrintNO() {
        int id = StringUtil.toInt(DBMetaUtil.getSettingsValueByKey(META.PRINT_NO), 0);
        id++;
        //如果打印序号大于30万，则重置为1
        if (id > 300 * 1000) {
            id = 1;
        }
        DBMetaUtil.updateSettingsValueByKey(META.PRINT_NO, id);

        return id;
    }

}
