package com.mwee.android.pos.businesscenter.koubei;

/**
 * 处理接单task
 * Created by qinwei on 2018/5/16.
 */

public class PreOrderTakeTask {
    private String orderMessage;
    private OnPreOrderAutoTakeTaskListener listener;
    public int retryCount;

    public PreOrderTakeTask(String orderMessage) {
        this.orderMessage = orderMessage;
        retryCount = 3;
    }

    public void start() {
        //存数据库
        PreOrderDBController.addOrUpdate(orderMessage);
        PreOrderApi.loadPreOrderTake(orderMessage, new PreOrderCallback<String>() {
            @Override
            public void onSuccess(String result) {
                //TODO 入报表
//                OrderProcessor.saveOrder()
                //TODO 通知UI更新
//                notice ui update
            }

            @Override
            public void onFailure(int code, String message) {
                if (retryCount > 0) {
                    retryCount--;
                    start();
                }
            }
        });
    }

    public void setOnPreOrderAutoTakeTaskListener(OnPreOrderAutoTakeTaskListener listener) {
        this.listener = listener;
    }

    public interface OnPreOrderAutoTakeTaskListener {
        void onCompleted(String orderId);
    }
}
