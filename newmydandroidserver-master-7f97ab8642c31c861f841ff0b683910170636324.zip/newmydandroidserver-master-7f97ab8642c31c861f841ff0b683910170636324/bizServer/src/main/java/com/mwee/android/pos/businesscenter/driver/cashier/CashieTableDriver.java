package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.table.AirTableManageInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.TableManagerDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;

/**
 * @Description: 美收银桌台
 * @author: Xiaolong
 * @Date: 2018/8/1
 */
@SuppressWarnings("unused")
public class CashieTableDriver implements IDriver {
    private static final String TAG = "cashierTable";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 获取所有餐桌信息--桌台首页
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAllMtable")
    public SocketResponse optAllMtable(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        response.data = new ArrayList<MtableDBModel>();
        try {
            response.data = TableManagerDBUtil.getTable("");
            response.code = SocketResultCode.SUCCESS;
            response.buildMessage();

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 获取所有桌台信息--管理桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAllTable")
    public SocketResponse optAllTable(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        response.data = new ArrayList<AirTableManageInfo>();
        try {
            response.data = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.buildMessage();

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 新增桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyAddTable")
    public SocketResponse msyAddTable(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            response.code = SocketResultCode.USER_SESSION_EXPIRED;
            response.message = "登录信息已过期";
            return response;
        }
        response.data = new ArrayList<AirTableManageInfo>();
        try {
            JSONObject request = JSON.parseObject(param);
            ArrayList<String> tables = (ArrayList<String>) JSON.parseArray(request.getString("tableNameList"), String.class);
            if (tables == null || tables.size() < 1) {
                response.message = "请输入有效桌台名称";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            ArrayList<MtableDBModel> mtableDBModels = new ArrayList<>();
            for (String table : tables) {
                String errMsg = TableManagerDBUtil.addTable(mtableDBModels, "1", table, 10, userDBModel);
                if (!TextUtils.isEmpty(errMsg)) {
                    response.message = errMsg;
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    return response;
                }
            }
            response.data = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.buildMessage();
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 删除桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyDeleteTable")
    public SocketResponse msyDeleteTable(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        response.data = new ArrayList<AirTableManageInfo>();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayList<String> tableIdList = (ArrayList<String>) JSON.parseArray(request.getString("tableIdList"), String.class);
            if (ListUtil.isEmpty(tableIdList)) {
                response.message = "请选择要删除的桌台";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.batchDeleteTable(tableIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            response.data = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

}
