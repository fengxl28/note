package com.mwee.myd.server.slave;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName: ReplicationDBUtil
 * @Description:
 * @author: SugarT
 * @date: 2018/5/3 下午5:43
 */
public class ReplicationDBUtil {

    public static boolean checkIntegrity(String originDB, String targetDB, String date) {
        boolean result = true;
        if (!checkIntegrity(originDB, targetDB, date, "tbSell")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellOrder")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellOrderItem")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellReceive")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellCheck")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellCoupon")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellOrderItemNote")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "tbSellPickMenuitem")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "order_cache")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "order_menu_cache")) {
            return false;
        }
        if (!checkIntegrity(originDB, targetDB, date, "order_pay_cache")) {
            return false;
        }
        return result;
    }

    /**
     * 校验从库的表数据完整性
     *
     * @param originDB
     * @param targetDB
     * @param date      日期
     * @param tableName 表名
     * @return
     */
    public static boolean checkIntegrity(String originDB, String targetDB, String date, String tableName) {
        if (TextUtils.isEmpty(originDB) || TextUtils.isEmpty(targetDB)) {
            return false;
        }
        if (TextUtils.isEmpty(tableName)) {
            return false;
        }

        boolean result = true;
        if (SlaveConstant.usePrimaryKeySellNo(tableName)) {
            result = checkIntegrityWithOrder(originDB, targetDB, tableName, date);
        } else if (SlaveConstant.useDateKeyBusinessDate(tableName)) {
            result = checkIntegrityWithSell(originDB, targetDB, tableName, date);
        } else {
            result = checkIntegrityWithMenuCache(originDB, targetDB, date);
        }
        return result;
    }

    /**
     * 校验 tbSell, tbSellOrder, tbSellOrderItem, tbSellReceive, tbSellCheck, tbSellCoupon, tbSellOrderItemNote,
     * tbSellPickMenuitem 表数据完整性
     *
     * @param originDB
     * @param targetDB    数据库名称
     * @param tableName 表名
     * @param date      日期
     * @return
     */
    private static boolean checkIntegrityWithSell(String originDB, String targetDB, String tableName, String date) {
        String countSQL = "SELECT count(*) FROM %s WHERE fsSellDate = '%s'";
        countSQL = String.format(countSQL, tableName, date);

        // 主库中记录数
        String mainCount = DBSimpleUtil.queryString(originDB, countSQL);
        // 从库中的记录数
        String slaveCount = DBSimpleUtil.queryString(targetDB, countSQL);

        if (TextUtils.isEmpty(mainCount) && !TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.isEmpty(mainCount) && TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.equals(mainCount, slaveCount)) {
            return false;
        }
        return true;
    }

    /**
     * 校验 order_cache, order_pay_cache 表的数据完整性
     *
     * @param originDB
     * @param targetDB    数据库名称
     * @param tableName 表名
     * @param date      日期
     * @return
     */
    private static boolean checkIntegrityWithOrder(String originDB, String targetDB, String tableName, String date) {
        String countSQL = "SELECT count(*) FROM %s WHERE business_date = '%s'";
        countSQL = String.format(countSQL, tableName, date);

        // 主库中的记录数
        String mainCount = DBSimpleUtil.queryString(originDB, countSQL);
        // 从库中的记录数
        String slaveCount = DBSimpleUtil.queryString(targetDB, countSQL);

        if (TextUtils.isEmpty(mainCount) && !TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.isEmpty(mainCount) && TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.equals(mainCount, slaveCount)) {
            return false;
        }
        return true;
    }

    /**
     * 校验 order_menu_cache 表数据完整性
     * @param originDB
     * @param targetDB    数据库名称
     * @param date
     * @return
     */
    private static boolean checkIntegrityWithMenuCache(String originDB, String targetDB, String date) {
        // 由于 order_menu_cache 表没有营业日期相关字段，只能通过从主库和从库中查出日期相关的所有订单号，才能从 order_menu_cache 中过滤出所有的当日的记录
        String queryOrderIdSQL = "SELECT order_id FROM order_cache WHERE business_date = '" + date + "'";
        List<String> orderIdMain = DBSimpleUtil.queryStringList(originDB, queryOrderIdSQL);
        List<String> orderIdSlave = DBSimpleUtil.queryStringList(targetDB, queryOrderIdSQL);

        if (ListUtil.isEmpty(orderIdMain)) {
            orderIdMain = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(orderIdSlave)) {
            orderIdMain.addAll(orderIdSlave);
        }
        if (ListUtil.isEmpty(orderIdMain)) {
            return true;
        }

        StringBuilder param = new StringBuilder();
        for (int index = 0; index < orderIdMain.size(); index++) {
            String orderId = orderIdMain.get(index);
            if (TextUtils.isEmpty(orderId)) {
                continue;
            }

            if (index > 0) {
                param.append(", ");
            }
            param.append("'");
            param.append(orderId);
            param.append("'");
        }
        String countSQL = "SELECT count(*) FROM order_menu_cache WHERE order_id IN (" + param.toString() + ")";

        String mainCount = DBSimpleUtil.queryString(originDB, countSQL);
        String slaveCount = DBSimpleUtil.queryString(targetDB, countSQL);

        if (TextUtils.isEmpty(mainCount) && !TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.isEmpty(mainCount) && TextUtils.isEmpty(slaveCount)) {
            return false;
        }
        if (!TextUtils.equals(mainCount, slaveCount)) {
            return false;
        }

        return true;
    }

    /**
     * 是否需要进行数据迁移
     *
     * @param date    营业日期 yyyy-MM-dd
     * @return
     */
    public static boolean needReplication(String date) {
        if (TextUtils.isEmpty(date)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#needReplication 日期为空");
            return false;
        }

        String sqlCount = "SELECT count(*) FROM tbSell WHERE fsSellDate = '" + date + "'";
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlCount), 0);
        if (count == 0) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#needReplication Master 库没有[" + date + "]的订单");
            return false;
        }

        String sqlUnUpload = "SELECT count(*) as count FROM tbSell where lver > pver";
        int countUnUpload = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlUnUpload));
        if (countUnUpload > 0) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#needReplication [" + countUnUpload + "]条数据未同步至服务端，暂不迁移");
            return false;
        }
        return true;
    }

    /**
     * 是否可以进行数据迁移
     * 1. 7 天前的数据
     * 2. 相关报表固化完成
     *
     * @param context
     * @param currentDate 当前营业日期
     * @param targetDate  需要迁移数据的营业日期
     * @return
     */
    public static boolean canReplication(Context context, String currentDate, String targetDate) {
        if (context == null) {
            return false;
        }
        if (TextUtils.isEmpty(currentDate) || TextUtils.isEmpty(targetDate)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#canReplication 日期为空");
            return false;
        }
        try {
            // 目标日期距离当前营业日期在 7 日之内
            if (DateUtil.daysBetween(targetDate, currentDate) <= 7) {
                RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#canReplication 7日内的数据不做迁移");
                return false;
            }
            // 报表未完全保存
            if (!DailyReportDBUtil.hasReportSaved(targetDate)) {
                RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#canReplication 报表未完全保存");
                return false;
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#canReplication " + e.getMessage());
            LogUtil.logError(e);
        }
        return true;
    }

    /**
     * 指定营业日期的数据是否需要从 slave 库迁回 master 库
     *
     * @param context
     * @param businessDate 营业日期
     * @return
     */
    public static boolean needMoveBack(Context context, String businessDate) {
        String dbName = SlaveDBUtils.buildDatabaseName(businessDate);

        // 数据库文件不存在
        if (!SlaveDBUtils.checkDBExists(context, dbName)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#needMoveBack 营业日期[" + businessDate + "]对应的数据库文件不存在");
            return false;
        }

        // 数据库中没有数据(数据库数据迁移只做整体的迁移，理论上不该出现仅迁移部分表的情况，所以这里仅判断 tbSell 是否有数据)
        String count = DBSimpleUtil.queryString(dbName, "SELECT count(*) FROM tbSell");
        if (StringUtil.toInt(count) <= 0) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#needMoveBack 营业日期[" + businessDate + "]没有订单数据");
            return false;
        }

        return true;
    }

    /**
     * 数据迁移
     *
     * @param context
     * @param originDB 原始数据库
     * @param targetDB 目标数据库
     * @param date     营业日期
     */
    public static void replication(Context context, String originDB, String targetDB, String date) {
        RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 即将迁移[" + date + "]数据, From [" + originDB + "] to [" + targetDB + "]");

        if (TextUtils.isEmpty(originDB) || TextUtils.isEmpty(targetDB) || TextUtils.isEmpty(date)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 参数不正确，终止");
            return;
        }

        // 原始库不存在，直接退出
        if (!SlaveDBUtils.checkDBExists(context, originDB)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 原始库[" + originDB + "]不存在，终止");
            return;
        }

        // 目标数据不存在，如果不是 master，则尝试创建 slave
        if (!SlaveDBUtils.checkDBExists(context, targetDB)) {
            if (targetDB.equalsIgnoreCase(APPConfig.DB_MAIN)) {
                RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 目标库为主库，且不存在，终止");
                return;
            } else {
                SlaveDBUtils.slaveCreate(context, targetDB);

                // 如果创建后，再次校验仍不存在，可能的创建失败，则直接退出
                if (!SlaveDBUtils.checkDBExists(context, targetDB)) {
                    RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 目标库[" + targetDB + "]尝试创建后仍不存在，终止");
                    return;
                }
            }
        }

        try {
            // 格式化日期
            if (!ReplicationDBUtil.isValidFormat("yyyy-MM-dd", date)) {
                date = DateUtil.formartDateStrToTarget(date, DateUtil.DATE_YYYYMMDD, "yyyy-MM-dd");
            }
            // 格式化之后，仍不满足，直接返回
            if (!ReplicationDBUtil.isValidFormat("yyyy-MM-dd", date)) {
                RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 日期[" + date + "]格式不正确，终止");
                return;
            }

            JSONObject data = queryDataByDate(originDB, date);
            if (WriteJsonDataToDB.writeDataToDB(targetDB, data, null)) {
                RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication From [" + originDB + "] to [" + targetDB + "]，[" + date + "]数据迁移完成");
                // 写入目标库成功后，校验数据库大小
                if (checkIntegrity(originDB, targetDB, date)) {
                    // 数据一致的情况下，删除原始库的数据
                    RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 迁移数据校验完成，删除原始库[" + originDB + "]、营业日期[" + date + "]数据");
                    deleteOrigin(originDB, date);
                } else {
                    // 数据不一致的情况下，删除目标库的数据，下次重新迁移
                    RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication 迁移数据校验不通过，删除目标库[" + targetDB + "]、营业日期[" + date + "]数据");
                    deleteOrigin(targetDB, date);
                }
            }
        } catch (Exception ex) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#replication " + ex.getMessage());
            LogUtil.logError(ex);
        }
    }

    private static void deleteOrigin(String originDB, String date) {
        String orderParam = buildOrderIdParamWithDate(originDB, date);
        if (TextUtils.isEmpty(orderParam)) {
            return;
        }
        DBManager.getInstance(originDB).executeInTransactionWithOutThread(db -> {
            db.execSQL("DELETE FROM tbSell WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellOrder WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellOrderItem WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellReceive WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellCheck WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellCoupon WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellOrderItemNote WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM tbSellPickMenuitem WHERE fsSellNo IN " + orderParam);
            db.execSQL("DELETE FROM order_cache WHERE order_id IN " + orderParam);
            db.execSQL("DELETE FROM order_menu_cache WHERE order_id IN " + orderParam);
            db.execSQL("DELETE FROM order_pay_cache WHERE order_id IN " + orderParam);
            return null;
        });
    }

    private static JSONObject queryDataByDate(String originDB, String date) {
        String params = buildOrderIdParamWithDate(originDB, date);
        if (TextUtils.isEmpty(params)) {
            return null;
        }

        JSONObject data = new JSONObject();

        List<JSONObject> sell = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSell WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sell)) {
            data.put("tbSell",  JSONArray.parseArray(JSON.toJSONString(sell)));
        }
        List<JSONObject> sellOrder = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellOrder WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellOrder)) {
            data.put("tbSellOrder", JSONArray.parseArray(JSON.toJSONString(sellOrder)));
        }
        List<JSONObject> sellOrderItem = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellOrderItem WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellOrderItem)) {
            data.put("tbSellOrderItem", JSONArray.parseArray(JSON.toJSONString(sellOrderItem)));
        }
        List<JSONObject> sellReceive = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellReceive WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellReceive)) {
            data.put("tbSellReceive", JSONArray.parseArray(JSON.toJSONString(sellReceive)));
        }
        List<JSONObject> sellCheck = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellCheck WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellCheck)) {
            data.put("tbSellCheck", JSONArray.parseArray(JSON.toJSONString(sellCheck)));
        }
        List<JSONObject> sellCoupon = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellCoupon WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellCoupon)) {
            data.put("tbSellCoupon", JSONArray.parseArray(JSON.toJSONString(sellCoupon)));
        }
        List<JSONObject> sellOrderItemNote = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellOrderItemNote WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellOrderItemNote)) {
            data.put("tbSellOrderItemNote", JSONArray.parseArray(JSON.toJSONString(sellOrderItemNote)));
        }
        List<JSONObject> sellPickMenuitem = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM tbSellPickMenuitem WHERE fsSellno IN " + params.toString());
        if (!ListUtil.isEmpty(sellPickMenuitem)) {
            data.put("tbSellPickMenuitem", JSONArray.parseArray(JSON.toJSONString(sellPickMenuitem)));
        }
        List<JSONObject> orderCache = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM order_cache WHERE order_id IN " + params.toString());
        if (!ListUtil.isEmpty(orderCache)) {
            data.put("order_cache", JSONArray.parseArray(JSON.toJSONString(orderCache)));
        }
        List<JSONObject> orderMenuCache = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM order_menu_cache WHERE order_id IN " + params.toString());
        if (!ListUtil.isEmpty(orderMenuCache)) {
            data.put("order_menu_cache", JSONArray.parseArray(JSON.toJSONString(orderMenuCache)));
        }
        List<JSONObject> orderPayCache = DBSimpleUtil.queryJsonList(originDB, "SELECT * FROM order_pay_cache WHERE order_id IN " + params.toString());
        if (!ListUtil.isEmpty(orderPayCache)) {
            data.put("order_pay_cache", JSONArray.parseArray(JSON.toJSONString(orderPayCache)));
        }
        return data;
    }

    /**
     * 查询数据库中对应营业日期的所有订单号，并构成 SQL 条件(eg. "('201801010001', '201801010002')")
     *
     * @param originDB
     * @param date
     * @return
     */
    @Nullable
    private static String buildOrderIdParamWithDate(String originDB, String date) {
        List<String> orderIdList = DBSimpleUtil.queryStringList(originDB, "SELECT fsSellNo FROM tbSell WHERE fsSellDate = '" + date + "'");
        if (ListUtil.isEmpty(orderIdList)) {
            return null;
        }

        StringBuilder params = new StringBuilder();
        params.append("(");
        for (int index = 0; index < orderIdList.size(); index++) {
            String orderId = orderIdList.get(index);
            if (TextUtils.isEmpty(orderId)) {
                continue;
            }
            params.append("'");
            params.append(orderId);
            params.append("'");
            if (index < orderIdList.size() - 1) {
                params.append(", ");
            }
        }
        params.append(")");
        return params.toString();
    }

    /**
     * 是否是有效格式的时间
     *
     * @param format
     * @param value
     * @return
     */
    public static boolean isValidFormat(String format, String value) {
        Date date = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            date = sdf.parse(value);
            if (!value.equals(sdf.format(date))) {
                date = null;
            }
        } catch (ParseException ex) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "ReplicationDBUtil#isValidFormat " + ex.getMessage());
        }
        return date != null;
    }
}
