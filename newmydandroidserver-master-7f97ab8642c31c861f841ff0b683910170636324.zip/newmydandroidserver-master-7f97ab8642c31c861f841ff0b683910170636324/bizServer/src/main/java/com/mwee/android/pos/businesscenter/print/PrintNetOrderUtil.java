package com.mwee.android.pos.businesscenter.print;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.netorder.NetOrder;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.kds.algorithm.KdsAlgorithm;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.air.AirPrinterSelect;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.TempAppOrderPrintInfoDBModel;
import com.mwee.android.pos.db.business.WechatOrderItemDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lxx on 16/7/7.
 * 打印----打印前的数据拼装
 */
public class PrintNetOrderUtil {


    /**
     * 网络订单外卖单小票  商户联
     *
     * @param tempAppOrder
     */
    public static void printNetworkTackOutReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName) {
        printNetworkTackOutReceipt(tempAppOrder, hostId, fsUserName, false);
    }

    /**
     * 打印外卖结账单小票
     *
     * @param tempAppOrder         订单对象
     * @param hostId               站点ID
     * @param fsUserName           服务员
     * @param replenishmentReceipt 是否是补单
     */
    public static void printNetworkTackOutReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt) {
        printNetworkTackOutReceipt(tempAppOrder, hostId, fsUserName, replenishmentReceipt, null);
    }

    public static void printNetworkTackOutReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt, String fsPrinterName) {

        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir()) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_SHOP_PRINT, "0"), "1")) {
                return;
            }
        }

        printNetworkTackOutReceipt(tempAppOrder, hostId, fsUserName, replenishmentReceipt, true, false, fsPrinterName);
    }

    /**
     * 打印外卖结账单小票
     *
     * @param tempAppOrder         订单对象
     * @param hostId               站点ID
     * @param fsUserName           服务员
     * @param replenishmentReceipt 是否是补单， 补单会打印"补单"标志
     * @param refuseReprint        是否拒绝重印：除商户手动触发打印小票外，其他场景都不允许打印  true : 不允许重印； false: 允许重印
     * @param fsPrinterName        打印机名称
     * @param isUserPrint          是否是用户手动打印结账单，true，是，false，不是
     */
    public static void printNetworkTackOutReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt, boolean refuseReprint, boolean isUserPrint, String fsPrinterName) {

        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir() && !isUserPrint) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_SHOP_PRINT, "0"), "1")) {
                return;
            }
        } else {
            //用户手动打印结账单，美易点后台开关：是否打印外卖结账单
            if (!isUserPrint && !PrintConfig.PRINT_NET_BILL) {
                return;
            }
        }

        if (tempAppOrder == null) {
            return;
        }
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop", ShopDBModel.class);
        String businessDate = HostUtil.getHistoryBusineeDate("");
        synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(tempAppOrder.orderId))) {
            if (refuseReprint && checkTempAppOrderPrintInfo(String.valueOf(tempAppOrder.orderId), 1)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "网络订单-打印-结账小票 中断，理由：已打印过" + JSON.toJSONString(tempAppOrder), String.valueOf(tempAppOrder.orderId));
                return;
            }
            tempAppOrder = NetOrderDBUtil.getTempAppOrderById(String.valueOf(tempAppOrder.orderId));
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    String.valueOf(tempAppOrder.orderId), "", businessDate,
                    0,
                    fsUserName,
                    "0", PrintReportId.NETWORK_TAKEOUT_RECEIPT,
                    hostId,
                    true);

            HashMap<String, Object> datas = new HashMap<>();

            //打印美味广告
            PrintUtil.printMWAD(datas);
            try {
                String orderTakeawaySource = NetOrder.getTackOutResouseName(tempAppOrder.orderTakeawaySource);
                datas.put("title", (replenishmentReceipt ? "(补单)" : "") + orderTakeawaySource + "外卖单");
                datas.put("title_little", "");
                datas.put("orderTakeawaySource", orderTakeawaySource);
                datas.put("orderNum", tempAppOrder.orderNum);    //POS生成的订单号--一般堂食用
                datas.put("orderId", "#" + tempAppOrder.orderId);//后台数据库订单号
                datas.put("outerOrderId", tempAppOrder.outerOrderId);//外卖平台订单号
                datas.put("restNum", tempAppOrder.restNum);  //第三方每日订单序号
                datas.put("fsAddr", shopDBModel.fsAddr);
                datas.put("fsShopName", shopDBModel.fsShopName);
                if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_VOID) {
                    datas.put("payStatus", "支付状态:已退款");
                } else if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_UNPAY) {
                    datas.put("payStatus", "支付状态:未支付");
                } else if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_PAY_PART) {
                    datas.put("payStatus", "支付状态:部分支付");
                } else {
                    datas.put("payStatus", "支付状态:已支付");
                }
                datas.put("data", tempAppOrder.date);
                List<JSONObject> orderDetailSimpleList = getOrderDetailJSONObjects(tempAppOrder);
                datas.put("orderDetailSimpleList", orderDetailSimpleList);
                datas.put("orderDetailSparseArray", tempAppOrder.orderDetailSparseArray);
                datas.put("deliveryFee", tempAppOrder.deliveryFee);
                //餐盒费
                if (tempAppOrder.boxFee != null && tempAppOrder.boxFee.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("boxFee", tempAppOrder.boxFee);
                }

                //外卖平台服务费
                if (tempAppOrder.fdServiceAmt != null && tempAppOrder.fdServiceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("fdServiceAmt", tempAppOrder.fdServiceAmt);
                }
                //合计
                if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                    datas.put("subTotal", tempAppOrder.total);
                } else {
                    datas.put("subTotal", tempAppOrder.subTotal);
                }

                //后台数据库订单号
                datas.put("bizType", tempAppOrder.bizType);
                datas.put("person", tempAppOrder.person);
                datas.put("readyFoodMode", tempAppOrder.readyFoodMode == NetworkConstans.READY_FOOD_MODE_NOW ? "立即备餐" : "稍后备餐");  //第三方每日订单序号

                if (tempAppOrder.cancelStatus()) {
                    datas.put("payStatus", "支付状态:已退款");
                    datas.put("voidDes", "已全额退款");
                }

                //实付
                if (tempAppOrder.realPaymentAmount != null && tempAppOrder.realPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("total", tempAppOrder.realPaymentAmount.toPlainString());
                } else {
                    datas.put("total", tempAppOrder.total.toPlainString());
                }
                //实收
                if (tempAppOrder.earnestMoney != null && tempAppOrder.earnestMoney.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("earnestMoney", tempAppOrder.earnestMoney.toPlainString());
                }
                //优惠金额
                datas.put("youhui", tempAppOrder.optYouhuiAmt());

                datas.put("quan", tempAppOrder.appOrderCouponList);
                datas.put("address", tempAppOrder.address);
                datas.put("distributionPhone", tempAppOrder.distributionPhone);
                datas.put("distributionName", tempAppOrder.distributionName);
                datas.put("distributionStartTime", tempAppOrder.expectedDeliveryTime());
                datas.put("orderDesc", tempAppOrder.orderRemark);
                datas.put("PrintTime", DateUtil.getCurrentTime());
                datas.put("PrintTime", DateUtil.getCurrentTime());
                datas.put("receiptName", tempAppOrder.optReceiptName());

                datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);

                datas.put("fsDptrName", "站点：" + hostId);//当前站点名称
            } catch (Exception e) {
                e.printStackTrace();
                RunTimeLog.addLog(RunTimeLog.NETORDER_PRINT, "打印外卖小票异常：" + JSON.toJSONString(tempAppOrder), "异常信息：" + e.getMessage());
            }
            task.uri = "bill/networktackoutreceipt";
            task.uri = TicketTempletUtils.getTakeShopUri(task.uri);
            task.fsPrnData = JSON.toJSONString(datas);

            if (TextUtils.isEmpty(fsPrinterName)) {
                //判断打印机是否为标签打印机，是，则改成站点打印机
                fsPrinterName = getPrintName(hostId, true);
            }

            task.fsPrinterName = fsPrinterName;

            //处理外卖单的打印份数
            String printCountConfig = CommonDBUtil.getConfig(DBPrintConfig.NET_ORDER_PRINT_COUNT);
            int printCountNum = StringUtil.toInt(printCountConfig, 1);
            if (printCountNum < 1) {
                printCountNum = 1;
            }
            for (int i = 0; i < printCountNum; i++) {
                PrintTaskDBModel taskPrn = task.clone();
                taskPrn.fiPrintNo = PrintJSONBuilder.generatePrintNO();
                datas.put("fiPrintNo", taskPrn.fiPrintNo);
                taskPrn.fsPrnData = JSON.toJSONString(datas);
                taskPrn.fsPrinterName = fsPrinterName;

                if (TextUtils.isEmpty(taskPrn.fsPrnData)) {
                    RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印出现异常，外卖结账单小票；没有fsPrnData数据", JSON.toJSONString(taskPrn), datas);
                }

                CheckAndPrintUtil.buildTaskEnvAndPrint(taskPrn);
            }
            updateTempAppOrderPrintInfo(tempAppOrder, 1, replenishmentReceipt);
        }
    }

    /**
     * 取结账单打印机
     *
     * @param hostId
     * @return
     */
    private static String getPrintName(String hostId, boolean isCheckTSCPrinter) {
        String fsPrinterName = "";
        if (DBPrintConfig.printNetBillByNetPrint()) {
            fsPrinterName = DBPrintConfig.optNetPrintName();
            if (!TextUtils.isEmpty(fsPrinterName)) {
                if (isCheckTSCPrinter) {
                    String fsCommandType = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCommandType from tbPrinter where fsPrinterName = '" + fsPrinterName + "'");
                    if (!"TSC".equalsIgnoreCase(fsCommandType)) {
                        return fsPrinterName;
                    }
                } else {
                    return fsPrinterName;
                }
            }
        }
        PrinterDBModel printer = DeviceDBUtil.getPrinterByHostID(hostId);
        if (printer != null && !TextUtils.isEmpty(printer.fsPrinterName)) {
            fsPrinterName = printer.fsPrinterName;
        } else {
            fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
        }
        return fsPrinterName;
    }

    /**
     * 打印外卖客户联小票---不允许重印
     *
     * @param tempAppOrder         订单对象
     * @param hostId               站点ID
     * @param fsUserName           服务员
     * @param replenishmentReceipt 是否是补单
     */
    public static void printNetworkCustomerReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt) {

        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir()) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_CUSTOMER_PRINT, "1"), "1")) {
                return;
            }
        }
        printNetworkCustomerReceipt(tempAppOrder, hostId, fsUserName, replenishmentReceipt, true);
    }

    /**
     * 打印外卖客户联小票
     *
     * @param tempAppOrder         订单对象
     * @param hostId               站点ID
     * @param fsUserName           服务员
     * @param replenishmentReceipt 是否是补单
     * @param refuseReprint        是否拒绝重印：除商户手动触发打印小票外，其他场景都不允许打印  true : 不允许重印； false: 允许重印
     */
    public static void printNetworkCustomerReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt, boolean refuseReprint) {
        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir()) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_CUSTOMER_PRINT, "1"), "1")) {
                return;
            }
        }

        if (tempAppOrder == null) {
            return;
        }

        String fsPrinterName = CommonDBUtil.getConfig(DBPrintConfig.NET_ORDER_CUSTOM_RECEIPT_PRINT);
        //美小易
        fsPrinterName = new AirPrinterSelect().getNetCustomPrinterName(hostId, fsPrinterName);
        if (TextUtils.isEmpty(fsPrinterName)) {
            return;
        }
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop", ShopDBModel.class);
        String businessDate = HostUtil.getHistoryBusineeDate("");
        synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(tempAppOrder.orderId))) {
            if (refuseReprint && checkTempAppOrderPrintInfo(String.valueOf(tempAppOrder.orderId), 2)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "网络订单-打印-客户联小票 中断，理由：已打印过" + JSON.toJSONString(tempAppOrder), tempAppOrder.orderId + "");
                return;
            }
            tempAppOrder = NetOrderDBUtil.getTempAppOrderById(String.valueOf(tempAppOrder.orderId));
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    String.valueOf(tempAppOrder.orderId), "", businessDate,
                    0,
                    fsUserName,
                    "0", PrintReportId.NETWORK_CUSTOM_RECEIPT,
                    hostId,
                    true);

            HashMap<String, Object> datas = new HashMap<>();

            //打印美味广告
            PrintUtil.printMWAD(datas);
            try {
                String orderTakeawaySource = NetOrder.getTackOutResouseName(tempAppOrder.orderTakeawaySource);
                datas.put("title", (replenishmentReceipt ? "(补单)" : "") + orderTakeawaySource + "外卖单客户联");
                datas.put("title_little", "");
                datas.put("orderTakeawaySource", orderTakeawaySource);
                datas.put("orderNum", tempAppOrder.orderNum);    //POS生成的订单号--一般堂食用
                datas.put("orderId", "#" + tempAppOrder.orderId);//后台数据库订单号
                datas.put("outerOrderId", tempAppOrder.outerOrderId);//外卖平台订单号
                datas.put("restNum", tempAppOrder.restNum);  //第三方每日订单序号
                datas.put("fsAddr", shopDBModel.fsAddr);
                datas.put("fsShopName", shopDBModel.fsShopName);
                if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_VOID) {
                    datas.put("payStatus", "支付状态:已退款");
                } else if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_UNPAY) {
                    datas.put("payStatus", "支付状态:未支付");
                } else if (tempAppOrder.payStatus == NetworkConstans.PAY_STATUS_PAY_PART) {
                    datas.put("payStatus", "支付状态:部分支付");
                } else {
                    datas.put("payStatus", "支付状态:已支付");
                }
                datas.put("data", tempAppOrder.date);
                List<JSONObject> orderDetailSimpleList = getOrderDetailJSONObjects(tempAppOrder);
                datas.put("orderDetailSimpleList", orderDetailSimpleList);
                datas.put("orderDetailSparseArray", tempAppOrder.orderDetailSparseArray);
                datas.put("deliveryFee", tempAppOrder.deliveryFee);
                //餐盒费
                if (tempAppOrder.boxFee != null && tempAppOrder.boxFee.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("boxFee", tempAppOrder.boxFee);
                }

                //外卖平台服务费 客户联隐藏
                if (tempAppOrder.fdServiceAmt != null && tempAppOrder.fdServiceAmt.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("fdServiceAmt", tempAppOrder.fdServiceAmt);
                }
                //合计
                if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                    datas.put("subTotal", tempAppOrder.total);
                } else {
                    datas.put("subTotal", tempAppOrder.subTotal);
                }

                //后台数据库订单号
                datas.put("bizType", tempAppOrder.bizType);
                datas.put("person", tempAppOrder.person);
                datas.put("readyFoodMode", tempAppOrder.readyFoodMode == NetworkConstans.READY_FOOD_MODE_NOW ? "立即备餐" : "稍后备餐");  //第三方每日订单序号

                if (tempAppOrder.cancelStatus()) {
                    datas.put("payStatus", "支付状态:已退款");
                    datas.put("voidDes", "已全额退款");
                }

                //实付
                if (tempAppOrder.realPaymentAmount != null && tempAppOrder.realPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("total", tempAppOrder.realPaymentAmount.toPlainString());
                } else {
                    datas.put("total", tempAppOrder.total.toPlainString());
                }
                //实收 客户联隐藏
                if (tempAppOrder.earnestMoney != null && tempAppOrder.earnestMoney.compareTo(BigDecimal.ZERO) > 0) {
                    datas.put("earnestMoney", tempAppOrder.earnestMoney.toPlainString());
                }
                //优惠金额
                datas.put("youhui", tempAppOrder.optYouhuiAmt());

                datas.put("quan", tempAppOrder.appOrderCouponList);
                datas.put("address", tempAppOrder.address);
                datas.put("distributionPhone", tempAppOrder.distributionPhone);
                datas.put("distributionName", tempAppOrder.distributionName);
                datas.put("distributionStartTime", tempAppOrder.expectedDeliveryTime());
                datas.put("orderDesc", tempAppOrder.orderRemark);
                datas.put("PrintTime", DateUtil.getCurrentTime());
                datas.put("PrintTime", DateUtil.getCurrentTime());
                datas.put("receiptName", tempAppOrder.optReceiptName());

                datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);

                datas.put("fsDptrName", "站点：" + hostId);//当前站点名称
            } catch (Exception e) {
                e.printStackTrace();
                RunTimeLog.addLog(RunTimeLog.NETORDER_PRINT, "打印外卖小票异常：" + JSON.toJSONString(tempAppOrder), "异常信息：" + e.getMessage());
            }
            task.uri = TicketTempletUtils.getTakeCustomUri("bill/networkcustomreceipt");
            task.fsPrnData = JSON.toJSONString(datas);

            task.fsPrinterName = fsPrinterName;

            PrintTaskDBModel taskPrn = task.clone();
            taskPrn.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", taskPrn.fiPrintNo);
            taskPrn.fsPrnData = JSON.toJSONString(datas);
            taskPrn.fsPrinterName = fsPrinterName;
            CheckAndPrintUtil.buildTaskEnvAndPrint(taskPrn);

            updateTempAppOrderPrintInfo(tempAppOrder, 2, replenishmentReceipt);
        }
    }

    @NonNull
    private static List<JSONObject> getOrderDetailJSONObjects(TempAppOrder tempAppOrder) {
        List<JSONObject> orderDetailSimpleList = new ArrayList<>();
        for (int i = 0; i < tempAppOrder.orderDetailSparseArray.size(); i++) {
            List<TempAppOrderDetail> temp = tempAppOrder.orderDetailSparseArray.get(i);
            JSONObject jsonItemPack = new JSONObject();
            List<JSONObject> orderDetailList = new ArrayList<>();
            for (int j = 0; j < temp.size(); j++) {
                TempAppOrderDetail tempOrderDetail = temp.get(j);
                JSONObject jsonItemMenu = new JSONObject();
                jsonItemMenu.put("itemPrice", tempOrderDetail.itemPrice);
                jsonItemMenu.put("totalItemPrice", tempOrderDetail.totalItemPrice);
                jsonItemMenu.put("itemNum", tempOrderDetail.itemNum);
                jsonItemMenu.put("itemName", tempOrderDetail.itemName);
                jsonItemMenu.put("itemProperties", tempOrderDetail.itemProperties);
                if (!ListUtil.isEmpty(tempOrderDetail.modifiertypes)) {
                    List<JSONObject> modifiers = new ArrayList<>();
                    for (TempAppOrderModifier tempModifierTemp : tempOrderDetail.modifiertypes) {
                        if (!ListUtil.isEmpty(tempModifierTemp.modifiers)) {
                            for (TempModifierDetail tempModifierDetail : tempModifierTemp.modifiers) {
                                JSONObject jsonModifer = new JSONObject();
                                jsonModifer.put("modifierNum", tempModifierDetail.modifierNum);
                                jsonModifer.put("modifierName", tempModifierDetail.modifierName);
                                modifiers.add(jsonModifer);
                            }
                        }
                    }
                    if (!ListUtil.isEmpty(modifiers)) {
                        jsonItemMenu.put("modifiers", tempOrderDetail.itemPrice);
                    }
                }

                orderDetailList.add(jsonItemMenu);
            }
            jsonItemPack.put("orderDetailList", orderDetailList);
            jsonItemPack.put("content", (i + 1));
            orderDetailSimpleList.add(jsonItemPack);
        }
        return orderDetailSimpleList;
    }

    /**
     * 厨房小票
     * 由于借用菜品制作单小票方法打印外卖制作单
     * 所有套餐数据放到fsNote中，菜品特色备注、做法等放到ingredientNotes字段打印
     *
     * @param tempAppOrder
     */
    public static String printNetworkKDSReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName) {
        return printNetworkKDSReceipt(tempAppOrder, hostId, fsUserName, false);
    }

    public static String printNetworkKDSReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt) {

        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir()) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_MAKE_PRINT, "1"), "1")) {
                return "";
            }
        }

        return printNetworkKDSReceipt(tempAppOrder, hostId, fsUserName, replenishmentReceipt, true);
    }

    /**
     * 打印厨房制作单小票
     *
     * @param tempAppOrder         订单信息
     * @param hostId               站点ID
     * @param fsUserName           服务员名称
     * @param replenishmentReceipt 是否是补单
     * @param refuseReprint        是否拒绝重印：除商户手动触发打印小票外，其他场景都不允许打印  true : 不允许重印； false: 允许重印
     * @return
     */
    public static String printNetworkKDSReceipt(TempAppOrder tempAppOrder, String hostId, String fsUserName, boolean replenishmentReceipt, boolean refuseReprint) {

        //todo 陈仁敏产品需求 美小易商户联 客户联 以及制作单 单独配置开关
        if (APPConfig.isAir()) {
            if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_WAIMAI_MAKE_PRINT, "1"), "1")) {
                return "";
            }
        }

        if (tempAppOrder == null) {
            return "";
        }
        String businessDate = HostUtil.getHistoryBusineeDate("");
        RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "网络订单-打印-厨房小票 " + JSON.toJSONString(tempAppOrder), String.valueOf(tempAppOrder.orderId));
        synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(tempAppOrder.orderId))) {
            int receptType = tempAppOrder.cancelStatus() ? 3 : 0;
            if (refuseReprint && checkTempAppOrderPrintInfo(String.valueOf(tempAppOrder.orderId), receptType)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "网络订单-打印-厨房小票 中断，理由：已打印过" + JSON.toJSONString(tempAppOrder), String.valueOf(tempAppOrder.orderId));
                return "";
            }
            //如果没有打印过制作单，则不打印退菜单
            if (receptType == 3 && !checkTempAppOrderPrintInfo(String.valueOf(tempAppOrder.orderId), 0)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "网络订单-打印-不打印退菜单 ，理由：厨房小票未打印，" + JSON.toJSONString(tempAppOrder), String.valueOf(tempAppOrder.orderId));
                return "";
            }
            tempAppOrder = NetOrderDBUtil.getTempAppOrderById(String.valueOf(tempAppOrder.orderId));

            JSONObject datas = new JSONObject();
            try {
                if (isTackeOut(tempAppOrder.bizType)) {
                    datas.put("title", (replenishmentReceipt ? "(补单)" : "") + NetOrder.getTackOutResouseName(tempAppOrder.orderTakeawaySource) + "外卖单");
                } else {
                    datas.put("title", (replenishmentReceipt ? "(补单)" : "") + "网络订单");
                }
                boolean isVioid = false;
                if (tempAppOrder.cancelStatus()) {
//                    datas.put("voidTitle", "* 退 菜 单 *");
                    datas.put("voidMark", "1");//退菜单标志
                    if (tempAppOrder.updateTime > 0 && System.currentTimeMillis() - tempAppOrder.updateTime >= 3 * 60 * 60 * 1000) {
                        datas.put("voidHint", "本单已取消超过3小时，延时打印原因：网络状况差");
                    }
                    isVioid = true;
                } else {
                    datas.put("voidTitle", "");
                }
                String eatType = "";
                if (isTackeOut(tempAppOrder.bizType)) {
                    //饿了么外卖：air3.7制作单调整,air3.8.0退菜单调整
                    boolean isAdjust = APPConfig.isAir() && tempAppOrder.orderTakeawaySource.startsWith(TakeAwaySource.ELEME);
                    if (isAdjust) {
                        eatType = "饿了么";
                        datas.put("isAdjust", true);
                    } else {
                        eatType = "(" + NetOrder.getTackOutResouseName(tempAppOrder.orderTakeawaySource) + "外卖)";
                    }
                } else if (tempAppOrder.eatType == 2) {
                    eatType = "(自提带走)";
                } else {
                    eatType = "(到店堂食)";
                }
                datas.put("eatType", eatType + (replenishmentReceipt ? "(补单)" : ""));
                //本地生产的订单号
                datas.put("orderNum", tempAppOrder.orderNum);
                //后台数据库订单号
                datas.put("orderId", tempAppOrder.orderId);
                //第三方每日订单序号
                datas.put("restNum", tempAppOrder.restNum);

                // 联系人信息---共享餐厅数据
                datas.put("contact", tempAppOrder.contact);

                //备注
                datas.put("orderDesc", tempAppOrder.orderRemark);
                datas.put("PrintTime", DateUtil.getCurrentTime());
                datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);

                String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
                datas.put("beep", beep);

                datas.put("distributionStartTime", tempAppOrder.expectedDeliveryTime());

                List<PrintItemDataBean> unCheckedItems = new ArrayList<>();
                StringBuilder unCheckedItemNames = new StringBuilder("【");
                List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();

                for (int i = 1; i <= tempAppOrder.orderDetailSparseArray.size(); i++) {

                    List<TempAppOrderDetail> pokeOrderDetailList = tempAppOrder.orderDetailSparseArray.get(i - 1);
                    if (ListUtil.isEmpty(pokeOrderDetailList)) {
                        continue;
                    }

                    sellOrderItemDBModels.clear();
                    unCheckedItems.clear();
                    if (tempAppOrder.orderDetailSparseArray.size() > 1) {
                        datas.put("pokeNo", i + "号口袋");
                    }

                    datas.remove("orderDetailList");
                    for (TempAppOrderDetail item : pokeOrderDetailList) {
                        String itemId = item.itemCode;
                        MenuitemDBModel itemDB = null;
                        if (TextUtils.equals(tempAppOrder.orderTakeawaySource, TakeAwaySource.MWEE) && !TextUtils.isEmpty(item.outerItemId)) {
                            itemId = item.outerItemId;
                        }
                        itemDB = MenuDBUtil.getUsefulMenuDBModelBy(itemId);
                        String unitName = "";
                        if (!TextUtils.isEmpty(item.specId) && RegexUtil.checkNumber(item.specId)) {
                            unitName = MenuDBUtil.getUnitNameByID(item.specId);
                        }

                        if (!TextUtils.isEmpty(unitName)) {
                            item.unit = unitName;
                        }
                        if (itemDB == null) {
                            LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId + "网络订单：未匹配到的菜品：" + item.itemName + "【" + itemId + "】", "");
                            unCheckedItemNames.append(item.itemName).append("、");
                            PrintItemDataBean printItemDataBean = new PrintItemDataBean();
                            printItemDataBean.fsItemName = (isVioid ? "(退)" : "") + item.itemName;
                            printItemDataBean.fdSaleQty = new BigDecimal(item.itemNum);
                            printItemDataBean.fsOrderUint = item.unit;
                            printItemDataBean.fdSettlePrice = item.itemPrice;
                            printItemDataBean.fsCreateTime = tempAppOrder.date;
                            if (ListUtil.listIsEmpty(item.modifiertypes)) {
                                printItemDataBean.fiOrderItemKind = 1;
                            } else {
                                printItemDataBean.fiOrderItemKind = 2;
                            }

                            printItemDataBean.fsNote = NetOrder.formatModifierNotes(item.modifiertypes);
                            printItemDataBean.ingredientNotes = item.itemProperties;

                            unCheckedItems.add(printItemDataBean);
                            continue;
                        }

                        RunTimeLog.addLog(RunTimeLog.NETORDER_PRINT, "网络订单：匹配到的菜品：" + item.itemName + "【" + itemId + "】", "");
                        PrintItemDataBean printItemDataBean = new PrintItemDataBean();
                        printItemDataBean.fiIsMulDept = itemDB.fiIsMulDept;
                        printItemDataBean.fsItemName = (isVioid ? "(退)" : "") + itemDB.fsItemName;
                        printItemDataBean.fdSaleQty = new BigDecimal(item.itemNum);
                        printItemDataBean.fsMenuClsId = itemDB.fsMenuClsId;
                        printItemDataBean.fsOrderUint = item.unit;
                        printItemDataBean.fdSettlePrice = item.itemPrice;
                        printItemDataBean.fsCreateTime = tempAppOrder.date;
                        List<PrintItemDataBean> packageDtlModel = null;
                        //匹配到套餐头， 查看套餐明细是否是固定套餐
                        if (itemDB.fiItemKind == 2) {
                            if (checkPackageSetSide(itemDB.fiItemCd)) {
                                packageDtlModel = optPackageDtlPrintModel(itemDB.fiItemCd, itemDB.fsItemName, tempAppOrder.date, printItemDataBean.fdSaleQty);
                                if (!ListUtil.isEmpty(packageDtlModel)) {
                                    sellOrderItemDBModels.addAll(packageDtlModel);
                                }
                                //估清
                                if (!TextUtils.isEmpty(unitName)) {
                                    //菜品和规格都找到对应记录--->扣库存
                                    checkSellOutValue(item.specId, printItemDataBean, packageDtlModel);
                                }
                                continue;
                            }
                            printItemDataBean.fiOrderItemKind = 2;
                        } else {
                            printItemDataBean.fiOrderItemKind = 1;
                        }
                        printItemDataBean.fsNote = NetOrder.formatModifierNotes(item.modifiertypes);

                        printItemDataBean.ingredientNotes = item.itemProperties;

                        printItemDataBean.fsDeptId = itemDB.fsDeptId;
                        printItemDataBean.fiItemCd = itemId;
                        printItemDataBean.ingredientFatherItemCd = printItemDataBean.fiItemCd;
                        sellOrderItemDBModels.add(printItemDataBean);

                        //估清
                        if (!TextUtils.isEmpty(unitName)) {
                            //菜品和规格都找到对应记录--->扣库存
                            checkSellOutValue(item.specId, printItemDataBean, packageDtlModel);
                        }
                    }

                    String receiptTag = "#" + tempAppOrder.orderId;
                    if (!TextUtils.equals(tempAppOrder.restNum, "0")) {
                        receiptTag = tempAppOrder.restNum + "#" + tempAppOrder.orderId;
                    }

                    boolean openKDS = DBOrderConfig.useKdsService() && DBOrderConfig.takeoutUseKdsService();

                    LogUtil.logBusiness("---------KDS单号----" + tempAppOrder.orderId +
                            "-----识别菜品数量-----" + sellOrderItemDBModels.size() +
                            "-----未识别数量--------" + unCheckedItems.size() + "---openKDS----" + openKDS);
                    //todo KDS  外卖进不进KDS
                    if (openKDS) {
                        int fiMakeBeforeDeliveryKDS = DBOrderConfig.getMakeBeforeDeliveryKDS();
                        if (!ListUtil.isEmpty(sellOrderItemDBModels)) {
                            KdsAlgorithm.getInstance().wmOrder(tempAppOrder, sellOrderItemDBModels, fiMakeBeforeDeliveryKDS);

                            //配料、以及没有打印部门的，还需要走原来的逻辑
                            List<PrintItemDataBean> models = new ArrayList<>();
                            for (PrintItemDataBean bean : sellOrderItemDBModels) {
                                if (TextUtils.isEmpty(bean.fsDeptId)) {
                                    models.add(bean);
                                }
                            }
                            if (!ListUtil.isEmpty(models)) {
                                printMenuItems(models, datas, receiptTag, businessDate, fsUserName, hostId, "order/printnetworkkdsreceipt");
                            }
                        }
                    } else {
                        if (!ListUtil.isEmpty(sellOrderItemDBModels)) {
                            printMenuItems(sellOrderItemDBModels, datas, receiptTag, businessDate, fsUserName, hostId, "order/printnetworkkdsreceipt");
                        }
                    }

                    /**
                     * 未匹配到的菜品
                     * 1、先找后台配置的外卖厨房打印机
                     * 2、当找不到外卖厨房打印机时，再找站点打印机
                     */
                    if (unCheckedItems.size() > 0) {
                        String printName = optNetOrderKDSPrinterName(hostId);
                        String fsCommandType = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCommandType from tbPrinter where fsPrinterName = '" + printName + "'");
                        //判断打印机是否为标签打印机
                        if ("TSC".equalsIgnoreCase(fsCommandType)) {
                            int allMenuCount = 0;
                            //构建标签打印机打印的总份数
                            for (PrintItemDataBean printItem : unCheckedItems) {
                                try {
                                    printItem.lastTscIndex = allMenuCount;
                                    //是否可改数(称重);0/1;为1=ture时,份数为1
                                    int count = printItem.fiIsEditQty == 1 ? 1 : printItem.fdSaleQty.intValue();
                                    allMenuCount += count;
                                } catch (Exception e) {
                                    allMenuCount += 1;
                                }
                            }
                            printSingleMakeTSC(datas, receiptTag, "0", printName, unCheckedItems, allMenuCount, businessDate, fsUserName, hostId);
                        } else {
                            int fiPrintNo = PrintJSONBuilder.generatePrintNO();
                            datas.put("orderDetailList", unCheckedItems);
                            datas.put("fiPrintNo", fiPrintNo);
                            //当前站点名称
                            datas.put("fsDptrName", "站点：" + hostId);

                            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                                    String.valueOf(tempAppOrder.orderId), "", businessDate,
                                    fiPrintNo,
                                    fsUserName,
                                    "0", PrintReportId.NETWORK_KDS_RECEIPT,
                                    hostId,
                                    true);

                            task.uri = "order/printnetworkkdsreceipt";
                            //外卖退菜单标志
                            if (isVioid) {
                                task.fsReportName = "外卖退菜单";
                                if (APPConfig.isAir()) {
                                    datas.put("isOneItemCut", "(退菜单)");
                                } else {
                                    datas.put("isOneItemCut", "外卖退菜单");
                                }
                            } else {
                                if (APPConfig.isAir()) {
//                                air3.7.0外卖制作单调整
                                    datas.put("isOneItemCut", "制作单");
                                } else {
                                    datas.put("isOneItemCut", "外卖制作单");
                                }
                            }
                            task.fsPrnData = datas.toJSONString();
                            task.fsPrinterName = printName;

                            String tips = unCheckedItemNames.toString();
                            if (!TextUtils.isEmpty(tips) && !TextUtils.equals("【", tips) && !isVioid) {
                                tips = tips.substring(0, tips.length() - 1);
                                tips = tips + "】";
                                NotifyToClient.unMatchMenuItems(hostId, tips);
                            }

                            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                        }
                    }
                }

                updateTempAppOrderPrintInfo(tempAppOrder, receptType, replenishmentReceipt);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return "";
    }

    /**
     * 获取外卖制作单打印机名称
     *
     * @return
     */
    private static String optNetOrderKDSPrinterName(String hostId) {
        String fsPrinterName = DBPrintConfig.optNetPrintName();
        if (TextUtils.isEmpty(fsPrinterName)) {
            PrinterDBModel printer;
            if (APPConfig.isCasiher()) {
                printer = DeviceDBUtil.getPrinterByDeptID("2");
                if (printer != null) {
                    fsPrinterName = printer.fsPrinterName;
                }
            } else {
                printer = DeviceDBUtil.getPrinterByHostID(hostId);
                if (printer == null) {
                    fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
                } else {
                    fsPrinterName = printer.fsPrinterName;
                }
            }

        }
        return fsPrinterName;
    }

    /**
     * 外卖去库存
     */
    private static void checkSellOutValue(String fiOrderUintCd, PrintItemDataBean printItemDataBean, List<PrintItemDataBean> packageOrderItemDBModels) {

//        if (fiOrderUintCd == 0) {
        if (TextUtils.isEmpty(fiOrderUintCd) || TextUtils.equals("0", fiOrderUintCd)) {
            return;
        }
        if (printItemDataBean == null) {
            return;
        }
        MenuItem menuItem = new MenuItem();
        menuItem.itemID = printItemDataBean.fiItemCd;
        menuItem.menuBiz = new MenuBiz();
        menuItem.currentUnit = new UnitModel();
        menuItem.currentUnit.fiOrderUintCd = fiOrderUintCd;

        //估清数量不可超过剩余数量
        SellOutViewModel sellOutViewModel = SellOutServerProcessor.getItemSellOutViewModel(menuItem.itemID, menuItem.currentUnit.fiOrderUintCd);
        if (sellOutViewModel == null || sellOutViewModel.fdInvQty.compareTo(printItemDataBean.fdSaleQty.subtract(printItemDataBean.fdBackQty)) > 0) {
            menuItem.menuBiz.buyNum = printItemDataBean.fdSaleQty;
            menuItem.menuBiz.voidNum = printItemDataBean.fdBackQty;
        } else {
            menuItem.menuBiz.buyNum = sellOutViewModel.fdInvQty;
            menuItem.menuBiz.voidNum = BigDecimal.ZERO;
            RunTimeLog.addLog(RunTimeLog.NETORDER_CUT_SELL_OUT, "库存不足; 菜品下单数量 = " + Calc.formatShow(printItemDataBean.fdSaleQty.subtract(printItemDataBean.fdBackQty)) + "； 剩余库存 = " + Calc.formatShow(sellOutViewModel.fdInvQty),
                    "", menuItem);
        }
        if (!ListUtil.isEmpty(packageOrderItemDBModels)) {
            menuItem.config = menuItem.config | 256;
            menuItem.menuBiz.selectedPackageItems = new ArrayList<>();
            for (PrintItemDataBean packageItem : packageOrderItemDBModels) {
                if (packageItem == null) {
                    continue;
                }
                MenuItem packageMenuItem = new MenuItem();
                packageMenuItem.itemID = packageItem.fiItemCd;
                packageMenuItem.menuBiz = new MenuBiz();
                packageMenuItem.currentUnit = new UnitModel();
                packageMenuItem.currentUnit.fiOrderUintCd = packageItem.fiOrderUintCd;

                sellOutViewModel = SellOutServerProcessor.getItemSellOutViewModel(packageMenuItem.itemID, packageMenuItem.currentUnit.fiOrderUintCd);
                if (sellOutViewModel == null || sellOutViewModel.fdInvQty.compareTo(packageItem.fdSaleAmt.subtract(packageItem.fdBackQty)) > 0) {
                    packageMenuItem.menuBiz.buyNum = packageItem.fdSaleAmt;
                    packageMenuItem.menuBiz.voidNum = packageItem.fdBackQty;
                } else {
                    packageMenuItem.menuBiz.buyNum = sellOutViewModel.fdInvQty;
                    packageMenuItem.menuBiz.voidNum = BigDecimal.ZERO;

                    RunTimeLog.addLog(RunTimeLog.NETORDER_CUT_SELL_OUT, "库存不足; 菜品下单数量 = " + Calc.formatShow(packageItem.fdSaleAmt.subtract(packageItem.fdBackQty)) + "； 剩余库存 = " + Calc.formatShow(sellOutViewModel.fdInvQty),
                            "套餐明细菜", packageMenuItem);
                }
                menuItem.menuBiz.selectedPackageItems.add(packageMenuItem);
            }
        }
        List<MenuItem> selectMenuItemList = new ArrayList<>();
        selectMenuItemList.add(menuItem);
        SellOutServerProcessor.checkSellOutValue(selectMenuItemList);

    }

    /**
     * 判断小票是否打印过
     *
     * @param orderId
     * @param receptType 小票类型0：制作单；1：结账单;2:外卖客户联 3：退菜单
     * @return boolean | true : 打印过； false : 未打印过
     */
    private static boolean checkTempAppOrderPrintInfo(String orderId, int receptType) {
        String sql = "select guid from TempAppOrderPrintInfo where orderId = '" + orderId + "' and receptType = '" + receptType + "'";
        return !TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql));
    }


    /**
     * 新增打印记录
     *
     * @param tempAppOrder
     * @param receptType           小票类型0：制作单；1：结账单
     * @param replenishmentReceipt 是否补单； 0：POS正常接单打印；1：补单；
     */
    private static void updateTempAppOrderPrintInfo(TempAppOrder tempAppOrder, int receptType, boolean replenishmentReceipt) {
        String sql = "select * from TempAppOrderPrintInfo where orderId = '" + tempAppOrder.orderId
                + "' and receptType = '" + receptType
                + "' and printType = '" + (replenishmentReceipt ? "1" : "0") + "'";
        TempAppOrderPrintInfoDBModel tempAppOrderPrintInfoDBModel = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, sql, TempAppOrderPrintInfoDBModel.class);
        if (tempAppOrderPrintInfoDBModel == null) {
            tempAppOrderPrintInfoDBModel = new TempAppOrderPrintInfoDBModel();
            tempAppOrderPrintInfoDBModel.guid = UUIDUtil.optUUID();
            tempAppOrderPrintInfoDBModel.orderId = String.valueOf(tempAppOrder.orderId);
            tempAppOrderPrintInfoDBModel.printTime = DateUtil.getCurrentTime();
            tempAppOrderPrintInfoDBModel.printTyp = replenishmentReceipt ? 1 : 0;
            tempAppOrderPrintInfoDBModel.receptType = receptType;
            tempAppOrderPrintInfoDBModel.fsShopGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select value from meta where key='104'");
            tempAppOrderPrintInfoDBModel.setDbName(APPConfig.DB_NET_ORDER);
            tempAppOrderPrintInfoDBModel.replaceNoTrans();
        }
    }

    /**
     * 打印已匹配到的外卖菜品
     *
     * @param sellOrderItemDBModels
     * @param datas
     * @param receiptTag
     * @param businessDate
     * @param fsUserName
     * @param hostId
     * @param uri
     */
    public static void printMenuItems(List<PrintItemDataBean> sellOrderItemDBModels, JSONObject datas,
                                      String receiptTag, String businessDate,
                                      String fsUserName, String hostId,
                                      String uri) {

        if (sellOrderItemDBModels.size() > 0) {
            GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                    .setItemList(sellOrderItemDBModels)
                    .setWithCurrentHost(false)
                    .setWithDeptMake(true)
                    .setWithDeptTransfer(false)
                    .setCheckArea(false)
                    .build();

            for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                String fsDeptId = entry.getKey();
                DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
                if (deptDBModel == null) {
                    continue;
                }

                datas.put("Dept", deptDBModel);
                datas.put("fsDptrName", "打印部门：" + deptDBModel.fsDeptName);

                PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                if (printer == null && !APPConfig.isCasiher()) {
                    String info = "打印制作单失败,没有找到启用的打印机。部门ID[" + fsDeptId + "]";
                    info = new AirPrinterSelect().getAirDeptIDNotFound(fsDeptId, info);
                    if (!TextUtils.isEmpty(info)) {
                        ToastUtil.showToast(info);
                    }
                    RunTimeLog.addLog(RunTimeLog.NETORDER_PRINT, info, deptDBModel.fsDeptName);
                    continue;
                }
                List<PrintItemDataBean> list = entry.getValue();
                if (ListUtil.isEmpty(list)) {
                    continue;
                }

                datas.remove("orderDetailList");

                boolean isTsc = "TSC".equalsIgnoreCase(printer.fsCommandType);

                if (isTsc) {
                    printSingleMakeTSC(datas, receiptTag, fsDeptId, printer.fsPrinterName, list, processor.tscCount, businessDate, fsUserName, hostId);
                } else {
                    // 制作单 1=一菜一切/2=总单/3=总单&一菜一切/4=一份一切
                    if (deptDBModel.fiIsOneItemCut == 1) {
                        printSingleMake(list, datas, businessDate, fsDeptId, printer.fsPrinterName, fsUserName, hostId, uri);
                    } else if (deptDBModel.fiIsOneItemCut == 2) {
                        printAllMake(list, datas, businessDate, fsDeptId, printer.fsPrinterName, fsUserName, hostId, uri);
                    } else if (deptDBModel.fiIsOneItemCut == 3) {
                        printSingleMake(list, datas, businessDate, fsDeptId, printer.fsPrinterName, fsUserName, hostId, uri);
                        printAllMake(list, datas, businessDate, fsDeptId, printer.fsPrinterName, fsUserName, hostId, uri);
                    } else if (deptDBModel.fiIsOneItemCut == 4) {
                        printSingle(list, datas, businessDate, fsDeptId, printer.fsPrinterName, fsUserName, hostId, uri);
                    }
                }
            }
        }
    }

    /**
     * 总单
     *
     * @param list
     * @param datas
     * @param businessDate
     * @param fsDeptId
     * @param fsPrinterName
     * @param fsUserName
     * @param hostId
     * @param uri
     */
    private static void printAllMake(List<PrintItemDataBean> list, JSONObject datas, String businessDate, String fsDeptId, String fsPrinterName,
                                     String fsUserName, String hostId, String uri) {

        int fiPrintNo = PrintJSONBuilder.generatePrintNO();
        datas.put("orderDetailList", list);
        datas.put("fiPrintNo", fiPrintNo);
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "", businessDate,
                fiPrintNo,
                fsUserName,
                fsDeptId, PrintReportId.NETWORK_KDS_RECEIPT,
                hostId,
                true);

        task.uri = uri;
        //外卖退菜单标志
        if (TextUtils.equals(datas.getString("voidMark"), "1")) {
            task.fsReportName = "外卖退菜单";
            if (APPConfig.isAir()) {
//                air3.8.0外卖退菜单调整
                datas.put("isOneItemCut", "(总单退菜单)");
            } else {
                datas.put("isOneItemCut", "总单退菜单");
            }
        } else {
            if (APPConfig.isAir()) {
//                air3.7外卖制作单调整
                datas.put("isOneItemCut", "(总单)");
            } else {
                datas.put("isOneItemCut", "总单制作单");
            }
        }
        task.fsPrnData = datas.toJSONString();
        task.fsPrinterName = fsPrinterName;

        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
    }

    /**
     * 一菜一切
     *
     * @param list
     * @param datas
     * @param businessDate
     * @param fsDeptId
     * @param fsPrinterName
     * @param fsUserName
     * @param hostId
     * @param uri
     */
    private static void printSingleMake(List<PrintItemDataBean> list, JSONObject datas, String businessDate, String fsDeptId, String fsPrinterName,
                                        String fsUserName, String hostId, String uri) {
        List<PrintItemDataBean> dataBeanList = new ArrayList<>();
        for (PrintItemDataBean printItemDataBean : list) {
            dataBeanList.clear();
            dataBeanList.add(printItemDataBean);
            int fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("orderDetailList", dataBeanList);
            datas.put("fiPrintNo", fiPrintNo);
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    "", "", businessDate,
                    fiPrintNo,
                    fsUserName,
                    fsDeptId, PrintReportId.NETWORK_KDS_RECEIPT,
                    hostId,
                    true);

            task.uri = uri;
            //外卖退菜单标志
            if (TextUtils.equals(datas.getString("voidMark"), "1")) {
                task.fsReportName = "外卖退菜单";
                if (APPConfig.isAir()) {
//                    air3.8.0外卖退菜单调整
                    datas.put("isOneItemCut", "(单品退菜单)");
                } else {
                    datas.put("isOneItemCut", "单品退菜单(一菜一切)");
                }
            } else {
                if (APPConfig.isAir()) {
//                    air3.7外卖制作单调整
                    datas.put("isOneItemCut", "(单品)");
                } else {
                    datas.put("isOneItemCut", "单品制作单(一菜一切)");
                }
            }
            task.fsPrnData = datas.toJSONString();
            task.fsPrinterName = fsPrinterName;
            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        }
    }

    /**
     * 一份一切
     *
     * @param list
     * @param datas
     * @param businessDate
     * @param fsDeptId
     * @param fsPrinterName
     * @param fsUserName
     * @param hostId
     * @param uri
     */
    private static void printSingle(List<PrintItemDataBean> list, JSONObject datas, String businessDate, String fsDeptId, String fsPrinterName,
                                    String fsUserName, String hostId, String uri) {
        List<PrintItemDataBean> dataBeanList = new ArrayList<>();
        for (PrintItemDataBean printItemDataBean : list) {
            int count = printItemDataBean.fiIsEditQty == 1 ? 1 : printItemDataBean.fdSaleQty.intValue();
            for (int j = 0; j < count; j++) {
                if (printItemDataBean.fiIsEditQty != 1) {
                    printItemDataBean.fdSaleQty = BigDecimal.ONE;
                }
                dataBeanList.clear();
                dataBeanList.add(printItemDataBean);
                int fiPrintNo = PrintJSONBuilder.generatePrintNO();
                datas.put("orderDetailList", dataBeanList);
                datas.put("fiPrintNo", fiPrintNo);
                PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                        "", "", businessDate,
                        fiPrintNo,
                        fsUserName,
                        fsDeptId, PrintReportId.NETWORK_KDS_RECEIPT,
                        hostId,
                        true);

                task.uri = uri;
                //外卖退菜单标志
                if (TextUtils.equals(datas.getString("voidMark"), "1")) {
                    task.fsReportName = "外卖退菜单";
                    if (APPConfig.isAir()) {
//                        air3.8.0外卖退菜单调整
                        datas.put("isOneItemCut", "(单品退菜单)");
                    } else {
                        datas.put("isOneItemCut", "单品退菜单(一份一切)");
                    }
                } else {
                    if (APPConfig.isAir()) {
//                        air3.7外卖制作单调整
                        datas.put("isOneItemCut", "(单品)");
                    } else {
                        datas.put("isOneItemCut", "单品制作单(一份一切)");
                    }
                }
                task.fsPrnData = datas.toJSONString();
                task.fsPrinterName = fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            }
        }
    }


    /**
     * 打印单品制作单---标签
     *
     * @param valueMap HashMap<String, Object> | 模板的value信息
     * @param fsDeptId String | 部门ID
     * @param list     List<SellOrderItemDBModel> | 菜品列表
     */
    private static void printSingleMakeTSC(JSONObject valueMap, String receiptTag, String fsDeptId, String printerName, List<PrintItemDataBean> list, int tscCount,
                                           String businessDate, String fsUserName, String hostId) {
        int fiPrintNo = 0;
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "", businessDate,
                fiPrintNo,
                fsUserName,
                fsDeptId, PrintReportId.MAKE_THE_TOTAL_LIST_SINGLE,
                hostId,
                true);
        task.uri = "order/makesingleTSC";
        task.fsPrinterName = printerName;
        if (TextUtils.equals(valueMap.getString("voidMark"), "1")) {
            //外卖退菜单标志
            task.fsReportName = "外卖退菜单";
        }
        for (PrintItemDataBean temp : list) {
            task.fsPrnData = null;
            task = task.clone();

            int count = temp.fiIsEditQty == 1 ? 1 : temp.fdSaleQty.intValue();

            for (int i = 1; i <= count; i++) {

                JSONObject printDatas = new JSONObject();

                String shopName = "";
                if (shopDBModel != null) {
                    shopName = shopDBModel.fsShopName;
                }
                printDatas.put("shopname", shopName);
                printDatas.put("id", receiptTag);  //显示
                printDatas.put("num", temp.fdSaleQty + temp.fsOrderUint);
                printDatas.put("itemname", temp.fsItemName);
                printDatas.put("price", Calc.formatShow(temp.fdSettlePrice) + "元");
                printDatas.put("itemnote", temp.fsNote + " " + temp.ingredientNotes + "");  //备注
                String sequence = (temp.lastTscIndex + i) + "/" + tscCount;
                LogUtil.log("printSingleMakeTSC sequence = " + sequence + " -->" + temp.fsItemName);
                printDatas.put("sequence", sequence);

                String tel = "";
                if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
                    tel = shopDBModel.fsTel;
                }
                String time;
                if (!TextUtils.isEmpty(tel)) {
                    printDatas.put("phone", "电话：" + tel);
                    time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                } else {
                    time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm");
                }
                printDatas.put("time", time);

                fiPrintNo = PrintJSONBuilder.generatePrintNO();
                task.fiPrintNo = fiPrintNo;
                valueMap.put("fiPrintNo", fiPrintNo);
                task.fsPrnData = printDatas.toJSONString();
                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            }
        }
    }


    /**
     * 检查XX套餐的组成项是否都是固定套餐
     *
     * @param fiItemCd 套餐头ID
     * @return boolean | true: 固定套餐； false: 非固定套餐
     */
    private static boolean checkPackageSetSide(String fiItemCd) {
        String sql = "select fsSetFoodName from tbmenuitemsetside where fiSetFoodType <> '0' and fiItemCd_M = '" + fiItemCd + "'";
        String fsSetFoodName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(fsSetFoodName)) {
            return true;
        }
        return false;
    }

    /**
     * 检查XX套餐的组成项是否都是固定套餐
     *
     * @param fiItemCd 套餐头ID
     * @return boolean | true: 固定套餐； false: 非固定套餐
     */
    private static List<PrintItemDataBean> optPackageDtlPrintModel(String fiItemCd, String packageName, String fsCreateTime, BigDecimal qty) {
        if (qty == null || qty.compareTo(BigDecimal.ZERO) <= 0) {
            qty = BigDecimal.ONE;
        }
        String sql = "select tbMenuItem.fiItemKind fiOrderItemKind,tbMenuItem.fsMenuClsId fsMenuClsId, tbMenuItem.fsDeptId fsDeptId, tbMenuItem.fiIsMulDept fiIsMulDept, " +
                "tbMenuItemSetSideDtl. fiItemCd_M fsSeq_M, tbMenuItemSetSideDtl.fdSaleQty fdSaleQty, " +
                "tbMenuItemSetSideDtl.fiItemCd fiItemCd, tbMenuItemSetSideDtl.fiOrderUintCd fiOrderUintCd, tbMenuItem.fsItemName " +
                "from tbMenuItemSetSideDtl inner join tbMenuItemSetSide " +
                "on tbMenuItemSetSide.fiItemCd_M = tbMenuItemSetSideDtl.fiItemCd_M and tbMenuItemSetSide.fiSetFoodCd = tbMenuItemSetSideDtl. fiSetFoodCd " +
                "left join tbMenuItem on tbMenuItemSetSideDtl .fiItemCd = tbMenuItem.fiItemCd " +
                "where tbMenuItemSetSide.fistatus = '1' and tbMenuItemSetSideDtl.fistatus = '1' and tbMenuItemSetSide.fiItemCd_M = '" + fiItemCd + "' " +
                "and tbMenuItemSetSide.fiSetFoodType = '0' and tbMenuItem.fistatus = '1' ";

        List<PrintItemDataBean> packageDtlMenuDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        if (!ListUtil.isEmpty(packageDtlMenuDBModels)) {
            for (PrintItemDataBean printItemDataBean : packageDtlMenuDBModels) {
                printItemDataBean.fsOrderUint = MenuDBUtil.getUnitNameByID(printItemDataBean.fiOrderUintCd);
                printItemDataBean.fdSettlePrice = BigDecimal.ZERO;
                printItemDataBean.fsCreateTime = fsCreateTime;
                printItemDataBean.fiOrderItemKind = 3;
                printItemDataBean.fsNote = "(属于)" + packageName;
                printItemDataBean.ingredientFatherItemCd = printItemDataBean.fiItemCd;

                if (printItemDataBean.fdSaleQty == null || printItemDataBean.fdSaleQty.compareTo(BigDecimal.ZERO) <= 0) {
                    printItemDataBean.fdSaleQty = BigDecimal.ONE;
                }
                printItemDataBean.fdSaleQty = printItemDataBean.fdSaleQty.multiply(qty);
            }
        }
        return packageDtlMenuDBModels;
    }

    /**
     * 微信外卖订单厨房小票
     *
     * @param wechatOrderModel
     */
    @Deprecated
    public static void printWechatKDSReceipt(final WechatOrderModel wechatOrderModel, final boolean isVoid, String hostId, String fsUserName) {

        if (wechatOrderModel == null) {
            return;
        }
        String businessDate = HostUtil.getHistoryBusineeDate("");

        LogUtil.logBusiness("微信外卖单-打印-厨房小票 " + JSON.toJSONString(wechatOrderModel));
        RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "微信外卖-打印-厨房小票 " + JSON.toJSONString(wechatOrderModel), wechatOrderModel.fsorderno + "");
        JSONObject datas = new JSONObject();
        try {
            datas.put("title", "微信外卖单");
            if (isVoid) {//备餐中的订单---厨房要打印退菜单
                datas.put("voidTitle", "* 退 菜 单 *");
            } else {
                datas.put("voidTitle", "");
            }
            datas.put("eatType", "微信外卖");
            datas.put("orderNum", wechatOrderModel.localOrderId); //订单号
            datas.put("orderId", wechatOrderModel.fsorderno);//网络订单号

            datas.put("restNum", "");//第三方外卖单号

            datas.put("orderitem", wechatOrderModel.orderitem);

            datas.put("orderDesc", wechatOrderModel.fsremark);
            datas.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("wechatOrderModel", wechatOrderModel);
            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);


            String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
            datas.put("beep", beep);

            List<PrintItemDataBean> unCheckedItems = new ArrayList<>();

            List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();

            for (WechatOrderItemDBModel item : wechatOrderModel.orderitem) {
                String itemId = item.fsitemcode;
                MenuitemDBModel itemDB = MenuDBUtil.getUsefulMenuDBModelBy(itemId);
                if (itemDB == null) {
                    LogUtil.logBusiness("网络订单：未匹配到的菜品：" + item.fsitemname + "【" + itemId + "】");
                    RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "网络订单：未匹配到的菜品：" + item.fsitemname + "【" + itemId + "】", "");
                    PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
                    sellOrderItemBean.fsItemName = item.fsitemname;
                    sellOrderItemBean.fdSaleQty = item.fiitemnum;
                    sellOrderItemBean.fsOrderUint = item.fsstandardname;
                    sellOrderItemBean.fdSettlePrice = item.fdrealamount;
                    sellOrderItemBean.fsCreateTime = item.fscreatetime;
                    sellOrderItemBean.ingredientNotes = item.fsremark;
                    unCheckedItems.add(sellOrderItemBean);
                    continue;
                }

                LogUtil.logBusiness("网络订单：匹配到的菜品：" + item.fsitemname + "【" + itemId + "】");
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "网络订单：匹配到的菜品：" + item.fsitemname + "【" + itemId + "】", "");
                PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
                sellOrderItemBean.fiIsMulDept = itemDB.fiIsMulDept;
                sellOrderItemBean.fsItemName = itemDB.fsItemName;
                sellOrderItemBean.fsMenuClsId = itemDB.fsMenuClsId;
                sellOrderItemBean.fdSaleQty = item.fiitemnum;
                sellOrderItemBean.fsOrderUint = item.fsstandardname;
                sellOrderItemBean.fdSettlePrice = item.fdsubtotal;
                sellOrderItemBean.fsCreateTime = item.fscreatetime;
                sellOrderItemBean.ingredientNotes = item.fsremark;
                sellOrderItemBean.fsDeptId = itemDB.fsDeptId;
                sellOrderItemBean.fiItemCd = itemId;
                sellOrderItemBean.ingredientFatherItemCd = itemId;
                sellOrderItemDBModels.add(sellOrderItemBean);
            }

            String receiptTag = "#" + wechatOrderModel.fsorderno;

            // todo KDS切入
            //todo KDS  外卖进不进KDS,据说这个接口不用了，就算了
            printMenuItems(sellOrderItemDBModels, datas, receiptTag, businessDate, fsUserName, hostId, "order/printnetworkkdsreceipt");

            /**
             * 未匹配到的菜品
             */
            if (unCheckedItems.size() > 0) {
                int fiPrintNo = PrintJSONBuilder.generatePrintNO();
                datas.put("orderitem", unCheckedItems);
                datas.put("fiPrintNo", fiPrintNo);
                datas.put("fsDptrName", "站点：" + hostId);//当前站点名称

                PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                        "", "", businessDate,
                        fiPrintNo,
                        fsUserName,
                        "0", PrintReportId.WECHAT_ORDER_ORDER,
                        hostId,
                        true);

                task.uri = "order/printwechatOrderkdsreceipt";
                task.fsPrnData = datas.toJSONString();
                task.fsPrinterName = DBPrintConfig.optNetPrintName();
                if (TextUtils.isEmpty(task.fsPrinterName)) {
                    PrinterDBModel printer = DeviceDBUtil.getPrinterByHostID(hostId);
                    if (printer == null) {
                        task.fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
                    } else {
                        task.fsPrinterName = printer.fsPrinterName;
                    }
                    String tips = unCheckedItems.toString();
                    if (!TextUtils.isEmpty(tips) && !TextUtils.equals("【", tips) && !isVoid) {
                        tips = tips.substring(0, tips.length() - 1);
                        tips = tips + "】";
                        NotifyToClient.unMatchMenuItems(hostId, tips);
                    }
                }
                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 微信外卖订单外卖单小票
     */
    @Deprecated
    public static void printWechatReceipt(final WechatOrderModel wechatOrderModel, String hostId, String fsUserName) {
        if (wechatOrderModel == null) {
            return;
        }
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop", ShopDBModel.class);
        if (shopDBModel == null) {
            return;
        }
        String businessDate = HostUtil.getHistoryBusineeDate(shopDBModel.fsShopGUID);
        if (TextUtils.isEmpty(businessDate)) {
            businessDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        }

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "", businessDate,
                0,
                fsUserName,
                "0", PrintReportId.WECHAT_ORDER_RECEIPT,
                hostId,
                true);

        HashMap<String, Object> datas = new HashMap<>();

        //打印美味广告
        PrintUtil.printMWAD(datas);
        try {
            datas.put("title", "微信外卖单");
            datas.put("title_little", "");
            datas.put("orderNum", "");
            datas.put("orderId", "#" + wechatOrderModel.fsorderno);
            String restNum = "POS单号:" + wechatOrderModel.localOrderId;
            if (TextUtils.isEmpty(wechatOrderModel.localOrderId)) {
                restNum = "";
            }
            datas.put("order_num", restNum);//本地订单号
            datas.put("fsAddr", shopDBModel.fsAddr);
            datas.put("fsShopName", shopDBModel.fsShopName);
//            if (wechatOrderModel.fistatus == 11) {
//                datas.put("payStatus", "支付状态:未支付");
//            } else {
//                datas.put("payStatus", "支付状态:已支付");
//            }
            datas.put("payStatus", wechatOrderModel.optPayState());
            datas.put("data", wechatOrderModel.fscreatetime);

            datas.put("orderitem", wechatOrderModel.orderitem);
            datas.put("deliveryFee", wechatOrderModel.fddistribution.toString());
            datas.put("quan", "");
            datas.put("totle", wechatOrderModel.fdrealamount.toString());
            datas.put("address", wechatOrderModel.fsaddress);
            datas.put("distributionPhone", wechatOrderModel.fsmobile);
            datas.put("distributionName", wechatOrderModel.fsname);
            datas.put("distributionStartTime", "期望送达时间:" + wechatOrderModel.fsarrivetime);
            datas.put("orderDesc", wechatOrderModel.fsremark);
            datas.put("PrintTime", DateUtil.getCurrentTime());

            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);

            datas.put("deliveryFee", wechatOrderModel.fddistribution);
            //餐盒费
            if (wechatOrderModel.fdboxamount != null && wechatOrderModel.fdboxamount.compareTo(BigDecimal.ZERO) > 0) {
                datas.put("boxFee", wechatOrderModel.fdboxamount);
            }

            //合计
            datas.put("subTotal", wechatOrderModel.optSubTotal());

            datas.put("bizType", 4);  //后台数据库订单号
            datas.put("person", wechatOrderModel.fidishwarenum);  //后台数据库订单号
            datas.put("readyFoodMode", "立即备餐");  //第三方每日订单序号

            //实付
            datas.put("total", wechatOrderModel.fdsellamount.toPlainString());
            //实收
            if (wechatOrderModel.fdrealamount != null && wechatOrderModel.fdrealamount.compareTo(BigDecimal.ZERO) > 0) {
                datas.put("earnestMoney", wechatOrderModel.fdrealamount.toPlainString());
            }
            //优惠金额
            datas.put("youhui", wechatOrderModel.fdcoupon);

            datas.put("address", wechatOrderModel.fsaddress);
            datas.put("distributionPhone", wechatOrderModel.fsmobile);
            datas.put("distributionName", wechatOrderModel.fsname);

            datas.put("distributionStartTime", "期望送达时间:立即送达");

            datas.put("orderDesc", wechatOrderModel.fsremark);
            datas.put("invoice", wechatOrderModel.optInvoice());
            datas.put("PrintTime", DateUtil.getCurrentTime());
            datas.put("tempAppOrder", wechatOrderModel);
            datas.put("printTailMessage", PrintConfig.PRINT_TAIL_MESSAGE);

            datas.put("fiPrintNo", 0);
            datas.put("fsDptrName", "站点：" + hostId);//当前站点名称
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.logBusiness("打印微信外卖小票异常：" + JSON.toJSONString(wechatOrderModel) + " 异常信息: " + e.getMessage());
            RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "打印微信外卖小票异常：" + JSON.toJSONString(wechatOrderModel), "异常信息：" + e.getMessage());
        }
        task.uri = "bill/wechatOrderReceipt";
        task.fsPrnData = JSON.toJSONString(datas);

        String fsPrinterName = getPrintName(hostId, true);

        task.fsPrinterName = fsPrinterName;

        //处理外卖单的打印份数
        String printCountConfig = CommonDBUtil.getConfig(DBPrintConfig.NET_ORDER_PRINT_COUNT);
        int printCountNum = StringUtil.toInt(printCountConfig, 1);
        if (printCountNum < 1) {
            printCountNum = 1;
        }
        for (int i = 0; i < printCountNum; i++) {
//            task = task.clone();
//            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();

            task.fsPrnData = null;
            task = task.clone();
            task.fiPrintNo = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", task.fiPrintNo);
            task.fsPrnData = JSON.toJSONString(datas);

            task.fsPrinterName = fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        }
    }

    /**
     * 是否是外卖单
     *
     * @return true 是
     * false 不是
     */
    public static boolean isTackeOut(int bizType) {
        if (bizType != NetworkConstans.BIZ_TYPE_TAKEOUT
                && bizType != NetworkConstans.BIZ_TYPE_FOODBOX
                && bizType != NetworkConstans.BIZ_TYPE_TAKEOUT_XIAGAOXIANONG_HOT
                && bizType != NetworkConstans.BIZ_TYPE_TAKEOUT_XIAGAOXIANONG_COLD) {
            return false;
        }
        return true;
    }


}
