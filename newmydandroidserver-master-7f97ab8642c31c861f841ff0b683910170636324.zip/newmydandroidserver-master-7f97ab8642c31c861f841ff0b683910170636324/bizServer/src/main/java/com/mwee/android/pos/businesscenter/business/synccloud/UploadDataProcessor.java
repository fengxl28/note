package com.mwee.android.pos.businesscenter.business.synccloud;

import android.content.ContentValues;
import android.support.annotation.WorkerThread;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.businesscenter.driver.BizSyncDriver;
import com.mwee.android.pos.component.datasync.net.UploadDataRequest;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.BillChangeDetailDBModel;
import com.mwee.android.pos.db.business.ChangeTableDBModel;
import com.mwee.android.pos.db.business.ItemChangeTableDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.SellCouponDBModel;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderDBModel;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.SellPickMenuitem;
import com.mwee.android.pos.db.business.SellcheckDBModel;
import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.pos.db.business.SeqnoDBModel;
import com.mwee.android.pos.db.business.TableChangeDetailDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ProgressCalcUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 数据上送的工具类
 * Created by virgil on 16/7/18.
 *
 * @author virgil
 */
public class UploadDataProcessor {
    ///    public final static String KEY_STATUS = "0x99";
///    public final static String KEY_ERROR = "0x98";
    private final static int STATUS_LOADING = 1;
    private final static int STATUS_FREE = 2;
    private static final String TAG = "UploadDataProcessor";
    /**
     * 当前是否有线程在上送数据
     */
    private static volatile boolean uploading = false;

    private static synchronized void uploadFinish(String errorMsg) {
        uploading = false;
    }

    /**
     * 当前是否已经可以在唤起一个线程进行上送
     *
     * @return boolean | true：可以发起上送；false：已经有线程在上送了。
     */
    private static synchronized boolean canUpload() {
        if (!allowUpload()) {
            return false;
        }
        boolean c = !uploading;
        uploading = true;
        return c;
    }

    public static boolean allowUpload() {
        if (!BaseConfig.isProduct()) {
            //if (!TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
            if (!APPConfig.isCasiher() && !TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
                //ServerService.sendSyncMessage(STATUS_FREE, "非生产包请手动开启上送功能");
                return false;
            }
        }
        if (!BindProcessor.isCurrentHostMain()) {
            return false;
        }
        return true;
    }

    private static int totalDataCount, curDataCount;

    private static int calcProgress(int step) {
        curDataCount += step;
        return ProgressCalcUtil.calcProgress(totalDataCount, curDataCount);
    }

    private static void onProgress(IProgressCallback progressCB, int step) {
        if (progressCB != null) {
            int progress = calcProgress(step);
            LogUtil.log("UploadDataProcessor", IProgressCallback.TAG_UPLOAD_ORDER_DATA + " progress-> " + progress);
            progressCB.onProgress(progress, IProgressCallback.TAG_UPLOAD_ORDER_DATA);
        }
    }

    /**
     * 开始上送订单，每张表读取20条数据,菜单表读取４０条数据上送，上送成功之后，再循环读取上送
     *
     * @return boolean | 是否进行上传
     */
    @Deprecated
    public static boolean startUploadAllLocalData(final IExecutorCallback callback) {
        return startUploadAllLocalData(callback, null);
    }

    @Deprecated
    public static boolean startUploadAllLocalData(final IExecutorCallback callback, IProgressCallback progressCB) {
        boolean can = canUpload();
        LogUtil.logBusiness("UploadDataProcessor startUploadAllLocalData 准备上送，判断是否允许上送：" + can + ", uploading->" + uploading);
        if (!can) {
            if (progressCB != null) {
                curDataCount = totalDataCount;
                onProgress(progressCB, 0);
            }
            return false;
        }

        if (curDataCount == 0 && totalDataCount == 0) {
            totalDataCount = calcUnfinishedDataCount();
        }
        onProgress(progressCB, 0);

        BusinessExecutor.executeNoWait(() -> {
            IExecutorCallback checkLeft = new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    LogUtil.logBusiness(TAG, "UploadDataProcessor 批量上送成功，开始检测待上送的数据");

                    BusinessExecutor.executeNoWait(() -> {
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (hasMoreUnFinishedData()) {
                            startUploadAllLocalData(callback, progressCB);
                        } else {
                            LogUtil.logBusiness("startUploadAllLocalData 成功");
                            curDataCount = totalDataCount;
                            onProgress(progressCB, 0);
                            totalDataCount = 0;
                            curDataCount = 0;
                            if (callback != null) {
                                callback.success(responseData);
                            }
                        }
                        return null;
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    curDataCount = -totalDataCount;
                    onProgress(progressCB, 0);
                    totalDataCount = 0;
                    curDataCount = 0;
                    if (callback != null) {
                        callback.fail(responseData);
                    }
                    return false;
                }
            };
            String shopGUID = HostUtil.getShopID();
            List<SeqnoDBModel> seqList = optSeqNo(shopGUID);
            List<ParamvalueDBModel> paramList = optParamValue(shopGUID);
            String sqlUnSuccessedOrder = "select fsSellNo from tbSell where lver>pver and fiBillStatus in (3,5,6) and fsShopGUID='" + shopGUID + "' limit 1";
            List<String> orderList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sqlUnSuccessedOrder);
            StringBuilder sbOrder = new StringBuilder();
            for (String temp : orderList) {
                sbOrder.append("'").append(temp).append("',");
            }
            String sqlWithoutColumnName;
            if (sbOrder.length() > 0) {
                sbOrder.deleteCharAt(sbOrder.length() - 1);
                sqlWithoutColumnName = "where %s in (%s) ";
            } else {
                //如果当前订单号的状态不符合要求，则上送null列表。
                doUpload(checkLeft, progressCB, null, null, null, null, null, null, seqList, paramList, null, null, null, null, null, null);
                return null;
            }

            String sqlIn = String.format(sqlWithoutColumnName, "fsSellNo", sbOrder.toString());
            List<SellDBModel> sellList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellDBModel.class);
            List<SellcheckDBModel> sellCheckList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellcheckDBModel.class);
            List<SellOrderItemDBModel> sellOrderItemList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellOrderItemDBModel.class);
            List<SellreceiveDBModel> sellReceiveList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellreceiveDBModel.class);
            List<SellOrderDBModel> sellOrderList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellOrderDBModel.class);
            List<SellCouponDBModel> sellCouponList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellCouponDBModel.class);
            List<SellPickMenuitem> sellPicks = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellPickMenuitem.class);
            List<ItemChangeTableDBModel> itemChangeTableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, ItemChangeTableDBModel.class);
            List<ChangeTableDBModel> changeTableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, ChangeTableDBModel.class);
            //菜品提成信息
            List<SellOrderItemBonusDBModel> bonusDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIn, SellOrderItemBonusDBModel.class);
            String sqlChange = String.format(sqlWithoutColumnName, "sell_no", sbOrder.toString());
            List<TableChangeDetailDBModel> tableChangeList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlChange, TableChangeDetailDBModel.class);
            List<BillChangeDetailDBModel> menuChangeList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlChange, BillChangeDetailDBModel.class);

            doUpload(checkLeft, progressCB, sellList, sellCheckList, sellOrderItemList,
                    sellReceiveList, sellOrderList, sellCouponList, seqList, paramList,
                    sellPicks, itemChangeTableDBModels, changeTableDBModels, bonusDBModels,
                    tableChangeList, menuChangeList);
            return null;
        });
        return true;
    }

    /**
     * 上送单个订单
     *
     * @param orderID String | orderID
     */
    private static void doUploadSingleOrder(final String orderID) {
        boolean canUpload = canUpload();
        LogUtil.logBusiness(TAG, "doUploadSingleOrder orderId:" + orderID + "; canUpload:" + canUpload);
        if (!canUpload) {
            return;
        }

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadDataProcessor 上送单个订单:" + orderID);
                uploadSingleOrder(orderID);
            }
        });
        thread.setPriority(1);
        thread.start();
    }

    private static List<SeqnoDBModel> optSeqNo(String shopGUID) {
        if (APPConfig.isCasiher()) {
            return null;
        }
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where lver>pver and fsShopGUID='" + shopGUID + "' limit 5", SeqnoDBModel.class);
    }

    private static List<ParamvalueDBModel> optParamValue(String shopGUID) {
        if (APPConfig.isCasiher()) {
            return null;
        }
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where lver>pver and fsShopGUID='" + shopGUID + "' limit 5", ParamvalueDBModel.class);
    }

    /**
     * 上送当前订单
     *
     * @param orderID String
     */
    @WorkerThread
    private static void uploadSingleOrder(final String orderID) {
        String sql1 = "select fiBillStatus from tbSell where fsSellNo='" + orderID + "' and fiBillStatus in (3,5,6)";
        String rightOrderStatusNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql1);
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadDataProcessor [" + orderID + "]订单状态为[" + rightOrderStatusNo + "]");
        LogUtil.logBusiness(TAG, "uploadSingleOrder orderId:" + orderID + "; rightOrderStatusNo:" + rightOrderStatusNo + ";");
        String shopGUID = HostUtil.getShopID();
        List<SeqnoDBModel> seqList = optSeqNo(shopGUID);
        List<ParamvalueDBModel> paramList = optParamValue(shopGUID);
        //如果当前订单号的状态不符合要求，则上送null列表。
        if (TextUtils.isEmpty(rightOrderStatusNo)) {
            doUpload(null, null, null, null,
                    null, null, null, seqList, paramList, null, null, null, null, null, null);
            return;
        }
        String sqlWithoutColumnName = "where %s='%s' ";
        String sql = String.format(sqlWithoutColumnName, "fsSellNo", orderID) + " and fsShopGUID='"+shopGUID+"'";
        List<SellDBModel> sellList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellDBModel.class);
        List<SellcheckDBModel> sellCheckList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellcheckDBModel.class);
        List<SellOrderDBModel> sellOrderList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOrderDBModel.class);
        List<SellreceiveDBModel> sellReceiveList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellreceiveDBModel.class);
        List<SellOrderItemDBModel> sellOrderItemList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOrderItemDBModel.class);
        List<SellCouponDBModel> sellCouponList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellCouponDBModel.class);
        List<SellPickMenuitem> sellPicks = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellPickMenuitem.class);
        List<ItemChangeTableDBModel> itemChangeTableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ItemChangeTableDBModel.class);
        List<ChangeTableDBModel> changeTableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ChangeTableDBModel.class);
        List<SellOrderItemBonusDBModel> bonusDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOrderItemBonusDBModel.class);
        String sqlChange = String.format(sqlWithoutColumnName, "sell_no", orderID);
        List<TableChangeDetailDBModel> tableChangeList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlChange, TableChangeDetailDBModel.class);
        List<BillChangeDetailDBModel> menuChangeList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlChange, BillChangeDetailDBModel.class);

        doUpload(null, sellList, sellCheckList, sellOrderItemList, sellReceiveList, sellOrderList, sellCouponList,
                seqList, paramList, sellPicks, itemChangeTableDBModels, changeTableDBModels, bonusDBModels, tableChangeList, menuChangeList);

    }

    @WorkerThread
    private synchronized static void doUpload(final IExecutorCallback mainCallBack,
                                              final List<SellDBModel> sellList,
                                              final List<SellcheckDBModel> sellCheckList,
                                              final List<SellOrderItemDBModel> sellOrderItemList,
                                              final List<SellreceiveDBModel> sellReceiveList,
                                              final List<SellOrderDBModel> sellOrderList,
                                              final List<SellCouponDBModel> sellCouponList,
                                              final List<SeqnoDBModel> seqList,
                                              final List<ParamvalueDBModel> paramList,
                                              final List<SellPickMenuitem> sellPicks,
                                              List<ItemChangeTableDBModel> itemChangeTableDBModels,
                                              List<ChangeTableDBModel> changeTableDBModels,
                                              List<SellOrderItemBonusDBModel> bonusDBModels,
                                              List<TableChangeDetailDBModel> tableChangeList,
                                              List<BillChangeDetailDBModel> menuChangeList) {
        doUpload(mainCallBack, null, sellList, sellCheckList, sellOrderItemList, sellReceiveList,
                sellOrderList, sellCouponList, seqList, paramList, sellPicks, itemChangeTableDBModels,
                changeTableDBModels, bonusDBModels, tableChangeList, menuChangeList);
    }

    @WorkerThread
    private synchronized static void doUpload(final IExecutorCallback mainCallBack,
                                              IProgressCallback progressCB,
                                              final List<SellDBModel> sellList,
                                              final List<SellcheckDBModel> sellCheckList,
                                              final List<SellOrderItemDBModel> sellOrderItemList,
                                              final List<SellreceiveDBModel> sellReceiveList,
                                              final List<SellOrderDBModel> sellOrderList,
                                              final List<SellCouponDBModel> sellCouponList,
                                              final List<SeqnoDBModel> seqList,
                                              final List<ParamvalueDBModel> paramList,
                                              final List<SellPickMenuitem> sellPicks,
                                              List<ItemChangeTableDBModel> itemChangeTableList,
                                              List<ChangeTableDBModel> changeTableList,
                                              List<SellOrderItemBonusDBModel> bonusDBModels,
                                              List<TableChangeDetailDBModel> tableChangeList,
                                              List<BillChangeDetailDBModel> menuChangeList) {
        UploadDataRequest request = new UploadDataRequest();
        ArrayMap<String, Object> data = new ArrayMap<>();
        boolean empty = true;
        int tempDataCount = 0;
        if (!ListUtil.isEmpty(sellList)) {
            empty = false;
            data.put("tbSell", sellList);
            tempDataCount += sellList.size();
        }
        if (!ListUtil.isEmpty(sellCheckList)) {
            empty = false;
            data.put("tbSellCheck", sellCheckList);
        }
        if (!ListUtil.isEmpty(sellOrderItemList)) {
            empty = false;
            data.put("tbSellOrderItem", sellOrderItemList);
        }
        if (!ListUtil.isEmpty(sellReceiveList)) {
            empty = false;
            data.put("tbSellReceive", sellReceiveList);
        }
        if (!ListUtil.isEmpty(sellOrderList)) {
            empty = false;
            data.put("tbSellOrder", sellOrderList);
        }
        if (!ListUtil.isEmpty(sellCouponList)) {
            data.put("tbSellCoupon", sellCouponList);
        }
        if (!ListUtil.isEmpty(seqList)) {
            empty = false;
            data.put("tbSeqNo", seqList);
            tempDataCount += seqList.size();
        }
        if (!ListUtil.isEmpty(paramList)) {
            empty = false;
            data.put("tbParamValue", paramList);
            tempDataCount += paramList.size();
        }
        if (!ListUtil.isEmpty(sellPicks)) {
            empty = false;
            data.put("tbSellPickMenuitem", sellPicks);
        }
        if (!ListUtil.isEmpty(itemChangeTableList)) {
            empty = false;
            data.put("tbItemChangeTable", itemChangeTableList);
        }
        if (!ListUtil.isEmpty(changeTableList)) {
            empty = false;
            data.put("tbChangeTable", changeTableList);
        }

        if (!ListUtil.isEmpty(bonusDBModels)) {
            empty = false;
            data.put("tbSellOrderItemBonus", bonusDBModels);
        }
        if (!ListUtil.isEmpty(tableChangeList)) {
            empty = false;
            // 后台要求前面加bill_
            data.put("bill_table_change_detail", tableChangeList);
        }
        if (!ListUtil.isEmpty(menuChangeList)) {
            empty = false;
            data.put("bill_change_detail", menuChangeList);
        }
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadDataProcessor 上送数据:\n" +
                "[订单表]=" + (sellList == null ? 0 : sellList.size()) + "条" + "\n" +
                "[订单单序表]=" + (sellOrderList == null ? 0 : sellOrderList.size()) + "条" + "\n" +
                "[订单菜品表]=" + (sellOrderItemList == null ? 0 : sellOrderItemList.size()) + "条" + "\n" +
                "[支付表]=" + (sellCheckList == null ? 0 : sellCheckList.size()) + "条" + "\n" +
                "[支付明细表]=" + (sellReceiveList == null ? 0 : sellReceiveList.size()) + "条" + "\n" +
                "[支付分账表]=" + (sellCouponList == null ? 0 : sellCouponList.size()) + "条" + "\n" +
                "[单号表]=" + (seqList == null ? 0 : seqList.size()) + "条" + "\n" +
                "[划菜]=" + (sellPicks == null ? 0 : sellPicks.size()) + "条" + "\n" +
                "[营业日期表]=" + (paramList == null ? 0 : paramList.size()) + "条" +
                "[转菜记录表]=" + (itemChangeTableList == null ? 0 : itemChangeTableList.size()) + "条" + "\n" +
                "[换桌记录表]=" + (changeTableList == null ? 0 : changeTableList.size()) + "条" +
                "[提成表]=" + (bonusDBModels == null ? 0 : bonusDBModels.size()) + "条" +
                "[转桌表]=" + (tableChangeList == null ? 0 : tableChangeList.size()) + "条" +
                "[转桌菜品明细表]=" + (menuChangeList == null ? 0 : menuChangeList.size()) + "条");
        if (!empty) {
            request.data = JSON.toJSON(data);

            int finalTempDataCount = tempDataCount;
            BusinessCallback callback = new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    IDBOperate<Boolean> op = (db) -> {
                        ContentValues values = new ContentValues(1);
                        if (!ListUtil.isEmpty(seqList)) {
                            for (SeqnoDBModel temp : seqList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SeqnoDBModel.fiSeqNo:" + temp.fiSeqNo + "; temp.pver:" + temp.pver);
                            }
                        }

                        if (!ListUtil.isEmpty(paramList)) {
                            for (ParamvalueDBModel temp : paramList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload ParamvalueDBModel.fsParamId:" + temp.fsparamid + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellCouponList)) {
                            for (SellCouponDBModel temp : sellCouponList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellCouponDBModel.fsSellNo:" + temp.fsSellNo + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellList)) {
                            for (SellDBModel temp : sellList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellDBModel.fssellno:" + temp.fssellno + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellCheckList)) {
                            for (SellcheckDBModel temp : sellCheckList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellcheckDBModel.fssellno:" + temp.fssellno + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellOrderItemList)) {
                            for (SellOrderItemDBModel temp : sellOrderItemList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellOrderItemDBModel.fsItemId:" + temp.fsItemId + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellReceiveList)) {
                            for (SellreceiveDBModel temp : sellReceiveList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellreceiveDBModel.fspaymentid:" + temp.fspaymentid + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellOrderList)) {
                            for (SellOrderDBModel temp : sellOrderList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellOrderDBModel.fssellno:" + temp.fssellno + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(sellPicks)) {
                            for (SellPickMenuitem temp : sellPicks) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellPickMenuitem.fsSellNo:" + temp.fsSellNo + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(itemChangeTableList)) {
                            for (ItemChangeTableDBModel temp : itemChangeTableList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload ItemChangeTableDBModel.fsSellNo:" + temp.fsSellNo + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(changeTableList)) {
                            for (ChangeTableDBModel temp : changeTableList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload ChangeTableDBModel.fsSellNo:" + temp.fsSellNo + "; temp.pver:" + temp.pver);
                            }
                        }

                        if (!ListUtil.isEmpty(bonusDBModels)) {
                            for (SellOrderItemBonusDBModel temp : bonusDBModels) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload SellOrderItemBonusDBModel.fssellno:" + temp.fssellno + "; temp.pver:" + temp.pver);
                            }
                        }

                        if (!ListUtil.isEmpty(tableChangeList)) {
                            for (TableChangeDetailDBModel temp : tableChangeList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload TableChangeDetailDBModel.id:" + temp.id + "; temp.pver:" + temp.pver);
                            }
                        }
                        if (!ListUtil.isEmpty(menuChangeList)) {
                            for (BillChangeDetailDBModel temp : menuChangeList) {
                                temp.pver = temp.lver;
                                values.clear();
                                values.put("pver", temp.pver);
                                temp.update(values, true);
                                LogUtil.logBusiness(TAG, "doUpload BillChangeDetailDBModel.id:" + temp.id + "; temp.pver:" + temp.pver);
                            }
                        }

                        onProgress(progressCB, finalTempDataCount);
                        return true;
                    };
                    RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadDataProcessor 上送数据成功；写入数据库");
                    DBManager.getInstance().executeInTransactionWithOutThread(op);
                    uploadFinish("");
                    BizSyncDriver.checkNeedReload();
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    uploadFinish(responseData.resultMessage);
                    RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadDataProcessor 上送数据失败,resultMessage=" + responseData.resultMessage);
                    return false;
                }
            };
            BusinessExecutor.execute(request, mainCallBack, callback, true);
        } else {
            uploadFinish("没有待同步的订单");
            if (mainCallBack != null) {
                mainCallBack.success(new ResponseData());
            }
        }

    }

    /**
     * 判断是否还有需要上送的数据
     *
     * @return boolean | true:还有需要上送的数据；false：没有了
     */
    @Deprecated
    public static boolean hasMoreUnFinishedData() {
        int count = calcUnfinishedDataCount();
        if (count > 0) {
            return true;
        }
        return false;
    }

    private static int calcUnfinishedDataCount() {
        List<String> tableList = new ArrayList<>();
        tableList.add("tbSell");

        if (!APPConfig.isCasiher()) {
            //订单号和账单号
            tableList.add("tbSeqNo");
            //开关配置及营业日期
            tableList.add("tbParamValue");
        }

        String shopGUID = HostUtil.getShopID();
        String sql = "SELECT count(*) as count FROM %1$s where lver>pver and fsShopGUID='" + shopGUID + "'";
        int count = 0;
        for (String temp : tableList) {
            int i = 0;
            if (TextUtils.equals("tbSell", temp)) {
                i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql + " and fiBillStatus in (3,5,6)", temp)));
            } else {
                i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, temp)));
            }
            count += i;
            LogUtil.log("UploadDataProcessor 上送检测 表[" + temp + "]待上送的数据为：" + i);
        }
        return count;
    }

    /**
     * 服务器异常，要求重新上送所有订单数据
     */
    public static void serverErrorReUploadData() {
        DBManager.getInstance().executeInTransactionWithOutThread((db) -> {
            List<String> tableList = new ArrayList<>();
            tableList.add("tbSellOrderItem");
            tableList.add("tbSell");
            tableList.add("tbSellCheck");
            tableList.add("tbSellReceive");
            tableList.add("tbSellOrder");
            tableList.add("tbSellCoupon");
            tableList.add("tbItemChangeTable");
            tableList.add("tbChangeTable");
            tableList.add("tbSellOrderItemBonus");
            tableList.add("table_change_detail");
            tableList.add("bill_change_detail");
            for (String tableName : tableList) {
                db.execSQL("update " + tableName + " set lver=(lver+5),pver='0' ");
            }
            return true;
        });
    }

    /**
     * 上送订单
     * 1. 上送基础数据
     * 2. 上送报表数据
     */
    @Deprecated
    public static void doUploadOrderWithBaseData() {
        LogUtil.logBusiness(TAG, "doUploadOrderWithBaseData()");
        UploadChangeDataProcessor.startUploadAllLocalChageData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "doUploadOrderWithBaseData() startUploadAllLocalData");
                startUploadAllLocalData(null);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }

    @Deprecated
    public static void doUploadOrderWithBaseData(IProgressCallback progressCb) {
        LogUtil.logBusiness(TAG, "doUploadOrderWithBaseData(progressCb)");
        UploadChangeDataProcessor.startUploadAllLocalChageData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "doUploadOrderWithBaseData(progressCb) startUploadAllLocalData");
                startUploadAllLocalData(null, progressCb);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, progressCb);
    }

    /**
     * 上送单个订单
     * 1. 上送基础数据
     * 2. 上送报表数据
     *
     * @param orderId 订单id
     */
    public static void doUploadSingleOrderWithBaseData(final String orderId) {
        LogUtil.logBusiness(TAG, "doUploadSingleOrderWithBaseData orderId:" + orderId);
        UploadChangeDataProcessor.startUploadAllLocalChageData(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                doUploadSingleOrder(orderId);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }
}
