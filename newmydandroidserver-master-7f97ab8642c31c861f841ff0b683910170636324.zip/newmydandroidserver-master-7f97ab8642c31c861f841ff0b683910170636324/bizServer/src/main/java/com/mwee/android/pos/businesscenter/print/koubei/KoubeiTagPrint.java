package com.mwee.android.pos.businesscenter.print.koubei;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.pos.businesscenter.print.PrintJSONBuilder;
import com.mwee.android.pos.businesscenter.print.PrintReportId;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: 口碑标签打印机
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/6/6
 */
public class KoubeiTagPrint extends KoubeiBasePrint {

    private static final String REPORT_ID = PrintReportId.KOBEI_PRE_ORDER_MAKE;
    private static final String TASK_URI = "order/makesingleTSC";



    String orderId;
    String userName;
    String orderTime;
    String takeNo;
    List<KBPreMenuItemModel> orderDetails;
    DeptDBModel deptDBModel;
    String fsPrinterName;


    public KoubeiTagPrint setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public KoubeiTagPrint setTakeNo(String takeNo) {
        this.takeNo = takeNo;
        return this;
    }

    public KoubeiTagPrint setUserName(String userName) {
        this.userName = userName;
        return this;
    }


    public KoubeiTagPrint setPrinterName(String fsPrinterName) {
        this.fsPrinterName = fsPrinterName;
        return this;
    }


    public KoubeiTagPrint setDeptDBModel(DeptDBModel deptDBModel) {
        this.deptDBModel = deptDBModel;
        return this;
    }


    public KoubeiTagPrint setOrderTime(String orderTime) {
        this.orderTime = orderTime;
        return this;
    }

    public KoubeiTagPrint setOrderDetails(List<KBPreMenuItemModel> orderDetails) {
        this.orderDetails = orderDetails;
        return this;
    }


    @Override
    public void print() {

    }


    @Override
    protected PrintTaskDBModel buildInitPrintTaskModel() {
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderId,
                "",
                getDefaultBusinessDate(),
                0,
                userName,
                "0",
                REPORT_ID,
                getDefaultHostId(),
                true
        );
        task.uri = TASK_URI;
        return task;
    }

    @Override
    protected JSONObject buildPrintJSONData() {
        JSONObject data = new JSONObject();
        ShopDBModel shopDBModel = getDefaultShopModel();
        String shopName = "";
        if (shopDBModel != null) {
            shopName = shopDBModel.fsShopName;
        }
        data.put("shopname", shopName);
        String id = "单号：" + takeNo;
        data.put("id", id);

        String tel = "";
        if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
            tel = shopDBModel.fsTel;
        }
        String time;
        if (!TextUtils.isEmpty(tel)) {
            data.put("phone", "电话：" + tel);
            time = DateUtil.formartDateStrToTarget(orderTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
        } else {
            time = DateUtil.formartDateStrToTarget(orderTime, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm");
        }
        data.put("time", time);

        return data;
    }

    @Override
    protected List<PrintTaskDBModel> onBuildTasks(JSONObject data, PrintTaskDBModel task) {
        ArrayList<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        for (int i = 0; i < orderDetails.size(); i++) {
            KBPreMenuItemModel itemModel = orderDetails.get(i);
            int dishQty = itemModel.dish_num.intValue();
            for(int j = 0; j < dishQty; j++) {
                PrintTaskDBModel cloneTask = task.clone();
                data.put("itemname", itemModel.dish_name);
                data.put("price", Calc.formatShow(itemModel.sell_price) + "元");
                data.put("num", itemModel.dish_num + "/" + itemModel.dish_unit);
                if (!TextUtils.isEmpty(itemModel.memo)) {
                    data.put("itemnote", itemModel.memo + "");  //备注
                }
                String sequence = j + 1 + "/" + dishQty;
                data.put("sequence", sequence);
                int fiPrintNo = PrintJSONBuilder.generatePrintNO();
                data.put("fiPrintNo", fiPrintNo);
                cloneTask.fiPrintNo = fiPrintNo;
                cloneTask.fsPrnData = data.toJSONString();
                if (deptDBModel != null) {
                    cloneTask.fsPrinterName = deptDBModel.fsPrinterName;
                    cloneTask.fsDeptId = deptDBModel.fsDeptId;
                    cloneTask.fsDeptName = deptDBModel.fsDeptName;
                } else {
                    cloneTask.fsPrinterName = fsPrinterName;
                    cloneTask.fsDeptName = "Cashier";
                }
                printTaskDBModels.add(cloneTask);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, JSON.toJSONString(cloneTask));
            }
        }
        return printTaskDBModels;
    }

    @Override
    public List<PrintTaskDBModel> buildShouldPrintTasks() {
        JSONObject data = buildPrintJSONData();
        if (data == null) {
            return null;
        }
        PrintTaskDBModel task = buildInitPrintTaskModel();
        if (task == null) {
            return null;
        }
        return onBuildTasks(data, task);
    }


}
