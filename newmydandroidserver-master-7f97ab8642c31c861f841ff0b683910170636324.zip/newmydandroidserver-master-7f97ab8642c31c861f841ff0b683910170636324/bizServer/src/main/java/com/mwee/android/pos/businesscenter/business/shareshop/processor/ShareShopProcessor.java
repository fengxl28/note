package com.mwee.android.pos.businesscenter.business.shareshop.processor;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.shareshop.been.model.ShareShopRefundDishesModel;
import com.mwee.android.pos.business.shareshop.been.model.ShareShopRefundPaymentModel;
import com.mwee.android.pos.business.shareshop.been.model.ShareShopRefundPushModel;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.business.shareshop.api.ShareShopApi;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by liuxiuxiu on 2018/3/29.
 */

public class ShareShopProcessor {

    /**
     * 同步锁
     */
    private final static Object cacheLock = new Object();
    /**
     * 内存中缓存的commit处理结果，key为CommitID，value为RapidActionRequset；
     * 只缓存一定的时间
     */
    private final static ArrayMap<String, Integer> commitHistory = new ArrayMap<>();
    /**
     * 是否有线程正在处理，key为CommitID，value为Object
     */
    private final static ArrayMap<String, Object> commitProcessing = new ArrayMap<>();


    public static void receivePushMsg(String msgBody) {
        if (TextUtils.isEmpty(msgBody)) {
            RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 收到推送空数据", msgBody);
            return;
        }

        try {
            JSONObject jsonObject = new JSONObject(msgBody);
            if (jsonObject.isNull("outerOrderId")) {  //订单相关的推送,没有outOrderId 的消息都是异常的消息
                //共享餐厅的退款
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅的退款监控  没有给到外部订单号 " + DateUtil.getCurrentTime(), msgBody);
                return;
            }

            String orderId = jsonObject.optString("orderId");
            if (TextUtils.isEmpty(orderId)) {
                //共享餐厅的退款,没有orderId 的消息都是异常的消息
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅的退款监控  没有给到订单号 " + DateUtil.getCurrentTime(), msgBody);
                return;
            }
            String timestamp = jsonObject.optString("timestamp");
            if (TextUtils.isEmpty(timestamp)) {
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅的退款监控  没给时间戳 " + DateUtil.getCurrentTime(), msgBody);
                return;
            } else {
                timestamp = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msg from push_msg_stack where msg='" + timestamp + "'");
                if (TextUtils.isEmpty(timestamp)) {
                    String time = DateUtil.getCurrentTime();
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "insert into push_msg_stack ('msg','updateTime') values ('" + msgBody + "','" + time + "')");
                }
            }

            if (checkNeedGoNext(jsonObject.optString("timestamp"), orderId, msgBody)) {
                receiveShareShopRefundPush(msgBody);
            }

        } catch (JSONException e) {
            RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 数据解析异常", msgBody);

        }
    }

    /**
     * 收到共享餐厅退款推送
     *
     * @param msgBody
     */
    public static void receiveShareShopRefundPush(final String msgBody) {
        if (TextUtils.isEmpty(msgBody)) {
            RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 收到推送空数据", msgBody);
            return;
        }
        String locedTableId = "";
        try {
            ShareShopRefundPushModel refundPushModel = JSON.parseObject(msgBody, ShareShopRefundPushModel.class);
            if (refundPushModel == null) {
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 处理消息异常---转换ShareShopRefundPushModel异常", msgBody);
                return;
            }
            if (!TextUtils.equals(ServerCache.getInstance().shopID, refundPushModel.shopId)) {
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 店铺ID不一致", refundPushModel.shopId, ServerCache.getInstance().shopID);
                return;
            }
            String fssellno = refundPushModel.outerOrderId;
            OrderCache orderCache = OrderSession.getInstance().getOrder(fssellno);
            if (orderCache == null) {
                log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 没找到对应订单", refundPushModel.outerOrderId, msgBody);
                return;
            }
            PaySession paySession = OrderSession.getInstance().getPay(fssellno);
            if (paySession != null && paySession.locked == 1) {
                log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 订单已交班，不处理退款信息", refundPushModel.outerOrderId, msgBody);
                return;
            }

            UserDBModel user = RapidBiz.getCloudUser();

            if (user == null) {
                user = new UserDBModel();
                user.fsUserId = "cash";
            }
            user.fsUserName = !TextUtils.isEmpty(refundPushModel.operator) ? refundPushModel.operator : "云收银";

            TableBizModel tableBizModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tableBiz where fsmtableid = '" + orderCache.fsmtableid + "' ", TableBizModel.class);
            if (tableBizModel == null) {
                TableBusinessUtil.openTable(orderCache.fsmtableid, fssellno, user);
                tableBizModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tableBiz where fsmtableid = '" + orderCache.fsmtableid + "' ", TableBizModel.class);
            }

            String reason = TextUtils.isEmpty(refundPushModel.reason) ? "云端操作" : refundPushModel.reason;

            //订单已结账
            if (orderCache.orderStatus == OrderStatus.PAIED) {
                if (TextUtils.equals(tableBizModel.fsmtablesteid, "2") && !TextUtils.equals(tableBizModel.fssellno, fssellno)) {
                    log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 桌台正在使用中，不处理退款信息", JSON.toJSONString(tableBizModel), msgBody);
                    return;
                } else {
                    BillUtil.antiPayOrderStatus(orderCache, user, fssellno, reason);
                    TableBusinessUtil.openTable(orderCache.fsmtableid, fssellno, user);
                }
            }

            //解锁桌台
            TableBusinessUtil.unlockTargetTable(orderCache.fsmtableid);
            //重新锁定桌台
            String errMsg = TableBusinessUtil.lockTable(orderCache.fsmtableid, HostBiz.cloudsite, user.fsUserId, user.fsUserName);
            if (!TextUtils.isEmpty(errMsg)) {
                log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 锁桌异常 " + errMsg, JSON.toJSONString(tableBizModel), msgBody);
                return;
            }
            locedTableId = orderCache.fsmtableid;

            // 剔出正在该桌台的服务员
            NotifyToClient.refreshShareShopOrderChange(orderCache.fsmtableid);

            String orderToken = ServerCache.getInstance().generateNewToken(fssellno);

            String fsmtableId = OrderSession.getTableID(fssellno);
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fssellno, "收到共享餐厅退款推送");
            try{
                orderCache = OrderSession.getInstance().getOrder(fssellno);
                OrderCache cloneCache = orderCache.clone();

                paySession = OrderSession.getInstance().getPay(fssellno);
                PaySession cloneSession = paySession.clone();
                if (!ListUtil.isEmpty(refundPushModel.refundDishes) && !ListUtil.isEmpty(orderCache.originMenuList)) {
                    boolean finded;
                    for (ShareShopRefundDishesModel shopRefundDishesModel : refundPushModel.refundDishes) {
                        finded = false;
                        if (shopRefundDishesModel == null) {
                            continue;
                        }
                        for (MenuItem menuItem : cloneCache.originMenuList) {
                            if (menuItem == null) {
                                continue;
                            }
                            if (TextUtils.equals(shopRefundDishesModel.commitId, menuItem.menuBiz.thirduniq) && !TextUtils.isEmpty(menuItem.menuBiz.thirduniq)) {
                                finded = true;
                                if (menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).compareTo(shopRefundDishesModel.voidNum) < 0) {
                                    log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 退菜数量不足 " + shopRefundDishesModel.commitId + " ： " + menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum), JSON.toJSONString(shopRefundDishesModel), JSON.toJSONString(cloneCache));
                                    shopRefundDishesModel.voidNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                                }
                                menuItem.doVoid(shopRefundDishesModel.voidNum, user.fsUserId, user.fsUserName, reason);
                                break;
                            }
                        }

                        if (!finded) {
                            log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 没有找到对应菜品" + shopRefundDishesModel.commitId, JSON.toJSONString(shopRefundDishesModel), JSON.toJSONString(cloneCache));
                        }

                    }
                }

                PayModel parentPay = null;

                if (!ListUtil.isEmpty(refundPushModel.refundPaymentList)) {
                    for (ShareShopRefundPaymentModel shopRefundPaymentModel : refundPushModel.refundPaymentList) {
                        if (shopRefundPaymentModel == null) {
                            continue;
                        }

                        //构建支付明细
                        if (TextUtils.isEmpty(shopRefundPaymentModel.paymentId)) {
                            continue;
                        }

                        BigDecimal fdReceMoney = BigDecimal.ZERO;
                        if ((shopRefundPaymentModel.refundAmount != null && shopRefundPaymentModel.refundAmount.compareTo(BigDecimal.ZERO) > 0)) {
                            fdReceMoney = shopRefundPaymentModel.refundAmount;
                        } else if ((shopRefundPaymentModel.refundScore != null && shopRefundPaymentModel.refundScore.compareTo(BigDecimal.ZERO) > 0)) {
                            fdReceMoney = shopRefundPaymentModel.refundScore;
                        } else if ((shopRefundPaymentModel.refundCardAmount != null && shopRefundPaymentModel.refundCardAmount.compareTo(BigDecimal.ZERO) > 0)) {
                            fdReceMoney = shopRefundPaymentModel.refundCardAmount;
                        } else if ((shopRefundPaymentModel.refundCouponAmount != null && shopRefundPaymentModel.refundCouponAmount.compareTo(BigDecimal.ZERO) > 0)) {
                            fdReceMoney = shopRefundPaymentModel.refundCouponAmount;
                        }

                        if ((fdReceMoney.compareTo(BigDecimal.ZERO) == 0) &&
                                (ListUtil.isEmpty(shopRefundPaymentModel.couponNo))) {
                            log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 退款金额无效", JSON.toJSONString(shopRefundPaymentModel), null);
                            continue;
                        }

                        if (TextUtils.equals(PayType.REWART, shopRefundPaymentModel.paymentId)) {
                            orderCache.rewardinfo = "";
                            OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, orderCache.rewardinfo);
                            continue;
                        }
                        PayOriginModel data = null;

                        if (!TextUtils.isEmpty(refundPushModel.memberNo) && !ListUtil.isEmpty(shopRefundPaymentModel.couponNo)) {
                            for (String couponId : shopRefundPaymentModel.couponNo) {
                                data = OrderUtil.buildPayModelByMemberTicketID(couponId);
                                parentPay = buildPayModel(data, parentPay, user, fdReceMoney, refundPushModel.orderId, refundPushModel.memberNo);
                                if (parentPay == null) {
                                    log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款  构建支付方式失败 " + shopRefundPaymentModel.paymentId, JSON.toJSONString(shopRefundPaymentModel), cloneSession);
                                    return;
                                }
                            }
                        } else {
                            if (OrderUtil.isMWMemberTicketByPayID(shopRefundPaymentModel.paymentId)) {
                                data = OrderUtil.buildPayModelByPaymentID(shopRefundPaymentModel.paymentId);
                            } else {
                                data = OrderUtil.buildPayModelByPaymentID(shopRefundPaymentModel.paymentId);
                            }
                            parentPay = buildPayModel(data, parentPay, user, fdReceMoney, refundPushModel.orderId, refundPushModel.memberNo);
                            if (parentPay == null) {
                                log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款  构建支付方式失败 " + shopRefundPaymentModel.paymentId, JSON.toJSONString(shopRefundPaymentModel), cloneSession);
                                return;
                            }
                        }
                    }
                }

                //将支付明细进行落帐----当没有支付信息的时候只更新订单退菜记录，当有支付信息时必须支付方式和菜品记录同时更新成功
                if (parentPay != null) {
                    SocketResponse<PayResultResponse> socketResponse = BillUtil.addPayDetail(orderToken, orderCache.orderID, user, HostBiz.cloudsite, true, parentPay);
                    if (socketResponse.success()) {
                        cloneCache.reCalcAllByAll();
                        OrderSession.getInstance().writeOrder(fssellno, cloneCache, true, "receiveShareShopRefundPush");
//                        OrderSession.getInstance().writeOrder(fssellno, true);

                        cloneSession = OrderSession.getInstance().generatePaySession(OrderSession.getInstance().getOrder(fssellno), user, HostBiz.cloudsite);
                        OrderSession.getInstance().writePay(fssellno, cloneSession);
                        OrderSession.getInstance().writePay(fssellno, true);
                    } else {
                        log(refundPushModel.orderId, -1, refundPushModel.timestamp, "共享餐厅退款 落账失败", JSON.toJSONString(parentPay), cloneSession);
                        return;
                    }
                } else if (!ListUtil.isEmpty(refundPushModel.refundDishes) && !ListUtil.isEmpty(orderCache.originMenuList)) {
                    cloneCache.reCalcAllByAll();
                    OrderSession.getInstance().writeOrder(fssellno, cloneCache, true, "receiveShareShopRefundPush 2");
//                    OrderSession.getInstance().writeOrder(fssellno, cloneCache);
//                    OrderSession.getInstance().writeOrder(fssellno, true);
                }
            }finally{
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fssellno, "收到共享餐厅退款推送");
            }

            ShareShopApi.notifyServerDealSuccess(refundPushModel.orderId, 1, 1);
            saveCache(refundPushModel.timestamp, 1);

        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅退款 处理消息异常", msgBody, e.getStackTrace());
            return;
        } finally {
            //如果操作过锁桌，需要解绑,通知站点刷新桌台状态
            if (!TextUtils.isEmpty(locedTableId)) {
                TableBusinessUtil.unlockTargetTable(locedTableId);
                NotifyToClient.refreshTableOrOrders();
            }
        }
    }

    /**
     * 构建支付方式
     *
     * @param data
     * @param parentPay
     * @param user
     * @param fdReceMoney
     * @param orderId
     * @param memberNo
     * @return
     */
    public static PayModel buildPayModel(PayOriginModel data, PayModel parentPay, UserDBModel user, BigDecimal fdReceMoney, String orderId, String memberNo) {

        //如果没有找到支付方式，则使用默认的卡券
        if (data == null) {
            data = PayUtil.addDefaultCoupon();
        }
        if (data == null) {
            return null;
        }

        PayModel currentSelectPay = new PayModel(user.fsUserId, user.fsUserName);
        currentSelectPay.data = data;
        currentSelectPay.payAmount = fdReceMoney.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("-1"));
        currentSelectPay.status = 1;
        currentSelectPay.showNote = "";
        currentSelectPay.createTime = DateUtil.getCurrentTime();
        currentSelectPay.businessInfo = orderId;

        //写入共享餐厅属性
        currentSelectPay.writeSharedShopPay();
        //写入秒付属性
        currentSelectPay.writeRapid();

        if (OrderUtil.isMWMemberTicket(data.payTypeGroupID)) {
            currentSelectPay.data.memberCouponModel = new MemberCouponModel();
            currentSelectPay.data.memberCouponModel.code = "";
        }
        if (!TextUtils.isEmpty(memberNo)) {
            currentSelectPay.memberCardNO = memberNo;
        }
        if (parentPay == null) {
            parentPay = currentSelectPay;
        } else {
            if (parentPay.secondPayList == null) {
                parentPay.secondPayList = new ArrayList<>();
            }
            parentPay.secondPayList.add(currentSelectPay);
        }

        return parentPay;
    }

    private static void log(String orderId, int actCode, String timestamp, String msg, String trace1, Object trace2) {
        RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, msg, trace1, trace2);
        ShareShopApi.notifyServerDealSuccess(orderId, 5, actCode);
        saveCache(timestamp, actCode);
    }


    /**
     * 是否需要处理当前的Commit，判断逻辑如下：
     * 1，是否已经有一个线程在处理，如果是，则中断；
     * 2，是否已经在内存中缓存了指定timestamp的处理结果，如果是，则中断；
     * 3，如果已经在db中缓存了指定timestamp的处理结果，如果是，则中断；
     *
     * @param timestamp String
     * @return boolean | 是否需要进行处理业务：true：没有缓存，交由业务处理；false：有缓存或者在处理中，业务不需要进行处理
     */
    private static boolean checkNeedGoNext(String timestamp, String orderId, String msgBody) {
        int result = 0;
        synchronized (cacheLock) {
            Object lock = commitProcessing.get(timestamp);
            if (lock != null) {
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅 已有线程在处理", timestamp, msgBody);
                return false;
            }
            Integer resultInteger = commitHistory.get(timestamp);
            if (resultInteger == null) {
                result = 0;
            } else {
                result = resultInteger;
            }
            if (result == 0) {
                String resultStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msgResult from push_msg_stack where msg='" + timestamp + "'");
                result = StringUtil.toInt(resultStr, 0);
                if (result != 0) {
                    RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅 已有处理结果缓存在内存中" + result, timestamp, msgBody);
                    ShareShopApi.notifyServerDealSuccess(orderId, 5, result);
                    return false;
                }
            } else {
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND_ERR, "共享餐厅 已有处理结果缓存在内存中" + result, timestamp, msgBody);
                ShareShopApi.notifyServerDealSuccess(orderId, 5, result);
                return false;
            }

            if (result == 0) {
                commitProcessing.put(timestamp, new Object());
            }
        }
        return true;
    }

    /**
     * 移除缓存{@link #commitProcessing}的处理中的timestamp，
     *
     * @param timestamp String
     */
    public static void removeProcessingCache(String timestamp) {
        synchronized (cacheLock) {
            commitProcessing.remove(timestamp);
        }
    }

    /**
     * 移除缓存{@link #commitHistory}里所缓存的处理结果，
     *
     * @param timestamp String
     */
    protected static void removeCommitHistoryCache(String timestamp) {
        synchronized (cacheLock) {
            commitHistory.remove(timestamp);
        }
    }

    /**
     * 缓存timestamp的结果到{@link #commitHistory}和DB中用于去重
     */
    public static void saveCache(String temptime, final int actCode) {
        //先判断是否需要缓存
        synchronized (cacheLock) {
            commitHistory.put(temptime, actCode);
            removeProcessingCache(temptime);
        }

        GlobalLooper.postDelayed(new Runnable() {
            @Override
            public void run() {
                removeCommitHistoryCache(temptime);
            }
        }, 1000 * 60 * 5);

        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update push_msg_stack set msgResult='" + actCode + "' where msg='" + temptime + "'");
                return null;
            }
        });

    }


}
