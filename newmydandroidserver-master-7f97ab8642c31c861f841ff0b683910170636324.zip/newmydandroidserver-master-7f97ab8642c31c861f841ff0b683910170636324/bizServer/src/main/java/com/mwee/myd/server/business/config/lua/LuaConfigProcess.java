package com.mwee.myd.server.business.config.lua;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.configuration.core.ConfigurationProcess;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.business.config.ConfigConstant;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.io.File;

/**
 * @ClassName: ConfigProcess
 * @Description:
 * @author: Cannan
 * @date: 2017/8/24 上午10:49
 */
public class LuaConfigProcess {

    public static final int CONFIGURATION_LUA = 201;

    private volatile static LuaConfigProcess instance;

    private ConfigurationProcess process;

    public static LuaConfigProcess getInstance() {
        if (instance == null) {
            synchronized (LuaConfigProcess.class) {
                if (instance == null) {
                    instance = new LuaConfigProcess();
                }
            }
        }
        return instance;
    }

    public synchronized void checkInit() {
        if (process == null) {
            process = new ConfigurationProcess.Builder()
                    .setPresenter(new LuaConfigurationPresenter())
                    .setProduct(BaseConfig.isProduct())
                    .setBizType(CONFIGURATION_LUA)
                    .setShopId(ClientMetaUtil.getSettingsValueByKey(META.SHOPID))
                    .setDeviceId(ServerHardwareUtil.getHardWareSymbol())
                    .build();
        }
    }

    public void refresh() {
        checkInit();
        process.refresh(ClientMetaUtil.getSettingsValueByKey(META.SHOPID));
    }

    /**
     * 校验缓存中，是否有新版本
     *
     * @return
     */
    public boolean checkCache() {
        LogUtil.logBusiness("Lua", "开始检测 lua 脚本版本");
        checkInit();
        return process.start(GlobalCache.getContext());
    }

    public String getData() {
        File directory = new File(ConfigConstant.getLuaDirPath(GlobalCache.getContext()));
        if (!directory.exists() || !directory.isDirectory()) {
            return "";
        }
        File[] files = directory.listFiles();
        if (files == null || files.length == 0) {
            return "";
        }
        File target = files[0];
        return FileUtil.readFile(target.getAbsolutePath());
    }
}
