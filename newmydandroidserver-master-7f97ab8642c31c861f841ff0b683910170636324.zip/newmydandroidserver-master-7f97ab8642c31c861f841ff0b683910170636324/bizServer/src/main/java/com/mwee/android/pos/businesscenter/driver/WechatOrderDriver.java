package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.netbiz.wechatOrder.WechatOrderApi;
import com.mwee.android.pos.businesscenter.netbiz.wechatOrder.WechatOrderDBUtil;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.wechatorder.GetAllWechatOrderResponse;
import com.mwee.android.pos.connect.business.wechatorder.OptWechatOrderFromBizResponse;
import com.mwee.android.pos.connect.business.wechatorder.UpdateWechatOrderResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * Created by liuxiuxiu on 2017/8/25.
 */
@SuppressWarnings("unused")
public class WechatOrderDriver implements IDriver {

    private static final String TAG = "wechatOrder";

    /**
     * 获取网络订单列表
     * 1、同步后台订单到本地
     * 2、解析同步数据，并将新订单插入数据库
     * 3、拉取数据库所有订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/ordersList")
    public SocketResponse ordersList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final GetAllWechatOrderResponse myResponseData = new GetAllWechatOrderResponse();
        response.data = myResponseData;
        try {
            final JSONObject request = JSON.parseObject(param);
            int currentPage = request.getInteger("currentPage");
            final String businessDate = request.getString("businessDate"); //营业日期
            final String time = request.getString("time");         //时间限制
            final String areaIds = request.getString("areaIds");      //不接受的区域
            final boolean checkDate = request.containsKey("checkDate") ? request.getBoolean("checkDate") : false;
            if (currentPage == 1) {
                WechatOrderApi.getDatasFromServer(false, new IResult() {
                    @Override
                    public void callBack(boolean result, String msg) {
                        if (result) {
                            response.code = SocketResultCode.SUCCESS;
                            response.message = msg;
                        } else {
                            response.message = msg;
                            response.code = SocketResultCode.BUSINESS_FAILED;
                        }

                        myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);

                        getPageWechatOrders(myResponseData, currentPage, businessDate, checkDate);
                    }
                });
            } else {
                getPageWechatOrders(myResponseData, currentPage, businessDate, checkDate);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    private void getPageWechatOrders(GetAllWechatOrderResponse myResponseData, int currentPage, String businessDate, boolean checkDate) {
        String date = businessDate;
        if (!checkDate) {  //获取网络订单不筛日期
            date = "";
        }
        Pair<Integer, List<WechatOrderModel>> allWechatOrders = WechatOrderDBUtil.getAllWechatOrders(currentPage, date,false);
        myResponseData.wechatOrderModelList = allWechatOrders.second;

//        String sql = "select count(*) from (" + allWechatOrders.first + ")";
//        int totalRecord = Integer.valueOf(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql));
//        myResponseData.pageCount = (totalRecord + 20 - 1) / 20;
        myResponseData.pageCount = (allWechatOrders.first == null ? 0 : allWechatOrders.first + 20 - 1) / 20;
    }

    /**
     * 更新网络订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateWechatOrder")
    public SocketResponse updateNetOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final UpdateWechatOrderResponse myResponseData = new UpdateWechatOrderResponse();

            final String orderId = request.getString("fsorderno"); //订单号
            final String areaIds = request.getString("areaIds"); //区域id
            final int operation = request.getInteger("operation");         //订单操作

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            final WechatOrderModel tempAppOrder = WechatOrderDBUtil.getWechatOrderByNo(orderId);
            if (tempAppOrder == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }
            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            IResponse<String> iResponse = new IResponse<String>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, String info) {
                    myResponseData.wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(orderId);
                    myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                    response.data = myResponseData;
                    if (result) {
                        response.message = "success";
                        response.code = SocketResultCode.SUCCESS;
                        NotifyToClient.updateWechatOrder(orderId);
                    } else {
                        response.message = msg;
                        response.code = SocketResultCode.BUSINESS_FAILED;
                    }
                }
            };

            WechatOrderApi.updateWechatOrderStatus(orderId, operation, 5, iResponse, head.hd, userDBModel.fsUserName);

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 更新网络订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optWechatOrderById")
    public SocketResponse optWechatOrderById(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final OptWechatOrderFromBizResponse myResponseData = new OptWechatOrderFromBizResponse();
            final String orderId = request.getString("fsorderno"); //订单号
            try {
                myResponseData.wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(orderId);
                if (myResponseData.wechatOrderModel == null || ListUtil.isEmpty(myResponseData.wechatOrderModel.orderitem)) {
                    WechatOrderApi.getWechatOrderByNo(orderId, false, new IResponse<WechatOrderModel>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, WechatOrderModel info) {
                            if (result && info != null) {
                                myResponseData.wechatOrderModel = info;
                                response.message = "success";
                                response.data = myResponseData;
                                response.code = SocketResultCode.SUCCESS;
                            } else {
                                response.message = msg;
                                response.data = myResponseData;
                                response.code = SocketResultCode.BUSINESS_FAILED;
                            }
                        }
                    });
                } else {
                    response.message = "success";
                    response.data = myResponseData;
                    response.code = SocketResultCode.SUCCESS;
                }
                myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(request.getString("businessDate"), request.getString("time"), request.getString("areaIds"));
            } catch (Exception e) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                LogUtil.logError(e);
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 打印网络订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/printWechatOrder")
    public SocketResponse printWechatOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final String orderId = request.getString("fsorderno"); //订单号
            WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(orderId);
            if (wechatOrderModel != null) {
                String hostId = head.hd;
                UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
                String fsUserName = userDBModel.fsUserName;
                switch (request.getInteger("receiptType")) {
                    case 1:
                        PrintNetOrderUtil.printWechatReceipt(wechatOrderModel, hostId, fsUserName);
                        break;
                    case 0:
                        PrintNetOrderUtil.printWechatKDSReceipt(wechatOrderModel, false, hostId, fsUserName);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @Override
    public String getModuleName() {
        return TAG;
    }
}
