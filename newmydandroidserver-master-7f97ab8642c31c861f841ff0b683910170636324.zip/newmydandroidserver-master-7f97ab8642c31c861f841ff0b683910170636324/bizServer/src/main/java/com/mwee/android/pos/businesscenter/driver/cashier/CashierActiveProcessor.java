package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.CashierLoginPosResponse;
import com.mwee.android.cashier.connect.bean.socket.CashierLoginResponse;
import com.mwee.android.pos.businesscenter.business.active.ActiveUtil;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.DownLoadDataProcessor;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * 美收银激活的相关处理
 * Created by virgil on 2018/2/2.
 *
 * @author virgil
 */

public class CashierActiveProcessor {

    /**
     * 整理门店数据
     *
     * @param posResponse
     */
    public static SocketResponse manageShopData(CashierLoginPosResponse posResponse) {
        SocketResponse socketResponse = new SocketResponse();
        String shopGuid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGuid from tbShop ");
        if (!TextUtils.equals(posResponse.data.msyShopInfoId, shopGuid)) {
            final CountDownLatch latch = new CountDownLatch(1);
            boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.SUCCESS;
                    latch.countDown();
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    latch.countDown();
                    return false;
                }
            },null);
            while (latch.getCount() > 0) {
                try {
                    latch.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (!doAsyn || !socketResponse.success()) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "正在同步数据,请稍后重试";
                return socketResponse;
            }
            cleanAllData();
            bindHost();
            HostUtil.updateHostPullAll();
        }
        ActiveUtil.updateTokenSeed(posResponse.data.msyShopInfoId, posResponse.data.msyToken, posResponse.data.seed);
        CashierActiveProcessor.updateIP();
        DBMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, posResponse.data.controlToken);
        ClientMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, posResponse.data.controlToken);
        CashierActiveProcessor.registerCheckToken();
        return socketResponse;
    }

    /**
     * 整理门店数据
     *
     * @param shopId
     * @param controlToken
     */
    public static SocketResponse manageShopData(String shopId, String controlToken) {
        SocketResponse socketResponse = new SocketResponse();
        String shopGuid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGuid from tbShop ");
        if (shopGuid != null && !TextUtils.equals(shopId, shopGuid)) {
            final CountDownLatch latch = new CountDownLatch(1);
            boolean doAsyn = UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.SUCCESS;
                    latch.countDown();
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    latch.countDown();
                    return false;
                }
            }, null);
            while (latch.getCount() > 0) {
                try {
                    latch.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (!doAsyn || !socketResponse.success()) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "正在同步数据,请稍后重试";
                return socketResponse;
            }
            cleanAllData();
            bindHost();
            HostUtil.updateHostPullAll();
        }
        updateIP();
        DBMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, controlToken);
        ClientMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, controlToken);
        CashierActiveProcessor.registerCheckToken();
        return socketResponse;
    }


    /**
     * 清除门店数据
     */
    public static void cleanAllData() {
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "清除所有历史数据");
        List<String> dbName = new ArrayList<>();
        dbName.add(APPConfig.DB_CLIENT);
        dbName.add(APPConfig.DB_MAIN);
        dbName.add(APPConfig.DB_PRINT);
        dbName.add(APPConfig.DB_NET_ORDER);
        for (String tempDB : dbName) {
            List<String> tableList = DBSimpleUtil.queryStringList(tempDB, "select name from sqlite_master where type='table' and name not in('meta','sqlite_master','android_metadata','unfinish_task');");
            DBManager.getInstance(tempDB).executeInTransactionWithOutThread((db) -> {
                for (String temp : tableList) {
                    db.delete(temp, null, null);
                }
                return null;
            });
            DBSimpleUtil.excuteSql(tempDB, "delete from meta where key not in ('1','204')");
        }
    }

    public static void bind() {
        updateIP();
        bindHost();
    }

    public static void updateIP() {
        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);
        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");

        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);

    }

    /**
     * 绑定站点
     */
    public static void bindHost() {
        HostStatusModel host = DBSimpleUtil.query(APPConfig.DB_MAIN, "where hostid='" + HostBiz.CASHIER + "'", HostStatusModel.class);
        if (host == null) {
            host = new HostStatusModel();
        }
        host.device = ServerHardwareUtil.getHardWareSymbol();
        host.hostid = HostBiz.CASHIER;
        host.bind_time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        host.bind_count++;
        host.bind_status = 1;
        host.biz_status = HostStatus.FINISH;
        host.current_user_id = "";
        host.replaceNoTrans();
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "绑定站点: device=" + host.device + " hostid=" + host.hostid
                + " bind_time=" + host.bind_time + " bind_count=" + host.bind_count + " biz_status=" + host.biz_status);
        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, HostBiz.CASHIER);
        if (BindProcessor.isCurrentHostMain()) {
            DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, HostBiz.CASHIER);
        }

    }

    public static String doLogin(String userID, String sectionID) {
        return HostUtil.hostLogin(userID, HostBiz.CASHIER, sectionID);
    }


    /**
     * 注册Token验证
     */
    public static void registerCheckToken() {
        String taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.CASH_LOGINPD + "' limit 1");
        if (TextUtils.isEmpty(taskid)) {
            JobScheudler.newJob(JobType.CASH_LOGINPD, taskid, 3);
        }
    }


    /**
     * 更新下载数据
     *
     * @return
     */
    public static SocketResponse download() {
        SocketResponse<CashierLoginResponse> socketResponse = new SocketResponse();
        MSYDownload(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, "下载数据成功！");
                socketResponse.code = SocketResultCode.SUCCESS;
                CashierActiveProcessor.bind();
                ServerCache.getInstance().refresh();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.DOWNLOAD_EXCEPTION, "下载数据接口异常 msg = " + responseData.resultMessage);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        });

        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "美收银登陆成功后下载数据：" + socketResponse.message);
        return socketResponse;
    }

    /**
     * 美易点数据下载，美收银统一设置参数
     *
     * @param callback
     */
    public static void MSYDownload(IExecutorCallback callback) {
        DownLoadDataProcessor.LIMIT = 100;
        DownLoadDataProcessor.PAGE_SIZE = 300;
        HostUtil.updateBusinessDate(DBMetaUtil.getSettingsValueByKey(META.SHOPID));
        DownLoadDataProcessor.downloadData(callback, null, null);
        //代码冲突
//        DownLoadDataProcessor.downloadData(callback);
    }

}
