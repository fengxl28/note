package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.dbutil.PermissionBizUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.CheckMoLingPermisionResultResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.permission.CheckPermissionResponse;
import com.mwee.android.pos.component.permission.MenuSimpleInfo;
import com.mwee.android.pos.connect.business.permission.PermissionAuthorityCheckingResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 * 业务中心权限相关操作
 * 1、校验用户是否具有某项权限{}
 */
@SuppressWarnings("unused")
public class PermissionDriver implements IDriver {

    private static final String TAG = "permission";

    /**
     * 授权验证
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/authorityChecking")
    public SocketResponse authorityChecking(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PermissionAuthorityCheckingResponse responseData = new PermissionAuthorityCheckingResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String waiterId = request.getString("waiterId");
            String hostId = head.hd;
            String pwd = request.getString("pwd");
            String fsiccardcode = request.getString("fsiccardcode");  //IC卡号
            String checkResult = PermissionBizUtil.checkPermissionAuthor(waiterId, pwd, hostId, fsiccardcode);
            if (!TextUtils.isEmpty(checkResult)) {
                response.message = checkResult;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            response.code = SocketResultCode.SUCCESS;
            response.message = "授权成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 校验权限
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/checkPermission")
    public SocketResponse checkPermission(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }

        SocketResponse response = new SocketResponse();
        CheckPermissionResponse responseData = new CheckPermissionResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String waiterId = request.getString("waiterId");
            String fsProgDtlId = request.getString("fsProgDtlId");
            String permissionType = request.getString("permissionType");
            String fsDiscountId = request.getString("fsDiscountId");
            List<MenuSimpleInfo> menuInfoLists = JSON.parseArray(request.getString("menuInfoLists"), MenuSimpleInfo.class);
            int discountRate = StringUtil.toInt(request.getString("discountRate"), -1);
            LogUtil.log("自定义折扣: " + discountRate);
            String errMsg = PermissionBizUtil.checkPermission(responseData, waiterId, fsProgDtlId, permissionType, fsDiscountId, menuInfoLists, discountRate);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (responseData.hasPermission) {
                response.code = SocketResultCode.SUCCESS;
            } else {
                response.code = SocketResultCode.BUSINESS_FAILED;
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常，请重试";
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 校验抹零权限
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/checkMoLingPermision")
    public static SocketResponse checkMoLingPermision(SocketHeader head, String param) {
        SocketResponse<CheckPermissionResponse> socketResponse = new SocketResponse<>();
        CheckPermissionResponse responseData = new CheckPermissionResponse();
        socketResponse.data = responseData;
        try {

            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            PayOriginModel selectPay = request.getObject("seletpay", PayOriginModel.class);
            BigDecimal inputAmt = request.getBigDecimal("inputAmt");

            if (inputAmt.compareTo(BigDecimal.ZERO) <= 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请输入支付金额";
                return socketResponse;
            }
            if (selectPay == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "支付方式不正确";
                return socketResponse;
            }

            String fsmtableId = OrderSaveDBUtil.getTableIDByOrderID(orderID);

            if (user.fiIsMaxReduce == 0) {
                responseData.hasPermission = true;
            } else {
                //计算出已使用额度
                BigDecimal usedAmt = BigDecimal.ZERO;
                PaySession session = OrderSession.getInstance().getPay(orderID);
                if (session != null && !ListUtil.isEmpty(session.selectPayListFull)) {
                    for (PayModel payModel : session.selectPayListFull) {
                        if (payModel == null || !payModel.checkEnable() || payModel.seq_M != -1 || !TextUtils.equals(payModel.waiterID, user.fsUserId)) {
                            continue;
                        }
                        //仅统计抹零相关支付方式
                        if (TextUtils.equals(PayType.NO_CHANGE,payModel.data.payTypeID)) {
                            usedAmt = usedAmt.add(payModel.payAmount.subtract(payModel.changeAmount));
                        }
                    }
                }
                //计算此次支付是否会超过限额：已用额度+本次支付金额
                usedAmt = usedAmt.add(inputAmt);
                if (usedAmt.compareTo(user.fdMaxReducePrice) <= 0) {
                    responseData.hasPermission = true;
                    //未超出限制 --- 可直接支付
                } else {
                    responseData.hasPermission = false;
                    //查出所有有权限的用户
                    responseData.permissionUserList = PermissionBizUtil.getAllUserMoLing(usedAmt);
                }
            }

            if (responseData.hasPermission) {
                socketResponse.code = SocketResultCode.SUCCESS;
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}
