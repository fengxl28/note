package com.mwee.android.pos.businesscenter.business.unfinish_task;

import android.support.annotation.IntDef;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Job的执行状态
 * Created by virgil on 2017/11/10.
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Target({METHOD, PARAMETER, FIELD, LOCAL_VARIABLE})
@IntDef({JobStatus.PREPAREED, JobStatus.FINISHED, JobStatus.CANCELED,JobStatus.WORKING,JobStatus.STOPED})
public @interface JobStatus {
    /**
     * 准备执行
     */
    int PREPAREED = 0;
    /**
     * 已完成
     */
    int FINISHED = 1;
    /**
     * 已取消,技术上的
     */
    int CANCELED = 2;
    /**
     * 执行中
     */
    int WORKING = 3;
    /**
     * 已终止,业务上的
     */
    int STOPED = 4;
}
