package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.List;
import java.util.Locale;

/**
 * Created by qinwei on 2018/7/17.
 */

public class ShiftDBUtils {
    public static List<DataModel> getShiftList() {
        String sql = "select fsShiftId as id,fsShiftName as name,datacache.value as status from tbshift left join (select * from datacache where type='%d') as datacache  on tbshift.fsShiftId=datacache.key where tbshift.fiStatus='1'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sql, IOCache.TYPE_SHIFT_CLOSE), DataModel.class);
    }

    public static String getShiftNameById(String shiftId) {
        String sql = "select fsShiftName from tbShift where fsShiftId = '%s'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, shiftId));
    }
}
