package com.mwee.android.pos.businesscenter.business.pay;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.netpay.model.NetPayModel;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.AccountBookUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.fastfood.FastFoodBizStatus;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 支付的业务处理类
 * Created by virgil on 2017/2/16.
 */

public class PayProcessor {

    private static final String TAG = "PayProcessor";

    /**
     * 美收银支付成功
     *
     * @param orderID String
     * @return boolean
     */
    public static void payCashierSuccess(String orderID) {
//        UploadDataProcessor.doUploadSingleOrderWithBaseData(orderID);
        UploadDataHelper.uploadOrderData(orderID, true);
    }

    /**
     * 支付成功的订单和支付的处理
     * 1，处理订单状态、支付状态、报表状态
     * 2，记入消息中心
     *
     * @param paySession PaySession | 支付Session
     * @param tableID    String | 桌台ID
     */
    public static boolean paySuccess(PaySession paySession, String tableID) {
        boolean result = false;

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableID, paySession.orderID, "支付成功的订单和支付的处理");
        try {

            RunTimeLog.addLog(RunTimeLog.PAY_FINISH_START, "start pay result", paySession.orderID, tableID, null);

            try {
                updateOrder(paySession, tableID, 0);
            } catch (Exception e) {
                LogUtil.logError(e);
                return false;
            }
            if (checkOrderValid(paySession.orderID)) {
                // 分配账套
                AccountBookUtil.processAccountBookAuto(paySession.orderID);

//                UploadDataProcessor.doUploadSingleOrderWithBaseData(paySession.orderID);
                UploadDataHelper.uploadOrderData(paySession.orderID, true);
                LogUtil.logBusiness(TAG, "paySuccess doUploadSingleOrderWithBaseData 1 orderId:" + paySession.orderID);
                //支付成功后要更新消息列表中结账状态
                MessageDBUtil.updatePayConfirmMessageStatus(paySession.orderID);
                MessageDBUtil.updatePayMessageStatus(paySession.billNO);

                NotifyToClient.refrehMessageData(); //刷新---消息提醒小红点及消息中心页面

                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                        }
//                        UploadDataProcessor.doUploadSingleOrderWithBaseData(paySession.orderID);
                        UploadDataHelper.uploadOrderData(paySession.orderID, false);
                        LogUtil.logBusiness(TAG, "paySuccess doUploadSingleOrderWithBaseData 2 orderId:" + paySession.orderID);
                    }
                });
                thread.setPriority(1);
                thread.start();
                result = true;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableID, paySession.orderID, "支付成功的订单和支付的处理");
        }

        ServerCache.getInstance().releaseToken(paySession.orderID);
        return result;
    }

    public static boolean checkOrderValid(String orderID) {
        String fdExpAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fdExpAmt from tbSell where fsSellno='" + orderID + "'");
        String fdPayAmt = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fdPayAmt from tbSell where fsSellno='" + orderID + "'");
        BigDecimal orderAmt = new BigDecimal(fdExpAmt);
        BigDecimal payAmt = new BigDecimal(fdPayAmt);
        if (orderAmt.compareTo(payAmt) != 0) {
            RunTimeLog.addLog(RunTimeLog.ORDER_CONFLICT_PAY, orderID + "订单checkOrderValid失败，【payAmt = '" + payAmt + "', orderAmt = '" + orderAmt + "'】将要重置订单状态 时间：" + DateUtil.getCurrentTimeInMills(), orderID, "", "", "");
            OrderSession.setPayed(orderID, 0);
            OrderSession.updateOrderStatus(orderID, OrderStatus.NORMAL);
            FastFoodBusinessUtil.updateOrderBizStatus(orderID, 1); //--快餐单业务表置为未结账
            return false;
        }
        return true;
    }

    /**
     * 支付成功的订单和支付的处理,处理订单状态、支付状态、报表状态
     *
     * @param paySession PaySession | 支付Session
     * @param tableID    String | 桌台ID
     * @param retryTime  int | 第几次保存
     */
    private static void updateOrder(PaySession paySession, String tableID, int retryTime) {
        //如果重试超过一次，则弹出异常
        if (retryTime > 1) {
            throw new RuntimeException("出现异常，请稍后重试");
        }
        if (TextUtils.isEmpty(paySession.currentHostID)) {
            throw new RuntimeException("hostid is null");
        }
        if (TextUtils.isEmpty(paySession.currentShiftID)) {
            throw new RuntimeException("shiftid is null");
        }
        if (TextUtils.isEmpty(paySession.waiterID)) {
            throw new RuntimeException("waiterID is null");
        }
        if (TextUtils.isEmpty(paySession.waiterName)) {
            throw new RuntimeException("waiterName is null");
        }

        // 参照快餐，需要保证内存中订单状态与数据库中一致 PayProcessor#paySuccessForFast
        OrderCache orderCache = OrderSession.getInstance().getOrder(paySession.orderID);
        orderCache.orderStatus = OrderStatus.PAIED;
        OrderSaveDBUtil.saveOnly(orderCache.orderID, orderCache, false);

        paySession.payed = 1;
        paySession.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);

        //存储支付信息
        PaySaveDBUtil.save(paySession.orderID, paySession, false);
        //存储支付信息到报表
        OrderProcessor.savePayOnly(paySession);
        //更新订单相关的信息，包括ordercache和tbsell表
        OrderSaveDBUtil.orderPaySuccess(paySession.orderID, tableID);

        //校验订单保存后的结果，如果订单状态、支付状态保存失败，则重新保存一遍
        String sql = "select tbsell.fiBillStatus,order_cache.order_status,order_pay_cache.payed from tbsell left join order_cache on tbsell.fsSellno = order_cache.order_id left join order_pay_cache on order_pay_cache.order_id=tbsell.fsSellno where fsSellno='" + paySession.orderID + "'";
        JSONObject orderResult = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
        if (!TextUtils.equals(orderResult.getString("fiBillStatus"), "3")) {
            RunTimeLog.addLog(RunTimeLog.PAY_FINISH_ERROR, "start pay result fiBillStatus err", paySession.orderID, tableID, null);
            updateOrder(paySession, tableID, retryTime + 1);
            return;
        }
        if (!TextUtils.equals(orderResult.getString("order_status"), "3")) {
            RunTimeLog.addLog(RunTimeLog.PAY_FINISH_ERROR, "start pay result order_status err", paySession.orderID, tableID, null);
            updateOrder(paySession, tableID, retryTime + 1);
            return;
        }
        if (!TextUtils.equals(orderResult.getString("payed"), "1")) {
            RunTimeLog.addLog(RunTimeLog.PAY_FINISH_ERROR, "start pay result payed err", paySession.orderID, tableID, null);
            updateOrder(paySession, tableID, retryTime + 1);
            return;
        }
        RunTimeLog.addLog(RunTimeLog.PAY_FINISH_START, "PayProcessor paySuccess 校验通过 tableID=" + tableID + ",orderID=" + paySession.orderID);

    }

    /**
     * 快餐完成结账
     *
     * @param paySession
     */
    public static String paySuccessForFast(UserDBModel user, String hostID, PaySession paySession, OrderCache orderCache) {
        if (TextUtils.isEmpty(paySession.currentHostID)) {
            throw new RuntimeException("hostid is null");
        }
        if (TextUtils.isEmpty(paySession.currentShiftID)) {
            throw new RuntimeException("shiftid is null");
        }
        if (TextUtils.isEmpty(paySession.waiterID)) {
            throw new RuntimeException("waiterID is null");
        }
        if (TextUtils.isEmpty(paySession.waiterName)) {
            throw new RuntimeException("waiterName is null");
        }

        List<MenuItem> unOrderItems = new ArrayList<>();     //所有未下单的菜
        for (MenuItem menuItem : orderCache.originMenuList) {
            OrderSeqModel orderSeqModel = orderCache.optSeqModel(menuItem.menuBiz.orderSeqID);
            if (orderSeqModel == null || orderSeqModel.seqStatus == OrderSeqStatus.NORMAL) {
                unOrderItems.add(menuItem);
            }
        }

        SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(unOrderItems);
        if (!result.success) {
            throw new RuntimeException(result.errorMsg);
        }

        /**
         * 筛出未下单的单序，全部置为已下单
         * int[]
         */

        StringBuilder seqsSB = new StringBuilder();
        for (OrderSeqModel orderSeqModel : orderCache.seqList) {
            LogUtil.log("快餐结账完成：", "订单单序：" + JSON.toJSONString(orderSeqModel));
            if (orderSeqModel.seqStatus == OrderSeqStatus.NORMAL) {
                seqsSB.append(orderSeqModel.seqNo).append(",");
                orderCache.updateSeqStatus(orderSeqModel.seqNo, OrderSeqStatus.ORDERED, user, hostID);
            }
        }
        if (!TextUtils.isEmpty(seqsSB.toString())) {
            orderCache.currentSeq++;
            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, null, "");
        }
        orderCache.orderStatus = OrderStatus.PAIED;
        //存储OrderCache
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache,false, "paySuccessForFast");

        paySession.payed = 1;
        paySession.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        //存储支付信息
        PaySaveDBUtil.save(paySession.orderID, paySession, false);
        //存储支付信息到报表
//        OrderProcessor.submit(orderCache, paySession);

        //快餐业务状态置为已完成
        FastFoodDBUtil.updateOrderBizStatus(paySession.orderID, FastFoodBizStatus.OVER);
        //存储支付信息到报表
        long time = System.currentTimeMillis();
        OrderProcessor.submit(orderCache, paySession);
        //将支付明细拆分到每个菜品上
        OrderProcessor.createSellCoupon(orderCache.orderID,true);
        time = System.currentTimeMillis() - time;
        LogUtil.logBusiness("===SCAN=PAY===",
                "PayProcessor#paySuccessForFast----" + paySession.orderID + "----processor.call---OrderProcessor.submit--- 耗时------:" + time);
        UploadDataHelper.uploadOrderData(paySession.orderID, true);

        //支付成功后要更新消息列表中结账状态
        MessageDBUtil.updatePayConfirmMessageStatus(paySession.billNO);
        MessageDBUtil.updatePayMessageStatus(paySession.billNO);

        NotifyToClient.refrehMessageData(); //刷新---消息提醒小红点及消息中心页面
        String seqs = seqsSB.toString();
        if (!TextUtils.isEmpty(seqs)) {
            seqs = seqs.substring(0, seqs.length() - 1);
        }
        //订单状态日志
        String sql = "select tbsell.fiBillStatus,order_cache.order_status,order_pay_cache.payed from tbsell left join order_cache on tbsell.fsSellno = order_cache.order_id left join order_pay_cache on order_pay_cache.order_id=tbsell.fsSellno where fsSellno='" + paySession.orderID + "'";
        JSONObject orderResult = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
        if (!TextUtils.equals(orderResult.getString("fiBillStatus"), "3")) {
            LogUtil.logBusiness("快餐结账后-paySuccessForFast:tbSell状态异常："+orderResult.getString("fiBillStatus"));
        }
        if (!TextUtils.equals(orderResult.getString("order_status"), "3")) {
            LogUtil.logBusiness("快餐结账后-paySuccessForFast:order_cache状态异常："+orderResult.getString("order_status"));
        }
        if (!TextUtils.equals(orderResult.getString("payed"), "1")) {
            LogUtil.logBusiness("快餐结账后-paySuccessForFast:order_pay_cache状态异常："+orderResult.getString("payed"));
        }

        return seqs;
    }

    /**
     * 手动设置已结账，处理订单状态、支付状态、报表状态
     *
     * @param orderId String | 订单号
     * @param tableID String | 桌台ID
     */
    public static void manualSetPaySuccess(OrderCache originOrderCache, String orderId, String tableID, UserDBModel userDBModel, String hostID) {
        manualSetPaySuccess(originOrderCache, orderId, tableID, userDBModel, hostID, 0);
    }

    /**
     * @param originOrderCache
     * @param orderId
     * @param tableID
     * @param userDBModel
     * @param hostID
     * @param autoShift        1:自动交班
     */
    public static void manualSetPaySuccess(OrderCache originOrderCache, String orderId, String tableID, UserDBModel userDBModel, String hostID, int autoShift) {
        PaySession session = OrderSession.getInstance().getPay(originOrderCache.orderID);
        if (session != null) {
            OrderUtil.recalcPaySessionLeftToPay(session, originOrderCache);
            if (TextUtils.isEmpty(session.currentShiftID)) {
                session.currentShiftID = HostUtil.getShiftIDOfCurrentHost();
            }
        } else {
            session = OrderSession.getInstance().generatePaySession(originOrderCache, userDBModel, hostID);
            OrderSession.getInstance().writePay(originOrderCache.orderID, session);
        }

        session.waiterID = userDBModel.fsUserId;
        session.waiterName = userDBModel.fsUserName;
        session.currentShiftID = HostUtil.getShiftIDByHost(hostID, userDBModel.fsUserId);
        session.payed = 1;
        session.locked = autoShift;
        session.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        originOrderCache.orderStatus = OrderStatus.PAIED;

//        OrderSaveDBUtil.save(originOrderCache.orderID, originOrderCache);
        OrderSession.getInstance().writeOrder(originOrderCache.orderID, originOrderCache, false, "manualSetPaySuccess");
        OrderProcessor.submit(originOrderCache, session); //写报表入库
        PayProcessor.paySuccess(session, tableID);
//        if (session != null) {
//            PayProcessor.paySuccess(session, orderId);
//        } else {
//            OrderSaveDBUtil.orderPaySuccess(orderId, tableID);
//        }
    }

    /**
     * 保存订单信息，并修改订单的为未完成支付的状态
     *
     * @param orderCache OrderCache
     */
    public static void saveOrderChangeNeedPay(OrderCache orderCache, UserDBModel user) {
        if (orderCache.orderStatus == OrderStatus.PAIED) {
            RunTimeLog.addLog(RunTimeLog.PAY_RESET, "修改为未支付", orderCache.orderID, user);
            orderCache.orderStatus = OrderStatus.NORMAL;
        }
        OrderSession.getInstance().writeOrder(orderCache.orderID, false, "saveOrderChangeNeedPay");
        OrderProcessor.saveOrder(orderCache, null);
        OrderSession.setPayed(orderCache.orderID, 0);
        //如果桌台不是开台状态，则手动打开桌台
        if (TableBusinessUtil.checkTableFree(orderCache.fsmtableid)) {
            TableBusinessUtil.doOpenTable(new SocketResponse(), HostUtil.getCurrentHost(), orderCache.fsmtableid, orderCache.orderID, user);
        }
    }


    /**
     * 构建支付明细
     *
     * @param payModel    支付方式
     * @param netPayModel 网络支付返回信息（平台优惠，商家优惠等优惠支付信息）
     */
    public static void buildNetPayExtra(PayModel payModel, NetPayModel netPayModel) {

        if (netPayModel == null) {
            return;
        }
        if (payModel.secondPayList == null) {
            payModel.secondPayList = new ArrayList<>();
        }
        //平台优惠
        PayModel platformDiscount = new PayModel(payModel.waiterID, payModel.waiterName);
        //商家优惠
        PayModel platformMerchantDiscount = new PayModel(payModel.waiterID, payModel.waiterName);
        platformDiscount.businessInfo = payModel.businessInfo;
        platformMerchantDiscount.businessInfo = payModel.businessInfo;

        platformDiscount.payAmount = new BigDecimal(netPayModel.platform_discount);
        platformMerchantDiscount.payAmount = new BigDecimal(netPayModel.platform_merchant_discount);

        // 如果主支付方式是预付金，从属支付方式也需要写为预付金
        if (payModel.isPayPre()) {
            platformDiscount.writePrePay();
            platformMerchantDiscount.writePrePay();
        }

        payModel.payAmount = payModel.payAmount.subtract(platformDiscount.payAmount).subtract(platformMerchantDiscount.payAmount);//在线实际支付金额 支付总金额-优惠金额（平台优惠+商家优惠）
        if (payModel.data.payTypeID.equals(PayType.ALI)) {//支付宝
            if (platformDiscount.payAmount.compareTo(BigDecimal.ZERO) > 0) {
                platformDiscount.data = OrderUtil.buildPayModelByPaymentID(PayType.ALI_DISCOUNT);
                payModel.secondPayList.add(platformDiscount);
            }
            if (platformMerchantDiscount.payAmount.compareTo(BigDecimal.ZERO) > 0) {
                platformMerchantDiscount.data = OrderUtil.buildPayModelByPaymentID(PayType.ALI_PLATFORM_MERCHANT_DISCOUNT);
                payModel.secondPayList.add(platformMerchantDiscount);
            }
        } else if (payModel.data.payTypeID.equals(PayType.WEIXIN)) {//微信
            if (platformDiscount.payAmount.compareTo(BigDecimal.ZERO) > 0) {
                platformDiscount.data = OrderUtil.buildPayModelByPaymentID(PayType.WINXIN_DISCOUNT);
                payModel.secondPayList.add(platformDiscount);
            }
            if (platformMerchantDiscount.payAmount.compareTo(BigDecimal.ZERO) > 0) {
                platformMerchantDiscount.data = OrderUtil.buildPayModelByPaymentID(PayType.WINXIN_PLATFORM_MERCHANT_DISCOUNT);
                payModel.secondPayList.add(platformMerchantDiscount);
            }
        }

    }

}
