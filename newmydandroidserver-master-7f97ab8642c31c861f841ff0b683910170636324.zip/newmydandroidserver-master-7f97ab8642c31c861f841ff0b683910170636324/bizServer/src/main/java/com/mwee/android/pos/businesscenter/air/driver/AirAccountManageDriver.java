package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.account.GetAccountDetailResponse;
import com.mwee.android.air.connect.business.account.GetAllAccountResponse;
import com.mwee.android.air.db.business.account.AccountManageInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AccountManageDBUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.tools.LogUtil;

/**
 * @ClassName: AirAccountManageDriver
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午9:10
 */
public class AirAccountManageDriver implements IDriver {

    public static final String DRIVER_TAG = "airAccountManager";

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/getAllAccount")
    public SocketResponse getAllAccount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAccountResponse responseData = new GetAllAccountResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            responseData.accountList = AccountManageDBUtils.queryAllAccount();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/getAccountDetail")
    public SocketResponse getAccountDetail(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAccountDetailResponse responseData = new GetAccountDetailResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsUserId = request.getString("fsUserId");
            if (TextUtils.isEmpty(fsUserId)) {
                response.message = "内部异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.account = AccountManageDBUtils.queryAccountDetailByID(fsUserId);
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/addAccount")
    public SocketResponse addAccount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAccountResponse responseData = new GetAllAccountResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            AccountManageInfo obj = request.getObject("account", AccountManageInfo.class);

            if (obj == null) {
                response.message = "内部错误";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            UserDBModel userDBModels = AccountManageDBUtils.queryUserDBModelByPhone(obj.fsCellphone);
            if (userDBModels != null) {
                response.message = "该手机号已被使用，请更换手机号";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AccountManageDBUtils.add(obj, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.accountList = AccountManageDBUtils.queryAllAccount();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增员工成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/updateAccount")
    public SocketResponse updateAccount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAccountResponse responseData = new GetAllAccountResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            AccountManageInfo obj = request.getObject("account", AccountManageInfo.class);

            if (obj == null) {
                response.message = "内部异常";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            UserDBModel userDBModels = AccountManageDBUtils.queryUserDBModelByPhoneAndUid(obj.fsCellphone, obj.fsUserId);
            if (userDBModels != null) {
                response.message = "该手机号已被使用，请更换手机号";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AccountManageDBUtils.update(obj, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.accountList = AccountManageDBUtils.queryAllAccount();
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改员工成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/deleteAccount")
    public SocketResponse deleteAccount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAccountResponse responseData = new GetAllAccountResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsUserId = request.getString("fsUserId");
            if (TextUtils.isEmpty(fsUserId)) {
                response.message = "内部异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AccountManageDBUtils.delete(fsUserId, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.accountList = AccountManageDBUtils.queryAllAccount();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除员工成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }
}
