package com.mwee.android.pos.businesscenter.business.kds.algorithm.bean;

import com.mwee.android.kds.entry.MenusItem;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;

/**
 * @ClassName: AMenuDataBean
 * @Description: Kds 算法模型初始化菜品数据
 * @author: Cannan
 * @date: 2018/11/12 下午4:49
 */
public class AMenuDataBean extends DBModel {

    /**
     * 菜的编号
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiItemCd}
     */
    @ColumnInf(name = "foodId")
    public String foodId = "";

    /**
     * 菜名
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fsItemName}
     */
    @ColumnInf(name = "foodName")
    public String foodName = "";

    /**
     * 同一锅最多并菜数量
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiMaxTogetherMenu}
     */
    @ColumnInf(name = "mergeNum")
    public int mergeNum = 0;

    /**
     * 一道菜在做好后被退菜，多少时间范围内，还可以再上给后面点的客户，因为太久了这道菜就不能再上了
     * {@link com.mwee.android.pos.db.business.MenuitemDBModel#fiRetireMenuTime}
     */
    @ColumnInf(name = "lifeTime")
    public int lifeTime = 0;

    public AMenuDataBean() {
    }

    public MenusItem.MenuItemInner convert() {
        MenusItem.MenuItemInner item = new MenusItem.MenuItemInner();
        item.setFoodId(this.foodId);
        item.setFoodName(this.foodName);
        item.setMergeNum(this.mergeNum);
//        item.setFoodTime(this.lifeTime);
        item.setLifeTime(this.lifeTime);
        return item;
    }
}
