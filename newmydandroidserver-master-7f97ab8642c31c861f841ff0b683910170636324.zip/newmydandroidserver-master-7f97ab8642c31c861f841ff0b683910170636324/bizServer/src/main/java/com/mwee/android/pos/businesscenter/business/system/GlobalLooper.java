package com.mwee.android.pos.businesscenter.business.system;

import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.SimpleArrayMap;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;

import java.util.Map;

/**
 * 全局的handler，避免每个业务都写一个HandlerThread
 * Created by virgil on 2017/9/12.
 *
 * @author virgil
 */

public class GlobalLooper {
    private final int KEY_LOOP = 0X98123;
    private final int KEY_STOP = 0X98124;
    private final int KEY_DESTROY = 0X98125;

    private Handler handler = null;
    private int count = 0;
    private ArrayMap<ILoopCall, Integer> task = new ArrayMap<>();
    /**
     * 轮询周期，默认30秒
     */
    private int INTERVAL_CYCLE = 30 * 1000;

    public GlobalLooper() {

    }

    /**
     * @param call  ILoopCall
     * @param cycle int | 轮询周期，2分钟*n
     */
    public static void registBasedOn2Minutes(ILoopCall call, int cycle) {
        if (ServerCache.getInstance().looper != null) {
            ServerCache.getInstance().looper.registListener(call, cycle * 4);
        }
    }

    /**
     * @param call  ILoopCall
     * @param cycle int | 轮询周期，30秒*n
     */
    public static void registBasedOn30Seconds(ILoopCall call, int cycle) {
        if (ServerCache.getInstance().looper != null) {
            ServerCache.getInstance().looper.registListener(call, cycle);
        }
    }

    public static void unRegist(ILoopCall call) {
        if (ServerCache.getInstance().looper != null) {
            ServerCache.getInstance().looper.unRegistListener(call);
        }
    }

    /**
     * 延迟执行一个任务
     *
     * @param runnable
     * @param delay
     */
    public static void postDelayed(Runnable runnable, long delay) {
        if (ServerCache.getInstance().looper != null) {
            ServerCache.getInstance().looper.postDelayWorker(runnable, delay);
        }
    }

    public static void destroy() {
        if (ServerCache.getInstance().looper != null) {
            ServerCache.getInstance().looper.destroyInstance();
        }
    }

    public synchronized void init() {
        if (handler == null) {
            HandlerThread handlerThread = new HandlerThread("MYD_SLooper_" + SystemClock.elapsedRealtime()) {
                @Override
                protected void onLooperPrepared() {
                    super.onLooperPrepared();
                    if (handler != null) {
                        handler.sendEmptyMessage(KEY_STOP);
                    }
                    handler = new Handler(Looper.myLooper()) {
                        @Override
                        public void handleMessage(Message msg) {
                            super.handleMessage(msg);
                            switch (msg.what) {
                                case KEY_LOOP:
                                    try {
                                        if (!task.isEmpty()) {
                                            ArrayMap<ILoopCall, Integer> tempMap = new ArrayMap<>();
                                            tempMap.putAll((SimpleArrayMap<? extends ILoopCall, ? extends Integer>) task);
                                            for (Map.Entry<ILoopCall, Integer> temp : tempMap.entrySet()) {
                                                if ((count % temp.getValue()) == 0) {
                                                    try {
                                                        temp.getKey().call();
                                                    }catch (Exception e){
                                                        e.printStackTrace();
                                                        RunTimeLog.addLog(RunTimeLog.GLOBAL_LOOPER_ERROR, "GlobalLooper 执行异常", JSON.toJSONString(e), temp.getKey());
                                                    }
                                                }
                                            }
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        RunTimeLog.addLog(RunTimeLog.GLOBAL_LOOPER_ERROR, "GlobalLooper 执行异常 KEY_LOOP", "", e);
                                    }
                                    // 2017/12/13 后置count++, 在首次循环执行的时候, 可以执行所有的task
                                    count++;
                                    handler.sendEmptyMessageDelayed(KEY_LOOP, INTERVAL_CYCLE);
                                    break;
                                case KEY_STOP:
                                    try {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                                            getLooper().quitSafely();
                                        } else {
                                            getLooper().quit();
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        RunTimeLog.addLog(RunTimeLog.GLOBAL_LOOPER_ERROR, "GlobalLooper 执行异常  KEY_STOP" , "", e);
                                    }
                                    break;
                                case KEY_DESTROY:
                                    try {
                                        task.clear();
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                                            getLooper().quitSafely();
                                        } else {
                                            getLooper().quit();
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        RunTimeLog.addLog(RunTimeLog.GLOBAL_LOOPER_ERROR, "GlobalLooper 执行异常  KEY_DESTROY" , "", e);
                                    }
                                    break;
                                default:
                                    break;
                            }

                        }
                    };
                    handler.sendEmptyMessageDelayed(KEY_LOOP, INTERVAL_CYCLE);
                }
            };
            handlerThread.start();
        }
    }

    private synchronized void registListener(ILoopCall call, int cycle) {
        if (task == null) {
            task = new ArrayMap<>();
        }
        task.put(call, cycle);
    }

    private synchronized void unRegistListener(ILoopCall call) {
        if (task == null) {
            task = new ArrayMap<>();
        }
        task.remove(call);
    }

    private void postDelayWorker(Runnable runnable, long delay) {
        if (handler != null) {
            handler.postDelayed(runnable, delay);
        }
    }

    public void destroyInstance() {
        if (handler != null) {
            handler.sendEmptyMessage(KEY_DESTROY);
            handler = null;
        }
    }
}
