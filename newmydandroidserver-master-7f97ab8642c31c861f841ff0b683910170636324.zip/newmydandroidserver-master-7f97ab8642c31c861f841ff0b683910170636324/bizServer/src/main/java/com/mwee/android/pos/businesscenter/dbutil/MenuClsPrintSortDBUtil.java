package com.mwee.android.pos.businesscenter.dbutil;

import android.content.ContentValues;
import android.text.TextUtils;

import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuClsPrintSortDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;


public class MenuClsPrintSortDBUtil {

    public static void forceUpdate() {
        updateMenuClsSort(getAllMenuCls(HostUtil.getShopID()));
    }

    /**
     * 当menuClsPrintSort表无数据时填充数据
     */
    public static void fillMenuCls() {
        if (!checkData()) {
            updateMenuClsSort(getAllMenuCls(HostUtil.getShopID()));
        }
    }

    /**
     * menuClsPrintSort表是否有数据
     *
     * @return true则有
     */
    private static boolean checkData() {
        String sqlMenuClsCount = "select count(*) from tbmenucls where fsShopGUID='" + HostUtil.getShopID() + "' " +
                " and fiStatus<>'13' and fiDataKind<>'1' and fsMenuClsId_P=0 ";
        String sql = "select count(*) from " + DBModel.getTableName(MenuClsPrintSortDBModel.class);
        String countOrg = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMenuClsCount);
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.equals(countOrg, count)) {
            return true;
        }
//        if (!TextUtils.equals("0", count)) {
//            return true;
//        }
        return false;
    }

    /**
     * 获取所有菜品分类打印排序
     */
    public static List<MenuClsPrintSortDBModel> getAllMenuCls(String shopGUID) {
        String sqlQueryMenuCls = "SELECT fsShopGUID,fsMenuClsId,fsMenuClsName,fiStatus,fiLevel,\n" +
                "(select count(*) FROM tbmenuitem WHERE fsMenuClsId=tbmenucls.fsMenuClsId and fistatus='1') 'count' \n" +
                "from " + DBModel.getTableName(MenuclsDBModel.class) +
                " where fsShopGUID='" + shopGUID + "'" +
                " and fiStatus<>'13' and fiDataKind<>'1' and fsMenuClsId_P=0 ORDER BY fiSortOrder";
        String sqlQueryMenuClsPrnSort = "select * from " + DBModel.getTableName(MenuClsPrintSortDBModel.class) +
                " where fsShopGUID='" + shopGUID + "'" +
                " order by fiPrintSortOrder asc";
        // 最新菜品分类列表
        List<MenuClsPrintSortDBModel> menuClsList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlQueryMenuCls, MenuClsPrintSortDBModel.class);
        if (!ListUtil.isEmpty(menuClsList)) {
            for (MenuClsPrintSortDBModel menuCls : menuClsList) {
                // 处理子分类下的菜品数量
                processSonMenuCls(shopGUID, menuCls);
            }
        }

        LogUtil.log("获取一级菜品分类 " + menuClsList);
        // 上一次排序结果
        List<MenuClsPrintSortDBModel> menuClsPrintSortList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlQueryMenuClsPrnSort, MenuClsPrintSortDBModel.class);
        LogUtil.log("获取上一次排序 " + menuClsPrintSortList);
        // 最终要给到用户的列表：menuClsList的内容+menuClsPrintSortList的排序
        List<MenuClsPrintSortDBModel> result = new ArrayList<>(menuClsList);

        processDiff(menuClsList, menuClsPrintSortList);
        mergePrintOrder(result, menuClsPrintSortList);
        sortByPrintOrder(result);

        return result;
    }

    private static void processSonMenuCls(String shopGUID, MenuClsPrintSortDBModel menuCls) {
        if (menuCls == null || menuCls.count != 0) {
            return;
        }
        String sql = "select fsShopGUID,fsMenuClsId,fsMenuClsName,fiStatus,fiLevel," +
                " (select count(*) FROM tbmenuitem WHERE fsMenuClsId=tbmenucls.fsMenuClsId and fistatus='1') 'count' " +
                " from " + DBModel.getTableName(MenuclsDBModel.class) +
                " where fsShopGUID='" + shopGUID + "'" +
                "  and fiStatus<>'13' and fiDataKind<>'1' and fsMenuClsId_P='" + menuCls.fsMenuClsId + "'";
        List<MenuClsPrintSortDBModel> sonList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuClsPrintSortDBModel.class);
        if (ListUtil.isEmpty(sonList)) {
            return;
        }
        for (MenuClsPrintSortDBModel sonCls : sonList) {
            processSonMenuCls(shopGUID, sonCls);
            if (sonCls != null) {
                menuCls.count += sonCls.count;
            }
        }
    }

    /**
     * 处理两列表差值
     */
    private static void processDiff(List<MenuClsPrintSortDBModel> menuClsList, List<MenuClsPrintSortDBModel> menuClsPrintSortList) {
        List<MenuClsPrintSortDBModel> addList = new ArrayList<>();
        List<MenuClsPrintSortDBModel> delList = new ArrayList<>();
        for (MenuClsPrintSortDBModel menuCls : menuClsList) {
            if (!contains(menuClsPrintSortList, menuCls)) {
                addList.add(menuCls);
            }
        }
        for (MenuClsPrintSortDBModel menuClsSort : menuClsPrintSortList) {
            if (!contains(menuClsList, menuClsSort)) {
                delList.add(menuClsSort);
            }
        }
        deleteMenuCls(delList);
        addMenuCls(addList);
    }

    private static boolean contains(List<MenuClsPrintSortDBModel> list, MenuClsPrintSortDBModel target) {
        for (MenuClsPrintSortDBModel menuCls : list) {
            if (TextUtils.equals(menuCls.fsMenuClsId, target.fsMenuClsId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 整合排序信息
     */
    private static void mergePrintOrder(List<MenuClsPrintSortDBModel> result, List<MenuClsPrintSortDBModel> menuClsSortList) {
        if (ListUtil.isEmpty(result)) {
            return;
        }
        int fromSort = -1;
        if (ListUtil.isEmpty(menuClsSortList)) {
            for (MenuClsPrintSortDBModel menuClsSort : result) {
                menuClsSort.fiPrintSortOrder = ++fromSort;
            }
        } else {
            fromSort = menuClsSortList.get(menuClsSortList.size() - 1).fiPrintSortOrder;
            for (MenuClsPrintSortDBModel menuCls : result) {
                for (MenuClsPrintSortDBModel menuClsSort : menuClsSortList) {
                    if (TextUtils.equals(menuCls.fsMenuClsId, menuClsSort.fsMenuClsId)) {
                        menuCls.fiPrintSortOrder = menuClsSort.fiPrintSortOrder;
                    }
                }
                if (menuCls.fiPrintSortOrder < 0) {
                    menuCls.fiPrintSortOrder = ++fromSort;
                }
            }
        }
    }

    private static void sortByPrintOrder(List<MenuClsPrintSortDBModel> result) {
        if (ListUtil.isEmpty(result)) {
            return;
        }
        for (int i = 0; i < result.size() - 1; i++) {
            for (int j = 0; j < result.size() - i - 1; j++) {
                if (result.get(j).fiPrintSortOrder > result.get(j + 1).fiPrintSortOrder) {
                    MenuClsPrintSortDBModel temp = result.get(j);
                    result.set(j, result.get(j + 1));
                    result.set(j + 1, temp);
                }
            }
        }
    }

    /**
     * 清除所有菜品分类打印排序
     */
    public static void clearAllMenuCls(String shopGUID) {
        String sql = "delete from " + DBModel.getTableName(MenuClsPrintSortDBModel.class) +
                " where fsShopGUID='" + shopGUID + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 添加菜品分类打印排序
     */
    public static void addMenuCls(List<MenuClsPrintSortDBModel> addList) {
        if (ListUtil.isEmpty(addList)) {
            return;
        }
        for (MenuClsPrintSortDBModel menuCls : addList) {
            LogUtil.log("添加菜品分类打印排序 " + menuCls.fsMenuClsId + " - " + menuCls.fsMenuClsName);
            menuCls.replaceNoTrans();
        }
    }

    /**
     * 删除菜品分类打印排序
     */
    public static void deleteMenuCls(List<MenuClsPrintSortDBModel> deleteList) {
        if (ListUtil.isEmpty(deleteList)) {
            return;
        }
        for (MenuClsPrintSortDBModel menuCls : deleteList) {
            LogUtil.log("删除菜品分类打印排序 " + menuCls.fsMenuClsId + " - " + menuCls.fsMenuClsName);
            menuCls.delete();
        }
    }

    /**
     * 更新菜品分类打印排序
     */
    public static void updateMenuClsSort(List<MenuClsPrintSortDBModel> menuClsSortList) {
        if (ListUtil.isEmpty(menuClsSortList)) {
            return;
        }
        String sql = "fsShopGUID='%s' and fsMenuClsId='%s'";
        ContentValues values = new ContentValues();
        for (MenuClsPrintSortDBModel menuCls : menuClsSortList) {
            values.clear();
            values.put("fiPrintSortOrder", menuCls.fiPrintSortOrder);
            menuCls.update(values, String.format(sql, menuCls.fsShopGUID, menuCls.fsMenuClsId), true);
        }
    }
}
