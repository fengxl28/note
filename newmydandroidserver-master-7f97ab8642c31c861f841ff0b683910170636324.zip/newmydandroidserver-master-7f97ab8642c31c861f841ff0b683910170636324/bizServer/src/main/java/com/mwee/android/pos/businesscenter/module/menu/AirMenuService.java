package com.mwee.android.pos.businesscenter.module.menu;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuDishAddResponse;
import com.mwee.android.air.connect.business.menu.MenuEditorResponse;
import com.mwee.android.air.connect.business.menu.MenuItemBeanResponse;
import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuClsDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemUnitDBUtils;
import com.mwee.android.pos.businesscenter.module.koubei.IAirMenuService;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.util.ListUtil;

import java.util.List;

/**
 * 菜品数据服务
 * Created by qinwei on 2018/6/5.
 */

public class AirMenuService implements IAirMenuService {
    @Override
    public List<MenuItemBean> findMenuItemAndUnitsByMenuClsId(String menuClsId) {
        List<MenuItemBean> menuItemBeans = MenuItemDBUtils.queryMenuItemsByClsId(menuClsId);
        if (!ListUtil.isEmpty(menuItemBeans)) {
            for (int i = 0; i < menuItemBeans.size(); i++) {
                menuItemBeans.get(i).menuItemUnitBeans = MenuItemUnitDBUtils.queryByMenuItemId(menuItemBeans.get(i).fiItemCd);
            }
        }
        return menuItemBeans;
    }

    @Override
    public AllMenuClsAndMenuItemResponse loadAirMenuManager(Boolean isLoadAllMenuItem, Boolean isContainSet) {
        AllMenuClsAndMenuItemResponse response = new AllMenuClsAndMenuItemResponse();
        response.menuClsBeanList = isContainSet?MenuClsDBUtils.queryAllContainSet():MenuClsDBUtils.queryAll();
        if (isLoadAllMenuItem) {
            response.menuItemBeanList = findMenuItemAndUnitsByMenuClsId(null);
        }
        return response;
    }

    @Override
    public MenuItemsResponse loadAirMenuItemByClsId(String fsMenuClsId) {
        MenuItemsResponse response = new MenuItemsResponse();
        response.menuItemBeanList = findMenuItemAndUnitsByMenuClsId(fsMenuClsId);
        return response;
    }

    @Override
    public MenuEditorResponse loadUpdateMenuItem(String fiItemCd, MenuItemEditorBody menuItemEditorBody) {
        MenuEditorResponse response = new MenuEditorResponse();
        MenuItemDBUtils.updateAirMenuItemAndUnit(fiItemCd, menuItemEditorBody);
        response.menuitemDBModel = MenuItemDBUtils.queryById(fiItemCd);
        response.menuItemUnitDBModels = MenuItemUnitDBUtils.queryByFiItemCd(fiItemCd);
        return response;
    }

    @Override
    public MenuDishAddResponse loadAddMenuItem(MenuItemEditorBody menuItemEditorBody) {
        MenuDishAddResponse response = new MenuDishAddResponse();
        String fiItemCd = MenuItemDBUtils.addAirMenuItem(menuItemEditorBody, ServerCache.getInstance().shopID);
        response.menuitemDBModel = MenuItemDBUtils.queryById(fiItemCd);
        response.menuItemUnitDBModels = MenuItemUnitDBUtils.queryByFiItemCd(fiItemCd);
        return response;
    }

    @Override
    public MenuItemBeanResponse loadAirMenuItemBeanById(String fiItemCd) {
        MenuItemBeanResponse response = new MenuItemBeanResponse();
        response.menuItemBean = MenuItemDBUtils.queryMenuItemBeanById(fiItemCd);
        response.menuItemBean.menuItemUnitBeans = MenuItemUnitDBUtils.queryByMenuItemId(fiItemCd);
        return response;
    }
}
