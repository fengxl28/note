package com.mwee.android.pos.businesscenter.air.dao;

import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;

import java.util.ArrayList;

/**
 * tbmtable表数据服务接口
 * Created by qinwei on 2018/8/17.
 */

public interface ITableDao extends IBaseDao<MtableDBModel> {
    /**
     * 新增拼桌信息
     *
     * @param mtableDBModel 原桌台信息
     * @param userDBModel   操作用户
     * @return
     */
    MtableDBModel insertShareTable(MtableDBModel mtableDBModel, UserDBModel userDBModel);


    /**
     * 查询原桌台所有拼桌信息列表
     *
     * @param tableId 桌台id
     * @return 所有拼桌列表
     */
    ArrayList<MtableDBModel> queryShareTablesByMainTableId(String tableId);

    /**
     * 根据桌台名称查找桌台
     *
     * @param mTableName
     * @return
     */
    MtableDBModel queryByMTableName(String mTableName);

    /**
     * 根据桌id或者桌台名称查找桌台
     *
     * @param table
     * @return
     */
    MtableDBModel queryByIdOrMTableName(String table);

    /**
     * 根据桌台二维码信息查询桌台
     *
     * @param table_no
     * @return
     */
    ArrayList<MtableDBModel> queryByTableNo(String table_no);

    /**
     * 根据桌台码类型配置查找桌台
     *
     * @param table_no
     * @return
     */
    MtableDBModel queryByTableNoAndTableQRConfig(String table_no);

}
