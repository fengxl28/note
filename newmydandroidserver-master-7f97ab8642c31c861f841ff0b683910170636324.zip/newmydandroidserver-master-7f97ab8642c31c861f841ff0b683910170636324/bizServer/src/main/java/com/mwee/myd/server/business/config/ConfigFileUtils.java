package com.mwee.myd.server.business.config;

import android.text.TextUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * @ClassName: ConfigFileUtils
 * @Description:
 * @author: SugarT
 * @date: 2017/8/24 下午3:51
 */
public class ConfigFileUtils {

    /**
     * 校验文件是否存在
     *
     * @param path
     * @return
     */
    public static boolean checkFileExists(String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }
        File file = new File(path);
        return checkFileExists(file);
    }

    /**
     * 校验文件是否存在
     *
     * @param file
     * @return
     */
    public static boolean checkFileExists(File file) {
        if (file == null) {
            return false;
        }
        return file.exists();
    }

    /**
     * 校验文件是否可读
     *
     * @param path
     * @return
     */
    public static boolean checkFileReadAccess(String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }
        if (!checkFileExists(path)) {
            return false;
        }
        try {
            File file = new File(path);
            return checkFileReadAccess(file);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 校验文件是否可读
     *
     * @param file
     * @return
     */
    public static boolean checkFileReadAccess(File file) {
        if (file == null) {
            return false;
        }
        return file.canRead();
    }

    /**
     * 是否是合法的zip文件
     *
     * @param path
     * @return
     */
    public static boolean isValidZipFile(String path) {
        if (!checkFileReadAccess(path)) {
            return false;
        }
        // 尝试打开，以校验文件
        ZipFile zipFile = null;
        try {
            zipFile = new ZipFile(path);
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (zipFile != null) {
                    zipFile.close();
                    zipFile = null;
                }
            } catch (IOException e) {
                // 暂不做处理
            }
        }
    }

    /**
     * 解压缩文件到指定目录
     *
     * @param zipPath 待解压缩的文件
     * @param destDir 解压缩后存放文件的目录
     */
    public static void unZip(String zipPath, String destDir) {
        if (TextUtils.isEmpty(zipPath) || TextUtils.isEmpty(destDir)) {
            return;
        }
        if (!destDir.endsWith(File.separator)) {
            destDir += File.separator;
        }
        try {
            File f = new File(destDir);
            if (!f.isDirectory()) {
                f.mkdirs();
            }
            ZipInputStream zin = new ZipInputStream(new FileInputStream(zipPath));
            try {
                ZipEntry ze = null;
                while ((ze = zin.getNextEntry()) != null) {
                    String path = destDir + ze.getName();

                    if (ze.isDirectory()) {
                        File unzipFile = new File(path);
                        if (!unzipFile.isDirectory()) {
                            unzipFile.mkdirs();
                        }
                    } else {
                        FileOutputStream fout = new FileOutputStream(path, false);
                        try {
                            for (int c = zin.read(); c != -1; c = zin.read()) {
                                fout.write(c);
                            }
                            zin.closeEntry();
                        } finally {
                            fout.close();
                        }
                    }
                }
            } finally {
                zin.close();
            }
        } catch (Exception e) {
            // do nothing
        }
    }

    public static void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        try {
            OutputStream out = new FileOutputStream(dst);
            try {
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }
}
