package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by qinwei on 2018/1/9.
 */
public class SellreceiveDBUtil {
    /**
     * 计算本地挂账额度
     *
     * @param fsCreditAccountId
     * @return
     */
//    public static BigDecimal optCreditAccountUsedAmt(String fsCreditAccountId, String sellDate) {
//        String sql = "SELECT  sum(fdrecemoney) fdrecemoney from  " +
//                "tbsellreceive a left join tbsell b  on a.fssellno = b.fssellno " +
//                "where a.fiStatus='1' and b.fiBillStatus !=6  and a.fsCreditAccountId='" + fsCreditAccountId + "' and b.fsSellDate='" + sellDate + "'";
//        LogUtil.log("本地挂账额度sql=" + sql);
//        String result = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
//        BigDecimal fdrecemoney = BigDecimal.ZERO;
//        if (!TextUtils.isEmpty(result)) {
//            fdrecemoney = new BigDecimal(result);
//        }
//        LogUtil.log("本地挂账额度为：" + result);
//        return fdrecemoney;
//    }
}
