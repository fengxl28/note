package com.mwee.android.pos.businesscenter.business.kds.algorithm.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * @ClassName: AOutletDataBean
 * @Description: Kds 算法模型初始化档口数据
 * @author: Cannan
 * @date: 2018/11/12 下午4:54
 */
public class AOutletDataBean extends BusinessBean {

    /**
     * 档口id
     * {@link com.mwee.android.pos.db.business.DeptDBModel#fsDeptId}
     */
    public String outletId = "";

    /**
     * 今天该档口对应的当班厨师人数
     */
    public int cookerNum = 0;

    public AOutletDataBean() {
    }
}
