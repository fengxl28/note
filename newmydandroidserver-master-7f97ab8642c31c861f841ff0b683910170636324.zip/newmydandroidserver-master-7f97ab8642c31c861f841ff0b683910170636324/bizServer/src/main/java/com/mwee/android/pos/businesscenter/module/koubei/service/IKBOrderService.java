package com.mwee.android.pos.businesscenter.module.koubei.service;

import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;

/**
 * 口碑扫码订单服务
 * Created by qinwei on 2018/8/17.
 */

public interface IKBOrderService {
    /**
     * 口碑桌台扫码订单->接单处理
     *
     * @param kbPreOrderCache 口碑订单信息
     */
    SocketResponse<ScannerTableOrderAcceptResponse> acceptPreOrder(KBPreOrderCache kbPreOrderCache);

    /**
     * 线上预点分配桌台
     *
     * @param order_id
     * @param tableId
     * @param printMake
     * @return
     */
    String allocationTableOrder(String order_id, String tableId,boolean printMake);

    /**
     * 结账清台
     *
     * @return
     */
    SocketResponse checkOut(String orderId, UserDBModel userDBModel);

    /**
     * 口碑桌台扫码订单->退款
     */
    void refund(String orderId);


    /**
     * 口碑桌台扫码后付款->接单
     *
     * @param kbOrder 口碑订单
     * @return
     */
    SocketResponse<ScannerTableOrderAcceptResponse> acceptAfterPayOrder(KBAfterPayOrder kbOrder, String hostId);


}
