package com.mwee.android.pos.businesscenter.business.kds.algorithm.bean;

import com.mwee.android.base.net.BusinessBean;

/**
 * @ClassName: ATableBean
 * @Description: kds 算法 api 接口入参桌台信息
 * @author: Cannan
 * @date: 2018/11/7 下午3:16
 */
public class ATableBean extends BusinessBean {

    /**
     * 餐桌对应的Id编号（一天之中是唯一的）
     * 2018-11-12 是否可直接使用订单号 fsSellNo
     * {@link com.mwee.android.pos.db.business.SellDBModel#fssellno}
     */
    public String tableId = "";

    /**
     * 餐桌名称
     * {@link com.mwee.android.pos.db.business.SellDBModel#fsMTableName}
     */
    public String tableName = "";

    /**
     * 餐桌对应人数
     * {@link com.mwee.android.pos.db.business.SellDBModel#fiCustSum}
     */
    public int peopleNum = 0;

    public ATableBean() {
    }
}
