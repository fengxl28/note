package com.mwee.myd.server.slave;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBCreate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.SdcardUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @ClassName: SlaveDBUtils
 * @Description: slave 数据库工具类
 * @author: SugarT
 * @date: 2018/5/29 下午8:25
 */
public class SlaveDBUtils {

    /**
     * 根据日期构建从库 dbName
     *
     * @param date String | 日期
     * @return
     */
    @NonNull
    public static String buildDatabaseName(String date) {
        if (TextUtils.isEmpty(date)) {
            return "";
        }
        try {
            if (ReplicationDBUtil.isValidFormat("yyyy-MM-dd", date)) {
                date = DateUtil.formartDateStrToTarget(date, "yyyy-MM-dd", DateUtil.DATE_YYYYMMDD);
            }

            String dbName = String.format(SlaveConstant.SLAVE_DATABASE_FORMAT, date);

            if (checkDBExists(GlobalCache.getContext(), dbName)) {
                // 默认获取数据库名称后，将会使用 DBManager 进行 SQL 操作, 这里进行注册
                if (DBManager.getInstance(dbName) == null) {
                    SQLiteDatabase db = SQLiteDatabase.openDatabase(GlobalCache.getContext().getDatabasePath(dbName).toString(), null, 0);
                    if (db != null) {
                        int version = db.getVersion();
                        db.close();
                        DBManager.init(GlobalCache.getContext(), 0, dbName, version);
                    }
                }
            } else {
                slaveCreate(GlobalCache.getContext(), dbName);
            }

            return dbName;
        } catch (Exception ex) {
            LogUtil.logError(ex);
            return "";
        }
    }

    /**
     * 校验 database 是否已存在
     *
     * @param context
     * @param dbName
     * @return
     */
    public static boolean checkDBExists(Context context, String dbName) {
        File file = context.getDatabasePath(dbName);
        return file.exists();
    }

    /**
     * 校验 table 是否已存在
     *
     * @param context
     * @param dbName
     * @param tableName
     * @return
     */
    public static boolean checkTableExists(Context context, String dbName, String tableName) {
        if (TextUtils.isEmpty(dbName)) {
            return false;
        }
        if (TextUtils.isEmpty(tableName)) {
            return false;
        }
        if (DBManager.getInstance(dbName) == null) {

        }
        String name = DBSimpleUtil.queryString(dbName, "SELECT DISTINCT tbl_name FROM sqlite_master WHERE tbl_name = '" + tableName + "'");
        if (!TextUtils.isEmpty(name)) {
            return true;
        }
        return false;
    }

    /**
     * 创建 database, 创建表(tbSell, tbSellOrder, tbSellOrderItem, tbSellReceive, tbSellCheck, tbSellCoupon, order_cache,
     * order_menu_cache, order_pay_cache)
     *
     * @param context
     * @param dbName
     * @return List<String> | 所有创建的表名
     */
    public static List<String> slaveCreate(Context context, String dbName) {
        // 所有创建的表名
        List<String> result = new ArrayList<>();

        // 校验磁盘空间
        String err = SdcardUtil.checkSDCardUsableWithToast(context);
        if (!TextUtils.isEmpty(err)) {
            RunTimeLog.addLog(RunTimeLog.SLAVE_DATABASE, "SlaveDBManager#prepareNextDatabase " + err);
            return result;
        }

        CountDownLatch lock = new CountDownLatch(1);

        try {
            DBManager.init(context, 0, dbName, 1, new IDBCreate() {
                @Override
                public void onCreate(SQLiteDatabase db) {
                    // 从文件中读取建表 SQL
                    String sql = loadJSONFromAsset(context);
                    if (TextUtils.isEmpty(sql)) {
                        return;
                    }

                    JSONObject jsonObject = JSONObject.parseObject(sql);
                    if (jsonObject == null) {
                        return;
                    }

                    // 遍历节点建表
                    for (String tableName : jsonObject.keySet()) {
                        if (TextUtils.isEmpty(tableName)) {
                            continue;
                        }
                        String createSQL = jsonObject.getString(tableName);
                        if (TextUtils.isEmpty(createSQL)) {
                            continue;
                        }
                        db.execSQL(createSQL);
                        LogUtil.log("slave create table: " + tableName + "\nsql: " + createSQL);

                        result.add(tableName);
                    }

                    if (lock != null) {
                        lock.countDown();
                    }
                }

                @Override
                public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

                }
            });
            if (lock.getCount() > 0) {
                try {
                    lock.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception ex) {
            LogUtil.logError(ex);
        } finally {
            return result;
        }
    }

    public static Pattern p = Pattern.compile("[0-9]{8}", Pattern.CASE_INSENSITIVE);

    /**
     * 删除指定日期前 30 日的数据库
     *
     * @param context
     * @param date    日期
     */
    public static void slaveDelete(Context context, String date) {
        File dbFile = context.getDatabasePath(APPConfig.DB_MAIN);
        if (dbFile == null) {
            return;
        }
        File dbFloder = dbFile.getParentFile();
        if (dbFloder != null && dbFloder.exists() && dbFloder.isDirectory()) {
            File[] allDB = dbFloder.listFiles();
            if (allDB != null && allDB.length > 0) {
                for (File db : allDB) {
                    if (!db.exists()) {
                        continue;
                    }
                    if (!db.isFile()) {
                        continue;
                    }
                    String fileName = db.getName();

                    // 从库的文件名称判断
                    if (!fileName.startsWith("slave_")) {
                        continue;
                    }

                    // 从文件中提取日期
                    String fileDate = "";
                    Matcher m = p.matcher(fileName);
                    if (m.find()) {
                        fileDate = m.group();
                    }
                    if (TextUtils.isEmpty(fileDate)) {
                        continue;
                    }

                    // 格式化日期
                    if (!ReplicationDBUtil.isValidFormat("yyyy-MM-dd", fileDate)) {
                        fileDate = DateUtil.formartDateStrToTarget(fileDate, DateUtil.DATE_YYYYMMDD, "yyyy-MM-dd");
                    }
                    if (!ReplicationDBUtil.isValidFormat("yyyy-MM-dd", fileDate)) {
                        continue;
                    }

                    // 如果文件日期超出当前日期 30 天，删除
                    try {
                        if (DateUtil.daysBetween(fileDate, date) > 30) {
                            FileUtil.deleteAllFile(db);
                        }
                    } catch (Exception e) {
                        LogUtil.logError(e);
                    }
                }
            }
        }
    }

    /**
     * 删除数据库
     *
     * @param context context
     * @param dbName  数据库名称
     */
    public static void slaveDestroy(Context context, String dbName) {
        if (context == null) {
            return;
        }
        if (TextUtils.isEmpty(dbName)) {
            return;
        }
        try {
            // 1. 删除 sqlite 文件
            File file = context.getDatabasePath(dbName);
            if (file != null && file.exists()) {
                FileUtil.deleteAllFile(file);
            }

            // 2. 删除 DBManage 中注册的实例
            DBManager.getInstance(dbName).closeAll();
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
    }

    /**
     * 获取对应数据库所有表名
     *
     * @param context
     * @param dbName  数据库名称
     * @return
     */
    public static List<String> findAllTableName(Context context, String dbName) {
        List<String> result;
        String sql = "SELECT name FROM sqlite_master WHERE type = 'table'";
        result = DBSimpleUtil.queryStringList(dbName, sql);
        if (result == null) {
            result = new ArrayList<>();
        }
        return result;
    }

    public static String loadJSONFromAsset(Context context) {
        String json;
        try {
            InputStream is = context.getAssets().open("slave_database.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    /**
     * 从主库获取建表语句，每次从库建表对齐主库
     *
     * @return
     */
    public static JSONObject loadSQLFromMaster() {
        String sql = "SELECT name, sql FROM sqlite_master WHERE name IN ('tbsell', 'tbsellorder', 'tbsellorderitem', 'tbsellreceive', 'tbsellcheck', 'tbsellCoupon', 'tbSellOrderItemNote', 'tbSellPickMenuitem', 'order_cache', 'order_menu_cache', 'order_pay_cache')";
        return DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
    }
}
