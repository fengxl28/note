package com.mwee.android.pos.businesscenter.dbutil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * 用户DB管理类
 * Created by qinwei on 2017/8/2.
 */

public class UserDBUtils {
    /**
     * 根据用户id查询用户信息
     *
     * @param userId
     * @return
     */
    public static UserDBModel queryById(String userId) {
        String sql = "select * from tbUser where fsUserId = '" + userId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, UserDBModel.class);
    }


    public static UserDBModel queryCloudUser() {
        String sqlWaiter = "select * from tbUser where fsStaffId = 'cash'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sqlWaiter, UserDBModel.class);
    }
}
