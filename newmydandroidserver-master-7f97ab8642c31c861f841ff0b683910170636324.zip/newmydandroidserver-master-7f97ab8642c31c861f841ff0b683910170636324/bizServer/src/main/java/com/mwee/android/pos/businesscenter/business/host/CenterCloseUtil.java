package com.mwee.android.pos.businesscenter.business.host;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;

import java.util.List;

/**
 * 业务中心的打烊处理类
 * Created by virgil on 16/9/27.
 */
public class CenterCloseUtil {
    /**
     * 存在未结账的订单
     */
    public final static int ERROR_ORDER_UN_PAIED = -1;
    /**
     * 存在部分支付的订单
     */
    public final static int ERROR_ORDER_UN_FINISHED = -2;
    /**
     * 存在未清台的桌子
     */
    public final static int ERROR_TABLE_UNCLEAR = -3;
    /**
     * 存在未交班的服务员
     */
    public final static int ERROR_UNSHIFT = -4;
    /**
     * 只能在主站点打烊
     */
    public final static int ERROR_HOST = -5;
    /**
     * 有服务员在登录中
     */
    public final static int ERROR_LOGIN = -6;

    public static SocketResponse processClose(String requestHostID) {
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        SocketResponse response = new SocketResponse();
        /**
         * todo 剔除小易快餐0元快餐账单
         */
        if (APPConfig.isAir()) {
            doDeleteZeroOrder(currentBusinessDate);
        }
        String sql_unpayed_order = "select order_id " +
                "from order_cache  " +
                "where order_status in (0,1,2,4) " +
                "and business_date='" + currentBusinessDate + "' " +
                "and order_id not in " +
                "(select Id from " +
                "(select fastfood_order_biz.order_id as Id, order_pay_cache.order_id payID " +
                "from fastfood_order_biz left join order_pay_cache " +
                "on fastfood_order_biz.order_id = order_pay_cache.order_id and fastfood_order_biz.business_date='" + currentBusinessDate + "' and order_pay_cache.business_date='" + currentBusinessDate + "' " +
                " where fastfood_biz_status = '0' and payID is null)" +
                ") " +  //过滤掉新开台的快餐单
                "limit 1";

        String unPayedOrderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);
        if (!TextUtils.isEmpty(unPayedOrderID)) {
            response.code = ERROR_ORDER_UN_PAIED;
            response.message = OrderDriver.getErrorMsg(unPayedOrderID);
            return response;
        }

        String sql_unfinished_order = "select order_id " +
                "from order_pay_cache   " +
                "where payed='0' and business_date='" + currentBusinessDate + "' limit 1";
        String unfinished_order = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unfinished_order);
        if (!TextUtils.isEmpty(unfinished_order)) {
            response.code = ERROR_ORDER_UN_FINISHED;
            response.message = OrderDriver.getErrorMsg(unfinished_order);
            return response;
        }
        String unFinishedTableName = TableBusinessUtil.getUncleanTable();
        if (!TextUtils.isEmpty(unFinishedTableName)) {
            response.code = ERROR_TABLE_UNCLEAR;
            response.message = "桌台[" + unFinishedTableName + "]尚未清台";
            return response;
        }
        String unShiftWaiter = getUnShiftUser(currentBusinessDate);
        if (!TextUtils.isEmpty(unShiftWaiter)) {
            response.code = ERROR_UNSHIFT;
            response.message = "收银员[" + unShiftWaiter + "]尚未交班";
            return response;
        }

        String currensHost = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        if (!TextUtils.equals(currensHost, requestHostID)) {
            response.code = ERROR_HOST;
            response.message = "只能在主站点打烊";
            return response;
        }
        //现在已经通过session来判断了，不再需要通过登录状态来判断了

//        String unCloseHost = HostUtil.getBizingHostIDWithoutCurrent();
//        if (!TextUtils.isEmpty(unCloseHost)) {
//            response.code = ERROR_LOGIN;
//            response.message = "有服务员在站点[" + unCloseHost + "]登录中。";
//            return response;
//        }
        return null;
    }

    /**
     * 获取未交班的收银员名称
     *
     * @param businessDate String
     * @return String
     */
    public static String getUnShiftUser(String businessDate) {
        String sql_unshift = "select waitername " +
                "from order_pay_cache   " +
                "where  locked='0' and  waiterid<>'cash' and business_date='%s' and order_id not in (select order_id from order_cache where  fiSellType = '2' and business_date='%s')";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql_unshift, businessDate, businessDate));
    }

    /**
     * 获取未交班的班别
     *
     * @param businessDate String
     * @return String
     */
    public static String getUnShiftName(String businessDate) {
        String sql_unshift = "select fsShiftName from tbshift where fsshiftid=(select shiftid from order_pay_cache  where  locked='0' and  waiterid<>'cash' and business_date='%s' and order_id not in (select order_id from order_cache where  fiSellType = '2' and business_date='%s')";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql_unshift, businessDate, businessDate));
    }

    /**
     * 判断当前班别是否有未交班的订单
     *
     * @param shiftID      String
     * @param businessDate String
     * @return String
     */
    public static String checkUnShift(String shiftID, String businessDate) {
        String sql = "select fsShiftName from tbshift where fsshiftid=(select shiftid from order_pay_cache where locked='0' and  waiterid<>'cash' and business_date='%s'  and shiftid='%s' and order_id not in (select order_id from order_cache where  fiSellType = '2' and business_date='%s') limit 1)";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, businessDate, shiftID, businessDate));
    }

    /**
     * 获取所有未结账订单
     *
     * @param businessDate String
     * @return String
     */
    public static List<JSONObject> getDidNotCheckList(String businessDate) {
        String sql_unpayed_order = "select order_id,fiSellType,tableID " +
                "from order_cache  " +
                "where order_status in (0,1,2,4) " +
                "and business_date='" + businessDate + "' " +
                "and order_id not in " +
                "(select Id from " +
                "(select fastfood_order_biz.order_id as Id, order_pay_cache.order_id payID " +
                "from fastfood_order_biz left join order_pay_cache " +
                "on fastfood_order_biz.order_id = order_pay_cache.order_id and fastfood_order_biz.business_date='" + businessDate + "' and order_pay_cache.business_date='" + businessDate + "' " +
                " where fastfood_biz_status = '0' and payID is null)" +
                ") " + //过滤掉新开台的快餐单
                "or order_id in ( select fsSellNo from tbsell where fiBillStatus in (0, 1, 2, 4) and fsSellDate='" + businessDate + "' ) " +//tbsell未结账订单
                "or order_id in ( select order_id from order_pay_cache where payed='0' and business_date='" + businessDate + "' )";//order_pay_cache未支付结账
        return DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql_unpayed_order);
    }


    /**
     * 处理小易0元账单未结账的问题
     *
     * @param currentBusinessDate
     */
    private static void doDeleteZeroOrder(String currentBusinessDate) {

        List<String> zeroUnPayAll = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select order_id from order_cache where business_date='" + currentBusinessDate + "' and order_status !='3' and fiSellType = '1' and total_price = '0'");
        //得到未结账的0元快餐订单 但是有菜品信息不可删除 需要商家手动处理
        List<String> zeroUnPayKeep = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select order_id from order_menu_cache where order_id in (select order_id from order_cache where business_date='" + currentBusinessDate + "' and order_status !='3' and fiSellType = '1' and total_price = '0') group by order_id");
        //得到未结账的0元快餐订单 没有菜品信息 可以直接删除
        if (!ListUtil.isEmpty(zeroUnPayAll)) {
            if (!ListUtil.isEmpty(zeroUnPayKeep)) {
                zeroUnPayAll.removeAll(zeroUnPayKeep);
            }
            String whereSql = ListUtil.optSqlParams(zeroUnPayAll);
            if (!TextUtils.isEmpty(whereSql)) {
                RunTimeLog.addLog(RunTimeLog.Shift, "需要删除的0元订单数据为[" + whereSql + "]");
                DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                    @Override
                    public Boolean doJob(SQLiteDatabase db) {
                        db.execSQL("delete from order_cache where order_id  in (" + whereSql + ")");
                        db.execSQL("delete from order_pay_cache where order_id  in (" + whereSql + ")");
                        db.execSQL("delete from tbSell where fssellno  in (" + whereSql + ")");
                        //db.execSQL("delete from fastfood_order_biz where order_id  in (" + whereSql + ")");
                        return true;
                    }
                });
            }
        }

    }


}
