package com.mwee.android.pos.businesscenter.driver;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.util.Pair;
import android.text.TextUtils;
import android.support.v4.util.ArrayMap;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.Driver;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.bonus.BonusUtils;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.DishesBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.NoteDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintTableUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.BatchCopyDishesResponse;
import com.mwee.android.pos.connect.business.bean.BatchReturnDishesResponse;
import com.mwee.android.pos.connect.business.bean.BatchTurnDishesRequest;
import com.mwee.android.pos.connect.business.bean.BatchTurnDishesResponse;
import com.mwee.android.pos.connect.business.bean.ChangeIngredientResponse;
import com.mwee.android.pos.connect.business.bean.ChangePackageItemsResponse;
import com.mwee.android.pos.connect.business.bean.MenuItemOperateAction;
import com.mwee.android.pos.connect.business.bean.MenuTemporaryResponse;
import com.mwee.android.pos.connect.business.bean.NoteListResponse;
import com.mwee.android.pos.connect.business.bean.OperateDishToCenterResponse;
import com.mwee.android.pos.connect.business.bean.model.CopyDiffModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.discount.DoDiscountResponse;
import com.mwee.android.pos.connect.business.dish.UpdateBuyNumResponse;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.TurnMenuItemModel;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.OrderType;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: DishesDriver
 * @Description:
 * @author: SugarT
 * @date: 16/8/16 上午10:18
 */
@SuppressWarnings("unused")
public class DishesDriver extends Driver {

    private static final String TAG = "dishes";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 更新提成人
     */
    @DrivenMethod(uri = "dishes/updateBonus")
    public static SocketResponse updateBonus(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            BaseSocketResponse responseData = new BaseSocketResponse();
            socketResponse.data = responseData;

            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSONObject.parseObject(params);
            String orderId = request.getString("orderId");
            String businessDate = request.getString("businessDate");
            List<MenuItem> menuList = JSONArray.parseArray(request.getString("menuList"), MenuItem.class);
            UserDBModel operationUser = request.getObject("operationUser", UserDBModel.class);

            if (!TextUtils.isEmpty(orderId)) {
                //检查订单token
                if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                    socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return socketResponse;
                }

                String fsmtableId = OrderDriver.getTableIDByOrderID(orderId);
                String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderId, "修改提成人");
                try {
                    OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "找不到订单" + orderId;
                        return socketResponse;
                    }
                    BonusBizUtil.updateBonus(orderCache, menuList);
                    OrderSession.getInstance().writeOrder(orderId, false, "updateBonus");
                } finally {
                    ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderId, "修改提成人");
                }
            }

            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 批量退菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/batchReturnDishes")
    public static SocketResponse batchReturnDishes(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        final BatchReturnDishesResponse response = new BatchReturnDishesResponse();
        socketResponse.data = response;
        try {
            //订单ID
            JSONObject request = JSONObject.parseObject(param);
            String orderId = request.getString("orderID");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            //检查订单token
            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }


            String currentTableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select tableID from order_cache where order_id = '" + orderId + "'");
            if (TextUtils.isEmpty(currentTableId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有找到桌台";
                return socketResponse;
            }

            //发起站点
            String hostId = head.hd;
            //退菜内容
            List<VoidMenuItemModel> voidMenuItemModels = JSON.parseArray(request.getString("voidMenuItemModels"), VoidMenuItemModel.class);

            int result = DishesBizUtil.returnMenuItem(orderId, head.hd, currentTableId, userDBModel, voidMenuItemModels, response.printNoList);
            if (result == 0) {
                response.orderCache = OrderSession.getInstance().getOrder(orderId);
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "退菜成功";
            } else if (result == -1) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在，请稍后重试";
                return socketResponse;
            } else if (result == -2) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单号异常";
            } else if (result == -3) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已被结账";
            } else if (result == -4) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "退菜中包含菜品券，不允许退菜";
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 批量退菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/changeName")
    public static SocketResponse changeMenuName(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        try {
            //订单ID
            JSONObject request = JSONObject.parseObject(param);
            String orderId = request.getString("orderID");
            String menuUniq = request.getString("menuUniq");
            String newName = request.getString("newName");
            socketResponse = DishesBizUtil.changeMenuName(head.ot, head.us, orderId, menuUniq, newName);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 清除买减信息
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/cleanGiftBuyInfo")
    public static SocketResponse cleanGiftBuyInfo(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        try {
            DoDiscountResponse responseData = new DoDiscountResponse();
            socketResponse.data = responseData;

            //订单ID
            JSONObject request = JSONObject.parseObject(param);
            String orderId = request.getString("orderID");
            String fiitemcd = request.getString("fiitemcd");
            String fiOrderUintCd = request.getString("fiOrderUintCd");
            List<MenuItem> menuList = JSONArray.parseArray(request.getString("menuList"), MenuItem.class);

            if (!ListUtil.isEmpty(menuList)) {
                for (MenuItem item : menuList) {
                    if (item == null) {
                        continue;
                    }
                    if (TextUtils.equals(item.currentUnit.fiOrderUintCd, fiOrderUintCd) &&
                            TextUtils.equals(item.itemID, fiitemcd) && item.menuBiz.bugGiftItem != null) {
                        item.cleanBuyGiftInfo();
                        item.calcTotal(false);
                    }
                }
            }

            OrderCache orderCache = null;
            if (!TextUtils.isEmpty(orderId)) {
                orderCache = OrderSession.getInstance().getOrder(orderId);
                if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                    for (MenuItem item : orderCache.originMenuList) {
                        if (item == null) {
                            continue;
                        }
                        if (TextUtils.equals(item.currentUnit.fiOrderUintCd, fiOrderUintCd) &&
                                TextUtils.equals(item.itemID, fiitemcd) && item.menuBiz.bugGiftItem != null) {
                            item.cleanBuyGiftInfo();
                            item.calcTotal(false);
                        }
                    }
                    orderCache.plusAllMenuAmount();
                }
            }

            responseData.orderCache = orderCache;
            responseData.tempMenu = menuList;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 批量复制
     */
    @DrivenMethod(uri = "dishes/batchCopyDishes")
    public static SocketResponse batchCopyDishes(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";

        final BatchCopyDishesResponse response = new BatchCopyDishesResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            // 源订单Id
            String originalOrderId = request.getString("orderId");
            // 目标桌台列表
            List<String> targetTableIdList = JSON.parseArray(request.getString("targetTableIdList"), String.class);
            LogUtil.logBusiness("批量复制菜品：源订单【" + originalOrderId + "】，目标桌台【" + targetTableIdList + "】");

            if (TextUtils.isEmpty(originalOrderId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "当前订单不存在，请重试";
                return socketResponse;
            }

            if (ListUtil.isEmpty(targetTableIdList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有目标桌台，请重试";
                return socketResponse;
            }

            if (!ServerCache.getInstance().verifyToken(originalOrderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            // 源订单
            OrderCache originalOrder = OrderSession.getInstance().getOrder(originalOrderId);
            if (originalOrder == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在，请稍后重试";
                return socketResponse;
            }

            if (ListUtil.isEmpty(originalOrder.originMenuList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有可复制菜品";
                return socketResponse;
            }

            // 源桌台Id
            String originalTableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select tableID from order_cache where order_id = '" + originalOrderId + "'");
            if (TextUtils.isEmpty(originalTableId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "当前订单异常，请重试";
                return socketResponse;
            }

            // 源桌台
            MtableDBModel originalTable = TableDBUtil.getMTableById(originalTableId);
            if (originalTable == null) {
                socketResponse.code = -2;
                socketResponse.message = "没有查询到指定桌台";
                return socketResponse;
            }

            // 锁源订单
            String originalTableLockUniq = ServerCache.getInstance().tableLockCache.doLock(originalTableId, originalOrderId, "复制菜品源桌台【" + originalTableId + "】");

            try {
                // 打印小票编号
                List<Integer> printNos;
                for (int i = 0; i < targetTableIdList.size(); i++) {
                    // 目标桌台
                    String targetTableId = targetTableIdList.get(i);
                    MtableDBModel targetTable = TableDBUtil.getMTableById(targetTableId);

                    if (targetTable == null) {
                        LogUtil.logBusiness("批量复制菜品：未查询到目标桌台【" + targetTableId + "】，跳过复制到该桌台");
                        continue;
                    }

                    TableBizModel targetTableBiz = TableDBUtil.optDefaultTableBizModel(targetTableId);
                    if (targetTableBiz == null) {
                        LogUtil.logBusiness("批量复制菜品：未查询到目标桌台【" + targetTableId + ", " + targetTable.fsmtablename + "】，跳过复制到该桌台");
                        continue;
                    }
                    if (!TableConstans.TABLE_STATUS_FREE.equals(targetTableBiz.fsmtablesteid) || !TextUtils.isEmpty(targetTableBiz.fssellno)) {
                        LogUtil.logBusiness("批量复制菜品：桌台不是空闲状态【" + targetTableId + ", " + targetTable.fsmtablename + "】，跳过复制到该桌台");
                        response.occupiedTableNameList.add(targetTable.fsmtablename);
                        continue;
                    }

                    String targetTableLockUniq = ServerCache.getInstance().tableLockCache.doLock(targetTableId, "", "复制菜品目标桌台【" + targetTableId + "】");

                    try {
                        // 锁目标桌台
                        String lockError = TableBusinessUtil.lockTable(targetTableId, head.hd, userDBModel.fsUserId, userDBModel.fsUserName, false);
                        if (!TextUtils.isEmpty(lockError)) {
                            LogUtil.logBusiness("批量复制菜品：未查询到目标桌台，跳过复制到该桌台--" + lockError);
                            continue;
                        }

                        OrderCache targetOrder = originalOrder.clone();
                        targetOrder.seqList = ListUtil.cloneList(originalOrder.seqList);
                        // 重新生成订单号
                        String targetOrderId = OrderDriver.generateNewOrderID();
                        LogUtil.logBusiness("批量复制菜品：目标桌台订单号【" + targetTableId + "，" + targetOrderId + "】");

                        // 更新目标订单信息
                        targetOrder.orderID = targetOrderId;
                        targetOrder.mealNumber = targetOrderId.substring(8, 12);
                        targetOrder.fsmareaid = targetTable.fsmareaid;
                        targetOrder.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + targetTable.fsmareaid + "'");
                        targetOrder.fsmtableid = targetTable.fsmtableid;
                        targetOrder.fsmtablename = targetTable.fsmtablename;
                        targetOrder.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
                        targetOrder.orderStatus = OrderStatus.NORMAL;
                        targetOrder.orderType = OrderType.NORMAL;
                        targetOrder.waiterID = userDBModel.fsUserId;
                        targetOrder.waiterName = userDBModel.fsUserName;
                        targetOrder.currentHostID = head.hd;
                        targetOrder.antiPayWaiterID = "";
                        targetOrder.antiPayWaiterName = "";
                        targetOrder.antiPayReason = "";
                        targetOrder.antiPayCount = 0;
                        targetOrder.printPre = 0;
                        targetOrder.voidreason = "";
                        targetOrder.mergedOrderID = "";
                        targetOrder.mergedOrderInfo = "";
                        targetOrder.minStandardAmt = BizConstant.NEGATIVE;
                        targetOrder.totalPrice = BigDecimal.ZERO;
                        targetOrder.totalMenuPrice = BigDecimal.ZERO;

                        List<SellOutViewModel> needSellout = new ArrayList<>();
                        for (int j = 0; j < targetOrder.originMenuList.size(); j++) {
                            MenuItem item = targetOrder.originMenuList.get(j);
                            // 餐标/低消补充菜直接跳过，不校验
                            if (DinnerStandardUtil.isStandardMenu(item.itemID)) {
                                continue;
                            }
                            Pair<String, CopyDiffModel> formatResult = DishesBizUtil.processCopyMenuItem(item, true, false);
                            String error = formatResult.first;
                            CopyDiffModel copyDiff = formatResult.second;
                            if (copyDiff != null) {
                                String key = targetTable.fsmtablename;
                                if (!response.copyDiffMap.containsKey(key)) {
                                    response.copyDiffMap.put(key, new ArrayList<>());
                                }
                                copyDiff.orderId = targetOrderId;
                                copyDiff.tableId = targetTableId;
                                copyDiff.tableName = targetTable.fsmtablename;
                                response.copyDiffMap.get(key).add(copyDiff);
                            }
                            if (!TextUtils.isEmpty(error)) {
                                LogUtil.logBusiness("批量复制菜品：--" + error + "--，跳过复制该菜品");
                                targetOrder.originMenuList.remove(item);
                                j--;
                                continue;
                            }
                        }

                        // 刷新沽清
                        NotifyToClient.refreshSellOut();
                        DriverBus.call("monitor/update_rapid_sell_out");

                        // 格式化后菜品数量为0，不再开台
                        if (ListUtil.isEmpty(targetOrder.originMenuList)) {
                            LogUtil.logBusiness("批量复制菜品：格式化后菜品数量为0，跳过复制到该桌台");
                            continue;
                        }

                        // 复制后更改原桌台信息
                        TableBusinessUtil.setOriginTable(targetOrder.originMenuList, targetOrder.fsmtableid, targetOrder.fsmtablename, false, "");

                        // 目标桌台开台
                        TableBusinessUtil.openTable(targetTableId, targetOrderId, userDBModel);

                        DinnerStandardUtil.minStandardChanged(targetOrder, targetOrder.fsmareaid, userDBModel);
                        targetOrder.reCalcAllByAll();
                        OrderSession.getInstance().writeOrder(targetOrder.orderID, targetOrder, true, "DishesDriver batchCopyDishes 批量复制");
//                        OrderProcessor.saveOrder(targetOrder, null);
                        ServerCache.getInstance().generateNewToken(targetOrder.orderID);

                        // 正餐模式下，目标订单预结单打印状态变为未印单
                        if (targetOrder.dinnerModel()) {
                            TableBusinessUtil.modifyPrePrint(null, targetOrder.fsmtableid, targetOrder.orderID, TableStatusBean.GENERAL);
                        }

                        // 目标桌台解锁
                        TableBusinessUtil.unlockTargetTable(targetTableId);

                        // 打印
                        // 打印开台单
                        printNos = PrintTableUtil.openTableReport(targetOrder, head.hd);
                        if (!ListUtil.isEmpty(printNos)) {
                            response.printNoList.addAll(printNos);
                        }
                        // 打印点菜单
                        printNos = PrintOrderUtil.printMenuList(targetOrder, -1, null, head.hd);
                        if (!ListUtil.isEmpty(printNos)) {
                            response.printNoList.addAll(printNos);
                        }
                        // 打印传菜单
                        printNos = PrintOrderUtil.printPassTo(targetOrder, head.hd);
                        if (!ListUtil.isEmpty(printNos)) {
                            response.printNoList.addAll(printNos);
                        }
                        // 打印制作单
                        PrintOrderUtil.printMakeOrder(targetOrder, head.hd, "", "");

                        // 通知更新
                        NotifyToClient.refreshTableOrOrders();
                        NotifyToClient.refreshTableLock();
                    } finally {
                        ServerCache.getInstance().tableLockCache.unLock(targetTableLockUniq, targetTableId, "", "复制菜品目标桌台【" + targetTableId + "】");
                    }
                }
                socketResponse.data = response;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "复制成功";
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(originalTableLockUniq, originalTableId, originalTableId, "复制菜品源桌台【" + originalTableId + "】");
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 批量转菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/batchTurnDishes")
    public static SocketResponse batchTurnDishes(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";

        final BatchTurnDishesResponse response = new BatchTurnDishesResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }

            BatchTurnDishesRequest request = JSON.parseObject(param, BatchTurnDishesRequest.class);
            if (!request.fromSmart && !ServerCache.getInstance().verifyToken(request.oldSell, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            String orderId = request.oldSell;
            String currentTableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select tableID from order_cache where order_id = '" + orderId + "'");
            if (TextUtils.isEmpty(currentTableId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "当前订单异常，请重试";
                return socketResponse;
            }

            String targetTableId = request.mewTableId;
            String reason = request.reason;
            List<TurnMenuItemModel> trasferList = request.list;

            MtableDBModel targetTable = TableDBUtil.getMTableById(targetTableId);
            if (targetTable == null) {
                socketResponse.code = -2;
                socketResponse.message = "没有查询到指定桌台";
                return socketResponse;
            }

            /**
             * 为防止死锁，锁桌要统一顺序，比较桌台ID大小
             */
            String firstLockTableId = "";
            String secondLockTableId = "";
            String firstSellno = "";
            String secondSellno = "";
            String firstTips = "";
            String secondTips = "";

            if (currentTableId.compareToIgnoreCase(targetTableId) > 0) {
                firstLockTableId = currentTableId;
                firstSellno = orderId;
                firstTips = "批量转菜";
                secondLockTableId = targetTableId;
                secondSellno = "";
                secondTips = "批量转菜目标桌台";
            } else {
                secondLockTableId = currentTableId;
                secondSellno = orderId;
                secondTips = "批量转菜";
                firstLockTableId = targetTableId;
                firstSellno = "";
                firstTips = "批量转菜目标桌台";
            }

            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(firstLockTableId, firstSellno, firstTips);
            try {
                String targetTableLockUniq = ServerCache.getInstance().tableLockCache.doLock(secondLockTableId, secondSellno, secondTips);
                try {

                    final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单已不存在，请稍后重试";
                        return socketResponse;
                    }

                    if (orderCache.shareShopOrder()) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "该订单不支持任何修改";
                        return socketResponse;
                    }
                    if (orderCache.existMemberCoupon()) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "已使用菜品券优惠，无法进行转菜操作";
                        return socketResponse;
                    }

                    // 校验的支付信息不包括超标赠送
                    String countReceive = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                            "select count(*) as count from tbSellReceive where fsSellNo='" + orderId + "'" +
                                    " and fsPaymentId !='" + PayType.DINNERSTANDARD_COUPON + "' and fiStatus != '13'");
                    int count = 0;
                    if (!TextUtils.isEmpty(countReceive)) {
                        count = StringUtil.toInt(countReceive, 0);
                    }
                    if (count > 0) {
                        socketResponse.code = -2;
                        socketResponse.message = "当前订单已有支付信息，不能转菜";
                        return socketResponse;
                    }

                    TableBizModel originTableBizModel = TableDBUtil.optDefaultTableBizModel(currentTableId);
                    if (originTableBizModel.hasUnConfirmedRapid()) {
                        socketResponse.code = -2;
                        socketResponse.message = "当前桌台还有秒点订单未被处理";
                        return socketResponse;
                    }
                    TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(targetTableId);

                    String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiBillStatus from tbSell where fsSellNo='" + tableBizModel.fssellno + "'");
                    if (TextUtils.equals(fiBillStatus, "4")) {
                        socketResponse.code = -1;
                        socketResponse.message = "目标桌台正在反结账，菜品不能转入";
                        return socketResponse;
                    }

                    /**
                     * 开始锁桌
                     */
                    String lockError = TableBusinessUtil.lockTable(targetTableId, head.hd, userDBModel.fsUserId, userDBModel.fsUserName, false);

                    if (!TextUtils.isEmpty(lockError)) {
                        socketResponse.code = -1;
                        socketResponse.message = lockError;
                        return socketResponse;
                    }

                    String shopID = HostUtil.getShopID();

                    //  从原订单中过滤出转菜列表
                    List<MenuItem> neadTurnItems = new ArrayList<>();

                    List<String> usedBuyGiftMenu = new ArrayList<>();

                    if (!ListUtil.isEmpty(orderCache.originMenuList)) {

                        for (int i = 0; i < trasferList.size(); i++) {
                            TurnMenuItemModel sellOrderItemDBModel = trasferList.get(i);

                            for (int j = 0; j < orderCache.originMenuList.size(); j++) {

                                MenuItem temp = orderCache.originMenuList.get(j);

                                // 餐标、低消补充菜直接跳过
                                if (DinnerStandardUtil.isStandardMenu(temp.itemID)) {
                                    continue;
                                }

                                if (temp.hasAllVoid()) {
                                    continue;
                                }

                                MenuItem trasferItem;
                                if (TextUtils.equals(temp.menuBiz.uniq, sellOrderItemDBModel.fsseq)) {
                                    BigDecimal qty = sellOrderItemDBModel.qty;
                                    //数量
                                    boolean doRemove = false;
                                    if (temp.supportWeight()) {
                                        qty = temp.menuBiz.buyNum;
                                        trasferItem = temp;
                                        doRemove = true;
                                    } else if (temp.menuBiz.voidNum.compareTo(BigDecimal.ZERO) == 0) {
                                        if (qty.compareTo(temp.menuBiz.buyNum) >= 0) {
                                            qty = temp.menuBiz.buyNum;
                                            doRemove = true;
                                            trasferItem = temp;
                                        } else {
                                            trasferItem = temp.createTransferClone();
                                            insertPaddleStatus(head, userDBModel, orderCache, trasferItem);
                                        }
                                    } else {
                                        trasferItem = temp.createTransferClone();
                                        insertPaddleStatus(head, userDBModel, orderCache, trasferItem);
                                        if (qty.compareTo(temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum)) > 0) {
                                            qty = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
                                        }
                                    }
                                    trasferItem.menuBiz.buyNum = qty;
                                    trasferItem.menuBiz.voidNum = BigDecimal.ZERO;

                                    if (qty.compareTo(temp.menuBiz.giftNum) < 0) {
                                        trasferItem.menuBiz.giftNum = qty;
                                    } else {
                                        trasferItem.menuBiz.giftNum = temp.menuBiz.giftNum;
                                    }

                                    if (doRemove) {
                                        orderCache.originMenuList.remove(j);
                                    } else {
                                        temp.menuBiz.buyNum = temp.menuBiz.buyNum.subtract(trasferItem.menuBiz.buyNum);
                                        temp.menuBiz.giftNum = temp.menuBiz.giftNum.subtract(trasferItem.menuBiz.giftNum);
                                        temp.calcTotal(orderCache.isMember);
                                    }

                                    if (trasferItem.menuBiz.bugGiftItem != null) {
                                        trasferItem.cleanBuyGiftInfo();
                                        usedBuyGiftMenu.add(trasferItem.itemID + "_" + trasferItem.currentUnit.fiOrderUintCd);
                                    }
                                    trasferItem.cleanMemberInfo();

                                    if (DBOrderConfig.useKdsService()) {
                                        // 通知 KDS 菜品拆分
                                        KdsManager.getInstance().splitMenu(temp.menuBiz.uniq, trasferItem.menuBiz.uniq, trasferItem.menuBiz.buyNum, 3);
                                    }

                                    /* 调整划菜数量 */
                                    BigDecimal delimited = temp.menuBiz.delimitNum;
                                    // 划菜数量优先分配到转菜的菜品
                                    if (trasferItem.menuBiz.buyNum.subtract(trasferItem.menuBiz.voidNum).compareTo(delimited) >= 0) {
                                        trasferItem.menuBiz.delimitNum = delimited;
                                        temp.menuBiz.delimitNum = BigDecimal.ZERO;
                                    } else {
                                        trasferItem.menuBiz.delimitNum = trasferItem.menuBiz.buyNum.subtract(trasferItem.menuBiz.voidNum);
                                        temp.menuBiz.delimitNum = delimited.subtract(trasferItem.menuBiz.delimitNum);
                                    }

                                    //记录转菜操作
                                    trasferItem.mergedItemInfo = "服务员【" + userDBModel.fsUserName + "】由" + orderCache.fsmtablename + "桌转至" + targetTable.fsmtablename + "桌  " + DateUtil.getCurrentDateTime();
                                    neadTurnItems.add(trasferItem);
                                    break;
                                }
                            }
                        }
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单中已没有菜品，请先回到桌台页";
                        TableBusinessUtil.unlockTargetTable(targetTableId);
                        return socketResponse;
                    }

                    if (ListUtil.listIsEmpty(neadTurnItems)) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "没有找到可转菜品，请重试";
                        TableBusinessUtil.unlockTargetTable(targetTableId);
                        return socketResponse;
                    }

                    if (!ListUtil.isEmpty(usedBuyGiftMenu)) {
                        for (String uniq : usedBuyGiftMenu) {
                            for (MenuItem menuItem : orderCache.originMenuList) {
                                if (menuItem.menuBiz.bugGiftItem != null && TextUtils.equals(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd, uniq)) {
                                    menuItem.cleanBuyGiftInfo();
                                }
                            }
                        }
                    }

                    if (ListUtil.listIsEmpty(neadTurnItems)) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "没有找到可转菜品，请重试";
                        TableBusinessUtil.unlockTargetTable(targetTableId);
                        return socketResponse;
                    }


                    if (TextUtils.isEmpty(tableBizModel.fssellno)) {
                        //创建订单
                        OrderCache order = OrderDriver.generateNewOrder();
                        order.mealNumber = order.orderID.substring(order.orderID.length() - 4, order.orderID.length());
                        order.waiterID = userDBModel.fsUserId;
                        order.waiterName = userDBModel.fsUserName;
                        order.shopID = shopID;
                        order.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
                        order.currentHostID = head.hd;
                        order.currentSectionID = OrderUtil.getSectionId();
                        order.businessDate = HostUtil.getHistoryBusineeDate("");
                        order.orderStatus = OrderStatus.NORMAL;
                        order.fsmareaid = targetTable.fsmareaid;//	--餐区代碼
                        order.areaName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMAreaName from tbmarea where fsMAreaId = '" + targetTable.fsmareaid + "'");
                        order.fsmtableid = targetTable.fsmtableid;//	--餐桌代碼
                        order.fsmtablename = targetTable.fsmtablename;//	--餐桌名稱

                        order.updateSeqStatus(order.currentSeq, OrderSeqStatus.ORDERED, userDBModel, head.hd);
                        order.originMenuList.addAll(neadTurnItems);

                        //计算菜品价格
                        for (MenuItem menuItem : order.originMenuList) {
                            // 目标桌台无订单时，菜品不计入餐标
                            DinnerStandardUtil.placeMenuIntoStandard(menuItem, false);
                            menuItem.updateOrderSeq(order.currentSeq);
                            menuItem.calcTotal(order.isMember);
                        }

                        // 开台时添加餐标、低消补充菜品
                        OrderDriver.addDinnerStandardMenus(order, userDBModel, head.hd);

                        //添加预置菜品
                        List<MenuItem> preOrderList = OrderBizUtil.getOpenParamOrderMenu(targetTable.fsmareaid, 1, userDBModel.fsUserId, userDBModel.fsUserName);
                        if (!ListUtil.isEmpty(preOrderList)) {
                            order.currentSeq++;
                            order.updateSeqStatus(order.currentSeq, OrderSeqStatus.ORDERED, userDBModel, head.hd);
                            for (MenuItem menuItem : preOrderList) {
                                menuItem.updateOrderSeq(order.currentSeq);
                                menuItem.calcTotal(order.isMember);
                            }
                            response.withPreMenuOrderSeq = order.currentSeq;
                            order.originMenuList.addAll(preOrderList);
                        } else {
                            response.withPreMenuOrderSeq = -1;
                        }

                        order.currentSeq++;
                        //加入预设菜品
                        //更新订单金额
                        order.plusAllMenuAmount();

                        //处理口碑关单清台
                        if (orderCache.originMenuList.size() == 0) {
                            orderCache.kbStatus = KBConstants.KB_ACTION_CLOSE;
                            OrderProcessor.notifyOrderChanged(orderCache.orderID);
                        }

                        OrderSession.getInstance().writeOrder(order.orderID, order, true, "batchTurnDishes");
//                        OrderProcessor.saveOrder(order, null);
                        response.openNewTable = true;
                        response.targetOrder = order;
                        //更新桌台状态
                        TableBusinessUtil.openTable(targetTableId, order.orderID, userDBModel);
                        ServerCache.getInstance().generateNewToken(order.orderID);
                    } else {
                        //读取订单
                        ServerCache.getInstance().releaseToken(tableBizModel.fssellno);
                        OrderCache targetOrder = OrderSession.getInstance().getOrder(tableBizModel.fssellno);
                        if (targetOrder == null) {
                            /**
                             * 如果出现异常，则解除目标桌台的锁定
                             */
                            TableBusinessUtil.unlockTable(targetTableId, head.hd);

                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = "目标桌台异常，请稍后重试。";
                            return socketResponse;
                        } else {
                            if (targetOrder.shareShopOrder()) {
                                TableBusinessUtil.unlockTable(targetTableId, head.hd);
                                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                socketResponse.message = "目标桌台不支持转菜";
                                return socketResponse;
                            }
                            //计算菜品价格并保存
                            targetOrder.currentSeq++;
                            for (MenuItem item : neadTurnItems) {
                                // 目标桌台有订单，且未使用餐标时，清除菜品的"是否计入餐标"属性，如目标桌台使用了餐标，沿用原桌台的"是否计入餐标"属性
                                if (targetOrder.diningStandardAmt.compareTo(BigDecimal.ZERO) <= 0) {
                                    DinnerStandardUtil.placeMenuIntoStandard(item, false);
                                }
                                item.updateOrderSeq(targetOrder.currentSeq);
                                item.calcTotal(targetOrder.isMember);
                                targetOrder.originMenuList.add(item);
                                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbSellPickMenuitem set fsSellNo= '" + targetOrder.orderID + "' where fsMenuSeq= '" + item.menuBiz.uniq + "'");
                            }
                            targetOrder.updateSeqStatus(targetOrder.currentSeq, OrderSeqStatus.ORDERED, userDBModel, head.hd);
                            targetOrder.currentSeq++;
                            targetOrder.plusAllMenuAmount();

                            //处理口碑关单清台
                            if (orderCache.originMenuList.size() == 0) {
                                orderCache.kbStatus = KBConstants.KB_ACTION_CLOSE;
                                OrderProcessor.notifyOrderChanged(orderCache.orderID);
                            }

                            OrderSession.getInstance().writeOrder(targetOrder.orderID, true, "batchTurnDishes 2");
//                            OrderProcessor.saveOrder(targetOrder, null);
                            ServerCache.getInstance().generateNewToken(targetOrder.orderID);
                        }
                        response.targetOrder = targetOrder;
                        response.openNewTable = false;
                    }

                    // 正餐模式下，转菜后，原订单/目标订单预结单打印状态变为未印单
                    if (orderCache.dinnerModel()) {
                        TableBusinessUtil.modifyPrePrint(null, orderCache.fsmtableid, orderCache.orderID, TableStatusBean.GENERAL);
                        TableBusinessUtil.modifyPrePrint(null, response.targetOrder.fsmtableid, response.targetOrder.orderID, TableStatusBean.GENERAL);
                    }

                    // 转菜更改原桌台信息
                    TableBusinessUtil.setOriginTable(response.targetOrder.originMenuList, response.targetOrder.fsmtableid, response.targetOrder.fsmtablename, false, "");

                    // 保存转菜记录
                    TableDBUtil.addItemChangeTable(orderCache.orderID, response.targetOrder.orderID,
                            originTableBizModel.fsmtableid, tableBizModel.fsmtableid, neadTurnItems, reason, userDBModel.fsUserName, shopID);
                    TableDBUtil.writeTableChanged(orderCache.orderID, response.targetOrder.orderID, originTableBizModel.fsmtableid, targetTableId,
                            orderCache.fsmtablename, targetTable.fsmtablename, orderCache.fsmareaid, targetTable.fsmareaid,
                            orderCache.areaName, response.targetOrder.areaName, response.targetOrder.businessDate, 2, neadTurnItems, userDBModel);

                    // KDS服务
                    boolean useKdsService = DBOrderConfig.useKdsService();
                    if (useKdsService) {
                        List<String> opt = new ArrayList<>();
                        for (MenuItem item : neadTurnItems) {
                            if (item == null) {
                                continue;
                            }
                            opt.add(item.menuBiz.uniq);
                        }
                        KdsManager.getInstance().transferMenu(opt, response.targetOrder, head.hd, userDBModel);
                    }

                    boolean lastMenu = false;
                    boolean onlyHasStandardMenu = false;// 原订单是否只剩下餐标/低消补充菜
                    /**
                     * 如果是最后一道菜，则清台
                     */
                    if (orderCache.originMenuList.size() == 0) {
                        lastMenu = true;
                        onlyHasStandardMenu = true;
                    } else {
                        lastMenu = true;
                        onlyHasStandardMenu = true;
                        for (MenuItem item : orderCache.originMenuList) {
                            // 如果有菜品没有全退
                            if (!item.hasAllVoid()) {
                                lastMenu = false;
                                // 该菜品不是餐标/低消补充菜
                                if (!DinnerStandardUtil.isStandardMenu(item.itemID)) {
                                    onlyHasStandardMenu = false;
                                }
                                break;
                            }
                        }
                    }

                    //更新划菜数据
                    for (MenuItem item : neadTurnItems) {
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbSellPickMenuitem set fsSellNo= '" + response.targetOrder.orderID + "' where fsMenuSeq= '" + item.menuBiz.uniq + "'");
                    }

                    if (lastMenu || onlyHasStandardMenu) {

                        String orderInTableId = orderCache.fsmtableid;
                        // 如果菜品列表为空，菜品列表中只剩下餐标/低消补充菜，则清空订单菜品
                        if (ListUtil.isEmpty(orderCache.originMenuList) || onlyHasStandardMenu) {
                            orderCache.clearAllMenu(true);
                        } else {
                            orderCache.clearAllMenu(false);
                        }
                        orderCache.personNum = 0;

                        //免除服务费
                        orderCache.writeConfig(1);
                        orderCache.feeFreeUID = userDBModel.fsUserId;
                        orderCache.feeFreeUName = userDBModel.fsUserName;

                        orderCache.reCalcAllByAll();
                        orderCache.mergedOrderID = response.targetOrder.orderID;
                        orderCache.mergedOrderInfo = "服务员【" + userDBModel.fsUserName + "】转菜，导致订单结账 " + DateUtil.getCurrentDateTime();
                        OrderSession.getInstance().generatePaySession(orderCache, userDBModel, head.hd);
                        OrderSession.getInstance().writePay(orderCache.orderID, true);
                        // 更新缓存中状态为已结账
                        OrderSession.updateOrderStatus(orderCache.orderID, OrderStatus.PAIED);
                        OrderSession.setPayed(orderCache.orderID, 1);
                        PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, orderCache.fsmtableid, userDBModel, head.hd, 1);
                        TableBusinessUtil.closeTable(socketResponse, orderInTableId, orderId);
                        OrderSession.getInstance().clearOrder(orderCache.orderID);
                    } else {
                        orderCache.reCalcAllByAll();
                        OrderProcessor.saveOrder(orderCache, null);
                    }
                    OrderSession.getInstance().writeOrder(orderCache.orderID, false, "batchTurnDishes 3");

                    /**
                     * 解除目标桌台的锁定
                     */
                    TableBusinessUtil.unlockTargetTable(targetTableId);
                    NotifyToClient.refreshTableOrOrders();
                    response.clearTable = lastMenu || onlyHasStandardMenu;
                    response.currentOrder = orderCache;

                    //KDS服务不打印转菜单
                    if(!useKdsService){
                        /**
                         * 打印转菜单
                         */
                        List<Integer> printIDs = PrintOrderUtil.printBatchTransfer(response.targetOrder, neadTurnItems, userDBModel, orderCache.fsmtablename, head.hd);
                        if (!ListUtil.isEmpty(printIDs)) {
                            response.printNoList.addAll(printIDs);
                        }
                        if (response.openNewTable && response.targetOrder != null) {
                            printIDs = PrintTableUtil.openTableReport(response.targetOrder, head.hd);
                            if (!ListUtil.isEmpty(printIDs)) {
                                response.printNoList.addAll(printIDs);
                            }
                        }
                        if (response.withPreMenuOrderSeq > 0) {
                            List<Integer> printNoList = PrintOrderUtil.printMenuList(response.targetOrder, response.withPreMenuOrderSeq, null, head.hd);
                            if (!ListUtil.isEmpty(printNoList)) {
                                response.printNoList.addAll(printNoList);
                            }
                            printNoList = PrintOrderUtil.printPassTo(response.targetOrder, head.hd);
                            if (!ListUtil.isEmpty(printNoList)) {
                                response.printNoList.addAll(printNoList);
                            }
                            PrintOrderUtil.printMakeOrder(response.targetOrder, head.hd, response.withPreMenuOrderSeq + "", "");
                        }
                    }
                    NotifyToClient.orderChange(orderCache.orderID);

                    response.targetMenuitem = neadTurnItems;

                    socketResponse.data = response;

                    socketResponse.code = SocketResultCode.SUCCESS;
                    socketResponse.message = "转菜成功";
                } finally {
                    ServerCache.getInstance().tableLockCache.unLock(targetTableLockUniq, secondLockTableId, secondSellno, secondTips);
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, firstLockTableId, firstSellno, firstTips);
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 将新生成的菜品存入划菜表，防止划菜状态丢失
     *
     * @param head
     * @param userDBModel
     * @param orderCache
     * @param trasferItem
     */
    private static void insertPaddleStatus(SocketHeader head, UserDBModel userDBModel, OrderCache orderCache, MenuItem trasferItem) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(trasferItem);
        OrderSaveDBUtil.replacePaddleData(orderCache, menuItems, userDBModel, trasferItem.menuBiz.fiMenuProgress, head.hd);
    }


    /**
     * 已点单菜品操作
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/operateDish")
    public static SocketResponse hurryDish(SocketHeader head, String param) {
//        OperateDishToCenterRequest request = null;
        SocketResponse socketResponse = new SocketResponse();
        try {
            final OperateDishToCenterResponse response = new OperateDishToCenterResponse();
            socketResponse.data = response;
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderID");

            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            List<String> uniqList = JSONArray.parseArray(request.getString("menuUniq"), String.class);
            if (ListUtil.listIsEmpty(uniqList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "菜品异常，请稍后重试";
                return socketResponse;
            }

            String hostId = head.hd;
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);

            boolean updateDBResult = false;
            int operateType = request.getInteger("operateType");
            switch (operateType) {
                case MenuItemOperateAction.ACTION_HURRY: {  //催菜
                    String sqlParam = getUniqParamInSql(uniqList);
                    if (TextUtils.isEmpty(sqlParam)) {
                        updateDBResult = false;
                    } else {

                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (menuItem == null) {
                                continue;
                            }
                            if (uniqList.contains(menuItem.menuBiz.uniq)) {
                                menuItem.doHurry();
                            }
                        }

                        List<MenuItem> menuItemList = OrderSaveDBUtil.getMenuByUniqList(sqlParam);
                        OrderSaveDBUtil.updateMenuHurryTimes(menuItemList, false);
                        updateDBResult = DishesUtil.hurryDish(sqlParam);

                        // KDS 服务
                        if (DBOrderConfig.useKdsService()) {
                            if(!ListUtil.isEmpty(uniqList)){
                                KdsManager.getInstance().hurry(orderId, uniqList, head.hd, userDBModel);
                            }
                        }else{
                            PrintOrderUtil.printBatchRush(menuItemList, orderCache, userDBModel.fsUserName, head.hd, new SyncCallback<List<Integer>>() {
                                @Override
                                public void callback(List<Integer> printNoList) {
                                    LogUtil.log("催菜小票待副站点打印数据：：" + JSON.toJSONString(printNoList));
                                    response.printNoList = printNoList;
                                }
                            });
                        }
                    }
                    break;
                }
                case MenuItemOperateAction.ACTION_DO_DISHES: { //起菜
                    String sqlParam = getUniqParamInSql(uniqList);
                    if (TextUtils.isEmpty(sqlParam)) {
                        updateDBResult = false;
                    } else {
                        List<MenuItem> menuItemList = new ArrayList<>();
                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (menuItem == null) {
                                continue;
                            }
                            if (uniqList.contains(menuItem.menuBiz.uniq)) {
                                menuItem.waitOrCall(3);//已点单菜品状态改为起菜状态
                                menuItemList.add(menuItem);
                            }
                        }
                        // 2018/12/8 这里通过uniq从数据库中查询的菜品仍为等叫状态, 下面OrderSaveDBUtil#updateMenuMakeState无效
//                        List<MenuItem> menuItemList = OrderSaveDBUtil.getMenuByUniqList(sqlParam);
                        OrderSaveDBUtil.updateMenuMakeState(menuItemList, false);
                        updateDBResult = DishesUtil.doDishes(sqlParam);

                        // KDS服务下不需打印小票
                        if(DBOrderConfig.useKdsService()){
                            if (!ListUtil.isEmpty(uniqList)) {
                                KdsManager.getInstance().serving(uniqList, head.hd, userDBModel);
                            }
                        }else{
                            //打印起菜单
                            PrintOrderUtil.printBatchWakeUp(orderCache, menuItemList, userDBModel, head.hd, new SyncCallback<List<Integer>>() {
                                @Override
                                public void callback(List<Integer> printNoList) {
                                    LogUtil.log("起菜小票待副站点打印数据：" + JSON.toJSONString(printNoList));
                                    response.printNoList = printNoList;
                                }
                            });
                        }
                    }
                    break;
                }
                case MenuItemOperateAction.ACTION_CHANGE_PRICE: {   //改价格
                    updateDBResult = doUpdateDishPrice(orderId, request.getBigDecimal("changePrice"), orderCache, uniqList.get(0));
                    if (!orderCache.dinnerModel() && updateDBResult && !ListUtil.isEmpty(orderCache.originMenuList)) {
                        response.menuItem = DishesUtil.findMenuItemBySeq(uniqList.get(0), orderCache.originMenuList);
                    }
                    break;
                }
                case MenuItemOperateAction.ACTION_PADDLE: {
                    String sqlParam = getUniqParamInSql(uniqList);
                    int menuProgress = 0;
                    if (TextUtils.isEmpty(sqlParam)) {
                        updateDBResult = false;
                    } else {
                        for (MenuItem menuItem : orderCache.originMenuList) {
                            if (menuItem == null) {
                                continue;
                            }
                            if (uniqList.contains(menuItem.menuBiz.uniq)) {
                                menuItem.menuBiz.fiMenuProgress = menuItem.menuBiz.fiMenuProgress == 0 ? 1 : 0;
                                menuProgress = menuItem.menuBiz.fiMenuProgress;
                            }
                        }
                        List<MenuItem> menuItemList = OrderSaveDBUtil.getMenuByUniqList(sqlParam);
                        OrderSaveDBUtil.updateMenuProgress(orderCache.orderID, orderCache.businessDate, menuItemList, menuProgress, false);
                        OrderSaveDBUtil.replacePaddleData(orderCache, menuItemList, userDBModel, menuProgress, head.hd);
                        updateDBResult = true;
                    }
                    break;
                }
                default:
                    throw new IllegalArgumentException("not support action value:" + operateType);
            }
            if (updateDBResult) {
                if (!orderCache.dinnerModel()) {
                    response.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                }
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "同步成功";
                NotifyToClient.orderChange(orderId);
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 处理修改时价菜操作
     *
     * @param orderCache
     * @param uniq
     * @return
     */
    public static boolean doUpdateDishPrice(String orderId, BigDecimal changePrice, OrderCache orderCache, String uniq) {
        if (!TextUtils.isEmpty(uniq) && orderCache != null && !ListUtil.isEmpty(orderCache.originMenuList)) {
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (TextUtils.equals(menuItem.menuBiz.uniq, uniq)) {
                    menuItem.changeTimesPrice(changePrice);//修改时价菜 后进行计算总价格
                    menuItem.calcTotal(orderCache.isMember);
                    orderCache.plusAllMenuAmount();
                    OrderSession.getInstance().writeOrder(orderId, true, "doUpdateDishPrice");
//                    OrderProcessor.saveOrder(orderCache, null);//更新相关数据库数据
                    break;
                }
            }
            return true;
        }
        return false;
    }


    /**
     * 修改称重菜重量
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/updateBuyNum")
    public static SocketResponse updateBuyNum(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        final UpdateBuyNumResponse responseData = new UpdateBuyNumResponse();
        socketResponse.data = responseData;
        try {
            JSONObject request = JSONObject.parseObject(param);
            String uniq = request.getString("uniq");
            String fsSellNo = request.getString("fsSellNo");
            BigDecimal buyNum = request.getBigDecimal("buyNum");
            if (!ServerCache.getInstance().verifyToken(fsSellNo, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }
            if (buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "菜品数量不得小于零";
                return socketResponse;
            }

            if (TextUtils.isEmpty(uniq)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请选择菜品";
                return socketResponse;
            }

            final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在";
                return socketResponse;
            }

            if (orderCache.orderStatus == OrderStatus.PAIED) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已完成结账";
                return socketResponse;
            }

            if (ListUtil.isEmpty(orderCache.originMenuList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单无已下单菜品";
                return socketResponse;
            }

            MenuItem menuItem = DishesUtil.findMenuItemBySeq(uniq, orderCache.originMenuList);

            if (menuItem == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有找到该菜品";
                return socketResponse;
            }
            menuItem.menuBiz.buyNum = buyNum;
            if (menuItem.isGift()) {
                menuItem.menuBiz.giftNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
            }
            List<MenuItem> indentfyList = new ArrayList<>();
            indentfyList.addAll(menuItem.menuBiz.selectedModifier);

            if (menuItem.supportWeight() && !ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) { //如果是修改称重菜重量则不校验配料数量
                menuItem.menuBiz.selectedModifier.clear();
            }
            List<MenuItem> itemList = new ArrayList<>();
            itemList.add(menuItem);
            SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(itemList);
            if (!result.success) {
                //还原数据
                List<MenuItem> list = OrderSaveDBUtil.getOrderMenuList(orderCache.orderID);
                if (!ListUtil.isEmpty(list)) {
                    orderCache.originMenuList = list;
                    orderCache.reCalcAllByAll();
                }
                socketResponse.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                socketResponse.message = result.errorMsg;
                return socketResponse;
            }
            menuItem.menuBiz.selectedModifier.addAll(indentfyList);
            menuItem.calcTotal(menuItem.useMemberPrice);

            responseData.needRefreshSellOutNum = result.needRefreshSellOutNum;
            if (result.needRefreshSellOutNum) {
                responseData.unitSellOutNew = result.unitSellOutNew;
            }

            orderCache.plusAllMenuAmount();

//            OrderProcessor.saveOrder(orderCache, null);
            OrderSession.getInstance().writeOrder(fsSellNo, true, "updateBuyNum");
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "更新成功";
            NotifyToClient.orderChange(fsSellNo);

            if (DBOrderConfig.useKdsService()) {
                KdsManager.getInstance().weigh(fsSellNo, uniq, head.hd, HostUtil.getUserModelBySession(head.us));
            }

            if (!orderCache.dinnerModel()) {
                responseData.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                responseData.menuItem = menuItem;
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }


    /**
     * 处理起菜操作
     *
     * @param uniqList
     * @return
     * @throws Exception
     */
    private static boolean doDishes(List<String> uniqList) throws Exception {
        String sqlParam = getUniqParamInSql(uniqList);
        if (TextUtils.isEmpty(sqlParam)) {
            return false;
        }

        List<MenuItem> menuItemList = OrderSaveDBUtil.getMenuByUniqList(sqlParam);
        for (MenuItem item : menuItemList) {
            item.waitOrCall(3);//已点单菜品状态改为起菜状态
        }
        OrderSaveDBUtil.updateMenuMakeState(menuItemList, false);

        return DishesUtil.doDishes(sqlParam);
    }

    /**
     * 处理催菜操作
     *
     * @param uniqList
     * @return
     */
    private static boolean doHurryDish(List<String> uniqList) {

        String sqlParam = getUniqParamInSql(uniqList);
        if (TextUtils.isEmpty(sqlParam)) {
            return false;
        }

        List<MenuItem> menuItemList = OrderSaveDBUtil.getMenuByUniqList(sqlParam);
        for (MenuItem item : menuItemList) {
            item.doHurry();
        }
        OrderSaveDBUtil.updateMenuHurryTimes(menuItemList, false);
        return DishesUtil.hurryDish(sqlParam);
    }

    /**
     * 将List中的菜品uniq组成SQL语句中的参数
     *
     * @param uniqList
     * @return "'a', 'b', 'c', ..."
     */
    private static String getUniqParamInSql(List<String> uniqList) {
        if (ListUtil.listIsEmpty(uniqList)) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < uniqList.size(); i++) {
            stringBuilder.append("'").append(uniqList.get(i)).append("'");
            if (i < uniqList.size() - 1) {
                stringBuilder.append(", ");
            }
        }
        return stringBuilder.toString();
    }


    /**
     * 修改配料菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/changeIngredient")
    public static SocketResponse changeIngredient(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            String orderId = request.getString("orderId");
            MenuItem newItem = JSONObject.parseObject(request.getString("newItem"), MenuItem.class);
            ArrayList<MenuItem> addedMenuItem = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("addedMenuItem"), MenuItem.class);
            ArrayList<MenuItem> deletedMenuItem = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("deletedMenuItem"), MenuItem.class);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }
            if (TextUtils.isEmpty(head.hd)) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = "站点id不能为空";
                return socketResponse;
            }

            if (newItem == null) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = "更改后菜品不能为空";
                return socketResponse;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单不存在";
                return socketResponse;
            }

            MenuItem old = null;//找到改之前菜品信息
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (TextUtils.equals(menuItem.menuBiz.uniq, newItem.menuBiz.uniq)) {
                    old = menuItem;
                    break;
                }
            }

            boolean isKdschangeDishIngredient = false;
            if (DBOrderConfig.useKdsService() && KdsManager.getInstance().inKdsSys(newItem.menuBiz.uniq)) {
                String newMenuName = KDSUtils.buildAMenuName(newItem);
                LogUtil.log("KDS#DishesDriver#changeIngredient 修改配料菜前菜名[" + KDSUtils.buildAMenuName(old) + "]");
                LogUtil.log("KDS#DishesDriver#changeIngredient 修改配料菜后菜名[" + newMenuName + "]");
//                 判断KDS中菜品状态
                if (!KdsManager.getInstance().changeDishIngredient(newItem.menuBiz.uniq, newMenuName)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "菜品已进入KDS制作中，不支持菜品编辑";
                    return socketResponse;
                } else {
                    isKdschangeDishIngredient = true;
                    LogUtil.log("KDS#DishesDriver#changeIngredient 进入KDS修改配料菜[" + newItem.menuBiz.uniq + "]");
                }
            }

            //设置退菜信息
            DishesUtil.changeMenuItemIngredient(user, orderCache.isMember, old, addedMenuItem, deletedMenuItem);
            //重新计算价格
            old.calcTotal(orderCache.isMember);
            orderCache.plusAllMenuAmount();
            OrderSession.getInstance().writeOrder(orderId, true, "changeIngredient");
//            OrderProcessor.saveOrder(orderCache, null);
            final ChangeIngredientResponse changeIngredientResponse = new ChangeIngredientResponse();
            changeIngredientResponse.newItem = old;
            if (!orderCache.dinnerModel()) {
                changeIngredientResponse.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
            } else {
                changeIngredientResponse.orderCache = orderCache;
            }
            List<Integer> printNoList = null;

            if (!isKdschangeDishIngredient) {
                // 打印退、加配料小票
                if (deletedMenuItem.size() > 0) {
                    printNoList = PrintOrderUtil.printVoidIngredient(orderCache, old, deletedMenuItem, user.fsUserName, head.hd);
                    if (!ListUtil.isEmpty(printNoList)) {
                        changeIngredientResponse.printTaskIds.addAll(printNoList);
                    }
                }

                if (addedMenuItem.size() > 0) {
                    printNoList = PrintOrderUtil.printAddIngredient(orderCache, old, addedMenuItem, user.fsUserName, head.hd);
                    if (!ListUtil.isEmpty(printNoList)) {
                        changeIngredientResponse.printTaskIds.addAll(printNoList);
                    }
                }
            }

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = changeIngredientResponse;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "";
        }
        return socketResponse;
    }

    /**
     * 修改套餐子项
     */
    @DrivenMethod(uri = "dishes/changePackageItems")
    public static SocketResponse changePackageItems(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            String orderId = request.getString("orderId");
            MenuItem newItem = JSONObject.parseObject(request.getString("newItem"), MenuItem.class);
            ArrayList<MenuItem> addedMenuItem = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("addedMenuItem"), MenuItem.class);
            ArrayList<MenuItem> deletedMenuItem = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("deletedMenuItem"), MenuItem.class);
            ArrayList<MenuItem> updatedMenuItem = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("updatedMenuItem"), MenuItem.class);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }
            if (TextUtils.isEmpty(head.hd)) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = "站点id不能为空";
                return socketResponse;
            }
            if (newItem == null) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = "更改后菜品不能为空";
                return socketResponse;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单不存在";
                return socketResponse;
            }
            MenuItem old = null;//找到改之前菜品信息
            for (MenuItem menuItem : orderCache.originMenuList) {
                if (TextUtils.equals(menuItem.menuBiz.uniq, newItem.menuBiz.uniq)) {
                    old = menuItem;
                    break;
                }
            }
            //设置退菜信息
            DishesUtil.changeMenuItemPackageItems(user, orderCache.isMember, old, addedMenuItem, deletedMenuItem, updatedMenuItem, head.hd);
            //重新计算价格
            old.calcTotal(orderCache.isMember);
            orderCache.plusAllMenuAmount();
            OrderSession.getInstance().writeOrder(orderId, true, "changePackageItems");
//            OrderProcessor.saveOrder(orderCache, null);
            final ChangePackageItemsResponse response = new ChangePackageItemsResponse();
            response.newItem = old;
            if (!orderCache.dinnerModel()) {
                response.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
            } else {
                response.orderCache = orderCache;
            }
            List<Integer> printNoList = null;

            //if (orderCache.orderStatus != OrderStatus.ANTI_PAIED)
            // 打印退、加套餐子项小票，只更新要求或做法不出小票
            if (deletedMenuItem.size() > 0) {
                printNoList = PrintOrderUtil.printVoidPackageItems(orderCache, old, deletedMenuItem, user.fsUserName, head.hd);
                if (!ListUtil.isEmpty(printNoList)) {
                    response.printTaskIds.addAll(printNoList);
                }
            }

            if (addedMenuItem.size() > 0) {
                printNoList = PrintOrderUtil.printAddPackageItems(orderCache, old, addedMenuItem, user.fsUserName, head.hd);
                if (!ListUtil.isEmpty(printNoList)) {
                    response.printTaskIds.addAll(printNoList);
                }
            }

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "";
        }
        return socketResponse;
    }

    /**
     * 获取要求
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/optNoteList")
    public static SocketResponse optNoteList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            String fiItemCd = request.getString("fiItemCd");
            String fsMenuClsId = request.getString("fsMenuClsId");

            NoteListResponse noteListResponse = new NoteListResponse();
            noteListResponse.noteModels = NoteDBUtil.getRequestByMenuItem(fiItemCd, fsMenuClsId, head.shopid);

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = noteListResponse;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "";
        }
        return socketResponse;
    }


    /**
     * 划菜
     *
     * @param head
     * @param param
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @DrivenMethod(uri = "dishes/delimit")
    public static SocketResponse delimit(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            String orderId = request.getString("orderId");
            ArrayMap<String, BigDecimal> menuWithCount = JSONObject.parseObject(request.getString("menuWithCount"), new TypeReference<ArrayMap<String, BigDecimal>>() {
            });

            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            if (menuWithCount == null || menuWithCount.size() <= 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "菜品异常，请稍后重试";
                return socketResponse;
            }

            if (DBOrderConfig.useKdsService()) {
                String err = KdsManager.getInstance().inKdsSys(new ArrayList<>(menuWithCount.keySet()));
                if (!TextUtils.isEmpty(err)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "菜品[" + err + "]进入KDS，不支持站点划菜";
                    return socketResponse;
                }
            }

            String hostId = head.hd;
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

            String uniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "划菜锁桌");
            try {
                if (orderCache.orderStatus == OrderStatus.PAIED || orderCache.orderStatus == OrderStatus.ANTI_BACK || orderCache.orderStatus == OrderStatus.CANCEL) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.msg(R.string.ser_pay_order_processed);
                    return socketResponse;
                }

                ArrayMap<String, BigDecimal> dishDelimit = new ArrayMap<>();

                if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                    for (MenuItem menuItem : orderCache.originMenuList) {
                        if (menuItem == null) {
                            continue;
                        }
                        if (!menuWithCount.containsKey(menuItem.menuBiz.uniq)) {
                            continue;
                        }

                        // 原始划菜数量
                        BigDecimal origin = menuItem.menuBiz.delimitNum;
                        // 此次划菜数量
                        BigDecimal current = menuWithCount.get(menuItem.menuBiz.uniq);
                        // 计算此次划菜差量
                        BigDecimal differ = current.subtract(origin);

                        dishDelimit.put(menuItem.menuBiz.uniq, differ);

                        // 修改菜品菜品
                        menuItem.menuBiz.delimitNum = current;
                        menuItem.menuBiz.fiMenuProgress = current.compareTo(BigDecimal.ZERO) > 0 ? 1 : 0;
                    }

                    OrderSaveDBUtil.replacePaddleData(head.hd, user, orderCache, dishDelimit);
                    OrderSession.getInstance().writeOrder(orderCache.orderID, false, "delimit");
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(uniq, orderCache.fsmtableid, orderCache.orderID, "划菜解锁");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 获取临时菜属性
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "dishes/loadMenuTempporaryModel")
    public static SocketResponse loadMenuTempporaryModel(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            String fiItemCd = request.getString("fiItemCd");
            MenuTemporaryResponse menuTemporaryResponse = new MenuTemporaryResponse();
            menuTemporaryResponse.menuTemporaryModel = MenuDBUtil.queryMenuTemporaryList(fiItemCd);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = menuTemporaryResponse;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = e.getMessage();
        }
        return socketResponse;
    }

    /**
     * 根据选中的菜品列表获取要求的并集
     */
    @DrivenMethod(uri = "dishes/optNoteListByMenuList")
    public static SocketResponse optNoteListByMenuList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }
            List<MenuItem> menuItemList = JSONArray.parseArray(request.getString("menuList"), MenuItem.class);
            NoteListResponse noteListResponse = new NoteListResponse();
            noteListResponse.noteModels = NoteDBUtil.optNoteListByMenuList(menuItemList, head.shopid);

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = noteListResponse;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "";
        }
        return socketResponse;
    }
}
