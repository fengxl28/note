package com.mwee.android.pos.businesscenter.business.washdata;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 洗数据类型
 */
@Retention(RetentionPolicy.SOURCE)
public @interface WashDataType {

    /**
     * 同步数据之前
     */
    String BEFORE_SYNC = "0";

    /**
     * 同步数据之后
     */
    String AFTER_SYNC = "1";

}
