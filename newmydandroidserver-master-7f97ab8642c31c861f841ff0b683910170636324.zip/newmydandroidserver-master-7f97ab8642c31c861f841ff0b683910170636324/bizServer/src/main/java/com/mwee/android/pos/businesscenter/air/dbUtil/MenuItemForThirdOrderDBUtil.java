package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by liuxiuxiu on 2018/6/12.
 * 菜品Util---->第三方订单入报表映射到本地菜品
 */

public class MenuItemForThirdOrderDBUtil {

    public static final String MENU_CLS_NAME = "外卖分类";
    public static final String MENU_ITEM_NAME = "【外卖未映射菜】";
    //销售分类
    public static final String EXP_CLS_NAME = "外卖未映射";
    //收入分类
    public static final String REVENUE_TYPE_NAME = "外卖未映射";

    public static MenuitemDBModel getTemporaryMenuDBModel() {
        String sql = "select * from tbmenuitem where  fiStatus<>'13' and fiIsTemporaryMenu='1' and fsItemName = '" + MENU_ITEM_NAME + "' limit 1";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuitemDBModel.class);
    }

    /**
     * 添加一个临时菜
     * 仅仅用于网络订单菜品入报表
     *
     * @param shopId
     * @return fiItemCd
     * <p>
     * 1）新建：若商家有外卖菜品无映射关系，则自动添加；
     * 2）分类：
     * a）在现有分类排序里，顺序号最大；
     * b）分类级别：全部分类;
     * c）分类名称：外卖分类
     * d）分类类型：菜品
     * e）销售归属：外卖未映射；
     * f）收入归属：外卖未映射；
     * 3）菜品：
     * a）菜品编码：
     * b）菜品名称：【外卖未映射菜】；
     * c）菜品分类：外卖分类；
     * d）销售归属：外卖未映射；
     * e）收入归属：外卖未映射；
     * f）菜品选项：可折扣、可外卖；
     * g）菜品价格：价格：1元，会员价：1元。
     * 4）状态：禁用，即在客户端点菜页面不显示。
     * 5）若该菜品被删除，则再有外卖菜品未映射时，系统再自动加一个“系统临时菜（外卖映射）”。
     */
    public static String addTempMenu2NetOrderMapping(String shopId, UserDBModel userDBModel) {

        //菜品销售分类ID
        String fsExpClsId = optExpClsId(shopId, userDBModel);

        //菜品收入分类ID
        String fsRevenueTypeId = optRevenueTypeId(shopId, userDBModel);

        //菜品分类ID
        String fsMenuClsId = optTempMenuClsId(shopId, userDBModel, fsExpClsId, fsRevenueTypeId);

        MenuItemEditorBody body = new MenuItemEditorBody();
        body.menuClsId = fsMenuClsId;
        body.name = MENU_ITEM_NAME;
        body.unitName = "份";
        body.price = "1";
        body.memberPrice = "1";
        body.repertoryNumber = "";
        body.isCanDiscount = true;
        body.isCanGift = false;
        body.isCanTimePrice = false;
        body.isCanWeight = false;
        body.isCanOutTake = false;
        body.isCanPrinter = false;
        body.isCanPreOrder = false;
        body.fiIsTemporaryMenu = 1;
        body.fiStatus = 9;
        body.fsExpClsId = fsExpClsId;
        body.fsRevenueTypeId = fsRevenueTypeId;
        body.fsUserId = userDBModel.fsUserId;
        body.fsUserName = userDBModel.fsUserName;

        return MenuItemDBUtils.addMenuItem(body, shopId);

    }

    /**
     * 获取菜品销售分类ID
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String optExpClsId(String shopId, UserDBModel userDBModel) {
        String fsExpClsId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsExpClsId from tbexpcls where fsExpClsName = '" + EXP_CLS_NAME + "'");
        if (TextUtils.isEmpty(fsExpClsId)) {
            fsExpClsId = addExpCls(shopId, userDBModel);
        }
        return fsExpClsId;
    }

    /**
     * 插入菜品销售分类
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String addExpCls(String shopId, UserDBModel userDBModel) {
        String id = IDHelper.generateExpClsId();
        ExpClsDBUitl.insert(id, EXP_CLS_NAME, 9, shopId, userDBModel);
        MetaDBController.updateSyncTime();
        return id;
    }


    /**
     * 获取菜品收入分类ID
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String optRevenueTypeId(String shopId, UserDBModel userDBModel) {
        String fsRevenueTypeId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsRevenueTypeId from tbrevenuetype where fsRevenueTypeName = '" + REVENUE_TYPE_NAME + "'");
        if (TextUtils.isEmpty(fsRevenueTypeId)) {
            fsRevenueTypeId = addRevenueType(shopId, userDBModel);
        }
        return fsRevenueTypeId;
    }

    /**
     * 插入菜品收入分类
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String addRevenueType(String shopId, UserDBModel userDBModel) {
        String id = IDHelper.generateRevenueTypeId();
        RevenueTypeDBUtil.insert(id, REVENUE_TYPE_NAME, 9, shopId, userDBModel);
        MetaDBController.updateSyncTime();
        return id;
    }


    /**
     * 获取菜品分类ID
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String optTempMenuClsId(String shopId, UserDBModel userDBModel, String fsExpClsId, String fsRevenueTypeId) {

        String fsMenuClsId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMenuClsId from tbMenuCls where fsMenuClsName = '外卖分类'");
        if (TextUtils.isEmpty(fsMenuClsId)) {
            fsMenuClsId = addTempMenuCls2NetOrderMapping(shopId, userDBModel, fsExpClsId, fsRevenueTypeId);
        }
        return fsMenuClsId;
    }

    /**
     * 插入菜品分类   状态为已删除
     *
     * @param shopId
     * @param userDBModel
     * @return
     */
    public static String addTempMenuCls2NetOrderMapping(String shopId, UserDBModel userDBModel, String fsExpClsId, String fsRevenueTypeId) {
        String id = IDHelper.generateMenuClsId();
        MenuClsDBUtils.insert(id, MENU_CLS_NAME, 1, 9, shopId, userDBModel, fsExpClsId, fsRevenueTypeId);
        MetaDBController.updateSyncTime();
        return id;
    }


}
