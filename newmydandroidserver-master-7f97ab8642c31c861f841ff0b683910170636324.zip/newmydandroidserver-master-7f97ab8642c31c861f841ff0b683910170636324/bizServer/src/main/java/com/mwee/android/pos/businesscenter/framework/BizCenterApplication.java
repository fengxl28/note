package com.mwee.android.pos.businesscenter.framework;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Looper;
import android.text.TextUtils;

import com.mwee.android.air.util.ApkUtils;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.alp.AlpLog;
import com.mwee.android.alp.PushServer;
import com.mwee.android.base.AppEnv;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.NetConfig;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.Interceptor;
import com.mwee.android.base.net.component.NetResultType;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.DrivenBusManager;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.exception.DrivenException;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.base.Environment;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.koubei.KBMakePrinter;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.localpush.PushServerReceiver;
import com.mwee.android.pos.businesscenter.business.moniter.KeepAliveUtil;
import com.mwee.android.pos.businesscenter.business.moniter.KoubeiKeepAliveUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.AutoDeliveryUtil;
import com.mwee.android.pos.businesscenter.business.notice.NoticeProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidLoop;
import com.mwee.android.pos.businesscenter.business.shareshop.api.ShareShopApi;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.driver.UdpPushDriver;
import com.mwee.android.pos.businesscenter.koubei.sync.KBOrderSyncManager;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.DeliveryApi;
import com.mwee.android.pos.businesscenter.socket.SocketServer;
import com.mwee.android.pos.component.log.BizLog;
import com.mwee.android.pos.component.push.XMPPPushManager;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.component.udp.UDPReceiverServer;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.common.OrderData;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.common.OrderWatcher;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.ProcessUtil;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.android.tools.timesync.TimeSyncUtil;
import com.mwee.myd.server.DBInit;
import com.mwee.myd.server.LocalDataManager;
import com.mwee.myd.server.ServerLog;
import com.mwee.myd.server.business.config.ConfigProcess;
import com.mwee.myd.server.business.login.LoginConstant;
import com.mwee.myd.server.util.ServerHardwareUtil;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.BuglyStrategy;
import com.tencent.bugly.crashreport.CrashReport;

import org.json.JSONObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import cn.mwee.android.pay.other.util.DeviceStateInfoUtil;

/**
 * 业务中心的Application
 * Created by virgil on 16/8/26.
 *
 * @author virgil
 */
public class BizCenterApplication {

    public static boolean inited = false;
    private static Object serverInterface;

    private static void prepareVersionCode(Context context) {
        PackageManager pm = context.getPackageManager();
        PackageInfo info = pm.getPackageArchiveInfo(context.getPackageCodePath(), 0);
        if (info != null) {
            BizConstant.VERSION_CODE = info.versionCode;
            BizConstant.VERSION_NAME = info.versionName;
        }
    }

    public static void destroy() {
        serverInterface = null;
    }

    public static void update() {
        invoke("abcdefg");
    }

    public static void forceLoadNewPlugin() {
        invoke("abcdefg");
    }

    public static Object invoke(String method, Object... param) {
        try {
            if (serverInterface != null) {
                Method[] methods = serverInterface.getClass().getMethods();
                if (methods != null && methods.length > 0) {
                    Method[] var5 = methods;
                    int var6 = methods.length;

                    for (int var7 = 0; var7 < var6; ++var7) {
                        Method temp = var5[var7];
                        if (temp.getName().equals(method) && temp.getParameterTypes().length == param.length) {
                            temp.setAccessible(true);
                            return temp.invoke(serverInterface, param);
                        }
                    }
                }
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void initEnv(Context context, Object serverInterface, AppEnv env) {
        APPConfig.PUSH_PORT = env.alpPort;
        prepareVersionCode(context);
        BaseConfig.ENV = env.env;
        GlobalCache.getInstance().registerContext(context);

        //环境设置库的初始化

        GlobalCache.getInstance().setLogOpen(BaseConfig.ENV != Environment.PRODUCT);
        LogUtil.setWriteLog(true);
        LogUpload.setTest(!BaseConfig.isProduct());
        DriverBus.setErrorWithException(false);
        AlpLog.setRelease(BaseConfig.isProduct());
        //时间同步
        new TimeSyncUtil().syncTime();
        //Bugly初始化
        initBugly(context);

        SocketConfig.API_VERSION = 103;
        SocketConfig.PORT_LIST = env.socketPorts;
        SocketConfig.PORT = env.socketPorts[0];

        //初始化DB,重要,需要放在业务初始化之前
        DBInit.initDB(context);
        DBInit.initClientDBConnection(context);
        DBInit.initOtherDB(GlobalCache.getContext());

        if (!TextUtils.isEmpty(env.hardwareSymbol)) {
            ServerHardwareUtil.updateHardwareSymbol(env.hardwareSymbol);
        }
        initDevConfig();

        ServerLog.initConfig(context);

        PrintConnector.getInstance().init(context);

        // 备份库的升级需要对接动态升级数据库。这里先注释掉，待数据库配置升级部分完成，放开。
//        ReplicationProcessor.getInstance().start();

        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_VERSION_CODE, env.versionCode);
        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_VERSION_NAME, env.versionName);

        APPConfig.refreshChunkLen();
    }

    public static void init(final Context context) {
        if (ProcessUtil.getCurrentProcessName(context).endsWith(":bizcenter")) {
            LogUtil.log("业务中心启动");
            try {
                DrivenBusManager.getInstance().init(context.getResources().getStringArray(R.array.bizcenter_drive_path));
            } catch (DrivenException e) {
                e.printStackTrace();
            }
            if (Looper.getMainLooper() == Looper.myLooper()) {
                LogUtil.log("业务中心工作在主线程");
            }
            //注册订单数据变化观察者
            OrderProcessor.addOrderWatcher(new OrderWatcher() {
                @Override
                public void onOrderChanged(String orderId) {
                    OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                    //口碑模式，正餐订单进行回流
                    if (orderCache != null && orderCache.isShouldSyncToKB()) {
                        //异步的任务
                        if (APPConfig.isMydKouBei() || APPConfig.isAirKouBei()) {
                            KBOrderSyncManager.getInstance().add(orderId);
                        }
                    }
                }
            });
            //初始化UDP监听
            UDPReceiverServer.getInstance().start();
            //初始化业务中心服务端
            SocketServer.getInstance().checkInit();

            checkInit();

            inited = true;
            //初始化ServerCache
            ServerCache.getInstance().init();

            //初始化ALP推送服务器
            PushServer.getInstance().startServer(APPConfig.PUSH_PORT, PushServerReceiver.getInstance());


            PrintConnector.getInstance().init(context);

            initDevConfig();
            //初始化XMPP的服务器
            if (BaseConfig.isProduct()) {
                XMPPPushManager.setPushAddress(XMPPPushManager.XMPP_URL_PRODUCT);
            }
            BizInfoCollect.initInfoCollect();

            //以下任务延时10秒处理
            GlobalLooper.postDelayed(() -> {

                //启动XMPP服务
                XMPPPushManager.startPushService();
                if (APPConfig.isMyd()) {
                    //美易点正餐，美小二服务端
                    DriverBus.call("waiterEntry/init");
                    // 启动排队服务
                    DriverBus.call("queueEntry/init");
                }

                //初始化秒点轮询服务
                RapidLoop.initRapidPayLoop();

                //初始化保活
                KeepAliveUtil.initKeepAliveLoop();

                //初始化自动配送
                AutoDeliveryUtil.initAutoDeliveryLoop();

                if (APPConfig.isAirKouBei() || APPConfig.isMydKouBei()) {
                    KBMakePrinter.init();
                    //口碑心跳apk没有安装，则使用http请求接口方式进行心跳
                    if (!ApkUtils.isAppInstalled(context, KBConstants.KB_PACKAGE_NAME)) {
                        KoubeiKeepAliveUtil.initKBKeepAliveLoop();
                    }
                }


                //初始化本地轮询任务
                JobScheudler.init();

            }, 10 * 1000);
            ShareShopApi.loadSnIsKBInfo();
            //以下任务延时20秒处理
            String booTime = DateUtil.getCurrentTime();
            GlobalLooper.postDelayed(() -> {


                //初始化网络订单和中控的轮询任务
                String key = "11111";
                //网络订单轮询
                String taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.NETORDER_REFRESH + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.NETORDER_REFRESH, key, 2);
                } else {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set cycle='2' where type = '" + JobType.NETORDER_REFRESH + "'");
                }
                //中控轮询
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.LOGINPD + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.LOGINPD, "1", "");
                }
                //XMPP上报
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.XMPP_STATE + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.XMPP_STATE, "1", "");
                }
                //获取支付前缀
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.QUERY_PAY_BARCODE_PREFIX + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.QUERY_PAY_BARCODE_PREFIX, "1", 3);
                }

                // 检测自然日报表的 Job
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.CHECK_REPORT_NATURE_JOB + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.CHECK_REPORT_NATURE_JOB, "1", 3);
                }

                //获取支付开通状态
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.QUERY_SHOP_PAY_STATUS + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.QUERY_SHOP_PAY_STATUS, "1", 3);
                }

                //获取会员配置
                taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select taskid from unfinish_task where  type = '" + JobType.QUERY_MEMBER_CONFIG + "' limit 1");
                if (TextUtils.isEmpty(taskid)) {
                    JobScheudler.newJob(JobType.QUERY_MEMBER_CONFIG, "1", 3);
                }

                //查询AB账上传状态
                JobScheudler.deleteJobByType(JobType.BILL_STATUS_SYNC);
                Job job = new Job();
                job.type = JobType.BILL_STATUS_SYNC;
                job.typeLoop = 0;
                job.driver_uri = "billDriver/syncBillUploadState";
                job.cycle = 2;
                JobScheudler.newJob(job);

                //获取公告
                NoticeProcessor.prepareGetNotice();

                //登录中控
                DriverBus.call("xmpp/dologin");


                //手动上送日志
                MwLog.manualCallUploadLog();

                ConfigProcess.getInstance().checkInit();
                //查询网络订单配送配置
                DeliveryApi.optDeliveryStatusForLoop();
                if (!APPConfig.isCasiher()) {
                    DriverBus.call("waiter/checkAlive");
                }
                BizLog.addLog(booTime, "", "", BizLog.SYS_START_TIME, "启动时间", "");
                if (APPConfig.isCasiher()) {
                    //注册全局性的通讯广播
                    NetConfig.addFinalInterceptor(new Interceptor() {
                        boolean error = false;

                        @Override
                        public void write(JSONObject jsonObject) {

                        }

                        @Override
                        public void receive(ResponseData responseData) {
                            if (responseData.netResult == NetResultType.SUCCESS) {
                                if (responseData.result == 602 || responseData.result == 70103) {
                                    synchronized (this) {
                                        if (!error) {
                                            error = true;
                                            NotifyToClient.broadcast("login/mydTokenExpired");
                                        }
                                    }
                                } else {
                                    synchronized (this) {
                                        error = false;
                                    }
                                }
                            }

                        }
                    });
                }
                LocalDataManager.uploadShopEnv();
            }, 20 * 1000);

        }
    }

    private static void initDevConfig() {
        if (!BaseConfig.isProduct()) {
            //处理xmpp的url
            String urlPush = DBMetaUtil.getSettingsValueByKey(META.DEV_URL_PUSH);
            if (!TextUtils.isEmpty(urlPush)) {
                XMPPPushManager.setPushAddress(urlPush);
            } else {
                if (TextUtils.equals(LoginConstant.getPDUrlRoot(), LoginConstant.URL_ROOT_PRODUCT)) {
                    XMPPPushManager.setPushAddress(XMPPPushManager.XMPP_URL_PRODUCT);
                } else {
                    XMPPPushManager.setPushAddress(XMPPPushManager.XMPP_URL_TEST);
                }
            }

            DriverBus.call("xmpp/devXmppLog");
        }
    }

    public static void checkInit() {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                String shopID = HostUtil.getShopID();
                if (!TextUtils.isEmpty(shopID) && BindProcessor.isCurrentHostMain()) {
                    UdpPushDriver.doBroadCast();
                }

                ShopDBModel shop = DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM tbshop WHERE fiStatus = '1'", ShopDBModel.class);
                if (shop != null) {
                    APPConfig.fiWorkMode = shop.fiWorkMode;
                }
                return null;
            }
        });

    }

    private static void initBugly(Context context) {
        BuglyStrategy strategy = new BuglyStrategy();
        String channel = "";
        try {
            ApplicationInfo info = context.getPackageManager().getApplicationInfo(context.getPackageName(),
                    PackageManager.GET_META_DATA);
            channel = info.metaData.getString("MWEE_POS_CHANNEL");
            strategy.setAppChannel(channel);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        strategy.setUploadProcess(false);
        //Bugly初始化
        String metaiD = BaseConfig.isProduct() ? "0504777205" : "2a05d769e2";
        strategy.setCrashHandleCallback(new CrashReport.CrashHandleCallback() {
            @Override
            public Map<String, String> onCrashHandleStart(int crashType, String errorType,
                                                          String errorMessage, String errorStack) {
                LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
                ParamvalueDBModel paramvalueDBModel = BizInfoCollect.getAccount(APPConfig.DB_MAIN);
                if (paramvalueDBModel != null) {
                    map.put("中控账号", paramvalueDBModel.fsParamValue);
                }
                map.put("站点ID", DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
                map.put("设备序列号", DeviceStateInfoUtil.getDeviceSerial());
                map.put("门店ID", DBMetaUtil.getSettingsValueByKey(META.SHOPID));
                map.put("cpu使用率", DeviceStateInfoUtil.provideTotalCpuPercent());
                return map;
            }

            @Override
            public byte[] onCrashHandleStart2GetExtraDatas(int crashType, String errorType, String errorMessage, String errorStack) {
                return null;
            }

        });
        Bugly.init(context.getApplicationContext(), metaiD, com.mwee.android.tools.LogUtil.SHOW, strategy);
    }

}
