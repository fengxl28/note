package com.mwee.android.pos.businesscenter.business.rapid.processor;

import android.os.SystemClock;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseIntArray;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.api.bean.model.SourceType;
import com.mwee.android.pos.business.rapid.util.RapidUtil;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageAbnormalOrderBizProcessor;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidApi;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.wechatfastfood.WechatFastFoodApi;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.order.discount.CouponCutMoney;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 秒点预付款订单的业务处理类
 * Created by virgil on 2017/7/24.
 */
public class RapidPrePayFastfoodBiz {

    /**
     * 牌号缓存
     */
    public static List<String> mealNumberCache = new ArrayList<>();

    public final static Object mealNumberLock = new Object();

    public final static LinkedHashMap<String, SparseIntArray> busyMealaNumberMap = new LinkedHashMap<>();

    /**
     * 刷新所有已占用牌号集合
     */
    public synchronized static void releanseBusyMealaNumberMap() {
        busyMealaNumberMap.clear();
        String sql = "select distinct mealNumber " +
                "from order_cache left join message " +
                "on order_cache.order_id = message.sellno " +
                "where order_cache.fsBillSourceId = '99' and message.businessStatus in ('0','1','2') and " +
                "order_cache.business_date = '" + HostUtil.getHistoryBusineeDate("") + "' and " +
                "message.msgType = '8' order by order_cache.mealNumber asc";

        List<String> mealNumberList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);

        String lable;
        int number;
        if (!ListUtil.isEmpty(mealNumberList)) {
            for (String str : mealNumberList) {
                number = optNmber(str);
                lable = optLable(str);
                SparseIntArray mealNumberArray = busyMealaNumberMap.get(lable);
                if (mealNumberArray == null) {
                    mealNumberArray = new SparseIntArray();
                    busyMealaNumberMap.put(lable, mealNumberArray);
                }
                mealNumberArray.put(number, number);
            }
        }
    }

    /**
     * 占用牌号
     *
     * @param mealNumber
     */
    public synchronized static void busyMealNumber(String mealNumber) {
        if (TextUtils.isEmpty(mealNumber)) {
            return;
        }
        int number = optNmber(mealNumber);
        String lable = optLable(mealNumber);

        SparseIntArray mealNumberArray = busyMealaNumberMap.get(lable);
        if (mealNumberArray == null) {
            mealNumberArray = new SparseIntArray();
            busyMealaNumberMap.put(lable, mealNumberArray);
        }
        mealNumberArray.put(number, number);
    }

    /**
     * 释放牌号
     *
     * @param mealNumber
     */
    public synchronized static void releaseBusyMealNumber(String mealNumber) {
        if (TextUtils.isEmpty(mealNumber)) {
            return;
        }
        int number = optNmber(mealNumber);
        String lable = optLable(mealNumber);
        LogUtil.log("lxd", "------释放牌号----mealNumber" + mealNumber);
        SparseIntArray mealNumberArray = busyMealaNumberMap.get(lable);
        if (mealNumberArray != null) {
            int index = mealNumberArray.indexOfValue(number);
            if (index >= 0) {
                mealNumberArray.removeAt(index);
            }
        }
    }

    /**
     * 缓存牌号
     *
     * @param mealNumber
     */
    public static void putMealNumber(String mealNumber) {
        synchronized (mealNumberLock) {
            LogUtil.log("lxd", "------缓存牌号----mealNumber" + mealNumber);
            mealNumberCache.add(mealNumber);
        }
    }

    /**
     * 释放牌号
     *
     * @param mealNumber
     */
    public static void removeMealNumber(String mealNumber) {
        synchronized (mealNumberLock) {
            mealNumberCache.remove(mealNumber);
        }
    }


    /**
     * 日切的时候清除缓存
     */
    public static void clearCache() {
        mealNumberCache.clear();
        busyMealaNumberMap.clear();
    }

    private volatile static Map<String, Long> netOrderMsgIdPool = new ArrayMap<>();

    /**
     * 释放订单ID
     *
     * @param msgId
     */
    public static synchronized void releaseNetOrderMsgId(String msgId) {
        netOrderMsgIdPool.remove(msgId);
        LogUtil.logBusiness("释放微信快餐正在处理微信快餐订单号：" + msgId + "");
    }

    /**
     * 检查msgId是否已存在
     *
     * @param msgId
     * @return boolean | true : 已存在； FALSE：不存在
     */
    public static synchronized boolean checkNetOrderMsgId(String msgId) {

        boolean msgIdPushed = netOrderMsgIdPool.get(msgId) != null;

        if (msgIdPushed) {
            msgIdPushed = SystemClock.elapsedRealtime() - netOrderMsgIdPool.get(msgId) < 61 * 1000;
        }
        LogUtil.logBusiness("锁住微信快餐正在处理微信快餐订单号：" + msgId + " " + msgIdPushed);
        netOrderMsgIdPool.put(msgId, SystemClock.elapsedRealtime());
        return msgIdPushed;
    }


    /**
     * 收到秒点快餐的菜品
     *
     * @param data  RapidGetModel
     * @param order RapidOrder
     */
    public static void receivePreFastFoodMenu(RapidActionModel resultData, RapidGetModel data, RapidOrder order) {
        if (order == null) {
            return;
        }
        if (NetOrderType.isRapidPrePay(order.bizType)) {
            TempOrderDishesCache tempDishes = RapidApi.buildTempOrder(resultData, order, data.fsid);
            if (resultData.result == RapidResult.SUCCESS && tempDishes != null) {
                SubmitOrderCheckNumResult checkSellout = SellOutServerProcessor.checkSellOutValue(tempDishes.tempSelectedMenuList, false);
                if (!checkSellout.success) {
                    RapidBiz.buildSellOut(resultData, RapidResult.ERROR_SELL_OUT, checkSellout.errorMsg, checkSellout);
                } else {

                    tempDishes.isMember = order.needBuildMemberPrice();

                    MenuItemVipPriceUtil.useCouponWhenBindMember(HostUtil.getShopID(), tempDishes.tempSelectedMenuList,
                            order.needBuildMemberPrice(),StringUtil.toInt(order.memberLevel),
                            "cash", order.memberId, order.plusId);

                    /*if (order.isVipPrice != -1 && !DBMetaUtil.autoUseMemberPrice() && !DBMetaUtil.autoUseVipDiscount()) {
                        OrderCache.updateAllMenuToMemberPrice(tempDishes.tempSelectedMenuList,
                                order.needBuildMemberPrice(),  StringUtil.toInt
                                (order.memberLevel), "cash", order.memberId, order.plusId);
                    }*/

                    tempDishes.plusTempSelectedMenuAmount();

                    CouponCutMoney cut = OrderCache.checkCouponMoney(OrderUtil.initOrderCutList(HostUtil.getHistoryBusineeDate("")), tempDishes.tempSelectedMenuList, tempDishes.tempTotalPrice, OrderUtil.getSectionId(), false, tempDishes.isDiningStandard());
                    if (cut != null) {
                        tempDishes.tempTotalPrice = tempDishes.tempTotalPrice.subtract(cut.fdCutmoney);
                    }

                    cleanOrder(order.orderId, order.userId);
                    writeFastFoodToIO(order.orderId, order.userId, tempDishes);
                }
            }
        }
    }


    /**
     * 清数据
     *
     * @param orderId
     * @param userId
     * @param userId
     */
    public static void cleanOrder(String orderId, String userId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where biz_key='" + userId + "'");
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where info='" + orderId + "'");
    }


    /**
     * 存储微信快餐单
     *
     * @param orderId
     * @param tempDishes
     */
    private synchronized static void writeFastFoodToIO(String orderId, String userId, TempOrderDishesCache tempDishes) {
        CacheModel cacheModel = new CacheModel();
        cacheModel.key = tempDishes.optFirstThirdOrderID();
        cacheModel.biz_key = userId;
        cacheModel.info = orderId;
        cacheModel.value = JSON.toJSONString(tempDishes);
        cacheModel.type = IOCache.TYPE_RAPID_PRE_FAST_FOOD;
        cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.updatetime = cacheModel.createtime;
        cacheModel.replaceNoTrans();
    }


    /**
     * 收到微信快餐的收款明细
     *
     * @param resultData RapidActionModel
     * @param payment    RapidPayment
     */
    public static void receivePreFastFoodPay(RapidActionModel resultData, final RapidPayment payment) {
        TempOrderDishesCache tempOrder = RapidPrePayBiz.buildPrePayOrderFull(payment.tableNo, payment.userId, payment.orderId, !TextUtils.isEmpty(payment.fsMemberNo),payment.isVipPrice, StringUtil.toInt(payment.memberLevel), payment.memberId, payment.plusId);
        if (!checkNetOrderMsgId(optSingleNo(payment))) {
            receivePreFastFoodPay(resultData, tempOrder, payment);
            releaseNetOrderMsgId(optSingleNo(payment));
        } else {
            LogUtil.logBusiness("收到微信快餐支付信息，但是该订单正在被处理，订单号：" + payment.orderId);
        }
    }

    /**
     * 收到微信快餐的收款明细
     *
     * @param resultData payment         支付信息
     * @param resultData RapidActionModel
     * @param payment    RapidPayment
     */
    public static void receivePreFastFoodPay(RapidActionModel resultData, TempOrderDishesCache tempOrder, final RapidPayment payment) {

        boolean autoOrder = false;
        if (APPConfig.isAir()) {
            autoOrder = TextUtils.equals(DBMetaUtil.getConfig(META.RAPID_FAST_FOOD_AUTO_ORDER, "1"), "1");
        } else {
            autoOrder = TextUtils.equals(DBMetaUtil.getConfig(META.RAPID_FAST_FOOD_AUTO_ORDER, "0"), "1");
        }
        BigDecimal totalPayed = RapidPrePayBiz.parseRapidPayTotalAmt(payment);

        if (tempOrder != null) {
            RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY,
                    "收到预付款 支付金额[" + totalPayed.toPlainString() + "],订单金额[" + tempOrder.tempTotalPrice.toPlainString() + "]",
                    "", (SourceType.isPrePayFastfoodModel(payment.sourceType) ? payment.orderId : payment.tableNo), payment, tempOrder);
        } else {
            RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY,
                    "收到预付款 支付金额[" + totalPayed.toPlainString() + "],但是没有找到对应的本地订单 ",
                    "", (SourceType.isPrePayFastfoodModel(payment.sourceType) ? payment.orderId : payment.tableNo), payment, null);
        }

        if (tempOrder != null && (totalPayed.compareTo(tempOrder.tempTotalPrice) >= 0)) {
            //如果支付金额大于或者等于订单金额---下单
            if (autoOrder || APPConfig.isCasiher()) { //自动接单,美收银默认
                wechatFastFoodAutoModel(resultData, tempOrder, payment);
            } else {
                //新增消息---提醒商户有新订单
                MessageOrderUtil.addUnDealFastFoodMsg(tempOrder, payment);

                wechatFastFoodManualModel(tempOrder, payment);
            }
        } else {
            MessageAbnormalOrderBizProcessor.addRapidPayAbnormalMsg(tempOrder, payment, totalPayed, 1, "", tempOrder == null ? "未查到相关菜品" : "收到预付款 支付金额[" + totalPayed.toPlainString() + "],订单金额[" + tempOrder.tempTotalPrice.toPlainString() + "]");
//            wechatFastfoodVoid(payment.orderId);
//            rejectWechatFastFood(payment.orderId, "", "");
            cleanOrder(payment.orderId, payment.userId);

        }

    }

    /**
     * 获取订单唯一标志
     * -----由于订单可能没有orderId或者用户ID,所以辨别是否是同一订单只能通过"订单的创建时间_订单ID_用户ID_支付金额"来判断是否为同一个订单
     *
     * @param payment
     * @return
     */
    private static String optSingleNo(final RapidPayment payment) {
        BigDecimal amt = RapidUtil.parseRapidPayTotalAmt(payment);
        if (amt == null){
            amt = BigDecimal.ZERO;
        }

        return payment.orderId + "_" + payment.userId + amt.stripTrailingZeros().toPlainString();
    }

    /**
     * 微信快餐自动接单模式
     * 先通知云端商户接单--最多重试三次
     * 接单通知失败---降级为手动接单
     * 接单通知成功---本地订单下单入口
     * 本地下单入库失败---退款、取消订单
     * 本地下单入库成功---清除缓存
     */
    private static void wechatFastFoodAutoModel(final RapidActionModel resultData, final TempOrderDishesCache tempOrder, final RapidPayment payment) {
        if (tempOrder == null || payment == null) {
            return;
        }
        final String fsSellNo = OrderDriver.generateNewOrderID();
        final String mealNumber = getWechatFastFoodMealNumber();

        //tempOrder.optFirstThirdOrderID()
//        if (checkNetOrderMsgId(optSingleNo(payment))) {
//            LogUtil.log(" 自动接单模式 - 微信快餐正在处理微信快餐订单号：" + tempOrder.thirdOrderID);
//            return;
//        }
        WechatFastFoodApi.getOrderRequest(payment.orderId, fsSellNo, mealNumber, 1, new IResponse<String>() {
            @Override
            public void callBack(boolean result, int code, String msg, String info) {
                if (result) {

                    MessageOrderUtil.saveRelation(fsSellNo, payment.orderId);

                    RapidBiz.rapidFastfoodOrder(resultData, tempOrder, mealNumber, fsSellNo);
                    if (resultData.result == RapidResult.SUCCESS) {
                        payment.rapidMenuOrderIdInner = tempOrder.optFirstThirdOrderID();
                        payment.outerOrderId = fsSellNo;
                        RapidApi.submitPay(resultData, payment);
                        if (resultData.result != RapidResult.SUCCESS) {
                            RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_NO, "先付款的秒付落帐失败，需要自动退款[" + resultData.errorInfo + "]", "", payment.tableNo, payment, tempOrder);
                            BigDecimal totalPayed = RapidPrePayBiz.parseRapidPayTotalAmt(payment);
                            MessageAbnormalOrderBizProcessor.addRapidPayAbnormalMsg(tempOrder, payment, totalPayed, 1, "", resultData.errorInfo);
                            /*wechatFastfoodVoid(payment.orderId);
                            rejectWechatFastFood(payment.orderId, fsSellNo, mealNumber);*/
                        } else {
                            UserDBModel user = RapidBiz.getCloudUser();
                            if (user == null) {
                                user = new UserDBModel();
                                user.fsUserName = tempOrder.waiterName;
                                user.fsUserId = tempOrder.waiterID;
                            }
                            BillUtil.startFinalPayProcess(ServerCache.getInstance().generateNewToken(fsSellNo), fsSellNo, user, HostUtil.getCurrentHost(), true, true);
                            NotifyToClient.orderChange(fsSellNo);
                            busyMealNumber(mealNumber);
                            //新增消息---提醒商户有新订单
                            MessageOrderUtil.addUnDealFastFoodMsg(tempOrder, payment);
                            MessageOrderUtil.updateFastFoodMsg(payment.orderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.GET);
                        }
                    } else {
                        BigDecimal totalPayed = RapidPrePayBiz.parseRapidPayTotalAmt(payment);
                        MessageAbnormalOrderBizProcessor.addRapidPayAbnormalMsg(tempOrder, payment, totalPayed, 1, "", resultData.errorInfo);
                        /*wechatFastfoodVoid(payment.orderId);
                        rejectWechatFastFood(payment.orderId, fsSellNo, mealNumber);*/
                    }

                    cleanOrder(payment.orderId, payment.userId);

                } else {
                    resultData.result = RapidResult.SUCCESS;  //转为手动接单的模式我们也告诉第三方接单成功
                    //新增消息---提醒商户有新订单
                    MessageOrderUtil.addUnDealFastFoodMsg(tempOrder, payment);

                    //如果接单失败，则进行自动降级到手动接单
                    wechatFastFoodManualModel(tempOrder, payment);
                }
            }

        }, false);
        removeMealNumber(mealNumber);

    }

    /**
     * 拒绝接单--将订单状态改为取消
     *
     * @param orderId
     * @param fsSellNo
     * @param mealNumber
     */
    private static void rejectWechatFastFood(String orderId, final String fsSellNo, final String mealNumber) {
        MessageOrderUtil.updateFastFoodMsg(orderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
        WechatFastFoodApi.updateWechatFastFoodStatus(orderId, "-2", fsSellNo, mealNumber, 1, new IResponse<String>() {
            @Override
            public void callBack(boolean result, int code, String msg, String info) {
                if (!result) {
                    // 多次失败是否要加任务--因为有自动取消订单机制，十分钟才轮一次的任务好像也没必要加
                }
            }
        });
    }

    private static void wechatFastfoodVoid(final String orderId) {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                BillUtil.autoVoidRapidPay("", orderId);
                return null;
            }
        });
    }

    /**
     * 微信快餐手动接单模式
     */
    private static void wechatFastFoodManualModel(TempOrderDishesCache tempOrder, RapidPayment payment) {
        cleanOrder(payment.orderId, payment.userId);
    }

    /**
     * 快餐取单--服务员手动取单
     *
     * @param resultData
     * @param tempOrder
     * @param payment
     */
    public static void getWechatFastfood(RapidActionModel resultData, TempOrderDishesCache tempOrder, final RapidPayment payment, String fsSellNo, String mealNumber) {

        BigDecimal totalPayed = RapidPrePayBiz.parseRapidPayTotalAmt(payment);
        if (tempOrder != null) {
            RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY,
                    "收到预付款 支付金额[" + totalPayed.toPlainString() + "],订单金额[" + tempOrder.tempTotalPrice.toPlainString() + "]",
                    "", (SourceType.isPrePayFastfoodModel(payment.sourceType) ? payment.orderId : payment.tableNo), payment, tempOrder);
            if (totalPayed.compareTo(tempOrder.tempTotalPrice) >= 0) {
                getOrderByWaiter(resultData, tempOrder, payment, fsSellNo, mealNumber);
            } else {
                RapidBiz.buildResultError(resultData, "支付金额不足，无法接单");
            }
        } else {
            RapidBiz.buildResultError(resultData, "订单信息异常");
        }
        removeMealNumber(mealNumber);
    }


    /**
     * 微信快餐自动接单模式
     * 先通知云端商户接单--最多重试三次
     * 接单通知失败---降级为手动接单
     * 接单通知成功---本地订单下单入口
     * 本地下单入库失败---退款、取消订单
     * 本地下单入库成功---清除缓存
     */
    private static void getOrderByWaiter(final RapidActionModel resultData, final TempOrderDishesCache tempOrder, final RapidPayment payment, final String fsSellNo, final String mealNumber) {
        RapidBiz.rapidFastfoodOrder(resultData, tempOrder, mealNumber, fsSellNo);
        if (resultData.result == RapidResult.SUCCESS) {
            LogUtil.logBusiness("下单成功， 开始存储支付信息 外部订单号：" + payment.orderId + "; sellno = " + fsSellNo);
            payment.rapidMenuOrderIdInner = tempOrder.optFirstThirdOrderID();
            payment.outerOrderId = fsSellNo;
            RapidApi.submitPay(resultData, payment);
            if (resultData.result != RapidResult.SUCCESS) {
                LogUtil.logBusiness(" 存储支付信息失败 外部订单号：" + payment.orderId + "; sellno = " + fsSellNo + "； 原因：" + resultData.errorInfo);
                RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_NO, "先付款的秒付落帐失败，需要自动退款[" + resultData.errorInfo + "]", fsSellNo, payment.orderId, payment, tempOrder);
                RapidBiz.buildResultError(resultData, resultData.errorInfo);
            } else {
                UserDBModel user = RapidBiz.getCloudUser();
                if (user == null) {
                    {
                        user = new UserDBModel();
                        user.fsUserName = tempOrder.waiterName;
                        user.fsUserId = tempOrder.waiterID;
                    }
                }
                BillUtil.startFinalPayProcess(ServerCache.getInstance().generateNewToken(fsSellNo), fsSellNo, user, HostUtil.getCurrentHost(), true, true);

                NotifyToClient.orderChange(fsSellNo);
                busyMealNumber(mealNumber);
                MessageOrderUtil.updateFastFoodMsg(payment.orderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.GET);
                LogUtil.logBusiness("接单成功 : " + payment.orderId);
            }
        } else {
            LogUtil.logBusiness("下单失败，外部订单号：" + payment.orderId + "; sellno = " + fsSellNo + "；原因：" + resultData.errorInfo);
            RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_NO, "先付款的秒付落帐失败，需要自动退款[" + resultData.errorInfo + "]", fsSellNo, payment.orderId, payment, tempOrder);
            RapidBiz.buildResultError(resultData, resultData.errorInfo);
        }
    }


    /**
     * 定时轮休轮到秒付快餐
     *
     * @param tempAppOrder
     */
    public static void turnRapidFastfoodOrder(final TempAppOrder tempAppOrder) {

//        if (checkNetOrderMsgId(optSingleNo(rapidPayment))) {
//            LogUtil.logBusiness("微信快餐正在处理微信快餐订单号：" + tempAppOrder.orderId + "； 中断本次处理请求");
//            return;
//        }

        LogUtil.logBusiness("微信快餐开始处理轮到的微信快餐 " + tempAppOrder.orderId + "; 取消状态：" + tempAppOrder.cancelStatus() + "； payStatus = " + tempAppOrder.payStatus);

        MessageFastFoodBean messageFastFoodBean = MessageDBUtil.getMessageFastfood(String.valueOf(tempAppOrder.orderId));

        if (messageFastFoodBean == null && tempAppOrder.diningStatus == 0) {
            optWechatFastFoodOrderById(String.valueOf(tempAppOrder.orderId));
        } else if ((tempAppOrder.payStatus == -1 || tempAppOrder.cancelStatus()) && messageFastFoodBean != null && messageFastFoodBean.businessStatus != 3) {
            // 网络订单的支付状态(-1已退款，0，未支付, 1部分支付，2已支付，3已就餐)
            MessageOrderUtil.updateFastFoodMsg(tempAppOrder.orderId, "", "", MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
//            releaseNetOrderMsgId(tempAppOrder.orderId);

            int status = MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT;
            if (APPConfig.isAir(GlobalCache.getContext())) {
                if (tempAppOrder.diningStatus == NetworkConstans.DINING_STATUS_USER_CANCEL) {//是否是取消订单
                    status = MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.CANCEL;
                }
            }
            MessageOrderUtil.updateFastFoodMsg(String.valueOf(tempAppOrder.orderId), "", "", status);
            releaseNetOrderMsgId(String.valueOf(tempAppOrder.orderId));
        } else if (messageFastFoodBean != null) {
//            releaseNetOrderMsgId(tempAppOrder.orderId);
        }

//        if (tempAppOrder.diningStatus == -2 && tempAppOrder.payStatus != -1) {
//            BusinessExecutor.executeNoWait(new ASyncExecute() {
//                @Override
//                public Object execute() {
////                    BillUtil.autoVoidRapidPay("", String.valueOf(tempAppOrder.orderId));
//                    return null;
//                }
//            });
//        }
    }

    /**
     * 获取订单详情并接单
     *
     * @param orderId
     */
    public static void optWechatFastFoodOrderById(final String orderId) {
        LogUtil.logBusiness(" 微信快餐获取新订单：" + orderId);
        WechatFastFoodApi.optWechatFastFoodOrderById(orderId, new IResponse<TempAppOrder>() {
            @Override
            public void callBack(boolean result, int code, String msg, TempAppOrder tempAppOrder) {
                if (!result) {
                    LogUtil.logBusiness("根据订单号拿订单失败 " + orderId);
                }

                if (result && tempAppOrder != null) {
                    if (TextUtils.isEmpty(tempAppOrder.mdJson) || TextUtils.isEmpty(tempAppOrder.jzJson)) {
                        LogUtil.logBusiness("根据订单号拿到的订单没有秒点秒付信息 : " + orderId);
                        return;
                    }
                    RapidOrder rapidOrder = JSON.parseObject(tempAppOrder.mdJson, RapidOrder.class);
                    RapidPayment rapidPayment = JSON.parseObject(tempAppOrder.jzJson, RapidPayment.class);
                    if (rapidOrder == null || rapidPayment == null) {
                        return;
                    }

                    String singleKey = optSingleNo(rapidPayment);
                    if (checkNetOrderMsgId(singleKey)) {
                        LogUtil.logBusiness(" 微信快餐正在处理微信快餐订单号：" + tempAppOrder.orderId + "   singleKey = " + singleKey);
                        return;
                    }

                    MessageFastFoodBean messageFastFoodBean = MessageDBUtil.checkFastExist(rapidPayment.orderId, rapidPayment.userId, Calc.formatShow(RapidUtil.parseRapidPayTotalAmt(rapidPayment)));

                    if (messageFastFoodBean != null) {
                        LogUtil.logBusiness("轮询到的新单订单已处理过 " + orderId);
                        releaseNetOrderMsgId(singleKey);
                        return;
                    }
                    RapidActionModel rapidActionModel = new RapidActionModel();
                    receivePreFastFoodMenu(rapidActionModel, new RapidGetModel(), rapidOrder);
                    if (rapidActionModel.result == RapidResult.SUCCESS) {
                        LogUtil.logBusiness("轮询到的新单订单信息入口成功 " + orderId);
                        receivePreFastFoodPay(rapidActionModel, rapidPayment);
                    } else {
                        LogUtil.logBusiness("轮询到的新单订单信息入口失败: " + orderId + ";错误信息：" + rapidActionModel.errorInfo);
                    }

                    releaseNetOrderMsgId(singleKey);
                }

//                releaseNetOrderMsgId(orderId);
            }
        });
    }

    /**
     * 取快餐牌号
     *
     * @return
     */
    public static synchronized String getWechatFastFoodMealNumber() {
        String result = "";
        //牌号前缀
        String label = DBMetaUtil.getConfig(META.RAPID_FAST_FOOD_NUMBER_PRE_LABEL, "A");
        //牌号取值范围
        int min = StringUtil.toInt(DBMetaUtil.getConfig(META.RAPID_FAST_FOOD_NUMBER_MIN, "1"), 1);
        int max = StringUtil.toInt(DBMetaUtil.getConfig(META.RAPID_FAST_FOOD_NUMBER_MAX, "999"), 999);

        result = optMealNumber(label, min, max, HostUtil.getHistoryBusineeDate(""));

        /**
         * 缓存牌号
         */
        putMealNumber(result);

        return result;
    }

    private static int optNmber(String mealNumber) {
        char[] values = mealNumber.toCharArray();
        StringBuilder number = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            char a = values[i];
            if (a > 47 && a <= 57) {
                number.append(String.valueOf(a));
            }
        }
        return StringUtil.toInt(number.toString());
    }

    private static String optLable(String mealNumber) {
        char[] values = mealNumber.toCharArray();
        StringBuilder label = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            char a = values[i];
            if (a >= 65 && a <= 90) {
                label.append(String.valueOf(a));
            }
        }
        return label.toString();
    }

    private static String optMealNumber(String label, int minNumber, int maxNumber, String businessDate) {

        if (busyMealaNumberMap.size() == 0) {
            releanseBusyMealaNumberMap();
        }
        LogUtil.log("lxd", "--------busyMealaNumberMap.size()=" + busyMealaNumberMap.size());

        SparseIntArray busyMealNumberArray = busyMealaNumberMap.get(label);
        if (busyMealNumberArray == null) {
            busyMealNumberArray = new SparseIntArray();
        }

        String lastMealNumberSQL = "select mealNumber " +
                "from order_cache left join message " +
                "on order_cache.order_id = message.sellno " +
                "where order_cache.fsBillSourceId = '99' and message.businessStatus in ('0','1','2', '4') and " +
                "order_cache.business_date = '" + businessDate + "' and " +
                //8-微信快、14-美小店
                "message.msgType = '8' or message.msgType = '14' and order_cache.mealNumber like '" + label + "%' order by order_cache.order_id desc limit 1";

        LogUtil.log("lxd", "--------lastMealNumberSQL=" + lastMealNumberSQL);
        String lastMealNumber = DBSimpleUtil.queryString(APPConfig.DB_MAIN, lastMealNumberSQL);
        LogUtil.log("lxd", "--------lastMealNumber=" + lastMealNumber);
        String result = "";
        int resultInt;
        if (TextUtils.isEmpty(lastMealNumber)) {
            //从未取过任何值时，从最小值开始取
            resultInt = minNumber;
            LogUtil.log("lxd", "-----1---mealNumberCache.size()=" + mealNumberCache.size());
            for (int i = 0; i < mealNumberCache.size(); i++) {
                if (!mealNumberCache.contains(label + (resultInt + i))) {
                    result = label + (resultInt + i);
                    break;
                }
            }

            LogUtil.log("lxd", "-----1---result=" + mealNumberCache.size());
            if (TextUtils.isEmpty(result)) {
                result = label + (resultInt + mealNumberCache.size());
            }

            return result;
        } else {
            int lastMealNumberInt = optNmber(lastMealNumber);
            if (lastMealNumberInt >= minNumber) {
//                for (int i = minNumber; i <= maxNumber; i++) {
                for (int i = lastMealNumberInt + 1; i <= maxNumber; i++) {
                    if (busyMealNumberArray.indexOfKey(i) < 0 && !mealNumberCache.contains(label + i)) {
                        return label + i;
                    }
                }
            }

            int heightLimit = lastMealNumberInt;
            if (lastMealNumberInt > maxNumber || lastMealNumberInt < minNumber) {
                heightLimit = maxNumber;
            }
            for (int i = minNumber; i <= heightLimit; i++) {
                if (busyMealNumberArray.indexOfKey(i) < 0 && !mealNumberCache.contains(label + i)) {
                    return label + i;
                }
            }

            return label + (busyMealNumberArray.keyAt(busyMealNumberArray.size() - 1) + 1);
        }
    }

}
