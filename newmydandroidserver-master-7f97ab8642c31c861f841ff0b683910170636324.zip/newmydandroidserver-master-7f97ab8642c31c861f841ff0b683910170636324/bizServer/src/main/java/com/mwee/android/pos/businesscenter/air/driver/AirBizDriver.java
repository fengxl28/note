package com.mwee.android.pos.businesscenter.air.driver;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.menu.UploadAllShopDishTypeRequest;
import com.mwee.android.air.connect.business.menu.UploadDishTypeBean;
import com.mwee.android.air.connect.business.order.OrderDetailResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadChangeDataProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * Created by liuxiuxiu on 2017/10/20.
 */
@SuppressWarnings("unused")
public class AirBizDriver implements IDriver {

    private static final String TAG = "airBizDriver";

    @DrivenMethod(uri = TAG + "/loadOrderDetail")
    public SocketResponse loadOrderDetail(SocketHeader head, String param) {
        JSONObject jsonObject = JSONObject.parseObject(param);
        String orderId = jsonObject.getString("orderId");
        OrderDetailResponse orderDetailResponse = new OrderDetailResponse();
        orderDetailResponse.orderCache = OrderSession.getInstance().getOrder(orderId);
        orderDetailResponse.payViewBean = BillUtil.buildPayViewData(orderId);
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.data = orderDetailResponse;
        socketResponse.code = SocketResultCode.SUCCESS;
        return socketResponse;
    }

    /**
     * 上传本地修改的数据
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/uploadLocalChangeData")
    public SocketResponse uploadLocalChangeData(SocketHeader head, String param) {

        // 通知副站点刷新数据，独立与上传云端
        NotifyToClient.broadcast("login/dataChangedAir");

        final SocketResponse response = new SocketResponse();
        final JSONObject ob = new JSONObject();
        try {
            UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    PayCache.getInstance().refresh();

                    ob.put("code", SocketResultCode.SUCCESS);
                    ob.put("error", "数据已上送");
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    ob.put("code", SocketResultCode.BUSINESS_FAILED);
                    ob.put("error", responseData.resultMessage);
                    return false;
                }
            }, null);

            response.code = ob.getInteger("code");
            response.message = ob.getString("error");

        } catch (Exception e) {
            LogUtil.logBusiness("/uploadLocalChangeData->系统异常:\n" + e.getMessage());
            response.code = SocketResultCode.EXCEPTION;
            response.message = "系统异常";
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/synchronousData")
    public SocketResponse synchronousData(SocketHeader head, String param) {
        final SocketResponse response = new SocketResponse();
        final JSONObject ob = new JSONObject();
        try {
            UploadDataHelper.uploadAllData(new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    UploadChangeDataProcessor.doPingBashUploadV2(new IExecutorCallback() {
                        @Override
                        public void success(ResponseData responseData) {
                            ob.put("code", SocketResultCode.SUCCESS);
                            ob.put("error", responseData.responseBean.errmsg);
                        }

                        @Override
                        public boolean fail(ResponseData responseData) {
                            ob.put("code", SocketResultCode.BUSINESS_FAILED);
                            ob.put("error", responseData.responseBean.errmsg);
                            return false;
                        }
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    ob.put("code", SocketResultCode.BUSINESS_FAILED);
                    ob.put("error", responseData.resultMessage);
                    return false;
                }
            }, null);

            response.code = ob.getInteger("code");
            response.message = ob.getString("error");

        } catch (Exception e) {
            LogUtil.logBusiness("/synchronousData->系统异常:\n" + e.getMessage());
            response.code = SocketResultCode.EXCEPTION;
            response.message = "系统异常";
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/uploadDishType")
    public SocketResponse uploadDishType(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            UploadAllShopDishTypeRequest request = new UploadAllShopDishTypeRequest();
            String savedMenuClsIdsJson = DBMetaUtil.getConfig(META.KEY_CACHE_MENU_CLS_IDS, "");
            List<UploadDishTypeBean> savedMenuClsIdsList = JSONObject.parseArray(savedMenuClsIdsJson, UploadDishTypeBean.class);
            if (savedMenuClsIdsList != null) {
                request.uploadAllShopDishTypeList.addAll(savedMenuClsIdsList);
                BusinessExecutor.execute(request, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof BasePosResponse) {
                            //成功清空下cacheMenuCls数据
                            LogUtil.logBusiness("上传菜品分类id列表menuClsIds->成功->清空Cache");
                            DBMetaUtil.updateSettingsValueByKey(META.KEY_CACHE_MENU_CLS_IDS, "");
                            socketResponse.code = SocketResultCode.SUCCESS;
                        } else {
                            LogUtil.logBusiness("上传菜品分类id列表menuClsIds->业务失败");
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = responseData.resultMessage;
                        }
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        LogUtil.logBusiness("上传菜品分类id列表menuClsIds->失败");
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                        return false;
                    }
                }, false);
            } else {
                LogUtil.logBusiness("上传菜品分类id列表menuClsIds->取消,因为savedMenuClsIdsJson=" + savedMenuClsIdsJson);
            }
        } catch (Exception e) {
            LogUtil.logBusiness("上传菜品分类id列表menuClsIds->系统异常:\n" + e.getMessage());
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

}

