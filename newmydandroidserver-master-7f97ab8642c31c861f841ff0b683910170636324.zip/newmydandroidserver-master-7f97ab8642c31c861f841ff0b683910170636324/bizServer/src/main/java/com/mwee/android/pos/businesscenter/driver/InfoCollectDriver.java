package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;

import cn.mwee.android.pay.infocollect.InfoCollect;
import cn.mwee.android.pay.infocollect.source.entity.AddRunInfoRequest;
import cn.mwee.android.pay.infocollect.source.entity.CommonInfoRequest;
import cn.mwee.android.pay.infocollect.source.entity.RunInfoAddResponse;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/2/4
 */
public class InfoCollectDriver implements IDriver {
    public static final String TAG = "infocollect";

    @Override
    public String getModuleName() {
        return TAG;
    }

    @DrivenMethod(uri = "infocollect/addClientCommonInfo")
    public SocketResponse<RunInfoAddResponse> addClientCommonInfo(SocketHeader head, String param) {
        SocketResponse<RunInfoAddResponse> socketResponse = generateSocketResponse();
        RunInfoAddResponse runInfoAddResponse = socketResponse.data;
        if (TextUtils.isEmpty(param)) {
            runInfoAddResponse.errmsg = "上报数据为空";
            return socketResponse;
        }
        JSONObject request = JSON.parseObject(param);
        String innerReqeust = request.getString("request");
        if (TextUtils.isEmpty(innerReqeust)) {
            runInfoAddResponse.errmsg = "上报request数据为空";
            return socketResponse;
        }
        CommonInfoRequest commonInfoRequest = JSON.parseObject(innerReqeust, CommonInfoRequest.class);
        if (commonInfoRequest == null || commonInfoRequest.data == null) {
            runInfoAddResponse.errmsg = "上报request数据为空";
            return socketResponse;
        }
        runInfoAddResponse.errno = 0;
        runInfoAddResponse.errmsg = "上报成功";
        InfoCollect.collectDeviceStateInfo(commonInfoRequest.data);
        return socketResponse;


    }

    @DrivenMethod(uri = "infocollect/addClientRunningInfo")
    public SocketResponse<RunInfoAddResponse> addClientRunningInfo(SocketHeader head, String param) {
        SocketResponse<RunInfoAddResponse> socketResponse = generateSocketResponse();
        RunInfoAddResponse runInfoAddResponse = socketResponse.data;
        if (TextUtils.isEmpty(param)) {
            runInfoAddResponse.errmsg = "上报数据为空";
            return socketResponse;
        }
        JSONObject request = JSON.parseObject(param);
        String innerReqeust = request.getString("request");
        if (TextUtils.isEmpty(innerReqeust)) {
            runInfoAddResponse.errmsg = "上报request数据为空";
            return socketResponse;
        }
        AddRunInfoRequest addRunInfoRequest = JSON.parseObject(innerReqeust, AddRunInfoRequest.class);
        if (addRunInfoRequest == null || addRunInfoRequest.data == null) {
            runInfoAddResponse.errmsg = "上报request数据为空";
            return socketResponse;
        }
        runInfoAddResponse.errno = 0;
        runInfoAddResponse.errmsg = "上报成功";
        InfoCollect.collect(addRunInfoRequest.data);
        return socketResponse;
    }

    private SocketResponse<RunInfoAddResponse> generateSocketResponse() {
        SocketResponse<RunInfoAddResponse> socketResponse = new SocketResponse<>();
        RunInfoAddResponse runInfoAddResponse = new RunInfoAddResponse();
        runInfoAddResponse.errno = -1;
        socketResponse.data = runInfoAddResponse;
        return socketResponse;
    }


}
