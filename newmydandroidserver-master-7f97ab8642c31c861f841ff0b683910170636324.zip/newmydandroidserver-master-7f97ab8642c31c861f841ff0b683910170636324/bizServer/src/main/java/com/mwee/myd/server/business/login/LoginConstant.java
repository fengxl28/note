package com.mwee.myd.server.business.login;


import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;

/**
 */
public class LoginConstant {

    public final static String ROOT_URL_PRODUCT = "http://b.mwee.cn/";
    public final static String ROOT_URL_TEST = "http://st.9now.net/";

    public final static String URL_ROOT_PRODUCT = ROOT_URL_PRODUCT+"shop/";
    public final static String URL_ROOT_TEST = ROOT_URL_TEST+"shop/";
    public final static String URL_XMPP_PRODUCT = "http://mxr.dc.mwee.cn/services/mxr/gateway/";
    public final static String URL_XMPP_TEST = "http://mxr.dc.uat.9now.net/services/mxr/gateway/";

    private static String URL_NOW = URL_ROOT_TEST;

    /**
     * 设置非生产环境下的UrlRoot
     *
     * @param urlRootTest String
     */
    public static void setUrlRootTest(String urlRootTest) {
        URL_NOW = urlRootTest;
        DBMetaUtil.updateSettingsValueByKey(META.DEV_URL_LOGIN, URL_NOW);
    }

    /**
     * 获取UrlRoot
     *
     * @return String
     */
    public static String getPDUrlRoot() {
        if (BaseConfig.isProduct()) {
            return URL_ROOT_PRODUCT;
        } else {
            return URL_NOW;
        }
    }
    /**
     * 获取UrlRoot
     *
     * @return String
     */
    public static String getXMPPUrlRoot() {
        if (BaseConfig.isProduct()) {
            return URL_XMPP_PRODUCT;
        } else {
            return URL_XMPP_TEST;
        }
    }

    public static String getBaseUrl(){
        if (BaseConfig.isProduct()) {
            return ROOT_URL_PRODUCT;
        } else {
            return ROOT_URL_TEST;
        }
    }
}
