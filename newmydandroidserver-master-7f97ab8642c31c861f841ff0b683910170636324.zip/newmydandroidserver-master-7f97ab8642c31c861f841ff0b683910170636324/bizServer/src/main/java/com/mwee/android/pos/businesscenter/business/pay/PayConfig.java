package com.mwee.android.pos.businesscenter.business.pay;

/**
 * PayConfig
 * Created by virgil on 16/7/25.
 */
public class PayConfig {

    /**
     * 需要找零的支付方式
     */
    public static String NEED_CHANGE = "";
    /**
     * 结账完成打印结账单
     */
//    public static boolean PRINT_AFTER_PAY = true;
    /**
     * 「销售代金券免找」对应哪个付款方式
     */
    public static String PAY_COUPON_FREE = "";
    /**
     * 「赠送代金券免找」对应哪个付款方式
     */
    public static String PAY_COUPON_GIVEN_FREE = "";
    /**
     * 支付完成是否自动开钱箱
     */
    public static boolean PAY_OPEN_BOX = false;
    /**
     * 是否自动完成结账
     */
//    public static boolean AUTO_FINISH_PAY=false;--->改为实时读取DB
    /**
     * 打印预结单和结账单是否合进行并菜品，默认不处理
     */
    public static boolean PRINT_COMBINE_DISHES = false;

    /**
     * 打印预结单和结账单模式，0：原始小票模式，1：采用菜品分类小票模式，2：采用单序分类小票模式
     * 前提：菜品合并开关是打开时，不能采用单序排序，可以采用菜品分类排序
     */
    public static int PRINT_ORDER_MODE = 0;

    /**
     * 打印预结单和结账单是否按照菜品分类显示，默认是
     */
    public static boolean PRINT_ORDER_BY_MENU_CLS = false;

    /**
     * 是否打印结账单
     */
    public static boolean PRINT_BILL_MARK = true;
}
