package com.mwee.android.pos.businesscenter.module.koubei;

import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuDishAddResponse;
import com.mwee.android.air.connect.business.menu.MenuEditorResponse;
import com.mwee.android.air.connect.business.menu.MenuItemBeanResponse;
import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.db.business.menu.MenuItemBean;

import java.util.List;

/**
 * Created by qinwei on 2018/6/5.
 */

public interface IAirMenuService {
    /**
     * 根据菜品分类id查询所有菜品（包含规格）
     *
     * @param menuClsId 菜品分类id
     * @return
     */
    List<MenuItemBean> findMenuItemAndUnitsByMenuClsId(String menuClsId);

    /**
     * 查询所有菜品分类
     *
     * @param isLoadAllMenuItem 是否需要加载所有菜品信息 true 加载 false 不加载
     * @param isContainSet     是否包含套餐
     * @return
     */
    AllMenuClsAndMenuItemResponse loadAirMenuManager(Boolean isLoadAllMenuItem, Boolean isContainSet);

    /**
     * 根据分类id查询菜品信息列表
     *
     * @param fsMenuClsId
     * @return
     */
    MenuItemsResponse loadAirMenuItemByClsId(String fsMenuClsId);


    /**
     * 更新菜品信息
     *
     * @param fiItemCd           菜品id
     * @param menuItemEditorBody 修改菜品的基本信息
     */
    MenuEditorResponse loadUpdateMenuItem(String fiItemCd, MenuItemEditorBody menuItemEditorBody);

    /**
     * 新增菜品信息
     *
     * @param menuItemEditorBody
     * @return
     */
    MenuDishAddResponse loadAddMenuItem(MenuItemEditorBody menuItemEditorBody);

    /**
     * 获取单个菜品信息
     *
     * @param fiItemCd
     * @return
     */
    MenuItemBeanResponse loadAirMenuItemBeanById(String fiItemCd);
}
