package com.mwee.android.pos.businesscenter.business.koubei.future;

/**
 * Created by zhangmin on 2018/10/13.
 */

public interface IKBFuturePushActionListener {


    /**
     * 推送口碑新订单
     */
    void pushFutureNewOrder();


}
