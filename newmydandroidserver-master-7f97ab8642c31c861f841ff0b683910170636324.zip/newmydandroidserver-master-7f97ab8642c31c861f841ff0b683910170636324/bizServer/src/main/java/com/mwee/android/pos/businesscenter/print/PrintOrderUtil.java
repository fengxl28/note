package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.pos.business.print.CustomSellDBModel;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.business.rapid.api.bean.model.EatType;
import com.mwee.android.pos.businesscenter.air.dbUtil.DeptDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.component.HostStatusDBUtils;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.db.DTOPrinterDBController;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.air.AirPrinterSelect;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberComments;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.SymbolUtils;
import com.mwee.android.pos.util.TempletIdManager;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 菜品相关的打印
 * Created by virgil on 2017/2/4.
 */

public class PrintOrderUtil {

    public static void printMakeOrder(final OrderCache orderCache, String hostId, final int seq) {
        printMakeOrder(orderCache, hostId, seq + "");
    }

    public static void printMakeOrder(final OrderCache orderCache, String hostId, final String seq) {
        printMakeOrder(orderCache, hostId, seq, "");
    }

    private static String formatCallNumV2(SellDBModel sell) {
        int num = 0;
        if (!TextUtils.isEmpty(sell.fssellno) && sell.fssellno.length() > 4) {
            num = StringUtil.toInt(sell.fssellno.substring(sell.fssellno.length() - 4, sell.fssellno.length()), 0);
        }
        return String.format(Locale.SIMPLIFIED_CHINESE, "%03d", num);
    }

    /**
     * 格式化牌号
     *
     * @param sell
     * @return
     */
    private static String formatCallNum(SellDBModel sell) {
        int num = 0;
        boolean isNumber = RegexUtil.checkNumber(sell.fsMealNumber);
        if (!isNumber) {
            if (TextUtils.equals(sell.fsMealNumber, "无")) {
                num = StringUtil.toInt(sell.fssellno.substring(8), 0);
            } else {
                return sell.fsMealNumber;
            }
        } else {
            if (TextUtils.isEmpty(sell.fsMealNumber)) {
                num = StringUtil.toInt(sell.fssellno.substring(8), 0);
            } else {
                num = StringUtil.toInt(sell.fsMealNumber);
            }
        }
        return RegexUtil.formatNumber(num, 3);

    }


    /**
     * 制作单
     *
     * @param orderCache 订单的基本信息
     * @param seq        String | 要打印的菜品单序，打印所有单序则传-1
     * @param menuUniq   String | 要打印指定的菜，则传菜品的uniq
     */
    public static void printMakeOrder(final OrderCache orderCache, final String hostId, final String seq, final String menuUniq) {
        BusinessExecutor.executeNoWait(new ASyncExecute<List<Integer>>() {
            @Override
            public ArrayList<Integer> execute() {
                if (orderCache.shareShopOrder()) {
                    return new ArrayList<>();
                }
                JSONObject data = new JSONObject();
                ArrayList<PrintItemDataBean> printItems = buildPrintItemsByOrderSeq(orderCache.orderID, seq, menuUniq);//构建小票内菜品信息
                ArrayList<Integer> printTaskIds = new ArrayList<>();//缓存业务中心打印不了的 print id

                SellDBModel sellDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", SellDBModel.class);
                if (!TextUtils.isEmpty(sellDBModel.fsCustMobile) && sellDBModel.fsCustMobile.length() > 4) {
                    sellDBModel.fsCustMobile = sellDBModel.fsCustMobile.substring(sellDBModel.fsCustMobile.length() - 4, sellDBModel.fsCustMobile.length());
                }
                String printTime = DateUtil.getCurrentTime();
                JSONObject times = new JSONObject();
                data.put("Sell", sellDBModel);
                if (!TextUtils.isEmpty(seq)) {
                    if (seq.contains(",")) {
                        data.put("fsCreateUserName", orderCache.waiterName);
                    } else {
                        data.put("addMenuLabel", getAddMenuLabel(seq));//将加菜标识存到打印数据里，打印制作单时，需要根据它是否显示加菜标识
                        data.put("fsCreateUserName", orderCache.optSeqModel(StringUtil.toInt(seq, 0)).createWaiterName);
                    }
                } else {
                    data.put("fsCreateUserName", orderCache.waiterName);
                }
                times.put("PrintTime", printTime);
                data.put("SysMode", times);
                if (TextUtils.equals("99", orderCache.fsBillSourceId)) {
                    data.put("eatType", orderCache.eatType == EatType.EAT_IN ? "(堂食)" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "(外带)" : "");
                }

                if (TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.PRINT_BAR_CODE), "1")) {
                    String barcode = formatCallNum(sellDBModel);
                    if (!TextUtils.equals("000", barcode)) {
                        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                        data.put("barCode", barcode + "*1" + shopId);
                    }
                }

                String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
                //兼容模版里蜂鸣声控制，1：开，否则：关
                if(!TextUtils.equals(beep,"1")){
                    beep = "";
                }
                data.put("beep", beep);

                if (printItems.size() > 0) {
                    GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                            .setItemList(printItems)
                            .setWithCurrentHost(false)
                            .setWithDeptMake(true)
                            .setWithDeptTransfer(false)
                            .setCheckArea(true)
                            .setTableAreaID(orderCache.fsmareaid)
                            .setCurrentHostId(hostId)
                            .build();

                    for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                        String fsDeptId = entry.getKey();
                        DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
                        if (deptDBModel == null) {
                            continue;
                        }

                        data.put("Dept", deptDBModel);

                        /**
                         * 打印份数
                         */
                        int fiPrintCopies = deptDBModel.fiPrintCopies;
                        if (fiPrintCopies == 0) {
                            fiPrintCopies = 1;
                        }

                        PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                        if (printer == null) {
                            String info = "打印制作单失败,没有找到启用的打印机。部门ID[" + fsDeptId + "]";
                            info = new AirPrinterSelect().getAirDeptIDNotFound(fsDeptId, info);
                            if (!TextUtils.isEmpty(info)) {
                                ToastUtil.showToast(info);
                            }
                            RunTimeLog.addLog(RunTimeLog.PAY_FAILE, info);
                            continue;
                        }
                        List<PrintItemDataBean> list = entry.getValue();
                        if (ListUtil.isEmpty(list)) {
                            continue;
                        }

                        data.remove("SellOrder");
                        data.remove("SellOrders");
                        data.remove("beep");

                        boolean isTsc = "TSC".equalsIgnoreCase(printer.fsCommandType);

                        if (isTsc) {//拦截TSC打印
                            boolean printerTscSingleMake = TextUtils.equals(ClientMetaUtil.getConfig(META.T_TSC_PRINTER, "1"), "1");//标签是否打印        0/不打印 1 打印
                            if (!printerTscSingleMake) {
                                break;
                            }
                        } else {//拦截厨房打印
                            boolean isPrinterMakeOrder = TextUtils.equals(ClientMetaUtil.getConfig(META.T_KITCHEN_PRINTER, "1"), "1");
                            if (!isPrinterMakeOrder) {
                                break;
                            }
                        }

                        for (int i = 0; i < fiPrintCopies; i++) {
                            //移除整单等叫标志，isAllWaitCall会在printAllMake方法中构建
                            data.remove("isAllWaitCall");
                            if (isTsc) {
                                printSingleMake(true, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, printTaskIds, processor.tscCount, beep);
                            } else {
                                // 制作单 1=一菜一切/2=总单/3=总单&一菜一切/4=一份一切
                                if (deptDBModel.fiIsOneItemCut == 1) {
                                    printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, printTaskIds, processor.tscCount, beep);
                                } else if (deptDBModel.fiIsOneItemCut == 2) {
                                    data.put("beep", beep);
                                    printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, printTaskIds, seq);
                                } else if (deptDBModel.fiIsOneItemCut == 3) {
                                    printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, ListUtil.cloneList(list), printTaskIds, processor.tscCount, beep);
                                    data.put("beep", beep);
                                    printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, printTaskIds, seq);
                                } else if (deptDBModel.fiIsOneItemCut == 4) {
                                    printSingle(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, list, printTaskIds, processor.tscCount, beep);
                                }
                            }
                        }
                    }
                }
                return printTaskIds;
            }
        });
    }

    /**
     * 根据单序判断是否显示加菜标识
     *
     * @return
     */
    public static String getAddMenuLabel(String orderSeq) {
        String addMenuLabel = "";//加菜标识
        if (!TextUtils.isEmpty(orderSeq)) {
            int seq = StringUtil.toInt(orderSeq, 1);
            if (seq > 1) {
                addMenuLabel = "(加菜)";
            }
        }
        return addMenuLabel;
    }

    private static void printAllMake(JSONObject valueMap, OrderCache orderCache, String fsDeptId, String fsPrinterName,
                                     String hostId, List<PrintItemDataBean> list,
                                     List<Integer> printTaskIds, String seq) {
        int fiPrintNo = PrintJSONBuilder.generatePrintNO();

        //是否打印整单等叫逻辑
        List<PrintItemDataBean> allWaitCallData = buildAllWaitCallData(list);

        if (!ListUtil.isEmpty(allWaitCallData)) {
            valueMap.put("isAllWaitCall", "1");
            list = allWaitCallData;
        }
        boolean printBatchNote = TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_SHOW_BATCHNOTE, "0"), "1");

        for (PrintItemDataBean printItemDataBean : list) {
            if (!printBatchNote) {
                //批量要求不线上在顶上时就需要线上查菜品头部
                if (!TextUtils.isEmpty(printItemDataBean.batchSpecialNote)) {
                    printItemDataBean.fsSpecialNote = TextUtils.isEmpty(printItemDataBean.fsSpecialNote) ?
                            printItemDataBean.batchSpecialNote : printItemDataBean.fsSpecialNote + ";" + printItemDataBean.batchSpecialNote;
                }

                if (!TextUtils.isEmpty(printItemDataBean.fsSpecialNote)) {
                    printItemDataBean.fsSpecialNote = "[" + printItemDataBean.fsSpecialNote + "]";
                }

                if (!TextUtils.isEmpty(printItemDataBean.fsWholeNote)) {
                    printItemDataBean.fsGeneralNote = TextUtils.isEmpty(printItemDataBean.fsGeneralNote) ?
                            printItemDataBean.fsWholeNote : printItemDataBean.fsGeneralNote + ";" + printItemDataBean.fsWholeNote;
                }
            } else {
                if (!TextUtils.isEmpty(printItemDataBean.fsSpecialNote)) {
                    printItemDataBean.fsSpecialNote = "[" + printItemDataBean.fsSpecialNote + "]";
                }

                if (!TextUtils.isEmpty(printItemDataBean.batchSpecialNote)) {
                    printItemDataBean.fsWholeNote = TextUtils.isEmpty(printItemDataBean.fsWholeNote) ?
                            printItemDataBean.batchSpecialNote : printItemDataBean.fsWholeNote + ";" + printItemDataBean.batchSpecialNote;
                }

            }
        }

        //整单备注
        if (!ListUtil.isEmpty(list) && printBatchNote) {
            if (!TextUtils.isEmpty(list.get(0).fsWholeNote)) {
                valueMap.put("wholeNote", list.get(0).fsWholeNote);
            }
        }

        valueMap.put("SellOrder", list);
        //根据选择的模版id构建数据
        if (TextUtils.equals(PrintDataProcessUtil.getSelectTempletId("order/make"), TempletIdManager.ID_DINNER_MAKE_2)) {
            valueMap.put("sellOrderOfPackage", sellOrderOfPackage(list, seq, orderCache.orderID));
        }
        valueMap.put("fiPrintNo", fiPrintNo);
        valueMap.put("menuItemCount", getIngredientListCount(list).intValue() + sumQty(list, false, true));
        LogUtil.log("menuItemCount:" + valueMap.getString("menuItemCount"));
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_TOTAL_LIST, hostId, true);
        task.uri = "order/make";
        task.fsPrnData = valueMap.toJSONString();
        task.fsPrinterName = fsPrinterName;

        //控制第二语言小票打印
        MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
//        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//        if (!task.printAtOnce) {
//            printTaskIds.add(task.fiPrintNo);
//        }
    }

    /**
     * 构建套餐头在上的制作单数据-模版使用
     *
     * @param originalData
     * @param seq
     * @param orderId
     * @return
     */
    private static List<PrintItemDataBean> sellOrderOfPackage(List<PrintItemDataBean> originalData, String seq, String orderId) {
        String sql = "select (fdSaleQty-fdBackQty) as fdSaleQty,fsMenuClsId," +
                "(case fiItemMakeSte " +
                " when 2 then '[等叫]' " +
                " when 4 then '[划菜]' " +
                " when 8 then '[打包]' " +
                " else '' end) as SfiItemMakeState, * " +
                " from tbSellOrderItem " +
                " where  fiIsPrn='1' and fsSellNo ='" + orderId + "' and fiOrderItemKind = '2' ";
        if (!TextUtils.isEmpty(seq)) {
            sql += " and fiOrderSeq in (" + seq + ")";
        }
        List<PrintItemDataBean> packageList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        if (packageList == null) {
            packageList = new ArrayList<>();
        }
        if (ListUtil.isEmpty(packageList)) {
            return originalData;
        }
        List<PrintItemDataBean> result = new ArrayList<>();
        for (PrintItemDataBean originData : originalData) {
            if (originData != null) {
                if (originData.fiOrderItemKind != 3) {
                    result.add(originData);
                } else {
                    for (PrintItemDataBean packageData : packageList) {
                        if (packageData != null && TextUtils.equals(packageData.fsseq, originData.fsSeq_M)) {
                            packageData.packageItemList.add(originData);
                            break;
                        }
                    }
                }
            }
        }
        result.addAll(packageList);
        return result;
    }

    public static BigDecimal getIngredientListCount(List<PrintItemDataBean> list) {
        BigDecimal count = BigDecimal.ZERO;
        for (PrintItemDataBean itemData : list) {
            if (itemData != null && !ListUtil.isEmpty(itemData.ingredientList)) {
                for (PrintItemDataBean ingredient : itemData.ingredientList) {
                    if (ingredient != null) {
                        count = count.add(ingredient.fdSaleQty);
                    }
                }
            }
        }
        return count;
    }

    /**
     * 标签打印
     *
     * @param isTsc
     * @param valueMap
     * @param orderCache
     * @param fsDeptId
     * @param fsPrinterName
     * @param hostId
     * @param list
     * @param printTaskIds
     * @param tscCount
     * @param beep
     */
    private static void printSingleMake(boolean isTsc, JSONObject valueMap, OrderCache orderCache,
                                        String fsDeptId, String fsPrinterName, String hostId,
                                        List<PrintItemDataBean> list, ArrayList<Integer> printTaskIds, int tscCount, String beep) {
        int fiPrintNo = 0;
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);

        for (PrintItemDataBean printItemDataBean : list) {
            //批量要求不线上在顶上时就需要线上查菜品头部
            if (!TextUtils.isEmpty(printItemDataBean.batchSpecialNote)) {
                printItemDataBean.fsSpecialNote = TextUtils.isEmpty(printItemDataBean.fsSpecialNote) ?
                        printItemDataBean.batchSpecialNote : printItemDataBean.fsSpecialNote + ";" + printItemDataBean.batchSpecialNote;
            }

            if (!TextUtils.isEmpty(printItemDataBean.fsSpecialNote)) {
                printItemDataBean.fsSpecialNote = "[" + printItemDataBean.fsSpecialNote + "]";
            }

            if (!TextUtils.isEmpty(printItemDataBean.fsWholeNote)) {
                printItemDataBean.fsGeneralNote = TextUtils.isEmpty(printItemDataBean.fsGeneralNote) ?
                        printItemDataBean.fsWholeNote : printItemDataBean.fsGeneralNote + ";" + printItemDataBean.fsWholeNote;
            }
        }

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_TOTAL_LIST_SINGLE, hostId, true);
        task.fsPrinterName = fsPrinterName;
        List<PrintItemDataBean> printList = new ArrayList<>();
        for (int x = 0; x < list.size(); x++) {
            PrintItemDataBean temp = list.get(x);
            if (x == list.size() - 1) {
                valueMap.put("beep", beep);
            }
            task = task.clone();
            printList.clear();
            printList.add(temp);
            valueMap.put("SellOrder", printList);

            if (isTsc) {
                int count = temp.fiIsEditQty == 1 ? 1 : temp.fdSaleQty.intValue();
                for (int i = 1; i <= count; i++) {

                    JSONObject printDatas = new JSONObject();

                    String shopName = "";
                    String time;
                    String id;

                    if (shopDBModel != null) {
                        shopName = shopDBModel.fsShopName;
                    }
                    printDatas.put("shopname", shopName);

                    if (!TextUtils.equals("无", orderCache.fsmtablename)) {
                        id = "台号:" + orderCache.fsmtablename;
                    } else {
                        id = "单号:" + orderCache.orderID.substring(orderCache.orderID.length() - 4, orderCache.orderID.length());
                    }

                    printDatas.put("id", id);
                    printDatas.put("num", PrintUtil.optBuyNumAndUnit(temp.fdSaleQty, temp.fsOrderUint));
                    printDatas.put("itemname", temp.fsItemName);
                    printDatas.put("price", Calc.formatShow(temp.fdSettlePrice) + "元");
                    String sequence = (temp.lastTscIndex + i) + "/" + tscCount;
                    LogUtil.log("sequence = " + sequence + " -->" + temp.fsItemName);
                    printDatas.put("sequence", sequence);
                    printDatas.put("itemnote", temp.fsNote + "");  //备注

                    String tel = "";
                    if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
                        tel = shopDBModel.fsTel;
                    }
                    if (!TextUtils.isEmpty(tel)) {
                        printDatas.put("phone", "电话：" + tel);
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                    } else {
                        time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm");
                    }
                    printDatas.put("time", time);
                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    printDatas.put("fiPrintNo", fiPrintNo);
                    task.uri = "order/makesingleTSC";
//                    task.fsPrnData = printDatas.toJSONString();
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, printDatas);
                }
            } else {
                fiPrintNo = PrintJSONBuilder.generatePrintNO();
                task.fiPrintNo = fiPrintNo;
                valueMap.put("fiPrintNo", fiPrintNo);
                task.uri = "order/makesingle";
//                task.fsPrnData = JSON.toJSONString(valueMap, SerializerFeature.DisableCircularReferenceDetect);
//                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                //控制第二语言小票打印
                MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
            }
//            if (!task.printAtOnce) {
//                printTaskIds.add(task.fiPrintNo);
//            }
        }
    }

    /**
     * 一份一切
     *
     * @param isTsc
     * @param valueMap
     * @param orderCache
     * @param fsDeptId
     * @param fsPrinterName
     * @param hostId
     * @param list
     * @param printTaskIds
     * @param tscCount
     * @param beep          蜂鸣
     */
    private static void printSingle(boolean isTsc, JSONObject valueMap, OrderCache orderCache,
                                    String fsDeptId, String fsPrinterName, String hostId,
                                    List<PrintItemDataBean> list, ArrayList<Integer> printTaskIds, int tscCount, String beep) {
        int fiPrintNo = 0;
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);

        for (PrintItemDataBean printItemDataBean : list) {
            //批量要求不线上在顶上时就需要线上查菜品头部
            if (!TextUtils.isEmpty(printItemDataBean.batchSpecialNote)) {
                printItemDataBean.fsSpecialNote = TextUtils.isEmpty(printItemDataBean.fsSpecialNote) ?
                        printItemDataBean.batchSpecialNote : printItemDataBean.fsSpecialNote + ";" + printItemDataBean.batchSpecialNote;
            }

            if (!TextUtils.isEmpty(printItemDataBean.fsSpecialNote)) {
                printItemDataBean.fsSpecialNote = "[" + printItemDataBean.fsSpecialNote + "]";
            }

            if (!TextUtils.isEmpty(printItemDataBean.fsWholeNote)) {
                printItemDataBean.fsGeneralNote = TextUtils.isEmpty(printItemDataBean.fsGeneralNote) ?
                        printItemDataBean.fsWholeNote : printItemDataBean.fsGeneralNote + ";" + printItemDataBean.fsWholeNote;
            }
        }

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID,
                orderCache.fsmtablename,
                orderCache.businessDate,
                fiPrintNo,
                orderCache.waiterName,
                fsDeptId, PrintReportId.MAKE_THE_SINGLE, hostId, true);
        task.fsPrinterName = fsPrinterName;
        for (int x = 0; x < list.size(); x++) {
            PrintItemDataBean temp = list.get(x).clone();

            int count = temp.fiIsEditQty == 1 ? 1 : temp.fdSaleQty.intValue();
            if (isTsc) {
                for (int i = 1; i <= count; i++) {
                    JSONObject printDatas = new JSONObject();
                    String shopName = "";
                    if (shopDBModel != null) {
                        shopName = shopDBModel.fsShopName;
                    }
                    printDatas.put("shopname", shopName);
                    String time = DateUtil.formartDateStrToTarget(temp.fsCreateTime, "yyyy-MM-dd HH:mm:ss", "HH:mm");
                    printDatas.put("time", time);
                    String id = "台号:" + orderCache.fsmtablename;
                    printDatas.put("id", id);
                    if (temp.fiIsEditQty == 1) {
                        printDatas.put("num", PrintUtil.optBuyNumAndUnit(temp.fdSaleQty, temp.fsOrderUint));
                    } else {
                        printDatas.put("num", PrintUtil.optBuyNumAndUnit(BigDecimal.ONE, temp.fsOrderUint));
                    }

                    printDatas.put("itemname", temp.fsItemName);
                    printDatas.put("price", Calc.formatShow(temp.fdSettlePrice) + "元");
                    String sequence = (temp.lastTscIndex + i) + "/" + tscCount;
                    LogUtil.log("sequence = " + sequence + " -->" + temp.fsItemName);
                    printDatas.put("sequence", sequence);
                    printDatas.put("itemnote", temp.fsNote + "");  //备注

                    String tel = "";
                    if (shopDBModel != null && !TextUtils.isEmpty(shopDBModel.fsTel)) {
                        tel = shopDBModel.fsTel;
                    }
                    if (!TextUtils.isEmpty(tel)) {
                        printDatas.put("phone", "电话：" + tel);
                    }

                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    printDatas.put("fiPrintNo", fiPrintNo);
                    task.uri = "order/makesingleTSC";
//                    task.fsPrnData = printDatas.toJSONString();
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
                }
            } else {
                for (int j = 0; j < count; j++) {
                    if (x == (list.size() - 1) && j == (count - 1)) {  //同一个批次只蜂鸣一次
                        valueMap.put("beep", beep);
                    }
                    task = task.clone();
                    List<PrintItemDataBean> printList = new ArrayList<>();
                    printList.clear();
                    printList.add(temp);
                    if (temp.fiIsEditQty != 1) {
                        temp.fdSaleQty = BigDecimal.ONE;
                    }
                    valueMap.put("SellOrder", printList);
                    fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    task.fiPrintNo = fiPrintNo;
                    valueMap.put("fiPrintNo", fiPrintNo);
                    task.uri = "order/makesingle";
//                    task.fsPrnData = JSON.toJSONString(valueMap, SerializerFeature.DisableCircularReferenceDetect);
//                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    //控制第二语言小票打印
                    MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, valueMap);
                }
            }
//            if (!task.printAtOnce) {
//                printTaskIds.add(task.fiPrintNo);
//            }
        }
    }

    public static ArrayList<PrintItemDataBean> buildPrintItemsByOrderSeq(String orderId, String seq, String menuUniq) {
        String sql = "select (fdSaleQty-fdBackQty) as fdSaleQty,fsMenuClsId," +
                "(case fiItemMakeSte " +
                " when 2 then '[等叫]' " +
                " when 4 then '[划菜]' " +
                " when 8 then '[打包]' " +
                " else '' end) as SfiItemMakeState, " +
                " parentItemName, *,(case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName " +
                " from tbSellOrderItem a " +
                " left join " +
                " (select fsseq parentseq, " +
                " fsItemName parentItemName " +
                " from tbSellOrderItem " +
                " where fsSellNo ='" + orderId + "' and fiOrderItemKind = '2' ) b " +
                " on " +
                " a.fsseq_m = b.parentseq  " +
                " where " +
                " (a.fdBackQty=0 or a.fdSaleQty!=a.fdBackQty) and " +
                " fiIsPrn='1' and fsSellNo ='" + orderId + "'";
        if (!TextUtils.isEmpty(seq)) {
            sql += " and fiOrderSeq in (" + seq + ")";
        }

        if (!TextUtils.isEmpty(menuUniq)) {
            sql += " and fsseq='" + menuUniq + "'";
        }

        /**
         * 所有单品和套餐明细
         */
        String singleItemSql = sql + " and fiOrderItemKind in ('1', '3') ";
        List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, singleItemSql, PrintItemDataBean.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        }

//        itemExModel.parentItemName = statementSellItemModel.fsItemName;

        /**
         * 所有配料
         */
        String ingredientSql = sql + " and fiOrderItemKind in ('4') ";
        List<PrintItemDataBean> ingredientDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, ingredientSql, PrintItemDataBean.class);
        if (ListUtil.isEmpty(ingredientDBModels)) {
            ingredientDBModels = new ArrayList<>();
        }

        /**
         * 配料作为要求打印
         */
        if (!ListUtil.isEmpty(ingredientDBModels) && ingredientDBModels.size() > 0) {
            for (PrintItemDataBean sellOrderItemBean : sellOrderItemDBModels) {
                for (int i = 0; i < ingredientDBModels.size(); i++) {
                    PrintItemDataBean ingredientItem = ingredientDBModels.get(i);
                    if (TextUtils.equals(sellOrderItemBean.fsseq, ingredientItem.fsSeq_M)) {
                        sellOrderItemBean.ingredientList.add(ingredientItem);
                        sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + ingredientItem.fsItemName + "*" + PrintUtil.optBuyNumAndUnit(ingredientItem.fdSaleQty, ingredientItem.fsOrderUint) + ";";

                        if (i != ingredientDBModels.size() - 1) {
                            sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + "\n";
                        }
                    }
                }
            }
        }

        //记录日志
        StringBuilder stringBuffer = new StringBuilder("订单：");
        stringBuffer.append(orderId).append("；时间：").append(DateUtil.getCurrentDate(DateUtil.DATE_YYYYMMDDHHMMSSSSS)).append(";打印制作单，单序：").append(seq).append(";菜品:");

        for (PrintItemDataBean printItemDataBean : sellOrderItemDBModels) {
            if (printItemDataBean == null) {
                continue;
            }
            stringBuffer.append(printItemDataBean.fiItemCd).append("-").append(printItemDataBean.fsItemName).append(";");

        }
        ActionLog.addLog(ActionLog.PR_PRINT_MAKE_INFO, stringBuffer.toString());
        return (ArrayList<PrintItemDataBean>) sellOrderItemDBModels;
    }

    /**
     * 打印转菜单 -- 批量转菜
     *
     * @param targetOrder  OrderCache | 订单信息
     * @param menuItemList MenuItem | 转菜的菜品信息
     * @param user         String  | 打印的value
     */
    public static List<Integer> printBatchTransfer(final OrderCache targetOrder, final List<MenuItem> menuItemList, final UserDBModel user, final String fromTableName, final String hostId) {
        JSONObject valueMap = new JSONObject();
        SellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo='" + targetOrder.orderID + "'", SellDBModel.class);
        valueMap.put("Sell", sell);
        valueMap.put("fromtablename", fromTableName);
        valueMap.put("totablename", targetOrder.fsmtablename);
        valueMap.put("PrintUser", user.fsUserName);

        List<PrintItemDataBean> turnItemBeen = new ArrayList<>();
        for (MenuItem item : menuItemList) {
            turnItemBeen.addAll(optTurnItemList(item));
        }

        if (ListUtil.listIsEmpty(turnItemBeen)) {
            return new ArrayList<>(0);
        }

        List<Integer> printTaskIds = new ArrayList<>();
        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(turnItemBeen)
                .setWithCurrentHost(false)
                .setWithDeptMake(true)
                .setWithDeptTransfer(true)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String deptID = entry.getKey();
            List<PrintItemDataBean> list = entry.getValue();
            DeptDBModel deptDBModel = processor.deptInfo.get(deptID);
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是制作部门，但是不能打印转菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsTurnBill != 1) {
                continue;
            }
            valueMap.put("SellOrder", list);
            int fiPrintNo = PrintJSONBuilder.generatePrintNO();
            valueMap.put("fiPrintNo", fiPrintNo);
            valueMap.put("Dept", deptDBModel.fsDeptName);

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    targetOrder.orderID,
                    targetOrder.fsmtablename,
                    targetOrder.businessDate,
                    fiPrintNo,
                    user.fsUserName,
                    deptID,
                    PrintReportId.TRANSFER,
                    hostId, true
            );
            task.uri = "order/transfer";
            task.fsPrnData = valueMap.toJSONString();
            task.fsPrinterName = deptDBModel.fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;
    }

    private static List<PrintItemDataBean> optTurnItemList(MenuItem menuItem) {

        String sqlMenu = "select *,(case fiItemMakeSte when 2 then '[等叫]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq='" + menuItem.menuBiz.uniq + "'";
        if (menuItem.supportPackage()) {
            sqlMenu = "select *,(case fiItemMakeSte when 2 then '[等叫]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq_m='" + menuItem.menuBiz.uniq + "'";
        }

        String sqlIngredient = "select *,(case fiItemMakeSte when 2 then '[等叫]' else '' end) as SfiItemMakeState from tbSellOrderItem where fiOrderItemKind = '4'  and fsseq_m='" + menuItem.menuBiz.uniq + "' and fdSaleQty > fdBackQty ";

        List<PrintItemDataBean> items = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenu, PrintItemDataBean.class);
        List<PrintItemDataBean> ingredentItems = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlIngredient, PrintItemDataBean.class);

        if (ListUtil.listIsEmpty(items)) {
            items = new ArrayList<>();
        } else if (items.size() == 1) {
            /**
             * 配料
             */
            StringBuilder stringBuilder = new StringBuilder("");
            if (!ListUtil.isEmpty(ingredentItems)) {
                for (int i = 0; i < ingredentItems.size(); i++) {
                    PrintItemDataBean printItemDataBean = ingredentItems.get(i);
                    stringBuilder.append(printItemDataBean.fsItemName).append("*").append(PrintUtil.optBuyNumAndUnit(printItemDataBean.fdSaleQty.subtract(printItemDataBean.fdBackQty), printItemDataBean.fsOrderUint)).append(";");
                    if (i != menuItem.menuBiz.selectedModifier.size() - 1) {
                        stringBuilder.append("\n");
                    }
                }
            }
            items.get(0).ingredientNotes = stringBuilder.toString();
        }
        return items;
    }

    /**
     * 打印起菜
     *
     * @param targetOrder OrderCache | 订单信息
     * @param menuItem    MenuItem | 转菜的菜品信息
     * @param user        String  | 打印的value
     */
    public static void printWaitCallData(final OrderCache targetOrder, final MenuItem menuItem, final UserDBModel user) {
        /**
         * 点单商品明细表 SellOrderItemDBModel
         * 获取销售表 SellDBModel
         */
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                JSONObject valueMap = new JSONObject();
                SellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo='" + targetOrder.orderID + "'", SellDBModel.class);
                valueMap.put("Sell", sell);
                String sqlMenu = "select (fdSaleQty-fdBackQty) as fdSaleQty,*,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq='" + menuItem.menuBiz.uniq + "'";
                if (menuItem.supportPackage()) {
                    sqlMenu = "select (fdSaleQty-fdBackQty) as fdSaleQty,*,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fiOrderItemKind = '3' and fsSeq_M = '" + menuItem.menuBiz.uniq + "' and fdSaleQty>fdBackQty";
                }
                String sqlMenuModifier = "select (fdSaleQty-fdBackQty) as fdSaleQty,*,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fiOrderItemKind = '4' and fsSeq_M = '" + menuItem.menuBiz.uniq + "'";
                List<PrintItemDataBean> items = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenu, PrintItemDataBean.class);

                List<PrintItemDataBean> modifiers = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenuModifier, PrintItemDataBean.class);
                StringBuilder modifierNote = new StringBuilder("");
                if (!ListUtil.isEmpty(modifiers)) {
                    for (int i = 0; i < modifiers.size(); i++) {
                        PrintItemDataBean modifier = modifiers.get(i);
                        if (modifier.fdBackQty == null) {
                            modifier.fdBackQty = BigDecimal.ZERO;
                        }
                        modifierNote.append(modifier.fsItemName).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.fdSaleQty.subtract(modifier.fdBackQty), modifier.fsOrderUint)).append(";");
                        if (i < modifiers.size() - 1) {
                            modifierNote.append("\n");
                        }
                    }
                }

                valueMap.put("ingredientNote", modifierNote.toString());

                valueMap.put("fsCreateUserName", targetOrder.optSeqModel(targetOrder.optLastSeq()).createWaiterName);
                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(items)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(true)
                        .setWithDeptTransfer(true)
                        .build();
                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                    String deptID = entry.getKey();
                    List<PrintItemDataBean> list = entry.getValue();
                    DeptDBModel deptDBModel = processor.deptInfo.get(deptID);
                    if (deptDBModel == null) {
                        continue;
                    }
                    /**
                     * 如果是制作部门，但是不能打印起菜单，则continue
                     */
                    if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsTaskBill != 1) {
                        continue;
                    }
                    valueMap.put("SellOrder", list);
                    int fiPrintNo = PrintJSONBuilder.generatePrintNO();
                    valueMap.put("fiPrintNo", fiPrintNo);
                    valueMap.put("Dept", deptDBModel.fsDeptName);
                    PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                            targetOrder.orderID,
                            targetOrder.fsmtablename,
                            targetOrder.businessDate,
                            fiPrintNo,
                            user.fsUserName,
                            deptID,
                            PrintReportId.WAITCALL);
                    task.uri = "order/waitcall";
                    task.fsPrnData = valueMap.toJSONString();
                    task.fsPrinterName = deptDBModel.fsPrinterName;
                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                }
                return new Object();
            }
        });
    }

    /**
     * 打印起菜--支持批量
     *
     * @param targetOrder  OrderCache | 订单信息
     * @param menuItemList MenuItem | 转菜的菜品信息
     * @param user         String  | 打印的value
     */
    public static List<Integer> printBatchWakeUp(final OrderCache targetOrder, final List<MenuItem> menuItemList, final UserDBModel user, final String hostId,
                                                 final SyncCallback<List<Integer>> callBack) {
        /**
         * 点单商品明细表 SellOrderItemDBModel
         * 获取销售表 SellDBModel
         */
        JSONObject valueMap = new JSONObject();
        SellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo='" + targetOrder.orderID + "'", SellDBModel.class);
        valueMap.put("Sell", sell);

        List<PrintItemDataBean> printItemDataBeanList = optWakeUpPrintData(menuItemList);

        List<Integer> printTaskIds = new ArrayList<>();
        valueMap.put("fsCreateUserName", targetOrder.optSeqModel(targetOrder.optLastSeq()).createWaiterName);
        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(printItemDataBeanList)
                .setWithCurrentHost(false)
                .setWithDeptMake(true)
                .setWithDeptTransfer(true)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String deptID = entry.getKey();
            List<PrintItemDataBean> list = entry.getValue();
            DeptDBModel deptDBModel = processor.deptInfo.get(deptID);
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是制作部门，但是不能打印起菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsTaskBill != 1) {
                continue;
            }
            valueMap.put("SellOrder", list);
            int fiPrintNo = PrintJSONBuilder.generatePrintNO();
            valueMap.put("fiPrintNo", fiPrintNo);
            valueMap.put("Dept", deptDBModel.fsDeptName);
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    targetOrder.orderID,
                    targetOrder.fsmtablename,
                    targetOrder.businessDate,
                    fiPrintNo,
                    user.fsUserName,
                    deptID,
                    PrintReportId.WAITCALL,
                    hostId,
                    true
            );
            task.uri = "order/waitcall";
            task.fsPrnData = valueMap.toJSONString();
            task.fsPrinterName = deptDBModel.fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;
    }

    /**
     * 构造起菜数据集合
     *
     * @param menuItemList
     * @return
     */
    private static List<PrintItemDataBean> optWakeUpPrintData(List<MenuItem> menuItemList) {
        List<PrintItemDataBean> printItemDataBeanList = new ArrayList<>();
        for (MenuItem menuItem : menuItemList) {

            String sqlMenu = "select *,(fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq='" + menuItem.menuBiz.uniq + "'";
            if (menuItem.supportPackage()) {
                sqlMenu = "select *,(fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fiOrderItemKind = '3' and fsSeq_M = '" + menuItem.menuBiz.uniq + "' and fdSaleQty>fdBackQty";
            }
            String sqlMenuModifier = "select *,(fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fiOrderItemKind = '4' and fsSeq_M = '" + menuItem.menuBiz.uniq + "'";
            List<PrintItemDataBean> items = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenu, PrintItemDataBean.class);

            if (ListUtil.listIsEmpty(items)) {
                continue;
            }
            if (items.size() == 1) {
                List<PrintItemDataBean> modifiers = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenuModifier, PrintItemDataBean.class);
                StringBuilder modifierNote = new StringBuilder("");
                if (!ListUtil.isEmpty(modifiers)) {
                    for (int i = 0; i < modifiers.size(); i++) {
                        PrintItemDataBean modifier = modifiers.get(i);
                        if (modifier.fdBackQty == null) {
                            modifier.fdBackQty = BigDecimal.ZERO;
                        }
                        modifierNote.append(modifier.fsItemName).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.fdSaleQty.subtract(modifier.fdBackQty), modifier.fsOrderUint)).append(";");
                        if (i < modifiers.size() - 1) {
                            modifierNote.append("\n");
                        }
                    }
                }
                items.get(0).ingredientNotes = modifierNote.toString();
            }

            printItemDataBeanList.addAll(items);
        }
        return printItemDataBeanList;
    }

    /**
     * 打印催菜单--支持批量
     *
     * @param menuItemList List<MenuItem>
     * @param orderCache   OrderCache
     */
    public static List<Integer> printBatchRush(final List<MenuItem> menuItemList, final OrderCache orderCache, final String waiterName, final String hostId,
                                               final SyncCallback<List<Integer>> callBack) {
        JSONObject datas = new JSONObject();
        datas.put("fssellno", orderCache.orderID);
        datas.put("fsMTableName", orderCache.fsmtablename);
        datas.put("PrintUser", orderCache.optSeqModel(orderCache.optLastSeq()).createWaiterName);

        List<PrintItemDataBean> printItemDataBeanList = optRushPrintDatas(menuItemList);

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(printItemDataBeanList)
                .setWithCurrentHost(false)
                .setWithDeptMake(true)
                .setWithDeptTransfer(true)
                .build();

        List<Integer> printTaskIds = new ArrayList<>();

        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String deptID = entry.getKey();
            List<PrintItemDataBean> list = entry.getValue();
            DeptDBModel deptDBModel = processor.deptInfo.get(deptID);
            if (deptDBModel == null) {
                continue;
            }

            /**
             * 如果是制作部门，但是不能打印催菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsHurryBill != 1) {
                continue;
            }

            datas.put("SellOrders", list);
            int printNO = PrintJSONBuilder.generatePrintNO();
            datas.put("fiPrintNo", printNO);
            datas.put("Dept", deptDBModel.fsDeptName);

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                    printNO,
                    waiterName,
                    deptID,
                    PrintReportId.REMIND_THE_MENU, hostId, true);
            task.uri = "order/remindDish";
            task.fsPrnData = datas.toJSONString();
            task.fsPrinterName = deptDBModel.fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;
    }

    /**
     * 批量转菜数据
     *
     * @param menuItemList
     * @return
     */
    private static List<PrintItemDataBean> optRushPrintDatas(List<MenuItem> menuItemList) {

        List<PrintItemDataBean> printItemDataBeanList = new ArrayList<>();
        for (MenuItem menuItem : menuItemList) {
            long waitTime = DateUtil.compareDate(menuItem.menuBiz.createTime,
                    DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT), DateUtil.DATE_VISUAL14FORMAT) / (1000 * 60);

            String sqlMenu = "select *, (fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq='" + menuItem.menuBiz.uniq + "'";
            if (menuItem.supportPackage()) {
                sqlMenu = "select *,(fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq_m = '" + menuItem.menuBiz.uniq + "'";
            }

            List<PrintItemDataBean> printItemDataBeans = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlMenu, PrintItemDataBean.class);

            if (ListUtil.isEmpty(printItemDataBeans)) {
                continue;
            }

            if (printItemDataBeans.size() == 1) {
                printItemDataBeans.get(0).waitTime = waitTime;
                printItemDataBeans.get(0).fdSaleQty = printItemDataBeans.get(0).fdSaleQty.subtract(menuItem.menuBiz.delimitNum);

                /**
                 * 所有配料
                 */
                String ingredientSql = "select *,(fdSaleQty-fdBackQty) as fdSaleQty,(case fiItemMakeSte when 3 then '[起菜]' else '' end) as SfiItemMakeState from tbSellOrderItem where fsseq_m = '" + menuItem.menuBiz.uniq + "' and fiOrderItemKind in ('4') ";
                List<PrintItemDataBean> ingredientDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, ingredientSql, PrintItemDataBean.class);
                if (ListUtil.isEmpty(ingredientDBModels)) {
                    ingredientDBModels = new ArrayList<>();
                }

                /**
                 * 配料作为要求打印
                 */
                if (!ListUtil.isEmpty(ingredientDBModels) && ingredientDBModels.size() > 0) {
                    for (PrintItemDataBean sellOrderItemBean : printItemDataBeans) {
                        for (int i = 0; i < ingredientDBModels.size(); i++) {
                            PrintItemDataBean ingredientItem = ingredientDBModels.get(i);
                            if (TextUtils.equals(sellOrderItemBean.fsseq, ingredientItem.fsSeq_M)) {
                                sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + ingredientItem.fsItemName + "*" + PrintUtil.optBuyNumAndUnit(ingredientItem.fdSaleQty, ingredientItem.fsOrderUint) + ";";
                                if (i != ingredientDBModels.size() - 1) {
                                    sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + "\n";
                                }
                            }
                        }
                    }
                }
            } else {
                for (PrintItemDataBean printItemDataBean : printItemDataBeans) {
                    printItemDataBean.waitTime = waitTime;
                    printItemDataBean.fdSaleQty = printItemDataBean.fdSaleQty.subtract(menuItem.menuBiz.delimitNum);
                }
            }
            printItemDataBeanList.addAll(printItemDataBeans);
        }
        return printItemDataBeanList;
    }

    /**
     * 打印秒点的点菜单，仅限秒点/美小二调用
     *
     * @param orderCache OrderCache
     */
    public static void printRapidMenuList(final OrderCache orderCache, String hostID) {
        String sql = "select fsPrinterName from tbPrinter where fsPrinterName in (select fsPrinterName from tbmarea where fsMAreaId='" + orderCache.fsmareaid + "');";
        String printer = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(printer)) {
            printMenuList(orderCache, null, ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
            RunTimeLog.addLog(RunTimeLog.PRINT_CONFIG, "点菜单，没有配置餐区打印机,SQL为：\n" + sql);
        } else {
            printMenuList(orderCache, printer, hostID);
        }
    }

    /**
     * 根据点餐批次打印点餐单
     *
     * @param orderCache
     * @param seq
     * @param hostID
     */
    public static void printRapidMenuList(final OrderCache orderCache, int seq, String hostID) {
        String printerName = null;
        if (APPConfig.isMyd()) {
            //美易点走餐区打印机打印
            String printer = DTOPrinterDBController.queryPrinterNameByFsMAreaId(orderCache.fsmareaid);
            if (TextUtils.isEmpty(printer)) {
                RunTimeLog.addLog(RunTimeLog.PRINT_CONFIG, "点菜单，没有配置餐区打印机");
            } else {
                printerName = printer;
            }
        }
        printMenuList(orderCache, seq, printerName, hostID);
    }

    /**
     * 打印订单的最后一个单序的点菜单
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printMenuList(final OrderCache orderCache, String printerName, String hostId) {
        if (orderCache.shareShopOrder()) {
            return new ArrayList<>();
        }
        int lastSeq = orderCache.optLastSeq();
        return printMenuList(orderCache, lastSeq, printerName, hostId);
    }

    /**
     * 打印点菜单
     *
     * @param orderCache OrderCache
     * @param seq        int
     */
    public static List<Integer> printMenuList(final OrderCache orderCache, final int seq, final String printerName, final String hostId) {
        ArrayList<Integer> printTaskIds = new ArrayList<>();
        if (!TextUtils.equals("1", CommonDBUtil.getConfig(DBPrintConfig.STATEMENT_PRINTER))) {
            LogUtil.logBusiness("商户设置不打印点菜单");
            return printTaskIds;
        }
        boolean printBatchNote = TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_SHOW_BATCHNOTE, "0"), "1");

//        BusinessExecutor.executeNoWait(new ASyncExecute() {
//            @Override
//            public Object execute() {
        JSONObject datas = new JSONObject();
        CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", CustomSellDBModel.class);
        sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
        sell.reservationTime = orderCache.eatTime;
        datas.put("Sell", sell);
        OrderSeqModel seqModel = orderCache.optSeqModel(orderCache.optLastSeq());
        String waiterId = seqModel == null ? "" : seqModel.createWaiterID;
        String waiterName = seqModel == null ? "" : seqModel.createWaiterName;
        datas.put("PrintUser", waiterName);
        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);
        datas.put("printPrice", DBPrintConfig.needPrintMenuPrice() ? 1 : 0);
        String date = orderCache.businessDate;

        String sql = "select fsseq,fsMenuClsId,fsOrderUint,fsSeq_M," +
                "(case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName fsItemName, " +
                "(case fdGiftQty when 0 then '' else '[Gift]' end)||fsItemName2 fsItemName2,fsNote, (fdSaleQty-fdBackQty) as fdSaleQty, " +
                "(fdSaleQty-fdBackQty) as qty, fiOrderItemKind, fiIsEditQty,fdsaleamt, " +
                "(case fiItemMakeSte when 2 then '[等叫]' else '' end) as SfiItemMakeState," +
                "fiWithinDiningStandard,fsSpecialNote,fsGeneralNote,fsWholeNote,batchSpecialNote,fsRootMenuClsName " +
                "from tbSellOrderItem where fsSellNo = '" + orderCache.orderID + "'" +
                " and fiOrderMode in (1,3)" +
                " and (fdSaleQty!=fdBackQty or fdBackQty=0)" +
                " and fsSellDate='" + date + "'";

        if (seq >= 0) {
            sql = sql + " and fiOrderSeq='" + seq + "'";
        }
        //普通菜品，套餐头
        String nomalItemsSql = sql + " and fiOrderItemKind in ('1','2') ";
        //配料菜
        String ingredientSql = sql + " and fiOrderItemKind = '4' ";
        //套餐菜
        String mackageDetailItemsSql = sql + " and fiOrderItemKind = '3' ";

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--1145");

        List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, nomalItemsSql, PrintItemDataBean.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        } else {
            if (printBatchNote) {
                for (PrintItemDataBean printItemDataBean : sellOrderItemDBModels) {
                    printItemDataBean.fsNote = printItemDataBean.fsGeneralNote + (TextUtils.isEmpty(printItemDataBean.fsSpecialNote) ? "" : ";" + printItemDataBean.fsSpecialNote);
                }
            }
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--1152");

        List<PrintItemDataBean> ingredientItemsList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, ingredientSql, PrintItemDataBean.class);
        if (ingredientItemsList == null) {
            ingredientItemsList = new ArrayList<>();
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--1159");

        List<PrintItemDataBean> slitList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, mackageDetailItemsSql, PrintItemDataBean.class);
        if (slitList == null) {
            slitList = new ArrayList<>();
        }

        BigDecimal ingredientCount = BigDecimal.ZERO;
        BigDecimal itemExModelCount = BigDecimal.ZERO;
        BigDecimal subTotalPrice = BigDecimal.ZERO;
        for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {
            subTotalPrice = subTotalPrice.add(statementSellItemModel.fdSaleAmt);
            for (PrintItemDataBean itemExModel : slitList) {
                if (itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                    if (statementSellItemModel.SLIT == null) {
                        statementSellItemModel.SLIT = new ArrayList<>();
                    }
                    statementSellItemModel.SLIT.add(itemExModel);
                    itemExModelCount = itemExModelCount.add(itemExModel.fdSaleQty);
                    // 套餐明细的价格已合计到套餐头
//                            subTotalPrice = subTotalPrice.add(itemExModel.fdSaleAmt);
                }
            }

            for (PrintItemDataBean ingredientModel : ingredientItemsList) {
                if (ingredientModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                    ingredientCount = ingredientCount.add(ingredientModel.fdSaleQty);
                    statementSellItemModel.ingredientList.add(ingredientModel);
                    subTotalPrice = subTotalPrice.add(ingredientModel.fdSaleAmt);
                }
            }
        }

        if (printBatchNote) {
            //整单备注
            if (!ListUtil.isEmpty(sellOrderItemDBModels)) {
                sellOrderItemDBModels.get(0).fsWholeNote = TextUtils.isEmpty(sellOrderItemDBModels.get(0).batchSpecialNote) ?
                        sellOrderItemDBModels.get(0).fsWholeNote : sellOrderItemDBModels.get(0).fsWholeNote + ";" + sellOrderItemDBModels.get(0).batchSpecialNote;
                if (!TextUtils.isEmpty(sellOrderItemDBModels.get(0).fsWholeNote)) {
                    datas.put("wholeNote", sellOrderItemDBModels.get(0).fsWholeNote);
                }
            }
        }

        //移除整单等叫标志，isAllWaitCall会在printAllMake方法中构建
        datas.remove("isAllWaitCall");

        //是否打印整单等叫逻辑
        List<PrintItemDataBean> allWaitCallData = buildAllWaitCallData(sellOrderItemDBModels);

        if (!ListUtil.isEmpty(allWaitCallData)) {
            datas.put("isAllWaitCall", "1");
            sellOrderItemDBModels = allWaitCallData;
        }
        datas.put("SellOrder", sellOrderItemDBModels);
        if (TextUtils.equals(PrintDataProcessUtil.getSelectTempletId("order/menulist"), TempletIdManager.ID_DINNER_MENULIST_2)) {
            datas.put("SellOrderGroupByCls", PrintDataProcessUtil.groupPrintItemByCls(sellOrderItemDBModels));
        }

        datas.put("Sub", ingredientCount.intValue() + itemExModelCount.intValue() + sumQty(sellOrderItemDBModels, false, false));
        datas.put("subTotalPrice", subTotalPrice.toPlainString());

        if (TextUtils.equals("99", orderCache.fsBillSourceId)) {
            datas.put("eatType", orderCache.eatType == EatType.EAT_IN ? "(堂食)" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "(外带)" : "");
        }

        //点菜单、预结单、结账单是否显示用餐标准内菜品金额 0：显示 1：不显示，默认1
        if (BigDecimal.ZERO.compareTo(sell.fdDiningStandardAmt) < 0) {
            datas.put("diningStandardPrintConfig", DBMetaUtil.getConfig(META.DINNERSTANDARD_PRINT_CONFIG, "1"));
        }

        String fsPrinterName = printerName;
        if (TextUtils.isEmpty(fsPrinterName)) {
            if (!TextUtils.isEmpty(hostId)) {
                fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbhost where fsHostId = '" + hostId + "'");
            }
        }

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                printNO,
                waiterName,
                "0",
                PrintReportId.ORDERED_MENU,
                hostId, true);
        task.uri = "order/menulist";
        task.fsPrinterName = fsPrinterName;

        //读美小二结账单打印配置：美小二出结账单，端上不出小票
        if (TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_MENU_ON_WAITER, "0"), "1")) {
            HostStatusModel waiter = HostStatusDBUtils.queryWaiter(waiterId);
            //printConfig：打印配置 0：不可打印，1可打印，默认0
            if (waiter != null && TextUtils.equals(waiter.hostid, HostBiz.mealorder) && waiter.printConfig == 1 && !TextUtils.isEmpty(waiter.device)) {
                task.fsHostId = waiter.device;//美小二硬件标志
            } else {
                LogUtil.logBusiness("美小二打印结账单开关为开，但不可打印：" + (waiter == null ? "" : "printConfig:" + waiter.printConfig + ",device:" + waiter.device));
            }
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--openTableAndOrder--1216");
        MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(printTaskIds, task, datas);
//            }
//        });

        return printTaskIds;
    }

    /**
     * 点菜单、传菜单、制作总单显示整单等叫
     * 整单等叫的判断规则以单个单据的所有菜品的等叫状态
     *
     * @param printItems
     */
    public static List<PrintItemDataBean> buildAllWaitCallData(List<PrintItemDataBean> printItems) {

        if (ListUtil.isEmpty(printItems)) {
            return null;
        }
        // 点菜单、传菜单、制作总单显示整单等叫
        if (TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_SHOW_ALL_WAITCALL, "0"), "1")) {
            boolean isAllWaitCall = true;
            for (PrintItemDataBean item : printItems) {
                if (item != null && TextUtils.isEmpty(item.SfiItemMakeState)) {
                    isAllWaitCall = false;
                    break;
                }
            }
            if (isAllWaitCall) {
                List<PrintItemDataBean> copyPrintItems = new ArrayList<>(printItems.size());
                //新增一个字段标示“整单等叫”，并将所有的菜品的等叫状态改为‘不等叫’
                for (PrintItemDataBean item : printItems) {
                    if (item != null) {
                        PrintItemDataBean copyItem = item.clone();
                        if (copyItem != null) {
                            copyItem.SfiItemMakeState = "";
                            if (!ListUtil.isEmpty(copyItem.SLIT)) {
                                for (PrintItemDataBean packageItem : copyItem.SLIT) {
                                    if (packageItem != null) {
                                        packageItem.SfiItemMakeState = "";
                                    }
                                }
                            }
                            copyPrintItems.add(copyItem);
                        }
                    }
                }
                return copyPrintItems;
            }
        }
        return null;
    }

    /**
     * 打印点菜预览单 未下厨
     *
     * @param request
     * @return
     */
    public static List<Integer> tempPrintPreMenuList(JSONObject request, String hostID) {

        JSONObject datas = new JSONObject();
        JSONObject sell = new JSONObject();


        sell.put("fsSellNo", request.getString("fsSellNo"));
        sell.put("fsMTableName", request.getString("fsMTableName"));

        sell.put("fiCustSum", request.getString("fiCustSum"));

        sell.put("fsSellDate", request.getString("fsSellDate"));
        sell.put("fsMSectionName", DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                "select fsMSectionName from tbmsection where fsMSectionId='" + request.getString("currentSectionID") + "'"));

        datas.put("Sell", sell);

        String waiterName = request.getString("printUser");
        datas.put("PrintUser", waiterName);
        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);
        int count = 0;
        List<JSONObject> sellOrderItemDBModels = new ArrayList<>();
        List<MenuItem> tempSelectedMenuList = JSON.parseArray(request.getString("tempSelectedMenuList"), MenuItem.class);
        for (MenuItem temp : tempSelectedMenuList) {

            JSONObject ob = new JSONObject();
            ob.put("fsItemName", temp.isMenuTemporary() ? "[临]" + temp.name : temp.name);
            ob.put("fdSaleQty", temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum));
            ob.put("fsOrderUint", temp.currentUnit.fsOrderUint);
            ob.put("fiOrderItemKind", 1);
            String fsNote = "";
            if (!temp.supportPackage()) {
                fsNote = !TextUtils.isEmpty(temp.menuBiz.selectedExtraStr) ? (temp.menuBiz.selectedExtraStr + ";" + temp.menuBiz.note) : temp.menuBiz.note;
            } else {
                fsNote = temp.menuBiz.note;
            }
            ob.put("fsnote", fsNote);
            BigDecimal itemCount = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
            if (temp.supportWeight()) {
                itemCount = BigDecimal.ONE;
            }
            if (temp.supportPackage()) {
                ob.put("fiOrderItemKind", 2);
                if (!ListUtil.isEmpty(temp.menuBiz.selectedPackageItems)) {
                    List<JSONObject> SLIT = new ArrayList<JSONObject>();
                    for (MenuItem item : temp.menuBiz.selectedPackageItems) {
                        JSONObject obpack = new JSONObject();
                        obpack.put("fiOrderItemKind", 3);
                        obpack.put("fsItemName", item.name);
                        obpack.put("fdSaleQty", item.menuBiz.buyNum);
                        obpack.put("fsNote", item.menuBiz.selectedExtraStr);
                        //count += item.menuBiz.buyNum.intValue();
                        SLIT.add(obpack);
                    }
                    ob.put("SLIT", SLIT);
                }
                count += itemCount.intValue();

            } else if (temp.supportIngredient()) {
                if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                    List<JSONObject> ingredientList = new ArrayList<>();
                    int modifierCount = 0;
                    for (MenuItem tempModifier : temp.menuBiz.selectedModifier) {
                        JSONObject obModifier = new JSONObject();
                        obModifier.put("fiOrderItemKind", 4);
                        obModifier.put("fsItemName", tempModifier.name);
                        BigDecimal tempCount = tempModifier.menuBiz.buyNum.subtract(tempModifier.menuBiz.voidNum);
                        obModifier.put("fdSaleQty", tempCount);
                        obModifier.put("fsOrderUint", tempModifier.currentUnit.fsOrderUint);
                        ingredientList.add(obModifier);
                        modifierCount += tempCount.intValue();
                    }
                    //count +=  modifierCount;
                    count += 1 + modifierCount;
                    ob.put("ingredientList", ingredientList);
                    if (!temp.supportWeight()) {
                        ob.put("fdSaleQty", 1);
                        while (itemCount.compareTo(BigDecimal.ONE) >= 1) {
                            count += 1 + modifierCount;
                            JSONObject obClone = (JSONObject) ob.clone();
                            obClone.put("ingredientList", ingredientList);
                            sellOrderItemDBModels.add(obClone);
                            itemCount = itemCount.subtract(BigDecimal.ONE);
                        }
                    }
                } else {
                    count += itemCount.intValue();
                }
            } else {
                count += itemCount.intValue();
            }

            sellOrderItemDBModels.add(ob);
        }
        datas.put("SellOrder", sellOrderItemDBModels);
        datas.put("Sub", count);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", request.getString("fsMTableName"), request.getString("fsSellDate"),
                printNO,
                request.getString("printUser"),
                "0",
                PrintReportId.ORDERED_MENU_PRE, hostID, true);
        task.uri = "order/temp_pre_menulist";
        task.fsPrnData = JSON.toJSONString(datas, SerializerFeature.DisableCircularReferenceDetect);
        task.fsPrinterName = DeviceDBUtil.getPrinterNameByHostID(hostID);
        List<Integer> printTaskIds = new ArrayList<>();
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

    /**
     * 打印点菜预览单 已下厨
     *
     * @param
     */
    public static List<Integer> printPreMenuList(JSONObject request, String hostiD) {

        JSONObject datas = new JSONObject();
        JSONObject sell = new JSONObject();


        sell.put("fsSellNo", request.getString("fsSellNo"));
        sell.put("fsMTableName", request.getString("fsMTableName"));

        sell.put("fiCustSum", request.getString("fiCustSum"));

        sell.put("fsSellDate", request.getString("fsSellDate"));
        sell.put("fsMSectionName", DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                "select fsMSectionName from tbmsection where fsMSectionId='" + request.getString("currentSectionID") + "'"));

        datas.put("Sell", sell);

        String waiterName = request.getString("printUser");
        datas.put("PrintUser", waiterName);
        int printNO = PrintJSONBuilder.generatePrintNO();
        datas.put("fiPrintNo", printNO);
        int count = 0;
        List<JSONObject> sellOrderItemDBModels = new ArrayList<>();


        ArrayList<MenuItem> tempMenuLists = new ArrayList<>();
        List<MenuItem> originMenuList = JSON.parseArray(request.getString("originMenuList"), MenuItem.class);
        for (MenuItem tempMenuItem : originMenuList) {
            if (tempMenuItem.menuBiz.buyNum.compareTo(tempMenuItem.menuBiz.voidNum) != 0 && tempMenuItem.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {

                //构建一份完全退掉的菜品 仅仅点菜预览单展示用
                MenuItem item2 = tempMenuItem.clone();
                item2.menuBiz.buyNum = tempMenuItem.menuBiz.voidNum;

                tempMenuLists.add(tempMenuItem);
                tempMenuLists.add(item2);


            } else {
                tempMenuLists.add(tempMenuItem);
            }
        }


        for (MenuItem temp : tempMenuLists) {

            JSONObject ob = new JSONObject();
            String fsItemName = temp.isMenuTemporary() ? "[临]" + temp.name : temp.name;
            ob.put("fsItemName", fsItemName);
            ob.put("fsRootMenuClsName", temp.rootMenuClsName);
            ob.put("fsMenuClsId", temp.rootMenuClsId);
            ob.put("fdSaleQty", temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum));
            ob.put("orderSeqID", temp.menuBiz.orderSeqID);

            if (temp.menuBiz.giftNum != null && temp.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
                ob.put("fsItemName", "[赠]" + fsItemName);
            }

            if (temp.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {

                if (temp.hasAllVoid()) {
                    ob.put("fsItemName", "[退]" + fsItemName);
                    ob.put("fdSaleQty", temp.menuBiz.voidNum);//菜品完全退掉
                } else {
                    ob.put("fsItemName", fsItemName);
                    ob.put("fdSaleQty", temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum));//菜品完全退掉

                }
            }

            ob.put("fsOrderUint", temp.currentUnit.fsOrderUint);
            ob.put("fiOrderItemKind", 1);
            String fsNote = "";
            if (!temp.supportPackage()) {
                fsNote = !TextUtils.isEmpty(temp.menuBiz.selectedExtraStr) ? (temp.menuBiz.selectedExtraStr + ";" + temp.menuBiz.note) : temp.menuBiz.note;
            } else {
                fsNote = temp.menuBiz.note;
            }
            ob.put("fsnote", fsNote);
            BigDecimal itemCount = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
            if (temp.supportWeight()) {
                itemCount = BigDecimal.ONE;
            }
            if (temp.supportPackage()) {
                ob.put("fiOrderItemKind", 2);
                if (!ListUtil.isEmpty(temp.menuBiz.selectedPackageItems)) {
                    List<JSONObject> SLIT = new ArrayList<JSONObject>();
                    for (MenuItem item : temp.menuBiz.selectedPackageItems) {
                        // 全退的套餐子项不打印
                        if (item.hasAllVoid()) {
                            continue;
                        }
                        JSONObject obpack = new JSONObject();
                        obpack.put("fiOrderItemKind", 3);
                        obpack.put("fsItemName", item.name);
                        obpack.put("fdSaleQty", item.menuBiz.buyNum.subtract(item.menuBiz.voidNum));
                        obpack.put("fsNote", item.menuBiz.selectedExtraStr);
                        obpack.put("fsMenuClsId", temp.rootMenuClsId);
                        //count += item.menuBiz.buyNum.intValue();
                        SLIT.add(obpack);
                    }
                    ob.put("SLIT", SLIT);
                }
                count += itemCount.intValue();

            } else if (temp.supportIngredient()) {
                if (!ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                    List<JSONObject> ingredientList = new ArrayList<>();
                    int modifierCount = 0;
                    for (MenuItem tempModifier : temp.menuBiz.selectedModifier) {
                        JSONObject obModifier = new JSONObject();
                        obModifier.put("fiOrderItemKind", 4);
                        obModifier.put("fsItemName", tempModifier.name);

                        BigDecimal tempCount = (itemCount.multiply(tempModifier.menuBiz.buyNum.subtract(tempModifier.menuBiz.voidNum)));
                        obModifier.put("fdSaleQty", tempCount);
                        obModifier.put("fsOrderUint", tempModifier.currentUnit.fsOrderUint);
                        obModifier.put("fsMenuClsId", temp.rootMenuClsId);
                        ingredientList.add(obModifier);

                        if (!temp.hasAllVoid()) {
                            modifierCount += tempCount.intValue();
                        }
                    }
                    if (temp.supportWeight() && temp.hasAllVoid()) {
                        itemCount = BigDecimal.ZERO;
                    }
                    count += itemCount.intValue() + modifierCount;
                    ob.put("ingredientList", ingredientList);

                } else {
                    count += itemCount.intValue();
                }
            } else {
                if (temp.supportWeight() && temp.hasAllVoid()) {
                    itemCount = BigDecimal.ZERO;
                }
                count += itemCount.intValue();
            }

            sellOrderItemDBModels.add(ob);
        }

        datas.put("SellOrder", sellOrderItemDBModels);
        String selectTemplet = PrintDataProcessUtil.getSelectTempletId("order/pre_menulist");
        if (TextUtils.equals(selectTemplet, TempletIdManager.ID_DINNER_PREMENULIST_1)) {
            datas.put("SellOrderGroupByTime", PrintDataProcessUtil.groupJSONItemByTime(sellOrderItemDBModels, "orderSeqID"));
        } else if (TextUtils.equals(selectTemplet, TempletIdManager.ID_DINNER_PREMENULIST_2)) {
            datas.put("SellOrderGroupByCls", PrintDataProcessUtil.groupJSONItemByCls(sellOrderItemDBModels, "fsMenuClsId"));
        }

        datas.put("Sub", count);

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", request.getString("fsMTableName"), request.getString("fsSellDate"),
                printNO,
                request.getString("printUser"),
                "0",
                PrintReportId.ORDERED_MENU_PRE, hostiD, true);
        task.uri = "order/pre_menulist";
        task.fsPrnData = JSON.toJSONString(datas, SerializerFeature.DisableCircularReferenceDetect);
        task.fsPrinterName = DeviceDBUtil.getPrinterNameByHostID(hostiD);
        List<Integer> printTaskIds = new ArrayList<>();
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }


    public static List<Integer> printPassTo(final OrderCache orderCache, final String hostId) {
        return printPassTo(orderCache, -1, hostId, "");
    }

    public static List<Integer> printPassTo(final OrderCache orderCache, String preTime, final String hostId) {
        return printPassTo(orderCache, -1, hostId, preTime);
    }

    public static List<Integer> printPassTo(final OrderCache orderCache, int seq, final String hostId) {
        return printPassTo(orderCache, seq, hostId, "");
    }

    /**
     * 打印传菜单
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printPassTo(final OrderCache orderCache, int seq, final String hostId, String preTime) {
        List<Integer> printTaskIds = new ArrayList<>();
        if (orderCache.shareShopOrder()) {
            return printTaskIds;
        }

        boolean printBatchNote = TextUtils.equals(DBMetaUtil.getConfig(META.PRINT_SHOW_BATCHNOTE, "0"), "1");

        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {

                JSONObject datas = new JSONObject();

                int lastSeq = seq > 0 ? seq : orderCache.optLastSeq();
                OrderSeqModel model = orderCache.optSeqModel(lastSeq);
                datas.put("PrintUser", orderCache.waiterName);

                String date = orderCache.businessDate;

                String sql = "select fsseq,fsMenuClsId,fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsNote,fsDeptId,  fiIsMulDept,fiItemCd,fiIsEditQty,(fdSaleQty-fdBackQty) as fdSaleQty," +
                        " (case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState," +
                        " fiOrderItemKind,fsGeneralNote,fsSpecialNote,fsWholeNote,batchSpecialNote,fsRootMenuClsName from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind <> '3'" +
                        " and fiOrderMode in (1,3)" +
                        " and (fdBackQty=0 or fdSaleQty!=fdBackQty)" +
                        " and fsSellDate='" + date + "'" +
                        " and fiOrderSeq='" + lastSeq + "'";

                String sql2 = "select fsseq,fsMenuClsId,fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsDeptId,fiIsMulDept,fiItemCd,fiIsEditQty, (fdSaleQty-fdBackQty) as fdSaleQty," +
                        "(case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState, fsGeneralNote,fsSpecialNote,fiOrderItemKind,fsWholeNote,batchSpecialNote,fsRootMenuClsName from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind = '3' " +
                        " and fiOrderMode in (1,3)" +
                        " and (fdBackQty=0 or fdSaleQty!=fdBackQty)" +
                        " and fsSellDate='" + date + "'" +
                        " and fiOrderSeq='" + lastSeq + "'";
                //todo and (fdBackQty=0 or fdSaleQty!=fdBackQty) 对接口碑后付款套餐 传菜单不打印 秦伟代码

                List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
                if (sellOrderItemDBModels == null) {
                    sellOrderItemDBModels = new ArrayList<>();
                } else {
                    if (printBatchNote) {
                        for (PrintItemDataBean printItemDataBean : sellOrderItemDBModels) {
                            printItemDataBean.fsNote = printItemDataBean.fsGeneralNote + (TextUtils.isEmpty(printItemDataBean.fsSpecialNote) ? "" : ";" + printItemDataBean.fsSpecialNote);
                        }
                    }
                }

                List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintItemDataBean.class);
                if (SLITList == null) {
                    SLITList = new ArrayList<>();
                }

                for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {

                    for (PrintItemDataBean itemExModel : SLITList) {
                        if (itemExModel.fiOrderItemKind == 3 && itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                            itemExModel.parentItemName = statementSellItemModel.fsItemName;
                        }
                    }
                }

                sellOrderItemDBModels.addAll(SLITList);

                /**
                 * 去除套餐头--套餐头不打印
                 */
                for (int i = 0; i < sellOrderItemDBModels.size(); i++) {
                    if (sellOrderItemDBModels.get(i).fiOrderItemKind == 2) {
                        sellOrderItemDBModels.remove(i);
                        i--;
                    }
                }

                CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo =" + orderCache.orderID, CustomSellDBModel.class);
                sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                        "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
                sell.reservationTime = preTime;
                datas.put("Sell", sell);


                String printPassto = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_PASSTO, "0");
                if (TextUtils.equals("0", printPassto) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null) {
                        if (!TextUtils.isEmpty(memberComments.memberLevel)) {
                            datas.put("memberLevel", memberComments.memberLevel);
                        }
                        if (!TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("sex", memberComments.sex);
                        }
                        if (memberComments.cardBalance.compareTo(BigDecimal.ZERO) >= 0 && !TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("cardBalance", memberComments.cardBalance);
                        }
                    }
                }

                String cloudBuffet = CommonDBUtil.getConfigWithDefault(DBPrintConfig.MWBYD_CLOUD_BUFFET, "0");
                if (TextUtils.equals("1", cloudBuffet) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null && memberComments.verifyComments()) {
                        if (memberComments.service_score > 0) {
                            datas.put("serviceScore", SymbolUtils.queryPentagram(memberComments.service_score));
                        }
                        if (!TextUtils.isEmpty(memberComments.messages)) {
                            datas.put("commentsMessages", memberComments.messages);
                        }
                        if (!TextUtils.isEmpty(memberComments.tags)) {
                            datas.put("tags", memberComments.tags);
                        }
                    }
                }

                if (printBatchNote) {
                    //整单备注
                    if (!ListUtil.isEmpty(sellOrderItemDBModels)) {
                        sellOrderItemDBModels.get(0).fsWholeNote = TextUtils.isEmpty(sellOrderItemDBModels.get(0).batchSpecialNote) ?
                                sellOrderItemDBModels.get(0).fsWholeNote : sellOrderItemDBModels.get(0).fsWholeNote + ";" + sellOrderItemDBModels.get(0).batchSpecialNote;
                        if (!TextUtils.isEmpty(sellOrderItemDBModels.get(0).fsWholeNote)) {
                            datas.put("wholeNote", sellOrderItemDBModels.get(0).fsWholeNote);
                        }
                    }
                }

                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(sellOrderItemDBModels)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(false)
                        .setWithDeptTransfer(true)
                        .setTableAreaID(orderCache.fsmareaid)
                        .build();
                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {

                    //移除整单等叫标志，isAllWaitCall会在printAllMake方法中构建
                    datas.remove("isAllWaitCall");

                    String deptID = entry.getKey();
                    List<PrintItemDataBean> list = entry.getValue();
                    DeptDBModel deptDBModel = processor.deptInfo.get(deptID);

                    int printNO = PrintJSONBuilder.generatePrintNO();
                    datas.put("fiPrintNo", printNO);

                    //是否打印整单等叫逻辑
                    List<PrintItemDataBean> allWaitCallData = buildAllWaitCallData(list);

                    if (!ListUtil.isEmpty(allWaitCallData)) {
                        datas.put("isAllWaitCall", "1");
                        list = allWaitCallData;
                    }

                    datas.put("sellorder", list);
                    if (TextUtils.equals(PrintDataProcessUtil.getSelectTempletId("order/passto"), TempletIdManager.ID_DINNER_PASSTO_2)) {
                        datas.put("SellOrderGroupByCls", PrintDataProcessUtil.groupPrintItemByCls(list));
                    }
                    datas.put("Sub", sumQty(list, false, true));
                    datas.put("Dept", deptDBModel.fsDeptName);
                    datas.put("fsCreateUserName", orderCache.optSeqModel(orderCache.optLastSeq()).createWaiterName);

                    PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                            orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                            printNO,
                            model.createWaiterName,
                            deptID,
                            PrintReportId.THE_MENU,
                            hostId,
                            true);
                    task.uri = "order/passto";
                    task.fsPrnData = datas.toJSONString();
                    task.fsPrinterName = deptDBModel.fsPrinterName;

                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    if (!task.printAtOnce) {
                        printTaskIds.add(task.fiPrintNo);
                    }
                }
                return null;
            }
        });
        return printTaskIds;
    }

    /**
     * 计算总数
     *
     * @param list            数据源
     * @param addCategoryHead 是否算套餐头
     * @param addCategoryBody 是否算套餐体
     * @return
     */
    public static int sumQty(List<? extends PrintItemDataBean> list, boolean addCategoryHead, boolean addCategoryBody) {
        int sumQty = 0;
        try {
            for (int i = 0; i < list.size(); i++) {
                PrintItemDataBean sellOrderItemDBModel = list.get(i);
                if (sellOrderItemDBModel.fiOrderItemKind == 2 && !addCategoryHead) {
                    continue;
                } else if (sellOrderItemDBModel.fiOrderItemKind == 3 && !addCategoryBody) {
                    continue;
                }

                if (sellOrderItemDBModel.fiIsEditQty == 1) { //称重菜算一份
                    sumQty = sumQty + 1;
                } else {
                    sumQty = sumQty + sellOrderItemDBModel.fdSaleQty.intValue();
                }

            }
        } catch (Exception e) {
            LogUtil.log(e.getMessage());
        }
        return sumQty;
    }

    /**
     * @param menuItem
     * @return
     */
    private static List<PrintItemDataBean> formatVoidItem(MenuItem menuItem) {
        List<PrintItemDataBean> item;
        String fiIsPrn = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiIsPrn from tbmenuitem where fiItemCd='" + menuItem.itemID + "'");

        if (TextUtils.equals(fiIsPrn, "1")) {
            String sql = "select * from tbSellOrderItem where fsSeq = '" + menuItem.menuBiz.uniq + "' and fiOrderItemKind = '1'";
            if (menuItem.supportPackage()) {
                sql = "select * from tbSellOrderItem where fsSeq_M = '" + menuItem.menuBiz.uniq + "' and fiOrderItemKind = '3' ";
            }
            item = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        } else {
            return new ArrayList<>();
        }
        if (ListUtil.isEmpty(item)) {
            return new ArrayList<>();
        }
        if (!menuItem.supportPackage() && item.size() == 1) {
            PrintItemDataBean printItem = item.get(0);
            printItem.fdBackQty = menuItem.menuBiz.voidNum;
            printItem.fsBackReason = menuItem.menuBiz.voidReson;
            /**
             * 配料
             */
            StringBuilder stringBuilder = new StringBuilder("");
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                    if(modifier.menuBiz.buyNum.compareTo(modifier.menuBiz.voidNum) > 0){
                        if (menuItem.supportWeight()) {//称重菜仅计算一份
                            stringBuilder.append(modifier.name).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.menuBiz.buyNum.subtract(modifier.menuBiz.voidNum), modifier.currentUnit.fsOrderUint)).append(";");
                        } else {
                            stringBuilder.append(modifier.name).append("*").append(PrintUtil.optBuyNumAndUnit(modifier.menuBiz.buyNum.subtract(modifier.menuBiz.voidNum).multiply(menuItem.menuBiz.voidNum), modifier.currentUnit.fsOrderUint)).append(";");
                        }
                    }
                }
                printItem.ingredientNotes = stringBuilder.toString();
            }
        } else if (menuItem.supportPackage() && item.size() > 0) {
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
                for (MenuItem menu : menuItem.menuBiz.selectedPackageItems) {
                    for (int i = 0; i < item.size(); i++) {
                        PrintItemDataBean extraItem = item.get(i);
                        if (TextUtils.equals(extraItem.fsseq, menu.menuBiz.uniq)) {
                            //如果明细之前退过了，就不在打印了
                            if(menu.menuBiz.buyNum.compareTo(menu.menuBiz.voidNum) > 0){
                                extraItem.fdBackQty = (menu.menuBiz.buyNum.subtract(menu.menuBiz.voidNum)).multiply(menuItem.menuBiz.voidNum);
                                extraItem.parentItemName = menuItem.name;
                                extraItem.fsBackReason = menuItem.menuBiz.voidReson;
                            }else{
                                item.remove(extraItem);
                            }
                            break;
                        }
                    }
                }
            }
          /*  for (MenuExtra tempExtra : menuItem.menuBiz.selectedPackageItem) {
                if (tempExtra.type == MenuExtraType.PACKAGE) {
                    for (MenuExtraItem tempExtraDetail : tempExtra.itemList) {
                        if (tempExtraDetail.selected && tempExtraDetail.num.compareTo(BigDecimal.ZERO) > 0) {
                            for (int i = 0; i < item.size(); i++) {
                                PrintItemDataBean extraItem = item.get(i);
                                if (TextUtils.equals(extraItem.fsseq, tempExtraDetail.uniq)) {
                                    extraItem.fdBackQty = tempExtraDetail.num.multiply(menuItem.menuBiz.voidNum);
                                }
                            }
                        }
                    }
                }
            }*/
        }
        return item;
    }

    /**
     * 打印退菜单--支持批量退菜
     *
     * @param orderCache   OrderCache
     * @param menuItemList MenuItem
     */
    public static List<Integer> printBatchVoid(final OrderCache orderCache, final List<MenuItem> menuItemList, final List<VoidMenuItemModel> voidMenuItemModels, final String waiterName, final String hostId) {

        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        sell.put("fsMTableName", orderCache.fsmtablename);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        if (!ListUtil.isEmpty(menuItemList) && menuItemList.size() > 0) {
            valueMap.put("orderTime", menuItemList.get(0).menuBiz.createTime);
        }


        List<PrintItemDataBean> sellOrderItemBeanList = new ArrayList<>();

        for (int i = 0; i < menuItemList.size(); i++) {
            MenuItem item = menuItemList.get(i);
            //注释此块代码，是因为已经在前面DishesBizUtil的returnMenuItem方法中赋值了
            /*for (VoidMenuItemModel voidMenuItemModel : voidMenuItemModels) {
                if (TextUtils.equals(voidMenuItemModel.fsseq, item.menuBiz.uniq)) {
                    item.menuBiz.voidNum = voidMenuItemModel.fdbackqty;
                    item.menuBiz.voidReson = voidMenuItemModel.fsbackreason;
                    break;
                }
            }*/

            sellOrderItemBeanList.addAll(formatVoidItem(item));
        }
        boolean hostPrintVoid = DBPrintConfig.needPrintHostVoid();

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemBeanList)
                .setWithCurrentHost(hostPrintVoid)
                .setWithDeptMake(true)
                .setWithDeptTransfer(true)
                .setCurrentHostId(hostId)
                .build();

        int printNO = 0;
        PrintTaskDBModel task;

        List<Integer> printTaskIds = new ArrayList<>();

        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1) {
                continue;
            }

            if (!TextUtils.equals(fsDeptId, "0")) {//过滤掉后厨出菜点 没有配置打印机的退菜单
                PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                if (printer == null) {
                    continue;
                }
            }
            valueMap.put("Dept", deptDBModel);

            List<PrintItemDataBean> list = entry.getValue();
            if (ListUtil.isEmpty(list)) {
                continue;
            }

            task = PrintJSONBuilder.buildPrintTask(
                    orderCache.orderID,
                    orderCache.fsmtablename,
                    orderCache.businessDate,
                    printNO,
                    waiterName,
                    fsDeptId,
                    PrintReportId.RETURN_THE_MENU,
                    hostId,
                    true
            );

            valueMap.remove("SellOrders");


            //TODO 2.5 退菜单不根据制作部门走  读取后台配置 默认打印总单  0/合并打印 1/分开打印 默认0
            if (TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_VOID_MERGE, "0"), "1")) {
                printBatchVoidSingle(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            } else {
                printBatchVoidAll(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            }

// --制作部门用-制作单 1=一菜一切/2=总单/3=总单&一菜一切/4=一份一切
            /*if (deptDBModel.fiIsOneItemCut == 1) {
                printBatchVoidSingle(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            } else if (deptDBModel.fiIsOneItemCut == 2) {
                printBatchVoidAll(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            } else if (deptDBModel.fiIsOneItemCut == 3) {
                printBatchVoidSingle(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
                valueMap.remove("SellOrders");
                printBatchVoidAll(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            } else if (deptDBModel.fiIsOneItemCut == 4) {//1份1切
                printBatchVoidSingleItem(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            } else {
                printBatchVoidAll(valueMap, list, task, deptDBModel.fsPrinterName, printTaskIds);
            }*/
        }
        return printTaskIds;
    }

//    /**
//     * 一份一切退菜单
//     *
//     * @param valueMap
//     * @param list
//     * @param task
//     * @param fsPrinterName
//     * @param printTaskIds
//     */
//    private static void printBatchVoidSingleItem(JSONObject valueMap, List<PrintItemDataBean> list, PrintTaskDBModel task, String fsPrinterName, List<Integer> printTaskIds) {
//        List<PrintItemDataBean> dataList = new ArrayList();
//        int count = 1;
//        int printNO;
//        for (PrintItemDataBean printItemDataBean : list) {
//            count = printItemDataBean.fiIsEditQty == 1 ? 1 : printItemDataBean.fdSaleQty.intValue();
//            for (int j = 0; j < count; j++) {
//                if (printItemDataBean.fiIsEditQty != 1) {
//                    printItemDataBean.fdSaleQty = BigDecimal.ONE;
//                }
//                dataList.clear();
//                dataList.add(printItemDataBean);
//                valueMap.put("SellOrders", dataList);
//                printNO = PrintJSONBuilder.generatePrintNO();
//                valueMap.put("fiPrintNo", printNO);
//                task = task.clone();
//                task.fiPrintNo = printNO;
//                task.uri = "order/void";
//                task.fsPrnData = valueMap.toJSONString();
//                task.fsPrinterName = fsPrinterName;
//                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
//                if (!task.printAtOnce) {
//                    printTaskIds.add(task.fiPrintNo);
//                }
//            }
//        }
//    }

    /**
     * 一菜一切退菜单
     *
     * @param valueMap
     * @param list
     * @param task
     * @param fsPrinterName
     * @param printTaskIds
     */
    private static void printBatchVoidSingle(JSONObject valueMap, List<PrintItemDataBean> list, PrintTaskDBModel task, String fsPrinterName, List<Integer> printTaskIds) {
        int printNO;
        List<PrintItemDataBean> dataList = new ArrayList();
        for (PrintItemDataBean printItemDataBean : list) {
            dataList.clear();
            dataList.add(printItemDataBean);
            valueMap.put("SellOrders", dataList);
            printNO = PrintJSONBuilder.generatePrintNO();
            valueMap.put("fiPrintNo", printNO);
            task = task.clone();
            task.fiPrintNo = printNO;
            task.uri = "order/void";
            task.fsPrnData = valueMap.toJSONString();
            task.fsPrinterName = fsPrinterName;
            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
    }

    /**
     * 总单退菜单
     *
     * @param valueMap
     * @param list
     * @param task
     * @param fsPrinterName
     * @param printTaskIds
     */
    private static void printBatchVoidAll(JSONObject valueMap, List<PrintItemDataBean> list, PrintTaskDBModel task, String fsPrinterName, List<Integer> printTaskIds) {
        valueMap.put("SellOrders", list);
        int printNO = PrintJSONBuilder.generatePrintNO();
        valueMap.put("fiPrintNo", printNO);
        task = task.clone();
        task.uri = "order/void";
        task.fiPrintNo = printNO;
        task.fsPrnData = valueMap.toJSONString();
        task.fsPrinterName = fsPrinterName;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
    }

    /**
     * 打印退配料
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printVoidIngredient(final OrderCache orderCache,
                                                    final MenuItem father, final List<MenuItem> changedList,
                                                    final String waiterName, final String hostId) {
        boolean isAdd = false;
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = 0;
        PrintTaskDBModel task;
        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        if (orderCache.fiSellType == 0) {
            sell.put("fsMTableName", orderCache.fsmtablename);
        } else {
            sell.put("fsMTableName", orderCache.mealNumber);
        }
        sell.put("fiSellType", orderCache.fiSellType);
        sell.put("waiterName", waiterName);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<String, String>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        //valueMap.put("isAdd", isAdd);

        valueMap.put("title", "退配料单");
        valueMap.put("tips", "退菜");

        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
        valueMap.put("beep", beep);
        valueMap.put("orderTime", father.menuBiz.createTime);

        //制作部门
        List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();
        for (MenuItem item : changedList) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelByID(item.itemID);
            MenuitemDBModel fatherItemDB = MenuDBUtil.getMenuDBModelByID(father.itemID);
            PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
            sellOrderItemBean.fiIsMulDept = fatherItemDB.fiIsMulDept;
            sellOrderItemBean.fsItemName = itemDB.fsItemName;
            sellOrderItemBean.fdSaleQty = item.menuBiz.buyNum;
            sellOrderItemBean.fsOrderUint = item.currentUnit.fsOrderUint;
            sellOrderItemBean.fiOrderItemKind = 4;
            sellOrderItemBean.fsDeptId = fatherItemDB.fsDeptId;
            sellOrderItemBean.fiItemCd = father.itemID;
            sellOrderItemBean.ingredientFatherItemCd = father.itemID;
            sellOrderItemBean.fdBackQty = item.menuBiz.voidNum;
            sellOrderItemBean.fsBackReason = item.menuBiz.voidReson;
            sellOrderItemDBModels.add(sellOrderItemBean);
        }
        boolean withDeptTransfer = false;
        if (orderCache.dinnerModel()) {
            withDeptTransfer = true;
        }

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemDBModels)
                .setWithCurrentHost(true)
                .setWithDeptMake(true)
                .setWithDeptTransfer(withDeptTransfer)
                .setCurrentHostId(hostId)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是退菜的时候，打印部门是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1 && !isAdd) {
                continue;
            }
            valueMap.put("Dept", deptDBModel);
            List<PrintItemDataBean> list = entry.getValue();
            if (!ListUtil.isEmpty(list)) {
                valueMap.put("ingredientItems", list);
                printNO = PrintJSONBuilder.generatePrintNO();
                valueMap.put("fiPrintNo", printNO);
                task = PrintJSONBuilder.buildPrintTask(
                        orderCache.orderID,
                        orderCache.fsmtablename,
                        orderCache.businessDate,
                        printNO,
                        waiterName,
                        fsDeptId,
                        PrintReportId.RETURN_THE_MENU,
                        hostId, true);
                task.uri = "order/voidIngredient";
                task.fsPrnData = valueMap.toJSONString();
                task.fsPrinterName = deptDBModel.fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                if (!task.printAtOnce) {
                    printTaskIds.add(task.fiPrintNo);
                }
            }
        }
        return printTaskIds;
    }


    /**
     * 打印加配料单
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printAddIngredient(final OrderCache orderCache,
                                                   final MenuItem father, final List<MenuItem> changedList,
                                                   final String waiterName, final String hostId) {
        boolean isAdd = true;
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = 0;
        PrintTaskDBModel task;
        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        if (orderCache.fiSellType == 0) {
            sell.put("fsMTableName", orderCache.fsmtablename);
        } else {
            sell.put("fsMTableName", orderCache.mealNumber);
        }
        sell.put("fiSellType", orderCache.fiSellType);
        sell.put("waiterName", waiterName);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<String, String>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        //valueMap.put("isAdd", isAdd);

        valueMap.put("title", "加配料单");
        valueMap.put("tips", "加菜");

        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
        valueMap.put("beep", beep);

        //制作部门
        List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();
        for (MenuItem item : changedList) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelByID(item.itemID);
            MenuitemDBModel fatherItemDB = MenuDBUtil.getMenuDBModelByID(father.itemID);
            PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
            sellOrderItemBean.fiIsMulDept = fatherItemDB.fiIsMulDept;
            sellOrderItemBean.fsItemName = itemDB.fsItemName;
            sellOrderItemBean.fdSaleQty = item.menuBiz.buyNum;
            sellOrderItemBean.fsOrderUint = item.currentUnit.fsOrderUint;
            sellOrderItemBean.fiOrderItemKind = 4;
            sellOrderItemBean.fsDeptId = fatherItemDB.fsDeptId;
            sellOrderItemBean.fiItemCd = father.itemID;
            sellOrderItemBean.ingredientFatherItemCd = father.itemID;
            sellOrderItemDBModels.add(sellOrderItemBean);
        }
        boolean withDeptTransfer = false;
        if (orderCache.dinnerModel()) {
            withDeptTransfer = true;
        }

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemDBModels)
                .setWithCurrentHost(true)
                .setWithDeptMake(true)
                .setWithDeptTransfer(withDeptTransfer)
                .setCurrentHostId(hostId)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是退菜的时候，打印部门是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1 && !isAdd) {
                continue;
            }
            valueMap.put("Dept", deptDBModel);
            List<PrintItemDataBean> list = entry.getValue();
            if (!ListUtil.isEmpty(list)) {
                valueMap.put("ingredientItems", list);
                printNO = PrintJSONBuilder.generatePrintNO();
                valueMap.put("fiPrintNo", printNO);
                task = PrintJSONBuilder.buildPrintTask(
                        orderCache.orderID,
                        orderCache.fsmtablename,
                        orderCache.businessDate,
                        printNO,
                        waiterName,
                        fsDeptId,
                        PrintReportId.INGREDIENT,
                        hostId, true);
                task.uri = "order/addIngredient";
                task.fsPrnData = valueMap.toJSONString();
                task.fsPrinterName = deptDBModel.fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                if (!task.printAtOnce) {
                    printTaskIds.add(task.fiPrintNo);
                }
            }
        }
        return printTaskIds;
    }


    /**
     * 打印退套餐子项
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printVoidPackageItems(final OrderCache orderCache,
                                                      final MenuItem father, final List<MenuItem> changedList,
                                                      final String waiterName, final String hostId) {
        boolean isAdd = false;
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = 0;
        PrintTaskDBModel task;
        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        if (orderCache.fiSellType == 0) {
            sell.put("fsMTableName", orderCache.fsmtablename);
        } else {
            sell.put("fsMTableName", orderCache.mealNumber);
        }
        sell.put("fiSellType", orderCache.fiSellType);
        sell.put("waiterName", waiterName);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<String, String>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        //valueMap.put("isAdd", isAdd);

        valueMap.put("title", "退套餐子项单");
        valueMap.put("tips", "退菜");

        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
        valueMap.put("beep", beep);

        // 套餐名称
        valueMap.put("packageName", father.name);
        valueMap.put("orderTime", father.menuBiz.createTime);

        //制作部门
        List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();
        for (MenuItem item : changedList) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelByID(item.itemID);
            MenuitemDBModel fatherItemDB = MenuDBUtil.getMenuDBModelByID(father.itemID);
            PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
            sellOrderItemBean.fiIsMulDept = fatherItemDB.fiIsMulDept;
            sellOrderItemBean.fsItemName = itemDB.fsItemName;
            sellOrderItemBean.fdSaleQty = item.menuBiz.buyNum;
            sellOrderItemBean.fsOrderUint = item.currentUnit.fsOrderUint;
            sellOrderItemBean.fiOrderItemKind = 3;
            if (fatherItemDB.fiIsSetDtlPrn == 1) {// 套餐头部门
                sellOrderItemBean.fsDeptId = fatherItemDB.fsDeptId;
            } else if (fatherItemDB.fiIsSetDtlPrn == 2) {// 套餐明细部门
                sellOrderItemBean.fsDeptId = itemDB.fsDeptId;
            }
            sellOrderItemBean.fiItemCd = itemDB.fiItemCd;
            sellOrderItemBean.packageFatherItemCd = father.itemID;
            sellOrderItemBean.fsSpecialNote = item.menuBiz.fsSpecialNote;
            sellOrderItemBean.fsGeneralNote = item.menuBiz.fsGeneralNote;
            sellOrderItemBean.batchSpecialNote = item.menuBiz.batchSpecialNote;
            sellOrderItemBean.fsWholeNote = item.menuBiz.batchGeneralNote;
            sellOrderItemBean.fsNote = item.menuBiz.note;
            sellOrderItemBean.fdBackQty = item.menuBiz.voidNum;
            sellOrderItemBean.fsBackReason = item.menuBiz.voidReson;
            sellOrderItemDBModels.add(sellOrderItemBean);
        }
        boolean withDeptTransfer = false;
        if (orderCache.dinnerModel()) {
            withDeptTransfer = true;
        }

        // 读后台配置，站点是否打印退菜单
        boolean hostPrintVoid = DBPrintConfig.needPrintHostVoid();

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemDBModels)
                .setWithCurrentHost(hostPrintVoid)
                .setWithDeptMake(true)
                .setWithDeptTransfer(withDeptTransfer)
                .setCurrentHostId(hostId)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是退菜的时候，打印部门是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1 && !isAdd) {
                continue;
            }
            valueMap.put("Dept", deptDBModel);
            List<PrintItemDataBean> list = entry.getValue();
            if (!ListUtil.isEmpty(list)) {
                valueMap.put("packageItems", list);
                printNO = PrintJSONBuilder.generatePrintNO();
                valueMap.put("fiPrintNo", printNO);
                task = PrintJSONBuilder.buildPrintTask(
                        orderCache.orderID,
                        orderCache.fsmtablename,
                        orderCache.businessDate,
                        printNO,
                        waiterName,
                        fsDeptId,
                        PrintReportId.RETURN_THE_MENU,
                        hostId, true);
                task.uri = "order/voidPackageItems";
                task.fsPrnData = valueMap.toJSONString();
                task.fsPrinterName = deptDBModel.fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                if (!task.printAtOnce) {
                    printTaskIds.add(task.fiPrintNo);
                }
            }
        }
        return printTaskIds;
    }


    /**
     * 打印加套餐子项
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printAddPackageItems(final OrderCache orderCache,
                                                     final MenuItem father, final List<MenuItem> changedList,
                                                     final String waiterName, final String hostId) {
        boolean isAdd = true;
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = 0;
        PrintTaskDBModel task;
        JSONObject valueMap = new JSONObject();
        JSONObject sell = new JSONObject();
        sell.put("fsSellNo", orderCache.orderID);
        if (orderCache.fiSellType == 0) {
            sell.put("fsMTableName", orderCache.fsmtablename);
        } else {
            sell.put("fsMTableName", orderCache.mealNumber);
        }
        sell.put("fiSellType", orderCache.fiSellType);
        sell.put("waiterName", waiterName);
        valueMap.put("Sell", sell);
        HashMap<String, String> sysModeMap = new HashMap<String, String>();
        sysModeMap.put("PrintTime", DateUtil.getCurrentDateTime("HH:mm"));
        valueMap.put("SysMode", sysModeMap);
        //valueMap.put("isAdd", isAdd);

        valueMap.put("title", "加套餐子项单");
        valueMap.put("tips", "加菜");

        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
        valueMap.put("beep", beep);

        // 套餐名称
        valueMap.put("packageName", father.name);

        //制作部门
        List<PrintItemDataBean> sellOrderItemDBModels = new ArrayList<>();
        for (MenuItem item : changedList) {
            MenuitemDBModel itemDB = MenuDBUtil.getMenuDBModelByID(item.itemID);
            MenuitemDBModel fatherItemDB = MenuDBUtil.getMenuDBModelByID(father.itemID);
            PrintItemDataBean sellOrderItemBean = new PrintItemDataBean();
            sellOrderItemBean.fiIsMulDept = fatherItemDB.fiIsMulDept;
            sellOrderItemBean.fsItemName = itemDB.fsItemName;
            if (father.isGift()) {
                sellOrderItemBean.fsItemName = "[赠]" + sellOrderItemBean.fsItemName;
            }
            sellOrderItemBean.fdSaleQty = item.menuBiz.buyNum;
            sellOrderItemBean.fsOrderUint = item.currentUnit.fsOrderUint;
            sellOrderItemBean.fiOrderItemKind = 3;
            if (fatherItemDB.fiIsSetDtlPrn == 1) {// 套餐头部门
                sellOrderItemBean.fsDeptId = fatherItemDB.fsDeptId;
            } else if (fatherItemDB.fiIsSetDtlPrn == 2) {// 套餐明细部门
                sellOrderItemBean.fsDeptId = itemDB.fsDeptId;
            }
            sellOrderItemBean.fiItemCd = itemDB.fiItemCd;
            sellOrderItemBean.packageFatherItemCd = father.itemID;
            sellOrderItemBean.fsSpecialNote = item.menuBiz.fsSpecialNote;
            sellOrderItemBean.fsGeneralNote = item.menuBiz.fsGeneralNote;
            sellOrderItemBean.batchSpecialNote = item.menuBiz.batchSpecialNote;
            sellOrderItemBean.fsWholeNote = item.menuBiz.batchGeneralNote;
            sellOrderItemBean.fsNote = item.menuBiz.note;
            sellOrderItemDBModels.add(sellOrderItemBean);
        }
        boolean withDeptTransfer = false;
        if (orderCache.dinnerModel()) {
            withDeptTransfer = true;
        }

        GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                .setItemList(sellOrderItemDBModels)
                .setWithCurrentHost(true)
                .setWithDeptMake(true)
                .setWithDeptTransfer(withDeptTransfer)
                .setCurrentHostId(hostId)
                .build();
        for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
            String fsDeptId = entry.getKey();
            DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
            //如果deptID为0.则使用站点打印机
            if (deptDBModel == null) {
                continue;
            }
            /**
             * 如果是退菜的时候，打印部门是制作部门，但是不能打印退菜单，则continue
             */
            if (deptDBModel.fiDeptCls == 2 && deptDBModel.fiIsBackBill != 1 && !isAdd) {
                continue;
            }
            valueMap.put("Dept", deptDBModel);
            List<PrintItemDataBean> list = entry.getValue();
            if (!ListUtil.isEmpty(list)) {
                valueMap.put("packageItems", list);
                printNO = PrintJSONBuilder.generatePrintNO();
                valueMap.put("fiPrintNo", printNO);
                task = PrintJSONBuilder.buildPrintTask(
                        orderCache.orderID,
                        orderCache.fsmtablename,
                        orderCache.businessDate,
                        printNO,
                        waiterName,
                        fsDeptId,
                        PrintReportId.PACKAGE_ITEM,
                        hostId, true);
                task.uri = "order/addPackageItems";
                task.fsPrnData = valueMap.toJSONString();
                task.fsPrinterName = deptDBModel.fsPrinterName;

                CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                if (!task.printAtOnce) {
                    printTaskIds.add(task.fiPrintNo);
                }
            }
        }
        return printTaskIds;
    }


    /**
     * KDS非算法制作单
     *
     * @param orderCache OrderCache | 订单信息
     * @param hostId     String | 站点信息
     * @param deptId     String | 部门信息
     * @param seq        String | 点餐批次
     * @param menuUniq   String | 菜品唯一标识
     */
    public static void kdsGMakeOrder(final OrderCache orderCache, final String hostId, final String deptId, final String seq, final List<String> menuUniq) {
        BusinessExecutor.executeNoWait((ASyncExecute<List<Integer>>) () -> {
            if (orderCache.shareShopOrder()) {
                return new ArrayList<>();
            }
            JSONObject data = new JSONObject();
            //构建小票内菜品信息
            ArrayList<PrintItemDataBean> printItems = buildPrintItemsByOrderSeq(orderCache.orderID, seq, "");
            //缓存业务中心打印不了的 print id
            ArrayList<Integer> printTaskIds = new ArrayList<>();

            SellDBModel sellDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", SellDBModel.class);
            if (!TextUtils.isEmpty(sellDBModel.fsCustMobile) && sellDBModel.fsCustMobile.length() > 4) {
                sellDBModel.fsCustMobile = sellDBModel.fsCustMobile.substring(sellDBModel.fsCustMobile.length() - 4, sellDBModel.fsCustMobile.length());
            }
            String printTime = DateUtil.getCurrentTime();
            JSONObject times = new JSONObject();
            data.put("Sell", sellDBModel);
            if (!TextUtils.isEmpty(seq)) {
                if (seq.contains(",")) {
                    data.put("fsCreateUserName", orderCache.waiterName);
                } else {
                    //将加菜标识存到打印数据里，打印制作单时，需要根据它是否显示加菜标识
                    data.put("addMenuLabel", getAddMenuLabel(seq));
                    data.put("fsCreateUserName", orderCache.optSeqModel(StringUtil.toInt(seq, 0)).createWaiterName);
                }
            } else {
                data.put("fsCreateUserName", orderCache.waiterName);
            }
            times.put("PrintTime", printTime);
            data.put("SysMode", times);
            if (TextUtils.equals("99", orderCache.fsBillSourceId)) {
                data.put("eatType", orderCache.eatType == EatType.EAT_IN ? "(堂食)" : orderCache.eatType == EatType.EAT_TAKE_OUT ? "(外带)" : "");
            }

            if (TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.PRINT_BAR_CODE), "1")) {
                String barcode = formatCallNum(sellDBModel);
                if (!TextUtils.equals("000", barcode)) {
                    String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                    data.put("barCode", barcode + "*1" + shopId);
                }
            }

            String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
            data.put("beep", beep);

            if (printItems.size() > 0) {
                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(printItems)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(true)
                        .setWithDeptTransfer(false)
                        .setCheckArea(true)
                        .setTableAreaID(orderCache.fsmareaid)
                        .setCurrentHostId(hostId)
                        .build();

                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                    String fsDeptId = entry.getKey();
                    DeptDBModel deptDBModel = processor.deptInfo.get(fsDeptId);
                    if (deptDBModel == null) {
                        continue;
                    }

                    // 非指定打印部门直接略过
                    if (!TextUtils.isEmpty(deptId) && !TextUtils.equals(deptDBModel.fsDeptId, deptId)) {
                        continue;
                    }

                    data.put("Dept", deptDBModel);

                    /**
                     * 打印份数
                     */
                    int fiPrintCopies = deptDBModel.fiPrintCopies;
                    if (fiPrintCopies == 0) {
                        fiPrintCopies = 1;
                    }

                    PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
                    if (printer == null) {
                        String info = "打印制作单失败,没有找到启用的打印机。部门ID[" + fsDeptId + "]";
                        info = new AirPrinterSelect().getAirDeptIDNotFound(fsDeptId, info);
                        if (!TextUtils.isEmpty(info)) {
                            ToastUtil.showToast(info);
                        }
                        RunTimeLog.addLog(RunTimeLog.PAY_FAILE, info);
                        continue;
                    }
                    List<PrintItemDataBean> list = entry.getValue();
                    if (ListUtil.isEmpty(list)) {
                        continue;
                    }

                    List<PrintItemDataBean> tarMenu = new ArrayList<>();
                    if (!ListUtil.isEmpty(menuUniq)) {
                        for (PrintItemDataBean bean : list) {
                            if (menuUniq.contains(bean.fsseq)) {
                                tarMenu.add(bean);
                            }
                        }
                    } else {
                        tarMenu = list;
                    }

                    data.remove("SellOrder");
                    data.remove("SellOrders");
                    data.remove("beep");

                    boolean isTsc = "TSC".equalsIgnoreCase(printer.fsCommandType);

                    if (isTsc) {//拦截TSC打印
                        boolean printerTscSingleMake = TextUtils.equals(ClientMetaUtil.getConfig(META.T_TSC_PRINTER, "1"), "1");//标签是否打印        0/不打印 1 打印
                        if (!printerTscSingleMake) {
                            break;
                        }
                    } else {//拦截厨房打印
                        boolean isPrinterMakeOrder = TextUtils.equals(ClientMetaUtil.getConfig(META.T_KITCHEN_PRINTER, "1"), "1");
                        if (!isPrinterMakeOrder) {
                            break;
                        }
                    }

                    for (int i = 0; i < fiPrintCopies; i++) {
                        if (isTsc) {
                            printSingleMake(true, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, processor.tscCount, beep);
                        } else {
                            // 制作单 1=一菜一切/2=总单/3=总单&一菜一切/4=一份一切
                            if (deptDBModel.fiIsOneItemCut == 1) {
                                printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, processor.tscCount, beep);
                            } else if (deptDBModel.fiIsOneItemCut == 2) {
                                data.put("beep", beep);
                                printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, seq);
                            } else if (deptDBModel.fiIsOneItemCut == 3) {
                                printSingleMake(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, processor.tscCount, beep);
                                data.put("beep", beep);
                                printAllMake(data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, seq);
                            } else if (deptDBModel.fiIsOneItemCut == 4) {
                                printSingle(false, data, orderCache, fsDeptId, printer.fsPrinterName, hostId, tarMenu, printTaskIds, processor.tscCount, beep);
                            }
                        }
                    }
                }
            }
            return printTaskIds;
        });
    }

    /**
     * KDS智能算法制作单打印
     *
     * @param fsDeptId String | 制作部门id
     * @param seq      String | 每一锅并菜的标识
     */
    public static void kdsAMakeOrder(String fsDeptId, String seq, BigDecimal num, String hostId) {
        BusinessExecutor.executeNoWait((ASyncExecute<List<Integer>>) () -> {
            List<Integer> taskIdList = new ArrayList<>();
            if (TextUtils.isEmpty(fsDeptId) || TextUtils.isEmpty(seq)) {
                return taskIdList;
            }

            // 根据部门查询打印机
            PrinterDBModel printer = DeviceDBUtil.getPrinterByDeptID(fsDeptId);
            if (printer == null) {
                String info = "打印制作单失败,没有找到启用的打印机。部门ID[" + fsDeptId + "]";
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, info);
                info = new AirPrinterSelect().getAirDeptIDNotFound(fsDeptId, info);
                if (!TextUtils.isEmpty(info)) {
                    ToastUtil.showToast(info);
                }
                return taskIdList;
            }
            boolean isTsc = "TSC".equalsIgnoreCase(printer.fsCommandType);
            if (isTsc) {
                //拦截TSC打印
                boolean printerTscSingleMake = TextUtils.equals(ClientMetaUtil.getConfig(META.T_TSC_PRINTER, "1"), "1");
                if (!printerTscSingleMake) {
                    return taskIdList;
                }
            } else {
                //拦截厨房打印
                boolean isPrinterMakeOrder = TextUtils.equals(ClientMetaUtil.getConfig(META.T_KITCHEN_PRINTER, "1"), "1");
                if (!isPrinterMakeOrder) {
                    return taskIdList;
                }
            }

            // 根据部门查询绑定的站点
            HostDBModel host = KDSUtils.queryHostByDeptId(fsDeptId);
            if (host == null) {
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "根据部门[" + fsDeptId + "]未能查询到绑定的站点");
                return taskIdList;
            }

            JSONObject data = new JSONObject();

            data.put("Dept", DeptDBUtils.queryById(fsDeptId));

            // 印号
            int fiPrintNo = PrintJSONBuilder.generatePrintNO();
            KDSUtils.updateMakePrintNoByPotId(seq, fsDeptId, fiPrintNo);
            data.put("fiPrintNo", fiPrintNo);

            List<PrintItemDataBean> printItems = buildKdsPrintItem(fsDeptId, seq, num);
            LogUtil.logBusiness("----KDS----fiPrintNo--------" + fiPrintNo + "-----seq-----" + seq + "-------printItems-------" + JSON.toJSONString(printItems));

            if (!ListUtil.isEmpty(printItems)) {
                List<PrintItemDataBean> tarItem = printItems.subList(0, 1);
                data.put("SellOrder", printItems);
            }

            String printTime = DateUtil.getCurrentTime();
            JSONObject times = new JSONObject();
            times.put("PrintTime", printTime);
            data.put("SysMode", times);

            String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
            data.put("beep", beep);

            // 是否开启扫码划菜
            if (host.fiIsOpenBarcode == 1) {
                data.put("barCode", seq);
            }

            // 构建打印任务
            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    "",
                    "",
                    HostUtil.getHistoryBusineeDate(""),
                    fiPrintNo,
                    "",
                    fsDeptId,
                    PrintReportId.MAKE_THE_TOTAL_LIST_SINGLE,
                    hostId,
                    true);
            task.uri = "order/kdsMake";
            task.fsPrnData = data.toJSONString();
            task.fsPrinterName = printer.fsPrinterName;
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "PrintOrderUtil#kdsAMakeOrder 构建的打印任务:\n" + JSON.toJSONString(task));

            //控制第二语言小票打印
            MenuPrinterTaskUtil.buildMenuPrinterTaskAndPrint(taskIdList, task, data);
            return taskIdList;
        });
    }

    /**
     * 使用tbsellorderitem查询套餐名称
     *
     * @param strs 套餐头菜品seq集合
     * @return
     */
    private static HashMap<String, String> queryPackageNames(List<String> strs) {
        String sql = "select fsSeq,fsItemName from tbSellOrderItem where fsSeq in (" + ListUtil.optSqlParams(strs) + ")";
        List<JSONObject> items = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
        HashMap<String, String> m = new HashMap<>();
        if (ListUtil.isEmpty(items)) {
            return m;
        }
        for (JSONObject item : items) {
            m.put(item.getString("fsSeq"), item.getString("fsItemName"));
        }
        return m;
    }

    /**
     * 查询配料明细id
     *
     * @param single
     * @return
     */
    private static List<String> queryIngredientIds(List<String> single) {
        String sql = "select fsSeq from tbSellOrderItem where fiOrderItemKind='4' and fsSeq_M in (" + ListUtil.optSqlParams(single) + ")";
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
    }

    /**
     * @param deptId
     * @param pot
     * @param num    拼锅下的dishId数量
     * @return
     */
    private static List<PrintItemDataBean> buildKdsPrintItem(String deptId, String pot, BigDecimal num) {
        //只有名称相同的菜品才会拼锅
        String sqlMenu = "select fiItemCd,fsOriginSeq,name,fsPotSeq,fsMenuClsId,fiItemKind,fiState,fsSellNo,fiSellType,fsDeptId " +
                "from tbKdsMenuItemState where fsPotSeq = '" + pot + "' and fsDeptId = '" + deptId + "' group by fsPotSeq";
        List<JSONObject> items = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sqlMenu);
        if (ListUtil.isEmpty(items)) {
            return null;
        }

        List<PrintItemDataBean> result = new ArrayList<>();

        List<PrintItemDataBean> wmBeans = buildWmPrintItem(items, num);
        if (!ListUtil.isEmpty(wmBeans)) {
            result.addAll(wmBeans);
        }

        List<PrintItemDataBean> dinnerBeans = buildKdsDinnerPrintItem(items, num);
        if (!ListUtil.isEmpty(dinnerBeans)) {
            result.addAll(dinnerBeans);
        }
        return result;
    }

    private static List<PrintItemDataBean> buildWmPrintItem(List<JSONObject> items, BigDecimal num) {
        List<PrintItemDataBean> printItemDataBeans = new ArrayList<>();

        for (JSONObject item : items) {
            int sellType = item.getIntValue("fiSellType");

            if (sellType == 2) {
                PrintItemDataBean bean = new PrintItemDataBean();
                bean.fiItemCd = item.getString("fiItemCd");
                bean.fiOrderItemKind = item.getIntValue("fiItemKind");
                bean.fsDeptId = item.getString("fsDeptId");
                bean.fsMenuClsId = item.getString("fsMenuClsId");
                bean.fdSaleQty = num;//todo 其他的菜品如何标记呢？

                String name = item.getString("name");
                String[] nameItem = name.split("%_#");
                if (nameItem.length >= 1) {
                    bean.fsItemName = "(外卖)" + nameItem[0].substring(2);
                }
                if (nameItem.length >= 2) {
                    bean.fsOrderUint = nameItem[1].substring(2);
                }
                if (nameItem.length >= 3) {
                    String fsNote = nameItem[2].substring(2);
                    bean.ingredientNotes += fsNote;
                }
                if (nameItem.length >= 4) {
                    bean.ingredientNotes = nameItem[3].substring(2);
                }
                if (nameItem.length >= 5) {
                    bean.fsGeneralNote = nameItem[4].substring(2);
                }
                if (nameItem.length >= 6) {
                    bean.fsSpecialNote = nameItem[4].substring(2);
                }
                if (nameItem.length >= 7) {
                    bean.fiIsEditQty = 1;
                }

                printItemDataBeans.add(bean);
            }
        }
        return printItemDataBeans;
    }

    private static List<PrintItemDataBean> buildKdsDinnerPrintItem(List<JSONObject> items, BigDecimal num) {
        List<String> single = new ArrayList<>();
        List<String> packageSeq = new ArrayList<>();
        for (JSONObject item : items) {
            int sellType = item.getIntValue("fiSellType");

            if (sellType != 2) {
                single.add(item.getString("fsOriginSeq"));
                if (TextUtils.equals(item.getString("fiItemKind"), "3")) {
                    packageSeq.add(item.getString("fsOriginSeq_M"));
                }
            }
        }
        if (ListUtil.isEmpty(single)) {
            return null;
        }

        List<String> ingredientIds = queryIngredientIds(single);
        if (!ListUtil.isEmpty(ingredientIds)) {
            single.addAll(ingredientIds);
        }

        //找出配料菜品id明细
        String sql = "select fsMenuClsId," +
                "(case fiItemMakeSte " +
                " when 2 then '[等叫]' " +
                " when 4 then '[划菜]' " +
                " when 8 then '[打包]' " +
                " else '' end) as SfiItemMakeState, " +
                " *,(case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName as fsItemName,  " +
                "(case when fiIsEditQty = 1 then (fdSaleQty-fdBackQty) else (case when fiOrderItemKind =4 then (fdSaleQty-fdBackQty) else '" + num + "' end) end) as fdSaleQty" +
                " from tbSellOrderItem where fsSeq in(" + ListUtil.optSqlParams(single) + ")";
        List<PrintItemDataBean> printItemDataBeans = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
        if (ListUtil.isEmpty(printItemDataBeans)) {
            return null;
        }
        //套餐明细给个套餐头名称
        HashMap<String, String> pa = queryPackageNames(packageSeq);
        List<PrintItemDataBean> ingredientDBModels = new ArrayList<>();
        for (int i = 0; i < printItemDataBeans.size(); i++) {
            PrintItemDataBean printItemDataBean = printItemDataBeans.get(i);

            if (printItemDataBean.fiOrderItemKind == 3) {
                printItemDataBean.parentItemName = pa.get(printItemDataBean.fsSeq_M);
            } else if (printItemDataBean.fiOrderItemKind == 4) {
                ingredientDBModels.add(printItemDataBean);
                printItemDataBeans.remove(printItemDataBean);
                i--;
            }
        }
        //构建配料菜品信息
        if (!ListUtil.isEmpty(ingredientDBModels) && ingredientDBModels.size() > 0) {
            for (PrintItemDataBean sellOrderItemBean : printItemDataBeans) {
                for (int i = 0; i < ingredientDBModels.size(); i++) {
                    PrintItemDataBean ingredientItem = ingredientDBModels.get(i);
                    if (TextUtils.equals(sellOrderItemBean.fsseq, ingredientItem.fsSeq_M)) {
                        sellOrderItemBean.ingredientList.add(ingredientItem);
                        sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + ingredientItem.fsItemName + "*" + PrintUtil.optBuyNumAndUnit(ingredientItem.fdSaleQty, ingredientItem.fsOrderUint) + ";";

                        if (i != ingredientDBModels.size() - 1) {
                            sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + "\n";
                        }
                    }
                }
            }
        }
        return printItemDataBeans;
    }

    public static List<PrintItemDataBean> buildKdsPrintItemByPot(String deptId, String pot, BigDecimal num) {
        String sqlMenu = "select fsOriginSeq from tbKdsMenuItemState where fsPotSeq = '" + pot + "' and fsDeptId = '" + deptId + "' group by fsOriginSeq";
        List<String> originMenuList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sqlMenu);
        if (ListUtil.isEmpty(originMenuList)) {
            return null;
        }

        String sql = "select fsMenuClsId," +
                "(case fiItemMakeSte " +
                " when 2 then '[等叫]' " +
                " when 4 then '[划菜]' " +
                " when 8 then '[打包]' " +
                " else '' end) as SfiItemMakeState, " +
                " parentItemName, *,(case fdGiftQty when 0 then '' else '[赠]' end)||fsItemName as fsItemName, (case when fiIsEditQty = 1 then fdSaleQty else '" + num + "' end) as fdSaleQty " +
                " from tbSellOrderItem a " +
                " left join " +
                " (select fsseq parentseq, " +
                " fsItemName parentItemName " +
                " from tbSellOrderItem " +
                " where fsSeq in (" + ListUtil.optSqlParams(originMenuList) + ") and fiOrderItemKind = '2' ) b " +
                " on " +
                " a.fsseq_m = b.parentseq  " +
                " where  fiIsPrn='1' ";

        /**
         * 所有单品和套餐明细
         */
        String singleItemSql = sql + "and fsSeq in (" + ListUtil.optSqlParams(originMenuList) + ")" + " and fiOrderItemKind in ('1', '3') ";
        List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, singleItemSql, PrintItemDataBean.class);
        if (sellOrderItemDBModels == null) {
            sellOrderItemDBModels = new ArrayList<>();
        }

        /**
         * 所有配料
         */
        String ingredientSql = sql + " and fsSeq_M in (" + ListUtil.optSqlParams(originMenuList) + ") and fiOrderItemKind in ('4') ";
        List<PrintItemDataBean> ingredientDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, ingredientSql, PrintItemDataBean.class);
        if (ListUtil.isEmpty(ingredientDBModels)) {
            ingredientDBModels = new ArrayList<>();
        }

        /**
         * 配料作为要求打印
         */
        if (!ListUtil.isEmpty(ingredientDBModels) && ingredientDBModels.size() > 0) {
            for (PrintItemDataBean sellOrderItemBean : sellOrderItemDBModels) {
                for (int i = 0; i < ingredientDBModels.size(); i++) {
                    PrintItemDataBean ingredientItem = ingredientDBModels.get(i);
                    if (TextUtils.equals(sellOrderItemBean.fsseq, ingredientItem.fsSeq_M)) {
                        sellOrderItemBean.ingredientList.add(ingredientItem);
                        sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + ingredientItem.fsItemName + "*" + PrintUtil.optBuyNumAndUnit(ingredientItem.fdSaleQty, ingredientItem.fsOrderUint) + ";";

                        if (i != ingredientDBModels.size() - 1) {
                            sellOrderItemBean.ingredientNotes = sellOrderItemBean.ingredientNotes + "\n";
                        }
                    }
                }
            }
        }
        return sellOrderItemDBModels;
    }

    /**
     * kds传菜单
     *
     * @param orderCache
     * @param hostId
     * @param fsDeptId
     * @param uniqList
     * @return
     */
    public static List<Integer> kdsGPassTo(final OrderCache orderCache, final String hostId, String fsDeptId, List<String> uniqList, int num) {
        List<Integer> printTaskIds = new ArrayList<>();
        if (orderCache.shareShopOrder()) {
            return printTaskIds;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {

                JSONObject datas = new JSONObject();

                int lastSeq = orderCache.optLastSeq();
                OrderSeqModel model = orderCache.optSeqModel(lastSeq);
                datas.put("PrintUser", orderCache.waiterName);

                String date = orderCache.businessDate;
                String sql = "select fsseq, fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsNote,fsDeptId,  fiIsMulDept,fiItemCd,fiIsEditQty," +
                        "(case when fiIsEditQty = 1 then (fdSaleQty-fdBackQty) else (case when fiOrderItemKind =4 then (fdSaleQty-fdBackQty)*" + num + " else '" + num + "' end) end) as fdSaleQty," +
                        " (case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState," +
                        " fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind <> '3'" +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'";

                String sql2 = "select fsseq,fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsDeptId,fiIsMulDept,fiItemCd,fiIsEditQty, (fdSaleQty-fdBackQty) as fdSaleQty," +
                        "(case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState, fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind = '3' " +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'";

                List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
                if (sellOrderItemDBModels == null) {
                    sellOrderItemDBModels = new ArrayList<>();
                }

                List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintItemDataBean.class);
                if (SLITList == null) {
                    SLITList = new ArrayList<>();
                }

                for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {
                    for (PrintItemDataBean itemExModel : SLITList) {
                        if (itemExModel.fiOrderItemKind == 3 && itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                            itemExModel.parentItemName = statementSellItemModel.fsItemName;
                        }
                    }
                }

                sellOrderItemDBModels.addAll(SLITList);

                /**
                 * 去除套餐头--套餐头不打印
                 */
                for (int i = 0; i < sellOrderItemDBModels.size(); i++) {
                    if (sellOrderItemDBModels.get(i).fiOrderItemKind == 2) {
                        sellOrderItemDBModels.remove(i);
                        i--;
                    }
                }

                CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo =" + orderCache.orderID, CustomSellDBModel.class);
                sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                        "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
                datas.put("Sell", sell);


                String printPassto = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_PASSTO, "0");
                if (TextUtils.equals("0", printPassto) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null) {
                        if (!TextUtils.isEmpty(memberComments.memberLevel)) {
                            datas.put("memberLevel", memberComments.memberLevel);
                        }
                        if (!TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("sex", memberComments.sex);
                        }
                        if (memberComments.cardBalance.compareTo(BigDecimal.ZERO) >= 0 && !TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("cardBalance", memberComments.cardBalance);
                        }
                    }
                }

                String cloudBuffet = CommonDBUtil.getConfigWithDefault(DBPrintConfig.MWBYD_CLOUD_BUFFET, "0");
                if (TextUtils.equals("1", cloudBuffet) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null && memberComments.verifyComments()) {
                        if (memberComments.service_score > 0) {
                            datas.put("serviceScore", SymbolUtils.queryPentagram(memberComments.service_score));
                        }
                        if (!TextUtils.isEmpty(memberComments.messages)) {
                            datas.put("commentsMessages", memberComments.messages);
                        }
                        if (!TextUtils.isEmpty(memberComments.tags)) {
                            datas.put("tags", memberComments.tags);
                        }
                    }
                }

                SellDBModel sellDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo ='" + orderCache.orderID + "'", SellDBModel.class);
                if (TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.PRINT_BAR_CODE), "1")) {
                    String barcode = formatCallNum(sellDBModel);
                    if (!TextUtils.equals("000", barcode)) {
                        String shopId = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                        datas.put("barCode", barcode + "*1" + shopId);
                    }
                }

                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(sellOrderItemDBModels)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(false)
                        .setWithDeptTransfer(true)
                        .build();
                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                    String deptID = entry.getKey();

                    List<PrintItemDataBean> list = entry.getValue();

                    // 过滤打印指定菜品
                    List<PrintItemDataBean> tarMenu = new ArrayList<>();
                    for (PrintItemDataBean bean : list) {
                        if (bean == null) {
                            continue;
                        }
                        if (uniqList.contains(bean.fsseq)) {
                            tarMenu.add(bean);
                        }
                    }

                    if (ListUtil.isEmpty(tarMenu)) {
                        continue;
                    }

                    DeptDBModel deptDBModel = processor.deptInfo.get(deptID);

                    int printNO = PrintJSONBuilder.generatePrintNO();
                    KDSUtils.updatePassPrintNoByDishId(uniqList, fsDeptId, printNO);
                    datas.put("fiPrintNo", printNO);
                    datas.put("sellorder", tarMenu);
                    datas.put("Sub", sumQty(tarMenu, false, true));
                    datas.put("Dept", deptDBModel.fsDeptName);
                    datas.put("fsCreateUserName", orderCache.optSeqModel(orderCache.optLastSeq()).createWaiterName);

                    PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                            orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                            printNO,
                            model.createWaiterName,
                            deptID,
                            PrintReportId.THE_MENU,
                            hostId,
                            true);
                    task.uri = "order/passto";
                    task.fsPrnData = datas.toJSONString();
                    task.fsPrinterName = deptDBModel.fsPrinterName;

                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    if (!task.printAtOnce) {
                        printTaskIds.add(task.fiPrintNo);
                    }
                }
                return null;
            }
        });
        return printTaskIds;
    }


    public static void printFastKdsPassTo(final OrderCache orderCache, UserDBModel user, final String hostId, List<String> fastDishIds) {

        if (ListUtil.isEmpty(fastDishIds)) {
            return;
        }

        String sql = "select fsSeq from tbSellOrderItem where fsSeq in (select fsOriginSeq from tbKdsMenuItemState where fsSeq in (" + ListUtil.optSqlParams(fastDishIds) + "))";
        List<String> dishIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (ListUtil.isEmpty(dishIdList)) {
            return;
        }

        List<String> fastDishIdList = new ArrayList<>();

        fastDishIdList.addAll(dishIdList);
        List<String> ingredientIds = PrintOrderUtil.queryIngredientIds(dishIdList);
        if (!ListUtil.isEmpty(ingredientIds)) {
            fastDishIdList.addAll(ingredientIds);
        }
        PrintFastFoodOrderUtil.printPassTo(orderCache, user, "" + (orderCache.currentSeq - 1), hostId,
                true, fastDishIdList, fastDishIds);
    }

    /**
     * 打印 kds 传菜单
     *
     * @param hostID
     * @param deptID
     * @param dishIdList
     */
    public static void printKdsPassTo(String hostID, String deptID, String orderId, List<String> dishIdList) {
        if (ListUtil.isEmpty(dishIdList)) {
            return;
        }
        String sql = "select fsSeq from tbSellOrderItem where fsSeq in (select fsOriginSeq from tbKdsMenuItemState where fsSeq in (" + ListUtil.optSqlParams(dishIdList) + "))";
        String var1 = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(var1)) {
            return;
        }
        List<String> menuSeqList = new ArrayList<>();
        menuSeqList.add(var1);
        List<String> ingredientIds = queryIngredientIds(menuSeqList);
        if (!ListUtil.isEmpty(ingredientIds)) {
            menuSeqList.addAll(ingredientIds);
        }
        OrderCache order = OrderSession.getInstance().getOrder(orderId);
        if (order == null) {
            return;
        }
        kdsGPassTo(order, hostID, deptID, menuSeqList, dishIdList.size());
        return;
    }

    /**
     * kds退菜待分配单
     *
     * @param foodName
     * @param retreatedId
     * @param deptID
     * @param hostID
     * @param user
     * @return
     */
    public static List<Integer> kdsARetreated(String foodName, String retreatedId, String barcode, String deptID, String hostID, UserDBModel user) {
        List<Integer> printTaskIds = new ArrayList<>();

        if (TextUtils.isEmpty(foodName)) {
            return printTaskIds;
        }
        if (TextUtils.isEmpty(retreatedId)) {
            return printTaskIds;
        }

        BusinessExecutor.executeNoWait(() -> {
            DeptDBModel dept = DeptDBUtils.queryById(deptID);
            if (dept == null) {
                return null;
            }

            JSONObject data = new JSONObject();
            data.put("Dept", dept);

            int printNO = PrintJSONBuilder.generatePrintNO();
            data.put("fiPrintNo", printNO);

            data.put("retreated", retreatedId);
            data.put("dish", KDSUtils.buildMenuFromAlgorithm(foodName));
            data.put("barCode", barcode);

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    "", "", "",
                    printNO,
                    user.fsUserName,
                    deptID,
                    PrintReportId.THE_MENU,
                    hostID,
                    true);
            task.uri = "order/kdsRetreated";
            task.fsPrnData = data.toJSONString();
            task.fsPrinterName = dept.fsPrinterName;

            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
            return null;
        });
        return printTaskIds;
    }

    /**
     * 打印传菜单
     *
     * @param orderCache OrderCache
     */
    public static List<Integer> printKdsGeneralPassTo(final OrderCache orderCache, final String hostId, List<String> seqList) {
        List<Integer> printTaskIds = new ArrayList<>();
        if (orderCache.shareShopOrder()) {
            return printTaskIds;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {

                JSONObject datas = new JSONObject();

                int lastSeq = orderCache.optLastSeq();
                OrderSeqModel model = orderCache.optSeqModel(lastSeq);
                datas.put("PrintUser", orderCache.waiterName);

                String date = orderCache.businessDate;
                String sql = "select fsseq, fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsNote,fsDeptId,  fiIsMulDept,fiItemCd,fiIsEditQty,(fdSaleQty-fdBackQty) as fdSaleQty," +
                        " (case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState," +
                        " fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind <> '3'" +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'" +
                        " and fiOrderSeq='" + lastSeq + "'";

                String sql2 = "select fsseq,fsOrderUint,fsSeq_M, (case fdGiftQty when 0 then (case fiOrderMode when '3' then '[赠]' else '' end) else '[赠]' end)||fsItemName as fsItemName,fsDeptId,fiIsMulDept,fiItemCd,fiIsEditQty, (fdSaleQty-fdBackQty) as fdSaleQty," +
                        "(case fiItemMakeSte " +
                        " when 2 then '[等叫]' " +
                        " when 4 then '[划菜]' " +
                        " when 8 then '[打包]' " +
                        " else '' end) as SfiItemMakeState, fiOrderItemKind from " + DBModel.getTableName(SellOrderItemDBModel.class) +
                        " where fiIsPrn='1' and fsSellNo = '" + orderCache.orderID + "'" +
                        " and fiOrderItemKind = '3' " +
                        " and fiOrderMode in (1,3)" +
                        " and fsSellDate='" + date + "'" +
                        " and fiOrderSeq='" + lastSeq + "'";

                List<PrintItemDataBean> sellOrderItemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintItemDataBean.class);
                if (sellOrderItemDBModels == null) {
                    sellOrderItemDBModels = new ArrayList<>();
                }

                List<PrintItemDataBean> SLITList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, PrintItemDataBean.class);
                if (SLITList == null) {
                    SLITList = new ArrayList<>();
                }

                for (PrintItemDataBean statementSellItemModel : sellOrderItemDBModels) {

                    for (PrintItemDataBean itemExModel : SLITList) {
                        if (itemExModel.fiOrderItemKind == 3 && itemExModel.fsSeq_M.equals(statementSellItemModel.fsseq)) {
                            itemExModel.parentItemName = statementSellItemModel.fsItemName;
                        }
                    }
                }

                sellOrderItemDBModels.addAll(SLITList);

                /**
                 * 去除套餐头--套餐头不打印
                 */
                for (int i = 0; i < sellOrderItemDBModels.size(); i++) {
                    if (sellOrderItemDBModels.get(i).fiOrderItemKind == 2) {
                        sellOrderItemDBModels.remove(i);
                        i--;
                    }
                }

                CustomSellDBModel sell = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsSellNo =" + orderCache.orderID, CustomSellDBModel.class);
                sell.fsMSectionName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,
                        "select fsMSectionName from tbmsection where fsMSectionId='" + orderCache.currentSectionID + "'");
                datas.put("Sell", sell);


                String printPassto = CommonDBUtil.getConfigWithDefault(DBPrintConfig.PRINT_PASSTO, "0");
                if (TextUtils.equals("0", printPassto) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null) {
                        if (!TextUtils.isEmpty(memberComments.memberLevel)) {
                            datas.put("memberLevel", memberComments.memberLevel);
                        }
                        if (!TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("sex", memberComments.sex);
                        }
                        if (memberComments.cardBalance.compareTo(BigDecimal.ZERO) >= 0 && !TextUtils.isEmpty(memberComments.sex)) {
                            datas.put("cardBalance", memberComments.cardBalance);
                        }
                    }
                }

                String cloudBuffet = CommonDBUtil.getConfigWithDefault(DBPrintConfig.MWBYD_CLOUD_BUFFET, "0");
                if (TextUtils.equals("1", cloudBuffet) && orderCache.memberInfoS != null) {
                    MemberComments memberComments = ServerCache.getInstance().optMemberComments(orderCache.memberInfoS.card_no);
                    if (memberComments != null && memberComments.verifyComments()) {
                        if (memberComments.service_score > 0) {
                            datas.put("serviceScore", SymbolUtils.queryPentagram(memberComments.service_score));
                        }
                        if (!TextUtils.isEmpty(memberComments.messages)) {
                            datas.put("commentsMessages", memberComments.messages);
                        }
                        if (!TextUtils.isEmpty(memberComments.tags)) {
                            datas.put("tags", memberComments.tags);
                        }
                    }
                }

                GroupPrintDataProcessor processor = GroupPrintDataProcessor.createBuilder()
                        .setItemList(sellOrderItemDBModels)
                        .setWithCurrentHost(false)
                        .setWithDeptMake(false)
                        .setWithDeptTransfer(true)
                        .build();
                for (Map.Entry<String, List<PrintItemDataBean>> entry : processor.result.entrySet()) {
                    String deptID = entry.getKey();
                    List<PrintItemDataBean> list = entry.getValue();
                    DeptDBModel deptDBModel = processor.deptInfo.get(deptID);

                    // 筛选菜品
                    List<PrintItemDataBean> tarMenu = new ArrayList<>();
                    if (ListUtil.isEmpty(seqList)) {
                        tarMenu.addAll(list);
                    } else {
                        for (PrintItemDataBean bean : list) {
                            if (seqList.contains(bean.fsseq)) {
                                tarMenu.add(bean);
                            }
                        }
                    }

                    int printNO = PrintJSONBuilder.generatePrintNO();
                    datas.put("fiPrintNo", printNO);
                    datas.put("sellorder", tarMenu);
                    datas.put("Sub", sumQty(list, false, true));
                    datas.put("Dept", deptDBModel.fsDeptName);
                    datas.put("fsCreateUserName", orderCache.optSeqModel(orderCache.optLastSeq()).createWaiterName);

                    PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                            orderCache.orderID, orderCache.fsmtablename, orderCache.businessDate,
                            printNO,
                            model.createWaiterName,
                            deptID,
                            PrintReportId.THE_MENU,
                            hostId,
                            true);
                    task.uri = "order/passto";
                    task.fsPrnData = datas.toJSONString();
                    task.fsPrinterName = deptDBModel.fsPrinterName;

                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                    if (!task.printAtOnce) {
                        printTaskIds.add(task.fiPrintNo);
                    }
                }
                return null;
            }
        });
        return printTaskIds;
    }
}
