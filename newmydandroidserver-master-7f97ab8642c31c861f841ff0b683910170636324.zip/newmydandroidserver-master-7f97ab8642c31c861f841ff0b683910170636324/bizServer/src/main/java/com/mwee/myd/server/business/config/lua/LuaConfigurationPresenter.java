package com.mwee.myd.server.business.config.lua;

import android.text.TextUtils;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.configuration.core.IConfigurationPresenter;
import com.mwee.android.configuration.net.bean.AppBean;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.business.config.ConfigConstant;
import com.mwee.myd.server.business.config.ConfigFileUtils;

import java.io.File;
import java.io.IOException;

/**
 * @ClassName: ConfigurationPresenter
 * @Description:
 * @author: Cannan
 * @date: 2017/8/24 上午10:12
 */
public class LuaConfigurationPresenter implements IConfigurationPresenter {

    public static final String LUA_SUFFIX = "lua";

    @Override
    public boolean checkValid(File file) {
        if (file == null) {
            return false;
        }
        if (!file.exists()) {
            LogUtil.logBusiness("Lua", "校验文件不通过，文件不存在");
            return false;
        }
        if (!file.isFile()) {
            LogUtil.logBusiness("Lua", "校验文件不通过，非文件");
            return false;
        }

        String fileName = file.getName();
        String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
        if (!TextUtils.equals(LUA_SUFFIX, suffix)) {
            LogUtil.logBusiness("Lua", "校验文件不通过，文件后缀错误, 文件后缀[" + suffix + "]");
            return false;
        }
        return true;
    }

    @Override
    public void checkFail() {
        LogUtil.log("配置检测失败");
    }

    @Override
    public void callBackToUser(boolean b, AppBean appBean) {
        LogUtil.log("配置检测成功, 是否有新的配置[" + b + "], ");
    }

    @Override
    public void downloaded(File file) {
        if (file == null) {
            return;
        }
        try {
            // 删除所有原有配置文件
            LogUtil.logBusiness("Lua", "脚本文件下载完成，即将删除原文件夹所有配置");
            String dirPath = ConfigConstant.getLuaDirPath(GlobalCache.getContext());
            FileUtil.deleteAllFile(dirPath);
            // copy配置文件到指定目录
            File tarFile = new File(dirPath, file.getName());
            if (!tarFile.exists()) {
                FileUtil.makeFileSafe(GlobalCache.getContext(), tarFile.getAbsolutePath());
            }
            LogUtil.logBusiness("Lua", "即将拷贝文件[" + file.getAbsolutePath() + "]至[" + tarFile.getAbsolutePath() + "]");
            ConfigFileUtils.copy(file, tarFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getCheckHistoryFileName() {
        return "LuaConfigurationCheckHistory";
    }

    @Override
    public String getCheckResponseKey() {
        return "LuaConfigurationCheckResponse";
    }

    @Override
    public String fileFormat() {
        return "vbparse_%d_V%d.lua";
    }
}
