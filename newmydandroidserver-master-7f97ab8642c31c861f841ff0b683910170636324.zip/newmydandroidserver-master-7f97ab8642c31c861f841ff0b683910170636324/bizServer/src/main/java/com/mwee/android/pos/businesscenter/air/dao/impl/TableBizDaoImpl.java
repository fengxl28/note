package com.mwee.android.pos.businesscenter.air.dao.impl;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.businesscenter.air.dao.ITableBizDao;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/8/17.
 */

public class TableBizDaoImpl implements ITableBizDao {
    @Override
    public TableBizModel queryById(String id) {
        String sql = "select * from tableBiz where fsmtableId = '" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, TableBizModel.class);
    }

    @Override
    public ArrayList<TableBizModel> queryAll() {
        return null;
    }

    @Override
    public long update(TableBizModel tableBizModel) {
        return 0;
    }

    @Override
    public long delete(String id) {
        return 0;
    }

    @Override
    public TableBizModel insert(MtableDBModel mtableDBModel) {
        TableBizModel tableStatusBean = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbMtable where fsmtableId = '" + mtableDBModel.fsmtableid + "'", TableBizModel.class);
        if (tableStatusBean != null) {
            tableStatusBean.replaceNoTrans();
        }
        return tableStatusBean;
    }

    @Override
    public boolean queryTableIsOpenedByTableId(String tableId) {
        TableBizModel tableBizModel = queryById(tableId);
        return tableBizModel != null && !tableBizModel.isFree();
    }

    @Override
    public boolean doOpenTable(MtableDBModel willOpenTable, String fssellno, UserDBModel userDBModel) {
        if (queryById(willOpenTable.fsmtableid) == null) {
            insert(willOpenTable);
        }
        return DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues();
                values.put("fsopenhstime", DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT));
                values.put("fssellno", fssellno);
                values.put("fsmtablesteid", TableConstans.TABLE_STATUS_OPEN);
                values.put("fsupdatetime", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (userDBModel != null) {
                    values.put("fsopenusername", userDBModel.fsUserName);
                    values.put("fsupdateusername", userDBModel.fsUserName);
                    values.put("fsupdateuserid", userDBModel.fsUserId);
                }
                db.update(DBModel.getTableName(TableBizModel.class), values, " fsmtableid = '" + willOpenTable.fsmtableid + "'", null);
                return true;
            }
        });
    }

    @Override
    public boolean doClearTable(MtableDBModel mtableDBModel, String orderId, UserDBModel userDBModel) {
        return DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues();
                values.put("fsopenhstime", "");
                values.put("fssellno", "");
                values.put("fsmtablesteid", TableConstans.TABLE_STATUS_FREE);
                values.put("fsupdatetime", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                if (userDBModel != null) {
                    values.put("fsopenusername", userDBModel.fsUserName);
                    values.put("fsupdateusername", userDBModel.fsUserName);
                    values.put("fsupdateuserid", userDBModel.fsUserId);
                }
                db.update(DBModel.getTableName(TableBizModel.class), values, " fsmtableid = '" + mtableDBModel.fsmtableid + "'", null);
                return true;
            }
        });
    }
}
