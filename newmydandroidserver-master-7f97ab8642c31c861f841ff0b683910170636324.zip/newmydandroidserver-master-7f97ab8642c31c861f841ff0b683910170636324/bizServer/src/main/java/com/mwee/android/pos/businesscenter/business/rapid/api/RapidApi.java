package com.mwee.android.pos.businesscenter.business.rapid.api;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBGetAfterPayOrder;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.rapid.api.bean.RapidActionRequset;
import com.mwee.android.pos.business.rapid.api.bean.RapidGetRequest;
import com.mwee.android.pos.business.rapid.api.bean.RapidGetResponse;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidfstData;
import com.mwee.android.pos.business.rapid.api.bean.model.SourceType;
import com.mwee.android.pos.businesscenter.business.koubei.KBAfterPayProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.future.KBFutureProcessor;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidOnlyPay;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayBiz;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.print.PrintRapidOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.businesscenter.koubei.sync.KBOrderSyncManager;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.jsonfilter.RapidJsonFilter;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 秒点秒付的接口API
 * Created by virgil on 2016/11/3.
 */

public class RapidApi {
    public static void sendGetDetailByID(final String commitID) {
        final List<BaseRequest> requestList = new ArrayList<>();
        RapidGetRequest request = new RapidGetRequest(); //根据commitID查询秒点订单详情
        request.commitID = commitID;
        requestList.add(request);

        final RapidActionRequset requsetAction = new RapidActionRequset();
        requsetAction.fsid = commitID;
        final long start = SystemClock.elapsedRealtime();
        requestList.add(requsetAction);
        RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控 getWL开始", commitID);
        // RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控 业务开始请求" + DateUtil.getCurrentTime() + "," + commitID);
        BusinessExecutor.execute(requestList, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        RapidBiz.prepareToRemoveCommitCache(commitID);
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        RapidBiz.prepareToRemoveCommitCache(commitID);
                        return false;
                    }
                }, new BusinessCallback() {
                    @Override
                    public boolean success(int i, ResponseData responseData) {
                        boolean shouldContinue = false;

                        if (responseData.responseBean != null) {
                            if (responseData.responseBean instanceof RapidGetResponse) {
                                RunTimeLog.addLog(RunTimeLog.RAPID_GETWL, "秒点监控 getWL 结果", requsetAction.fsid, responseData.responseBean);

                                RapidGetResponse response = (RapidGetResponse) responseData.responseBean;
                                if (response.data != null) {
                                    shouldContinue = true;
                                    try {
                                        buildActionRequest(requsetAction, response.data);
                                    } catch (Exception e) {
                                        LogUtil.logError(e);
                                    }
                                }
                                RunTimeLog.addLog(RunTimeLog.RAPID_PUTWL, "秒点监控 putWL 开始", requsetAction.fsid,
                                        requsetAction);
                            } else {
                                long out = SystemClock.elapsedRealtime() - start;
                                if (out > 3500) {
                                    RunTimeLog.addLog(RunTimeLog.RPAID_BUSINESS_TIME_CONSUM, String.valueOf(out), requsetAction.fsid, responseData.responseBean);
                                }
                                RunTimeLog.addLog(RunTimeLog.RAPID_PUTWL_END, "秒点监控 putWL 结果", requsetAction.fsid, responseData.responseBean);
                                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
                            }
                        }
                        return shouldContinue;
                    }

                    @Override
                    public boolean fail(int i, ResponseData responseData) {
                        long out = SystemClock.elapsedRealtime() - start;
                        //耗时超过3.5秒，则报警
                        if (out > 3500) {
                            RunTimeLog.addLog(RunTimeLog.RPAID_BUSINESS_TIME_CONSUM, String.valueOf(out), requsetAction.fsid, responseData.responseBean);
                        }
                        if (i == 0) {
                            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 getWL 失败", requsetAction.fsid, responseData);
                        } else {
                            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 putWL 失败", requsetAction.fsid, responseData);
//                            if (TextUtils.equals(requsetAction.fsaction, RapidAction.GET_ORDER_DETAIL)
//                                    || TextUtils.equals(requsetAction.fsaction, RapidAction.SUBMIT_ORDER)
//                                    || TextUtils.equals(requsetAction.fsaction, RapidAction.PAY_ORDER)
//                                    || TextUtils.equals(requsetAction.fsaction, RapidAction.SEARCH_PAY)) {
                            InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
//                            }
                        }
                        return false;
                    }
                }
                , true);
    }

    public static void sendGetDetailByID(final RapidGetModel model) {
        final RapidActionRequset requsetAction = new RapidActionRequset();
        requsetAction.fsid = model.fsid;
        buildActionRequest(requsetAction, model);
        final long start = SystemClock.elapsedRealtime();
        RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控 putWL开始", model.fsid);
        BusinessExecutor.execute(requsetAction, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        RapidBiz.removeProcessingCache(model.fsid);
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        RapidBiz.removeProcessingCache(model.fsid);
                        return false;
                    }
                }, new BusinessCallback() {
                    @Override
                    public boolean success(int i, ResponseData responseData) {
                        if (responseData.responseBean != null) {
                            long out = SystemClock.elapsedRealtime() - start;
                            if (out > 3500) {
                                RunTimeLog.addLog(RunTimeLog.RPAID_BUSINESS_TIME_CONSUM, String.valueOf(out), requsetAction.fsid, responseData.responseBean);
                            }
                            RunTimeLog.addLog(RunTimeLog.RAPID_PUTWL_END, "秒点监控 putWL 结果", requsetAction.fsid, responseData.responseBean);
                            InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
                        }
                        return false;
                    }

                    @Override
                    public boolean fail(int i, ResponseData responseData) {
                        long out = SystemClock.elapsedRealtime() - start;
                        //耗时超过3.5秒，则报警
                        if (out > 3500) {
                            RunTimeLog.addLog(RunTimeLog.RPAID_BUSINESS_TIME_CONSUM, String.valueOf(out), requsetAction.fsid, responseData.responseBean);
                        }
                        RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 putWL 失败", requsetAction.fsid, responseData);
                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
                        return false;
                    }
                }
                , true);
    }

    public static RapidActionRequset buildActionRequest(RapidActionRequset requsetAction, RapidGetModel data) {
        RapidActionModel result = parseAction(data);
        requsetAction.fsid = data.fsid;
        requsetAction.fsaction = data.fsaction;
        requsetAction.fistate = result.result;
        //为了方便后台数据统计，增加下面三个字段 pro2.5
        Object objFsrdata = JSON.parse(result.resultBiz);
        int devType = 11;
        if (APPConfig.isMyd()) {
            devType = 11;
        } else if (APPConfig.isAir()) {
            devType = 13;
        } else if (APPConfig.isCasiher()) {
            devType = 10;
        }
        if (objFsrdata != null && objFsrdata instanceof JSONObject) {
            JSONObject jsonFsrdata = (JSONObject) objFsrdata;
            /**
             "devType":软件类型   10美收银,11美易点-安卓,12美易点-windows,13美小易
             "posVersion":版本号
             "deviceId":设备Id
             * **/

            jsonFsrdata.put("devType", devType);
            jsonFsrdata.put("posVersion", BizConstant.VERSION_NAME);
            jsonFsrdata.put("deviceId", ServerHardwareUtil.getHardWareSymbol());
            requsetAction.fsrdata = jsonFsrdata.toJSONString();
        } else if (objFsrdata == null) {
            JSONObject jsonFsrdata = new JSONObject();
            jsonFsrdata.put("devType", devType);
            jsonFsrdata.put("posVersion", BizConstant.VERSION_NAME);
            jsonFsrdata.put("deviceId", ServerHardwareUtil.getHardWareSymbol());
            requsetAction.fsrdata = jsonFsrdata.toJSONString();
        } else {
            requsetAction.fsrdata = result.resultBiz;
        }
        requsetAction.fserror = result.errorInfo;
        //缓存CommitID的结果用于去重
        RapidBiz.saveRapidCache(data, requsetAction);
        return requsetAction;
    }

    /**
     * 构建 RapidOrder，并处理桌台名称赋值给了tableNo字段的场景
     *
     * @param data RapidGetModel
     * @return RapidOrder
     */
    public static RapidOrder buildRapidOrder(RapidGetModel data) {
        try {
            RapidOrder order = JSON.parseObject(data.fstdata, RapidOrder.class);
            if (order != null) {
                order.action = data.fsaction;
                if (!TableDBUtil.checkTableExist(order.tableNo)) {
                    String tableID = TableDBUtil.getTableIDByName(order.tableNo);
                    if (!TextUtils.isEmpty(tableID)) {
                        order.tableNo = tableID;
                    }
                }
            }
            return order;
        } catch (Exception e) {
            LogUtil.logError("buildRapidOrder", e);

        }
//        order.eatTime = "2018-11-22 19:28:00";

        return null;
    }

    /**
     * 构建 RapidPayment，并处理桌台名称赋值给了tableNo字段的场景
     *
     * @param data RapidGetModel
     * @return RapidPayment
     */
    public static RapidPayment buildRapidPayment(RapidGetModel data) {
        RapidPayment order = JSON.parseObject(data.fstdata, RapidPayment.class);
        if (order != null) {
            order.action = data.fsaction;
            if (!TableDBUtil.checkTableExist(order.tableNo)) {
                String tableID = TableDBUtil.getTableIDByName(order.tableNo);
                if (!TextUtils.isEmpty(tableID)) {
                    order.tableNo = tableID;
                }
            }
        }
        return order;
    }

    /**
     * 构建 RapidBookOrder
     *
     * @param data RapidGetModel
     * @return RapidBookOrder
     */
    public static RapidBookOrder buildRapidBookOrder(RapidGetModel data) {
        RapidBookOrder order = JSON.parseObject(data.fstdata, RapidBookOrder.class);
        if (order != null) {
            order.action = data.fsaction;
        }
        return order;
    }

    public static RapidActionModel parseAction(RapidGetModel data) {
        RapidActionModel resultData = new RapidActionModel();
        resultData.fsid = data.fsid;
        resultData.result = RapidResult.SUCCESS;
        switch (data.fsaction) {
            case RapidAction.RING: {
                /* 呼叫服务 */
                if (HostUtil.isShopFinished()) {
                    resultData.result = RapidResult.ERROR_ANTI_PAY;
                    resultData.errorInfo = "餐厅已打烊";
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action:call 餐厅已打烊， 禁止呼叫铃", data.fsid, data);
                    return resultData;
                }
                RapidOrder order = buildRapidOrder(data);
                String result = callService(order.tableNo);
                resultData.result = TextUtils.isEmpty(result) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = result;
                JSONObject object = new JSONObject();
                object.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = object.toJSONString();
            }
            break;
            case RapidAction.OPEN_TABLE: {
                if (HostUtil.isShopFinished()) {
                    resultData.result = RapidResult.ERROR_ANTI_PAY;
                    resultData.errorInfo = "餐厅已打烊";
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action:kt; 餐厅已打烊，禁止开台", data.fsid, data);
                    return resultData;
                }
                RapidOrder order = buildRapidOrder(data);
                String result = openTable(order.tableNo);
                resultData.result = TextUtils.isEmpty(result) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = result;
                JSONObject object = new JSONObject();
                object.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = object.toJSONString();

            }
            break;
            case RapidAction.SEARCH_PAY:
            case RapidAction.GET_ORDER_DETAIL: {
                /* 查询订单实时信息 */
                //如果是查询订单的commitID，则赋值给Application

                RapidOrder rapidOrder = buildRapidOrder(data);
                //桌台上的订单
                OrderCache orderCache = queryOrderByTableId(rapidOrder.tableNo);
                //桌台上的秒点单信息---未取单的数据
                TempOrderDishesCache tempOrder = TableDBUtil.getTempOrderByTableId(rapidOrder.tableNo);
                //先付款的秒点单信息
                TempOrderDishesCache tempPreOrder = RapidPrePayBiz.buildPrePayOrderFull(rapidOrder.tableNo,
                        rapidOrder.userId, rapidOrder.orderId, rapidOrder.needBuildMemberPrice(),rapidOrder.isVipPrice, StringUtil.toInt
                                (rapidOrder.memberLevel), rapidOrder.memberId, rapidOrder.plusId);
                //如果没有任何订单信息表示还未下过任何单
                if (orderCache == null && tempOrder == null && tempPreOrder == null) {
                    resultData.result = RapidResult.ERROR_NO_ORDER;
                    boolean hasOpenParam = OrderBizUtil.hasOpenParamByTableId(rapidOrder.tableNo);
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("showOpenAutoDish", hasOpenParam ? 1 : 0);
                    resultData.resultBiz = jsonObject.toJSONString();
                    resultData.errorInfo = "未查询到相关订单信息, 桌台[" + rapidOrder.tableNo + "]";
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action: findorderbytableno 未查询到相关订单信息", data
                            .fsid, rapidOrder.tableNo);

                } else if (orderCache != null && NetOrderType.isKouBeiOrder(orderCache.thirdOrderType)) {
                    //口碑先付款订单不允许拉单
                    resultData.result = RapidResult.ERROR_NO_ORDER;
                    boolean hasOpenParam = OrderBizUtil.hasOpenParamByTableId(rapidOrder.tableNo);
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("showOpenAutoDish", hasOpenParam ? 1 : 0);
                    resultData.resultBiz = jsonObject.toJSONString();
                    resultData.errorInfo = "桌台已有其他订单，如需下单，请联系服务员";
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点拉单 Action: " + data.fsaction + " 桌台已有口碑先付款订单，不允许拉单", data
                            .fsid, rapidOrder.tableNo);
                } else {
                    RapidOrder existOrder = null;
                    //含有未确认的菜---包含未称重的称重菜和未确定价格的时间菜
                    boolean hasUnConfirmedMenu = false;

                    if (orderCache != null) {
                        if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
                            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action: findorderbytableno 桌台[" + orderCache.fsmtableid + "]正在反结账 (parseAction)",
                                    resultData.fsid, orderCache.fsmtableid);
                        }
//                        if (checkAntiPay(resultData, orderCache)) {
//                            return resultData;
//                        }
                        //已将下面逻辑移动到RapidBiz.convert方法里
//                        orderCache = orderCache.clone();
//                        if (checkRapidPayExist(resultData, order.tableNo, orderCache.orderID)) {
//                            return resultData;
//                        }
//                        if (tempPreOrder != null && !ListUtil.isEmpty(tempPreOrder.tempSelectedMenuList)) {
//                            orderCache.originMenuList.addAll(tempPreOrder.tempSelectedMenuList);
//                            orderCache.reCalcAllByAll();
//                        }

                        //桌台上的订单 + 先付款的临时订单
                        existOrder = buildRapidOrder(rapidOrder, orderCache, tempPreOrder == null ? null :
                                tempPreOrder.tempSelectedMenuList);

                        //orderCache已是被克隆过的对象了
                        if (tempPreOrder != null && !ListUtil.isEmpty(tempPreOrder.tempSelectedMenuList)) {
                            orderCache.originMenuList.removeAll(tempPreOrder.tempSelectedMenuList);
                        }

                        if (RapidBiz.addMenuList(existOrder, orderCache.originMenuList, 1)) {
                            hasUnConfirmedMenu = true;
                        }

                        if (tempPreOrder != null && !ListUtil.isEmpty(tempPreOrder.tempSelectedMenuList)) {
                            if (RapidBiz.addMenuList(existOrder, tempPreOrder.tempSelectedMenuList, 3)) {
                                hasUnConfirmedMenu = true;
                            }

                            tempPreOrder.plusTempSelectedMenuAmount();
                            //待支付金额小于等于0
                            if (existOrder.notPaymentAmount.compareTo(tempPreOrder.tempTotalPrice) < 0) {
                                existOrder.notPaymentAmount = tempPreOrder.tempTotalPrice;
                            }
                        }
                    }

                    if (existOrder == null && tempOrder != null) {
                        existOrder = buildRapidOrder(rapidOrder, tempOrder);
                    }

                    String eatTime = "";
                    int eatType = 0;
                    String orderRemark = "";
                    if (tempPreOrder != null) {
                        eatTime = tempPreOrder.eatTime;
                        eatType = tempPreOrder.eatType;
                        orderRemark = tempPreOrder.orderRemark;
                        if (existOrder == null) {
                            existOrder = buildRapidOrder(rapidOrder, tempPreOrder);
                        }
                        existOrder.bizType = tempPreOrder.thirdBizType;
                        existOrder.orderId = tempPreOrder.optFirstThirdOrderID();
                    }

                    if (tempOrder != null) {
                        eatTime = tempOrder.eatTime;
                        eatType = tempOrder.eatType;
                        orderRemark = tempOrder.orderRemark;
                        existOrder.orderId = tempOrder.optFirstThirdOrderID();
                        if (RapidBiz.addMenuList(existOrder, tempOrder.tempSelectedMenuList, 0)) {
                            hasUnConfirmedMenu = true;
                        }
                    }

                    if (tempPreOrder != null && orderCache == null) {
                        if (RapidBiz.addMenuList(existOrder, tempPreOrder.tempSelectedMenuList, 3)) {
                            hasUnConfirmedMenu = true;
                        }
                    }

                    //如果没有已下厨的菜，或者有未确认的菜，则不能支付
                    if (hasUnConfirmedMenu) {
                        existOrder.payStatus = 0; // 微信端是通过支付状态==0来判断可以支付，所以这里目前只能写死为1000
                    }

                    if (tempPreOrder != null || NetOrderType.isRapidPrePay(rapidOrder.bizType) || rapidOrder.payFirst
                            == 1 || NetOrderType.isShareShopPrePay(rapidOrder.bizType)) {
                        existOrder.diningStatus = 10;
                        existOrder.orderStatus = 1;
                        if (existOrder.payStatus != 0) {
                            if (tempPreOrder != null) {
                                existOrder.payStatus = 1;
                            }
                        }
                    }
                    // 订单存在菜品券时，秒点不允许买单 - 订单返回未确认状态控制秒点无法付款
                    if (orderCache.existMemberCoupon()) {
                        existOrder.payStatus = 5;
                    }

                    LogUtil.log("findorderbytableno, 转换的秒点订单信息:\n" + JSON.toJSONString(existOrder));

                    if (TextUtils.equals(RapidAction.GET_ORDER_DETAIL, data.fsaction)) {  //秒付买单
                        // 校验餐标/低消
                        String checkErr = checkDinnerStandard(orderCache, tempOrder, tempPreOrder, existOrder);
                        if (!TextUtils.isEmpty(checkErr)) {
                            RapidBiz.buildResultError(resultData, checkErr);
                            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action: findorderbytableno 桌台[" + existOrder.tableNo + "]校验餐标/低消不通过，不允许结账 (parseAction)：" + checkErr,
                                    resultData.fsid, existOrder.tableNo);
                            return resultData;
                        }

                        RapidBiz.checkRapidPayCommit(existOrder);
                        existOrder.useNewCheckRule = 1;
                    }
                    existOrder.eatTime = eatTime;//用餐时间
                    /*美小店 添加 start */
                    existOrder.eatType = eatType;
                    existOrder.orderRemark = orderRemark;
                    /*美小店 添加 end */
                    resultData.result = RapidResult.SUCCESS;
                    resultData.resultBiz = JSON.toJSONString(existOrder, new RapidJsonFilter());
                    resultData.errorInfo = "查订单实时信息成功！";
                }
            }
            break;
            case RapidAction.SUBMIT_ORDER: {//下单、加菜
                if (HostUtil.isShopFinished()) {
                    resultData.result = RapidResult.ERROR_ANTI_PAY;
                    resultData.errorInfo = "餐厅已打烊";
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action:order 餐厅已打烊， 禁止下单", data.fsid, data);
                    return resultData;
                }
                receiveRapidOrder(resultData, data);
            }
            break;
            case RapidAction.PAY_ORDER: { //支付
                receiveRapidPay(resultData, data);
            }
            break;
            case RapidAction.BOOK_ORDER: {//预定
                RapidBookOrder bookOrder = buildRapidBookOrder(data);
                newBookOrder(bookOrder);
            }
            case RapidAction.QUERY_TABLES: {
                resultData.result = RapidResult.SUCCESS;
                resultData.resultBiz = RapidBiz.queryTableInfoList();
                resultData.errorInfo = "查订单实时信息成功！";
            }
            break;
            case RapidAction.KB_ORDER_NEW:
            case RapidAction.KB_ORDER_NEW_COMPENSATE:
                String resultNew = KBPreOrderProcessor.pushNewOrder(data);
                resultData.result = TextUtils.isEmpty(resultNew) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultNew;
                JSONObject objectNew = new JSONObject();
                objectNew.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectNew.toJSONString();
                break;
            case RapidAction.KB_ORDER_CANCEL:
                String resultCancel = KBPreOrderProcessor.pushCancelOrder(data);
                resultData.result = TextUtils.isEmpty(resultCancel) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultCancel;
                JSONObject objectCancel = new JSONObject();
                objectCancel.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectCancel.toJSONString();
                break;
            case RapidAction.KB_ORDER_REJECT:
                String resultReject = KBPreOrderProcessor.pushRejuctOrder(data);
                resultData.result = TextUtils.isEmpty(resultReject) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultReject;
                JSONObject objectReject = new JSONObject();
                objectReject.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectReject.toJSONString();
                break;
            case RapidAction.KB_ORDER_APPLY_REFUND://todo 用户申请退款
                String resultApplyRefund = KBPreOrderProcessor.pushApplyRefund(data);
                resultData.result = TextUtils.isEmpty(resultApplyRefund) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultApplyRefund;
                JSONObject objectApplyRefund = new JSONObject();
                objectApplyRefund.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectApplyRefund.toJSONString();
                break;
           /* case RapidAction.KB_ORDER_REFUNDED://todo 商家同意退款
                String resultAgreeRefund = KBPreOrderProcessor.pushAgreeRefund(data);
                resultData.result = TextUtils.isEmpty(resultAgreeRefund) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultAgreeRefund;
                JSONObject objectAgreeRefund = new JSONObject();
                objectAgreeRefund.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectAgreeRefund.toJSONString();
                break;*/
            case RapidAction.KB_ORDER_REFUND://todo 口碑退款
                String resultefund = KBPreOrderProcessor.pushRefund(data);
                resultData.result = TextUtils.isEmpty(resultefund) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultefund;
                JSONObject objectRefund = new JSONObject();
                objectRefund.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectRefund.toJSONString();
                break;
            case RapidAction.KB_ORDER_REJECT_REFUNDED:
                String rejectRefundResult = KBPreOrderProcessor.pushRejectRefund(data);
                resultData.result = TextUtils.isEmpty(rejectRefundResult) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = rejectRefundResult;
                JSONObject objectRejectRefund = new JSONObject();
                objectRejectRefund.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectRejectRefund.toJSONString();
                break;
            case RapidAction.KB_FUTURE_PUSH://todo 口碑后付款订单
            case RapidAction.KB_FUTURE_PUSH_COMPENSATE://todo 口碑后付款订单
                String resultFuture = KBFutureProcessor.pushFutureNewOrder(data);
                resultData.result = TextUtils.isEmpty(resultFuture) ? RapidResult.SUCCESS : RapidResult.ERROR;
                resultData.errorInfo = resultFuture;
                JSONObject objectRefundFuture = new JSONObject();
                objectRefundFuture.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = objectRefundFuture.toJSONString();
                break;
            case RapidAction.KB_AFTER_PAY_NOTIFY:
            case RapidAction.KB_AFTER_PAY_NOTIFY_COMPENSATE:
                //口碑后付支付通知
                KBAfterPayProcessor.afterPayNotify(resultData, data);
                JSONObject afterPayJson = new JSONObject();
                afterPayJson.put("status", resultData.result == RapidResult.SUCCESS ? "1" : "4");
                resultData.resultBiz = afterPayJson.toJSONString();
                break;
            case RapidAction.KB_AFTER_PAY_PULL:
                KBGetAfterPayOrder getAfterPayOrder = JSONObject.parseObject(data.fstdata, KBGetAfterPayOrder.class);
                //口碑拉单
                if (!TextUtils.isEmpty(getAfterPayOrder.out_biz_no)) {
                    RunTimeLog.addLog(RunTimeLog.KB_ORDER_SYNC, "口碑拉单消息：getAfterPayOrder:" + getAfterPayOrder.toString());
                    OrderCache orderCache = OrderSession.getInstance().getOrder(getAfterPayOrder.out_biz_no);
                    if (orderCache != null && orderCache.isShouldSyncToKB()) {
                        KBOrderSyncManager.getInstance().add(getAfterPayOrder.out_biz_no);
                    }
                }
                break;
            default:
                break;
        }
        return resultData;
    }

    /**
     * 校验餐标/低消
     */
    private static String checkDinnerStandard(OrderCache orderCache, TempOrderDishesCache tempOrder, TempOrderDishesCache tempPreOrder, RapidOrder rapidOrder) {
        String checkErr = "";
        List<MenuItem> menuItems = new ArrayList<>();
        if (orderCache != null) {
            checkErr = DinnerStandardUtil.checkDinnerStandardPayExcludeMinStandard(orderCache);
            if (!TextUtils.isEmpty(checkErr)) {
                return checkErr;
            }
            menuItems.addAll(orderCache.originMenuList);
        }

        if (tempOrder != null) {
            checkErr = DinnerStandardUtil.checkDinnerStandardPayExcludeMinStandard(tempOrder);
            if (!TextUtils.isEmpty(checkErr)) {
                return checkErr;
            }
            menuItems.addAll(tempOrder.tempSelectedMenuList);
        }

        if (tempPreOrder != null) {
            checkErr = DinnerStandardUtil.checkDinnerStandardPayExcludeMinStandard(tempPreOrder);
            if (!TextUtils.isEmpty(checkErr)) {
                return checkErr;
            }
            menuItems.addAll(tempPreOrder.tempSelectedMenuList);
        }

        if (rapidOrder != null) {
            if (!DinnerStandardUtil.isFillMinStandard(rapidOrder.tableNo, 2, menuItems, rapidOrder.total)) {
                return DinnerStandardUtil.ERROR_ON_MIN_STANDARD;
            }
        }
        return checkErr;
    }

    /**
     * 新秒点预定消息
     */
    public static void newBookOrder(RapidBookOrder rapidBookOrder) {
        //消息中心新增记录
        String date = HostUtil.getHistoryBusineeDate("");
        MessageOrderUtil.addBookOrderMessage(rapidBookOrder, date);

        //打印
        PrintRapidOrderUtil.printRapidBookOrder(rapidBookOrder);

        //通知业务中心站点弹框提示
        String tips = rapidBookOrder.orderInfo.name + "预定了" + rapidBookOrder.orderInfo.orderTime + "到店就餐，已支付预订款：" +
                Calc.formatShow(rapidBookOrder.orderInfo.deposit) + "元";
        String hostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        NotifyToClient.newBookOrderTips(hostID, tips);
    }

    /**
     * 如果订单在反结账，则不再接收秒点秒付数据
     *
     * @param resultData RapidActionModel
     * @param orderCache OrderCache
     * @return boolean |  true:在反结账；false：没有在反结账
     */
    public static boolean checkAntiPay(RapidActionModel resultData, OrderCache orderCache) {
        if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
            resultData.result = RapidResult.ERROR_ANTI_PAY;
            resultData.errorInfo = "桌台[" + orderCache.fsmtableid + "]反结账";
            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action: qryorderbytable 正在反结账", resultData.fsid,
                    orderCache.fsmtableid);
            return true;
        }
        return false;
    }

    /**
     * 如果订单已有秒付信息，则不再接收秒点秒付数据
     *
     * @param resultData RapidActionModel
     * @param tableID    String
     * @param orderID    String
     * @return boolean | true:有秒付信息；false：没有秒付信息
     */
    public static boolean checkRapidPayExist(RapidActionModel resultData, String tableID, String orderID) {
        //不再判断，要允许不断重复支付
//        String rapidPayCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as count from
// tbSellReceive where isRapidPay='1' and fiStatus = '1' and fsSellNo='" + orderID + "'");
//        if (StringUtil.toInt(rapidPayCount, 0) > 0) {
//            resultData.result = RapidResult.ERROR_DUPLICATE_RAPID_PAY;
//            resultData.errorInfo = "该订单已有秒付信息";
//            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 Action: findorderbytableno 该订单已有秒付信息", resultData.fsid,
// tableID);
//
//            LogUtil.logBusiness("秒点订单 Action: findorderbytableno\n" + "桌台[" + tableID + "]\n该订单已有秒付信息");
//            return true;
//        }
        return false;
    }

    /**
     * 通过桌台号查询相关订单
     *
     * @param tableNo String
     * @return OrderCache
     */
    public static OrderCache queryOrderByTableId(String tableNo) {
        TableBizModel table = TableDBUtil.getTableBizModelById(tableNo);
        if (table != null && !TextUtils.isEmpty(table.fssellno)) {
            return OrderSession.getInstance().getOrder(table.fssellno);
        }
        return null;
    }

    /**
     * 呼叫服务
     *
     * @param tableNo 桌台号
     * @return 错误信息
     */
    private static String callService(String tableNo) {
        TableBusinessUtil.callService(tableNo);
        NotifyToClient.refreshTableOrOrders();
        NotifyToClient.refreshRapidbell(tableNo, "0", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
        return "";
    }

    /**
     * 检查桌子状态
     *
     * @param tableId
     * @return
     */
    private static String openTable(String tableId) {
        if (!TableBusinessUtil.isExist(tableId)) {
            return "没有查询到该桌台信息";
        } else {
            /*
             * 秒点订单开台
             * 1. 桌台空闲，开台成功
             * 2. 桌台占用，无订单，成功
             * 3. 桌台占用，有订单，不是反结账订单，成功
             * 4. 桌台占用，有订单，反结账订单，成功
             * */
            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(tableId);

            if (TableConstans.TABLE_STATUS_FREE.equals(tableBizModel.fsmtablesteid) &&
                    TextUtils.isEmpty(tableBizModel.fssellno)) {
                return "";
            } else {
                OrderCache orderCache = RapidBiz.queryOrderById(tableBizModel.fssellno);

                if (orderCache == null) {
                    return "";
                } else {
                    if (orderCache.orderStatus == OrderStatus.CREATED || orderCache.orderStatus == OrderStatus.NORMAL ||
                            orderCache.orderStatus == OrderStatus.NORMAL_SENT || orderCache.orderStatus == OrderStatus.ANTI_PAIED) {
                        return "";
                    } else {
                        return "餐台不能开台, 订单[" + orderCache.orderID + "]正在反结账(" + orderCache.orderStatus + ")";
                    }

                }
            }
        }
    }

    /**
     * 收到秒点的支付信息，此处进行分发
     *
     * @param resultData RapidActionModel
     * @param data       RapidGetModel
     */
    private static void receiveRapidPay(RapidActionModel resultData, RapidGetModel data) {

        RapidPayment payment = buildRapidPayment(data);
        if (NetOrderType.isRapid(payment.bizType)) {
            //常规秒付
            submitPay(resultData, payment);
        } else if (NetOrderType.isRapidPrePay(payment.bizType)) {
            //先付款秒付
            resultData.result = RapidResult.SUCCESS;
            if (SourceType.isPrePayFastfoodModel(payment.sourceType)) {
                //秒点快餐
                RapidPrePayFastfoodBiz.receivePreFastFoodPay(resultData, payment);
            } else {
                RapidPrePayBiz.receivePreOrderPay(resultData, payment);
            }

        } else if (NetOrderType.isShareShopPrePay(payment.bizType)) {
            //共享餐厅的业务类型
            resultData.result = RapidResult.SUCCESS;
            RapidPrePayBiz.receivePreOrderPay(resultData, payment);
        } else if (NetOrderType.isRapidOnlyPay(payment.bizType)) {
            //纯收银
            RapidOnlyPay.receivePurePayInfo(payment, data.fsid);
        }
    }

    /**
     * 收到秒点的点菜单
     *
     * @param resultData RapidActionModel
     * @param data       RapidGetModel
     */
    private static void receiveRapidOrder(RapidActionModel resultData, RapidGetModel data) {

        RapidOrder order = buildRapidOrder(data);
        if (NetOrderType.isRapid(order.bizType) || NetOrderType.isPreOrder(order.bizType)) {
            submitOrder(resultData, order, data.fsid);
        } else if (NetOrderType.isRapidPrePay(order.bizType)) {
            resultData.result = RapidResult.SUCCESS;
            if (SourceType.isPrePayFastfoodModel(order.sourceType)) {
                //秒点快餐
                RapidPrePayFastfoodBiz.receivePreFastFoodMenu(resultData, data, order);
            } else {
                RapidPrePayBiz.receivePreOrderMenu(resultData, data, order);
            }
        } else if (NetOrderType.isShareShopPrePay(order.bizType)) {
            resultData.result = RapidResult.SUCCESS;
            RapidPrePayBiz.receivePreOrderMenu(resultData, data, order);
        }
    }

    public static TempOrderDishesCache buildTempOrderOld(RapidActionModel resultData, RapidOrder rapidOrder,
                                                         String commitID) {
        if (!TableBusinessUtil.isExist(rapidOrder.tableNo)) {
            RapidBiz.buildResultError(resultData, "未查到餐桌信息");
            return null;
        }

        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(rapidOrder.tableNo);

        OrderCache orderCache = RapidBiz.queryOrderById(tableBizModel.fssellno);
        if (orderCache != null) {
            if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 桌台[" + orderCache.fsmtableid + "]正在反结账 (buildTempOrderOld)",
                        resultData.fsid, orderCache.fsmtableid);
            }
//            if (RapidApi.checkAntiPay(resultData, orderCache)) {//正在反结账
//                return null;
//            }
        }
        TempOrderDishesCache tempDishes = null;
        if (rapidOrder.bizType == NetOrderType.RAPID_NORMAL) {
            tempDishes = TableDBUtil.getTempOrderByTableId(rapidOrder.tableNo);
        }
        if (tempDishes == null) {
            tempDishes = new TempOrderDishesCache();
            UserDBModel user = RapidBiz.getCloudUser();

            if (user == null) {
                RapidBiz.buildResultError(resultData, "未查询到云收银账号");
                return tempDishes;
            }
            tempDishes.tempCreateTime = DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss");
            tempDishes.commitID = commitID;
            tempDishes.waiterID = user.fsUserId;
            tempDishes.waiterName = user.fsUserName;
            String shopID = HostUtil.getShopID();
            tempDishes.businessDate = HostUtil.getHistoryBusineeDate(shopID);
            tempDishes.currentSectionID = OrderUtil.getSectionId();
            tempDishes.currentHostID = HostBiz.cloudsite;
            tempDishes.personNum = rapidOrder.people;
            if (tempDishes.personNum <= 0) {
                tempDishes.personNum = 1;
            }
        }
        tempDishes.thirdOrderID = rapidOrder.orderId;
        tempDishes.thirdBizType = rapidOrder.bizType;
        RapidBiz.buildOrder(resultData, tempDishes, rapidOrder);
        return tempDishes;
    }


    public static TempOrderDishesCache buildTempOrder(RapidActionModel resultData, RapidOrder rapidOrder,
                                                      String commitID) {
        if (!SourceType.isPrePayFastfoodModel(rapidOrder.sourceType)) {//正餐秒点先付款才需要校验桌台相关信息
            if (!TableBusinessUtil.isExist(rapidOrder.tableNo)) {
                RapidBiz.buildResultError(resultData, "未查到餐桌信息");
                return null;
            }

            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(rapidOrder.tableNo);

            OrderCache orderCache = RapidBiz.queryOrderById(tableBizModel.fssellno);
            if (orderCache != null) {
                if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
                    RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 桌台[" + orderCache.fsmtableid + "]正在反结账 (buildTempOrder)",
                            resultData.fsid, orderCache.fsmtableid);
                }
//                if (RapidApi.checkAntiPay(resultData, orderCache)) {//正在反结账
//                    return null;
//                }

                // 使用了餐标的桌台，不允许秒点加菜下单
                if (orderCache.isDiningStandard()) {
                    RapidBiz.buildResultError(resultData, DinnerStandardUtil.ERROR_ON_DINING_STANDARD);
                    return null;
                }
            }
        }

        TempOrderDishesCache tempDishes = null;
        if (rapidOrder.bizType == NetOrderType.RAPID_NORMAL) {
            tempDishes = TableDBUtil.getTempOrderByTableId(rapidOrder.tableNo);
        }
        if (tempDishes == null) {
            tempDishes = new TempOrderDishesCache();
            UserDBModel user = RapidBiz.getCloudUser();

            if (user == null) {
                RapidBiz.buildResultError(resultData, "未查询到云收银账号");
                return tempDishes;
            }
            tempDishes.tempCreateTime = DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss");
            tempDishes.commitID = commitID;
            tempDishes.eatTime = rapidOrder.eatTime;//用餐时间 小易v3.5.0添加
            tempDishes.waiterID = user.fsUserId;
            tempDishes.waiterName = user.fsUserName;
            String shopID = HostUtil.getShopID();
            tempDishes.businessDate = HostUtil.getHistoryBusineeDate(shopID);
            tempDishes.currentSectionID = OrderUtil.getSectionId();
            tempDishes.currentHostID = HostBiz.cloudsite;
            tempDishes.personNum = rapidOrder.people;
            tempDishes.eatType = rapidOrder.eatType;
            tempDishes.orderRemark = rapidOrder.orderRemark;
            if (tempDishes.personNum <= 0) {
                tempDishes.personNum = 1;
            }
        }
        tempDishes.thirdOrderID = rapidOrder.orderId;
        tempDishes.thirdBizType = rapidOrder.bizType;
        RapidBiz.buildOrder(resultData, tempDishes, rapidOrder);
        return tempDishes;
    }

    public static TempOrderDishesCache submitOrder(RapidActionModel resultData, RapidOrder rapidorder,
                                                   String commitID) {
        TempOrderDishesCache tempDishes = buildTempOrder(resultData, rapidorder, commitID);

        if (resultData.result == RapidResult.SUCCESS && tempDishes != null) {
            /* 构建订单成功下单 */
            RapidBiz.order(resultData, tempDishes, rapidorder);
        }
        return tempDishes;
    }

    /**
     * 构建基础的订单信息
     *
     * @param rapidOrder           拉单参数
     * @param orderCache           桌台上的订单
     * @param tempSelectedMenuList 现付款模式下的临时订单----先付款下的菜品
     * @return 如果桌台上没有订单信息返回 null
     */
    @NonNull
    public static RapidOrder buildRapidOrder(RapidfstData rapidOrder, OrderCache orderCache, List<MenuItem>
            tempSelectedMenuList) {
        if (orderCache == null) {
            return null;
        }
        RapidOrder existOrder = new RapidOrder(rapidOrder);
        JSONObject shop = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsShopGUID,fsShopName,fsCompanyGUID from " +
                "tbshop");
        existOrder.manageShopId = shop.getString("fsCompanyGUID");
        existOrder.shopId = shop.getString("fsShopGUID");
        existOrder.shopName = shop.getString("fsShopName");
        existOrder.bizType = orderCache.thirdOrderType; // 业务类型
        if (existOrder.bizType == 0 || existOrder.bizType == 14 || existOrder.bizType == NetOrderType.KB_AFTER_PAY_ORDER) {
            existOrder.bizType = 15;
        }
        existOrder.discountType = 0;
        existOrder.clientStatus = 1; // 客户端在线状态 在线
        existOrder.diningStatus = 20; // 就餐状态 下单到厨房
        existOrder.placeOrderTime = orderCache.businessDate + " " + orderCache.createTime;
        RapidBiz.convert(existOrder, orderCache, tempSelectedMenuList);
        return existOrder;
    }

    @NonNull
    private static RapidOrder buildRapidOrder(RapidOrder rapidOrder, TempOrderDishesCache tempOrder) {
        if (tempOrder == null) {
            return null;
        }
        RapidOrder existOrder = new RapidOrder(rapidOrder);
        JSONObject shop = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsShopGUID,fsShopName,fsCompanyGUID from " +
                "tbshop");
        existOrder.manageShopId = shop.getString("fsCompanyGUID");
        existOrder.shopId = shop.getString("fsShopGUID");
        existOrder.shopName = shop.getString("fsShopName");
        existOrder.bizType = tempOrder.thirdBizType; // 业务类型
        if (existOrder.bizType == 0 || existOrder.bizType == 14 || existOrder.bizType == NetOrderType.KB_AFTER_PAY_ORDER) {
            existOrder.bizType = 15;
        }
        existOrder.discountType = 0;
        existOrder.clientStatus = 1; // 客户端在线状态 在线
        existOrder.diningStatus = 0; // 就餐状态 下单到厨房
        existOrder.orderId = tempOrder.optFirstThirdOrderID();

        existOrder.placeOrderTime = tempOrder.tempCreateTime;
        RapidBiz.convert(existOrder, tempOrder);
        return existOrder;
    }

    public static void submitPay(RapidActionModel resultData, RapidPayment payment) {
        if (!BaseConfig.isProduct()) {
            LogUtil.log("收到的秒付信息:\n" + JSON.toJSONString(payment));
        }
        RapidBiz.buildPayment(resultData, payment);
    }
}
