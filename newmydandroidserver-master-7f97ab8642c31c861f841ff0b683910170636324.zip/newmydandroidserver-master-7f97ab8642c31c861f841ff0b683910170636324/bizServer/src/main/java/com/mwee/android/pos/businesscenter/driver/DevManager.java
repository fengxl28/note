package com.mwee.android.pos.businesscenter.driver;

import android.content.Context;
import android.os.Build;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.log.LogBizConfigBuilder;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.android.tools.log.Zip;
import com.mwee.myd.server.util.ServerHardwareUtil;

import org.json.JSONObject;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/**
 * @ClassName: DevManager
 * @Description:
 * @author: SugarT
 * @date: 2018/1/16 上午10:06
 */
public class DevManager implements IDriver {

    public static final String DRIVER_TAG = "dev";

    private volatile static DevManager instance;

    public static DevManager getInstance() {
        if (instance == null) {
            synchronized (DevManager.class) {
                if (instance == null) {
                    instance = new DevManager();
                }
            }
        }
        return instance;
    }

    /**
     * 上传 database
     *
     * @param context
     */
    @DrivenMethod(uri = DRIVER_TAG + "/uploadDB")
    public void uploadDB(Context context) {
        new LowThread(() -> {
            String dbPath = context.getDatabasePath(APPConfig.DB_MAIN).getParent();
            RunTimeLog.addLog(RunTimeLog.UPLOAD_DATABASE, "数据库源文件夹路径: " + dbPath);
            String tarFloder = buildZipFileParent(context);
            String tarPath = tarFloder + buildZipFile(context);
            RunTimeLog.addLog(RunTimeLog.UPLOAD_DATABASE, "数据库目标压缩路径: " + tarPath);
            try {
                Zip.ZipFolder(dbPath, tarPath);
                upload(context, tarFloder);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    public String buildZipFileParent(Context context) {
        return context.getExternalCacheDir().getPath() + File.separator + "databases" + File.separator;
    }

    /**
     * 获取压缩的文件名
     *
     * @param context
     * @return
     */
    public String buildZipFile(Context context) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault());
        String time = formatter.format(new Date());
        return  "databases_" + time + ".zip";
    }

    public void upload(Context context, String path) {
        try {
            File dirFile = new File(path);
            File[] list = dirFile.listFiles();
            HashMap<String, String> params = new HashMap<>();

            params.put("SessionID", LogUpload.SESSION);
            params.put("shopId", DBSimpleUtil.queryString(APPConfig.DB_CLIENT, "SELECT value FROM meta WHERE key='" + META.SHOPID + "'"));
            params.put("Model", Build.MODEL);
            params.put("SDKVer", Build.VERSION.SDK_INT + "");
            params.put("APPVer", context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName);
            params.put("DeviceID", ServerHardwareUtil.getHardWareSymbol());

            for (final File file : list) {
                if (file.isDirectory()) {
                    continue;
                }
                if (!file.getName().endsWith(".zip")) {
                    continue;
                }

                try {
                    String result = LogUpload.uploadFile(getServerUrl(), params, file, "Bbox");
                    RunTimeLog.addLog(RunTimeLog.UPLOAD_DATABASE, "数据库上传结果: " + result);
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.optInt("errno") == 0) {
                        FileUtil.deleteAllFile(file);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } catch (Error e) {
                    e.printStackTrace();
                }
            }

        } catch (Exception ex) {

        }
    }

    /**
     * 获取上传服务器地址
     *
     * @return
     */
    public String getServerUrl() {
        if (BaseConfig.isDEV()) {
            return "http://st.9now.net/shop/error.php";
        } else {
            return LogBizConfigBuilder.URL_LOG_SERVER_PRODUCT;
        }
    }

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
