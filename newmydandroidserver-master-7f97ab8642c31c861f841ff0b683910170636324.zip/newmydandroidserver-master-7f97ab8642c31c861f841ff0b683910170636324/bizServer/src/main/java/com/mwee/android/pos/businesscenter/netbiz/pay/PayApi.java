package com.mwee.android.pos.businesscenter.netbiz.pay;

import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.netpay.RefundQueryRequest;
import com.mwee.android.pos.business.netpay.RefundRequest;

/**
 * 支付的一些网络操作
 * Created by virgil on 16/7/18.
 */
public class PayApi {
    /*public static void sendRefund(String orderID, String businessInfo, IExecutorCallback callback) {
        NetPayRefundRequest refundRequest = new NetPayRefundRequest();
        refundRequest.pay_order = businessInfo;
        refundRequest.fssellno = orderID;
        BusinessExecutor.execute(refundRequest, callback);
    }*/

    /**
     * 退款请求
     * @param payOrder
     * @param callback
     */
    public static void sendRefund(String payOrder, IExecutorCallback callback) {
        RefundRequest refundRequest = new RefundRequest();
        refundRequest.pay_order = payOrder;
        BusinessExecutor.execute(refundRequest, callback);
    }

    /**
     * 查询退款结果
     * @param payOrder
     * @param callback
     */
    public static void refundQuery(String payOrder, IExecutorCallback callback) {
        RefundQueryRequest refundRequest = new RefundQueryRequest();
        refundRequest.pay_order = payOrder;
        BusinessExecutor.execute(refundRequest, callback);
    }
}
