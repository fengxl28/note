package com.mwee.android.pos.businesscenter.business.washdata;

import com.mwee.android.base.net.BusinessBean;

/**
 * 洗数据配置
 */
public class WashDataConfig extends BusinessBean {

    /**
     * see{@link WashDataType#BEFORE_SYNC} 对应的版本号
     */

    public int versionBeforeSync = 0;

    /**
     * see{@link WashDataType#AFTER_SYNC} 对应的版本号
     */
    public int versionAfterSync = 0;

    public WashDataConfig() {
    }
}
