package com.mwee.android.pos.businesscenter.netbiz.wechatfastfood;

import android.text.TextUtils;

import com.mwee.android.pos.base.Cache;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by liuxiuxiu on 2018/6/12.
 */

public class WechatFastfoodCache extends Cache {
    public final String LOG_CONSTANCE = "微信快餐锁 ";
    /**
     * 微信快餐订单操作锁
     */
    private HashMap<String, ReentrantLock> lockPool = new HashMap<>();

    public WechatFastfoodCache() {
    }

    /**
     * 加锁
     *
     * @param orderId
     * @param log
     */
    public synchronized void doLock(String orderId, String log) {
        LogUtil.logBusiness(LOG_CONSTANCE + " 上锁 [" + orderId + "] 时间：" + DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss:SSS") + "; log = " + log);
        ReentrantLock lock = lockPool.get(orderId);
        if (lock == null) {
            lock = new ReentrantLock();
            lockPool.put(orderId, lock);
        }
        lock.lock();
    }

    /**
     * 解锁
     *
     * @param orderId
     * @param log
     */
    public synchronized void unLock(String orderId, String log) {
        LogUtil.logBusiness(LOG_CONSTANCE + " 解锁 [" + orderId + "] 时间：" + DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss:SSS") + "; log = " + log);
        ReentrantLock lock = lockPool.get(orderId);
        if (lock != null) {
            if (lock.getQueueLength() > 0) {
                lock.unlock();
            } else {
                lock.unlock();
                lockPool.remove(orderId);
                LogUtil.logBusiness(LOG_CONSTANCE + " 解锁 [" + orderId + "] 时间：" + DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss:SSS") + "; 已经没有线程等待这个锁，将此锁移除出缓存");
            }
        }
    }

    public void init() {
    }

    @Override
    public void refresh() {

    }

    @Override
    public void clean() {
        HashMap<String, ReentrantLock> lockMap = new HashMap<>();
        lockMap.putAll(lockPool);
        for (String key : lockMap.keySet()) {
            ReentrantLock lock = lockMap.get(key);
            if (lock != null && lock.getQueueLength() <= 0) {
                lockPool.remove(key);
            }
        }
    }
}
