package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.bargain.GetBargainListResponse;
import com.mwee.android.air.connect.business.tprinter.GetTPrinterListRequest;
import com.mwee.android.air.connect.business.tprinter.GetTPrinterListResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrinterSource;
import com.mwee.android.pos.businesscenter.air.dbUtil.TPrinterUtils;
import com.mwee.android.pos.component.datasync.net.GetTableQRShortLinkResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.GetAllPrinterResponse;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.tools.LogUtil;

/**
 * Description: 与美收银区分开
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/6/5
 */
public class AirNewPrinterDriver implements IDriver {
    private static final String TAG = "airNewPrinter";

    @Override
    public String getModuleName() {
        return TAG;
    }


    @DrivenMethod(uri = TAG + "/replaceTDeptItemCut")
    public SocketResponse replaceTDeptItemCut(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            int fiIsOneItemCut = request.getObject("fiIsOneItemCut", Integer.class);
            PrinterSource printerSource = new PrinterSource();
            printerSource.updateTDeptItemCut(fiIsOneItemCut, userDBModel);
//            TPrinterUtils.updateTDeptItemCut(fiIsOneItemCut, userDBModel);

            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/fiReverse")
    public SocketResponse updateTSCReverse(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            int fiReverse = request.getObject("fiReverse", Integer.class);
            PrinterSource printerSource = new PrinterSource();
            printerSource.updateTSCReverse(fiReverse, userDBModel);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/loadAllPrinter")
    public SocketResponse loadAllPrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
//            List<PrinterDBModel> allPrinters = TPrinterUtils.queryAll();
            GetAllPrinterResponse allPrinterResponse = new GetAllPrinterResponse();
            PrinterSource printerSource = new PrinterSource();
            allPrinterResponse.printerItems = printerSource.queryAllPrinters(head.hd);
//            if (!ListUtil.isEmpty(allPrinters)) {
//                allPrinterResponse.printerItems = TPrinterUtils.build(head.hd, allPrinters);
//            }

            response.data = allPrinterResponse;
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAddPrinter")
    public SocketResponse loadAddPrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSONObject.parseObject(param);
        PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
        if (printerItem == null) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "非法请求";
            return response;
        }
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            PrinterDBModel old = TPrinterUtils.queryAllPrinterByName(printerItem.name);
            PrinterSource printerSource = new PrinterSource();
            if (old == null) {
//                TPrinterUtils.addPrinter(printerItem, head.hd, userDBModel);
                printerSource.addPrinterByAir(printerItem, head.hd, userDBModel);
                response.code = SocketResultCode.SUCCESS;
                response.message = "成功";
            } else if (old.fiStatus == 1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印机[" + printerItem.name + "] 已存在";
            } else if (old.fiStatus == 13) {
                //打印被删除 恢复操作
//                old.fiStatus = 1;
//                old.replaceNoTrans();
                printerItem.id = old.fiID;
//                TPrinterUtils.updatePrinter(printerItem, head.hd, userDBModel);

                printerSource.updatePrinter(printerItem, head.hd, userDBModel);
                response.code = SocketResultCode.SUCCESS;
                response.message = "成功";
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadUpdatePrinter")
    public SocketResponse loadUpdatePrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSONObject.parseObject(param);
        PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
        if (printerItem == null) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "非法请求";
            return response;
        }
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);

            PrinterDBModel printerDBModel = TPrinterUtils.queryById(printerItem.id);
            PrinterSource printerSource = new PrinterSource();
            if (printerDBModel == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印机[" + printerItem.name + "] 不存在，修改失败";
                return response;
            }
            PrinterDBModel old = TPrinterUtils.queryAllPrinterByName(printerItem.name);
            if (!TextUtils.equals(printerDBModel.fsPrinterName, printerItem.name) && old != null) {
                if (old.fiStatus == 1) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "打印机[" + printerItem.name + "] 已存在";
                    return response;
                }
                printerItem.id = old.fiID;
            }
            printerSource.updatePrinter(printerItem, head.hd, userDBModel);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/loadDeletePrinter")
    public SocketResponse loadDeletePrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
            if (TPrinterUtils.queryById(printerItem.id) == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "你要删除的打印机不存在！";
                return response;
            }
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            PrinterSource printerSource = new PrinterSource();
            printerSource.deletePrinter(printerItem, head.hd, userDBModel);
//            TPrinterUtils.delete(printerItem.id, userDBModel,printerItem.depId);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = TAG + "/loadTPrinterList")
    public SocketResponse loadTPrinterList(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject params = JSON.parseObject(param);
            String suitableProd = params.getString("suitableProd");
            GetTPrinterListRequest request = new GetTPrinterListRequest();
            request.suitableProd = suitableProd;
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof GetTPrinterListResponse) {
                        response.data = responseData.responseBean;
                        response.code = SocketResultCode.SUCCESS;
                    } else {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    response.code = SocketResultCode.EXCEPTION;
                    response.message = responseData.resultMessage;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }
}
