package com.mwee.android.pos.businesscenter.netbiz.member;

import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.base.task.net.NetJob;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.ActiveNoNameCardRequest;
import com.mwee.android.pos.business.member.ActiveNoNameCardResponse;
import com.mwee.android.pos.business.member.BindMemberEntityCardRequest;
import com.mwee.android.pos.business.member.BindMemberEntityCardResponse;
import com.mwee.android.pos.business.member.CheckCardTypeRequest;
import com.mwee.android.pos.business.member.CheckCardTypeResponse;
import com.mwee.android.pos.business.member.MemberBalanceChangedListRequest;
import com.mwee.android.pos.business.member.MemberBalanceChangedResponse;
import com.mwee.android.pos.business.member.MemberConfigRequest;
import com.mwee.android.pos.business.member.MemberConfigResponse;
import com.mwee.android.pos.business.member.MemberCouponRequest;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.business.member.MemberRechargePayTypeDefined;
import com.mwee.android.pos.business.member.ValidateCodeRequest;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.business.member.entity.MemberHistoryResponse;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.dbutil.CardRelationDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.air.AirPrinterSelect;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.BaseMemberResponse;
import com.mwee.android.pos.component.member.net.GetMemberCardByCardNoRequest;
import com.mwee.android.pos.component.member.net.GetMemberCardResponse;
import com.mwee.android.pos.component.member.net.GetMemberRechargeOrderRequest;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageRequest;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageResponse;
import com.mwee.android.pos.component.member.net.MemberConsumePreSearchRequest;
import com.mwee.android.pos.component.member.net.MemberConsumePreSearchResponse;
import com.mwee.android.pos.component.member.net.MemberHistoryScoreSearchRequest;
import com.mwee.android.pos.component.member.net.MemberHistoryScoreSearchResponse;
import com.mwee.android.pos.component.member.net.NewMemberChargeOnlineRequest;
import com.mwee.android.pos.component.member.net.QueryNewMemberChargeResultRequest;
import com.mwee.android.pos.component.member.net.QueryNewMemberChargeResultResponse;
import com.mwee.android.pos.component.member.net.model.FoodInfoModel;
import com.mwee.android.pos.component.member.net.model.MemberCouponConsumeData;
import com.mwee.android.pos.component.member.net.model.MemberCouponConsumeModel;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.component.member.net.model.MemberCouponRefundData;
import com.mwee.android.pos.component.member.net.model.MemberCouponType;
import com.mwee.android.pos.component.member.net.model.MemberPreConsumeModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberCouponQueryData;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponConsumeResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponGetRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponQueryRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponQueryResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBindEntityCardResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBindEntityCardResultRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberVerifyCodeResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Created by virgil on 2016/10/11.
 *
 * @author virgil
 */

public class MemberApi {

    /**
     * 获取会员配置信息
     *
     * @param shopID  分店ID
     * @param mShopID 总店ID
     */
    public static void loadMemberConfig(String shopID, String mShopID, IResponse<MemberConfig> callback) {
        MemberConfigRequest request = new MemberConfigRequest();
        request.companyGUID = Integer.valueOf(mShopID);
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberConfigResponse) {
                    MemberConfigResponse response = (MemberConfigResponse) responseData.responseBean;
                    callback.callBack(true, responseData.result, responseData.resultMessage, response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 获取会员历史积分
     *
     * @param cardNo String | 会员卡号
     * @param lastID int | 最后一条记录数
     */
    public static void loadMemberHistoryScore(String cardNo, int lastID, IResponse<MemberHistoryResponse> callback) {
        MemberHistoryScoreSearchRequest request = new MemberHistoryScoreSearchRequest();
        request.card_no = cardNo;
        request.last_id = lastID;
        request.pagesize = 20;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberHistoryScoreSearchResponse) {
                    MemberHistoryScoreSearchResponse response = (MemberHistoryScoreSearchResponse) responseData.responseBean;
                    callback.callBack(true, responseData.result, responseData.resultMessage, response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void loadMemberBalanceChangedData(String cardNo, String lastID, int limit, IResponse<BalanceOrderList> callback) {
        MemberBalanceChangedListRequest request = new MemberBalanceChangedListRequest();
        request.card_no = cardNo;
        request.last_id = lastID;
        request.limit = limit;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceChangedResponse) {
                    MemberBalanceChangedResponse response = (MemberBalanceChangedResponse) responseData.responseBean;
                    callback.callBack(true, responseData.result, responseData.resultMessage, response.data);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void loadMemberRechargePackage(String csID, String version, IResponse<GetMemberRechargePackageResponse> callback) {
        GetMemberRechargePackageRequest request = new GetMemberRechargePackageRequest();
        request.cs_id = csID;
        request.v = version;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberRechargePackageResponse) {
                    GetMemberRechargePackageResponse response = (GetMemberRechargePackageResponse) responseData.responseBean;
                    callback.callBack(true, responseData.result, responseData.resultMessage, response);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void loadMemberCoupons(String shopID, String mShopID, String cardNo, int page, int pageSize, IResponse<MemberCouponResponse> callback) {
        MemberCouponRequest request = new MemberCouponRequest();
        request.card_no = cardNo;
        request.page = page;
        request.shopid = Integer.valueOf(shopID);
        request.m_shopid = Integer.valueOf(mShopID);
        request.pageSize = pageSize;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData == null) {
                    return;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberCouponResponse) {
                    MemberCouponResponse response = (MemberCouponResponse) responseData.responseBean;
                    callback.callBack(true, responseData.result, responseData.resultMessage, response);
                }

            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData == null) {
                    return false;
                }
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    public static void loadMemberRechargeOrder(String tradeNo, IExecutorCallback callback) {
        GetMemberRechargeOrderRequest request = new GetMemberRechargeOrderRequest();
        request.trade_no = tradeNo;
        BusinessExecutor.execute(request, callback, false);
    }
/*//TODO 会员重构---    已废弃
    public static void sendConsumeBalance(final OrderCache orderCache, final String thirdOrderID, final String password, final BigDecimal amount, final String pay_code, final IMemberBalance memberBalance) {
        if (TextUtils.isEmpty(pay_code)) {
            sendRefreshMemberSession(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        sendConsumeBalance(orderCache, thirdOrderID, password, amount, orderCache.memberInfoS.pay_code, memberBalance);
                    } else {
                        memberBalance.process(info, null, false);
                    }
                }
            });
            return;
        }

        MemberBalanceConsumeRequest request = new MemberBalanceConsumeRequest();
        request.amount = amount;
        request.card_no = pay_code;
        request.password = password;
        request.out_trade_no = thirdOrderID;
        request.device_id = ServerHardwareUtil.getHardWareSymbol();

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "OrderBizUtil#sendConsumeBalance ------会员回调-- 支付业务中心-");
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceConsumeResponse) {
                    memberBalance.process("", (MemberBalanceConsumeResponse) responseData.responseBean, false);
                } else {
                    memberBalance.process("支付失败，请重试", null, false);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null) {
                    if (responseData.responseBean.status == 203 || responseData.responseBean.errno == 203) {
                        memberBalance.process("需要输入储值密码", null, true);
                    } else if (responseData.responseBean.status == 500 || responseData.responseBean.errno == 500) {
                        RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付结果 会员payCode已过期，开始自动刷新 cardNO=" + orderCache.memberInfoS.card_no, orderCache.orderID, orderCache.fsmtableid, responseData, pay_code);
                        // TODO: 2018/9/24 异步
                        sendRefreshMemberSession(orderCache, orderCache.memberInfoS.card_no, new IResult() {
                            @Override
                            public void callBack(boolean result, String info) {
                                if (result) {
                                    sendConsumeBalance(orderCache, thirdOrderID, password, amount, orderCache.memberInfoS.pay_code, memberBalance);
                                } else {
                                    memberBalance.process(info, null, false);
                                }
                            }
                        });
                    } else {
                        memberBalance.process(responseData.resultMessage, null, false);
                    }
                } else {
                    memberBalance.process(responseData.resultMessage, null, false);
                }
                return false;
            }
        });
        job.execute();

//        BusinessExecutor.execute(request, null, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceConsumeResponse) {
//                    memberBalance.process("", (MemberBalanceConsumeResponse) responseData.responseBean, false);
//                } else {
//                    memberBalance.process("支付失败，请重试", null, false);
//                }
//                return false;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (responseData.responseBean != null) {
//                    if (responseData.responseBean.status == 203 || responseData.responseBean.errno == 203) {
//                        memberBalance.process("需要输入储值密码", null, true);
//                    } else if (responseData.responseBean.status == 500 || responseData.responseBean.errno == 500) {
//                        RunTimeLog.addLog(RunTimeLog.PAY_MEM_BALANCE, "储值支付结果 会员payCode已过期，开始自动刷新 cardNO=" + orderCache.memberInfoS.card_no, orderCache.orderID, orderCache.fsmtableid, responseData, pay_code);
//                        sendRefreshMemberSession(orderCache, orderCache.memberInfoS.card_no, new IResult() {
//                            @Override
//                            public void callBack(boolean result, String info) {
//                                if (result) {
//                                    sendConsumeBalance(orderCache, thirdOrderID, password, amount, orderCache.memberInfoS.pay_code, memberBalance);
//                                } else {
//                                    memberBalance.process(info, null, false);
//                                }
//                            }
//                        });
//                    } else {
//                        memberBalance.process(responseData.resultMessage, null, false);
//                    }
//                } else {
//                    memberBalance.process(responseData.resultMessage, null, false);
//                }
//                return false;
//            }
//        });
    }*/


    /**
     * 会员重构---已废弃
     *
     * @param orderCache
     * @param cardNo
     * @param callBack
     */
    public static void sendRefreshMemberSession(final OrderCache orderCache, final String cardNo, final IResult callBack) {
        GetMemberCardByCardNoRequest getMemberCardByCardNoRequest = new GetMemberCardByCardNoRequest();
        getMemberCardByCardNoRequest.card_no = cardNo;

        NetJob job = new NetJob(getMemberCardByCardNoRequest);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息", orderCache.orderID, orderCache.fsmtableid, responseData);
                if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                    GetMemberCardResponse response = (GetMemberCardResponse) responseData.responseBean;
                    orderCache.refreshMember(response.data);
                    OrderSaveDBUtil.upateMemberInfo(orderCache.orderID, JSON.toJSONString(orderCache.memberInfoS));
                    if (callBack != null) {
                        callBack.callBack(true, "");
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (callBack != null) {
                    callBack.callBack(false, responseData.resultMessage);
                }
                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息失败", orderCache.orderID, orderCache.fsmtableid, responseData);
                return false;
            }
        });
        job.execute();

//        BusinessExecutor.execute(getMemberCardByCardNoRequest, null, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息", orderCache.orderID, orderCache.fsmtableid, responseData);
//                if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
//                    GetMemberCardResponse response = (GetMemberCardResponse) responseData.responseBean;
//                    orderCache.refreshMember(response.data);
//                    OrderSaveDBUtil.upateMemberInfo(orderCache.orderID, JSON.toJSONString(orderCache.memberInfoS));
//                    if (callBack != null) {
//                        callBack.callBack(true, "");
//                    }
//                }
//                return false;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (callBack != null) {
//                    callBack.callBack(false, responseData.resultMessage);
//                }
//                RunTimeLog.addLog(RunTimeLog.PAY_GET_MEMBER, "获取会员信息失败", orderCache.orderID, orderCache.fsmtableid, responseData);
//                return false;
//            }
//        });
    }

    /**
     * @param payList
     * @param amount
     * @param cannotDiscount 订单不可折扣金额（不可折扣菜品金额合计+服务费）
     * @param cardNO
     * @param serverCallback
     */
    public static void sendPreSearchConsume(List<PayModel> payList, BigDecimal amount, BigDecimal cannotDiscount, String cardNO, final BusinessCallback serverCallback) {
        final MemberConsumePreSearchRequest request = new MemberConsumePreSearchRequest();
        request.amount = amount;
        request.card_no = cardNO;
        request.coupon_code = PayUtil.getMemberTicketCode(payList);
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(request.coupon_code)) {
            sb.append("3,");
        }
        if (PayUtil.hasMemberPoint(payList)) {
            sb.append("4,");
        }
        if (PayUtil.hasMemberBalance(payList)) {
            sb.append("5,");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        request.drop_amount = cannotDiscount;
        if (request.drop_amount.compareTo(BigDecimal.ZERO) < 0) {
            request.drop_amount = BigDecimal.ZERO;
        }
        request.usePreferential = sb.toString();

        NetJob job = new NetJob(request);
        job.setServerThreadCallback(new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.logBusiness("===SCAN=PAY===", "MemberApi#sendPreSearchConsume ------会员回调-- 支付业务中心-");

                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
                    MemberConsumePreSearchResponse response = (MemberConsumePreSearchResponse) responseData.responseBean;
                    if (!request.usePreferential.contains("4") && response.data != null && response.data.no_use_score != null) {
                        response.data.user_all_score = response.data.no_use_score.user_all_score;
                        response.data.use_score = response.data.no_use_score.use_score;
                        response.data.score_money = response.data.no_use_score.score_money;
                        response.data.cost_bonus_unit = response.data.no_use_score.cost_bonus_unit;
                    }
                    processMemberPreConsumeResponse(responseData);
                }
                if (serverCallback != null) {
                    serverCallback.success(i, responseData);
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (serverCallback != null) {
                    serverCallback.fail(i, responseData);
                }
                return false;
            }
        });
        job.execute();

//        BusinessExecutor.execute(request, new IExecutorCallback() {
//            @Override
//            public void success(ResponseData responseData) {
//
//            }
//
//            @Override
//            public boolean fail(ResponseData responseData) {
//                return false;
//            }
//        }, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
//                    MemberConsumePreSearchResponse response = (MemberConsumePreSearchResponse) responseData.responseBean;
//                    if (!request.usePreferential.contains("4") && response.data != null && response.data.no_use_score != null) {
//                        response.data.user_all_score = response.data.no_use_score.user_all_score;
//                        response.data.use_score = response.data.no_use_score.use_score;
//                        response.data.score_money = response.data.no_use_score.score_money;
//                        response.data.cost_bonus_unit = response.data.no_use_score.cost_bonus_unit;
//                    }
//                    processMemberPreConsumeResponse(responseData);
//                }
//                if (serverCallback != null) {
//                    serverCallback.success(i, responseData);
//                }
//                return true;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
//                if (serverCallback != null) {
//                    serverCallback.fail(i, responseData);
//                }
//                return false;
//            }
//        }, false);
    }

    private static void processMemberPreConsumeResponse(ResponseData responseData) {
        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConsumePreSearchResponse) {
            MemberPreConsumeModel data = ((MemberConsumePreSearchResponse) responseData.responseBean).data;
            if (!TextUtils.isEmpty(data.checkTicketCanUse())) {
                data.coupons_list = null;
            }
            if (!TextUtils.isEmpty(data.checkBalanceCanUse())) {
                data.is_pay_can_use = 0;
            }
            if (!TextUtils.isEmpty(data.checkPointCanUse())) {
                data.use_score = 0;
                data.score_money = BigDecimal.ZERO;
            }
            filterMemberCoupon(data);
        }

    }

    /**
     * 过滤会员的券
     *
     * @param data MemberPreConsumeModel
     * @return MemberPreConsumeModel
     */
    private static MemberPreConsumeModel filterMemberCoupon(MemberPreConsumeModel data) {
        if (data == null) {
            return null;
        }

        if (!ListUtil.isEmpty(data.coupons_list)) {
            String sql = "select fsNote from tbPayment where fsPaymentTypeId in ('30','31','32') and fiStatus = '1'";
            List<String> noteList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
            for (int i = 0; i < data.coupons_list.size(); i++) {
                MemberCouponModel temp = data.coupons_list.get(i);
                boolean exist = false;
                for (String tempCouponID : noteList) {
                    if (TextUtils.equals(temp.coupon_id, tempCouponID)) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    data.coupons_list.remove(i);
                    i--;
                }
            }
        }
        return data;
    }


    /**
     * 使用会员优惠券
     *
     * @param session          PaySession
     * @param orderCache       OrderCache
     * @param currentSelectPay PayModel
     * @return String | 异常信息，如果非空，表示使用会员优惠券失败
     */
    public static String useMemberCoupon(final PaySession session, final OrderCache orderCache, String memberCardNO, final PayModel currentSelectPay) {
        currentSelectPay.memberCardNO = memberCardNO;
        currentSelectPay.ticketCode = currentSelectPay.data.memberCouponModel.code;
        switch (currentSelectPay.data.memberCouponModel.c_type) {
            case MemberCouponType.CASH:
                BigDecimal leftToPay = PayUtil.getLeftToPayIgnoreService(session, orderCache);
                BigDecimal canDiscount = BigDecimal.ZERO;
                if (currentSelectPay.data.checkForDiscount()) {
                    canDiscount = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);
                    if (canDiscount.compareTo(BigDecimal.ZERO) == 0) {
                        return "可抵扣的金额为0，不能使用此券";
                    }
                } else {
                    canDiscount = leftToPay;
                }
                currentSelectPay.payAmount = currentSelectPay.data.memberCouponModel.price;
                if (currentSelectPay.data.checkForDiscount()) {
                    checkMemberCouponForChange(currentSelectPay, currentSelectPay.payAmount, canDiscount);
                }
                break;
            case MemberCouponType.DISCOUNT: {
                //折扣券
                if (TextUtils.isEmpty(currentSelectPay.data.memberCouponModel.discount)) {
                    return ("券的折扣率设置的不正确，不能使用这张券");
                }
                BigDecimal discountPercent = new BigDecimal(currentSelectPay.data.memberCouponModel.discount);
                if (discountPercent.compareTo(BigDecimal.ZERO) <= 0 || discountPercent.compareTo(BizConstant.HUNDREND) >= 0) {
                    return ("券的折扣率设置的不正确，不能使用这张券");
                }
                BigDecimal totalPrice = orderCache.optTotalMenuPrice();
                if (currentSelectPay.data.checkForDiscount()) {
                    //获取可折扣的菜品金额
                    totalPrice = PayUtil.getDiscountAmtByOrderTotal(orderCache);
                }
                final BigDecimal discountPrice = totalPrice.multiply(discountPercent).divide(BizConstant.HUNDREND, 2, BigDecimal.ROUND_HALF_UP);
                currentSelectPay.payAmount = totalPrice.subtract(discountPrice);
                if (currentSelectPay.payAmount.compareTo(BigDecimal.ZERO) < 0) {
                    currentSelectPay.payAmount = BigDecimal.ZERO;
                }
            }
            break;
            case MemberCouponType.REDUCE: {
                //满减券
                //先处理异常数据
                if (currentSelectPay.data.memberCouponModel.full == null || currentSelectPay.data.memberCouponModel.full.compareTo(BigDecimal.ZERO) < 0) {
                    currentSelectPay.data.memberCouponModel.full = BigDecimal.ZERO;
                }
                if (currentSelectPay.data.memberCouponModel.pmt_price == null || currentSelectPay.data.memberCouponModel.pmt_price.compareTo(BigDecimal.ZERO) < 0) {
                    currentSelectPay.data.memberCouponModel.pmt_price = BigDecimal.ZERO;
                }

                if (currentSelectPay.data.checkForDiscount()) {
                    //获取可折扣的菜品金额
                    BigDecimal totalPrice = PayUtil.getDiscountAmtByLeftToPay(session, orderCache);
                    if (totalPrice.compareTo(currentSelectPay.data.memberCouponModel.full) >= 0) {
                        currentSelectPay.payAmount = currentSelectPay.data.memberCouponModel.pmt_price;
                    } else {
                        return ("订单可折扣金额[" + totalPrice.toPlainString() + "]小于该券设置的满[" + currentSelectPay.data.memberCouponModel.full.toPlainString() + "]的要求，不能使用。");
                    }
                } else {
                    if (orderCache.optTotalMenuPrice().compareTo(currentSelectPay.data.memberCouponModel.full) >= 0) {
                        currentSelectPay.payAmount = currentSelectPay.data.memberCouponModel.pmt_price;
                    } else {
                        return ("订单消费金额[" + orderCache.optTotalMenuPrice().toPlainString() + "]小于该券设置的满[" + currentSelectPay.data.memberCouponModel.full.toPlainString() + "]的要求，不能使用。");
                    }
                }
            }
            break;
            default:
                return ("暂不支持这种券");
        }

        return "";
    }

    /**
     * 处理门店券的免找
     *
     * @param currentSelectPay  PayModel | 选择的券
     * @param payAmoun          BigDecimal
     * @param canDiscountAmount BigDecimal
     */
    public static void checkMemberCouponForChange(PayModel currentSelectPay, BigDecimal payAmoun, BigDecimal canDiscountAmount) {
        //计算是否需要进行免找
        BigDecimal subValue = payAmoun.subtract(canDiscountAmount);
        if (subValue.compareTo(BigDecimal.ZERO) > 0) {
            if (currentSelectPay.subPayList == null) {
                currentSelectPay.subPayList = new ArrayList<>();
            }
            PayOriginModel payTypeCouponGiven = OrderUtil.buildPayModelByParamID(DBPayConfig.PAY_COUPON_FREE);
            if (payTypeCouponGiven != null) {
                PayModel model = new PayModel(currentSelectPay.waiterID, currentSelectPay.waiterName);
                model.data = payTypeCouponGiven;
                model.payAmount = subValue.negate();
                currentSelectPay.subPayList.add(model);
            }
        }
    }

    /**
     * 会员充值
     *
     * @param ruleID
     * @param amount
     * @param pay_code
     * @param payType
     * @param micro
     * @param cardNo
     * @param callback
     */
    public static void sendOnlineRechargeRequest(int ruleID, BigDecimal amount, String pay_code, int payType, String micro, String cardNo, IResponse<QueryNewMembeChargeResultModel> callback) {

        List<BaseRequest> list = new ArrayList<>();
        NewMemberChargeOnlineRequest request = new NewMemberChargeOnlineRequest();
        request.pay_price = Calc.format(amount, 0, RoundingMode.DOWN).intValue();
        request.card_no = cardNo;
        request.pay_code = pay_code;

        request.rule_id = ruleID;
        request.pay_micro = micro;

        request.pay_class = payType;

        switch (payType) {
            case MemberRechargePayTypeDefined.PayClassDefined.ALIPAY:
                request.pay_type = MemberRechargePayTypeDefined.PayTypeDefined.ALIPAY;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.WECHAT:
                request.pay_type = MemberRechargePayTypeDefined.PayTypeDefined.WEIXIN;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.UP:
                request.pay_type = MemberRechargePayTypeDefined.PayTypeDefined.UNIONPAY;
                break;
            case MemberRechargePayTypeDefined.PayClassDefined.BAIDU:
                request.pay_type = MemberRechargePayTypeDefined.PayTypeDefined.BAIFUBAO;
                break;
        }

        request.paysourceid = 105;
        request.pay_name = "Android-" + DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsshopName from tbshop ");
        request.device_id = ServerHardwareUtil.getHardWareSymbol();
        list.add(request);

        QueryNewMemberChargeResultRequest queryResultRequest = new QueryNewMemberChargeResultRequest();
        queryResultRequest.type = "1";
        queryResultRequest.sourceid = 105;
        queryResultRequest.v = "1.1";
        list.add(queryResultRequest);
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());
        list.add(queryResultRequest.clone());

        final String[] trade_no = {""};
        final long start = SystemClock.elapsedRealtime();

        BusinessExecutor.execute(list, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                boolean shouldContinue = false;
                if (responseData.responseBean != null) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值:" + responseData.responseBean.toString());

                    QueryNewMemberChargeResultResponse response = (QueryNewMemberChargeResultResponse) responseData.responseBean;
                    if (response.data != null) {

                        if (android.text.TextUtils.isEmpty(trade_no[0])) {
                            trade_no[0] = response.data.trade_no;
                            QueryNewMemberChargeResultRequest request;
                            for (int j = 1; j < list.size(); j++) {
                                request = (QueryNewMemberChargeResultRequest) list.get(j);
                                request.trade_no = trade_no[0];
                            }
                        }

                        if (response.data.pay_status == 1) {

                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--扣款 成功," + response.data.toString());
                            //101=>发起交易  102=>等待确认   103=>等待付款    104=>交易/支付完成   105=>退款
                            if (response.data.status == 105) {
                                shouldContinue = false;
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 失败" + response.data.toString());
                                if (callback != null) {
                                    callback.callBack(false, 2, android.text.TextUtils.isEmpty(response.data.pay_status_msg) ? "充值失败" : response.data.pay_status_msg, response.data);
                                }
                                updateMemberRechargeJob(trade_no[0]);
                            } else if (response.data.status == 104) {
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 成功," + response.data.toString());
                                shouldContinue = false;
                                if (callback != null) {
                                    if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                        response.data.trade_no = trade_no[0];
                                    }
                                    callback.callBack(true, 1, "", response.data);
                                }
                                updateMemberRechargeJob(trade_no[0]);
                            } else {
                                //充值中
                                addMemberRechargeJob(trade_no[0], cardNo);
                                if (i == list.size() - 1) {
                                    shouldContinue = false;
                                    if (callback != null) {
                                        if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                            response.data.trade_no = trade_no[0];
                                        }
                                        callback.callBack(true, 0, "", response.data);
                                    }
                                } else {
                                    shouldContinue = true;
                                    RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 进行中。。。" + response.data.toString());
                                }
                            }
                        } else if (response.data.pay_status == 2) {
                            //充值失败
                            shouldContinue = false;
                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--扣款 失败" + response.data.toString());
                            if (callback != null) {
                                callback.callBack(false, 2, android.text.TextUtils.isEmpty(response.data.pay_status_msg) ? "充值失败" : response.data.pay_status_msg, response.data);
                            }
                            updateMemberRechargeJob(trade_no[0]);
                        } else {
                            //充值中
                            addMemberRechargeJob(trade_no[0], cardNo);
                            if (i == list.size() - 1) {
                                shouldContinue = false;
                                if (callback != null) {
                                    if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                        response.data.trade_no = trade_no[0];
                                    }
                                    callback.callBack(true, 0, "", response.data);
                                }
                            } else {
                                shouldContinue = true;
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--扣款 中。。。" + response.data.toString());
                            }
                        }
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "开始查询充值结果" + response.data.trade_no);
                    } else if (i == 0) {
                        shouldContinue = false;
                    }
                }
                return shouldContinue;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                long out = SystemClock.elapsedRealtime() - start;
                //耗时超过3.5秒，则报警
                if (out > 3500) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, String.valueOf(out) + responseData.responseBean);
                }
                if (i == 0) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值" + responseData);
                } else {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "查询充值结果" + responseData);
                }
                if (callback != null) {
                    callback.callBack(false, 2, "充值失败", null);
                }
                return false;
            }
            //此处，需要明确传false进行阻塞
        }, false);

    }

    /**
     * 添加会员充值Job
     *
     * @param tradeNo
     * @param cardNo
     */
    public static void addMemberRechargeJob(String tradeNo, String cardNo) {
        if (android.text.TextUtils.isEmpty(tradeNo)) {
            return;
        }
        //  会员充值添加Job
        Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType.MEMBER_RECHARGE_QUERY_RESULT + "' AND biz_key = '" + tradeNo + "'", Job.class);
        if (job == null) {
            job = new Job();
            job.type = JobType.MEMBER_RECHARGE_QUERY_RESULT;
            job.biz_key = tradeNo;
            job.info = cardNo;
            job.cycle = 3;
            job.cycle_count = 2;
            JobScheudler.newJob(job);
        } else {
            job.updateJobPrepared();
        }
    }

    /**
     * 更新会员充值Job
     *
     * @param tradeNo 交易号
     */
    public static void updateMemberRechargeJob(String tradeNo) {
        if (android.text.TextUtils.isEmpty(tradeNo)) {
            return;
        }
        Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType.MEMBER_RECHARGE_QUERY_RESULT + "' AND biz_key = '" + tradeNo + "'", Job.class);
        if (job != null) {
            job.updateJobFinished();
        }
    }

    /**
     * 查询会员充值结果
     *
     * @param tradeNo  String | 交易号
     * @param callback IExecutorCallback
     */
    public static void queryOnlineRechargeRequest(String tradeNo, IResponse<QueryNewMembeChargeResultModel> callback) {

        QueryNewMemberChargeResultRequest queryResultRequest = new QueryNewMemberChargeResultRequest();
        queryResultRequest.type = "1";
        queryResultRequest.sourceid = 105;
        queryResultRequest.v = "1.1";
        queryResultRequest.trade_no = tradeNo;

        final long start = SystemClock.elapsedRealtime();

        BusinessExecutor.execute(queryResultRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值:" + responseData.responseBean.toString());

                    QueryNewMemberChargeResultResponse response = (QueryNewMemberChargeResultResponse) responseData.responseBean;
                    if (response.data != null) {


                        if (response.data.pay_status == 1) {


                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--扣款 成功," + response.data.toString());
                            //101=>发起交易  102=>等待确认   103=>等待付款    104=>交易/支付完成   105=>退款
                            if (response.data.status == 105) {
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 失败" + response.data.toString());
                                if (callback != null) {
                                    callback.callBack(false, 2, android.text.TextUtils.isEmpty(response.data.pay_status_msg) ? "充值失败" : response.data.pay_status_msg, response.data);
                                }
                                updateMemberRechargeJob(tradeNo);
                            } else if (response.data.status == 104) {
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 成功," + response.data.toString());
                                if (callback != null) {
                                    if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                        response.data.trade_no = tradeNo;
                                    }
                                    callback.callBack(true, 1, "", response.data);
                                }
                                updateMemberRechargeJob(tradeNo);
                            } else {
                                //充值中
                                RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值--会员账户 进行中。。。" + response.data.toString());
                                if (callback != null) {
                                    if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                        response.data.trade_no = tradeNo;
                                    }
                                    callback.callBack(true, 0, "", response.data);
                                }
                            }
                        } else if (response.data.pay_status == 2) {
                            //充值失败
                            RunTimeLog.addLog(RunTimeLog.MEMBER, i + "充值失败" + response.data.toString());
                            if (callback != null) {
                                callback.callBack(false, 2, android.text.TextUtils.isEmpty(response.data.pay_status_msg) ? "充值失败" : response.data.pay_status_msg, response.data);
                            }
                            updateMemberRechargeJob(tradeNo);
                        } else {
                            //充值中
                            addMemberRechargeJob(tradeNo, "");
                            if (callback != null) {
                                if (response.data != null && android.text.TextUtils.isEmpty(response.data.trade_no)) {
                                    response.data.trade_no = tradeNo;
                                }
                                callback.callBack(true, 0, "", response.data);
                            }
                        }
                        RunTimeLog.addLog(RunTimeLog.MEMBER, "开始查询充值结果" + response.data.trade_no);
                    }

                } else {
                    if (callback != null) {
                        callback.callBack(false, 2, "充值失败", null);

                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                long out = SystemClock.elapsedRealtime() - start;
                //耗时超过3.5秒，则报警
                if (out > 3500) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, String.valueOf(out) + responseData.responseBean);
                }
                if (i == 0) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "请求充值" + responseData);
                } else {
                    RunTimeLog.addLog(RunTimeLog.MEMBER, "查询充值结果" + responseData);
                }
                if (callback != null) {
                    callback.callBack(false, 2, "充值失败", null);
                }
                return false;
            }
            //此处，需要明确传false进行阻塞
        }, false);

    }

    public static void queryMemberInfo(String cardNo, IResponse<MemberInfo> callback) {
        MemberBizUtil.sendGetMemberCardByCardNoRequest(cardNo, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                    GetMemberCardResponse getMemberCardResponse = (GetMemberCardResponse) responseData.responseBean;
                    MemberInfo info = new MemberInfo();
                    info.amount = getMemberCardResponse.data.card_data.amount;
                    info.score = getMemberCardResponse.data.card_data.score;
                    callback.callBack(true, responseData.result, responseData.resultMessage, info);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        });
    }

    public static MemberInfo queryMemberInfo(String cardNo) {
        final MemberInfo[] memberInfo = new MemberInfo[1];
        ServerMemberApi.loadMemberCardDetailsByCardNo(ServerCache.getInstance().fsCompanyGUID, ServerCache.getInstance().shopID, cardNo, new IResponse<NewMemberCardDetailsModel>() {
            @Override
            public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                if (result) {
                    memberInfo[0] = new MemberInfo();
                    memberInfo[0].amount = info.cardData.amount;
                    memberInfo[0].score = info.cardData.score;
                    memberInfo[0].cardNo = info.cardInfo.card_no;
                    memberInfo[0].cardNo = new AirPrinterSelect().getMemberCardPrintFormat(memberInfo[0].cardNo);
                }
            }
        });
        return memberInfo[0];
    }

    /**
     * 会员开卡----支持第三方卡与会员实体卡
     *
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @param nameValue        姓名
     * @param sex              性别
     * @param birthday         生日
     * @param userDBModel      操作人
     * @return
     */
    public static void memberBindCard(String cardNumber, String phone,
                                      String verificationCode, String nameValue,
                                      int sex, String birthday, UserDBModel userDBModel, IResponse response) {

        BindMemberEntityCardRequest request = new BindMemberEntityCardRequest();
        request.mobile = phone;
        request.cardNo = cardNumber;
        request.verifyCode = verificationCode;
        request.brandId = ServerCache.getInstance().fsCompanyGUID;

        if (TextUtils.isEmpty(request.brandId)) {
            request.brandId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsshopguid = '" + ServerCache.getInstance().shopID + "' ");
            ServerCache.getInstance().fsCompanyGUID = request.brandId;
        }
        request.deviceId = ServerHardwareUtil.getHardWareSymbol();
        request.realName = nameValue;
        request.gender = sex;
        request.birthday = birthday;
        if (userDBModel != null) {
            request.whoOptEntityCard = userDBModel.fsUserName;
        }

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                processBinCardResult(cardNumber, phone, userDBModel, responseData, response);
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                processBinCardResult(cardNumber, phone, userDBModel, responseData, response);
                return false;
            }
        }, false);
    }

    /**
     * 验证码校验----虚拟卡开卡，仅需要校验验证码
     *
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @return
     */
    public static void checkVerificationCode(String phone,
                                             String verificationCode, IResponse iResponse) {

        ValidateCodeRequest request = new ValidateCodeRequest();
        request.mobile = phone;
        request.code = verificationCode;
        request.brandId = ServerCache.getInstance().fsCompanyGUID;

        if (TextUtils.isEmpty(request.brandId)) {
            request.brandId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsshopguid = '" + ServerCache.getInstance().shopID + "' ");
            ServerCache.getInstance().fsCompanyGUID = request.brandId;
        }
        request.type = 1;

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData == null || responseData.responseBean == null){
                    if (iResponse != null) {
                        iResponse.callBack(false, -1001, "校验'验证码'失败，请重试", null);
                    }
                }else if (responseData.responseBean instanceof NewMemberVerifyCodeResponse) {
                    NewMemberVerifyCodeResponse response = (NewMemberVerifyCodeResponse) responseData.responseBean;
                    if (iResponse != null) {
                        iResponse.callBack(response.errno == SocketResultCode.SUCCESS, response.errno, response.errmsg, response.data);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, null);
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (responseData == null || responseData.responseBean == null){
                    if (iResponse != null) {
                        iResponse.callBack(false, -1002, "校验'验证码'失败，请重试", null);
                    }
                }else if (iResponse != null) {
                    iResponse.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, null);
                }
                return false;
            }
        }, false);
    }

    /**
     * 检查卡类型
     *
     * @param cardNumber 卡号
     * @return
     */
    public static void checkCardType(String cardNumber, IResponse response) {

        CheckCardTypeRequest request = new CheckCardTypeRequest();
        request.cardNo = cardNumber;
        request.brandId = ServerCache.getInstance().fsCompanyGUID;

        if (TextUtils.isEmpty(request.brandId)) {
            request.brandId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsshopguid = '" + ServerCache.getInstance().shopID + "' ");
            ServerCache.getInstance().fsCompanyGUID = request.brandId;
        }

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");

                if (responseData.responseBean != null && responseData.responseBean instanceof CheckCardTypeResponse) {
                    CheckCardTypeResponse checkCardTypeResponse = (CheckCardTypeResponse) responseData.responseBean;
                    //查下结果
                    if (checkCardTypeResponse.data != null) {
                        if (!TextUtils.isEmpty(checkCardTypeResponse.data.entity_card_act_mode)) {
                            if (response != null) {
                                if (TextUtils.equals(checkCardTypeResponse.data.entity_card_act_mode, "1")) {
                                    response.callBack(true, 1, checkCardTypeResponse.data.entity_card_act_mode, "");
                                } else {
                                    response.callBack(true, 2, checkCardTypeResponse.data.entity_card_act_mode, "");
                                }
                            }
                        } else {
                            if (response != null) {
                                response.callBack(false, responseData.result == 0 ? -111 : responseData.result, responseData.resultMessage, null);
                            }
                            LogUtil.logBusiness("查询卡类型1", JSON.toJSONString(checkCardTypeResponse));
                        }

                    } else {
                        if (response != null) {
                            response.callBack(false, responseData.result == 0 ? -112 : responseData.result, responseData.resultMessage, null);
                        }
                        LogUtil.logBusiness("查询卡类型2", JSON.toJSONString(checkCardTypeResponse));
                    }
                } else {
                    if (response != null) {
                        response.callBack(false, responseData.result == 0 ? -113 : responseData.result, responseData.resultMessage, null);
                    }
                    LogUtil.logBusiness("查询卡类型3", JSON.toJSONString(responseData));
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof CheckCardTypeResponse) {
                    CheckCardTypeResponse checkCardTypeResponse = (CheckCardTypeResponse) responseData.responseBean;

                    if (checkCardTypeResponse.errno == 201
                            || checkCardTypeResponse.errno == 500
                            || checkCardTypeResponse.errno == 501
                    ) {
                        //会员卡不存在
                        if (response != null) {
                            response.callBack(true, 0, "0", "");
                        }
                    } else {
                        if (response != null) {
                            response.callBack(false, responseData.result == 0 ? -1 : responseData.result, responseData.resultMessage, null);
                        }
                    }
                } else {
                    if (response != null) {
                        response.callBack(false, responseData.result == 0 ? -1 : responseData.result, responseData.resultMessage, null);
                    }
                }

                LogUtil.logBusiness("查下卡类型异常 fail ", JSON.toJSONString(responseData));
                return false;
            }
        }, false);
    }

    /**
     * 激活不记名实体卡
     *
     * @param cardNumber 卡号
     * @return
     */
    public static void activeNoNameCard(String cardNumber, IResponse iResponse) {

        ActiveNoNameCardRequest request = new ActiveNoNameCardRequest();
        request.cardNo = cardNumber;
        request.brandId = ServerCache.getInstance().fsCompanyGUID;

        if (TextUtils.isEmpty(request.brandId)) {
            request.brandId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsshopguid = '" + ServerCache.getInstance().shopID + "' ");
            ServerCache.getInstance().fsCompanyGUID = request.brandId;
        }
        request.deviceId = ServerHardwareUtil.getHardWareSymbol();
        request.actStoreId = ServerCache.getInstance().shopID;

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");

                if (responseData.responseBean != null && responseData.responseBean instanceof ActiveNoNameCardResponse) {
                    ActiveNoNameCardResponse checkCardTypeResponse = (ActiveNoNameCardResponse) responseData.responseBean;
                    //查下结果
                    if (checkCardTypeResponse.data != null) {
                        if (iResponse != null) {
                            iResponse.callBack(true, checkCardTypeResponse.errno, checkCardTypeResponse.errmsg, checkCardTypeResponse.data.card_no);
                        }
                    } else {
                        if (iResponse != null) {
                            iResponse.callBack(false, checkCardTypeResponse.errno, checkCardTypeResponse.errmsg, null);
                        }
                        LogUtil.logBusiness("激活不记名实体卡异常1", JSON.toJSONString(checkCardTypeResponse));
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                    }
                    LogUtil.logBusiness("激活不记名实体卡异常2", JSON.toJSONString(responseData));
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof ActiveNoNameCardResponse) {
                    ActiveNoNameCardResponse checkCardTypeResponse = (ActiveNoNameCardResponse) responseData.responseBean;
                    if (iResponse != null) {
                        iResponse.callBack(false, checkCardTypeResponse.errno, checkCardTypeResponse.errmsg, null);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                    }
                }
                LogUtil.logBusiness("激活不记名实体卡异常 fail ", JSON.toJSONString(responseData));
                return false;
            }
        }, false);
    }

    public static void processBinCardResult(String cardNumber, String phone, UserDBModel userDBModel, ResponseData responseData, IResponse response) {

        if (responseData == null) {
            if (response != null) {
                response.callBack(false, -109, "开卡失败，请重试", null);
            }
            LogUtil.logBusiness("会员开卡异常0");
            return;
        }

        if (responseData.responseBean != null && responseData.responseBean instanceof BindMemberEntityCardResponse) {
            BindMemberEntityCardResponse bindMemberEntityCardResponse = (BindMemberEntityCardResponse) responseData.responseBean;
            //绑卡结果
            if (bindMemberEntityCardResponse.data != null) {
                if (bindMemberEntityCardResponse.data.bindEntityCard != null) {
                    if (bindMemberEntityCardResponse.data.bindEntityCard.errno == 0) {
                        if (bindMemberEntityCardResponse.data.setCurrentEntityCard == null
                                || bindMemberEntityCardResponse.data.setCurrentEntityCard.errno != 0) {
                            if (response != null) {
                                response.callBack(true, 0, "开卡成功, 设置当前卡失败", "");
                            }
                        } else if (bindMemberEntityCardResponse.data.saveAttrEntityCard == null
                                || bindMemberEntityCardResponse.data.saveAttrEntityCard.errno != 0) {
                            if (response != null) {
                                response.callBack(true, 0, "开卡成功, 设置卡属性失败", "");
                            }
                        } else {
                            if (response != null) {
                                //开卡成功
                                response.callBack(true, 0, "", "");
                            }
                        }
                    } else if (bindMemberEntityCardResponse.data.bindEntityCard.errno == 500
                            || bindMemberEntityCardResponse.data.bindEntityCard.errno == 501) {
                        //绑卡失败   根据错误码：500，501有，走端上手机号绑定虚拟卡校验逻辑
                        // errno=500，errmsg=卡号错误； errno=501，errmsg=卡号不存在；

                        //当前会员名下有实体卡？
                        boolean hasEntityCard = false;
                        if (bindMemberEntityCardResponse.data.queryEntityCard != null
                                && bindMemberEntityCardResponse.data.queryEntityCard.data != null
                                && !ListUtil.isEmpty(bindMemberEntityCardResponse.data.queryEntityCard.data.entity_card_list)) {
                            hasEntityCard = true;
                        }

                        String errMsg = CardRelationDBUtil.bindCard(cardNumber, phone, userDBModel);
                        if (TextUtils.isEmpty(errMsg)) {
                            //虚拟卡"开卡成功"
                            if (response != null) {
                                response.callBack(true, 0, hasEntityCard ? "实体卡仍然可用!请及时补办新卡" : "开卡成功", "");
                            }
                        } else {
                            if (response != null) {
                                response.callBack(false, -110, errMsg, null);
                            }
                        }
                    } else {
                        if (response != null) {
                            response.callBack(false, bindMemberEntityCardResponse.data.bindEntityCard.errno, bindMemberEntityCardResponse.data.bindEntityCard.errmsg, null);
                        }
                        LogUtil.logBusiness("会员开卡异常4", JSON.toJSONString(bindMemberEntityCardResponse));
                    }
                } else {
                    if (response != null) {
                        response.callBack(false, responseData.result == 0 ? -111 : responseData.result, responseData.resultMessage, null);
                    }
                    LogUtil.logBusiness("会员开卡异常1", JSON.toJSONString(bindMemberEntityCardResponse));
                }

            } else {
                if (response != null) {
                    response.callBack(false, responseData.result == 0 ? -112 : responseData.result, responseData.resultMessage, null);
                }
                LogUtil.logBusiness("会员开卡异常2", JSON.toJSONString(bindMemberEntityCardResponse));
            }
        } else {
            if (response != null) {
                response.callBack(false, responseData.result == 0 ? -113 : responseData.result, responseData.resultMessage, null);
            }
            LogUtil.logBusiness("会员开卡异常3", JSON.toJSONString(responseData));
        }
    }

    /**
     * 会员重构----绑定实体卡号
     *
     * @param cardNumber       卡号
     * @param phone            手机号
     * @param verificationCode 验证码
     * @return
     */
    public static void newMemberBindEntityCard(String cardNumber, String phone,
                                               String verificationCode, final IResponse response) {

        NewMemberBindEntityCardResultRequest resultRequest = new NewMemberBindEntityCardResultRequest();
        resultRequest.mobile = phone;
        resultRequest.extCardNo = cardNumber;
        resultRequest.verifyCode = verificationCode;
        resultRequest.actStoreId = Integer.parseInt(ServerCache.getInstance().shopID);
        //获取 fsCompanyGUID
        resultRequest.brandId = getCompanyGUID();


        BusinessExecutor.execute(resultRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                //绑定实体卡返回数据处理
                bindEntityCardResponse(responseData, response);
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                //绑定实体卡返回数据处理
                bindEntityCardResponse(responseData, response);
                return false;
            }
        }, false);
    }

    /**
     * 绑定实体卡返回数据处理
     *
     * @param responseData
     * @param response
     */
    public static void bindEntityCardResponse(ResponseData responseData, IResponse response) {
        if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberBindEntityCardResponse) {
            NewMemberBindEntityCardResponse bindEntityCardResponse = (NewMemberBindEntityCardResponse) responseData.responseBean;
            if (response != null) {
                if (bindEntityCardResponse.errno == 0) {
                    response.callBack(true, bindEntityCardResponse.errno, bindEntityCardResponse.errmsg, null);
                } else {
                    response.callBack(false, bindEntityCardResponse.errno, bindEntityCardResponse.errmsg, null);
                }
            }
            //绑卡结果

        } else {
            if (response != null) {
                response.callBack(false, responseData.result == 0 ? -113 : responseData.result, responseData.resultMessage, null);
            }
        }
    }

    /**
     * 菜品券核销
     *
     * @param sn 券号
     * @param callback
     */
    public static void couponConsumeRequest(String sn, List<String> snList, String reqId, String tradeNo, IResponse<List<String>> callback) {
        MemberCouponConsumeRequest request = new MemberCouponConsumeRequest();
        request.sn = sn;
        request.type = "9now";
        request.codes = snList;
        request.requestId = reqId;
        request.trade_no = tradeNo;
        class ConsumeReqCallback implements IExecutorCallback {
            @Override
            public void success(ResponseData responseData) {
                MemberCouponConsumeResponse response = null;
                int errno = -1;
                String errmsg = null;
                if (responseData.responseBean != null) {
                    response = (MemberCouponConsumeResponse) responseData.responseBean;
                    if (null != response) {
                        errno = response.errno;
                        errmsg = response.errmsg;
                    }
                }
                callback.callBack(0 == errno, errno, errmsg, getFailedCoupnSn(response));
            }

            @Override
            public boolean fail(ResponseData responseData) {
                MemberCouponConsumeResponse response = (MemberCouponConsumeResponse) responseData.responseBean;
                callback.callBack(false, responseData.responseBean.errno, responseData.resultMessage, getFailedCoupnSn(response));
                return false;
            }

            public ConsumeReqCallback(List<String> snList) {
                mInSnList = snList;
            }
            private List<String> mInSnList = null;
            private List<String> getFailedCoupnSn(MemberCouponConsumeResponse response) {
                if (null == response )
                    return mInSnList;
                List<String> succCouponMap = response.parseSuccedCoupons();
                if (null == succCouponMap || succCouponMap.isEmpty())
                    return mInSnList;
                List<String> failSnList = null;
                int i, iSz = mInSnList.size(), iSuccSz = succCouponMap.size();
                if (iSuccSz >= iSz)
                    return null;
                String sn;
                for (i = 0; i < iSz; i ++ ) {
                    sn = mInSnList.get(i);
                    if (succCouponMap.contains(sn))
                        continue;
                    if (null == failSnList)
                        failSnList = new ArrayList<>(iSz - iSuccSz);
                    failSnList.add(sn);
                }
                return failSnList;
            }
        }
        ConsumeReqCallback apiExecuteCallback = new ConsumeReqCallback(snList);
        BusinessExecutor.execute(request, apiExecuteCallback, false);
    }

    /**
     * 获取菜品券列表
     *
     * @param cardNo 会员卡号
     * @param payAmount 订单总额
     * @param foodInfo 菜品信息
     * String foodInfo,
     * @param callback
     */
    public static void getMemberCouponListRequest(String csId, String cardNo, BigDecimal payAmount, List<FoodInfoModel> foodInfo, IResponse callback) {
        MemberCouponGetRequest request = new MemberCouponGetRequest();
        request.cardNo = cardNo;
        request.payAmount = payAmount;
        request.foodInfo = foodInfo;
        request.csId = Integer.valueOf(csId);
        request.storeId = Integer.valueOf(ServerCache.getInstance().shopID);
        request.brandId = Integer.valueOf(ServerCache.getInstance().fsCompanyGUID);
        request.requestId = UUIDUtil.optUUID();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    if (responseData.responseBean.errno == 0) {
                        callback.callBack(true, responseData.responseBean.errno, responseData.responseBean.msg, responseData.responseBean);
                    } else {
                        callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                    }
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, responseData.responseBean);
                }
                return false;
            }
        }, false);
    }

    /**
     * 回退会员菜品券
     * @param cardNo 会员卡号
     * @param snList 要退的券号列表
     * @param callback
     */
    public static void refundMemberCoupon(String cardNo, List<String> snList, IResponse callback) {
        MemberCouponRefundRequest request = new MemberCouponRefundRequest();
        request.cardNo = cardNo;
        request.couponList = snList;
        request.mShopId = Integer.valueOf(ServerCache.getInstance().fsCompanyGUID);
        request.shopId = Integer.valueOf(ServerCache.getInstance().shopID);
        request.requestId = UUIDUtil.optUUID();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    if (responseData.responseBean.errno == 0) {
                        callback.callBack(true, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                    } else {
                        callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                    }
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, responseData.responseBean);
                }
                return false;
            }
        }, false);
    }

    /**
     * 查询会员菜品券
     * @param sn 券号
     * @param callback
     */
    public static void queryMemberCoupon(String sn, IResponse callback) {
        MemberCouponQueryRequest request = new MemberCouponQueryRequest();
        request.sn = sn;
        request.mShopId = Integer.valueOf(ServerCache.getInstance().fsCompanyGUID);
        request.shopId = Integer.valueOf(ServerCache.getInstance().shopID);
        request.requestId = UUIDUtil.optUUID();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    if (responseData.responseBean.errno == 0) {
                        callback.callBack(true, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                    } else {
                        callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                    }
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData.responseBean != null) {
                    callback.callBack(false, responseData.responseBean.errno, responseData.responseBean.errmsg, responseData.responseBean);
                } else {
                    callback.callBack(false, responseData.result, responseData.resultMessage, responseData.responseBean);
                }
                return false;
            }
        },
        false );
    }

    /**
     * 获取 fsCompanyGUID
     *
     * @return
     */
    public static String getCompanyGUID() {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbshop where fsshopguid = '" + ServerCache.getInstance().shopID + "' ");
    }

//    /*************************************************************************
//     *  用于测试
//     */
//    static boolean gbIsStubMode = true;
//    static int  giQueryRes = 0;
//    private static void stub_queryCoupon(String sn, IResponse callback) {
//        MemberCouponQueryResponse responseData = new MemberCouponQueryResponse();
//        if ( 0 == giQueryRes) {
//            responseData.errno = 0;
//            responseData.data = new MemberCouponQueryData();
//            responseData.data.sn = new String(sn);
//        } else if ( 1 == giQueryRes) {
//            responseData.errno = 0;
//            responseData.data = null;
//        } else {
//            responseData.errno = 1;
//            responseData.errmsg = "请求失败";
//        }
//        debug_log("query", sn, responseData, null);
//        callback.callBack(0 == responseData.errno, responseData.errno, responseData.errmsg, responseData);
//    }
//
//    static int  giWriteoffRes = 0;
//    private static void stub_writeoffCoupon(List<String> snList, IResponse<List<String>> callback) {
//        MemberCouponConsumeResponse responseData = new MemberCouponConsumeResponse();
//        List<String> failedSnList = null;
//        if ( 0 == giWriteoffRes) {
//            responseData.errno = 0;
//        } else if ( 1 == giWriteoffRes) {
//            responseData.errno = 0;
//            failedSnList = new ArrayList<>();
//            for (int i = 0; i < snList.size(); i ++) {
//                failedSnList.add(new String(snList.get(i)));
//            }
//        } else if (2 == giWriteoffRes) {
//            failedSnList = new ArrayList<>();
//            for (int i = 0; i < snList.size(); i ++) {
//                if ( 0 == (i % 2) )
//                    failedSnList.add(new String(snList.get(i)));
//            }
//        } else {
//            responseData.errno = 1;
//            responseData.errmsg = "请求失败";
//            for (int i = 0; i < snList.size(); i ++) {
//                failedSnList.add(new String(snList.get(i)));
//            }
//        }
//        debug_log("writeoff", snList, responseData, failedSnList);
//        callback.callBack(0 == responseData.errno, responseData.errno, responseData.errmsg, failedSnList);
//    }
//
//    static int  giRefundRes = 0;
//    private static void stub_refundCoupon(List<String> snList, IResponse callback) {
//        MemberCouponRefundResponse responseData = new MemberCouponRefundResponse();
//        if ( 0 == giRefundRes) {
//            responseData.errno = 0;
//            responseData.data = new MemberCouponRefundData();
//            responseData.data.success = new ArrayList<>();
//            for (int i = 0; i < snList.size(); i ++) {
//                responseData.data.success.add(new String(snList.get(i)));
//            }
//        } else if ( 1 == giRefundRes) {
//            responseData.errno = 0;
//            responseData.data = new MemberCouponRefundData();
//            responseData.data.fail = new ArrayList<>();
//            for (int i = 0; i < snList.size(); i ++) {
//                responseData.data.fail.add(new String(snList.get(i)));
//            }
//        } else if ( 2 == giRefundRes) {
//            responseData.errno = 0;
//            responseData.data = new MemberCouponRefundData();
//            responseData.data.fail = new ArrayList<>();
//            for (int i = 0; i < snList.size(); i ++) {
//                if ( 0 == (i % 2) )
//                    responseData.data.success.add(new String(snList.get(i)));
//                else
//                    responseData.data.fail.add(new String(snList.get(i)));
//            }
//        } else {
//            responseData.errno = 1;
//            responseData.errmsg = "请求失败";
//        }
//        debug_log("refund", snList, responseData, null);
//        callback.callBack(0 == responseData.errno, responseData.errno, responseData.errmsg, responseData);
//    }
//
//    private static void debug_log(String apiType, Object param, BasePosResponse response, List<String> failList) {
//        String logStr = apiType += "\nparam:";
//        if (param instanceof String) {
//            logStr += "\nparam:" + (String) param;
//        }
//        else {
//            List<String> snList = (List<String>)(param);
//            for (int i = 0; i < snList.size(); i ++) {
//                logStr += "," + snList.get(i);
//            }
//        }
//        logStr += "\nResponse:";
//        if (response instanceof  MemberCouponRefundResponse ) {
//            MemberCouponRefundResponse refundResponse = (MemberCouponRefundResponse)response;
//            logStr += "error_no:" + refundResponse.errno + "  error_msg:" + refundResponse.errmsg;
//            logStr += "\ndata:";
//            if (null == refundResponse.data)
//                logStr += "null";
//            else {
//                if (null == refundResponse.data.success)
//                    logStr += "\nsucc:null";
//                else {
//                    logStr += "\nsucc:";
//                    for (int i = 0; i < refundResponse.data.success.size(); i ++)
//                        logStr += refundResponse.data.success.get(i) + ",";
//                }
//                if (null == refundResponse.data.fail)
//                    logStr += "\nsucc:null";
//                else {
//                    logStr += "\nfail:";
//                    for (int i = 0; i < refundResponse.data.fail.size(); i ++)
//                        logStr += refundResponse.data.fail.get(i) + ",";
//                }
//            }
//        }
//        else if (response instanceof  MemberCouponConsumeResponse ) {
//            MemberCouponConsumeResponse consumeResponse = (MemberCouponConsumeResponse)response;
//            logStr += "error_no:" + consumeResponse.errno + "  error_msg:" + consumeResponse.errmsg;
//            logStr += "\nfailList:";
//            if (null == failList)
//                logStr += "null";
//            else {
//                for (int i = 0; i < failList.size(); i ++)
//                    logStr += failList.get(i) + ",";
//            }
//        }
//        else if (response instanceof  MemberCouponQueryResponse ) {
//            MemberCouponQueryResponse queryResponse = (MemberCouponQueryResponse)response;
//            logStr += "error_no:" + queryResponse.errno + "  error_msg:" + queryResponse.errmsg;
//            logStr += "\ndata:";
//            if (null == queryResponse.data)
//                logStr += "null";
//            else {
//                if (null == queryResponse.data.sn)
//                    logStr += "\nsn:null";
//                else {
//                    logStr += "\nsn:" + queryResponse.data.sn;
//                }
//            }
//        }
//        logStr += "\n\n";
//        Log.d("coupon_test", logStr);
//    }
//    /**  测试终止 **/
//    /*************************************************************************/
}
