package com.mwee.android.pos.businesscenter.business.order;

import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.cashier.connect.bean.http.model.GetTsOrderModel;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.constants.CouponType;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCouponConsumeData;
import com.mwee.android.pos.component.member.net.model.MemberDishCouponBean;
import com.mwee.android.pos.component.member.net.model.MemberDishCouponReqStat;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponQueryRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponQueryResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.discount.DiscountMenuItem;
import com.mwee.android.pos.connect.business.discount.DiscountRepSubCode;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponBean;
import com.mwee.android.pos.db.business.menu.bean.MenuItemCouponModel;
import com.mwee.android.pos.db.business.menu.bean.MenuSellType;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.discount.BuyGiftItemModel;
import com.mwee.android.pos.db.business.order.discount.CouponBuyGiftModel;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Optional;

/**
 * Created by liuxiuxiu on 2017/9/19.
 */

public class MenuItemCouponProcessor {

    private static final String TAG = "DiscountBizUtil";


    /**
     * Map<菜品seq, MenuItemCouponModel>   menuCouponMap
     * <p>
     * List<MenuItem> tempMenuList      未下单菜品
     * <p>
     * tableId, orderId,
     * <p>
     * MenuItemCouponBean orderCutModel   整单立减信息
     *
     * @param needRefreshList List<MenuItem> not null 有异常时须要重新刷新的item
     * @param errMsg String[] not null errMsg[0] 保存错误消息
     * @return DiscountRepSubCode 成功返回DiscountRepSubCode.eOk；其他时，当errMsg[0]等于null时， 返回的为DoDiscountResponse.sub_code
     */
    public static DiscountRepSubCode dealCoupon(String tableId, String orderId,
                                                Map<String, MenuItemCouponModel> menuCouponMap,
                                                Map<String, Map<String, List<String>>> buygiftRelation,
                                                List<MenuItem> menuList,
                                                MenuItemCouponBean orderCutModel,
                                                UserDBModel userDBModel,
                                                String hostId,
                                                List<String> failedWriteoffCoupons,
                                                List<String> failedRefundCoupons,
                                                String[] errMsg) {
        errMsg[0] = null;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableId, orderId, "打折");
        try {
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

            if (orderCache != null) {
                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    errMsg[0] = "订单已完成结账";
                    return DiscountRepSubCode.eWrong;
                }
            }

            //整单立减折扣-----仅针对已下单订单，未下单订单不支持使用整单立减功能
            DiscountDBModel discountDBModelCut = null;
            if (orderCutModel != null) {
                discountDBModelCut = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + orderCutModel.couponId + "' and fiStatus = '1' ", DiscountDBModel.class);
                if (discountDBModelCut != null && orderCutModel.fdTotalddv != null) {
                    discountDBModelCut.fdddv = orderCutModel.fdTotalddv;
                }
                if (discountDBModelCut != null && !MenuItemCouponProcessor.dataIsEffectiveDate(discountDBModelCut)) {
                    errMsg[0] = "整单立减折扣[" + discountDBModelCut.fsDiscountName + "]未生效";
                    return DiscountRepSubCode.eWrong;
                }
            }

            DiscountDBModel discountDBModel = null;
            //校验折扣有效性
            if (menuCouponMap != null && menuCouponMap.size() > 0) {
                for (MenuItemCouponModel couponModel : menuCouponMap.values()) {
                    if (couponModel == null) {
                        continue;
                    }
                    if (couponModel.discount != null) {
                        if (!TextUtils.isEmpty(couponModel.discount.couponId)) {
                            discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + couponModel.discount.couponId + "' and fiStatus = '1' ", DiscountDBModel.class);
                            if (discountDBModel != null && !MenuItemCouponProcessor.dataIsEffectiveDate(discountDBModel)) {
                                errMsg[0] = "折扣[" + discountDBModel.fsDiscountName + "]未生效";
                                return DiscountRepSubCode.eWrong;
                            }
                        }
                    }
                }
            }

            /** 预处理会员菜品券 **/
            List<ItemCouponInfo>  useCouponList = new ArrayList<>();
            List<ItemCouponInfo>  refundCouponList = new ArrayList<>();
            String[] reqParams = new String[2];
            List<MenuItem> splitItems = new ArrayList<>();
            List<MenuItem> needRefreshList = new ArrayList<>();
            DiscountRepSubCode dealCouponSubCode = preDealMbDishCoupon(menuCouponMap, menuList, useCouponList, refundCouponList, splitItems, reqParams, needRefreshList);
            if (DiscountRepSubCode.eOk != dealCouponSubCode) {
                return dealCouponSubCode;
            }

            //如果被赠送的菜品参与了买减优惠，其他联动的菜品也清除买减优惠信息
            List<String> needCleanBuyGiftMenuInfo = new ArrayList<>();

            //取消会员价或者取消折扣，赠送、买减
            for (MenuItem menuItem : menuList) {
                if (menuItem == null || menuItem.hasAllVoid()) {
                    continue;
                }
                MenuItemCouponModel menuItemCouponModel = menuCouponMap.get(menuItem.menuBiz.uniq);
                if (menuItemCouponModel != null) {
                    if (!menuItemCouponModel.gift && menuItem.menuBiz.menuSellType == MenuSellType.GIFT) {
                        menuItem.cancelGift(false);
                        menuItem.calcTotal(menuItem.useMemberPrice);
                    }
                    if (menuItemCouponModel.discount == null && menuItem.menuBiz.selectDiscount != null) {
                        menuItem.cancelDiscount(false);
                        menuItem.calcTotal(menuItem.useMemberPrice);
                    }
                    if (!menuItemCouponModel.memberPrice && menuItem.useMemberPrice) {
                        menuItem.cancelVipPrice();
                    }
                    if (menuItem.menuBiz.bugGiftItem != null && menuItemCouponModel.buyGiftHeadOrFoot == 0) {
                        menuItem.cleanBuyGiftInfo();
                        menuItem.calcTotal(menuItem.useMemberPrice);
                        needCleanBuyGiftMenuInfo.add(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd);
                    }
                }

                if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                    for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                        MenuItemCouponModel modifierCouponModel = menuCouponMap.get(modifier.menuBiz.uniq);
                        if (modifierCouponModel != null) {

                            if (!modifierCouponModel.gift && modifier.menuBiz.menuSellType == MenuSellType.GIFT) {
                                modifier.cancelGift(false);
                                modifier.calcTotal(modifier.useMemberPrice);
                            }
                            if (modifierCouponModel.discount == null && modifier.menuBiz.selectDiscount != null) {
                                modifier.cancelDiscount(false);
                                modifier.calcTotal(modifier.useMemberPrice);
                            }
                            if (!modifierCouponModel.memberPrice && modifier.useMemberPrice) {
                                modifier.cancelVipPrice();
                            }
                            if (modifier.menuBiz.bugGiftItem != null && modifierCouponModel.buyGiftHeadOrFoot == 0) {
                                modifier.cleanBuyGiftInfo();
                                modifier.calcTotal(modifier.useMemberPrice);
                                needCleanBuyGiftMenuInfo.add(modifier.itemID + "_" + modifier.currentUnit.fiOrderUintCd);
                            }
                        }
                    }
                }
            }

            List<MenuItem> needStoreItemList = new ArrayList<>();
            dealCouponSubCode = writeoffMemberCoupon(orderCache, useCouponList, refundCouponList, reqParams, needStoreItemList, failedWriteoffCoupons, failedRefundCoupons);
            boolean bNeedStore = procSplitMenuItems(orderCache, splitItems, failedWriteoffCoupons);
            if (DiscountRepSubCode.eOk != dealCouponSubCode) {
                //若卡券处理整体失败，但是其中又又部分成功, 则部分成功的仍须要保存
                if (bNeedStore || needStoreItemList.size() > 0 ) {
                    orderCache.plusAllMenuAmount();
                    //存入报表
                    OrderSession.getInstance().writeOrder(orderCache.orderID, true, "useMemberCoupon");
                }
                return dealCouponSubCode;
            }

            //去除历史买减信息，防止重设买减时，会重新拆分菜，或者买减菜品和上一次买减菜品不一致
            if (!ListUtil.mapIsEmpty(buygiftRelation) && ListUtil.mapIsEmpty(menuCouponMap)) {
                for (String fsBargainId : buygiftRelation.keySet()) {
                    Map<String, List<String>> menuRelations = buygiftRelation.get(fsBargainId);
                    if (menuRelations != null && menuRelations.size() > 0) {
                        for (List<String> idList : menuRelations.values()) {
                            if (ListUtil.isEmpty(idList)) {
                                continue;
                            }
                            List<String> idCopy = new ArrayList<>();
                            idCopy.addAll(idList);
                            for (String id : idCopy) {
                                if (TextUtils.isEmpty(id) && id.contains("_")) {
                                    MenuItemCouponModel model = menuCouponMap.get(id.split("_")[0]);
                                    if (model != null && model.buyGiftHeadOrFoot != 0) {
                                        //buyGiftHeadOrFoot == 0 表示本批次新设置的买减信息
                                        idList.remove(id);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Map<String, MenuItemCouponModel> giftCouponMap = new HashMap<>();
            Map<String, MenuItemCouponModel> memberPriceCouponMap = new HashMap<>();
            Map<String, MenuItemCouponModel> discountCouponMap = new HashMap<>();
            //分批处理优惠
            for (String seq : menuCouponMap.keySet()) {
                MenuItemCouponModel couponModel = menuCouponMap.get(seq);
                if (couponModel.gift) {
                    giftCouponMap.put(seq, couponModel);
                } else {
                    if (couponModel.memberPrice) {
                        memberPriceCouponMap.put(seq, couponModel);
                    }
                    if (couponModel.discount != null) {
                        discountCouponMap.put(seq, couponModel);
                    }
                }
            }

            //首先处理赠送
            for (String seq : giftCouponMap.keySet()) {
                MenuItemCouponModel couponModel = giftCouponMap.get(seq);
                menuCouponMap.remove(seq);
                for (MenuItem menuItem : menuList) {
                    if (TextUtils.equals(seq, menuItem.menuBiz.uniq)) {
                        if (menuItem.menuBiz.bugGiftItem != null) {
                            menuItem.cleanBuyGiftInfo();
                            needCleanBuyGiftMenuInfo.add(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd);
                        }
                        menuItem.cancelDiscount();
                        menuItem.cleanMemberInfo();
                        menuItemCouponGift(orderCache, menuList, menuItem, couponModel);
                        break;
                    }

                    if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                            MenuItemCouponModel modifierCouponModel = giftCouponMap.get(modifier.menuBiz.uniq);
                            if (modifierCouponModel != null) {
                                if (modifier.menuBiz.bugGiftItem != null) {
                                    modifier.cleanBuyGiftInfo();
                                    needCleanBuyGiftMenuInfo.add(modifier.itemID + "_" + modifier.currentUnit.fiOrderUintCd);
                                }
                                modifier.cancelDiscount();
                                modifier.cleanMemberInfo();
                                menuItemCouponGift(orderCache, menuList, modifier, modifierCouponModel);
                            }
                        }
                    }
                }
            }

            //取会员相关信息，会员价用到
            int memberLevel = -1;
            String csId = "";
            String plusId = "";

            NewMemberCardInfoModel model = ServerCache.getInstance().getNewMemberWithHost(hostId);
            if (model != null) {
                memberLevel = model.level;
                csId = model.cs_id;
//                    plusId = model.cp_id??? TODO 黑卡ID拿不到???
            }

            //处理会员价信息---配料菜没有会员价，不需要特殊处理
            for (String seq : memberPriceCouponMap.keySet()) {
                MenuItemCouponModel memberCouponModel = memberPriceCouponMap.get(seq);
                if (memberCouponModel == null) {
                    continue;
                }
                menuCouponMap.remove(seq);
                for (MenuItem menuItem : menuList) {
                    if (TextUtils.equals(seq, menuItem.menuBiz.uniq)) {

                        if (menuItem.menuBiz.bugGiftItem != null) {
                            needCleanBuyGiftMenuInfo.add(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd);
                        }

                        if (memberLevel > 0 && !menuItem.supportTimes() && !menuItem.isMenuTemporary()) {
                            //支持多等级会员价
                            menuItem.currentUnit.fdVIPPrice = MenuItemVipPriceUtil.getMemberVipPrice(menuItem.itemID, menuItem.currentUnit.fiOrderUintCd, memberLevel, csId, plusId);
                        }

                        //使用会员价
                        menuItem.useVipPrice(memberCouponModel.memberOperUserId, memberCouponModel.memberCertigierUserId);

                        break;
                    }
                }
            }

            // 清空买减信息
            if (!ListUtil.isEmpty(needCleanBuyGiftMenuInfo)) {
                for (String ids : needCleanBuyGiftMenuInfo) {
                    for (MenuItem menuItem : menuList) {
                        if (menuItem == null) {
                            continue;
                        }
                        if (menuItem.menuBiz.bugGiftItem != null && TextUtils.equals((menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd), ids)) {
                            menuItem.cleanBuyGiftInfo();
                            menuItem.calcTotal(menuItem.useMemberPrice);
                        }
                    }
                }
            }

            //处理买减信息
            if (!ListUtil.mapIsEmpty(buygiftRelation)) {
                addBuyGiftToMenuItem(userDBModel, menuList, orderCache, buygiftRelation, discountCouponMap);
            }

            //处理菜品折扣---普通折扣
            Map<BigDecimal, List<String>> cashDiscountMap = new HashMap<>();
            Map<BigDecimal, MenuItemCouponBean> cashDiscountCertigierMap = new HashMap<>();
            boolean meet = false;
            for (String seq : discountCouponMap.keySet()) {
                MenuItemCouponModel couponModel = discountCouponMap.get(seq);
                for (MenuItem menuItem : menuList) {
                    meet = menuDiscount(seq, menuItem, null, couponModel, cashDiscountMap, cashDiscountCertigierMap, menuCouponMap);

                    if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier) && !meet) {
                        for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                            if (menuDiscount(seq, modifier, menuItem, couponModel, cashDiscountMap, cashDiscountCertigierMap, menuCouponMap)) {
                                meet = true;
                                break;
                            }
                        }
                    }

                    if (meet) {
                        break;
                    }
                }
            }

            MenuItemCouponBean cashCouponBean = null;
            //处理菜品金额折
            for (BigDecimal amt : cashDiscountMap.keySet()) {
                cashCouponBean = cashDiscountCertigierMap.get(amt);
                if (cashCouponBean == null) {
                    cashCouponBean = new MenuItemCouponBean();
                    cashCouponBean.operUserId = userDBModel.fsUserId;
                }
                cashDiscount(menuList, cashDiscountMap.get(amt), cashCouponBean, DiscountType.CASH, amt);
            }

            //订单买减信息
            if (orderCache != null) {
                if (discountDBModelCut != null) {
                    orderCache.addDiscountCut(discountDBModelCut, userDBModel.fsUserId, "", "");
                } else {
                    orderCache.cancelDiscountCut();
                }
            }
            for (MenuItem item : menuList) {
                item.calcTotal(item.useMemberPrice);
            }
            if (orderCache != null) {
                //重新计算价格
                orderCache.plusAllMenuAmount();
                //存入报表
                OrderSession.getInstance().writeOrder(orderId, true, "doDiscount");
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableId, orderId, "打折");
        }
        return DiscountRepSubCode.eOk;
    }

    /**
     * 买减
     *
     * @param userDBModel       操作人
     * @param menuList
     * @param orderCache
     * @param buygiftRelation
     * @param discountCouponMap
     */
    public static void addBuyGiftToMenuItem(UserDBModel userDBModel, List<MenuItem> menuList,
                                            OrderCache orderCache,
                                            Map<String, Map<String, List<String>>> buygiftRelation,
                                            Map<String, MenuItemCouponModel> discountCouponMap) {

        if (ListUtil.isEmpty(menuList) || ListUtil.mapIsEmpty(buygiftRelation)) {
            return;
        }

        if (ListUtil.mapIsEmpty(discountCouponMap)) {
            discountCouponMap = new ArrayMap<>();
        }

        //每个订单中同样一个菜品只能使用一次买减
        //1、找出本次参与买减的所有菜品   List<String> usedBuyGiftMenu
        //2、将 usedBuyGiftMenu 中的菜品清空买减优惠信息

        List<String> usedBuyGiftMenu = new ArrayList<>();

        for (String fsBargainId : buygiftRelation.keySet()) {
            Map<String, List<String>> menuRelations = buygiftRelation.get(fsBargainId);
            if (!ListUtil.mapIsEmpty(menuRelations)) {
                usedBuyGiftMenu.addAll(menuRelations.keySet());
            }
        }

        for (MenuItem menuItem : menuList) {
            if (menuItem == null) {
                continue;
            }
            if (menuItem.menuBiz.bugGiftItem == null) {
                continue;
            }
            if (usedBuyGiftMenu.contains(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd)) {
                menuItem.cleanBuyGiftInfo();
                menuItem.calcTotal(menuItem.useMemberPrice);
                continue;
            }

                    /*for (String uniq : uniqList) {
                        if (TextUtils.equals(uniq, menuItem.menuBiz.uniq)) {
                            menuItem.cleanBuyGiftInfo();
                            menuItem.calcTotal(false);
                            break;
                        }
                    }*/
        }

        String businessDate = "";
        if (orderCache == null) {
            businessDate = HostUtil.getHistoryBusineeDate("");
        } else {
            businessDate = orderCache.businessDate;
        }

        /*
           buygiftRelation
         * key:fsBargainId  买减ID
         * value: Map<菜品fiitemCd_规格Cd, 菜品uniq集合>
         */
        for (String fsBargainId : buygiftRelation.keySet()) {
            Map<String, List<String>> menuRelations = buygiftRelation.get(fsBargainId);
            CouponBuyGiftModel couponBuyGiftModel = OrderUtil.optBuyGift(businessDate, fsBargainId);
            if (couponBuyGiftModel == null) {
                continue;
            }
            if (menuRelations != null && menuRelations.size() > 0) {
                MenuItem menuItem;
                BigDecimal itemBuyCount = BigDecimal.ZERO;
                BigDecimal headCount = BigDecimal.ZERO;
                BigDecimal tailCount = BigDecimal.ZERO;


                for (String id : menuRelations.keySet()) {
                    BuyGiftItemModel bugGiftItem = OrderUtil.optBugGiftItem(fsBargainId, id.split("_")[0], id.split("_")[1]);
                    bugGiftItem.fsBargainName = couponBuyGiftModel.fsBargainName;
                    headCount = bugGiftItem.fdSaleQty;
                    tailCount = bugGiftItem.fdSaleQty_gift;
                    List<String> uniqStrList = menuRelations.get(id);
                    if (ListUtil.isEmpty(uniqStrList)) {
                        continue;
                    }
                    for (String uniq : uniqStrList) {
                        Iterator<MenuItem> menuItemIterator = menuList.iterator();
                        while (menuItemIterator.hasNext()) {
                            if (tailCount.compareTo(BigDecimal.ZERO) <= 0) {
                                break;
                            }
                            menuItem = menuItemIterator.next();

                            if (menuItem.hasAllVoid()) {
                                continue;
                            }

                            if (menuItem.isMenuTemporary() || menuItem.supportWeight() || menuItem.supportTimes()) {
                                continue;
                            }

                            if (TextUtils.equals(uniq, menuItem.menuBiz.uniq)) {

                                itemBuyCount = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);

                                if (itemBuyCount.compareTo(BigDecimal.ZERO) <= 0) {
                                    continue;
                                }

                                if (menuItem.supportWeight()) {
                                    itemBuyCount = BigDecimal.ONE;
                                }

                                if (headCount.compareTo(BigDecimal.ZERO) > 0) {
                                    if (headCount.compareTo(itemBuyCount) >= 0) {
                                        menuItem.cancelGift(false);
                                        menuItem.useMemberPrice = false;
                                        menuItem.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", true);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --1--- 当前菜品购买数量不足头菜时，全做头菜  decreasConfig" + menuItem.menuBiz.buyNum);

                                        headCount = headCount.subtract(itemBuyCount);
                                    } else {
                                        //大于头菜时，需要做拆分处理   拆出所剩的头菜，剩余菜品数理再和尾菜做比对
                                        MenuItem menuItemClone = menuItem.clone();
                                        menuItemClone.updateUniq();
                                        menuItemClone.menuBiz.buyNum = headCount;
                                        menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                        menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                        menuItemClone.useMemberPrice = false;
                                        menuItemClone.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", true);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --2--- 大于头菜时，需要做拆分处理   拆出所剩的头菜，剩余菜品数理再和尾菜做比对  decreasConfig" + menuItemClone.menuBiz.buyNum);

                                        menuItemClone.cancelGift(false);
                                        menuItemClone.calcTotal(false);

                                        if (DBOrderConfig.useKdsService()) {
                                            // 通知 KDS 菜品拆分
                                            KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                        }

                                        if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            orderCache.originMenuList.add(menuItemClone);
                                        } else {
                                            menuList.add(menuItemClone);
                                        }

                                        if (discountCouponMap.get(menuItem.menuBiz.uniq) != null) {
                                            discountCouponMap.put(menuItemClone.menuBiz.uniq, discountCouponMap.get(menuItem.menuBiz.uniq).clone());
                                        }

                                        headCount = headCount.subtract(headCount);

                                        if (tailCount.compareTo(itemBuyCount.subtract(menuItemClone.menuBiz.buyNum)) >= 0) {
                                            //拆出的菜不足尾菜部分，全做尾菜处理
                                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemClone.menuBiz.buyNum);
                                            menuItem.useMemberPrice = false;
                                            menuItem.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", false);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --3--- 拆出的菜不足尾菜部分，全做尾菜处理  addConfig" + menuItem.menuBiz.buyNum);

                                            menuItem.cancelGift(false);
                                            menuItem.calcTotal(false);

                                            tailCount = tailCount.subtract(menuItem.menuBiz.buyNum);
                                        } else {
                                            //拆出的菜大于尾菜部分，再做拆分处理
                                            MenuItem menuItemCloneTail = menuItem.clone();
                                            menuItemCloneTail.updateUniq();
                                            menuItemCloneTail.menuBiz.buyNum = tailCount;
                                            menuItemCloneTail.menuBiz.voidNum = BigDecimal.ZERO;
                                            menuItemCloneTail.menuBiz.giftNum = BigDecimal.ZERO;
                                            menuItemCloneTail.useMemberPrice = false;
                                            menuItemCloneTail.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", false);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --4--- 拆出的菜大于尾菜部分，再做拆分处理  addConfig" + menuItemCloneTail.menuBiz.buyNum);

                                            menuItemCloneTail.cancelGift(false);
                                            menuItemCloneTail.calcTotal(false);

                                            if (DBOrderConfig.useKdsService()) {
                                                // 通知 KDS 菜品拆分
                                                KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemCloneTail.menuBiz.uniq, menuItemCloneTail.menuBiz.buyNum, 2);
                                            }

                                            if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                                orderCache.originMenuList.add(menuItemCloneTail);
                                            } else {
                                                menuList.add(menuItemCloneTail);
                                            }
                                            if (discountCouponMap.get(menuItem.menuBiz.uniq) != null) {
                                                discountCouponMap.put(menuItemCloneTail.menuBiz.uniq, discountCouponMap.get(menuItem.menuBiz.uniq).clone());
                                            }
                                            tailCount = tailCount.subtract(tailCount);

                                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemClone.menuBiz.buyNum).subtract(menuItemCloneTail.menuBiz.buyNum);
                                            menuItem.calcTotal(false);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --5--- 多出部分不做额外处理 " + menuItem.menuBiz.buyNum);
                                        }
                                    }
                                } else if (tailCount.compareTo(BigDecimal.ZERO) > 0) {

                                    if (tailCount.compareTo(itemBuyCount.subtract(headCount)) >= 0) {
                                        //头菜已分完，当前菜品又不足尾菜部分，全做尾菜处理
                                        menuItem.cancelGift(false);
                                        menuItem.useMemberPrice = false;
                                        menuItem.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", false);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --6--- 头菜已分完，当前菜品又不足尾菜部分，全做尾菜处理  addConfig" + menuItem.menuBiz.buyNum);
                                        menuItem.calcTotal(false);
                                        tailCount = tailCount.subtract(itemBuyCount);
                                    } else {
                                        //头菜已分完，当前菜品大于尾菜部分，再做拆分处理
                                        MenuItem menuItemCloneTail = menuItem.clone();
                                        menuItemCloneTail.updateUniq();
                                        menuItemCloneTail.menuBiz.buyNum = tailCount;
                                        menuItemCloneTail.menuBiz.voidNum = BigDecimal.ZERO;
                                        menuItemCloneTail.menuBiz.giftNum = BigDecimal.ZERO;
                                        menuItemCloneTail.useMemberPrice = false;
                                        menuItemCloneTail.useBuyGift(bugGiftItem, userDBModel.fsUserId, "", false);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItemCloneTail.menuBiz.uniq + " --7--- 头菜已分完，当前菜品大于尾菜部分，再做拆分处理  addConfig" + menuItemCloneTail.menuBiz.buyNum);
                                        menuItemCloneTail.cancelGift(false);
                                        menuItemCloneTail.calcTotal(false);

                                        if (DBOrderConfig.useKdsService()) {
                                            // 通知 KDS 菜品拆分
                                            KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemCloneTail.menuBiz.uniq, menuItemCloneTail.menuBiz.buyNum, 2);
                                        }

                                        if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            orderCache.originMenuList.add(menuItemCloneTail);
                                        } else {
                                            menuList.add(menuItemCloneTail);
                                        }
                                        if (discountCouponMap.get(menuItem.menuBiz.uniq) != null) {
                                            discountCouponMap.put(menuItemCloneTail.menuBiz.uniq, discountCouponMap.get(menuItem.menuBiz.uniq).clone());
                                        }
                                        tailCount = tailCount.subtract(tailCount);

                                        menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemCloneTail.menuBiz.buyNum);
                                        menuItem.calcTotal(false);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItemCloneTail.menuBiz.uniq + " --8--- 尾菜已分完，剩余菜品不做额外处理 " + menuItem.menuBiz.buyNum);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 处理赠送、会员价、折扣（金额折、自定义折扣、普通折扣）  ------------          金额折
     *
     * @param menuItemList
     * @param couponBean
     * @param fsDiscountId
     * @param discountAmt
     */
    public static void cashDiscount(List<MenuItem> menuItemList, List<String> seqList, MenuItemCouponBean couponBean, String fsDiscountId, BigDecimal discountAmt) {
        if (ListUtil.isEmpty(menuItemList)) {
            LogUtil.logBusiness("金额折异常", "没有菜品");
            return;
        }

        if (ListUtil.isEmpty(seqList)) {
            LogUtil.logBusiness("金额折异常", "没有目标菜品的seq列表");
            return;
        }

        DiscountDBModel discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + DiscountType.CASH + "'", DiscountDBModel.class);
        if (discountDBModel == null) {
            LogUtil.logBusiness("金额折异常", "没有查询到金额折折扣对象");
            return;
        }

        // 金额折转换的折扣率
        BigDecimal disCashRate = calcCashDiscountRate(menuItemList, seqList, discountDBModel, discountAmt);

        BigDecimal hasDisAmt = BigDecimal.ZERO;

        for (MenuItem menuItem : menuItemList) {
            if (menuItem == null) {
                continue;
            }
            LogUtil.logBusiness("折扣", "菜品【" + menuItem.name + "," + menuItem.itemID + "," +
                    menuItem.currentUnit.fsOrderUint + "," + menuItem.currentUnit.fiOrderUintCd + "】进行折扣【" +
                    JSON.toJSONString(discountDBModel) + "】");

            // 有配料要折扣
            for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                for (String ingredientUniq : seqList) {
                    if (TextUtils.equals(modifier.menuBiz.uniq, ingredientUniq)) {
                        giveDiscountToMenu(couponBean, discountDBModel, fsDiscountId, discountAmt, disCashRate, modifier, menuItem);
                        modifier.calcTotal(menuItem.useMemberPrice);

                        // 统计已折扣的金额
                        if (modifier.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(modifier.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, modifier.menuBiz.selectDiscount.fsDiscountId)) {
                            hasDisAmt = hasDisAmt.add(modifier.menuBiz.discountAmount);
                        }
                        break;
                    }
                }
            }

            if (seqList.contains(menuItem.menuBiz.uniq)) {
                giveDiscountToMenu(couponBean, discountDBModel, fsDiscountId, discountAmt, disCashRate, menuItem, null);
                menuItem.calcTotal(menuItem.useMemberPrice);

                // 统计已折扣的金额
                if (menuItem.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(menuItem.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, menuItem.menuBiz.selectDiscount.fsDiscountId)) {
                    hasDisAmt = hasDisAmt.add(menuItem.menuBiz.discountAmount);
                }
            }
        }

        // 由于折扣率保留小数，所有菜品按照折扣率折扣后，是否有未折扣的金额，调整菜品折扣金额
        checkCashLeftDiscount(menuItemList, seqList, discountAmt, hasDisAmt);

    }

    /**
     * 由于折扣率保留小数，所有菜品按照折扣率折扣后，是否有未折扣的金额，调整菜品折扣金额
     */
    private static void checkCashLeftDiscount(List<MenuItem> menuItemList, List<String> seqList, BigDecimal discountAmt, BigDecimal hasDisAmt) {
        BigDecimal leftDis = discountAmt.subtract(hasDisAmt);
        if (leftDis.compareTo(BigDecimal.ZERO) != 0) {
            // 未能分配的折扣金额，由菜品依次折扣
            for (MenuItem menuItem : menuItemList) {
                if (menuItem == null) {
                    continue;
                }
                boolean needCalc = false;
                if (seqList.contains(menuItem.menuBiz.uniq)) {
                    // 仅菜品支持折扣，且进行金额折的时候，分摊金额折
                    if (menuItem.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(menuItem.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, menuItem.menuBiz.selectDiscount.fsDiscountId)) {
                        // 菜品还可以折扣的金额
                        BigDecimal canDisAmt = menuItem.menuBiz.totalPrice;
                        if (canDisAmt.compareTo(leftDis) > 0) {
                            menuItem.menuBiz.discountAmount = menuItem.menuBiz.discountAmount.add(leftDis);
                            leftDis = BigDecimal.ZERO;
                        } else {
                            menuItem.menuBiz.discountAmount = menuItem.menuBiz.discountAmount.add(canDisAmt);
                            leftDis = leftDis.subtract(canDisAmt);
                        }
                    }
                    needCalc = true;
                }

                for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                    for (String ingredientUniq : seqList) {
                        if (TextUtils.equals(ingredientUniq, modifier.menuBiz.uniq)) {
                            if (modifier.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(modifier.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, modifier.menuBiz.selectDiscount.fsDiscountId)) {
                                // 菜品还可以折扣的金额
                                BigDecimal canDisAmt = modifier.menuBiz.totalPrice;
                                if (canDisAmt.compareTo(leftDis) > 0) {
                                    modifier.menuBiz.discountAmount = modifier.menuBiz.discountAmount.add(leftDis);
                                    leftDis = BigDecimal.ZERO;
                                } else {
                                    modifier.menuBiz.discountAmount = modifier.menuBiz.discountAmount.add(canDisAmt);
                                    leftDis = leftDis.subtract(canDisAmt);
                                }
                            }
                            needCalc = true;

                            break;
                        }
                    }
                }

                if (needCalc) {
                    menuItem.calcTotal(menuItem.useMemberPrice);
                }
            }
        }
    }


    /**
     * 金额折   ---    计算折扣率    给定要折扣金额，计算出该金额占所选菜品集合中可折扣菜品的比例
     *
     * @param menuItemList
     * @param discountDBModel
     * @param discountAmt
     * @return
     */
    private static BigDecimal calcCashDiscountRate(List<MenuItem> menuItemList, List<String> seqList, DiscountDBModel discountDBModel, BigDecimal discountAmt) {
        if (discountDBModel != null && discountAmt != null && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal total = BigDecimal.ZERO;
            for (MenuItem item : menuItemList) {
                if (item == null) {
                    continue;
                }

                if (!ListUtil.isEmpty(seqList)) {
                    for (MenuItem modifier : item.menuBiz.selectedModifier) {
                        for (String ingredientUniq : seqList) {
                            if (!TextUtils.equals(ingredientUniq, modifier.menuBiz.uniq)) {
                                continue;
                            }

                            if (discountDBModel.ficouponid != 2) {
                                //非整单折扣要判断菜品是否支持此折扣
                                String sql = "select * from (select fsdiscountid from tbDiscountItem where fiItemCd = '" + modifier.itemID + "' and fiOrderUintCd = '" + modifier.currentUnit.fiOrderUintCd + "' and fiStatus = '1' union all select fsdiscountid from tbdiscountmenucls where fsMenuClsId = '" + modifier.categoryCode + "' and fistatus = '1')";
                                List<String> discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                                if (!discountIDList.contains(DiscountType.CASH)) {
                                    continue;
                                }
                            } else {
                                // 整单打折要判断该折扣是否支持不可折扣菜品参与打折
                                // 不可折扣菜品不参与该整单打折 && 菜品不可折扣 -> 不折
                                if (discountDBModel.fiIsDisMenu == 0 && !item.supportDiscount()) {
                                    continue;
                                }
                            }

                            modifier.cancelDiscount();
                            modifier.calcTotal(false);

                            if ((item.supportDiscount() || OrderUtil.supportFullOrderDiscount(discountDBModel, item))) {
                                total = total.add(modifier.menuBiz.totalPrice);
                            }
                        }
                    }
                }

                if (seqList.contains(item.menuBiz.uniq)) {
                    if (discountDBModel.ficouponid != 2) {
                        //非整单折扣要判断菜品是否支持此折扣
                        String sql = "select * from (select fsdiscountid from tbDiscountItem where fiItemCd = '" + item.itemID + "' and fiOrderUintCd = '" + item.currentUnit.fiOrderUintCd + "' and fiStatus = '1' union all select fsdiscountid from tbdiscountmenucls where fsMenuClsId = '" + item.categoryCode + "' and fistatus = '1')";
                        List<String> discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                        if (!discountIDList.contains(DiscountType.CASH)) {
                            continue;
                        }
                    } else {
                        // 整单打折要判断该折扣是否支持不可折扣菜品参与打折
                        // 不可折扣菜品不参与该整单打折 && 菜品不可折扣 -> 不折
                        if (discountDBModel.fiIsDisMenu == 0 && !item.supportDiscount()) {
                            continue;
                        }
                    }

                    item.cancelDiscount(false);
                    item.calcTotal(item.useMemberPrice);

                    if ((item.supportDiscount() || OrderUtil.supportFullOrderDiscount(discountDBModel, item)) && seqList.contains(item.menuBiz.uniq)) {
                        total = total.add(item.menuBiz.totalPrice);
                    }
                }
            }

            if (total.compareTo(BigDecimal.ZERO) > 0 && discountAmt.compareTo(total) <= 0) {
                return discountAmt.divide(total, 4, RoundingMode.HALF_UP);
            }
        }
        return BigDecimal.ZERO;
    }

    /**
     * 给菜品打折
     *
     * @param seq
     * @param menuItem
     * @param father
     * @param couponModel
     * @param cashDiscountCertigierMap
     * @param cashDiscountMap
     * @param menuCouponMap
     */
    private static boolean menuDiscount(String seq, MenuItem menuItem, MenuItem father,
                                        MenuItemCouponModel couponModel,
                                        Map<BigDecimal, List<String>> cashDiscountMap,
                                        Map<BigDecimal, MenuItemCouponBean> cashDiscountCertigierMap,
                                        Map<String, MenuItemCouponModel> menuCouponMap) {
        if (TextUtils.equals(seq, menuItem.menuBiz.uniq)) {

            if (TextUtils.equals(couponModel.discount.couponId, DiscountType.CASH)) {
                //金额折
                if (couponModel.discount.fdddv.compareTo(BigDecimal.ZERO) > 0) {
                    //历史金额折---不需要重新计算
                    menuCouponMap.remove(seq);
                } else {
                    //重新计算金额折的折扣金额和折扣率
                    List<String> menuSeqList = cashDiscountMap.get(couponModel.discount.fdTotalddv);
                    if (ListUtil.isEmpty(menuSeqList)) {
                        menuSeqList = new ArrayList<>();
                        cashDiscountMap.put(couponModel.discount.fdTotalddv, menuSeqList);
                    }
                    menuItem.cancelGift(false);
                    menuSeqList.add(menuItem.menuBiz.uniq);
                    cashDiscountCertigierMap.put(couponModel.discount.fdTotalddv, couponModel.discount);
                    menuCouponMap.remove(seq);
                }
            } else {
                //普通折扣-设置折扣到菜品上
                menuItem.cancelGift(false);
                menuItemCouponDiscount(couponModel.discount, menuItem, father);
                menuItem.calcTotal(couponModel.memberPrice);
                menuCouponMap.remove(seq);
            }
            return true;
        }
        return false;
    }

    /**
     * 折扣落到菜/配料上
     *
     * @param target 菜品/配料
     * @param father 单品或套餐时请传null，配料时传主菜（配料的可折扣属性读主菜的）
     */
    private static void menuItemCouponDiscount(MenuItemCouponBean couponBean,
                                               MenuItem target, MenuItem father) {
        // 配料的可折扣属性读主菜的
        MenuItem checkSupport = father == null ? target : father;
        DiscountDBModel discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + couponBean.couponId + "' and fiStatus = '1' ", DiscountDBModel.class);

        //自定义折扣---折扣率取前端服务员配置的折扣率
        if (TextUtils.equals(DiscountType.CUTSOME_DISOUNT, couponBean.couponId)) {
            discountDBModel.fiDiscountRate = couponBean.fiDiscountRate;
        }

        if (checkSupport.supportDiscount()) { // 菜品可折扣

            if (discountDBModel != null && discountDBModel.ficouponid != 2) {
                // 缓存已赋值的折扣
                int rate = couponBean.fiDiscountRate;

                //非整单打折的折扣要校验该菜品是否支持该折扣
                String sql = "select tbdiscount.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,tbdiscountitem.fiDiscountRate fiDiscountRate from tbdiscount inner join tbdiscountitem on tbdiscountitem.fsDiscountId=tbdiscount.fsDiscountId where tbdiscount.fsDiscountId<>'99999' and tbdiscountitem.fsDiscountId='" + couponBean.couponId + "' and tbdiscountitem.fiStatus ='1' and tbdiscount.fiStatus ='1' and tbdiscountitem.fiOrderUintCd='%1$s' and tbdiscountitem.fiItemCd='%2$s' order by tbdiscount.fsDiscountId asc";
                DiscountDBModel discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.currentUnit.fiOrderUintCd, target.itemID), DiscountDBModel.class);
                if (discount == null) {
                    sql = "select dismenucls.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,dismenucls.fiDiscountRate fiDiscountRate from (select * from tbdiscountmenucls where fsMenuClsId = (select fsMenuClsId from tbmenuitem where fiitemcd = '%1$s') and fistatus = '1' and fsdiscountid = '%2$s' ) dismenucls left join tbdiscount " +
                            "on tbdiscount.fsdiscountid = dismenucls.fsdiscountid and tbdiscount.fistatus = '1' ";
                    discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.itemID, couponBean.couponId), DiscountDBModel.class);
                }

                // 兼容后台自定义折扣可能为部分折扣的情况
                if (discount != null && TextUtils.equals(DiscountType.CUTSOME_DISOUNT, discount.fsDiscountId)) {
                    discount.fiDiscountRate = rate;
                }

                target.giveDiscount(discount, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
            } else {
                target.giveDiscount(discountDBModel, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
            }
        } else { // 菜品不可折扣
            // 整单打折 && 不可折扣菜品可参与该整单打折 -> 可折
            if (discountDBModel != null && discountDBModel.ficouponid == 2 && discountDBModel.fiIsDisMenu == 1) {
                target.giveDiscount(discountDBModel, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
            }
        }
    }

    /**
     * 菜品赠送
     *
     * @param orderCache
     * @param menuItemList
     * @param menuItem
     * @param couponModel
     */
    private static void menuItemCouponGift(OrderCache orderCache, List<MenuItem> menuItemList, MenuItem menuItem, MenuItemCouponModel couponModel) {
        //赠送菜品---没有给数量时，默认是全部赠送
        if (couponModel != null && couponModel.giftNumber != null && couponModel.giftNumber.compareTo(BigDecimal.ZERO) > 0) {
            if (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
                //该菜品是赠送状态--再次提交的赠送数量小于已赠送数量---->取消部分赠送
                if (couponModel.giftNumber.compareTo(menuItem.menuBiz.giftNum) < 0) {
                    MenuItem menuItemClone = menuItem.clone();
                    menuItemClone.updateUniq();
                    menuItemClone.menuBiz.buyNum = menuItemClone.menuBiz.buyNum.subtract(couponModel.giftNumber);
                    menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                    menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                    menuItemClone.cancelGift(false);
                    menuItemClone.calcTotal(false);

                    if (DBOrderConfig.useKdsService()) {
                        // 通知 KDS 菜品拆分
                        KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                    }

                    menuItem.menuBiz.buyNum = couponModel.giftNumber;
                    if (menuItem.doGift(couponModel.giftOperUserId, couponModel.giftCertigierUserId, couponModel.giftReason)) {
                        menuItem.cleanBuyGiftInfo();
                        menuItem.calcTotal(false);
                    }

                    if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        orderCache.originMenuList.add(menuItemClone);
                    } else {
                        menuItemList.add(menuItemClone);
                    }

                    /* 调整划菜数量 */
                    // 已划菜数量
                    BigDecimal delimited = menuItem.menuBiz.delimitNum;
                    // 划菜数量优先分配到赠送的菜品
                    if (menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).compareTo(delimited) >= 0) {
                        menuItem.menuBiz.delimitNum = delimited;
                        menuItemClone.menuBiz.delimitNum = BigDecimal.ZERO;
                    } else {
                        menuItem.menuBiz.delimitNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                        menuItemClone.menuBiz.delimitNum = delimited.subtract(menuItem.menuBiz.delimitNum);
                    }
                }
            } else if (couponModel.giftNumber.compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).subtract(menuItem.menuBiz.giftNum)) < 0) {
                //非赠送菜品---赠送数量小于菜品数量时，认为是赠送部分菜品
                MenuItem menuItemClone = menuItem.clone();
                menuItemClone.updateUniq();
                menuItemClone.menuBiz.buyNum = couponModel.giftNumber;
                menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                if (menuItemClone.doGift(couponModel.giftOperUserId, couponModel.giftCertigierUserId, couponModel.giftReason)) {
                    menuItem.cleanBuyGiftInfo();
                    menuItemClone.calcTotal(false);
                }
                menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(couponModel.giftNumber);
                menuItem.calcTotal(false);

                if (DBOrderConfig.useKdsService()) {
                    // 通知 KDS 菜品拆分
                    KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                }

                if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                    orderCache.originMenuList.add(menuItemClone);
                } else {
                    menuItemList.add(menuItemClone);
                }

                /* 调整划菜数量 */
                // 已划菜数量
                BigDecimal delimited = menuItem.menuBiz.delimitNum;
                // 划菜数量优先分配到赠送的菜品
                if (menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum).compareTo(delimited) >= 0) {
                    menuItemClone.menuBiz.delimitNum = delimited;
                    menuItem.menuBiz.delimitNum = BigDecimal.ZERO;
                } else {
                    menuItemClone.menuBiz.delimitNum = menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum);
                    menuItem.menuBiz.delimitNum = delimited.subtract(menuItemClone.menuBiz.delimitNum);
                }
            } else {
                //非赠送菜品---赠送数量大于等于菜品数量时，认为是赠送全部菜品
                if (menuItem.doGift(couponModel.giftOperUserId, couponModel.giftCertigierUserId, couponModel.giftReason)) {
                    menuItem.cleanBuyGiftInfo();
                    menuItem.calcTotal(false);
                }
            }
        } else {
            if (menuItem.doGift(couponModel.giftOperUserId, couponModel.giftCertigierUserId, couponModel.giftReason)) {
                menuItem.cleanBuyGiftInfo();
                menuItem.calcTotal(false);
            }
        }
    }

    /**
     * 检查数据是否生效
     *
     * @return boolean | true 菜品已生效；false: 菜品还未生效
     */
    public static boolean dataIsEffectiveDate(DiscountDBModel discountDBModel) {
        if (discountDBModel.fiIsEffectiveDate == 0) {
            return true;
        }
        if (TextUtils.isEmpty(discountDBModel.fsStarDate) || TextUtils.isEmpty(discountDBModel.fsEndDate)) {
            return true;
        }
        long startTime = DateTimeUtil.strToDate(discountDBModel.fsStarDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
        long endTime = DateTimeUtil.strToDate(discountDBModel.fsEndDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
        return DateTimeUtil.isBetweenMillis(startTime, endTime);
    }

    /**
     * 折扣落到菜/配料上
     *
     * @param target 菜品/配料
     * @param father 单品或套餐时请传null，配料时传主菜（配料的可折扣属性读主菜的）
     */
    private static void giveDiscountToMenu(MenuItemCouponBean couponBean, DiscountDBModel discountDBModel, String fsDiscountId, BigDecimal discountAmt,
                                           BigDecimal disCashRate, MenuItem target, MenuItem father) {
        // 配料的可折扣属性读主菜的
        MenuItem checkSupport = father == null ? target : father;
        if (checkSupport.supportDiscount()) {
            if (discountDBModel != null && discountDBModel.ficouponid != 2) {
                //非整单打折的折扣要校验该菜品是否支持该折扣
                String sql = "select tbdiscount.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,tbdiscountitem.fiDiscountRate fiDiscountRate from tbdiscount inner join tbdiscountitem on tbdiscountitem.fsDiscountId=tbdiscount.fsDiscountId where tbdiscountitem.fsDiscountId='" + fsDiscountId + "' and tbdiscountitem.fiStatus ='1' and tbdiscount.fiStatus ='1' and tbdiscountitem.fiOrderUintCd='%1$s' and tbdiscountitem.fiItemCd='%2$s' order by tbdiscount.fsDiscountId asc";
                DiscountDBModel discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.currentUnit.fiOrderUintCd, target.itemID), DiscountDBModel.class);
                if (discount == null) {
                    sql = "select dismenucls.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,dismenucls.fiDiscountRate fiDiscountRate from (select * from tbdiscountmenucls where fsMenuClsId = (select fsMenuClsId from tbmenuitem where fiitemcd = '%1$s') and fistatus = '1' and fsdiscountid = '%2$s' ) dismenucls left join tbdiscount " +
                            "on tbdiscount.fsdiscountid = dismenucls.fsdiscountid and tbdiscount.fistatus = '1' ";
                    discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.itemID, fsDiscountId), DiscountDBModel.class);
                }
                if (discount != null && TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discount.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discount, disCashRate, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
                } else {
                    target.giveDiscount(discount, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
                }
            } else {// 整单打折
                if (discountDBModel != null && TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discountDBModel.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discountDBModel, disCashRate, couponBean.reason, "", "", false);
                } else {
                    target.giveDiscount(discountDBModel, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
                }
            }
        } else { // 菜品不可折扣
            // 整单打折 && 不可折扣菜品可参与该整单打折 -> 可折
            if (discountDBModel != null && discountDBModel.ficouponid == 2 && discountDBModel.fiIsDisMenu == 1) {
                if (TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discountDBModel.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discountDBModel, disCashRate, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
                } else {
                    target.giveDiscount(discountDBModel, couponBean.reason, couponBean.operUserId, couponBean.certigierUserId, false);
                }
            }
        }
    }

    /**
     * 预处理会员菜品券，分离出须要核销的及须要退回的。 并做一定的数据检查
     *
     */
    static class ItemCouponInfo {
        public MemberDishCouponBean mCouponBean;
        public MenuItem mItem;
    }

    private static DiscountRepSubCode preDealMbDishCoupon(Map<String, MenuItemCouponModel> menuCouponMap,
                                                          List<MenuItem> menuList,
                                                          List<ItemCouponInfo>  useCouponList,
                                                          List<ItemCouponInfo>  refundCouponList,
                                                          List<MenuItem>  splitMenuItems,   //须要拆分的菜品（比如数量为2的菜品只使用了一张菜品券，须要将1个拆分为2个）
                                                          String[] reqParams,
                                                          List<MenuItem> needRefreshItemList) {
        List<MenuItem> hadWriteoffList = new ArrayList<>();
        List<MenuItem> notUsedList = new ArrayList<>();
        if (!checkMemberCouponWriteoffStat(menuList, hadWriteoffList, notUsedList)) {
            needRefreshItemList.addAll(hadWriteoffList);
            needRefreshItemList.addAll(notUsedList);
            return DiscountRepSubCode.eAbnormalCoupon;
        }
        ItemCouponInfo tmpCouponInfo = null, tmpCouponInfo2 = null;
        //检查新增菜品券
        String consumeReqId = null, consumeTradeNo = null, itemUniq;
        Iterator<Map.Entry<String, MenuItemCouponModel>> couponIter = menuCouponMap.entrySet().iterator();
        Map.Entry<String, MenuItemCouponModel> couponEntry;
        MenuItemCouponModel couponModel;
        MenuItem menuItem = null;
        MemberDishCouponBean itemMbCouponBean = null, itemMbCouponBean2 = null;
        int i, menuSz = menuList.size();
        while (couponIter.hasNext()) {
            couponEntry = couponIter.next();
            couponModel = couponEntry.getValue();
            if (null == couponModel )
                continue;
            itemUniq = couponEntry.getKey();
            if (null == itemUniq || itemUniq.isEmpty())
                continue;
            for ( i = 0; i < menuSz; i ++) {
                menuItem = menuList.get(i);
                if (null == menuItem || null == menuItem.menuBiz || menuItem.menuBiz.uniq == null || !itemUniq.equals(menuItem.menuBiz.uniq))
                    continue;
                break;
            }
            if (i >= menuSz)
                continue;
            if (couponModel.useMemberCoupon)
            {
                //使用菜品券
                if (null == couponModel.dishCoupon || TextUtils.isEmpty(couponModel.dishCoupon.code) || TextUtils.isEmpty(couponModel.dishCoupon.coupon_id) )
                    continue;
                if (menuItem.usedMbCouponSucc()) {
                    itemMbCouponBean = menuItem.usedMemberDishCoupon();
                    //若菜品券已经使用则这次不做处理
                    if (couponModel.dishCoupon.code.equals(itemMbCouponBean.code))
                        continue;
                    //原来已经使用菜品券而这里又给了新的菜品券，则旧券做退回处理
                    tmpCouponInfo = new ItemCouponInfo();
                    tmpCouponInfo.mCouponBean = couponModel.dishCoupon;
                    tmpCouponInfo.mItem = menuItem;
                    useCouponList.add(tmpCouponInfo);
                    tmpCouponInfo = new ItemCouponInfo();
                    tmpCouponInfo.mCouponBean = itemMbCouponBean;
                    tmpCouponInfo.mItem = menuItem;
                    refundCouponList.add(tmpCouponInfo);

                } else {
                    tmpCouponInfo = new ItemCouponInfo();
                    tmpCouponInfo.mCouponBean = couponModel.dishCoupon;
                    tmpCouponInfo.mItem = menuItem;
                    useCouponList.add(tmpCouponInfo);
                }
                removeSameItemInList(hadWriteoffList, menuItem);
                removeSameItemInList(notUsedList, menuItem);

                //判断菜品是否须要拆分
                if (!menuItem.supportWeight() && menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).doubleValue() > 1) {
                    // 非称重菜，数量为多份时,需要拆开一个条目，单独使用优惠券
                    splitMenuItems.add(menuItem);
                }

            } else {
                //原来已经使用菜品券的现在又取消了
                if (menuItem.usedMbCouponSucc()) {
                    tmpCouponInfo = new ItemCouponInfo();
                    tmpCouponInfo.mCouponBean = menuItem.usedMemberDishCoupon();
                    tmpCouponInfo.mItem = menuItem;
                    refundCouponList.add(tmpCouponInfo);
                }
                removeSameItemInList(hadWriteoffList, menuItem);
                removeSameItemInList(notUsedList, menuItem);
            }
        }
        if (hadWriteoffList.size() + notUsedList.size() > 0 ) {
            needRefreshItemList.addAll(hadWriteoffList);
            needRefreshItemList.addAll(notUsedList);
            return DiscountRepSubCode.eAbnormalCoupon;
        }

        //如果一个菜品券由A菜移到B菜，则不再调API回退菜品券及重新核销，直接交换条目的菜品券信息
        int j, useSz = useCouponList.size(), refundSz = refundCouponList.size();
        List<MenuItem> changedItemList = new ArrayList<>();
        HashMap<String, Boolean> couponCodeHash = new HashMap<>();
        for ( i = 0; i < refundSz; i ++) {
            tmpCouponInfo = refundCouponList.get(i);
            itemMbCouponBean = tmpCouponInfo.mCouponBean;
            if (couponCodeHash.containsKey(itemMbCouponBean.code)) {
                needRefreshItemList.addAll(changedItemList);
                return DiscountRepSubCode.eDuplicateCoupon;
            }
            couponCodeHash.put(itemMbCouponBean.code, false);

            for ( j = 0; j < useSz; j ++ ) {
                tmpCouponInfo2 = useCouponList.get(j);
                itemMbCouponBean2 = tmpCouponInfo2.mCouponBean;
                if (itemMbCouponBean2.code.equals(itemMbCouponBean.code)) {
                    break;
                }
            }
            if (j >= useSz)
                continue;
            tmpCouponInfo2.mItem.copyMemberCouponInfo(tmpCouponInfo.mItem);
            tmpCouponInfo.mItem.cleanMemberCouponInfo();
            changedItemList.add(tmpCouponInfo.mItem);
            changedItemList.add(tmpCouponInfo2.mItem);
            useCouponList.remove(j); useSz --;
            refundCouponList.remove(i--); refundSz --;
        }

        if (useSz > 0 ) {
            consumeReqId = UUIDUtil.optUUID();
            consumeTradeNo = UUIDUtil.optUUID();
            for ( j = 0; j < useSz; j ++ ) {
                tmpCouponInfo2 = useCouponList.get(j);
                itemMbCouponBean2 = tmpCouponInfo2.mCouponBean;
                if (couponCodeHash.containsKey(itemMbCouponBean2.code)) {
                    needRefreshItemList.addAll(changedItemList);
                    return DiscountRepSubCode.eDuplicateCoupon;
                }
                couponCodeHash.put(itemMbCouponBean2.code, false);
                tmpCouponInfo2.mItem.useDishCouponForAPI(tmpCouponInfo2.mCouponBean, consumeReqId, consumeTradeNo);
                changedItemList.add(tmpCouponInfo2.mItem);
            }
        }

        for ( i = 0; i < refundSz; i ++) {
            tmpCouponInfo = refundCouponList.get(i);
            tmpCouponInfo.mItem.markRefundMbCoupon();
            changedItemList.add(tmpCouponInfo.mItem);
        }
        if (changedItemList.size() > 0 ) {
            OrderSaveDBUtil.updMenuValueProp(changedItemList);
        }
        reqParams[0] = consumeReqId;
        reqParams[1] = consumeTradeNo;
        return DiscountRepSubCode.eOk;
    }

    private static void removeSameItemInList(List<MenuItem> itemList, MenuItem compareItem) {
        if (null == itemList || null == compareItem || null == compareItem.menuBiz || TextUtils.isEmpty(compareItem.menuBiz.uniq) )
            return;
        int i, iSz = itemList.size();
        MenuItem item;
        for ( i = 0; i < iSz; i ++ ) {
            item = itemList.get(i);
            if (null == item || null == item.menuBiz || null == item.menuBiz.uniq)
                continue;
            if (!compareItem.menuBiz.uniq.equals(item.menuBiz.uniq))
                continue;
            itemList.remove(i);
            break;
        }
    }

    /**
     *
     * 核销、回退菜品券
     * @param orderCache
     * @param useCouponList          核销券的相关信息list
     * @param refundCouponList       回退券的相关信息list
     * @param reqParams              调用API的请求参数
     * @param needStoreMenuItems      须要重新保存的条目（主要用于没有全部成功，部分核销或者部分回退成功后的保存）
     * @param failedWriteoffCoupons  核销失败的券
     * @param failedRefundCoupons    回退失败的券
     * @return
     */
    private static DiscountRepSubCode writeoffMemberCoupon(OrderCache orderCache,
                                                           List<ItemCouponInfo>  useCouponList,
                                                           List<ItemCouponInfo>  refundCouponList,
                                                           String[] reqParams,
                                                           List<MenuItem> needStoreMenuItems,
                                                           List<String> failedWriteoffCoupons,
                                                           List<String> failedRefundCoupons ) {
        String couponSn;
        List<String> snList = new ArrayList<>();
        ItemCouponInfo tmpItemCouponInfo;
        int i, iSz = refundCouponList.size();
        if (iSz > 0 )
        {
            snList.clear();
            for ( i = 0; i < iSz; i ++) {
                tmpItemCouponInfo = refundCouponList.get(i);
                snList.add(tmpItemCouponInfo.mCouponBean.code);
            }
            class IResponseRefundCoupon implements IResponse<MemberCouponRefundResponse> {
                private List<ItemCouponInfo>  mRefundCouponList;
                private List<MenuItem> mNeedSaveMenuItems;
                private List<String> mFailRefundCouponCodeLst;
                public boolean mbSucc = false;
                IResponseRefundCoupon(List<ItemCouponInfo>  refundCouponList, List<MenuItem> ndSaveItemList, List<String> failRefundCouponCodeLst) {
                    mRefundCouponList = refundCouponList;
                    mNeedSaveMenuItems = ndSaveItemList;
                    mFailRefundCouponCodeLst = failRefundCouponCodeLst;
                }
                @Override
                public void callBack(boolean result, int code, String msg, MemberCouponRefundResponse refundResponse) {
                    if (null != refundResponse && null != refundResponse.data) {
                        ItemCouponInfo info;
                        int i, iSz = mRefundCouponList.size();
                        int iSuccCount = 0;
                        for ( i = 0; i < iSz; i ++ ) {
                            info = mRefundCouponList.get(i);
                            if (null != refundResponse.data.success && refundResponse.data.success.contains(info.mCouponBean.code)) {
                                iSuccCount ++;
                                if (info.mItem.refundDishCoupon == null && TextUtils.equals(info.mItem.memberDishCoupon.code, info.mCouponBean.code)) {
                                    info.mItem.cleanMemberCouponInfo();
                                }
                                //已经回退成功须要重新保存
                                info.mItem.refundDishCoupon = null;
                                mNeedSaveMenuItems.add(info.mItem);
                                continue;
                            }
                            if (null != refundResponse.data.fail && refundResponse.data.fail.contains(info.mCouponBean.code)) {
                                //明确有回退失败的答复
                                info.mItem.markWriteoffMbCouponSucc();
                                info.mItem.memberDishCoupon = info.mItem.refundDishCoupon;
                                info.mItem.refundDishCoupon = null;
                                mNeedSaveMenuItems.add(info.mItem);
                            }
                        }
                        if (null != refundResponse.data.fail && refundResponse.data.fail.size() > 0 ) {
                            mFailRefundCouponCodeLst.addAll(refundResponse.data.fail);
                        }
                        mbSucc = iSuccCount == iSz;
                    } else {
                        mbSucc = false;
                    }
                }
            }
            IResponseRefundCoupon responseCallback = new IResponseRefundCoupon(refundCouponList, needStoreMenuItems, failedRefundCoupons);
            try {
                MemberApi.refundMemberCoupon(orderCache.memberInfoS.card_no, snList, responseCallback);
            }
            catch (Exception e) {
                LogUtil.logError(e);
            }
            if (!responseCallback.mbSucc) {
                //Log.v("junTest", "退券失败:" + responseCallback.mFailRefundCouponCodeLst);
                for (ItemCouponInfo coupon : responseCallback.mRefundCouponList) {
                    if (coupon.mItem.refundDishCoupon != null) {
                        coupon.mItem.memberDishCoupon = coupon.mItem.refundDishCoupon;
                        coupon.mItem.refundDishCoupon = null;
                    }
                }
                return DiscountRepSubCode.eRefundFail;
            }
        }
        iSz = useCouponList.size();
        if (iSz > 0 )
        {
            snList.clear();
            tmpItemCouponInfo = useCouponList.get(0);
            couponSn = tmpItemCouponInfo.mCouponBean.code;
            snList.add(tmpItemCouponInfo.mCouponBean.code);
            for ( i = 1; i < iSz; i ++) {
                tmpItemCouponInfo = useCouponList.get(i);
                couponSn += "," + tmpItemCouponInfo.mCouponBean.code;
                snList.add(tmpItemCouponInfo.mCouponBean.code);
            }
            class IResponseConsumeCoupon implements IResponse<List<String>> {
                private List<ItemCouponInfo>  mInCouponList;
                private List<MenuItem> mNeedSaveMenuItems;
                private List<String>  mFailedCouponCodeLst;
                public boolean mbSucc = false;
                IResponseConsumeCoupon(List<ItemCouponInfo>  useCouponList, List<MenuItem> ndSaveItemList, List<String> failedCouponCodeLst) {
                    mInCouponList = useCouponList;
                    mNeedSaveMenuItems = ndSaveItemList;
                    mFailedCouponCodeLst = failedCouponCodeLst;
                }
                @Override
                public void callBack(boolean result, int code, String msg, List<String> failedCouponCodeLst) {
                    mbSucc = null == failedCouponCodeLst || failedCouponCodeLst.size() == 0;
                    MenuItem item;
                    if (mbSucc) {
                        //全部核销成功
                        for ( int i = 0; i < mInCouponList.size(); i ++ ) {
                            item = mInCouponList.get(i).mItem;
                            item.markWriteoffMbCouponSucc();
                            mNeedSaveMenuItems.add(item);
                        }
                    } else {
                        //请求失败（或者部分成功部分失败)
                        ItemCouponInfo info;
                        for ( int i = 0; i < mInCouponList.size(); i ++ ) {
                            info = mInCouponList.get(i);
                            if (failedCouponCodeLst.contains(info.mCouponBean.code)) {
                                if (result) {
                                    //明确返回核销失败
                                    info.mItem.cleanMemberCouponInfo();
                                    mNeedSaveMenuItems.add(info.mItem);
                                }
                            }
                            else {
                                //核销成功
                                info.mItem.markWriteoffMbCouponSucc();
                                mNeedSaveMenuItems.add(info.mItem);
                            }
                        }
                        mFailedCouponCodeLst.addAll(failedCouponCodeLst);
                    }
                }
            }
            IResponseConsumeCoupon responseCallback = new IResponseConsumeCoupon(useCouponList, needStoreMenuItems, failedWriteoffCoupons);
            try {
                MemberApi.couponConsumeRequest(couponSn, snList, reqParams[0], reqParams[1], responseCallback);
            }
            catch (Exception e) {
                LogUtil.logError(e);
            }
            if (!responseCallback.mbSucc) {
                return DiscountRepSubCode.eWriteoffFail;
            }
        }
        return DiscountRepSubCode.eOk;
    }

    /**
     * 检查使用菜品券有异常的条目
     * 由于网络超时或者POS端异常（例如崩溃）导致服务端菜品券已核销但是POS端没有保存下来核销状态等，对于异常状态重新载入时重新向服务端检查核销状态，保持POS端与服务端一致
     * @return true:检查成功（获取API都返会会结果，并不表示没有异常）， false:检查出现异常，例如API报错，超时
     */
    public static boolean checkMemberCouponWriteoffStat(List<MenuItem> menuItemList,
                                                        List<MenuItem> hadUsedItemList,
                                                        List<MenuItem> notUsedItemList) {
        if (null == menuItemList)
            return true;
        int i, iSz = menuItemList.size();
        if (0 == iSz)
            return true;
        MenuItem menuItem;
        MemberDishCouponReqStat.EReqStat stat;
        List<MenuItem> abnormalItemList = new ArrayList<>();
        boolean bResult = true;
        class IResponseQueryCoupon implements IResponse<MemberCouponQueryResponse> {
            private String mCouponSN;
            private MenuItem mCurItem;
            private boolean mbCheckFinish = false;
            private List<MenuItem>  mFixList;
            private List<MenuItem>  mHadUseList;
            private List<MenuItem>  mNotUseList;
            public IResponseQueryCoupon(List<MenuItem>  fixList, List<MenuItem> hadUseList, List<MenuItem> notUseList) {
                mFixList = fixList;
                mHadUseList = hadUseList;
                mNotUseList = notUseList;
            }
            public void setCurItem(String couponSn, MenuItem item) {
                mCouponSN = couponSn;
                mCurItem = item;
                mbCheckFinish = false;
            }
            public boolean isCheckFinish() {
                return mbCheckFinish;
            }
            @Override
            public void callBack(boolean result, int code, String msg, MemberCouponQueryResponse info) {
                if (result) {
                    mbCheckFinish = true;
                    if (null != info && null != info.data && null != info.data.sn && info.data.sn.equals(mCouponSN) ) {
                        mCurItem.cleanMemberCouponInfo();
                        mFixList.add(mCurItem);
                        if (null != mNotUseList)
                            mNotUseList.add(mCurItem);
                    } else {
                        mCurItem.markWriteoffMbCouponSucc();
                        mFixList.add(mCurItem);
                        if (null != mHadUseList)
                            mHadUseList.add(mCurItem);
                    }
                }
            }
        }
        IResponseQueryCoupon queryCallback = new IResponseQueryCoupon(abnormalItemList, hadUsedItemList, notUsedItemList);
        MemberDishCouponBean couponBean;
        for ( i = 0; i < iSz; i ++ ) {
            menuItem = menuItemList.get(i);
            if (null == menuItem )
                continue;
            stat = menuItem.dishCouponReqStat();
            if (!MemberDishCouponReqStat.isAbnormalStat(stat))
                continue;
            if (menuItem.refundDishCoupon != null) {
                couponBean = menuItem.refundDishCoupon;
            } else {
                couponBean = menuItem.usedMemberDishCoupon();
            }
            if (null == couponBean || TextUtils.isEmpty(couponBean.code) ) {
                LogUtil.logError("MenuItem's member coupon info is abnormal[menuitem:" + menuItem.itemID + "]");
                continue;
            }
            try {
                queryCallback.setCurItem(couponBean.code, menuItem);
                MemberApi.queryMemberCoupon(couponBean.code, queryCallback);
            }
            catch (Exception e) {
                LogUtil.logError(e);
            }
            if (!queryCallback.isCheckFinish())
                bResult = false;
        }

        iSz = abnormalItemList.size();
        if (iSz > 0)
            OrderSaveDBUtil.updMenuValueProp(abnormalItemList);
        return bResult;
    }

    /**
     * 拆分菜品处理
     * @param splitItemList List<MenuItem> not null 须要拆分的条目list.
     * @return true: 有改变的条目; false:没有改变的条目
     */
    private static boolean procSplitMenuItems(@NonNull  OrderCache orderCache, @NonNull  List<MenuItem> splitItemList, @NonNull List<String> failedWriteoffCoupons) {
        int i, iSz = splitItemList.size();
        if (iSz <= 0 )
            return false;
        MenuItem item, newItem;
        MemberDishCouponBean couponBean;
        boolean needStore = false;
        for ( i = iSz - 1; i >= 0 ;  i --) {
            item = splitItemList.get(i);
            if (null == item ) {
                splitItemList.remove(i);
                continue;
            }
            couponBean = item.usedMemberDishCoupon();
            if (null == couponBean || null == couponBean.code) {
                splitItemList.remove(i);
                continue;
            }
            if (failedWriteoffCoupons.contains(couponBean.code)) {
                splitItemList.remove(i);
                continue;
            }
            // 非称重菜，数量为多份时,需要拆开一个条目，单独使用优惠券
            newItem = item.clone();
            newItem.menuBiz.generateUniq();
            newItem.menuBiz.buyNum = item.menuBiz.buyNum.subtract(new BigDecimal(1));
            item.menuBiz.buyNum = new BigDecimal(1);
            item.menuBiz.voidNum = BigDecimal.ZERO;
            item.calcTotal(item.useMemberPrice);
            newItem.cleanMemberCouponInfo();
            if (null != orderCache && null != orderCache.originMenuList ) {
                orderCache.originMenuList.add(newItem);
                needStore = true;
            }
        }
        return needStore;
    }
}
