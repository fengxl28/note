package com.mwee.android.pos.businesscenter.print.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.PosBillPayChannel;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.businesscenter.print.PrintJSONBuilder;
import com.mwee.android.pos.businesscenter.print.PrintReportId;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.posmodel.print.PrintTaskDBModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/5/30
 */
public class KoubeiShopPrint extends KoubeiCustomerPrint {
    public KoubeiShopPrint() {
        super(TYPE_SHOP);
    }

    @Override
    protected boolean interruptPrint() {
        boolean interruptPrint = checkTempAppOrderPrintInfo(String.valueOf(orderId), type) && replenishmentReceipt;
        if (interruptPrint) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-商户联小票 中断，理由：已打印过" + JSON.toJSONString(orderId), orderId + "");
        }
        return interruptPrint;
    }

    @Override
    protected List<PrintTaskDBModel> onBuildTasks(JSONObject data, PrintTaskDBModel task) {
        ArrayList<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        data.put("titleSubFix", "-商户联");
        //打印号
        int printNO = PrintJSONBuilder.generatePrintNO();
        data.put("fiPrintNo", printNO);
        task.fiPrintNo = printNO;
        JSONArray statisticsDiscountArray = new JSONArray();
        JSONArray payChannelsArray = new JSONArray();
        List<PosBillPayChannel> posBillPayChannels = JSON.parseArray(orderCache.payListInfo, PosBillPayChannel.class);
        if (posBillPayChannels != null) {
            for (PosBillPayChannel posBillPayChannel : posBillPayChannels) {
                List<RapidPayModel> rapidPayModels = posBillPayChannel.rapidPayModels;
                if (rapidPayModels != null) {
                    for (RapidPayModel rapidPayModel : rapidPayModels) {
                        JSONObject rapidObject = new JSONObject();
                        //张敏加的
                        if (TextUtils.equals(rapidPayModel.fsPaymentName, "支付宝口碑支付")||TextUtils.equals(rapidPayModel.fsPaymentName, "微信小程序口碑支付")) {
                            rapidObject.put("channel_type", rapidPayModel.fsPaymentName);
                            rapidObject.put("pay_amount", rapidPayModel.fdReceMoney);
                            payChannelsArray.add(rapidObject);
                        } else {
                            rapidObject.put("fsDiscountName", rapidPayModel.fsPaymentName);
                            rapidObject.put("discountamt", rapidPayModel.fdReceMoney);
                            statisticsDiscountArray.add(rapidObject);
                        }
                    }
                }
            }
        }

        if (!statisticsDiscountArray.isEmpty()) {
            data.put("statisticsDiscount", statisticsDiscountArray);
        }
        if (!payChannelsArray.isEmpty()) {
            data.put("pay_channels", payChannelsArray);
        }
        task.uri = TicketTempletUtils.getKBOrderShopUri();
        task.fsReportId = PrintReportId.KOBEI_PRE_ORDER_SHOP;
        task.fsReportName = PrintJSONBuilder.getReportNameByID(task.fsReportId);
        task.fsPrnData = data.toJSONString();
        printTaskDBModels.add(task);
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-商户联task" + JSON.toJSONString(task), "");
        return printTaskDBModels;
    }
}
