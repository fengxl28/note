package com.mwee.android.pos.businesscenter.business.notice;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.datasync.net.GetAllNoticeRequest;
import com.mwee.android.pos.component.datasync.net.GetAllNoticeResponse;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.business.NoticeDBModel;
import com.mwee.android.pos.db.business.notice.NoticeDBUtil;

import java.util.List;

/**
 * Created by lxx on 16/10/24.
 */
public class NoticeProcessor {

    public static void prepareGetNotice() {
        if (BindProcessor.isCurrentHostMain()) {
            String lastUpdateTime = NoticeDBUtil.getInstance().getLastUpdateTime();
            getAllNotice(lastUpdateTime);
        }
    }

    /**
     * 获取所有公告
     *
     * @param date
     * @return
     */
    public static String getAllNotice(String date) {
        GetAllNoticeRequest getDataRequest = new GetAllNoticeRequest();
        getDataRequest.fsUpdateTime = date;
        IExecutorCallback callback = new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean instanceof GetAllNoticeResponse) {
                    GetAllNoticeResponse getDataResponse = (GetAllNoticeResponse) responseData.responseBean;
                    List<NoticeDBModel> noticeDBModelList = getDataResponse.data;
                    NoticeDBUtil.getInstance().saveNoticeList(noticeDBModelList);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        };
        return BusinessExecutor.execute(getDataRequest, callback, null, true);
    }

}
