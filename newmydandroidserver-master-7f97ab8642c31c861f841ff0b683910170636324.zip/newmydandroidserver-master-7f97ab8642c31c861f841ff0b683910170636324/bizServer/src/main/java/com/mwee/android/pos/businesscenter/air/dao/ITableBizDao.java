package com.mwee.android.pos.businesscenter.air.dao;

import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.table.TableBizModel;

/**
 * tableBiz桌台状态表数据服务
 * Created by qinwei on 2018/8/17.
 */

public interface ITableBizDao extends IBaseDao<TableBizModel> {
    TableBizModel insert(MtableDBModel mtableDBModel);

    /**
     * 桌台是否占用
     *
     * @param tableId
     * @return
     */
    boolean queryTableIsOpenedByTableId(String tableId);

    /**
     * 开台
     *
     * @param willOpenTable
     * @param fssellno
     * @return
     */
    boolean doOpenTable(MtableDBModel willOpenTable, String fssellno, UserDBModel userDBModel);

    /**
     * 清台操作
     *
     * @param mtableDBModel
     * @param orderId
     * @return
     */
    boolean doClearTable(MtableDBModel mtableDBModel, String orderId, UserDBModel userDBModel);
}
