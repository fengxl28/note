package com.mwee.android.pos.businesscenter.koubei.sync;

/**
 * 订单同步控制器
 * Created by qinwei on 2018/10/22.
 */

public class KBOrderSyncManager {
    private static KBOrderSyncManager mInstance;


    public KBOrderSyncManager() {
    }

    public static KBOrderSyncManager getInstance() {
        if (mInstance == null) {
            mInstance = new KBOrderSyncManager();
        }
        return mInstance;
    }


    public void add(String orderId) {
        KBOrderSyncService.getInstance().add(orderId);
    }

    public void stopAll() {
        KBOrderSyncService.getInstance().stopAll();
    }

}
