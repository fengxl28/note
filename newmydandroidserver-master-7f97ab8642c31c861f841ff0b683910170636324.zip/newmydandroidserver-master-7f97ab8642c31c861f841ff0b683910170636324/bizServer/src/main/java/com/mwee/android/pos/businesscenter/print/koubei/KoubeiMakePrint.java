package com.mwee.android.pos.businesscenter.print.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.DeptDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuClsMuldeptDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrinterSource;
import com.mwee.android.pos.businesscenter.print.DeviceDBUtil;
import com.mwee.android.pos.businesscenter.print.PrintJSONBuilder;
import com.mwee.android.pos.businesscenter.print.PrintReportId;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangmin on 2018/6/1.
 */
public class KoubeiMakePrint extends KoubeiCustomerPrint {

    /**
     * 产品说口碑预点单 标签打印先隐藏
     */
    public static final boolean TAG_ENABLE = true;

    protected final PrinterSource mPrinterSource;


    public KoubeiMakePrint() {
        super(TYPE_MAKE);
        mPrinterSource = new PrinterSource();
    }

    @Override
    protected boolean interruptPrint() {
        boolean interruptPrint = checkTempAppOrderPrintInfo(String.valueOf(orderId), type);
        if (interruptPrint) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-制作单小票 中断，理由：已打印过" + JSON.toJSONString(orderId), orderId + "");
        }
        return interruptPrint;
    }

    @Override
    protected synchronized List<PrintTaskDBModel> onBuildTasks(JSONObject data, PrintTaskDBModel task) {
        ArrayList<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        task.uri = TicketTempletUtils.getKBOrderMakeUri();

        task.fsReportId = PrintReportId.KOBEI_PRE_ORDER_MAKE;
        task.fsReportName = PrintJSONBuilder.getReportNameByID(task.fsReportId);

        //单个菜品的打印数据集合
        List<KBPreMenuItemModel> dishMenuSingleCopy = new ArrayList<>();

        //套餐菜品的打印数据集合
        List<KBPreMenuItemModel> dishPackageCopy = new ArrayList<>();

        //异常菜品以临时菜形式走站点打印
        List<KBPreMenuItemModel> exceptionMenuMakePrinter = new ArrayList<>();

        Iterator<KBPreMenuItemModel> iterator = dishDetails.iterator();
        while (iterator.hasNext()) {
            KBPreMenuItemModel model = iterator.next();
            if (!checkMatchMenu(model)) {
                //如果套餐头匹配不上 那么套餐头 套餐明细都从站点出
                if (model.main_flag && model.type.equals("COMBO")) {
                    //异常产品从站点出  并且只打印套餐明细 不打印套餐头
                    exceptionMenuMakePrinter.addAll(model.packageMenuItemDetails);
                } else {
                    exceptionMenuMakePrinter.add(model);
                }

            } else {
                if (model.main_flag && model.type.equals("COMBO")) {
                    //todo 重新计算套餐明细数量
                    for (KBPreMenuItemModel packageMenuItemDetail : model.packageMenuItemDetails) {
                        packageMenuItemDetail.dish_num = model.dish_num.multiply(packageMenuItemDetail.dish_num);
                    }
                    dishPackageCopy.add(model);
                } else {
                    dishMenuSingleCopy.add(model);
                }
            }
        }

        if (!ListUtil.isEmpty(exceptionMenuMakePrinter)) {
            PrintTaskDBModel cloneTask = task.clone();
            String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID) + "'");
            boolean isTag = mPrinterSource.isTagPrinterByPrinterName(fsPrinterName);
            if (isTag && TAG_ENABLE) {
                printTaskDBModels.addAll(getTagPrintTaskModelException(exceptionMenuMakePrinter, fsPrinterName));
            }
            //打印号
            int printNO = PrintJSONBuilder.generatePrintNO();
            data.put("fiPrintNo", printNO);
            cloneTask.fiPrintNo = printNO;
            data.put("Dept", "");
            data.put("dish_details", exceptionMenuMakePrinter);
            cloneTask.fsPrnData = data.toJSONString();
            cloneTask.fsPrinterName = fsPrinterName;
            cloneTask.fsDeptId = "";
            cloneTask.fsDeptName = "Cashier";
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印异常菜品走临时菜-制作单task" + JSON.toJSONString(cloneTask), "");
            printTaskDBModels.add(cloneTask);
        }

        Map<String, List<KBPreMenuItemModel>> printData=new HashMap<>();
        printData.putAll(getMenuSinglePrinterMap(dishMenuSingleCopy));
        Map<String, List<KBPreMenuItemModel>> menuDepPackageMap = getPackagePrinterMap(dishPackageCopy);
        for (Map.Entry<String, List<KBPreMenuItemModel>> stringListEntry : menuDepPackageMap.entrySet()) {
            if (printData.containsKey(stringListEntry.getKey())) {
                printData.get(stringListEntry.getKey()).addAll(stringListEntry.getValue());
            }else{
                printData.put(stringListEntry.getKey(),stringListEntry.getValue());
            }
        }
        /**
         * 正常菜品走部门打印
         */
        if (printData.isEmpty()) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-普通菜品打印制作单异常-获取菜品打印Map为null");
        }
        for (String depId : printData.keySet()) {
            DeptDBModel deptDBModel = DeptDBUtils.queryById(depId);
            boolean isTag = mPrinterSource.isTagPrinterByPrinterName(deptDBModel.fsPrinterName);
            if (isTag && TAG_ENABLE) {
                printTaskDBModels.addAll(getTagPrintTaskModel(printData.get(depId), deptDBModel));
                continue;
            }

            List<KBPreMenuItemModel> dishData = printData.get(depId);

            // 制作单 1=一菜一切/2=总单/3=总单&一菜一切/4=一份一切
            if (deptDBModel.fiIsOneItemCut == 1) {
                printTaskDBModels.addAll(printBySingleDish(task, deptDBModel, dishData, data, depId));
            } else if (deptDBModel.fiIsOneItemCut == 2) {
                printTaskDBModels.add(printByComplex(task, deptDBModel, dishData, data, depId));
            } else if (deptDBModel.fiIsOneItemCut == 3) {
                printTaskDBModels.add(printByComplex(task, deptDBModel, dishData, data, depId));
                printTaskDBModels.addAll(printBySingleDish(task, deptDBModel, dishData, data, depId));
            } else if (deptDBModel.fiIsOneItemCut == 4) {
                printTaskDBModels.addAll(printBySingleItem(task, deptDBModel, dishData, data, depId));
            }
        }
        return printTaskDBModels;
    }

    /**
     * 生成制作总单任务对象
     *
     * @param task
     * @param deptDBModel
     * @param dishData
     * @param data
     * @param depId
     * @return
     */
    private PrintTaskDBModel printByComplex(PrintTaskDBModel task, DeptDBModel deptDBModel, List<KBPreMenuItemModel> dishData, JSONObject data, String depId) {
        PrintTaskDBModel cloneTask = task.clone();

        //打印号
        int printNO = PrintJSONBuilder.generatePrintNO();
        data.put("fiPrintNo", printNO);
        cloneTask.fiPrintNo = printNO;
        data.put("Dept", deptDBModel.fsDeptName);
        data.put("dish_details", dishData);
        data.put("receiptType", "(总单)");
        cloneTask.fsPrnData = data.toJSONString();
        cloneTask.fsPrinterName = deptDBModel.fsPrinterName;
        cloneTask.fsDeptId = depId;
        cloneTask.fsDeptName = deptDBModel.fsDeptName;
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-制作单task" + JSON.toJSONString(cloneTask), "");
        return cloneTask;
    }

    /**
     * 生成一菜一切制作单任务对象们
     *
     * @param task
     * @param deptDBModel
     * @param dishData
     * @param data
     * @param depId
     * @return
     */
    private List<PrintTaskDBModel> printBySingleDish(PrintTaskDBModel task, DeptDBModel deptDBModel, List<KBPreMenuItemModel> dishData, JSONObject data, String depId) {

        List<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        for (int i = 0; i < dishData.size(); i++) {
            PrintTaskDBModel cloneTask = task.clone();
            int printNO = PrintJSONBuilder.generatePrintNO();
            data.put("fiPrintNo", printNO);
            cloneTask.fiPrintNo = printNO;
            data.put("Dept", deptDBModel.fsDeptName);
            //根据菜品重新分割数据
            // TODO: 2018/10/19 修改数据完成单条数据展示
            //TODO 美易点一菜一切/一份一切需要测试验证是否适配
            List<KBPreMenuItemModel> singleDishArray = new ArrayList<>();
            singleDishArray.add(dishData.get(i));

            data.put("dish_details", singleDishArray);
            data.put("receiptType", "(单品)");
            cloneTask.fsPrnData = data.toJSONString();
            cloneTask.fsPrinterName = deptDBModel.fsPrinterName;
            cloneTask.fsDeptId = depId;
            cloneTask.fsDeptName = deptDBModel.fsDeptName;
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-制作单task" + JSON.toJSONString(cloneTask), "");
            printTaskDBModels.add(cloneTask);
        }

        return printTaskDBModels;
    }

    /**
     * 生成一份一切制作单任务对象
     *
     * @param task
     * @param deptDBModel
     * @param dishData
     * @param data
     * @param depId
     * @return
     */
    private List<PrintTaskDBModel> printBySingleItem(PrintTaskDBModel task, DeptDBModel deptDBModel, List<KBPreMenuItemModel> dishData, JSONObject data, String depId) {
        List<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        for (int i = 0; i < dishData.size(); i++) {
            KBPreMenuItemModel itemModel = dishData.get(i);
            int dishQty = itemModel.dish_num.intValue();
            itemModel.dish_num = new BigDecimal(1);
            for (int j = 0; j < dishQty; j++) {
                PrintTaskDBModel cloneTask = task.clone();
                int printNO = PrintJSONBuilder.generatePrintNO();
                data.put("fiPrintNo", printNO);
                cloneTask.fiPrintNo = printNO;
                data.put("Dept", deptDBModel.fsDeptName);
                //根据单独份数重新分割数据
                // TODO: 2018/10/19 修改数据完成单条数据展示
                List<KBPreMenuItemModel> singleDishArray = new ArrayList<>();
                singleDishArray.add(itemModel);

                data.put("dish_details", singleDishArray);
                data.put("receiptType", "(单品)");
                cloneTask.fsPrnData = data.toJSONString();
                cloneTask.fsPrinterName = deptDBModel.fsPrinterName;
                cloneTask.fsDeptId = depId;
                cloneTask.fsDeptName = deptDBModel.fsDeptName;
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-制作单task" + JSON.toJSONString(cloneTask), "");
                printTaskDBModels.add(cloneTask);
            }
        }

        return printTaskDBModels;
    }

    /**
     * 单个菜品的打印
     *
     * @param itemModels
     */
    private Map<String, List<KBPreMenuItemModel>> getMenuSinglePrinterMap(List<KBPreMenuItemModel> itemModels) {
        //获取打印机逻辑 根据菜品id->获取分类id->获取部门id->获取打印机名称.
        HashMap<String, List<KBPreMenuItemModel>> map = new HashMap<>();
        for (KBPreMenuItemModel itemModel : itemModels) {
            if (TextUtils.equals(itemModel.dish_name, "预点单餐盒费")) {
                continue;
            }
            //根据菜品ID找分类id
            MenuitemDBModel menuitemDBModel = MenuItemDBUtils.queryById(itemModel.fiItemCd);
            //菜品是否可打印
            if (menuitemDBModel.fiIsPrn == 0) {
                continue;
            }
            //根据菜品分类id查询 关联的打印机名称列表
            List<String> depIds = new ArrayList<>();
            if (APPConfig.isMydKouBei()) {
                depIds = MenuClsMuldeptDBUtils.queryDepIdByMenu(menuitemDBModel);
            } else {
                depIds = MenuClsMuldeptDBUtils.queryDepIdByDic(menuitemDBModel.fsMenuClsId);
            }
            if (depIds.isEmpty()) {
                String info = "打印制作单失败,没有找到启用的打印机。菜品ID[" + menuitemDBModel.fsMenuClsId + "]";
//                ToastUtil.showToast(info);
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, info, "");
                continue;
            }

            //一个菜品可能对多个部门（打印机） 分组各个打印机下菜品
            for (String depId : depIds) {
                List<KBPreMenuItemModel> kbPreMenuItemModels = map.get(depId);
                if (kbPreMenuItemModels == null) {
                    kbPreMenuItemModels = new ArrayList<>();
                    kbPreMenuItemModels.add(itemModel);
                    map.put(depId, kbPreMenuItemModels);
                } else {
                    kbPreMenuItemModels.add(itemModel);
                }

            }

        }
        return map;
    }


    /**
     * 套餐 key--部门id  value菜品集合
     *
     * @param
     * @return
     */
    private Map<String, List<KBPreMenuItemModel>> getPackagePrinterMap(List<KBPreMenuItemModel> fatherModules) {
        HashMap<String, List<KBPreMenuItemModel>> map = new HashMap<>();
        for (KBPreMenuItemModel fatherModule : fatherModules) {

            MenuitemDBModel fatherDBModel = MenuItemDBUtils.queryById(fatherModule.fiItemCd);
            //套餐头菜品不打印
            if (fatherDBModel.fiIsPrn == 0) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "根据套餐头进行打印  打印制作单失败,菜品属性为不可打印。菜品ID[" + fatherDBModel.fiItemCd + "]", JSON.toJSONString(fatherModule));
                continue;
            } else if (fatherDBModel.fiIsPrn == 1 && fatherDBModel.fiIsSetDtlPrn == 1) {//套餐头菜品打印 并且根据套餐头打印
                //根据菜品分类id查询 关联的打印机名称列表
                List<String> depIds = MenuClsMuldeptDBUtils.queryDepIdByMenu(fatherDBModel);
                //todo 美小易需要单独处理 具体逻辑待定
            /*if (APPConfig.isMydKouBei()) {
                depIds = MenuClsMuldeptDBUtils.queryDepIdByMenu(fatherDBModel);
            } else {
                depIds = MenuClsMuldeptDBUtils.queryDepIdByDic(fatherDBModel.fsMenuClsId);
            }*/
                if (depIds.isEmpty()) {
                    RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "根据套餐头进行打印  打印制作单失败,没有找到启用的打印机。菜品分类ID[" + fatherDBModel.fsMenuClsId + "]", "");
                    continue;
                }
                //一个菜品可能对多个部门（打印机） 分组各个打印机下菜品
                for (String depId : depIds) {
                    List<KBPreMenuItemModel> kbPreMenuItemModels = map.get(depId);
                    if (kbPreMenuItemModels == null) {
                        kbPreMenuItemModels = new ArrayList<>();
                        kbPreMenuItemModels.addAll(fatherModule.packageMenuItemDetails);
                        map.put(depId, kbPreMenuItemModels);
                    } else {
                        kbPreMenuItemModels.addAll(fatherModule.packageMenuItemDetails);
                    }
                }
            } else {//套餐头菜品打印 并且根据套餐明细打印
                Map<String, List<KBPreMenuItemModel>> packageDetailMap = getMenuSinglePrinterMap(fatherModule.packageMenuItemDetails);
                for (Map.Entry<String, List<KBPreMenuItemModel>> stringListEntry : packageDetailMap.entrySet()) {
                    if (map.containsKey(stringListEntry.getKey())) {
                        map.get(stringListEntry.getKey()).addAll(stringListEntry.getValue());
                    }else{
                        map.put(stringListEntry.getKey(),stringListEntry.getValue());
                    }
                }
            }
        }
        return map;
    }


    /**
     * 获取标签打印的task
     *
     * @param itemModels
     * @return
     */
    private List<PrintTaskDBModel> getTagPrintTaskModel(List<KBPreMenuItemModel> itemModels, DeptDBModel deptDBModel) {
        return new KoubeiTagPrint()
                .setOrderDetails(itemModels)
                .setOrderId(orderId)
                .setOrderTime(orderCache.order_time)
                .setUserName("admin")
                .setTakeNo(orderCache.take_no)
                .setDeptDBModel(deptDBModel)
                .buildShouldPrintTasks();
    }


    /**
     * 获取标签打印的task
     *
     * @param itemModels
     * @return
     */
    private List<PrintTaskDBModel> getTagPrintTaskModelException(List<KBPreMenuItemModel> itemModels, String fsPrinterName) {
        return new KoubeiTagPrint()
                .setOrderDetails(itemModels)
                .setOrderId(orderId)
                .setOrderTime(orderCache.order_time)
                .setUserName("admin")
                .setTakeNo(orderCache.take_no)
                .setPrinterName(fsPrinterName)
                .buildShouldPrintTasks();
    }


    private String getDefaultPrinterName() {
        String fsPrinterName = DBPrintConfig.optNetPrintName();
        if (TextUtils.isEmpty(fsPrinterName)) {
            PrinterDBModel printer = DeviceDBUtil.getPrinterByHostID(hostId);
            if (printer == null) {
                fsPrinterName = DeviceDBUtil.getCurrentHostPrinterName();
            } else {
                fsPrinterName = printer.fsPrinterName;
            }
        }
        return fsPrinterName;
    }


    /**
     * 校验当前菜品是是否走口碑临时菜逻辑
     *
     * @param dish_detail
     * @return ture/表示匹配成功  fale菜品异常匹配失败
     */
    public static boolean checkMatchMenu(KBPreMenuItemModel dish_detail) {

        if (TextUtils.isEmpty(dish_detail.fiItemCd) || TextUtils.isEmpty(dish_detail.fiOrderUintCd)) {
            return false;
        }
        String sqlMenuItem = "select fsItemName from tbmenuitem where fiItemCd='" + dish_detail.fiItemCd + "' and fistatus = '1'";
        String fsItemName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMenuItem);
        if (TextUtils.isEmpty(fsItemName)) {//菜品
            return false;
        }
        String sqlMenuItemUint = "SELECT fiOrderUintCd from tbmenuitemuint where fiOrderUintCd= '" + dish_detail.fiOrderUintCd + "' and fistatus ='1'";
        if (TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMenuItemUint))) {//规格
            return false;
        }
        return true;

    }
}
