package com.mwee.android.pos.businesscenter.business.koubei;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.print.koubei.KoubeiCustomerPrint;
import com.mwee.android.pos.businesscenter.print.koubei.KoubeiMakePrint;
import com.mwee.android.pos.businesscenter.print.koubei.KoubeiShopPrint;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangmin on 2018/6/1.
 */

public class KBMakePrinter {


    public static void init() {

        GlobalLooper.registBasedOn30Seconds(new ILoopCall() {
            @Override
            public void call() {

                List<CacheModel> cacheModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from datacache where  type = '" + IOCache.TYPE_KB_MAKE + "'", CacheModel.class);
                Iterator<CacheModel> iterator = cacheModelList.iterator();
                while (iterator.hasNext()) {
                    CacheModel item = iterator.next();
                    long timePrint = StringUtil.toLong(item.value, 0l);
                    // 打印时间小于当前时间 立即打印 否则交给下一次轮询任务
                    if (timePrint - DateUtil.getCurrentTimeInMills() <= 0) {

                        printKBMake(item.key);

                        item.delete();
                    }
                }
            }
        }, 1);

    }


    /**
     * 构建30秒轮询打印 口碑预点单制作单的机制
     *
     * @param order_id
     * @param printerTime
     */
    public static void buildMakeCache(String order_id, String printerTime) {

        CacheModel cacheModel = new CacheModel();
        cacheModel.key = order_id;
        cacheModel.type = IOCache.TYPE_KB_MAKE;
        cacheModel.value = printerTime;
        cacheModel.createtime = DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss");
        cacheModel.replace();

    }


    /**
     * /**
     *
     * @param order_id
     */
    public static void printKBMake(String order_id) {
        if (TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_MAKE_PRINT, "1"), "1")) {

            new KoubeiMakePrint()
                    .setOrderId(order_id)
                    .setUserName("admin")
                    .print();

            //口碑回传'已下厨'状态.
            String merchant_id = KBPreOrderDBUtils.queryMerchantId(order_id);
            new KBPreOrderApi().cooking(order_id, merchant_id, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    LogUtil.logBusiness("口碑订单状态callback1--已下厨--成功--order_id=" + order_id + "   商户ID-->" + merchant_id);
                    //BPreOrderDBUtils.update(order_id + "", "COOKING");
//                    KBPreOrderCache kbPreOrderCache = KBPreOrderDBUtils.query(order_id);
//                    NotifyToClient.refreshCooking(kbPreOrderCache);
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    LogUtil.logBusiness("口碑订单状态callback1--已下厨--失败--order_id=" + order_id + "   商户ID-->" + merchant_id);
                    return false;
                }
            });
        }

    }


    /**
     * 处理延时打印模式下
     * 口碑预点单打印问题
     *
     * @param order_id
     * @param table_time
     */
    public static void treatPrinter(String order_id, String table_time) {


        //客户联商户联理解打印
        printBill(order_id);

        if (!TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_MAKE_PRINT, "1"), "1")) {
            return;
        }
        //备餐时间
        int beicanTime = StringUtil.toInt(ClientMetaUtil.getConfig(META.PRE_ORDER_PREPARE_TIME, "30")) * 60 * 1000;
        //当前时间
        Long currentTime = System.currentTimeMillis();
        //预约时间
        Long yuyuetime = DateTimeUtil.getLongByTimeReal(table_time, "yyyy-MM-dd HH:mm:ss");
        //打印时间
        Long printerTime = yuyuetime - beicanTime;

        if (printerTime <= currentTime) {
            // 打印时间小于当前时间
            //立即打印
            printKBMake(order_id);

        } else if (printerTime - currentTime < 10 * 60 * 1000) {
            // 打印时间距当前时间不足10分钟, 自己轮询  交给GloopLoop轮询处理
            buildMakeCache(order_id, printerTime.toString());
        } else {
            // 打印时间超出当前时间10分钟, 交给 Job 轮询
            //开启job
            Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType.KB_PRINTER + "' AND biz_key = '" + order_id + "'", Job.class);
            if (job == null) {
                job = new Job();
                job.type = JobType.KB_PRINTER;
                job.biz_key = order_id;
                job.info = printerTime.toString();
                job.cycle = 1;
//                job.trace1 = String.valueOf(isSendCooking);
                JobScheudler.newJob(job);
            }
        }


    }


    /**
     * 美小易 手动点击打印
     * （手动点击打印时 不管是否开启 口碑商户联开关 都要打印 且 只打印口碑商户联）
     *
     * @param order_id
     */
    public static void printAirBill(String order_id) {
        UserDBModel hostUser = HostUtil.getHostUser();
        String userName = hostUser != null && !TextUtils.isEmpty(hostUser.fsUserName) ? hostUser.fsUserName : "admin";
        new KoubeiShopPrint()
                .setOrderId(order_id)
                .setUserName(userName)
                .print();
    }

    public static void printBill(String order_id) {
        UserDBModel hostUser = HostUtil.getHostUser();
        String userName = hostUser != null && !TextUtils.isEmpty(hostUser.fsUserName) ? hostUser.fsUserName : "admin";

        if (TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_SHOP_PRINT, "0"), "1")) {
            new KoubeiShopPrint()
                    .setOrderId(order_id)
                    .setUserName(userName)
                    .print();
        }

        if (TextUtils.equals(ClientMetaUtil.getConfig(META.T_KB_CUSTOMER_PRINT, "1"), "1")) {
            new KoubeiCustomerPrint()
                    .setOrderId(order_id)
                    .setUserName(userName)
                    .print();
        }

    }
}
