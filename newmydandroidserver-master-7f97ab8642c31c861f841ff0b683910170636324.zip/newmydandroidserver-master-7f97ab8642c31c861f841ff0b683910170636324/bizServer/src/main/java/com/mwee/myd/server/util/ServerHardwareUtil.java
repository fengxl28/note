package com.mwee.myd.server.util;

import android.os.Environment;
import android.text.TextUtils;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.SdcardUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by virgil on 2018/3/1.
 *
 * @author virgil
 */

public class ServerHardwareUtil {
    /**
     * 获取硬件标示符,
     * 获取顺序为：DB里存的硬件标示符->文件里存的硬件标示符
     * <p>
     * 如果获取失败，则重新生成，
     * 生成的顺序是：序列号->Wifi macAddress->以太网 macAddress->IMEI->DeviceID->UUID
     *
     * @return String
     */
    public synchronized static String getHardWareSymbol() {
        String result = getHardwareSymbolInner();
        BizConstant.DEVICE_ID = result;
        return result;
    }

    /**
     * 将硬件标志写入DB
     *
     * @param symbol String
     */
    public synchronized static void updateHardwareSymbol(String symbol) {
        DBMetaUtil.updateSettingsValueByKey(META.HARDWARE_SYMBOL, symbol);
    }

    private synchronized static String getHardwareSymbolInner() {

        String address = DBMetaUtil.getSettingsValueByKey(META.HARDWARE_SYMBOL);
        if (!TextUtils.isEmpty(address)) {
            return address;
        }
        if (!SdcardUtil.hasExternalStoragePermission(GlobalCache.getContext())) {
            return "";
        }
        Map<String, String> config = FileUtil.readProperties(getConfigPath());
        if (TextUtils.isEmpty(address)) {
            if (config == null) {
                config = new HashMap<>();
            }
            address = config.get("symbol");
        }
        if (!TextUtils.isEmpty(address)) {
            config.put("symbol", address);
            DBMetaUtil.updateSettingsValueByKey(META.HARDWARE_SYMBOL, address);
            FileUtil.writeProperties(GlobalCache.getContext(), getConfigPath(), config);
            return address;
        }
        //如果获取为空，先拿取序列号
        if (TextUtils.isEmpty(address)) {
            address = DeviceUtil.getSerialNO();
        }
        //再拿Mac地址
        if (TextUtils.isEmpty(address)) {
            address = DeviceUtil.getMacAddress(GlobalCache.getContext());
        }
        //再拿IMEI
        if (TextUtils.isEmpty(address)) {
            address = DeviceUtil.getImei(GlobalCache.getContext());
        }
        //再拿DeviceID
        if (TextUtils.isEmpty(address)) {
            address = DeviceUtil.getDeviceID(GlobalCache.getContext());
            if (!TextUtils.isEmpty(address) && address.startsWith("000000")) {
                address = "";
            }
        }
        //最后拿UUID
        if (TextUtils.isEmpty(address)) {
            address = ClientMetaUtil.getSettingsValueByKey(META.KEY_UUID);
        }
        if (TextUtils.isEmpty(address)) {
            address = DeviceUtil.generateUUID();
            DBMetaUtil.updateSettingsValueByKey(META.KEY_UUID, address);
        }
        if (!TextUtils.isEmpty(address)) {
            config.put("symbol", address);
            DBMetaUtil.updateSettingsValueByKey(META.HARDWARE_SYMBOL, address);
            FileUtil.writeProperties(GlobalCache.getContext(), getConfigPath(), config);
        }
        return address;
    }

    public static String getConfigPath() {
        return Environment.getExternalStorageDirectory().getPath() + "/puscene/yunpos";
    }

    /**
     * 将硬件标识符写入sdcard
     */
    public static void writeHardwareToSdcard() {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                String address = ClientMetaUtil.getSettingsValueByKey(META.HARDWARE_SYMBOL);
                if (!TextUtils.isEmpty(address)) {
                    Map<String, String> config = FileUtil.readProperties(getConfigPath());
                    if (TextUtils.isEmpty(address)) {
                        if (config == null) {
                            config = new HashMap<>();
                        }
                        address = config.get("symbol");
                        config.put("symbol", address);
                        FileUtil.writeProperties(GlobalCache.getContext(), getConfigPath(), config);
                    }
                }
                return null;
            }
        });
    }
}
