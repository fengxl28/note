package com.mwee.android.pos.businesscenter.air.dbUtil;


import android.text.TextUtils;

import com.mwee.android.air.db.business.bargain.FullReduceBean;
import com.mwee.android.air.db.business.payment.PaymentInfo;
import com.mwee.android.air.db.business.payment.PaymentManageInfo;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.BargainDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.business.CutmoneyDBModel;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * author:luoshenghua
 * create on:2018/6/2
 * description:
 */
public class AirBargainDBUtil {

    /**
     * 添加满减优惠
     *
     * @return int
     */
    public static String addFullReduce(FullReduceBean fullReduceBean, UserDBModel userDBModel) {

        String fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        String fsPaymentId = getFsPaymentId(fsShopGUID, userDBModel.fsUpdateUserId, userDBModel.fsUpdateUserName);
        if (TextUtils.isEmpty(fsPaymentId)) {
            LogUtil.log("AirBargainDBUtil", "添加满减优惠-->paymentId插入失败");
            return "满减优惠添加失败";
        }

        String checkSql = "select * from tbBargain where fsBargainName = '" + fullReduceBean.fsBargainName + "' and fiStatus = '1'";
        BargainDBModel bargainDBModelTemp = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, BargainDBModel.class);
        if (bargainDBModelTemp != null) {
            LogUtil.log("--------tbBargain--该优惠已存在=");
            return "该优惠已存在";
        } else {
            String HistoryDate = HostUtil.getHistoryBusineeDate("");
            bargainDBModelTemp = new BargainDBModel();
            bargainDBModelTemp.fsBargainId = IDHelper.generateFullReduceId();
            bargainDBModelTemp.fsBargainName = fullReduceBean.fsBargainName;
            bargainDBModelTemp.fsBeginTime =HistoryDate;
            bargainDBModelTemp.fsEndTime = DateTimeUtil.getHistoryDateAfterYears(HistoryDate, 99);
//            bargainDBModelTemp.fsMSectionIdList = fullReduceBean.fsMSectionIdList;
            bargainDBModelTemp.fiPlanType = 1;
            bargainDBModelTemp.fsPlanTypeValue = "1";
            bargainDBModelTemp.fiBargainCls = 18003;
            bargainDBModelTemp.fiStatus = 1;
            bargainDBModelTemp.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            bargainDBModelTemp.fsUpdateUserId = userDBModel.fsUpdateUserId;
            bargainDBModelTemp.fsUpdateUserName = userDBModel.fsUpdateUserName;
            bargainDBModelTemp.fsShopGUID = fsShopGUID;
            bargainDBModelTemp.fiDataSource = 1;
            bargainDBModelTemp.sync = 1;

            bargainDBModelTemp.replaceNoTrans();
            MetaDBController.updateSyncTime();
            addtbCutMoney(bargainDBModelTemp, fullReduceBean, fsPaymentId);//添加消费金额满减表数据
            return "";
        }
    }


    /**
     * 添加消费金额满减表数据
     *
     * @return int
     */
    private static String addtbCutMoney(BargainDBModel bargainDBModel, FullReduceBean fullReduceBean, String fsPaymentId) {
        String checkSql = "select * from tbcutmoney where fsBargainId = '" + bargainDBModel.fsBargainId + "' and fiStatus = '1'";
        CutmoneyDBModel cutmoneyDBModelTemp = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, CutmoneyDBModel.class);
        if (cutmoneyDBModelTemp != null) {
            LogUtil.log("--------tbcutmoney--该优惠已存在=");
            return "该优惠已存在";
        } else {
            cutmoneyDBModelTemp = new CutmoneyDBModel();
            cutmoneyDBModelTemp.fsBargainId = bargainDBModel.fsBargainId;
            cutmoneyDBModelTemp.fdFullmoney = fullReduceBean.fdFullmoney;
            cutmoneyDBModelTemp.fdCutmoney = fullReduceBean.fdCutmoney;
            cutmoneyDBModelTemp.fifullcuttype = fullReduceBean.fifullcuttype;
            cutmoneyDBModelTemp.fsPaymentId = fsPaymentId;
            cutmoneyDBModelTemp.fiStatus = 1;
            cutmoneyDBModelTemp.fsUpdateTime = bargainDBModel.fsUpdateTime;
            cutmoneyDBModelTemp.fsUpdateUserId = bargainDBModel.fsUpdateUserId;
            cutmoneyDBModelTemp.fsUpdateUserName = bargainDBModel.fsUpdateUserName;
            cutmoneyDBModelTemp.fsShopGUID = bargainDBModel.fsShopGUID;
            cutmoneyDBModelTemp.fiDataSource = 1;
            cutmoneyDBModelTemp.sync = 1;
            cutmoneyDBModelTemp.replaceNoTrans();
            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 获取删除满减优惠列表
     *
     * @return int
     */
    public static int deleteFullReduceBatch(List<String> fullReduceIdList, UserDBModel userDBModel) {
        String rebuildStr = parsListToSQLParam(fullReduceIdList);
        String fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        String fsUpdateUserName = userDBModel == null ? "" : userDBModel.fsUserName;
        String fsUpdateUserId = userDBModel == null ? "" : userDBModel.fsUserId;

        int success = 0;
        boolean tbbargainResult = DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbbargain set fistatus = '13',  sync = '1',fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fsBargainId in (" + rebuildStr + ") and fistatus = '1'");
        boolean tbcutmoneyResult = DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbcutmoney set fistatus = '13', sync = '1', fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fsBargainId in (" + rebuildStr + ") and fistatus = '1'");
        if (tbbargainResult && tbcutmoneyResult) {
            success = 1;
        }
        MetaDBController.updateSyncTime();
        return success;
    }

    /**
     * 更新满减优惠
     *
     * @return int
     */
    public static String updateFullReduce(FullReduceBean fullReduceBean, UserDBModel UpUserDBModel) {
        LogUtil.log("------更新满减优惠  updateFullReduce  fsBargainId=" + fullReduceBean.fsBargainId);
        if (TextUtils.isEmpty(fullReduceBean.fsBargainId)) {
            LogUtil.log("----更新满减优惠  tbBargain  优惠信息异常，请重试=");
            return "优惠信息异常，请重试";
        }
        String checkSql = "select * from tbBargain where fsBargainId = '" + fullReduceBean.fsBargainId + "'";
        BargainDBModel upBargainDBModelTemp = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, BargainDBModel.class);
        if (upBargainDBModelTemp == null) {
            LogUtil.log("------更新满减优惠  tbBargain 未找到该优惠");
            return "未找到该优惠";
        } else {
            upBargainDBModelTemp.fsBargainId = fullReduceBean.fsBargainId;
            upBargainDBModelTemp.fsBargainName = fullReduceBean.fsBargainName;
//            upBargainDBModelTemp.fsBeginTime = startTime;
//            upBargainDBModelTemp.fsEndTime = DateTimeUtil.getDateAfterYears(99);
//            upBargainDBModelTemp.fsMSectionIdList = fullReduceBean.fsMSectionIdList;

            upBargainDBModelTemp.fiPlanType = 1;
            upBargainDBModelTemp.fsPlanTypeValue = "1";
            upBargainDBModelTemp.fiBargainCls = 18003;
            upBargainDBModelTemp.fiStatus = 1;
            upBargainDBModelTemp.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            upBargainDBModelTemp.fsUpdateUserId = UpUserDBModel.fsUpdateUserId;
            upBargainDBModelTemp.fsUpdateUserName = UpUserDBModel.fsUpdateUserName;
            upBargainDBModelTemp.fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
            upBargainDBModelTemp.sync = 1;
            upBargainDBModelTemp.fiDataSource = 1;
            upBargainDBModelTemp.replaceNoTrans();
            updateTbCutMoney(upBargainDBModelTemp, fullReduceBean);
            MetaDBController.updateSyncTime();
            return "";
        }
    }


    /**
     * 更新消费金额满减表数据
     *
     * @return int
     */
    private static String updateTbCutMoney(BargainDBModel upBargainDBModel, FullReduceBean fullReduceBean) {
        LogUtil.log("------更新消费金额满减表数据  updateTbCutMoney  fsBargainId=" + upBargainDBModel.fsBargainId);
        if (TextUtils.isEmpty(upBargainDBModel.fsBargainId)) {
            LogUtil.log("------更新消费金额满减表数据  tbcutmoney 优惠信息异常，请重试");
            return "优惠信息异常，请重试";
        }
        String checkSql = "select * from tbcutmoney where fsBargainId = '" + upBargainDBModel.fsBargainId + "' and fiStatus = '1'";
        CutmoneyDBModel upCutmoneyDBModelTemp = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, CutmoneyDBModel.class);
        if (upCutmoneyDBModelTemp == null) {
            LogUtil.log("--------更新消费金额满减表数据  tbcutmoney  未找到该优惠=");
            return "未找到该优惠";
        } else {
            String fsPaymentId = queryPaymentId(upBargainDBModel.fsShopGUID);
            upCutmoneyDBModelTemp.fsBargainId = upBargainDBModel.fsBargainId;
            upCutmoneyDBModelTemp.fdFullmoney = fullReduceBean.fdFullmoney;
            upCutmoneyDBModelTemp.fdCutmoney = fullReduceBean.fdCutmoney;
            upCutmoneyDBModelTemp.fifullcuttype = fullReduceBean.fifullcuttype;
            upCutmoneyDBModelTemp.fsPaymentId = fsPaymentId;
            upCutmoneyDBModelTemp.fiStatus = 1;
            upCutmoneyDBModelTemp.fsUpdateTime = upBargainDBModel.fsUpdateTime;
            upCutmoneyDBModelTemp.fsUpdateUserId = upBargainDBModel.fsUpdateUserId;
            upCutmoneyDBModelTemp.fsUpdateUserName = upBargainDBModel.fsUpdateUserName;
            upCutmoneyDBModelTemp.fsShopGUID = upBargainDBModel.fsShopGUID;
            upCutmoneyDBModelTemp.sync = 1;
            upCutmoneyDBModelTemp.fiDataSource = 1;

            upCutmoneyDBModelTemp.replaceNoTrans();
            MetaDBController.updateSyncTime();
            return "";
        }
    }


    /**
     * 获取满减优惠列表
     *
     * @return int
     */
    public static List<FullReduceBean> optFullReduceList() {
        String sql = "select tbBargain.fsBargainId,tbBargain.fsBargainName,tbBargain.fiPlanType,tbCutMoney.fdFullmoney,tbCutMoney.fdCutmoney,tbCutMoney.fifullcuttype from tbBargain inner join tbCutMoney on tbBargain.fsBargainId= tbCutMoney.fsBargainId where tbBargain.fiStatus='1' and tbCutMoney.fiStatus='1' and tbBargain.fiBargainCls in ('3','18003')";
        List<FullReduceBean> bargainDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, FullReduceBean.class);
        return bargainDBModelList;
    }

    public static String parsListToSQLParam(List<String> params) {
        StringBuilder stringBuilder = new StringBuilder();

        if (!ListUtil.isEmpty(params)) {
            for (String str : params) {
                stringBuilder.append("'").append(str).append("'").append(",");
            }
            String str = stringBuilder.toString();
            if (stringBuilder.length() > 1) {
                str = str.substring(0, str.length() - 1);
            }
            return str;
        }
        return "";
    }


    /**
     * 获取满减优惠支付ID
     *
     * @return int
     */
    public static String getFsPaymentId(String fsShopGUID, String fsUpdateUserId, String fsUpdateUserName) {
        String fsPaymentId = queryPaymentId(fsShopGUID);

        if (TextUtils.isEmpty(fsPaymentId)) {
            addPayment(fsShopGUID, fsUpdateUserId, fsUpdateUserName);
            return queryPaymentId(fsShopGUID);
        }

        return fsPaymentId;
    }

    /**
     * 查询消费支付代号
     *
     * @return String
     */
    private static String queryPaymentId(String fsShopGUID) {
        String sql = "select fsPaymentId from tbpayment where fsShopGUID='" + fsShopGUID + "' and fiStatus='1' and fsPaymentId='" + PayType.FULL_REDUCE + "'";
        String fsPaymentId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return fsPaymentId;
    }

    /**
     * 兼容老店
     * 添加满减支付方式
     */
    private static synchronized void addPayment(String fsShopGUID, String fsUpdateUserId, String fsUpdateUserName) {
        PaymentInfo model = new PaymentInfo();

        //android端新建满减支付方式默认主要字段数据保持与后台添加的数据完全一致，除sync，fiDataSource等
        model.fsPaymentId = PayType.FULL_REDUCE;
        model.fsShopGUID = fsShopGUID;
        model.fsPaymentTypeId = "90";
        model.fsPaymentName = "满减";
        model.fdDefaultPrice = BigDecimal.ZERO;
        model.fiIsForeign = 0;
        model.fdExchangeRate = BigDecimal.ZERO;
        model.fiIsCalcPaid = 0;
        model.fiIsCalcInvoice = 0;
        model.fiIsPremium = 1;
        model.fsNote = "";
        model.fiSortOrder = 0;
        model.fiStatus = 1;
        model.fiDataKind = 1;
        model.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        model.fsUpdateUserId = fsUpdateUserId;
        model.fsUpdateUserName = fsUpdateUserName;
        model.sync = 1;
        model.fiDataSource = 1;

//        model.fscolor = "";
//        model.fdDiscountRate = BigDecimal.ZERO;
//        model.fsDiscountPaymentId = "";
//        model.fiIsPartAmtDiscount = 0;
//        model.fsShortcutKey = "";
//        model.fsHelpCode = "";
//        model.fiIsEffectiveDate = 0;
//        model.fsStarDate = "";
//        model.fsEndDate = "";
//        model.fiVoucherPlatform = 0;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
    }
}
