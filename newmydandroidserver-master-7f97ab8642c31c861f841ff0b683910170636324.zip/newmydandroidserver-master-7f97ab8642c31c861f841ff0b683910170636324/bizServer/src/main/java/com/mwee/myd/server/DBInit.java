package com.mwee.myd.server;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.business.constants.TempAppOrderConstant;
import com.mwee.android.pos.business.netorder.NetOrder;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderModifier;
import com.mwee.android.pos.component.datasync.net.model.TempModifierDetail;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.DBTools;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuExtra;
import com.mwee.android.pos.db.business.menu.bean.MenuExtraItem;
import com.mwee.android.pos.db.business.menu.bean.MenuExtraType;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBCreate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Created by virgil on 2018/2/28.
 *
 * @author virgil
 */

public class DBInit {

    protected final static int DBVERSION = 143;

    public static void initClientDBConnection(Context context) {
        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase(context.getDatabasePath(APPConfig.DB_CLIENT).toString(), null, 0);
            if (db != null) {
                int version = db.getVersion();
                db.close();
                DBManager.init(context, 0, APPConfig.DB_CLIENT, version);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }


        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase(context.getDatabasePath(APPConfig.DB_PRINT).toString(), null, 0);
            if (db != null) {
                int version = db.getVersion();
                db.close();
                DBManager.init(context, 0, APPConfig.DB_PRINT, version);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    public static void initOtherDB(Context context) {
        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase(context.getDatabasePath(APPConfig.DB_BUGLY).toString(), null, 0);
            if (db != null) {
                int version = db.getVersion();
                db.close();
                DBManager.init(context, 0, APPConfig.DB_BUGLY, version);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }

        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase(context.getDatabasePath(APPConfig.DB_INFO_COLLECT).toString(), null, 0);
            if (db != null) {
                int version = db.getVersion();
                db.close();
                DBManager.init(context, 0, APPConfig.DB_INFO_COLLECT, version);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    /**
     * 注意，2.7的标签逆向的开关转移到了tbPrinter里，每个打印机可以单独配置，所以需要从META表抽取开关
     * //CALLME 这里
     *
     * @param context
     */
    public static void initDB(Context context) {
        DBManager.setDefaultDbName(APPConfig.DB_MAIN);
        DBManager.init(context, R.raw.posclientdb, APPConfig.DB_MAIN, DBVERSION, new IDBCreate() {
            @Override
            public void onCreate(SQLiteDatabase db) {
                RunTimeLog.addLog(RunTimeLog.DB, "BaseDBInit initDB onCreate version " + DBVERSION);
                checkExtra(true, db);
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                RunTimeLog.addLog(RunTimeLog.DB, "BaseDBInit initDB onUpgrade oldVersion " + oldVersion + ",newVersion" + newVersion);
                try {
                    if (oldVersion < 2) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN \"uri\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN \"fiRetry\" INTEGER");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN \"fiPaperSize\" INTEGER");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN \"fsbackup0\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN \"fsbackup1\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN \"fsbackup2\" TEXT");

                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"jobstack\" (\"appOrderId\" INTEGER PRIMARY KEY  NOT NULL  DEFAULT (0), \"type\" INTEGER, \"status\" BOOL, \"params\" TEXT, \"updateTime\" VARCHAR, \"other1\" TEXT, \"other2\" TEXT, \"other3\" TEXT, \"other4\" TEXT)");
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"tempapporder\" (\"payStatus\" INTEGER, \"orderStatus\" INTEGER, \"diningStatus\" INTEGER, \"orderId\" PRIMARY KEY  NOT NULL  DEFAULT (0), \"bizType\" INTEGER, \"body\" TEXT)");
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"push_msg_stack\" (\"msgId\"  INTEGER PRIMARY KEY  NOT NULL  DEFAULT (0), \"receipt\" BOOL, \"updateTime\" VARCHAR, \"msg\" TEXT)");
                    }
                    if (oldVersion < 3) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellcheck ADD COLUMN \"fsbackup0\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellcheck ADD COLUMN \"fsbackup1\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellcheck ADD COLUMN \"fsbackup2\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellcheck ADD COLUMN \"locked\" INTEGER  DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN \"fsbackup0\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN \"fsbackup1\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN \"fsbackup2\" TEXT");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN \"locked\" INTEGER  DEFAULT 0");

                        //会员积分赠送表
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"order_member_score\" (\"orderid\" TEXT PRIMARY KEY  NOT NULL  DEFAULT 0, \"order_real_amount\" NUMERIC DEFAULT 0, \"memebr_score\" INTEGER DEFAULT 0, \"member_card_no\" TEXT, \"is_refund\" INTEGER DEFAULT 0, \"biz_date\" TEXT, \"is_done\" INTEGER DEFAULT 0, \"shopid\" TEXT)");

                    }
                    if (oldVersion < 4) {
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"host_status\" (\"hostid\" CHAR,\"device\" CHAR,\"bind_time\" DATETIME,\"bind_count\" INTEGER DEFAULT (0) ,\"bind_status\" INTEGER DEFAULT (0) ,\"biz_status\" INTEGER DEFAULT (0) , \"current_user_id\" CHAR)");
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"data_history\" (\"time\" DATETIME PRIMARY KEY  NOT NULL  UNIQUE , \"data\" TEXT)");
                        DBTools.exeSqlWithoutException(db, "insert or replace into meta values(" + META.BIZ_CENTER_IS_MAINHOST + ",1)");
                        DBTools.exeSqlWithoutException(db, "insert or replace into meta values(" + META.BIZ_CENTER_ADDRESS + ",'127.0.0.1')");
                        DBTools.exeSqlWithoutException(db, "insert or replace into meta values(" + META.BIZ_CENTER_CURRENT_HOST_ID + ",'" + getHistoryHost(db) + "')");

                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN \"fsTaskDetail\" TEXT");
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"datacache\" (\"key\" CHAR PRIMARY KEY  DEFAULT 0, \"value\" TEXT)");
                    }
                    if (oldVersion < 5) {

                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN \"fiIsBonus\" int(11) NOT NULL DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN \"fiIsTakeAway\" int(11) NOT NULL DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN \"fiIsHot\" int(11) NOT NULL DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN \"fiIsSet\" int(11) NOT NULL DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN \"fscolor\" char(11)  DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN waiterid CHAR");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN totalCalcPaied  NUMERIC");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN waitername TEXT ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN shiftid varchar(20)  ");

                        DBTools.exeSqlWithoutException(db, "alter table tbMenuItem add column fiIsMulDept int DEFAULT 0 ; --COMMENT '是否为多制作部门(0=否/1=是)'");
                        DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column fiIsMulDept int DEFAULT 0 ; --COMMENT '是否为多制作部门(0=否/1=是)'");
                        DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column fiIsSetDtlPrn int DEFAULT 2 ; --COMMENT '是否套餐头部门打印(1=套餐头部门/2=明细部门)'");

                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbMenuItemMulDept " +
                                "(" +
                                "fiMulDeptCd         int          NOT NULL  " +
                                ",fiItemCd           int             NOT NULL" +
                                ",fsShopGUID         VARCHAR(80)     NOT NULL " +
                                ",fsDeptId           VARCHAR(20)       " +
                                ",fsMAreaId          VARCHAR(20)       " +
                                ",fiStatus           int             NOT NULL " +
                                ",fsUpdateTime       VARCHAR(20)     NOT NULL " +
                                ",fsUpdateUserId     VARCHAR(20)           " +
                                ",fsUpdateUserName   VARCHAR(30)  " +
                                ",CONSTRAINT pk_tbMenuItemMulDept PRIMARY KEY(fiMulDeptCd)" +
                                ")");

                    }

                    if (oldVersion < 6) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE data_history ADD COLUMN data_path VARCHAR");
                        checkDataHistoryUpdate(db);
                    }
                    if (oldVersion < 7) {
                        checkPayCacheTableFull(db);
                        checkMultiDeptOrder(db);
                    }
                    if (oldVersion < 8) {
                        /*
                         * LXX 10-19 新增公告表
                         * 3.2.3版本
                         */
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbnotice (" +
                                "  Id int(11) NOT NULL  ," +
                                "  fsTitle varchar(50) NOT NULL ," +
                                "  fsContent varchar(2000) NOT NULL ," +
                                "  fiStatus int(11) NOT NULL DEFAULT '1' ," +
                                "  fsCreatUser varchar(11) DEFAULT '' ," +
                                "  fsCreatTime varchar(20) NOT NULL ," +
                                "  fsShopGUID varchar(80) DEFAULT NULL," +
                                "  fsUpdateTime varchar(20) NOT NULL ," +
                                "  isRead int(11) NOT NULL DEFAULT '0' ," +
                                "  PRIMARY KEY (Id)" +
                                ")");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN \"fiItemSetCalc\" INTEGER");
                        DBTools.exeSqlWithoutException(db, "alter table tbmenuitemsetside ADD COLUMN fiSetFoodType int DEFAULT 0; --COMMENT '配菜项类型(0=固定/1=可选)'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmtable ADD COLUMN prestatmentstatus INTEGER DEFAULT 0; --COMMENT '预结单打印状态(0=未打印/1=已打印)'");
                        checkMultiDeptOrder(db);
                    }
                    if (oldVersion < 9) {
                        checkPaySessionSynced(db);
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS 'dailyReport' " +
                                "('businessdate' VARCHAR NOT NULL , " +
                                "'type' VARCHAR NOT NULL , " +
                                "'value' TEXT NOT NULL , " +
                                "'param1' TEXT NOT NULL , " +
                                "'param2' TEXT NOT NULL , " +
                                "'updateTime' VARCHAR NOT NULL , " +
                                "'shopGUID' VARCHAR NOT NULL , " +
                                "'id' INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL  UNIQUE  DEFAULT 1)");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmarea ADD COLUMN wxMsgCount INTEGER DEFAULT 0; --COMMENT '餐区内所有云端消息数'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmtable ADD COLUMN ordersource INTEGER DEFAULT 0; --COMMENT '餐台订单来源(0=本地订单/1=秒点订单)'");
                    }

                    if (oldVersion < 10) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_member_score ADD COLUMN fdExpAmt NUMERIC DEFAULT 0; --COMMENT '订单总额'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_member_score ADD COLUMN requestOrderid TEXT; --COMMENT '会员的请求流水号'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN isRapidPay INTEGER DEFAULT 0; --COMMENT '是否秒付'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmarea ADD COLUMN fsPrinterName varchar(100) DEFAULT NULL; --COMMENT '餐区对应的打印机'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbshop ADD COLUMN fslogourl varchar(100) DEFAULT NULL; --COMMENT '门店fslogourl'");
                    }

                    if (oldVersion < 11) {
                        checkTableFlag(db);
                    }
                    if (oldVersion < 12) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN voidreason TEXT");
                        checkShiftID(db);
                    }

                    if (oldVersion < 13) {
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS table_lock (fsMTableId VARCHAR(20),lockedStatus INTEGER,lockedUserID VARCHAR(20),lockedUserName VARCHAR(50) ,fsHostId varchar(30), PRIMARY KEY (fsMTableId))");
                    }
                    if (oldVersion < 14) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN ficouponid int DEFAULT 0; --COMMENT '折扣方案(0 菜品折扣 /1 整单立减 / 2 整单打折)'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fdddv NUMERIC DEFAULT 0; --COMMENT '(立减的金额)'");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fsbakprintername VARCHAR(100);");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN switch_backup Integer DEFAULT 0; ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN switchTime VARCHAR(20) ; ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN is_backup_printer Integer DEFAULT 0; ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_member_score ADD COLUMN billNO Integer DEFAULT 0");
                    }

                    if (oldVersion < 15) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN fsbakprintername VARCHAR(100);");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsDiscountId varchar(50) DEFAULT NULL; ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsDiscountName varchar(16) DEFAULT NULL; ");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN mergedOrderID varchar(16) DEFAULT NULL; ");
                    }
                    if (oldVersion < 16) {
                        transSellOrderItem(db);
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitemsetsidedtl ADD COLUMN fdIncrease NUMERIC DEFAULT 0");
                    }
                    if (oldVersion < 17) {
                        //添加折扣率
                        DBTools.exeSqlWithoutException(db, "alter table tbPayment add column fdDiscountRate NUMERIC(18,6);");
                        //添加折扣归属
                        DBTools.exeSqlWithoutException(db, "alter table tbPayment add column fsDiscountPaymentId varchar(10) DEFAULT NULL;");
                    }

                    if (oldVersion < 18) {
                        /**
                         * 17-01-16 lxx
                         * 添加订单来源
                         */
                        DBTools.exeSqlWithoutException(db, "alter table tempapporder add column orderTakeawaySource varchar DEFAULT NULL;");

                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbuserMenuItemRole(\n" +
                                "  'fsUserId' varchar(20) NOT NULL DEFAULT '',\n" +
                                "  'fiItemCd' int(11) NOT NULL,\n" +
                                "  'fiType' int(11) NOT NULL ,\n" +
                                "  'fiOrderUintCd' int(11) NOT NULL , \n" +
                                "  'fsShopGUID' varchar(80) NOT NULL DEFAULT '' ,\n" +
                                "  'fsCreateTime' varchar(20) DEFAULT NULL ,\n" +
                                "  'fsCreateUserId' varchar(20) DEFAULT NULL ,\n" +
                                "  'fsCreateUserName' varchar(30) DEFAULT NULL ,\n" +
                                "  'fsUpdateUserId' varchar(20) DEFAULT NULL ,\n" +
                                "  'fsUpdateUserName' varchar(30) DEFAULT NULL ,\n" +
                                "  'fsUpdateTime' varchar(20) DEFAULT NULL ,\n" +
                                "  'fiStatus' int(11) DEFAULT NULL,\n" +
                                "  PRIMARY KEY ('fsUserId','fiItemCd','fiOrderUintCd','fsShopGUID')\n" +
                                ")");
                        DBTools.exeSqlWithoutException(db, "alter table tbuser add column loginToken varchar(20) DEFAULT NULL;");
                        DBTools.exeSqlWithoutException(db, "alter table tbuser add column loginHost varchar(20) DEFAULT NULL;");
                        DBTools.exeSqlWithoutException(db, "alter table tbTransferPrn add column fiStatus Integer DEFAULT 1;");
                        DBTools.exeSqlWithoutException(db, "alter table tbuser add column fiIsRetreatFood INTEGER DEFAULT 0;");

                        /**
                         * lxx 2017-01-22 微信点餐表
                         */
                        creatTableWechat(db);
                    }

                    if (oldVersion < 19) {
                        /**
                         *lxx 2017-02-09 消息中心
                         */
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"message\" (\"msgId\" INTEGER PRIMARY KEY  AUTOINCREMENT NOT NULL , \"msgCategory\" INTEGER, \"msgType\" INTEGER, \"readStatus\" INTEGER, \"dealStatus\" INTEGER, \"businessStatus\" INTEGER, \"businessDate\" VARCHAR, \"msgHead\" TEXT check(typeof(\"msgHead\") = 'text') , \"msgDes\" TEXT check(typeof(\"msgDes\") = 'text'), \"msgBody\" TEXT check(typeof(\"msgBody\") = 'text') , \"createTime\" VARCHAR, \"createUser\" VARCHAR, \"updateTime\" VARCHAR, \"updateUser\" VARCHAR, \"standBy1\" VARCHAR, \"standBy2\" VARCHAR)");
                        /**
                         * zhangmin 2017-02-09 开台参数
                         */
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"tbopenparam\" (\"fiId\" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , \"fsMAreaId\" VARCHAR NOT NULL , \"fiOrderUintCd\" INTEGER NOT NULL , \"fiItemCd\" INTEGER NOT NULL , \"fiNumberType\" INTEGER NOT NULL  DEFAULT 1, \"fiSaleQty\" INTEGER NOT NULL , \"fiIsGift\" INTEGER NOT NULL  DEFAULT 0, \"fiStatus\" INTEGER NOT NULL  DEFAULT 1, \"fsShopGUID\" VARCHAR NOT NULL , \"fsUpdateTime\" VARCHAR NOT NULL , \"fsUpdateUserId\" VARCHAR NOT NULL , \"fsUpdateUserName\" VARCHAR NOT NULL )");

                        /**
                         * qw 2017-02-10 餐桌区域新增一个排序字段
                         */
                        DBTools.exeSqlWithoutException(db, "alter table tbMArea add column fiSortOrder Integer DEFAULT 0;");
                        /**
                         * lxx 2017-02-14 微信订单新增一个字段标示更新时间的
                         */
                        DBTools.exeSqlWithoutException(db, "alter table tbwechatorder add column fssettlement VARCHAR ;");
                    }
                    if (oldVersion < 20) {
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN order_status INTEGER DEFAULT -1");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN person_num INTEGER DEFAULT -1");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN total_price NUMERIC DEFAULT -1");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN create_time NUMERIC DEFAULT -1");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN tableID varchar(20) DEFAULT NULL");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN tableName varchar(50) DEFAULT NULL");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN business_date  varchar(8) DEFAULT NULL");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN is_member  INTEGER DEFAULT 0");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN member_info  varchar(500) DEFAULT NULL");
                        updateV20(db);

                        //lxx 2017-2-21 会员等级ID;打折理由是否必选
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fiVIPId int DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fiDiscReason NUMERIC DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"tableBiz\" (\n" +
                                "\"fsmtableid\" character varchar(20) PRIMARY KEY  NOT NULL ,\n" +
                                "\"fsmareaid\" character varchar(20) DEFAULT (NULL) ,\n" +
                                "\"fssellno\" character varchar(20) DEFAULT (NULL) ,\n" +
                                "\"fsmtablesteid\" character varchar(20),\n" +
                                "\"fshint\" character varchar(20) DEFAULT (NULL) ,\n" +
                                "\"fisharebills\" integer NOT NULL ,\n" +
                                "\"fistatus\" integer NOT NULL ,\n" +
                                "\"fiopenjob\" integer NOT NULL  DEFAULT (0) ,\n" +
                                "\"fsopenusername\" character varchar(30) DEFAULT (NULL) ,\n" +
                                "\"fsopenhstime\" character varchar(20) DEFAULT (NULL) ,\n" +
                                "\"fioccupyflag\" integer NOT NULL ,\n" +
                                "\"fiwxmsgflag\" integer NOT NULL ,\n" +
                                "\"prestatmentstatus\" INTEGER DEFAULT (0) , \n" +
                                "\"ordersource\" INTEGER DEFAULT 0, \n" +
                                "\"flag\" INTEGER DEFAULT 0, \n" +
                                "\"extra_order\" TEXT,\n" +
                                "lockedStatus INTEGER DEFAULT 0, " +
                                "lockedUserID varchar(20) DEFAULT null, " +
                                "lockedUserName varchar(50) DEFAULT null, " +
                                "lockedHostId varchar(30) DEFAULT null, " +
                                "\"fsupdatetime\" character varying(20) DEFAULT (NULL) ,\n" +
                                "\"fsupdateuserid\" character varying(80) DEFAULT (NULL) ,\n" +
                                "\"fsupdateusername\" character varying(80) DEFAULT (NULL))");

                        //2017-02-22，添加登录站点的班别信息
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE host_status ADD COLUMN shiftid varchar(10) DEFAULT -1;");
                        //2017-02-22，添加登录站点的餐段信息
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE host_status ADD COLUMN sectionid varchar(10) DEFAULT -1;");
                        //满减券表
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbpaymentfullcut(\n" +
                                "                fsPaymentId varchar(10) primary key not null,\n" +
                                "                fdFullmoney decimal(18,2) default null,\n" +
                                "                fdCutmoney decimal(18,2) default null,\n" +
                                "                fsShopGUID varchar(80) not null,\n" +
                                "                fsUpdateTime varchar(20) default null,\n" +
                                "                fsUpdateUserId varchar(20) default null,\n" +
                                "                fsUpdateUserName varchar(30) default null\n" +
                                "        )");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fiIsPartAmtDiscount int DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fsShortcutKey varchar(50) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fsHelpCode varchar(50) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fiIsEffectiveDate int DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fsStarDate varchar(80) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD COLUMN fsEndDate varchar(80) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE push_msg_stack ADD COLUMN msgResult TEXT DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE push_msg_stack ADD COLUMN msgBizValue TEXT DEFAULT null;");

                        DBTools.exeSqlWithoutException(db, "drop table order_member_score");
                        /**
                         * lxx 2017-03-03 锁桌业务迁移到桌台业务表
                         */
                        DBTools.exeSqlWithoutException(db, "drop table table_lock");
                    }
                    if (oldVersion < 21) {
                        //17-03-08 添加菜品与配料分组关系表
                        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbmenuingredgprel(\n" +
                                "  'fsMenuClsId' varchar(30) NOT NULL,\n" +
                                "  'fiItemCd' int(11) NOT NULL,\n" +
                                "  'fiStatus' int(11) NOT NULL,\n" +
                                "  'fsShopGUID' varchar(80) NOT NULL,\n" +
                                "  'fsUpdateTime' varchar(20) DEFAULT NULL,\n" +
                                "  'fsUpdateUserId' varchar(20) DEFAULT NULL,\n" +
                                "  'fsUpdateUserName' varchar(30) DEFAULT NULL,\n" +
                                "  PRIMARY KEY ('fsMenuClsId','fiItemCd','fsShopGUID')\n" +
                                ")");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fsiccardcode varchar(30) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE host_status ADD COLUMN user_session varchar(20) DEFAULT null;");

                        //17-3-15 营业设置生效时间
                        // 菜品有效时间
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiIsEffectiveDate int DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fsStarDate varchar(80) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fsEndDate varchar(80) DEFAULT null;");
                        //支付方式有效时间 数据库version 版本号为20已经添加

                        //折扣有效时间
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fiIsEffectiveDate int DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fsStarDate varchar(80) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fsEndDate varchar(80) DEFAULT null;");
                        DBTools.exeSqlWithoutException(db, "alter table tbuser add column fiisgift INTEGER DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "alter table tbuser add column fiIsDiscount INTEGER DEFAULT 0;");
                        DBTools.exeSqlWithoutException(db, "alter table tbsellreceive add column fsPaymentTypeId varchar(4) DEFAULT '';");
                        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTask ADD COLUMN fiPrintCount int DEFAULT 0;");
                        updateV21(db);
                    }
                    if (oldVersion < 22) {
                        updateV22(db);
                    }

                    if (oldVersion < 23) {
                        updateV23(db);
                    }

                    if (oldVersion < 24) {
                        //version 1.8.0.1 打赏
                        updateV24(db);
                    }

                    if (oldVersion < 25) {
                        //version 1.8.1 订单来源
                        updateV25(db);
                    }
                    if (oldVersion < 26) {
                        updateV26(db);
                    }
                    if (oldVersion < 27) {
                        //1.8.3
                        updateV27(db);
                    }
                    if (oldVersion < 28) {
                        //2.0
                        updateV28(db);
                    }
                    if (oldVersion < 29) {
                        //2.0.1
                        updateV29(db);
                    }
                    if (oldVersion < 30) {
                        //2.0.3
                        updateV30(db, true);
                    }

                    if (oldVersion < 31) {
                        //2.1
                        updateV31(true, db);
                    }
                    if (oldVersion < 32) {
                        //2.2
                        updateV32(true, db);
                    }
                    if (oldVersion < 33) {
                        //2.2.1
                        updateV33(true, db);
                    }
                    if (oldVersion < 34) {
                        // pro2.2.2
                        updateV34(true, db);
                    }
                    if (oldVersion < 35) {
                        // pro2.2.3
                        updateV35(true, db);
                    }
                    if (oldVersion < 36) {
                        // air2.0
                        updateV36(true, db);
                    }
                    if (oldVersion < 37) {
                        // pro2.4
                        updateV37(true, db);
                    }
                    if (oldVersion < 38) {
                        //air 2.1
                        updateV38(true, db);
                    }

                    if (oldVersion < 39) {
                        updateV39(true, db);
                    }

                    if (oldVersion < 40) {
                        //2.4.3
                        updateV40(true, db);
                    }

                    if (oldVersion < 41) {
                        // pro2.5
                        updateV41(true, db);
                    }

                    if (oldVersion < 42) {
                        // pro2.5.2
                        updateV42(true, db);
                    }

                    if (oldVersion < 43) {
                        // air2.2
                        updateV43(true, db);
                    }

                    if (oldVersion < 44) {
                        // pro2.6
                        updateV44(true, db);
                    }

                    if (oldVersion < 45) {
                        // pro2.7
                        updateV45(true, db);
                    }

                    if (oldVersion < 46) {
                        // pro2.7.1
                        updateV46(true, db);
                    }
                    if (oldVersion < 47) {
                        // pro2.7.6
                        updateV47(true, db);
                    }

                    if (oldVersion < 48) {
                        // pro2.7.6  补充版本
                        updateV48(true, db);
                    }

                    if (oldVersion < 49) {
                        // pro2.7.7
                        updateV49(true, db);
                    }
                    if (oldVersion < 50) {
                        // pro2.8
                        updateV50(true, db);
                    }

                    if (oldVersion < 51) {
                        // air2.5.1
                        updateV51(true, db);
                    }

                    if (oldVersion < 53) {
                        //TODO 注：meger的时候版本号要按顺序走哦
                        // pro2.7.6  补充版本（为打印机准备）---2018-06-30
                        updateV53(true, db);
                    }

                    if (oldVersion < 54) {
                        //美收银1.4.1
                        updateV54(true, db);
                    }

                    if (oldVersion < 55) {
                        //美易点2.8.1---补充版本2018-07-09
                        updateV55(true, db);
                    }

                    if (oldVersion < 56) {
                        // 美易点 2.8.5
                        updateV56(true, db);
                    }

                    if (oldVersion < 57) {
                        LogUtil.logBusiness("业务中心数据库升级", "57");
                        // 美易点 2.8.5.326
                        updateV57(true, db);
                    }

                    if (oldVersion < 60) {
                        LogUtil.logBusiness("业务中心数据库升级", "60");
                        //美易点2.9  --- 数据库预留4个版本
                        updateV60(true, db);
                    }


                    if (oldVersion < 61) {
                        LogUtil.logBusiness("业务中心数据库升级", "61");
                        //美易点2.9.1  --- 补全插入的2.8.5版本的数据库升级
                        updateV61(true, db);
                    }

                    if (oldVersion < 62) {
                        LogUtil.logBusiness("业务中心数据库升级", "62");
                        //美易点2.9.1.361
                        updateV62(true, db);
                    }

                    if (oldVersion < 70) {
                        LogUtil.logBusiness("业务中心数据库升级", "70");
                        // 美易点3.0
                        updateV70(true, db);
                    }

                    if (oldVersion < 80) {
                        LogUtil.logBusiness("业务中心数据库升级", "80");
                        // 美易点3.0.1
                        updateV80(true, db);
                    }

                    if (oldVersion < 81) {
                        LogUtil.logBusiness("业务中心数据库升级", "81");
                        // 美易点3.0.2 美团虚拟打印机
                        updateV81(db);
                    }

                    if (oldVersion < 85) {
                        LogUtil.logBusiness("业务中心数据库升级", "85");
                        // 美易点3.0.3  口碑三期
                        updateV85(true, db);
                    }


                    if (oldVersion < 95) {
                        LogUtil.logBusiness("业务中心数据库升级", "95");
                        // 美易点3.1
                        updateV95(true, db);
                    }

                    if (oldVersion < 96) {
                        LogUtil.logBusiness("业务中心数据库升级", "96");
                        // 美易点3.1.1
                        updateV96(true, db);
                    }

                    if (oldVersion < 100) {
                        // 美易点3.2(KDS版本)
                        LogUtil.logBusiness("业务中心数据库升级", "100");
                        updateV100(true, db);
                    }

                    if (oldVersion < 105) {
                        LogUtil.logBusiness("业务中心数据库升级", "105");
                        // 美易点3.3
                        updateV105(true, db);
                    }

                    if (oldVersion < 110) {
                        LogUtil.logBusiness("业务中心数据库升级", "110");
                        updateV100(true, db);
                        updateV105(true, db);
                        // 美易点3.3.2 会员重构
                        updateV110(true, db);
                    }

                    if (oldVersion < 115) {
                        LogUtil.logBusiness("业务中心数据库升级", "115");
                        // 美易点3.4 KDS 二期
                        updateV115(true, db);
                    }

                    if (oldVersion < 116) {
                        LogUtil.logBusiness("业务中心数据库升级", "116");
                        updateV100(true, db);
                        updateV105(true, db);
                        updateV110(true, db);
                        updateV115(true, db);
                    }

                    if (oldVersion < 120) {
                        LogUtil.logBusiness("业务中心数据库升级", "120");
                        // 美易点3.4.1
                        updateV120(true, db);
                    }

                    if (oldVersion < 125) {
                        LogUtil.logBusiness("业务中心数据库升级", "125");
                        // 美易点3.4.2
                        updateV125(true, db);
                    }

                    if (oldVersion < 130) {
                        LogUtil.logBusiness("业务中心数据库升级", "130");
                        // 美易点3.5
                        updateV130(true, db);
                    }

                    if (oldVersion < 131) {
                        LogUtil.logBusiness("业务中心数据库升级", "131");
                        updateV131(true, db);
                    }

                    if (oldVersion < 132) {
                        LogUtil.logBusiness("业务中心数据库升级", "131");
                        updateV132(true, db);
                    }

                    if (oldVersion < 135) {
                        LogUtil.logBusiness("业务中心数据库升级", "135");
                        // 美易点3.5.2
                        updateV135(true, db);
                    }

                    if (oldVersion < 136) {
                        LogUtil.logBusiness("业务中心数据库升级", "136");
                        // 美易点3.5.2.546
                        updateV136(true, db);
                    }

                    if (oldVersion < 137) {
                        LogUtil.logBusiness("业务中心数据库升级", "137");
                        // 美易点3.5.3
                        updateV137(true, db);
                    }

                    if (oldVersion < 138) {
                        LogUtil.logBusiness("业务中心数据库升级", "138");
                        // 美易点3.5.3.551
                        updateV131(true, db);
                        updateV132(true, db);
                        updateV135(true, db);
                        updateV136(true, db);
                        updateV137(true, db);
                    }

                    if (oldVersion < 141) {
                        LogUtil.logBusiness("业务中心数据库升级", "141");
                        // 美易点3.5.4.555
                        updateV141(true, db);
                    }

                    if (oldVersion < 143) {
                        LogUtil.logBusiness("业务中心数据库升级", "143");
                        // 美易点3.5.6 --- AB帐版本
                        updateV143(true, db);
                    }

                    checkExtra(true, db);
                } catch (SQLException e) {
                    RunTimeLog.addLog(RunTimeLog.DB, "数据库更新错误1:" + e.getMessage());
                    LogUtil.logError(e);
                } catch (Exception e) {
                    RunTimeLog.addLog(RunTimeLog.DB, "数据库更新错误2:" + e.getMessage());
                    LogUtil.logError(e);
                }
            }
        });
        NetOrderDBInit.initDB(context);
    }

    /**
     * 美易点3.5.6
     */
    private static void updateV143(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //出售方案
            DBTools.exeSqlWithoutException(db, "CREATE TABLE `tbshopsellplan` (\n" +
                    "  `fsGuid` char(36) ,\n" +
                    "  `fsPlanName` varchar(20) ,\n" +
                    "  `fbTimeLimit` tinyint(1) DEFAULT '0' ,\n" +
                    "  `fsBeginTime` datetime ,\n" +
                    "  `fsEndTime` datetime ,\n" +
                    "  `fsSellDay` varchar(20) ,\n" +
                    "  `fsMSectionIds` varchar(1000) ,\n" +
                    "  `fsMAreaIds` varchar(1000) ,\n" +
                    "  `fiStauts` int(11)  DEFAULT '1' ,\n" +
                    "  `fsShopGUID` varchar(80) ,\n" +
                    "  `fsUpdateTime` varchar(30),\n" +
                    "  `fsUpdateUserId` varchar(30),\n" +
                    "  `fsUpdateUserName` varchar(30),\n" +
                    "  `fsCreateTime` varchar(30),\n" +
                    "  `fsCreateUserId` varchar(30),\n" +
                    "  `fsCreateUserName` varchar(30),\n" +
                    "  `fsCustomStartTime` varchar(30),\n" +
                    "  `fsCustomEndTime` varchar(30),\n" +
                    "  `fsServiceIds` varchar(30) DEFAULT '1',\n" +
                    "  PRIMARY KEY (`fsGuid`)\n" +
                    ")");

            //出售方案对应菜品明细
            DBTools.exeSqlWithoutException(db, "CREATE TABLE `tbsellmenumap` (\n" +
                    "  `fsGuid` char(36) ,\n" +
                    "  `fsSellPlanGuid` char(36) ,\n" +
                    "  `fiItemCodeCd` int(11) ,\n" +
                    "  `fiOrderUintCd` int(11) ,\n" +
                    "  `fiStatus` int(11)  DEFAULT '1' ,\n" +
                    "  `fsShopGUID` varchar(80) ,\n" +
                    "  `fsUpdateTime` varchar(80)  ,\n" +
                    "  `fsUpdateUserId` varchar(80) ,\n" +
                    "  `fsUpdateUserName` varchar(30) ,\n" +
                    "  PRIMARY KEY (`fsGuid`)\n" +
                    ")");

            //出售方案对应菜品明细
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdRealOriginalAmt decimal(18, 2) default 0 ");

            // 账套表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE `bill_account_book` (\n" +
                    "    `id` int(10) DEFAULT '',\n" +
                    "    `shop_guid` varchar(80) DEFAULT '',\n" +
                    "    `company_guid` varchar(80) DEFAULT '',\n" +
                    "    `account_book_id` varchar(50) DEFAULT '',\n" +
                    "    `account_book_name` varchar(50) DEFAULT '',\n" +
                    "    `note` varchar(255) DEFAULT '',\n" +
                    "    `upload_type` int(2) DEFAULT '1',\n" +
                    "    `upload_time` varchar(50) DEFAULT '',\n" +
                    "    `data_percent` int(11) DEFAULT '0' ,\n" +
                    "    `upload_repeat` int(2) DEFAULT '0' ,\n" +
                    "    `business_type` int(11) DEFAULT '0' ,\n" +
                    "    `interface_mid` varchar(36) DEFAULT '',\n" +
                    "    `status` int(2) DEFAULT '1' ,\n" +
                    "    `exclude_payment` varchar(1000) DEFAULT '' ,\n" +
                    "    `auto_filter` int(2) DEFAULT '0' ,\n" +
                    "    `create_time` varchar(50) DEFAULT '',\n" +
                    "    `user_id` varchar(20) DEFAULT '',\n" +
                    "    `user_name` varchar(20) DEFAULT '',\n" +
                    "    `update_time` varchar(50) DEFAULT '',\n" +
                    "    PRIMARY KEY (`shop_guid`,`account_book_id`) \n" +
                    ")");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN fsAccountBook varchar(500) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN fsAccountBook varchar(500) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fsBillClass2 varchar(100) DEFAULT '' ");
        }

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbshopsellplan,tbsellmenumap,tbuser,bill_account_book");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.5.4.555
     *
     * @param serverDB
     * @param db
     */
    private static void updateV141(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD fdRealAmt decimal(18, 2) default 0");
        }
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.5.3
     */
    private static void updateV137(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //菜品条码
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsBarCode varchar(50) DEFAULT ''");
        }
    }

    private static void updateV132(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbKdsMenuItemState ADD COLUMN fsMenuClsId varchar(10) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbKdsMenuItemState ADD COLUMN fsRestNum varchar(10) DEFAULT ''");
        }
        haveToDowanloadData(serverDB, db);
    }

    private static void updateV131(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, " ALTER TABLE tbKdsMenuItemState ADD COLUMN fiSellType  INT(6) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbKdsMenuItemState ADD COLUMN fsServedUniq  VARCHAR(80) DEFAULT '' ");
        }
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.5.2.546
     */
    private static void updateV136(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //支付方式助记码
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPayment ADD COLUMN fsPayHelpCode varchar(20) DEFAULT ''");
        }
        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbpayment");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.5.2
     */
    private static void updateV135(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //整单备注（每个单序的整单备注--普通）
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsWholeNote varchar(80) DEFAULT ''");

            //整单备注（每个单序的整单备注--显著）
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN batchSpecialNote varchar(80) DEFAULT ''");
        }
        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbpayment");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.5
     */
    private static void updateV130(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //手动开发票表
            DBTools.exeSqlWithoutException(db, "create table manualInvoicing\n" +
                    "(orderId varchar(80) not null ,\n" +
                    "fsShopGUID varchar(80) ,\n" +
                    "code varchar(80) ,\n" +
                    "status int default 0,\n" +
                    "amt decimal(18, 2) default 0  ,\n" +
                    "printTimes int default 0,\n" +
                    "date varchar(30) default '',\n" +
                    "createTime varchar(30) default '',\n" +
                    "updateTime varchar(30) default '',\n" +
                    "updateUserId varchar(20) ,\n" +
                    "updateUserName varchar(30) ,\n" +
                    "primary key (orderId)\n" +
                    ")");
            //订单附加费表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS billSurchargeDetail (\n" +
                    "  'sellNo' varchar(20) ,\n" +
                    "  'sellDate' varchar(20),\n" +
                    "  'surchargeId' Integer DEFAULT 0,\n" +
                    "  'surchargeName' varchar(128) ,\n" +
                    "  'surchargeAmt' numeric(18,2),\n" +
                    "  'companyGuid' varchar(50),\n" +
                    "  'shopGuid' varchar(50),\n" +
                    "  'createTime' varchar(50) ,\n" +
                    "  'userId' varchar(50),\n" +
                    "  'userName' varchar(50),\n" +
                    "  certigierUserId varchar(50),\n" +
                    "  certigierUserName varchar(50),\n" +
                    "  lver Integer DEFAULT 0,\n" +
                    "  pver Integer DEFAULT 0,\n" +
                    "  PRIMARY KEY ('shopGuid','sellNo','surchargeId')\n" +
                    ")");

            //订单 和 菜品优惠明细
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS billItemCouponDetail(\n" +
                    "  \"guid\" varchar(80) ,\n" +
                    "  \"sellNo\" varchar(20) ,\n" +
                    "  \"itemSeq\" varchar(128),\n" +
                    "  \"couponMode\" Integer DEFAULT 0,\n" +
                    "  \"couponType\" Integer DEFAULT 0,\n" +
                    "  \"couponId\" varchar(128),\n" +
                    "  \"couponName\" varchar(128) ,\n" +
                    "  \"couponAmt\" numeric(18,2) ,\n" +
                    "  \"couponRate\" numeric(18,2) ,\n" +
                    "  \"couponNum\" numeric(18,2),\n" +
                    "  \"couponClassId\" Integer DEFAULT 0,\n" +
                    "  \"couponClassName\" varchar(128) ,\n" +
                    "  \"createTime\" varchar(50),\n" +
                    "  \"sellDate\" varchar(20),\n" +
                    "  \"companyGuid\" varchar(20),\n" +
                    "  \"shopGuid\" varchar(20),\n" +
                    "  \"userId\" varchar(50) ,\n" +
                    "  \"userName\" varchar(50) ,\n" +
                    "  \"certigierUserId\" varchar(30) ,\n" +
                    "  \"cretigierUserName\" varchar(30),\n" +
                    "  lver Integer DEFAULT 0,\n" +
                    "  pver Integer DEFAULT 0,\n" +
                    "  PRIMARY KEY ('guid')\n" +
                    ");");
            // 结账授权人信息
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD fsCertigierUserId vachar(80) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD fsCertigierUserName vachar(80) DEFAULT '' ");
            // tbSellCheck fsDeviceId varchar(32)  存在哪个设备结账
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellCheck ADD fsDeviceId vachar(32) DEFAULT '' ");
        }

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbmenuitemcpprice");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.4.2
     */
    private static void updateV125(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //黑卡特权价格
            DBTools.exeSqlWithoutException(db, "create table tbmenuitemcpprice\n" +
                    "(fsGuid char(36)  not null ,\n" +
                    " fsShopGUID varchar(80) ,\n" +
                    " fiItemCd int not null ,\n" +
                    " fiOrderUintCd int ,\n" +
                    " fiCpId int  ,\n" +
                    " fdCpPrice decimal(18, 2) default 0 ,\n" +
                    " fiStatus int default 1 ,\n" +
                    " fibindType int(6) default 0  ,\n" +
                    " ficsId int(6)  ,\n" +
                    " fsUpdateTime varchar(30) default '',\n" +
                    " fsUpdateUserId varchar(20) ,\n" +
                    " fsUpdateUserName varchar(30) ,\n" +
                    " primary key (fsGuid)\n" +
                    " )");

            // 报表重新创建，增加主键
            DBTools.exeSqlWithoutException(db, "ALTER TABLE dailyReport RENAME TO dailyReportTemp");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE dailyReportTemp ADD fiReportIndex INTEGER  NOT NULL default 1 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE dailyReportTemp ADD fiReportTotal INTEGER  NOT NULL default 1 ");
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS 'dailyReport' " +
                    "('businessdate' VARCHAR NOT NULL ," +
                    " 'type' VARCHAR NOT NULL ," +
                    " 'value' TEXT NOT NULL ," +
                    " 'param1' TEXT NOT NULL ," +
                    " 'param2' TEXT NOT NULL ," +
                    " 'updateTime' VARCHAR NOT NULL ," +
                    " 'shopGUID' VARCHAR NOT NULL ," +
                    " 'id' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ," +
                    " 'fiReportIndex' INTEGER  NOT NULL default 1," + // 销售数量表分批次存储，该字段为存储批次
                    " 'fiReportTotal' INTEGER  NOT NULL default 1," + // 销售数量表总批次数
                    "  UNIQUE (businessdate,type,param1,shopGUID,fiReportIndex)" +
                    " )");

            try {
                // 为防止数据丢失，老表不删除
                DBTools.exeSqlWithoutException(db, "INSERT INTO dailyReport SELECT * FROM dailyReportTemp");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbmenuitemcpprice");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.4.1
     */
    private static void updateV120(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //'打印来源, 0:打印部门 , 1:下单餐区'
            DBTools.exeSqlWithoutException(db, "alter table tbdept add fiTransferSource INT(6) DEFAULT '0'");

            //传菜点关联餐桌区域
            DBTools.exeSqlWithoutException(db, "create table tbtransferarea\n" +
                    "     (\n" +
                    "     fsDeptId_Transfer varchar(20) default '' not null,\n" +
                    "     fsMAreaId_Make varchar(20) default '' ,\n" +
                    "     fsShopGUID varchar(80) default '' ,\n" +
                    "     fsUpdateTime varchar(20) ,\n" +
                    "     fsUpdateUserId varchar(20),\n" +
                    "     fsUpdateUserName varchar(30) ,\n" +
                    "     fiStatus int ,\n" +
                    "     primary key (fsDeptId_Transfer, fsMAreaId_Make, fsShopGUID)\n" +
                    "     );");
        }

        //卡实收
        DBTools.exeSqlWithoutException(db, "alter table tbpayment add fdCardRealAmt decimal(18,2) DEFAULT '0';");

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbPaymentType,tbpayment,tbdept,tbtransferarea,tbdiscount");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * KDS二期
     *
     * @param serverDB
     * @param db
     */
    private static void updateV115(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdept ADD COLUMN fiMakeNumber INT(10) DEFAULT 20");
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbKdsBarcode\n" +
                    "(\n" +
                    "  barcode          VARCHAR(30),\n" +
                    "  dishId           CHAR(36),\n" +
                    "  deptId           VARCHAR(20),\n" +
                    "  state            INT(6),\n" +
                    "  PRIMARY KEY (dishId, deptId, barcode)\n" +
                    ");");
        }
        setModifiedTables(serverDB, db, "tbdept");
        haveToDowanloadData(serverDB, db);
    }

    private static void updateV100(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiIsChef  INT(10) DEFAULT 0 ");

            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbHostPrintDepart\n" +
                    "(\n" +
                    "  fsGuid           CHAR(36) PRIMARY KEY NOT NULL,\n" +
                    "  fsHostId         VARCHAR(30),\n" +
                    "  fsDeptId         VARCHAR(20),\n" +
                    "  fsShopGUID       VARCHAR(80),\n" +
                    "  fiStatus         INT(6) DEFAULT 1,\n" +
                    "  fsUpdateTime     VARCHAR(20),\n" +
                    "  fsUpdateUserId   VARCHAR(20),\n" +
                    "  fsUpdateUserName VARCHAR(30),\n" +
                    "  UNIQUE (fsHostId, fsDeptId, fsShopGUID)\n" +
                    ");");
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbUserPrintDepart (\n" +
                    "  fsGuid           CHAR(36) PRIMARY KEY NOT NULL,\n" +
                    "  fsUserId         VARCHAR(20) DEFAULT '',\n" +
                    "  fsDeptId         VARCHAR(20) DEFAULT '',\n" +
                    "  fsShopGUID       VARCHAR(80) DEFAULT '',\n" +
                    "  fiStatus         INT(6)      DEFAULT 1,\n" +
                    "  fsUpdateTime     VARCHAR(20) DEFAULT '',\n" +
                    "  fsUpdateUserId   VARCHAR(20) DEFAULT '',\n" +
                    "  fsUpdateUserName VARCHAR(30) DEFAULT '',\n" +
                    "  UNIQUE (fsUserId, fsDeptId, fsShopGUID)\n" +
                    ");");
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbKdsMenuItemState (\n" +
                    "  fsSeq            VARCHAR(80) DEFAULT '',\n" +
                    "  fiItemCd         INT(11)     DEFAULT 0,\n" +
                    "  name             VARCHAR(80) DEFAULT '',\n" +
                    "  fsOriginSeq      VARCHAR(80) DEFAULT '',\n" +
                    "  fsOriginSeq_M    VARCHAR(80) DEFAULT '',\n" +
                    "  fiItemKind       INT(6)      DEFAULT 0,\n" +
                    "  fsDeptId         VARCHAR(80) DEFAULT '',\n" +
                    "  fsPotSeq         VARCHAR(80) DEFAULT '',\n" +
                    "  fsBarCode        VARCHAR(80) DEFAULT '',\n" +
                    "  fsServedUniq     VARCHAR(80) DEFAULT '',\n" +
                    "  fiState          INT(6)      DEFAULT 1,\n" +
                    "  fiHurryCount     INT(6)      DEFAULT 0,\n" +
                    "  fsHurryTime      VARCHAR(20) DEFAULT '',\n" +
                    "  fsHurryUserId    VARCHAR(20) DEFAULT '',\n" +
                    "  fsHurryUserName  VARCHAR(30) DEFAULT '',\n" +
                    "  fsSellNo         VARCHAR(20) DEFAULT '',\n" +
                    "  fiMakePrintNo    VARCHAR(80) DEFAULT '',\n" +
                    "  fiPassPrintNo    VARCHAR(80) DEFAULT '',\n" +
                    "  fsShopGUID       VARCHAR(80) DEFAULT '',\n" +
                    "  fsUpdateHostId   VARCHAR(80) DEFAULT '',\n" +
                    "  fsUpdateTime     VARCHAR(20) DEFAULT '',\n" +
                    "  fsUpdateUserId   VARCHAR(20) DEFAULT '',\n" +
                    "  fsUpdateUserName VARCHAR(30) DEFAULT '',\n" +
                    "  PRIMARY KEY (fsSeq, fsDeptId)\n" +
                    ");");
        }

        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiIsEnableKDS  INT(6) DEFAULT 1 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiLatestUpMenuTime  INT(10) DEFAULT 25 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiIsDishesTakeaway  INT(6) DEFAULT 1 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiIsOpenBarcode  INT(6) DEFAULT 1 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiOrderSource  INT(10) DEFAULT 0 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiOrderDispNumber  INT(10) DEFAULT 0 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiYellowBackground  INT(10) DEFAULT 5 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbhost ADD COLUMN fiOrangeBackground  INT(10) DEFAULT 10 ");

        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiMaxTogetherMenu  INT(10) DEFAULT 1 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiRetireMenuTime  INT(10) DEFAULT 5 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiUpMenuOrder  INT(10) DEFAULT 1 ");

        setModifiedTables(serverDB, db, "tbuser,tbparamvalue,tbhost,tbHostPrintDepart,tbUserPrintDepart,tbmenuitem");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.3
     */
    private static void updateV110(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //卡类型 0：品牌卡 1：区域卡
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitemvipprice ADD COLUMN fibindType INT(6) DEFAULT '0'");
            //模板ID
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitemvipprice ADD COLUMN ficsId INT(6) DEFAULT '0'");

            //多卡多等级折扣关联关系表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE `tbdiscountvip` (\n" +
                    "  `fsDiscountId` varchar(10) NOT NULL,\n" +
                    "  `fsShopGUID` varchar(80) NOT NULL,\n" +
                    "  `fivipCardType` int(6) NOT NULL DEFAULT '0',\n" +
                    "  `fivipCardCsId` int(6) NOT NULL DEFAULT '0',\n" +
                    //会员等级 为-1:表示会员折扣不限制会员等级
                    "  `fiviplevelId` int(6) DEFAULT '-1' ,\n" +
                    "  `fsviplevelDesc` varchar(20) DEFAULT NULL ,\n" +
                    "  `fiStatus` int(11) NOT NULL DEFAULT '1' ,\n" +
                    "  `fiDataSource` tinyint(4) DEFAULT '0',\n" +
                    "  `fsUpdateTime` varchar(20) NOT NULL,\n" +
                    "  `fsUpdateUserId` varchar(20) DEFAULT NULL,\n" +
                    "  `fsUpdateUserName` varchar(30) DEFAULT NULL,\n" +
                    "  PRIMARY KEY (`fsDiscountId`,`fsShopGUID`,`fivipCardCsId`)\n" +
                    ")");
        }
        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbmenuitemvipprice,tbdiscountvip");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.1.1
     */
    private static void updateV96(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //小票模版表加上选中时间
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrintTempletPrivate ADD COLUMN fsSelectedTime VARCHAR(20) DEFAULT '' ");
        }
        //3.0版本tbdiscount加了字段，但没有强制下拉数据，在这个版本补上
        setModifiedTables(serverDB, db, "tbdiscount");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.3
     */
    private static void updateV105(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //折扣类型
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN ficouponid INT(6) DEFAULT '-1' ");
            //点菜终端名称
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN terminal_name vachar(50) DEFAULT '' ");
            //点菜终端ID
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN terminal_id vachar(80) DEFAULT '' ");
            //转桌记录
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS  `table_change_detail` (  \n" +
                    "id INT(8) DEFAULT '' ,\n" +    // 后台主键，端上不管
                    "seq  VARCHAR(50) DEFAULT '' ,\n" + // 唯一码，端上用的
                    "company_guid VARCHAR(80) DEFAULT '' ,\n" +  // 总店号
                    "shop_guid VARCHAR(80) DEFAULT '' , \n" +  // 门店号
                    "sell_date VARCHAR(80) DEFAULT '', \n" +    // 营业日期
                    "create_kind INT(4) DEFAULT '', \n" +  // 操作类型(1:整桌转台 2:部分转菜 3:整桌并台）
                    "sell_no VARCHAR(20) DEFAULT '' , \n" + // 账单单号
                    "table_id VARCHAR(20) DEFAULT '', \n" +  // 餐桌id
                    "table_name VARCHAR(50) DEFAULT '', \n" +  // 餐桌名
                    "area_id VARCHAR(20) DEFAULT '', \n" +  // 餐桌区域id
                    "area_name VARCHAR(50) DEFAULT '', \n" +  // 餐桌区域名称
                    "origin_sell_no VARCHAR(20) DEFAULT '', \n" +    // 原始账单单号
                    "origin_table_id VARCHAR(20) DEFAULT '', \n" +  // 原始桌台ID
                    "origin_table_name VARCHAR(50) DEFAULT '', \n" +  // 原始桌台名称
                    "origin_area_id VARCHAR(20) DEFAULT '', \n" +  // 原始餐桌区域id
                    "origin_area_name VARCHAR(50) DEFAULT '', \n" +  // 原始餐桌区域名称
                    "create_user_id VARCHAR(20) DEFAULT '', \n" +    // 操作人id
                    "create_user_name VARCHAR(50) DEFAULT '', \n" +    // 操作人名称
                    "create_time timestamp DEFAULT '', \n" +    // 操作时间
                    "lver INT(6)  DEFAULT '0' ,\n" +
                    "pver INT(6)  DEFAULT '0' ,\n" +
                    "PRIMARY KEY  (`seq`,`sell_no`,`shop_guid`,`company_guid`)    \n" +
                    ")");
            //转菜明细表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS  `bill_change_detail` (  \n" +
                    "id INT(8) DEFAULT '' ,\n" +    // 后台主键，端上不管
                    "change_id INT(8) DEFAULT '' ,   \n" +  // 转桌id，对应table_change_detail中的id，后台用，端上不管
                    "seq VARCHAR(50) DEFAULT '' ,   \n" +   // 唯一码，端上用的，对应table_change_detail中的seq
                    "sell_date VARCHAR(80) DEFAULT '' , \n" + // 营业日期
                    "sell_no VARCHAR(20) DEFAULT '' , \n" + // 账单单号
                    "item_cd INT(8) DEFAULT '' ,  \n" +     // 菜品itemCd
                    "item_id  VARCHAR(30) DEFAULT '' ,\n" + // 菜品id
                    "item_name VARCHAR(250)  DEFAULT '' ,\n" +  // 菜品名称
                    "order_unit_id VARCHAR(20) DEFAULT '' , \n" +  // 菜品规格id
                    "order_unit_name VARCHAR(50) DEFAULT '', \n" +    // 菜品规格名称
                    "order_item_kind INT(2) DEFAULT 0 , \n" + // 点菜方式(1:单品 2：套餐头 3：套餐明细 4：配料菜)
                    "change_qty DECIMAL(18,2) DEFAULT '0.00', \n" +  // 转菜数量
                    "change_amt DECIMAL(18,2) DEFAULT '0.00', \n" +  // 转菜金额
                    "lver INT(6)  DEFAULT '0' ,\n" +
                    "pver INT(6)  DEFAULT '0' ,\n" +
                    "PRIMARY KEY  (`id`)    \n" +
                    ")");
        }

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbPayment");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.1
     */
    private static void updateV95(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS  `areaBiz` (  \n" +
                    "fsMAreaId VARCHAR(20) DEFAULT '' ,\n" +    // 桌台区域Id
                    "fsMAreaName  VARCHAR(80) DEFAULT '' ,\n" + // 桌台区域名称
                    "fsShopGUID VARCHAR(80)  DEFAULT '' ,\n" +  // 门店GUID
                    "fiStatus INT(6) DEFAULT 1 , \n" +  // 状态，1-正常，9-禁用，13-删除
                    "fiMinStandardStatus INT(6) DEFAULT 0, \n" +    // 是否启用最低消费标准，1-启用，0-未启用
                    "fdMinStandardAmt DECIMAL(18,2) DEFAULT '-1.00' , \n" + // 最低消费标准金额，默认-1，表示未启用最低消费标准
                    "fiPlaySound INT(6) DEFAULT 1, \n" +    // 是否开启消息提示音，1-开启，0-关闭
                    "fsStr1 VARCHAR(80)  DEFAULT '', \n" +  // 预留字段1
                    "fsStr2 VARCHAR(80)  DEFAULT '', \n" +  // 预留字段2
                    "fsUpdateTime VARCHAR(20) DEFAULT '' ,  \n" +
                    "fsUpdateUserId VARCHAR(20) DEFAULT '' ,   \n" +
                    "fsUpdateUserName VARCHAR(30) DEFAULT '' ,   \n" +
                    "PRIMARY KEY  (`fsMAreaId`,`fsShopGUID`)    \n" +
                    ")");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiWithinDiningStandard INT(6) DEFAULT '0' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN  fdMinStandardAmt decimal(18,2) DEFAULT '-1.00' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN  fdDiningStandardAmt decimal(18,2) DEFAULT '-1.00' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE host_status ADD COLUMN  printConfig int(6) DEFAULT '0' ");
        }

        // 后台有预置数据，需更新
        setModifiedTables(serverDB, db, "tbMenuCls,tbMenuItem,tbMenuItemUint,tbPayment");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.0.3  口碑三期
     *
     * @param serverDB
     * @param db
     */
    private static void updateV85(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdCouponMoney decimal(11,2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorder ADD COLUMN fsThirdBatchNo varchar(32) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fsThirdItemCd varchar(32) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fsThirdOrderUintCd varchar(32) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fsThirdStatus varchar(32) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsThirdPaymentId varchar(80) DEFAULT '' ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fsExtInfo Text DEFAULT '' ");
            setModifiedTables(serverDB, db, "tbPayment");
            haveToDowanloadData(serverDB, db);
        }
    }

    /**
     * pro3.0.2
     * 美团虚拟打印机
     *
     * @param db
     */
    private static void updateV81(SQLiteDatabase db) {
        /*
         * 新增外卖菜品映射关系表----从虚拟打印机接单，无法到后台配置映射关系
         */
        com.mwee.myd.server.util.DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbNetorderItemMappingRelationship (\n" +
                "fsNetorderItemName VARCHAR(80) ,\n" +
                "fsNetorderUintName VARCHAR(80) ,\n" +
                "fdNetorderSaleAmt DECIMAL(18,2) DEFAULT '0.00' ,\n" +
                "fiItemCd INT(11) ,\n" +
                "fsOrderUint varchar(50) ,\n" +
                "fiStatus INT(6)  DEFAULT '1' ,\n" +
                "fsShopGUID VARCHAR(80) ,\n" +
                "fsUpdateTime  VARCHAR(20) DEFAULT NULL ,\n" +
                "fsUpdateUserId VARCHAR(20) DEFAULT NULL ,\n" +
                "fsUpdateUserName VARCHAR(20) DEFAULT NULL ,\n" +
                "lver INT(6)  DEFAULT '0' ,\n" +
                "pver INT(6)  DEFAULT '0' ,\n" +
                "sync INT(6)  DEFAULT '0' ,\n" +
                "PRIMARY KEY (`fsNetorderItemName`,`fsNetorderUintName`, 'fsShopGUID')\n" +
                ")");

    }

    /**
     * 美易点2.9.1.361版本
     * 美易点2.9.1补充版本
     *
     * @param serverDB
     * @param db
     */
    private static void updateV62(boolean serverDB, SQLiteDatabase db) {
        setModifiedTables(serverDB, db, "tbMenuItemUint,tbmenuitemvipprice");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.0.1  提成菜
     *
     * @param serverDB
     * @param db
     */
    private static void updateV80(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            // 是否允许登录pos(0:否;1:是)
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiIsPosLogin INT(6) DEFAULT 1 ");

            // 提成菜设置
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS  `tbBonusMenu` (\n" +
                    "    fsBonusMenuGuid  CHAR(36) ,\n" +
                    "    fsBonusMenuId VARCHAR(10) DEFAULT '' ,\n" +
                    "    fsBonusMenuName  VARCHAR(30) DEFAULT '' ,\n" +
                    "    fiBonusMenuType  INT(6) DEFAULT 0 , \n" +
                    "    fsShopGUID VARCHAR(80)  DEFAULT '' , \n" +
                    "    fiStatus INT(6) DEFAULT 1 , \n" +
                    "    fsUpdateTime VARCHAR(20) DEFAULT '' ,\n" +
                    "    fsUpdateUserId VARCHAR(20) DEFAULT '' ,\n" +
                    "    fsUpdateUserName VARCHAR(30) DEFAULT '' ,\n" +
                    "    PRIMARY KEY (`fsBonusMenuGuid`),\n" +
                    "    UNIQUE (`fsBonusMenuId`,`fsShopGUID`) \n" +
                    "    )");

            // 提成菜设置关联菜品
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbBonusManageMenu (\n" +
                    "    fsBonusMenuGuid CHAR(36) ,\n" +
                    "    fiItemCd INT(11) ,\n" +
                    "    fiOrderUintCd INT(11) DEFAULT '0' ,\n" +
                    "    fdPercentumPrice DECIMAL(18,2) DEFAULT '0.00' ,\n" +
                    "    fdBonusPrice DECIMAL(18,2) DEFAULT '0.00' ,\n" +
                    "    fiStatus INT(6) DEFAULT '1' ,\n" +
                    "    fsShopGUID VARCHAR(80) NOT NULL ,\n" +
                    "    fsUpdateTime  VARCHAR(20) DEFAULT NULL ,\n" +
                    "    fsUpdateUserId VARCHAR(20) DEFAULT NULL ,\n" +
                    "    fsUpdateUserName VARCHAR(20) DEFAULT NULL ,\n" +
                    "    PRIMARY KEY (`fiOrderUintCd`,`fiItemCd`,`fsShopGUID`,`fsBonusMenuGuid`)\n" +
                    ")");

            // 提成菜设置关联用户
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbBonusManageUser (\n" +
                    "    fsBonusMenuGuid CHAR(36) ,\n" +
                    "    fsUserId VARCHAR(20) ,\n" +
                    "    fiStatus INT(6)  DEFAULT '1' ,\n" +
                    "    fsShopGUID VARCHAR(80) ,\n" +
                    "    fsUpdateTime  VARCHAR(20) DEFAULT NULL ,\n" +
                    "    fsUpdateUserId VARCHAR(20) DEFAULT NULL ,\n" +
                    "    fsUpdateUserName VARCHAR(20) DEFAULT NULL ,\n" +
                    "    PRIMARY KEY (`fsUserId`,`fsShopGUID`,`fsBonusMenuGuid`)\n" +
                    ")");

            // 提成菜报表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbSellOrderItemBonus (\n" +
                    "fssellno VARCHAR(80) ,\n" +
                    "fsSeq varchar(80) ,\n" +
                    "fiItemCd INT(11) ,\n" +
                    "fsitemName VARCHAR(80) ,\n" +
                    "fiOrderUintCd INT(11) DEFAULT '0' ,\n" +
                    "fsOrderUint varchar(50) ,\n" +
                    "fdsaleAmt DECIMAL(18,2) DEFAULT '0.00' ,\n" +
                    "fdBonusQty DECIMAL(18,2) DEFAULT '0.00' ,\n" +
                    "fsBonusMenuGuid CHAR(36),\n" +
                    "fsBonusMenuName  VARCHAR(30) DEFAULT '',\n" +
                    "fiBonusMenuType  INT(6) DEFAULT 0, \n" +
                    "fdBonusAmt DECIMAL(18,2) DEFAULT '0.00',\n " +
                    "fsBonusUserId VARCHAR(30) DEFAULT '',\n" +
                    "fsBonusUserName  VARCHAR(30) DEFAULT '',\n" +
                    "fsBonusCertigierUserId  VARCHAR(30) DEFAULT '',\n" +
                    "fsBonusCertigierUserName  VARCHAR(30) DEFAULT '',\n" +
                    "fsselldate VARCHAR(80) ,\n" +
                    "fiStatus INT(6)  DEFAULT '1' ,\n" +
                    "fsShopGUID VARCHAR(80) ,\n" +
                    "fsUpdateTime  VARCHAR(20) DEFAULT NULL ,\n" +
                    "fsUpdateUserId VARCHAR(20) DEFAULT NULL ,\n" +
                    "fsUpdateUserName VARCHAR(20) DEFAULT NULL ,\n" +
                    "lver INT(6)  DEFAULT '0' ,\n" +
                    "pver INT(6)  DEFAULT '0' ,\n" +
                    "PRIMARY KEY (`fsShopGUID`,`fsSeq`)\n" +
                    ")");


        }

        setModifiedTables(serverDB, db, "tbuser,tbBonusMenu,tbBonusManageMenu,tbBonusManageUser");
        haveToDowanloadData(serverDB, db);
    }


    /**
     * 美易点2.9.1版本
     * 美易点2.9补充版本
     * 由于2.8.5版本在2.9版本后上线， 需补全插入的2.8.5版本的数据库升级
     *
     * @param serverDB
     * @param db
     */
    private static void updateV61(boolean serverDB, SQLiteDatabase db) {
        updateV56(serverDB, db);
        updateV57(serverDB, db);
        setModifiedTables(serverDB, db, "tbPrintTempletPublic");
        haveToDowanloadData(serverDB, db);
    }


    private static void updateV57(boolean serverDB, SQLiteDatabase db) {
        setModifiedTables(serverDB, db, "tbMenuItemUint,tbmenuitemvipprice,tbBonusManageUser");
        haveToDowanloadData(serverDB, db);
        // 美易点 2.8.3 版本之后丢失数据库版本 55 的内容，这里重新补齐
        updateV55(serverDB, db);
    }

    /**
     * 美易点 2.8.5(新增菜品条码)
     * 此版本在 美易点 2.9 之后插入。2.9 以上的版本，需要再次调用此方法，以作适配
     *
     * @param serverDB
     * @param db
     */
    private static void updateV56(boolean serverDB, SQLiteDatabase db) {
        // 条形码
        if (!isFieldExist(db, "tbmenuitem", "fsBarCode")) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fsBarCode VARCHAR(32) DEFAULT '';");
        }
        setModifiedTables(serverDB, db, "tbmenuitem");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * 美易点3.0
     *
     * @param serverDB
     * @param db
     */
    private static void updateV70(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //`fiIsDisMenu` int(6) DEFAULT '0' COMMENT '不可打折菜品是否参与折扣(0:否;1:是)'，默认否
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD COLUMN fiIsDisMenu int(6) NOT NULL DEFAULT '0'");
        }
    }

    /**
     * 美易点2.9
     *
     * @param serverDB
     * @param db
     */
    private static void updateV60(boolean serverDB, SQLiteDatabase db) {

        //菜品满减关联菜品
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tbbargainfullitem` (\n" +
                "  `fsBargainId` varchar(8) NOT NULL DEFAULT '',\n" +
                "  `fiItemCd` int(11) NOT NULL DEFAULT '0',\n" +
                "  `fiOrderUintCd` int(11) NOT NULL DEFAULT '0',\n" +
                "  `fsShopGUID` varchar(80) NOT NULL DEFAULT '',\n" +
                "  `fsUpdateTime` varchar(20) DEFAULT '',\n" +
                "  `fsUpdateUserId` varchar(20) DEFAULT '',\n" +
                "  `fsUpdateUserName` varchar(30) DEFAULT '',\n" +
                "  `fiStatus` int(11) DEFAULT '1' ,\n" +
                "  PRIMARY KEY (`fsBargainId`,`fiItemCd`,`fiOrderUintCd`,`fsShopGUID`)\n" +
                ")");

        if (serverDB) {
            //'单笔最大抹零金额:0=不限/1=固定金额'
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiIsMaxReduce INT(11) NOT NULL DEFAULT '0' ");
            //允许最大抹零金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN  fdMaxReducePrice decimal(18,1) DEFAULT '0' ");
            // 转菜记录
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tbitemchangetable` (\n" +
                    "  `fsSellNo` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsMTableId` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsSeq` varchar(80) NOT NULL DEFAULT '',\n" +
                    "  `fiItemCd` decimal(18,0) NOT NULL DEFAULT '',\n" +
                    "  `fsItemId` varchar(30) DEFAULT NULL DEFAULT '',\n" +
                    "  `fsItemName` varchar(250) NOT NULL DEFAULT '',\n" +
                    "  `fdChangeQty` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsChangeReason` varchar(80) DEFAULT NULL DEFAULT '',\n" +
                    "  `fsSellNo_new` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsMTableId_new` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsCreateTime` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsCreateUserName` varchar(30) NOT NULL DEFAULT '',\n" +
                    "  `fsShopGUID` varchar(80) NOT NULL DEFAULT '',\n" +
                    "  `lver` integer NOT NULL DEFAULT '1',\n" +
                    "  `pver` integer NOT NULL DEFAULT '0',\n" +
                    "  PRIMARY KEY (`fsSellNo`,`fsSellNo_new`,`fsSeq`,`fsShopGUID`)\n" +
                    ")");
            // 合桌记录表sqlite中已存在，但未指定主键，故先drop再create
            DBTools.exeSqlWithoutException(db, "DROP TABLE tbchangetable");
            // 合桌记录
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tbchangetable` (\n" +
                    "  `fsSellNo` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fiTimes` int(11) NOT NULL DEFAULT '0',\n" +
                    "  `fsMTableId` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsMTableId_new` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsChangeReason` varchar(80) DEFAULT NULL DEFAULT '',\n" +
                    "  `fsCreateTime` varchar(20) NOT NULL DEFAULT '',\n" +
                    "  `fsCreateUserName` varchar(30) NOT NULL DEFAULT '',\n" +
                    "  `fsShopGUID` varchar(80) DEFAULT NULL DEFAULT '',\n" +
                    "  `lver` integer NOT NULL DEFAULT '1',\n" +
                    "  `pver` integer NOT NULL DEFAULT '0',\n" +
                    "  PRIMARY KEY (`fsSellNo`,`fsMTableId`,`fsMTableId_new`,`fsShopGUID`)\n" +
                    ")");
            // 原始桌台信息
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsOriginTableId VARCHAR(20) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsOriginTableName VARCHAR(50) DEFAULT ''");

            //买减
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN fdBuyGiftAmt decimal(18,0) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdBuyGiftAmt decimal(18,0) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdBuyGiftName VARCHAR(50) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdBuyGiftId VARCHAR(50) DEFAULT ''");

            // 一级分类信息
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsRootMenuClsId VARCHAR(20) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsRootMenuClsName VARCHAR(50) DEFAULT ''");

            //小票模版新增（模版类型，最低支持版本）字段
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinttempletpublic ADD COLUMN fiTempletType int(4) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinttempletpublic ADD COLUMN fiMinSupportVersion int(11) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinttempletprivate ADD COLUMN fiTempletType int(4) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinttempletprivate ADD COLUMN fiMinSupportVersion int(11) DEFAULT 0");

            //需要强制下载几张表的数据
            setModifiedTables(serverDB, db, "tbbargainfullitem,tbuser");
            haveToDowanloadData(serverDB, db);
        }

    }

    /**
     * pro2.8.1菜品来源、air2.5.2、美收银1.4.1：打印机添加头像image
     * 美易点2.8.1---补充版本2018-07-09
     * 由于air2.5.1.281已经发布线上，pro2.8.1需要额外加字段，所以只能再升级数据库
     *
     * @param serverDB
     * @param db
     */
    private static void updateV55(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN antiPayCount INT(11) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN invoiceBusinessNo VARCHAR(32) DEFAULT ''");

            //映射用的集团编码'
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbrevenuetype ADD fsCompanyId VARCHAR(10) DEFAULT ''");
//            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbrevenuetypegrReventoup ADD fsCompanyId VARCHAR(10) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbexpcls ADD fsCompanyId VARCHAR(10) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdiscount ADD fsCompanyId VARCHAR(10) DEFAULT '' ");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiCompanyItemCd int(11) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsCompanyMenuClsId varchar(10) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsCompanyExpClsId varchar(10) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsCompanyRevenueTypeId varchar(10) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsCompanyDiscountId varchar(10) DEFAULT NULL");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN fsCompanyPaymentId varchar(10) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN fsCompanyPaymentTypeId varchar(10) DEFAULT NULL");
        }

        //映射用的集团编码'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiCompanyId int(11) DEFAULT '0' ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenucls ADD fsCompanyId VARCHAR(10) DEFAULT ''");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbaskgp ADD fsCompanyId VARCHAR(10) DEFAULT ''");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbbargain ADD fsCompanyId VARCHAR(10) DEFAULT ''");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD fsCompanyId VARCHAR(10) DEFAULT ''");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpaymenttype ADD fsCompanyId VARCHAR(10) DEFAULT ''");


        //air需要强制下载几张表的数据
        setModifiedTables(serverDB, db, "tbmenucls,tbmenuitem,tbpayment,tbexpcls,tbrevenuetype");
        haveToDowanloadData(serverDB, db);

    }

    /**
     * pro2.8.1菜品来源、air2.5.1.281、美收银1.4.1：打印机添加头像image
     *
     * @param serverDB
     * @param db
     */
    private static void updateV54(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //pro2.8.1菜品来源
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsBillSourceId varchar(10) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsBillSourceName varchar(30) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fsBillSourceNo varchar(80) DEFAULT ''");
            //air2.5.2
            //air2.5.1.281
            DBTools.exeSqlWithoutException(db, "ALTER TABLE kbOrder ADD COLUMN payStatus VARCHAR(80) DEFAULT '' ");
        }

        //美收银1.4.1：打印机添加头像image
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinter ADD COLUMN fsImageUrl varchar(100) DEFAULT ''");

        //air需要强制下载几张表的数据
        setModifiedTables(serverDB, db, "tbpaymenttype,tbpayment,tbmenuitem");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * pro2.7.7补充版本  --- 补充版本---2018-06-30
     * 由于此版本是在pro2.8及air2.5.1版本上线后插入的前序版本，
     * 所以要兼容此版本升级到pro2.8及air2.5.1版本的问题，
     * 解决方案是此版本的数据库版本号定为53，数据库升级部分要判断
     * 50级51版本的字段是否已存在，不存在的要补上。pro2.8.1开始，
     * 数据库要使用54版本，air2.5.1之后的版本要使用54版本
     *
     * @param serverDB
     * @param db
     */
    private static void updateV53(boolean serverDB, SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinter ADD COLUMN fiPrinterNum INT(11) DEFAULT 0");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinter ADD COLUMN fiControlBill INT(4) DEFAULT 0");

        //兼容49版本数据库升级
        if (!isFieldExist(db, "tbexpcls", "sync")) {
            updateV49(serverDB, db);
        }

        //兼容50版本数据库升级
        if (!isFieldExist(db, "order_cache", "invoiceState")) {
            updateV50(serverDB, db);
        }

        //兼容51版本数据库升级
        updateV51(serverDB, db);

    }

    /**
     * air2.5.1 口碑预点单退款记录表
     *
     * @param serverDB
     * @param db
     */
    public static void updateV51(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //口碑预点单退款记录表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tborderrefundkoubei` (\n" +
                    "  fsSellNo varchar(20) NOT NULL DEFAULT '' PRIMARY KEY ,\n" +
                    "  fsRefundType int(1) ,\n" +
                    "  fsOperator varchar(32) ,\n" +
                    "  fsAuthorizer varchar(32) DEFAULT '',\n" +
                    "  fsRefundTime varchar(20) \n" +
                    ");");
        }
    }

    /**
     * pro 2.8
     *
     * @param serverDB
     * @param db
     */
    public static void updateV50(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //菜品分类排序---小票打印
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS menuClsPrintSort(\n" +
                    "fsShopGUID varchar(80),\n" +
                    "fsMenuClsId  varchar(10),\n" +
                    "fsMenuClsName varchar(30) ,\n" +
                    "fiLevel int(11),\n" +
                    "fiPrintSortOrder  int(11),\n" +
                    "fsUpdateTime varchar(20),\n" +
                    "fsUpdateUserName varchar(20),\n" +
                    "fiDataSource int(11),\n" +
                    "PRIMARY KEY (fsShopGUID, fsMenuClsId)\n" +
                    ");");
            //ordere_cache 增加 开票状态
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN invoiceState int DEFAULT 0 ");
            //ordere_cache表增加 发票详情
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN invoiceDetail VARCHAR(360) DEFAULT '' ");

            //tbsell表增加 开票状态 0:不开票；1：需要开票（打印过开票二维码） 2：开票成功  3：开票中 4：开票失败
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN fiInvoiceState int DEFAULT 0 ");
            //tbsell表增加 发票请求流水号
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN fsInvoiceNo VARCHAR(80) DEFAULT '' ");
            //tbSellOrderItem 新增原始单价
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdOriginPrice DECIMAL(18,2) DEFAULT 0.00 ");


            //新增预点单表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"kbOrder\" (\n" +
                    "  \"order_id\" text(100),\n" +
                    "  \"merchant_id\" text(100),\n" +
                    "  \"biz_product\" text(100),\n" +
                    "  \"shop_id\" text(50),\n" +
                    "  \"business_type\" text(20),\n" +
                    "  \"dinner_type\" text(20),\n" +
                    "  \"order_style\" text(20),\n" +
                    "  \"channel\" text(20),\n" +
                    "  \"people_num\" text(20),\n" +
                    "  \"take_style\" text(20),\n" +
                    "  \"take_no\" text(20),\n" +
                    "  \"bill_amount\" decimal(10,2),\n" +
                    "  \"receipt_amount\" decimal(10,2),\n" +
                    "  \"trade_amount\" decimal(10,2),\n" +
                    "  \"pay_amount\" decimal(10,2),\n" +
                    "  \"service_amount\" decimal(10,2),\n" +
                    "  \"packing_amount\" decimal(10,2),\n" +
                    "  \"other_amount\" decimal(10,2),\n" +
                    "  \"table_time\" text(20),\n" +
                    "  \"order_time\" text(20),\n" +
                    "  \"user_mobile\" text(20),\n" +
                    "  \"memo\" text(200),\n" +
                    "  \"ext_info\" text(500),\n" +
                    "  \"member_flag\" text(20),\n" +
                    "  \"status\" text(10),\n" +
                    "  \"dish_details\" text,\n" +
                    "  \"pay_channels\" text,\n" +
                    "  PRIMARY KEY (\"order_id\")\n" +
                    ");");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fdLunchBoxCost decimal(8,2) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbbargain ADD COLUMN sync int(2) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbbargain ADD COLUMN fiDataSource int(6) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbcutmoney ADD COLUMN sync int(2) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbcutmoney ADD COLUMN fiDataSource int(6) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbshop ADD COLUMN fiWorkMode TINYINT(4) DEFAULT -1 ;");
        }
        setModifiedTables(serverDB, db, "tbPrintTempletPublic");
        haveToDowanloadData(serverDB, db);
    }

    /**
     * pro2.7.7
     * 2018-06-15 补充
     *
     * @param serverDB
     * @param db
     */
    private static void updateV49(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbexpcls ADD COLUMN sync int(2) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbexpcls ADD COLUMN fiDataSource int(6) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbrevenuetype ADD COLUMN sync int(2) DEFAULT 0 ;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbrevenuetype ADD COLUMN fiDataSource int(6) DEFAULT 0 ;");
        }
    }

    /**
     * pro2.7.6 打印
     * 2018-06-14 补充
     *
     * @param serverDB
     * @param db
     */
    private static void updateV48(boolean serverDB, SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiCutSamSung INT(11) DEFAULT 0 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiSupportStatusCheck INT(11) DEFAULT 0 ");
    }

    /**
     * pro 2.7.6 划菜
     *
     * @param serverDB
     * @param db
     */
    public static void updateV47(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //划菜表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbSellPickMenuitem\n" +
                    "(\n" +
                    "  fsSellNo       VARCHAR(20),\n" +
                    "  fsMenuSeq      VARCHAR(80),\n" +
                    "  fdPickQty      NUMERIC(18,6),\n" +
                    "  fiPickSeq      INT,\n" +
                    "  fiStatus       INT,\n" +
                    "  fsOptTime      VARCHAR(20),\n" +
                    "  fsOptUserId    VARCHAR(20),\n" +
                    "  fsOptUserName  VARCHAR(30),\n" +
                    "  fsOptReason    VARCHAR(80),\n" +
                    "  fsAuthUserId   VARCHAR(20),\n" +
                    "  fsAuthUserName VARCHAR(30),\n" +
                    "  fiOrderSeq     INT,\n" +
                    "  fsHostId       VARCHAR(30),\n" +
                    "  fsShopGUID     VARCHAR(80),\n" +
                    "  lver           INT,\n" +
                    "  pver           INT,\n" +
                    "  fsSellDate varchar(40),\n" +
                    "  fiItemCd int ,\n" +
                    "  fiOrderItemKind int(2),\n" +
                    "  fsItemName VARCHAR(80),\n" +
                    "  CONSTRAINT tbSellPickMenuitem_fsSellNo_fsMenuSeq_fiPickSeq_fsShopGUID_pk\n" +
                    "  PRIMARY KEY (fsSellNo, fsMenuSeq, fiPickSeq, fsShopGUID)\n" +
                    ");");

            //菜品做法、要求表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbSellOrderItemNote\n" +
                    "(\n" +
                    "  fsGuid           VARCHAR(80)\n" +
                    "    PRIMARY KEY,\n" +
                    "  fsSellNo         VARCHAR(20),\n" +
                    "  fsMenuSeq        VARCHAR(80),\n" +
                    "  fdAskQty         NUMERIC(18, 6),\n" +
                    "  fdTotalAskQty    NUMERIC(18, 6),\n" +
                    "  fsAskGpId        VARCHAR(6),\n" +
                    "  fiAskId          INT,\n" +
                    "  fsAskName        VARCHAR(50),\n" +
                    "  fdAddPrice       NUMERIC(18, 6),\n" +
                    "  fdTotalAddPrice  NUMERIC(18, 6),\n" +
                    "  fsCreateTime     VARCHAR(20),\n" +
                    "  fsCreateUserId   VARCHAR(20),\n" +
                    "  fsCreateUserName VARCHAR(30),\n" +
                    "  fsUpdateTime     VARCHAR(20),\n" +
                    "  fsUpdateUserId   VARCHAR(20),\n" +
                    "  fsUpdateUserName VARCHAR(30),\n" +
                    "  fiType           INT,\n" +
                    "  fsShopGUID       VARCHAR(80),\n" +
                    "  lver             INT,\n" +
                    "  pver             INT,\n" +
                    "  fsSellDate varchar(40)," +
                    "  fiItemCd int ,\n" +
                    "  fiOrderItemKind int(2),\n" +
                    "  fsItemName VARCHAR(80)\n" +
                    ");");
        }

        //--'是否可预点单 0:不上传,1:上传'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiIsPrePoint int(11) DEFAULT 1 ;");

        //2.7.6强制下载小票模版两张表和tbpayment表
        setModifiedTables(serverDB, db, "tbPrintTempletPublic,tbPrintTempletPrivate,tbpayment");
    }

    /**
     * pro 2.7.1 为支持后台方便统计数据，tbsell表新增几个字段
     *
     * @param serverDB
     * @param db
     */
    public static void updateV46(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //tbsell表增加 总店Id  不能为空
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN companyGuid VARCHAR(80) DEFAULT '' ");
            //tbsell表增加 区域名称AreaName  不能为空
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN areaName VARCHAR(80) DEFAULT '' ");
            //tbsell表增加 餐段名称SectionName  不能为空
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN sectionName VARCHAR(80) DEFAULT '' ");
            //tbsell表增加 开台站点名称HostName  站点名字
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN hostName VARCHAR(80) DEFAULT '' ");
            //tbsell表增加 收银站点名称HostName  站点名字 不能为空
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN cashHostName VARCHAR(80) DEFAULT '' ");
            //tbsell表增加 总店Id  不能为空
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN clientType INT DEFAULT '1' ");
            //tbsellOrderItem表增加 可提成点字段
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiIsBonus INT DEFAULT '0' ");
            //tbPrinter表增加 是否新旧打印机字段
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinter ADD COLUMN fiNewPrinter INT DEFAULT '0' ");
            //小票模版-基础表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbPrintTempletPublic (\n" +
                    "  fsTempletId varchar(20) NOT NULL,\n" +
                    "  fsTempletKey varchar(20) NOT NULL,\n" +
                    "  fsTempletName varchar(50) DEFAULT NULL,\n" +
                    "  fiStatus int  DEFAULT 1,\n" +
                    "  fsTempletFile text DEFAULT NULL,\n" +
                    "  fsTempletData text DEFAULT NULL,\n" +
                    "  fsNote varchar(50) DEFAULT NULL,\n" +
                    "  fsCreateTime varchar(20) DEFAULT NULL,\n" +
                    "  fsCreateUserId varchar(20) DEFAULT NULL,\n" +
                    "  fsCreateUserName varchar(30) DEFAULT NULL,\n" +
                    "  fsUpdateTime varchar(20)DEFAULT NULL,\n" +
                    "  fsUpdateUserId varchar(20) DEFAULT NULL,\n" +
                    "  fsUpdateUserName varchar(30) DEFAULT NULL,\n" +
                    "  PRIMARY KEY (\"fsTempletId\", \"fsTempletKey\")\n" +
                    ");");
            //小票模版-门店
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbPrintTempletPrivate (\n" +
                    "  fsTempletId varchar(20) NOT NULL,\n" +
                    "  fsTempletKey varchar(20) NOT NULL,\n" +
                    "  fsTempletName varchar(50) DEFAULT NULL,\n" +
                    "  fsShopGUID varchar(80) NOT NULL,\n" +
                    "  fsTempletFile text DEFAULT NULL,\n" +
                    "  fiSelected int DEFAULT 0,\n" +
                    "  fiStatus int DEFAULT 1,\n" +
                    "  sync int DEFAULT 0,\n" +
                    "  fsCreateTime varchar(20) DEFAULT NULL,\n" +
                    "  fsCreateUserId varchar(20) DEFAULT NULL,\n" +
                    "  fsCreateUserName varchar(30) DEFAULT NULL,\n" +
                    "  fsUpdateTime varchar(20) DEFAULT NULL,\n" +
                    "  fsUpdateUserId varchar(20) DEFAULT NULL,\n" +
                    "  fsUpdateUserName varchar(30) DEFAULT NULL,\n" +
                    "  PRIMARY KEY (\"fsTempletId\", \"fsTempletKey\",\"fsShopGUID\")\n" +
                    ");");
            setModifiedTables(serverDB, db, "tbprinter,tbPrintTempletPublic,tbPrintTempletPrivate");
        }
    }

    public static void updateV45(boolean serverDB, SQLiteDatabase db) {
        /**
         * 估清类型 0：份数估清； 1：重量估清
         */
        DBTools.exeSqlWithoutException(db, "ALTER TABLE localSellOut ADD COLUMN sellOutType DECIMAL(18,2) DEFAULT 0 ");
        //是否是临时菜：0=false/1=true
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiIsTemporaryMenu int(11) DEFAULT 0 ");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiIsTemporaryMenu int(11) DEFAULT 0 ");
        //'允许最大折扣率'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiUserDiscount int(11) DEFAULT 0 ");
        //tbsell表增加版本信息  fsSoftVersion` varchar(80) DEFAULT '' COMMENT '软件版本号'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fsSoftVersion VARCHAR(80) DEFAULT '' ");
        //tbprinter表新增fsPrinterSN字段  `fsPrinterSN` varchar(30) DEFAULT NULL COMMENT '打印机SN号',
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbprinter ADD COLUMN fsPrinterSN VARCHAR(30) DEFAULT '' ");

        // tbBuygiftItem 部分字段删除非空约束
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbBuygiftItem RENAME TO tbBuygiftItemTemp");
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbBuygiftItem (\n" +
                "  fsBargainId VARCHAR(8) NOT NULL DEFAULT '',\n" +
                "  fiItemCd INT(11) NOT NULL DEFAULT '0',\n" +
                "  fiOrderUintCd INT(11) NOT NULL DEFAULT '0',\n" +
                "  fsShopGUID VARCHAR(80) NOT NULL DEFAULT '',\n" +
                "  fdBargainPrice DECIMAL(18,2) DEFAULT NULL,\n" +
                "  fdSaleQty DECIMAL(18,2) DEFAULT NULL,\n" +
                "  fdSaleQty_gift DECIMAL(18,2) DEFAULT NULL,\n" +
                "  fiDiscountRate INT(11) DEFAULT NULL,\n" +
                "  fiStatus INT(11) DEFAULT NULL,\n" +
                "  fsUpdateTime VARCHAR(20) DEFAULT NULL,\n" +
                "  fsUpdateUserId VARCHAR(20) DEFAULT NULL,\n" +
                "  fsUpdateUserName VARCHAR(30) DEFAULT NULL,\n" +
                "  PRIMARY KEY (fsBargainId, fiItemCd, fiOrderUintCd, fsShopGUID)\n" +
                ")");
        setModifiedTables(serverDB, db, "tbmenuitem,tbuser,tbprinter,tbBuygiftItem");
        try {
            DBTools.exeSqlWithoutException(db, "INSERT INTO tbBuygiftItem SELECT * FROM tbBuygiftItemTemp");
            DBTools.exeSqlWithoutException(db, "DROP TABLE tbBuygiftItemTemp");
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    public static void updateV44(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"tbsellCoupon\" (\n" +
                    "\"fsSeq\" VARCHAR(80) NOT NULL,\n" +
                    "\"fiPaySeq\" VARCHAR(80) NOT NULL,\n" +
                    "\"fsCheckBillNo\" INT(11) NOT NULL,\n" +
                    "\"fsSellNo\" VARCHAR(20) NOT NULL ,\n" +
                    "\"fiOrderSeq\" INT(11) NOT NULL ,\n" +
                    "\"fsSellDate\" VARCHAR(10) NOT NULL ,\n" +
                    "\"fsShopGuid\" VARCHAR(80) NOT NULL ,\n" +
                    "\"fsPaymentId\" VARCHAR(10) DEFAULT NULL ,\n" +
                    "\"fsPaymentName\" VARCHAR(20) DEFAULT NULL ,\n" +
                    "\"fsPaymentTypeId\" VARCHAR(10) DEFAULT NULL ,\n" +
                    "\"fsPaymentTypeName\" VARCHAR(20) DEFAULT NULL ,\n" +
                    "\"fdSpliteAmt\" DECIMAL(18,4) DEFAULT 0.00 ,\n" +
                    "\"fiIsCalcPaid\" TINYINT(4) NOT NULL DEFAULT 1 ,\n" +
                    "\"fsCreateTime\" VARCHAR(19) DEFAULT NULL,\n" +
                    "\"fsUpdateTime\" VARCHAR(19) DEFAULT NULL,\n" +
                    "\"lver\" TINYINT(4) DEFAULT 0,\n" +
                    "\"pver\" TINYINT(4) DEFAULT 0,\n" +
                    "CONSTRAINT \"pk_tbSellCoupon\" PRIMARY KEY (\"fsSeq\", \"fsSellNo\", \"fsCheckBillNo\", \"fiPaySeq\")\n" +
                    ")");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fiSourceType TINYINT(4) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsThirdAccountName VARCHAR(50) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsThirdOrder VARCHAR(120) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsCreditAccountId VARCHAR(20) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsCreditAccountName VARCHAR(50) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsMemCardNo VARCHAR(50) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fsTicketCode VARCHAR(50) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fiIsPartAmtDiscount TINYINT(4) DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN fiSeq_M INT(11) DEFAULT NULL");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdCouponSpecialAmt DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdCouponVipAmt DECIMAL(18,2) DEFAULT 0.00");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiMemDiscount DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fdDiscountMemAmt DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiIsSpecialty TINYINT(2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiIsNew TINYINT(2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN fiIsHot TINYINT(2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdRoundAmt DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdCouponSpecialAmt DECIMAL(18,2) DEFAULT 0.00");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdCouponVipAmt DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdDiscountMemAmt DECIMAL(18,2) DEFAULT 0.00 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fiVersion int(18,2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fsThirdOrderId VARCHAR(20) DEFAULT NULL ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fiThirdBizType int(18,2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdOriginalAmtDis DECIMAL(18,2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdServiceSplitCouponAmt DECIMAL(18,2) DEFAULT 0 ");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fdServiceSplitCalcAmt DECIMAL(18,2) DEFAULT 0 ");


            try {
                //迁移数据
                String sql = "update tbSellReceive set fsCreditAccountId=fsMiscno,fsCreditAccountName=fsNote where fsPaymentId='" + PayType.HUNG + "'";
                DBTools.exeSqlWithoutException(db, sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //可打印全部菜 '可打印全部菜 0-false,1-true';
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbdept ADD COLUMN fiPrintDishes INT(11) DEFAULT 0");
        }
        //是否纯收银的菜品 0：否；1：是
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItem ADD COLUMN fiIsPurePay INT(2) DEFAULT 0");

        //'分账模式:0:按金额比例,1:按分账金额,2:按分账比例'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiLedgerMode int(11) DEFAULT 0 ");

    }

    public static void updateV43(boolean serverDB, SQLiteDatabase db) {

        //是否适用于所有菜品分类：0:否 1：是'
        if (!isFieldExist(db, "tbaskgp", "fiUseAllMenuCls")) {
            DBTools.exeSqlWithoutException(db, "ALTER table tbaskgp add column fiUseAllMenuCls int(4) default 0");
        }

        //迁移数据
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("select * from tbmenuitemaskgp where fistatus <> '13' and fiRelationtype <> '3' ", null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    // 1:全部 , 2:菜品分类，3:菜品',
                    int fiRelationtype = cursor.getInt(cursor.getColumnIndex("fiRelationtype"));
                    String fsAskGpId = cursor.getString(cursor.getColumnIndex("fsAskGpId"));
                    if (fiRelationtype == 1) {
                        String updateSQL = "update tbaskgp set fiUseAllMenuCls = '1', sync = '1' where fsAskGpId = '" + fsAskGpId + "'";
                        DBTools.exeSqlWithoutException(db, updateSQL);
                    } else {
                        String fsGuid = UUID.randomUUID().toString();
                        String fsUpdateUserName = cursor.getString(cursor.getColumnIndex("fsUpdateUserName"));
                        String fsUpdateTime = cursor.getString(cursor.getColumnIndex("fsUpdateTime"));
                        String fsShopGUID = cursor.getString(cursor.getColumnIndex("fsShopGUID"));
                        String fsUpdateUserId = cursor.getString(cursor.getColumnIndex("fsUpdateUserId"));
                        String fsMenuClsId = cursor.getString(cursor.getColumnIndex("fsMenuClsId"));
                        String insertSQL = "insert into tbaskgpmenucls(fsGuid,fsMenuClsId,fsAskGpId, fsUpdateUserId,fsUpdateUserName,fsUpdateTime, fsShopGUID, fiStatus, fiDataSource, sync) " +
                                "values('" + fsGuid + "','" + fsMenuClsId + "', '" + fsAskGpId + "','" + fsUpdateUserId + "','" + fsUpdateUserName + "','" + fsUpdateTime + "','" + fsShopGUID + "', '1', '1','1')";
                        DBTools.exeSqlWithoutException(db, insertSQL);
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
    }

    public static void updateV42(boolean serverDB, SQLiteDatabase db) {
        if (!serverDB) {
            Cursor cursor = null;
            try {
                cursor = db.rawQuery("select * from tbaskgpmenucls ", null);
            } catch (Exception e) {
                //菜品要求分组关联菜品分类
                DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbaskgpmenucls (\n" +
                        "  fsGuid varchar(36) NOT NULL PRIMARY KEY ,\n" +
                        "  fsMenuClsId varchar(10) ,\n" +
                        "  fsAskGpId varchar(6) ,\n" +
                        "  fsUpdateTime varchar(20) ,\n" +
                        "  fsUpdateUserId varchar(20) DEFAULT NULL,\n" +
                        "  fsUpdateUserName varchar(30) DEFAULT NULL ,\n" +
                        "  fsShopGUID varchar(80) ,\n" +
                        "  fiStatus int(11) DEFAULT '1' ,\n" +
                        "  fiDataSource int(4) DEFAULT '0', " +
                        " sync int(2) DEFAULT 0" +
                        "  )");
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }
        }
    }

    public static void updateV41(boolean serverDB, SQLiteDatabase db) {
        //做法多选 0:未选中,1:多选
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiMultiPractice int(11) DEFAULT '0' ");
        //'做法最小'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiPracticeMin int(11) DEFAULT '1'");
        //'做法最大'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiPracticeMax int(11) DEFAULT '1'");
        if (serverDB) {
            //是否存在预付款信息  0:没有预付款信息 / 1有预付款支付信息 / 2预付款已退
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tableBiz ADD COLUMN prePayFlag int(11) DEFAULT '0'");
            //'挂账名字拼音首字母'
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbcreditaccount ADD fsCreditAccountNamePY VARCHAR(50) DEFAULT ''");
        }

        //菜品要求分组关联菜品分类
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbaskgpmenucls (\n" +
                "  fsGuid varchar(36) NOT NULL PRIMARY KEY ,\n" +
                "  fsMenuClsId varchar(10) ,\n" +
                "  fsAskGpId varchar(6) ,\n" +
                "  fsUpdateTime varchar(20) ,\n" +
                "  fsUpdateUserId varchar(20) DEFAULT NULL,\n" +
                "  fsUpdateUserName varchar(30) DEFAULT NULL ,\n" +
                "  fsShopGUID varchar(80) ,\n" +
                "  fiStatus int(11) DEFAULT '1' ,\n" +
                "  fiDataSource int(4) DEFAULT '0', " +
                " sync int(2) DEFAULT 0" +
                "  )");
    }

    public static void updateV40(boolean serverDB, SQLiteDatabase db) {
        if (serverDB) {
            //第三方会员卡与美味会员卡关联表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbCardRelation (\n" +
                    "  fsGuid varchar(36) NOT NULL PRIMARY KEY ,\n" +
                    "  fsRelKey varchar(36),\n" +
                    "  fsRelValue varchar(36) ,\n" +
                    "  fsBody varchar(50),\n" +
                    "  fsRemark varchar(500),\n" +
                    "  fsShopGUID varchar(80) NOT NULL,\n" +
                    "  fsCreateTime varchar(20) ,\n" +
                    "  fsUpdateTime varchar(20) ,\n" +
                    "  fsUpdateUserId varchar(20) ,\n" +
                    "  fsUpdateUserName varchar(30),\n" +
                    "  fiStatus int(11),\n" +
                    "  fiDataSource int(4),\n" +
                    "  pver int(4) default 0,\n" +
                    "  lver int(4) default 0,\n" +
                    "  sync int(4) default 0\n" +
                    " )");
        }
    }

    protected static void checkExtra(boolean serverDB, SQLiteDatabase db) {
        if (!isFieldExist(db, "tbmenuitemvipprice", "fiStatus")) {
            DBTools.exeSqlWithoutException(db, "alter table  tbmenuitemvipprice add column fiStatus int(11) DEFAULT 0;");
        }
    }

    public static void updateV39(boolean serverDB, SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiCPL TINYINT(4) DEFAULT 0");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiPrinterType TINYINT(4) DEFAULT 0");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiReverse TINYINT(4) DEFAULT 0");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiLanguage TINYINT(4) DEFAULT 0");
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "ALTER TABLE host_status ADD COLUMN sync_flag TINYINT(4) DEFAULT 0");
            setModifiedTables(serverDB, db, "tbPrinter");
        }
    }

    public static void updateV38(boolean serverDB, SQLiteDatabase db) {
        //添加菜品分类部门关联表
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS \"tbmenuClsMuldept\" (\n" +
                "  \"fsGuid\" VARCHAR(36),\n" +
                "  \"fsMenuClsId\" VARCHAR(10),\n" +
                "  \"fsShopGUID\" VARCHAR(80),\n" +
                "  \"fsDeptId\" VARCHAR(20),\n" +
                "  \"fsMAreaId\" VARCHAR(20),\n" +
                "  \"fiStatus\" integer(11),\n" +
                "  \"fsUpdateTime\" VARCHAR(20),\n" +
                "  \"fsUpdateUserId\" VARCHAR(20),\n" +
                "  \"fsUpdateUserName\" VARCHAR(30),\n" +
                "  \"fiDataSource\" integer(4),\n" +
                " sync  int(2) DEFAULT 0, " +
                "  PRIMARY KEY (\"fsGuid\")\n" +
                ");");
        //修改菜品分类表 '是否后厨打印:0无后厨打印,1单制作部门,2多制作部门'
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenucls ADD fiIsPrn int(11) DEFAULT 0");
        //是否可手机点菜：0，不可以；1，可以
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD COLUMN fiIsWechatOrder TINYINT(4) DEFAULT 0");
        //将所有菜品设置为可手机点菜
        DBTools.exeSqlWithoutException(db, "update tbmenuitem set fiIsWechatOrder='1',sync='1', fsUpdateTime = '" + DateUtil.getCurrentTime() + "' where fiDataSource='1'");
        if (serverDB) {
            //折扣方案分类关联表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbdiscountmenucls (\n" +
                    "fsGuid char(36) PRIMARY KEY , \n" +
                    "fsShopGUID varchar(80) , \n" +
                    "fsDiscountId varchar(8) , \n" +
                    "fsMenuClsId varchar(10) , \n" +
                    "fiDiscountRate int(11) DEFAULT 0 , \n" +
                    "fiStatus int(11)  DEFAULT 1, \n" +
                    "fiDataSource int(4) DEFAULT 0 ,\n" +
                    "fsUpdateTime varchar(20) , \n" +
                    "fsUpdateUserId varchar(20) DEFAULT '' , \n" +
                    "fsUpdateUserName varchar(30) DEFAULT '', \n" +
                    "sync int(2) DEFAULT 0 \n" +
                    ")");
        }
    }

    protected static void updateV37(boolean serverDB, final SQLiteDatabase db) {
        if (serverDB) {
            //第三方订单号
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD thirdOrderId varchar(20) DEFAULT ''");
            //预结单打印次数
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD printPre int(2) DEFAULT '0'");
            //结账单打印次数
            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD printbill int(2) DEFAULT '0'");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD thirdOrderId varchar(20) DEFAULT ''");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD thirdOrderType int(2) DEFAULT ''");

            //原始结算总价
            DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column fdOriginalAmt decimal(18,2) default 0.00");
            //原始结算总价
            DBTools.exeSqlWithoutException(db, "alter table tbsell add column fdOriginalAmt decimal(18,2) default 0.00");
            DBTools.exeSqlWithoutException(db, "update tbsell set fdOriginalAmt=fdSaleAmt where fdOriginalAmt='0' and fdSaleAmt<>'0'");
            DBTools.exeSqlWithoutException(db, "update tbsellorderitem set fdOriginalAmt=fdSaleAmt where fdOriginalAmt='0' and fdSaleAmt<>'0'");

            //菜品改价次数
            DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column changePriceTimes int(2) default 0");

        }

        //'验券平台1:美团点评',
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbpayment ADD fiVoucherPlatform int(11) DEFAULT 0 ;");
    }

    protected static void updateV36(boolean serverDB, final SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemAskGp ADD fiRelationtype int(11) DEFAULT '3'");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemAskGp ADD fsMenuClsId varchar(10) DEFAULT ''");
        DBTools.exeSqlWithoutException(db, "alter table tbMenuItemAskGp rename to tbMenuItemAskGpTemp");
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbmenuitemaskgp (\n" +
                " fiItemCd int(11)  DEFAULT '0' ,\n" +
                "  fsAskGpId varchar(6)  DEFAULT '' ,\n" +
                "  fsShopGUID varchar(80) DEFAULT '',\n" +
                "  fsUpdateTime varchar(20) DEFAULT NULL,\n" +
                "  fiStatus int(11) DEFAULT NULL,\n" +
                "  fsUpdateUserId varchar(20) DEFAULT NULL,\n" +
                "  fsUpdateUserName varchar(30) DEFAULT NULL,\n" +
                "  sync  int(2) DEFAULT 0,\n" +
                "  fiDataSource tinyint(4) DEFAULT '0',\n" +
                "  fiRelationtype int(11) DEFAULT '3',\n" +
                "  fsMenuClsId varchar(10) DEFAULT '',\n" +
                " PRIMARY KEY (fiItemCd,fsAskGpId,fsShopGUID,fsMenuClsId)\n" +
                ")");
        setModifiedTables(serverDB, db, "tbMenuItemAskGp");
        //2018-01-09 lxx 解决版本升级跨度太大导致数据库升级失败问题---不能通过再起线程做迁移数据的问题了
//        new LowThread(new Runnable() {
//            @Override
//            public void run() {
        try {
            DBTools.exeSqlWithoutException(db, "INSERT INTO tbMenuItemAskGp SELECT * FROM tbMenuItemAskGpTemp");
            DBTools.exeSqlWithoutException(db, "drop table tbMenuItemAskGpTemp");
        } catch (Exception e) {
            LogUtil.logError(e);
        }
//            }
//        }).start();
    }

    /**
     * 添加有数据待更新待标志，登录页会读取该值自动下载数据
     *
     * @param serverDB
     * @param db
     */
    private static void haveToDowanloadData(boolean serverDB, final SQLiteDatabase db) {
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "insert or replace into meta values('" + META.UPDATE_NOTIFY + "','1')");
        }
    }

    /**
     * 设置哪些表需要重新下载
     */
    private static void setModifiedTables(boolean serverDB, final SQLiteDatabase db, String tbNames) {
        if (TextUtils.isEmpty(tbNames)) {
            return;
        }
        if (serverDB) {
            tbNames = tbNames.toLowerCase();
            Cursor cursor = null;
            String tbNamesOrg = null;
            try {
                cursor = db.query("meta", new String[]{"value"}, "key = ?", new String[]{META.MODIFIED_TABLES + ""}, null, null, null);

                if (cursor != null) {
                    if (cursor.moveToNext()) {
                        tbNamesOrg = cursor.getString(0);
                        StringBuilder sb = new StringBuilder();
                        if (TextUtils.isEmpty(tbNamesOrg)) {
                            sb.append(tbNames);
                        } else {
                            sb.append(tbNamesOrg);
                            List<String> tbOrg = Arrays.asList(tbNamesOrg.split(","));
                            for (String tb : tbNames.split(",")) {
                                if (tbOrg.contains(tb)) {
                                    continue;
                                }
                                sb.append(",").append(tb.trim());
                            }
                        }
                        DBTools.exeSqlWithoutException(db, "insert or replace into meta values('" + META.MODIFIED_TABLES + "','" + sb.toString() + "')");
                    } else {
                        DBTools.exeSqlWithoutException(db, "insert or replace into meta values('" + META.MODIFIED_TABLES + "','" + tbNames + "')");
                    }
                } else {
                    DBTools.exeSqlWithoutException(db, "insert or replace into meta values('" + META.MODIFIED_TABLES + "','" + tbNames + "')");
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }
        }
    }

    protected static void updateV35(boolean serverDB, SQLiteDatabase db) {
        //餐区服务费收取方式：①不收服务费；②整单金额比例（折前）；③整单金额比例（折后）；④菜品（已勾选服务费）⑤固定金额。
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmarea ADD fiServiceType INT DEFAULT 1");
        //餐区服务费金额
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmarea ADD fdServiceAmt NUMERIC(18,6) DEFAULT 0");
        if (serverDB) {
            //添加菜品沽清的表
            DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS localSellOut (" +
                    "  fiOrderUintCd integer PRIMARY KEY NOT NULL," +
                    "  fiStatus integer DEFAULT(0)," +
                    "  fdInvQty numeric DEFAULT(0)," +
                    "  fsItemName text ," +
                    "  fiItemCd integer DEFAULT(0)," +
                    "  fsOrderUint text DEFAULT(NULL))");
            DBTools.exeSqlWithoutException(db, "INSERT INTO localSellOut SELECT tbmenuitemuint.fiOrderUintCd, tbmenuitemuint.fiStatus, tbmenuitemuint.fdInvQty, tbmenuitem.fsItemName, tbmenuitemuint.fiItemCd,tbmenuitemuint.fsOrderUint FROM tbmenuitemuint left join tbmenuitem on tbmenuitemuint.fiItemCd=tbmenuitem.fiItemCd where tbmenuitemuint.fiStatus in('2','3')");
        }

        //迁移网络订单数据
        new HandlerThread("MergeNetOrderThread") {
            @Override
            protected void onLooperPrepared() {
                super.onLooperPrepared();

                LogUtil.log("网络订单迁移：onLooperPrepared() 启动");

                new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        LogUtil.log("网络订单迁移：run() 开始");
                        mergeNetOrderDatas();

                        LogUtil.log("网络订单迁移: 数据已迁移完毕");
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                                getLooper().quitSafely();
                            } else {
                                getLooper().quit();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, 60 * 1000);
            }
        }.start();
    }

    protected static void updateV34(boolean serverDB, SQLiteDatabase db) {
        //由于V33时，sqlite文件的版本号是32，但是sqlite内容和33一致，为了避免表结构出现异常，V34手动再调用一次V33。
        updateV33(serverDB, db);
        //判断是否需要从0开始同步服务器端的数据
        boolean canReSyncDataFrom0 = !serverDB || !hasUnSyncedData(db);
        if (canReSyncDataFrom0) {
            DBTools.exeSqlWithoutException(db, "update meta set value='0' where key in ('2','3')");
        }
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmarea ADD COLUMN fiServiceRate INT DEFAULT 0");

        if (serverDB) {

            //添加轮询的任务
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN typeLoop INT DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN loopDestTime  VARCHAR(200)");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN laskWorkTime  VARCHAR(200)");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN driver_uri  VARCHAR(200)");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN driver_param  VARCHAR(200)");

            //添加押金属性
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellreceive ADD COLUMN fiThirdType INT(10) DEFAULT 0");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fiSelected INT DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fiUploadStatus INT DEFAULT 0");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fsUploadMsg VARCHAR(200)");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsell ADD COLUMN fsUploadTime VARCHAR(20)");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE order_cache ADD COLUMN hidden INT DEFAULT 0");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiBillAuthority INT DEFAULT 1");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuser ADD COLUMN fiBillClass INT DEFAULT 1");
            //分账折前金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fdSplitDisBeforeAmt DECIMAL(18,6) DEFAULT 0");
            //分账折扣金额
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fdSplitDisAmt DECIMAL(18,6)  DEFAULT 0 ");
            //'分账折后金额';
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbsellorderitem ADD COLUMN fdSplitDisAfterAmt DECIMAL(18,6)  DEFAULT 0");

            // 修改报表
            DBTools.exeSqlWithoutException(db, "UPDATE dailyReport SET param1 = '0, 1'");
        }
    }

    protected static void updateV33(boolean serverDB, final SQLiteDatabase db) {
        //添加套餐分账
        try {
            if (!isFieldExist(db, "tbmenuitem", "fiSplitStatus")) {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD fiSplitStatus INT(11) DEFAULT '9'");
            }
            if (!isFieldExist(db, "tbmenuitem", "fsExpClsId")) {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD fsExpClsId varchar(10)");
            }
            if (!isFieldExist(db, "tbmenuitem", "fsRevenueTypeId")) {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitem ADD fsRevenueTypeId varchar(10)");
            }
            if (!isFieldExist(db, "tbmenuitemsetside", "fdSplitPrice")) {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitemsetside ADD fdSplitPrice INT(4)  DEFAULT '0'");
            }
            if (!isFieldExist(db, "tbmenuitemsetside", "fiSplitPrice")) {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmenuitemsetside ADD fiSplitPrice INT(4)  DEFAULT '0'");
            }
            if (serverDB) {
                if (!isFieldExist(db, "tbSellOrderItem", "fiSplitStatus")) {
                    DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD fiSplitStatus INT(11)  DEFAULT '9'");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    protected static void updateV32(boolean serverDB, final SQLiteDatabase db) {

        //修改标识
        DBTools.exeSqlWithoutException(db, "alter table tbMArea add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMArea ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMTableCls add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMTableCls ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMTable add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMTable ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbHost add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbHost ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuCls add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuCls ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuItem add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItem ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuItemUint add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemUint ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuItemSetSide add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemSetSide ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuItemSetSideDtl add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemSetSideDtl ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbAskGp add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbAskGp ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbAsk add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbAsk ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMenuItemAskGp add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemAskGp ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbPaymentType add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPaymentType ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbPayment add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPayment ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbPrinter add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbPrinter ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbHostExternal add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbHostExternal ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbshop add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbshop ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbparamValue add column sync int(2) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbparamValue ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

        //COMMENT '店铺标识符: 0:普通门店 1:小散门店';
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbshop ADD COLUMN fiShopType TINYINT(4)  DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "alter table tbMTable add column fsOrderJob varchar(20) NOT NULL DEFAULT 0");

        //满减叠加
        DBTools.exeSqlWithoutException(db, "alter table tbcutmoney add column fifullcuttype int(2) DEFAULT 0;");

        //update  网络订单
        if (serverDB) {
            DBTools.exeSqlWithoutException(db, "alter table tbUser add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbUser ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbUserRole add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbUserRole ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbAuthorityDtl add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbAuthorityDtl ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbuserdiscount add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbuserdiscount ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbDept add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbDept ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbMenuItemMulDept add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbMenuItemMulDept ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbDiscount add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbDiscount ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbDiscountItem add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbDiscountItem ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "alter table tbTransferPrn add column sync int(2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbTransferPrn ADD COLUMN fiDataSource TINYINT(4) DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN cycle int DEFAULT 1;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE unfinish_task ADD COLUMN cycle_count int DEFAULT 0;");

            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN subTotal decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN discountAmount decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN couponAmount decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN deliveryFee decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN fdServiceAmt decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tempapporder ADD COLUMN boxFee decimal(18,2) DEFAULT 0;");
            DBTools.exeSqlWithoutException(db, "DROP table jobstack");

            //转菜信息
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellOrderItem ADD COLUMN mergedItemInfo varchar(50) DEFAULT NULL; ");
            //换桌或转菜完结信息
            DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSell ADD COLUMN mergedOrderInfo varchar(50) DEFAULT NULL; ");

            //add 网络订单菜品明细库
            String sql = "CREATE TABLE IF NOT EXISTS tempapporderdetails (\n" +
                    "              orderId varchar(36) NOT NULL,\n" +
                    "              orderDetailId varchar(30),\n" +
                    "              parentID int(11) DEFAULT 0,\n" +
                    "              itemName decimal(18,2) DEFAULT 0,\n" +
                    "              itemNum decimal(18,2) DEFAULT 0,\n" +
                    "              itemPrice decimal(18,2) DEFAULT 0,\n" +
                    "              totalItemPrice decimal(18,2) DEFAULT 0,\n" +
                    "              type int(11) ,\n" +
                    "              body varchar(30),\n" +
                    "              PRIMARY KEY ('orderId', 'orderDetailId'))";
            DBTools.exeSqlWithoutException(db, sql);

            //版本升级数据兼容--网络订单迁移
//            new LowThread(new Runnable() {
//                @Override
//                public void run() {
            Cursor cursor = null;
            try {
                //1、查询当前营业日期下，所有未交班订单的菜品
                cursor = db.rawQuery("select * from tempapporder ", null);
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        TempAppOrder tempAppOrder = JSON.parseObject(cursor.getString(cursor.getColumnIndex("body")), TempAppOrder.class);
                        if (tempAppOrder != null) {
                            if (!ListUtil.isEmpty(tempAppOrder.orderDetailList)) {
                                DBTools.exeSqlWithoutException(db, "delete from tempapporderdetails where orderId = '" + tempAppOrder.orderId + "'");
                                for (TempAppOrderDetail tempAppOrderDetail : tempAppOrder.orderDetailList) {
                                    if (tempAppOrderDetail != null) {
                                        tempAppOrderDetail.uniq = UUID.randomUUID().toString();

                                        if (!ListUtil.isEmpty(tempAppOrderDetail.modifiertypes)) {
                                            for (TempAppOrderModifier tempAppOrderModifier : tempAppOrderDetail.modifiertypes) {
                                                if (tempAppOrderModifier != null) {
                                                    tempAppOrderModifier.uniq = UUID.randomUUID().toString();

                                                    if (!ListUtil.isEmpty(tempAppOrderModifier.modifiers)) {
                                                        for (TempModifierDetail tempModifierDetail : tempAppOrderModifier.modifiers) {
                                                            if (tempModifierDetail != null) {
                                                                tempModifierDetail.uniq = UUID.randomUUID().toString();
                                                                DBTools.exeSqlWithoutException(db, "insert into tempapporderdetails values('" + tempAppOrder.orderId + "', '" + tempModifierDetail.uniq + "', '"
                                                                        + tempAppOrderModifier.uniq + "', '" + tempModifierDetail.modifierName + "', '" + tempModifierDetail.modifierNum + "', '" + tempModifierDetail.modifierPrice + "', " +
                                                                        " '" + tempModifierDetail.modifierPrice + "', '" + TempAppOrderConstant.MENU_TYPE_MODIFIER_DETAIL + "', '" + JSON.toJSONString(tempModifierDetail) + "' )");
                                                            }
                                                        }
                                                        tempAppOrderModifier.modifiers.clear();
                                                    }
                                                    DBTools.exeSqlWithoutException(db, "insert into tempapporderdetails values('" + tempAppOrder.orderId + "', '" + tempAppOrderModifier.uniq + "', '"
                                                            + tempAppOrderDetail.uniq + "', '" + tempAppOrderModifier.modifierTypeName + "', '1', '0', '0', '"
                                                            + (tempAppOrderModifier.isSet == 0 ? TempAppOrderConstant.MENU_TYPE_MODIFIER_SET : TempAppOrderConstant.MENU_TYPE_MODIFIER_INGREDIENT)
                                                            + "', '" + JSON.toJSONString(tempAppOrderModifier) + "' )");
                                                }
                                            }
                                            tempAppOrderDetail.modifiertypes.clear();
                                        }
                                        DBTools.exeSqlWithoutException(db, "insert into tempapporderdetails values('" + tempAppOrder.orderId + "', '" + tempAppOrderDetail.uniq + "', '-1', '" + tempAppOrderDetail.itemName + "', '" + tempAppOrderDetail.itemNum + "'," +
                                                " '" + tempAppOrderDetail.itemPrice + "', '" + tempAppOrderDetail.totalItemPrice + "', '"
                                                + TempAppOrderConstant.MENU_TYPE_NORMAL
                                                + "', '" + JSON.toJSONString(tempAppOrderDetail) + "' )");
                                    }
                                }
                                tempAppOrder.orderDetailList.clear();
                            }

                            //合计
                            BigDecimal subTotal = tempAppOrder.subTotal;
                            if (tempAppOrder.subTotal == null || tempAppOrder.subTotal.compareTo(BigDecimal.ZERO) <= 0) {
                                subTotal = tempAppOrder.total;
                            }
                            tempAppOrder.body = "";
                            DBTools.exeSqlWithoutException(db, "update tempapporder set subTotal = '" + subTotal + "', discountAmount = '" + tempAppOrder.discountAmount + "', couponAmount = '" + tempAppOrder.couponAmount + "', deliveryFee = '" + tempAppOrder.deliveryFee + "', fdServiceAmt = '" + tempAppOrder.fdServiceAmt + "', boxFee ='" + tempAppOrder.boxFee + "', body = '" + JSON.toJSONString(tempAppOrder) + "' where orderId = '" + tempAppOrder.orderId + "' ");
                        }
                    }
                }

            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }
//                }
//            }).start();

        }
    }

    /**
     * DBVersion升级到31
     *
     * @param serverDB boolean | 是否是业务中心db
     * @param db       SQLiteDatabase
     */
    protected static void updateV31(boolean serverDB, final SQLiteDatabase db) {

        //清除上次更新数据时间--必须重新拉数据
        DBTools.exeSqlWithoutException(db, "update meta set value = '0' where key = '2'");

        //菜品不同等级会员价表
        String sql = "CREATE TABLE IF NOT EXISTS tbmenuitemvipprice (\n" +
                "              Guid varchar(36) PRIMARY KEY  NOT NULL,\n" +
                "              fiItemCd int(11),\n" +
                "              fiVIPType int(11) DEFAULT 0,\n" +
                "              fdVIPPrice decimal(18,2) DEFAULT 0,\n" +
                "              fiOrderUintCd int(11) ,\n" +
                "              fsUpdateTime varchar(30),\n" +
                "              fsUpdateUserId varchar(20),\n" +
                "              fsUpdateUserName varchar(30),\n" +
                "              fsShopGUID varchar(80))";
        DBTools.exeSqlWithoutException(db, sql);
        //新增点配料菜最大份数
        DBTools.exeSqlWithoutException(db, "alter table tbmenuitem add column fiMax int(11) DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "DROP table datacache");
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS datacache (key CHAR , value TEXT,info TEXT, type int(4) DEFAULT 0, biz_key TEXT,createtime TEXT,updatetime TEXT,PRIMARY KEY ('key','type'))");

        //菜品要求是否显著显示 0:否,1:是
        DBTools.exeSqlWithoutException(db, "alter table tbaskgp add column fiIsShow int(11) NOT NULL DEFAULT '0';");
        //添加优惠的开始时间和结束时间
        DBTools.exeSqlWithoutException(db, "alter table tbbargain add column fscustomendtime TEXT");
        DBTools.exeSqlWithoutException(db, "alter table tbbargain add column fscustomstarttime TEXT");

        if (serverDB) {
            //显著要求
            DBTools.exeSqlWithoutException(db, "alter table tbSellOrderItem add column fsSpecialNote varchar(100) DEFAULT '';");
            //普通要求
            DBTools.exeSqlWithoutException(db, "alter table tbSellOrderItem add column fsGeneralNote varchar(100) DEFAULT '';");
            DBTools.exeSqlWithoutException(db, "alter table tbSellOrderItem add column hassub int DEFAULT 0;");

            //tbsell 加公司税号字段
            DBTools.exeSqlWithoutException(db, "alter table tbSell add column fsdutyparagraph varchar(50) DEFAULT '';");

            //修改报表存储type 为 打印uri
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_SALE + "' where type = '4'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_DAILY + "' where type = '6'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_VOID + "' where type = '7'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_GIFT + "' where type = '8'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_MAX_SALE_QUANTITY + "' where type = '10'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_MAX_SALE_PRICE + "' where type = '11'");
            DBTools.exeSqlWithoutException(db, "update dailyReport set type = '" + ReportConsrance.REPORT_DEPT + "' where type = '12'");

            //版本升级数据兼容
            Cursor cursor = null;
            try {
                String fsShopGuid = "";
                String businessDate = "";
                cursor = db.rawQuery("select key, value from meta where key in ('104', '105')", null);
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        String key = cursor.getString(cursor.getColumnIndex("key"));
                        if (TextUtils.equals(key, META.SHOPID + "")) {
                            fsShopGuid = cursor.getString(cursor.getColumnIndex("value"));
                        } else {
                            businessDate = cursor.getString(cursor.getColumnIndex("value"));
                        }
                    }
                }

                if (TextUtils.isEmpty(businessDate) || TextUtils.isEmpty(fsShopGuid)) {
                    return;
                }
                //1、查询当前营业日期下，所有未交班订单的菜品
                cursor = db.rawQuery("select * from order_menu_cache where order_id in (select order_id from order_cache where  business_date = '" + businessDate + "' and order_id not in (select order_id from order_pay_cache where locked = '1' and business_date = '" + businessDate + "'))", null);

                if (cursor != null) {
                    Boolean transform;
                    while (cursor.moveToNext()) {
                        transform = false;
                        MenuItem menu = JSON.parseObject(cursor.getString(cursor.getColumnIndex("value")), MenuItem.class);
                        if (!ListUtil.isEmpty(menu.menuBiz.selectedPackageItem)) {
                            menu.menuBiz.selectedPackageItems.clear();
                            for (MenuExtra menuExtra : menu.menuBiz.selectedPackageItem) {
                                //套餐
                                if (menuExtra.type == MenuExtraType.PACKAGE) {
                                    for (MenuExtraItem menuExtraItem : menuExtra.itemList) {
                                        if (menuExtraItem != null && menuExtraItem.selected) {
                                            //取菜品规格
                                            UnitModel unitModel = new UnitModel();
                                            unitModel.fiItemCd = menuExtraItem.id;
                                            unitModel.fiOrderUintCd = menuExtraItem.unitID;
                                            unitModel.fiInitCount = menuExtraItem.tempNum == null ? 1 : menuExtraItem.tempNum.intValue();
                                            unitModel.fdSalePrice = menuExtraItem.price;
                                            unitModel.fsOrderUint = "份";

                                            MenuItem packageItem = new MenuItem();
                                            packageItem.menuBiz = new MenuBiz();
                                            packageItem.itemID = menuExtraItem.id;
                                            packageItem.currentUnit = unitModel;
                                            packageItem.categoryCode = menuExtraItem.groupIDFather + "";
                                            packageItem.name = menuExtraItem.name;
                                            packageItem.name2 = menuExtraItem.name;
                                            packageItem.currentUnit.fdVIPPrice = menuExtraItem.fdVIPPrice;
                                            packageItem.currentUnit.fdSalePrice = menuExtraItem.increasePrice;
                                            packageItem.menuBiz.uniq = menuExtraItem.uniq;
                                            packageItem.menuBiz.buyNum = menuExtraItem.num;
                                            packageItem.currentUnit.fiInitCount = menuExtraItem.tempNum == null ? 0 : menuExtraItem.tempNum.intValue();
                                            packageItem.menuBiz.isDefault = menuExtraItem.isDefault;
                                            packageItem.menuBiz.fiHurryTimes = menu.menuBiz.fiHurryTimes;
                                            menu.menuBiz.selectedPackageItems.add(packageItem);
                                        }
                                    }
                                    transform = true;
                                }
                            }
                        }

                        if (transform) {
                            String orderId = cursor.getString(cursor.getColumnIndex("order_id"));
                            DBTools.exeSqlWithoutException(db, "update order_menu_cache set value='" + JSON.toJSONString(menu) + "' where order_id='" + orderId + "' and uniq = '" + menu.menuBiz.uniq + "'");
                        }
                    }
                }

            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }

        }
    }

    public static void updateV30(final SQLiteDatabase db, boolean bizCenter) {
        //套餐会员价
        DBTools.exeSqlWithoutException(db, "alter table tbmenuitemsetsidedtl add column fdVIPDifference decimal(18,2) NOT NULL DEFAULT '0.00';");

        if (bizCenter) {
            //消息新增区域ID，桌台ID，订单号字段
            DBTools.exeSqlWithoutException(db, "alter table message add column mareaId varchar(20) NOT NULL DEFAULT '';");
            DBTools.exeSqlWithoutException(db, "alter table message add column mtableId varchar(20) NOT NULL DEFAULT '';");
            DBTools.exeSqlWithoutException(db, "alter table message add column sellNo varchar(20) NOT NULL DEFAULT '';");

//            new LowThread(new Runnable() {
//                @Override
//                public void run() {
            Cursor cursor = null;
            try {
                cursor = db.rawQuery("select * from message ", null);

                if (cursor != null) {
                    while (cursor.moveToNext()) {

                        String msgId = cursor.getString(cursor.getColumnIndex("msgId"));    //消息ID
                        String msgDes = cursor.getString(cursor.getColumnIndex("msgDes"));    //区域ID
                        String standBy2 = cursor.getString(cursor.getColumnIndex("standBy2")); //桌台ID
                        String msgHead = cursor.getString(cursor.getColumnIndex("msgHead")); //桌台ID
                        String msgType = cursor.getString(cursor.getColumnIndex("msgType")); //消息类型
                        if (TextUtils.equals(msgType, "4")) {
                            DBTools.exeSqlWithoutException(db, "update message set mtableId = '" + standBy2 + "', sellNo = '" + msgHead + "'  where msgId='" + msgId + "'");
                        } else {
                            DBTools.exeSqlWithoutException(db, "update message set mareaId='" + msgDes + "', mtableId = '" + standBy2 + "' where msgId='" + msgId + "'");
                        }
                    }
                }

            } catch (Exception e) {
                LogUtil.logError(e);
            } finally {
                DBSimpleUtil.closeCursor(cursor);
            }
//                }
//            }).start();
        }

    }

    public static void updateV29(final SQLiteDatabase db) {
        //消息中心表新增关联ID字段
        DBTools.exeSqlWithoutException(db, "alter table message add column correlationId TEXT DEFAULT '';");
    }

    private static void updateV28(final SQLiteDatabase db) {

        //新增表'门店服务关联表'
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbshopservice (\n" +
                "  fsGuid char(36) NOT NULL ,\n" +
                "  fiServiceId int(11) NOT NULL DEFAULT '1' ,\n" +
                "  fsShopGUID varchar(80) DEFAULT '' ,\n" +
                "  fiStatus int(11) DEFAULT '1' ,\n" +
                "  fsUpdateTime timestamp  DEFAULT NULL ,\n" +
                "  fsUpdateUserId varchar(20) DEFAULT '' ,\n" +
                "  fsUpdateUserName varchar(30) DEFAULT '' ,\n" +
                "  PRIMARY KEY ('fsGuid', 'fsShopGUID','fiServiceId')\n" +
                ") ;");
        DBTools.exeSqlWithoutException(db, "alter table unfinish_task add column  trace1 TEXT DEFAULT NULL;");
        DBTools.exeSqlWithoutException(db, "alter table unfinish_task add column  trace2 TEXT DEFAULT NULL;");
        DBTools.exeSqlWithoutException(db, "alter table order_cache add column  antiPayCount int DEFAULT 0;");

        DBTools.exeSqlWithoutException(db, "update tbmenuitem set fiIsSetDtlPrn = '2' where fiIsPrn = '1' and fiIsSetDtlPrn = '0' ");

        try {
            DBTools.exeSqlWithoutException(db, "alter table tbSellOrderItem add column  fsDataSrckind char(10) DEFAULT NULL;");
            DBTools.exeSqlWithoutException(db, "alter table tbSellOrderItem add column  fsSrcVerno char(10) DEFAULT NULL;");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateV27(final SQLiteDatabase db) {
        //公告表加是否提醒字段
        DBTools.exeSqlWithoutException(db, "alter table tbnotice add column alert int DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "alter table tbnotice add column fiType int DEFAULT 1;");
    }


    private static void updateV26(final SQLiteDatabase db) {
        //order_cache表加快餐的牌号字段
        DBTools.exeSqlWithoutException(db, "alter table order_cache add column mealNumber varchar(10) DEFAULT '';");

        new LowThread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    cursor = db.rawQuery("select order_id, value from order_cache where fiSellType='1'", null);

                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("value");
                        int orderIdValue = cursor.getColumnIndex("order_id");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            String orderId = cursor.getString(orderIdValue);
                            JSONObject order = null;
                            if (!TextUtils.isEmpty(value)) {
                                order = JSON.parseObject(value, JSONObject.class);
                            }

                            if (order != null) {
                                String mealNumber = order.getString("mealNumber");
                                DBTools.exeSqlWithoutException(db, "update order_cache set mealNumber='" + mealNumber + "' where order_id='" + orderId + "'");
                            }
                        }
                    }

                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
            }
        }).start();

    }

    private static void updateV25(final SQLiteDatabase db) {
        //lxx 17-05-22 order_cache 新增订单来源字段
        DBTools.exeSqlWithoutException(db, "alter table order_cache add column fsBillSourceId varchar(10) DEFAULT '1';");
        //预制订单来源数据
        new LowThread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    cursor = db.rawQuery("select count(*) from tbBillSource", null);

                    if (cursor != null) {
                        if (cursor.moveToFirst()) {
                            int cursorInt = cursor.getInt(0);
                            if (cursorInt <= 0) {
                                String time = DateUtil.getCurrentTime();
                                DBTools.exeSqlWithoutException(db, "insert into tbBillSource values(1, '本店', '1', '1', '1', '" + time + "', 'admin', '管理员', '')");
                                DBTools.exeSqlWithoutException(db, "insert into tbBillSource values(2, '饿了么', '1', '1', '1', '" + time + "', 'admin', '管理员', '')");
                                DBTools.exeSqlWithoutException(db, "insert into tbBillSource values(3, '美团外卖', '1', '1', '1', '" + time + "', 'admin', '管理员', '')");
                                DBTools.exeSqlWithoutException(db, "insert into tbBillSource values(4, '百度外卖', '1', '1', '1', '" + time + "', 'admin', '管理员', '')");
                            }
                        }
                    }

                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
            }
        }).start();

    }


    private static void updateV24(final SQLiteDatabase db) {
        //新增打赏
        DBTools.exeSqlWithoutException(db, "alter table tbSell add column fsrewardinfo varchar(50) DEFAULT NULL;");//打赏信息
        DBTools.exeSqlWithoutException(db, "alter table order_cache add column rewardinfo varchar(50) DEFAULT NULL;");//打赏信息
    }

    private static void updateV23(final SQLiteDatabase db) {
        //lxx 17-04-06 菜品规格表新增'起点数量','成本价'
        DBTools.exeSqlWithoutException(db, "alter table tbmenuitemuint add column fiInitCount int(11) DEFAULT NULL;");
        DBTools.exeSqlWithoutException(db, "alter table tbmenuitemuint add column fdCostPrice decimal(18,2) DEFAULT 0;");
        //lxx 17-04-07 报表中加字段区分正餐单和快餐单 0:正餐， 1：快餐
        DBTools.exeSqlWithoutException(db, "alter table tbsell add column fiSellType int(11) DEFAULT 0;");
        DBTools.exeSqlWithoutException(db, "alter table order_cache add column fiSellType int(11) DEFAULT 0;");
        //快餐订单业务表
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS fastfood_order_biz ( \n" +
                "order_id text PRIMARY KEY NOT NULL, \n" +
                "fastfood_biz_status integer DEFAULT(-1), \n" +
                "opentime varchar(30) DEFAULT (NULL) , \n" +
                "lockedStatus INTEGER DEFAULT 0, \n" +
                "lockedUserID varchar(20) DEFAULT null, \n" +
                "lockedUserName varchar(50) DEFAULT null,  \n" +
                "lockedHostId varchar(30) DEFAULT null, " +
                "business_date  varchar(8) DEFAULT NULL  )");
        DBTools.exeSqlWithoutException(db, "ALTER TABLE tbSellReceive ADD COLUMN isCouponMoney INTEGER DEFAULT 0; --COMMENT '是否满减'");
    }

    private static void updateV22(final SQLiteDatabase db) {
        //lxx 17-03-23 网络订单表新增日期字段
        DBTools.exeSqlWithoutException(db, "alter table tempapporder add column date varchar(30) DEFAULT NULL;");
        //创建订单菜品的缓存表，让菜品从order_cache里剥离出来
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS 'order_menu_cache' ('uniq' VARCHAR(50) PRIMARY KEY  NOT NULL  UNIQUE ,'indexnum' INTEGER default 0, 'order_id' varchar(20), 'orderseq' INTEGER default 0, 'uniq_m' varchar(50), 'value' TEXT, 'fiItemMakeState' INTEGER default 0, 'fiHurryTimes' INTEGER default 0)");

    }

    private static void updateV21(final SQLiteDatabase db) {
        new LowThread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.SIMPLIFIED_CHINESE);
                    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd", Locale.SIMPLIFIED_CHINESE);
                    cursor = db.rawQuery("select value from meta where key='105'", null);

                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("value");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (value.length() == 8) {
                                String convertedCurrentDate = sdf.format(sdf2.parse(value));
                                DBTools.exeSqlWithoutException(db, "update meta set value='" + convertedCurrentDate + "' where key='105'");
                            }
                        }
                    }
                    cursor = db.rawQuery("select business_date from order_cache where business_date not like '%-%'", null);

                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("business_date");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (value.length() == 8) {
                                String convertedCurrentDate = sdf.format(sdf2.parse(value));
                                DBTools.exeSqlWithoutException(db, "update order_cache set business_date='" + convertedCurrentDate + "' where business_date='" + value + "'");
                            }
                        }
                    }
                    cursor = db.rawQuery("select business_date from order_pay_cache where business_date not like '%-%'", null);

                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("business_date");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (value.length() == 8) {
                                String convertedCurrentDate = sdf.format(sdf2.parse(value));
                                DBTools.exeSqlWithoutException(db, "update order_pay_cache set business_date='" + convertedCurrentDate + "' where business_date='" + value + "'");
                            }
                        }
                    }
//                    cursor = db.rawQuery("select fsDate from tbPrintTask where fsDate not like '%-%'", null);
//
//                    if (cursor != null) {
//                        int indexValue = cursor.getColumnIndex("fsDate");
//
//                        while (cursor.moveToNext()) {
//                            String value = cursor.getString(indexValue);
//                            if (value.length() == 8) {
//                                String convertedCurrentDate = sdf.format(sdf2.parse(value));
//                                DBTools.exeSqlWithoutException(db, "update tbPrintTask set fsDate='" + convertedCurrentDate + "' where fsDate='" + value + "'");
//                            }
//                        }
//                    }

                    cursor = db.rawQuery("select businessdate from dailyReport where businessdate not like '%-%'", null);

                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("businessdate");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (value.length() == 8) {
                                String convertedCurrentDate = sdf.format(sdf2.parse(value));
                                DBTools.exeSqlWithoutException(db, "update dailyReport set businessdate='" + convertedCurrentDate + "' where businessdate='" + value + "'");
                            }
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
            }
        }).start();
    }

    private static void updateV20(final SQLiteDatabase db) {
        new LowThread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    cursor = db.rawQuery("select value from order_cache ", null);
                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("value");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (!TextUtils.isEmpty(value)) {
                                OrderCache cache = JSON.parseObject(value, OrderCache.class);
                                ContentValues contentValues = new ContentValues();
                                contentValues.put("order_id", cache.orderID);
                                contentValues.put("order_status", cache.orderStatus);
                                contentValues.put("total_price", cache.optTotalPrice().toPlainString());
                                contentValues.put("person_num", cache.personNum);
                                contentValues.put("create_time", cache.createTime);
                                contentValues.put("tableID", cache.fsmtableid);
                                contentValues.put("tableName", cache.fsmtablename);
                                contentValues.put("business_date", cache.businessDate);
                                contentValues.put("is_member", cache.isMember ? 1 : 0);
                                contentValues.put("member_info", cache.memberInfoS != null ? JSON.toJSONString(cache.memberInfoS) : "");

                                db.update("order_cache", contentValues, "order_id='" + cache.orderID + "'", null);
                            }
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }

                try {
                    cursor = db.rawQuery("select value from order_pay_cache where business_date=(select value from meta where key='105')", null);
                    if (cursor != null) {
                        int indexValue = cursor.getColumnIndex("value");

                        while (cursor.moveToNext()) {
                            String value = cursor.getString(indexValue);
                            if (!TextUtils.isEmpty(value)) {
                                PaySession session = JSON.parseObject(value, PaySession.class);
                                if (session == null) {
                                    continue;
                                }
                                OrderCache cache = session.order;
                                if (cache != null) {
                                    ContentValues contentValues = new ContentValues();
                                    contentValues.put("order_id", cache.orderID);
                                    contentValues.put("order_status", cache.orderStatus);
                                    contentValues.put("total_price", cache.optTotalPrice().toPlainString());
                                    contentValues.put("person_num", cache.personNum);
                                    contentValues.put("create_time", cache.createTime);
                                    contentValues.put("tableID", cache.fsmtableid);
                                    contentValues.put("tableName", cache.fsmtablename);
                                    contentValues.put("business_date", cache.businessDate);
                                    contentValues.put("is_member", cache.isMember ? 1 : 0);
                                    contentValues.put("member_info", cache.memberInfoS != null ? JSON.toJSONString(cache.memberInfoS) : "");

                                    db.update("order_cache", contentValues, "order_id='" + cache.orderID + "'", null);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
            }
        }).start();
    }

    /**
     * 表结构修改，将tbsellorder的fiID去掉，tbPrintTask的fiID不再设为主键
     *
     * @param db SQLiteDatabase
     */
    private static void transSellOrderItem(final SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "alter table tbsellorder rename to tbsellordertemp");

        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbsellorder(fsSellNo VARCHAR(20) NOT NULL,fiOrderSeq int NOT NULL,fsSellDate varchar(10) NOT NULL,fiOrderCls int NOT NULL,fiOrderSte int NOT NULL,fsNote VARCHAR(250),fsCreateTime VARCHAR(20) NOT NULL,fsCreateUserId VARCHAR(20),fsCreateUserName VARCHAR(30),fsUpdateTime VARCHAR(20) NOT NULL,fsShopGUID VARCHAR(80) NOT NULL,lver integer NOT NULL  DEFAULT (1) ,pver integer NOT NULL  DEFAULT (0) ,iupcount integer NOT NULL  DEFAULT (0),PRIMARY KEY (fsSellNo,fiOrderSeq,fsShopGUID))");
        //修改打印任务表的主键
        DBTools.exeSqlWithoutException(db, "alter table tbPrintTask rename to tbPrintTaskTemp");
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbPrintTask\n" +
                "(\n" +
                "fiID   Integer DEFAULT 0,\n" +
                "fiID_Server  Integer DEFAULT 0,     \n" +
                "fiPrintNo  int   NOT NULL, \n" +
                "fsCreateTime  VARCHAR(20)  NOT NULL,\n" +
                "fsCreateUserName VARCHAR(30) ,\n" +
                "fsHostId  VARCHAR(30) ,\n" +
                "fsDeptId  VARCHAR(20) ,\n" +
                "fsDeptName  VARCHAR(100),\n" +
                "fsPrinterName  VARCHAR(100)  NOT NULL,\n" +
                "fsReportId  VARCHAR(20)  ,\n" +
                "fsReportName  VARCHAR(50) ,\n" +
                "fsPrnData  text ,\n" +
                "fsPrnData2  text ,\n" +
                "fiTaskType  int   NOT NULL,\n" +
                "fiPrnDataType  int  ,  \n" +
                "fsRemark  VARCHAR(50)  , \n" +
                "fsSellNo  VARCHAR(20)  , \n" +
                "fsOtherNo  VARCHAR(20) ,  \n" +
                "fsDate   VARCHAR(10)  , \n" +
                "fiStatus  int   NOT NULL,\n" +
                "fiErrCount   int   ,  \n" +
                "fsFinishTime  VARCHAR(20) ,\n" +
                "fsPrnOkAction  text, \n" +
                "uri TEXT, \n" +
                "fiRetry INTEGER, \n" +
                "fiPaperSize INTEGER, \n" +
                "fsTaskDetail TEXT, \n" +
                "is_backup_printer Integer DEFAULT 0, \n" +
                "fsbakprintername VARCHAR(100),\n" +
                "CONSTRAINT pk_tbPrintTask PRIMARY KEY(fiPrintNo,fsHostId)\n" +
                ")");
        DBTools.exeSqlWithoutException(db, "drop table tbPrintTaskTemp");
        DBTools.exeSqlWithoutException(db, "alter table tbsellreceive rename to tbsellreceiveTemp");
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbsellreceive (" +
                "fiindex serial NOT NULL," +
                "fsSellNo varchar(20) NOT NULL," +
                "fsSellDate varchar(10) NOT NULL," +
                "fsCheckBillNo varchar(20) NOT NULL," +
                "fiSeq int NOT NULL," +
                "fiPaymentType int NOT NULL," +
                "fspaymenttypename varchar(30)," +
                "fsShopGUID varchar(80) NOT NULL," +
                "fiStatus int NOT NULL," +
                "fsPaymentId varchar(20) NOT NULL," +
                "fspaymentname varchar(30)," +
                "fdForeignMoney decimal(18,2) NOT NULL," +
                "fdExchangeRate decimal(18,2) NOT NULL," +
                "fdPayMoney decimal(18,2) NOT NULL," +
                "fdReceMoney decimal(18,2) NOT NULL," +
                "fsMiscno text," +
                "fiIsCalcPaid int NOT NULL," +
                "fiIsCalcInvoice int NOT NULL," +
                "fsNote varchar(250) DEFAULT(NULL)," +
                "fsHostId varchar(30) DEFAULT(NULL)," +
                "fsCreateTime varchar(20) NOT NULL," +
                "fsCreateUserId varchar(20) NOT NULL," +
                "fsCreateUserName varchar(20) NOT NULL," +
                "fsUpdateTime varchar(20) DEFAULT(NULL)," +
                "fsUpdateUserId varchar(20) DEFAULT(NULL)," +
                "fsUpdateUserName varchar(30) DEFAULT(NULL)," +
                "lver integer NOT NULL DEFAULT(1)," +
                "pver integer NOT NULL DEFAULT(0)," +
                "iupcount integer NOT NULL DEFAULT(0)," +
                "fsbackup0 text," +
                "fsbackup1 text," +
                "fsbackup2 text, isRapidPay INTEGER DEFAULT 0," +
                "  PRIMARY KEY(fsSellNo,fsCheckBillNo,fiSeq,fiPaymentType,fsShopGUID,fsPaymentId)" +
                ")");
        new LowThread(new Runnable() {
            @Override
            public void run() {
                try {
                    DBTools.exeSqlWithoutException(db, "INSERT INTO tbsellorder SELECT fsSellNo,fiOrderSeq,fsSellDate,fiOrderCls,fiOrderSte,fsNote,fsCreateTime,fsCreateUserId,fsCreateUserName,fsUpdateTime,fsShopGUID,lver,pver,iupcount FROM tbsellordertemp");
                    DBTools.exeSqlWithoutException(db, "drop table tbsellordertemp");
                    DBTools.exeSqlWithoutException(db, "INSERT INTO tbsellreceive SELECT * FROM tbsellreceiveTemp");
                    DBTools.exeSqlWithoutException(db, "drop table tbsellreceiveTemp");
                } catch (Exception e) {
                    LogUtil.logError(e);
                }
            }
        }).start();
    }

    /**
     * 检查订单表的多部门打印的字段
     *
     * @param db SQLiteDatabase
     */
    private static void checkMultiDeptOrder(SQLiteDatabase db) {
        Cursor cursor = null;

        boolean exist = false;
        boolean existMul = false;

        try {
            cursor = db.rawQuery("select * from tbsellorderitem limit 0", null);
            if (cursor != null) {
                int indexSetDtl = cursor.getColumnIndex("fiIsSetDtlPrn");
                int indexIsMul = cursor.getColumnIndex("fiIsMulDept");

                cursor.moveToNext();
                if (indexIsMul >= 0) {
                    existMul = true;
                }
                if (indexSetDtl >= 0) {
                    exist = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        if (!exist) {
            try {
                DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column fiIsSetDtlPrn int DEFAULT 2 ; --COMMENT '是否套餐头部门打印(1=套餐头部门/2=明细部门)'");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        if (!existMul) {
            try {
                DBTools.exeSqlWithoutException(db, "alter table tbsellorderitem add column fiIsMulDept int DEFAULT 0 ; --COMMENT '是否为多制作部门(0=否/1=是)'");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        checkMultiDeptMenu(db);
    }

    /**
     * 判断列是否存在
     *
     * @param db        SQLiteDatabase
     * @param tableName String
     * @param fieldName String
     * @return boolean | true： 列存在；false：列不存在
     */
    public static boolean isFieldExist(SQLiteDatabase db, String tableName, String fieldName) {
        Cursor cursor = null;

        boolean exist = false;

        try {
            cursor = db.rawQuery("select * from " + tableName + " limit 0", null);
            if (cursor != null) {
                int index = cursor.getColumnIndex(fieldName);

                cursor.moveToNext();
                if (index >= 0) {
                    exist = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        return exist;
    }

    /**
     * 检查菜品表的多部门打印的字段
     *
     * @param db SQLiteDatabase
     */
    private static void checkMultiDeptMenu(SQLiteDatabase db) {
        Cursor cursor = null;

        boolean existMul = false;

        try {
            cursor = db.rawQuery("select * from tbMenuItem limit 0", null);
            if (cursor != null) {
                int indexIsMul = cursor.getColumnIndex("fiIsMulDept");

                cursor.moveToNext();
                if (indexIsMul >= 0) {
                    existMul = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }

        if (!existMul) {
            try {
                DBTools.exeSqlWithoutException(db, "alter table tbMenuItem add column fiIsMulDept int DEFAULT 0 ; --COMMENT '是否为多制作部门(0=否/1=是)'");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        checkMultiDeptTable(db);
    }

    /**
     * 检查多部门打印的表
     *
     * @param db SQLiteDatabase
     */
    private static void checkMultiDeptTable(SQLiteDatabase db) {
        Cursor cursor = null;
        boolean exist = false;
        try {
            cursor = db.rawQuery("SELECT  count(*) as count  FROM sqlite_master WHERE type='table' AND name ='tbMenuItemMulDept' ", null);
            if (cursor != null) {
                int indexHostID = cursor.getColumnIndex("count");
                cursor.moveToNext();
                int result = cursor.getInt(indexHostID);
                if (result > 0) {
                    exist = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        if (!exist) {
            try {
                DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbMenuItemMulDept " +
                        "(" +
                        "fiMulDeptCd         int          NOT NULL  " +
                        ",fiItemCd           int             NOT NULL" +
                        ",fsShopGUID         VARCHAR(80)     NOT NULL " +
                        ",fsDeptId           VARCHAR(20)        " +
                        ",fsMAreaId          VARCHAR(20)       " +
                        ",fiStatus           int              " +
                        ",fsUpdateTime       VARCHAR(20)      " +
                        ",fsUpdateUserId     VARCHAR(20)           " +
                        ",fsUpdateUserName   VARCHAR(30)  " +
                        ",CONSTRAINT pk_tbMenuItemMulDept PRIMARY KEY(fiMulDeptCd)" +
                        ")");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }

    private static void checkPayCacheTableFull(SQLiteDatabase db) {
        Cursor cursor = null;
        cursor = db.rawQuery("select * from order_pay_cache limit 0", null);
        boolean exist = false;
        try {
            if (cursor != null) {
                int indexHostID = cursor.getColumnIndex("waiterid");
                cursor.moveToNext();
                if (indexHostID >= 0) {
                    exist = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        if (!exist) {
            try {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN waiterid CHAR");
                DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN totalCalcPaied  NUMERIC");
                DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN waitername TEXT ");
                DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN shiftid varchar(20)  ");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }

    private static String getHistoryHost(SQLiteDatabase db) {
        String sql = "select * from tbhost where  fiStatus=1 order by (case when fiHostCls='12' then 0 else 1 end) asc,fiHostCls  Desc,fsPrinterName desc";

        Cursor cursor = null;
        cursor = db.rawQuery(sql, null);
        String hostID = "";
        try {
            if (cursor != null) {
                int indexHostID = cursor.getColumnIndex("fsHostId");
                int indexPrinter = cursor.getColumnIndex("fsPrinterName");

                while (cursor.moveToNext()) {
                    String tempHostID = cursor.getString(indexHostID);
                    String printerName = cursor.getString(indexPrinter);
                    if (!TextUtils.isEmpty(printerName)) {
                        hostID = tempHostID;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return hostID;
    }

    public static void checkDataHistoryUpdate(SQLiteDatabase db) {
//        String sql = "select time,data from data_history where data is not null";
//        Cursor cursor = null;
//        cursor = db.rawQuery(sql, null);
//        String sqlUpdate = "update data_history set data_path='%1$s', data='' where time='%2$s'";
//
//        try {
//            if (cursor != null) {
//                int indexTime = cursor.getColumnIndex("time");
//                int indexData = cursor.getColumnIndex("data");
//                db.beginTransaction();
//
//                while (cursor.moveToNext()) {
//                    String time = cursor.getString(indexTime);
//                    String data = cursor.getString(indexData);
//                    String path = DownLoadDataProcessor.writeDataToIO(time, data);
//                    DBTools.exeSqlWithoutException(db, String.format(sqlUpdate, path, time));
//                }
//                db.setTransactionSuccessful();
//            }
//        } catch (Exception e) {
//            LogUtil.logError(e);
//        } finally {
//            DBSimpleUtil.closeCursor(cursor);
//            if (db.inTransaction()) {
//                db.endTransaction();
//            }
//        }
    }

    private static void checkPaySessionSynced(SQLiteDatabase db) {
        Cursor cursor = null;

        boolean existMul = false;

        try {
            cursor = db.rawQuery("select * from order_pay_cache limit 0", null);
            if (cursor != null) {
                int indexIsMul = cursor.getColumnIndex("synced");

                cursor.moveToNext();
                if (indexIsMul >= 0) {
                    existMul = true;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }

        if (!existMul) {
            try {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE order_pay_cache ADD COLUMN 'synced' INTEGER DEFAULT 0");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }

    /**
     * 检查桌台标志位、额外订单信息的字段
     *
     * @param db SQLiteDatabase
     */
    private static void checkTableFlag(SQLiteDatabase db) {

        boolean existFlag = isFieldExist(db, "tbmtable", "flag");
        boolean existExtraOrder = isFieldExist(db, "tbmtable", "extra_order");

        if (!existFlag) {
            try {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmtable ADD COLUMN flag INTEGER DEFAULT 0; --COMMENT '桌台的标志位'");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        if (!existExtraOrder) {
            try {
                DBTools.exeSqlWithoutException(db, "ALTER TABLE tbmtable ADD COLUMN extra_order TEXT; --'桌台额外存储的订单信息(秒点订单用)'");
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }

    /**
     * 创建微信点单相关的表
     *
     * @param db
     */
    private static void creatTableWechat(SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS tbwechatorder (fsorderno varchar(20) PRIMARY KEY  NOT NULL ,fsopenid varchar(100) NOT NULL ,fscompanyguid varchar(80) DEFAULT (NULL) ," +
                "fsshopguid varchar(80) NOT NULL ,fsshopname text NOT NULL ,fisex int(11) DEFAULT (NULL) ,fsname varchar(100) NOT NULL ,fitag int(11) DEFAULT (NULL) ," +
                "fsaddress text NOT NULL ,fsmobile varchar(20) NOT NULL ,fidishwarenum int(11) DEFAULT (NULL) ,fiinvoice int(11) DEFAULT (NULL) ," +
                "fiinvoicetype int(11) DEFAULT (NULL) ,fsinvoicename text,fdcoupon decimal(18,2) DEFAULT (NULL) ," +
                "fdintegral decimal(18,2) DEFAULT (NULL) ,fddistribution decimal(18,2) DEFAULT (NULL) ,fdboxamount decimal(18,2) DEFAULT (NULL) ," +
                "fsarrivetime varchar(20) NOT NULL ,fspaytype varchar(2) DEFAULT (NULL) ,fdsellamount decimal(18,2) NOT NULL ," +
                "fdrealamount decimal(18,2) NOT NULL ,fistatus int(11) NOT NULL ,fsremark text,fsupdatetime varchar(20) NOT NULL ," +
                "fscreatetime varchar(20) NOT NULL ,localOrderId varchar(20) DEFAULT (null) )");

        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tbwechatorderitem` (\n" +
                "  `fsseqno` varchar(20) NOT NULL ,\n" +
                "  `fsorderno` varchar(20) NOT NULL ,\n" +
                "  `fsshopguid` varchar(80) NOT NULL ,\n" +
                "  `fsitemcode` varchar(20) NOT NULL ,\n" +
                "  `fsitemname` text NOT NULL ,\n" +
                "  `fiitemnum` int(11) NOT NULL ,\n" +
                "  `fdmemberamount` decimal(18,2) DEFAULT NULL ,\n" +
                "  `fdsellamount` decimal(18,2) DEFAULT NULL ,\n" +
                "  `fsactivityno` varchar(50) DEFAULT NULL ,\n" +
                "  `fddiscount` decimal(18,2) DEFAULT NULL ,\n" +
                "  `fddiscountrate` decimal(18,2) DEFAULT NULL,\n" +
                "  `fddiscountamount` decimal(18,2) DEFAULT NULL ,\n" +
                "  `fdsubtotal` decimal(18,2) DEFAULT NULL ,\n" +
                "  `fiactivitytype` int(11) DEFAULT NULL ,\n" +
                "  `fdrealamount` decimal(18,2) NOT NULL,\n" +
                "  `fipresentflag` int(11) DEFAULT NULL,\n" +
                "  `fimenuflag` int(11) DEFAULT NULL,\n" +
                "  `fsmenuguid` varchar(80) DEFAULT NULL ,\n" +
                "  `fsmenuseqno` varchar(30) DEFAULT NULL,\n" +
                "  `fsmenuname` varchar(50) DEFAULT NULL ,\n" +
                "  `fdaddprice` decimal(18,2) DEFAULT NULL,\n" +
                "  `fsstandardcode` varchar(20) DEFAULT NULL,\n" +
                "  `fsstandardname` varchar(50) DEFAULT NULL,\n" +
                "  `fspracticecode` varchar(20) DEFAULT NULL,\n" +
                "  `fspracticename` varchar(50) DEFAULT NULL,\n" +
                "  `fdpracticeamount` decimal(18,2) DEFAULT NULL,\n" +
                "  `fsremark` text ,\n" +
                "  `fsupdatetime` varchar(20) NOT NULL,\n" +
                "  `fscreatetime` varchar(20) NOT NULL,\n" +
                "  PRIMARY KEY (`fsseqno`,`fsorderno`)\n" +
                ") ");

        DBTools.exeSqlWithoutException(db, "CREATE TABLE IF NOT EXISTS `tbwechatpaydetail` (\n" +
                "  `fsseqno` varchar(20) NOT NULL,\n" +
                "  `fsorderno` varchar(20) NOT NULL ,\n" +
                "  `fstypeno` varchar(20) DEFAULT NULL,\n" +
                "  `fsshopguid` varchar(80) NOT NULL,\n" +
                "  `fspayno` varchar(50) DEFAULT NULL ,\n" +
                "  `fdpayamount` decimal(18,2) NOT NULL ,\n" +
                "  `fdsettleamount` decimal(18,2) DEFAULT NULL ,\n" +
                "  `ficount` int(11) DEFAULT NULL ,\n" +
                "  `fscode` varchar(20) DEFAULT NULL,\n" +
                "  `firealflag` int(11) DEFAULT NULL,\n" +
                "  `fipaytype` int(11) NOT NULL ,\n" +
                "  `fipaystate` int(11) NOT NULL,\n" +
                "  `fsupdatetime` varchar(20) NOT NULL,\n" +
                "  `fscreatetime` varchar(20) NOT NULL ,\n" +
                "  PRIMARY KEY (`fsseqno`,`fsorderno`,`fsshopguid`)\n" +
                ") \n");
    }

    /**
     * Version4升级到Version5的时候，给order_pay_cache新增的几个字段，没有赋值，如果商户在营业中升级了app，会导致这些数据没有班别信息，无法交班。
     * 此时，需要手动将对应信息从报表的数据里同步过来
     *
     * @param db SQLiteDatabase
     */
    private static void checkShiftID(SQLiteDatabase db) {
        DBTools.exeSqlWithoutException(db, "update order_pay_cache set shiftid=(select fsShiftId from tbSellCheck left join  order_pay_cache on tbSellCheck.fsSellNo=order_pay_cache.order_id where order_pay_cache.shiftid is null) where order_pay_cache.shiftid is null");
        DBTools.exeSqlWithoutException(db, "update order_pay_cache set waiterid=(select fsUpdateUserId from tbSellCheck left join  order_pay_cache on tbSellCheck.fsSellNo=order_pay_cache.order_id where order_pay_cache.waiterid is null) where order_pay_cache.waiterid is null");
        DBTools.exeSqlWithoutException(db, "update order_pay_cache set waitername=(select fsUpdateUserName from tbSellCheck left join  order_pay_cache on tbSellCheck.fsSellNo=order_pay_cache.order_id where order_pay_cache.waitername is null) where order_pay_cache.waitername is null");
    }

    /**
     * 检测是否由未上送的数据
     *
     * @param db SQLiteDatabase
     * @return boolean
     */
    private static boolean hasUnSyncedData(SQLiteDatabase db) {
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT count(*) as count FROM tbParamValue where lver>pver", null);
            if (cursor != null) {
                int indexIsMul = cursor.getColumnIndex("count");
                cursor.moveToNext();
                if (indexIsMul >= 0) {
                    return cursor.getInt(indexIsMul) > 0;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        try {
            List<String> tableList = new ArrayList<>();
            tableList.add("tbshop");
            tableList.add("tbHost");
            tableList.add("tbHostExternal");
            tableList.add("tbMArea");
            tableList.add("tbMtable");
            tableList.add("tbMenuCls");
            tableList.add("tbMenuItem");
            tableList.add("tbMenuItemUint");
            tableList.add("tbMenuItemSetSide");
            tableList.add("tbMenuItemSetSideDtl");
            tableList.add("tbDiscount");
            tableList.add("tbDiscountItem");
            tableList.add("tbAskGp");
            tableList.add("tbAsk");
            tableList.add("tbMenuItemAskGp");
            tableList.add("tbPayment");
            tableList.add("tbDept");
            tableList.add("tbUser");
            tableList.add("tbUserRole");
            tableList.add("tbPrinter");
            tableList.add("tbMenuItemMulDept");
            tableList.add("tbparamValue");

            String sql = "SELECT count(*) as count FROM %1$s where sync = '1'";
            for (String temp : tableList) {
                cursor = db.rawQuery(String.format(sql, temp), null);
                if (cursor != null) {
                    int count = cursor.getColumnIndex("count");

                    cursor.moveToNext();

                    if (count >= 0 && cursor.getInt(count) > 0) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        } finally {
            DBSimpleUtil.closeCursor(cursor);
        }
        return false;
    }

    /**
     * 版本升级，网络订单迁移到新库
     */
    private static void mergeNetOrderDatas() {
        List<TempAppOrder> tempAppOrderList = new ArrayList<>();
        List<TempAppOrder> tempAppOrders;

        LogUtil.log("网络订单迁移：mergeNetOrderDatas() 开始");
        if (!BindProcessor.isCurrentHostMain()) {
            LogUtil.log("网络订单迁移：非主站点  结束");
            return;
        }
        try {
            while (true) {
                tempAppOrderList.clear();
                String sql = "select * from tempapporder order by createTime desc limit 5";
                tempAppOrders = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TempAppOrder.class);
                if (ListUtil.isEmpty(tempAppOrders)) {

                    LogUtil.log("网络订单迁移：已经没有数据");
                    break;
                }

                LogUtil.log("网络订单迁移：数量：" + tempAppOrders.size());
                for (TempAppOrder appOrder : tempAppOrders) {
                    try {
                        if (appOrder == null) {
                            continue;
                        }
                        String body = appOrder.body;
                        int diningStatus = appOrder.diningStatus;
                        int orderStatus = appOrder.orderStatus;
                        int payStatus = appOrder.payStatus;
                        String orderTakeawaySource = appOrder.orderTakeawaySource;
                        String appOrderDate = appOrder.date;
                        appOrder = JSON.parseObject(body, TempAppOrder.class);
                        if (appOrder != null) {
                            appOrder.orderDetailList = getTempAppOrderDetailList(String.valueOf(appOrder.orderId));
                            appOrder.body = "";
                            appOrder.diningStatus = diningStatus;
                            appOrder.orderStatus = orderStatus;
                            appOrder.payStatus = payStatus;
                            appOrder.orderTakeawaySource = orderTakeawaySource;
                            appOrder.date = appOrderDate;
                            tempAppOrderList.add(appOrder);
                        }
                    } catch (Exception e) {
                        LogUtil.logError("网络订单转化异常：" + JSON.toJSONString(appOrder) + "   ----   错误信息：" + e.getMessage());
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tempapporder where orderId = '" + appOrder.orderId + "'");
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tempapporderdetails where orderId = '" + appOrder.orderId + "'");
                    }
                }

                for (TempAppOrder appOrder : tempAppOrderList) {
                    LogUtil.log("网络订单迁移：存入新库：orderId = " + appOrder.orderId);
                    NetOrder.saveTempAppOrder(appOrder);
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tempapporder where orderId = '" + appOrder.orderId + "'");
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from tempapporderdetails where orderId = '" + appOrder.orderId + "'");
                }


            }
        } catch (Exception e) {
            LogUtil.log("网络订单迁移：异常 " + e.getMessage());
        }
    }


    /**
     * 获取网络订单的菜品列表
     *
     * @param orderId String  订单ID
     * @return List<TempAppOrderDetail>
     */
    private static List<TempAppOrderDetail> getTempAppOrderDetailList(final String orderId) {
        List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tempapporderdetails where orderId='" + orderId + "' and type = '1' ");
        List<TempAppOrderDetail> itemList = new ArrayList<>();
        if (list != null && !ListUtil.isEmpty(list)) {
            for (JSONObject temp : list) {
                TempAppOrderDetail tempAppOrderDetail = JSON.parseObject(temp.getString("body"), TempAppOrderDetail.class);
                if (tempAppOrderDetail != null) {
                    itemList.add(tempAppOrderDetail);
                }
            }
        }

        List<JSONObject> tempModifierDetaiList;

        if (!ListUtil.isEmpty(itemList)) {
            for (TempAppOrderDetail tempAppOrderDetail : itemList) {
                if (tempAppOrderDetail != null) {
                    list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tempapporderdetails where orderId='" + orderId + "' and parentID = '" + tempAppOrderDetail.uniq + "' and type in ('2','3') ");
                    if (list != null && !ListUtil.isEmpty(list)) {
                        for (JSONObject temp : list) {
                            TempAppOrderModifier tempAppOrderModifier = JSON.parseObject(temp.getString("body"), TempAppOrderModifier.class);
                            if (tempAppOrderModifier != null) {
                                tempModifierDetaiList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tempapporderdetails where orderId='" + orderId + "' and parentID = '" + tempAppOrderModifier.uniq + "' and type = '4' ");
                                if (tempModifierDetaiList != null && !ListUtil.isEmpty(tempModifierDetaiList)) {
                                    for (JSONObject detailTemp : tempModifierDetaiList) {
                                        TempModifierDetail tempModifierDetail = JSON.parseObject(detailTemp.getString("body"), TempModifierDetail.class);
                                        if (tempModifierDetail != null) {
                                            tempAppOrderModifier.modifiers.add(tempModifierDetail);
                                        }
                                    }
                                }
                                tempAppOrderDetail.modifiertypes.add(tempAppOrderModifier);
                            }
                        }
                    }
                }
            }
        }
        return itemList;
    }
}