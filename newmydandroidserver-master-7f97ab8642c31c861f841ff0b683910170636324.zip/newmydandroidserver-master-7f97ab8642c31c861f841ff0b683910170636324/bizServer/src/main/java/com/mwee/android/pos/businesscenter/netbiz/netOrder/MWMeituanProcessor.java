package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.kds.utils.StringUtils;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderProcess;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadNetorderDataProcessor;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.model.MwOrder;
import com.mwee.android.pos.component.datasync.net.model.NetorderItemMappingRelationshipDBModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2018/10/29.
 */

public class MWMeituanProcessor {

    /**
     * 收到网络订单数据
     *
     * @param orderList
     */
    public static List<String> receiveOrder(List<MwOrder> orderList) {
        List<String> saveResult = new ArrayList<>();

        if (!ListUtil.isEmpty(orderList)) {
            int receiveResult;
            for (MwOrder mwOrder : orderList) {
                if (mwOrder == null) {
                    continue;
                }
                receiveResult = receiveOrder(mwOrder.getAppOrder());
                if (receiveResult == 1) {
                    LogUtil.logBusiness("虚拟打印机外卖 业务中心 已成功入库订单 orderId = " + mwOrder.getAppOrder().orderId);
                    saveResult.add(mwOrder.getPath());
                } else if (receiveResult == -1002) {
                    LogUtil.logBusiness("虚拟打印机外卖 业务中心 重复订单 orderId = " + mwOrder.getAppOrder().orderId);
                    saveResult.add(mwOrder.getPath());
                } else {
                    LogUtil.logBusiness("虚拟打印机外卖 业务中心 订单入库失败 orderId = " + mwOrder.getAppOrder().orderId, "异常编码：" + receiveResult);
                }
            }
        }

        return saveResult;
    }

    /**
     * 将网络订单入库、打印
     *
     * @param appOrder
     * @return int | 1：成功； 其他表示异常
     */
    public static int receiveOrder(TempAppOrder appOrder) {
        LogUtil.log("收到虚拟打印机外卖：" + JSON.toJSONString(appOrder));
        if (appOrder == null ||
                TextUtils.isEmpty(appOrder.orderId) ||
                ListUtil.isEmpty(appOrder.orderDetailList) ||
                !TextUtils.equals(appOrder.orderTakeawaySource, TakeAwaySource.MWMEITUAN)) {
            LogUtil.logBusiness("虚拟打印机外卖", "收到异常外卖订单" + JSON.toJSONString(appOrder));
            return -1001;
        }

        synchronized (ServerCache.getInstance().netOrderCache.optLock(appOrder.orderId)) {
            TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(appOrder.orderId);
            if (tempAppOrder != null) {
                LogUtil.logBusiness("虚拟打印机外卖", "中断外卖处理；原因：已处理过 订单号：" + appOrder.orderId);
                return -1002;
            }

            //找到外卖菜品与本地菜品的映射关系
            for (TempAppOrderDetail detail : appOrder.orderDetailList) {
                if (detail == null || !TextUtils.isEmpty(detail.itemCode)) {
                    continue;
                }
                checkAndMappingItem(detail);
            }

            //数据待上送
            appOrder.sync = 1;

            //将外卖订单入库
            int result = NetOrderProcess.writeTempappOrder(appOrder);
            if (result == 1) {
                //入库成功后--打印小票
                String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);

                PrintNetOrderUtil.printNetworkTackOutReceipt(appOrder, hostId, "虚拟外卖");

                //todo 外卖怎么进KDS
                PrintNetOrderUtil.printNetworkKDSReceipt(appOrder, hostId, "虚拟外卖");

                PrintNetOrderUtil.printNetworkCustomerReceipt(appOrder, hostId, "虚拟外卖", false);

                ServerCache.getInstance().netOrderCache.putNetOrderPrint(appOrder.orderId);
//                UploadNetorderDataProcessor.doUploadSingleNetOrder(appOrder.orderId);
                UploadDataHelper.uploadNetOrderData(appOrder.orderId);
            } else {
                LogUtil.logBusiness("虚拟打印机外卖", "美团虚拟打印机 订单入库异常 tempAppOrder = " + JSON.toJSONString(appOrder));
            }
            return result;
        }
    }


    /**
     * 查询第三方菜品与本地菜品的映射关系
     *
     * @param detail 外卖菜品
     * @return
     */
    public static void findMappingRelation(TempAppOrderDetail detail) {

        String sql = "select fiItemCd id, fsOrderUint value from tbNetorderItemMappingRelationship where fsNetorderItemName = '" + detail.itemName + "'  and fsNetorderUintName = '" + detail.unit + "' ";
        DataModel dataModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, DataModel.class);
        if (dataModel == null
                || TextUtils.isEmpty(dataModel.id)
                || TextUtils.equals(dataModel.id, "0")) {
            return;
        }
        detail.itemCode = dataModel.id;
        detail.specId = dataModel.value;

    }

    /**
     * 查询第三方菜品与本地菜品的映射关系
     *
     * @param thirdItemName 第三方菜品的名称
     * @param thirdItemUint 第三方菜品的规格
     * @return
     */
    public static String optLocalItemcd(String thirdItemName, String thirdItemUint) {
        String sqlParam = "";
        if (!TextUtils.isEmpty(thirdItemUint)) {
            sqlParam = " and fsNetorderUintName = '" + thirdItemUint + "'";
        }
        String sql = "select fiItemCd from tbNetorderItemMappingRelationship where fsNetorderItemName = '" + thirdItemName + "' " + sqlParam;
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 查找本地菜品是否可映射，并将外卖数据插入本地数据库
     *
     * @param detail 第三方菜品
     * @return
     */
    public static void checkAndMappingItem(TempAppOrderDetail detail) {

        boolean neadNotifyToClientRefresh = false;
        String name = detail.itemName;
        String unit = detail.unit;

        name = name.replace("[赠]", "");

        NetorderItemMappingRelationshipDBModel relationshipDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbNetorderItemMappingRelationship where fsNetorderItemName = '" + name + "' and fsNetorderUintName = '" + unit + "'", NetorderItemMappingRelationshipDBModel.class);
        if (relationshipDBModel == null) {
            relationshipDBModel = new NetorderItemMappingRelationshipDBModel();
            relationshipDBModel.fsNetorderItemName = name;
            relationshipDBModel.fsNetorderUintName = unit;
            relationshipDBModel.fdNetorderSaleAmt = detail.itemPrice;
            relationshipDBModel.fiStatus = 1;
            relationshipDBModel.fsUpdateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            relationshipDBModel.fsUpdateUserId = "cash";
            relationshipDBModel.fsUpdateUserName = "云收银";
            relationshipDBModel.fsShopGUID = ServerCache.getInstance().shopID;
            relationshipDBModel.pver = 1;
            relationshipDBModel.lver = 5;
            relationshipDBModel.sync = 1;
            relationshipDBModel.replaceNoTrans();
            neadNotifyToClientRefresh = true;
        }

//        if (relationshipDBModel.fiItemCd <= 0
        if (StringUtil.toInt(relationshipDBModel.fiItemCd, 0) <= 0
                && !TextUtils.isEmpty(name)
                && !TextUtils.isEmpty(unit)) {
            String findItemSQL = "select fiitemcd from tbmenuitem where fistatus = '1' and fiItemKind in ('1','2') and fsitemname = '%s' ";

            String localItemcd = DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(findItemSQL, name));
            if (!TextUtils.isEmpty(localItemcd)) {
                String uintInfoSQL = "SELECT fiOrderUintCd FROM tbmenuitemuint WHERE fiItemCd = '" + localItemcd + "' AND fiStatus = '1' AND fsOrderUint = '" + unit + "' ";
                String fiOrderUintCd = DBSimpleUtil.queryString(APPConfig.DB_MAIN, uintInfoSQL);
                if (!TextUtils.isEmpty(fiOrderUintCd)) {
                    relationshipDBModel.fsOrderUint = fiOrderUintCd;
                    relationshipDBModel.fiItemCd = localItemcd;
                    relationshipDBModel.replaceNoTrans();
                    neadNotifyToClientRefresh = true;
                }
            }
        }

//        if (relationshipDBModel.fiItemCd > 0) {
        if (StringUtil.toInt(relationshipDBModel.fiItemCd, 0) > 0) {
            detail.itemCode = relationshipDBModel.fiItemCd;
            detail.specId = relationshipDBModel.fsOrderUint;
        }

        if (neadNotifyToClientRefresh) {
            NotifyToClient.updateMappingRelation();
        }


    }


}
