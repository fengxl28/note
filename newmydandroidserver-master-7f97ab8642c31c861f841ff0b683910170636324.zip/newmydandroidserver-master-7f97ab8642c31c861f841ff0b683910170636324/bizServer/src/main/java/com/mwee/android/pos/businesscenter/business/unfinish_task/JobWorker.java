package com.mwee.android.pos.businesscenter.business.unfinish_task;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.future.KBOrderRefundRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.NetResultType;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.CheckTokenIsExistsRequest;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.einvoice.api.InvoiceRedRequest;
import com.mwee.android.pos.business.member.MemberConfigRequest;
import com.mwee.android.pos.business.member.MemberConfigResponse;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.business.netpay.NetResponse;
import com.mwee.android.pos.business.netpay.RefundRequest;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundRequest;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundResponse;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.business.shift.ShiftDinnerProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.KBMakePrinter;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderProcess;
import com.mwee.android.pos.businesscenter.driver.AccountBookUtil;
import com.mwee.android.pos.businesscenter.driver.BizSyncDriver;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.cross.net.CancelHungRequest;
import com.mwee.android.pos.component.datasync.net.GetAllNetOrderRequest;
import com.mwee.android.pos.component.datasync.net.GetPayPrefixRequest;
import com.mwee.android.pos.component.datasync.net.GetPayPrefixResponse;
import com.mwee.android.pos.component.datasync.net.GetShopPayStatusRequest;
import com.mwee.android.pos.component.datasync.net.GetShopPayStatusResponse;
import com.mwee.android.pos.component.datasync.net.model.ShopPayStatus;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.MemberBalanceRefundRequest;
import com.mwee.android.pos.component.member.net.MemberBalanceRefundResponse;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeResponse;
import com.mwee.android.pos.component.member.net.MemberOrderRefundRequest;
import com.mwee.android.pos.component.member.net.MemberOrderRefundResponse;
import com.mwee.android.pos.component.member.net.QueryNewMemberChargeResultRequest;
import com.mwee.android.pos.component.member.net.QueryNewMemberChargeResultResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberRechargeResultRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBalanceRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberBalanceRefundResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderRefundResponse;
import com.mwee.android.pos.connect.business.bean.ShopPayResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * Job的Worker类，需要运行在业务中心
 * Created by virgil on 2017/3/2.
 */

@SuppressWarnings("unused")
public class JobWorker {
    public JobWorker() {

    }

    public void work(Job job) {
        try {
            boolean found = false;
            Method[] methods = this.getClass().getDeclaredMethods();
            for (Method method : methods) {
                method.setAccessible(true);
                JobType anno = method.getAnnotation(JobType.class);
                if (anno != null) {
                    if (anno.value() == job.type) {
                        found = true;
                        LogUtil.log("JobScheudler work " + job.type + "," + job.taskid);
                        method.invoke(this, job);
                        break;
                    }
                }
            }
            if (!found) {
                workAsDriver(job);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    /**
     * 判断是否需要走Driver调用
     *
     * @param job Job
     */
    private void workAsDriver(Job job) {
        if (!TextUtils.isEmpty(job.driver_uri)) {
            LogUtil.log("JobScheudler work driver:" + job.driver_uri);
            job.updateJobWorking();
            try {
                if (!TextUtils.isEmpty(job.driver_param)) {
                    Object[] paramList = job.driver_param.split("#@%");
                    if (paramList.length > 0) {
                        DriverBus.call(job.driver_uri, paramList);
                    } else {
                        DriverBus.call(job.driver_uri);
                    }
                } else {
                    DriverBus.call(job.driver_uri);
                }

                job.laskWorkTime = DateUtil.getCurrentTime();
                job.finished = 1;
            } catch (Exception e) {
                LogUtil.logError(e);
                //出现异常，则将任务设置为未执行，并清除执行时间
                job.laskWorkTime = "";
                job.finished = 0;
            } finally {
                job.update_time = DateUtil.getCurrentTime();
                job.replaceNoTrans();
            }
        } else {
            job.updateJobCancel();
        }
    }

    /**
     * 会员赠送积分和优惠券
     *
     * @param job Job
     */
    @JobType(JobType.MEMBER_GIFT)
    private void processMemberGift(final Job job) {
        MemberOrderConsumeRequest consumeRequest = JSON.parseObject(job.info, MemberOrderConsumeRequest.class);
        consumeRequest._timestamp = String.valueOf(DateUtil.getCurrentTimeInMills() / 1000);
        BusinessExecutor.execute(consumeRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    job.trace2 = JSON.toJSONString(responseData.responseBean);
                    job.finished = 1;
                    job.update_time = DateUtil.getCurrentTime();
                    job.replaceNoTrans();
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 会员赠送积分和优惠券---会员重构
     *
     * @param job Job
     */
    @JobType(JobType.MEMBER_GIFT_NEW)
    private void processMemberGiftNew(final Job job) {
        NewMemberOrderConsumeRequest consumeRequest = JSON.parseObject(job.info, NewMemberOrderConsumeRequest.class);
        BusinessExecutor.execute(consumeRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                    job.trace2 = JSON.toJSONString(responseData.responseBean);
                    job.finished = 1;
                    job.update_time = DateUtil.getCurrentTime();
                    job.replaceNoTrans();
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderConsumeResponse) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 秒付的退款
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_RAPID)
    private void processRapid(final Job job) {
        RapidRefundRequest refundRequest = JSON.parseObject(job.info, RapidRefundRequest.class);
        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_RAPID, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof RapidRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 口碑后付的退款
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_KOUBEI_AFTER_PAY)
    private void processKBAfterPay(final Job job) {
        KBOrderRefundRequest refundRequest = JSON.parseObject(job.info, KBOrderRefundRequest.class);
        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_RAPID, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof RapidRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 会员订单的退款
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_MEMBER)
    private void processMember(final Job job) {
        MemberOrderRefundRequest refundRequest = JSON.parseObject(job.info, MemberOrderRefundRequest.class);
        refundRequest._timestamp = String.valueOf(DateUtil.getCurrentTimeInMills() / 1000);

        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_MEMBER, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof MemberOrderRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    } else if (responseData.resultMessage.contains("重复退款") || responseData.resultMessage.contains("重复的回调")) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 网络支付的退款
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_NET)
    private void processNet(final Job job) {
        RefundRequest refundRequest = new RefundRequest();
        refundRequest.pay_order = job.info;
        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_NET, job.info, "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof NetResponse) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 取消在线挂账
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_ONLINE_HUNG)
    private void processHung(final Job job) {
        CancelHungRequest cancelHungRequest = new CancelHungRequest();
        cancelHungRequest.creditOrderId = job.info;
        BusinessExecutor.execute(cancelHungRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.PAY_HUNG, job.info, "取消在线挂账 任务执行失败", cancelHungRequest);
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 会员储值的退款
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_MEMBER_BALANCE)
    private void processMemberBlance(final Job job) {
        MemberBalanceRefundRequest refundRequest = JSON.parseObject(job.info, MemberBalanceRefundRequest.class);
        refundRequest._timestamp = String.valueOf(DateUtil.getCurrentTimeInMills() / 1000);
        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_BALANCE, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof MemberBalanceRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    } else if (responseData.resultMessage.contains("重复退款") || responseData.resultMessage.contains("重复的回调")) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 会员储值的退款---会员重构对接
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_MEMBER_BALANCE_NEW)
    private void processMemberBlanceNew(final Job job) {
        NewMemberBalanceRefundRequest refundRequest = JSON.parseObject(job.info, NewMemberBalanceRefundRequest.class);

        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_BALANCE, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberBalanceRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    } else if (responseData.resultMessage.contains("重复退款") || responseData.resultMessage.contains("重复的回调")) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }

    /**
     * 会员回退积分、优惠券---会员重构
     *
     * @param job Job
     */
    @JobType(JobType.REFUND_MEMBER_NEW)
    private void processMemberNew(final Job job) {
        NewMemberOrderRefundRequest refundRequest = JSON.parseObject(job.info, NewMemberOrderRefundRequest.class);
        BusinessExecutor.execute(refundRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_MEMBER, "", "", refundRequest);
                if (responseData.netResult == 0) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof NewMemberOrderRefundResponse) {
                        job.updateJobFinished();
                        return false;
                    } else if (responseData.resultMessage.contains("重复退款") || responseData.resultMessage.contains("重复的回调")) {
                        job.updateJobFinished();
                        return false;
                    }
                }
                job.updateJobPrepared();
                return false;
            }
        }, true);
    }


    /**
     * 网络订单定时刷新
     *
     * @param job Job
     */
    @JobType(JobType.NETORDER_REFRESH)
    private void getAllNetOrder(final Job job) {
        if (ServerCache.getInstance().netOrderCache != null) {
            ServerCache.getInstance().netOrderCache.checkCacheExpired();
        }

        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        //删除超过10分钟缓存的推送消息
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from push_msg_stack where msgBizValue = '1000' and ((strftime('%s','" + currentTime + "') - strftime('%s',updateTime))>600) ");

        LogUtil.log("JobWorker 开始轮询网络订单" + DateUtil.getCurrentDateTime());
        GetAllNetOrderRequest getDataRequest = new GetAllNetOrderRequest();
        getDataRequest.diningStatus = "-1,-2,20,30,35,40";
        BusinessExecutor.execute(getDataRequest, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                LogUtil.log("JobWorker 开始解析网络订单 " + DateUtil.getCurrentDateTime());
                int result = NetOrderProcess.parseGetAllNetworkData(responseData);
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                LogUtil.logBusiness("获取所有网络订单失败, 请稍后重试（" + responseData.resultMessage + ")");
                return false;
            }
        }, true);
    }

    /**
     * 中控定时登录
     *
     * @param job Job
     */
    @JobType(JobType.LOGINPD)
    private void loginPD(final Job job) {
        JobScheudler.updateJobStatusByType(JobType.LOGINPD, JobStatus.WORKING);
        String session = DBMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID);
        if (TextUtils.isEmpty(session)) {
            DriverBus.call("xmpp/dologin");
        } else {
            JobScheudler.updateJobStatusByType(JobType.LOGINPD, JobStatus.FINISHED);
        }
    }

    /**
     * 定时上报xmpp的登录状态
     *
     * @param job Job
     */
    @JobType(JobType.XMPP_STATE)
    private void XMPP_STATE(final Job job) {
        //xmpp保活老接口已废弃，不在调用
//        String session = DBMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID);
//        UploadXmppStateRequest requet = new UploadXmppStateRequest();
//        requet.state = TextUtils.isEmpty(session) ? "0" : "1";
//        BusinessExecutor.execute(requet, null, new BusinessCallback() {
//            @Override
//            public boolean success(int i, ResponseData responseData) {
//                JobScheudler.updateJobWorkTimeByType(JobType.XMPP_STATE);
//                return true;
//            }
//
//            @Override
//            public boolean fail(int i, ResponseData responseData) {
//                return false;
//            }
//        }, true);
    }


    /**
     * 定时Token验证
     *
     * @param job Job
     */
    @JobType(JobType.CASH_LOGINPD)
    private void cashLoginpd(final Job job) {
        String token = DBMetaUtil.getSettingsValueByKey(META.CASHIER_PD_TOKEN);
        if (TextUtils.isEmpty(token)) {
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "验证token：为null");
            return;
        }
        CheckTokenIsExistsRequest request = new CheckTokenIsExistsRequest();
        request.token = token;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }


            @Override
            public boolean fail(ResponseData responseData) {
                if (responseData != null && responseData.netResult == NetResultType.SUCCESS && responseData.result == 1007) {
                    RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "等录过期：" + JSON.toJSONString(responseData));
                    NotifyToClient.broadcast("login/controlTokenExpired");
                }
                return false;
            }
        }, false);
    }


    /**
     * 保存日报表
     * Job执行前置条件
     * 1. 进行日切
     * 2. 报表未完全保存成功
     *
     * @param job
     */
    @JobType(JobType.SAVE_DAILY_REPORT)
    private void saveDailyReport(Job job) {
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        String targetBusinessDate = job.biz_key;

        int targetCount = DailyReportDBUtil.optTargetBookCount();

        //自然日
        String naturalDate = job.info;
        RunTimeLog.addLog(RunTimeLog.SAVE_DAILY_REPORT, "轮询->保存营业报表[" + targetBusinessDate + "]");

        // 前置条件判断
        if (TextUtils.equals(currentBusinessDate, targetBusinessDate)) {
            RunTimeLog.addLog(RunTimeLog.SAVE_DAILY_REPORT, "轮询->保存营业报表[" + targetBusinessDate + "], 日期一致，退出本次轮询");
            return;
        }
        if (DailyReportDBUtil.hasSavedReport(targetBusinessDate, targetCount)) {
            job.updateJobCancel();
            RunTimeLog.addLog(RunTimeLog.SAVE_DAILY_REPORT, "轮询->保存营业报表[" + targetBusinessDate + "], 报表已完全保存, 取消Job");
            return;
        }

        if (APPConfig.isMyd()) {
            BizSyncDriver.saveReport(targetBusinessDate, naturalDate, 0, "1", false);
            List<AccountBookDBModel> accountBookList = AccountBookUtil.optAllAccountBook(false);
            if (!ListUtil.isEmpty(accountBookList)) {
                for (AccountBookDBModel accountBook : accountBookList) {
                    if (accountBook == null || TextUtils.equals("1", accountBook.accountBookId)) {
                        continue;
                    }
                    BizSyncDriver.saveReport(targetBusinessDate, naturalDate, 1, accountBook.accountBookId, false);
                }
            }
        } else {
            BizSyncDriver.saveReport(targetBusinessDate, naturalDate, 0, "", false);
            BizSyncDriver.saveReport(targetBusinessDate, naturalDate, 1, "", false);
        }


        // 存储之后再次校验报表是否已存储完全
        if (DailyReportDBUtil.hasSavedReport(targetBusinessDate, targetCount)) {
            job.updateJobFinished();
        } else {
            job.updateJobPrepared();
        }

    }

    /**
     * 上送营业总结
     *
     * @param job
     */
    @JobType(JobType.SUMMARY)
    private void sendSummary(Job job) {
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        String targetBusinessDate = job.biz_key;
        RunTimeLog.addLog(RunTimeLog.SEND_SUMMARY, "轮询->上送总结[" + targetBusinessDate + "]");
        ShiftDinnerProcessor.sendSummary(targetBusinessDate, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                if (result) {
                    job.updateJobFinished();
                    RunTimeLog.addLog(RunTimeLog.SEND_SUMMARY, "轮询->上送总结[" + targetBusinessDate + "]  成功");
                } else {
                    job.updateJobPrepared();
                    RunTimeLog.addLog(RunTimeLog.SEND_SUMMARY, "轮询->上送总结[" + targetBusinessDate + "]  失败 " + info);
                }
            }
        });
    }


    /**
     * 打印口碑小票
     *
     * @param job
     */
    @JobType(JobType.KB_PRINTER)
    private void sendKBPrinter(Job job) {
        if (TextUtils.isEmpty(job.info)) {
            LogUtil.log("口碑小票打印 Job, 打印时间为空");
            return;
        }
        Long timePrint = StringUtil.toLong(job.info, 0l);
        // 打印时间 - 当前时间 > 10分钟，等待下一轮执行
        if (timePrint - DateUtil.getCurrentTimeInMills() > 10 * 60 * 1000) {
            job.updateJobPrepared();
            return;
        }
        //小于10分钟的打印任务 交给KBMakePrinter去处理
        KBMakePrinter.buildMakeCache(job.biz_key, timePrint.toString());

        job.updateJobFinished();

    }


    /**
     * 查询会员充值结果
     *
     * @param job
     */
    @JobType(JobType.MEMBER_RECHARGE_QUERY_RESULT)
    private void queryMemberRechargeResult(Job job) {
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        String targetBusinessDate = job.biz_key;
        RunTimeLog.addLog(RunTimeLog.MEMBER, "轮询->查询会员充值结果[" + targetBusinessDate + "]");

        QueryNewMemberChargeResultRequest queryResultRequest = new QueryNewMemberChargeResultRequest();
        queryResultRequest.type = "1";
        queryResultRequest.sourceid = 105;
        queryResultRequest.v = "1.1";
        queryResultRequest.trade_no = job.biz_key;

        final long start = SystemClock.elapsedRealtime();

        BusinessExecutor.execute(queryResultRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                try {
                    if (responseData != null && responseData.responseBean != null && (responseData.responseBean instanceof QueryNewMemberChargeResultResponse)) {
                        QueryNewMemberChargeResultResponse response = (QueryNewMemberChargeResultResponse) responseData.responseBean;
                        if (response.data.pay_status == 1) {
                            if (response.data.status == 104 || response.data.status == 105) {
                                job.updateJobFinished();
                            } else {
                                job.updateJobPrepared();
                            }
                        } else if (response.data.pay_status == 2) {
                            job.updateJobFinished();
                        } else {
                            job.updateJobPrepared();
                        }
                    } else {
                        job.updateJobPrepared();
                    }

                } catch (Exception e) {
                    job.updateJobPrepared();
                }

            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobPrepared();
                return false;
            }
        });

    }

    /**
     * 检测自然日报表的 Job
     *
     * @param job
     */
    @JobType(JobType.CHECK_REPORT_NATURE_JOB)
    private void checkJobWithReportNature(Job job) {
        List<String> result = queryReportDateByNature();

        if (ListUtil.isEmpty(result)) {
            RunTimeLog.addLog(RunTimeLog.REPORT_SAVE_BY_NATURE, "自然日相关报表已完全存储");
            return;
        }
        RunTimeLog.addLog(RunTimeLog.REPORT_SAVE_BY_NATURE, "自然日相关报表还有(" + JSON.toJSONString(result) + ")未完全存储");

        // 如果存在部分自然日的报表可能存在问题，需要创建对应的 Job, 轮询重新保存报表
        String queryJobSQL = "SELECT * FROM unfinish_task WHERE type = '" + JobType.SAVE_REPORT_NATURE + "' AND biz_key = '%s'";
        for (String nature : result) {
            Job task = DBSimpleUtil.query(APPConfig.DB_MAIN, queryJobSQL, Job.class);
            if (task == null) {
                task = new Job();
                task.type = JobType.SAVE_REPORT_NATURE;
                task.biz_key = nature;
                task.cycle = 3;
                task.cycle_count = 2;
                JobScheudler.newJob(task);
            } else {
                task.updateJobPrepared();
            }
        }

        // 检测自然日报表的 Job 需要保持轮询，不关闭
        job.updateJobPrepared();
    }

    /**
     * 查询未保存完成的自然日的报表
     * 1. 订单表有数据，但固化报表没有数据
     * 2. 固化报表的更新时间小于等于报表的日期，固化报表可能保存在当日之间，保存也许不完全
     *
     * @return List<String> | 有问题的自然日日期
     */
    @NonNull
    private List<String> queryReportDateByNature() {
        Set<String> result = new HashSet<>();

        // 查询未创建报表的日期(订单表有数据，报表没有数据) - 收款明细表
        String checkByDayNotExistSQL = "SELECT * FROM (SELECT date(fsUpdateTime) AS nature_date FROM tbsellreceive " +
                "GROUP BY nature_date) AS m WHERE m.nature_date NOT IN (SELECT businessdate FROM dailyReport WHERE " +
                "type = '" + ReportConsrance.CHECK_BY_DAY + "' GROUP BY businessdate)";
        List<String> dateCheckByDayNotExist = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, checkByDayNotExistSQL);
        if (!ListUtil.isEmpty(dateCheckByDayNotExist)) {
            result.addAll(dateCheckByDayNotExist);
        }

        // 外卖报表
        String dateExistSQL = "SELECT date(date) AS nature_date FROM tempapporder GROUP BY nature_date";
        List<String> dateExist = DBSimpleUtil.queryStringList(APPConfig.DB_NET_ORDER, dateExistSQL);
        String netOrderExistSQL = "SELECT businessdate FROM dailyReport WHERE type = '" + ReportConsrance.NET_ORDER +
                "' GROUP BY businessdate";
        List<String> dateReport = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, netOrderExistSQL);
        if (!ListUtil.isEmpty(dateExist)) {
            if (ListUtil.isEmpty(dateReport)) {
                result.addAll(dateExist);
            } else {
                for (String date : dateExist) {
                    if (dateReport.contains(date)) {
                        continue;
                    }
                    result.add(date);
                }
            }
        }

        // 微信外卖
        String weChatNotExistSQL = "SELECT * FROM (SELECT date(fscreatetime) AS nature_date FROM tbwechatorder GROUP " +
                "BY nature_date) AS m WHERE m.nature_date NOT IN (SELECT businessdate FROM dailyReport WHERE type = " +
                "'" + ReportConsrance.WECHAT_ORDE + "' GROUP BY businessdate)";
        List<String> dateWeChatNotExist = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, weChatNotExistSQL);
        if (!ListUtil.isEmpty(dateWeChatNotExist)) {
            result.addAll(dateWeChatNotExist);
        }

        // 查询报表可能保存不完全的日期(保存报表的日期需大于报表对应)
        String reportNotCompleteSQL = "SELECT businessdate FROM dailyReport WHERE date(updateTime) <= businessdate " +
                "AND type IN ('" + ReportConsrance.CHECK_BY_DAY + "', '" + ReportConsrance.NET_ORDER + "', '" +
                ReportConsrance.WECHAT_ORDE + "')";
        List<String> dateReportNotComplete = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, reportNotCompleteSQL);
        if (!ListUtil.isEmpty(dateReportNotComplete)) {
            result.addAll(dateReportNotComplete);
        }
        return new ArrayList<>(result);
    }

    /**
     * 保存按自然日统计的报表
     *
     * @param job
     */
    @JobType(JobType.SAVE_REPORT_NATURE)
    private void saveReportNature(Job job) {
        // 获取 Job 对应的自然日日期
        String dateNature = job.biz_key;
        if (TextUtils.isEmpty(dateNature)) {
            return;
        }

        if (APPConfig.isMyd()) {
            DailyReportDBUtil.saveReportByNature(dateNature, 0, "1");
            List<AccountBookDBModel> accountBookList = AccountBookUtil.optAllAccountBook(false);
            if (!ListUtil.isEmpty(accountBookList)) {
                for (AccountBookDBModel accountBook : accountBookList) {
                    if (accountBook == null || TextUtils.equals("1", accountBook.accountBookId)) {
                        continue;
                    }
                    DailyReportDBUtil.saveReportByNature(dateNature, 1, accountBook.accountBookId);
                }
            }
        } else {
            DailyReportDBUtil.saveReportByNature(dateNature, 0, "");
            DailyReportDBUtil.saveReportByNature(dateNature, 1, "");
        }

        job.updateJobFinished();
    }

    /**
     * 查询支付前缀
     *
     * @param job
     */
    @JobType(JobType.QUERY_PAY_BARCODE_PREFIX)
    private void queryPayPrefix(Job job) {
        GetPayPrefixRequest request = new GetPayPrefixRequest();
        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof GetPayPrefixResponse) {
                    JSONObject obj = JSON.parseObject(((GetPayPrefixResponse) responseData.responseBean).data);
                    // 微信前缀
                    if (obj.containsKey("1")) {
                        String value = obj.getString("1");
                        if (!TextUtils.isEmpty(value)) {
                            NetPayUtil.PREFIX_WECHAT = value.split(",");
                        }
                    }
                    // 支付宝前缀
                    if (obj.containsKey("2")) {
                        String value = obj.getString("2");
                        if (!TextUtils.isEmpty(value)) {
                            NetPayUtil.PREFIX_ALI = value.split(",");
                        }
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        });
    }

    /**
     * 查询支付开通状态
     */
    @JobType(JobType.QUERY_SHOP_PAY_STATUS)
    private void queryShopPayStatus(Job job) {
        ShopPayResponse shopPayResponse = new ShopPayResponse();
        GetShopPayStatusRequest request = new GetShopPayStatusRequest();
        request.shopguid = HostUtil.getShopID();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof GetShopPayStatusResponse) {
                    List<ShopPayStatus> data = ((GetShopPayStatusResponse) responseData.responseBean).data;
                    if (ListUtil.isEmpty(data)) {
                        return;
                    }
                    for (ShopPayStatus shopPay : data) {
                        if (shopPay == null || TextUtils.isEmpty(shopPay.payment_type)) {
                            continue;
                        }
                        if (TextUtils.equals("ALIPAY", shopPay.payment_type)) {// 支付宝
                            shopPayResponse.allowAliPayBack = shopPay.allow_pay_back;
                            DBMetaUtil.updateSettingsValueByKey(META.ALLOW_ALIPAY_BACK, shopPay.allow_pay_back ? "1" : "0");
                        }
                        if (TextUtils.equals("WXPAY", shopPay.payment_type)) {// 微信
                            shopPayResponse.allowWxPayBack = shopPay.allow_pay_back;
                            DBMetaUtil.updateSettingsValueByKey(META.ALLOW_WXPAY_BACK, shopPay.allow_pay_back ? "1" : "0");
                        }
                    }
                    NotifyToClient.broadcast("login/syncShopPayStatus", JSON.toJSONString(shopPayResponse));
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }

    /**
     * 电子发票冲红
     *
     * @param job
     */
    @JobType(JobType.INVOICE_DEPRECATED)
    private void deprecateInvoice(Job job) {
        String businessNo = job.biz_key;
        if (TextUtils.isEmpty(businessNo)) {
            job.updateJobCancel();
            return;
        }

        InvoiceRedRequest request = new InvoiceRedRequest();
        request.sourceId = 168;
        request.businessNo = businessNo;
        request.reason = job.info;
        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                // 成功后, 任务标记完成, 不再执行
                job.updateJobFinished();
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                // do nothing，失败不做任何处理，等待下次 Job 重新执行。
                return false;
            }
        });
    }

    @JobType(JobType.QUERY_MEMBER_CONFIG)
    private void queryMemberConfig(Job job) {
        String fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM tbshop WHERE fsShopGUID = '" + fsShopGUID + "'", ShopDBModel.class);
        if (shopDBModel == null) {
            RunTimeLog.addLog(RunTimeLog.MEMBER_CONFIG, "未查到门店信息");
            return;
        }
        MemberConfigRequest request = new MemberConfigRequest();
        request.companyGUID = Integer.valueOf(shopDBModel.fsCompanyGUID);
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MemberConfigResponse) {
                    MemberConfigResponse response = (MemberConfigResponse) responseData.responseBean;
                    if (response.data != null) {
                        DBMetaUtil.updateSettingsValueByKey(META.MEMBER_CONFIG, JSON.toJSONString(response.data));
                    } else {
                        DBMetaUtil.updateSettingsValueByKey(META.MEMBER_CONFIG, "");
                    }
                } else {
                    DBMetaUtil.updateSettingsValueByKey(META.MEMBER_CONFIG, "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                DBMetaUtil.updateSettingsValueByKey(META.MEMBER_CONFIG, "");
                return false;
            }
        });
    }

    /**
     * 查询会员充值结果
     *
     * @param job
     */
    @JobType(JobType.NEW_MEMBER_RECHARGE_QUERY_RESULT)
    private void queryNewMemberRechargeResult(Job job) {
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        String trade_no = job.biz_key;
        RunTimeLog.addLog(RunTimeLog.MEMBER, "轮询->查询会员充值结果,trade_no:" + trade_no);

        MemberRechargeResultRequest queryResultRequest = new MemberRechargeResultRequest();
        queryResultRequest.trade_no = job.biz_key;
        queryResultRequest.companyGuid = job.info;

        final long start = SystemClock.elapsedRealtime();

        BusinessExecutor.execute(queryResultRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                try {
                    if (responseData != null && responseData.responseBean != null && (responseData.responseBean instanceof QueryNewMemberChargeResultResponse)) {
                        QueryNewMemberChargeResultResponse response = (QueryNewMemberChargeResultResponse) responseData.responseBean;
                        if (response.data.pay_status == 1) {
                            if (response.data.status == 104 || response.data.status == 105) {
                                job.updateJobFinished();
                            } else {
                                job.updateJobPrepared();
                            }
                        } else if (response.data.pay_status == 2) {
                            job.updateJobFinished();
                        } else {
                            job.updateJobPrepared();
                        }
                    } else {
                        job.updateJobPrepared();
                    }

                } catch (Exception e) {
                    job.updateJobPrepared();
                }

            }

            @Override
            public boolean fail(ResponseData responseData) {
                InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                job.updateJobPrepared();
                return false;
            }
        });

    }
}
