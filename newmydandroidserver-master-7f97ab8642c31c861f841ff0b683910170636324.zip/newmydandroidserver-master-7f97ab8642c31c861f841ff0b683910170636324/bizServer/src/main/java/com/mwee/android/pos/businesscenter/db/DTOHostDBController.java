package com.mwee.android.pos.businesscenter.db;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by qinwei on 2019/3/11 8:55 PM
 * email: qin.wei@mwee.cn
 */
public class DTOHostDBController {
    /**
     * 根据id查询 站点信息
     *
     * @param hostId
     * @return
     */
    public HostDBModel queryById(String hostId) {
        String sql = "select * from tbhost where fsHostId='" + hostId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, HostDBModel.class);
    }
}
