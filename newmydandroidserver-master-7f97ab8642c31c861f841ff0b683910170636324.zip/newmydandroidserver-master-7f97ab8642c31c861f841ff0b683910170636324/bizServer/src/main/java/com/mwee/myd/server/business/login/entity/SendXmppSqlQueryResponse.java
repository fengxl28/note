package com.mwee.myd.server.business.login.entity;


import com.mwee.android.base.net.BaseResponse;

/**
 * Created by hm on 2018/1/8.
 *
 */
public class SendXmppSqlQueryResponse extends BaseResponse {

    public Object data;
    public int elapsedMilliseconds;
    public String errmsg;
    public int errno;
    public String requestId;

}
