package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * 数据库表id生成器
 * Created by qinwei on 2017/10/14.
 */

public class IDHelper {
    /**
     * 菜品表 fiItemCd int
     */
    public final static String TB_MENU_ITEM = "tbMenuItem";
    /**
     * 规格表 fiOrderUintCd int
     */
    public final static String TB_MENU_ITEM_UINT = "tbMenuItemUint";
    /**
     * 套餐组成项表 fiSetFoodCd int  	fiItemCd_M int
     */
    public final static String TB_MENU_ITEM_SETSIDE = "tbMenuItemSetSide";
    /**
     * 要求表 fiId int
     */
    public final static String TB_ASK = "tbAsk";
    /**
     * 菜品要求组关联表 fiItemCd int 	 fsAskGpId varchar(6) 	fsShopGUID(80)
     */
    public final static String TB_MENU_ITEM_ASKGP = "tbMenuItemAskGp";
    /**
     * 菜品部门关联表 fiMulDeptCd int
     */
    public final static String TB_MENU_ITEM_MUL_DEPT = "tbMenuItemMulDept";

    /**
     * 要求组表 fsAskGpId varchar(6) 	fsShopGUID(80)
     */
    public final static String TB_ASKGP = "tbAskGp";
    /**
     * 菜品分类表 fsMenuClsId varchar(10)	fsShopGUID(80)
     */
    public final static String TB_MENU_CLS = "tbMenuCls";
    /**
     * 系统配置表 fsParamId varchar(5)
     */
    public final static String TB_PARAM_VALUE = "tbparamValue";
    /**
     * 折扣方式表 fsDiscountId varchar(10)
     */
    public final static String TB_DISCOUNT = "tbDiscount";

    /**
     * 支付方式表 fsPaymentId varchar(10)     fsShopGUID(80)
     */
    public final static String TB_PAYMENT = "tbPayment";

    /**
     * 打印机表 fiID int  fsShopGUID varchar(10)
     */
    public final static String TB_PRINTER = "tbPrinter";
    /**
     * 菜品分类部门关联表 String 10
     */
    public final static String TB_MENU_CLS_MULDEPT = "tbmenuClsMuldept";

    /**
     * 部门表 fsDeptId
     */
    public final static String TB_DEPT = "tbdept";


    /**
     * 活动优惠表 fsBargainId varchar(8)
     */
    public final static String TB_BARGAIN = "tbBargain";

    /**
     * 收入分类
     * String 10
     */
    public final static String EXP_CLS = "tbexpcls";
    /**
     * 销售分类
     * String 10
     */
    public final static String REVENUE_TYPE = "tbrevenuetype";

    /**
     * 生成主键id
     *
     * @param tableName 数据库表名称
     * @return 主键id
     */
    private static long generateId(String tableName) {
        String keyName = "";
        int length = 1;
        switch (tableName) {
            case TB_MENU_ITEM:
                keyName = "fiItemCd";
                length = 8;
                break;
            case TB_MENU_ITEM_UINT:
                keyName = "fiOrderUintCd";
                length = 8;
                break;
            case TB_MENU_ITEM_SETSIDE:
                keyName = "fiSetFoodCd";
                length = 8;
                break;
            case TB_ASK:
                keyName = "fiId";
                length = 8;
                break;
            case TB_MENU_ITEM_ASKGP:
                keyName = "fsAskGpId";
                length = 6;
                break;
            case TB_MENU_ITEM_MUL_DEPT:
                keyName = "fiMulDeptCd";
                length = 8;
                break;
            case TB_ASKGP:
                keyName = "fsAskGpId";
                length = 6;
                break;
            case TB_MENU_CLS:
                keyName = "fsMenuClsId";
                length = 8;
                break;
            case TB_PARAM_VALUE:
                keyName = "fsParamId";
                length = 5;
                break;
            case TB_DISCOUNT:
                keyName = "fsDiscountId";
                length = 8;
                break;
            case TB_PAYMENT:
                keyName = "fsPaymentId";
                length = 8;
                break;
            case TB_PRINTER:
                keyName = "fiID";
                length = 5;
                break;
            case TB_MENU_CLS_MULDEPT:
                keyName = "fsGuid";
                length = 8;
                break;
            case TB_DEPT:
                keyName = "fsDeptId";
                length = 5;
                break;
            case TB_BARGAIN:
                keyName = "fsBargainId";
                length = 7;
                break;
            case EXP_CLS:
                keyName = "fsExpClsId";
                length = 10;
                break;
            case REVENUE_TYPE:
                keyName = "fsRevenueTypeId";
                length = 10;
                break;
            default:
                break;
        }
        String sql = "select " + keyName + " from " + tableName + " where fiDataSource = '1' order by " + keyName + " asc limit 1";
        String result = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        Integer id = 0;
        if (TextUtils.isEmpty(result)) {
            //如果没有找到pos产生的数据 id则用最大值
            switch (length) {
                case 5:
                    id = 99999;
                    break;
                case 6:
                    id = 999999;
                    break;
                case 7:
                    id = 9999999;
                    break;
                case 8:
                    id = 99999999;
                    break;
                default:
                    id = 9999;
                    break;
            }
        } else {
            //找到pos生成id列表中最小值
            id = StringUtil.toInt(result, -1);
            //如果发现id小于0  则从9999进行递减
            if (id < 0) {
                id = 9999;
            } else {
                //减一生成新的id
                id--;
            }
        }
        List<String> ids = queryIds(tableName, keyName);
        if (ids != null) {
            //防止生成id重复
            return optId(id, ids);
        }
        return id;
    }

    public static List<String> queryIds(String tableName, String idName) {
        String sql = "select " + idName + " from " + tableName;
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
    }

    /**
     * 生成id候补逻辑，防止id重复
     *
     * @param id
     * @param ids
     * @return
     */
    public static long optId(long id, List<String> ids) {
        if (ids.contains(id + "")) {
            return optId((id - 1), ids);
        }
        return id;
    }


    /**
     * 生成菜品id
     *
     * @return
     */
    public static int generateMenuId() {
        return (int) generateId(TB_MENU_ITEM);
    }

    public static String generateMenuCode() {
        return DateUtil.getCurrentDate("yyMMddHHmm");
    }

    /**
     * 生成规格id
     *
     * @return
     */
    public static int generateMenuUnitId() {
        return (int) generateId(TB_MENU_ITEM_UINT);
    }

    /**
     * 生成套餐组成项id
     *
     * @return
     */
    public static int generateFiSetFoodCd() {
        return (int) generateId(TB_MENU_ITEM_SETSIDE);
    }

    /**
     * 生成要求id
     *
     * @return
     */
    public static int generateAskId() {
        return (int) generateId(TB_ASK);
    }

    /**
     * 生成折扣id
     *
     * @return
     */
    public static String generateDiscountId() {
        return String.valueOf(generateId(TB_DISCOUNT));
    }

    /**
     * 生成要求组id
     *
     * @return
     */
    public static String generateAskGpId() {
        return generateId(TB_ASKGP) + "";
    }

    /**
     * 生成菜品分类id
     *
     * @return
     */
    public static String generateMenuClsId() {
        return generateId(TB_MENU_CLS) + "";
    }

    /**
     * 生成部门id
     *
     * @return
     */
    public static String generateDeptId() {
        return generateId(TB_DEPT) + "";
    }

    /**
     * 生成菜品销售分类关联部门id
     *
     * @return
     */
    public static String generateExpClsId() {
        return generateId(EXP_CLS) + "";
    }

    /**
     * 生成菜品收入分类关联部门id
     *
     * @return
     */
    public static String generateRevenueTypeId() {
        return generateId(REVENUE_TYPE) + "";
    }

    public static String generateMenuClsMuldeptId() {
        return generateId(TB_MENU_CLS_MULDEPT) + "";
    }

    /**
     * 生成打印机id
     *
     * @return
     */
    public static int generatePrinterId() {
        return (int) generateId(TB_PRINTER);
    }

    /**
     * 生成优惠活动id
     *
     * @return
     */
    public static String generateFullReduceId() {
        return generateId(TB_BARGAIN) + "";
    }

    /**
     * 生成支付方式id
     *
     * @return
     */
    public static String generatePaymentId() {
        return generateId(TB_PAYMENT) + "";
    }


}
