package com.mwee.android.pos.businesscenter.business.washdata;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.List;

public class WashDataProcessor {

    private static final String TAG = "WashDataProcessor";

    /**
     * 对应类型 see{@link WashDataType#BEFORE_SYNC}
     */
    private static final int CURRENT_VERSION_BEFORE_SYNC = 0;
    /**
     * 对应类型 see{@link WashDataType#AFTER_SYNC}
     */
    private static final int CURRENT_VERSION_AFTER_SYNC = 2;

    public static boolean washBeforeSync(IProgressCallback progressCallback) {
        return washData(WashDataType.BEFORE_SYNC, progressCallback);
    }

    public static boolean washAfterSync(IProgressCallback progressCallback) {
        return washData(WashDataType.AFTER_SYNC, progressCallback);
    }

    private static boolean washData(String washDataType, IProgressCallback progressCallback) {
        int oldVer = 0, curVer = 0;

        if (progressCallback != null) {
            progressCallback.onProgress(1, IProgressCallback.TAG_UPDATE_DATA);
        }

        WashDataConfig config = readConfig();
        if (config == null) {
            config = new WashDataConfig();
        }

        if (progressCallback != null) {
            progressCallback.onProgress(10, IProgressCallback.TAG_UPDATE_DATA);
        }

        if (TextUtils.equals(WashDataType.BEFORE_SYNC, washDataType)) {
            oldVer = config.versionBeforeSync;
            curVer = CURRENT_VERSION_BEFORE_SYNC;
        } else if (TextUtils.equals(WashDataType.AFTER_SYNC, washDataType)) {
            oldVer = config.versionAfterSync;
            curVer = CURRENT_VERSION_AFTER_SYNC;
        }
        LogUtil.logBusiness(TAG, "washData oldVer=" + oldVer + ", curVer=" + curVer + ", washDataType=" + washDataType + ", config=" + JSON.toJSONString(config));

        if (oldVer >= curVer) {
            if (progressCallback != null) {
                progressCallback.onProgress(100, IProgressCallback.TAG_UPDATE_DATA);
            }
            return true;
        }

        try {
            if (progressCallback != null) {
                progressCallback.onProgress(30, IProgressCallback.TAG_UPDATE_DATA);
            }

            // 美易点3.5.4
            if (oldVer < 1) {
                washV1(washDataType);
            }

            // 美易点3.5.6
            if (oldVer < 2) {
                washV2(washDataType);
            }

            if (progressCallback != null) {
                progressCallback.onProgress(99, IProgressCallback.TAG_UPDATE_DATA);
            }
            writeConfig(washDataType, curVer, config);
            if (progressCallback != null) {
                progressCallback.onProgress(100, IProgressCallback.TAG_UPDATE_DATA);
            }
            return true;
        } catch (Exception e) {
            LogUtil.logError(TAG + " 洗数据异常", e);
            if (progressCallback != null) {
                progressCallback.onProgress(100, IProgressCallback.TAG_UPDATE_DATA);
            }
        }
        return false;
    }

    /**
     * 美易点3.5.4
     * 3.5.4版本部分报表需要统计菜品实收
     * 在tbSellOrderItem表新增了fdRealAmt字段（实收），将当前营业日期下所有已结账的订单数据重新生成实收
     */
    private static void washV1(String washDataType) {
        try {
            if (TextUtils.equals(washDataType, WashDataType.AFTER_SYNC)) {
                // 美易点且没打烊
                if (APPConfig.isMyd() && !HostUtil.isShopFinished()) {
                    LogUtil.logBusiness(TAG, "washV1 统计菜品实收 开始");
                    String sql = "select fsSellNo from tbSell where fiBillStatus = '3' and fsSellDate = '%s'";
                    List<String> orderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, String.format(sql, HostUtil.getHistoryBusineeDate("")));
                    if (!ListUtil.isEmpty(orderIdList)) {
                        for (String orderId : orderIdList) {
                            if (!TextUtils.isEmpty(orderId)) {
                                OrderProcessor.createSellCoupon(orderId, true);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogUtil.logError(TAG + "washV1 洗数据异常", e);
        }
    }

    /**
     * 美易点3.5.6
     */
    private static void washV2(String washDataType) {
        try {
            if (TextUtils.equals(washDataType, WashDataType.AFTER_SYNC)) {
                // 美易点
                if (APPConfig.isMyd()) {
                    LogUtil.logBusiness(TAG, "washV2 刷新历史订单账套信息 开始");
                    // 刷历史订单账套信息
                    // hidden/fiSelected == 0 --> B账，fsAccountBook = ',A-id,,B-id,'；hidden/fiSelected == 1 --> A账，fsAccountBook = ',B-id,'；
                    String sqlCacheUpdate = "UPDATE order_cache SET fsAccountBook=CASE WHEN hidden='0' THEN ',1,,2,' WHEN hidden='1' THEN ',2,' ELSE '' END ";
                    String sqlSellUpdate = "UPDATE tbSell SET fsAccountBook=CASE WHEN fiSelected='0' THEN ',1,,2,' WHEN fiSelected='1' THEN ',2,' ELSE '' END ";
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlCacheUpdate);
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlSellUpdate);
                    LogUtil.logBusiness(TAG, "washV2 刷新历史订单账套信息 完成");

                    LogUtil.logBusiness(TAG, "washV2 刷新历史报表账套信息 开始");
                    // 刷报表账套信息，注意：先刷B账的，防止与原值混淆
                    // dailyReport:param1 == 0 --> A账 --> 'A-id'；dailyReport:param1 == 1 --> B账 --> 'B-id'；
                    String sqlReportUpdateB = "UPDATE dailyReport SET param1='2' WHERE param1='1' ";
                    String sqlReportUpdateA = "UPDATE dailyReport SET param1='1' WHERE param1='0' ";
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlReportUpdateB);
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlReportUpdateA);
                    LogUtil.logBusiness(TAG, "washV2 刷新历史报表账套信息 完成");
                }
            }
        } catch (Exception e) {
            LogUtil.logError(TAG + "washV2 洗数据异常", e);
        }
    }

    private static void writeConfig(String washDataType, int newVer, WashDataConfig oldConfig) {
        if (oldConfig == null) {
            return;
        }
        if (TextUtils.equals(WashDataType.BEFORE_SYNC, washDataType)) {
            oldConfig.versionBeforeSync = newVer;
        } else if (TextUtils.equals(WashDataType.AFTER_SYNC, washDataType)) {
            oldConfig.versionAfterSync = newVer;
        }
        DBMetaUtil.updateSettingsValueByKey(META.WASH_DATA_CONFIG, JSON.toJSONString(oldConfig));
    }

    private static WashDataConfig readConfig() {
        String config = DBMetaUtil.getConfig(META.WASH_DATA_CONFIG, "");
        if (TextUtils.isEmpty(config)) {
            return null;
        }
        WashDataConfig washDataConfig = null;
        try {
            washDataConfig = JSON.parseObject(config, WashDataConfig.class);
        } catch (Exception e) {
            LogUtil.logError(TAG + " 解析洗数据配置异常", e);
        }
        return washDataConfig;
    }
}
