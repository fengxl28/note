package com.mwee.android.pos.businesscenter.air.dao;

import com.mwee.android.sqlite.base.DBModel;

import java.util.ArrayList;

/**
 * 数据库表服务通用接口
 * Created by qinwei on 2018/8/17.
 */

public interface IBaseDao<T extends DBModel> {
    T queryById(String id);

    ArrayList<T> queryAll();

    long update(T t);

    long delete(String id);


}
