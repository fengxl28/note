package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/6/5.
 */

public class PrintReportUtil {

    /**
     * 打印各种报表小票
     *
     * @param type         int
     * @param businessDate String
     * @param datas        Map<String, Object>
     * @param hostId       String
     */
    public static List<Integer> printReport(final String type, final String businessDate,
                                            final Map<String, Object> datas, final String hostId) {
        String reportId = "";
        switch (type) {
            case ReportConsrance.REPORT_NEW_DAILY:
            case ReportConsrance.REPORT_DAILY:
                reportId = PrintReportId.DAILY_TABLE;
                break;
            case ReportConsrance.REPORT_SALE:
                reportId = PrintReportId.SALES_VOLUME_TABLE;
                break;
            case ReportConsrance.REPORT_VOID:
                reportId = PrintReportId.SCHEDULE_OF_FOOD_BACK;
                break;
            case ReportConsrance.REPORT_GIFT:
                reportId = PrintReportId.GIVE_FOOD_LIST;
                break;
            case ReportConsrance.REPORT_DISCOUNT:
                reportId = PrintReportId.DISCOUNT_REPORT;
                break;
            case ReportConsrance.REPORT_MAX_SALE_QUANTITY:
                reportId = PrintReportId.HINGHEST_SALES_SCALE;
                break;
            case ReportConsrance.REPORT_MAX_SALE_PRICE:
                reportId = PrintReportId.HINGHEST_SALES_TABLE;
                break;
            case ReportConsrance.REPORT_DEPT: //档口统计表
                reportId = PrintReportId.STATISTICS_OF_ARCHIVES_MOUTHS;
                break;
            case ReportConsrance.REPORT_AB: //AB账
                reportId = PrintReportId.AB_REPORT;
                break;
            case ReportConsrance.REPORT_TIME: //时段统计表
                reportId = PrintReportId.TIME_REPORT;
                break;
            case ReportConsrance.WECHAT_ORDE: //微信外卖
                reportId = PrintReportId.WECHAT_REPORT;
                break;
            case ReportConsrance.NET_ORDER: //外卖
                reportId = PrintReportId.NET_ORDER_REPORT;
                break;
            case ReportConsrance.MEITUAN_NET_ORDER: //美团外卖
                reportId = PrintReportId.MEITUAN_NET_ORDER;
                break;
            case ReportConsrance.WECHAT_FAST_FOOD: //微信外卖
                reportId = PrintReportId.WECHAT_FAST_FOOD;
                break;
            case ReportConsrance.CHECK_BY_DAY: //微信外卖
                reportId = PrintReportId.CHECK_BY_DAY;
                break;
            case ReportConsrance.REPORT_ALL_DISCOUNT: //折扣汇总表
                reportId = PrintReportId.ALL_DISCOUNT_REPORT;
                break;
            case ReportConsrance.REPORT_BUNDLE_SALE: //套餐销量
                reportId = PrintReportId.BUNDLE_NUM;
                break;
            case ReportConsrance.REPORT_SALE_CLS_NUM: //销售分类统计
                reportId = PrintReportId.SALE_CLS_NUM;
                break;
            case ReportConsrance.REPORT_INCOME_CLS_NUM: //收入分类统计
                reportId = PrintReportId.INCOME_CLS_NUM;
                break;
            case ReportConsrance.REPORT_SURCHARGE_DETAIL: //溢收明细
                reportId = PrintReportId.SURCHARGE_DETAIL;
                break;
            case ReportConsrance.REPORT_MEMBER_CHARGE: //会员储值汇总
                reportId = PrintReportId.MEMBER_CHARGE_DATA;
                break;
            default:
                break;
        }
        List<Integer> printTaskIds = new ArrayList<>();

        if (!TextUtils.isEmpty(businessDate) && datas != null && datas.size() > 0 && !TextUtils.isEmpty(reportId)) {
            int printNO = PrintJSONBuilder.generatePrintNO();
            String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");

            PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                    "", "",
                    businessDate,
                    printNO,
                    "",
                    "0",
                    reportId,
                    hostId,
                    true
            );
            task.uri = type;

            task.fsPrnData = JSONObject.toJSONString(datas);
            task.fsPrinterName = fsPrinterName;
            CheckAndPrintUtil.buildTaskEnvAndPrint(task);
            if (!task.printAtOnce) {
                printTaskIds.add(task.fiPrintNo);
            }
        }
        return printTaskIds;

    }

    /**
     * 打印交班表
     *
     * @param businessDate 营业时间
     */
    public static List<Integer> printShiftReceipt(final String hostId, final String businessDate, final HashMap<String, Object> value,
                                                  final String titleRemind) {

        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "",
                businessDate,
                printNO,
                "",
                "0",
                PrintReportId.LOG_TABLE,
                hostId,
                true
        );
        task.uri = "report/shift";

        if (value != null) {
            value.put("titleRemind", titleRemind);
            String shopName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select fsShopName from tbShop where fsShopGUID = '" + HostUtil.getShopID()+"'");
            value.put("fsShopName",shopName);
        }
        task.fsPrnData = JSON.toJSON(value).toString();
        task.fsPrinterName = fsPrinterName;

        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

    /**
     * 打印沽清明细
     *
     * @param hostId
     * @param businessDate
     * @param modelList
     */
    public static List<Integer> printSellout(final String hostId, final String businessDate, List<SellOutViewModel> modelList) {
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "",
                businessDate,
                printNO,
                "",
                "0",
                PrintReportId.SELLOUT_DETAIL,
                hostId,
                true
        );
        task.uri = "report/sellout";
        JSONObject datas = new JSONObject();
        String shopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        String shopName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select fsShopName from tbShop where fsShopGUID = '" +shopGUID+"'");
        datas.put("fsShopName",shopName);
        datas.put("Businessdate", businessDate);
        datas.put("sellout", modelList);
        task.fsPrnData = JSON.toJSON(datas).toString();
        task.fsPrinterName = fsPrinterName;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }

    /**
     * 打印沽清明细
     *
     * @param hostId
     * @param businessDate
     */
    public static List<Integer> printSalesTarget(final String hostId, final String businessDate, Map<String, Object> printParamsMap) {
        List<Integer> printTaskIds = new ArrayList<>();
        int printNO = PrintJSONBuilder.generatePrintNO();
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");

        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(
                "", "",
                businessDate,
                printNO,
                "",
                "0",
                PrintReportId.SALES_TARGET,
                hostId,
                true
        );
        task.uri = "report/processSalesTarget";
        JSONObject datas = new JSONObject();
        String shopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        String shopName = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select fsShopName from tbShop where fsShopGUID = '" +shopGUID+"'");
        datas.put("fsShopName",shopName);
        datas.put("Businessdate", businessDate);
        datas.putAll(printParamsMap);
        task.fsPrnData = JSON.toJSON(datas).toString();
        task.fsPrinterName = fsPrinterName;
        CheckAndPrintUtil.buildTaskEnvAndPrint(task);
        if (!task.printAtOnce) {
            printTaskIds.add(task.fiPrintNo);
        }
        return printTaskIds;
    }
}
