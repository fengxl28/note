package com.mwee.android.pos.businesscenter.business.localpush;

import android.text.TextUtils;

import com.mwee.android.alp.IMsgReceiver;
import com.mwee.android.alp.PushServer;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.component.alp.ServerAction;
import com.mwee.android.tools.LogUtil;

/**
 * 本地推送的消息解析器
 * Created by virgil on 2016/12/13.
 */

public class PushServerReceiver implements IMsgReceiver {
    private static PushServerReceiver instance = new PushServerReceiver();

    private PushServerReceiver() {

    }
//
//    @Override
//    public String getModuleName() {
//        return "lpc";
//    }

    public static PushServerReceiver getInstance() {
        return instance;
    }

    @Override
    public void receive(String uniq, String param) {
        try {
            if (!TextUtils.isEmpty(param)) {
                int indexMsgType = param.indexOf(ServerAction.SYMBOL_SPLIT);
                String actionType = param.substring(0, indexMsgType);
                String value = "";
                if (param.length() > indexMsgType) {
                    value = param.substring(indexMsgType + ServerAction.SYMBOL_SPLIT.length());
                }
                if (TextUtils.isEmpty(value)) {
                    return;
                }
                switch (actionType) {
                    case ServerAction.TRANSFER:
                        PushServer.getInstance().pushMsg(value);
                        break;
                    case ServerAction.TRANSFER_TO:
                        int indexTarget = value.indexOf(ServerAction.SYMBOL_SPLIT);
                        String target = null;
                        String info = value;
                        if (indexTarget >= 0) {
                            target = value.substring(0, indexTarget);
                            info = value.substring(indexTarget + ServerAction.SYMBOL_SPLIT.length());
                        }
                        if (TextUtils.isEmpty(target)) {
                            PushServer.getInstance().pushMsg(value);
                        } else {
                            PushServer.getInstance().pushMsgTo(target, info);
                        }

                        break;
                    case ServerAction.EXCUTE:
                        int indexuri = value.indexOf(ServerAction.SYMBOL_SPLIT);
                        String uri = "";
                        String uriParam = "";

                        if (indexuri < 0) {
                            uri = value;
                        } else {
                            uri = value.substring(0, indexuri);
                            if (value.length() > indexuri) {
                                uriParam = value.substring(indexuri + ServerAction.SYMBOL_SPLIT.length());
                            }
                        }

                        if (TextUtils.isEmpty(uriParam)) {
                            DriverBus.call(uri);
                        } else {
                            Object[] paramList = uriParam.split(ServerAction.SYMBOL_SPLIT);
                            DriverBus.call(uri, paramList);
                        }
                        break;
                    case ServerAction.PARSE:
                        break;
                    default:
                        PushServer.getInstance().pushMsg(value);
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    @Override
    public void connected() {

    }

    @Override
    public void disconnected() {

    }
}
