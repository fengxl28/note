package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.message.UnDealCountMessageModel;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.PhoneDowngradeDBUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageAbnormalOrdersDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.wechatOrder.WechatOrderDBUtil;
import com.mwee.android.pos.businesscenter.netbiz.wechatfastfood.WechatFastFoodApi;
import com.mwee.android.pos.businesscenter.netbiz.wechatfastfood.WechatFastFoodProcessor;
import com.mwee.android.pos.businesscenter.print.PrintRapidOrderUtil;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.message.MessageCenterUnDealResponse;
import com.mwee.android.pos.connect.business.message.MessageFastfoddListResponse;
import com.mwee.android.pos.connect.business.message.MessageOrderListResponse;
import com.mwee.android.pos.connect.business.message.MessagePayListResponse;
import com.mwee.android.pos.connect.business.message.MessageSystemListResponse;
import com.mwee.android.pos.connect.business.message.UpdateMessageOrderResponse;
import com.mwee.android.pos.connect.business.order.PayConfirmResponse;
import com.mwee.android.pos.connect.business.order.RapidOrderConfirmReceiptResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.FastfoodUnDealCountResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.OptWechatFastfoodFromBizResponse;
import com.mwee.android.pos.connect.business.wechatfastfood.UpdateWechatFastfoodResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.message.MessageFastFoodBean;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lxx on 17/2/13.
 * 消息中心
 */
@SuppressWarnings("unused")
public class MessageDriver implements IDriver {

    private static final String TAG = "message";

    /**
     * 获取点菜消息列表
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/ordersList")
    public SocketResponse ordersList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MessageOrderListResponse responseData = new MessageOrderListResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            String time = request.getString("time");         //时间限制
            String areaIds = request.getString("areaIds");      //不接受的区域
            responseData.messageOrderBeanList = MessageDBUtil.getMessageOrders(businessDate, time, areaIds);

            responseData.unDealCountMessageModel = optUnDealCountMessageModel(businessDate, time, areaIds);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取支付消息列表
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/payList")
    public SocketResponse payList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            //MessagePayListRequest request = JSON.parseObject(param, MessagePayListRequest.class);
            JSONObject request = JSON.parseObject(param);
            MessagePayListResponse responseData = new MessagePayListResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            String time = request.getString("time");         //时间限制
            String areaIds = request.getString("areaIds");      //不接受的区域
            responseData.messagePayBeanList = MessageDBUtil.getMessagePay(businessDate, time, areaIds);
            responseData.unDealCountMessageModel = optUnDealCountMessageModel(businessDate, time, areaIds);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/systemList")
    public SocketResponse systemList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            //MessagePayListRequest request = JSON.parseObject(param, MessagePayListRequest.class);
            JSONObject request = JSON.parseObject(param);
            MessageSystemListResponse responseData = new MessageSystemListResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            String time = request.getString("time");         //时间限制
            String areaIds = request.getString("areaIds");      //不接受的区域
            responseData.messageSystemBeanList = MessageDBUtil.getMessageSystem(businessDate, time, areaIds);
            responseData.unDealCountMessageModel = optUnDealCountMessageModel(businessDate, time, areaIds);
            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 未读消息数量
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/unDealCount")
    public SocketResponse unDealCount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            //MessageCenterUnDealRequest request = JSON.parseObject(param, MessageCenterUnDealRequest.class);
            JSONObject request = JSON.parseObject(param);
            MessageCenterUnDealResponse responseData = new MessageCenterUnDealResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            String time = request.getString("time");         //时间限制
            String areaIds = request.getString("areaIds");      //不接受的区域
            responseData.unDealCountMessageModel = optUnDealCountMessageModel(businessDate, time, areaIds);
            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    public static UnDealCountMessageModel optUnDealCountMessageModel(String businessDate, String time, String areaIds) {
        int orderUndealCount = MessageDBUtil.getMessageOrdersUnDealCount(businessDate, time, areaIds);
        int payUndealCount = MessageDBUtil.getMessagePayUnDealCount(businessDate, time, areaIds);
        int netOrderCount = NetOrderDBUtil.getUnDealNetOrderCount() + PhoneDowngradeDBUtil.getMessageMeituanDowngradeUnDealCount();
        if (netOrderCount <= 0) {
            netOrderCount = NetOrderDBUtil.getUnTurnedrderCount();
        }
        int wechatOrderCount = WechatOrderDBUtil.getUnDealWechatOrderCount();
        int systemCount = MessageDBUtil.getMessageSystemUnDealCount(businessDate, time);
        int fastfood = MessageDBUtil.getMessageFastfoodUnDealCount(businessDate);
        int unMappingOrderCount = MessageDBUtil.getUnMappingOrderCount(businessDate);
        int abnormalOrder = MessageAbnormalOrdersDBUtil.optUndealCount();

        UnDealCountMessageModel unDealCountMessageModel = new UnDealCountMessageModel();

        unDealCountMessageModel.orderUndealCount = orderUndealCount;
        unDealCountMessageModel.payUndealCount = payUndealCount;
        unDealCountMessageModel.netOrderCount = netOrderCount;
        unDealCountMessageModel.wechatOrderCount = wechatOrderCount;
        unDealCountMessageModel.systemCount = systemCount;
        unDealCountMessageModel.fastfood = fastfood;
        unDealCountMessageModel.abnormalOrders = abnormalOrder;
        unDealCountMessageModel.unMappingOrderCount = unMappingOrderCount;
        return unDealCountMessageModel;
    }

    /**
     * 更新点菜消息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateMessageOrder")
    public SocketResponse updateMessageOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UpdateMessageOrderResponse responseData = new UpdateMessageOrderResponse();

            int msgId = request.getInteger("msgId");
            String tableId = request.getString("tableId");
            int businessStatus = request.getInteger("businessStatus");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String errMessage;
            if (msgId < 0) {
                errMessage = MessageDBUtil.updateMessageOrderByTableId(tableId, businessStatus, userDBModel);
            } else {
                errMessage = MessageDBUtil.updateMessageOrder(msgId, businessStatus, userDBModel);
            }
            if (TextUtils.isEmpty(errMessage)) {
                response.code = SocketResultCode.SUCCESS;
                NotifyToClient.refrehMessageData();
            } else {
                response.code = 10001;
                response.message = errMessage;
            }
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 打印秒点单确认小票
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/rapidConfirmReceipt")
    public SocketResponse rapidConfirmReceipt(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        RapidOrderConfirmReceiptResponse responseData = new RapidOrderConfirmReceiptResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);

            String userName = request.getString("printUser");
            String hostId = head.hd;
            TempOrderDishesCache tempOrderDishesCache = JSON.parseObject(request.getString("tempOrderDishesCache"), TempOrderDishesCache.class);
            if (tempOrderDishesCache == null) {
                response.message = "秒点消息异常";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.printNoList = PrintRapidOrderUtil.printRapidConfirmMenuList(tempOrderDishesCache, userName, hostId);
            response.code = SocketResultCode.SUCCESS;
            response.message = "打印成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常";
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 忽略秒付纯收银消息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/ignoreRapid")
    public SocketResponse ignoreRapid(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        RapidOrderConfirmReceiptResponse responseData = new RapidOrderConfirmReceiptResponse();
        response.data = responseData;
        try {
            //IgnoreRapidOnlyPayOrderRequest request = JSON.parseObject(param, IgnoreRapidOnlyPayOrderRequest.class);
            JSONObject request = JSON.parseObject(param);
            int msgId = request.getIntValue("msgID");

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            Map<String, String> map = new HashMap<>();
            map.put("tableName", "");  //桌台名称
            map.put("payAmt", Calc.formatShow(request.getBigDecimal("payAmt")));  //已支付金额
            map.put("allAmt", "0.0");  //订单总金额
            //将秒付纯收银消息置为已处理
            MessageDBUtil.updateRapidOnlyPayMessage(request.getIntValue("msgID"), MessageConstance.MessagePayBuinessStatus.RAPID_ONLY_PAY.IGNORE, userDBModel, "", "", JSON.toJSONString(map));

            NotifyToClient.refreshUndealMessage();
            NotifyToClient.refrehMessageData();

            response.code = SocketResultCode.SUCCESS;
            response.message = "处理成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常";
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 忽略\允许秒付拉单确认消息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updatePayConfirm")
    public SocketResponse updatePayConfirm(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        RapidOrderConfirmReceiptResponse responseData = new RapidOrderConfirmReceiptResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            int msgId = request.getIntValue("msgID");
            int businessStatus = request.getIntValue("businessStatus");

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);

            //将秒付纯收银消息置为已处理
            MessageDBUtil.updateRapidPayConfirmMessage(msgId, businessStatus, userDBModel);

            NotifyToClient.refreshUndealMessage();
            NotifyToClient.refrehMessageData();

            response.code = SocketResultCode.SUCCESS;
            response.message = "处理成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常";
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 所有未处理秒付拉单确认消息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/unDealConfirmMessageList")
    public SocketResponse unDealConfirmMessageList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PayConfirmResponse responseData = new PayConfirmResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);

            responseData.payConfirmBeanList = MessageDBUtil.getUnDealPayConfirmMessage();

            response.code = SocketResultCode.SUCCESS;
            response.message = "处理成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常";
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/addXMPPLoginErrorMsg")
    public SocketResponse addXMPPLoginErrorMsg(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        //添加xmpp 登录信息
        try {
            MessageBiz.addXMPPLoginErrorMsg(param);
            response.message = "新增xmpp登录失败信息成功";
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "新增xmpp登录失败信息失败";
        }
        return response;
    }


    /**
     * 获取快餐消息列表
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/fastfoodList")
    public SocketResponse fastfoodList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MessageFastfoddListResponse responseData = new MessageFastfoddListResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            String time = request.getString("time");         //时间限制
            String areaIds = request.getString("areaIds");      //不接受的区域
            responseData.messageFastFoodBeenList = MessageDBUtil.getMessageFastfoodList(businessDate);
            responseData.unDealCountMessageModel = optUnDealCountMessageModel(businessDate, time, areaIds);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getUnDealFastFoodMsgCount")
    public SocketResponse getUnDealFastFoodMsgCount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            FastfoodUnDealCountResponse responseData = new FastfoodUnDealCountResponse();
            String businessDate = request.getString("businessDate"); //营业日期
            responseData.count = MessageDBUtil.getMessageFastfoodUnDealCount(businessDate);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optWechatfastfoodById")
    public SocketResponse optWechatfastfoodById(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            final OptWechatFastfoodFromBizResponse myResponseData = new OptWechatFastfoodFromBizResponse();
            final String outerOrderId = request.getString("outerOrderId"); //订单号
            try {
                myResponseData.messageFastFoodBean = MessageDBUtil.getMessageFastfood(outerOrderId);

                response.data = myResponseData;
                response.code = SocketResultCode.SUCCESS;

                myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(request.getString("businessDate"), request.getString("time"), request.getString("areaIds"));
            } catch (Exception e) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                LogUtil.logError(e);
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 更新微信快餐订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateWechatFastfood")
    public SocketResponse updateWechatFastfood(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final UpdateWechatFastfoodResponse myResponseData = new UpdateWechatFastfoodResponse();

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            final String outerOrderId = request.getString("outerOrderId"); //订单号

            ServerCache.getInstance().wechatFastfoodCache.doLock(outerOrderId, userDBModel.fsUserName + " 操作更新订单状态 diningStatus=" + request.getString("diningStatus") + "， 站点：" + head.hd);

            final String diningStatus = request.getString("diningStatus"); //订单操作
            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            final String areaIds = request.getString("areaIds"); //区域id

            MessageFastFoodBean fastFoodBean = MessageDBUtil.getMessageFastfood(outerOrderId);
            if (fastFoodBean == null) {
                response.message = "订单异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            final String fsOrderNo = fastFoodBean.sellNo;
            final String number = fastFoodBean.number();

            IResponse<String> iResponse = new IResponse<String>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, String info) {
                    if (result) {
                        if (TextUtils.equals("-2", diningStatus) || TextUtils.equals("-1", diningStatus)) {
                            MessageOrderUtil.updateFastFoodMsg(outerOrderId, fsOrderNo, number, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.REJECT);
                        } else {
                            RapidPrePayFastfoodBiz.releaseBusyMealNumber(number);  //释放牌号
                            MessageOrderUtil.updateFastFoodMsg(outerOrderId, fsOrderNo, number, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.PREPARED);
                        }
                        response.message = "success";
                        response.code = SocketResultCode.SUCCESS;
                    } else {
                        response.message = msg;
                        response.code = SocketResultCode.BUSINESS_FAILED;
                    }
                    myResponseData.fastFoodBean = MessageDBUtil.getMessageFastfood(outerOrderId);
                    myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                    response.data = myResponseData;
                }
            };

            WechatFastFoodApi.updateWechatFastFoodStatus(outerOrderId, diningStatus, fsOrderNo, number, 5, iResponse);
            ServerCache.getInstance().wechatFastfoodCache.unLock(outerOrderId, userDBModel.fsUserName + " 操作更新订单状态结束 diningStatus=" + diningStatus + "， 站点：" + head.hd + ";[" + fsOrderNo + "," + number + "]");
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 扫码触发微信快餐已备餐状态更改
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/notifiyServerMenuPrepared")
    public SocketResponse notifiyServerMenuPrepared(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final String msgId = request.getString("msgId"); //消息ID

            MessageFastFoodBean fastFoodBean = MessageDBUtil.getMessageFastfoodByMsgId(msgId);
            if (fastFoodBean == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未找到有效订单，请稍后重试 " + msgId;
                return response;
            }
            if (fastFoodBean.businessStatus == MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.PREPARED) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单状态已变化，请刷新重试 " + fastFoodBean.businessStatus;
                return response;
            }
            WechatFastFoodProcessor.notifiyServerMenuPrepared(msgId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 微信快餐接单
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getWechatFastfood")
    public SocketResponse getWechatFastfood(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final UpdateWechatFastfoodResponse myResponseData = new UpdateWechatFastfoodResponse();

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            final String outerOrderId = request.getString("outerOrderId"); //订单号

            ServerCache.getInstance().wechatFastfoodCache.doLock(outerOrderId, userDBModel.fsUserName + " 操作接单， 站点：" + head.hd);
            int businessStatus = MessageBiz.optFastFoodMsgBusinessStatus(outerOrderId);
            if (businessStatus == -1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单已发生变化，请刷新重试 " + businessStatus;
                return response;
            } else if (businessStatus != MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.NONE) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "订单状态已变化，请重新重试 " + businessStatus;
                return response;
            }

            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            final String areaIds = request.getString("areaIds"); //区域id

            final String fsSellNo = OrderDriver.generateNewOrderID();
            final String mealNumber = RapidPrePayFastfoodBiz.getWechatFastFoodMealNumber();
            IResponse<String> iResponse = new IResponse<String>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, String info) {
                    if (result) {
                        RapidActionModel resultData = new RapidActionModel();
                        MessageOrderUtil.saveRelation(fsSellNo, outerOrderId);
                        String errMsg = MessageOrderUtil.getWechatFastfoodOrder(resultData, outerOrderId, fsSellNo, mealNumber);
                        if (TextUtils.isEmpty(errMsg)) {
                            NotifyToClient.orderChange(fsSellNo);
                            MessageOrderUtil.updateFastFoodMsg(outerOrderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.GET);
                            response.message = "success";
                            response.code = SocketResultCode.SUCCESS;
                        } else {
                            response.message = errMsg;
                            response.code = SocketResultCode.BUSINESS_FAILED;
                        }
                    } else {
                        response.message = msg;
                        response.code = SocketResultCode.BUSINESS_FAILED;
                    }
                    myResponseData.fastFoodBean = MessageDBUtil.getMessageFastfood(outerOrderId);
                    myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                    response.data = myResponseData;
                }
            };

            WechatFastFoodApi.getOrderRequest(outerOrderId, fsSellNo, mealNumber, 5, iResponse, false);
            ServerCache.getInstance().wechatFastfoodCache.unLock(outerOrderId, userDBModel.fsUserName + " 接单操作结束， 站点：" + head.hd + ";[" + fsSellNo + "," + mealNumber + "]");

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
