package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.business.print.PrintUtil;
import com.mwee.android.pos.businesscenter.business.localpush.MessageBean;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.localpush.PushMsgManager;
import com.mwee.android.pos.businesscenter.business.localpush.PushMsgManager.MessageType;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.business.print.CheckPrintTemplet;

/**
 * 打印任务构建。
 * 业务中心构建
 * Created by liuxiuxiu on 2017/6/15.
 */
public class CheckAndPrintUtil {


    /**
     * 构建打印任务的相关环境参数。
     * 包括：
     * 1，备用打印机的检测{@link #prepare(PrintTaskDBModel, boolean)}
     * 2，小票尺寸{@link #prepare(PrintTaskDBModel,boolean)}
     * 3，是否可以直接打印{@link PrintTaskDBModel#printAtOnce}
     * 4，不能直接打印时的站点ID{@link PrintTaskDBModel#fsHostId}
     * <p>
     * 然后检测能否直接打印：
     * A，如果能够直接打印，则调用{@link PrintConnector#print(PrintTaskDBModel, boolean)}进行打印
     * B，如果不能直接打印，则推送消息到能打印的站点进行打印
     *
     * @param task PrintTaskDBModel
     */
    public static void buildTaskEnvAndPrint(PrintTaskDBModel task) {
        if (TextUtils.equals("device/openmoneybox", task.uri) && TextUtils.isEmpty(task.fsPrnData)) {
            RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印出现异常，buildTaskEnvAndPrint() 收到数据异常；没有fsPrnData数据", JSON.toJSONString(task));
        }
        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildTaskEnvAndPrint--start--PrintNo:"+ task.fiPrintNo );
        buildTaskEnv(task,false);
        if (TextUtils.equals("device/openmoneybox", task.uri) && TextUtils.isEmpty(task.fsPrnData)) {
            RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印出现异常，buildTaskEnvAndPrint()----buildTaskEnv后 数据异常；没有fsPrnData数据", JSON.toJSONString(task));
        }

        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildTaskEnvAndPrint--55--PrintNo:"+ task.fiPrintNo);
        PrintConnector.getInstance().print(task);
        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildTaskEnvAndPrint--58--PrintNo:"+ task.fiPrintNo);
        if (!task.printAtOnce) {
//            NotifyToClient.printReceipt(task.fsHostId, task);
            MessageBean printMessage = new MessageBean(MessageType.TPYE_PRINTTASK,task.fsHostId, "login/printReceipt",JSON.toJSONString(task));
            printMessage.setMaxRetryTimeLen(12*60);
            printMessage.setRetryDelay(20*1000);
            PushMsgManager.getInstance().send(printMessage);
        }
        if (TextUtils.equals("device/openmoneybox", task.uri) && TextUtils.isEmpty(task.fsPrnData)) {
            RunTimeLog.addLog(RunTimeLog.PRINTER_TASK_ERR, "打印出现异常，buildTaskEnvAndPrint()----方法执行结束后 数据异常；没有fsPrnData数据", JSON.toJSONString(task));
        }
        LogUtil.logOnlineDebug("--order--bizCenter--openAndCheckToOrder--buildTaskEnvAndPrint--end----PrintNo:"+ task.fiPrintNo);
    }

    public static void buildTaskEnvAndPrint(PrintTaskDBModel... tasks) {
        if (tasks != null && tasks.length > 0) {
            for (PrintTaskDBModel task : tasks) {
                buildTaskEnvAndPrint(task);
            }
        }
    }

    public static void buildTaskEnv(PrintTaskDBModel task,boolean isReprint) {
        prepare(task,isReprint);
        if (!PrintConnector.getInstance().canTouchPrinterDevice(task)) {
            task.printAtOnce = false;
        }
    }

    /**
     * 处理一下打印任务的默认状态
     * 包括：
     * 1，打印尺寸；
     * 2，是否切换到备用打印机
     *
     * @param taskModel PrintTaskDBModel
     * @param isReprint 是否为重打
     * @return PrintTaskDBModel
     */
    private static PrintTaskDBModel prepare(PrintTaskDBModel taskModel,boolean isReprint) {
        JSONObject config = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsCommandType,fiPaperSize from tbPrinter where fsPrinterName='" + taskModel.fsPrinterName + "'");
        int printerPaperSize = 2;
        String commandType = "";
        if (config != null) {
            printerPaperSize = StringUtil.toInt(config.getString("fiPaperSize"), 2);
            commandType = config.getString("fsCommandType");
        }
        taskModel.fiStatus = 1;
        taskModel.is_backup_printer = 0;
        taskModel.fsbakprintername = "";
        //默认使用打印机本身的尺寸,默认不使用Task的size

        taskModel.fiPaperSize = PrintUtil.getSize(commandType, printerPaperSize);
        if (TextUtils.equals(taskModel.fsHostId, HostBiz.mealorder) || TextUtils.equals(taskModel.fsHostId, HostBiz.localhost) || TextUtils.equals(taskModel.fsHostId, HostBiz.cloudsite)) {
            taskModel.fsHostId = ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        }
        //如果不是重打就构建模版数据（当从使用模版打印切换为不使用模版打印，此时重打小票，会导致小票上没数据）
        if(!isReprint){
            taskModel.fsPrnData2=CheckPrintTemplet.checkKeyTemplet(taskModel.uri);
        }
        reCheckPrinter(taskModel);
//        taskModel.replaceNoTrans();
        RunTimeLog.addLog(RunTimeLog.PRINT_NEW_TASK, "receiveTask PrintStub prepare", String.valueOf(taskModel.fiPrintNo), taskModel.fsReportName + "],printerName=[" + taskModel.fsPrinterName);
        return taskModel;
    }

    /**
     * 检查当前打印任务对应的打印机是否切换到了备用打印机
     *
     * @param taskModel PrintTaskDBModel
     */
    public static void reCheckPrinter(PrintTaskDBModel taskModel) {
        if (taskModel.is_backup_printer == 1 && !TextUtils.isEmpty(taskModel.fsbakprintername)) {
            return;
        }
        String target = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsbakprintername from tbPrinter  where switch_backup='1' and fsPrinterName='" + taskModel.fsPrinterName + "'");
        if (!TextUtils.isEmpty(target)) {
            taskModel.fsbakprintername = target;
            taskModel.is_backup_printer = 1;
        }
    }
}
