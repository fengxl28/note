package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderModel;
import com.mwee.android.pos.connect.business.fastfood.model.FastOrderynamicDMode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.fastfood.FastFoodSimpInfo;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.FastFoodOrderBizDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/4/10.
 * 快餐业务
 */
public class FastFoodBusinessUtil {

    /**
     * orderCache 转成FastOrderynamicDMode
     *
     * @param orderCache
     * @return
     */
    public static FastOrderynamicDMode optFastOrderynamicDMode(OrderCache orderCache) {
        FastOrderynamicDMode fastOrderynamicDMode = new FastOrderynamicDMode();
        fastOrderynamicDMode.count = orderCache.originMenuList.size();
        fastOrderynamicDMode.totalAmt = orderCache.optTotalMenuPrice();
        fastOrderynamicDMode.CouponCutMoneyInfo = orderCache.couponCut == null ? "" : orderCache.couponCut.fsBargainName + "  -" + Calc.formatShow(orderCache.couponCut.fdCutmoney);

        /**
         * 优惠金额
         */
        fastOrderynamicDMode.discountAmt = orderCache.totalDiscountAmount;

        /**
         * 满减金额
         */
        fastOrderynamicDMode.couponCut = orderCache.couponCut;

        if (orderCache.selectOrderDiscountCut != null) {
            fastOrderynamicDMode.fsDiscountCutId = orderCache.selectOrderDiscountCut.fsDiscountId;
            fastOrderynamicDMode.fdDiscountCutAmt = orderCache.selectOrderDiscountCut.fdddv;
        }

        if (!ListUtil.listIsEmpty(orderCache.originMenuList)) {
            BigDecimal cut = BigDecimal.ZERO;
            if (orderCache.couponCut != null && orderCache.couponCut.fdCutmoney.compareTo(BigDecimal.ZERO) > 0) {
                cut = orderCache.couponCut.fdCutmoney;
            }
            fastOrderynamicDMode.totalAmt = orderCache.optTotalMenuPrice().subtract(cut);
        }
        return fastOrderynamicDMode;
    }

    /**
     * orderCache 转换成 FastOrderModel
     *
     * @param orderCache
     * @return
     */
    public static FastOrderModel turnOrderCacheToFastOrderModel(OrderCache orderCache) {
        FastOrderModel fastOrderModel = new FastOrderModel();
        if (orderCache == null) {
            return fastOrderModel;
        }
        fastOrderModel.orderId = orderCache.orderID;
        fastOrderModel.thirdOrderId = orderCache.thirdOrderId;
        fastOrderModel.thirdOrderType = orderCache.thirdOrderType;
        fastOrderModel.orderSeqModels.addAll(orderCache.seqList);
        fastOrderModel.orderSeqId = orderCache.currentSeq;
        fastOrderModel.mealNumber = orderCache.mealNumber;
        fastOrderModel.personNumber = orderCache.personNum;
        fastOrderModel.billSourceId = orderCache.fsBillSourceId;
        fastOrderModel.billSourceName = FastFoodDBUtil.getBillSourceName(orderCache.fsBillSourceId);
        //前端显示菜品总价
        fastOrderModel.totalPrice = orderCache.optTotalMenuPrice();
        fastOrderModel.fsDiscountCutId = orderCache.selectOrderDiscountCut == null ? "" : orderCache.selectOrderDiscountCut.fsDiscountId;
        fastOrderModel.memberInfoS = orderCache.memberInfoS;
        fastOrderModel.isMember = orderCache.isMember;
        fastOrderModel.discountAmt = orderCache.totalDiscountAmount;
        fastOrderModel.sectionId = orderCache.currentSectionID;
        if (orderCache.selectOrderDiscountCut != null) {
            fastOrderModel.fsDiscountCutId = orderCache.selectOrderDiscountCut.fsDiscountId;
            fastOrderModel.fdDiscountCutAmt = orderCache.selectOrderDiscountCut.fdddv;
        }
        if (!ListUtil.listIsEmpty(orderCache.originMenuList)) {
            BigDecimal cut = BigDecimal.ZERO;
            if (orderCache.couponCut != null && orderCache.couponCut.fdCutmoney.compareTo(BigDecimal.ZERO) > 0) {
                cut = orderCache.couponCut.fdCutmoney;
                fastOrderModel.discountMsg = orderCache.couponCut.fsBargainName + "：-" + cut.toString();
            }
            fastOrderModel.totalPrice = orderCache.optTotalMenuPrice().subtract(cut);
        }
        return fastOrderModel;
    }

    /**
     * 开单
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static synchronized OrderCache startFastFoodOrder(String waiterID, String waiterName, String hostId, String fsBillSourceId) {
        return startFastFoodOrder(waiterID, waiterName, hostId, fsBillSourceId,1);
    }

    /**
     * 开单
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static synchronized OrderCache startFastFoodOrder(String waiterID, String waiterName, String hostId, String fsBillSourceId,int personNum) {
        OrderCache orderCache = null;
        //1查询fastfood_order_biz表中有没有下单并且未被锁定的订单
        String sql = "select order_id from fastfood_order_biz where fastfood_biz_status = '0' and lockedStatus = '0' and business_date = '" + HostUtil.getHistoryBusineeDate("") + "' and order_id not in (select order_id from order_pay_cache where business_date = '" + HostUtil.getHistoryBusineeDate("") + "' and payed = '0') limit 1";
        String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (!TextUtils.isEmpty(orderId)) {
            orderCache = OrderSession.getInstance().getOrder(orderId);
        }

        if (orderCache == null) {
            //2、新生成一个订单
            orderCache = createNewOrderCache(waiterID, waiterName, hostId, fsBillSourceId,personNum);
        } else {
            orderCache.isMember = false;
            orderCache.memberInfoS = null;
            orderCache.originMenuList.clear();
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().refreshCacheOrder(orderCache);
        }
        if (TextUtils.isEmpty(orderCache.mealNumber) && autoMealNOMode()) {
            //自动生成牌号
            orderCache.mealNumber = DataCacheDBUtil.generateNewMealNumber();
        }
        //重置开单人和订单来源
        orderCache.waiterName = waiterName;
        orderCache.fsBillSourceId = fsBillSourceId;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false,"startFastFoodOrder");
        return orderCache;
    }

    /**
     * 创建一个新的订单 OrderCache
     * 允许没有OrderID
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static OrderCache createNewOrderCache(String waiterID, String waiterName, String hostId, String fsBillSourceId,int personNum) {
        return createNewOrderCache("", waiterID, waiterName, hostId, fsBillSourceId, personNum, 0);
    }

    /**
     * 创建一个新的订单 OrderCache
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static OrderCache createNewOrderCache(String waiterID, String waiterName, String hostId, String fsBillSourceId) {
        //新生成有个订单号
//        String orderId = OrderDriver.generateNewOrderID();
        return createNewOrderCache("", waiterID, waiterName, hostId, fsBillSourceId);
    }

    /**
     * 创建一个新的订单 OrderCache
     * 允许没有OrderID
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static OrderCache createNewOrderCache(String fsSellNo, String waiterID, String waiterName, String hostId, String fsBillSourceId) {
        return createNewOrderCache(fsSellNo, waiterID, waiterName, hostId, fsBillSourceId, 1, 0);
    }

    /**
     * 创建一个新的订单 OrderCache
     * 允许没有OrderID
     *
     * @param waiterID   //锁单发起人ID
     * @param waiterName //锁单发起人Name
     * @param hostId     //锁单站点ID
     * @return
     */
    public static OrderCache createNewOrderCache(String fsSellNo, String waiterID, String waiterName, String hostId, String fsBillSourceId, int lockedStatus) {
        return createNewOrderCache(fsSellNo, waiterID, waiterName, hostId, fsBillSourceId, 1, lockedStatus);
    }

    public static OrderCache createNewOrderCache(String fsSellNo, String waiterID, String waiterName, String hostId, String fsBillSourceId, int personNum, int lockedStatus) {
        OrderCache orderCache;
        if (!TextUtils.isEmpty(fsSellNo)) {
            orderCache = OrderDriver.generateNewOrder(fsSellNo);
        } else {
            orderCache = OrderDriver.generateNewOrder();
        }
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = waiterID;
        orderCache.waiterName = waiterName;
        orderCache.shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        orderCache.currentHostID = hostId;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        orderCache.businessDate = HostUtil.getHistoryBusineeDate("");
        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.fiSellType = 1;
        orderCache.personNum = personNum;
        orderCache.mealNumber = "";
        if (TextUtils.isEmpty(fsBillSourceId) || TextUtils.equals("-1", fsBillSourceId)) {
            fsBillSourceId = "1";
        }
        orderCache.fsBillSourceId = fsBillSourceId;

        orderCache.updateSeqStatus(1, OrderSeqStatus.NORMAL, null, "");
        //保存订单
        if (!TextUtils.isEmpty(orderCache.orderID)) {
            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false,"createNewOrderCache");
            FastFoodDBUtil.save(lockedStatus, orderCache);
        }
        return orderCache;
    }


    /**
     * 是否自动牌号
     *
     * @return
     */
    public static boolean autoMealNOMode() {
        return TextUtils.equals("1", DBMetaUtil.getSettingsValueByKey(META.FASTFOOD_MEAL_NO_AUTO));
    }


    /**
     * 获取所有快餐订单简讯
     *
     * @return
     */
    public static final List<FastFoodSimpInfo> qurySimpOrderInfos(String businessDate, String fsBillSourceId) {
        String sql = "select orderBiz.order_id order_id, order_cache.fsBillSourceId fsBillSourceId,order_cache.mealNumber mealNumber,billSource.fsBillSourceName fsBillSourceName, orderBiz.opentime as create_time, IFNULL(payInfo.hasPayInfo, 0) hasPayInfo " +
                "from fastfood_order_biz as orderBiz " +
                "left join " +
                "(select fsSellNo, count(*) as hasPayInfo from tbSellReceive where fiStatus <> '13' and fsSellDate = '" + businessDate + "' and isCouponMoney <> '1' group by fssellno ) as payInfo " +
                "on orderBiz.order_id = payInfo.fsSellNo ";
//        if (!TextUtils.equals("-1", fsBillSourceId)){  //是否筛选订单来源
        sql += " left join order_cache on order_cache.order_id = orderBiz.order_id ";
        sql += " left join (select fsBillSourceName,fsBillSourceId from tbBillSource group by fsBillSourceName) billSource  on order_cache.fsBillSourceId = billSource.fsBillSourceId ";

//        }

        sql += "where (" +
                " orderBiz.fastfood_biz_status in ('1','3') or " +
                "(orderBiz.fastfood_biz_status = '0' and orderBiz.order_id in (select order_id from order_pay_cache where business_date = '" + businessDate + "'))" +
                ") " +
                "and orderBiz.business_date = '" + businessDate + "' ";

        if (!TextUtils.equals("-1", fsBillSourceId)) {  //是否筛选订单来源
            //查询多个来源订单
            if (fsBillSourceId.contains(",")) {
                sql += " and order_cache.fsBillSourceId in (" + fsBillSourceId + ")";
            } else {
                sql += " and order_cache.fsBillSourceId ='" + fsBillSourceId + "'";
            }
        }

        sql += " order by orderBiz.order_id asc";

        List<FastFoodSimpInfo> fastFoodSimpInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, FastFoodSimpInfo.class);
        if (ListUtil.listIsEmpty(fastFoodSimpInfos)) {
            fastFoodSimpInfos = new ArrayList<>();
        }
        return fastFoodSimpInfos;
    }

    private static Object lockOrderLock = new Object();

    /**
     * 检测桌台锁定
     *
     * @param hostID  String
     * @param userID  String
     * @param orderId String
     * @return
     */
    public static String checkOrderLock(String hostID, String userID, String orderId) {
        String errorInfo = "";
        synchronized (lockOrderLock) {
            FastFoodOrderBizDBModel model = FastFoodDBUtil.optFastFoodOrderBizById(orderId);

            //如果桌台目前没有被锁定，
            if (model == null || model.lockedStatus == 0) {
                errorInfo = "";
            } else if (TextUtils.equals(hostID, model.lockedHostId)) {
                errorInfo = "";
                unLockOrderByOrderId(orderId);
            } else {
                boolean locked = false;
                if (!(TextUtils.equals(hostID, model.lockedHostId) && TextUtils.equals(userID, model.lockedUserID))) {
                    //如果桌台已被锁定，判断指定站点登录的服务员是否和锁定的服务员一致。
                    //如果不一致，则意味着出现了异常，导致原来未能释放桌台的锁定，此时则清除该桌台的锁定状态
                    if (!TextUtils.equals(HostBiz.mealorder, hostID)) {
                        String loginUserID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select current_user_id from host_status where hostid='" + model.lockedHostId + "'");
                        if (!TextUtils.equals(model.lockedUserID, loginUserID)) {
                            errorInfo = "";
                            unLockOrderByOrderId(orderId);
                        } else {
                            locked = true;
                        }
                    } else {
                        locked = true;
                    }
                }
                if (locked) {
                    errorInfo = "该订单目前由[" + model.lockedUserName + "]在[" + model.lockedHostId + "]操作";
                }
            }
        }
        return errorInfo;
    }

    /**
     * 锁单
     *
     * @param orderId  订单ID
     * @param userId   服务员ID
     * @param userName 服务员Name
     * @param hostId   站点ID
     */
    public static void lockedOrder(String orderId, String userId, String userName, String hostId) {
        //鎖桌前释放当前站点下的其他桌台
        unLockOrderByHostId(hostId);
        unLockOrderByUserId(userId);
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set lockedStatus='1',lockedUserID='" + userId +
                "',lockedHostId='" + hostId + "',lockedUserName='" + userName + "' where order_id='" + orderId + "' ");
    }

    /**
     * 更新订单业务状态
     *
     * @param orderId 订单ID
     */
    public static void updateOrderBizStatus(String orderId) {
        int bizStatus = 0;
        Integer status = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, "select count(*) as items from tbSellOrderItem where fsSellNo='" + orderId + "'", "items", Integer.class);
        if (status != null) {//是否有已下单的菜
            bizStatus = 1;
            status = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, "select payed from order_pay_cache where order_id='" + orderId + "'", "payed", Integer.class);
            if (status != null && status.intValue() == 1) {//支付状态是已结账
                bizStatus = 2;
            }
        }
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set fastfood_biz_status='" + bizStatus + "' where order_id='" + orderId + "' ");
    }

    /**
     * 更新订单业务状态
     *
     * @param orderId   订单ID
     * @param bizStatus 业务状态 0:新开单； 1： 已有下单的菜品； 2：已完成结账
     */
    public static void updateOrderBizStatus(String orderId, int bizStatus) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set fastfood_biz_status='" + bizStatus + "' where order_id='" + orderId + "' ");
    }


    /**
     * 解锁某站点的锁单
     *
     * @param hostId 站点ID
     */
    public static void unLockOrderByHostId(String hostId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where lockedHostId='" + hostId + "' ");

    }

    /**
     * 解锁指定服务员的锁单
     *
     * @param userID 服务员ID
     */
    public static void unLockOrderByUserId(String userID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where lockedUserID='" + userID + "' ");
    }

    /**
     * 解锁指定订单
     *
     * @param orderId 订单ID
     */
    public static void unLockOrderByOrderId(String orderId) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update fastfood_order_biz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where order_id='" + orderId + "' ");
    }
}
