package com.mwee.android.pos.businesscenter.socket;

import android.net.TrafficStats;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.base.task.LowThread;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.NameConstant;
import com.mwee.android.pos.businesscenter.netbiz.UriMapping;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.Logger;
import com.mwee.android.pos.connect.config.SocketConfig;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SerializeUtil;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketRequest;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.SafeUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 业务中心的服务器
 *
 * @ClassName: SocketServer
 * @Description:
 * @author: SugarT
 * @date: 16/8/16 上午10:09
 */
public class SocketServer {

    /**
     * 任务重试间隔时间
     */
    public static final int RETRY_INTEVAL = 500;
    private static final String TAG = "SocketServer";
    private final static SocketServer _instance = new SocketServer();
    private static ThreadPoolExecutor serverExecutor = null;
    private static String shopid;
    /**
     * 不校验shopId的uriList
     */
    private static List<String> ignoreShopIdUriList;
    /**
     * 不校验登录token的uriList
     */
    private static List<String> ignoreUriList;
    /**
     * 不校验版本号的uriList
     */
    private static List<String> ignoreVersionUriList;
    private List<ServerThread> mServerThreads = new ArrayList<>();

    private SocketServer() {

    }

    public static SocketServer getInstance() {
        return _instance;
    }

    private static String getShopID() {
        if (TextUtils.isEmpty(shopid)) {
            shopid = HostUtil.getShopID();
        }
        return shopid;
    }

    public static void pushTask(Runnable runnable) {
        if (serverExecutor == null) {
            getInstance().checkInit();
        }
        serverExecutor.execute(runnable);
    }

    public synchronized void checkInit() {


        checkAlive();
        if (serverExecutor == null) {
            serverExecutor = new ThreadPoolExecutor(4, 40, 2, TimeUnit.MINUTES, new SynchronousQueue<>(), new ThreadFactory() {
                @Override
                public Thread newThread(@NonNull Runnable r) {
                    Thread th = new Thread(r);
                    th.setName("MYD_SNetPool_" + SystemClock.elapsedRealtime());
                    th.setPriority(8);
                    return th;
                }
            }, (r, executor) -> {
                RunTimeLog.addLog(RunTimeLog.SYS_SERVER_QUEUE, "线程队列已满");
                if (BaseConfig.isProduct()) {
                    new LowThread(r).start();
                    synchronized (SocketServer.this) {
                        try {
                            if (serverExecutor != null) {
                                serverExecutor.shutdown();
                            }
                        } finally {
                            serverExecutor = null;
                        }
                    }
                } else {
                    ToastUtil.showToast("线程队列已满");
                }
            });
        }

        if (ListUtil.isEmpty(ignoreUriList)) {
            ignoreUriList = new ArrayList<>();
            Collections.addAll(ignoreUriList, UriMapping.ignoreSession);
        }

        if (ListUtil.isEmpty(ignoreVersionUriList)) {
            ignoreVersionUriList = new ArrayList<>();
            Collections.addAll(ignoreVersionUriList, UriMapping.ignoreVersion);
        }

        if (ListUtil.isEmpty(ignoreShopIdUriList)) {
            ignoreShopIdUriList = new ArrayList<>();
            Collections.addAll(ignoreShopIdUriList, UriMapping.ignoreShopId);
        }
    }

    public void destory() {
        if (mServerThreads != null && !mServerThreads.isEmpty()) {
            try {
                for (int i = 0; i < mServerThreads.size(); i++) {
                    ServerThread temp = mServerThreads.get(i);
                    try {
                        temp.disconnect();
                        temp.finish();
                        temp.interrupt();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    mServerThreads.remove(i);
                    i--;
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
        if (serverExecutor != null) {
            serverExecutor.shutdown();
            serverExecutor = null;
        }
    }

    public void checkAlive() {
        if (ListUtil.listIsEmpty(mServerThreads)) {
            for (int i = 0; i < SocketConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = new ServerThread(SocketConfig.PORT_LIST[i]);
                serverThread.start();
                mServerThreads.add(serverThread);
            }
        } else {
            for (int i = 0; i < SocketConfig.PORT_LIST.length; i++) {
                ServerThread serverThread = mServerThreads.get(i);
                boolean alive = true;
                if (serverThread.finish || !serverThread.isAlive() || serverThread.isInterrupted()) {
                    alive = false;
                    try {
                        serverThread.interrupt();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                LogUtil.log("SocketServer check Alive " + SocketConfig.PORT_LIST[i] + " " + (alive ? "alive" : "dead"));

                if (!alive) {
                    serverThread = new ServerThread(SocketConfig.PORT_LIST[i]);
                    serverThread.start();
                    mServerThreads.set(i, serverThread);
                }
            }
        }
    }

    private static class ServerThread extends Thread {


        public volatile boolean finish = false;
        int retryTimes = 0;
        private int socketPort;
        private ServerSocket mServer;
        private Socket mSocket;

        private ServerThread(int port) {
            socketPort = port;
            setDaemon(false);
            retryTimes = 0;
        }

        @Override
        public void run() {
            connect();
        }

        public synchronized void finish() {
            finish = true;
        }

        private synchronized boolean checkFinish() {
            return finish;
        }

        /**
         * 连接
         */
        private void connect() {
            try {
                if (BindProcessor.isActived() && !BindProcessor.isCurrentHostMain()) {
                    finish();
                    return;
                }
                mServer = new ServerSocket();
                mServer.setReuseAddress(true);
                mServer.bind(new InetSocketAddress(socketPort));
                while (true) {
                    retryTimes = 0;
                    if (checkFinish()) {
                        break;
                    }
                    LogUtil.log(TAG, "start listen, port=" + socketPort);
                    if (BaseConfig.isDEV()) {
                        TrafficStats.setThreadStatsTag(0x9381);
                    }
                    mSocket = mServer.accept();
                    mSocket.setKeepAlive(false);
                    ClientHandler client = new ClientHandler(mSocket);
                    SocketServer.pushTask(client);
                }
            } catch (Exception e) {
                LogUtil.logError(e);
                RunTimeLog.addLog(RunTimeLog.SYS_SERVER, socketPort + ";exception:" + StringUtil.getExceptionInfo(e));
            } finally {
                disconnect();
                if (!checkFinish()) {
                    RunTimeLog.addLog(RunTimeLog.SYS_SERVER, socketPort + " disconnected, reconnect now.retry times: " + retryTimes);
                    if (retryTimes++ < SocketConfig.SERVER_MAX_RETRY_TIMES) {
                        try {
                            Thread.sleep(10 * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        try {
                            Thread.sleep(60 * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    connect();
                }
            }
        }

        /**
         * 断开连接
         */
        private void disconnect() {
            try {
                if (mServer != null) {
                    mServer.close();
                    mServer = null;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Client处理线程
     */
    private static class ClientHandler implements Runnable {
        private Socket socket;

        private InputStream mReader;
        private OutputStream mWriter;

        private ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            mWriter = (socket.getOutputStream());
            mReader = (socket.getInputStream());
        }

        @Override
        public void run() {
            LogUtil.log(TAG + " " + String.format("开始监听客户端: %s", socket.getRemoteSocketAddress()));
            SocketResponse res;
            String requestId = "";
            try {
                String strRequest;

                byte[] header = new byte[4];
                int readCount = mReader.read(header, 0, 4);
                if (readCount <= 0) {
                    sendResponse(buildErrorResponse(SocketResultCode.DESERIALIZE_FAILED));
                    return;
                }
                int totalLength = SerializeUtil.bytesToInteger(header);
                if (totalLength >= 50000000) {
                    sendResponse(buildErrorResponse(SocketResultCode.DESERIALIZE_FAILED));
                    return;
                }
                byte[] content = new byte[totalLength];
                int totalReadCount = 0;
                while (totalLength > 0) {
                    readCount = mReader.read(content, totalReadCount, totalLength);
                    totalReadCount += readCount;
                    totalLength = totalLength - readCount;
                }
                strRequest = new String(content);
                if (strRequest.startsWith("{")) {
                    sendResponse(buildErrorResponse(SocketResultCode.VERSION_LOW), false);
                    return;
                }
                strRequest = SafeUtil.decrypt(NameConstant.PWD_HOST_CON, NameConstant.PWD_IV, strRequest);
                if (TextUtils.isEmpty(strRequest)) {
                    sendResponse(buildErrorResponse(SocketResultCode.DECRYPT_FAIL));
                    return;
                }
                if (!BaseConfig.isProduct()) {
                    LogUtil.logNET(TAG + " receive request" + strRequest);
                    RunTimeLog.addLog(RunTimeLog.SOCKET_REQUEST, " receive request" + strRequest);
                }

                SocketRequest request = JSON.parseObject(strRequest, SocketRequest.class);
                SocketHeader head = request.head;
                int filterError = doFilter(request);
                if (filterError != SocketResultCode.SUCCESS) {
                    sendResponse(buildErrorResponse(filterError));
                    LogUtil.log(TAG, "request refused, close socket connection");
                    RunTimeLog.addLog(RunTimeLog.SOCKET_REQUEST, "request refused, close socket connection");
                    return;
                }

                String userSession = head.us;
                if (!ignoreUriList.contains(request.uri)) {
                    if (TextUtils.isEmpty(userSession)) {
                        sendResponse(buildErrorResponse(SocketResultCode.USER_SESSION_EXPIRED));
                        return;
                    }
                    String userID = HostUtil.getUserIDBySession(userSession);
                    if (TextUtils.isEmpty(userID)) {
                        sendResponse(buildErrorResponse(SocketResultCode.USER_SESSION_EXPIRED));
                        return;
                    }
                }
                requestId = request.head.requestId;
                if (!BaseConfig.isProduct()) {
                    writeLog(request.head.requestId, strRequest);
                }

                Object obj;
                if (head.exe == 1) {
                    if (TextUtils.isEmpty(request.params)) {
                        obj = DriverBus.call(request.uri, request.head);
                    } else {
                        JSONObject jsonRequest = JSON.parseObject(request.params);
                        obj = DriverBus.call(request.uri, request.head, jsonRequest.values());
                    }
                } else {
                    if (TextUtils.isEmpty(request.params)) {
                        obj = DriverBus.call(request.uri, request.head);
                    } else {
                        obj = DriverBus.call(request.uri, request.head, request.params);
                    }
                }

                if (obj != null && obj instanceof SocketResponse) {
                    res = (SocketResponse) obj;
                } else {
                    res = new SocketResponse();
                    res.code = SocketResultCode.EXCEPTION;
                }
                res.head = head;
                LogUtil.log(TAG, "shopId from server: " + getShopID());

                sendResponse(res);
//                }
            } catch (JSONException e) {
                LogUtil.logError(e);
                res = new SocketResponse();
                res.code = SocketResultCode.DESERIALIZE_FAILED;
                sendResponse(res);
            } catch (Exception e) {
                LogUtil.logError(e);
                sendResponse(buildExceptionResponse());

            } catch (Error e) {
                LogUtil.logError(e);
                sendResponse(buildExceptionResponse());
            } finally {
                if (!BaseConfig.isProduct()) {
                    if (!TextUtils.isEmpty(requestId)) {
                        writeLogFinish(requestId);
                    }
                }
                disconnect();
            }
        }

        private void writeLog(String requestID, String request) {
            CacheModel cacheModel = new CacheModel();
            cacheModel.key = requestID;
            cacheModel.value = String.valueOf(SystemClock.elapsedRealtime());
            cacheModel.type = IOCache.TYPE_REQUESTID;
            cacheModel.biz_key = "";
            cacheModel.info = request;
            cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            cacheModel.updatetime = cacheModel.createtime;
            cacheModel.replaceNoTrans();
        }

        private void writeLogFinish(String requestID) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update datacache set biz_key='" + SystemClock.elapsedRealtime() + "' where key='" + requestID + "' and type='" + IOCache.TYPE_REQUESTID + "'");
        }

        private SocketResponse buildExceptionResponse() {
            return buildExceptionResponse("");
        }

        private SocketResponse buildExceptionResponse(String msg) {
            return buildErrorResponse(SocketResultCode.EXCEPTION, msg);
        }

        private SocketResponse buildErrorResponse(int code) {
            return buildErrorResponse(code, "");
        }

        private SocketResponse buildErrorResponse(int code, String msg) {
            SocketResponse res = new SocketResponse();
            res.code = code;
            res.message = msg;
            return res;
        }

        private void sendResponse(SocketResponse res) {
            sendResponse(res, true, null);
        }

        private void sendResponse(SocketResponse res, boolean encrypt) {
            sendResponse(res, encrypt, null);
        }

        private void sendResponse(SocketResponse res, Logger logger) {
            sendResponse(res, true, logger);
        }

        private void sendResponse(SocketResponse res, boolean encrypt, Logger logger) {
            if (res == null) {
                res = buildExceptionResponse();
            }
            res.buildMessage();

            try {
                String info = JSON.toJSONString(res, SerializerFeature.DisableCircularReferenceDetect);
                if (!BaseConfig.isProduct()) {
                    LogUtil.logNET(TAG + " sendResponse " + info);
                    if (info.length() < 1024 * 1024) {
                        RunTimeLog.addLog(RunTimeLog.SOCKET_RESPONSE, "sendResponse " + info);
                    }

                }
                if (encrypt) {
                    if (logger != null) {
                        logger.log("START SocketServer#sendResponse#encrypt() -- " + SystemClock.elapsedRealtime());
                    }
                    info = SafeUtil.encrypt(NameConstant.PWD_HOST_CON, NameConstant.PWD_IV, info);
                    if (logger != null) {
                        logger.log("END SocketServer#sendResponse#encrypt() -- " + SystemClock.elapsedRealtime());
                    }
                }
                byte[] infoByte = info.getBytes();
                byte[] requestHeader = SerializeUtil.integerToBytes(infoByte.length, 4);

                if (logger != null) {
                    logger.log("START SocketServer#OutputStream#write() -- " + SystemClock.elapsedRealtime());
                }
                mWriter.write(requestHeader);
                mWriter.write(infoByte);
                mWriter.flush();
                if (logger != null) {
                    logger.log("END SocketServer#OutputStream#write() -- " + SystemClock.elapsedRealtime());
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            } catch (Error e) {
                LogUtil.logError(e);
            }
        }

        private int doFilter(SocketRequest request) {
            SocketHeader headers = request.head;
            if (headers == null) {
                RunTimeLog.addLog(RunTimeLog.SOCKET, "request header is empty");
                return SocketResultCode.SUCCESS;
            }

            if (!ignoreShopIdUriList.contains(request.uri)) {
                String localShopID = getShopID();
                if (!TextUtils.isEmpty(localShopID) && !TextUtils.equals(localShopID, headers.shopid)) {
                    //对shopid做个更新机制，满足美收银切换账号逻辑
                    shopid = null;
                    localShopID = getShopID();
                    if (!TextUtils.equals(localShopID, headers.shopid)) {
                        LogUtil.logBusiness(TAG, " shopId from request: " + headers.shopid + ", from center: " + localShopID);
                        return SocketResultCode.WRONG_SHOP;
                    }
                }
            }

            if (!ignoreVersionUriList.contains(request.uri)) {
                int apiVersion = headers.version;
                if (apiVersion < SocketConfig.API_VERSION) {
                    return SocketResultCode.VERSION_LOW;
                } else if (apiVersion > SocketConfig.API_VERSION) {
                    return SocketResultCode.VERSION_HIGH;
                }
            }
            return SocketResultCode.SUCCESS;

        }

        /**
         * 断开连接
         */
        private void disconnect() {
            try {
                if (mWriter != null) {
                    mWriter.close();
                    mWriter = null;
                }
                if (mReader != null) {
                    mReader.close();
                    mReader = null;
                }
                if (socket != null) {
                    socket.close();
                    socket = null;
                }
            } catch (Exception e) {
                LogUtil.logError(e);
            }
        }
    }
}
