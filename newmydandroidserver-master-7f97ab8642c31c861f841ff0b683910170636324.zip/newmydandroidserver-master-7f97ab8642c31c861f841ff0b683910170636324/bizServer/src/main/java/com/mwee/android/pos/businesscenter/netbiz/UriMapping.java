package com.mwee.android.pos.businesscenter.netbiz;

/**
 * Created by virgil on 2017/7/6.
 */

public class UriMapping {

    /**
     * 忽略session的请求
     */
    public final static String[] ignoreSession = new String[]{
            "bizsync/loadActiveHostAndLoginForAdmin",
            "bizsync/loginForDinner",
            "monitor/loadLoginData",
            "systemSetting/allTablesInfo",
            "systemSetting/logSearchParams",
            "bizsync/checkMainPointConnected",
            "monitor/getSwitchPrinterList",
            "monitor/printer_update",
            "ordersync/reprinterBillRecept",
            "ordersync/getSellOut",
            "ordersync/uploadDataToServer",
            "monitor/printReportReceipt",
            "monitor/saveDailyreport",
            "notice/lastNotice",
            "notice/unalert",
            "notice/allNotice",
            "bizsync/getDataFromCenter",
            "bizsync/bindHost",
            "bizsync/get_unbind_host",
            "bizsync/get_token",
            "bizsync/setasmain",
            "monitor/getPrintTask",
            "monitor/unPrintTask",
            "monitor/updatePrintTask",
            "monitor/printer_status_update",
            "bizsync/getBackUpData",
            "bizsync/finish_dinner_host",
            "bizsync/synclog",
            "bizsync/logoutForDinner",
            "cashierLogin/syncData",
            "cashierLogin/getVerifyCode",
            "cashierLogin/doLogin",
            "cashierLogin/cashierActive",
            "biz/uploadVersion",
            "message/unDealCount",
            "bizsync/checkReplication",
            "P433Driver/updatePrinterList",
            "P433Driver/updateHostIdOfStation",
            "message/unDealCount",
            "advertising/startUpImage",
            "ordersync/getDidNotCheck",
            "ordersync/unfinish_shift",
            "ordersync/automaticSuccession",
            "permission/checkPermission",
            "netOrder/mtwmOrder",
            "bizsync/loadWorkMode",
            "airNewPrinter/loadAllPrinter",
            "menuManager/loadAirOnPrinterMenuCls",
            "kds/queryByChef",
            "infocollect/addClientRunningInfo",
            "infocollect/addClientCommonInfo",
            "biz/getAllPrinter"
    };

    /**
     * 忽略APP版本号的请求
     */
    public final static String[] ignoreVersion = new String[]{
            "bizsync/logoutForDinner"};

    public final static String[] ignoreShopId = new String[]{
            "bizsync/checkMainPointConnected"
    };
}
