package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ExpclsDBModel;
import com.mwee.android.pos.db.business.RevenuetypeDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2018/6/12.
 */

public class RevenueTypeDBUtil {


    /**
     * 新增销售分类
     *
     * @param name
     * @return
     @ColumnInf(name = "fiDataKind")
     public int fiDataKind = 0;
     @ColumnInf(name = "fsRevenueTypeId", primaryKey = true)
     public String fsRevenueTypeId = "";
     @ColumnInf(name = "fsRevenueTypeName")
     public String fsRevenueTypeName = "";

     */
    public static boolean insert(String id, String name, int fistatus, String shopId, UserDBModel userDBModel) {
        RevenuetypeDBModel model = new RevenuetypeDBModel();
        model.setDbName(APPConfig.DB_MAIN);
        model.fsRevenueTypeId = id;
        model.fsRevenueTypeName = name;
        model.fiStatus = fistatus;
        model.fiSortOrder = 0;
        model.fiDataKind = 2;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsShopGUID = shopId;
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.fiDataSource = 1;
        model.sync = 1;
        model.replaceNoTrans();
        return true;
    }
}
