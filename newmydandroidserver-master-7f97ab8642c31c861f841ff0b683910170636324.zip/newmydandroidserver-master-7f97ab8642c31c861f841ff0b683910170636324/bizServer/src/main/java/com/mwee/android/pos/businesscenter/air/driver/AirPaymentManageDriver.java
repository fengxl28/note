package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.payment.GetAllPaymentResponse;
import com.mwee.android.air.connect.business.payment.GetPaymentResponse;
import com.mwee.android.air.connect.business.payment.PayTypeListResponse;
import com.mwee.android.air.db.business.payment.PaymentInfo;
import com.mwee.android.air.db.business.payment.PaymentManageInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.PaymentManageDBUtils;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * @ClassName: AirPaymentManageDriver
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午3:20
 */
public class AirPaymentManageDriver implements IDriver {

    public static final String DRIVER_TAG = "airPaymentManager";

    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }


    /**
     * 加载配送费支付方式 如果未查到则创建一个
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadDistributionFeePaymentById")
    public SocketResponse loadDistributionFeePaymentById(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String paymentId = request.getString("fsPaymentId");

            GetPaymentResponse responseData = new GetPaymentResponse();
            responseData.pay = PaymentManageDBUtils.queryPaymentManageInfoById(paymentId);
            if (responseData.pay == null) {

                UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
                if (userDBModel == null) {
                    response.code = SocketResultCode.USER_SESSION_EXPIRED;
                    response.message = "登录信息已过期";
                    return response;
                }

                String fsShopGUID = ClientMetaUtil.getSettingsValueByKey(META.SHOPID);
                PaymentInfo paymentInfo = PaymentManageDBUtils.addPayment(fsShopGUID, userDBModel.fsUpdateUserId, userDBModel.fsUpdateUserName, paymentId);

                PaymentManageInfo pay = new PaymentManageInfo();
                pay.fsPaymentId = paymentInfo.fsPaymentId;
                pay.fiDataKind = paymentInfo.fiDataKind;
                pay.fiIsCalcPaid = paymentInfo.fiIsCalcPaid;
                pay.fsPaymentName = paymentInfo.fsPaymentName;

                responseData.pay = pay;
                response.data = responseData;

            }
            response.data = responseData;
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return response;
    }


    /**
     * 修改支付方式是否计入实收
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/updatePaymentFiIsCalcPaid")
    public SocketResponse updatePaymentFiIsCalcPaid(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String paymentId = request.getString("fsPaymentId");
            int fiIsCalcPaid = request.getInteger("fiIsCalcPaid");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            PaymentManageDBUtils.updatePaymentFiIsCalcPaid(paymentId, fiIsCalcPaid, userDBModel);
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return response;
    }


    @DrivenMethod(uri = DRIVER_TAG + "/getAllPayment")
    public SocketResponse getAllPayment(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllPaymentResponse responseData = new GetAllPaymentResponse();
        response.data = responseData;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            responseData.paymentList = PaymentManageDBUtils.queryAllPaymentWithoutHidden();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/addPayment")
    public SocketResponse addPayment(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllPaymentResponse responseData = new GetAllPaymentResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsPaymentName = request.getString("fsPaymentName");
            int fiIsCalcPaid = request.getInteger("fiIsCalcPaid");
            int fiIsPremium = request.getInteger("fiIsPremium");

            if (TextUtils.isEmpty(fsPaymentName)) {
                response.message = "付款方式不能为空";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = PaymentManageDBUtils.add(fsPaymentName, fiIsCalcPaid,fiIsPremium, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.paymentList = PaymentManageDBUtils.queryAllPaymentWithoutHidden();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增支付方式成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @DrivenMethod(uri = DRIVER_TAG + "/updatePayment")
    public SocketResponse updatePayment(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllPaymentResponse responseData = new GetAllPaymentResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsPaymentId = request.getString("fsPaymentId");
            String fsPaymentName = request.getString("fsPaymentName");
            int fiIsCalcPaid = request.getInteger("fiIsCalcPaid");
            int fiIsPremium = request.getInteger("fiIsPremium");

            if (TextUtils.isEmpty(fsPaymentId)) {
                response.message = "内部异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (TextUtils.isEmpty(fsPaymentName)) {
                response.message = "付款方式不能为空";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = PaymentManageDBUtils.update(fsPaymentId, fsPaymentName, fiIsCalcPaid,fiIsPremium, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.paymentList = PaymentManageDBUtils.queryAllPaymentWithoutHidden();
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改支付方式成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/deletePayment")
    public SocketResponse deletePayment(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllPaymentResponse responseData = new GetAllPaymentResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            String fsPaymentId = request.getString("fsPaymentId");
            if (TextUtils.isEmpty(fsPaymentId)) {
                response.message = "内部异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = PaymentManageDBUtils.delete(fsPaymentId, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.paymentList = PaymentManageDBUtils.queryAllPaymentWithoutHidden();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除支付方式成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadPayTypeList")
    public SocketResponse loadPayTypeList(SocketHeader head, String param) {
        PayCache.getInstance().refresh();
        SocketResponse socketResponse = new SocketResponse();

        String orderId = JSONObject.parseObject(param).getString("orderId");
        if (TextUtils.isEmpty(orderId)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单id不能为空";
            return socketResponse;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
        if (orderCache == null) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "无效订单号";
            return socketResponse;
        }
        PayTypeListResponse payTypeListResponse = new PayTypeListResponse();
        payTypeListResponse.payOriginModels = BillUtil.buildPayTypeList(orderCache);
        socketResponse.data = payTypeListResponse;
        return socketResponse;
    }

}
