package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.base.task.callback.SyncCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.PhoneDowngradeDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.ThirdOrderTurnToLocalReportProcess;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.MWMeituanProcessor;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.businesscenter.print.DeviceDBUtil;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.MwOrderResponse;
import com.mwee.android.pos.component.datasync.net.model.MeituanMappingViewBean;
import com.mwee.android.pos.component.datasync.net.model.MwOrder;
import com.mwee.android.pos.component.datasync.net.model.NetorderItemMappingRelationshipDBModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderSimpleInfo;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.takeout.TakeOutBindStatus;
import com.mwee.android.pos.component.takeout.TakeOutBindStatusRequest;
import com.mwee.android.pos.component.takeout.TakeOutBindStatusResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.netorder.GetAllBindingStatusResponse;
import com.mwee.android.pos.connect.business.netorder.GetAllNetOrderResponse;
import com.mwee.android.pos.connect.business.netorder.GetNetOrderSimpleInfoResponse;
import com.mwee.android.pos.connect.business.netorder.NetorderStatusResponse;
import com.mwee.android.pos.connect.business.netorder.OptNetOrderFromBizResponse;
import com.mwee.android.pos.connect.business.netorder.PrintNetorderReceiptResponse;
import com.mwee.android.pos.connect.business.netorder.QueryMeituanMappingResponse;
import com.mwee.android.pos.connect.business.netorder.UpdateNetOrderResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;

/**
 * Created by lxx on 17/2/13.
 * 外卖
 */
@SuppressWarnings("unused")
public class NetOrderDriver implements IDriver {

    private static final String TAG = "netOrder";

    /**
     * 获取网络订单列表
     * 1、同步后台订单到本地
     * 2、解析同步数据，并将新订单插入数据库
     * 3、拉取数据库所有订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/ordersList")
    public SocketResponse ordersList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final GetAllNetOrderResponse myResponseData = new GetAllNetOrderResponse();
        response.data = myResponseData;
        final JSONObject request = JSON.parseObject(param);

        try {
            int currentPage = request.getInteger("currentPage");
            final String businessDate = request.getString("businessDate"); //营业日期
            final String time = request.getString("time");         //时间限制
            final String source = request.getString("source");     //订单来源
            final String areaIds = request.getString("areaIds");      //不接受的区域
            final Boolean checkDate = request.getBoolean("checkDate");
            myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(request
                    .getString("businessDate"), request.getString("time"), request.getString("areaIds"));
            myResponseData.deliverySettingMap = ServerCache.getInstance().netOrderCache
                    .optDeliverySettings();

            if (currentPage == 1) {
                NetOrderApi.getAllNetOrderDatasIExecutorCallback(businessDate, false, new IResponse<String>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, String info) {
                        if (result) {
                            response.code = SocketResultCode.SUCCESS;
                            response.message = msg;
                        } else {
                            response.message = msg;
                            response.code = SocketResultCode.BUSINESS_FAILED;
                        }
                        getPageOrders(myResponseData, checkDate, currentPage, businessDate, source);
                    }
                });
            } else {
                getPageOrders(myResponseData, checkDate, currentPage, businessDate, source);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    private void getPageOrders(GetAllNetOrderResponse myResponseData, boolean checkDate, int currentPage, String
            businessDate, String source) {
        String date = businessDate;
        //获取网络订单不筛日期
        if (!checkDate) {
            date = "";
        }
        Pair<Integer, List<TempAppOrder>> allOrders = NetOrderDBUtil.getAllOrders(currentPage, date, source);
        myResponseData.tempAppOrderList = allOrders.second;

        myResponseData.pageCount = (allOrders.first == null ? 0 : allOrders.first + 30 - 1) / 30;
    }

    /**
     * 获取网络订单列表 -- 纯拉取本地库里的网络订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optTempappordersList")
    public SocketResponse optTempappordersList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final GetNetOrderSimpleInfoResponse myResponseData = new GetNetOrderSimpleInfoResponse();
        response.data = myResponseData;
        final JSONObject request = JSON.parseObject(param);

        try {
            int currentPage = request.getInteger("currentPage");
            //自然日日期
            String businessDate = request.getString("businessDate");
            //订单来源
            String source = request.getString("source");
            String sellNo = request.getString("sellNo");

            Pair<Integer, List<TempAppOrderSimpleInfo>> allOrders = NetOrderDBUtil.getElemeAndMeituanAllOrders(currentPage, businessDate,
                    source, sellNo);
            myResponseData.tempAppOrderList = allOrders.second;

            myResponseData.tempAppOrderMappingInfoMap.putAll(NetOrderDBUtil.optUnMappingOrderMapV2());
            myResponseData.tempAppOrderMappingInfoMap.putAll(NetOrderDBUtil.optUnTurnedOrderList());
            LinkedHashMap<String, String> mappingOrdersMap = NetOrderDBUtil.optMappingOrderMap(businessDate, source);
            if (mappingOrdersMap != null && mappingOrdersMap.size() > 0 && !ListUtil.isEmpty(myResponseData
                    .tempAppOrderList)) {
                for (TempAppOrderSimpleInfo tempAppOrderSimpleInfo : myResponseData.tempAppOrderList) {
                    if (tempAppOrderSimpleInfo != null) {
                        tempAppOrderSimpleInfo.fssellno = mappingOrdersMap.get(tempAppOrderSimpleInfo.orderId);
                    }
                }
            }
            myResponseData.pageCount = (allOrders.first == null ? 0 : allOrders.first + 20 - 1) / 20;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 根据订单号搜索网络订单列表 -- 纯拉取本地库里的网络订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optSearchTempappordersList")
    public SocketResponse optSearchTempappordersList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final GetNetOrderSimpleInfoResponse myResponseData = new GetNetOrderSimpleInfoResponse();
        final JSONObject request = JSON.parseObject(param);

        try {
            //自然日日期
            String businessDate = request.getString("businessDate");
            //订单来源
            String source = request.getString("source");
            String sellNo = request.getString("sellNo");

            myResponseData.tempAppOrderList = NetOrderDBUtil.getSearchElemeAndMeituanAllOrders(businessDate, source,
                    sellNo);
            response.code = SocketResultCode.SUCCESS;
            response.message = "搜索成功";
            response.data = myResponseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 更新网络订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     * <p>
     * lxx 2017/04/20 目前只对接饿了么和美团，
     * 订单来源      订单状态   orderStatus   diningStatus
     * 饿了么|美团      新订单        0              0
     * 饿了么|美团      已接单        2              20
     * 饿了么|美团      已完成        3             40
     * 饿了么|美团      取消         -2              -2
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateNetOrder")
    public SocketResponse updateNetOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final UpdateNetOrderResponse myResponseData = new UpdateNetOrderResponse();

            final String orderId = request.getString("orderId"); //订单号
            final int bizType = request.getInteger("bizType");
            final int operation = request.getInteger("operation");         //订单操作
            String reason = request.getString("reason");     //原因
            String orderNum = request.getString("orderNum");      //本地订单号
            final String businessDate = request.getString("businessDate");
            final String time = request.getString("time");
            final String areaIds = request.getString("areaIds");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            final TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
            if (tempAppOrder == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }

            IResponse<String> iResponse = new IResponse<String>() {
                @Override
                public void callBack(final boolean result, int code, final String msg, String info) {
                    BusinessExecutor.executeAsyncExcute(new ASyncExecute<String>() {
                        @Override
                        public String execute() {
                            myResponseData.tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
                            myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel
                                    (businessDate, time, areaIds);
                            LogUtil.log("获取未处理消息数量");
                            return "";
                        }
                    }, new SyncCallback<String>() {
                        @Override
                        public void callback(String s) {
                            response.data = myResponseData;
                            if (result) {
                                response.message = "success";
                                response.code = SocketResultCode.SUCCESS;
                            } else {

                                response.message = msg;
                                response.code = SocketResultCode.BUSINESS_FAILED;
                            }
                            NotifyToClient.updateTempApporder(orderId);

                            LogUtil.log("通知站点更新订单信息");
                        }
                    });
                }
            };

            if (NetworkConstans.OPERATION_TYPE_GET == operation) {
                NetOrderApi.getOrderRequest(tempAppOrder, 5, iResponse, false,head.hd);
            } else if (NetworkConstans.PLEASE_TAKE_FOOD == operation) {
                NetOrderApi.takeOrderRequest(tempAppOrder, 5, iResponse);
            } else if (NetworkConstans.OPERATION_TYPE_CANCEL == operation || NetworkConstans.OPERATION_TYPE_VOID ==
                    operation) {
                NetOrderApi.cancelOrderRequest(tempAppOrder, 5, iResponse, head.hd, userDBModel.fsUserName);
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        LogUtil.log("更改网络订单状态方法完毕");
        return response;
    }

    /**
     * 更新网络订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optTempAppOrderById")
    public SocketResponse optTempAppOrderById(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            //OptNetOrderFromBizRequest request = JSON.parseObject(param, OptNetOrderFromBizRequest.class);
            JSONObject request = JSON.parseObject(param);
            final OptNetOrderFromBizResponse myResponseData = new OptNetOrderFromBizResponse();
            final String orderId = request.getString("orderId"); //订单号
            try {
                myResponseData.tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
                String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache" +
                        " where thirdOrderId = '" + orderId + "'");
                myResponseData.paySession = OrderSession.getInstance().getPay(local_order_id);
                response.message = "success";
                response.data = myResponseData;
                response.code = SocketResultCode.SUCCESS;
                myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(request.getString
                        ("businessDate"), request.getString("time"), request.getString("areaIds"));
            } catch (Exception e) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                LogUtil.logError(e);
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 更新网络订单状态
     * 1、更新服务器订单状态
     * 2、更新本地订单状态
     * 3、获取本地最新订单详情，返回给发起请求的站点
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateNetOrderTurnErrInfo")
    public SocketResponse updateNetOrderTurnErrInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            //OptNetOrderFromBizRequest request = JSON.parseObject(param, OptNetOrderFromBizRequest.class);
            JSONObject request = JSON.parseObject(param);
            final OptNetOrderFromBizResponse myResponseData = new OptNetOrderFromBizResponse();
            final String orderId = request.getString("orderId"); //订单号
            try {
                ThirdOrderTurnToLocalReportProcess.updateThirdOrderUnTurnedTips(orderId, true);
                myResponseData.tempAppOrder = null;
                response.message = "success";
                response.data = myResponseData;
                response.code = SocketResultCode.SUCCESS;
                myResponseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(request.getString
                        ("businessDate"), request.getString("time"), request.getString("areaIds"));
            } catch (Exception e) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                LogUtil.logError(e);
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 打印网络订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/printNetorder")
    public SocketResponse printNetorder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final PrintNetorderReceiptResponse myResponseData = new PrintNetorderReceiptResponse();
        response.data = myResponseData;

        try {
            JSONObject request = JSON.parseObject(param);
            final String orderId = request.getString("orderId"); //订单号
            TempAppOrder appOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
            if (appOrder != null) {
                String hostId = head.hd;
                String fsUserName = request.getString("fsUserName");
                String fsprinterName = DeviceDBUtil.getPrinterNameByHostID(hostId);
                switch (request.getInteger("receiptType")) {
                    case 1:
                        PrintNetOrderUtil.printNetworkTackOutReceipt(appOrder, hostId, fsUserName, false, false,
                                true, fsprinterName);
                        break;
                    case 0:
                        PrintNetOrderUtil.printNetworkKDSReceipt(appOrder, hostId, fsUserName, false, false);
                        break;
                    case 2:
                        //外卖客户联
                        PrintNetOrderUtil.printNetworkCustomerReceipt(appOrder, hostId, fsUserName, false, false);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取网络订单状态
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getNetOrderStatus")
    public SocketResponse getNetOrderStatus(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final NetorderStatusResponse myResponseData = new NetorderStatusResponse();
        response.data = myResponseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId"); //订单号
            TempAppOrder tempAppOrder = NetOrderDBUtil.getTempAppOrderById(orderId);
            if (tempAppOrder != null) {
                myResponseData.tempAppOrder = tempAppOrder;
            } else {
                response.code = SocketResultCode.EXCEPTION;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        response.buildMessage();
        return response;
    }

    /**
     * 查询店铺外卖绑定情况（美团，饿了么）
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getAllBindingStatus")
    public SocketResponse getAllBindingStatus(SocketHeader head, String param) {
        final SocketResponse response = new SocketResponse();
        String fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        if (TextUtils.isEmpty(fsShopGUID)) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.buildMessage();
            return response;
        }

        try {
            List<BaseRequest> list = new ArrayList<>();
            TakeOutBindStatusRequest requestM = new TakeOutBindStatusRequest();
            requestM.request_id = UUID.randomUUID().toString();
            requestM.shop_guid = fsShopGUID;
            requestM.takeawaySource = "MEITUAN";

            TakeOutBindStatusRequest requestE = new TakeOutBindStatusRequest();
            requestE.request_id = UUID.randomUUID().toString();
            requestE.shop_guid = fsShopGUID;
            requestE.takeawaySource = "ELEME";
            list.add(requestM);
            list.add(requestE);
            GetAllBindingStatusResponse getAllBindingStatusResponse = new GetAllBindingStatusResponse();
            BusinessExecutor.execute(list, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    return false;
                }
            }, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof
                            TakeOutBindStatusResponse) {
                        TakeOutBindStatus takeOutBindStatus = ((TakeOutBindStatusResponse) responseData.responseBean)
                                .data;
                        getAllBindingStatusResponse.takeOutBindStatuses.add(takeOutBindStatus);
                        response.data = getAllBindingStatusResponse;
                        if (takeOutBindStatus.platform.equals("MEITUAN")) {
                            return true;
                        }
                    }
                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    response.code = SocketResultCode.EXCEPTION;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.buildMessage();
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/updateMessageMeituanDowngradeDealStatus")
    public SocketResponse updateMessageMeituanDowngradeDealStatus(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            PhoneDowngradeDBUtil.updateMessageMeituanDowngradeDealStatus();

            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        response.buildMessage();
        return response;
    }

    /**
     * 美团外卖下单
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/mtwmOrder")
    public SocketResponse<MwOrderResponse> mtwmOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }

        SocketResponse response = new SocketResponse();
        try {
            LogUtil.logBusiness("虚拟打印机外卖 业务中心 收到外卖入库请求", param);
            JSONObject request = JSON.parseObject(param);
            List<MwOrder> orderList = JSON.parseArray(request.getString("orders"), MwOrder.class);

            List<String> orderPath = MWMeituanProcessor.receiveOrder(orderList);
            // todo 处理过的单子，需要把 path 给shell那边，删除文件用
            MwOrderResponse orderResponse = new MwOrderResponse();
            orderResponse.setPaths(orderPath);

            response.data = orderResponse;
            response.code = SocketResultCode.SUCCESS;
            response.message = "美团外卖下单";
        } catch (Exception e) {
            LogUtil.logError("虚拟打印机外卖 业务中心 解析遇到异常" + param, e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/queryMeituanMapping")
    public SocketResponse queryMeituanMapping(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final QueryMeituanMappingResponse data = new QueryMeituanMappingResponse();
        response.data = data;

        try {
            final JSONObject request = JSON.parseObject(param);
            int state = request.getInteger("state");
            String sql = "" +
                    "SELECT tbNetorderItemMappingRelationship.fsNetorderItemName AS fsNetorderItemName,\n" +
                    "       tbNetorderItemMappingRelationship.fsNetorderUintName AS fsNetorderUintName,\n" +
                    "       tbNetorderItemMappingRelationship.fdNetorderSaleAmt  AS fdNetorderSaleAmt,\n" +
                    "       tbmenuitem.fiItemCd                                  AS fiItemCd,\n" +
                    "       tbmenuitem.fsItemName                                AS fsItemName,\n" +
                    "       tbmenuitemuint.fsOrderUint                           AS fsOrderUint,\n" +
                    "       tbmenuitemuint.fdSalePrice                           AS fdSalePrice\n" +
                    "FROM tbNetorderItemMappingRelationship\n" +
                    "       LEFT JOIN tbmenuitem ON tbNetorderItemMappingRelationship.fiItemCd = tbmenuitem.fiItemCd AND tbmenuitem.fiStatus = '1'\n" +
                    "       LEFT JOIN tbmenuitemuint ON tbNetorderItemMappingRelationship.fsOrderUint = tbmenuitemuint.fiOrderUintCd AND tbmenuitemuint.fiStatus = '1'\n" +
                    "WHERE tbNetorderItemMappingRelationship.fiStatus = '1' ";

            if (1 == state) {
                // 查询未关联菜品
                sql += " AND (tbmenuitem.fiItemCd IS NULL OR tbmenuitem.fiItemCd = '' OR tbmenuitem.fiItemCd = '0' OR tbNetorderItemMappingRelationship.fsOrderUint NOT IN (SELECT fiOrderUintCd FROM tbmenuitemuint WHERE fistatus = '1')) ";
            }

            sql += " order by tbNetorderItemMappingRelationship.fsNetorderItemName, tbNetorderItemMappingRelationship.fsNetorderUintName ";

            data.menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MeituanMappingViewBean.class);
            String sqlCount = "" +
                    "SELECT sum(1)            AS countAll,\n" +
                    "       sum(CASE\n" +
                    "             WHEN fiItemCd IS NULL OR \n" +
                    "                  fiItemCd = '' OR \n" +
                    "                  fiItemCd = '0' OR\n" +
                    "                  fiItemCd NOT IN (SELECT fiItemCd FROM tbmenuitem WHERE fiStatus = '1') OR\n" +
                    "                  fsOrderUint NOT IN (SELECT fiOrderUintCd FROM tbmenuitemuint WHERE fistatus = '1') THEN 1\n" +
                    "             ELSE 0 END) AS countUnMapping\n" +
                    "FROM tbNetorderItemMappingRelationship\n" +
                    "WHERE fiStatus = '1'";
            JSONObject jsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sqlCount);
            if (jsonObject != null) {
                data.countAll = StringUtil.toInt(jsonObject.getString("countAll"), 0);
                data.countUnMapping = StringUtil.toInt(jsonObject.getString("countUnMapping"), 0);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/updateMeituanMapping")
    public SocketResponse updateMeituanMapping(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            final JSONObject request = JSON.parseObject(param);
            NetorderItemMappingRelationshipDBModel model = request.getObject("relation", NetorderItemMappingRelationshipDBModel.class);
            saveRelationModel(userDBModel, model);
            NotifyToClient.updateMappingRelation();
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        response.buildMessage();
        return response;
    }

    /**
     * 保存菜品映射关联
     *
     * @param userDBModel
     * @param model
     */
    private void saveRelationModel(UserDBModel userDBModel, NetorderItemMappingRelationshipDBModel model) {
        if (model == null) {
            return;
        }
        String sqlExist = "SELECT * FROM tbNetorderItemMappingRelationship WHERE fsNetorderItemName = '" + model.fsNetorderItemName + "' AND fsNetorderUintName = '" + model.fsNetorderUintName + "' AND fsShopGUID = '" + HostUtil.getShopID() + "' ";
        NetorderItemMappingRelationshipDBModel target = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, NetorderItemMappingRelationshipDBModel.class);
        if (target == null) {
            target = new NetorderItemMappingRelationshipDBModel();
            target.fsNetorderItemName = model.fsNetorderItemName;
            target.fsNetorderUintName = model.fsNetorderUintName;
            target.fsShopGUID = HostUtil.getShopID();
        }
        target.fdNetorderSaleAmt = model.fdNetorderSaleAmt;
        target.fiItemCd = model.fiItemCd;
        target.fsOrderUint = model.fsOrderUint;
        target.fiStatus = 1;
        target.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        target.fsUpdateUserId = userDBModel.fsUserId;
        target.fsUpdateUserName = userDBModel.fsUserName;
        target.lver += 1;
        target.sync = 1;
        target.replaceNoTrans();
        RunTimeLog.addLog(RunTimeLog.NETORDER_MW_MEITUAN, "外卖虚拟打印机 更换菜品映射 服务员：" + userDBModel.fsUserName, model.fsNetorderItemName, model.fiItemCd + "", model);
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
