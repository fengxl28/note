package com.mwee.android.pos.businesscenter.air.driver;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.table.GetAirTableChangeResponse;
import com.mwee.android.air.connect.business.table.GetAllAreaAndTableResponse;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.TableManagerDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/16.
 * 桌台管理相关操作
 */
@SuppressWarnings("unused")
public class AirTableManagerDriver implements IDriver {

    private static final String TAG = "airTableManager";

    /**
     * 获取所有餐区，桌台等信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAllAreaAndTable")
    public SocketResponse authorityChecking(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 新增餐区
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/addArea")
    public SocketResponse addArea(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String areaName = request.getString("areaName");
            boolean batchAddTable = request.getBoolean("batchAddTable");
            int tableCount = request.getIntValue("tableCount");
            int person = request.getIntValue("person");

            if (TextUtils.isEmpty(areaName)) {
                response.message = "餐区名称无效";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (batchAddTable && tableCount < 1) {
                response.message = "桌台数量必须大于0";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (batchAddTable && person < 1) {
                response.message = "人数必须大于0";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.addArea(responseData, areaName, batchAddTable, tableCount, person, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增餐区成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 修改餐区名称
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateAreaName")
    public SocketResponse updateAreaName(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String areaId = request.getString("areaId");
            String areaName = request.getString("areaName");
            if (TextUtils.isEmpty(areaId)) {
                response.message = "餐区信息异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.updateAreaName(areaId, areaName, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "修改餐区成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 删除餐区
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/deleteArea")
    public SocketResponse deleteArea(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String areaId = request.getString("areaId");
            if (TextUtils.isEmpty(areaId)) {
                response.message = "餐区信息异常,请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.deleteArea(areaId, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增餐区成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 新增桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/addTable")
    public SocketResponse addTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String areaId = request.getString("areaId");
            String tableName = request.getString("tableName");
            int seats = request.getIntValue("seats");

            if (TextUtils.isEmpty(areaId)) {
                response.message = "请选择一个有效餐区";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (TextUtils.isEmpty(tableName)) {
                response.message = "请输入有效桌台名称";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (seats < 1) {
                response.message = "人数必须大于0";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            ArrayList<MtableDBModel> mtableDBModels = new ArrayList<>();
            String errMsg = TableManagerDBUtil.addTable(mtableDBModels, areaId, tableName, seats, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (mtableDBModels.size() > 0) {
                responseData.inSertMtableDBModel = mtableDBModels.get(0);
            }
            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 修改桌台信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updateTable")
    public SocketResponse updateTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            String areaId = request.getString("areaId");
            String fsmtableId = request.getString("fsmtableId");
            String tableName = request.getString("tableName");
            int seats = request.getIntValue("seats");

            if (TextUtils.isEmpty(areaId)) {
                response.message = "请选择一个有效餐区";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (TextUtils.isEmpty(fsmtableId)) {
                response.message = "桌台信息异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (TextUtils.isEmpty(tableName)) {
                response.message = "请输入有效桌台名称";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (seats < 1) {
                response.message = "人数必须大于0";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.updateTable(areaId, fsmtableId, tableName, seats, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            MtableDBModel currentTableDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmtable where fsmtableId = '" + fsmtableId + "'", MtableDBModel.class);
            responseData.mtableDBModel = currentTableDBModel;
            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "新增桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 批量删除桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/batchDeleteTable")
    public SocketResponse batchDeleteTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllAreaAndTableResponse responseData = new GetAllAreaAndTableResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayList<String> tableIdList = (ArrayList<String>) JSON.parseArray(request.getString("tableIdList"), String.class);
            if (ListUtil.isEmpty(tableIdList)) {
                response.message = "请选择要删除的桌台";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = TableManagerDBUtil.batchDeleteTable(tableIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.airAreaManagerInfo = TableManagerDBUtil.optAreaManagerInfo();
            responseData.airTableManageInfo = TableManagerDBUtil.optTableManagerInfo();
            response.code = SocketResultCode.SUCCESS;
            response.message = "删除桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    /**
     * 获取小散换桌需要的数据
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadTableChangeInfo")
    public SocketResponse loadTableChangeInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAirTableChangeResponse responseData = new GetAirTableChangeResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            List<MtableDBModel> hintTables = TableDBUtil.getAllHintTables();
            List<TableStatusBean> tableS = TableDBUtil.getAllTableStatus();
            ArrayMap<String, TableStatusBean> tableStatus = new ArrayMap<>();
            for (TableStatusBean temp : tableS) {
                tableStatus.put(temp.fsmtableid, temp);
            }
            responseData.tableStatus = tableStatus;
            responseData.mareaDBModelList = TableManagerDBUtil.getArea();

            List<MtableDBModel> mtableDBModels = TableManagerDBUtil.getTable("");

            responseData.allTables = TableManagerDBUtil.getAllTables(mtableDBModels, hintTables);
            responseData.areaTable = TableManagerDBUtil.groupTables(mtableDBModels);

            response.code = SocketResultCode.SUCCESS;
            response.message = "删除桌台成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    @Override
    public String getModuleName() {
        return TAG;
    }

}
