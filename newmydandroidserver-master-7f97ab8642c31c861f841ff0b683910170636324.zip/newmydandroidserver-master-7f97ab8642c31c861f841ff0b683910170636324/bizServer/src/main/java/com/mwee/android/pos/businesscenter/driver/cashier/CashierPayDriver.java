package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.GenIDPosRequest;
import com.mwee.android.cashier.connect.bean.http.GenIDPosResponse;
import com.mwee.android.cashier.connect.bean.socket.CashierPayResultResponse;
import com.mwee.android.cashier.connect.bean.socket.GenTempOrderResponse;
import com.mwee.android.cashier.connect.bean.socket.GetPayNoteResponse;
import com.mwee.android.cashier.connect.bean.socket.PrepareThirdPayResponse;
import com.mwee.android.cashier.connect.bean.socket.model.CashierPayResultInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.order.DiscountBizUtil;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintFastFoodOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.pay.PayVoidResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqModel;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.NetPayResult;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 美收银的支付的Driver
 * Created by virgil on 2018/2/1.
 *
 * @author virgil
 */
@SuppressWarnings("unused")
public class CashierPayDriver implements IDriver {
    /**
     * 构建真实订单支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/buildRealOrder")
    public static SocketResponse<?> preparePay(SocketHeader head, String param) {
        SocketResponse<GenTempOrderResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            GenTempOrderResponse response = new GenTempOrderResponse();
            OrderCache orderCache = request.getObject("tempOrder", OrderCache.class);
            if (orderCache == null) {
                socketResponse.msg(R.string.ser_cashier_login_no_phone);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            PaySession session = OrderSession.getInstance().getPay(orderCache.orderID);
            if (orderCache.checkTempOrder()) {
                String error = CashierOrderProcessor.submitCacheOrder(orderCache, session, user, head.hd);
                if (!TextUtils.isEmpty(error)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                } else {
                    head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                }
                session = OrderSession.getInstance().getPay(orderCache.orderID);
            }
            orderCache.reCalcAllByAll();
            response.updateOrderCache(orderCache);
            response.orderToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "cashierPay/buildRealOrder");
            socketResponse.data = response;
            if (session != null) {
                session = OrderUtil.buildPayCache(session, orderCache, session.billNO, head.hd, user.fsUserId, user.fsUserName);
                OrderSession.getInstance().writePay(orderCache.orderID, session);
                response.realPrice = session.priceLeftToPay;
            } else {
                response.realPrice = orderCache.optTotalPrice().subtract(orderCache.optDiscountCutAmt());
            }
            response.buildDiscountName();
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "构建真实订单支付：" + orderCache.toString());
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取"其他"里的明细
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/getCustomPayNote")
    public static SocketResponse<?> getOtherPayInfo(SocketHeader head, String param) {
        SocketResponse<GetPayNoteResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            GetPayNoteResponse response = new GetPayNoteResponse();
            response.noteList = DataCacheDBUtil.getCustomPayNote();
            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 使用折扣方案
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/selectDiscount")
    public static SocketResponse<?> selectDiscount(SocketHeader head, String param) {
        SocketResponse<GenTempOrderResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            int clearCoupon = request.getInteger("clearCoupon");
            int discountRate = request.getInteger("discountRate");
            BigDecimal cutMoney = request.getBigDecimal("cutMoney");
            //先处理订单号
            orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.ser_cashier_error_order);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            DiscountDBModel discountDBModel = null;
            if (clearCoupon > 0) {

            } else {
                if (discountRate > 0) {
                    discountRate = 100 - discountRate;
                    discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format("select * from tbDiscount where fsDiscountId='%s' and fiStatus='1'", DiscountType.CUTSOME_DISOUNT), DiscountDBModel.class);
                    if (discountDBModel == null) {
                        socketResponse.message = "该折扣方案已被禁用";
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    } else {
                        discountDBModel.fiDiscountRate = discountRate;
                    }
                } else if (cutMoney != null && cutMoney.compareTo(BigDecimal.ZERO) > 0) {
                    discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format("select * from tbDiscount where fsDiscountId='%s' and fiStatus='1'", DiscountType.CUTSOME_CUT), DiscountDBModel.class);
                    if (discountDBModel == null) {
                        socketResponse.message = "该折扣方案已被禁用";
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        return socketResponse;
                    } else {
                        discountDBModel.fdddv = cutMoney;
                    }
                } else {
                    socketResponse.message = "参数错误";
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            List<String> uniq = new ArrayList<>();

            for (MenuItem temp : orderCache.originMenuList) {
                if (temp.hasAllVoid()) {
                    continue;
                }
                uniq.add(temp.menuBiz.uniq);
            }
            if (clearCoupon > 0) {
                DiscountBizUtil.doDiscount(orderCache.originMenuList, orderCache.orderID, orderCache.fsmtableid, true, null, false, false, 0, false, null, user, null, uniq, -1, null);
            } else if (discountDBModel.ficouponid == 2) {
                DiscountBizUtil.doDiscount(orderCache.originMenuList, orderCache.orderID, orderCache.fsmtableid, false, "", false, false, 0, false, discountDBModel.fsDiscountId, user, null, uniq, discountRate, null);
            } else if (discountDBModel.ficouponid == 1) {
                DiscountBizUtil.doDiscount(orderCache.originMenuList, orderCache.orderID, orderCache.fsmtableid, false, discountDBModel.fsDiscountId, false, false, 0, false, null, user, null, uniq, -1, cutMoney);
            }
            orderCache.reCalcAllByAll();
            PaySession session = OrderSession.getInstance().getPay(orderCache.orderID);
            GenTempOrderResponse response = new GenTempOrderResponse();
            if (session != null) {
                session = OrderUtil.buildPayCache(session, orderCache, session.billNO, head.hd, user.fsUserId, user.fsUserName);
                OrderSession.getInstance().writePay(orderCache.orderID, session);
                response.realPrice = session.priceLeftToPay;
            } else {
                response.realPrice = orderCache.optTotalPrice().subtract(orderCache.optDiscountCutAmt());
            }
            OrderSession.getInstance().writeOrder(orderCache.orderID, false, "cashierPay/selectDiscount");
            response.updateOrderCache(orderCache);

            socketResponse.data = response;
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "使用折扣方案：" + response.toString());
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 暂不结账
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/payPause")
    public static SocketResponse<?> payPause(SocketHeader head, String param) {
        SocketResponse<CashierPayResultResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            //先处理订单号
            orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.ser_cashier_error_order);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);

            /**
             * 处理暂不结账 打印结账单问题
             */
            //前端所有未下单的菜
            List<MenuItem> itemList = new ArrayList<>();
            // 清除缓存中未下单的菜
            for (int i = 0; i < orderCache.originMenuList.size(); i++) {
                MenuItem item = orderCache.originMenuList.get(i);
                if (item != null && !item.hasAllVoid() && !orderCache.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                    orderCache.originMenuList.remove(i);
                    itemList.add(item);
                    i--;
                }
            }
            //去重的逻辑
            List<MenuItem> currentOrderMenu = new ArrayList<>();
            currentOrderMenu.addAll(orderCache.originMenuList);
            for (int i = 0; i < currentOrderMenu.size(); i++) {
                MenuItem tempMenu = currentOrderMenu.get(i);
                if (!orderCache.isOrderedSeqNo(tempMenu.menuBiz.orderSeqID)) {
                    itemList.add(tempMenu);
                    orderCache.originMenuList.remove(tempMenu);
                    continue;
                }
                for (int j = 0; j < itemList.size(); j++) {
                    MenuItem temp = itemList.get(j);
                    if (!TextUtils.isEmpty(tempMenu.menuBiz.uniq) && TextUtils.equals(tempMenu.menuBiz.uniq, temp.menuBiz.uniq)) {
                        //只要有一个菜是重复下的，就认为是重复订单
                        socketResponse.code = SocketResultCode.DUPLICATE;
                        socketResponse.message = "该订单已处理，请勿重复提交";
                        return socketResponse;
                    }
                }
            }
            if (itemList.size() > 0) {
                List<MenuItem> unOrderItems = new ArrayList<>();     //所有未下单的菜
                List<Integer> normalOrderSeqModel = new ArrayList<>();   //所有未下单的单序ID
                //给未下单的菜赋值下单时间，拆分配料菜
                for (int i = 0; i < itemList.size(); i++) {
                    MenuItem menuItem = itemList.get(i);
                    if (menuItem != null && !orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                        menuItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                        if (!menuItem.supportWeight() && menuItem.supportIngredient() && menuItem.menuBiz.selectedModifier.size() > 0 && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ONE) > 0) {
                            unOrderItems.addAll(menuItem.splitIngredientItem());
                        } else {
                            unOrderItems.add(menuItem);
                        }
                        normalOrderSeqModel.add(menuItem.menuBiz.orderSeqID);
                    }
                }
                if (!ListUtil.isEmpty(unOrderItems)) {
                    if (DBMetaUtil.autoUseMemberPrice()) {
                        //开启自动使用会员价 后加菜的菜品自动使用会员价
                        for (MenuItem menuItem : unOrderItems) {
                            if (orderCache.isMember) {
                                menuItem.useVipPrice("admin", "");
                            }
                        }
                    }
                    orderCache.originMenuList.addAll(unOrderItems);
                    for (Integer i : normalOrderSeqModel) {
                        orderCache.updateSeqStatus(i, OrderSeqStatus.ORDERED, user, head.hd);
                    }
                    //更新单序前先打印小票
                    orderCache.currentSeq++;
                    orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, null, head.hd);
                }
            }
            //更新快餐订单业务状态
            FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 1);
            //解锁订单
            FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);
            PaySession paySession = OrderSession.getInstance().getPay(orderID);
            String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
            if (!TextUtils.isEmpty(error)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = error;
            }

            if (itemList.size() > 0) {//打印单号为临时单号 需要提交过后再进行打印
                OrderSession.getInstance().writeOrder(orderCache.orderID, true, "cashierPay/payPause");
//                OrderProcessor.saveOrder(orderCache, null);
                //打印点菜单
                PrintFastFoodOrderUtil.printMenuList(orderCache, user, orderCache.currentSeq - 1, "", head.hd);
                //打印制作单
//                PrintFastFoodOrderUtil.printMake(orderCache, user, orderCache.currentSeq - 1, head.hd);

                //打印制作单
                if (DBOrderConfig.useKdsService() && DBOrderConfig.fastUseKdsService()) {//快餐KDS
                    KdsManager.getInstance().order(orderCache, String.valueOf(orderCache.currentSeq - 1), head.hd, user);
                } else {
                    PrintFastFoodOrderUtil.printMake(orderCache, user, orderCache.currentSeq - 1, head.hd);
                }
            }


            CashierPayResultResponse response = new CashierPayResultResponse();
            response.orderIDNeedUpdate = orderCache.orderID;
            response.payFinished = false;

            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "暂不结账：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    /**
     * 使用"现金"支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/payCash")
    public static SocketResponse<?> payCash(SocketHeader head, String param) {
        SocketResponse<CashierPayResultResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            BigDecimal receiveAmt = request.getBigDecimal("receiveAmt");//应付金额
            BigDecimal calcPaidAmt = request.getBigDecimal("calcPaidAmt");//实付金额
            int purePay = request.getInteger("purePay");//是否是纯收银

            boolean isAmtOk = receiveAmt == null || receiveAmt.compareTo(BigDecimal.ZERO) < 0 ||
                    calcPaidAmt == null || calcPaidAmt.compareTo(BigDecimal.ZERO) < 0;
            if (isAmtOk) {
                socketResponse.msg(R.string.ser_cashier_error_price);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            if (purePay == 1) {
                /**
                 * 纯收银的菜品
                 */
                MenuItem cashierMenu = MenuItemDBUtils.buildCashierMenu();
                if (cashierMenu == null) {
                    socketResponse.msg(R.string.ser_cashier_error_menu);
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }
                cashierMenu.menuBiz.uniq = UUIDUtil.optUUID();
                cashierMenu.menuBiz.buyNum = BigDecimal.ONE;
                cashierMenu.menuBiz.orderSeqID = 1;
                //改变菜品售价为应收金额  挂到订单上
                cashierMenu.currentUnit.fdSalePrice = receiveAmt;
                cashierMenu.currentUnit.fdVIPPrice = receiveAmt;
                cashierMenu.calcTotal(false);

                GenIDPosRequest genIDRequest = new GenIDPosRequest();
                BusinessExecutor.execute(genIDRequest, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GenIDPosResponse) {
                            GenIDPosResponse response = (GenIDPosResponse) responseData.responseBean;
                            if (response.data != null && !TextUtils.isEmpty(response.data.orderNum)) {

                                UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
                                OrderCache orderCache = FastFoodBusinessUtil.createNewOrderCache(response.data.orderNum, userDBModel.fsUserId, userDBModel.fsUserName, head.hd, "1");
                                orderCache.fiSellType = 3;//表示纯收银
                                orderCache.mealNumber = "1";
                                orderCache.originMenuList.add(cashierMenu);
                                orderCache.whetherRound = false;
                                orderCache.reCalcAllByAll();

                                //重新生成Token
                                head.ot = ServerCache.getInstance().generateNewToken(response.data.orderNum);
                                PaySession paySession = OrderSession.getInstance().getPay(orderCache.orderID);
                                paySession = OrderUtil.buildPayCache(paySession, orderCache, response.data.payNum, head.hd, userDBModel.fsUserId, userDBModel.fsUserName);
                                OrderSession.getInstance().writeOrder(response.data.orderNum, orderCache, false, "cashierPay/payCash");
                                // OrderProcessor.saveOrder(orderCache, null);
                                OrderSession.getInstance().writePay(response.data.orderNum, paySession);

                                CashierPayResultResponse cashierPayResultResponse = new CashierPayResultResponse();
                                cashierPayResultResponse.orderIDNeedUpdate = orderCache.orderID;
                                cashierPayResultResponse.payFinished = false;
                                cashierPayResultResponse.orderTokenNew = head.ot;

                                socketResponse.data = cashierPayResultResponse;

                                if (socketResponse.success()) {
                                    PayOriginModel payOriginModel = PayCache.getPayType(PayType.RMB);
                                    if (paySession != null && paySession.payed == 1) {//表示已经支付过信息了 处理异常情况 防止订单再进行支付问题
                                        cashierPayResultResponse.thirdPayStatus = NetPayResult.SUCCESS;
                                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                        socketResponse.msg(R.string.ser_pay_amt_payed_finish);
                                    } else {
                                        SocketResponse<PayResultResponse> netResponse = BillUtil.selectPayType(head.ot, orderCache.orderID, payOriginModel, calcPaidAmt, userDBModel, head.hd, false, false);
                                        if (!netResponse.success()) {
                                            socketResponse.code = netResponse.code;
                                            socketResponse.message = netResponse.message;
                                        } else {
                                            payFinish(socketResponse, head.ot, orderCache.orderID, userDBModel, head.hd);
                                        }
                                    }
                                }
                                socketResponse.data = cashierPayResultResponse;

                                return;
                            }
                        }
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
//                        error.append(responseData.resultMessage);
                        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "纯收银使用现金支付 GenIDPosRequest请求失败", "", responseData.responseBean);
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                        return false;
                    }
                }, false);
            } else {
                //先处理订单号
                orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
                if (TextUtils.isEmpty(orderID)) {
                    socketResponse.msg(R.string.ser_cashier_error_order);
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }

                UserDBModel user = HostUtil.getUserModelBySession(head.us);
                //重新生成Token
                head.ot = ServerCache.getInstance().generateNewToken(orderID);
                OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
                PaySession paySession = OrderSession.getInstance().getPay(orderID);
                if (orderCache.checkTempOrder()) {
                    String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
                    if (!TextUtils.isEmpty(error)) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = error;
                    } else {
                        head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                        orderID = orderCache.orderID;
                    }
                }
                CashierPayResultResponse response = new CashierPayResultResponse();
                response.orderIDNeedUpdate = orderCache.orderID;
                response.payFinished = false;
                response.orderTokenNew = head.ot;
                socketResponse.data = response;
                if (socketResponse.success()) {
                    PayOriginModel payOriginModel = PayCache.getPayType(PayType.RMB);
                    if (paySession != null && paySession.payed == 1) {//表示已经支付过信息了 处理异常情况 防止订单再进行支付问题
                        response.thirdPayStatus = NetPayResult.SUCCESS;
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.msg(R.string.ser_pay_amt_payed_finish);
                    } else {
                        SocketResponse<PayResultResponse> netResponse = BillUtil.selectPayType(head.ot, orderCache.orderID, payOriginModel, calcPaidAmt, user, head.hd, false, true);
                        if (!netResponse.success()) {
                            socketResponse.code = netResponse.code;
                            socketResponse.message = netResponse.message;
                        } else {
                            payFinish(socketResponse, head.ot, orderCache.orderID, user, head.hd);
                        }
                    }

                }
                socketResponse.data = response;
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "使用现金支付：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }


    /**
     * 使用"其他"支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/payOther")
    public static SocketResponse<?> payOther(SocketHeader head, String param) {
        SocketResponse<CashierPayResultResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            String note = request.getString("note");
            //先处理订单号
            orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.ser_cashier_error_order);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            //重新生成Token
            head.ot = ServerCache.getInstance().generateNewToken(orderID);
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            PaySession paySession = OrderSession.getInstance().getPay(orderID);
            if (orderCache.checkTempOrder()) {
                String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
                if (!TextUtils.isEmpty(error)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                } else {
                    head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                    orderID = orderCache.orderID;
                }
                paySession = OrderSession.getInstance().getPay(orderCache.orderID);
            }
            CashierPayResultResponse response = new CashierPayResultResponse();
            response.orderIDNeedUpdate = orderCache.orderID;
            response.payFinished = false;
            response.orderTokenNew = head.ot;
            socketResponse.data = response;
            if (socketResponse.success()) {
                PayOriginModel payOriginModel = PayCache.getPayType(PayType.OTHER);
                if (paySession != null && paySession.payed == 1) {//表示已经支付过信息了 处理异常情况 防止订单再进行支付问题
                    response.thirdPayStatus = NetPayResult.SUCCESS;
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.msg(R.string.ser_pay_amt_payed_finish);
                } else {
                    SocketResponse<PayResultResponse> netResponse = BillUtil.selectPayType(head.ot, orderCache.orderID, payOriginModel, paySession.priceLeftToPay, user, head.hd, false, true);
                    if (!netResponse.success()) {
                        socketResponse.code = netResponse.code;
                        socketResponse.message = netResponse.message;
                    } else {
                        DataCacheDBUtil.addCustomPayNote(note);
                        payFinish(socketResponse, head.ot, orderCache.orderID, user, head.hd);
                        response.info.note = note;
                    }
                }

            }
            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "使用其他支付：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    /**
     * 准备扫码支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/preparePayNet")
    public static SocketResponse<?> preparePayNet(SocketHeader head, String param) {
        SocketResponse<PrepareThirdPayResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            int purePay = request.getInteger("purePay");
            //先处理订单号
            orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
            if (purePay == 0 && TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.ser_cashier_error_order);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);

            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            PaySession paySession = OrderSession.getInstance().getPay(orderID);
            if (orderCache.checkTempOrder()) {
                String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
                if (!TextUtils.isEmpty(error)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                } else {
                    head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                    orderID = orderCache.orderID;
                }
            }
            PrepareThirdPayResponse response = new PrepareThirdPayResponse();
            response.orderIDNeedUpdate = orderCache.orderID;
            response.orderTokenNew = head.ot;
            if (socketResponse.success()) {
                paySession = OrderSession.getInstance().getPay(orderCache.orderID);
                response.thirdOrderID = OrderUtil.buildNetOrderID(paySession.fsShopID, paySession.billNO);
            }

            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "准备扫码支付：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }


    /**
     * 准备纯收银扫码支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/preparePayPureNet")
    public static SocketResponse<?> preparePayPureNet(SocketHeader head, String param) {

        SocketResponse<PrepareThirdPayResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            //String orderID = request.getString("orderID");
            BigDecimal payAmount = request.getBigDecimal("payAmount");
            int purePay = request.getInteger("purePay");
            if (purePay == 1) {
                /**
                 * 纯收银的菜品
                 */
                MenuItem cashierMenu = MenuItemDBUtils.buildCashierMenu();
                if (cashierMenu == null) {
                    socketResponse.msg(R.string.ser_cashier_error_menu);
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    return socketResponse;
                }
                cashierMenu.menuBiz.uniq = UUIDUtil.optUUID();
                cashierMenu.menuBiz.buyNum = BigDecimal.ONE;
                cashierMenu.menuBiz.orderSeqID = 1;
                //改变菜品售价为应收金额  挂到订单上
                cashierMenu.currentUnit.fdSalePrice = payAmount;
                cashierMenu.currentUnit.fdVIPPrice = payAmount;
                cashierMenu.calcTotal(false);

                GenIDPosRequest genIDRequest = new GenIDPosRequest();
                BusinessExecutor.execute(genIDRequest, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GenIDPosResponse) {
                            GenIDPosResponse response = (GenIDPosResponse) responseData.responseBean;
                            if (response.data != null && !TextUtils.isEmpty(response.data.orderNum)) {

                                UserDBModel user = HostUtil.getUserModelBySession(head.us);
                                OrderCache orderCache = FastFoodBusinessUtil.createNewOrderCache(response.data.orderNum, user.fsUserId, user.fsUserName, head.hd, "1");
                                orderCache.fiSellType = 3;//表示纯收银
                                orderCache.mealNumber = "1";
                                orderCache.whetherRound = false;
                                orderCache.originMenuList.add(cashierMenu);
                                orderCache.reCalcAllByAll();

                                //重新生成Token
                                head.ot = ServerCache.getInstance().generateNewToken(response.data.orderNum);

                                PaySession paySession = OrderSession.getInstance().getPay(orderCache.orderID);
                                paySession = OrderUtil.buildPayCache(paySession, orderCache, response.data.payNum, head.hd, user.fsUserId, user.fsUserName);
                                OrderSession.getInstance().writeOrder(response.data.orderNum, orderCache, false, "cashierPay/preparePayPureNet");
                                OrderSession.getInstance().writePay(response.data.orderNum, paySession);


                                if (orderCache.checkTempOrder()) {
                                    String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
                                    if (!TextUtils.isEmpty(error)) {
                                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                        socketResponse.message = error;
                                    } else {
                                        head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                                    }
                                }
                                PrepareThirdPayResponse payResponse = new PrepareThirdPayResponse();
                                payResponse.orderIDNeedUpdate = orderCache.orderID;
                                payResponse.orderTokenNew = head.ot;
                                if (socketResponse.success()) {
                                    paySession = OrderSession.getInstance().getPay(orderCache.orderID);
                                    payResponse.thirdOrderID = OrderUtil.buildNetOrderID(paySession.fsShopID, paySession.billNO);
                                }
                                socketResponse.data = payResponse;

                                return;
                            }
                        }
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "纯收银使用扫码支付 GenIDPosRequest请求失败", "", responseData.responseBean);
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;

                        return false;
                    }
                }, false);
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "准备扫码支付：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }


    /**
     * 扫码支付
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/payNet")
    public static SocketResponse<?> payNet(SocketHeader head, String param) {
        SocketResponse<CashierPayResultResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            String barCode = request.getString("barCode");
            String thirdOrderID = request.getString("thirdOrderID");
            //先处理订单号
            orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.ser_cashier_error_order);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            String codeError = NetPayUtil.checkSuooprt(null, barCode);
            if (!TextUtils.isEmpty(codeError)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = codeError;
                return socketResponse;
            }
            if (TextUtils.isEmpty(thirdOrderID)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "第三方订单号为空";
                return socketResponse;
            }
            UserDBModel user = HostUtil.getUserModelBySession(head.us);

            //重新生成Token
            head.ot = ServerCache.getInstance().generateNewToken(orderID);
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            PaySession paySession = OrderSession.getInstance().getPay(orderID);
            if (orderCache.checkTempOrder()) {
                String error = CashierOrderProcessor.submitCacheOrder(orderCache, paySession, user, head.hd);
                if (!TextUtils.isEmpty(error)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = error;
                } else {
                    head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
                    orderID = orderCache.orderID;
                }
                paySession = OrderSession.getInstance().getPay(orderCache.orderID);
            }
            CashierPayResultResponse response = new CashierPayResultResponse();
            response.orderIDNeedUpdate = orderCache.orderID;
            response.payFinished = false;
            response.orderTokenNew = head.ot;
            socketResponse.data = response;
            if (socketResponse.success()) {
                if (paySession != null && paySession.payed == 1) {//表示已经支付过信息了 处理异常情况 防止订单再进行支付问题
                    response.thirdPayStatus = NetPayResult.SUCCESS;
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.msg(R.string.ser_pay_amt_payed_finish);
                } else {
                    SocketResponse<PayResultResponse> netResponse = BillUtil.selectNetPay(head.ot, orderCache.orderID, false, thirdOrderID, paySession.priceLeftToPay, barCode, user, head.hd, false);
                    if (!netResponse.success() || netResponse.data.thirdPayStatus != NetPayResult.SUCCESS) {
                        socketResponse.code = netResponse.code;
                    } else {
                        payFinish(socketResponse, head.ot, orderCache.orderID, user, head.hd);
                        //response.payFinished = netResponse.data.payFinished;
                    }
                    response.thirdPayOrderID = netResponse.data.thirdPayOrderID;
                    response.thirdPayStatus = netResponse.data.thirdPayStatus;
                    response.needMemberPwd = netResponse.data.needMemberPwd;
                    socketResponse.message = netResponse.message;
                }
            }

            socketResponse.data = response;
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "重新查询条码支付的结果：" + JSON.toJSONString(socketResponse), orderID, "", "");
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 重新查询条码支付的结果
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/reSearchPay")
    public static SocketResponse reSearchPay(SocketHeader head, String param) {
        SocketResponse<CashierPayResultResponse> socketResponse = new SocketResponse<>();
        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderID");
        String thirdPayOrderID = request.getString("thirdPayOrderID");
        //先处理订单号
        orderID = CashierOrderProcessor.checkOrderIDValid(orderID);
        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        if (TextUtils.isEmpty(thirdPayOrderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "第三方支付的订单号为空";
            return socketResponse;
        }
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        //重新生成Token
        head.ot = ServerCache.getInstance().generateNewToken(orderID);
        SocketResponse<PayResultResponse> netResponse = BillUtil.selectNetPay(head.ot, orderID, true, thirdPayOrderID, BigDecimal.ZERO, "", user,
                head.hd, false);
        CashierPayResultResponse response = new CashierPayResultResponse();
        response.orderIDNeedUpdate = orderID;
        response.payFinished = false;
        response.orderTokenNew = head.ot;
        socketResponse.data = response;
        if (!netResponse.success()) {
            socketResponse.code = netResponse.code;
            socketResponse.message = netResponse.message;
        } else {
            if (netResponse.success() && netResponse.data.thirdPayStatus == NetPayResult.SUCCESS) {
                payFinish(socketResponse, head.ot, orderID, user, head.hd);
            }
            response.payFinished = netResponse.data.payFinished;
            response.thirdPayOrderID = netResponse.data.thirdPayOrderID;
            response.thirdPayStatus = netResponse.data.thirdPayStatus;
            response.needMemberPwd = netResponse.data.needMemberPwd;
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "重新查询条码支付的结果：" + JSON.toJSONString(socketResponse), orderID, "", "");
        return socketResponse;
    }

    public static void payFinish(SocketResponse<CashierPayResultResponse> socketResponse, String orderToken, String orderID, UserDBModel userDBModel, String hosID) {
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        orderCache.businessDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        PaySession paySession = OrderSession.getInstance().getPay(orderID);
        paySession.businessDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        OrderUtil.recalcPaySessionLeftToPay(paySession, orderCache);
        SocketResponse<PayResultResponse> resultResponse = BillUtil.startFinalPayProcess(orderToken, orderID, userDBModel, hosID, false, true);
        //如果自动结账失败，则进行自动退款
        boolean isVoidPay = false;
        if (!resultResponse.success()) {
            socketResponse.code = resultResponse.code;
            socketResponse.message = resultResponse.message;
            if (!ListUtil.isEmpty(paySession.selectPayListFull)) {
                for (PayModel temp : paySession.selectPayListFull) {
                    if (temp.checkEnable()) {
                        BillUtil.startVoidPay(orderToken, orderID, userDBModel, hosID, temp.seq);
                        isVoidPay = true;
                    }
                }
            }
        }
        if (resultResponse.data != null) {
            socketResponse.data.payFinished = resultResponse.data.payFinished;
            socketResponse.data.thirdPayOrderID = resultResponse.data.thirdPayOrderID;
            socketResponse.data.thirdPayStatus = resultResponse.data.thirdPayStatus;
            socketResponse.data.needMemberPwd = resultResponse.data.needMemberPwd;
        }
        if (isVoidPay) {
            return;
        }
        CashierPayResultInfo info = new CashierPayResultInfo();
        socketResponse.data.info = info;
        info.orderID = orderCache.orderID;
        info.amountTotal = orderCache.optTotalPriceBeforeDiscount().toPlainString();
        info.amtNeedPay = orderCache.optTotalPrice().subtract(orderCache.optDiscountCutAmt()).toPlainString();
        info.round = orderCache.totalRound.toPlainString();
        info.mealno = orderCache.mealNumber;
        for (PayModel payModel : paySession.selectPayListFull) {
            if (payModel.data.payTypeID.equals(PayType.LESS)) {
                continue;
            }
            info.payType = payModel.data.payName;
        }
        if (orderCache.selectOrderDiscountCut != null) {
            info.couponAmount = orderCache.selectOrderDiscountCut.fdddv.toPlainString();
            info.couponName = "自定义减价";
        } else {
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                for (MenuItem temp : orderCache.originMenuList) {
                    if (temp.menuBiz.selectDiscount != null) {
                        info.couponName = new BigDecimal(100 - temp.menuBiz.selectDiscount.fiDiscountRate).divide(new BigDecimal(10)).toString() + "折";
                        break;
                    }
                }
            }
            info.couponAmount = orderCache.totalDiscountAmount.toPlainString();
        }
        info.isJustPay = orderCache.fiSellType == 3 ? 1 : 0;
        CashierOrderProcessor.submitCacheOrder(orderCache, paySession, userDBModel, hosID);
    }

    /**
     * 反结账
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/antiPay")
    public static SocketResponse antiPay(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        JSONObject request = JSON.parseObject(param);
        String orderID = request.getString("orderID");
        UserDBModel user = HostUtil.getUserModelBySession(head.us);
        if (TextUtils.isEmpty(orderID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "订单号为空";
            return socketResponse;
        }
        OrderCache orderCache;
        SocketResponse<GenTempOrderResponse> genTempOrderResponse = CashierOrderProcessor.getCachedOrderPos(orderID);
        if (genTempOrderResponse.success()) {
            orderCache = genTempOrderResponse.data.temOrder;
        } else {
            orderCache = OrderSession.getInstance().getOrder(orderID);
        }
        if (orderCache == null) {
            socketResponse.code = genTempOrderResponse.code;
            socketResponse.message = genTempOrderResponse.message;
            return socketResponse;
        }
        if (orderCache.orderStatus == OrderStatus.ANTI_PAIED) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "此订单尚未结账，请去未结账订单中处理。";
            return socketResponse;
        }
        PaySession session = OrderSession.getInstance().getPay(orderID);
        if (orderCache == null || session == null) {
            socketResponse.msg(R.string.ser_cashier_error_order);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            return socketResponse;
        }
        List<PayModel> needVoid = new ArrayList<>();
        int seq = -1;
        if (!ListUtil.isEmpty(session.selectPayListFull)) {

            for (PayModel temp : session.selectPayListFull) {
                if (temp.checkEnable()) {
                    seq = temp.seq;
                    break;
                }
            }
        }
        BaseSocketResponse response = new BaseSocketResponse();
        head.ot = ServerCache.getInstance().generateNewToken(orderID);
        if (seq > 0) {
            SocketResponse<PayVoidResponse> voidResponse = BillUtil.startCashierVoidPay(head.ot, orderID, user, head.hd);
            socketResponse.code = voidResponse.code;
            socketResponse.message = voidResponse.message;
            BillUtil.antiPayOrderStatus(orderCache, user, orderID, "");
            if (orderCache.fiSellType == 3) {
                orderCache.originMenuList.get(0).doVoid(orderCache.totalCount, user.fsUserId, user.fsUserName, "");
                orderCache.reCalcAllByAll();
                SocketResponse<CashierPayResultResponse> cashierPayResultResponse = new SocketResponse<>();
                cashierPayResultResponse.data = new CashierPayResultResponse();
                payFinish(cashierPayResultResponse, head.ot, orderCache.orderID, user, head.hd);
            } else {
                CashierOrderProcessor.submitCacheOrder(orderCache, session, user, head.hd);
            }
        }
        socketResponse.data = response;
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "反结账：" + JSON.toJSONString(socketResponse), orderID, "", "");
        return socketResponse;
    }

    /**
     * 打印结账单
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/doBillPrinter")
    public static SocketResponse<?> doBillPrinter(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            UserDBModel user = HostUtil.getUserModelBySession(head.us);

            PrintBillUtil.printFastFoodBill(orderID, head.hd, user.fsUserName);

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "打印结账单：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    /**
     * 打印制作单
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierPay/doMakePrinter")
    public static SocketResponse<?> doMakePrinter(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderID");
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
            //获取单序
            String seqsSB = "";
            for (OrderSeqModel orderSeqModel : orderCache.seqList) {
                if (orderSeqModel.seqStatus == OrderSeqStatus.ORDERED) {
                    seqsSB = seqsSB + orderSeqModel.seqNo + ",";
                }
            }

            if (!TextUtils.isEmpty(seqsSB)) {
                seqsSB = seqsSB.substring(0, seqsSB.length() - 1);
            }

            //快餐进KDS
            if (DBOrderConfig.useKdsService() && DBOrderConfig.fastUseKdsService()) {//快餐KDS
                KdsManager.getInstance().order(orderCache, seqsSB, head.hd, user);
            } else {
                PrintFastFoodOrderUtil.printMake(orderCache, user, seqsSB, head.hd);
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "打印制作单：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return "cashierPay";
    }
}
