package com.mwee.android.pos.businesscenter.module.koubei.process;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBDishMenuItem;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.OutDishInfo;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 口碑订单菜品转换美味菜品数据结构
 * Created by qinwei on 2019/1/24 12:06 PM
 * email: qin.wei@mwee.cn
 */

public class KBMenuItemUtils {
    /**
     * 口碑后付订单转美味菜品数据结构
     *
     * @param dish_details 口碑菜品数据
     * @param memo
     * @return 本地菜品业务数据
     */
    public static ArrayList<MenuItem> copyTo(List<KBDishMenuItem> dish_details, String memo) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        MenuitemDBModel itemDB = null;
        MenuItemUnitDBModel unit = null;
        for (KBDishMenuItem item : dish_details) {
            if (TextUtils.equals(item.dish_type, KBDishMenuItem.COMBO)) {
                //套餐
                itemDB = findMappingMenuItemDBModel(item.out_dish_id, item.dish_name, DBConstants.MENU_ITEM_KIND_PACKAGE);
                unit = findMappingMenuItemUnitDBModel(item.out_sku_id, DBConstants.MENU_ITEM_KIND_PACKAGE);
            } else {
                //单品
                itemDB = findMappingMenuItemDBModel(item.out_dish_id, item.dish_name, DBConstants.MENU_ITEM_KIND_SINGLE);
                unit = findMappingMenuItemUnitDBModel(item.out_sku_id, DBConstants.MENU_ITEM_KIND_SINGLE);
            }
            //匹配到本地菜品
            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB);
            //保存第三方菜品信息
            menuItem.thirdMenuId = item.dish_id;
            menuItem.thirdMenuName = item.dish_name;
            menuItem.thirdUnitId = item.sku_id;
            menuItem.thirdUnitName = item.out_dish_infos.SPECIFICATION;
            unit.fdVIPPrice = item.price;
            unit.fdOriginPrice = item.price;
            unit.fdSalePrice = item.price;
            menuItem.updateCurrentUnit(UnitModel.copyTo(unit));
            //处理菜品业务数据
            menuItem.menuBiz = MenuBiz.newInstance();
            menuItem.menuBiz.addConfig(8);
            menuItem.menuBiz.buyNum = item.num;
            //添加菜品要求
            menuItem.addNotes(buildNotes(item.out_dish_infos, memo));
            menuItem.addOrderNote(buildNote(memo));
            if (!ListUtil.isEmpty(item.selected_meal_info)) {
                switch (item.dish_type) {
                    case KBDishMenuItem.COMBO:
                        //拼接一个套餐属性
                        menuItem.config = menuItem.config | 256;
                        //处理套餐
                        menuItem.menuBiz.selectedPackageItems = KBMenuItemUtils.copyTo(item.selected_meal_info);
                        break;
                    case KBDishMenuItem.SINGLE:
                        //写入配料主菜属性
                        menuItem.config = menuItem.config | 1024;
                        //处理配料
                        menuItem.menuBiz.selectedModifier = KBMenuItemUtils.copyTo(item.selected_meal_info);
                        //菜品价格减去配料价格
                        for (KBDishMenuItem.SelectedMealInfo selectedMealInfo : item.selected_meal_info) {
                            menuItem.price = menuItem.price.subtract(selectedMealInfo.side_price.multiply(selectedMealInfo.num));
                        }
                        menuItem.currentUnit.fdOriginPrice = menuItem.price;
                        menuItem.currentUnit.fdSalePrice = menuItem.price;
                        menuItem.currentUnit.fdVIPPrice = menuItem.price;
                        break;
                    default:
                        break;
                }
            }
            //口碑菜品额外信息保存
            if (item.out_dish_infos != null) {
                JSONObject object = new JSONObject();
                object.put("out_dish_infos", item.out_dish_infos);
                menuItem.menuBiz.extInfo = object.toJSONString();
            }
            menuItems.add(menuItem);
        }
        return menuItems;
    }


    /**
     * 口碑后付订单配料转美味菜品
     *
     * @param selected_meal_info
     * @return
     */
    public static List<MenuItem> copyTo(ArrayList<KBDishMenuItem.SelectedMealInfo> selected_meal_info) {
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        for (KBDishMenuItem.SelectedMealInfo item : selected_meal_info) {
            MenuitemDBModel itemDB = null;
            if (TextUtils.equals(item.type, KBDishMenuItem.SelectedMealInfo.COMBO)) {
                //套餐子明细
                itemDB = findMappingMenuItemDBModel(item.out_dish_id, item.dish_name, DBConstants.MENU_ITEM_KIND_SINGLE);
            } else if (TextUtils.equals(item.type, KBDishMenuItem.SelectedMealInfo.SIDE)) {
                //配料
                itemDB = findMappingMenuItemDBModel(item.out_dish_id, item.dish_name, DBConstants.MENU_ITEM_KIND_SIDE);
            }
            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB);
            menuItem.thirdMenuId = item.dish_id;
            menuItem.thirdMenuName = item.dish_name;
            menuItem.thirdUnitId = item.sku_id;
            menuItem.thirdUnitName = item.unit;
            MenuItemUnitDBModel unit = findMappingMenuItemUnitDBModel(item.out_sku_id, DBConstants.MENU_ITEM_KIND_SINGLE);
//            unit.fsOrderUint = menuItem.thirdUnitName;
            switch (item.type) {
                case KBDishMenuItem.SelectedMealInfo.COMBO:
                    unit.fdVIPPrice = item.add_price;
                    unit.fdOriginPrice = item.add_price;
                    unit.fdSalePrice = item.add_price;
                    break;
                case KBDishMenuItem.SelectedMealInfo.SIDE:
                    unit.fdVIPPrice = item.side_price;
                    unit.fdOriginPrice = item.side_price;
                    unit.fdSalePrice = item.side_price;
                    break;
                default:
                    break;
            }
            menuItem.updateCurrentUnit(UnitModel.copyTo(unit));
            menuItem.menuBiz = MenuBiz.newInstance();
            menuItem.menuBiz.addConfig(8);
            menuItem.menuBiz.buyNum = item.num;
            /* 口碑做法 */
            if (item.out_dish_infos != null) {
                NoteItemModel note = new NoteItemModel();
                note.selected = true;
                note.num = BigDecimal.ONE;
                note.name = item.out_dish_infos.PRACTICE;
                note.uniq = UUIDUtil.optUUID();
                menuItem.addNote(note);
                JSONObject object = new JSONObject();
                object.put("out_dish_infos", item.out_dish_infos);
                menuItem.menuBiz.extInfo = object.toJSONString();
            }
            menuItems.add(menuItem);
        }
        return menuItems;
    }

    public static ArrayList<MenuItem> copyTo(ArrayList<KBPreMenuItemModel> dish_details, String memo) {
        NoteItemModel noteOrder = NoteItemModel.createCustomeNote(memo, 1, BigDecimal.ZERO);
        ArrayList<MenuItem> menuItems = new ArrayList<>();
        for (KBPreMenuItemModel item : dish_details) {
            MenuitemDBModel itemDB = null;
            MenuItemUnitDBModel unit = null;
            //套餐
            if (item.type.equals("COMBO")) {
                itemDB = findMappingMenuItemDBModel(item.fiItemCd, item.dish_name, DBConstants.MENU_ITEM_KIND_PACKAGE);
                unit = findMappingMenuItemUnitDBModel(item.fiOrderUintCd, DBConstants.MENU_ITEM_KIND_PACKAGE);
            } else {
                //单品
                itemDB = findMappingMenuItemDBModel(item.fiItemCd, item.dish_name, DBConstants.MENU_ITEM_KIND_SINGLE);
                unit = findMappingMenuItemUnitDBModel(item.fiOrderUintCd, DBConstants.MENU_ITEM_KIND_SINGLE);
            }
            //匹配到本地菜品
            MenuItem menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
            menuItem.updateCurrentUnit(UnitModel.copyTo(unit));
            if (menuItem.currentUnit == null) {
                menuItem.currentUnit = new UnitModel();
            }
            if (menuItem.menuBiz == null) {
                menuItem.menuBiz = new MenuBiz();
            }
            menuItem.menuBiz.generateUniq();
            menuItem.menuBiz.addConfig(8);
            menuItem.menuBiz.selectOrderNote.clear();
            menuItem.addOrderNote(noteOrder);
            /* 口碑做法 */
            if (!TextUtils.isEmpty(item.practice_info)) {
                NoteItemModel note = new NoteItemModel();
                note.selected = true;
                note.num = BigDecimal.ONE;
                note.name = item.practice_info;
                note.uniq = UUIDUtil.optUUID();
                menuItem.addNote(note);
                menuItem.menuBiz.note = item.practice_info;
            }
            //价格
            menuItem.price = item.sell_price;
            menuItem.currentUnit.fdOriginPrice = item.sell_price;
            menuItem.currentUnit.fdSalePrice = item.sell_price;
            menuItem.currentUnit.fdVIPPrice = item.member_price;
            menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
            menuItem.menuBiz.totalPrice = item.sell_price.multiply(item.dish_num);
            menuItem.menuBiz.buyNum = item.dish_num;
            //去掉时价 称重属性
            if (menuItem.supportTimes()) {
                menuItem.decreasConfig(512);
            }
            if (menuItem.supportWeight()) {
                menuItem.decreasConfig(32);
            }
            if (!ListUtil.isEmpty(item.packageMenuItemDetails)) {
                //拼接一个套餐属性
                menuItem.config = menuItem.config | 256;
                //处理套餐
                menuItem.menuBiz.selectedPackageItems = copyTo(item.packageMenuItemDetails, memo);
            }

            if (!ListUtil.isEmpty(item.selectedModifier)) {
                //拼接一个套餐属性
                menuItem.config = menuItem.config | 1024;
                //处理套餐
                menuItem.menuBiz.selectedModifier = copyTo(item.selectedModifier, memo);
            }


            menuItems.add(menuItem);
        }
        return menuItems;
    }

    /**
     * 找映射菜品
     *
     * @param out_dish_id  美味菜品id
     * @param menuItemKind 菜品类型
     * @return 美味菜品信息
     */
    private static MenuitemDBModel findMappingMenuItemDBModel(String out_dish_id, String dish_name, int menuItemKind) {
        MenuitemDBModel itemDB = null;
        if (!TextUtils.isEmpty(out_dish_id)) {
            itemDB = MenuDBUtil.getUsefulMenuDBModelBy(out_dish_id);
            if (itemDB != null) {
                itemDB.fsItemName = dish_name;
                return itemDB;
            }
        }
        if (menuItemKind == DBConstants.MENU_ITEM_KIND_PACKAGE) {
            itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_KB_PACKAGE_TEMP);
        } else if (menuItemKind == DBConstants.MENU_ITEM_KIND_SINGLE) {
            itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_TEMP);
        } else if (menuItemKind == DBConstants.MENU_ITEM_KIND_SIDE) {
            itemDB = MenuDBUtil.getUsefulMenuDBModelBy(DBConstants.MENU_ITEM_ID_TEMP);
        }
        itemDB.fsItemName = dish_name + "[口碑]";
        itemDB.fsItemName2 = dish_name + "[口碑]";
        return itemDB;
    }

    /**
     * 找映射菜品规格
     *
     * @param out_sku_id 本地规格id
     * @return 美味菜品规格信息
     */
    private static MenuItemUnitDBModel findMappingMenuItemUnitDBModel(String out_sku_id, int menuItemKind) {
        MenuItemUnitDBModel unitDBModel = null;
        //找映射规格
        if (!TextUtils.isEmpty(out_sku_id)) {
            unitDBModel = MenuDBUtil.queryMenuItemUnit(out_sku_id);
            return unitDBModel;
        }
        //使用临时规格
        if (menuItemKind == DBConstants.MENU_ITEM_KIND_PACKAGE) {
            unitDBModel = MenuDBUtil.queryMenuItemUnit(DBConstants.MENU_UNIT_ID_KB_PACKAGE_TEMP);
        } else {
            unitDBModel = MenuDBUtil.queryMenuItemUnit(DBConstants.MENU_ITEM_UNIT_ID_TEMP);
        }
        if (unitDBModel == null) {
            RunTimeLog.addLog(RunTimeLog.DINNER_ORDER, "fiOrderUintCd:" + out_sku_id + ",not find");
        }
        return unitDBModel;
    }


    private static NoteItemModel buildNote(String name) {
        NoteItemModel note = new NoteItemModel();
        note.selected = true;
        note.num = BigDecimal.ONE;
        note.name = name;
        note.uniq = UUIDUtil.optUUID();
        return note;
    }

    /**
     * 构建要求
     * {
     * "PRACTICE_PRICE": "0.00",
     * "SPECIFICATION": "份",
     * "SALES_PROPERTY": "{\"备注\":[\"加急\"]}"
     * }
     *
     * @param outDishInfo
     * @param memo
     * @return
     */
    private static ArrayList<NoteItemModel> buildNotes(OutDishInfo outDishInfo, String memo) {
        ArrayList<NoteItemModel> notes = new ArrayList<>();
        if (outDishInfo == null) {
            return notes;
        }
        //处理做法
        if (!TextUtils.isEmpty(outDishInfo.PRACTICE)) {
            notes.add(buildNote(outDishInfo.PRACTICE));
        }
        if (!TextUtils.isEmpty(outDishInfo.SALES_PROPERTY)) {
            //处理菜品销售属性
            JSONObject jsonObject = JSONObject.parseObject(outDishInfo.SALES_PROPERTY);
            Set<Map.Entry<String, Object>> set = jsonObject.entrySet();
            for (Map.Entry<String, Object> entry : set) {
                //不需要拼接要求组名
                List<String> values = JSONObject.parseArray(entry.getValue().toString(), String.class);
                String name = "";
                for (int i = 0; i < values.size(); i++) {
                    if (i == values.size() - 1) {
                        name += values.get(i);
                    } else {
                        name += values.get(i) + ",";
                    }
                }
                notes.add(buildNote(name));
            }
        }
        return notes;
    }
}
