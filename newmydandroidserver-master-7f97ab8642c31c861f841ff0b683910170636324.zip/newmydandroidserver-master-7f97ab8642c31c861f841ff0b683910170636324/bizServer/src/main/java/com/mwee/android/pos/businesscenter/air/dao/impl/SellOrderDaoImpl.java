package com.mwee.android.pos.businesscenter.air.dao.impl;

import com.mwee.android.pos.businesscenter.air.dao.ISellOrderDao;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.SellOrderDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;

/**
 * Created by qinwei on 2018/10/29.
 */

public class SellOrderDaoImpl implements ISellOrderDao {
    @Override
    public SellOrderDBModel queryById(String id) {
        return null;
    }

    @Override
    public ArrayList<SellOrderDBModel> queryAll() {
        return null;
    }


    @Override
    public long update(SellOrderDBModel sellOrderDBModel) {
        return 0;
    }

    @Override
    public long delete(String id) {
        return 0;
    }

    @Override
    public boolean isExistByThirdSeq(String fsThirdBatchNo) {
        String sql = "select count(*) from  tbSellOrder where fsThirdBatchNo='" + fsThirdBatchNo + "'";
        return StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), 0) > 0;
    }
}
