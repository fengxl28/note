package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.businesscenter.print.MemberPrint;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberRechargeResultModel;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.CheckCardTypeResponse;
import com.mwee.android.pos.component.member.newInterface.model.NewPayCodeModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberListResponse;
import com.mwee.android.pos.connect.business.pay.GetPayMemberTicketResponse;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.dbutil.CardRelationDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.ServerMemberApi;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.connect.business.bean.NewQueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.PrinterMemberResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by huangming on 2018/12/4.
 * 会员重构新Driver接口
 */

public class NewMemberDriver implements IDriver {

    private static final String TAG = "newMemberDriver";

    /**
     * 获取会员的优惠券的列表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getmemberticket")
    public static SocketResponse getMemberTicket(SocketHeader head, String param) {
        SocketResponse<GetPayMemberTicketResponse> socketResponse = new SocketResponse<>();
        LogUtil.log("会员重构", "业务中心收到拿数据请求");
        try {
            JSONObject request = JSON.parseObject(param);
            String orderID = request.getString("orderid");
            if (TextUtils.isEmpty(orderID)) {
                socketResponse.msg(R.string.serr_invalid_orderid);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            socketResponse = BillUtil.searchMemberTicket(orderID);
            LogUtil.log("会员重构", "业务中心拿数据后返回结果");
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError("会员重构", e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/queryMemberScore")
    public SocketResponse queryMemberScore(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String cardNoOrMobile = request.getString("cardNoOrMobile");
            int pageNo = request.getInteger("pageNo");

            ServerMemberApi.queryMemberScore(mShopID, cardNoOrMobile, pageNo, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 储值记录
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryTradeDetail")
    public SocketResponse queryTradeDetail(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String cardNoOrMobile = request.getString("cardNoOrMobile");
            int pageNo = request.getInteger("pageNo");

            ServerMemberApi.queryMemberTradeDetail(mShopID, cardNoOrMobile, pageNo, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 优惠券列表
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryMemberCoupons")
    public SocketResponse queryMemberCoupons(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String cardNo = request.getString("cardNo");
            int pageNo = request.getInteger("pageNo");

            ServerMemberApi.queryMemberCoupons(mShopID, cardNo, pageNo, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 会员特权
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryMemberPrivate")
    public SocketResponse queryMemberPrivate(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String csId = request.getString("csId");
            String cardNo = request.getString("cardNo");
            int memberLevel = request.getInteger("memberLevel");

            String shopGUID = ServerCache.getInstance().shopID;

            ServerMemberApi.queryMemberPrivate(mShopID, csId, memberLevel,shopGUID,cardNo, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberInfo")
    public SocketResponse loadMemberInfo(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse socketResponse = new SocketResponse();
        NewQueryMemberListResponse response = new NewQueryMemberListResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.data = response;

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            // 会员帐号，手机号/卡号
            String account = request.getString("account");

            if (TextUtils.isEmpty(account)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "会员卡号或手机号为空";
                return socketResponse;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(account);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员与美味会员号映射【" + account + "," + cardNoRelation + "】");
                account = cardNoRelation;
            }

            String companyGUID = ServerCache.getInstance().fsCompanyGUID;
            String shopGUID = ServerCache.getInstance().shopID;
            // 手机验证码
            String verifyCode = request.getString("verifyCode");
            // 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
            int verifyCodeType = request.getIntValue("verifyCodeType");

            // 需要拿卡详情的卡号
            final String[] cardNo = {""};
            final String countFinal = account;
            if (RegexUtil.checkIsPhoneNumber(account)) { // 手机号，拿列表
                ServerMemberApi.loadMemberCardListByMobile(companyGUID, shopGUID, account, verifyCode, verifyCodeType, new IResponse<List<NewMemberCardListItemModel>>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, List<NewMemberCardListItemModel> info) {
                        if (code == SocketResultCode.SUCCESS) {
                            // 卡列表为空,再把此账号当卡号查询
                            if (ListUtil.isEmpty(info)) {
//                                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
//                                socketResponse.message = "该手机号名下没有适用当前门店的卡";
                                cardNo[0] = countFinal;
                                return;
                            }

                            // 只有1张卡，不赋值卡列表，后面赋值卡详情
                            if (info.size() == 1) {
                                cardNo[0] = info.get(0).cardNo;
                            } else { // 多张卡，赋值卡列表
                                response.cardList = info;
                                response.cardDetails = null;
                            }
                        } else {
                            //3003：查不到会员卡；查不到时,再把此账号当卡号查询
                            if(code == 3003){
                                cardNo[0] = countFinal;
                            }else{
                                socketResponse.code = code;
                                socketResponse.message = msg;
                            }
                        }
                    }
                });
            } else {
                cardNo[0] = account;
            }

            // 失败
            if (!socketResponse.success()) {
                return socketResponse;
            }

            // 多张卡，返回
            if (!ListUtil.isEmpty(response.cardList) && response.cardList.size() > 1) {
                return socketResponse;
            }

            if (!TextUtils.isEmpty(cardNo[0])) {// 卡号，拿详情
                ServerMemberApi.loadMemberCardDetailsByCardNo(companyGUID, shopGUID, cardNo[0], new IResponse<NewMemberCardDetailsModel>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                        if (code == SocketResultCode.SUCCESS) {
                            response.cardList = null;
                            response.cardDetails = info;
                        } else {
                            socketResponse.code = code;
                            socketResponse.message = msg;
                        }
                    }
                });
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "会员卡号异常";
            }

            // 失败
            if (!socketResponse.success()) {
                return socketResponse;
            }

            // 是否需要绑定到订单
            boolean needBindToOrder = request.getBooleanValue("needBindToOrder");
            String orderId = request.getString("orderId");
            if (needBindToOrder) {
                OrderCache orderCache = null;
                if (TextUtils.isEmpty(orderId)) {
                    RunTimeLog.addLog(RunTimeLog.MEMBER_PRE_BIND, "NewMemberDriver -> 订单号为空，模式为下单前绑定会员");
                } else {
                    // 下面进行绑到订单的操作
                    if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                        socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                        return socketResponse;
                    }
                    orderCache = OrderSession.getInstance().getOrder(orderId);
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "未找到该订单，请稍后重试";
                        return socketResponse;
                    }

                    if (orderCache.orderStatus == OrderStatus.PAIED) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单已被结账";
                        return socketResponse;
                    }
                }

                response.bindResponse = new NewQueryMemberInfoAndBindToOrderResponse();
                ServerMemberApi.bindMemberToOrder(response.bindResponse, header.hd, response.cardDetails, orderCache, userDBModel);
                NotifyToClient.orderChange(orderId);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 查询会员信息，通过会员卡号
     */
    @DrivenMethod(uri = TAG + "/loadMemberCardDetailsByCardNo")
    public SocketResponse loadMemberCardDetailsByCardNo(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            String companyGUID = request.getString("companyGUID");
            String cardNo = request.getString("cardNo");

            if (TextUtils.isEmpty(cardNo)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "会员卡号为空";
                return socketResponse;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(cardNo);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员好与美味会员号映射【" + cardNo + "," + cardNoRelation + "】");
                cardNo = cardNoRelation;
            }
            String shopGUID = ServerCache.getInstance().shopID;
            ServerMemberApi.loadMemberCardDetailsByCardNo(companyGUID, shopGUID, cardNo, (result, code, msg, info) -> {
                socketResponse.data = info;
                socketResponse.code = code;
                socketResponse.message = msg;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 查询会员卡列表，通过手机号
     */
    @DrivenMethod(uri = TAG + "/loadMemberCardListByMobile")
    public SocketResponse loadMemberCardListByMobile(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();
        NewQueryMemberListResponse response = new NewQueryMemberListResponse();
        socketResponse.data = response;

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            String companyGUID = request.getString("companyGUID");
            String mobile = request.getString("mobile");
            // 有订单号，则在只有一张会员卡时将会员卡和订单绑定，不需要绑定时，请传空
            String orderId = request.getString("orderId");
            // 是否仅获取当前门店下的卡
            boolean onlyCurrentShop = request.getBooleanValue("onlyCurrentShop");
            // 手机验证码
            String verifyCode = request.getString("verifyCode");
            // 手机验证码类型 1 实体卡激活验证码；2 其他；3 手机号收银
            int verifyCodeType = request.getIntValue("verifyCodeType");

            if (TextUtils.isEmpty(mobile)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "该手机号不能识";
                return socketResponse;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(mobile);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员好与美味会员号映射【" + mobile + "," + cardNoRelation + "】");
                mobile = cardNoRelation;
            }

            String shopGUID = onlyCurrentShop ? HostUtil.getShopID() : "";
            ServerMemberApi.loadMemberCardListByMobile(companyGUID, shopGUID, mobile, verifyCode, verifyCodeType, (result, code, msg, info) -> {
                socketResponse.code = code;
                socketResponse.message = msg;
                response.cardList = info;
                response.bindResponse = null;
            });

            if (socketResponse.code != SocketResultCode.SUCCESS) {
                return socketResponse;
            }

            if (ListUtil.isEmpty(response.cardList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "该手机号名下没有适用当前门店的卡";
                return socketResponse;
            }

            if (response.cardList.size() != 1) {// 不绑订单
                return socketResponse;
            }

            NewMemberCardListItemModel cardItem = response.cardList.get(0);
            ServerMemberApi.loadMemberCardDetailsByCardNo(companyGUID, shopGUID, cardItem.cardNo, new IResponse<NewMemberCardDetailsModel>() {
                @Override
                public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                    socketResponse.code = code;
                    socketResponse.message = msg;
                    if (code != SocketResultCode.SUCCESS) {
                        return;
                    }
                    response.cardDetails = info;

                    // orderId为空，不绑订单
                    if (TextUtils.isEmpty(orderId)) {
                        return;
                    }

                    // 下面进行绑到订单的操作
                    OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "未找到该订单，请稍后重试";
                        return;
                    }

                    if (orderCache.orderStatus == OrderStatus.PAIED) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单已被结账";
                        return;
                    }

                    if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                        socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                        return;
                    }

                    response.bindResponse = new NewQueryMemberInfoAndBindToOrderResponse();
                    ServerMemberApi.bindMemberToOrder(response.bindResponse, header.hd, info, orderCache, userDBModel);
                    NotifyToClient.orderChange(orderId);
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/loadMemberCardByCardNoAndBindToOrder")
    public SocketResponse loadMemberCardByCardNoAndBindToOrder(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        final NewQueryMemberInfoAndBindToOrderResponse dataResponse = new NewQueryMemberInfoAndBindToOrderResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            final String companyGUID = request.getString("companyGUID");
            final String orderId = request.getString("orderId");
            final boolean isUsedMemberPrice = request.getBooleanValue("isUsedMemberPrice");
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (TextUtils.isEmpty(orderId)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER_PRE_BIND, "NewMemberDriver -> 订单号为空，模式为下单前绑定会员");
            } else {
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请稍后重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }
            }

            String cardNo = request.getString("cardNo");

            if (TextUtils.isEmpty(cardNo)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "会员卡号为空";
                return response;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(cardNo);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员号与美味会员号映射【" + cardNo + "," + cardNoRelation + "】");
                cardNo = cardNoRelation;
            }
            ServerMemberApi.loadMemberCardDetailsByCardNo(companyGUID, ServerCache.getInstance().shopID, cardNo, new IResponse<NewMemberCardDetailsModel>() {
                @Override
                public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                    if (code == SocketResultCode.SUCCESS && info != null) {
                        ServerMemberApi.bindMemberToOrder(dataResponse, header.hd, info, orderCache, userDBModel);
                        response.code = SocketResultCode.SUCCESS;
                        response.message = "操作成功";
                    } else {
                        response.code = code;
                        response.message = msg;
                    }
                }
            });

            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/bindMemberCardToOrder")
    public SocketResponse bindMemberCardToOrder(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        final NewQueryMemberInfoAndBindToOrderResponse dataResponse = new NewQueryMemberInfoAndBindToOrderResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            NewMemberCardListItemModel memberCard = request.getObject("memberCard", NewMemberCardListItemModel.class);

            if (memberCard == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "会员卡信息异常，请稍后重试";
                return response;
            }

            String orderId = request.getString("orderId");
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (TextUtils.isEmpty(orderId)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER_PRE_BIND, "NewMemberDriver -> 订单号为空，模式为下单前绑定会员");
            } else {
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请稍后重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, header.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }
            }

            ServerMemberApi.loadMemberCardDetailsByCardNo(ServerCache.getInstance().fsCompanyGUID, ServerCache.getInstance().shopID,
                    memberCard.cardNo, new IResponse<NewMemberCardDetailsModel>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, NewMemberCardDetailsModel info) {
                            if (code == SocketResultCode.SUCCESS && info != null) {
                                info.cardSize = memberCard.cardSize;
                                ServerMemberApi.bindMemberToOrder(dataResponse, header.hd, info, orderCache, userDBModel);
                                response.code = SocketResultCode.SUCCESS;
                                response.message = msg;
                            } else {
                                response.code = code;
                                response.message = msg;
                            }
                        }
                    });

            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/sendVerifyCode")
    public SocketResponse sendVerifyCode(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(header.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String companyGUID = request.getString("companyGUID");
            String mobile = request.getString("mobile");
            // 验证码使用场景，1:实体卡激活（只限实体卡激活验证码使用）；2:普通验证码
            int type = request.getIntValue("type");

            if (TextUtils.isEmpty(mobile)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "手机号为空";
                return response;
            }

            ServerMemberApi.sendVerifyCode(companyGUID, mobile, type, new IResponse<Boolean>() {
                @Override
                public void callBack(boolean result, int code, String msg, Boolean info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 会员修改密码
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/changeMemberPsw")
    public SocketResponse changeMemberPsw(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String cardNo = request.getString("cardNo");
            String password = request.getString("password");

            ServerMemberApi.changeMemberPsw(mShopID, cardNo, password, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 会员开卡----绑定实体卡号
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/bindEntity")
    public SocketResponse memberBindEntityCard(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final BaseSocketResponse dataResponse = new BaseSocketResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String cardNumber = request.getString("cardNumber");
            String phone = request.getString("phone");
            String verificationCode = request.getString("verificationCode");

            if (TextUtils.isEmpty(cardNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入卡号";
                return response;
            }

            if (TextUtils.isEmpty(phone)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入手机号";
                return response;
            }

            if (TextUtils.isEmpty(verificationCode)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入验证码";
                return response;
            }

            MemberApi.newMemberBindEntityCard(cardNumber, phone, verificationCode, new IResponse() {
                @Override
                public void callBack(boolean result, int code, String msg, Object info) {
                    if (result) {
                        response.code = SocketResultCode.SUCCESS;
                        response.message = TextUtils.isEmpty(msg) ? "绑定成功" : msg;
                    } else {
                        response.code = code;
                        response.message = msg;
                    }
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 打印会员特权
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/printPrivilege")
    public SocketResponse printPrivilege(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse socketResponse = new SocketResponse();
        final PrinterMemberResponse response = new PrinterMemberResponse();
        socketResponse.data = response;
        try {

            JSONObject request = JSON.parseObject(param);
            MemberPrivateDetailModel.CardPrivilege memberPrivilege = JSON.parseObject(request.getString("memberPrivilege"), MemberPrivateDetailModel.CardPrivilege.class);
            List<Integer> list = MemberPrint.printPrivilege(request.getString("cardNo"), memberPrivilege);
            if (!ListUtil.isEmpty(list)) {
                response.printNoList.addAll(list);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 打印会员充值
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/printerChargeInfo")
    public SocketResponse printerChargeInfo(SocketHeader head, String params) {

        SocketResponse socketResponse = new SocketResponse();
        final PrinterMemberResponse response = new PrinterMemberResponse();
        socketResponse.data = response;
        try {

            JSONObject request = JSON.parseObject(params);
            MemberRechargeResultModel orderModel = JSON.parseObject(request.getString("chargeInfo"), MemberRechargeResultModel.class);
            String payType = request.getString("payType");
            String memberName = request.getString("memberName");
            List<Integer> list = MemberPrint.printCharge(orderModel, payType, memberName, head.hd);
            if (!ListUtil.isEmpty(list)) {
                response.printNoList.addAll(list);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 会员特权
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryRechargePackage")
    public SocketResponse queryRechargePackage(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String mShopID = request.getString("mShopID");
            String cardNo = request.getString("cardNo");
            String csId = request.getString("csId");
            int memberLevel = request.getInteger("memberLevel");

            ServerMemberApi.queryRechargePackage(mShopID, cardNo, csId, memberLevel, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 会员充值
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/memberRecharge")
    public SocketResponse memberRecharge(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String companyGuid = request.getString("companyGuid");
            String cardNo = request.getString("cardNo");
            String payMicro = request.getString("payMicro");
            String ruleId = request.getString("ruleId");
            BigDecimal buyAmount = request.getBigDecimal("buyAmount");
            int payType = request.getInteger("payType");

            if (payType != 0) {
                // 2018/4/25 不读取客户端入参的类型，业务中心判断
                String error = NetPayUtil.checkSuooprt(null, payMicro);
                if (!TextUtils.isEmpty(error)) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = error;
                    return response;
                }
                payType = NetPayUtil.judgePayType(payMicro);
            }

            ServerMemberApi.memberRecharge(companyGuid, cardNo, payMicro, ruleId, buyAmount, payType, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 查询会员充值结果
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryPayResult")
    public SocketResponse queryPayResult(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String companyGuid = request.getString("companyGuid");
            String tradeNo = request.getString("tradeNo");

            ServerMemberApi.queryPayResult(tradeNo, companyGuid, (result, code, msg, info) -> {
                response.code = code;
                response.message = msg;
                response.data = info;
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 检查卡类型
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/checkCardType")
    public SocketResponse checkCardType(SocketHeader head, String param){
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final CheckCardTypeResponse dataResponse = new CheckCardTypeResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);

            String cardNumber = request.getString("cardNumber");

            if (TextUtils.isEmpty(cardNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入卡号";
                return response;
            }

            MemberApi.checkCardType(cardNumber, new IResponse() {
                @Override
                public void callBack(boolean result, int code, String msg, Object info) {
                    if (result) {
                        response.code = SocketResultCode.SUCCESS;
                        response.message = TextUtils.isEmpty(msg) ? "查询成功" : msg;
                        dataResponse.type = msg;
                        dataResponse.msg = msg;
                    } else {
                        response.code = code;
                        response.message = msg;
                    }
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 激活不记名卡
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/activeNoNameCard")
    public SocketResponse activityNoNameCard(SocketHeader head, String param){
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final BaseSocketResponse dataResponse = new BaseSocketResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);

            String cardNumber = request.getString("cardNumber");

            if (TextUtils.isEmpty(cardNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入卡号";
                return response;
            }

            MemberApi.activeNoNameCard(cardNumber, new IResponse() {
                @Override
                public void callBack(boolean result, int code, String msg, Object info) {
                    if (result) {
                        response.code = SocketResultCode.SUCCESS;
                        response.message = TextUtils.isEmpty(msg) ? "激活成功" : msg;
                    } else {
                        response.code = code;
                        response.message = msg;
                    }
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 会员充值payCode查询
     *
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryPayCode")
    public SocketResponse queryPayCode(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String companyGuid = request.getString("companyGuid");
            String cardNo = request.getString("cardNo");
            ServerMemberApi.getPayCode(companyGuid, cardNo, new IResponse<NewPayCodeModel>() {
                @Override
                public void callBack(boolean result, int code, String msg, NewPayCodeModel info) {
                    if (result && info != null && !TextUtils.isEmpty(info.payCode)) {
                        response.code = code;
                        response.message = msg;
                        response.data = info;
                    } else {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = msg;
                    }
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }


}
