package com.mwee.android.pos.businesscenter.air;

import com.mwee.android.air.util.TicketTempletConstants;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrintTempletPrivateDBUtils;
import com.mwee.android.pos.db.APPConfig;

/**
 * Created by qinwei on 2018/8/29.
 */

public class TicketTempletUtils {
    public static String findDefultTempletId(String fsTempletKey) {
        switch (fsTempletKey) {
            case TicketTempletConstants.URI_DINNER_PRE_BILL:
                return TicketTempletConstants.ID_TAKE_DINNER_PRE_BILL_DETAIL;
            case TicketTempletConstants.URI_DINNER_BILL:
                return TicketTempletConstants.ID_DINNER_BILL_DETAIL;
            case TicketTempletConstants.URI_FAST_BILL:
                return TicketTempletConstants.ID_FAST_BILL_DETAIL;
            case TicketTempletConstants.URI_TAKE_CUSTOM_BILL:
                return TicketTempletConstants.ID_TAKE_CUSTOM_DETAIL;
            case TicketTempletConstants.URI_TAKE_SHOP_BILL:
                return TicketTempletConstants.ID_TAKE_SHOP_DETAIL;
            case TicketTempletConstants.URI_KB_CUSTOM_BILL:
                return TicketTempletConstants.ID_KB_CUSTOM_DETAIL;
            case TicketTempletConstants.URI_KB_SHOP_BILL:
                return TicketTempletConstants.ID_KB_SHOP_DETAIL;
            case TicketTempletConstants.URI_KB_ORDER_MAKE:
                return TicketTempletConstants.ID_KB_ORDER_MAKE__DETAIL;
            case TicketTempletConstants.URI_MEIXIAODIAN_BILL:
                return TicketTempletConstants.ID_MEIXIAODIAN_BILL_NORMAL;
            default:
                return "";
        }
    }

    /**
     * @param uri
     * @return 正餐结账单打印uri
     */
    public static String getDinnerBillUri(String uri) {
        return APPConfig.isAir() ? optUri(uri, TicketTempletConstants.URI_DINNER_BILL) : uri;
    }

    /**
     * 预结单打印uri
     *
     * @param uri
     * @return
     */
    public static String getDinnerPreBillUri(String uri) {
        return APPConfig.isAir() ? optUri(uri, TicketTempletConstants.URI_DINNER_PRE_BILL) : uri;
    }


    /**
     * @param uri          default uri
     * @param billSourceId air美小店结账单：910
     * @return 快餐结账单打印uri
     */
    public static String getFastBillUri(String uri, String billSourceId) {
        if (APPConfig.isAir()) {
            if ("910".equals(billSourceId)) {
                String tempNewUri = optUri(uri, TicketTempletConstants.URI_MEIXIAODIAN_BILL);
                if (!tempNewUri.equals(uri)) {
                    return tempNewUri;
                }
            }
            return optUri(uri, TicketTempletConstants.URI_FAST_BILL);
        }
        return uri;
    }

    /**
     * @param uri
     * @return 外卖客户联打印uri
     */
    public static String getTakeCustomUri(String uri) {
        return APPConfig.isAir() ? optUri(uri, TicketTempletConstants.URI_TAKE_CUSTOM_BILL) : uri;
    }

    /**
     * 外卖商户联
     *
     * @param uri
     * @return
     */
    public static String getTakeShopUri(String uri) {
        return APPConfig.isAir() ? optUri(uri, TicketTempletConstants.URI_TAKE_SHOP_BILL) : uri;
    }

    /**
     * 口碑制作单uri
     *
     * @return
     */
    public static String getKBOrderMakeUri() {
        return TicketTempletConstants.URI_KB_ORDER_MAKE;
    }

    /**
     * 口碑客户联小票打印uri
     *
     * @return
     */
    public static String getKBOrderCustomUri() {
        return TicketTempletConstants.URI_KB_CUSTOM_BILL;
    }

    /**
     * 口碑商家联小票uri
     *
     * @return
     */
    public static String getKBOrderShopUri() {
        return TicketTempletConstants.URI_KB_SHOP_BILL;
    }

    private static String optUri(String oldUri, String newUri) {
        if (PrintTempletPrivateDBUtils.queryUsedTempletByTempletKey(newUri) != null) {
            return newUri;
        }
        return oldUri;
    }
}
