package com.mwee.android.pos.businesscenter.module.user;

import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;

/**
 * Created by qinwei on 2019/3/11 8:41 PM
 * email: qin.wei@mwee.cn
 */
public interface IUserService {
    /**
     * 获取登录页面数据
     *
     * @return
     */
    GetLoginDataResponse loadLoginData();

    /**
     * 登录
     *
     * @param username 用户名 或者手机号
     * @param pwd      密码
     * @return 登录信息
     */
//    LoginResponse doLogin(String username, String pwd);
}
