package com.mwee.android.pos.businesscenter.driver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.connect.business.monitor.notice.GetLastNoticeResponse;
import com.mwee.android.pos.connect.business.monitor.notice.GetNoticeFromBizCenterResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.notice.NoticeDBUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by liuxiuxiu on 2017/6/22.
 * 公告相关业务
 */

@SuppressWarnings("unused")
public class NoticeDriver implements IDriver {
    private static final String TAG = "notice";

    /**
     * 获取公告列表
     *
     * @return
     */
    @Override
    public String getModuleName() {
        return TAG;
    }

    @DrivenMethod(uri = TAG + "/allNotice")
    public SocketResponse allNotice(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();

        GetNoticeFromBizCenterResponse response = new GetNoticeFromBizCenterResponse();
        socketResponse.data = response;
        try {
            JSONObject request = JSON.parseObject(param);
            String fsUpdateTime = request.getString("fsUpdateTime");

            response.noticeDBModelList = NoticeDBUtil.getInstance().getAllNotice(fsUpdateTime);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "获取公告成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;

    }

    /**
     * 获取上一条公告
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/lastNotice")
    public SocketResponse lastNotice(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();

        GetLastNoticeResponse response = new GetLastNoticeResponse();
        socketResponse.data = response;
        try {
            JSONObject request = JSON.parseObject(param);
            int id = request.getInteger("id");
            int unAlert = request.getInteger("unAlert");
            String fsUpdateTime = request.getString("fsUpdateTime");
            if (id >= 0) {
                NoticeDBUtil.getInstance().changeNoticeStatus(id, 1, unAlert);
            }
            response.noticeDBModel = NoticeDBUtil.getInstance().getLastNoticeAlert(fsUpdateTime);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "获取公告成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;

    }

    /**
     * 将公告置为不再提醒
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/unalert")
    public SocketResponse unalert(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int id = request.getInteger("id");
            int unAlert = request.getInteger("unAlert");
            if (id >= 0) {
                NoticeDBUtil.getInstance().changeNoticeStatus(id, 1, unAlert);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "更新公告成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;

    }
}

