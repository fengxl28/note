package com.mwee.android.pos.businesscenter.business.active;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.Result;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.WriteJsonDataToDB;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.driver.UdpPushDriver;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.BindResponse;
import com.mwee.android.pos.component.datasync.net.DownloadNetOrderMappingRelationRequest;
import com.mwee.android.pos.component.datasync.net.DownloadNetOrderMappingRelationResponse;
import com.mwee.android.pos.component.datasync.net.GetDataRequest;
import com.mwee.android.pos.component.datasync.net.GetDataResponse;
import com.mwee.android.pos.component.datasync.net.model.BindRequestV2;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.DownLoadDataProcessor;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.callback.ICallback;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.sync.EncryptUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2018/1/18.
 *
 * @author virgil
 */

public class ActiveUtil {
    public static String tag = "ActiveUtil";

    public static void updateTokenSeed(String shopID, String serverToken, String seed) {
        String token = EncryptUtil.MD5Purity(serverToken + ServerHardwareUtil.getHardWareSymbol());
        DBMetaUtil.updateSettingsValueByKey(META.TOKEN, token);
        DBMetaUtil.updateSettingsValueByKey(META.SEED, seed);
        DBMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);

        ClientMetaUtil.updateSettingsValueByKey(META.TOKEN, token);
        ClientMetaUtil.updateSettingsValueByKey(META.SEED, seed);
        ClientMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
    }

    public static void onlyActive(String shopID, IExecutorCallback callback) {
        BindRequestV2 bindRequest = new BindRequestV2();
        bindRequest.deviceId = ServerHardwareUtil.getHardWareSymbol();
        bindRequest.shopType = APPConfig.getShopType();
        ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 0);

        BusinessExecutor.execute(bindRequest, callback, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData == null || responseData.responseBean == null) {
                    return false;
                }
                BindResponse bindResponse = (BindResponse) responseData.responseBean;
                if (bindResponse.errno != 0) {
                    responseData.result = Result.BUSINESS_FAIL;
                    if (!TextUtils.isEmpty(bindResponse.errmsg)) {
                        responseData.resultMessage = bindResponse.errmsg;
                    }
                    ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 0);
                    return false;
                }
                updateTokenSeed(shopID, bindResponse.data.fstoken, bindResponse.data.fsseed);
                DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);
                DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");

                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);
                ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");

                try {
                    BindProcessor.setCurrentHostAsMain(true);
                    UdpPushDriver.doBroadCast();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, tag + "激活成功！\ntoken = " + bindResponse.data.fstoken + ";\nseed = " + bindResponse.data.fsseed);
                LogUtil.logNET(tag, "激活成功！\ntoken = " + bindResponse.data.fstoken + ";\nseed = " + bindResponse.data.fsseed);
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 0);
                ClientMetaUtil.updateSettingsValueByKey(META.SHOPID, "");
                RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, "激活失败 msg = " + responseData.resultMessage);
                LogUtil.logNET(tag, "激活失败 msg = " + responseData.resultMessage);
                return false;
            }
        }, false);
    }

    public static void onlyDownload(IExecutorCallback callback) {
        DownLoadDataProcessor.downloadData(callback, null, "", new ICallback<List<String>>() {
            @Override
            public void onSuccess(List<String> var1) {
                if (ListUtil.isEmpty(var1)) {
                    return;
                }
                if (var1.contains(DBModel.getTableName(MtableDBModel.class)) || var1.contains(DBModel.getTableName(MareaDBModel.class))) {
                    NotifyToClient.refreshTableQueue();
                }
            }

            @Override
            public void onFailure(int code, String msg) {

            }

            @Override
            public void onExecuteSubThread(List<String> strings) {

            }
        });
    }

    public static void bindAndDownload(final String shopID, IExecutorCallback callback) {
        List<BaseRequest> list = new ArrayList<>();
        String token = ClientMetaUtil.getSettingsValueByKey(META.TOKEN);
        if (TextUtils.isEmpty(token)) {
            BindRequestV2 bindRequest = new BindRequestV2();
            bindRequest.deviceId = ServerHardwareUtil.getHardWareSymbol();
            bindRequest.shopType = APPConfig.getShopType();
            list.add(bindRequest);
            ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 0);
        }

        GetDataRequest getDataRequest = new GetDataRequest();
        getDataRequest.tag = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        if (TextUtils.isEmpty(getDataRequest.tag) || TextUtils.equals("null", getDataRequest.tag)) {
            getDataRequest.tag = "-1";
        }
        list.add(getDataRequest);

        DownloadNetOrderMappingRelationRequest downloadNetOrderMappingRelationRequest = new DownloadNetOrderMappingRelationRequest();
        downloadNetOrderMappingRelationRequest.searchTime = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        if (TextUtils.isEmpty(downloadNetOrderMappingRelationRequest.searchTime)) {
            downloadNetOrderMappingRelationRequest.searchTime = "0";
        }
        list.add(downloadNetOrderMappingRelationRequest);

       /* DownloadTableCountRequest tbCountRequest = new DownloadTableCountRequest();
        tbCountRequest.updatetime = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
        list.add(tbCountRequest);*/

        BusinessExecutor.execute(list, callback, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null) {
                    if (responseData.responseBean instanceof BindResponse) {
                        BindResponse bindResponse = (BindResponse) responseData.responseBean;
                        if (bindResponse.errno != 0) {
                            responseData.result = Result.BUSINESS_FAIL;
                            if (!TextUtils.isEmpty(bindResponse.errmsg)) {
                                responseData.resultMessage = bindResponse.errmsg;
                            }
                            ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                            return false;
                        }
                        updateTokenSeed(shopID, bindResponse.data.fstoken, bindResponse.data.fsseed);
                        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);
                        DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");

                        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_ADDRESS, "127.0.0.1");
                        ClientMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_IS_MAINHOST, 1);

                        try {
                            BindProcessor.setCurrentHostAsMain(true);
                            UdpPushDriver.doBroadCast();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, tag + "绑定成功！\ntoken = " + token + ";\nseed = " + bindResponse.data.fsseed);
                        ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                    } else if (responseData.responseBean instanceof GetDataResponse) {
                        RunTimeLog.addLog(RunTimeLog.BOOT_SHOP_DATA, tag + "下载数据成功！");
                        GetDataResponse getDataResponse = (GetDataResponse) responseData.responseBean;
                        WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, getDataResponse.data, getDataResponse.tag);
                        ClientMetaUtil.updateSettingsValueByKey(META.ACTIVE_AND_DOWNLOAD_FINISHED, 1);
                        //public 模版小票到private
                        ReceiptTempletUtil.saveReceiptTemplete();
                    } /*else if (responseData.responseBean instanceof DownloadTableCountResponse) {
                        JSONObject data = ((DownloadTableCountResponse) responseData.responseBean).data;
                    } else if (responseData.responseBean instanceof DownloadTableCountResponse) {
                        DownloadTableCountResponse responseBean = (DownloadTableCountResponse) responseData.responseBean;
                        JSONObject data = responseBean.data;
                        StringBuilder tbNames = new StringBuilder();
                        if (data != null && data.size() > 0) {
                            for (String key : data.keySet()) {
                                int value = Integer.parseInt(data.getString(key));
                                if (TextUtils.isEmpty(key) || value == 0) continue;
                                tbNames.append(key).append(",");
                            }
                        }
                        DownLoadDataProcessor.updateSyncTime(responseBean.tag);
                        if (tbNames.length() > 0) {
                            String tbName = tbNames.substring(0, tbNames.length() - 1);
                            DownLoadDataProcessor.downloadTables(tbName, tbCountRequest.updatetime, new IExecutorCallback() {
                                @Override
                                public void success(ResponseData responseData) {
                                    //public 模版小票到private 美小易需要这部操作
                                    ReceiptTempletUtil.saveReceiptTemplete();
                                }

                                @Override
                                public boolean fail(ResponseData responseData) {
                                    return false;
                                }
                            }, false);
                        }
                        DownLoadDataProcessor.updateSyncTime(responseBean.tag);
                    }*/ else if (responseData.responseBean instanceof DownloadNetOrderMappingRelationResponse) {
                        try {
                            DownloadNetOrderMappingRelationResponse responseBean = (DownloadNetOrderMappingRelationResponse) responseData.responseBean;
                            JSONObject ob = new JSONObject();
                            ob.put("tbNetorderItemMappingRelationship", responseBean.data.get("tbNetorderItemMappingRelationship"));
                            WriteJsonDataToDB.writeDataToDB(APPConfig.DB_MAIN, ob, null);
                        } catch (Exception e) {
                            RunTimeLog.addLog(RunTimeLog.DOWNLOAD_EXCEPTION, "tbNetorderItemMappingRelationship表下载数据异常: " + responseData.resultMessage + "\n" + e.getMessage());
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.DOWNLOAD_EXCEPTION, "下载数据接口异常 msg = " + responseData.resultMessage);
                return false;
            }
            //此处，需要明确传false进行阻塞
        }, false);
    }
}
