package com.mwee.android.pos.businesscenter.koubei.sync;

import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.business.common.OrderData;
import com.mwee.android.pos.db.business.common.OrderDataDBUtils;
import com.mwee.android.pos.db.business.order.OrderCache;

import java.util.concurrent.ExecutorService;

/**
 * 口碑订单同步任务
 * Created by qinwei on 2018/10/22.
 */

public class OrderSyncTask implements OrderSyncThread.OnOrderSyncThreadListener {
    private String orderId;
    private ExecutorService mExecutors;
    private OnOrderSyncTaskListener listener;
    private OrderSyncThread orderSyncThread;

    public OrderSyncTask(String orderId, ExecutorService mExecutors) {
        this.orderId = orderId;
        this.mExecutors = mExecutors;
    }

    public void start() {
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
        OrderData orderData = OrderDataDBUtils.queryOrderData(orderId);
        if (checkCanExecuteTask(orderCache, orderData)) {
            orderSyncThread = new OrderSyncThread(orderCache, orderData);
            orderSyncThread.setOnOrderSyncThreadListener(this);
            mExecutors.execute(orderSyncThread);
            trace(orderId + ":启动线程执行订单数据同步");
        } else {
            listener.onError(orderId, orderId + ":未找到订单相关信息，同步失败");
            trace(orderId + ":未找到订单相关信息，同步失败");
        }
    }

    private boolean checkCanExecuteTask(OrderCache orderCache, OrderData orderData) {
        return orderCache != null && orderData != null;
    }

    public void stop() {
    }


    @Override
    public void onCompleted() {
        listener.onCompleted(orderId);
    }

    @Override
    public void onError(String errorMsg) {
        listener.onError(orderId, errorMsg);

    }

    public void setOnOrderSyncTaskListener(OnOrderSyncTaskListener listener) {
        this.listener = listener;
    }

    public interface OnOrderSyncTaskListener {
        void onCompleted(String id);

        void onError(String id, String msg);
    }

    private void trace(String msg) {
        RunTimeLog.addLog(RunTimeLog.KB_ORDER_SYNC, "OrderSyncTask:" + msg);
    }
}
