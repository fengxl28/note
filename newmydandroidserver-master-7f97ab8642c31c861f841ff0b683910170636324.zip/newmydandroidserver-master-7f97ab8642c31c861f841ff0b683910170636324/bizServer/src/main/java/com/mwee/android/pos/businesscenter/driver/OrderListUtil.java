package com.mwee.android.pos.businesscenter.driver;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.Pair;
import android.text.TextUtils;

import com.mwee.android.pos.connect.business.bean.model.OrderListMenuModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListPayModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.order.FastFoodOrderBizDBModel;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.DBToolsUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 订单列表的Sql拼接
 * Created by virgil on 2016/10/11.
 */
public class OrderListUtil {

    /**
     * 获取订单数据
     *
     * @param currentPage      页码
     * @param withUnpayedOrder
     * @param businessDate     营业日期
     * @param fiSellType       订单类型
     * @param shopID           门店id
     * @param withoutOrderID
     * @param withOrderID
     * @param billType         账单类型
     * @param billStatus       账单状态
     * @param tableName        桌台名称
     * @param fsBillSourceId   订单来源
     * @return
     */
    protected static Pair<Integer, List<OrderListModel>> getOrderList(int currentPage, final boolean withUnpayedOrder, final String businessDate, final String fiSellType, final String shopID,
                                                       final String withoutOrderID, final String withOrderID, final int billType, String accountBookId, String billStatus, String tableName, String fsBillSourceId) {
        return getOrderList(currentPage, "", withUnpayedOrder, businessDate, fiSellType,
                shopID, withoutOrderID, withOrderID, billType, accountBookId, billStatus, tableName, fsBillSourceId);
    }

    /**
     * 获取订单数据
     *
     * @param currentPage      页码
     * @param numberNo         输入的订单号
     * @param withUnpayedOrder
     * @param businessDate     营业日期
     * @param fiSellType       订单类型
     * @param shopID           门店id
     * @param withoutOrderID
     * @param withOrderID
     * @param billType         账单类型
     * @param billStatus       账单状态
     * @param tableName        桌台名称
     * @param fsBillSourceId   订单来源
     * @return
     */
    protected static Pair<Integer, List<OrderListModel>> getOrderList(int currentPage, String numberNo, boolean withUnpayedOrder,
                                                                      String businessDate, String fiSellType, String shopID,
                                                                      String withoutOrderID, String withOrderID, int billType, String accountBookId,
                                                                      String billStatus, String tableName, String fsBillSourceId) {
        Pair<Integer, List<OrderListModel>> orderListFromDb = getOrderListFromDb(currentPage, numberNo, APPConfig.DB_MAIN, withUnpayedOrder, businessDate, fiSellType, shopID, withoutOrderID, withOrderID, billType, accountBookId, billStatus, tableName, fsBillSourceId);
        Integer pageCount = orderListFromDb.first;
        List<OrderListModel> mainDbData = orderListFromDb.second;
        // TODO: 2018/5/18 修改从库名称获取
        String otherDbName = APPConfig.DB_MAIN;
        List<OrderListModel> otherDbData = null;
        if (!TextUtils.equals(APPConfig.DB_MAIN, otherDbName)) {
            Pair<Integer, List<OrderListModel>> otherData = getOrderListFromDb(currentPage, "", otherDbName, withUnpayedOrder, businessDate, fiSellType, shopID, withoutOrderID, withOrderID, billType, accountBookId, billStatus, tableName, fsBillSourceId);
            pageCount += otherData.first;
            otherDbData = otherData.second;
        }
        return new Pair<>(pageCount, mergeOrderList(mainDbData, otherDbData));
    }

    private static List<OrderListModel> mergeOrderList(List<OrderListModel> originalData, List<OrderListModel> tempData) {
        if (ListUtil.isEmpty(originalData)) {
            if (ListUtil.isEmpty(tempData)) {
                return new ArrayList<>(1);
            }
            return tempData;
        }
        if (ListUtil.isEmpty(tempData)) {
            return originalData;
        }
        List<OrderListModel> result = new ArrayList<>();
        result.addAll(originalData);
        //倒序遍历，顺序添加
        for (int i = tempData.size() - 1; i >= 0; i--) {
            OrderListModel temp = tempData.get(i);
            if (temp == null) {
                continue;
            }
            boolean isExist = false;
            for (OrderListModel original : originalData) {
                if (original == null) {
                    continue;
                }
                if (TextUtils.equals(temp.orderID, original.orderID)) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                result.add(0, temp);//顺序添加
            }
        }
        return result;
    }

    protected static Pair<Integer, List<OrderListModel>> getOrderListFromDb(int currentPage, String numberNo, final String databaseName, final boolean withUnpayedOrder, final String businessDate,
                                                                  final String fiSellType, final String shopID, final String withoutOrderID, final String withOrderID,
                                                                  final int billType, String accountBookId, String billStatus, String tableName, String fsBillSourceId) {
        final String[] queryParams = new String[1];
        queryParams[0] = "";
        List<OrderListModel> orderList = DBManager.getInstance(databaseName).executeQuery(new IDBOperate<List<OrderListModel>>() {

            @Override
            public List<OrderListModel> doJob(SQLiteDatabase db) {
                String sqlMenu = "select " +
                        "tbsell.fsSellNo as orderID" +
                        ",tbsell.fsShopGuid as shopID" +
                        ",tbsell.fsMealNumber as mealNumber" +
                        ",tbsell.fsSellTime as createTimeOrder" +
                        ",tbsell.fsCreateUserId as orderWaiterID" +
                        ",tbsell.fsCreateUserName as orderWaiterName" +
                        ",tbsell.fsSellDate as businessDate" +
                        ",tbsell.fsMtableId as fsMtableId" +
                        ",tbsell.fsMTableName as fsMTableName" +
                        ",tbsell.fdExpAmt as totalPrice" +
                        ",tbsell.fsHostId as orderHostID" +
                        ",tbsell.fiBillStatus as orderStatus" +
                        ",tbsell.fiSellType as fiSellType" +
                        ",tbsell.fsBillSourceId as fsBillSourceId" +
                        ",tbsell.fsBillSourceName as fsBillSourceName" +
                        ",tbsell.thirdOrderType as thirdOrderType" +
                        ",tbsell.mergedOrderID as mergedOrderID" +
                        ",tbsell.fiInvoiceState as fiInvoiceState" +
                        ",tbsell.fsInvoiceNo as fsInvoiceNo" +
                        ",tbSellCheck.fsCheckBillNO as billNO" +
                        ",tbSellCheck.fsCheckTime as payTime" +
                        ",tbSellCheck.fsShiftId as payShiftID" +
                        ",tbSellCheck.fsHostId as payHostID" +
                        ",tbSellCheck.fsUpdateUserId as payWaiterID" +
                        ",tbSellCheck.fsUpdateUserName as payWaiterName" +
                        ",tbSellCheck.fiStatus as fiStatus" +
                        " from tbsell";
                if (withUnpayedOrder) {
                    queryParams[0] += " left outer join tbSellCheck";
                } else {
                    queryParams[0] += " inner join tbSellCheck";
                }
                queryParams[0] += " on" +
                        " tbsell.fsSellNo=tbSellCheck.fsSellNo" +
                        " where" +
                        " tbSell.fiSellType in (" + fiSellType + ") and " +
                        " tbsell.fsSellDate='" + businessDate + "'" +
                        " and" +
                        " tbsell.fsShopGUID='" + shopID + "'" +
                        " and" +
                        " tbsell.fiBillStatus in (" + billStatus + ")";
//                        " tbsell.fiBillStatus not in ('0','6')";
                if (!TextUtils.isEmpty(withoutOrderID)) {
                    queryParams[0] += " and tbsell.fsSellNo<>" + withoutOrderID;
                }
                if (!TextUtils.isEmpty(withOrderID) && !TextUtils.isEmpty(tableName)) {
                    queryParams[0] += " and (tbsell.fsSellNo like '%" + withOrderID + "%' or tbsell.fsMTableName like '%" + tableName + "%')";
                } else {
                    if (!TextUtils.isEmpty(withOrderID)) {
                        queryParams[0] += " and tbsell.fsSellNo='" + withOrderID + "'";
                    }
                    if (!TextUtils.isEmpty(tableName)) {
                        queryParams[0] += " and tbsell.fsMTableName like '%" + tableName + "%'";
                    }
                }
                // AB账
                if (APPConfig.isMyd()) {
                    queryParams[0] += " and tbSell.fsAccountBook like '%," + accountBookId + ",%' ";
                } else {
                    queryParams[0] += (billType == 0 ? "" : " and tbsell.fiSelected = '0'");
                }
                if (!TextUtils.isEmpty(numberNo)) {
                    //根据单号模糊查询
                    queryParams[0] += " and tbsell.fsSellNo like '%" + numberNo + "%' or tbsell.fsMTableName like '%" + numberNo + "%'";
                }

                if (!TextUtils.isEmpty(fsBillSourceId) && !TextUtils.equals("-1", fsBillSourceId)) {
                    queryParams[0] += " AND tbSell.fsBillSourceId = '" + fsBillSourceId + "'";
                }

                queryParams[0] += " order by tbsell.fsSellNo desc";
                sqlMenu += queryParams[0];
                if (TextUtils.isEmpty(numberNo)) {//分页查询
                    int offset = (currentPage - 1) * 20;//偏移量
                    sqlMenu = sqlMenu + " limit 20 offset " + offset;
                }

                Cursor cursor = null;
                List<OrderListModel> orderMap = null;
                try {
                    cursor = db.rawQuery(sqlMenu, null);
                    orderMap = new ArrayList<OrderListModel>();
                    if (cursor != null) {
                        int indexOrderID = cursor.getColumnIndex("orderID");
                        int indexShopID = cursor.getColumnIndex("shopID");
                        int indexMealNumber = cursor.getColumnIndex("mealNumber");
                        int indexCreateTimeOrder = cursor.getColumnIndex("createTimeOrder");
                        int indexOrderWaiterID = cursor.getColumnIndex("orderWaiterID");
                        int indexOrderWaiterName = cursor.getColumnIndex("orderWaiterName");
                        int indexBusinessDate = cursor.getColumnIndex("businessDate");
                        int indexfsMtableId = cursor.getColumnIndex("fsMtableId");
                        int indexfsMTableName = cursor.getColumnIndex("fsMTableName");
                        int indexOrderHostID = cursor.getColumnIndex("orderHostID");
                        int indexOrderStatus = cursor.getColumnIndex("orderStatus");
                        int indexTotalPrice = cursor.getColumnIndex("totalPrice");
                        int indexMergedOrderID = cursor.getColumnIndex("mergedOrderID");


                        int indexBillNO = cursor.getColumnIndex("billNO");
                        int indexPayTime = cursor.getColumnIndex("payTime");
                        int indexPayShiftID = cursor.getColumnIndex("payShiftID");
                        int indexPayHostID = cursor.getColumnIndex("payHostID");
                        int indexPayWaiterID = cursor.getColumnIndex("payWaiterID");
                        int indexPayWaiterName = cursor.getColumnIndex("payWaiterName");
                        int indexfiStatus = cursor.getColumnIndex("fiStatus");
                        int indexfiSellType = cursor.getColumnIndex("fiSellType");
                        int fsBillSourceId = cursor.getColumnIndex("fsBillSourceId");
                        int fsBillSourceName = cursor.getColumnIndex("fsBillSourceName");
                        int thirdOrderType = cursor.getColumnIndex("thirdOrderType");

                        int fiInvoiceState = cursor.getColumnIndex("fiInvoiceState");
                        int fsInvoiceNo = cursor.getColumnIndex("fsInvoiceNo");

                        while (cursor.moveToNext()) {
                            OrderListModel model = new OrderListModel();
                            model.orderID = DBToolsUtil.buildValueByCursor(cursor, indexOrderID, String.class);
                            model.orderIDMin = StringUtil.toInt(model.orderID.substring(8), 0) + "";
                            model.fsShopID = DBToolsUtil.buildValueByCursor(cursor, indexShopID, String.class);
                            model.mealNumber = DBToolsUtil.buildValueByCursor(cursor, indexMealNumber, String.class);
                            model.createTimeOrder = DBToolsUtil.buildValueByCursor(cursor, indexCreateTimeOrder, String.class);
                            model.orderWaiterID = DBToolsUtil.buildValueByCursor(cursor, indexOrderWaiterID, String.class);
                            model.orderWaiterName = DBToolsUtil.buildValueByCursor(cursor, indexOrderWaiterName, String.class);
                            model.businessDate = DBToolsUtil.buildValueByCursor(cursor, indexBusinessDate, String.class);
                            model.totalPrice = DBToolsUtil.buildValueByCursor(cursor, indexTotalPrice, BigDecimal.class);
                            model.mergedOrderID = DBToolsUtil.buildValueByCursor(cursor, indexMergedOrderID, String.class);
                            model.fsmtableid = DBToolsUtil.buildValueByCursor(cursor, indexfsMtableId, String.class);
                            model.fsmtablename = DBToolsUtil.buildValueByCursor(cursor, indexfsMTableName, String.class);
                            model.orderHostID = DBToolsUtil.buildValueByCursor(cursor, indexOrderHostID, String.class);
                            model.orderStatus = DBToolsUtil.buildValueByCursor(cursor, indexOrderStatus, int.class);
                            model.billNO = DBToolsUtil.buildValueByCursor(cursor, indexBillNO, String.class);
                            model.payTime = DBToolsUtil.buildValueByCursor(cursor, indexPayTime, String.class);
                            model.payShiftID = DBToolsUtil.buildValueByCursor(cursor, indexPayShiftID, String.class);
                            model.payHostID = DBToolsUtil.buildValueByCursor(cursor, indexPayHostID, String.class);
                            model.payWaiterID = DBToolsUtil.buildValueByCursor(cursor, indexPayWaiterID, String.class);
                            model.payWaiterName = DBToolsUtil.buildValueByCursor(cursor, indexPayWaiterName, String.class);
                            int fiStatus = DBToolsUtil.buildValueByCursor(cursor, indexfiStatus, int.class);
                            model.locked = fiStatus == 2 ? 1 : 0;
                            model.payed = model.orderStatus == OrderStatus.PAIED ? 1 : 0;
                            model.fiSellType = DBToolsUtil.buildValueByCursor(cursor, indexfiSellType, int.class);
                            model.fsBillSourceId = DBToolsUtil.buildValueByCursor(cursor, fsBillSourceId, String.class);
                            model.fsBillSourceName = DBToolsUtil.buildValueByCursor(cursor, fsBillSourceName, String.class);
                            model.thirdOrderType = DBToolsUtil.buildValueByCursor(cursor, thirdOrderType, int.class);

                            model.fiInvoiceState = DBToolsUtil.buildValueByCursor(cursor, fiInvoiceState, int.class);
                            model.fsInvoiceNo = DBToolsUtil.buildValueByCursor(cursor, fsInvoiceNo, String.class);
                            //                        orderMap.put(model.orderID, model);
                            dealErrorOrder(model);
                            //0:订单来自从库，1：来自主库
                            if (TextUtils.equals(databaseName, APPConfig.DB_MAIN)) {
                                model.orderSource = 1;
                            } else {
                                model.orderSource = 0;
                            }
                            orderMap.add(model);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return orderMap;
            }

            private void dealErrorOrder(OrderListModel model) {
                if (model.payed == 1) {
                    //订单状态是已结账但是支付是未结账状态
                    String status = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select payed from order_pay_cache where order_id = '" + model.orderID + "'");
                    if (!TextUtils.equals(status, "1")) {
                        model.errorOrderStatus = 5;

                        //正餐要校验桌台上的订单是否是当前异常订单
                        if (model.fiSellType == 0) {
                            String fssellno = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tableBiz where fsmtableid = '" + model.fsmtableid + "'");
                            if (!TextUtils.equals(model.orderID, fssellno) && !TextUtils.isEmpty(fssellno)) {
                                model.errorOrderStatus = 2;
                            }
                        }
                    }
                    return;//订单已结账，不作处理
                }
                if (model.fiSellType == 0) {//正餐
                    TableBizModel tableBiz = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tableBiz where fsmtableid = '" + model.fsmtableid + "'", TableBizModel.class);
                    if (tableBiz == null) {
                        model.errorOrderStatus = 1;
                        return;
                    }
                    //fsmtablesteid餐桌狀態代號;1空闲 / 2开台 / 3占用 / 8预订 / 9停用
                    if (TextUtils.equals(tableBiz.fsmtablesteid, "2")) {
                        if (!TextUtils.equals(model.orderID, tableBiz.fssellno)) {
                            model.errorOrderStatus = 2;
                        }
                    } else {
                        model.errorOrderStatus = 1;
                    }
                } else if (model.fiSellType == 1) {//快餐订单
                    FastFoodOrderBizDBModel fastFoodBiz = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from fastfood_order_biz where order_id = '" + model.orderID + "'", FastFoodOrderBizDBModel.class);
                    if (fastFoodBiz == null || fastFoodBiz.fastfood_biz_status != 1) {//fastfood_biz_status 0:临时订单 1：未结账  2：已结账
                        model.errorOrderStatus = 4;
                    }
                }
            }
        });

        String countStr = DBSimpleUtil.queryString(databaseName, "select count(*) from tbsell " + queryParams[0]);
        int dataCount = StringUtil.toInt(countStr, 0);
        return new Pair<>(dataCount, orderList);
    }

    protected static ArrayMap<String, List<OrderListMenuModel>> getOrderMenuList(final String businessDate, final String shopID, final String withOrderID) {
        return DBManager.getInstance().executeQuery(new IDBOperate<ArrayMap<String, List<OrderListMenuModel>>>() {
            @Override
            public ArrayMap<String, List<OrderListMenuModel>> doJob(SQLiteDatabase db) {
                String sqlMenu = "select " +
                        "fsSeq as uniq" +
                        ",fsSellNo as orderID" +
                        ",fiItemCd as itemID" +
                        ",fsItemName as name" +
                        ",fdBargainPrice as singlePrice" +
                        ",fdSubTotal2 as totalPrice" +
                        ",fdSaleQty as buyNum" +
                        ",fdBackQty" +
                        " from tbSellorderitem " +
                        "where " +
                        "tbSellorderitem.fsSellDate='" + businessDate + "' " +
                        "and tbSellorderitem.fsShopGUID='" + shopID + "' " +
                        "and tbSellorderitem.fiOrderItemKind<>'3' ";
                if (!TextUtils.isEmpty(withOrderID)) {
                    sqlMenu += " and fsSellNo='" + withOrderID + "'";
                }
                sqlMenu += " order by fsSellNo desc,fsCreateTime asc";
                Cursor cursor = null;
                ArrayMap<String, List<OrderListMenuModel>> menu = null;
                try {
                    cursor = db.rawQuery(sqlMenu, null);
                    menu = new ArrayMap<String, List<OrderListMenuModel>>();
                    if (cursor != null) {
                        int indexOrderID = cursor.getColumnIndex("orderID");
                        int indexUniq = cursor.getColumnIndex("uniq");
                        int indexItemID = cursor.getColumnIndex("itemID");
                        int indexItemName = cursor.getColumnIndex("name");
                        int indexSinglePrice = cursor.getColumnIndex("singlePrice");
                        int indexTotalPrice = cursor.getColumnIndex("totalPrice");
                        int indexNum = cursor.getColumnIndex("buyNum");
                        int indexfdBackQty = cursor.getColumnIndex("fdBackQty");

                        while (cursor.moveToNext()) {
                            String orderID = DBToolsUtil.buildValueByCursor(cursor, indexOrderID, String.class);
                            OrderListMenuModel model = new OrderListMenuModel();
                            model.buyNum = DBToolsUtil.buildValueByCursor(cursor, indexNum, String.class);
                            model.uniq = DBToolsUtil.buildValueByCursor(cursor, indexUniq, String.class);
                            model.itemID = DBToolsUtil.buildValueByCursor(cursor, indexItemID, String.class);
                            model.name = DBToolsUtil.buildValueByCursor(cursor, indexItemName, String.class);
                            model.price = DBToolsUtil.buildValueByCursor(cursor, indexSinglePrice, BigDecimal.class);
                            model.totalPrice = DBToolsUtil.buildValueByCursor(cursor, indexTotalPrice, BigDecimal.class);
                            BigDecimal backQty = DBToolsUtil.buildValueByCursor(cursor, indexfdBackQty, BigDecimal.class);
                            if (backQty.compareTo(BigDecimal.ZERO) > 0) {
                                model.isVoid = true;
                            }
                            List<OrderListMenuModel> list = menu.get(orderID);
                            if (list == null) {
                                list = new ArrayList<OrderListMenuModel>();
                            }
                            list.add(model);
                            menu.put(orderID, list);
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return menu;
            }
        });
    }


    protected static ArrayMap<String, List<OrderListPayModel>> getOrderPayList(final String businessDate, final String shopID, final String withOrderID) {
        return DBManager.getInstance().executeQuery(new IDBOperate<ArrayMap<String, List<OrderListPayModel>>>() {
            @Override
            public ArrayMap<String, List<OrderListPayModel>> doJob(SQLiteDatabase db) {
                String sqlMenu = "select " +
                        "tbSellReceive.fsSellNo as orderID" +
                        ",tbSellReceive.fspaymentId as payTypeID" +
                        ",tbSellReceive.fspaymentname as payName" +
                        ",tbSellReceive.fdPayMoney as fdPayMoney" +
                        ",tbPayment.fsPaymentTypeId as fsPaymentTypeId" +
                        ",tbSellReceive.fdReceMoney as fdReceMoney " +
                        "from " +
                        "tbSellReceive " +
                        "left join tbPayment on tbPayment.fspaymentId == tbSellReceive.fspaymentId " +
                        "where  " +
                        "tbSellReceive.fiStatus<> '13' " +
                        "and " +
                        "tbSellReceive.fsSellDate='" + businessDate + "' " +
                        "and " +
                        "tbSellReceive.fsShopGUID='" + shopID + "' ";
                if (!TextUtils.isEmpty(withOrderID)) {
                    sqlMenu += " and fsSellNo='" + withOrderID + "'";
                }
                sqlMenu += " order by fsSellNo desc,fsCreateTime asc";
                Cursor cursor = null;
                ArrayMap<String, List<OrderListPayModel>> menu = null;
                try {
                    cursor = db.rawQuery(sqlMenu, null);
                    menu = new ArrayMap<String, List<OrderListPayModel>>();
                    if (cursor != null) {
                        int indexOrderID = cursor.getColumnIndex("orderID");
                        int indexPayTypeID = cursor.getColumnIndex("payTypeID");
                        int indexPayName = cursor.getColumnIndex("payName");
                        int indexfdPayMoney = cursor.getColumnIndex("fdPayMoney");
                        int indexfdreceMoney = cursor.getColumnIndex("fdReceMoney");
                        while (cursor.moveToNext()) {
                            String orderID = DBToolsUtil.buildValueByCursor(cursor, indexOrderID, String.class);
                            OrderListPayModel model = new OrderListPayModel();
                            model.payTypeID = DBToolsUtil.buildValueByCursor(cursor, indexPayTypeID, String.class);
                            model.payName = DBToolsUtil.buildValueByCursor(cursor, indexPayName, String.class);
                            model.payAmount = DBToolsUtil.buildValueByCursor(cursor, indexfdPayMoney, BigDecimal.class);
                            BigDecimal fdreceMoney = DBToolsUtil.buildValueByCursor(cursor, indexfdreceMoney, BigDecimal.class);
                            model.changeAmount = model.payAmount.subtract(fdreceMoney);

                            List<OrderListPayModel> list = menu.get(orderID);
                            if (list == null) {
                                list = new ArrayList<OrderListPayModel>();
                            }
                            list.add(model);
                            menu.put(orderID, list);
                        }
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return menu;
            }
        });
    }
}
