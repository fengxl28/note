package com.mwee.android.pos.businesscenter.business.order.api;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.SparseArray;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SellOutMenuClsViewModel;
import com.mwee.android.pos.connect.business.order.model.SellOutModel;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 估清相关的Util
 * Created by virgil on 2016/11/29.
 */

public class SellOutServerProcessor {
    private final static Object lock = new Object();

//    /**
//     * 重新拉取沽清数量
//     */
//    public static void init(){
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,"INSERT INTO localSellOut (SELECT tbmenuitemuint.fiItemCd,tbmenuitem.fsItemName,tbmenuitemuint.fdInvQty,tbmenuitemuint.fiStatus,tbmenuitemuint.fiOrderUintCd,tbmenuitemuint.fsOrderUint FROM tbmenuitemuint left join tbmenuitem on tbmenuitemuint.fiItemCd=tbmenuitem.fiItemCd where tbmenuitemuint.fiStatus in('2','3'))");
//    }

    /**
     * 是否全部沽清了
     *
     * @return true则全部沽清，剩余0
     */
    public static boolean isAllSellOut(SellOutViewModel sellout) {
        return sellout != null && sellout.fdInvQty.compareTo(BigDecimal.ZERO) == 0;
    }

    /**
     * 是否全部沽清了
     *
     * @return true则全部沽清，剩余0
     */
    public static boolean isAllSellOutFromDB(String fiItemCd, String fiOrderUintCd) {
        SellOutViewModel sellout = getItemSellOutViewModel(fiItemCd, fiOrderUintCd);
        return sellout != null && sellout.fdInvQty.compareTo(BigDecimal.ZERO) == 0;
    }

    /**
     * 获取所有设置为估清的菜品
     *
     * @return List<RapidSellOutModel>
     */
    public static List<SellOutModel> getAllSellOut() {
//        String sql = "select * from localSellOut where fiStatus in ('2','3')";
        String sql = "select localSellOut.fiOrderUintCd,localSellOut.fiStatus,localSellOut.fdInvQty from localSellOut " +
                " left join tbMenuItem on localSellOut.fiItemCd = tbMenuItem.fiItemCd " +
                " left join tbMenuItemUint on localSellOut.fiOrderUintCd = tbMenuItemUint.fiOrderUintCd " +
                " where tbMenuItem.fiStatus<>'13' and tbMenuItemUint.fiStatus<>'13' and localSellOut.fiStatus in ('2','3')";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOutModel.class);
    }

    /**
     * 获取所有设置为已估清的菜品，使用ViewModel
     *
     * @return List<SellOutViewModel>
     */
    public static List<SellOutViewModel> getAllSellOutViewModel() {
//        String sql = "select * from localSellOut where fiStatus in ('2','3')";
        String sql = "select localSellOut.fiOrderUintCd,localSellOut.fiStatus,localSellOut.fdInvQty,localSellOut.fiItemCd,localSellOut.sellOutType, " +
                " tbMenuItem.fsItemName,tbMenuItemUint.fsOrderUint from localSellOut " +
                " left join tbMenuItem on localSellOut.fiItemCd = tbMenuItem.fiItemCd " +
                " left join tbMenuItemUint on localSellOut.fiOrderUintCd = tbMenuItemUint.fiOrderUintCd " +
                " where tbMenuItem.fiStatus<>'13' and tbMenuItemUint.fiStatus<>'13' and localSellOut.fiStatus in ('2','3')";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOutViewModel.class);
    }

    /**
     * 获取所有设置为已估清的菜品，使用ViewModel
     *
     * @return List<SellOutViewModel>
     */
    public static List<SellOutViewModel> getAllSellOutViewModelWithMenuCls() {
        String sql = "select localSellOut.fiOrderUintCd,localSellOut.fiStatus,localSellOut.fdInvQty,localSellOut.fiItemCd,localSellOut.sellOutType," +
                " tbMenuItem.fsMenuClsId,tbMenuItem.fsItemName,tbMenuItemUint.fsOrderUint from localSellOut " +
                " left join tbMenuItem on localSellOut.fiItemCd = tbMenuItem.fiItemCd " +
                " left join tbMenuItemUint on localSellOut.fiOrderUintCd = tbMenuItemUint.fiOrderUintCd " +
                " where tbMenuItem.fiStatus<>'13' and tbMenuItemUint.fiStatus<>'13' and localSellOut.fiStatus in ('2','3')";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOutViewModel.class);
    }

    /**
     * 已沽清菜品按菜品分类分组处理
     */
    public static List<SellOutMenuClsViewModel> groupSellOut() {
        List<SellOutViewModel> allSellOutModel = SellOutServerProcessor.getAllSellOutViewModelWithMenuCls();
        String shopID = HostUtil.getShopID();

        ArrayMap<String, List<SellOutViewModel>> temp = new ArrayMap<>();
        if (!ListUtil.isEmpty(allSellOutModel)) {
            for (SellOutViewModel sellOut : allSellOutModel) {
                MenuclsDBModel rootMenuCls = MenuDBUtil.getRootMenuCls(shopID, sellOut.fsMenuClsId);
                if (rootMenuCls == null || TextUtils.isEmpty(rootMenuCls.fsMenuClsId) || TextUtils.isEmpty(rootMenuCls.fsMenuClsName)) {
                    continue;
                }
                String key = rootMenuCls.fsMenuClsId + "_" + rootMenuCls.fsMenuClsName;
                if (!temp.containsKey(key)) {
                    temp.put(key, new ArrayList<>());
                }
                sellOut.fsMenuClsId = rootMenuCls.fsMenuClsId;
                sellOut.fsMenuClsName = rootMenuCls.fsMenuClsName;
                temp.get(key).add(sellOut);
            }
        }

        List<SellOutMenuClsViewModel> dataList = new ArrayList<>();
        if (temp.size() > 0) {
            for (String key : temp.keySet()) {
                SellOutMenuClsViewModel sellOutMenuCls = new SellOutMenuClsViewModel();
                String[] split = key.split("_");
                if (split == null || split.length < 2) {
                    continue;
                }
                sellOutMenuCls.fsMenuClsId = split[0];
                sellOutMenuCls.fsMenuClsName = split[1];
                sellOutMenuCls.sellOutItemList = temp.get(key);
                dataList.add(sellOutMenuCls);
            }
        }
        return dataList;
    }

    /**
     * 获取菜品估清情况，使用ViewModel
     *
     * @return SellOutViewModel   null表示该菜品没有被估清
     */
    public static SellOutViewModel getItemSellOutViewModel(String fiItemCd, String fsOrderUint) {
        String sql = "select * from localSellOut where fiStatus in ('2','3') and fiItemCd = '" + fiItemCd + "' and fiOrderUintCd = '" + fsOrderUint + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, SellOutViewModel.class);
    }

    /**
     * 获取所有设置为已估清且沽清数量为0的菜品，使用ViewModel
     *
     * @return List<SellOutViewModel>
     */
    public static List<SellOutViewModel> getAllSellOutViewModelWithZero() {
//        String sql = "select * from localSellOut where fiStatus in ('2','3') ";
//        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellOutViewModel.class);
        return getAllSellOutViewModel();
    }

    /**
     * 按照ID来设置沽清
     *
     * @param fiOrderUintCd int | 规格ID
     * @param fiStatus      int | 状态
     * @param fdInvQty      BigDecimal | 剩余数量
     */
    public static void updateSellOut(String fiOrderUintCd, int fiStatus, BigDecimal fdInvQty) {
        SellOutViewModel data = DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT tbmenuitemuint.fiItemCd,tbmenuitem.fsItemName,tbmenuitemuint.fdInvQty,tbmenuitemuint.fiStatus,tbmenuitemuint.fiOrderUintCd,tbmenuitemuint.fsOrderUint FROM tbmenuitemuint left join tbmenuitem on tbmenuitemuint.fiItemCd=tbmenuitem.fiItemCd where tbmenuitemuint.fiOrderUintCd ='" + fiOrderUintCd + "'", SellOutViewModel.class);
        data.fiStatus = fiStatus;
        data.fdInvQty = fdInvQty;
        data.replaceNoTrans();
    }

    /**
     * 更新菜品的估清
     *
     * @param data SellOutViewModel
     */
    public static void updateSellOut(SellOutViewModel data) {
        synchronized (lock) {
            data.replaceNoTrans();
        }
    }

    /**
     * 重置菜品估清状态，通知服务端刷新估清状态
     */
    public static void cancelSellOut(String fiOrderUintCd) {
        synchronized (lock) {
            String sql = "delete from  localSellOut  where fiOrderUintCd='" + fiOrderUintCd + "'";
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        }
    }

    /**
     * 重置所有菜品为非估清状态，通知服务端刷新估清状态
     */
    public static void resetAllSellOut() {
        resetAllSellOut(true);
    }

    /**
     * 重置所有临时估清菜品为非估清状态，通知服务端刷新估清状态
     */
    public static void resetAllTempSellOut() {
        resetAllTempSellOut(true);
    }

    /**
     * 重置所有菜品为非估清状态，不刷新服务端的估清状态
     */
    public static void resetAllSellOutWithoutNotify() {
        resetAllSellOut(false);
    }

    /**
     * 重置所有估清菜品为"未估清"的状态
     *
     * @param notifyServer boolean | 是否刷新服务端的估清状态
     */
    private static void resetAllTempSellOut(boolean notifyServer) {
        synchronized (lock) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from localSellOut  where fistatus = '2' ");
        }
        if (notifyServer) {
            DriverBus.call("monitor/update_rapid_sell_out");
        }
    }

    /**
     * 重置所有估清菜品为"未估清"的状态
     *
     * @param notifyServer boolean | 是否刷新服务端的估清状态
     */
    private static void resetAllSellOut(boolean notifyServer) {
        synchronized (lock) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from localSellOut ");
        }
        if (notifyServer) {
            DriverBus.call("monitor/update_rapid_sell_out");
        }
    }

    /**
     * 菜品下单时的估清数量处理--默认去库存
     *
     * @param selectMenuItemList List<MenuItem>
     */
    public static SubmitOrderCheckNumResult checkSellOutValue(List<MenuItem> selectMenuItemList) {
        return checkSellOutValue(selectMenuItemList, true);
    }

    /**
     * 菜品下单时的估清数量处理
     *
     * @param selectMenuItemList 菜品列表
     * @param decreaseQuantity   是否需要去库存 true: 直接减库存； false: 只检验，不去库存
     * @return
     */
    public static SubmitOrderCheckNumResult checkSellOutValue(List<MenuItem> selectMenuItemList, boolean decreaseQuantity) {
        SubmitOrderCheckNumResult result = new SubmitOrderCheckNumResult();
        synchronized (lock) {
            if (!ListUtil.isEmpty(selectMenuItemList)) {
                List<SellOutViewModel> unitLeft = getAllSellOutViewModel();
                //如果没有估清的菜品，则不需要走下面的判断
                if (ListUtil.isEmpty(unitLeft)) {
                    result.success = true;
                    result.needRefreshSellOutNum = false;
                    result.notEnough = null;
                    result.errorMsg = "";
                    return result;
                }
//                SparseArray<BigDecimal> totalSelectNum = new SparseArray<>();
                ArrayMap<String, BigDecimal> totalSelectNum = new ArrayMap<>();

                //首先整理出所有的菜品使用的数量
                for (MenuItem temp : selectMenuItemList) {
                    if (temp.supportPackage()) {
                        //是套餐菜品
                        if (temp.menuBiz.selectedPackageItems.size() > 0) {
                            //套餐菜品沽清逻辑修改
                            for (MenuItem item : temp.menuBiz.selectedPackageItems) {
                                BigDecimal bigDecimal = totalSelectNum.get(item.currentUnit.fiOrderUintCd);
                                if (bigDecimal == null) {
                                    bigDecimal = BigDecimal.ZERO;
                                }
                                bigDecimal = bigDecimal.add(item.menuBiz.buyNum.multiply(temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum)));
                                totalSelectNum.put(item.currentUnit.fiOrderUintCd, bigDecimal);
                            }
                        }
                    } else {
                        BigDecimal bugNum = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
                        BigDecimal alreadyNum = totalSelectNum.get(temp.currentUnit.fiOrderUintCd);
                        if (alreadyNum == null) {
                            alreadyNum = BigDecimal.ZERO;
                        }
                        alreadyNum = alreadyNum.add(bugNum);
                        totalSelectNum.put(temp.currentUnit.fiOrderUintCd, alreadyNum);

                        if (temp.supportIngredient() && !ListUtil.isEmpty(temp.menuBiz.selectedModifier)) {
                            //含有配料的菜品
                            if (temp.supportPackage()) {
                                bugNum = BigDecimal.ONE;
                            }
                            for (MenuItem menuItem : temp.menuBiz.selectedModifier) {
//                                BigDecimal ingerdientBubNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).multiply(bugNum);
                                // 称重菜按1份计算
                                BigDecimal ingerdientBubNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).multiply(temp.supportWeight() ? BigDecimal.ONE : bugNum);
                                BigDecimal ingerdientAlreadyNum = totalSelectNum.get(menuItem.currentUnit.fiOrderUintCd);
                                if (ingerdientAlreadyNum == null) {
                                    ingerdientAlreadyNum = BigDecimal.ZERO;
                                }
                                ingerdientAlreadyNum = ingerdientAlreadyNum.add(ingerdientBubNum);
                                totalSelectNum.put(menuItem.currentUnit.fiOrderUintCd, ingerdientAlreadyNum);
                            }
                        }
                    }
                }
                //是否需要跟新库存
                boolean hasNeedCheckUnit = false;
                //数量不足的菜品
                List<SellOutViewModel> notEnough = new ArrayList<>();

                for (SellOutViewModel temp : unitLeft) {
                    //已选规格的数量
                    BigDecimal selectUnitNum = totalSelectNum.get(temp.fiOrderUintCd);
                    if (selectUnitNum == null) {
                        continue;
                    } else {
                        hasNeedCheckUnit = true;
                        //先判断估清菜品的数量，是考虑到某些称重菜，在下单的时候可能会输入0
                        if (temp.fdInvQty.compareTo(BigDecimal.ZERO) == 0) {
                            notEnough.add(temp);
                        } else {
                            if (temp.fdInvQty.compareTo(selectUnitNum) >= 0) {
                                continue;
                            } else {
                                notEnough.add(temp);
                            }
                        }
                    }
                }
                List<SellOutViewModel> notEnoughFinal = new ArrayList<>();
                List<SellOutModel> unitLeftFinal = new ArrayList<>();
                if (notEnough.size() > 0) {
                    notEnoughFinal.addAll(notEnough);
                }
                if (unitLeft.size() > 0) {
                    unitLeftFinal.addAll(unitLeft);
                }
                if (hasNeedCheckUnit) {
                    if (notEnough.size() > 0) {
                        result.success = false;
                        result.needRefreshSellOutNum = true;
                        result.notEnough = notEnoughFinal;
                        result.unitSellOutNew = unitLeftFinal;
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < (notEnough.size() > 3 ? 3 : notEnough.size()); i++) {
                            SellOutViewModel temp = notEnough.get(i);
                            sb.append("[")
                                    .append(temp.fsItemName)
                                    .append("]库存不足,剩余")
                                    //.append(temp.fdInvQty.setScale(0, BigDecimal.ROUND_HALF_UP).toPlainString())
                                    .append(temp.fdInvQty.toPlainString())
                                    .append(temp.fsOrderUint)
                                    .append(";");
                        }
                        result.errorMsg = sb.toString();
                    } else {
                        if (decreaseQuantity) {
                            decreaseQuantity(unitLeftFinal, totalSelectNum);
                            result.unitSellOutNew = unitLeftFinal;
                        }
                        result.success = true;
                        result.needRefreshSellOutNum = true;
                        result.notEnough = null;
                        result.errorMsg = "";
                    }
                    NotifyToClient.refreshSellOut();
                } else {
                    result.success = true;
                    result.needRefreshSellOutNum = false;
                    result.notEnough = null;
                    result.errorMsg = "";
                }
                //估清菜品下单成功，且导致估清数量发生了变更，则通过服务端刷新
                if (result.needRefreshSellOutNum) {
                    DriverBus.call("monitor/update_rapid_sell_out");
                }
            } else {
                result.success = true;
            }
        }
        return result;
    }

    /**
     * 开始更新db里的估清菜品的数量
     *
     * @param unitLeft       List<SellOutModel>
     * @param totalSelectNum SparseArray<BigDecimal>
     */
    public static void decreaseQuantity(final List<SellOutModel> unitLeft, final ArrayMap<String, BigDecimal> totalSelectNum) {
        synchronized (lock) {
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                @Override
                public Boolean doJob(SQLiteDatabase db) {
                    ContentValues values = new ContentValues();
                    for (SellOutModel temp : unitLeft) {
                        //已选规格的数量
                        BigDecimal selectUnitNum = totalSelectNum.get(temp.fiOrderUintCd);
                        if (selectUnitNum != null && temp.fdInvQty.compareTo(selectUnitNum) >= 0) {
                            values.clear();
                            temp.fdInvQty = temp.fdInvQty.subtract(selectUnitNum);
                            if (temp.fdInvQty.compareTo(BigDecimal.ZERO) < 0) {
                                temp.fdInvQty = BigDecimal.ZERO;
                            }
                            values.put("fdInvQty", temp.fdInvQty.toString());
                            db.update("localSellOut", values, "fiOrderUintCd='" + temp.fiOrderUintCd + "'", null);
                        }
                    }
                    return true;
                }
            });
        }
    }

    /**
     * 扣库存
     *
     * @param tempSelectedMenuList 下单的菜品
     */
    public static void decreaseQuantity(ArrayList<MenuItem> tempSelectedMenuList) {
//        SparseArray<BigDecimal> totalSelect = new SparseArray<>();
        ArrayMap<String, BigDecimal> totalSelect = new ArrayMap<>();
        for (MenuItem menuItem : tempSelectedMenuList) {
            if (menuItem.supportPackage()) {
                //是套餐菜品
                if (menuItem.menuBiz.selectedPackageItems.size() > 0) {
                    //套餐菜品沽清逻辑修改
                    for (MenuItem item : menuItem.menuBiz.selectedPackageItems) {
                        BigDecimal bigDecimal = totalSelect.get(item.currentUnit.fiOrderUintCd);
                        if (bigDecimal == null) {
                            bigDecimal = BigDecimal.ZERO;
                        }
                        bigDecimal = bigDecimal.add(item.menuBiz.buyNum.multiply(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum)));
                        totalSelect.put(item.currentUnit.fiOrderUintCd, bigDecimal);
                    }
                }
            } else {
                totalSelect.put(menuItem.currentUnit.fiOrderUintCd, menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum));
            }
        }
        List<SellOutViewModel> sellOut = SellOutServerProcessor.getAllSellOutViewModel();
        List<SellOutModel> unitLeftFinal = new ArrayList<>();
        if (!ListUtil.isEmpty(sellOut)) {
            unitLeftFinal.addAll(sellOut);
            SellOutServerProcessor.decreaseQuantity(unitLeftFinal, totalSelect);
            DriverBus.call("monitor/update_rapid_sell_out");
        }
    }

    public static boolean isSellOutAll(SubmitOrderCheckNumResult submitOrderCheckNumResult, ArrayList<MenuItem> tempSelectedMenuList) {
        boolean isSellOutAll = true;
        for (SellOutViewModel sellOutViewModel : submitOrderCheckNumResult.notEnough) {
            if (sellOutViewModel.fdInvQty.compareTo(BigDecimal.ZERO) > 0 || submitOrderCheckNumResult.notEnough.size() != tempSelectedMenuList.size()) {
                isSellOutAll = false;
            }
        }
        return isSellOutAll;
    }

    public static void doVoidMenuItem(SubmitOrderCheckNumResult submitOrderCheckNumResult, ArrayList<MenuItem> tempSelectedMenuList, UserDBModel userDBModel) {
        for (MenuItem menuItem : tempSelectedMenuList) {
            if (menuItem.supportPackage()) {
                //套餐退菜单独处理
                List<MenuItem> menuItems = new ArrayList<>();
                menuItems.add(menuItem);
                SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(menuItems, false);
                if (!ListUtil.isEmpty(result.notEnough)) {
                    //套餐子菜品有沽清整个菜品进行退菜
                    menuItem.doVoid(menuItem.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "菜品沽清");
                }
            } else {
                //处理其他类型菜品退菜
                for (SellOutViewModel sellOutViewModel : submitOrderCheckNumResult.notEnough) {
                    if (TextUtils.equals(sellOutViewModel.fiItemCd, menuItem.itemID) &&
                            TextUtils.equals(sellOutViewModel.fiOrderUintCd, menuItem.currentUnit.fiOrderUintCd)) {
                        BigDecimal voidNum = menuItem.menuBiz.buyNum.subtract(sellOutViewModel.fdInvQty);
                        menuItem.doVoid(voidNum, userDBModel.fsUserId, userDBModel.fsUserName, "菜品沽清");
                        break;
                    }
                }
            }
        }
    }
}
