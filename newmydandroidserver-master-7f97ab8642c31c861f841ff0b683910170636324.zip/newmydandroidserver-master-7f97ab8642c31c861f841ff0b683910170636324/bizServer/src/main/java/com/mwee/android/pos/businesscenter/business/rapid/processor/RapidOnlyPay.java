package com.mwee.android.pos.businesscenter.business.rapid.processor;

import android.text.TextUtils;

import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.util.RapidUtil;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 秒付纯收银
 * Created by virgil on 2017/7/31.
 */

public class RapidOnlyPay {
    public static void receivePurePayInfo(RapidPayment payment, String commitID) {
        RunTimeLog.addLog(RunTimeLog.RAPID_PURE, "收到纯收银订单", commitID, payment);

        String savePayToOrderDirectResult;
        String sellNo = "";
        if (!TextUtils.isEmpty(payment.tableNo)) {
            OrderCache orderCache;
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(payment.tableNo, payment.orderId, "秒付纯收银");
            try {
                String orderID = TableBusinessUtil.getOrderIDByTableID(payment.tableNo);
                if (TextUtils.isEmpty(orderID)) {
                    savePayToOrderDirectResult = "当前桌台没有订单";
                } else {
                    try {
                        orderCache = OrderSaveDBUtil.get(orderID);
                        if (orderCache == null) {
                            savePayToOrderDirectResult = "订单出现异常";
                        } else {
                            sellNo = orderID;
                            ServerCache.getInstance().generateNewToken(orderID);
                            BigDecimal orderNeedPay = orderCache.optTotalPrice();
                            if (orderCache.couponCut != null) {
                                orderNeedPay = orderNeedPay.subtract(orderCache.couponCut.fdCutmoney);
                            }
                            if (orderCache.selectOrderDiscountCut != null) {
                                orderNeedPay = orderNeedPay.subtract(orderCache.selectOrderDiscountCut.fdddv);
                            }
                            BigDecimal rapidTotalAmt = RapidUtil.parseRapidPayTotalAmt(payment);
                            //如果金额完美的匹配上，则直接进行秒付
                            if (orderNeedPay.compareTo(rapidTotalAmt) == 0) {
                                payment.outerOrderId = orderID;
                                RapidActionModel rapidActionModel = new RapidActionModel();
                                RapidBiz.buildPayment(rapidActionModel, payment);
                                if (rapidActionModel.result == RapidResult.SUCCESS) {
                                    savePayToOrderDirectResult = "";
                                } else {
                                    savePayToOrderDirectResult = "纯收银记录绑定到桌台异常绑定到订单异常";
                                }
                            } else {
                                savePayToOrderDirectResult = "订单待支付金额[" + orderNeedPay.toPlainString() + "]和纯收银金额[" + rapidTotalAmt.toPlainString() + "]不一致";
                            }
                            ServerCache.getInstance().releaseToken(orderID);
                        }
                    } catch (Exception e) {
                        savePayToOrderDirectResult = "纯收银绑定到桌台过程中遇到了异常" + e.getMessage();
                        RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, savePayToOrderDirectResult);
                        ActionLog.addLog(savePayToOrderDirectResult, ActionLog.MESSAGE_RAPID_ONLY_PAY);
                    }
                }

            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, payment.tableNo, payment.orderId, "秒付纯收银");
            }
        } else {
            savePayToOrderDirectResult = "没有桌台";
        }
        if (!TextUtils.isEmpty(savePayToOrderDirectResult)) {
            payment.fsMemberNo = "";
            RunTimeLog.addLog(RunTimeLog.RAPID_PURE_NO, savePayToOrderDirectResult, commitID, payment);
            MessageOrderUtil.addRapidOnlyPayMessage(payment, sellNo, MessageConstance.MessagePayBuinessStatus.RAPID_ONLY_PAY.NONE);
        } else {
            RunTimeLog.addLog(RunTimeLog.RAPID_PURE_OK, savePayToOrderDirectResult, commitID, payment);
            MessageOrderUtil.addRapidOnlyPayMessage(payment, sellNo, MessageConstance.MessagePayBuinessStatus.RAPID_ONLY_PAY.DOWN);
        }
    }

    /**
     * 该方法仅限业务中心使用
     *
     * @param rapidPayment
     * @return
     */
    public static ArrayList<PayModel> optPayModelListByRapidPay(RapidPayment rapidPayment) {
        if (rapidPayment == null || ListUtil.isEmpty(rapidPayment.paymentList)) {
            return new ArrayList<>();
        }
        return optPayModelListByRapidPay(rapidPayment.paymentList);
    }

    public static ArrayList<PayModel> optPayModelListByRapidPay(List<RapidPayModel> paymentList) {
        ArrayList<PayModel> payModels = new ArrayList<>();
        if (ListUtil.isEmpty(paymentList)) {
            return payModels;
        }
        for (int i = 0; i < paymentList.size(); i++) {
            RapidPayModel rapidPayModel = paymentList.get(i);

            if (rapidPayModel== null || rapidPayModel.fdReceMoney == null
                    || rapidPayModel.fdReceMoney.compareTo(BigDecimal.ZERO) <= 0){
                continue;
            }
            PayOriginModel data = null;
            if (OrderUtil.isMWMemberTicketByPayID(rapidPayModel.fsPaymentId)) {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            } else if (!TextUtils.isEmpty(rapidPayModel.fsMemberNo) && !TextUtils.isEmpty(rapidPayModel.fsCoupon_id)) {
                data = OrderUtil.buildPayModelByMemberTicketID(rapidPayModel.fsCoupon_id);
            } else {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            }

            //如果没有找到支付方式，则使用默认的卡券
            if (data == null) {
                data = PayUtil.addDefaultCoupon();
            }
            UserDBModel userCash = UserCache.getInstance().getCloudUser();
            if (userCash == null) {
                userCash = new UserDBModel();
                userCash.fsUserId = "cash";
                userCash.fsUserName = "云收银";
            }

            PayModel currentSelectPay = new PayModel(userCash.fsUserId, userCash.fsUserName);
            currentSelectPay.data = data;
            currentSelectPay.payAmount = rapidPayModel.fdReceMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
            currentSelectPay.status = 1;
            currentSelectPay.showNote = rapidPayModel.fsNote;
            currentSelectPay.createTime = DateUtil.getCurrentTime();
            currentSelectPay.seq = 1;
            currentSelectPay.businessInfo = "";

            currentSelectPay.writeRapid();
            currentSelectPay.seq_M = 1;
            if (OrderUtil.isMWMemberTicket(data.payTypeGroupID)) {
                currentSelectPay.data.memberCouponModel = new MemberCouponModel();
                currentSelectPay.data.memberCouponModel.code = rapidPayModel.fsMiscno;
            }
            payModels.add(currentSelectPay);
        }
        return payModels;
    }

}
