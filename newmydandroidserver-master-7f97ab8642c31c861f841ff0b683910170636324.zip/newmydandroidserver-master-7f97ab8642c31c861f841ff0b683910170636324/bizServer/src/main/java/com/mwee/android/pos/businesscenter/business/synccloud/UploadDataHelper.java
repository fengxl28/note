package com.mwee.android.pos.businesscenter.business.synccloud;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.datasync.net.UploadChangeDataRequest;
import com.mwee.android.pos.component.datasync.net.UploadDataRequest;
import com.mwee.android.pos.component.datasync.net.UploadNetOrderMappingRelationRequest;
import com.mwee.android.pos.component.datasync.net.UploadNetorderDataRequest;
import com.mwee.android.pos.component.datasync.net.model.NetorderItemMappingRelationshipDBModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderUploadBean;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.AskgpDBModel;
import com.mwee.android.pos.db.business.AskgpMenuClsDBModel;
import com.mwee.android.pos.db.business.BargainDBModel;
import com.mwee.android.pos.db.business.BillChangeDetailDBModel;
import com.mwee.android.pos.db.business.BillItemCouponDetailDBModel;
import com.mwee.android.pos.db.business.BillSurchargeDetailDBModel;
import com.mwee.android.pos.db.business.CardRelationDBModel;
import com.mwee.android.pos.db.business.CutmoneyDBModel;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.DiscountitemDBModel;
import com.mwee.android.pos.db.business.ExpclsDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.HostexternalDBModel;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MenuClsMuldeptDBModel;
import com.mwee.android.pos.db.business.MenuItemMulDeptDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MenuitemaskgpDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsideDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsidedtlDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.PaymenttypeDBModel;
import com.mwee.android.pos.db.business.RevenuetypeDBModel;
import com.mwee.android.pos.db.business.SellBaseDBModel;
import com.mwee.android.pos.db.business.SellCouponDBModel;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellOrderDBModel;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.SellOrderItemDBModel;
import com.mwee.android.pos.db.business.SellPickMenuitem;
import com.mwee.android.pos.db.business.SellcheckDBModel;
import com.mwee.android.pos.db.business.SellreceiveDBModel;
import com.mwee.android.pos.db.business.SeqnoDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.TableChangeDetailDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.UserroleDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPrivateDBModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class UploadDataHelper {

    private static final String TAG = "UploadDataHelper";

    // 注意，这里维护的DBModel中需要有主键～～～

    // 报表依赖的基础数据
    private static ArrayMap<String, Class<? extends DBModel>> basicTableModelMap =
            new ArrayMap<String, Class<? extends DBModel>>() {
                {
                    put("tbMArea", MareaDBModel.class);
                    put("tbMTable", MtableDBModel.class);
                    put("tbMenuCls", MenuclsDBModel.class);
                    put("tbMenuItem", MenuitemDBModel.class);
                    put("tbMenuItemUint", MenuItemUnitDBModel.class);
                    put("tbMenuItemSetSide", MenuitemsetsideDBModel.class);
                    put("tbMenuItemSetSideDtl", MenuitemsetsidedtlDBModel.class);
                    put("tbDiscount", DiscountDBModel.class);
                    put("tbDiscountItem", DiscountitemDBModel.class);
                    put("tbAskGp", AskgpDBModel.class);
                    put("tbAsk", AskDBModel.class);
                    put("tbMenuItemAskGp", MenuitemaskgpDBModel.class);
                    put("tbPayment", PaymentDBModel.class);
                    put("tbPaymentType", PaymenttypeDBModel.class);
                    put("tbDept", DeptDBModel.class);
                    put("tbUser", UserDBModel.class);
                    put("tbPrinter", PrinterDBModel.class);
                    put("tbMenuItemMulDept", MenuItemMulDeptDBModel.class);
                    put("tbMenuClsMulDept", MenuClsMuldeptDBModel.class);
                    put("tbParamValue", ParamvalueDBModel.class);
                    put("tbAskGpMenuCls", AskgpMenuClsDBModel.class);
                    put("tbExpCls", ExpclsDBModel.class);
                    put("tbRevenueType", RevenuetypeDBModel.class);
                    put("tbShop", ShopDBModel.class);
                    put("tbHost", HostDBModel.class);
                    put("tbHostExternal", HostexternalDBModel.class);
                    put("tbUserRole", UserroleDBModel.class);
                    put("tbBargain", BargainDBModel.class);
                    put("tbCutMoney", CutmoneyDBModel.class);
                }
            };
    // 报表不依赖的基础数据
    private static ArrayMap<String, Class<? extends DBModel>> otherBasicTableModelMap =
            new ArrayMap<String, Class<? extends DBModel>>() {
                {
                    put("tbCardRelation", CardRelationDBModel.class);
                    put("tbPrintTempletPrivate", PrintTempletPrivateDBModel.class);
                    put("tbNetOrderItemMappingRelationship", NetorderItemMappingRelationshipDBModel.class);
                }
            };
    // 报表数据
    private static ArrayMap<String, Class<? extends SellBaseDBModel>> orderTableModelMap =
            new ArrayMap<String, Class<? extends SellBaseDBModel>>() {
                {
                    put("tbSeqNo", SeqnoDBModel.class);
                    put("tbParamValue", ParamvalueDBModel.class);
                    put("tbSell", SellDBModel.class);
                    put("tbSellCheck", SellcheckDBModel.class);
                    put("tbSellOrderItem", SellOrderItemDBModel.class);
                    put("tbSellReceive", SellreceiveDBModel.class);
                    put("tbSellOrder", SellOrderDBModel.class);
                    put("tbSellCoupon", SellCouponDBModel.class);
                    put("tbSellPickMenuItem", SellPickMenuitem.class);
                    put("tbSellOrderItemBonus", SellOrderItemBonusDBModel.class);
                    // 后台要求前面加bill_
                    put("bill_table_change_detail", TableChangeDetailDBModel.class);
                    put("bill_change_detail", BillChangeDetailDBModel.class);

                    put("billItemCouponDetail", BillItemCouponDetailDBModel.class);
                    put("billSurchargeDetail", BillSurchargeDetailDBModel.class);
                }
            };
    // 外卖数据
    private static ArrayMap<String, Class<? extends DBModel>> netOrderTableModelMap =
            new ArrayMap<String, Class<? extends DBModel>>() {
                {
                    put("tempapporder", TempAppOrderUploadBean.class);
                }
            };

    private static volatile ShopDBModel shopDBModel;

    /**
     * 获取未上送数据条数，包括基础数据、报表数据、网络订单数据，其中报表数据以订单为维度计算
     *
     * @return 未上送数据条数
     */
    public static int getAllNotUploadDataCount() {
        int count = 0;
        count += calcNotUploadBasicDataCount(basicTableModelMap);
        count += calcNotUploadBasicDataCount(otherBasicTableModelMap);
        // 报表以订单量计算
        count += calcNotUploadOrderDataCount(null);
        count += calcNotUploadNetOrderDataCount(null);
        return count;
    }

    /**
     * 上送所有报表数据
     *
     * @param newThread 是否新开线程
     */
    public static void uploadOrderData(boolean newThread) {
        if (newThread) {
            BusinessExecutor.executeNoWait(new ASyncExecute() {
                @Override
                public Object execute() {
                    uploadAllData(null, false, null, null);
                    return null;
                }
            });
        } else {
            uploadAllData(null, false, null, null);
        }
    }

    /**
     * 上送指定报表数据
     *
     * @param orderId   订单id
     * @param newThread 是否新开线程
     */
    public static void uploadOrderData(String orderId, boolean newThread) {
        if (TextUtils.isEmpty(orderId)) {
            return;
        }

        List<String> orderIdList = new ArrayList<>();
        orderIdList.add(orderId);

        if (newThread) {
            BusinessExecutor.executeNoWait(new ASyncExecute() {
                @Override
                public Object execute() {
                    uploadAllData(orderIdList, false, null, null);
                    return null;
                }
            });
        } else {
            uploadAllData(orderIdList, false, null, null);
        }
    }

    /**
     * 上送所有数据，包括：基础数据、报表数据、外卖数据
     *
     * @param outerCallback    主回调
     * @param progressCallback 进度回调
     * @return
     */
    public static boolean uploadAllData(IExecutorCallback outerCallback, IProgressCallback progressCallback) {
        return uploadAllData(null, true, outerCallback, progressCallback);
    }

    /**
     * 上送所有数据，包括：基础数据、报表数据、外卖数据（传参控制）
     *
     * @param orderIdList      订单id列表
     * @param withNetOrder     是否上送外卖数据
     * @param outerCallback    主回调
     * @param progressCallback 进度回调
     * @return
     */
    public static boolean uploadAllData(List<String> orderIdList, boolean withNetOrder,
                                        IExecutorCallback outerCallback, IProgressCallback progressCallback) {
        UploadTask uploadTask = new UploadTask();
        uploadTask.basicTask = buildUploadBasicDataTask(new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                if (outerCallback != null) {
                    outerCallback.fail(responseData);
                }
                return false;
            }
        }, progressCallback);
        uploadTask.orderTask = buildUploadOrderDataTask(orderIdList, outerCallback, progressCallback);
        uploadTask.otherBasicTask = buildUploadOtherBasicDataTask();
        // 外卖数据根据场景通过传参控制是否需要上送
        if (withNetOrder) {
            uploadTask.netOrderTask = buildUploadNetOrderDataTask(null);
        }

        return UploadData.startUpload(uploadTask);
    }

    /**
     * 上送外卖数据
     *
     * @param orderId 订单id
     * @return
     */
    public static boolean uploadNetOrderData(String orderId) {
        UploadTask uploadTask = new UploadTask();
        List<String> orderIdList = new ArrayList<>();
        if (!TextUtils.isEmpty(orderId)) {
            orderIdList.add(orderId);
        }
        uploadTask.basicTask = buildUploadBasicDataTask(null, null);
        uploadTask.netOrderTask = buildUploadNetOrderDataTask(orderIdList);
        return UploadData.startUpload(uploadTask);
    }

    /**
     * 是否允许上送基础数据
     *
     * @return true-允许，false-不允许
     */
    private static boolean allowUploadBasicData() {
        if (!BindProcessor.isCurrentHostMain()) {
            return false;
        }
        return true;
    }

    /**
     * 是否允许上送报表数据
     *
     * @return true-允许，false-不允许
     */
    private static boolean allowUploadOrderData() {
        if (!BaseConfig.isProduct()) {
            //if (!TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
            if (!APPConfig.isCasiher() && !TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
                //ServerService.sendSyncMessage(STATUS_FREE, "非生产包请手动开启上送功能");
                return false;
            }
        }
        if (!BindProcessor.isCurrentHostMain()) {
            return false;
        }
        return true;
    }

    /**
     * 构建上送基础数据任务
     */
    private static IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>> buildUploadBasicDataTask(
            IExecutorCallback outerCallback, IProgressCallback progressCallback) {
        return new IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>>() {
            @Override
            public boolean allowUpload() {
                boolean allow = allowUploadBasicData();
                LogUtil.logBusiness(TAG, "1 是否允许上送基础数据：" + allow);
                return allow;
            }

            @Override
            public int calcUnfinishedDataCount() {
                int count = calcNotUploadBasicDataCount(basicTableModelMap);
                LogUtil.logBusiness(TAG, "2 剩余待上送的基础数据量为：" + count);
                return count;
            }

            @Override
            public ArrayMap<String, List<? extends DBModel>> buildData() {
                return buildUploadBasicDataOnce(basicTableModelMap);
            }

            @Override
            public List<? extends BaseRequest> buildRequest(ArrayMap<String, List<? extends DBModel>> data) {
                List<BaseRequest> requestList = new ArrayList<>();
                LogUtil.logBusiness(TAG, "3 构建请求，本次上送的基础数据为：" + data.keySet());
                UploadChangeDataRequest request = new UploadChangeDataRequest();
                request.data = JSON.toJSON(data);
                requestList.add(request);
                return requestList;
            }

            @Override
            public void uploadSuccess(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "4 本次上送基础数据成功");
                if (outerCallback != null) {
                    outerCallback.success(responseData);
                }
            }

            @Override
            public void uploadFail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "5 本次上送基础数据失败");
                if (outerCallback != null) {
                    outerCallback.fail(responseData);
                }
            }

            @Override
            public int updateDataSyncStatus(ArrayMap<String, List<? extends DBModel>> data) {
                int updateCount = updateBasicDataStatus(data);
                LogUtil.logBusiness(TAG, "6 本次更新的基础数据量：" + updateCount);
                return updateCount;
            }

            @Override
            public void processProgress(int progress) {
                if (progressCallback != null) {
                    progressCallback.onProgress(progress, IProgressCallback.TAG_UPLOAD_BASE_DATA);
                }
            }
        };
    }

    /**
     * 构建上送报表数据任务
     */
    private static IUploadDataCallback<ArrayMap<String, List<? extends SellBaseDBModel>>> buildUploadOrderDataTask(
            List<String> orderIdList, IExecutorCallback outerCallback, IProgressCallback progressCallback) {
        List<String> formattedOrderIdList = formatList(orderIdList);
        LogUtil.logBusiness(TAG, "准备上送报表数据：formattedOrderIdList=" + formattedOrderIdList);
        return new IUploadDataCallback<ArrayMap<String, List<? extends SellBaseDBModel>>>() {
            @Override
            public boolean allowUpload() {
                boolean allow = allowUploadOrderData();
                LogUtil.logBusiness(TAG, "1 是否允许上送报表数据：" + allow);
                return allow;
            }

            @Override
            public int calcUnfinishedDataCount() {
                int count = calcNotUploadOrderDataCount(formattedOrderIdList);
                LogUtil.logBusiness(TAG, "2 剩余待上送的报表数据量为：" + count);
                return count;
            }

            @Override
            public ArrayMap<String, List<? extends SellBaseDBModel>> buildData() {
                return buildUploadOrderDataOnce(formattedOrderIdList);
            }

            @Override
            public List<? extends BaseRequest> buildRequest(ArrayMap<String, List<? extends SellBaseDBModel>> data) {
                List<BaseRequest> requestList = new ArrayList<>();
                LogUtil.logBusiness(TAG, "3 构建请求，本次上送的报表数据为：" + data.keySet());
                UploadDataRequest request = new UploadDataRequest();
                request.data = JSON.toJSON(data);
                requestList.add(request);
                return requestList;
            }

            @Override
            public void uploadSuccess(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "4 本次上送报表数据成功");
                if (outerCallback != null) {
                    outerCallback.success(responseData);
                }
            }

            @Override
            public void uploadFail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "5 本次上送报表数据失败");
                if (outerCallback != null) {
                    outerCallback.fail(responseData);
                }
            }

            @Override
            public int updateDataSyncStatus(ArrayMap<String, List<? extends SellBaseDBModel>> data) {
                int updateCount = updateOrderDataStatus(data);
                LogUtil.logBusiness(TAG, "6 本次更新的报表数据量：" + updateCount);
                return updateCount;
            }

            @Override
            public void processProgress(int progress) {
                if (progressCallback != null) {
                    progressCallback.onProgress(progress, IProgressCallback.TAG_UPLOAD_ORDER_DATA);
                }
            }
        };
    }

    /**
     * 构建上送报表不依赖的基础数据任务
     */
    private static IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>> buildUploadOtherBasicDataTask() {
        return new IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>>() {
            @Override
            public boolean allowUpload() {
                boolean allow = allowUploadBasicData();
                LogUtil.logBusiness(TAG, "1 是否允许上送报表不依赖的基础数据：" + allow);
                return allow;
            }

            @Override
            public int calcUnfinishedDataCount() {
                int count = calcNotUploadBasicDataCount(otherBasicTableModelMap);
                LogUtil.logBusiness(TAG, "2 剩余待上送的报表不依赖的基础数据量为：" + count);
                return count;
            }

            @Override
            public ArrayMap<String, List<? extends DBModel>> buildData() {
                return buildUploadBasicDataOnce(otherBasicTableModelMap);
            }

            @Override
            public List<? extends BaseRequest> buildRequest(ArrayMap<String, List<? extends DBModel>> data) {
                ArrayMap<String, List<? extends DBModel>> newData = new ArrayMap<>(data);

                List<BaseRequest> requestList = new ArrayList<>();
                LogUtil.logBusiness(TAG, "3 构建请求，本次上送的报表不依赖的基础数据为：" + data.keySet());
                UploadChangeDataRequest request = new UploadChangeDataRequest();
                requestList.add(request);

                //美团外卖菜品映射走单独接口
                String tbNetOrderItemMappingRelationship = "tbNetOrderItemMappingRelationship";
                List<? extends DBModel> mappingRelationshipDataList = data.get(tbNetOrderItemMappingRelationship);
                if (!ListUtil.isEmpty(mappingRelationshipDataList)) {
                    UploadNetOrderMappingRelationRequest mappingRelationRequest = new UploadNetOrderMappingRelationRequest();
                    mappingRelationRequest.tbNetorderItemMappingRelationship = JSON.toJSON(mappingRelationshipDataList);
                    requestList.add(mappingRelationRequest);
                }

                newData.remove(tbNetOrderItemMappingRelationship);
                request.data = JSON.toJSON(data);

                return requestList;
            }

            @Override
            public int updateDataSyncStatus(ArrayMap<String, List<? extends DBModel>> data) {
                int updateCount = updateBasicDataStatus(data);
                LogUtil.logBusiness(TAG, "6 本次更新的报表不依赖的基础数据量：" + updateCount);
                return updateCount;
            }
        };
    }

    /**
     * 构建上送外卖数据任务
     */
    private static IUploadDataCallback<TempAppOrderUploadBean> buildUploadNetOrderDataTask(List<String> orderIdList) {
        List<String> formattedOrderIdList = formatList(orderIdList);
        LogUtil.logBusiness(TAG, "准备上送外卖数据：formattedOrderIdList=" + formattedOrderIdList);
        return new IUploadDataCallback<TempAppOrderUploadBean>() {
            @Override
            public boolean allowUpload() {
                boolean allow = allowUploadOrderData();
                LogUtil.logBusiness(TAG, "1 是否允许上送外卖数据：" + allow);
                return allow;
            }

            @Override
            public int calcUnfinishedDataCount() {
                int count = calcNotUploadNetOrderDataCount(formattedOrderIdList);
                LogUtil.logBusiness(TAG, "2 剩余待上送的外卖数据量为：" + count);
                return count;
            }

            @Override
            public TempAppOrderUploadBean buildData() {
                return buildUploadNetOrderDataOnce(formattedOrderIdList);
            }

            @Override
            public List<? extends BaseRequest> buildRequest(TempAppOrderUploadBean data) {
                List<BaseRequest> requestList = new ArrayList<>();
                UploadNetorderDataRequest request = new UploadNetorderDataRequest();
                request.tbTakeawayDetail = JSON.toJSON(data);

                LogUtil.logBusiness(TAG, "3 构建请求，本次上送的外卖数据");
                requestList.add(request);

                return requestList;
            }

            @Override
            public int updateDataSyncStatus(TempAppOrderUploadBean data) {
                int updateCount = updateNetOrderDataStatus(data);
                LogUtil.logBusiness(TAG, "6 本次更新的外卖数据量：" + updateCount);
                return updateCount;
            }
        };
    }

    /**
     * 计算未上送的基础数据数量
     *
     * @param tableModelMap basicTableModelMap/otherBasicTableModelMap
     * @return 数量
     */
    private static int calcNotUploadBasicDataCount(ArrayMap<String, Class<? extends DBModel>> tableModelMap) {
        String shopGUID = HostUtil.getShopID();
        String sql = "SELECT count(*) as count FROM %1$s where sync = '1' and fsShopGUID='" + shopGUID + "' ";
        int count = 0;
        for (String temp : tableModelMap.keySet()) {
            int i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, temp)));
            count += i;
            LogUtil.log(TAG, " 上送检测 表[" + temp + "]待上送的数据为：" + i);
        }
        return count;
    }

    /**
     * 构建未上送的基础数据
     *
     * @param tableModelMap basicTableModelMap/otherBasicTableModelMap
     * @return ArrayMap《表名, 数据列表》
     */
    private static ArrayMap<String, List<? extends DBModel>> buildUploadBasicDataOnce(ArrayMap<String, Class<? extends DBModel>> tableModelMap) {
        ArrayMap<String, List<? extends DBModel>> data = new ArrayMap<>();
        String shopGUID = HostUtil.getShopID();
        String sql = "where sync = '1' and fsShopGUID='" + shopGUID + "' limit 5";

        for (String tableName : tableModelMap.keySet()) {
            List<? extends DBModel> dbModels;
            if (TextUtils.equals(tableName.toLowerCase(), "tbparamvalue")) {
                String sqlWechat = "SELECT * FROM tbparamvalue WHERE (fsParamId LIKE 'chat%' OR fsParamId = 'a01') AND sync = 1 and fsShopGUID='" + shopGUID + "' ";
                List<ParamvalueDBModel> wechatList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlWechat, ParamvalueDBModel.class);
                if (ListUtil.isEmpty(wechatList)) {
                    dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ParamvalueDBModel.class);
                } else {
                    dbModels = new ArrayList<>(wechatList);
                }
            } else {
                dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, tableModelMap.get(tableName));
            }

            if (!ListUtil.isEmpty(dbModels)) {
                data.put(tableName, dbModels);
            }
        }

        return data;
    }

    /**
     * 更新基础数据上送状态
     *
     * @param data ArrayMap《表名, 数据列表》
     * @return 更新的数量
     */
    private static int updateBasicDataStatus(ArrayMap<String, List<? extends DBModel>> data) {
        LogUtil.logBusiness(TAG, "更新基础数据：" + data.keySet());
        final int[] count = {0};
        IDBOperate op = new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues(1);
                for (String tableName : data.keySet()) {
                    List<? extends DBModel> dbModels = data.get(tableName);
                    if (!ListUtil.isEmpty(dbModels)) {
                        for (DBModel temp : dbModels) {
                            values.clear();
                            values.put("sync", 0);
                            temp.update(values, true);
                        }
                        count[0] += dbModels.size();
                    }
                }
                return true;
            }
        };
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, TAG + " 更新基础数据上送状态，写入数据库");
        DBManager.getInstance().executeInTransactionWithOutThread(op);
        return count[0];
    }

    /**
     * 计算未上送的报表数据数量
     *
     * @param orderIdList 订单id列表
     * @return 数量
     */
    private static int calcNotUploadOrderDataCount(List<String> orderIdList) {
        List<String> tableList = new ArrayList<>();
        tableList.add("tbSell");

        if (!APPConfig.isCasiher()) {
            //订单号和账单号
            tableList.add("tbSeqNo");
            //开关配置及营业日期
            tableList.add("tbParamValue");
        }

        String shopGUID = HostUtil.getShopID();
        String sqlBase = "select count(*) as count FROM %1$s where fsShopGUID='" + shopGUID + "' and lver>pver ";

        int count = 0;
        for (String temp : tableList) {
            int i = 0;
            if (TextUtils.equals("tbSell", temp)) {
                String sqlSell = String.format(sqlBase + " and fiBillStatus in (3,5,6)", temp);
                if (!ListUtil.isEmpty(orderIdList)) {
                    String orderIdParam = convertParamListToString(orderIdList);
                    if (!TextUtils.isEmpty(orderIdParam)) {
                        sqlSell = sqlSell + " and fsSellNo in (" + orderIdParam + ")";
                    }
                }
                i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlSell));
            } else {
                i = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sqlBase, temp)));
            }
            count += i;
            LogUtil.log(TAG, " 上送检测 表[" + temp + "]待上送的数据为：" + i);
        }
        return count;
    }

    /**
     * 构建未上送的报表数据
     *
     * @param orderIdList 订单id列表
     * @return ArrayMap《表名, 数据列表》
     */
    private static ArrayMap<String, List<? extends SellBaseDBModel>> buildUploadOrderDataOnce(List<String> orderIdList) {
        ArrayMap<String, List<? extends SellBaseDBModel>> data = new ArrayMap<>();
        String shopGUID = HostUtil.getShopID();

        List<SeqnoDBModel> seqNoDataList = optDataList(shopGUID, SeqnoDBModel.class);
        if (!ListUtil.isEmpty(seqNoDataList)) {
            data.put("tbSeqNo", seqNoDataList);
        }
        List<ParamvalueDBModel> paramValueDataList = optDataList(shopGUID, ParamvalueDBModel.class);
        if (!ListUtil.isEmpty(paramValueDataList)) {
            data.put("tbParamValue", paramValueDataList);
        }

        String orderIdParam = "";
        String sqlOrderNeedUpload = "select fsSellNo from tbSell where fiBillStatus in (3,5,6) and fsShopGUID='" + shopGUID + "' and lver>pver %s limit 1 ";
//        if (ListUtil.isEmpty(orderIdList)) {
//            sqlOrderNeedUpload = String.format(sqlOrderNeedUpload, " and lver>pver ");
//        } else {
        // 上送指定订单，订单id列表转换为参数形式
        orderIdParam = convertParamListToString(orderIdList);
        if (!TextUtils.isEmpty(orderIdParam)) {
            orderIdParam = " and fsSellNo in (" + orderIdParam + ") ";
        }
        sqlOrderNeedUpload = String.format(sqlOrderNeedUpload, orderIdParam);
//        }

        List<String> orderList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sqlOrderNeedUpload);

        String sqlWithoutColumnName;
        orderIdParam = convertParamListToString(orderList);
        if (TextUtils.isEmpty(orderIdParam)) {
            //如果当前订单号的状态不符合要求，则上送null列表。
            return data;
        }
        sqlWithoutColumnName = "where %s in (%s) ";

        String sqlNormal = String.format(sqlWithoutColumnName + " and fsShopGUID='%s' ", "fsSellNo", orderIdParam, shopGUID);
        String sqlChangeTable = String.format(sqlWithoutColumnName, "sell_no", orderIdParam);
        String sqlBillReport = String.format(sqlWithoutColumnName, "sellNo", orderIdParam);

        for (String tableName : orderTableModelMap.keySet()) {
            if (TextUtils.equals(tableName.toLowerCase(), "tbseqno") ||
                    TextUtils.equals(tableName.toLowerCase(), "tbparamvalue")) {
                continue;
            }

            List<? extends SellBaseDBModel> dbModels;
            if (TextUtils.equals(tableName.toLowerCase(), "bill_table_change_detail") ||
                    TextUtils.equals(tableName.toLowerCase(), "bill_change_detail")) {
                dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlChangeTable, orderTableModelMap.get(tableName));
            } else if (TextUtils.equals(tableName, "billItemCouponDetail") ||
                    TextUtils.equals(tableName, "billSurchargeDetail")) {
                dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlBillReport, orderTableModelMap.get(tableName));
            } else {
                dbModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlNormal, orderTableModelMap.get(tableName));
            }

            if (!ListUtil.isEmpty(dbModels)) {
                data.put(tableName, dbModels);
            }
        }

//        LogUtil.logBusiness(TAG, "********************* start *************************");
//        if (!ListUtil.mapIsEmpty(data)) {
//            LogUtil.logBusiness(TAG, "########### data size = " + data.size());
//            for (String table : data.keySet()) {
//                List<? extends SellBaseDBModel> list = data.get(table);
//                if (!ListUtil.isEmpty(list)) {
//                    LogUtil.logBusiness(TAG, "########### data: table = (" + table + "), size = " + list.size());
//                    for (SellBaseDBModel model : list) {
//                        LogUtil.logBusiness(TAG, "########### data: table = (" + table + "), model = " + JSON.toJSONString(model));
//
//                    }
//                }
//            }
//        }
//        LogUtil.logBusiness(TAG, "*********************  end  *************************");

        return data;
    }

    /**
     * 更新报表数据上送状态
     *
     * @param data ArrayMap《表名, 数据列表》
     * @return 更新的数量
     */
    private static int updateOrderDataStatus(ArrayMap<String, List<? extends SellBaseDBModel>> data) {
        LogUtil.logBusiness(TAG, "更新报表数据：" + data.keySet());
        final int[] count = {0};
        IDBOperate op = new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues(1);
                for (String tableName : data.keySet()) {
                    List<? extends SellBaseDBModel> dbModels = data.get(tableName);

                    if (!ListUtil.isEmpty(dbModels)) {
                        for (SellBaseDBModel temp : dbModels) {
                            temp.pver = temp.lver;
                            values.clear();
                            values.put("pver", temp.pver);
                            temp.update(values, true);
                        }
                        if (TextUtils.equals(tableName.toLowerCase(), "tbsell") ||
                                TextUtils.equals(tableName.toLowerCase(), "tbseqno") ||
                                TextUtils.equals(tableName.toLowerCase(), "tbparamvalue")) {
                            count[0] += dbModels.size();
                        }
                    }
                }
                return true;
            }
        };
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, TAG + " 更新报表数据上送状态，写入数据库");
        DBManager.getInstance().executeInTransactionWithOutThread(op);
        return count[0];
    }

    /**
     * 计算未上送的外卖数据数量
     *
     * @param orderIdList 订单id列表
     * @return 数量
     */
    private static int calcNotUploadNetOrderDataCount(List<String> orderIdList) {
        String sql = "SELECT count(*) as count FROM tempapporder where sync = '1' and orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "'";
        String orderIdParam = convertParamListToString(orderIdList);
        if (!TextUtils.isEmpty(orderIdParam)) {
            sql = sql + " and orderId in (" + orderIdParam + ")";
        }
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql));
        LogUtil.log(TAG, " 上送检测 表[ tempapporder ]待上送的数据为：" + count);
        return count;
    }

    /**
     * 构建未上送的外卖数据
     *
     * @param orderIdList 订单id列表
     * @return ArrayMap《表名, 数据列表》
     */
    private static TempAppOrderUploadBean buildUploadNetOrderDataOnce(List<String> orderIdList) {
        TempAppOrderUploadBean tempAppOrderUploadBean;
        String orderIdParam = convertParamListToString(orderIdList);
        if (TextUtils.isEmpty(orderIdParam)) {
            tempAppOrderUploadBean = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempapporder where sync = '1' and  orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "' limit 1", TempAppOrderUploadBean.class);
        } else {
            tempAppOrderUploadBean = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempapporder where orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "' and orderId in (" + orderIdParam + ") limit 1", TempAppOrderUploadBean.class);
        }

        if (tempAppOrderUploadBean == null) {
            return null;
        }

        if (shopDBModel == null) {
            shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);
        }

        if (shopDBModel != null) {
            tempAppOrderUploadBean.shopGuid = shopDBModel.fsShopGUID;
            tempAppOrderUploadBean.shopName = shopDBModel.fsShopName;
            tempAppOrderUploadBean.companyGuid = shopDBModel.fsCompanyGUID;
        }
        if (!TextUtils.isEmpty(tempAppOrderUploadBean.sellDate)) {
            tempAppOrderUploadBean.sellDate = DateUtil.formartDateStrToTarget(tempAppOrderUploadBean.sellDate, DateUtil.DATE_VISUAL14FORMAT, "yyyy-MM-dd");
        }

        String sumAmt = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select sum(totalItemPrice) amt from tempapporderdetails where orderId = '" + tempAppOrderUploadBean.sellNo + "' ");
        if (TextUtils.isEmpty(sumAmt)) {
            sumAmt = "0";
        }
        BigDecimal totalAmt = new BigDecimal(sumAmt);
        if (totalAmt.compareTo(BigDecimal.ZERO) <= 0) {
            tempAppOrderUploadBean.itemAmount = tempAppOrderUploadBean.totalAmount;
        } else {
            tempAppOrderUploadBean.itemAmount = totalAmt;
        }

        return tempAppOrderUploadBean;
    }

    /**
     * 更新外卖数据上送状态
     *
     * @param data ArrayMap《表名, 数据列表》
     * @return 更新的数量
     */
    private static int updateNetOrderDataStatus(TempAppOrderUploadBean data) {
        if (data == null) {
            return 0;
        }
        LogUtil.logBusiness(TAG, "更新外卖数据");
        final int[] count = {0};
        IDBOperate op = new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                ContentValues values = new ContentValues(1);
                values.clear();
                values.put("sync", 0);
                data.update(values, true);
                count[0] += 1;
                return true;
            }
        };
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, TAG + " 更新基础数据上送状态，写入数据库");
        DBManager.getInstance().executeInTransactionWithOutThread(op);
        return count[0];
    }

    /**
     * 格式化String列表，去除为空的item
     *
     * @param list 原列表
     * @return 新列表
     */
    private static List<String> formatList(List<String> list) {
        List<String> newList = new ArrayList<>();
        if (ListUtil.isEmpty(list)) {
            return newList;
        }
        for (String item : list) {
            if (TextUtils.isEmpty(item)) {
                continue;
            }
            newList.add(item);
        }
        return newList;
    }

    private static <T extends DBModel> List<T> optDataList(String shopGUID, Class<T> cls) {
        if (APPConfig.isCasiher()) {
            return null;
        }
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where lver>pver and fsShopGUID='" + shopGUID + "' limit 5", cls);
    }

    /**
     * 将String列表转化为SQL查询参数
     *
     * @param paramList String列表
     * @return eg: '1','2','3'
     */
    private static String convertParamListToString(List<String> paramList) {
        if (ListUtil.isEmpty(paramList)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String param : paramList) {
            sb.append("'").append(param).append("',");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }
}
