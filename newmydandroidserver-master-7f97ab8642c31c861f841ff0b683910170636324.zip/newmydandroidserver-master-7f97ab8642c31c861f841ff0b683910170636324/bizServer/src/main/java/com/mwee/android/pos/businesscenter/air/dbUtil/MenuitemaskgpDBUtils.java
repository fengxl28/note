package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuitemaskgpDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by qinwei on 2017/10/24.
 */

public class MenuitemaskgpDBUtils {
    public static void add(String fiItemCd, String fsAskGpId, String shopId) {

        MenuitemaskgpDBModel tempModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemaskgp where fiStatus = '1' and fsAskGpId = '" + fsAskGpId + "' and fiItemCd = '" + fiItemCd + "'", MenuitemaskgpDBModel.class);
        if (tempModel == null) {
            MenuitemaskgpDBModel menuitemaskgpDBModel = new MenuitemaskgpDBModel();
            menuitemaskgpDBModel.fiItemCd = fiItemCd;
            menuitemaskgpDBModel.fiStatus = 1;
            menuitemaskgpDBModel.fsAskGpId = fsAskGpId;
            menuitemaskgpDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            menuitemaskgpDBModel.fsShopGUID = shopId;
            menuitemaskgpDBModel.fsUpdateUserId = "admin";
            menuitemaskgpDBModel.fsUpdateUserName = "管理员";
            menuitemaskgpDBModel.fiDataSource = 1;
            menuitemaskgpDBModel.sync = 1;
            menuitemaskgpDBModel.replaceNoTrans();
        }
    }

    public static void deleteByMenuId(String fiItemCd) {
        String sql = "update tbmenuitemaskgp set fistatus=13,fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1 where fiItemCd='" + fiItemCd+"' and fiRelationtype = '3' ";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }
}
