package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.bargain.GetBargainListResponse;
import com.mwee.android.air.db.business.bargain.FullReduceBean;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AirBargainDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.BargainDBModel;
import com.mwee.android.pos.db.business.CutmoneyDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * author:luoshenghua
 * create on:2018/6/2
 * description:air2.6 满减优惠
 */
@SuppressWarnings("unused")
public class AirBargainManagerDriver implements IDriver {

    private static final String TAG = "airBargainManagerDriver";

    /**
     * 添加满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/addFullReduce")
    public SocketResponse addFullReduce(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            FullReduceBean fullReduceBean = JSON.parseObject(request.getString("fullReduceBean"), FullReduceBean.class);
            if (fullReduceBean == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirBargainDBUtil.addFullReduce(fullReduceBean, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMsg;
                LogUtil.log("----------errMsg=" + errMsg);
            } else {
                response.code = SocketResultCode.SUCCESS;
                response.message = "新增优惠成功！";
                LogUtil.log("----------新增优惠成功");
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 批量删除满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/deleteFullReduceBatch")
    public SocketResponse deleteFullReduceBatch(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetBargainListResponse responseData = new GetBargainListResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            List<String> bargainIdList = JSON.parseArray(request.getJSONArray("fullReduceIdList").toString(), String.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            int isSuccess = AirBargainDBUtil.deleteFullReduceBatch(bargainIdList, userDBModel);
            if (isSuccess == 1) {
                response.code = SocketResultCode.SUCCESS;
                responseData.bargainDBModelList = AirBargainDBUtil.optFullReduceList();
                response.data = responseData;
                response.message = "数据删除成功";
            } else {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "数据删除失败";
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 更新满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/updateFullReduce")
    public SocketResponse updateFullReduce(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            FullReduceBean fullReduceBean = JSON.parseObject(request.getString("fullReduceBean"), FullReduceBean.class);

            if (fullReduceBean == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirBargainDBUtil.updateFullReduce(fullReduceBean, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMsg;
                LogUtil.log("----------errMsg=" + errMsg);
            } else {
                response.code = SocketResultCode.SUCCESS;
                response.message = "优惠更新成功！";
                LogUtil.log("----------更新优惠成功");
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取满减优惠列表
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/optFullReduceList")
    public SocketResponse optFullReduceList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetBargainListResponse responseData = new GetBargainListResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            List<FullReduceBean> bargainDBModelList = AirBargainDBUtil.optFullReduceList();
            if (!ListUtil.isEmpty(bargainDBModelList)) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "数据获取成功";
                responseData.bargainDBModelList = bargainDBModelList;
            } else {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "数据获取失败";
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
