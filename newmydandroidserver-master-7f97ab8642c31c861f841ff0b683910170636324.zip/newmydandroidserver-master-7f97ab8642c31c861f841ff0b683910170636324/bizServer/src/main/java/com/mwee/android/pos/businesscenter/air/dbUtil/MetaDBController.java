package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.tools.DateUtil;

/**
 * META配置表数据控制器
 * Created by qinwei on 2017/10/11.
 */

public class MetaDBController {
    public static void updateSyncTime() {
        DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
    }
}

