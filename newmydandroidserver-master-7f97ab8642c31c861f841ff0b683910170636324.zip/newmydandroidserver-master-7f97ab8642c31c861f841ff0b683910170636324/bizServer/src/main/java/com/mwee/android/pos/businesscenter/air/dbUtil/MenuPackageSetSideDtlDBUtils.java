package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideDtlBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuitemsetsidedtlDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by qinwei on 2017/10/22.
 */

public class MenuPackageSetSideDtlDBUtils {

    public static void deleteBySetSideCd(String fiSetFoodCd) {
        //删除套餐明细关联
        String deleteSetsideDetailDeleteSql = "update  tbmenuitemsetsidedtl set fiStatus=13, fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1  WHERE fiSetFoodCd='" + fiSetFoodCd + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, deleteSetsideDetailDeleteSql);
    }

    public static void deleteByPackageId(String packageId) {
        String deleteSetSideDtl = "update  tbmenuitemsetsidedtl set fiStatus=13, fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1  WHERE fiItemCd_M='" + packageId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, deleteSetSideDtl);
    }

    public static void addMenuPackageSetSideDtl(MenuPackageSetSideDtlBean menuPackageSetSideDtlBean, UserDBModel userDBModel, String shopId) {
        MenuitemsetsidedtlDBModel dtlModel = new MenuitemsetsidedtlDBModel();
        dtlModel.fiItemCd_M = menuPackageSetSideDtlBean.fiItemCd_M;
        dtlModel.fiSetFoodCd = menuPackageSetSideDtlBean.fiSetFoodCd;
        dtlModel.fiItemCd = menuPackageSetSideDtlBean.fiItemCd;
        dtlModel.fiOrderUintCd = menuPackageSetSideDtlBean.fiOrderUintCd;
        dtlModel.fdBargainPrice = BigDecimal.ZERO;
        dtlModel.fiDefault = 0;//默认选中;0=false/1=true
        dtlModel.fiSortOrder = 88;
        dtlModel.fiStatus = 1;
        //销售菜品数量
        dtlModel.fdSaleQty = menuPackageSetSideDtlBean.fdSaleQty;
        dtlModel.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            dtlModel.fsUpdateUserId = userDBModel.fsUserId;
            dtlModel.fsUpdateUserName = userDBModel.fsUserName;
        }
        dtlModel.fsShopGUID = shopId;
        dtlModel.fiDataSource = 1;
        dtlModel.sync = 1;
        dtlModel.replaceNoTrans();
    }

    /**
     * 查询一组规格  套餐内占用规格信息
     *
     * @param unitIds
     * @return
     */
    public static String queryMenuItemNameAndUnitNameAndPackageNameMessage(List<String> unitIds) {
        String where = "";
        for (int i = 0; i < unitIds.size(); i++) {
            if (i != unitIds.size() - 1) {
                where += "'" + unitIds.get(i) + "',";
            } else {
                where += "'" + unitIds.get(i) + "'";
            }
        }
        String sql = "select * from tbmenuitemsetsidedtl where fiStatus=1 and fiOrderUintCd in(" + where + ") limit 1";
        MenuPackageSetSideDtlBean menuPackageSetSideDtlBean = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuPackageSetSideDtlBean.class);
        if (menuPackageSetSideDtlBean != null) {
            String unitName = MenuItemUnitDBUtils.queryUnitNameById(menuPackageSetSideDtlBean.fiOrderUintCd);
            String menuItemName = MenuItemDBUtils.queryMenuItemNameByUnitId(menuPackageSetSideDtlBean.fiOrderUintCd);
            String packageName = MenuItemDBUtils.queryNameById(menuPackageSetSideDtlBean.fiItemCd_M);
            return "【" + menuItemName + "（" + unitName + "）】已在【" + packageName + "】使用，删除该规格将致套餐无法使用，请取消使用后再进行删除。";
        }
        return "";
    }
}
