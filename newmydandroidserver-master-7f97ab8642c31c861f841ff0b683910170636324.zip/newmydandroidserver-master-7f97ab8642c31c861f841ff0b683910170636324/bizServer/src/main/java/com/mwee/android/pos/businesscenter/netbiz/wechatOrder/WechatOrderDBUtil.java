package com.mwee.android.pos.businesscenter.netbiz.wechatOrder;

import android.text.TextUtils;
import android.util.Pair;

import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.WechatOrderDBModel;
import com.mwee.android.pos.db.business.WechatOrderItemDBModel;
import com.mwee.android.pos.db.business.WechatPayDetailDBModel;
import com.mwee.android.pos.db.business.report.model.WechatPayInfoModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lxx on 17/1/16.
 */

public class WechatOrderDBUtil {

    /**
     * 获取所有微信外卖
     * strftime('%Y%m%d', date)
     *
     * @param date 日期yyyy-MM-dd
     * @return
     */
    public static Pair<Integer, List<WechatOrderModel>> getAllWechatOrders(int currentPage, String date, boolean kds) {
//        productInitData();
        String params = "";
        if (!TextUtils.isEmpty(date)) {
            params = " where fscreatetime like '" + date + "%'";
        }
        params += " order by fsorderNo desc";
        String sql = "select * from " + DBModel.getTableName(WechatOrderModel.class) + params;
        int offset = (currentPage - 1) * 20;//偏移量
        sql = sql + " limit 20 offset " + offset;
        List<WechatOrderModel> wechatOrderModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, WechatOrderModel.class);
        if (wechatOrderModelList == null) {
            return new Pair<>(0, new ArrayList<>());
        }
        List<WechatOrderItemDBModel> wechatOrderItemDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(WechatOrderItemDBModel.class) + params, WechatOrderItemDBModel.class);
        if (wechatOrderItemDBModelList == null) {
            wechatOrderItemDBModelList = new ArrayList<>();
        }

        List<WechatPayDetailDBModel> wechatPayDetailDBModelList = new ArrayList<>();
        if (!kds) {
            wechatPayDetailDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(WechatPayDetailDBModel.class) + params, WechatPayDetailDBModel.class);
            if (wechatPayDetailDBModelList == null) {
                wechatPayDetailDBModelList = new ArrayList<>();
            }
        }

        Map<String, List<WechatOrderItemDBModel>> itemMap = new HashMap<>();
        Map<String, List<WechatPayDetailDBModel>> payMap = new HashMap<>();

        for (WechatOrderItemDBModel wechatOrderItemDBModel : wechatOrderItemDBModelList) {
            List<WechatOrderItemDBModel> wechatOrderItemDBModels = itemMap.get(wechatOrderItemDBModel.fsorderno);
            if (wechatOrderItemDBModels == null) {
                wechatOrderItemDBModels = new ArrayList<>();
                itemMap.put(wechatOrderItemDBModel.fsorderno, wechatOrderItemDBModels);
            }
            wechatOrderItemDBModels.add(wechatOrderItemDBModel);
        }

        for (WechatPayDetailDBModel wechatPayDetailDBModel : wechatPayDetailDBModelList) {
            List<WechatPayDetailDBModel> wechatPayDetailDBModels = payMap.get(wechatPayDetailDBModel.fsorderno);
            if (wechatPayDetailDBModels == null) {
                wechatPayDetailDBModels = new ArrayList<>();
                payMap.put(wechatPayDetailDBModel.fsorderno, wechatPayDetailDBModels);
            }
            wechatPayDetailDBModels.add(wechatPayDetailDBModel);
        }

        for (WechatOrderModel wechatOrderModel : wechatOrderModelList) {
            wechatOrderModel.orderitem = itemMap.get(wechatOrderModel.fsorderno);
            wechatOrderModel.paydetail = payMap.get(wechatOrderModel.fsorderno);
        }

        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbwechatpaydetail " + params);
        int dataCount = StringUtil.toInt(countStr, 0);
        return new Pair<>(dataCount, wechatOrderModelList);
    }

    /**
     * 根据订单号读取订单信息
     *
     * @param fsorderno 订单号---订单信息
     * @return
     */
    public static WechatOrderModel getWechatOrderByNo(String fsorderno) {
        WechatOrderModel wechatOrderModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsorderno = '" + fsorderno + "'", WechatOrderModel.class);
        if (wechatOrderModel != null) {
            List<WechatOrderItemDBModel> wechatOrderItemDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fsorderno = '" + fsorderno + "'", WechatOrderItemDBModel.class);
            if (wechatOrderItemDBModelList == null) {
                wechatOrderItemDBModelList = new ArrayList<>();
            }
            List<WechatPayDetailDBModel> wechatPayDetailDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fsorderno = '" + fsorderno + "'", WechatPayDetailDBModel.class);
            if (wechatPayDetailDBModelList == null) {
                wechatPayDetailDBModelList = new ArrayList<>();
            }
            wechatOrderModel.paydetail = wechatPayDetailDBModelList;
            wechatOrderModel.orderitem = wechatOrderItemDBModelList;
        }
        return wechatOrderModel;
    }

    /**
     * 删除3天前的数据
     *
     * @param businessDate 营业日期 yyyy-MM-dd
     * @param day          天数 int  -3 ： 三天前
     */
    public static void deleteDatasByDate(String businessDate, int day) {
        try {
            String createTimeLimit = daysAgo(businessDate, day);
            String sql = "delete from " + DBModel.getTableName(WechatOrderDBModel.class) + " where fscreatetime < " + createTimeLimit;
            String sqlPay = "delete from " + DBModel.getTableName(WechatPayDetailDBModel.class) + " where fscreatetime < " + createTimeLimit;
            String sqlDetail = "delete from " + DBModel.getTableName(WechatOrderItemDBModel.class) + " where fscreatetime < " + createTimeLimit;
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlPay);
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlDetail);
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "清除三十天前的微信点餐数据出现异常" + e.getMessage(), "");
        }
    }

    private static String daysAgo(String smdate, int bdate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = Calendar.getInstance();
            cal.setTime(sdf.parse(smdate));
            cal.add(cal.DATE, bdate);
            Date date = cal.getTime();
            SimpleDateFormat targetFormat = new SimpleDateFormat(DateUtil.DATE_VISUAL14FORMAT);
            return targetFormat.format(date);
        } catch (Exception e) {
        }
        return smdate;
    }

    public static void productInitData() {
        String allCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbwechatorder");
        int count = StringUtil.toInt(allCount, 0);
        String data = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        for (int i = count; i < count + 5; i++) {
            WechatOrderDBModel wechatOrderDBModel = new WechatOrderModel();
            String fsorderno = String.valueOf(10000 + i);
            wechatOrderDBModel.fsorderno = fsorderno;
            wechatOrderDBModel.fistatus = i % 12;
            wechatOrderDBModel.fdrealamount = BigDecimal.TEN;
            wechatOrderDBModel.fdboxamount = BigDecimal.ONE;
            wechatOrderDBModel.fdsellamount = BizConstant.HUNDREND;
            wechatOrderDBModel.fsaddress = "中国上海市上海市徐汇区三江路" + i + "号";
            wechatOrderDBModel.fsremark = "少放盐";
            wechatOrderDBModel.fsmobile = "1585144660" + i;
            wechatOrderDBModel.fddistribution = BigDecimal.ZERO;
            wechatOrderDBModel.fsname = "张三点";
            wechatOrderDBModel.fscreatetime = data;

            wechatOrderDBModel.replaceNoTrans();

            for (int j = 0; j < 3; j++) {
                WechatOrderItemDBModel wechatOrderItemDBModel = new WechatOrderItemDBModel();
                wechatOrderItemDBModel.fsorderno = fsorderno;
                wechatOrderItemDBModel.fsseqno = j + "";
                wechatOrderItemDBModel.fsitemcode = j + "";
                if (j == 0) {
                    wechatOrderItemDBModel.fsitemcode = "1702130013";
                }
                wechatOrderItemDBModel.fiitemnum = BigDecimal.ONE;
                wechatOrderItemDBModel.fsitemname = "小炒" + j;
                wechatOrderItemDBModel.fdaddprice = BigDecimal.ONE;
                wechatOrderItemDBModel.fdsellamount = BigDecimal.TEN;
                wechatOrderItemDBModel.fdsubtotal = BigDecimal.TEN;
                wechatOrderItemDBModel.fsremark = "多肉肉";
                wechatOrderItemDBModel.fscreatetime = data;
                wechatOrderItemDBModel.replaceNoTrans();
            }

            WechatPayDetailDBModel wechatPayDetailDBModel = new WechatPayDetailDBModel();
            wechatPayDetailDBModel.fdpayamount = new BigDecimal(199);
            wechatPayDetailDBModel.fsorderno = fsorderno;
            wechatPayDetailDBModel.fipaystate = 1;
            wechatPayDetailDBModel.fipaytype = count % 7;
            wechatPayDetailDBModel.fscreatetime = data;
            wechatPayDetailDBModel.replaceNoTrans();
        }
    }

    /**
     * 检测订单是否已存在
     *
     * @param fsorderno
     * @return true:已存在
     */
    public static boolean isExist(String fsorderno) {
        String wechatOrderNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsorderno from tbwechatorder where fsorderno = '" + fsorderno + "'");
        if (TextUtils.isEmpty(wechatOrderNo)) {
            return false;
        }
        return true;
    }

    /**
     * 获取未处理微信外卖数量
     *
     * @return
     */
    public static int getUnDealWechatOrderCount() {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as wechatOrdercount from tbwechatorder where fistatus = '0' ");
        return StringUtil.toInt(count, 0);
    }

    /**
     * 获取微信外卖数量
     *
     * @return
     */
    public static int getWechatOrderCount() {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbwechatorder");
        return StringUtil.toInt(count, 0);
    }

    /**
     * 支付方式汇总
     *
     * @param date
     * @return
     */
    public static List<WechatPayInfoModel> caculatePayReport(String date) {
        if (TextUtils.isEmpty(date)) {
            date = DateUtil.getCurrentDate("yyyy-MM-dd");
        }

        /**
         * 完整sql = "selectfipaytype, sum(fdpayamount) amt from tbwechatpaydetail where fscreatetime like '" + date + "%' and fipaystate = 1 group by fipaytype"
         * 由于数据不全暂时不判断支付状态fipaystate
         */
        String sql = "select fipaytype, sum(fdpayamount) amt from tbwechatpaydetail where fscreatetime like '" + date + "%' and fipaystate = '1' group by fipaytype";
        List<WechatPayInfoModel> wechatPayInfoModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, WechatPayInfoModel.class);
        if (wechatPayInfoModels == null) {
            return new ArrayList();
        }
        return wechatPayInfoModels;
    }
}
