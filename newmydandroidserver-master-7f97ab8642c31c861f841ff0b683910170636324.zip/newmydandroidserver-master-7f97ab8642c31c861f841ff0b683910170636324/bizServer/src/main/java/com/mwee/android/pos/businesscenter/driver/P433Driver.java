package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.MetaDBController;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.localpush.PushMsgManager;
import com.mwee.android.pos.businesscenter.dbutil.PrintTaskDBUtil;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.GetAllP433ListResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created by huangming on 2018/5/24.
 */

public class P433Driver implements IDriver {

    private static final String TAG = "P433Driver";
    private static final long CHECK_HOST_CHANGE_SPACE = 60*1000;

    private long lastUploadTime ;
    private int changeHostCount = 0;

    private String lastHostId;
    private String lastStationId;

    /**
     *  更新基站对应的站点
     *
     */
    @DrivenMethod(uri = TAG + "/updateHostIdOfStation")
    public SocketResponse updateHostIdOfStation(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try{
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            String p433StationId = request.getString("p433StationId");
            String printerList = "";
            JSONObject p433Data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN,"select * from dataCache where type ='"+ IOCache.TYPE_P433+"'");
            if(p433Data == null || p433Data.size() == 0){
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,String.format("insert into dataCache(key,biz_key,value,info,type) values('%s','%s','%s','%s','%s')",IOCache.TYPE_P433,p433StationId,hostId,printerList,IOCache.TYPE_P433));
            }else{
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,"update dataCache set biz_key = '"+p433StationId+"' , value = '"+hostId+"' , info = '"+printerList+"' where type ='"+ IOCache.TYPE_P433+"' and key = '"+IOCache.TYPE_P433+"'");
            }
            LogUtil.logBusiness(TAG,"updateHostIdOfStation--更新有基站站点："+hostId+"，"+p433StationId);
            //当基站所在站点变化了，就去查询下433打印机未打印的和打印失败的，进行重打
            if(p433Data != null && !TextUtils.equals(p433Data.getString("value"),hostId)){
                query433PrintErrorTaskAndPrint(hostId);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }

    /**
     *  当基站信息变更后，在有基站的新站点上重新打印433打印失败的task
     * @param newHostId
     */
    private void query433PrintErrorTaskAndPrint(String newHostId){
        List<PrintTaskDBModel> errorPrintList = PrintTaskDBUtil.get433PrintErrorTask();
        if(ListUtil.isEmpty(errorPrintList)){
            return;
        }
        //是否是主站点
        boolean isCenterHost = TextUtils.equals(HostUtil.getCurrentHost(),newHostId);
        for (PrintTaskDBModel printTaskDBModel : errorPrintList) {
            if(printTaskDBModel == null){
                continue;
            }
            //以前打印失败的站点跟有基站的站点是不是同一个，不是，则给新站点发送打印失败的任务重打
            if(!TextUtils.equals(printTaskDBModel.fsHostId,newHostId)){
                printTaskDBModel.fsHostId = newHostId;
                PrintTaskDBUtil.updateHostIdOfTask(""+printTaskDBModel.fiPrintNo,newHostId);
                //主站点通过AIDL发送，副站点通过ALP
                if(isCenterHost){
                    printTaskDBModel.printAtOnce = true;
                    PrintConnector.getInstance().print(printTaskDBModel);
                }else{
                    NotifyToClient.printReceipt(newHostId, printTaskDBModel);
                    //TODO 需要将原先有基站的站点的打印失败的任务移除，不在重试，后面优化
//                    PushMsgManager.getInstance().sendTo(newHostId, "login/printReceipt",PushMsgManager.MessageType.TPYE_PRINTTASK,JSON.toJSONString(printTaskDBModel));
                }
                LogUtil.logBusiness(TAG,"query433PrintErrorTaskAndPrint--重新打印433打印失败的task："+printTaskDBModel.fiPrintNo+"，"+newHostId);
            }
        }
    }

    /**
     *  更新基站对应的打印机列表
     *
     */
    @DrivenMethod(uri = TAG + "/updatePrinterList")
    public SocketResponse updatePrinterList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try{
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            String p433StationId = request.getString("p433StationId");
            String p433Data = request.getString("printerList");
            P433DataManager.getInstance().setP433Data(p433Data);

            //socketResponse.data = 1 : 需要继续上送数据，0：不需要
            if(P433DataManager.getInstance().getRegistedHostSize() > 0){
                socketResponse.data = 1;
                //通知关心433数据的站点更新数据
                P433DataManager.getInstance().sendP433DataForAllHost(p433Data);
                LogUtil.log(TAG,"updatePrinterList--告诉基站站点需要上送数据，并将433数据下发注册站点");
            }else{
                socketResponse.data = 0;
                LogUtil.log(TAG,"updatePrinterList--告诉基站站点不需要上送数据");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }

    /**
     *  注册到需要433打印机数据列表
     *
     */
    @DrivenMethod(uri = TAG + "/registerNeedP433DataList")
    public SocketResponse registerNeedP433DataList(SocketHeader head, String param){
        SocketResponse socketResponse = new SocketResponse();
        try{
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            //如果此时基站都没有，则直接告诉站点，433无信号
            //socketResponse.data = 1 : 无基站，433无信号，0：有
            if(TextUtils.isEmpty(PrintConnector.getHostIdOfP433())){
                socketResponse.data = 1;
                LogUtil.logBusiness(TAG,"registerNeedP433DataList--告诉站点433无信号，"+hostId);
            }else{
                socketResponse.data = 0;
            }
            P433DataManager.getInstance().registerHost(hostId);
            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }

    /**
     *  反注册到需要433打印机数据列表
     *
     */
    @DrivenMethod(uri = TAG + "/unregisterNeedP433DataList")
    public SocketResponse unregisterNeedP433DataList(SocketHeader head, String param){
        SocketResponse socketResponse = new SocketResponse();
        try{
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            P433DataManager.getInstance().unregisterHost(hostId);

            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }



    /**
     * 检查商户终端是否插入多个打印机基站
     * @param hostId
     * @param p433StationId
     */
    private void checkStationStatus(String hostId,String p433StationId){
        if(lastUploadTime != 0){
            if(System.currentTimeMillis() - lastUploadTime > CHECK_HOST_CHANGE_SPACE){
                if(changeHostCount > 4){
                    ToastUtil.showToast("暂不支持插入多个打印机基站，请检查！");
                }
                lastUploadTime = System.currentTimeMillis();
                changeHostCount = 0;
            }else{
                if(!TextUtils.isEmpty(lastHostId) && !TextUtils.isEmpty(lastStationId)){
                    if(!TextUtils.equals(lastHostId,hostId) && !TextUtils.equals(lastStationId,p433StationId)){
                        changeHostCount ++;
                    }
                }
            }
        }else{
            lastUploadTime = System.currentTimeMillis();
        }
        lastHostId = hostId;
        lastStationId = p433StationId;
    }

    /**
     *  获取打印机列表
     *
     */
    @DrivenMethod(uri = TAG + "/get433PrinterList")
    public SocketResponse get433PrinterList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try{
            socketResponse.data = new GetAllP433ListResponse(PrintConnector.getAllPrinterList());
            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }

    /**
     *  更新433打印机PrinterSN
     *
     */
    @DrivenMethod(uri = TAG + "/updatePrinterSN")
    public SocketResponse updatePrinterSN(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try{
            JSONObject request = JSON.parseObject(param);
            String printerName = request.getString("printerName");
            String printerSN = request.getString("printerSN");
//            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN,"update tbPrinter set fsPrinterSN='" + printerSN + "' where fsPrinterName='" + printerName + "'");
//            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fsStr1='" + printerSN + "', sync = '1', fsupdateTime = '" + DateUtil.getCurrentTime() + "' where fsPrinterName='" + temp.fsPrinterName + "'");
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fsPrinterSN='" + printerSN + "', sync = '1', fsupdateTime = '" + DateUtil.getCurrentTime() + "'  where fsPrinterName='" + printerName + "'");
            //标志各个站点需要更新
            MetaDBController.updateSyncTime();
            //通知各个站点更新数据
            NotifyToClient.refreshAllPrinterStatus();
            socketResponse.code = SocketResultCode.SUCCESS;
        }catch (Exception e){
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e.getMessage());
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
