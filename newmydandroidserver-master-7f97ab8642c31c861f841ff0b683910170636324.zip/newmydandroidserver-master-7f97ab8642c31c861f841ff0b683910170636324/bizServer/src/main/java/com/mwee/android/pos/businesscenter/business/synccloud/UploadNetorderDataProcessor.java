package com.mwee.android.pos.businesscenter.business.synccloud;

import android.support.annotation.WorkerThread;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.component.datasync.net.UploadNetorderDataRequest;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderUploadBean;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * 数据上送的工具类
 */
public class UploadNetorderDataProcessor {
    /**
     * 当前是否有线程在上送数据
     */
    private static volatile boolean uploading = false;
    private static volatile ShopDBModel shopDBModel;

    private static synchronized void uploadFinish(String errorMsg) {
        uploading = false;
    }

    /**
     * 当前是否已经可以在唤起一个线程进行上送
     *
     * @return boolean | true：可以发起上送；false：已经有线程在上送了。
     */
    private static synchronized boolean canUpload() {
        if (!allowUpload()) {
            return false;
        }
        boolean c = !uploading;
        uploading = true;
        return c;
    }

    public static boolean allowUpload() {
        if (!BaseConfig.isProduct()) {
            //if (!TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
            if (!APPConfig.isCasiher() && !TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_UPLOAD), "1")) {
                //ServerService.sendSyncMessage(STATUS_FREE, "非生产包请手动开启上送功能");
                return false;
            }
        }
        if (!BindProcessor.isCurrentHostMain()) {
            return false;
        }
        return true;
    }

    /**
     * 开始上送订单，每张表读取20条数据,菜单表读取４０条数据上送，上送成功之后，再循环读取上送
     *
     * @return boolean | 是否进行上传
     */
    @Deprecated
    public static boolean startUploadAllLocalData(final IExecutorCallback callback) {
        if (!canUpload()) {
            return false;
        }

        BusinessExecutor.executeNoWait(() -> {
            IExecutorCallback checkLeft = new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    LogUtil.log("UploadNetorderDataProcessor 批量上送成功，开始检测待上送的数据");

                    BusinessExecutor.executeNoWait(() -> {
                        try {
                            Thread.sleep(200);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (hasMoreUnFinishedData()) {
                            startUploadAllLocalData(callback);
                        } else {
                            LogUtil.logBusiness("UploadNetorderDataProcessor 成功");
                            if (callback != null) {
                                callback.success(responseData);
                            }
                        }
                        return null;
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    if (callback != null) {
                        callback.fail(responseData);
                    }
                    return false;
                }
            };

            TempAppOrderUploadBean tempAppOrderUploadBean = optBean("");
            doUpload(checkLeft, tempAppOrderUploadBean);
            return null;
        });
        return true;
    }

    /**
     * 上送单个订单
     *
     * @param orderID String | orderID
     */
    @Deprecated
    public static void doUploadSingleNetOrder(final String orderID) {
        if (!canUpload()) {
            return;
        }

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadNetorderDataProcessor 上送单个订单:" + orderID);
                uploadSingleNetOrder(orderID);
            }
        });
        thread.setPriority(1);
        thread.start();
    }

    /**
     * 上送当前订单
     *
     * @param orderID String
     */
    @WorkerThread
    private static void uploadSingleNetOrder(final String orderID) {
        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadNetorderDataProcessor [" + orderID + "]");

        TempAppOrderUploadBean tempAppOrderUploadBean = optBean(orderID);

        doUpload(null, tempAppOrderUploadBean);
    }

    private static TempAppOrderUploadBean optBean(String orderId) {
        TempAppOrderUploadBean tempAppOrderUploadBean;
        if (TextUtils.isEmpty(orderId)) {
            tempAppOrderUploadBean = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempapporder where sync = '1' and  orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "' limit 1", TempAppOrderUploadBean.class);
        } else {
            tempAppOrderUploadBean = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempapporder where orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "' and orderid = '" + orderId + "'", TempAppOrderUploadBean.class);
        }

        if (tempAppOrderUploadBean == null) {
            return null;
        }

        if (shopDBModel == null) {
            shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop limit 1", ShopDBModel.class);
        }

        if (shopDBModel != null) {
            tempAppOrderUploadBean.shopGuid = shopDBModel.fsShopGUID;
            tempAppOrderUploadBean.shopName = shopDBModel.fsShopName;
            tempAppOrderUploadBean.companyGuid = shopDBModel.fsCompanyGUID;
        }
        if (!TextUtils.isEmpty(tempAppOrderUploadBean.sellDate)) {
            tempAppOrderUploadBean.sellDate = DateUtil.formartDateStrToTarget(tempAppOrderUploadBean.sellDate, DateUtil.DATE_VISUAL14FORMAT, "yyyy-MM-dd");
        }

//        int itemamt = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select sum(totalItemPrice) amt from tempapporderdetails where orderId = '" + tempAppOrderUploadBean.sellNo + "' "), 0);
        String sumAmt = DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, "select sum(totalItemPrice) amt from tempapporderdetails where orderId = '" + tempAppOrderUploadBean.sellNo + "' ");
        if(TextUtils.isEmpty(sumAmt)){
            sumAmt = "0";
        }
        BigDecimal totalAmt = new BigDecimal(sumAmt);
        if (totalAmt.compareTo(BigDecimal.ZERO) <= 0) {
            tempAppOrderUploadBean.itemAmount = tempAppOrderUploadBean.totalAmount;
        } else {
            tempAppOrderUploadBean.itemAmount = totalAmt;
        }

        return tempAppOrderUploadBean;
    }

    @WorkerThread
    private synchronized static void doUpload(final IExecutorCallback mainCallBack,
                                              TempAppOrderUploadBean tempAppOrderUploadBean) {
        UploadNetorderDataRequest request = new UploadNetorderDataRequest();

        RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadNetorderDataProcessor 上送数据");
        if (tempAppOrderUploadBean != null) {
            request.tbTakeawayDetail = JSON.toJSON(tempAppOrderUploadBean);

            BusinessCallback callback = new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {

                    DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "update tempapporder set sync = 0 where orderid = '" + tempAppOrderUploadBean.sellNo + "'");
                    RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadNetorderDataProcessor 上送数据成功；写入数据库");
                    uploadFinish("");
                    return true;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    uploadFinish(responseData.resultMessage);
                    RunTimeLog.addLog(RunTimeLog.BOOT_DATA_SEND, "UploadNetorderDataProcessor 上送数据失败,resultMessage=" + responseData.resultMessage);
                    return false;
                }
            };
            BusinessExecutor.execute(request, mainCallBack, callback, true);
        } else {
            uploadFinish("没有待同步的订单");
            if (mainCallBack != null) {
                mainCallBack.success(new ResponseData());
            }
        }

    }

    /**
     * 判断是否还有需要上送的数据
     *
     * @return boolean | true:还有需要上送的数据；false：没有了
     */
    public static boolean hasMoreUnFinishedData() {
        int count = calcUnfinishedDataCount();
        if (count > 0) {
            return true;
        }
        return false;
    }

    private static int calcUnfinishedDataCount() {
        String sql = "SELECT count(*) as count FROM tempapporder where sync = '1' and orderTakeawaySource='" + TakeAwaySource.MWMEITUAN + "'";
        int count = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql));

        LogUtil.log("UploadDataProcessor 上送检测 表[ tempapporder ]待上送的数据为：" + count);

        return count;
    }
}
