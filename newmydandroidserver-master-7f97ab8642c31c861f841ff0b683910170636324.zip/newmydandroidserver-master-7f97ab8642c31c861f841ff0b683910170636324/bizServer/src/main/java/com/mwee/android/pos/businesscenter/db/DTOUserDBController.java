package com.mwee.android.pos.businesscenter.db;

/**
 * Created by qinwei on 2019/3/11 8:54 PM
 * email: qin.wei@mwee.cn
 */
public class DTOUserDBController {

}
