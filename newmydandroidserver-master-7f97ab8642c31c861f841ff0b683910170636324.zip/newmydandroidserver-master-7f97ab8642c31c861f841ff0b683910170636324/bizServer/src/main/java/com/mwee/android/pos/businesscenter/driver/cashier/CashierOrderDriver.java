package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.GetCacheOrderListPosRequest;
import com.mwee.android.cashier.connect.bean.http.GetCacheOrderListPosResponse;
import com.mwee.android.cashier.connect.bean.http.GetMealNoPosRequest;
import com.mwee.android.cashier.connect.bean.http.GetMealNoPosResponse;
import com.mwee.android.cashier.connect.bean.http.GetReportListPosResponse;
import com.mwee.android.cashier.connect.bean.http.GetReportSevenPosRequest;
import com.mwee.android.cashier.connect.bean.http.GetReportSingleDayResponse;
import com.mwee.android.cashier.connect.bean.http.GetReportTodayPosRequest;
import com.mwee.android.cashier.connect.bean.http.GetReportYesterdayPosRequest;
import com.mwee.android.cashier.connect.bean.http.model.CashierTempOrder;
import com.mwee.android.cashier.connect.bean.socket.CashierReportResponse;
import com.mwee.android.cashier.connect.bean.socket.GenTempOrderResponse;
import com.mwee.android.cashier.connect.bean.socket.GetUnfinishedOrderCountResponse;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.business.order.DiscountBizUtil;
import com.mwee.android.pos.businesscenter.business.order.DishesBizUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.sync.ZipUtils;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 美收银的订单相关
 * Created by virgil on 2018/1/30.
 *
 * @author virgil
 */

@SuppressWarnings("unused")
public class CashierOrderDriver implements IDriver {

    /**
     * 生成一个缓存单
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/genTempOrder")
    public static SocketResponse<?> genTempOrder(SocketHeader head, String param) {
        SocketResponse<GenTempOrderResponse> socketResponse = new SocketResponse<>();
        try {
            UserDBModel user = HostUtil.getUserModelBySession(head.us);
            if (user == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                return socketResponse;
            }

            OrderCache orderCache = FastFoodBusinessUtil.createNewOrderCache("", user.fsUserId, user.fsUserName, HostBiz.CASHIER, "1");
            orderCache.businessDate = DateUtil.getCurrentDate("yyyy-MM-dd");
            orderCache.orderID = UUID.randomUUID().toString();
            orderCache.writeConfig(2);
            GetMealNoPosRequest genMealNoRequest = new GetMealNoPosRequest();
            BusinessExecutor.execute(genMealNoRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMealNoPosResponse) {
                        GetMealNoPosResponse response = (GetMealNoPosResponse) responseData.responseBean;
                        if (!TextUtils.isEmpty(response.data)) {
                            orderCache.mealNumber = response.data;
                            return;
                        }
                    }
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "获取牌号失败";
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    //返回失败在业务上也是正常情况
                    socketResponse.message = responseData.resultMessage;
                    return true;
                }
            }, false);
            if (socketResponse.success()) {
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "cashierOrder/genTempOrder");

                GenTempOrderResponse response = new GenTempOrderResponse();
                response.updateOrderCache(orderCache);
                socketResponse.data = response;
            }

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        if (socketResponse.data != null)
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "生成缓存单：" + socketResponse.data.toString());
        return socketResponse;
    }

    /**
     * 退菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/msyReturnDishes")
    public static SocketResponse msyReturnDishes(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        GenTempOrderResponse response = new GenTempOrderResponse();
        socketResponse.data = response;
        try {
            //订单ID
            JSONObject request = JSONObject.parseObject(param);
            String orderId = request.getString("orderID");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }
            //退菜内容
            List<VoidMenuItemModel> voidMenuItemModels = JSON.parseArray(request.getString("voidMenuItemModels"), VoidMenuItemModel.class);

            int result = DishesBizUtil.returnMenuItem(orderId, head.hd, "", userDBModel, voidMenuItemModels, new ArrayList<Integer>());
            if (result == 0) {
                response.temOrder = OrderSession.getInstance().getOrder(orderId);
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "退菜成功";
            } else if (result == -1) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已不存在，请稍后重试";
                return socketResponse;
            } else if (result == -2) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单号异常";
            } else if (result == -3) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已被结账";
            } else if (result == -4) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "退菜中包含菜品券，不允许退菜";
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 赠菜
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/msygiftDishes")
    public static SocketResponse msygiftDishes(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        GenTempOrderResponse response = new GenTempOrderResponse();
        socketResponse.data = response;
        try {
            //订单ID
            JSONObject request = JSONObject.parseObject(param);
            String orderId = request.getString("orderID");
            List<String> uniqList = JSON.parseArray(request.getString("uniqList"), String.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "未找到该订单，请回到桌台页重试";
                return socketResponse;
            }
            DiscountBizUtil.doDiscount(orderCache.originMenuList, orderCache.orderID, orderCache.fsmtableid, false, null, true,
                    false, 0, false, null, userDBModel, null, uniqList, -1, null);

            //重新计算价格
            orderCache.plusAllMenuAmount();
            //存入报表
            OrderSession.getInstance().writeOrder(orderId, true, "cashierOrder/msygiftDishes");
//            OrderProcessor.saveOrder(orderCache, null);

            response.temOrder = orderCache;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取所有未完成订单的列表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/getUnFinishedOrder")
    public static SocketResponse<?> getUnFinishedOrder(SocketHeader head, String param) {
        SocketResponse<GetUnfinishedOrderCountResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSONObject.parseObject(param);
            int pageIndex = request.getIntValue("pageIndex");
            String startDate = request.getString("startDate");
            String endDate = request.getString("endDate");
            GetCacheOrderListPosRequest posRequest = new GetCacheOrderListPosRequest();
            final GetUnfinishedOrderCountResponse response = new GetUnfinishedOrderCountResponse();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            posRequest.endDate = endDate;
            posRequest.startDate = startDate;
            posRequest.pageIndex = pageIndex;
            posRequest.pageSize = 5;
            BusinessExecutor.execute(posRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetCacheOrderListPosResponse) {
                        GetCacheOrderListPosResponse posResponse = (GetCacheOrderListPosResponse) responseData.responseBean;
                        for (CashierTempOrder cashierTempOrder : posResponse.data.list) {
                            cashierTempOrder.orderCache = JSON.parseObject(ZipUtils.unGzip(cashierTempOrder.orderInfo), OrderCache.class);
                            cashierTempOrder.orderCache.reCalcAllByAll();
                        }
                        response.data = posResponse.data.list;
                        response.pageNum = posResponse.data.pageNum;
                        response.pages = posResponse.data.pages;
                        socketResponse.code = SocketResultCode.SUCCESS;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);

            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取缓存单
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/getCachedOrder")
    public static SocketResponse<?> getCachedOrder(SocketHeader head, String param) {
        SocketResponse<GenTempOrderResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject jsonObject = JSON.parseObject(param);
            String orderID = jsonObject.getString("orderID");
            socketResponse = CashierOrderProcessor.getCachedOrderPos(orderID);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取报表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "cashierOrder/getReport")
    public static SocketResponse<?> getReport(SocketHeader head, String param) {
        SocketResponse<CashierReportResponse> socketResponse = new SocketResponse<>();
        try {
            final CashierReportResponse response = new CashierReportResponse();
            List<BaseRequest> requestList = new ArrayList<>(3);
            GetReportTodayPosRequest todayPosRequest = new GetReportTodayPosRequest();
            requestList.add(todayPosRequest);
            GetReportYesterdayPosRequest yesterdayPosRequest = new GetReportYesterdayPosRequest();
            requestList.add(yesterdayPosRequest);
            GetReportSevenPosRequest sevenPosRequest = new GetReportSevenPosRequest();
            requestList.add(sevenPosRequest);
            BusinessExecutor.execute(requestList, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.message = responseData.resultMessage;
                    socketResponse.code = responseData.result;
                    return false;
                }
            }, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null) {
                        if (responseData.responseBean instanceof GetReportSingleDayResponse) {
                            GetReportSingleDayResponse posResponse = (GetReportSingleDayResponse) responseData.responseBean;
                            if (i == 0) {
                                response.today = posResponse.data;
                            } else if (i == 1) {
                                response.yesterday = posResponse.data;
                            }
                            socketResponse.code = SocketResultCode.SUCCESS;
                        } else if (responseData.responseBean instanceof GetReportListPosResponse) {
                            GetReportListPosResponse posResponse = (GetReportListPosResponse) responseData.responseBean;
                            response.lastSeven = new ArrayList<>();
                            response.lastSeven.addAll(posResponse.data);
                            socketResponse.code = SocketResultCode.SUCCESS;
                        }
                        return true;
                    } else {
                        return false;
                    }

                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    socketResponse.code = responseData.result;
                    return false;
                }
            }, false);

            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return "cashierOrder";
    }

}
