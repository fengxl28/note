package com.mwee.android.pos.businesscenter.business.xmpp;

import android.content.Context;
import android.os.Process;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobStatus;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.dbutil.MessageBiz;
import com.mwee.android.pos.businesscenter.driver.MonitorDriver;
import com.mwee.android.pos.businesscenter.print.CheckAndPrintUtil;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.push.XMPPPushManager;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.db.sync.EncryptUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.log.LogUpload;
import com.mwee.myd.server.business.login.LoginApi;
import com.mwee.myd.server.business.login.LoginConstant;
import com.mwee.myd.server.business.login.entity.LoginPDModel;
import com.mwee.myd.server.business.login.entity.LoginPDResponse;

import org.jivesoftware.smack.packet.Message;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * XMPP相关的Driver
 * Created by virgil on 2017/2/21.
 */
@SuppressWarnings("unused")
public class XmppDriver implements IDriver {
    /**
     * 发起登录
     */
    @DrivenMethod(uri = "xmpp/dologin")
    public static void d() {
        if (!BindProcessor.isCurrentHostMain()) {
            return;
        }
        //做登录
        final ParamvalueDBModel paramvalueDBModel = BizInfoCollect.getAccount(APPConfig.DB_MAIN);
        if (paramvalueDBModel != null) {
            RunTimeLog.addLog(RunTimeLog.XMPP_LOGINPD_INFO, "中控账户： " + paramvalueDBModel.fsParamValue);
        }
        DBMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, "");

        if (paramvalueDBModel != null && !TextUtils.isEmpty(paramvalueDBModel.fsParamValue) && !TextUtils.isEmpty(paramvalueDBModel.fsStr1)) {
            final String account = paramvalueDBModel.fsParamValue.trim();
            LoginApi.doLogin(account, paramvalueDBModel.fsStr1.trim(), new BusinessCallback() {
                @Override
                public boolean success(int index, ResponseData responseData) {
                    DBMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, "");

                    if (responseData.responseBean != null) {
                        if (responseData.responseBean instanceof LoginPDResponse) {
                            final LoginPDResponse response = (LoginPDResponse) responseData.responseBean;


                            //http更改xmpp在线状态-异步方法,http请求state为“成功”
                            //xmpp保活老接口已废弃，不在调用
//                            LoginApi.postState("1");

                            loginPDSuccess(response, account);
                            return true;
                        }
                    }
                    loginPDFail(responseData.resultMessage);

                    return true;
                }

                @Override
                public boolean fail(int index, ResponseData responseData) {
                    loginPDFail(responseData.resultMessage);
                    //通知内容的准备
                    return false;
                }
            });
        } else {
            loginPDFail("美味账号、密码设置不正确");
        }
    }

    /**
     * 登录成功
     *
     * @param response LoginPDResponse
     * @param account  String | 中控账号
     */
    private static void loginPDSuccess(LoginPDResponse response, String account) {
        try {
            if (response != null) {
                LoginPDModel model = JSON.parseObject(response.data, LoginPDModel.class);
                if (model == null) {
                    return;
                }

                DBMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, model.SessionID);
                DBMetaUtil.updateSettingsValueByKey(META.XMPP_BBOX, model.Bbox);//Bbox->{0:关闭，1:开启}
                NotifyToClient.refreshSetting(String.valueOf(META.XMPP_BBOX), String.valueOf(model.Bbox));

                LogUpload.updateSessoin(model.SessionID);
                LogUpload.setHost(ClientMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID));
                LogUtil.setOnlineDebugMode("1".equals(String.valueOf(model.Bbox)));
                BizInfoCollect.setOnlineDebugMode("1".equals(String.valueOf(model.Bbox)));

                // 登录XMPP
                XMPPPushManager.updateAccount(account);
                JobScheudler.updateJobStatusByType(JobType.LOGINPD, JobStatus.FINISHED);
                //中控登录信息
                MessageBiz.addPDLoginSuccessMsg();
                NotifyToClient.addSystemLoginPDMessage(MessageConstance.TYPE_PD_LOGIN, model.SessionID);
                InfoCollect.collectDeviceStateInfo();
                //网络订单轮询
//            JobStackUtil.startJob();
            } else {
                loginPDFail("");
            }
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
    }

    /**
     * 中控登录失败
     *
     * @param error String | 登录失败的异常信息
     */
    private static void loginPDFail(String error) {
        DBMetaUtil.updateSettingsValueByKey(META.XMPP_SESSION_ID, "");
        //http更改xmpp在线状态-异步方法,http请求state为“失败”
        //xmpp保活老接口已废弃，不在调用
//        LoginApi.postState("0");
        if (TextUtils.isEmpty(error)) {
            error = "中控登录异常";
        }
        MessageBiz.addPDLoginErrorMsg(error);
        NotifyToClient.addSystemLoginPDMessage(MessageConstance.TYPE_PD_LOGIN, "-1");
        LogUtil.log(error);
        NotifyToClient.loingPDError(error);
        //中控登录失败
        JobScheudler.updateJobStatusByType(JobType.LOGINPD, JobStatus.PREPAREED);
        RunTimeLog.addLog(RunTimeLog.XMPP_LOGINPD_FAIL, error);
    }

    /**
     * 收到推送的消息
     *
     * @param pushMsg XmppMessage
     */
    @DrivenMethod(uri = "xmpp/recvmsg")
    public static void b(Message pushMsg) {
        PushListenerClient.receiveMsg(pushMsg);
    }

    /**
     * XMPP服务器返回账号登录冲突
     *
     * @param context Context
     */
    @DrivenMethod(uri = "xmpp/pushlogout")
    public static void c(Context context) {
        try {
            XMPPPushManager.updateAccount("");
            XMPPPushManager.stopConnect();
            //需要等待1分钟
            Thread.sleep(60 * 1000);
            d();
        } catch (Exception e) {
            LogUtil.logError(e);
        }
    }

    /**
     * XMPP收到秒点的推送
     *
     * @param commitID String
     */
    @DrivenMethod(uri = "xmpp/receiveRapidPush")
    public static void g(String commitID) {
        RunTimeLog.addLog(RunTimeLog.RAPID, "收到秒点相关信息监控：" + commitID);
        LogUtil.logBusiness("收到秒点相关信息监控：" + commitID);
        RapidBiz.receiveID(commitID);
    }

    @DrivenMethod(uri = "xmpp/receiveRapidPushV2")
    public static void g(RapidGetModel model) {
        RunTimeLog.addNowLog(RunTimeLog.RAPID, Process.myPid()+"收到秒点相关信息监控：" + model.fsid, model);

        if (!verifySign(model)) {
            return;
        }

        RapidBiz.receiveID(model);
    }

    /**
     * 秒点签名校验
     *
     * @param model
     * @return
     */
    private static boolean verifySign(RapidGetModel model) {
        String sign = null;
        String timestamp = model.fiTimestamp;
        if (!TextUtils.isEmpty(timestamp)) {
            String seed = DBMetaUtil.getSettingsValueByKey(META.SEED);
            sign = seed + "&" + model.fsid + "&" + timestamp;
            sign = EncryptUtil.MD5Purity(sign);
        }
        if (!TextUtils.isEmpty(sign) && !TextUtils.isEmpty(model.fsSign) && !TextUtils.equals(sign, model.fsSign)) {
            LogUtil.logBusiness("秒点签名不一致，不处理此次消息。\n本地加密签名: " + sign + "\n服务返回签名: " + model.fsSign);
            return false;
        }
        return true;
    }

    @DrivenMethod(uri = "xmpp/devEnvChange")
    public static void h(String url, String isTest, String xmppUrl) {
        Constant.setUrlRootTest(url);
        if (TextUtils.equals(isTest, "1")) {
            LoginConstant.setUrlRootTest(LoginConstant.URL_ROOT_TEST);
            DBMetaUtil.updateSettingsValueByKey(META.DEV_URL_PRODUCT, 0);
        } else {
            LoginConstant.setUrlRootTest(LoginConstant.URL_ROOT_PRODUCT);
            DBMetaUtil.updateSettingsValueByKey(META.DEV_URL_PRODUCT, 1);
        }
        XMPPPushManager.resetServerUrl(xmppUrl);
    }

    @DrivenMethod(uri = "xmpp/devXmppLog")
    public static void i() {
        XMPPPushManager.showLog = !TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.DEV_XMPP_LOG), "0");
    }

    /**
     * 唤起重打
     *
     * @param printNO  String | 打印序号
     * @param hostID   String | 打印任务的站点ID
     * @param userName String | 发起重打的用户名
     */
    @DrivenMethod(uri = "xmpp/reprint")
    public static void k(String printNO, String hostID, String userName) {
        PrintTaskDBModel taskDBModel = MonitorDriver.getTask(printNO, hostID);
        taskDBModel.fiStatus = 1;
        taskDBModel.titleRemind = "(重打-" + userName + ")";
        taskDBModel.manaualReprint = 1;
        CheckAndPrintUtil.buildTaskEnv(taskDBModel, true);
        taskDBModel.printAtOnce = true;
        NotifyToClient.rePrintReceipt(hostID, taskDBModel);
    }

    @DrivenMethod(uri = "xmpp/kds_reprint")
    public static void l(String printNO, String userName) {
        PrintTaskDBModel taskDBModel = MonitorDriver.getTask(printNO);
        taskDBModel.fiStatus = 1;
        taskDBModel.titleRemind = "(重打-" + userName + ")";
        taskDBModel.manaualReprint = 1;
        CheckAndPrintUtil.buildTaskEnv(taskDBModel, true);
        taskDBModel.printAtOnce = true;
        NotifyToClient.rePrintReceipt(taskDBModel.fsHostId, taskDBModel);
    }

    @Override
    public String getModuleName() {
        return "xmpp";
    }


}
