package com.mwee.android.pos.businesscenter.dbutil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.TableConstans;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.setting.SettingConfig;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.localpush.SimpleData;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AreaBizDBModel;
import com.mwee.android.pos.db.business.BillChangeDetailDBModel;
import com.mwee.android.pos.db.business.ChangeTableDBModel;
import com.mwee.android.pos.db.business.ItemChangeTableDBModel;
import com.mwee.android.pos.db.business.MareaDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.TableChangeDetailDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.table.AreaBizSimpleModel;
import com.mwee.android.pos.db.business.table.MtableSimpleModel;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.db.business.table.TableBizSimpInfo;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.db.business.table.TableStatusSimpleBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 桌台相关的操作类
 * Created by virgil on 2016/10/9.
 */

public class TableDBUtil {

    /**
     * 写入 转桌/合桌/转菜 记录
     *
     * @param originalOrderId   原始订单号
     * @param targetOrderId     目标订单号
     * @param originalTableId   原始桌台Id
     * @param targetTableId     目标桌台Id
     * @param originalTableName 原始桌台名称
     * @param targetTableName   目标桌台名称
     * @param originalAreaId    原始餐区Id
     * @param targetAreaId      目标餐区Id
     * @param originalAreaName  原始餐区名称
     * @param targetAreaName    目标餐区名称
     * @param businessDate      营业日期
     * @param operationKind     操作类型(1:整桌转台 2:部分转菜 3:整桌并台）
     * @param menuItemList      被操作的菜品列表
     * @param operationUser     操作人
     */
    public static void writeTableChanged(String originalOrderId, String targetOrderId,
                                         String originalTableId, String targetTableId, String originalTableName, String targetTableName,
                                         String originalAreaId, String targetAreaId, String originalAreaName, String targetAreaName,
                                         String businessDate, int operationKind, List<MenuItem> menuItemList, UserDBModel operationUser) {
        TableChangeDetailDBModel tableChange = new TableChangeDetailDBModel();
        tableChange.seq = UUIDUtil.optUUID();
        tableChange.shop_guid = HostUtil.getShopID();
        tableChange.company_guid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsCompanyGUID from tbShop where fsShopGUID = '" + tableChange.shop_guid + "'");
        tableChange.sell_date = businessDate;
        // 操作类型(1:整桌转台 2:部分转菜 3:整桌并台）
        tableChange.create_kind = operationKind;
        tableChange.fsSellNo = targetOrderId;
        tableChange.table_id = targetTableId;
        tableChange.table_name = targetTableName;
        tableChange.area_id = targetAreaId;
        tableChange.area_name = targetAreaName;
        tableChange.origin_sell_no = originalOrderId;
        tableChange.origin_table_id = originalTableId;
        tableChange.origin_table_name = originalTableName;
        tableChange.origin_area_id = originalAreaId;
        tableChange.origin_area_name = originalAreaName;
        if (operationUser != null) {
            tableChange.create_user_id = operationUser.fsUserId;
            tableChange.create_user_name = operationUser.fsUserName;
        }
        tableChange.create_time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        tableChange.lver = 1;
        tableChange.pver = 0;
        tableChange.replaceNoTrans();

        // 存菜品明细操作记录
        if (!ListUtil.isEmpty(menuItemList)) {
            for (MenuItem item : menuItemList) {
                if (item == null || DinnerStandardUtil.isStandardMenu(item.itemID)) {
                    return;
                }
                writeMenuTurned(tableChange.seq, businessDate, targetOrderId, item);
                if (!ListUtil.isEmpty(item.menuBiz.selectedPackageItems)) {
                    for (MenuItem packageItem : item.menuBiz.selectedPackageItems) {
                        writeMenuTurned(tableChange.seq, businessDate, targetOrderId, packageItem);
                    }
                }
                if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
                    for (MenuItem modifier : item.menuBiz.selectedModifier) {
                        writeMenuTurned(tableChange.seq, businessDate, targetOrderId, modifier);
                    }
                }
            }
        }
    }

    /**
     * 写入 转桌/合桌/转菜 时菜品明细记录
     *
     * @param seq           对应 转桌/合桌/转菜 的seq
     * @param targetOrderId 目标订单号
     * @param menuItem      被操作的菜品
     */
    private static void writeMenuTurned(String seq, String businessDate, String targetOrderId, MenuItem menuItem) {
        BillChangeDetailDBModel menuChange = new BillChangeDetailDBModel();
        menuChange.seq = seq;
        menuChange.sell_date = businessDate;
        menuChange.fsSellNo = targetOrderId;
        if (menuItem != null) {
            menuChange.item_cd = menuItem.itemID;
            menuChange.item_id = menuItem.fsItemId;
            menuChange.item_name = menuItem.name;
            if (menuItem.currentUnit != null) {
                menuChange.order_unit_id = menuItem.currentUnit.fiOrderUintCd;
                menuChange.order_unit_name = menuItem.currentUnit.fsOrderUint;
            }
            // fiItemKind--菜品种类；1单品 2套餐头,4 配料
            String fiOrderItemKind = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiOrderItemKind from tbSellOrderItem where fsSeq='" + menuItem.menuBiz.uniq + "'");
            if (!TextUtils.isEmpty(fiOrderItemKind)) {
                // order_item_kind--1:单品 2：套餐头 3：套餐明细 4：配料
                menuChange.order_item_kind = StringUtil.toInt(fiOrderItemKind);
            }
            if (menuItem.menuBiz != null) {
                menuChange.change_qty = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                menuChange.change_amt = menuItem.menuBiz.totalPrice;
            }
        }
        menuChange.lver = 1;
        menuChange.pver = 0;
        menuChange.replaceNoTrans();
    }

    /**
     * 批量添加转菜记录
     *
     * @param orderId      来源订单号
     * @param orderIdNew   目标订单号
     * @param mTableId     来源桌台号
     * @param mTableIdNew  目标桌台号
     * @param transferList 转菜列表
     * @param reason       转菜理由
     * @param userName     操作用户名称
     * @param shopGUID     门店GUID
     */
    public static void addItemChangeTable(String orderId, String orderIdNew, String mTableId, String mTableIdNew, List<MenuItem> transferList, String reason, String userName, String shopGUID) {
        if (ListUtil.isEmpty(transferList)) {
            return;
        }
        for (MenuItem menu : transferList) {
            addItemChangeTable(orderId, orderIdNew, mTableId, mTableIdNew, menu, reason, userName, shopGUID);
        }
    }

    /**
     * 添加单个菜品转菜记录
     *
     * @param orderId     来源订单号
     * @param orderIdNew  目标订单号
     * @param mTableId    来源桌台号
     * @param mTableIdNew 目标桌台号
     * @param menuItem    转菜信息
     * @param reason      转菜理由
     * @param userName    操作用户名称
     * @param shopGUID    门店GUID
     */
    public static void addItemChangeTable(String orderId, String orderIdNew, String mTableId, String mTableIdNew, MenuItem menuItem, String reason, String userName, String shopGUID) {
        ItemChangeTableDBModel itemChangeTableDBModel = new ItemChangeTableDBModel();
        itemChangeTableDBModel.fsSellNo = orderId;
        itemChangeTableDBModel.fsSellNo_new = orderIdNew;
        itemChangeTableDBModel.fsMTableId = mTableId;
        itemChangeTableDBModel.fsMTableId_new = mTableIdNew;
        itemChangeTableDBModel.fiItemCd = menuItem.itemID;
        itemChangeTableDBModel.fsItemId = menuItem.fsItemId;
        itemChangeTableDBModel.fsItemName = menuItem.name;
        itemChangeTableDBModel.fsSeq = menuItem.menuBiz.uniq;
        itemChangeTableDBModel.fdChangeQty = menuItem.menuBiz.buyNum.toPlainString();
        itemChangeTableDBModel.fsChangeReason = reason;
        itemChangeTableDBModel.fsCreateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        itemChangeTableDBModel.fsCreateUserName = userName;
        itemChangeTableDBModel.fsShopGUID = shopGUID;
        itemChangeTableDBModel.lver = 1;
        itemChangeTableDBModel.pver = 0;
        itemChangeTableDBModel.replaceNoTrans();
    }

    /**
     * 添加换桌、合桌记录
     *
     * @param orderId     来源订单号
     * @param mTableId    来源桌台号
     * @param mTableIdNew 目标桌台号
     * @param reason      换桌理由
     * @param userName    操作用户名称
     * @param shopGUID    门店GUID
     */
    public static void addChangeTable(String orderId, String mTableId, String mTableIdNew, String reason, String userName, String shopGUID) {
        ChangeTableDBModel changeTableDBModel = new ChangeTableDBModel();
        changeTableDBModel.fsSellNo = orderId;
        changeTableDBModel.fsMTableId = mTableId;
        changeTableDBModel.fsMTableId_new = mTableIdNew;
        changeTableDBModel.fiTimes = 1;
        changeTableDBModel.fsChangeReason = reason;
        changeTableDBModel.fsCreateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        changeTableDBModel.fsCreateUserName = userName;
        changeTableDBModel.fsShopGUID = shopGUID;
        changeTableDBModel.lver = 1;
        changeTableDBModel.pver = 0;
        changeTableDBModel.replaceNoTrans();
    }

    /**
     * 获取所有拼出的桌台信息
     *
     * @return
     */
    public static List<MtableDBModel> getAllHintTables() {

        List<MtableDBModel> dataList = getAllDeleteBizTables();

        String sql = "select fsmtablename, fsmtableid, " +  //桌台名称, 桌台ID
                " fiseats, fsmareaid, fshint, fiSortOrder " + // 座位数, 所在区域
                "from tbmtable where fiStatus = '2' and fsmareaid not in (" +
                " select fsmareaid from tbmarea where fiStatus <> '1'  )" +
                " order by fsMAreaId, fiSortOrder, fsMTableName";
        List<MtableDBModel> statusBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        if (!ListUtil.isEmpty(statusBeanList)) {
            dataList.addAll(statusBeanList);
        }
        return dataList;
    }

    /**
     * 获取所有拼出的桌台信息--简化版
     *
     * @return
     */
    public static List<MtableSimpleModel> getAllHintTablesSimple() {
        List<MtableSimpleModel> dataList = getAllDeleteBizTablesSimple();

        String sql = "select fsmtablename, fsmtableid, " +  //桌台名称, 桌台ID
                " fiseats, fsmareaid, fshint, fiSortOrder " + // 座位数, 所在区域
                "from tbmtable where fiStatus = '2' and fsmareaid not in (" +
                " select fsmareaid from tbmarea where fiStatus <> '1'  )" +
                " order by fsMAreaId, fiSortOrder, fsMTableName";
        List<MtableSimpleModel> statusBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableSimpleModel.class);
        if (!ListUtil.isEmpty(statusBeanList)) {
            dataList.addAll(statusBeanList);
        }

        return dataList;
    }

    /**
     * 获取所有已被删除的营业中的桌台
     *
     * @return
     */
    public static List<MtableDBModel> getAllDeleteBizTables() {
        String bizTableIdsql = "select fsmtableid from tablebiz where fsmtablesteid = '2'";

        List<String> bizTableIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, bizTableIdsql);
        if (ListUtil.isEmpty(bizTableIdList)) {
            return new ArrayList<>();
        }

        String bizTableIds = ListUtil.optSqlParams(bizTableIdList);

        String hintTableFatherId = "select fshint from tbmtable where fistatus = '2' and fsmtableid in (" + bizTableIds + ")";

        List<String> hintTableFatherList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, hintTableFatherId);
        if (!ListUtil.isEmpty(hintTableFatherList)) {
            bizTableIdList.addAll(hintTableFatherList);
        }
        bizTableIds = ListUtil.optSqlParams(bizTableIdList);

        String sql = "select fsmtablename, fsmtableid, fiseats, fsmareaid, fshint, fiSortOrder from tbmtable where fistatus in ('9','13') and fsmtableid in (" + bizTableIds + ")";
        List<MtableDBModel> bizTables = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        if (bizTables == null) {
            bizTables = new ArrayList<>();
        }
        return bizTables;
    }

    /**
     * 获取所有已被删除的营业中的桌台--简化版
     *
     * @return
     */
    public static List<MtableSimpleModel> getAllDeleteBizTablesSimple() {
        String bizTableIdsql = "select fsmtableid from tablebiz where fsmtablesteid = '2'";

        List<String> bizTableIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, bizTableIdsql);
        if (ListUtil.isEmpty(bizTableIdList)) {
            return new ArrayList<>();
        }

        String bizTableIds = ListUtil.optSqlParams(bizTableIdList);

        String hintTableFatherId = "select fshint from tbmtable where fistatus = '2' and fsmtableid in (" + bizTableIds + ")";

        List<String> hintTableFatherList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, hintTableFatherId);
        if (!ListUtil.isEmpty(hintTableFatherList)) {
            bizTableIdList.addAll(hintTableFatherList);
        }
        bizTableIds = ListUtil.optSqlParams(bizTableIdList);

        String sql = "select fsmtablename, fsmtableid, fiseats, fsmareaid, fshint, fiSortOrder from tbmtable where fistatus in ('9','13') and fsmtableid in (" + bizTableIds + ")";
        List<MtableSimpleModel> bizTables = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableSimpleModel.class);
        if (bizTables == null) {
            bizTables = new ArrayList<>();
        }
        return bizTables;
    }

    /**
     * 获取所有桌台业务---仅返回有业务的桌台
     * 数据筛选条件：已开台或有服务铃或有秒点单信息
     *
     * @return 返回信息：是否有支付信息 int|>0有支付信息 <= 0 无支付 桌台占用标识; 云端交互信息标识, 订单来源,业务表示(服务铃,秒点单), 额外订单数据(秒点单)
     */
    public static List<TableStatusBean> getAllTableStatus() {
        String sql = "select IFNULL(payInfo.hasPayInfo, 0) hasPayInfo,tbsell.thirdOrderType, tbsell.fdExpAmt,tbsell.fiCustSum, tableBiz.* from tableBiz left outer join tbsell on tableBiz.fssellno=tbsell.fssellno left join (select fsSellNo, count(*) as hasPayInfo from tbSellReceive where fiStatus <> '13' and isCouponMoney <> '1' group by fssellno ) as payInfo on payInfo.fssellno=tbsell.fssellno where fsmtablesteid = '2' or extra_order <> '' or ((flag & 2) == 2) or ((flag & 4) == 4)";
        List<TableStatusBean> statusBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TableStatusBean.class);
        return statusBeanList;
    }

    /**
     * 获取所有桌台业务---仅返回有业务的桌台
     * 数据筛选条件：已开台或有服务铃或有秒点单信息
     *
     * @return 返回信息：是否有支付信息 int|>0有支付信息 <= 0 无支付 桌台占用标识; 云端交互信息标识, 订单来源,业务表示(服务铃,秒点单), 额外订单数据(秒点单)
     */
    public static List<TableStatusSimpleBean> getAllTableStatusSimple() {
        String sql = "select IFNULL(payInfo.hasPayInfo, 0) hasPayInfo,tbsell.thirdOrderType, tbsell.fdExpAmt,tbsell.fiCustSum, tableBiz.* from tableBiz left outer join tbsell on tableBiz.fssellno=tbsell.fssellno left join (select fsSellNo, count(*) as hasPayInfo from tbSellReceive where fiStatus <> '13' and isCouponMoney <> '1' group by fssellno ) as payInfo on payInfo.fssellno=tbsell.fssellno where fsmtablesteid = '2' or extra_order <> '' or ((flag & 2) == 2) or ((flag & 4) == 4)";
        List<TableStatusSimpleBean> statusBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TableStatusSimpleBean.class);
        return statusBeanList;
    }

    /**
     * 获取各个区域未读消息数量
     *
     * @return Map<区域ID                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ，                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               该区域消息数量>  | all--->消息总和
     */
    public static synchronized ArrayMap<String, Integer> getAllAreasMessage() {
        /* 统计消息数 */
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                //更新BD
                ContentValues values = new ContentValues();
                values.put("wxMsgCount", 0);
                db.update(DBModel.getTableName(MareaDBModel.class), values, null, null);
                return true;
            }
        });
        /* 更新有服务铃或秒点单未读通知的餐区消息数, 需优化 */
        /* 服务铃、秒点单，任有其一的餐桌数 */
        String sqlone = "select tbMArea.*, count(*) as wxMsgCount from tbMArea, tableBiz where tbMArea.fsMAreaId = " +
                "tableBiz.fsmareaid and ((tableBiz.flag & 2) = 2 or (tableBiz.flag & 4) = 4) group by " +
                "tbMArea.fsMAreaId";
        List<MareaDBModel> msgone = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlone, MareaDBModel.class);

        /* 服务铃、秒点单 都有的餐桌数 */
        String sqlBoth = "select tbMArea.*, count(*) as wxMsgCount from tbMArea, tableBiz where tbMArea.fsMAreaId = " +
                "tableBiz.fsmareaid and ((tableBiz.flag & 2) = 2 and (tableBiz.flag & 4) = 4) group by " +
                "tbMArea.fsMAreaId";
        List<MareaDBModel> msgboth = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlBoth, MareaDBModel.class);

        if (!ListUtil.isEmpty(msgone)) {
            for (final MareaDBModel model : msgone) {
                if (!ListUtil.isEmpty(msgboth)) {
                    for (MareaDBModel mareaDBModel : msgboth) {
                        if (TextUtils.equals(model.fsMAreaId, mareaDBModel.fsMAreaId)) {
                            model.wxMsgCount += mareaDBModel.wxMsgCount;
                        }
                    }
                }
                DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                    @Override
                    public Boolean doJob(SQLiteDatabase db) {
                        //更新BD
                        ContentValues values = new ContentValues();
                        values.put("wxMsgCount", model.wxMsgCount);
                        db.update(DBModel.getTableName(MareaDBModel.class), values, "fsMAreaId='" + model.fsMAreaId + "'", null);
                        return true;
                    }
                });
            }
        }

        String sql = "select * from " + DBModel.getTableName(MareaDBModel.class) + " where fiStatus = '1' order by fiSortOrder ";//根据fiSortOrder（后台可配置）字段进行排序
        List<MareaDBModel> mareaDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MareaDBModel.class);
        if (mareaDBModelList == null) {
            mareaDBModelList = new ArrayList<>();
        }

        ArrayMap<String, Integer> areaMessage = new ArrayMap<>();

        if (mareaDBModelList.size() > 0) {
            areaMessage.put("all", getAllMessageCount());
        }

        for (MareaDBModel mareaDBModel : mareaDBModelList) {
            areaMessage.put(mareaDBModel.fsMAreaId, mareaDBModel.wxMsgCount);
        }

        return areaMessage;
    }

    /**
     * 获取所有未读消息数量
     *
     * @return
     */
    public static int getAllMessageCount() {
        String sql = "select sum(wxmsgcount) as sumCount from tbMArea";
        return DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "sumCount", Integer.class);
    }

    /**
     * 开台
     *
     * @param fsmtableid  桌台ID
     * @param orderId     订单ID
     * @param userDBModel 操作用户
     */
    protected static void openTable(final String fsmtableid, final String orderId, final UserDBModel userDBModel) {
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                //更新BD
                try {
                    ContentValues values = new ContentValues();
                    values.put("fsopenhstime", DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT));
                    values.put("fssellno", orderId);
                    values.put("fsmtablesteid", TableConstans.TABLE_STATUS_OPEN);
                    values.put("fsupdatetime", DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
                    if (userDBModel != null) {
                        values.put("fsopenusername", userDBModel.fsUserName);
                        values.put("fsupdateusername", userDBModel.fsUserName);
                        values.put("fsupdateuserid", userDBModel.fsUserId);
                    }
                    db.update(DBModel.getTableName(TableBizModel.class), values, " fsmtableid = '" + fsmtableid + "'", null);
                } catch (Exception e) {
                    LogUtil.logError(e);
                }
                return true;
            }
        });
    }


    public static TableBizModel optDefaultTableBizModel(String fsmtableid) {
        checkTableBizxists(fsmtableid);
        return TableDBUtil.getTableBizModelById(fsmtableid);
    }

    public static boolean isOpenStatus(String fsmtableId) {
        TableBizModel tableBizModel = optDefaultTableBizModel(fsmtableId);
        if (tableBizModel != null) {
            return TextUtils.equals(tableBizModel.fsmtablesteid, TableConstans.TABLE_STATUS_OPEN);
        }
        return false;
    }

    /**
     * 根据桌台ID获取订单号
     *
     * @param fsmtableid String
     * @return String
     */
    public static String optOrderIDByTableID(String fsmtableid) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tableBiz where fsmtableid='" + fsmtableid + "'");
    }

    /**
     * 检查桌台业务是否存在
     * 不存在：插入一条记录
     *
     * @param tableId 桌台ID
     * @return
     */
    public static void checkTableBizxists(String tableId) {
        if (TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableId from tableBiz where fsmtableId = '" + tableId + "'"))) {
            TableBizModel tableStatusBean = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbMtable where fsmtableId = '" + tableId + "'", TableBizModel.class);
            if (tableStatusBean != null) {
                tableStatusBean.replaceNoTrans();
            }
        }
    }

    /**
     * 填充更新桌台信息的用户和时间
     *
     * @param newTable    MtableDBModel
     * @param userDBModel UserDBModel
     */
    public static void fillUpdateTableInfo(MtableDBModel newTable, UserDBModel userDBModel) {
        if (userDBModel != null) {
            newTable.fsupdateusername = userDBModel.fsUserName;
            newTable.fsupdatetime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            newTable.fsupdateuserid = userDBModel.fsUserId;
        }
    }

    /**
     * 填充更新桌台信息的用户和时间
     *
     * @param newTable    MtableDBModel
     * @param userDBModel UserDBModel
     */
    public static void fillUpdateTableInfo(TableBizModel newTable, UserDBModel userDBModel) {
        if (userDBModel != null) {
            newTable.fsupdateusername = userDBModel.fsUserName;
            newTable.fsupdatetime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
            newTable.fsupdateuserid = userDBModel.fsUserId;
        }
    }

    /**
     * 通过桌子ID查找桌子信息
     *
     * @param tableID String  桌台ID
     * @return MtableDBModel  桌子Model；如果桌子不存在，返回null
     */
    public static MtableDBModel getMTableById(String tableID) {
        String sql = "select * from " + DBModel.getTableName(MtableDBModel.class) + " where fistatus in (1,2) and fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    /**
     * 通过桌子ID查找桌子信息
     *
     * @param tableID String  桌台ID
     * @return MtableDBModel  桌子Model；如果桌子不存在，返回null
     */
    public static MtableDBModel getMTableByIdWithDelete(String tableID) {
        String sql = "select * from " + DBModel.getTableName(MtableDBModel.class) + " where fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    /**
     * 根据桌台ID获取桌台名称
     *
     * @param tableID String 桌台ID
     * @return String  桌台名称
     */
    public static String getTableNameById(String tableID) {
        String sql = "select fsmtablename from tbmtable where fistatus in (1,2) and fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "fsmtablename", String.class);
    }

    /**
     * 通过桌子ID查找桌子信息---包含有订单信息的已删除桌台
     *
     * @param tableID String  桌台ID
     * @return MtableDBModel  桌子Model；如果桌子不存在，返回null
     */
    public static MtableDBModel getMTableContantDeleteDataById(String tableID) {
        String sql = "select * from " + DBModel.getTableName(MtableDBModel.class) + " left join tablebiz on tablebiz.fsmtableid = tbmtable.fsmtableid where (tbmtable.fistatus in (1,2) or tablebiz.fsmtablesteid = '2') and tableBiz.fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    /**
     * 根据桌台名称获取桌台ID
     *
     * @param tableName String 桌台名称
     * @return String  桌台ID
     */
    public static String getTableIDByName(String tableName) {
        String sql = "select fsmtableid  from tbmtable where fiStatus in (1,2) and fsmtablename = '" + tableName + "'";
        return DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "fsmtableid", String.class);
    }

    /**
     * 判断某桌台是否存在
     *
     * @param tableID 桌台ID
     * @return boolean true:存在 | false:不存在
     */
    public static boolean checkTableExist(String tableID) {
        String sql = "select fsmtableid from tbmtable where fiStatus in (1,2) and fsmtableid = '%s'";
        String id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, tableID));
        return !TextUtils.isEmpty(id);
    }

    /**
     * 获取桌台业务Model
     *
     * @param tableID 桌台ID
     * @return TableBizModel 桌台业务对象
     */
    public static TableBizModel getTableBizModelById(String tableID) {
        String sql = "select * from " + DBModel.getTableName(TableBizModel.class) + " where fsmtableid = '" + tableID + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, TableBizModel.class);
    }

    /**
     * 获取所有桌台业务Model
     *
     * @return TableBizModel 桌台业务对象
     */
    public static List<TableBizModel> getTableBizModel() {
        String sql = "select * from " + DBModel.getTableName(TableBizModel.class) + " where fistatus <> '13' ";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TableBizModel.class);
    }

    /**
     * 获取所有桌台业务Model
     *
     * @return TableBizModel 桌台业务对象
     */
    public static List<TableBizSimpInfo> getTableSimpleInfoModel() {
        String sql = "select * from " + DBModel.getTableName(MtableDBModel.class) + " where fistatus <> '13' order by fiSortOrder asc, fsmtablename asc";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, TableBizSimpInfo.class);
    }

    /**
     * 获取桌台业务状态
     *
     * @param tableID 桌台ID
     * @return TableStatusBean 桌台业务状态
     */
    public static TableStatusBean getTableStatusById(String tableID) {
        String sql = "select tbsell.fdExpAmt,tbsell.fiCustSum, tableBiz.* " + //占用标识; 云端交互信息标识, 订单来源,业务表示(服务铃,秒点单), 额外订单数据(秒点单)
                "from tableBiz left outer join tbsell on tableBiz.fssellno=tbsell.fssellno where tableBiz.fsmtableid = '" + tableID + "'";
        TableStatusBean statusBeanList = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, TableStatusBean.class);
        return statusBeanList;
    }

    /**
     * 新桌台插入数据库, 自然桌的拼桌数累计加一
     *
     * @param newTable MtableDBModel
     */
    public static void sumbmitShareTable(MtableDBModel newTable, UserDBModel userDBModel) {

        updateTablebills(newTable.fshint);

        newTable.fistatus = 2;
        newTable.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        newTable.fsupdateuserid = userDBModel.fsUserId;
        newTable.fsupdateusername = userDBModel.fsUserName;
        newTable.replaceNoTrans();
    }

    /**
     * 更新拼桌数
     *
     * @param fsmtableid 桌台ID
     */
    public static void updateTablebills(final String fsmtableid) {
        if (TextUtils.isEmpty(fsmtableid)) {
            return;
        }
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                db.execSQL("update tbmtable set fisharebills = (fisharebills + 1) where fsmtableid = '" + fsmtableid + "'");
                return true;
            }
        });
    }

    /**
     * 获取桌台上的秒点单信息
     *
     * @param tableID 桌台ID
     * @return TempOrderDishesCache 秒点单信息
     */
    public static TempOrderDishesCache getTempOrderByTableId(String tableID) {
        String sql = "select extra_order from " + DBModel.getTableName(TableBizModel.class) + " where fistatus in (1,2) and fsmtableid = '" + tableID + "'";
        String extraOrder = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sql, "extra_order", String.class);
        TempOrderDishesCache tempOrder = null;
        try {
            tempOrder = JSON.parseObject(extraOrder, TempOrderDishesCache.class);
        } catch (Exception e) {
            LogUtil.logError(e);
        }
        return tempOrder;
    }

    /**
     * 释放桌台
     * 将桌台业务置为未开台、订单号为空、还原预结账单打印状态
     * 桌台业务不能直接删除、可能有秒点信息或者锁桌信息
     *
     * @param tableID 桌台ID
     */
    public static void releaseTableBizById(String tableID) {
        String updateSql = "update tableBiz set fsmtablesteid = '1', fssellno = '',prePayFlag = '0', fioccupyflag = '0' where fsmtableid = '" + tableID + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateSql);
    }

    /**
     * 解鎖桌台
     *
     * @param tableBizModel
     */
    public static void unlocakTable(TableBizModel tableBizModel) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where fsmtableid='" + tableBizModel.fsmtableid + "' ");
    }

    /**
     * 锁桌
     *
     * @param targetTableID   桌台ID
     * @param requestHostID   请求锁桌的站点
     * @param requestUserID   收银员ID
     * @param requestUserName 收银员名称
     */
    protected static void lockTable(String targetTableID, String requestHostID, String requestUserID, String requestUserName, boolean needUnlockOthers) {
        if (needUnlockOthers) {
            //鎖桌前释放当前站点下的其他桌台
            TableDBUtil.unlockTableByHostId(requestHostID);
        }

        checkTableBizxists(targetTableID);
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='1',lockedUserID='" + requestUserID +
                "',lockedHostId='" + requestHostID + "',lockedUserName='" + requestUserName + "' where fsmtableid='" + targetTableID + "' ");
    }

    /**
     * 解锁某服务员锁住的所有桌台
     *
     * @param userID 服务员ID
     */
    public static void unlocakAllTableByUser(String userID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where lockedUserID='" + userID + "' ");
    }

    /**
     * 根据桌台ID解锁指定桌台
     *
     * @param targetTableID 桌台ID
     */
    public static void unlockTableById(String targetTableID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where fsmtableid='" + targetTableID + "'");
    }

    /**
     * 解锁某站点锁住的所有桌台
     *
     * @param requestHostID 站点ID
     */
    public static void unlockTableByHostId(String requestHostID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where  lockedHostId='" + requestHostID + "'");
    }

    /**
     * 解锁桌台
     *
     * @param targetTableID 桌台ID
     * @param requestHostID 站点ID
     */
    public static void unlockTableByTableIdAndHostId(String targetTableID, String requestHostID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tableBiz set lockedStatus='0',lockedUserID='',lockedHostId='',lockedUserName='' where fsmtableid='" + targetTableID + "' and lockedHostId='" + requestHostID + "'");
    }

    /**
     * 查询所有的桌台ID和桌台名称
     *
     * @return
     */
    public static List<SimpleData> getTableIdAndName() {
        List<SimpleData> list = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsMTableId as id,fsMTableName as name from tbMTable", SimpleData.class);
        if (ListUtil.isEmpty(list)) {
            list = new ArrayList<>();
        }
        return list;
    }

    /**
     * 查询桌子是否正在被占用
     *
     * @param fsmtableId
     * @return true : 桌子正在被占用； false:桌台空闲
     */
    public static boolean checkTableInBusiness(String fsmtableId) {
        if (TextUtils.isEmpty(fsmtableId)) {
            return false;
        }
        String sql = "select fsmtableId from tableBiz where fsmtableId = '" + fsmtableId + "' and (fsmtablesteid = '2' or extra_order <> '' or ((flag & 2) == 2) or ((flag & 4) == 4))";
        String fsmtableName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return !TextUtils.isEmpty(fsmtableName);
    }

    /**
     * 获取所有区域业务
     *
     * @return
     */
    public static List<AreaBizDBModel> getAllAreaBiz() {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "SELECT tbMArea.fsMAreaId,tbMArea.fsMAreaName," +
                "areaBiz.fiMinStandardStatus,areaBiz.fdMinStandardAmt,areaBiz.fiPlaySound FROM tbMArea " +
                " LEFT JOIN areaBiz ON tbMArea.fsMAreaId=areaBiz.fsMAreaId " +
                " WHERE tbMArea.fsShopGUID='" + HostUtil.getShopID() + "'", AreaBizDBModel.class);
    }

    /**
     * 获取所有区域业务--简化版
     *
     * @return
     */
    public static List<AreaBizSimpleModel> getAllAreaBizSimple() {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "SELECT tbMArea.fsMAreaId,tbMArea.fsMAreaName," +
                "areaBiz.fiMinStandardStatus,areaBiz.fdMinStandardAmt,areaBiz.fiPlaySound FROM tbMArea " +
                " LEFT JOIN areaBiz ON tbMArea.fsMAreaId=areaBiz.fsMAreaId " +
                " WHERE tbMArea.fsShopGUID='" + HostUtil.getShopID() + "'", AreaBizSimpleModel.class);
    }

    /**
     * 通过区域Id获取区域业务
     *
     * @return
     */
    public static AreaBizDBModel getAreaBizByAreaId(String areaId) {
        if (TextUtils.isEmpty(areaId)) {
            return new AreaBizDBModel();
        }
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM areaBiz " +
                " WHERE fsMAreaId='" + areaId + "' AND fsShopGUID='" + HostUtil.getShopID() + "'", AreaBizDBModel.class);
    }

    /**
     * @return ArrayMap<String                               ,                                                               Integer>
     */
    public static ArrayMap<String, Integer> queryTableStateNum() {
        ArrayMap<String, Integer> result = new ArrayMap<>();
        int total = 0;
        int free = 0;
        int busy = 0;
        int print = 0;

        String sql = "select sum(1) as busy, sum(case when fioccupyflag = '2' then 1 else 0 end) as isPrint from tableBiz where fsmtablesteid in ('2', '3', '8')";
        JSONObject object = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
        if (object != null) {
            busy = object.getIntValue("busy");
            print = object.getIntValue("isPrint");
        }

        String sql2 = "SELECT count(*) FROM tbmtable WHERE fiStatus IN ('1', '2') AND fsmareaid NOT IN (SELECT fsmareaid FROM tbmarea WHERE fiStatus <> '1')";
        total = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql2), 0);

        free = total - busy;

        result.put("total", total);
        result.put("free", free);
        result.put("busy", busy);
        result.put("print", print);


        if (SettingConfig.SERVICE_RESERVATION) {
            //开启了预定服务

            //未处理的预约单数量
            String appointSql = "";

            //未处理的占台数量
            String occupiedSql = "select count(*) num from reservation where ";

            result.put("appoint", StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, appointSql), 0));
            result.put("occupied", StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, occupiedSql), 0));
        }

        return result;
    }
}
