package com.mwee.android.pos.businesscenter.framework;

import android.text.TextUtils;

import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by liuxiuxiu on 2018/6/20.
 * 桌台锁
 */

public class TableLockCache extends Cache {
    private static final int MAX_LOCK_NUM=20;

    private Object putLock = null;

    public final Object optFastFoodOrderLock =new Object();
    /**
     * 桌台锁池
     * key 桌台ID
     * value ReentrantLock对象
     */
    private HashMap<String, ReentrantLock> tableLockPool = new HashMap<>();

    public TableLockCache() {
        putLock = new Object();
    }

    /**
     * 尝试拿锁---有时间限制
     *
     * @param timeOut      限制时长（单位秒）
     * @param fsmtableId   桌台ID
     * @param orderId      订单ID
     * @param logConstance 操作日志--->用于记录
     */
    public synchronized boolean tryLock(long timeOut, String fsmtableId, String orderId, String logConstance) {
        LogUtil.logBusiness("桌台定时尝试获取锁开始[" + fsmtableId + "," + orderId + "]", logConstance);
        ReentrantLock reentrantLock = tableLockPool.get(fsmtableId);
        if (reentrantLock == null) {
            reentrantLock = new ReentrantLock();
            tableLockPool.put(fsmtableId, reentrantLock);
        }
        boolean result = false;
        try {
            result = reentrantLock.tryLock(timeOut, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.logBusiness("桌台定时尝试获取锁异常[" + fsmtableId + "," + orderId + "]" + e.getMessage(), logConstance);
        }
        LogUtil.logBusiness("桌台定时尝试获取锁结束[" + fsmtableId + "," + orderId + "]", logConstance);
        return result;
    }

    /**
     * 尝试拿锁
     *
     * @param fsmtableId   桌台ID
     * @param orderId      订单ID
     * @param logConstance 操作日志--->用于记录
     */
    public synchronized boolean tryLock(String fsmtableId, String orderId, String logConstance) {
        LogUtil.logBusiness("桌台尝试获取锁开始[" + fsmtableId + "," + orderId + "]", logConstance);
        ReentrantLock reentrantLock = tableLockPool.get(fsmtableId);
        if (reentrantLock == null) {
            reentrantLock = new ReentrantLock();
            tableLockPool.put(fsmtableId, reentrantLock);
        }
        boolean result = reentrantLock.tryLock();
        LogUtil.logBusiness("桌台尝试获取锁结束[" + fsmtableId + "," + orderId + "]", logConstance);
        return result;
    }

    /**
     * 锁
     *
     * @param fsmtableId   桌台ID
     * @param orderId      订单ID
     * @param logConstance 操作日志--->用于记录
     */
    public String doLock(String fsmtableId, String orderId, String logConstance) {
        String uniq = UUID.randomUUID().toString();

        String lockId = fsmtableId;
        /**
         * 为了快餐不死锁，特意添加了逻辑，快餐是 TextUtils.isEmpty(fsmtableId)，留20个快餐锁
         */
        if (TextUtils.isEmpty(fsmtableId) && !TextUtils.isEmpty(orderId) && orderId.length()>8) {

            String orderTemp = orderId.substring(8);
            if (orderTemp.contains("_")) {
                String[] temp = orderTemp.split("_");
                orderTemp = temp[0];
            }

            try {
                int temp = Integer.parseInt(orderTemp);
                lockId = "mydfastfood" + temp % MAX_LOCK_NUM;
            } catch (NumberFormatException e) {
                lockId = fsmtableId;
            }
        }

        LogUtil.logBusiness("桌台加锁开始[" + uniq + ", " + lockId + "," + orderId + "] @Thread-" + Thread.currentThread().hashCode(), logConstance);
        ReentrantLock reentrantLock = tableLockPool.get(lockId);
        if (reentrantLock == null) {
            synchronized (putLock) {
                reentrantLock = tableLockPool.get(lockId);
                if (reentrantLock == null) {
                    reentrantLock = new ReentrantLock();
                    tableLockPool.put(lockId, reentrantLock);
                }
            }
        }

        reentrantLock.lock();
        LogUtil.logBusiness("桌台加锁成功[" + uniq + ", " + lockId + "," + orderId + "] @Thread-" + Thread.currentThread().hashCode(), logConstance);

        if (!BaseConfig.isProduct()) {
            CacheModel cacheModel = new CacheModel();
            cacheModel.key = uniq;
            cacheModel.value = logConstance;
            cacheModel.type = IOCache.TYPE_TABLE_CACHE_LOCK;
            cacheModel.biz_key = lockId;
            cacheModel.info = orderId;
            cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            cacheModel.updatetime = cacheModel.createtime;
            cacheModel.replaceNoTrans();
        }
        return uniq;
    }

    /**
     * 解锁
     *
     * @param fsmtableId   桌台ID
     * @param orderId      订单ID
     * @param logConstance 操作日志--->用于记录
     */
    public synchronized void unLock(String uniq, String fsmtableId, String orderId, String logConstance) {

        String lockId = fsmtableId;
        /**
         * 为了快餐不死锁，特意添加了逻辑，快餐是 TextUtils.isEmpty(fsmtableId)，留20个快餐锁
         */
        if (TextUtils.isEmpty(fsmtableId) && !TextUtils.isEmpty(orderId) && orderId.length()>8) {

            String orderTemp = orderId.substring(8);
            if (orderTemp.contains("_")) {
                String[] temp = orderTemp.split("_");
                orderTemp = temp[0];
            }

            try {
                int temp = Integer.parseInt(orderTemp);
                lockId = "mydfastfood" + temp % MAX_LOCK_NUM;
            } catch (NumberFormatException e) {
                lockId = fsmtableId;
            }
        }

        LogUtil.logBusiness("桌台解锁开始[" + uniq + ", " + lockId + "," + orderId + "] @Thread-" + Thread.currentThread().hashCode(), logConstance);
        ReentrantLock reentrantLock = tableLockPool.get(lockId);
        if (reentrantLock != null) {
            if (reentrantLock.getQueueLength() > 0) {
                reentrantLock.unlock();
                LogUtil.logBusiness("桌台解锁结束[" + uniq + ", " + lockId + "," + orderId + "] @Thread-" + Thread.currentThread().hashCode() + "; 还有线程等待该锁，等待数量：" + reentrantLock.getQueueLength(), logConstance);
            } else {
                reentrantLock.unlock();
//                tableLockPool.remove(fsmtableId);
                LogUtil.logBusiness("桌台解锁结束[" + uniq + ", " + lockId + "," + orderId + "] @Thread-" + Thread.currentThread().hashCode() + "; 该锁已经没有等待用户，移除此锁", logConstance);
            }
            if (!BaseConfig.isProduct()) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "DELETE FROM datacache WHERE type = '" + IOCache.TYPE_TABLE_CACHE_LOCK + "' AND key = '" + uniq + "'");
            }
        }
    }

    @Override
    public void refresh() {

    }

    @Override
    public void clean() {

    }
}
