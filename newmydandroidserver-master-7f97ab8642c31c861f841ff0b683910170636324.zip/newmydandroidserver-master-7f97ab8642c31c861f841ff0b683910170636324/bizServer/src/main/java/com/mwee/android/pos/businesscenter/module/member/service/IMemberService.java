package com.mwee.android.pos.businesscenter.module.member.service;

import com.mwee.android.pos.component.member.newInterface.model.MemberCouponsDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberPrivateDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberScoreDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.MemberTradeDetailModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardListItemModel;
import com.mwee.android.pos.connect.framework.SocketResponse;

import java.util.List;

/**
 * 会员业务接口
 * Created by qinwei on 2019/3/12 11:16 AM
 * email: qin.wei@mwee.cn
 */
public interface IMemberService {
    /**
     * 查询会员信息
     *
     * @param companyId
     * @param shopId
     * @param cardNo
     */
    SocketResponse<NewMemberCardDetailsModel> loadMemberDetailByCardNo(String companyId, String shopId, String cardNo);

    /**
     * 会员列表
     *
     * @param companyId      公司id
     * @param shopId         门店id
     * @param mobile         手机号
     * @param verifyCode     验证码 23422
     * @param verifyCodeType 类型1 //验证码类型 1.实体卡激活验证码；2 其他;3，手机号收银
     * @return
     */
    SocketResponse<List<NewMemberCardListItemModel>> loadMemberCardListByMobile(String companyId, String shopId, String mobile, String verifyCode, int verifyCodeType);

    /**
     * 加载会员余额明细
     *
     * @param companyId      公司id
     * @param cardNoOrMobile 卡号或者手机号
     * @param pageNo         加载页码
     * @return
     */
    SocketResponse<MemberTradeDetailModel> loadMemberTradeDetail(String companyId, String cardNoOrMobile, int pageNo);

    /**
     * 加载积分明细
     *
     * @param brandId
     * @param cardNoOrMobile
     * @param pageNo
     * @return
     */
    SocketResponse<MemberScoreDetailModel> loadMemberScore(String brandId, String cardNoOrMobile, int pageNo);

    /**
     * 会员优惠券列表
     *
     * @param brandId
     * @param cardNo
     * @param pageNo
     * @return
     */
    SocketResponse<MemberCouponsDetailModel> loadMemberCoupons(String brandId, String cardNo, int pageNo);

    /**
     * 查询会员特权
     *
     * @param brandId
     * @param csId
     * @param memberLevel
     * @param storeId
     * @param cardNo
     * @return
     */
    SocketResponse<MemberPrivateDetailModel> loadMemberPrivate(String brandId, String csId, int memberLevel, String storeId, String cardNo);


}
