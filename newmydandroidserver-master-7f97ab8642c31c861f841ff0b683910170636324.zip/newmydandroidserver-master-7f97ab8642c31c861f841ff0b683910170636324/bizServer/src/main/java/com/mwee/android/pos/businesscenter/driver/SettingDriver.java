package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.setting.SettingProcessor;
import com.mwee.android.pos.businesscenter.dbutil.MenuClsPrintSortDBUtil;
import com.mwee.android.pos.business.setting.preorder.QueryPreOrderSettingRequest;
import com.mwee.android.pos.business.setting.preorder.SavePreOrderSettingRequest;
import com.mwee.android.pos.businesscenter.air.dbUtil.CompatibleErrorDataUtils;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.takeout.GetTakeOutPlatformInfoRequest;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.setting.GetAllMenuClsPrintSortResponse;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.connect.business.setting.preorder.PreOrderSettingResponse;
import com.mwee.myd.server.business.config.ConfigConstant;
import com.mwee.myd.server.business.config.ConfigProcess;
import com.mwee.android.pos.connect.business.setting.GetAllTableInfosResponse;
import com.mwee.android.pos.connect.business.setting.GetBizVersionResponse;
import com.mwee.android.pos.connect.business.setting.GetConfigArrayResponse;
import com.mwee.android.pos.connect.business.setting.LogSearchParamsResponse;
import com.mwee.android.pos.connect.business.setting.MandatoryUnLockTableResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuClsPrintSortDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.table.TableBizSimpInfo;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/6/19.
 * 更多页面对应操作
 */
@SuppressWarnings("unused")
public class SettingDriver implements IDriver {

    private static final String TAG = "systemSetting";

    /**
     * 获取查看日志的过滤条件
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/logSearchParams")
    public SocketResponse logSearchParams(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        LogSearchParamsResponse responseData = new LogSearchParamsResponse();
        response.data = responseData;
        try {
            //LogSearchParamsRequest request = JSON.parseObject(param, LogSearchParamsRequest.class);
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            responseData.tableNameList = SettingProcessor.getAllTableName();
            responseData.waiterNameList = SettingProcessor.getAllWaiterName();
            responseData.hostIdlList = SettingProcessor.getAllHostId(hostId);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 获取所有桌台信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/allTablesInfo")
    public SocketResponse allTablesInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllTableInfosResponse responseData = new GetAllTableInfosResponse();
        response.data = responseData;
        try {
            //GetAllTableInfosRequest request = JSON.parseObject(param, GetAllTableInfosRequest.class);
            List<TableBizSimpInfo> tableBizSimpInfoList = TableDBUtil.getTableSimpleInfoModel();
            if (ListUtil.isEmpty(tableBizSimpInfoList)) {
                tableBizSimpInfoList = new ArrayList<>();
            }
            responseData.tableBizModelList = tableBizSimpInfoList;
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 获取所有桌台信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/mandatoryUnLockTable")
    public SocketResponse mandatoryUnLockTable(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        MandatoryUnLockTableResponse responseData = new MandatoryUnLockTableResponse();
        response.data = responseData;
        try {
            //MandatoryUnLockTableRequest request = JSON.parseObject(param, MandatoryUnLockTableRequest.class);
            JSONObject request = JSON.parseObject(param);
            String fsTableId = request.getString("fsTableId");
            TableBusinessUtil.unlockTargetTable(fsTableId);
            String orderId = TableBusinessUtil.getOrderIDByTableID(fsTableId);
            if (!TextUtils.isEmpty(orderId)) {
                ServerCache.getInstance().releaseToken(orderId);
            }
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 获取配置项
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/configArray")
    public SocketResponse configArray(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetConfigArrayResponse responseData = new GetConfigArrayResponse();
        response.data = responseData;
        try {
            //GetConfigArrayRequest request = JSON.parseObject(param, GetConfigArrayRequest.class);
            JSONObject request = JSON.parseObject(param);
            String fileName = request.getString("fileName");
            if (TextUtils.isEmpty(fileName)) {
                fileName = ConfigConstant.ConfigFileName;
            }
            responseData.configDetail = ConfigProcess.getInstance().getAllData(fileName);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取配置信息 --> 支持开卡功能的门店列表
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/bindCardShopConfigArray")
    public SocketResponse bindCardShopConfigArray(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetConfigArrayResponse responseData = new GetConfigArrayResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            String fileName = request.getString("fileName");
            if (TextUtils.isEmpty(fileName)) {
                fileName = ConfigConstant.ConfigFileName;
            }
            responseData.configDetail = ConfigProcess.getInstance().getAllData(fileName);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/getBizVersion")
    public SocketResponse getBizVersion(SocketHeader head, String param) {
        SocketResponse<GetBizVersionResponse> response = new SocketResponse<>();
        GetBizVersionResponse data = new GetBizVersionResponse();
        response.data = data;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            data.currentVersionName = APPConfig.currentVersionName;
            data.cachedVersionName = APPConfig.cachedVersionName;
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/getAllMenuCls")
    public SocketResponse getAllMenuCls(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllMenuClsPrintSortResponse responseData = new GetAllMenuClsPrintSortResponse();
        response.data = responseData;

        try {
            String shopGUID = JSON.parseObject(param).getString("shopGUID");
            responseData.menuClsPrintSortList = MenuClsPrintSortDBUtil.getAllMenuCls(shopGUID);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/clearAllMenuCls")
    public SocketResponse clearAllMenuCls(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            String shopGUID = JSON.parseObject(param).getString("shopGUID");
            MenuClsPrintSortDBUtil.clearAllMenuCls(shopGUID);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/addMenuCls")
    public SocketResponse addMenuCls(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject obj = JSON.parseObject(param);
            List<MenuClsPrintSortDBModel> list = JSON.parseArray(obj.getString("menuClsList"), MenuClsPrintSortDBModel.class);
            MenuClsPrintSortDBUtil.addMenuCls(list);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/updateMenuCls")
    public SocketResponse updateMenuCls(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject obj = JSON.parseObject(param);
            List<MenuClsPrintSortDBModel> list = JSON.parseArray(obj.getString("menuClsList"), MenuClsPrintSortDBModel.class);
            MenuClsPrintSortDBUtil.updateMenuClsSort(list);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 获取配置信息 --> 支持开卡功能的门店列表
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/cleanSyncError")
    public SocketResponse cleanSyncError(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            CompatibleErrorDataUtils.startCleanSyncError(response);

            LogUtil.log("startCleanSyncError--->回调啦");
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取预点单设置数据
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getPreOrderSettingData")
    public SocketResponse getPreOrderInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        JSONObject socketRequest = JSON.parseObject(param);
        QueryPreOrderSettingRequest request = new QueryPreOrderSettingRequest();

        SocketResponse<PreOrderSettingResponse> socketResponse = new SocketResponse();

        BusinessExecutor.execute(request, new IExecutorCallback() {

            @Override
            public void success(ResponseData responseData) {
                if (responseData != null) {
                    PreOrderSettingResponse preOrderSettingResponse = (PreOrderSettingResponse) responseData.responseBean;
                    if (preOrderSettingResponse != null) {
                        if (preOrderSettingResponse.errno == 0) {
                            socketResponse.data = preOrderSettingResponse;
                            socketResponse.code = SocketResultCode.SUCCESS;
                            return;
                        }
                    }
                }
                socketResponse.code = SocketResultCode.EXCEPTION;
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.CONNECT_FAILED;
                return false;
            }
        }, false);

        return socketResponse;
    }

    /**
     * 保存预点单设置数据
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/savePreOrderSettingData")
    public SocketResponse savePreOrderSettingData(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        JSONObject paramObject = JSON.parseObject(param);
        SavePreOrderSettingRequest request = new SavePreOrderSettingRequest();
        request.shopHoursBegin = paramObject.getString("shopHoursBegin");
        request.shopHoursEnd = paramObject.getString("shopHoursEnd");
        request.orderTimeBegin = paramObject.getString("orderTimeBegin");
        request.orderTimeEnd = paramObject.getString("orderTimeEnd");
        request.prepareTime = paramObject.getInteger("prepareTime");
        request.orderTakingType = paramObject.getInteger("orderTakingType");

        SocketResponse<BasePosResponse> socketResponse = new SocketResponse();

        BusinessExecutor.execute(request, new IExecutorCallback() {

            @Override
            public void success(ResponseData responseData) {
                if (responseData != null) {
                    BasePosResponse basePosResponse = (BasePosResponse) responseData.responseBean;
                    if (basePosResponse != null) {
                        if (basePosResponse.errno == 0) {
                            socketResponse.data = basePosResponse;
                            socketResponse.code = SocketResultCode.SUCCESS;
                            return;
                        }
                    }
                }
                socketResponse.code = SocketResultCode.EXCEPTION;
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.CONNECT_FAILED;
                return false;
            }
        }, false);

        return socketResponse;
    }

    /**
     * 获取外卖平台信息
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getTakeOutPlatformInfo")
    public SocketResponse getTakeOutPlatformInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        JSONObject paramObject = JSON.parseObject(param);
        GetTakeOutPlatformInfoRequest request = new GetTakeOutPlatformInfoRequest();
        request.source = paramObject.getString("source");

        SocketResponse<BasePosResponse> socketResponse = new SocketResponse();

        BusinessExecutor.execute(request, new IExecutorCallback() {

            @Override
            public void success(ResponseData responseData) {
                if (responseData != null) {
                    BasePosResponse basePosResponse = (BasePosResponse) responseData.responseBean;
                    if (basePosResponse != null) {
                        if (basePosResponse.errno == 0) {
                            socketResponse.data = basePosResponse;
                            socketResponse.code = SocketResultCode.SUCCESS;
                            return;
                        }
                    }
                }
                socketResponse.code = SocketResultCode.EXCEPTION;
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.CONNECT_FAILED;
                if (responseData != null) {
                    socketResponse.message = responseData.resultMessage;
                }
                return false;
            }
        }, false);

        return socketResponse;
    }



    @Override
    public String getModuleName() {
        return TAG;
    }
}
