package com.mwee.android.pos.businesscenter.air.dao.impl;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.air.dao.IBaseDao;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.inject.ColumnInf;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/10/17.
 */

public abstract class BaseDaoImpl<T extends DBModel> implements IBaseDao<T> {
    protected Class<T> clazz;
    protected String tableName;
    protected String primaryKeyColumn;

    public BaseDaoImpl() {
        clazz = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        tableName = T.getTableName(clazz);
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            if (fields[i].isAnnotationPresent(ColumnInf.class)) {
                ColumnInf columnInf = fields[i].getAnnotation(ColumnInf.class);
                if (columnInf.primaryKey()) {
                    String columnName = columnInf.name();
                    primaryKeyColumn = TextUtils.isEmpty(columnName) ? columnName : fields[i].getName();
                    break;
                }
            }
        }
    }

    @Override
    public T queryById(String id) {
        String sql = "select * from " + tableName + " where " + primaryKeyColumn + "='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, clazz);
    }

    @Override
    public ArrayList<T> queryAll() {
        String sql = "select * from " + tableName;
        return (ArrayList<T>) DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, clazz);
    }

    @Override
    public long update(T t) {
        t.replaceNoTrans();
        return 0;
    }

    @Override
    public long delete(String id) {
        return 0;
    }
}
