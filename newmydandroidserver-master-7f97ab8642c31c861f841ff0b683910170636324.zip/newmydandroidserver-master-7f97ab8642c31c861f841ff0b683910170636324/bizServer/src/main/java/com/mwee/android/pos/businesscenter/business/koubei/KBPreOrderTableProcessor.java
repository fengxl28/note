package com.mwee.android.pos.businesscenter.business.koubei;

import com.alibaba.fastjson.JSON;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by zhangmin on 2018/8/20.
 */

public class KBPreOrderTableProcessor {


    /**
     * 接单 口碑预点桌台单 并且为堂食模式下
     *
     * @param preOrderCache
     * @param retrySeq
     * @return
     */
    public static String acceptTableOrder(KBPreOrderCache preOrderCache, int retrySeq) {

        KBPreOrderApi orderApi = new KBPreOrderApi();
        final String[] result = new String[1];
        preOrderCache.take_no = "下厨时分配";

        orderApi.acceptOrder(preOrderCache.order_id + "", preOrderCache.business_type, KBConstants.ORDER_STYLE_LATFORM, preOrderCache.merchant_id, preOrderCache.take_no, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "接单成功", "订单详情" + JSON.toJSONString(preOrderCache));
                /**
                 *  1 改变本地订单的状态
                 */
                KBPreOrderDBUtils.update(preOrderCache.order_id + "", "RECEIPT");
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set take_no = '" + preOrderCache.take_no + "' where  order_id = '" + preOrderCache.order_id + "'");

                //todo 口碑正餐桌台模式 手动分配桌台以后打印
                //KBPreOrderDBUtils.saveBill(preOrderCache);
                //KBMakePrinter.treatPrinter(preOrderCache.order_id, preOrderCache.table_time);
                result[0] = "";
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                //todo 接单失败 连续处理三次
                if (retrySeq < 0 && retrySeq < 3) {
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            acceptTableOrder(preOrderCache, retrySeq + 1);
                        }
                    }, 2000);
                } else {
                    result[0] = responseData.resultMessage;
                }
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, retrySeq + "接单  口碑预点单，订单号：" + preOrderCache.order_id, "异常信息：" + responseData.resultMessage);

                return false;
            }
        });
        return result[0];
    }


    /**
     * 分配桌台
     */
    /*public static synchronized String allocationTable(String order_id, String tableId, boolean printMake) {

        //TableBizDaoImpl tableBizDao = new TableBizDaoImpl();
        TableBizModel tableBizModel = new TableBizDaoImpl().queryById(tableId);
        if (tableBizModel != null && !TextUtils.isEmpty(tableBizModel.fssellno)) {
            return "当前桌台已被操作,无法继续分配桌台";
        }

        KBPreOrderCache kbPreOrderCache = KBPreOrderDBUtils.query(order_id);
        TempOrderDishesCache tempOrder = buildTempOrder(kbPreOrderCache, tableId);
        String errorMsg = submitOrder(kbPreOrderCache, tempOrder, printMake);
        if (TextUtils.isEmpty(errorMsg)) {//分配桌台成功 修改桌号
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set take_no = '" + tempOrder.fsmtablename + "' where  order_id = '" + kbPreOrderCache.order_id + "'");

            //todo 上送分配的订单号给后台 有隐患
            new KBPreOrderApi().allocationTable(order_id, kbPreOrderCache.business_type, kbPreOrderCache.merchant_id, tempOrder.fsmtablename, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {


                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    return false;
                }
            });
        }
        return errorMsg;
    }*/

   /* private static TempOrderDishesCache buildTempOrder(KBPreOrderCache kbPreOrderCache, String tableId) {

        TempOrderDishesCache tempOrder = new TempOrderDishesCache();
        UserDBModel userDBModel = HostUtil.getCloudUser();
        tempOrder.tempCreateTime = DateUtil.getCurrentDateTime("yyyy-MM-dd HH:mm:ss");
        tempOrder.waiterID = userDBModel.fsUserId;
        tempOrder.waiterName = userDBModel.fsUserName;
        tempOrder.businessDate = HostUtil.getHistoryBusineeDate(HostUtil.getShopID());
        tempOrder.currentSectionID = OrderUtil.getSectionId();
        tempOrder.currentHostID = HostBiz.cloudsite;
        tempOrder.personNum = Integer.valueOf(kbPreOrderCache.people_num);
        tempOrder.eatType = 0;
        tempOrder.thirdOrderID = kbPreOrderCache.order_id;
        //todo 第三方业务类型 干啥的搞不清楚
        tempOrder.thirdBizType = NetOrderType.KB_ORDER;
        MtableDBModel table = TableDBUtil.getMTableById(tableId);
        tempOrder.fsmtableid = table.fsmtableid;
        tempOrder.fsmareaid = table.fsmareaid;
        tempOrder.fsmtablename = table.fsmtablename;
        tempOrder.tempSelectedMenuList.addAll(KBOrderUtils.copyTo((ArrayList<KBPreMenuItemModel>) kbPreOrderCache.dish_details, kbPreOrderCache.memo));
        tempOrder.tempCreateTime = DateUtil.getCurrentTime();
        tempOrder.isRapidTempOrderCache = true;
        tempOrder.phone = kbPreOrderCache.user_mobile;

        tempOrder.plusTempSelectedMenuAmount();
        return tempOrder;
    }*/


    /**
     * 进行下单
     *
     * @param tempOrder TempOrderDishesCache | 订单信息
     */
   /* private static String submitOrder(KBPreOrderCache kbPreOrderCache, TempOrderDishesCache tempOrder, boolean printMake) {
        MtableDBModel table = TableDBUtil.getMTableById(tempOrder.fsmtableid);
        SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse = new SocketResponse<>();
        JSONObject request = new JSONObject();
        request.put("shopId", HostUtil.getShopID());
        request.put("orderDishesCache", tempOrder);
        request.put("hostID", HostBiz.cloudsite);
        TableBusinessUtil.openTableAndOrder(socketResponse, HostBiz.cloudsite, request);
        if (socketResponse.code == SocketResultCode.SUCCESS) {
            OrderCache orderCache = socketResponse.data.orderCache;
            String orderID = orderCache.orderID;
            //todo 强制给口碑堂食订单赋值 有待改进
            orderCache.thirdOrderId = tempOrder.thirdOrderID;
            orderCache.thirdOrderType = tempOrder.thirdBizType;
            orderCache.fiSellType = 0;
            orderCache.fsBillSourceId = BillSourceValue.BILL_KB;
            //todo 不能圆整 否则账目不平
            orderCache.whetherRound = false;
            orderCache.totalPrice = kbPreOrderCache.receipt_amount;
            orderCache.totalService = kbPreOrderCache.service_amount;
            orderCache.serviceRate = 0;
            orderCache.totalCount = KBOrderUtils.calculateTotalCount(orderCache);
            UserDBModel userDBModel = HostUtil.getCloudUser();
            PaySession paySession = KBOrderUtils.newPaySession(kbPreOrderCache, orderCache, userDBModel);

            OrderSession.getInstance().writeOrder(orderID, orderCache, false, "submitOrder");
            OrderSession.getInstance().writePay(orderID);
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "kbOrderId[" + orderID + "] ->分配桌台方式成功", JSON.toJSONString(orderCache), paySession);
            //PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, "", userDBModel, HostBiz.cloudsite);
            OrderSession.getInstance().refreshCacheOrder(orderCache);

            *//**
             * 1 口碑订单先分配桌台不打印  再核销以后打印   【桌台信息能上传到后台 打印单据正确】
             * 2 口碑订单先进行了核销      再分配桌台后打印 【桌台不能上传到后台  打印单据有误 因为核销以后重新拉取数据  后台桌台名称是下厨时分配 会把本地桌台号覆盖 导致打印有误    为了兼容有两种方法  1 需要在打印的时候拦截 去本地桌台名称 】
             *//*
            if (printMake) {
                KBMakePrinter.printKBMake(kbPreOrderCache.order_id);
                //打印传菜单
                PrintOrderUtil.printPassTo(orderCache, kbPreOrderCache.table_time, HostUtil.getCurrentHost());
            }
        } else {
            if (socketResponse.code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "口碑预点正餐模式监控 已估清，菜品" + socketResponse.message, tempOrder.thirdOrderID, table.fsmtableid, "");
            } else {
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "口碑预点正餐模式监控 秒点订单自动加菜失败[" + socketResponse.message + "]", tempOrder.thirdOrderID, table.fsmtableid, "");
            }
            //todo 还原桌台的秒点相关的状态
            TableBusinessUtil.cleanRapidOrder(tempOrder.fsmtableid);
        }

        NotifyToClient.refreshTableOrOrders();
        if (socketResponse.code == SocketResultCode.SUCCESS) {
            return "";
        }
        return socketResponse.message;
    }*/


}
