package com.mwee.android.pos.businesscenter.business.message;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayBean;
import com.mwee.android.air.db.business.kbbean.future.KBOrderRefundRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.netpay.NetResponse;
import com.mwee.android.pos.business.netpay.PayStatusQueryRequest;
import com.mwee.android.pos.business.netpay.PayStatusQueryResponse;
import com.mwee.android.pos.business.netpay.RefundRequest;
import com.mwee.android.pos.business.netpay.model.PayStatusQueryModel;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundRequest;
import com.mwee.android.pos.business.rapid.api.bean.RapidRefundResponse;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.dbutil.MessageAbnormalOrdersDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.GetAllNetOrderResponse;
import com.mwee.android.pos.component.datasync.net.model.GetAllNetOrderDataModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderDetailBean;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2018/5/25.
 */

public class MessageAbnormalOrderBizProcessor {


    /**
     * 新增口碑后付异常订单消息
     *
     * @param kbAfterPayBean 秒点信息
     * @param reason         原因
     */
    public static void addKBAfterPayAbnormalMsg(KBAfterPayBean kbAfterPayBean,
                                                String reason) {
        if (kbAfterPayBean == null) {
            return;
        }
        if (!checkRepeat(kbAfterPayBean.order_id)) {
            BigDecimal totalPayed = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(kbAfterPayBean.rapidPayModels)) {
                for (RapidPayModel rapidPayModel : kbAfterPayBean.rapidPayModels) {
                    if (rapidPayModel != null && rapidPayModel.fdReceMoney.compareTo(BigDecimal.ZERO) > 0) {
                        totalPayed = totalPayed.add(rapidPayModel.fdReceMoney);
                    }
                }
            }
            Map<String, String> map = new HashMap<>();
            map.put("payAmt", Calc.formatShow(totalPayed));
            map.put("reason", reason);
            String mapStr = JSON.toJSONString(map);
            String businessDate = HostUtil.getHistoryBusineeDate("");

            MessageAbnormalOrdersDBUtil.addKBAfterPayAbnormalMsg(JSON.toJSONString(kbAfterPayBean), mapStr, kbAfterPayBean.order_id,
                    businessDate, kbAfterPayBean.out_biz_no);
            NotifyToClient.addAbnormalOrderMessage(MessageConstance.TYPE_KOUBEI_AFTER_PAY, kbAfterPayBean.order_id);
        }

    }

    /**
     * 新增秒付异常订单消息
     *
     * @param tempOrder  秒点信息
     * @param payment    秒付信息
     * @param totalPayed 秒付付款总金额
     * @param fiSellType 订单类型：正餐；快餐；外卖
     * @param orderId    订单号
     */
    public static void addRapidPayAbnormalMsg(TempOrderDishesCache tempOrder, RapidPayment payment,
                                              BigDecimal totalPayed, int fiSellType, String orderId,
                                              String reason) {
        if (payment == null) {
            return;
        }
        if (!checkRepeat(payment.orderId)) {
            Map<String, String> map = new HashMap<>();
            map.put("table", TableDBUtil.getTableNameById(payment.tableNo));
            map.put("payAmt", Calc.formatShow(totalPayed));
            map.put("reason", reason);
            String mapStr = JSON.toJSONString(map);
            String tempOrderStr = tempOrder == null ? "" : JSON.toJSONString(tempOrder);
            String businessDate = HostUtil.getHistoryBusineeDate("");

            MessageAbnormalOrdersDBUtil.addRapidPayAbnormalMsg(JSON.toJSONString(payment), tempOrderStr, mapStr, payment.tableNo,
                    payment.tableNo, payment.orderId, businessDate, fiSellType, orderId);
            NotifyToClient.addAbnormalOrderMessage(MessageConstance.TYPE_RAPID_PAY, payment.orderId);
        }

    }

    /**
     * 新增扫码支付异常订单消息
     *
     * @param payment    支付信息
     * @param totalPayed 总金额
     * @param createUser 服务员
     * @param tableNo    桌台No
     * @param areaId     餐区ID
     * @param orderId    订单号
     * @param payBillNo  支付订单号
     * @param fiSellType 订单类型：正餐；快餐；外卖
     * @param reason     异常原因
     */
    public static void addScanPayAbnormalMsg(PayModel payment, BigDecimal totalPayed,
                                             String createUser, String tableNo,
                                             String areaId, String orderId,
                                             String payBillNo, int fiSellType,
                                             String reason) {
        if (payment == null) {
            return;
        }

        if (!checkRepeat(payBillNo)) {
            Map<String, String> map = new HashMap<>();
            map.put("table", TableDBUtil.getTableNameById(tableNo));
            map.put("payAmt", Calc.formatShow(totalPayed));
            map.put("reason", reason);
            String mapStr = JSON.toJSONString(map);
            String businessDate = HostUtil.getHistoryBusineeDate("");

            MessageAbnormalOrdersDBUtil.addScanPayAbnormalMsg(JSON.toJSONString(payment), mapStr, tableNo,
                    areaId, payBillNo, businessDate, createUser, orderId, fiSellType);

            NotifyToClient.addAbnormalOrderMessage(MessageConstance.TYPE_SCAN_PAY, payBillNo);
        }
    }


    /**
     * 检查消息是否已重复
     *
     * @param billNo 支付订单号
     * @return boolean | true : 消息库里已有该订单； false： 消息库里没有该订单
     */
    public static boolean checkRepeat(String billNo) {
        String msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msgId from message where standBy2 = '" + billNo + "'");
        if (!TextUtils.isEmpty(msgId)) {
            return true;
        }
        return false;
    }

    /**
     * 查询退款状态
     *
     * @param orderId
     * @param type
     * @param iResult
     */
    public static void payStatusQuery(String orderId, int type, IResponse<String> iResult) {
        PayStatusQueryRequest refundRequest = new PayStatusQueryRequest();
        refundRequest.orderno = orderId;
        refundRequest.type = type;
        refundRequest.shopguid = DBMetaUtil.getConfig(META.SHOPID, "0");
        BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {

                if (iResult != null) {
                    int errCode = dealResponse(responseData);
                    if (errCode == 0) {
                        iResult.callBack(true, 0, "退款成功", null);
                    } else {
                        iResult.callBack(false, errCode, "退款状态查询失败，请重试", null);
                        ActionLog.addLog("异常订单 查询退款  返回异常结果 " + errCode, orderId, "", ActionLog.MESSAGE_ABNORMAL_ORDER, responseData);
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                ActionLog.addLog("异常订单 查询退款  返回异常结果 ", orderId, "", ActionLog.MESSAGE_ABNORMAL_ORDER, responseData);
                if (iResult != null) {
                    iResult.callBack(false, -2, responseData.resultMessage, null);
                }
                return false;
            }
        }, false);
    }


    /**
     * 解析退款状态查询结果
     *
     * @param responseData
     * @return int | 0：未退款；-1：已退款；-2：退款状态查询失败，请重试
     */
    private static int dealResponse(ResponseData responseData) {
        if (responseData.responseBean != null) {
            try {
                if (responseData.responseBean instanceof PayStatusQueryResponse) {
                    PayStatusQueryResponse getDataResponse = (PayStatusQueryResponse) responseData.responseBean;
                    PayStatusQueryModel model = getDataResponse.data;
                    if (model.status != 2 && model.status != 4) {
                        return 0;
                    } else {
                        return -1;
                    }
                }
            } catch (Exception e) {
                LogUtil.logError("查询退款情况   解析遇到异常", e);
                return -2;
            }
        }
        return -2;
    }


    /**
     * 退款请求----扫码支付
     *
     * @param businessInfo
     * @param iResult
     */
    public static void voidScanPay(String businessInfo, IResult iResult) {
        RefundRequest refundRequest = new RefundRequest();
        refundRequest.pay_order = businessInfo;
        BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(true, "退款成功");
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_NET, businessInfo, "", refundRequest);
                if (iResult != null) {
                    iResult.callBack(false, responseData.resultMessage);
                }
                return false;
            }
        }, false);
    }

    /**
     * 退款请求 --- 秒付退款
     *
     * @param businessInfo
     * @param iResult
     */
    public static void voidRapidPay(String businessInfo, IResult iResult) {
        RapidRefundRequest refundRequest = new RapidRefundRequest();
        refundRequest.orderId = businessInfo;
        BusinessExecutor.execute(refundRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(true, "退款成功");
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_NET, businessInfo, "", refundRequest);
                if (iResult != null) {
                    iResult.callBack(false, responseData.resultMessage);
                }
                return false;
            }
        }, false);
    }

    /**
     * 退款请求 --- 口碑后付退款
     *
     * @param localId      本地订单号
     * @param kbPayOrderId 口碑支付订单号
     * @param iResult
     */
    public static void voidKoubeiAfterPay(String localId,BigDecimal amt, String kbPayOrderId, IResult iResult) {
        KBOrderRefundRequest kbOrderRefundRequest = new KBOrderRefundRequest();
        kbOrderRefundRequest.orderId = kbPayOrderId;
        kbOrderRefundRequest.outBizNo = localId;
        kbOrderRefundRequest.requestId = UUIDUtil.optUUID();
        kbOrderRefundRequest.amount = amt;
        BusinessExecutor.execute(kbOrderRefundRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (iResult != null) {
                    iResult.callBack(true, "退款成功");
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.REFUND_FAILED_NET, kbPayOrderId, "", kbOrderRefundRequest);
                if (iResult != null) {
                    iResult.callBack(false, responseData.resultMessage);
                }
                return false;
            }
        }, false);
    }

    /**
     * 检查异常订单是否可关联订单
     *
     * @param detailBean
     * @param hostId
     * @param userSessoin
     * @param response
     * @return
     */
    public static SocketResponse checkAbnormalOrder(MessageAbnormalOrderDetailBean detailBean, String hostId, String userSessoin, SocketResponse response) {
        if (detailBean == null) {
            response.message = "订单信息异常，请重试";
            response.code = SocketResultCode.BUSINESS_FAILED;
            return response;
        }
        if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.VOID) {
            response.message = "该订单已退款";
            response.code = SocketResultCode.BUSINESS_FAILED;
            return response;
        } else if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.MAPPING) {
            response.message = "该订单已被关联";
            response.code = SocketResultCode.BUSINESS_FAILED;
            return response;
        }

        if (TextUtils.equals(detailBean.msgBody, "0")) {
            //正餐
            if (TextUtils.isEmpty(detailBean.mtableId)) {
                //没有桌台ID无法关联订单
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "该订单不支持此操作";
                return response;
            } else {

                // 锁桌判断
                String error = TableBusinessUtil.checkTableLock(hostId, userSessoin, detailBean.mtableId);
                if (!TextUtils.isEmpty(error)) {
                    response.message = error;
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    return response;
                }

                if (!TextUtils.isEmpty(detailBean.correlationId)) {
                    String currentSellNO = TableDBUtil.optOrderIDByTableID(detailBean.mtableId);
                    if (TextUtils.isEmpty(currentSellNO)) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "该订单已结账，不允许关联！";
                        return response;
                    } else if (!TextUtils.equals(currentSellNO, detailBean.correlationId)) {
                        response.message = "该订单对应的桌台订单信息已变，是否确认关联？";
                        response.code = SocketResultCode.SUCCESS;
                        return response;
                    } else {
                        response.message = "是否确认关联到该订单对应桌台?";
                        response.code = SocketResultCode.SUCCESS;
                        return response;
                    }
                } else if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                    //扫码付没有订单号，无法管理
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "该订单不支持此操作";
                    return response;
                }
                response.message = "是否确认关联到该订单对应桌台?";
                response.code = SocketResultCode.SUCCESS;
                return response;

            }

        } else if (TextUtils.equals(detailBean.msgBody, "1")) {
            //快餐
            if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                //扫码付必须要有订单ID
                if (TextUtils.isEmpty(detailBean.correlationId)) {
                    //没有订单号无法关联订单
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "该订单不支持此操作";
                    return response;
                } else {
                    OrderCache orderCache = OrderSession.getInstance().getOrder(detailBean.correlationId);
                    if (orderCache == null) {
                        //没有找到对应订单无法关联
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "该订单不支持此操作";
                        return response;
                    }
                    if (orderCache.orderStatus == OrderStatus.PAIED) {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = detailBean.correlationId + "订单已结账";
                        return response;
                    }
                    response.message = "是否确认关联到该订单对应桌台?";
                    response.code = SocketResultCode.SUCCESS;
                }
            } else {
                //微信快餐  必须要同时又菜品信息和支付信息，否则无法操作
                if (TextUtils.isEmpty(detailBean.msgHead) || TextUtils.isEmpty(detailBean.msgDes)) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "该订单不支持此操作";
                    return response;
                } else {
                    response.message = "是否确认下单？";
                    response.code = SocketResultCode.SUCCESS;
                }
            }
        } else {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "该订单不支持此操作";
            return response;
        }

        return response;
    }


}
