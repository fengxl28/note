package com.mwee.android.pos.businesscenter.koubei;

/**
 * Created by qinwei on 2018/5/16.
 */

public interface PreOrderCallback<T> {
    void onSuccess(T t);

    void onFailure(int code, String message);
}
