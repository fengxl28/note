package com.mwee.android.pos.businesscenter.print;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.print.CustomSellDBModel;
import com.mwee.android.pos.business.print.PrintBillMenuItemMode;
import com.mwee.android.pos.business.print.PrintItemDataBean;
import com.mwee.android.pos.business.print.StatementSellItemModel;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.businesscenter.dbutil.MenuClsPrintSortDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.business.MenuClsPrintSortDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TempletIdManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 打印数据处理类
 */
public class PrintDataProcessUtil {

    /**
     * 根据桌台整理数据
     * 预结单、结账单
     *
     * @param originalData  原始数据
     * @param sellTableId   订单所在桌台Id
     * @param sellTableName 订单所在桌台名称
     * @return
     */
    public static List<JSONObject> groupSellItemByTable(List<StatementSellItemModel> originalData, String sellTableId, String sellTableName) {
        List<com.alibaba.fastjson.JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(originalData)) {
            return result;
        }
        // 按桌台分组 <originTableName+"-"+originTableId,menuItemList>
        LinkedHashMap<String, List<PrintBillMenuItemMode>> group = new LinkedHashMap<>();
        for (int i = 0; i < originalData.size(); i++) {
            StatementSellItemModel menu = originalData.get(i);
            // 没有桌台信息的，使用当前桌台信息，兼容已下单的老数据
            if (TextUtils.isEmpty(menu.fsOriginTableId) || TextUtils.isEmpty(menu.fsOriginTableName)) {
                menu.fsOriginTableId = sellTableId;
                menu.fsOriginTableName = sellTableName;
            }
            String key = menu.fsOriginTableName + "-" + menu.fsOriginTableId;
            if (!group.containsKey(key)) {
                group.put(key, new ArrayList<>());
            }
            group.get(key).add(PrintBillMenuItemMode.createOtherBillMode(menu, ""+i + 1));
        }
        // 整理数据到json
        int dataId = 1;//菜品排序编号
        for (String originTable : group.keySet()) {
            List<PrintBillMenuItemMode> list = group.get(originTable);
            com.alibaba.fastjson.JSONObject jsonObject = new com.alibaba.fastjson.JSONObject();
            String tableName = originTable.split("-")[0];// 原桌台名称
            jsonObject.put("originTable", tableName);
            for (PrintBillMenuItemMode mode : list) {
                String menuIndex;
                //退菜不计入排序
                if(!TextUtils.isEmpty(mode.fsItemName) && mode.fsItemName.contains("[退]")){
                    menuIndex = " ";
                }else{
                    menuIndex = ""+dataId;
                    dataId++;
                }
                mode.index = menuIndex;
            }
            jsonObject.put("menuItemList", JSON.toJSON(list));
            result.add(jsonObject);
        }
        return result;
    }

    /**
     * 根据单序整理数据
     * 结账单、预结单
     *
     * @param originalData 原数据
     * @return
     */
    public static List<JSONObject> groupSellItemByTime(List<StatementSellItemModel> originalData) {
        List<JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(originalData)) {
            return result;
        }
        StatementSellItemModel data[] = originalData.toArray(new StatementSellItemModel[originalData.size()]);
        int size = data.length;

        for (int i = 0; i < size; i++) {//冒泡排序 从大到小
            for (int j = 1; j < size - i - 1; j++) {
                StatementSellItemModel itemModel = data[j];
                StatementSellItemModel tempModel = data[j + 1];
                if (itemModel == null || tempModel == null) {
                    continue;
                }
                if (itemModel.fiOrderSeq < tempModel.fiOrderSeq) {//前面的数字小于后面的数字就交换
                    data[j] = tempModel;
                    data[j + 1] = itemModel;
                }
            }
        }
        //按单序分组。每个单序下存个list
        int orderSeq = -1;
        int menuItemIndex = 1;
        List<PrintBillMenuItemMode> orderSeqList = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            StatementSellItemModel model = data[i];
            String menuIndex;
            //退菜不计入排序
            if(!TextUtils.isEmpty(model.fsItemName) && model.fsItemName.contains("[退]")){
                menuIndex = " ";
            }else{
                menuIndex = ""+menuItemIndex;
                menuItemIndex ++;
            }

            if (orderSeq != model.fiOrderSeq) {
                if (orderSeq != -1) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("menuItemList", JSON.toJSON(orderSeqList));
                    jsonObject.put("orderSeq", orderSeq);
                    result.add(jsonObject);
                }
                orderSeqList.clear();
                orderSeqList.add(PrintBillMenuItemMode.createOtherBillMode(model, menuIndex));
                orderSeq = model.fiOrderSeq;
            } else {
                orderSeqList.add(PrintBillMenuItemMode.createOtherBillMode(model, menuIndex));
            }
            //最后一个结束
            if (i == data.length - 1) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("menuItemList", JSON.toJSON(orderSeqList));
                jsonObject.put("orderSeq", orderSeq);
                result.add(jsonObject);
            }
        }
        return result;
    }

    /**
     * 菜品按照菜品分类分组排序
     * 预结单、结账单
     *
     * @param menuItems 原数据
     */
    public static List<JSONObject> groupSellItemByCls(List<StatementSellItemModel> menuItems) {
        MenuClsPrintSortDBUtil.fillMenuCls();
        String sql3 = "select * from " + DBModel.getTableName(MenuClsPrintSortDBModel.class) + " order by fiPrintSortOrder asc";
        // 菜品分配打印排序列表
        List<MenuClsPrintSortDBModel> menuClses = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql3, MenuClsPrintSortDBModel.class);
        addSysMenuCls(menuClses);
        List<JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(menuClses)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "");
            jsonObject.put("menuItemList", turnToPrintMode(menuItems, true));
            result.add(jsonObject);
            return result;
        }
        if (ListUtil.isEmpty(menuItems)) {
            return result;
        }

        HashMap<String, List<PrintBillMenuItemMode>> menuItemGroup = new HashMap<>(); // <menuClsId, menuItems>
        for (int i = 0; i < menuItems.size(); i++) {
            StatementSellItemModel menuItem = menuItems.get(i);
            String menuClsId = menuItem.fsMenuClsId;
            MenuclsDBModel rootMenuCls = MenuDBUtil.getRootMenuCls(menuItem.fsshopguid, menuItem.fsMenuClsId);
            if (rootMenuCls != null) {
                menuClsId = rootMenuCls.fsMenuClsId;
            }
            if (!menuItemGroup.containsKey(menuClsId)) {
                menuItemGroup.put(menuClsId, new ArrayList<>());
            }
            List<PrintBillMenuItemMode> list = menuItemGroup.get(menuClsId);
            list.add(PrintBillMenuItemMode.createOtherBillMode(menuItem, ""+(i + 1)));
        }
        int dataId = 1;//菜品排序编号
        for (int i = 0; i < menuClses.size(); i++) {
            MenuClsPrintSortDBModel menuType = menuClses.get(i);
            if (!menuItemGroup.containsKey(menuType.fsMenuClsId)) {
                continue;
            }

            List<PrintBillMenuItemMode> tempData = menuItemGroup.get(menuType.fsMenuClsId);
            if(ListUtil.isEmpty(tempData)){
                continue;
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", tempData.get(0).rootMenuClsName);
            BigDecimal menuClsTotalAmt = BigDecimal.ZERO;
            for (PrintBillMenuItemMode mode : tempData) {
                String menuIndex;
                //退菜不计入排序
                if(!TextUtils.isEmpty(mode.fsItemName) && mode.fsItemName.contains("[退]")){
                    menuIndex = " ";
                }else{
                    menuIndex = ""+dataId;
                    dataId++;
                }
                menuClsTotalAmt = menuClsTotalAmt.add(mode.originalAmt);
                mode.index = menuIndex;
            }
            jsonObject.put("menuClsTotalAmt", menuClsTotalAmt);
            jsonObject.put("menuItemList", JSON.toJSON(tempData));
            result.add(jsonObject);
            menuItemGroup.remove(menuType.fsMenuClsId);
        }
        //根据分类排序后，剩下的数据处理
        if (menuItemGroup.size() > 0) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "无分类");
            List<PrintBillMenuItemMode> residualData = new ArrayList<>();
            BigDecimal menuClsTotalAmt = BigDecimal.ZERO;
            for (String key : menuItemGroup.keySet()) {
                for (PrintBillMenuItemMode mode : menuItemGroup.get(key)) {
                    String menuIndex;
                    //退菜不计入排序
                    if(!TextUtils.isEmpty(mode.fsItemName) && mode.fsItemName.contains("[退]")){
                        menuIndex = " ";
                    }else{
                        menuIndex = ""+dataId;
                        dataId++;
                    }
                    mode.index = menuIndex;
                    residualData.add(mode);
                    menuClsTotalAmt = menuClsTotalAmt.add(mode.originalAmt);
                }
            }
            jsonObject.put("menuClsTotalAmt", menuClsTotalAmt);
            jsonObject.put("menuItemList", JSON.toJSON(residualData));
            result.add(jsonObject);
        }
        return result;
    }

    /**
     * 根据单序整理数据
     * 点菜预览单
     *
     * @param originalData 原数据，数据格式为JSONObject
     * @param seqField     单序在原始数据中所存字段名称
     * @return
     */
    public static List<JSONObject> groupJSONItemByTime(List<JSONObject> originalData, String seqField) {
        List<JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(originalData) || TextUtils.isEmpty(seqField)) {
            return result;
        }
        //按单序分组。每个单序下存个list
        String orderSeq = "-1";
        List<JSONObject> orderSeqList = new ArrayList<>();
        for (int i = 0; i < originalData.size(); i++) {
            JSONObject menuItem = originalData.get(i);
            String menuItemSeq = "-1";
            if (menuItem.containsKey(seqField)) {
                menuItemSeq = menuItem.getString(seqField);
            }
            if (!TextUtils.equals(orderSeq, menuItemSeq)) {
                if (!TextUtils.equals(orderSeq, "-1")) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("menuItemList", JSON.toJSON(orderSeqList));
                    jsonObject.put("orderSeq", orderSeq);
                    result.add(jsonObject);
                }
                orderSeqList.clear();
                menuItem.put("menuItemIndex", "" + (i + 1));
                orderSeqList.add(menuItem);
                orderSeq = menuItemSeq;
            } else {
                menuItem.put("menuItemIndex", "" + (i + 1));
                orderSeqList.add(menuItem);
            }
            //最后一个结束
            if (i == originalData.size() - 1) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("menuItemList", JSON.toJSON(orderSeqList));
                jsonObject.put("orderSeq", orderSeq);
                result.add(jsonObject);
            }
        }
        return result;
    }

    /**
     * 根据菜品分类整理数据
     * 点菜单
     *
     * @param itemList 原数据
     * @return
     */
    public static List<JSONObject> groupPrintItemByCls(List<PrintItemDataBean> itemList) {
        MenuClsPrintSortDBUtil.fillMenuCls();
        String sql3 = "select * from " + DBModel.getTableName(MenuClsPrintSortDBModel.class) + " order by fiPrintSortOrder asc";
        // 菜品分类打印排序列表
        List<MenuClsPrintSortDBModel> menuClses = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql3, MenuClsPrintSortDBModel.class);
        addSysMenuCls(menuClses);

        List<JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(menuClses)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "");
            jsonObject.put("menuItemList", itemList);
            result.add(jsonObject);
            return result;
        }
        if (ListUtil.isEmpty(itemList)) {
            return result;
        }

        String shopGUID = HostUtil.getShopID();
        HashMap<String, List<PrintItemDataBean>> menuItemGroup = new HashMap<>(); // <menuClsId, menuItems>
        for (int i = 0; i < itemList.size(); i++) {
            PrintItemDataBean item = itemList.get(i);
            String menuClsId = item.fsMenuClsId;
            MenuclsDBModel rootMenuCls = MenuDBUtil.getRootMenuCls(shopGUID, item.fsMenuClsId);
            if (rootMenuCls != null) {
                menuClsId = rootMenuCls.fsMenuClsId;
            }
            if (!menuItemGroup.containsKey(menuClsId)) {
                menuItemGroup.put(menuClsId, new ArrayList<>());
            }
            menuItemGroup.get(menuClsId).add(item);
        }
        for (int i = 0; i < menuClses.size(); i++) {
            MenuClsPrintSortDBModel menuType = menuClses.get(i);
            if (!menuItemGroup.containsKey(menuType.fsMenuClsId)) {
                continue;
            }
            List<PrintItemDataBean> tempData = menuItemGroup.get(menuType.fsMenuClsId);
            if(ListUtil.isEmpty(tempData)){
                continue;
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", tempData.get(0).fsRootMenuClsName);
            jsonObject.put("menuItemList", JSON.toJSON(tempData));
            result.add(jsonObject);
            menuItemGroup.remove(menuType.fsMenuClsId);
        }
        //根据分类排序后，剩下的数据处理
        if (menuItemGroup.size() > 0) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "无分类");
            List<PrintItemDataBean> residualData = new ArrayList<>();
            for (String key : menuItemGroup.keySet()) {
                residualData.addAll(menuItemGroup.get(key));
            }
            jsonObject.put("menuItemList", JSON.toJSON(residualData));
            result.add(jsonObject);
        }
        return result;
    }

    /**
     * 根据菜品分类整理数据
     * 点菜预览单
     *
     * @param itemList     原始数据
     * @param menuClsField 菜品分类在原始数据中所存字段
     * @return
     */
    public static List<JSONObject> groupJSONItemByCls(List<JSONObject> itemList, String menuClsField) {
        MenuClsPrintSortDBUtil.fillMenuCls();
        String sql3 = "select * from " + DBModel.getTableName(MenuClsPrintSortDBModel.class) + " order by fiPrintSortOrder asc";
        // 菜品分类打印排序列表
        List<MenuClsPrintSortDBModel> menuClses = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql3, MenuClsPrintSortDBModel.class);
        addSysMenuCls(menuClses);
        List<JSONObject> result = new ArrayList<>();
        if (ListUtil.isEmpty(menuClses)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "");
            jsonObject.put("menuItemList", itemList);
            result.add(jsonObject);
            return result;
        }
        if (ListUtil.isEmpty(itemList) || TextUtils.isEmpty(menuClsField)) {
            return result;
        }

        String shopGUID = HostUtil.getShopID();
        // 1 数据按分类分组
        HashMap<String, List<JSONObject>> menuItemGroup = new HashMap<>(); // <menuClsId, menuItems>
        for (int i = 0; i < itemList.size(); i++) {
            JSONObject item = itemList.get(i);
            String menuClsId = "";
            if (item.containsKey(menuClsField)) {
                menuClsId = item.getString(menuClsField);
            }

            MenuclsDBModel rootMenuCls = MenuDBUtil.getRootMenuCls(shopGUID, menuClsId);
            if (rootMenuCls != null) {
                menuClsId = rootMenuCls.fsMenuClsId;
            }

            if (!menuItemGroup.containsKey(menuClsId)) {
                menuItemGroup.put(menuClsId, new ArrayList<>());
            }
            menuItemGroup.get(menuClsId).add(item);
        }
        // 2 按照菜品分类打印顺序将数据归到result列表
        int dataId = 1;//菜品排序编号
        for (int i = 0; i < menuClses.size(); i++) {
            MenuClsPrintSortDBModel menuType = menuClses.get(i);
            if (!menuItemGroup.containsKey(menuType.fsMenuClsId)) {
                continue;
            }
            List<JSONObject> tempData = menuItemGroup.get(menuType.fsMenuClsId);
            if(ListUtil.isEmpty(tempData)){
                continue;
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", tempData.get(0).get("fsRootMenuClsName"));
            for (JSONObject obj : tempData) {
                obj.put("index", dataId);
                dataId++;
            }
            jsonObject.put("menuItemList", JSON.toJSON(tempData));
            result.add(jsonObject);
            menuItemGroup.remove(menuType.fsMenuClsId);
        }
        // 3 根据分类排序后，剩下的数据处理
        if (menuItemGroup.size() > 0) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("menuClsName", "无分类");
            List<JSONObject> residualData = new ArrayList<>();
            for (String key : menuItemGroup.keySet()) {
                for (JSONObject obj : menuItemGroup.get(key)) {
                    obj.put("index", dataId);
                    residualData.add(obj);
                    dataId++;
                }
            }
            jsonObject.put("menuItemList", JSON.toJSON(residualData));
            result.add(jsonObject);
        }
        return result;
    }

    public static List<PrintBillMenuItemMode> turnToPrintMode(List<StatementSellItemModel> items, boolean isOtherBillData) {
        List<PrintBillMenuItemMode> result = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            StatementSellItemModel item = items.get(i);
            if (item == null) {
                continue;
            }
            PrintBillMenuItemMode mode;
            if (isOtherBillData) {
                mode = PrintBillMenuItemMode.createOtherBillMode(item, ""+(i + 1));
            } else {
                mode = PrintBillMenuItemMode.create(item);
            }
            result.add(mode);
        }
        return result;
    }

    /**
     * 根据选择的结账单或预结单模版构建对应的数据
     * @param resultData
     * @param originalData
     * @param sell
     * @param templetKey
     */
    public static void buildBillData(JSONObject resultData,List<StatementSellItemModel> originalData,CustomSellDBModel sell,String templetKey){
        if(APPConfig.isMyd()){
            //使用模版开关
            if(DBMetaUtil.useTemplet()) {
                //得到选择的小票模版id
                String selectedTempletId = getSelectedTempletId(templetKey);
                //结账单-桌台排序
                if (TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_BILL_4) || TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_PREBILL_4)) {
                    //打印预结单和结账单是否合进行并菜品,如果开启了，则不能使用单序和桌台排序模版
                    if (!PayConfig.PRINT_COMBINE_DISHES) {
                        resultData.put("sellorderGroupByTable", groupSellItemByTable(originalData, sell.fsMTableId, sell.fsMTableName));
                        // 由于模板中将免服务费放进了优惠明细，故这里只要有过服务费，就显示
                        sell.fdServiceAmt = sell.fdServiceAmt.add(sell.fdFreeSveAmt);
                    }
                    //结账单-分类排序
                } else if (TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_BILL_3) || TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_PREBILL_3)) {
                    resultData.put("sellorderGroupByCls", groupSellItemByCls(originalData));
                    // 由于模板中将免服务费放进了优惠明细，故这里只要有过服务费，就显示
                    sell.fdServiceAmt = sell.fdServiceAmt.add(sell.fdFreeSveAmt);
                    //结账单-单序排序
                } else if (TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_BILL_2) || TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_PREBILL_2)) {
                    if (!PayConfig.PRINT_COMBINE_DISHES) {
                        resultData.put("sellorderGroupByTime", groupSellItemByTime(originalData));
                        // 由于模板中将免服务费放进了优惠明细，故这里只要有过服务费，就显示
                        sell.fdServiceAmt = sell.fdServiceAmt.add(sell.fdFreeSveAmt);
                    }
                } else if (TextUtils.equals(selectedTempletId, TempletIdManager.ID_DINNER_PREBILL_5)){
                    buildPreBill5Data(resultData,originalData,sell);
                    return;
                }
                resultData.put("Sell", sell);
            }
        }
        //默认数据
        resultData.put("sellorder",turnToPrintMode(originalData, false));
    }

    private static void buildPreBill5Data(JSONObject resultData,List<StatementSellItemModel> originalData,CustomSellDBModel sell){
        List<PrintBillMenuItemMode> result = new ArrayList<>();
        //会员价合计
        BigDecimal memberTotalAmt = BigDecimal.ZERO;
        //原价合计
        BigDecimal originalTotalAmt = BigDecimal.ZERO;
        //原价对应的折扣合计
        BigDecimal originalDiscountAmt = BigDecimal.ZERO;
        //会员价对应的折扣合计
        BigDecimal memberDiscountAmt = BigDecimal.ZERO;
        //优惠
        BigDecimal memberCouponTotalAmt = BigDecimal.ZERO;
        BigDecimal originalCouponTotalAmt = BigDecimal.ZERO;
        //服务费
        BigDecimal memberServiceAmt = BigDecimal.ZERO;
        BigDecimal originalServiceAmt = BigDecimal.ZERO;
        //圆整
        BigDecimal memberRoundAmt = BigDecimal.ZERO;
        BigDecimal originalRoundAmt = BigDecimal.ZERO;

        for (int i = 0; i < originalData.size(); i++) {
            StatementSellItemModel itemModel = originalData.get(i);
            if(itemModel != null){
                PrintBillMenuItemMode billMode = PrintBillMenuItemMode.create(itemModel);
                billMode.index = ""+(i+1);
                //没有赠送并且没有使用会员价，则判断是否绑定了会员，若绑定了，会员价=当前售卖价，若没有，会员价=规格中会员价
                if(itemModel.fiOrderMode != 3 && itemModel.fiPriceTag != 3){
                    if(!TextUtils.isEmpty(sell.fsCardNo)){
                        billMode.vipAmtNew = billMode.fdsaleamt.toPlainString();
                    }else{
                        billMode.vipAmtNew = buildMemberAmt(itemModel).toPlainString();
                    }
                }
                if(TextUtils.isEmpty(billMode.vipAmtNew)){
                    billMode.vipAmtNew = "0";
                }
                if(BigDecimal.ZERO.compareTo(billMode.giftAmt) < 0){
                    billMode.originalAmt = BigDecimal.ZERO;
                }
                if(!TextUtils.isEmpty(billMode.buyGiftName)){
                    billMode.originalAmt = billMode.buyGiftAmt;
                }
                if(!TextUtils.isEmpty(billMode.specialAmtNew)){
                    billMode.originalAmt = itemModel.fdCouponSpecialAmt;
                }
                originalTotalAmt = originalTotalAmt.add(billMode.originalAmt);
                memberTotalAmt = memberTotalAmt.add(new BigDecimal(billMode.vipAmtNew));
                if(!TextUtils.isEmpty(itemModel.fsDiscountId)){
                    if(TextUtils.equals(itemModel.fsDiscountId, DiscountType.CASH)){
                        memberDiscountAmt = memberDiscountAmt.add(itemModel.fdDiscountAmt);
                        originalDiscountAmt = originalDiscountAmt.add(itemModel.fdDiscountAmt);
                    }else{
                        BigDecimal discountRate = new BigDecimal(itemModel.fiDiscountRate).divide(BizConstant.HUNDREND,2, RoundingMode.HALF_UP);
                        memberDiscountAmt = memberDiscountAmt.add(new BigDecimal(billMode.vipAmtNew).multiply(discountRate));
                        originalDiscountAmt = originalDiscountAmt.add(billMode.originalAmt.multiply(discountRate));
                    }
                }
                result.add(billMode);
            }
        }
        //优惠 = 折扣+免服务费+满减+整单立减(其中不包含会员价优惠，赠送，特价，买减，因为与会员价冲突)
        memberCouponTotalAmt = memberCouponTotalAmt.add(memberDiscountAmt);
        originalCouponTotalAmt = originalCouponTotalAmt.add(originalDiscountAmt);

        OrderCache orderCache = OrderSession.getInstance().getOrder(sell.fssellno);
        if(orderCache != null){
            OrderCache cloneOrderCache = orderCache.clone();
            cloneOrderCache.isMember = !orderCache.isMember;
            if(cloneOrderCache.isMember){
                cloneOrderCache.updateAllMenuToMemberPrice("");
            }
            cloneOrderCache.reCalcAllByAll();
            //使用会员价的orderCache，使用原价的orderCache
            OrderCache memberOrderCache,orginalOrderCache;
            if(orderCache.isMember){
                memberOrderCache = orderCache;
                orginalOrderCache = cloneOrderCache;
            }else{
                memberOrderCache = cloneOrderCache;
                orginalOrderCache = orderCache;
            }
            //会员价圆整，服务费，优惠计算
            memberRoundAmt = memberOrderCache.totalRound;
            memberServiceAmt = memberOrderCache.totalService;
            memberCouponTotalAmt = memberCouponTotalAmt.add(memberOrderCache.checkFreeFee() ? memberServiceAmt : BigDecimal.ZERO);
            if(memberOrderCache.couponCut != null){//满减
                memberCouponTotalAmt = memberCouponTotalAmt.add(memberOrderCache.couponCut.fdCutmoney);
            }
            if(memberOrderCache.selectOrderDiscountCut != null){//整单立减
                memberCouponTotalAmt = memberCouponTotalAmt.add(memberOrderCache.selectOrderDiscountCut.fdddv);
            }
            //原价圆整，服务费，优惠计算
            originalRoundAmt = orginalOrderCache.totalRound;
            originalServiceAmt = orginalOrderCache.totalService;
            originalCouponTotalAmt = originalCouponTotalAmt.add(orginalOrderCache.checkFreeFee() ? originalServiceAmt : BigDecimal.ZERO);
            if(orginalOrderCache.couponCut != null){//满减
                originalCouponTotalAmt = originalCouponTotalAmt.add(orginalOrderCache.couponCut.fdCutmoney);
            }
            if(orginalOrderCache.selectOrderDiscountCut != null){//整单立减
                originalCouponTotalAmt = originalCouponTotalAmt.add(orginalOrderCache.selectOrderDiscountCut.fdddv);
            }
        }

        //服务费，圆整为0时，不显示
        int showRound = 0;
        int showService = 0;
        if(memberRoundAmt.compareTo(BigDecimal.ZERO) != 0 || originalRoundAmt.compareTo(BigDecimal.ZERO) != 0){
            showRound = 1;
        }
        if(memberServiceAmt.compareTo(BigDecimal.ZERO) != 0 || originalServiceAmt.compareTo(BigDecimal.ZERO) != 0){
            showService = 1;
        }

        JSONObject sellPay = new JSONObject();
        sellPay.put("showRound",showRound);
        sellPay.put("showService",showService);
        sellPay.put("memberTotalAmt",memberTotalAmt.stripTrailingZeros().toPlainString());
        sellPay.put("originalTotalAmt",originalTotalAmt.stripTrailingZeros().toPlainString());
        sellPay.put("memberServiceAmt",memberServiceAmt.stripTrailingZeros().toPlainString());
        sellPay.put("originalServiceAmt",originalServiceAmt.stripTrailingZeros().toPlainString());
        sellPay.put("memberRoundAmt",memberRoundAmt.stripTrailingZeros().toPlainString());
        sellPay.put("originalRoundAmt",originalRoundAmt.stripTrailingZeros().toPlainString());
        sellPay.put("memberCouponTotalAmt", memberCouponTotalAmt.stripTrailingZeros().toPlainString());
        sellPay.put("originalCouponTotalAmt", originalCouponTotalAmt.stripTrailingZeros().toPlainString());
        //会员价应收
        sellPay.put("memberExpAmt",(memberTotalAmt.subtract(memberCouponTotalAmt).subtract(memberRoundAmt).add(memberServiceAmt)).stripTrailingZeros().toPlainString());
        //原价应收
        sellPay.put("originalExpAmt",(originalTotalAmt.subtract(originalCouponTotalAmt).subtract(originalRoundAmt).add(originalServiceAmt)).stripTrailingZeros().toPlainString());
        resultData.put("sellPay", sellPay);
        resultData.put("sellorder", result);
    }

    private static BigDecimal buildMemberAmt(StatementSellItemModel model){
        if(model == null){
            return BigDecimal.ZERO;
        }
        String memberPrice = DBSimpleUtil.queryString(APPConfig.DB_MAIN,"select fdVIPPrice from tbMenuItemUint where fiItemCd = '"+model.fiItemCd+"' and fiOrderUintCd = '"+model.fiOrderUintCd+"' ");
        if(TextUtils.isEmpty(memberPrice)){
            return model.fdSaleAmt;
        }
        if(model.fiIsEditQty == 1){
            return model.fdSaleQty.subtract(model.fdBackQty).multiply(new BigDecimal(memberPrice)).add(model.fdAddPrice);
        }else{
            return (model.fdSaleQty.subtract(model.fdGiftqty).subtract(model.fdBackQty)).multiply(new BigDecimal(memberPrice).add(model.fdAddPrice));
        }
    }

    /**
     * 返回选择的模版id
     * @return
     */
    public static String getSelectTempletId(String templetKey){
        if(!APPConfig.isMyd() || !DBMetaUtil.useTemplet()){
            return "";
        }
        return PrintDataProcessUtil.getSelectedTempletId(templetKey);
    }

    public static String getSelectedTempletId(String templetKey){
        String sql = "select fsTempletId from tbPrintTempletPrivate where fiSelected=1 and fsTempletKey='" + templetKey + "'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    /**
     * 添加系统预置分类
     */
    private static void addSysMenuCls(List<MenuClsPrintSortDBModel> menuClses) {
        // 系统预置数据
        String sqlQuerySys = "select tbMenuCls.fsShopGUID as fsShopGUID," +
                "tbMenuCls.fsMenuClsId as fsMenuClsId," +
                "tbMenuCls.fsMenuClsName as fsMenuClsName," +
                "tbMenuCls.fiLevel as fiLevel," +
                "tbMenuCls.fiDataSource as fiDataSource," +
                "fiSortOrder as fiPrintSortOrder from tbMenuCls " +
                "where fiDataKind='1' and fsMenuClsId_P='0' order by fiSortOrder asc";
        List<MenuClsPrintSortDBModel> menuClsBySys = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlQuerySys, MenuClsPrintSortDBModel.class);
        if (!ListUtil.isEmpty(menuClsBySys)){
            menuClses.addAll(menuClsBySys);
        }
    }
}
