package com.mwee.android.pos.businesscenter.business.rapid.processor;

import android.text.TextUtils;
import android.util.Log;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.business.einvoice.api.InvoiceDetailResponse;
import com.mwee.android.pos.business.einvoice.model.InvoiceDetailBean;
import com.mwee.android.pos.business.rapid.api.bean.LoopRapidRequest;
import com.mwee.android.pos.business.rapid.api.bean.LoopRapidResponse;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.businesscenter.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.ThirdOrderDBUtil;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.DeliveryApi;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.order.InvoiceState;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2017/4/6.
 */

public class RapidLoop {
    private static final int MSG_REMOVE = 8888;

    /**
     * 秒付轮询方法的入口
     * 只有主站点才需要轮询
     */
    public static void initRapidPayLoop() {
        GlobalLooper.registBasedOn2Minutes(new ILoopCall() {
            @Override
            public void call() {
                //美收银不需要这个轮询
                if (APPConfig.isCasiher()) {
                    GlobalLooper.unRegist(this);
                    return;
                }
                //只有主站点才需要进行轮询，如果还没有激活，则继续轮询
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
//                //6分钟太长
//                final int count = TableBusinessUtil.getOpendTableCount();
//                LogUtil.log("Loop 开始轮秒付,已开台桌台=" + count);
//                if (count < 1) {
//                    GlobalLooper.regist(this, 3);
//                    return;
//                } else {
//                    GlobalLooper.regist(this, 1);
//                }

                final int count = TableBusinessUtil.getOpendTableCount();
                LogUtil.log("Loop 开始轮秒付,已开台桌台=" + count);
                if (count < 1) {
                    GlobalLooper.registBasedOn2Minutes(this, 3);
                } else {
                    GlobalLooper.registBasedOn2Minutes(this, 1);
                }
                LoopRapidRequest request = new LoopRapidRequest();
                BusinessExecutor.execute(request, null, new BusinessCallback() {
                    @Override
                    public boolean success(int i, ResponseData responseData) {
                        try {
                            if (responseData.responseBean != null && responseData.responseBean instanceof LoopRapidResponse) {
                                LoopRapidResponse response = (LoopRapidResponse) responseData.responseBean;
                                if (!ListUtil.isEmpty(response.data)) {
                                    for (RapidGetModel temp : response.data) {
                                        RapidBiz.receiveLoop(temp);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            LogUtil.logError(e);
                        }
                        return true;
                    }

                    @Override
                    public boolean fail(int i, ResponseData responseData) {
                        return false;
                    }
                }, true);

            }
        }, 1);
        GlobalLooper.registBasedOn2Minutes(new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询，如果还没有激活，则继续轮询
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                int netOrderCoun = ThirdOrderDBUtil.optThirdOrderCount();
                //如果门店网络订单很少，则延长轮询时间
                GlobalLooper.registBasedOn2Minutes(this, netOrderCoun < 2 ? 5 : 1);
                NetOrderApi.getAllNetOrderDatasIExecutorCallback("", true, "0,10", null);
//                WechatOrderApi.getDatasFromServer(true, null);
            }
        }, 1);


        //todo 这儿轮询处理口碑预点单  防止漏单情况

        //两小时刷新一次外卖开通配置
        int refreshRefreshConfigPeriod = 60;
        if (BaseConfig.isDEV()) {
            Log.i("rapidloop", "---> change period of loop to 2 minutes in rapidloop");
            refreshRefreshConfigPeriod = 1;
        }
        GlobalLooper.registBasedOn2Minutes(new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询，如果还没有激活，则继续轮询
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                DeliveryApi.optDeliveryStatusForLoop();
            }
        }, refreshRefreshConfigPeriod);


        //一小时获取一次电子发票开票状态
        GlobalLooper.registBasedOn2Minutes(new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询，如果还没有激活，则继续轮询
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                String sql = "SELECT invoiceBusinessNo FROM tbSell WHERE fiInvoiceState NOT IN ('" + InvoiceState.INVOICE_SUCCESS + "', '" + InvoiceState.NO_INVOICING + "') and invoiceBusinessNo != '' and invoiceBusinessNo not null";
                List<String> integerList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                if (!ListUtil.isEmpty(integerList)) {
//                    StringBuilder stringBuilder = new StringBuilder();
//                    //每次最多请求10条，分多次请求发票详情接口，减轻服务器压力
//                    int perMax = 10;
//                    List<String> divideList = new ArrayList<>();
//                    for (int i = 0; i < integerList.size(); i++) {
//                        String businessNo = integerList.get(i);
//                        if (TextUtils.isEmpty(businessNo)) {
//                            continue;
//                        }
//                        stringBuilder.append(businessNo);
//                        if (i == 0 || (i + 1) % perMax != 0 && (i + 1) != integerList.size()) {
//                            //当第一个或当不是10的倍数且不是最后一个拼接','
//                            stringBuilder.append(",");
//                        }
//                        if (i != 0 && (i + 1) % perMax == 0 || (i + 1) == integerList.size()) {
//                            //不是第一个且当是10倍数时或最后一个时
//                            divideList.add(stringBuilder.toString());
//                            stringBuilder.delete(0, stringBuilder.length());
//                        }
//                    }
                    //每次最多请求10条，分多次请求发票详情接口，减轻服务器压力
                    int perMax = 10;
                    List<String> divideList = new ArrayList<>();
                    if (integerList.size() <= perMax) {
                        divideList.add(ListUtil.listToStr(integerList, ","));
                    } else {
                        List<String> tempList = new ArrayList<>();
                        for (int i = 0; i < integerList.size(); i++) {
                            tempList.add(integerList.get(i));
                            if (i != 0 && (i + 1) % perMax == 0 || (i + 1) == integerList.size()) {
                                divideList.add(ListUtil.listToStr(tempList, ","));
                                tempList.clear();
                            }
                        }
                    }

                    //递归请求电子发票详情,消除并发,减轻服务器压力
                    EInvoiceProcess.recursionEInvoiceDetails(divideList, 0);
                }
            }
        }, 30);
    }


}
