package com.mwee.android.pos.businesscenter.module.koubei.service.impl;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.businesscenter.module.koubei.process.KBOrderUtils;
import com.mwee.android.pos.businesscenter.air.dao.ISellDao;
import com.mwee.android.pos.businesscenter.air.dao.ISellOrderDao;
import com.mwee.android.pos.businesscenter.air.dao.ITableBizDao;
import com.mwee.android.pos.businesscenter.air.dao.ITableDao;
import com.mwee.android.pos.businesscenter.air.dao.impl.SellDaoImpl;
import com.mwee.android.pos.businesscenter.air.dao.impl.SellOrderDaoImpl;
import com.mwee.android.pos.businesscenter.air.dao.impl.TableBizDaoImpl;
import com.mwee.android.pos.businesscenter.air.dao.impl.TableDaoImpl;
import com.mwee.android.pos.businesscenter.module.koubei.service.IKBOrderService;
import com.mwee.android.pos.businesscenter.business.koubei.KBMakePrinter;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderApi;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderDBUtils;
import com.mwee.android.pos.businesscenter.business.koubei.future.KBFutureProcessor;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 口碑扫码点菜业务处理
 * Created by qinwei on 2018/8/17.
 */

public class KBOrderServiceImpl implements IKBOrderService {
    private ISellOrderDao sellOrderDao;
    private ISellDao sellDao;
    /**
     * 桌台数据服务
     */
    private ITableDao tableDao;
    /**
     * 桌台业务数据服务
     */
    private ITableBizDao tableBizDao;

    public KBOrderServiceImpl() {
        tableDao = new TableDaoImpl();
        tableBizDao = new TableBizDaoImpl();
        sellDao = new SellDaoImpl();
        sellOrderDao = new SellOrderDaoImpl();
    }

    /**
     * 正餐模式下 商家手动分配桌台
     *
     * @param
     * @return
     */
    @Override
    public String allocationTableOrder(String order_id, String tableId, boolean printMake) {
        synchronized (KBOrderServiceImpl.class) {
            TableBizModel tableBizModel = tableBizDao.queryById(tableId);
            if (tableBizModel != null && !TextUtils.isEmpty(tableBizModel.fssellno)) {
                return "当前桌台已被操作,无法继续分配桌台";
            }
            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);
            MtableDBModel mtableDBModel = TableDBUtil.getMTableById(tableId);
            UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
            //第三方菜品转本地菜品
            ArrayList<MenuItem> tempSelectedMenuList = KBOrderUtils.copyTo((ArrayList<KBPreMenuItemModel>) preOrderCache.dish_details, preOrderCache.memo);
            //第三方菜品转本地菜品
            SubmitOrderCheckNumResult submitOrderCheckNumResult = SellOutServerProcessor.checkSellOutValue(tempSelectedMenuList, false);
            if (!submitOrderCheckNumResult.success) {
                trace(preOrderCache.order_id, submitOrderCheckNumResult.errorMsg, "");
                return submitOrderCheckNumResult.errorMsg;
            }
            //生成orderCache
            OrderCache orderCache = KBOrderUtils.newOrderCache(preOrderCache, true);
            KBOrderUtils.addMenuItems(orderCache, tempSelectedMenuList, userDBModel);
            orderCache.fsmtableid = mtableDBModel.fsmtableid;
            orderCache.fsmtablename = mtableDBModel.fsmtablename;
            orderCache.fsmareaid = mtableDBModel.fsmareaid;
            orderCache.eatTime = preOrderCache.table_time;

            //orderCache入库
            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "KBOrderServiceImpl allocationTableOrder");
            trace(preOrderCache.order_id, "分配桌台 本地单号id[" + orderCache.orderID + "] 订单入库成功", orderCache);

            //生成PaySession
            PaySession paySession = KBOrderUtils.newPaySession(preOrderCache, orderCache, userDBModel);

            //PaySession入库
            OrderSession.getInstance().writePay(orderCache.orderID, true);
            trace(preOrderCache.order_id, "分配桌台 本地单号id[" + orderCache.orderID + "] 支付明细入库成功", paySession);

            //开台
            tableBizDao.doOpenTable(mtableDBModel, orderCache.orderID, userDBModel);
            trace(preOrderCache.order_id, "分配桌台 开台成功啦 tableId[" + mtableDBModel.fsmtableid + "]", mtableDBModel);

            //推送客户端桌台刷新
            NotifyToClient.refreshTableOrOrders();

            /**
             * 1 口碑订单先分配桌台不打印  再核销以后打印   【桌台信息能上传到后台 打印单据正确】
             * 2 口碑订单先进行了核销      再分配桌台后打印 【桌台不能上传到后台  打印单据有误 因为核销以后重新拉取数据  后台桌台名称是下厨时分配 会把本地桌台号覆盖 导致打印有误    为了兼容有两种方法  1 需要在打印的时候拦截 去本地桌台名称 】
             */
            if (printMake) {
                KBMakePrinter.printKBMake(preOrderCache.order_id);
                //点菜单
                //todo 点菜单
                PrintOrderUtil.printRapidMenuList(orderCache, HostUtil.getCurrentHost());
                //传菜单
                PrintOrderUtil.printPassTo(orderCache, preOrderCache.table_time, HostUtil.getCurrentHost());
            }
            //修改本地数据库中取餐号为桌台名称
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set take_no = '" + mtableDBModel.fsmtablename + "' where  order_id = '" + preOrderCache.order_id + "'");
            //todo 上送分配的订单号给后台 有隐患
            new KBPreOrderApi().allocationTable(order_id, preOrderCache.business_type, preOrderCache.merchant_id, mtableDBModel.fsmtablename, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    return false;
                }
            });
            return "";
        }
    }

    @Override
    public SocketResponse<ScannerTableOrderAcceptResponse> acceptPreOrder(KBPreOrderCache preOrderCache) {
        SocketResponse<ScannerTableOrderAcceptResponse> socketResponse = new SocketResponse<>();
        String lockResult = ServerCache.getInstance().tableLockCache.doLock(preOrderCache.take_no, "", "acceptPreOrder");
        try {
            MtableDBModel mtableDBModel = tableDao.queryByTableNoAndTableQRConfig(preOrderCache.take_no);
            if (mtableDBModel == null || mtableDBModel.fistatus == 13 || mtableDBModel.fistatus == 9) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "桌台信息[" + preOrderCache.take_no + "]不存在,无法接单";
                trace(preOrderCache.order_id, socketResponse.message, "");
                return socketResponse;
            }
            UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
            String hostId = HostUtil.getCurrentHost();
            //第三方菜品转本地菜品
            ArrayList<MenuItem> tempSelectedMenuList = KBOrderUtils.copyTo((ArrayList<KBPreMenuItemModel>) preOrderCache.dish_details, preOrderCache.memo);
            SubmitOrderCheckNumResult submitOrderCheckNumResult = SellOutServerProcessor.checkSellOutValue(tempSelectedMenuList, false);
            if (!submitOrderCheckNumResult.success) {
                socketResponse.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                socketResponse.message = submitOrderCheckNumResult.errorMsg;
                trace(preOrderCache.order_id, submitOrderCheckNumResult.errorMsg, "");
                return socketResponse;
            }

            new KBPreOrderApi().acceptOrder(preOrderCache.order_id, KBConstants.BUSINESS_TYPE_DINNER, KBConstants.ORDER_STYLE_SCAN, preOrderCache.merchant_id, preOrderCache.take_no, new BusinessCallback() {
                @Override
                public boolean success(int i, ResponseData responseData) {
                    //订单标记为已完成
                    KBPreOrderDBUtils.update(preOrderCache.order_id + "", KBConstants.STATUS_FINISH);
                    //todo 仅仅适用于口碑先付款扫码支付
                    KBPreOrderDBUtils.updateTableName(preOrderCache.order_id + "", mtableDBModel.fsmtablename);
                    trace(preOrderCache.order_id, "接单成功", responseData);
                    //即将开台的桌台
                    MtableDBModel willOpenTable = null;
                    if (tableBizDao.queryTableIsOpenedByTableId(mtableDBModel.fsmtableid)) {
                        //桌台被占用，则拼一个桌台进行开台
                        willOpenTable = tableDao.insertShareTable(mtableDBModel, userDBModel);
                        trace(preOrderCache.order_id, "原桌台被占用拼了个台哦 tableId[" + willOpenTable.fsmtableid + "]", willOpenTable);
                    } else {
                        willOpenTable = mtableDBModel;
                    }
                    OrderCache orderCache = KBOrderUtils.newOrderCache(preOrderCache, true);
                    KBOrderUtils.addMenuItems(orderCache, tempSelectedMenuList, userDBModel);
                    //扣库存
                    SellOutServerProcessor.decreaseQuantity(tempSelectedMenuList);
                    orderCache.fsmtableid = willOpenTable.fsmtableid;
                    orderCache.fsmtablename = willOpenTable.fsmtablename;
                    orderCache.fsmareaid = willOpenTable.fsmareaid;
                    //订单入库
                    OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "acceptPreOrder");
                    trace(preOrderCache.order_id, "本地单号id[" + orderCache.orderID + "] 订单入库成功", orderCache);

                    PaySession paySession = KBOrderUtils.newPaySession(preOrderCache, orderCache, userDBModel);
                    //写入支付明细
                    OrderSession.getInstance().writePay(orderCache.orderID, true);
                    trace(preOrderCache.order_id, "本地单号id[" + orderCache.orderID + "] 支付明细入库成功", paySession);
                    //开台
                    boolean result = tableBizDao.doOpenTable(willOpenTable, orderCache.orderID, userDBModel);
                    if (result) {
                        //todo 扫码接单需要退出桌台（解决秒点扫码接单桌台没锁住bug）
                        NotifyToClient.refreshkborderchange(orderCache.fsmtableid, orderCache.fsmtablename);
                        //打印制作单
                        KBMakePrinter.printKBMake(preOrderCache.order_id);
                        //todo 点菜单
                        PrintOrderUtil.printRapidMenuList(orderCache, hostId);
                        PrintOrderUtil.printPassTo(orderCache, hostId);

                        //清空秒点相关信息
                        if (!TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select extra_order from tableBiz where fsmtableid='" + orderCache.fsmtableid + "'"))) {
                            trace(preOrderCache.order_id, "口碑先付款下单导致自动清除桌台上的秒点下单信息", orderCache.fsmtableid);
                            TableBusinessUtil.cleanRapidOrder(orderCache.fsmtableid);
                            MessageDBUtil.updateMessageOrderByTableId(orderCache.fsmtableid, MessageConstance.MessageOrderBuinessStatus.RAPID.IGNORE, userDBModel);
                            NotifyToClient.refrehMessageData();
                        }

                        socketResponse.code = SocketResultCode.SUCCESS;
                        socketResponse.message = "接单成功";
                        NotifyToClient.refreshTableOrOrders();
                        trace(preOrderCache.order_id, "开台成功啦 tableId[" + willOpenTable.fsmtableid + "]", willOpenTable);


                        //todo 正餐模式下 先付款自动清台
                        if (!APPConfig.isAir() && PayUtil.supportPreRapidAutoPay()) {
                            trace(preOrderCache.order_id, "口碑先付款  本地单号id[" + orderCache.orderID + "] 秒付自动清台", "");
                            checkOut(orderCache.orderID, userDBModel);
                        }


                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "接单失败";
                        trace(preOrderCache.order_id, socketResponse.message, "");
                    }
                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    trace(preOrderCache.order_id, "接单失败，" + responseData.resultMessage, "");
                    return false;
                }
            });
            return socketResponse;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockResult, preOrderCache.take_no, "", "acceptPreOrder");
        }
        return socketResponse;
    }

    @Override
    public SocketResponse checkOut(String orderId, UserDBModel userDBModel) {
        SocketResponse response = null;

        try {
            response = new SocketResponse();
            //校验桌台订单与结账订单是否一致
            //订单设置为已结账
//            OrderCache orderCache = orderCacheDao.queryById(orderId);
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            TableBizModel tableBizModel = tableBizDao.queryById(orderCache.fsmtableid);
            if (!TextUtils.equals(tableBizModel.fssellno, orderId)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "结账订单与桌台订单不一致";
                return response;
            }
            //桌台清台
            MtableDBModel mtableDBModel = tableDao.queryById(orderCache.fsmtableid);
            boolean result = tableBizDao.doClearTable(mtableDBModel, orderId, userDBModel);
            if (!result) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "清台失败";
                return response;
            }
            if (!TextUtils.isEmpty(mtableDBModel.fshint)) {
                //如果桌台是拼桌则删除
                tableDao.delete(mtableDBModel.fsmtableid);
            }
            PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, mtableDBModel.fsmtableid, userDBModel, HostUtil.getCurrentHost());
            //打印结账单
            KBMakePrinter.printBill(orderCache.thirdOrderId);
            NotifyToClient.refreshTableOrOrders();
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = e.getMessage();
        }
        //如果桌台是拼桌
        return response;
    }

    @Override
    public void refund(String orderId) {
//        todo 1.调用口碑退款接口

//        todo 2.订单退所有订单菜品

//        todo 3.订单删除所有支付方式

//        todo 4.进行结账，如果桌台为占用，则清除桌台状态信息

//        todo 桌台为拼桌则删除临时桌台
    }

    @Override
    public SocketResponse<ScannerTableOrderAcceptResponse> acceptAfterPayOrder(KBAfterPayOrder afterPayOrder, String hostId) {
        synchronized (KBAfterPayOrder.class) {
            SocketResponse<ScannerTableOrderAcceptResponse> socketResponse = new SocketResponse<>();
            try {
                //找桌台逻辑变动
                String kbOrderId = afterPayOrder.order_id;
                MtableDBModel mtableDBModel = tableDao.queryByTableNoAndTableQRConfig(afterPayOrder.table_no);
                if (mtableDBModel == null || mtableDBModel.fistatus == 13 || mtableDBModel.fistatus == 9) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "桌台信息[" + afterPayOrder.table_no + "]不存在,无法接单";
                    trace(kbOrderId, socketResponse.message, "");
                    return socketResponse;
                }
                if (sellOrderDao.isExistByThirdSeq(afterPayOrder.batch_no)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "已接单,请勿重复提交";
                    traceAfterPay(kbOrderId, socketResponse.message, "");
                    return socketResponse;

                }
                //已结账订单无法接单
                if (sellDao.querySellIsDone(afterPayOrder.out_biz_no, kbOrderId)) {
                    socketResponse.code = SocketResultCode.KB_LOCAL_ORDER_ALREADY_DONE;
                    socketResponse.message = "已结账清台，无法接单";
                    traceAfterPay(kbOrderId, socketResponse.message, "");
                    return socketResponse;
                }
                OrderCache orderCache = null;
                String localOrderId = "";
                TableBizModel tableBizModel = tableBizDao.queryById(mtableDBModel.fsmtableid);
                if (tableBizModel != null && !tableBizModel.isFree()) {
                    orderCache = OrderSession.getInstance().getOrder(tableBizModel.fssellno);
                    if (orderCache == null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单数据异常";
                        traceAfterPay(kbOrderId, socketResponse.message, "");
                        return socketResponse;
                    }
                    if (orderCache.inAntiPaied()) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "订单正在结账，无法接单";
                        traceAfterPay(kbOrderId, socketResponse.message, "");
                        return socketResponse;
                    }
                    //先付款订单已经关联
                    if (orderCache.thirdOrderType == NetOrderType.KB_ORDER) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "桌台已关联先付款订单，订单号[" + orderCache.thirdOrderId + "]，无法接单";
                        traceAfterPay(kbOrderId, socketResponse.message, "");
                        return socketResponse;
                    }
                    localOrderId = orderCache.orderID;
                }
                //本地订单关联的总单id校验
                if (orderCache != null && !TextUtils.isEmpty(orderCache.kbOrderId) && !TextUtils.equals(orderCache.kbOrderId, afterPayOrder.order_id)) {
                    //桌台已关联订单、本地订单关联了口碑订单、本地订单关联的口碑与接单的口碑订单不一致
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "桌台已被占用[" + orderCache.orderID + "]，无法接单";
                    traceAfterPay(kbOrderId, socketResponse.message, "");
                    return socketResponse;
                }
                UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
                //第三方菜品转本地菜品
                ArrayList<MenuItem> tempSelectedMenuList = KBOrderUtils.copyTo(afterPayOrder.dish_list, afterPayOrder.memo);
                //沽清校验
                SubmitOrderCheckNumResult submitOrderCheckNumResult = SellOutServerProcessor.checkSellOutValue(tempSelectedMenuList, false);
                if (!submitOrderCheckNumResult.success) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = submitOrderCheckNumResult.errorMsg;
                    traceAfterPay(kbOrderId, submitOrderCheckNumResult.errorMsg, "");
                    return socketResponse;
                }

                //第一次接单需要生成订单号
                if (TextUtils.isEmpty(localOrderId)) {
                    localOrderId = OrderDriver.generateNewOrderID(true);
                }
                trace(kbOrderId, "调用接单服务接单", "");
                String errorMsg = KBFutureProcessor.acceptFutureOrder(afterPayOrder.order_id, afterPayOrder.batch_no, localOrderId);
                if (!TextUtils.isEmpty(errorMsg)) {
                    trace(kbOrderId, "接单服务返回接单失败:" + errorMsg, "");
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = errorMsg;
                    return socketResponse;
                }
                //扣除库存数量
                SellOutServerProcessor.decreaseQuantity(tempSelectedMenuList);
                boolean hasOpenParamOrderMenuItem = false;
                if (orderCache == null) {
                    //生成新单
                    orderCache = KBOrderUtils.newOrderCache(afterPayOrder, localOrderId, userDBModel);
                    //订单桌台信息
                    orderCache.fsmtableid = mtableDBModel.fsmtableid;
                    orderCache.fsmareaid = mtableDBModel.fsmareaid;
                    orderCache.fsmtablename = mtableDBModel.fsmtablename;
                    //检测是否有开台预点菜品
                    List<MenuItem> openParamOrderMenuItem = OrderBizUtil.getOpenParamOrderMenu(mtableDBModel.fsmareaid, orderCache.personNum, userDBModel.fsUserId, userDBModel.fsUserName);
                    if (!ListUtil.isEmpty(openParamOrderMenuItem)) {
                        trace(kbOrderId, "添加开台预置菜品:", openParamOrderMenuItem);
                        hasOpenParamOrderMenuItem = true;
                        KBOrderUtils.addMenuItems(orderCache, (ArrayList<MenuItem>) openParamOrderMenuItem, userDBModel);
                    }
                    trace(kbOrderId, "即将进行开台 tableId:" + orderCache.fsmtableid + ",tableName:" + orderCache.fsmtablename, "");
                    //开台
                    tableBizDao.doOpenTable(mtableDBModel, orderCache.orderID, userDBModel);
                    trace(kbOrderId, "开台成功 tableId:" + orderCache.fsmtableid + ",tableName:" + orderCache.fsmtablename + "，orderId:" + orderCache.orderID, "");
                }

                if (TextUtils.isEmpty(orderCache.kbOrderId)) {
                    orderCache.kbOrderId = afterPayOrder.order_id;
                    orderCache.kbTableNo = afterPayOrder.table_no;
                    trace(kbOrderId, "绑定口碑订单号orderId:"
                            + orderCache.orderID + ",kbOrderId" + afterPayOrder.order_id
                            + " ，kbTableNo:" + orderCache.kbTableNo, "");
                }
                //设置口碑批次
                orderCache.updateThirdSeq(afterPayOrder.batch_no, userDBModel, hostId);
                //加菜
                KBOrderUtils.addMenuItems(orderCache, tempSelectedMenuList, userDBModel);
                trace(kbOrderId, "添加口碑批次菜品:", tempSelectedMenuList);
                //加菜完入库
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "acceptAfterPayOrder");
                trace(kbOrderId, "写报表库，订单信息:", orderCache);
                trace(kbOrderId, "开始打印点菜单，制作单，传菜单", "");
                int lastSeq = orderCache.optLastSeq();
                if (hasOpenParamOrderMenuItem) {
                    PrintOrderUtil.printRapidMenuList(orderCache, lastSeq - 1, hostId);
                    //开台参数制作单
                    PrintOrderUtil.printMakeOrder(orderCache, hostId, lastSeq - 1);
                    //开台参数传菜单
                    PrintOrderUtil.printPassTo(orderCache, lastSeq - 1, hostId);
                }
                //点菜单
                PrintOrderUtil.printRapidMenuList(orderCache, lastSeq, hostId);
                //制作单
                PrintOrderUtil.printMakeOrder(orderCache, hostId, lastSeq);
                //传菜单
                PrintOrderUtil.printPassTo(orderCache, hostId);
                ScannerTableOrderAcceptResponse response = new ScannerTableOrderAcceptResponse();
                response.status = KBConstants.STATUS_RECEIPT;
                socketResponse.data = response;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "接单成功";

                //todo 为美小二服务 后期优化直接删除
                NotifyToClient.refreshkborderchange(orderCache.fsmtableid, orderCache.fsmtablename);
                if (APPConfig.isMydKouBei()) {
                    //todo 通知副机 刷新口碑订单信息
                    NotifyToClient.refreshKBOrderItem(afterPayOrder.id, KBConstants.STATUS_RECEIPT);
                }

                return socketResponse;
            } catch (Exception e) {
                e.printStackTrace();
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = e.getMessage();
                trace(afterPayOrder.order_id, "系统出错:" + e.getMessage(), "");
            }
            return socketResponse;
        }
    }


    private void trace(String kbOrderId, String msg, Object object) {
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "kbOrderId[" + kbOrderId + "] ->" + msg, "", object);
    }

    private void traceAfterPay(String kbOrderId, String msg, Object object) {
        RunTimeLog.addLog(RunTimeLog.KB_AFTER_PAY_ORDER, "kbOrderId[" + kbOrderId + "] ->" + msg, "", object);
    }
}
