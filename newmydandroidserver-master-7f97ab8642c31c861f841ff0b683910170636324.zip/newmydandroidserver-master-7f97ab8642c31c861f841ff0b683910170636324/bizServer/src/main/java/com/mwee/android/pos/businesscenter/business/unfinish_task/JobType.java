package com.mwee.android.pos.businesscenter.business.unfinish_task;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Created by virgil on 2017/3/2.
 * <p>
 * 由于客户端比较多且同步开发，所以会存在key值冲突的问题。
 * 所以加KEY之前请到WIKI上去确认该值是否已被使用，同时要记得把新增的KEY同步到wiki上
 * WIKI地址：<a href='http://wiki.mwbyd.cn/pages/viewpage.action?pageId=18959595'>JobType 定义</a>
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Target({METHOD, PARAMETER, FIELD, LOCAL_VARIABLE})
public @interface JobType {
    //秒付退款；
    int REFUND_RAPID = 0;
    //会员退款(积分/消费券)；
    int REFUND_MEMBER = 1;
    //网络支付退款
    int REFUND_NET = 2;
    //会员储值退款
    int REFUND_MEMBER_BALANCE = 3;
    //会员赠送
    int MEMBER_GIFT = 4;
    //定时刷新网络订单
    int NETORDER_REFRESH = 5;
    //定时登录中控
    int LOGINPD = 6;
    //定时上报xmpp状态
    int XMPP_STATE = 7;

    /**
     * 账单定时传至第三方后台
     */
    int BILL_UPLOAD = 8;
    /**
     * 轮询隐藏订单
     */
    int BILL_HIDDEN = 9;
    /**
     * 轮询同步账单上传状态
     */
    int BILL_STATUS_SYNC = 10;

    /**
     * 存储日报表
     */
    int SAVE_DAILY_REPORT = 11;
    /**
     * 会员充值结果查询
     */
    int MEMBER_RECHARGE_QUERY_RESULT = 12;
    /**
     * 美收银Token验证
     */
    int CASH_LOGINPD = 13;

    /**
     * 美易点---上报'门店当天结算汇总数据入库'
     */
    int SUMMARY = 14;

    /**
     * 口碑制作单延时打印
     */
    int KB_PRINTER = 15;

    /**
     * 存储自然日的报表
     */
    int SAVE_REPORT_NATURE = 16;
    /**
     * 查询支付二维码前缀
     */
    int QUERY_PAY_BARCODE_PREFIX = 17;

    /**
     * 轮询检测存储自然日报表的 Job 任务
     */
    int CHECK_REPORT_NATURE_JOB = 18;

    /**
     * 电子发票冲红(废弃)
     */
    int INVOICE_DEPRECATED = 19;

    /**
     * 取消在线挂账
     */
    int REFUND_ONLINE_HUNG = 20;

    /**
     * 查询会员配置
     */
    int QUERY_MEMBER_CONFIG = 21;

    /**
     * 查询支付开通状态
     */
    int QUERY_SHOP_PAY_STATUS = 22;

    /**
     * 口碑后付退款
     */
    int REFUND_KOUBEI_AFTER_PAY = 23;

    /**
     * 会员储值退款---会员重构，对接新接口
     * 美易点pro3.3.2及后续版本开始使用新接口
     */
    int REFUND_MEMBER_BALANCE_NEW = 24;


    /**
     * 会员回退积分、优惠券---会员重构，对接新接口
     * 美易点pro3.3.2及后续版本开始使用新接口
     */
    int REFUND_MEMBER_NEW = 25;

    /**
     * 会员赠送---会员重构，对接新接口
     * 美易点pro3.3.2及后续版本开始使用新接口
     */
    int MEMBER_GIFT_NEW = 26;

    /**
     *  新会员充值结果查询
     */
    int NEW_MEMBER_RECHARGE_QUERY_RESULT = 28;

    int value();
}
