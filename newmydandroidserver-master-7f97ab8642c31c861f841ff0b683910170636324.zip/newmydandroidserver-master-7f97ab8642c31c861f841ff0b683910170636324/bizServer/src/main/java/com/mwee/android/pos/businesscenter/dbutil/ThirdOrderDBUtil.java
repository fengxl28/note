package com.mwee.android.pos.businesscenter.dbutil;

import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.netbiz.wechatOrder.WechatOrderDBUtil;

/**
 * Created by liuxiuxiu on 2017/9/13.
 * 第三方订单
 */

public class ThirdOrderDBUtil {

    /**
     * 获取第三方订单总数
     * 网络订单+微信外卖
     *
     * @return
     */
    public static int optThirdOrderCount() {
        return NetOrderDBUtil.getNetOrderCount() + WechatOrderDBUtil.getWechatOrderCount();
    }
}
