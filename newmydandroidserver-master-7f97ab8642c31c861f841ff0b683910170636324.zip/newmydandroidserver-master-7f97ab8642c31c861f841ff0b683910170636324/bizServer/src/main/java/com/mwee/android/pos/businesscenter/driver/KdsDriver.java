package com.mwee.android.pos.businesscenter.driver;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.business.kds.KDSUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.kds.algorithm.KdsAlgorithm;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.kds.QueryByChefResponse;
import com.mwee.android.pos.connect.business.kds.QueryByProductionResponse;
import com.mwee.android.pos.connect.business.kds.QueryDutyMemberResponse;
import com.mwee.android.pos.connect.business.kds.bean.ChefOrderViewBean;
import com.mwee.android.pos.connect.business.kds.bean.KdsDutyViewBean;
import com.mwee.android.pos.connect.business.kds.bean.KdsMenuViewBean;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.bind.HostCls;
import com.mwee.android.pos.db.business.kds.KdsBarcodeState;
import com.mwee.android.pos.db.business.kds.KdsMakeState;
import com.mwee.android.pos.db.business.kds.KdsMenuItemStateDBModel;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * @ClassName: KdsDriver
 * @Description: kds 业务服务
 * @author: Cannan
 * @date: 2018/11/13 下午4:07
 */
public class KdsDriver implements IDriver {

    public static final String TAG = "kds";

    @Override
    public String getModuleName() {
        return TAG;
    }

    @DrivenMethod(uri = TAG + "/queryDutyMemberStatus")
    public SocketResponse<QueryDutyMemberResponse> queryDutyMembers(SocketHeader header, String param) {
        SocketResponse<QueryDutyMemberResponse> response = new SocketResponse();
        QueryDutyMemberResponse data = new QueryDutyMemberResponse();
        response.data = data;
        try {
            List<KdsDutyViewBean> userDBModels = KDSUtils.queryDutyMembersStatus(header.hd);
            if (userDBModels == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "当前站点未绑定厨师";
            } else {
                response.code = SocketResultCode.SUCCESS;
                response.message = "成功";
                response.data.dutyList = userDBModels;
            }
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
            e.printStackTrace();
        }
        return response;
    }

    /**
     * 覆盖档口绑定关系，并返回所有绑定关系
     */
    @DrivenMethod(uri = TAG + "/changeDutyState")
    public SocketResponse<QueryDutyMemberResponse> changeDutyState(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse<QueryDutyMemberResponse> response = new SocketResponse();
        QueryDutyMemberResponse data = new QueryDutyMemberResponse();
        response.data = data;
        try {
            List<KdsDutyViewBean> paramValue = JSON.parseArray(JSON.parseObject(param).getString("updateValue"), KdsDutyViewBean.class);
            List<KdsDutyViewBean> results = KDSUtils.updateDutyMembers(header.hd, paramValue);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
            response.data.dutyList = results;
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
            e.printStackTrace();
        }
        return response;
    }

    /**
     * 总厨大屏幕显示
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryByChef")
    public SocketResponse queryByChef(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        QueryByChefResponse data = new QueryByChefResponse();
        response.data = data;
        data.businessDate = HostUtil.getHistoryBusineeDate("");
        try {
            HostDBModel host = HostUtil.queryById(header.hd);
            if (host == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "站点信息错误，请稍后重试";
                return response;
            }
            if (host.fiHostCls != HostCls.Kitchen) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "该站点不是KDS大屏站点";
                return response;
            }
            RunTimeLog.addLog(RunTimeLog.KDS_SERVICE, "总厨大屏站点[" + header.hd + "]最大显示订单数[" + host.fiOrderDispNumber + "], 仅显示订单来源[" + host.fiOrderSource + "]");

            String businessDate = HostUtil.getHistoryBusineeDate("");
            statisticsSellNum(data, businessDate);

            // 查询单头信息
            // todo fiSellType 订单类型，需要体现在订单的单头里
            //     * 0：正餐；
            //     * 1：快餐；
            //     * 2：外卖；
            //     * 3：纯收银
            //     * 4口碑预点单[快餐类型]
            String sql3 = "" +
                    "select tbsell.fsSellNo as fsSellNo, fsMTableName,tbsell.fsMealNumber,tbsell.fiSellType, tbsell.fsCreateTime as fsCreateTime\n" +
                    "from tbsell\n" +
                    "           left join tablebiz on tbsell.fssellno = tablebiz.fssellno\n" +
                    "where fsSellDate = '" + businessDate + "'\n" +
                    "  and tbsell.fssellno in (select fssellno from tbKdsMenuItemState where fistate not in ('3', '4', '5') " +
                    "group by fssellno)\n" +
                    "order by fsCreateTime desc \n";
            if (host.fiOrderDispNumber > 0) {
                sql3 += " limit " + host.fiOrderDispNumber;
            }
            List<JSONObject> sellList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql3);

            List<ChefOrderViewBean> orderList = new ArrayList<>();
            data.orderList = orderList;

            // 构建订单明细
            if (sellList != null) {
                for (JSONObject sell : sellList) {
                    if (sell == null) {
                        continue;
                    }
                    ChefOrderViewBean bean = buildChefOrder(sell);
                    if (bean == null) {
                        continue;
                    }
                    orderList.add(bean);
                }
            }

            List<TempAppOrder> allOrders = NetOrderDBUtil.getAllOrdersForKDS(1, data.businessDate, null);
            if (!ListUtil.isEmpty(allOrders)) {
                for (TempAppOrder wmOrder : allOrders) {
                    ChefOrderViewBean chefOrderViewBean = new ChefOrderViewBean();
                    String orderID = wmOrder.orderId;
                    chefOrderViewBean.orderID = orderID;
                    try {
                        chefOrderViewBean.restNum = Integer.parseInt(wmOrder.restNum);
                    } catch (Exception e) {
                    }
                    //2饿了么 /3美团外卖 /4百度外卖 /…103口碑/21 微信外卖
                    if (wmOrder.orderTakeawaySource.contains(TakeAwaySource.ELEME)) {
                        chefOrderViewBean.fsBillSourceId = 2;
                        chefOrderViewBean.fiselltype = 2;
                    } else if (wmOrder.orderTakeawaySource.contains(TakeAwaySource.MEITUAN)) {
                        chefOrderViewBean.fsBillSourceId = 3;
                        chefOrderViewBean.fiselltype = 2;
                    } else if (wmOrder.orderTakeawaySource.contains(TakeAwaySource.MWEE)) {
                        chefOrderViewBean.fsBillSourceId = 21;
                        chefOrderViewBean.fiselltype = 2;
                    }

                    chefOrderViewBean.orderTime = wmOrder.date;
                    buildChefWMOrder(wmOrder, chefOrderViewBean, data);

                    orderList.add(chefOrderViewBean);
                }
            }

        } catch (Exception ex) {
            LogUtil.logError(ex);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 这样做是很不合理的，但是订单的菜品表 里
     *
     * @param wmOrder
     * @param chefOrderViewBean
     */
    private void buildChefWMOrder(TempAppOrder wmOrder, ChefOrderViewBean chefOrderViewBean, QueryByChefResponse data) {

        String sql = "select fsSeq,fiItemCd,name,fiItemKind, fiHurryCount,fiState from tbKdsMenuItemState where fsSellNo='" + wmOrder.orderId + "'";
        List<JSONObject> jsonObjectList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
        for (JSONObject jsonObject : jsonObjectList) {
            KdsMenuViewBean menu = new KdsMenuViewBean();
            String name = jsonObject.getString("name");
            menu.name = name;
            menu.num = BigDecimal.valueOf(1);

            String[] nameItem = name.split(KDSUtils.KDS_MENU_NAME_SEPARATOR);
            if (nameItem.length >= 1) {
                menu.name = nameItem[0].substring(2);
            }
            if (nameItem.length >= 2) {
                menu.unit = nameItem[1].substring(2);
            }
            if (nameItem.length >= 3) {
                menu.note = nameItem[2].substring(2);
            }
            menu.uniq = jsonObject.getString("fsSeq");

            int state = jsonObject.getIntValue("fiState");
            int count = jsonObject.getIntValue("fiHurryCount");


            data.totleNum++;

            if (state == 2) {
                menu.state = KdsMakeState.Making;
                data.makingNum++;
            } else if (state == 1 || state == 0) {
                menu.state = KdsMakeState.Wait;
                data.produced++;
            } else if (state == 3) {
                menu.state = KdsMakeState.Completed;
                data.completed++;
            }
            if (count > 0) {
                menu.urge = 1;
            }

            //todo 超时需要重新计算
//            int timeout = StringUtil.toInt(DBMetaUtil.getConfig(META.KDS_TIMEOUT, "25"), 25);
//            timeout = timeout * 60;
//
//            dayFormat(chefOrderViewBean.orderTime).getTime()-new Date().getTime()
//            data.timeoutNum

            chefOrderViewBean.menuList.add(menu);
        }
    }

    public static Date dayFormat(String time) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(time);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * 构建总厨大屏单头信息
     *
     * @param sell
     * @return
     */
    @Nullable
    private ChefOrderViewBean buildChefOrder(JSONObject sell) {
        ChefOrderViewBean bean = new ChefOrderViewBean();
        bean.orderID = sell.getString("fsSellNo");
        bean.fsMealNumber = sell.getString("fsMealNumber");
        bean.tableName = sell.getString("fsMTableName");
        bean.orderTime = sell.getString("fsCreateTime");
        bean.fiselltype = sell.getIntValue("fiSellType");
        List<KdsMenuViewBean> menuList = new ArrayList<>();
        bean.menuList = menuList;

        // 普通菜
        String sql4 = "" +
                "select fsseq,\n" +
                "       fsItemName,\n" +
                "       (fdSaleQty - fdBackQty) as fdSaleQty,\n" +
                "       fsOrderUint,\n" +
                "       fsNote,\n" +
                "       (case when m.fiHurryCount > 0 then '1' else '0' end)                as urge,\n" +
                "       (case when making > 0 then '2' when wait > 0 then '1' else '3' end) as state\n" +
                "from tbSellOrderItem\n" +
                "       left join (select fsOriginSeq,\n" +
                "                         sum(fiHurryCount)                                      as fiHurryCount,\n" +
                "                         sum(case when fiState = '2' then 1 else 0 end)         as making,\n" +
                "                         sum(case when fiState in ('0', '1') then 1 else 0 end) as wait\n" +
                "                  from tbKdsMenuItemState\n" +
                "                  group by fsOriginSeq) m on tbSellOrderItem.fsSeq = m.fsOriginSeq\n" +
                "where tbSellOrderItem.fsSellNo = '" + bean.orderID + "' and fiOrderItemKind = '1'";
        List<JSONObject> commList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql4);

        // 套餐头
        String sql5 = "" +
                "select fsseq,\n" +
                "       fsItemName,\n" +
                "       (fdSaleQty - fdBackQty)                                             as fdSaleQty,\n" +
                "       fsOrderUint,\n" +
                "       fsNote,\n" +
                "       (case when m.fiHurryCount > 0 then '1' else '0' end)                as urge,\n" +
                "       (case when making > 0 then '2' when wait > 0 then '1' else '3' end) as state\n" +
                "from tbSellOrderItem\n" +
                "       left join (select fsOriginSeq_M,\n" +
                "                         sum(fiHurryCount)                                      as fiHurryCount,\n" +
                "                         sum(case when fiState = '2' then 1 else 0 end)         as making,\n" +
                "                         sum(case when fiState in ('0', '1') then 1 else 0 end) as wait\n" +
                "                  from tbKdsMenuItemState\n" +
                "                  group by fsOriginSeq_M) m on tbSellOrderItem.fsSeq = m.fsOriginSeq_M\n" +
                "where tbSellOrderItem.fsSellNo = '" + bean.orderID + "'\n" +
                "  and fiOrderItemKind = '2';\n";
        List<JSONObject> packageList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql5);

        if (commList == null) {
            commList = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(packageList)) {
            commList.addAll(packageList);
        }

        if (ListUtil.isEmpty(commList)) {
            return null;
        }
        for (JSONObject item : commList) {
            if (item == null) {
                continue;
            }
            BigDecimal num = item.getBigDecimal("fdSaleQty");
            if (BigDecimal.ZERO.compareTo(num) == 0) {
                continue;
            }
            KdsMenuViewBean menu = new KdsMenuViewBean();
            menu.name = item.getString("fsItemName");
            menu.num = num;
            menu.unit = item.getString("fsOrderUint");
            menu.note = item.getString("fsNote");
            menu.urge = item.getIntValue("urge");
            menu.state = item.getIntValue("state");
            menuList.add(menu);
        }
        return bean;
    }

    /**
     * 统计订单数
     *
     * @param data
     * @param businessDate
     */
    private void statisticsSellNum(QueryByChefResponse data, String businessDate) {
        int timeout = StringUtil.toInt(DBMetaUtil.getConfig(META.KDS_TIMEOUT, "25"), 25);
        timeout = timeout * 60;

        // 统计订单数
        String sql2 = "" +
                "select sum(1)                                                               as totalNum,\n" +
                "       sum(case\n" +
                "                 when (julianday('now', 'localtime') * 86400 - julianday(fsCreateTime) * 86400) > " + timeout + " then 1\n" +
                "                 else 0 end)                                                as timeoutNum,\n" +
                "       sum(case when making > 0 then 1 else 0 end)                          as makingNum,\n" +
                "       sum(case when making > 0 then 0 when wait > 0 then 1 else 0 end) as waitNum,\n" +
                "       sum(case when making > 0 then 0 when wait > 0 then 0 else 1 end)     as completeNum\n" +
                "from (select *\n" +
                "      from (select fssellno,\n" +
                "                   sum(case when fistate in ('0', '1') then 1 else 0 end) as wait,\n" +
                "                   sum(case when fistate = '2' then 1 else 0 end)         as making,\n" +
                "                   sum(case when fistate in ('3', '4', '5') then 1 else 0 end)         as complete\n" +
                "            from tbKdsMenuItemState\n" +
                "            where fssellno in (select fssellno from tbsell where fsSellDate = '" + businessDate + "')\n" +
                "            group by fssellno) m\n" +
                "                 left join tbsell on m.fssellno = tbsell.fssellno)";
        JSONObject kdsInfo = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql2);
        if (kdsInfo != null) {
            data.totleNum = kdsInfo.getIntValue("totalNum");
            data.timeoutNum = kdsInfo.getIntValue("timeoutNum");
            data.produced = kdsInfo.getIntValue("waitNum");
            data.makingNum = kdsInfo.getIntValue("makingNum");
            data.completed = kdsInfo.getIntValue("completeNum");
        }
    }

    /**
     * 制作站点根据状态查询菜品
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryByProduction")
    public SocketResponse queryByProduction(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        QueryByProductionResponse data = new QueryByProductionResponse();
        response.data = data;
        try {
            List<DeptDBModel> dept = KDSUtils.queryDeptByHostId(header.hd);
            if (ListUtil.isEmpty(dept)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "站点未绑定制作部门";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            int pageSize = request.getIntValue("pageSize");
            int pageNum = request.getIntValue("pageNum");
            int state = request.getIntValue("state");

            // 制作中单独处理
            if (KdsMakeState.Making == state) {
                Pair<Integer, Map<String, List<KdsMenuViewBean>>> result = KdsManager.getInstance().queryByMaking(header.hd);
                if (result != null) {
                    data.count = result.first;
                    data.menuListByMaking = result.second;
                }
                return response;
            }

            switch (state) {
                case KdsMakeState.Wait:
                case KdsMakeState.ToBeProduced:
                case KdsMakeState.PendingAllocation: {
                    int num = 0;
                    List<Pair<String, List<String>>> dishPotByDept = new ArrayList<>();
                    for (DeptDBModel model : dept) {
                        Pair<Integer, List<List<String>>> dishByDept = KdsAlgorithm.getInstance().queryDishIdByAlg(model.fsDeptId, state);
                        if (dishByDept == null) {
                            continue;
                        }
                        num += dishByDept.first;
                        if (!ListUtil.isEmpty(dishByDept.second)) {
                            for (List<String> pot : dishByDept.second) {
                                dishPotByDept.add(new Pair<>(model.fsDeptId, pot));
                            }
                        }
                    }
                    data.count = num;

                    if (!ListUtil.isEmpty(dishPotByDept)) {
                        int min = (pageNum - 1) * pageSize;
                        if (min > num || min < 0) {
                            min = 0;
                        }
                        int max = pageNum * pageSize;
                        if (max > num) {
                            max = num;
                        }
                        dishPotByDept = dishPotByDept.subList(min, max);

                        List<KdsMenuViewBean> result = new ArrayList<>();
                        if (!ListUtil.isEmpty(dishPotByDept)) {
                            for (Pair<String, List<String>> pair : dishPotByDept) {
                                if (pair == null) {
                                    continue;
                                }
                                result.addAll(KdsAlgorithm.getInstance().convertAlgorithmResultByPot(pair.first, pair.second, state));
                            }
                        }
                        data.menuList = result;
                    }
                    return response;
                }
                case KdsMakeState.Completed:
                case KdsMakeState.Retired: {
                    Pair<Integer, List<KdsMenuViewBean>> result = KdsAlgorithm.getInstance().queryDishIdByLocal(header.hd, state, pageSize, pageNum);
                    if (result != null) {
                        data.count = result.first;
                        data.menuList = result.second;
                    }
                    return response;
                }
                default:
                    break;
            }

//            int num = 0;
//            List<KdsMenuViewBean> menuList = new ArrayList<>();
//            for (DeptDBModel model : dept) {
//                Pair<Integer, List<KdsMenuViewBean>> menuByDept = KdsManager.getInstance().query(model.fsDeptId, state, 0, 0);
//                if (menuByDept == null) {
//                    continue;
//                }
//                num += menuByDept.first;
//                if (!ListUtil.isEmpty(menuByDept.second)) {
//                    menuList.addAll(menuByDept.second);
//                }
//            }
//
//            if (!ListUtil.isEmpty(menuList)) {
//
//                int min = (pageNum - 1) * pageSize;
//                if (min > menuList.size() || min < 0) {
//                    min = 0;
//                }
//                int max = pageNum * pageSize;
//                if (max > menuList.size()) {
//                    max = menuList.size();
//                }
//
//                data.count = menuList.size();
//                data.menuList = menuList.subList(min, max);
//            }
        } catch (Exception ex) {
            LogUtil.logError(ex);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 制作站点查询菜品明细
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryDtlByProduction")
    public SocketResponse queryDtlByProduction(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        QueryByProductionResponse data = new QueryByProductionResponse();
        response.data = data;
        try {
            List<DeptDBModel> dept = KDSUtils.queryDeptByHostId(header.hd);
            if (ListUtil.isEmpty(dept)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "站点未绑定制作部门";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            String uniq = request.getString("uniq");
            String deptId = request.getString("deptId");
            int state = request.getIntValue("state");

            if (TextUtils.isEmpty(uniq)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "菜品标识不能为空";
                return response;
            }

            if (TextUtils.isEmpty(deptId)) {
                if (dept.size() > 1) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "查询部门为空";
                    return response;
                } else {
                    deptId = dept.get(0).fsDeptId;
                }
            }

            List<KdsMenuItemStateDBModel> menuList = null;

            switch (state) {
                case KdsMakeState.Wait:
                case KdsMakeState.ToBeProduced:
                    menuList = KDSUtils.queryDishByPotId(uniq, deptId, state);
                    break;
                case KdsMakeState.Making:
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "暂不支持查询[制作中]明细";
                    return response;
                case KdsMakeState.Completed:
                    menuList = KDSUtils.queryDishByBarcode(uniq, deptId, state);
                    break;
                case KdsMakeState.PendingAllocation:
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "暂不支持查询[待分配]明细";
                    return response;
                case KdsMakeState.Retired:
                    menuList = KDSUtils.queryDishByBarcode(uniq, deptId, state);
                    break;
                default:
                    break;
            }

            if (ListUtil.isEmpty(menuList)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "拼菜信息变更，请刷新页面";
                return response;
            }

            List<KdsMenuViewBean> result = new ArrayList<>();
            for (KdsMenuItemStateDBModel model : menuList) {
                if (model == null) {
                    continue;
                }
                KdsMenuViewBean bean = model.convert(KdsMakeState.Unknown, BigDecimal.ONE);
                bean.fsDeptId = deptId;
                result.add(bean);
            }
            data.menuList = result;
        } catch (Exception ex) {
            LogUtil.logError(ex);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 划菜
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/serve")
    public SocketResponse serve(SocketHeader header, String param) {
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--" + "--准备进入serve方法--" + param + "--");
        long serveDriverTime = System.currentTimeMillis();
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        QueryByProductionResponse data = new QueryByProductionResponse();
        response.data = data;
        try {
            JSONObject request = JSON.parseObject(param);

            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--KDSUtils.queryDeptByHostId--" + "--准备查询档口列表--" + JSON.toJSONString(header.hd));

            if (ListUtil.isEmpty(KDSUtils.queryDeptByHostId(header.hd))) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "站点未绑定制作部门";
                return response;
            }

            String barcode = request.getString("uniq");

            if (TextUtils.isEmpty(barcode)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "菜品标识不能为空";
                return response;
            }

            if (request.getBooleanValue("isScan") && KDSUtils.isBarcodeWithinStateExist(barcode, KdsBarcodeState.Trashed)) {//判断是否是扫码划菜且小票是否废弃
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--当前小票对应菜品已退，：" + barcode);
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "条码已失效，请扫退菜待分配单";
                return response;
            } else if (KDSUtils.isAllMatchedStateWithinBarcode(barcode, KdsBarcodeState.Served)) {//表示所有的菜均已划掉，则该小票废弃
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--小票菜品已全部划掉：" + barcode);
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "不要重复划菜";
                return response;
            } else if (request.getString("serveCount") == null && KDSUtils.isPartMatchedStateWithBarcode(barcode, KdsBarcodeState.Served)) {//serveCount为空表示整体划菜，isPartMatchedStateWithBarcode是否存在部分划菜
                RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--小票对应菜品已部分划菜：" + barcode);
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "该菜品部分已完成划菜，条码失效，请点击数字继续划菜";
                return response;
            }

            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--KDSUtils.queryDishByPotId--" + "--准备查询条码对应的dishid");
            long startTime = System.currentTimeMillis();
            List<KdsMenuItemStateDBModel> menuTarget = KDSUtils.queryDishByPotId(barcode);
            RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve--KDSUtils.queryDishByPotId--" + (System.currentTimeMillis() - startTime) + "--查询条码对应的dishid完成");

            if (ListUtil.isEmpty(menuTarget)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未找到指定菜品";
                return response;
            }

            // 查询条形码关联的菜品信息
            RunTimeLog.addLog(RunTimeLog.KDS_SERVICE, "KdsDriver#serve--#DBSimpleUtil.queryStringList--" + System.currentTimeMillis() + "--准备查询条形码对应的档口信息");
            startTime = System.currentTimeMillis();
            //这里必须对档口去重处理，否则同一个档口会重复划菜多次
            List<String> deptIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select distinct(fsDeptId) from tbKdsMenuItemState where fsPotSeq = '" + barcode + "'");
            RunTimeLog.addLog(RunTimeLog.KDS_SERVICE, "并菜标识[" + barcode + "]的菜品，关联制作部门[" + JSON.toJSONString(deptIdList) + "]");

            if (ListUtil.isEmpty(deptIdList)) {
                LogUtil.logError("并菜标识[" + barcode + "]的菜品无关联制作部门");
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未找到Barcode关联的打印部门";
            } else {
                KdsManager.getInstance().lastServedDeptIds = deptIdList;
                for (String deptIdWithBarcode : deptIdList) {
                    //划菜数量
                    int serveCount = menuTarget.size();
                    if (request.getString("serveCount") != null) {
                        serveCount = Integer.valueOf(request.getString("serveCount"));
                    }

                    // 标识位，是否是待分配退菜单
                    boolean isUnAssign = menuTarget.get(0).fsSeq.startsWith(KdsAlgorithm.ALGORITHM_RETREATED_PREFIX);

                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve 准备调用KDSManager开始档口[" + deptIdWithBarcode + "]划菜,[isUnAssign]" + isUnAssign + ",[划菜数量]" + serveCount);
                    startTime = System.currentTimeMillis();
                    KdsManager.getInstance().delimit(barcode, deptIdWithBarcode, menuTarget.get(0).name, menuTarget.get(0).fiItemCd, new BigDecimal(serveCount), isUnAssign, header.hd, HostUtil.getUserModelBySession(header.us));

                    RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve " + (System.currentTimeMillis() - startTime) + " 调用KDSManager划菜完成");
                }
            }
        } catch (Exception ex) {
            LogUtil.logError(ex);
            response.code = SocketResultCode.EXCEPTION;
        }
        RunTimeLog.addLog(RunTimeLog.KDS_RUNTIME, "KdsDriver#serve[" + (System.currentTimeMillis() - serveDriverTime) + "]划菜主流程结束");

        return response;
    }

    /**
     * 取消划菜
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/cancel_serve")
    public SocketResponse cancelServer(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            if (ListUtil.isEmpty(KDSUtils.queryDeptByHostId(header.hd))) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "站点未绑定制作部门";
                return response;
            }

            if (ListUtil.isEmpty(KdsManager.getInstance().lastServedDeptIds)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "无可撤销档口信息";
                return response;
            }

            for (String deptId : KdsManager.getInstance().lastServedDeptIds) {
                KdsManager.getInstance().cancelDelimit(deptId, header.hd, HostUtil.getUserModelBySession(header.us));
            }
            KdsManager.getInstance().lastServedDeptIds.clear();
        } catch (Exception ex) {
            LogUtil.logError(ex);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }
}
