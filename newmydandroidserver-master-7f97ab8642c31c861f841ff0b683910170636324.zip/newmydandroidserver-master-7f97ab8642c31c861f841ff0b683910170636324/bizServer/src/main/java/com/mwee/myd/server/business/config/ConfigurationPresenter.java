package com.mwee.myd.server.business.config;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.configuration.core.IConfigurationPresenter;
import com.mwee.android.configuration.net.bean.AppBean;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;

import java.io.File;

/**
 * @ClassName: ConfigurationPresenter
 * @Description:
 * @author: SugarT
 * @date: 2017/8/24 上午10:12
 */
public class ConfigurationPresenter implements IConfigurationPresenter {

    @Override
    public boolean checkValid(File file) {
        if (file == null) {
            return false;
        }
        if (!file.exists()) {
            return false;
        }
        if (!file.isFile()) {
            return false;
        }
        if (!ConfigFileUtils.isValidZipFile(file.getAbsolutePath())) {
            return false;
        }
        return true;
    }

    @Override
    public void checkFail() {
        // TODO: 2017/8/24  未能成功调用网络接口检测
        LogUtil.log("配置检测失败");
    }

    @Override
    public void callBackToUser(boolean b, AppBean appBean) {
        // TODO: 2017/8/24 接口检测成功
        LogUtil.log("配置检测成功, 是否有新的配置[" + b + "], ");
    }

    @Override
    public void downloaded(File file) {
        if (file == null) {
            return;
        }
        // 删除所有原有配置文件
        String dirPath = ConfigConstant.getConfigDirPath(GlobalCache.getContext());
        FileUtil.deleteAllFile(dirPath);
        // 解压缩配置文件到指定目录
        ConfigFileUtils.unZip(file.getAbsolutePath(), dirPath);
    }

    @Override
    public String getCheckHistoryFileName() {
        return "";
    }

    @Override
    public String getCheckResponseKey() {
        return "";
    }

    @Override
    public String fileFormat() {
        return "";
    }
}
