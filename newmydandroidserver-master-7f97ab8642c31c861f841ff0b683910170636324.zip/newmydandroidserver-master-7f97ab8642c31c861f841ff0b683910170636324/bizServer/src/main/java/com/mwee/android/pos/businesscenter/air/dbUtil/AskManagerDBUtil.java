package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.ask.AirAskGroupManagerInfo;
import com.mwee.android.air.db.business.ask.AirAskManageInfo;
import com.mwee.android.air.util.DBPrimaryKeyUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.AskgpDBModel;
import com.mwee.android.pos.db.business.AskgpMenuClsDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * //============================================================
 * //	Table:		tbAsk				要求内容表
 * //============================================================
 * CREATE TABLE tbAsk
 * (
 * fsAskGpId		VARCHAR(6)		NOT NULL	--菜品要求分组代号
 * ,fiId			int			NOT NULL	--流水号;自增号
 * ,fsAskName		VARCHAR(50)		NOT NULL	--要求名称
 * ,fdAddPrice		NUMERIC(18,6)				--加价
 * ,fiItemCd		int					--菜品內码;作法组-菜品私用
 * ,fiStatus		Int			NOT NULL	--状态;1正常/13删除
 * ,fsUpdateTime		VARCHAR(20)				--修改日期时间
 * ,fsUpdateUserId		VARCHAR(20)				--修改用户代码
 * ,fsUpdateUserName	VARCHAR(30)				--修改用户名称
 * ,fsShopGUID		VARCHAR(80)		NOT NULL	--门店GUID
 * ,CONSTRAINT pk_tbAsk PRIMARY KEY(fiId,ShopGUID)
 * );
 * Created by liuxiuxiu on 2017/10/14.
 */

public class AskManagerDBUtil {

    public static List<AskgpDBModel> queryAllAskGp() {
        String sql = "select * from tbaskgp where fistatus = '1'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AskgpDBModel.class);
    }

    public static List<AirAskGroupManagerInfo> optAllAskGroupList() {
        String sql = "select fsAskGpId,fsAskGpName, fiUseAllMenuCls from tbaskgp where fistatus = '1' order by fisortorder asc, fsAskGpId desc";
        List<AirAskGroupManagerInfo> airAskGroupManagerInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirAskGroupManagerInfo.class);
        if (ListUtil.isEmpty(airAskGroupManagerInfos)) {
            airAskGroupManagerInfos = new ArrayList<>();
        } else {
            airAskGroupManagerInfos.add(0, optDefaultAirAskGroupManagerInfo());
        }

        List<JSONObject> jsonObjectList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select fsAskGpId,fsMenuClsId from tbaskgpmenucls where fistatus = '1'");
        if (!ListUtil.isEmpty(jsonObjectList)) {
            for (JSONObject jsonObject : jsonObjectList) {
                for (AirAskGroupManagerInfo airAskGroupManagerInfo : airAskGroupManagerInfos) {
                    if (TextUtils.equals(jsonObject.getString("fsAskGpId"), airAskGroupManagerInfo.fsAskGpId)) {
                        List<String> menClsIdList = airAskGroupManagerInfo.fsMenuClsIdList;
                        if (ListUtil.isEmpty(menClsIdList)) {
                            menClsIdList = new ArrayList<>();
                            airAskGroupManagerInfo.fsMenuClsIdList = menClsIdList;
                        }
                        menClsIdList.add(jsonObject.getString("fsMenuClsId"));
                        break;
                    }
                }
            }
        }

        return airAskGroupManagerInfos;
    }

    public static List<AirAskManageInfo> optAllAskList() {
        String sql = "select fsAskGpId,fiId, fsAskName,fdAddPrice from tbAsk where fistatus = '1'";
        List<AirAskManageInfo> airAskManageInfos = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirAskManageInfo.class);
        if (ListUtil.isEmpty(airAskManageInfos)) {
            airAskManageInfos = new ArrayList<>();
        }
        return airAskManageInfos;
    }

    private static AirAskGroupManagerInfo optDefaultAirAskGroupManagerInfo() {
        AirAskGroupManagerInfo airAskGroupManagerInfo = new AirAskGroupManagerInfo();
        airAskGroupManagerInfo.fsAskGpName = "全部要求";
        return airAskGroupManagerInfo;
    }

    /**
     * 新增要求分组
     *
     * @param askGpName
     * @param userDBModel
     * @return
     */
    public static synchronized String doAddAskGp(String askGpName, boolean all, List<String> menuClsIdList, UserDBModel userDBModel) {
        String checkSql = "select * from tbaskgp where fsAskGpName = '" + askGpName + "' and fistatus = '1'";
        AskgpDBModel askgpDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, AskgpDBModel.class);
        if (askgpDBModel != null) {
            if (askgpDBModel.fiStatus == 13) {
                askgpDBModel.fiStatus = 1;
                askgpDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                if (userDBModel != null) {
                    askgpDBModel.fsUpdateUserName = userDBModel.fsUserName;
                    askgpDBModel.fsUpdateUserId = userDBModel.fsUserId;
                }
                askgpDBModel.sync = 1;
            } else {
                return "'" + askGpName + "'已存在";
            }
        } else {
            askgpDBModel = new AskgpDBModel();
            askgpDBModel.fsAskGpId = IDHelper.generateAskGpId();
            askgpDBModel.fiStatus = 1;
            askgpDBModel.fiDataKind = 2;
            askgpDBModel.fsAskGpName = askGpName;
            askgpDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            askgpDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                askgpDBModel.fsUpdateUserName = userDBModel.fsUserName;
                askgpDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            askgpDBModel.fiSortOrder = generateSortOrder();
            askgpDBModel.fiDataSource = 1;
            askgpDBModel.sync = 1;
        }

        if (all) {
            askgpDBModel.fiUseAllMenuCls = 1;
        } else {
            askgpDBModel.fiUseAllMenuCls = 0;
        }
        askgpDBModel.replaceNoTrans();

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbaskgpmenucls set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + askgpDBModel.fsAskGpId + "' and fistatus= '1' ");
        if (!all && !ListUtil.isEmpty(menuClsIdList)) {
            addAskGPMenuCls(askgpDBModel.fsAskGpId, menuClsIdList, userDBModel);
        }
        MetaDBController.updateSyncTime();

        return "";
    }

    /**
     * 修改要求分组
     *
     * @param fsAskGpId
     * @param fsAskGpName
     * @param userDBModel
     * @return
     */
    public static synchronized String updateAskGpName(String fsAskGpId, String fsAskGpName, boolean all, List<String> menuClsIdList, UserDBModel userDBModel) {
        String checkSql = "select * from tbaskgp where fsAskGpId = '" + fsAskGpId + "'";
        AskgpDBModel askgpModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, AskgpDBModel.class);
        if (askgpModel == null || askgpModel.fiStatus == 13) {
            return "未找到该分组";
        } else {
            String oldfsAskGpId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, " select fsAskGpId from tbaskgp where fsAskGpName = '" + fsAskGpName + "' and fistatus = '1' and fsAskGpId <> '" + fsAskGpId + "'");
            if (!TextUtils.isEmpty(oldfsAskGpId)) {
                return fsAskGpName + " 分组已存在";
            }
            askgpModel.fsAskGpName = fsAskGpName;
            askgpModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                askgpModel.fsUpdateUserName = userDBModel.fsUserName;
                askgpModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            askgpModel.sync = 1;

            if (all) {
                askgpModel.fiUseAllMenuCls = 1;
            } else {
                askgpModel.fiUseAllMenuCls = 0;
            }

            askgpModel.replaceNoTrans();

            if (all || ListUtil.isEmpty(menuClsIdList)) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbmenuitemaskgp set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + fsAskGpId + "' and fistatus= '1' ");
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbaskgpmenucls set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + fsAskGpId + "' and fistatus= '1' ");
                return "";
            }

            if (!ListUtil.isEmpty(menuClsIdList)) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbaskgpmenucls set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + fsAskGpId + "' and fistatus= '1' ");
                addAskGPMenuCls(fsAskGpId, menuClsIdList, userDBModel);
            }
            MetaDBController.updateSyncTime();
            return "";
        }
    }


    /**
     * 添加菜品要求分组和菜品分类关联关系
     *
     * @param fsAskGpId
     * @param menuClsIdList
     * @param userDBModel
     */
    private static void addAskGPMenuCls(String fsAskGpId, List<String> menuClsIdList, UserDBModel userDBModel) {

        for (String fsMenuClsId : menuClsIdList) {
            String sql = "select * from tbaskgpmenucls where fsAskGpId = '" + fsAskGpId + "' and fsMenuClsId ='" + fsMenuClsId + "'";
            AskgpMenuClsDBModel askgpMenuClsDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, AskgpMenuClsDBModel.class);
            if (askgpMenuClsDBModel == null) {
                askgpMenuClsDBModel = new AskgpMenuClsDBModel();
                askgpMenuClsDBModel.fsAskGpId = fsAskGpId;
                askgpMenuClsDBModel.fsGuid = DBPrimaryKeyUtil.optPrimaryKey();
                askgpMenuClsDBModel.fsMenuClsId = fsMenuClsId;
                askgpMenuClsDBModel.fiDataSource = 1;
                askgpMenuClsDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            }
            askgpMenuClsDBModel.sync = 1;
            askgpMenuClsDBModel.fiStatus = 1;
            askgpMenuClsDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            askgpMenuClsDBModel.fsUpdateUserName = userDBModel.fsUpdateUserName;
            askgpMenuClsDBModel.fsUpdateUserId = userDBModel.fsUpdateUserId;
            askgpMenuClsDBModel.replaceNoTrans();
        }
    }


    private static int generateSortOrder() {
        String sql = "select max(fiSortOrder) from tbaskgp";
        String max = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(max)) {
            return 1;
        } else {
            return StringUtil.toInt(max) + 1;
        }
    }

    /**
     * 删除要求分组
     *
     * @param fsaskgpId
     * @param userDBModel
     * @return
     */
    public static synchronized String deleteAskGp(String fsaskgpId, UserDBModel userDBModel) {

        String checkAsksql = "select count(*) from tbask where fiStatus = '1' and fsAskGpId = '" + fsaskgpId + "'";
        String childCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, checkAsksql);
        if (Integer.valueOf(childCount) > 0) {
            return "请先删除分组下所有要求";
        }
        String checkSql = "select * from tbaskgp where fsAskGpId = '" + fsaskgpId + "'";
        //查询当前要求分组下面是否存在要求

        AskgpDBModel askgpDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkSql, AskgpDBModel.class);
        if (askgpDBModel == null || askgpDBModel.fiStatus == 13) {
            return "";
        } else {
            askgpDBModel.fiStatus = 13;
            askgpDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            if (userDBModel != null) {
                askgpDBModel.fsUpdateUserName = userDBModel.fsUserName;
                askgpDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            askgpDBModel.sync = 1;
            askgpDBModel.fiUseAllMenuCls = 0;
            askgpDBModel.replaceNoTrans();
            String deleteAskItemsSql = "update tbask set fiStatus=13,sync=1,fsUpdateTime='" + DateUtil.getCurrentTime() + "' where fsAskGpId='" + fsaskgpId + "'";
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, deleteAskItemsSql);

            //删除分组要求分组和菜品分类的关联关系
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbmenuitemaskgp set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + fsaskgpId + "' and fistatus= '1' ");
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbaskgpmenucls set fistatus = '13', sync = '1', fsUpdateTime = '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', fsUpdateUserName = '" + userDBModel.fsUpdateUserName + "', fsUpdateUserId = '" + userDBModel.fsUpdateUserId + "' where fsAskGpId = '" + fsaskgpId + "' and fistatus= '1' ");

            MetaDBController.updateSyncTime();
            return "";
        }
    }

    /**
     * 删除要求
     *
     * @param askIdList
     * @param userDBModel
     * @return
     */
    public static synchronized String batchDeleteAsk(ArrayList<String> askIdList, UserDBModel userDBModel) {
        String ids = parsListToSQLParam(askIdList);
        String fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        String fsUpdateUserName = userDBModel == null ? "" : userDBModel.fsUserName;
        String fsUpdateUserId = userDBModel == null ? "" : userDBModel.fsUserId;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbask set fistatus = '13', sync = '1', fsupdateusername = '" + fsUpdateUserName + "',fsupdatetime = '" + fsUpdateTime + "',fsupdateuserid = '" + fsUpdateUserId + "' where fiId in (" + ids + ")");
        return "";
    }

    public static String parsListToSQLParam(List<String> params) {
        StringBuilder stringBuilder = new StringBuilder();

        if (!ListUtil.isEmpty(params)) {
            for (String str : params) {
                stringBuilder.append("'").append(str).append("'").append(",");
            }
            String str = stringBuilder.toString();
            if (stringBuilder.length() > 1) {
                str = str.substring(0, str.length() - 1);
            }
            return str;
        }
        return "";
    }


    /**
     * 新增要求
     *
     * @param askGpId     分组ID
     * @param fsaskName   要求名称
     * @param price       加价
     * @param userDBModel
     * @return
     */
    public static synchronized String addAsk(String askGpId, String fsaskName, BigDecimal price, UserDBModel userDBModel) {
        String checkAskGPSql = "select * from tbaskgp where fsAskGpId = '" + askGpId + "'";
        AskgpDBModel askgpDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkAskGPSql, AskgpDBModel.class);
        if (askgpDBModel == null || askgpDBModel.fiStatus == 13) {
            return "要求分组无效";
        }
        String checkTableSql = "select * from tbask where fsAskName = '" + fsaskName + "' and fistatus = '1'";
        AskDBModel askDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkTableSql, AskDBModel.class);
        if (askDBModel != null) {
            if (askDBModel.fiStatus == 13) {
                askDBModel.fiStatus = 1;
                askDBModel.fdAddPrice = price;
                askDBModel.fsAskGpId = askGpId;
                askDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                askDBModel.sync = 1;
                if (userDBModel != null) {
                    askDBModel.fsUpdateUserName = userDBModel.fsUserName;
                    askDBModel.fsUpdateUserId = userDBModel.fsUserId;
                }
                askDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();
            } else {
                return fsaskName + " 要求已存在";
            }
        } else {
            askDBModel = new AskDBModel();
            askDBModel.fiId = String.valueOf(IDHelper.generateAskId());
            askDBModel.fsAskName = fsaskName;
            askDBModel.fiStatus = 1;
            askDBModel.fdAddPrice = price;
            askDBModel.fsAskGpId = askGpId;
            askDBModel.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            askDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
            askDBModel.sync = 1;
            askDBModel.fiDataSource = 1;
            if (userDBModel != null) {
                askDBModel.fsUpdateUserName = userDBModel.fsUserName;
                askDBModel.fsUpdateUserId = userDBModel.fsUserId;
            }
            askDBModel.replaceNoTrans();
            MetaDBController.updateSyncTime();
        }
        return "";
    }

    /**
     * 更新要求
     *
     * @param fsaskId     要求ID
     * @param askGpId     分组ID
     * @param fsaskName   要求名称
     * @param price       加价
     * @param userDBModel
     * @return
     */
    public static synchronized String updateAsk(String fsaskId, String askGpId, String fsaskName, BigDecimal price, UserDBModel userDBModel) {
        String checkAskGPSql = "select * from tbaskgp where fsAskGpId = '" + askGpId + "'";
        AskgpDBModel askgpDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkAskGPSql, AskgpDBModel.class);
        if (askgpDBModel == null || askgpDBModel.fiStatus == 13) {
            return "要求分组无效";
        }
        String checkTableSql = "select * from tbask where fiId = '" + fsaskId + "'";
        AskDBModel askDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, checkTableSql, AskDBModel.class);
        if (askDBModel != null) {
            if (askDBModel.fiStatus == 13) {
                askDBModel.fiStatus = 1;
                askDBModel.fdAddPrice = price;
                askDBModel.fsAskName = fsaskName;
                askDBModel.fsAskGpId = askGpId;
                askDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                askDBModel.sync = 1;
                if (userDBModel != null) {
                    askDBModel.fsUpdateUserName = userDBModel.fsUserName;
                    askDBModel.fsUpdateUserId = userDBModel.fsUserId;
                }
                askDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();
            } else {
                String oldfsAskId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, " select fiId " +
                        "from tbask where fsAskName = '" + fsaskName + "' and fistatus = '1' " +
                        "and fiId <> '" + fsaskId + "'");
                if (!TextUtils.isEmpty(oldfsAskId)) {
                    return fsaskName + " 要求已存在";
                }
                askDBModel.fiStatus = 1;
                askDBModel.fdAddPrice = price;
                askDBModel.fsAskName = fsaskName;
                askDBModel.fsAskGpId = askGpId;
                askDBModel.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                askDBModel.fiDataSource = 1;
                askDBModel.sync = 1;
                if (userDBModel != null) {
                    askDBModel.fsUpdateUserName = userDBModel.fsUserName;
                    askDBModel.fsUpdateUserId = userDBModel.fsUserId;
                }
                askDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();
            }
        } else {
            return "未查到该要求,请重试";
        }
        return "";
    }


    public static void associateMenuItem(String fiItemCd, String shopId) {
        List<AskgpDBModel> askGps = AskManagerDBUtil.queryAllAskGp();
        associateMenuItem(fiItemCd, shopId, askGps);
    }

    public static void associateMenuItem(String fiItemCd, String shopId, List<AskgpDBModel> askGps) {
        if (!ListUtil.isEmpty(askGps)) {
            for (AskgpDBModel askGp : askGps) {
                MenuitemaskgpDBUtils.add(fiItemCd, askGp.fsAskGpId, shopId);
            }
        }
    }

    /**
     * 分类置顶
     *
     * @param
     * @return
     */
    public static String doAskgpToTop(String fsAskGpId) {
        //<fiSortOrder fiSortOrder--  fiSortOrder=1
        int fiSortOrder = 0;
        AskgpDBModel askgpDBModel = queryById(fsAskGpId);
        fiSortOrder = askgpDBModel.fiSortOrder;
        askgpDBModel.fiSortOrder = 1;
        askgpDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        askgpDBModel.sync = 1;
        String sql = "update tbaskgp set fiSortOrder=fiSortOrder+1,sync=1,fsUpdateTime='" + DateUtil.getCurrentTime() + "' where fiStatus='1' and fiSortOrder<" + fiSortOrder;
        askgpDBModel.replaceNoTrans();
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        MetaDBController.updateSyncTime();
        return null;
    }

    public static AskgpDBModel queryById(String fsAskGpId) {
        String sql = "select * from tbaskgp where fsAskGpId='" + fsAskGpId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, AskgpDBModel.class);
    }


    public static void unAssociateMenuClsByClsId(String clsId) {
        String sql = "update tbmenuitemaskgp set fistatus=13,fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1 where fsMenuClsId='" + clsId + "' and fiRelationtype = '2' ";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    public static List<AirAskManageInfo> findAskListByGpId(String fsAskGpId) {
        String sql = "select fsAskGpId,fiId, fsAskName,fdAddPrice from tbAsk where fiStatus=1 and fsAskGpId='" + fsAskGpId + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirAskManageInfo.class);
    }

    public static List<AirAskManageInfo> findAskListAll() {
        String sql = "select fsAskGpId,fiId, fsAskName,fdAddPrice from tbAsk where fiStatus=1";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AirAskManageInfo.class);
    }

    /**
     * 查询已关联该要求分组的所有菜品分类id列表
     *
     * @param askGpId
     * @return
     */
    public static List<String> findAssociatedMenuClsIdByAskGpId(String askGpId) {
        String sql = "select fiuseallmenucls from tbaskgp where fistatus ='1' and fsaskgpid='" + askGpId + "'";
        String isUseAllMenuCls = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        String querySql = "";
        if ("1".equals(isUseAllMenuCls)) {
            querySql = "select fsmenuclsid from tbmenucls where fistatus ='1'";
        } else {
            querySql = "select fsmenuclsid from tbaskgpmenucls where fistatus ='1' and fsaskgpid='" + askGpId + "'";
        }
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, querySql);
    }

    public static String findAskGpIdByAskId(String fiid) {
        String sql = "select fsaskgpid from tbask where fistatus ='1' and fiid='" + fiid + "'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }


    public static void doSortAskList(ArrayList<AirAskManageInfo> askList) {
//        todo 排序保存
//        String sql="update tbAsk set "

    }
}
