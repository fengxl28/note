package com.mwee.android.pos.businesscenter.business.order;

import android.support.v4.util.Pair;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.businesscenter.print.PrintFastFoodOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.member.net.model.MemberCouponRefundData;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundResponse;
import com.mwee.android.pos.connect.business.bean.model.CopyDiffModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.VoidMenuItemModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/8/22.
 */

public class DishesBizUtil {
    public static SocketBaseResponse checkCanOperateOrder(String orderToken, String orderID) {
        SocketBaseResponse response = new SocketBaseResponse();
        if (TextUtils.isEmpty(orderID)) {
            response.msg(R.string.ser_pay_empty_orderid);
            return response;
        }
        //token校验
        if (!ServerCache.getInstance().verifyToken(orderID, orderToken)) {
            response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
            return response;
        }

        int orderStatus = OrderSession.getInstance().getOrder(orderID).orderStatus;
        if (orderStatus == OrderStatus.PAIED || orderStatus == OrderStatus.ANTI_BACK || orderStatus == OrderStatus.CANCEL) {
            response.msg(R.string.ser_pay_order_processed);
            return response;
        }
        return response;
    }

    /**
     * 退菜
     *
     * @param orderId            订单ID
     * @param hostId             站点ID
     * @param currentTableId     当前桌台ID
     * @param userDBModel        服务员名称
     * @param voidMenuItemModels 退菜列表
     * @param printNoList        未打印小票的printNO
     * @return int           -3： 订单已被结账 -2: 订单号异常  -1： 订单异常  0： 退菜成功 -4: 包含菜品券，需先退券，才能退菜
     */
    public static int returnMenuItem(String orderId, String hostId, String currentTableId, UserDBModel userDBModel, List<VoidMenuItemModel> voidMenuItemModels, List<Integer> printNoList) {
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(currentTableId, orderId, userDBModel.fsUserName + "操作退菜 站点：" + hostId);
        try {

            //订单号异常
            if (TextUtils.isEmpty(orderId)) {
                return -2;
            }

            //获取订单
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);

            //未找到订单
            if (orderCache == null) {
                return -1;
            }

            //订单已被结账
            if (orderCache.orderStatus == OrderStatus.PAIED) {
                return -3;
            }
            List<VoidMenuItemModel> usedDishCouponMenu = new ArrayList<>();
            // 获取退菜中包含的菜品券信息
            for (int j = 0; j < orderCache.originMenuList.size(); j++) {
                MenuItem temp = orderCache.originMenuList.get(j);
                if (temp == null || temp.hasAllVoid()) {
                    continue;
                }
                for (int i = 0; i < voidMenuItemModels.size(); i++) {
                    VoidMenuItemModel item = voidMenuItemModels.get(i);
                    if (TextUtils.equals(temp.menuBiz.uniq, item.fsseq)) {
                        if (temp.usedMbCouponSucc() && temp.memberDishCoupon != null) {
                            usedDishCouponMenu.add(item);
                        }
                        break;
                    }
                }
            }
            if (!usedDishCouponMenu.isEmpty()) {
                return -4;
            }

            //退菜中参与买减的菜品
            List<VoidMenuItemModel> usedBuyGiftMenu = new ArrayList<>();

            //执行退菜并筛出退菜MenuItem
            List<MenuItem> voidItemList = new ArrayList<>();
            for (int j = 0; j < orderCache.originMenuList.size(); j++) {
                MenuItem temp = orderCache.originMenuList.get(j);
                if (temp == null || temp.hasAllVoid()) {
                    continue;
                }
                for (int i = 0; i < voidMenuItemModels.size(); i++) {
                    VoidMenuItemModel item = voidMenuItemModels.get(i);
                    if (TextUtils.equals(temp.menuBiz.uniq, item.fsseq)) {
                        if (temp.menuBiz.bugGiftItem != null) {
                            usedBuyGiftMenu.add(item);
                        }
                        if (temp.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                            temp.menuBiz.buyNum = BigDecimal.ONE;
                        }
                        MenuItem copyMenuItem = temp.clone();
                        copyMenuItem.menuBiz.voidNum = item.fdbackqty;
                        copyMenuItem.menuBiz.voidReson = item.fsbackreason;
                        voidItemList.add(copyMenuItem);
                        temp.doVoid(item.fdbackqty, item.fsbackuserid, item.fsbackusername, item.fsbackreason);
                        temp.calcTotal(orderCache.isMember);
                        if (DBOrderConfig.useKdsService()) {
                            KdsManager.getInstance().backMenu(temp.menuBiz.uniq, item.fdbackqty, temp.supportPackage(), hostId, userDBModel);
                        }
                        break;
                    }
                }
            }

            //清除买减信息
            for (MenuItem menuItem : orderCache.originMenuList) {
                for (VoidMenuItemModel voidMenu : usedBuyGiftMenu) {
                    if (TextUtils.equals(menuItem.itemID, voidMenu.fiItemCd) && TextUtils.equals(menuItem.currentUnit.fiOrderUintCd, voidMenu.fiOrderUintCd)) {
                        menuItem.cleanBuyGiftInfo();
                        menuItem.calcTotal(orderCache.isMember);
                    }
                }
            }
            // 正餐模式下，退菜后，订单预结单打印状态变为未印单
            if (orderCache.dinnerModel()) {
                TableBusinessUtil.modifyPrePrint(null, orderCache.fsmtableid, orderCache.orderID, TableStatusBean.GENERAL);
            }

            //重新计算订单
            orderCache.plusAllMenuAmount();

            //订单置为未支付
            OrderSession.setPayed(orderCache.orderID, 0);
            //重新保存订单
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "returnMenuItem");
//            OrderProcessor.saveOrder(orderCache, null);

            //通知各个站点，订单发生了变化
            NotifyToClient.orderChange(orderCache.orderID);

            if (!DBOrderConfig.useKdsService()) {
                //非反结账订单打印小票 2.4需求反结帐需要打印退菜小票
//            if (orderCache.orderStatus != OrderStatus.ANTI_PAIED) {
                if (orderCache.dinnerModel()) {
                    List<Integer> list = PrintOrderUtil.printBatchVoid(orderCache, voidItemList, voidMenuItemModels, userDBModel.fsUserName, hostId);
                    if (!ListUtil.isEmpty(list)) {
                        printNoList.addAll(list);
                    }
                } else {
                    List<Integer> list = PrintFastFoodOrderUtil.printBatchVoid(orderCache, voidItemList, userDBModel.fsUserName, hostId);
                    if (!ListUtil.isEmpty(list)) {
                        printNoList.addAll(list);
                    }
                }
            }
//            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, currentTableId, orderId, userDBModel.fsUserName + "操作退菜 站点：" + hostId);
        }
        return 0;
    }

//    public static String turnMenuItem(String orderId, String currentTableId, String hostId, String targetTableId, String reason , UserDBModel userDBModel,List<TurnMenuItemModel> trasferList ) {
//
//        Object batchTrun = ServerCache.getInstance().optLock(currentTableId);
//        synchronized (batchTrun) {
//            //订单号异常
//            if (TextUtils.isEmpty(orderId)) {
//                return "订单号异常";
//            }
//
//            //获取订单
//            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
//
//            //未找到订单
//            if (orderCache == null) {
//                return "订单异常";
//            }
//
//            //订单已被结账
//            if (orderCache.orderStatus == OrderStatus.PAIED) {
//                return "订单已被结账";
//            }
//
//            String coutnReceive = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as count from tbSellReceive where fsSellNo='" + orderId + "'");
//            int count = 0;
//            if (!TextUtils.isEmpty(coutnReceive)) {
//                count = StringUtil.toInt(coutnReceive, 0);
//            }
//            if (count > 0) {
//                return "当前订单已有支付信息，不能转菜";
//            }
//
//            MtableDBModel targetTable = TableDBUtil.getMTableById(targetTableId);
//            if (targetTable == null) {
//                return "没有查询到指定桌台";
//            }
//            TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(targetTableId);
//
//            String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiBillStatus from tbSell where fsSellNo='" + tableBizModel.fssellno + "'");
//            if (TextUtils.equals(fiBillStatus, "4")) {
//                return "目标桌台正在反结账，菜品不能转入";
//            }
//            /**
//             * 开始锁桌
//             */
//            String lockError = TableBusinessUtil.lockTable(targetTableId, hostId, userDBModel.fsUserId, userDBModel.fsUserName, false);
//
//            if (!TextUtils.isEmpty(lockError)) {
//                return lockError;
//            }
//
//            String shopID = HostUtil.getShopID();
//
//            //  从原订单中过滤出转菜列表
//            List<MenuItem> neadTurnItems = new ArrayList<>();
//
//            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
//
//                for (int i = 0; i < trasferList.size(); i++) {
//                    TurnMenuItemModel sellOrderItemDBModel = trasferList.get(i);
//
//                    for (int j = 0; j < orderCache.originMenuList.size(); j++) {
//
//                        MenuItem temp = orderCache.originMenuList.get(j);
//                        if (temp.hasAllVoid()) {
//                            continue;
//                        }
//
//                        MenuItem trasferItem;
//                        if (TextUtils.equals(temp.menuBiz.uniq, sellOrderItemDBModel.fsseq)) {
//                            BigDecimal qty = sellOrderItemDBModel.qty;
//                            //数量
//                            boolean doRemove = false;
//                            if (temp.supportWeight()) {
//                                qty = temp.menuBiz.buyNum;
//                                trasferItem = temp;
//                                doRemove = true;
//                            } else if (temp.menuBiz.voidNum.compareTo(BigDecimal.ZERO) == 0) {
//                                if (qty.compareTo(temp.menuBiz.buyNum) >= 0) {
//                                    qty = temp.menuBiz.buyNum;
//                                    doRemove = true;
//                                    trasferItem = temp;
//                                } else {
//                                    trasferItem = temp.createTransferClone();
//                                }
//                            } else {
//                                trasferItem = temp.createTransferClone();
//                                if (qty.compareTo(temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum)) > 0) {
//                                    qty = temp.menuBiz.buyNum.subtract(temp.menuBiz.voidNum);
//                                }
//                            }
//                            trasferItem.menuBiz.buyNum = qty;
//                            trasferItem.menuBiz.voidNum = BigDecimal.ZERO;
//
//                            if (qty.compareTo(temp.menuBiz.giftNum) < 0) {
//                                trasferItem.menuBiz.giftNum = qty;
//                            } else {
//                                trasferItem.menuBiz.giftNum = temp.menuBiz.giftNum;
//                            }
//
//                            if (doRemove) {
//                                orderCache.originMenuList.remove(j);
//                            } else {
//                                temp.menuBiz.buyNum = temp.menuBiz.buyNum.subtract(trasferItem.menuBiz.buyNum);
//                                temp.menuBiz.giftNum = temp.menuBiz.giftNum.subtract(trasferItem.menuBiz.giftNum);
//                                temp.calcTotal(orderCache.isMember);
//                            }
//                            trasferItem.cleanMemberInfo();
//                            neadTurnItems.add(trasferItem);
//                            break;
//                        }
//                    }
//                }
//            } else {
//                return "订单中已没有菜品，请先回到桌台页";
//            }
//
//            if (ListUtil.listIsEmpty(neadTurnItems)) {
//                return "没有找到可转菜品，请重试";
//            }
//
//            if (TextUtils.isEmpty(tableBizModel.fssellno)) {
//                //创建订单
//                String orderID = OrderDriver.generateNewOrderID();
//                OrderCache order = new OrderCache();
//                order.orderID = orderID;
//                order.mealNumber = orderID.substring(orderID.length() - 4, orderID.length());
//                order.waiterID = userDBModel.fsUserId;
//                order.waiterName = userDBModel.fsUserName;
//                order.shopID = shopID;
//                order.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
//                order.currentHostID = hostId;
//                order.currentSectionID = OrderUtil.getSectionId();
//                order.businessDate = HostUtil.getHistoryBusineeDate("");
//                order.orderStatus = OrderStatus.NORMAL;
//                order.fsmareaid = targetTable.fsmareaid;//	--餐区代碼
//                order.fsmtableid = targetTable.fsmtableid;//	--餐桌代碼
//                order.fsmtablename = targetTable.fsmtablename;//	--餐桌名稱
//                order.updateSeqStatus(1, OrderSeqStatus.ORDERED, userDBModel, hostId);
//                order.currentSeq = 1;
//                order.originMenuList.addAll(neadTurnItems);
//
//
//                //计算菜品价格
//                for (MenuItem menuItem : order.originMenuList) {
//                    menuItem.updateOrderSeq(order.currentSeq);
//                    menuItem.calcTotal(order.isMember);
//                }
//                //添加预置菜品
//                List<MenuItem> preOrderList = OrderBizUtil.getOpenParamOrderMenu(targetTable.fsmareaid, 1, userDBModel.fsUserId, userDBModel.fsUserName);
//                if (!ListUtil.isEmpty(preOrderList)) {
//                    order.currentSeq++;
//                    order.updateSeqStatus(order.currentSeq, OrderSeqStatus.ORDERED, userDBModel, hostId);
//                    for (MenuItem menuItem : preOrderList) {
//                        menuItem.updateOrderSeq(order.currentSeq);
//                        menuItem.calcTotal(order.isMember);
//                    }
//                    response.withPreMenuOrderSeq = order.currentSeq;
//                    order.originMenuList.addAll(preOrderList);
//                } else {
//                    response.withPreMenuOrderSeq = -1;
//                }
//
//                order.currentSeq++;
//                //加入预设菜品
//                //更新订单金额
//                order.plusAllMenuAmount();
//
//                OrderProcessor.saveOrder(order, null);
//                OrderSession.getInstance().writeOrder(order.orderID, order);
//                response.openNewTable = true;
//                response.targetOrder = order;
//                //更新桌台状态
//                TableBusinessUtil.openTable(targetTableId, orderID, userDBModel);
//
//            } else {
//                //读取订单
//                ServerCache.getInstance().releaseToken(tableBizModel.fssellno);
//                OrderCache targetOrder = OrderSession.getInstance().getOrder(tableBizModel.fssellno);
//                if (targetOrder == null) {
//                    /**
//                     * 如果出现异常，则解除目标桌台的锁定
//                     */
//                    TableBusinessUtil.unlockTable(targetTableId, hostId);
//
//                    return "目标桌台异常，请稍后重试。";
//                } else {
//                    //计算菜品价格并保存
//                    targetOrder.currentSeq++;
//                    for (MenuItem item : neadTurnItems) {
//                        item.updateOrderSeq(targetOrder.currentSeq);
//                        item.calcTotal(targetOrder.isMember);
//                        targetOrder.originMenuList.add(item);
//                    }
//                    targetOrder.updateSeqStatus(targetOrder.currentSeq, OrderSeqStatus.ORDERED, userDBModel, hostId);
//                    targetOrder.currentSeq++;
//                    targetOrder.plusAllMenuAmount();
//                    OrderSession.getInstance().writeOrder(targetOrder.orderID, targetOrder);
//                    OrderProcessor.saveOrder(targetOrder, null);
//                }
//                response.targetOrder = targetOrder;
//                response.openNewTable = false;
//            }
//            boolean lastMenu = false;
//            /**
//             * 如果是最后一道菜，则清台
//             */
//            if (orderCache.originMenuList.size() == 0) {
//                lastMenu = true;
//            } else {
//                lastMenu = true;
//                for (MenuItem item : orderCache.originMenuList) {
//                    if (!item.hasAllVoid()) {
//                        lastMenu = false;
//                        break;
//                    }
//                }
//            }
//
//            if (lastMenu) {
//                String orderInTableId = orderCache.fsmtableid;
//                orderCache.clearAllMenu();
//                orderCache.reCalcAllByAll();
//                orderCache.mergedOrderID = targetOrder.orderID;
//                PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, orderCache.fsmtableid);
//                TableBusinessUtil.closeTable(socketResponse, orderInTableId, orderId);
//            } else {
//                orderCache.plusAllMenuAmount();
//                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache);
//                OrderProcessor.saveOrder(orderCache, null);
//            }
//
//            /**
//             * 解除目标桌台的锁定
//             */
//            TableBusinessUtil.unlockTargetTable(targetTableId);
//            NotifyToClient.refreshTableOrOrders();
//            response.clearTable = lastMenu;
//            response.currentOrder = orderCache;
//
//            /**
//             * 打印转菜单
//             */
//            List<Integer> printIDs = PrintOrderUtil.printBatchTransfer(response.targetOrder, neadTurnItems, user, orderCache.fsmtablename, hostId);
//            if (!ListUtil.isEmpty(printIDs)) {
//                response.printNoList.addAll(printIDs);
//            }
//            if (response.openNewTable && response.targetOrder != null) {
//                printIDs = PrintTableUtil.openTableReport(response.targetOrder, request.currentHostID);
//                if (!ListUtil.isEmpty(printIDs)) {
//                    response.printNoList.addAll(printIDs);
//                }
//            }
//            if (response.withPreMenuOrderSeq > 0) {
//                List<Integer> printNoList = PrintOrderUtil.printMenuList(response.targetOrder, response.withPreMenuOrderSeq, null, request.currentHostID);
//                if (!ListUtil.isEmpty(printNoList)) {
//                    response.printNoList.addAll(printNoList);
//                }
//                printNoList = PrintOrderUtil.printPassTo(response.targetOrder, request.currentHostID);
//                if (!ListUtil.isEmpty(printNoList)) {
//                    response.printNoList.addAll(printNoList);
//                }
//                PrintOrderUtil.printMakeOrder(response.targetOrder, hostId, response.withPreMenuOrderSeq + "", "", new SyncCallback<List<Integer>>() {
//                    @Override
//                    public void callback(List<Integer> printNoList) {
//                        LogUtil.log("制作单小票待副站点打印数据：" + JSON.toJSONString(printNoList));
//                        if (!ListUtil.isEmpty(printNoList)) {
//                            response.printNoList.addAll(printNoList);
//                        }
//                    }
//                });
//            }
//            NotifyToClient.orderChange(orderCache.orderID);
//
//        }
//        return "";
//    }

    /**
     * 修改菜品名称
     *
     * @param ot          String | orderToken
     * @param userSession String | UserSession
     * @param orderID     String | 订单号
     * @param uniq        String | 菜品唯一表示
     * @param newName     String | 新的菜品名称
     * @return SocketResponse
     */
    public static SocketResponse changeMenuName(String ot, String userSession, String orderID, String uniq, String newName) {
        SocketResponse socketResponse = new SocketResponse();
        UserDBModel userDBModel = HostUtil.getUserModelBySession(userSession);
        if (userDBModel == null) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            return socketResponse;
        }
        SocketBaseResponse error = checkCanOperateOrder(ot, orderID);
        if (!error.success()) {
            socketResponse.code = error.code;
            socketResponse.message = error.message;
            return socketResponse;
        }
        OrderCache orderCache = OrderSession.getInstance().getOrder(orderID);
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, userDBModel.fsUserName + "修改菜品名称 uniq = " + uniq + "; newName = " + newName);
        try {
            orderCache = OrderSession.getInstance().getOrder(orderID);
            if (!ListUtil.isEmpty(orderCache.originMenuList)) {
                for (MenuItem temp : orderCache.originMenuList) {
                    if (TextUtils.equals(temp.menuBiz.uniq, uniq)) {
                        temp.name = newName;
                        temp.name2 = newName;
                        OrderSession.getInstance().writeOrder(orderID, false, "changeMenuName");
                        OrderSaveDBUtil.updateMenuName(orderID, uniq, newName);
                        break;
                    }
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, userDBModel.fsUserName + "修改菜品名称 uniq = " + uniq + "; newName = " + newName);
        }
        return socketResponse;
    }

    /**
     * 校验待复制菜品，包括套餐明细及配料菜
     *
     * @param item         待复制菜品
     * @param checkAllVoid 是否校验全退状态
     * @param checkSellOut 是否校验沽清状态：该参数设为true，则只要有沽清，就校验不通过；设为false，只有全部沽清时返回错误
     * @return ""则校验通过，否则返回错误信息
     */
    public static Pair<String, CopyDiffModel> processCopyMenuItem(MenuItem item, boolean checkAllVoid, boolean checkSellOut) {
        String error = "";
        // 移除全退菜品
        if (item == null || item.menuBiz == null) {
            error = "菜品【" + JSON.toJSONString(item) + "】异常";
            return new Pair<>(error, null);
        }

        if (checkAllVoid && item.hasAllVoid()) {
            error = "菜品【" + item.name + ", " + item.itemID + "】已全部退菜";
            return new Pair<>(error, null);
        }

        CopyDiffModel copyDiff = null;
        // 获取沽清
        SellOutViewModel sellOut = SellOutServerProcessor.getItemSellOutViewModel(item.itemID, item.currentUnit.fiOrderUintCd);
        // 入参控制：只要有沽清，就返回错误
        if (checkSellOut && sellOut != null) {
            error = "菜品【" + item.name + ", " + item.itemID + "】已被沽清，剩余【" + sellOut.fdInvQty.toPlainString() + "】";
            return new Pair<>(error, null);
        }
        // 全部沽清的菜品，跳过不复制
        if (SellOutServerProcessor.isAllSellOut(sellOut)) {
            error = "菜品【" + item.name + ", " + item.itemID + "】已全部沽清，剩余0";
            copyDiff = createCopyDiff(item, item.menuBiz.buyNum.subtract(item.menuBiz.voidNum));
            return new Pair<>(error, copyDiff);
        }

        // 更新uniq
        item.updateUniq();
        // 更新购买数量
        if (item.menuBiz.voidNum.compareTo(BigDecimal.ZERO) > 0) {
            item.menuBiz.buyNum = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
        }
        BigDecimal buyNumBackUp = item.menuBiz.buyNum;// 备份一下购买数量
        BigDecimal newInvQty = BizConstant.NEGATIVE;// 新剩余数量
        if (sellOut != null && sellOut.fdInvQty.compareTo(BigDecimal.ZERO) > 0) {
            // 购买数量 > 剩余数量 时，将购买数量置为剩余数量
            if (sellOut.fdInvQty.compareTo(BigDecimal.ZERO) > 0 && item.menuBiz.buyNum.compareTo(sellOut.fdInvQty) > 0) {
                copyDiff = createCopyDiff(item, sellOut);
                item.menuBiz.buyNum = sellOut.fdInvQty;
                newInvQty = BigDecimal.ZERO;
            } else {
                newInvQty = sellOut.fdInvQty.subtract(item.menuBiz.buyNum);
            }
            // 更新沽清数量
            if (newInvQty.compareTo(BigDecimal.ZERO) >= 0) {
                sellOut.fdInvQty = newInvQty;
                SellOutServerProcessor.updateSellOut(sellOut);
            }
        }
        if (item.menuBiz.buyNum.compareTo(BigDecimal.ZERO) <= 0) {
            // 如果是称重菜并且没有沽清，那么购买数量为0时需要复制
            if (!(item.supportWeight() && sellOut == null)) {
                error = "菜品【" + item.name + ", " + item.itemID + "】购买数量为0";
                return new Pair<>(error, copyDiff);
            }
            item.menuBiz.buyNum = BigDecimal.ZERO;
        }

        // 清除催菜信息
        item.menuBiz.fiHurryTimes = 0;
        // 清除划菜信息
        item.menuBiz.fiMenuProgress = 0;
        item.menuBiz.delimitNum = BigDecimal.ZERO;
        // 清除退菜信息
        item.menuBiz.voidNum = BigDecimal.ZERO;
        item.menuBiz.voidReson = "";
        item.menuBiz.voidUserID = "";
        item.menuBiz.voidUserName = "";
        item.menuBiz.voidTime = "";

        // 校验套餐明细
        if (item.supportPackage() && !ListUtil.isEmpty(item.menuBiz.selectedPackageItems)) {
            for (int i = 0; i < item.menuBiz.selectedPackageItems.size(); i++) {
                MenuItem packageItem = item.menuBiz.selectedPackageItems.get(i);
                // 套餐明细全退时直接移除
                if (packageItem == null || packageItem.menuBiz == null || packageItem.hasAllVoid()) {
                    item.menuBiz.selectedPackageItems.remove(packageItem);
                    i--;
                    continue;
                }
                // 套餐明细校验失败，直接认为套餐头校验失败
                error = processCopyMenuItem(packageItem, false, true).first;
                if (!TextUtils.isEmpty(error)) {
                    if (copyDiff == null) {
                        copyDiff = createCopyDiff(item, item.menuBiz.buyNum);
                    } else {
                        copyDiff.diffNum = buyNumBackUp;
                    }
                    return new Pair<>(error, copyDiff);
                }
            }
        }

        // 校验配料菜
        if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
            for (int i = 0; i < item.menuBiz.selectedModifier.size(); i++) {
                MenuItem modifier = item.menuBiz.selectedModifier.get(i);
                // 配料菜校验失败，移除该配料菜
                error = processCopyMenuItem(modifier, true, false).first;
                if (!TextUtils.isEmpty(error)) {
                    item.menuBiz.selectedModifier.remove(modifier);
                    i--;
                    continue;
                }
            }
        }

        return new Pair<>(error, copyDiff);
    }

    private static CopyDiffModel createCopyDiff(MenuItem item, BigDecimal diffNum) {
        if (item == null || item.currentUnit == null || item.menuBiz == null || diffNum == null) {
            return null;
        }
        if (diffNum.compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }
        CopyDiffModel copyDiff = new CopyDiffModel();
        copyDiff.itemID = item.itemID;
        copyDiff.itemName = item.name;
        copyDiff.fiOrderUintCd = item.currentUnit.fiOrderUintCd;
        copyDiff.fsOrderUint = item.currentUnit.fsOrderUint;
        copyDiff.isWeight = item.supportWeight();
        copyDiff.diffNum = diffNum;
        return copyDiff;
    }

    private static CopyDiffModel createCopyDiff(MenuItem item, SellOutViewModel sellout) {
        if (item == null || item.currentUnit == null || item.menuBiz == null || sellout == null) {
            return null;
        }
        if (!TextUtils.equals(item.itemID, sellout.fiItemCd) || !TextUtils.equals(item.currentUnit.fiOrderUintCd, sellout.fiOrderUintCd)) {
            return null;
        }
        BigDecimal realBuy = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
        if (realBuy.compareTo(sellout.fdInvQty) <= 0) {
            return null;
        }
        CopyDiffModel copyDiff = new CopyDiffModel();
        copyDiff.itemID = item.itemID;
        copyDiff.itemName = item.name;
        copyDiff.fiOrderUintCd = item.currentUnit.fiOrderUintCd;
        copyDiff.fsOrderUint = item.currentUnit.fsOrderUint;
        copyDiff.isWeight = item.supportWeight();
        copyDiff.diffNum = realBuy.subtract(sellout.fdInvQty);
        return copyDiff;
    }
}
