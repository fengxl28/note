package com.mwee.android.pos.businesscenter.business.moniter;

import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.keppalive.KeepAliveRequest;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.NetWorkUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

/**
 * 口碑心跳
 */
public class KoubeiKeepAliveUtil {

    public static void initKBKeepAliveLoop() {
        ILoopCall loopCall = new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询
                if (!BindProcessor.isActived()) {
                    return;
                }
                KeepAliveRequest request = new KeepAliveRequest();
                request.token = DBMetaUtil.getConfig(META.XMPP_SESSION_ID, "");
                request.deviceid = DeviceUtil.getDeviceID(GlobalCache.getContext());
                request.app_version = BizConstant.VERSION_NAME;
                request.clientType = APPConfig.getClientType();
                String fsshopguid = DBMetaUtil.getConfig(META.SHOPID, "");
                request.shopid = StringUtil.toInt(fsshopguid, 0);
                request.sn_id = ServerHardwareUtil.getHardWareSymbol();
                request.product = "CO";
                request.type = "BOH";
                request.hardware_version = android.os.Build.MODEL;
                request.soft_version = BizConstant.VERSION_NAME;
                request.sys_type = "Android";
                request.sys_version = android.os.Build.VERSION.RELEASE;
                request.time = DateTimeUtil.getTime(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss");
                request.manufacturer = "商米";
                request.network_type = NetWorkUtil.getMobileNetWorkTypeDes(GlobalCache.getContext());
                request.isv_server_time = request.time;
                request.isv_pid = "";
                request.enableKouBei = "2";
                BusinessExecutor.execute(request, null, null, true);
            }
        };
        GlobalLooper.registBasedOn30Seconds(loopCall, 20);
    }
}
