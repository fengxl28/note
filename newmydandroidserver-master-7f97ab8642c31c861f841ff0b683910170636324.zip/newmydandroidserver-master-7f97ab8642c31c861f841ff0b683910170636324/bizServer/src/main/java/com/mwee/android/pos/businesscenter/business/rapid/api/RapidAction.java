package com.mwee.android.pos.businesscenter.business.rapid.api;

import android.text.TextUtils;

/**
 * 秒点API的操作类型
 * Created by virgil on 2016/11/3.
 */
public class RapidAction {
    public final static String RING = "call";// 服务铃
    public final static String OPEN_TABLE = "kt";// 开台
    public final static String GET_ORDER_DETAIL = "findorderbytableno";// 结账查询订单实时信息--跳转结账页
    public final static String SUBMIT_ORDER = "order";// 下单
    public final static String PAY_ORDER = "checkout";// 结账
    public final static String SEARCH_PAY = "qryorderbytable";// 查询订单信息
    public final static String BOOK_ORDER = "bookingPush";// 预定订单
    public final static String QUERY_TABLES = "querytablist";// 美老板获取桌台列表

    /**
     * 口碑新单
     */
    public final static String KB_ORDER_NEW = "kborderpush";// 口碑新单
    public final static String KB_ORDER_NEW_COMPENSATE = "kborderpush_compensate";// 口碑新单补偿
    /**
     * 口碑用户取消
     */
    public final static String KB_ORDER_CANCEL = "kbordercancel";// 用户取消
    /**
     * 口碑拒单
     * 5分钟不接单超时行为
     */
    public final static String KB_ORDER_REJECT = "kborderreject";// 商家拒单

    /**
     * 口碑退款
     */
    public final static String KB_ORDER_REFUND = "kborderrefund";// 口碑退款

    /**
     * 口碑用户申请退款
     */
    public final static String KB_ORDER_APPLY_REFUND = "kborderapplyrefund";// 用户申请退款

    /**
     * 口碑商家同意退款
     */
    public final static String KB_ORDER_REFUNDED = "kborderrefunded";// 商家同意退款

    /**
     * 口碑后付款推送新订单
     */
    public final static String KB_FUTURE_PUSH = "kbafterpaypush";// 口碑后付款推送新订单
    public final static String KB_FUTURE_PUSH_COMPENSATE = "kbafterpaypush_compensate";// 口碑后付款推送新订单补偿

    /**
     * 超时打款口碑自动驳回退款
     */
    public final static String KB_ORDER_REJECT_REFUNDED = "kborderrejectrefund";

    /**
     * 口碑后付支付通知
     */
    public final static String KB_AFTER_PAY_NOTIFY = "kbafterpaynotify";//口碑后付支付通知


    public final static String KB_AFTER_PAY_NOTIFY_COMPENSATE = "kbafterpaynotify_compensate";//口碑后付支付通知补偿

    /**
     * 口碑拉单目前每隔两分钟一次
     */
    public final static String KB_AFTER_PAY_PULL = "kbafterpaypull";

    /**
     * 是否是秒付拉单
     *
     * @param action String
     * @return boolean
     */
    public static boolean isPullOrderByPay(String action) {
        return TextUtils.equals(action, GET_ORDER_DETAIL);
    }
    /**
     * 是否是秒点拉单
     *
     * @param action String
     * @return boolean
     */
    public static boolean isPullOrderByOrder(String action) {
        return TextUtils.equals(action, SEARCH_PAY);
    }
}
