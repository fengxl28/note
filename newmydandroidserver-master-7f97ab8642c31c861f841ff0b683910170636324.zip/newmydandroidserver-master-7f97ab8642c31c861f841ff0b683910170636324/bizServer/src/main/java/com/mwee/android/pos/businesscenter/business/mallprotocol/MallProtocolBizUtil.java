package com.mwee.android.pos.businesscenter.business.mallprotocol;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.datasync.net.MallProtocolRequest;
import com.mwee.android.pos.component.datasync.net.MallProtocolResponse;
import com.mwee.android.pos.component.datasync.net.model.MallProtocolModel;
import com.mwee.android.pos.util.HttpUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

/**
 * 商场协议 处理类
 */
public class MallProtocolBizUtil {

    private static final String TAG = "MallProtocolBizUtil";

    /**
     * 缓存门店商场协议，ArrayMap<fiApitype,MallProtocolModel>
     */
    private static ArrayMap<String, MallProtocolModel> mallProtocol = new ArrayMap<>();
    /**
     * 商场协议获取结果，0-成功，<0失败
     */
    private static int getMallProtocolResult = -1;

    // 食宝街 订单拍照协议
    private static final String PROTOCOL_47 = "47";

    /**
     * 更新商场协议
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=31599949
     *
     * @param async 是否异步更新，true异步，false同步
     */
    public static void updateMallProtocol(boolean async) {
        MallProtocolRequest request = new MallProtocolRequest();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "获取商场协议成功");
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof MallProtocolResponse) {
                    MallProtocolResponse response = (MallProtocolResponse) responseData.responseBean;
                    getMallProtocolResult = 0;
                    if (!ListUtil.isEmpty(response.data)) {
                        for (MallProtocolModel model : response.data) {
                            if (model == null) {
                                continue;
                            }
                            mallProtocol.put(model.fiApitype, model);
                        }
                    }
                    LogUtil.logBusiness(TAG, "更新商场协议为：【" + JSON.toJSONString(mallProtocol) + "】");
                } else {
                    LogUtil.logBusiness(TAG, "更新商场协议失败，数据异常");
                    getMallProtocolResult = -1;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "获取商场协议失败：" + responseData.resultMessage + "(" + responseData.result + ")");
                getMallProtocolResult = -1;
                return false;
            }
        }, async);
    }

    public static void checkMallProtocol() {
        if (getMallProtocolResult < 0) {
            LogUtil.logBusiness(TAG, "重新更新商场协议");
            updateMallProtocol(false);
        }
    }

    /**
     * 食宝街 订单上传
     *
     * @param orderId   订单id
     * @param orderTime 结账时间
     * @param deviceId  设备号
     * @param retry     重试次数，主要用来上传失败重试时内部传值，外部调用请传0
     * @param orderType     1：结账；2反结账
     */
    public static void doForShibaojie(String orderId, String shopId, int orderType, String orderTime, String deviceId, int retry) {
        if (getMallProtocolResult == 0 && ListUtil.mapIsEmpty(mallProtocol)) {
            LogUtil.logBusiness(TAG, "商场协议为空，不执行食宝街订单上传--orderId=" + orderId + ", orderTime=" + orderTime + ", deviceId=" + deviceId + "; orderType = "+ orderType + "; shopId = "+ shopId);
            return;
        }
        if (getMallProtocolResult == 0 && !mallProtocol.containsKey(PROTOCOL_47)) {
            LogUtil.logBusiness(TAG, "商场协议不包括 食宝街，不执行食宝街订单上传--orderId=" + orderId + ", orderTime=" + orderTime + ", deviceId=" + deviceId + "; orderType = "+ orderType + "; shopId = "+ shopId);
            return;
        }
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                // 上次更新商场协议是否失败了，如失败则重新更新下
                checkMallProtocol();

                MallProtocolModel mallProtocolModel = mallProtocol.get(PROTOCOL_47);
                if (mallProtocolModel == null || TextUtils.isEmpty(mallProtocolModel.fsServerAddress)) {
                    LogUtil.logBusiness(TAG, "获取的食宝街商场协议/服务地址为空，不执行食宝街订单上传--orderId=" + orderId + ", orderTime=" + orderTime + ", deviceId=" + deviceId + "; orderType = "+ orderType + "; shopId = "+ shopId);
                    return null;
                }
                LogUtil.logBusiness(TAG, "执行食宝街订单上传--orderId=" + orderId + ", orderTime=" + orderTime + ", deviceId=" + deviceId + ", fsServerAddress=" + mallProtocolModel.fsServerAddress + "; orderType = "+ orderType + "; shopId = "+ shopId);

                // 进行订单拍照
                HttpUtil.doShibaojieFormPost(mallProtocolModel.fsServerAddress, orderId, shopId, orderTime, orderType, deviceId, 0);
                return null;
            }
        });
    }

}
