package com.mwee.android.pos.businesscenter.business.rapid.api;

import com.alibaba.fastjson.JSONArray;

/**
 * 秒点的操作结果
 * Created by virgil on 2016/11/3.
 */

public class RapidActionModel {
    public int result = RapidResult.SUCCESS;
    public String errorInfo = "";
    public String resultBiz = "";
    public String fsid = "";//uuid
    public RapidActionModel() {

    }
}
