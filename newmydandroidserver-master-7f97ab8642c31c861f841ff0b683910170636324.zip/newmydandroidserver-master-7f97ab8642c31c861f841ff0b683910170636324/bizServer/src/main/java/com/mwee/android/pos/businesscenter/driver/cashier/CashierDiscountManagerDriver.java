package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.bargain.GetBargainListResponse;
import com.mwee.android.air.connect.business.discount.GetAllDiscountManagerInfoResponse;
import com.mwee.android.air.db.business.bargain.FullReduceBean;
import com.mwee.android.air.db.business.discount.DiscountManagerInfo;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.AirBargainDBUtil;
import com.mwee.android.pos.businesscenter.air.dbUtil.AirDiscountDBUtil;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description: 美收银优惠
 * @author: Xiaolong
 * @Date: 2018/8/1
 */
@SuppressWarnings("unused")
public class CashierDiscountManagerDriver implements IDriver {
    private static final String TAG = "cashierDiscountManager";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 获取所有折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyOptAllDiscount")
    public SocketResponse optAllDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;
            response.message = "数据获取成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 修改折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyUpdateDiscount")
    public SocketResponse updateDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            DiscountManagerInfo discountManagerInfo = JSON.parseObject(request.getString("discountManagerInfo"), DiscountManagerInfo.class);
            if (discountManagerInfo == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.updateDiscount(discountManagerInfo, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 新增折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyAddDiscount")
    public SocketResponse addDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }
            DiscountManagerInfo discountManagerInfo = JSON.parseObject(request.getString("discountManagerInfo"), DiscountManagerInfo.class);

            if (discountManagerInfo == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.addDiscount(discountManagerInfo, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 批量删除折扣
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/msyBatchDeleteDiscount")
    public SocketResponse batchDeleteDiscount(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetAllDiscountManagerInfoResponse responseData = new GetAllDiscountManagerInfoResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            ArrayList<String> discountIdList = (ArrayList<String>) JSON.parseArray(request.getString("discountIdList"), String.class);
            if (ListUtil.isEmpty(discountIdList)) {
                response.message = "请选择要删除的折扣";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirDiscountDBUtil.batchDeleteDiscount(discountIdList, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            responseData.discountManagerInfoArrayList = AirDiscountDBUtil.optAllDiscountManagerInfoList();
            response.code = SocketResultCode.SUCCESS;

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


    /**
     * 添加满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/msyAddFullReduce")
    public SocketResponse addFullReduce(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            FullReduceBean fullReduceBean = JSON.parseObject(request.getString("fullReduceBean"), FullReduceBean.class);
            if (fullReduceBean == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirBargainDBUtil.addFullReduce(fullReduceBean, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMsg;
                LogUtil.log("----------errMsg=" + errMsg);
            } else {
                response.code = SocketResultCode.SUCCESS;
                LogUtil.log("----------新增优惠成功");
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        response.buildMessage();
        return response;
    }

    /**
     * 批量删除满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/msyDeleteFullReduceBatch")
    public SocketResponse deleteFullReduceBatch(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetBargainListResponse responseData = new GetBargainListResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            List<String> bargainIdList = JSON.parseArray(request.getJSONArray("fullReduceIdList").toString(), String.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            int isSuccess = AirBargainDBUtil.deleteFullReduceBatch(bargainIdList, userDBModel);
            if (isSuccess == 1) {
                response.code = SocketResultCode.SUCCESS;
                responseData.bargainDBModelList = AirBargainDBUtil.optFullReduceList();
                response.data = responseData;
                response.message = "数据删除成功";
            } else {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "数据删除失败";
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 更新满减优惠
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/msyUpdateFullReduce")
    public SocketResponse updateFullReduce(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            FullReduceBean fullReduceBean = JSON.parseObject(request.getString("fullReduceBean"), FullReduceBean.class);

            if (fullReduceBean == null) {
                response.message = "操作异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            String errMsg = AirBargainDBUtil.updateFullReduce(fullReduceBean, userDBModel);
            if (!TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = errMsg;
                LogUtil.log("----------errMsg=" + errMsg);
            } else {
                response.code = SocketResultCode.SUCCESS;
                LogUtil.log("----------更新优惠成功");
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取满减优惠列表
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/msOptFullReduceList")
    public SocketResponse optFullReduceList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        GetBargainListResponse responseData = new GetBargainListResponse();
        response.data = responseData;
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            List<FullReduceBean> bargainDBModelList = AirBargainDBUtil.optFullReduceList();
            if (!ListUtil.isEmpty(bargainDBModelList)) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "数据获取成功";
                responseData.bargainDBModelList = bargainDBModelList;
            } else {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "数据获取失败";
            }


        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }


}
