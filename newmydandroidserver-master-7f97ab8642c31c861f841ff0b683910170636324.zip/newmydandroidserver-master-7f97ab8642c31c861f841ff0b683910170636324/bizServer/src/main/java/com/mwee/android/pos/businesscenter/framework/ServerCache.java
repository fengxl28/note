package com.mwee.android.pos.businesscenter.framework;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.base.CommonCache;
import com.mwee.android.pos.business.print.PrintCache;
import com.mwee.android.pos.business.setting.SettingConfig;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.dbutil.ShopDBUtil;
import com.mwee.android.pos.businesscenter.netbiz.member.ServerMemberApi;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderCache;
import com.mwee.android.pos.businesscenter.netbiz.wechatfastfood.WechatFastfoodCache;
import com.mwee.android.pos.component.datasync.net.TableQRBiznessModel;
import com.mwee.android.pos.component.log.MydLog;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.net.model.MemberComments;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.db.business.pay.OrderConfig;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.util.UUIDUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by virgil on 2017/6/17.
 */

public class ServerCache extends Cache {
    private final static ServerCache instance = new ServerCache();
    /**
     * 操作token池的锁
     */
    private final Object tokenLock = new Object();
    public String shopID = "";
    /**
     * 总店ID
     */
    public String fsCompanyGUID = "";
    public NetOrderCache netOrderCache = new NetOrderCache();
    public WechatFastfoodCache wechatFastfoodCache = new WechatFastfoodCache();
    public GlobalLooper looper = new GlobalLooper();
    /**
     * token池
     */
    private ArrayMap<String, String> tokenPool = new ArrayMap<>();
    private HashMap<String, Object> lockPool = new HashMap<>();


    public TableLockCache tableLockCache = new TableLockCache();
    private Object lockFastFood = new Object();
    /**
     * 会员评论池
     */
    private ArrayMap<String, MemberComments> memberCommentsPool = new ArrayMap<>();
    /**
     * 桌台秒付码池
     * key:桌台ID
     */
    private ArrayMap<String, TableQRBiznessModel> tableQRPool = new ArrayMap<>();

    private ArrayMap<String, NewMemberCardInfoModel> hostMemInfoPool = new ArrayMap<>();

    /**
     * 今日营业目标
     */
    public String salesTarget;

    private ServerCache() {
    }

    public static ServerCache getInstance() {
        return instance;
    }


    /**
     * 订单号缓存---每个订单号缓存1分钟
     */
    private List<String> orderIdPool = new ArrayList<>();

    /**
     * 缓存订单号
     *
     * @param orderId
     */
    public synchronized void putOrderId(String orderId) {
        orderIdPool.add(orderId);
    }

    /**
     * 检查订单号是否已存在
     * -----将未缓存过的订单号缓存，一分钟后删除
     *
     * @param orderId
     * @return boolean | true: 不存在； false： 已存在
     */
    public synchronized boolean checkOrderIdCached(String orderId) {
        boolean valid = orderIdPool.contains(orderId);
        if (!valid) {
            orderIdPool.add(orderId);

            GlobalLooper.postDelayed(new Runnable() {
                @Override
                public void run() {
                    releaseOrderIdCache(orderId);
                }
            }, 1000 * 60);
        }

        return valid;
    }

    /**
     * 释放订单号缓存
     *
     * @param orderId
     */
    public synchronized void releaseOrderIdCache(String orderId) {
        orderIdPool.remove(orderId);
    }

//    /**
//     * 获取一个对象锁：
//     * 1，正餐传桌台
//     * 2，其他传空字符串
//     *
//     * @param tableID String
//     * @return Object
//     */
//    public static Object getLock(String tableID) {
//        return ServerCache.getInstance().optLock(tableID);
//    }

//    /**
//     * 根据订单号获取一个对象锁
//     *
//     * @param orderID
//     * @return
//     */
//    public static Object getLockByOrder(String orderID) {
//        return getLock(OrderSaveDBUtil.getTableIDByOrderID(orderID));
//    }


    /*====================================订单操作的锁相关====================================*/

    public void init() {

        refresh(false);
        netOrderCache.init();
        wechatFastfoodCache.init();
        looper.init();
    }

    @Override
    public void refresh() {
        refresh(true);
    }

    /**
     * 刷新缓存
     *
     * @param loginPD boolean | 是否登录中控并刷新xmpp
     */
    public void refresh(boolean loginPD) {
        netOrderCache.refresh();
        shopID = ShopDBUtil.queryShopId();
        fsCompanyGUID = ShopDBUtil.queryCompanyGUID();

        MydLog.refreshConfig();
        PayCache.getInstance().refresh();
        RoundConfig.init(shopID);
        PrintCache.initParam();
        SettingConfig.initParam();
        if (loginPD) {
            DriverBus.call("xmpp/dologin");
        }

        OrderConfig.init();
        CommonCache.getInstance().refresh();
    }

    @Override
    public void clean() {
        if (netOrderCache != null) {
            netOrderCache.clean();
        }
        if (wechatFastfoodCache != null) {
            wechatFastfoodCache.clean();
        }
        CommonCache.getInstance().clean();
    }

    /**
     * 生成一个新的Token
     *
     * @param orderID String | 订单号
     * @return String | 生成的Token
     */
    public String generateNewToken(String orderID) {
        if (TextUtils.isEmpty(orderID)) {
            return "";
        }
        String token = UUIDUtil.optUUID();
        synchronized (tokenLock) {
            tokenPool.put(orderID, token);
        }
        return token;
    }

    /**
     * 校验订单Token
     *
     * @param orderID String | 订单号
     * @param token   String | token
     * @return boolean | 校验的结果：true：合法；false：不合法
     */
    public boolean verifyToken(String orderID, String token) {
        boolean match;
        synchronized (tokenLock) {
            String originToken = tokenPool.get(orderID);
            match = TextUtils.equals(originToken, token);
        }
        return match;
    }

    /*====================================会员评论相关====================================*/

    /**
     * 释放订单的token
     *
     * @param orderID String
     * @param token   String
     */
    public void releaseToken(String orderID, String token) {
        synchronized (tokenLock) {
            String originToken = tokenPool.get(orderID);
            if (TextUtils.equals(originToken, token)) {
                tokenPool.remove(orderID);
            }
        }
    }

    public void releaseToken(String orderID) {
        synchronized (tokenLock) {
            tokenPool.remove(orderID);
        }
    }

    /**
     * 清除所有的订单Token
     */
    public void releaseAllToken() {
        synchronized (tokenLock) {
            tokenPool.clear();
        }
    }

    /*public synchronized Object optLock(String tableID) {
        if (TextUtils.isEmpty(tableID)) {
            return lockFastFood;
        }
        Object lock = lockPool.get(tableID);
        if (lock == null) {
            lock = new Object();
            lockPool.put(tableID, lock);
        }
        return lock;
    }*/


    /*====================================桌台秒付码相关====================================*/

    /**
     * 缓存会员评论
     *
     * @param cardNo
     * @param memberComments
     */
    public void putMemberComments(String cardNo, MemberComments memberComments) {
        if (TextUtils.isEmpty(cardNo)) {
            return;
        }
        if (memberCommentsPool == null) {
            return;
        }
        memberCommentsPool.put(cardNo, memberComments);
    }

    /**
     * 获取会员评论
     *
     * @param cardNo
     * @return
     */
    public MemberComments optMemberComments(String cardNo) {
        if (TextUtils.isEmpty(cardNo)) {
            return null;
        }
        if (memberCommentsPool == null) {
            return null;
        }
        return memberCommentsPool.get(cardNo);
    }

    public void putMemberWithHost(String fsHostId, MemberCardModel model) {
        if (TextUtils.isEmpty(fsHostId)) {
            return;
        }
        if (hostMemInfoPool == null) {
            hostMemInfoPool = new ArrayMap<>();
        }
        hostMemInfoPool.put(fsHostId, ServerMemberApi.convertToNewCardInfoModel(model.card_info));
    }

    public void putNewMemberWithHost(String fsHostId, NewMemberCardInfoModel model) {
        if (TextUtils.isEmpty(fsHostId)) {
            return;
        }
        if (hostMemInfoPool == null) {
            hostMemInfoPool = new ArrayMap<>();
        }
        hostMemInfoPool.put(fsHostId, model);
    }

    public void delNewMemberWithHost(String fsHostId) {
        if (TextUtils.isEmpty(fsHostId)) {
            return;
        }
        if (hostMemInfoPool == null) {
            hostMemInfoPool = new ArrayMap<>();
        }
        hostMemInfoPool.remove(fsHostId);
    }

    public NewMemberCardInfoModel getNewMemberWithHost(String fsHostId) {
        if (TextUtils.isEmpty(fsHostId)) {
            return null;
        }
        if (hostMemInfoPool == null) {
            return null;
        }
        return hostMemInfoPool.get(fsHostId);
    }

    /**
     * 删除会员评论
     *
     * @param cardNo
     */
    public void releaseMemberComments(String cardNo) {
        if (TextUtils.isEmpty(cardNo)) {
            return;
        }
        if (memberCommentsPool == null) {
            return;
        }
        memberCommentsPool.remove(cardNo);
    }

    /**
     * 缓存桌台秒付码
     *
     * @param tableNo
     * @param tableQRBiznessModel
     */
    public void putTableQR(String tableNo, TableQRBiznessModel tableQRBiznessModel) {
        if (tableQRBiznessModel == null) {
            return;
        }
        tableQRPool.put(tableNo, tableQRBiznessModel);
    }

    /**
     * 获取桌台秒付码
     *
     * @param tableId
     * @return
     */
    public TableQRBiznessModel optTableQR(String tableId) {
        if (TextUtils.isEmpty(tableId)) {
            return null;
        }
        if (tableQRPool == null) {
            return null;
        }
        return tableQRPool.get(tableId);
    }

    /**
     * 删除桌台码
     *
     * @param tableId
     */
    public void releaseTableQR(String tableId) {
        if (TextUtils.isEmpty(tableId)) {
            return;
        }
        if (tableQRPool == null) {
            return;
        }
        tableQRPool.remove(tableId);
    }

    /**
     * 删除所有桌台码
     */
    public void releaseAllTableQR() {
        if (tableQRPool == null) {
            return;
        }
        tableQRPool.clear();
    }

    /**
     * 销毁
     */
    public void destroy() {
        if (looper != null) {
            looper.destroyInstance();
        }
        clean();
        if (tableQRPool != null) {
            tableQRPool.clear();
        }
        tableQRPool = null;
        if (memberCommentsPool != null) {
            memberCommentsPool.clear();
        }
        memberCommentsPool = null;
//        if (lockPool != null) {
//            lockPool.clear();
//        }
//        lockPool = null;
        if (tokenPool != null) {
            tokenPool.clear();
        }
        tokenPool = null;
    }
}
