package com.mwee.android.pos.businesscenter.business.unfinish_task;

import android.content.ContentValues;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.component.member.net.MemberOrderConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberOrderConsumeRequest;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.util.Calendar;
import java.util.List;

/**
 * 任务调度，需要运行在业务中心
 * Created by virgil on 2017/3/2.
 */
public class JobScheudler {
    /**
     * 实例
     */
    private static JobScheudler instance;
    /**
     * 是否正在处理
     */
    private boolean working = false;

    private JobScheudler() {

    }

    /**
     * 检查当前实例的生成情况
     */
    private static synchronized void checkInstance() {
        if (instance == null) {
            instance = new JobScheudler();
            instance.prepare();
        }
    }

    private static synchronized void doInit() {
        //将所有执行中的任务设置为未执行，仅限业务初始化时调用
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set finished='0' where finished='3'");
        String jobCount = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from unfinish_task where finished='0'");
        int jobCountInt = StringUtil.toInt(jobCount, 0);
        if (jobCountInt <= 0) {
            return;
        }
        checkInstance();
    }

    /**
     * 初始化整个实例
     */
    public synchronized static void init() {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                doInit();
                return null;
            }
        });
    }

    /**
     * 启动调度器的工作(包含初始化检测和启动Handler的轮询)
     */
    private synchronized static void start() {
        checkInstance();
    }

    private synchronized static void insertJob(Job job) {
        ContentValues values = DBModel.getReplaceInfo(job);
        String taskid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select max(taskid) from unfinish_task ");
        int key = 0;
        if (!TextUtils.isEmpty(taskid)) {
            key = StringUtil.toInt(taskid, 0) + 1;
        }
        values.put("taskid", key);
        job.taskid = key;
        job.replace(values, true);
    }

    /**
     * 添加一个Job
     *
     * @param job Job
     */
    public synchronized static void newJob(Job job) {
        insertJob(job);
        start();
    }

    /**
     * 添加一个Job
     *
     * @param request MemberOrderConsumeRequest
     */
    public synchronized static Job newMemberGiftWithProcessing(MemberOrderConsumeRequest request, String fsSellNo) {
        final Job job = new Job();
        job.info = JSON.toJSONString(request);
        job.type = JobType.MEMBER_GIFT;
        job.biz_key = fsSellNo;
        job.trace1 = request.order_id;
        job.finished = 3;
        newJob(job);
        return job;
    }

    /**
     * 添加一个Job
     *
     * @param request NewMemberOrderConsumeRequest
     */
    public synchronized static Job newMemberGiftNewWithProcessing(NewMemberOrderConsumeRequest request, String fsSellNo) {
        final Job job = new Job();
        job.info = JSON.toJSONString(request);
        job.type = JobType.MEMBER_GIFT_NEW;
        job.biz_key = fsSellNo;
        job.trace1 = request.orderId;
        job.finished = 3;
        newJob(job);
        return job;
    }

    /**
     * 添加一个Job
     *
     * @param jobType int | see{@link JobType}
     * @param bizKey  String
     * @param bizInfo String
     */
    public synchronized static void newJob(int jobType, String bizKey, String bizInfo) {
        Job job = new Job();
        job.type = jobType;
        job.biz_key = bizKey;
        job.info = bizInfo;
        newJob(job);
    }

    /**
     * 添加一个Job
     *
     * @param jobType int | see{@link JobType}
     * @param bizKey  String
     * @param cycle   int | 轮询周期
     */
    public synchronized static void newJob(int jobType, String bizKey, int cycle) {
        Job job = new Job();
        job.type = jobType;
        job.biz_key = bizKey;
        job.cycle = cycle;
        newJob(job);
    }

    /**
     * 根据业务主键来更新Job的执行时间
     *
     * @param jobType int | see{@link JobType}
     * @param bizKey  String | 业务主键
     * @param status  int | see{@link JobStatus}
     */
    public static void updateJobStatus(int jobType, String bizKey, @JobStatus int status) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set finished='" + status + "',update_time='" + DateUtil.getCurrentTime() + "' where type='" + jobType + "' and biz_key='" + bizKey + "'");
    }

    /**
     * 删除指定类型的Job
     *
     * @param jobType int | see{@link JobType}
     */
    public static void deleteJobByType(int jobType) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from  unfinish_task where type='" + jobType + "'");
    }

    /**
     * 根据Job的类型来更新状态
     * @param jobType int | see{@link JobType}
     * @param status int | see{@link JobStatus}
     */
    public static void updateJobStatusByType(int jobType, @JobStatus int status) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set finished='" + status + "',update_time='" + DateUtil.getCurrentTime() + "' where type='" + jobType + "'");
    }

    /**
     * 更新任务的执行时间
     * @param jobType int | see{@link JobType}
     */
    public static void updateJobWorkTimeByType(int jobType,String time) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set update_time='" + time + "',laskWorkTime='"+time+"' where type='" + jobType + "'");
    }

    /**
     * 更新任务的执行时间
     * @param jobType int | see{@link JobType}
     */
    public static void updateJobWorkTimeByType(int jobType) {
        updateJobWorkTimeByType(jobType,DateUtil.getCurrentTime());
    }

    public static String getTrace2ByTrace1AndBizKey(String bizKey, String trace1, int jobType) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select trace2 from unfinish_task where type='" + jobType + "' and biz_key='" + bizKey + "' and trace1='" + trace1 + "'");
    }

    /**
     * 初始化Thread和Handler
     */
    private void prepare() {
        GlobalLooper.registBasedOn2Minutes(new ILoopCall() {
            @Override
            public void call() {
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                synchronized (JobScheudler.class) {
                    if (working) {
                        return;
                    }
                    working = true;
                }
                try {
                    JobWorker worker = new JobWorker();
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update unfinish_task set cycle_count=cycle_count+1");
                    String currentTimeFull = DateUtil.getCurrentTime();

                    //拿取30个任务,轮询状态为"准备中"或者状态为"已完成"且轮询类型为循环闹钟的任务
                    // TODO: 2018/6/1 直接删除 limit 限制 和 每次 30 个循环取出，好像没有太大区别，先直接删除 limit 限制。
                    List<Job> jobCount = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from unfinish_task where (finished='0') or (finished='1' and typeLoop='2') order by taskid desc", Job.class);
                    for (Job temp : jobCount) {
                        if (temp.typeLoop == 1) {
                            if (TextUtils.isEmpty(temp.loopDestTime) || temp.loopDestTime.length() < DateUtil.DATE_VISUAL14FORMAT.length()) {
                                //时间格式不合法，则设置为取消
                                temp.updateJobCancel();
                            } else if (DateUtil.compareDate(temp.loopDestTime, currentTimeFull, DateUtil.DATE_VISUAL14FORMAT) > 3600) {
                                //过期1小时，则job取消
                                temp.updateJobCancel();
                            } else {
                                worker.work(temp);
                            }
                        } else if (temp.typeLoop == 2) {
                            if (TextUtils.isEmpty(temp.loopDestTime) || temp.loopDestTime.length() < 8) {
                                //时间格式不合法，则设置为取消
                                temp.updateJobCancel();
                            } else {
                                if (temp.loopDestTime.length() == 8) {
                                    temp.loopDestTime = DateUtil.getCurrentDate("yyyy-MM-dd")+" "+temp.loopDestTime;
                                    //日期加1
                                    temp.loopDestTime = DateUtil.addTime(temp.loopDestTime, DateUtil.DATE_VISUAL14FORMAT, Calendar.DATE, 1);
                                    temp.replaceNoTrans();
                                }

                                    long minus=DateUtil.compareDate(temp.loopDestTime, currentTimeFull, DateUtil.DATE_VISUAL14FORMAT);
                                    if(minus<0){
                                        continue;
                                    }else if ( minus> 3600 * 1000) {

                                        //过期1小时，则job设置为已完成，并日期加1
                                        temp.finished = JobStatus.FINISHED;
                                        temp.loopDestTime = DateUtil.addTime(temp.loopDestTime, DateUtil.DATE_VISUAL14FORMAT, Calendar.DATE, 1);
                                        temp.replaceNoTrans();
                                    } else {
                                        if (!TextUtils.isEmpty(temp.laskWorkTime) && DateUtil.compareDate(temp.laskWorkTime, currentTimeFull, DateUtil.DATE_VISUAL14FORMAT) < 7200*1000) {
                                            //如果距离最近执行时间过去不到两小时，则直接跳过
                                            continue;
                                        }else {
                                            worker.work(temp);
                                        }
                                    }
                            }
                        } else {
                            if (temp.cycle >= 1) {
                                if (temp.cycle_count % temp.cycle == 0) {
                                    worker.work(temp);
                                }
                            } else {
                                worker.work(temp);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    synchronized (JobScheudler.class) {
                        working = false;
                    }
                }
            }
        }, 5);
    }
}