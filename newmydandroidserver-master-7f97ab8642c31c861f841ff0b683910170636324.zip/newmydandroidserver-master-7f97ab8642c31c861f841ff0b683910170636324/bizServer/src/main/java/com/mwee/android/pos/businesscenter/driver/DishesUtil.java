package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;
import android.util.SparseArray;

import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.BonusMenuDBModel;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/2/4.
 */

public class DishesUtil {
    /**
     * 催菜
     *
     * @param seqId
     * @return
     */
    public static boolean hurryDish(String seqId) {
        String sql = "update tbsellorderitem SET fiHurryTimes=fiHurryTimes+1 where fsSeq in (" + seqId + ") or fsSeq_M in (" + seqId + ")";
        return DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 起菜
     *
     * @param seqId
     * @return
     */
    public static boolean doDishes(String seqId) {
        String sql = "update tbsellorderitem SET fiItemMakeSte=3 where fsSeq in (" + seqId + ") or fsSeq_M in (" + seqId + ")";
        return DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }


    public static boolean updateDishNumber(String menuUniq, BigDecimal changeNum) {
        String sql = "update tbsellorderitem SET fdSaleQty=" + changeNum + " where fsSeq='" + menuUniq + "'";
        return DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 根据销售明细序列seq 从orderCache中查询出指定 销售菜品信息
     *
     * @param seq
     * @param originMenuList
     * @return
     */
    public static MenuItem findMenuItemBySeq(String seq, List<MenuItem> originMenuList) {
        for (int i = 0; i < originMenuList.size(); i++) {
            if (seq.equals(originMenuList.get(i).menuBiz.uniq)) {
                return originMenuList.get(i);
            }
        }
        return null;
    }

    /**
     * 筛选出所有被退掉的菜和新增的菜
     *
     * @param oldList 编辑前的配料集合
     * @param newList 编辑后的配料集合
     * @return
     */
    public static SparseArray<List<MenuItem>> updateMenuItem(List<MenuItem> oldList, List<MenuItem> newList) {
        SparseArray<List<MenuItem>> changedList = new SparseArray<>();
        List<MenuItem> addedMenuItem = new ArrayList<>();
        List<MenuItem> deletedMenuItem = new ArrayList<>();

        for (int j = 0; j < oldList.size(); j++) {
            MenuItem oldItem = oldList.get(j);
            if (oldItem == null || oldItem.menuBiz.buyNum.compareTo(oldItem.menuBiz.voidNum) <= 0) {  //之前已经退完的菜，不参与本次筛选
                oldList.remove(j);
                j--;
                continue;
            }

            oldItem.menuBiz.buyNum = oldItem.menuBiz.buyNum.subtract(oldItem.menuBiz.voidNum);

            for (int i = 0; i < newList.size(); i++) {
                MenuItem newItem = newList.get(i);
                if (TextUtils.equals(oldItem.itemID, newItem.itemID)) {
                    if (oldItem.menuBiz.buyNum.compareTo(newItem.menuBiz.buyNum) > 0) {  //退菜了
                        newItem.menuBiz.buyNum = oldItem.menuBiz.buyNum.subtract(newItem.menuBiz.buyNum);
                        deletedMenuItem.add(newItem);
                    } else if (oldItem.menuBiz.buyNum.compareTo(newItem.menuBiz.buyNum) < 0) { //加菜了
                        newItem.menuBiz.buyNum = newItem.menuBiz.buyNum.subtract(oldItem.menuBiz.buyNum);
                        addedMenuItem.add(newItem);
                    }
                    newList.remove(i);
                    oldList.remove(j);
                    i--;
                    j--;
                    break;
                }
            }
        }
        deletedMenuItem.addAll(oldList);
        addedMenuItem.addAll(newList);

        changedList.put(0, addedMenuItem);
        changedList.put(1, deletedMenuItem);
        return changedList;
    }

    /**
     * 修改菜品配料
     *
     * @param isMember   是否登录了会员
     * @param menu       改动的菜品
     * @param voidItems  退菜列表
     * @param addedItems 新增菜列表
     */
    public static void changeMenuItemIngredient(UserDBModel userDBModel, boolean isMember, MenuItem menu, List<MenuItem> addedItems, List<MenuItem> voidItems) {
        for (MenuItem orderItem : menu.menuBiz.selectedModifier) {

            for (MenuItem voidItem : voidItems) {
                if (TextUtils.equals(orderItem.itemID, voidItem.itemID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, voidItem.currentUnit.fiOrderUintCd)) {
                    orderItem.doVoid(voidItem.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "");
                    if (menu.isGift()) {  //如果配料头被赠送了，配料也要被赠送
                        orderItem.doGift(menu.menuBiz.giftUserID, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                    }
                    orderItem.calcTotal(isMember);
                    break;
                }
            }
            for (MenuItem addItem : addedItems) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, addItem.currentUnit.fiOrderUintCd)) {
                    orderItem.menuBiz.buyNum = orderItem.menuBiz.buyNum.add(addItem.menuBiz.buyNum);
                    if (menu.isGift()) {
                        orderItem.doGift(menu.menuBiz.giftUserID, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                    }
                    orderItem.calcTotal(isMember);
                    break;
                }
            }
        }

        for (MenuItem addItem : addedItems) {
            boolean isExist = false;
            for (MenuItem orderItem : menu.menuBiz.selectedModifier) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, addItem.currentUnit.fiOrderUintCd)) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                if (menu.isGift()) {
                    addItem.doGift(userDBModel.fsUserId, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                }
                addItem.calcTotal(isMember);
                menu.menuBiz.selectedModifier.add(addItem);
            }
        }

        // 如果新添加了配料，整个配料菜需要重新使用折扣
        if (menu.supportDiscount() && menu.menuBiz.selectDiscount != null) {
            menu.giveDiscount(menu.menuBiz.selectDiscount, menu.menuBiz.discountReason, menu.menuBiz.discountUserID, menu.menuBiz.discountUserName, false);
        }

        menu.calcTotal(isMember);
    }

    /**
     * 修改套餐子项
     *
     * @param userDBModel  用户信息
     * @param isMember     是否是会员
     * @param menu         套餐
     * @param addedItems   加菜列表
     * @param voidItems    退菜列表
     * @param updatedItems 更新的菜品列表（要求/做法更新）
     */
    public static void changeMenuItemPackageItems(UserDBModel userDBModel, boolean isMember, MenuItem menu, List<MenuItem> addedItems, List<MenuItem> voidItems, List<MenuItem> updatedItems, String hostId) {
        for (MenuItem orderItem : menu.menuBiz.selectedPackageItems) {
            for (MenuItem voidItem : voidItems) {
                if (TextUtils.equals(orderItem.itemID, voidItem.itemID) &&
                        TextUtils.equals(orderItem.packSubID, voidItem.packSubID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, voidItem.currentUnit.fiOrderUintCd)) {
                    orderItem.doVoid(voidItem.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, voidItem.menuBiz.voidReson);
                    if (menu.isGift()) {  //如果套餐头被赠送了，套餐子项也要被赠送
                        orderItem.forceGift(menu.menuBiz.giftUserID, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                    }
                    orderItem.calcTotal(isMember);

                    if (DBOrderConfig.useKdsService()) {
                        KdsManager.getInstance().backMenu(orderItem.menuBiz.uniq, voidItem.menuBiz.buyNum, false, hostId, userDBModel);
                    }
                    break;
                }
            }
            for (MenuItem addItem : addedItems) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID) &&
                        TextUtils.equals(orderItem.packSubID, addItem.packSubID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, addItem.currentUnit.fiOrderUintCd)) {
                    orderItem.menuBiz.buyNum = orderItem.menuBiz.buyNum.add(addItem.menuBiz.buyNum);
                    if (menu.isGift()) {
                        orderItem.forceGift(menu.menuBiz.giftUserID, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                    }
                    orderItem.calcTotal(isMember);
                    break;
                }
            }
            for (MenuItem updateItem : updatedItems) {
                if (TextUtils.equals(orderItem.itemID, updateItem.itemID) &&
                        TextUtils.equals(orderItem.packSubID, updateItem.packSubID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, updateItem.currentUnit.fiOrderUintCd)) {
                    orderItem.menuBiz.selectNote.clear();
                    orderItem.menuBiz.selectNote.addAll(updateItem.menuBiz.selectNote);
                    orderItem.menuBiz.selectMulProcedure.clear();
                    orderItem.menuBiz.selectMulProcedure.addAll(updateItem.menuBiz.selectMulProcedure);
                    if (menu.isGift()) {
                        orderItem.forceGift(menu.menuBiz.giftUserID, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                    }
                    orderItem.calcTotal(isMember);
                }
            }
        }

        for (MenuItem addItem : addedItems) {
            boolean isExist = false;
            for (MenuItem orderItem : menu.menuBiz.selectedPackageItems) {
                if (TextUtils.equals(orderItem.itemID, addItem.itemID) &&
                        TextUtils.equals(orderItem.packSubID, addItem.packSubID) &&
                        TextUtils.equals(orderItem.currentUnit.fiOrderUintCd, addItem.currentUnit.fiOrderUintCd)) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                if (menu.isGift()) {
                    addItem.forceGift(userDBModel.fsUserId, menu.menuBiz.giftAuthUserId, menu.menuBiz.giftReason);
                }
                addItem.calcTotal(isMember);
                menu.menuBiz.selectedPackageItems.add(addItem);
            }
        }

        // 如果新添加了套餐子项，整个套餐需要重新使用折扣
        if (menu.supportDiscount() && menu.menuBiz.selectDiscount != null) {
            menu.giveDiscount(menu.menuBiz.selectDiscount, menu.menuBiz.discountReason, menu.menuBiz.discountUserID, menu.menuBiz.discountUserName, true);
        }

        menu.calcTotal(isMember);
    }

    /**
     * 更新提成信息
     *
     * @param orderId       订单id
     * @param businessDate  营业日期
     * @param menuItems     提成的菜品
     * @param operationUser 操作人员
     */
    public static void doBonus(String orderId, String businessDate, List<MenuItem> menuItems, UserDBModel operationUser) {
        if (ListUtil.isEmpty(menuItems)) {
            return;
        }
        for (MenuItem item : menuItems) {
            if (item == null || item.menuBiz == null) {
                continue;
            }
            SellOrderItemBonusDBModel model = new SellOrderItemBonusDBModel();
            model.fssellno = orderId;
            model.fsSeq = item.menuBiz.uniq;
            model.fiItemCd = item.itemID;
            model.fsitemName = item.name;
            model.fiOrderUintCd = item.currentUnit.fiOrderUintCd;
            model.fsOrderUint = item.currentUnit.fsOrderUint;
            model.fdsaleAmt = item.price;
            model.fdBonusQty = item.menuBiz.buyNum.subtract(item.menuBiz.voidNum);
            model.fsBonusUserId = item.menuBiz.bonusUserId;
            String shopID = HostUtil.getShopID();
            UserDBModel user = UserDBUtils.queryById(item.menuBiz.bonusUserId);
            if (user != null) {
                String sql = "SELECT tbBonusMenu.fsBonusMenuGuid,tbBonusMenu.fsBonusMenuName,tbBonusMenu.fiBonusMenuType " +
                        " FROM tbBonusMenu INNER JOIN tbBonusManageUser " +
                        " ON tbBonusManageUser.fsBonusMenuGuid=tbBonusMenu.fsBonusMenuGuid " +
                        " WHERE tbBonusManageUser.fsStaffId='" + item.menuBiz.bonusUserId + "'" +
                        " AND tbBonusMenu.fsShopGUID='" + shopID + "'";
                BonusMenuDBModel bonusMenu = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, BonusMenuDBModel.class);
                if (bonusMenu != null) {
                    model.fsBonusMenuGuid = bonusMenu.fsBonusMenuGuid;
                    model.fsBonusMenuName = bonusMenu.fsBonusMenuName;
                    model.fiBonusMenuType = bonusMenu.fiBonusMenuType;
                }
                model.fsBonusUserName = user.fsUserName;
            }
            model.fsBonusCertigierUserId = item.menuBiz.bonusAuthorizerId;
            UserDBModel authUser = UserDBUtils.queryById(item.menuBiz.bonusAuthorizerId);
            if (authUser != null) {
                model.fsBonusCertigierUserName = authUser.fsUserName;
            }
            model.fsselldate = businessDate;
            model.fiStatus = 1;
            model.fsShopGUID = shopID;
            model.fsUpdateTime = DateTimeUtil.getCurrentDateTime();
            model.fsUpdateUserId = operationUser.fsUserId;
            model.fsUpdateUserName = operationUser.fsUserName;
            model.replaceNoTrans();
        }
    }
}
