package com.mwee.android.pos.businesscenter.business.netOrder.air;

import android.text.TextUtils;

import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.TakeAwaySource;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2018/8/13.
 */

public class NetOrderProcessor {

    public void saveToDB(TempAppOrder tempAppOrder) {
        //构建OrderCache

        //构建menuItems

        //构建支付明细

        //save to db
    }


    /**
     * TempAppOrder 转 OrderCache
     *
     * @param tempAppOrder
     * @return
     */
    public OrderCache newOrderCache(TempAppOrder tempAppOrder) {
        UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
        String shopID = HostUtil.getShopID();
        String date = "";
        if (APPConfig.isCasiher()) {
            date = DateUtil.getCurrentDate("yyyy-MM-dd");
        } else {
            date = HostUtil.getHistoryBusineeDate(shopID);
        }
        String orderID = OrderDriver.generateNewOrderID(true);
        OrderCache orderCache = OrderDriver.generateNewOrder(orderID);
        orderCache.thirdOrderType = NetOrderType.NET_ORDER;
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = userDBModel.fsUserId;
        orderCache.waiterName = userDBModel.fsUserName;
        orderCache.shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = OrderUtil.getSectionId();
        orderCache.businessDate = date;
        orderCache.mealNumber = orderID.substring(8);
        orderCache.orderStatus = OrderStatus.NORMAL;
        orderCache.fiSellType = 2;
        orderCache.currentSeq = 1;
        orderCache.whetherRound = false;
        orderCache.thirdOrderId = String.valueOf(tempAppOrder.orderId);
        orderCache.fsBillSourceId = getBillSourceId(tempAppOrder.orderTakeawaySource);
        //将第一批次置为已下单
        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
        //构建已点菜品
        orderCache.originMenuList = copyToMenuList(tempAppOrder.orderDetailList, orderCache.currentSeq);
        orderCache.reCalcAllByAll();
        // 当日已上传账单，后续账单默认隐藏
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0") || TextUtils.equals(status, "1")) {
            orderCache.hidden = 1;
        }
        orderCache.fsAccountBook = ",1,";
        orderCache.updateSeqStatus(1, OrderSeqStatus.NORMAL, userDBModel, HostBiz.cloudsite);
        //保存订单
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "newOrderCache");
        //锁死订单，不允许该订单被站点捡到
        return orderCache;
    }

    /**
     * TempAppOrderDetail 转MenuItem
     *
     * @param orderDetailList
     * @param currentSeq
     * @return
     */
    private List<MenuItem> copyToMenuList(List<TempAppOrderDetail> orderDetailList, int currentSeq) {
        List<MenuItem> menuItemList = new ArrayList<>();
        for (TempAppOrderDetail tempAppOrderDetail : orderDetailList) {
//            menuItemList.add(copyToMenu(tempAppOrderDetail, currentSeq));
        }
        return menuItemList;
    }

//    private MenuItem copyToMenu(TempAppOrderDetail item, int currentSeq) {
//        MenuitemDBModel itemDB = null;
//        MenuItemUnitDBModel unitDBModel = null;
//        MenuItem menuItem = null;
//
//        String itemId = item.itemCode;
//        if (TextUtils.equals(tempAppOrderDetail.orderTakeawaySource, TakeAwaySource.MWEE) && !TextUtils.isEmpty(item.outerItemId)) {
//            itemId = item.outerItemId;
//        }
//        itemDB = MenuDBUtil.getUsefulMenuDBModelBy(itemId);
//
//        if (!TextUtils.isEmpty(item.specId)) {
//            unitDBModel = MenuDBUtil.queryMenuItemUnit(StringUtil.toInt(item.specId));
//        }
//
//        //匹配到本地菜品
//        if (itemDB != null) {
//            menuItem = MenuDBUtil.buildMenuByDBModel(itemDB, null);
//            if (unitDBModel != null) {
//                menuItem.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
//            }
//            if (menuItem.currentUnit == null) {
//                menuItem.currentUnit = new UnitModel();
//            }
//            if (menuItem.menuBiz == null) {
//                menuItem.menuBiz = new MenuBiz();
//            }
//            if (menuItem.supportTimes()) {
//                menuItem.changeTimesPrice(item.itemPrice);
//            }
//            menuItem.menuBiz.generateUniq();
//            menuItem.menuBiz.addConfig(8);
//        } else {
//            //未匹配到本地菜品
//            /**
//             * 后台开启自动使用临时菜入库开关或者是美收银模式,未映射菜品自动使用临时菜入库
//             */
//            if ((TextUtils.equals(PrintConfig.NET_ORDER_MAPPING_WITH_TEMP_MENU, "1") || APPConfig.isCasiher() || APPConfig.isAir()) && bizTempMenu != null) {
//                          /* 构建菜品信息 */
//                menuItem = MenuDBUtil.buildMenuByDBModel(bizTempMenu.clone(), null, true);
//                if (menuItem.currentUnit == null) {
//                    if (bizTempUnit != null) {
//                        menuItem.currentUnit = UnitModel.copyTo(bizTempUnit);
//                    } else {
//                        menuItem.currentUnit = new UnitModel();
//                    }
//                }
//                menuItem.name = item.itemName + "（外卖映射）";
//                menuItem.name2 = item.itemName + "（外卖映射）";
//
//            } else {
//                //未匹配到本地菜品
//                menuItem = new MenuItem();
//                if (unitDBModel == null) {
//                    unitDBModel = new MenuItemUnitDBModel();
//                    unitDBModel.fiOrderUintCd = 0;
//                    unitDBModel.fsOrderUint = item.unit;
//                }
//                menuItem.currentUnit = UnitModel.copyTo(unitDBModel);
//                menuItem.name = item.itemName;
//                menuItem.name2 = item.itemName;
//            }
//
//            if (menuItem.menuBiz == null) {
//                menuItem.menuBiz = new MenuBiz();
//            }
//            menuItem.menuBiz.generateUniq();
//
//            menuItem.menuBiz.createTime = DateUtil.getCurrentTime();
//            //菜品自动映射失败
//            RunTimeLog.addLog(RunTimeLog.NETORDER_MAP_FAIL, "第三方订单入报表失败，原因：映射失败 orderId = " + tempAppOrder.orderId);
//            if (!APPConfig.isCasiher()) {
//                unMappingItemCount++;
//            }
//        }
//        menuItem.menuBiz.orderSeqID = orderCache.currentSeq;
//        orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
//        orderCache.currentSeq++;
//
//        initItemModifiers(item.modifiertypes, menuItem);
//
//        menuItem.menuBiz.selectOrderNote.clear();
//        menuItem.addOrderNote(noteOrder);
//        //为兼容外卖菜品总价!=单价X数量的问题，POS入库时做兼容
//        if (item.totalItemPrice.compareTo(item.itemPrice.multiply(new BigDecimal(item.itemNum))) != 0) {
//            item.itemPrice = item.totalItemPrice;
//            item.itemNum = 1;
//        }
//
//        //为兼容外卖菜品总价!=单价X数量的问题，POS入库时做兼容
//        if (item.totalItemPrice.compareTo(item.itemPrice.multiply(new BigDecimal(item.itemNum))) != 0) {
//            item.itemPrice = item.totalItemPrice;
//            item.itemNum = 1;
//        }
//
//        menuItem.thirdMenuId = item.takeawayItemId;
//        menuItem.thirdMenuName = item.itemName;
//        menuItem.thirdUnitId = item.takeawaySpecId;
//        menuItem.thirdUnitName = "";
//
//        if (menuItem.supportTimes()) {
//            menuItem.changeTimesPrice(item.itemPrice);
//        }
//
//        //价格
//        menuItem.price = item.itemPrice;
//        menuItem.currentUnit.fdOriginPrice = item.itemPrice;
//        menuItem.currentUnit.fdSalePrice = item.itemPrice;
//        menuItem.currentUnit.fdVIPPrice = item.itemPrice;
//        // 2017/12/26 itemPrice 即菜品最终价格, 不需额外计算 modifierPrice
////                menuItem.menuBiz.priceExtraTotal = item.modifierPrice;
//        menuItem.menuBiz.priceExtraTotal = BigDecimal.ZERO;
//        menuItem.menuBiz.totalPrice = item.totalItemPrice;
//        menuItem.menuBiz.buyNum = new BigDecimal(item.itemNum);
//        menuItem.menuBiz.pokeNo = item.pokeNo;
//        menuItem.fsBillSourceId = fsBillSourceId;
//        menuItem.fsBillSourceNo = fsBillSourceNo;
//        return null;
//    }

    private String getBillSourceId(String orderTakeawaySource) {
        if (!TextUtils.isEmpty(orderTakeawaySource)) {
            if (orderTakeawaySource.startsWith("ELEME")) {
                return "2";
            } else if (orderTakeawaySource.startsWith("MEITUAN")) {
//                update from 3 to 22 and ignore local past order in db
                return "22";
            } else if (orderTakeawaySource.startsWith("BAIDU")) {
                return "4";
            } else if (orderTakeawaySource.startsWith("MWEE")) {
                return "21";
            }
        }
        return "1";
    }
}
