package com.mwee.android.pos.businesscenter.netbiz.wechatOrder;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.NetworkConstans;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.GetAllWeChatRequest;
import com.mwee.android.pos.component.datasync.net.GetWechatOrderByNoRequest;
import com.mwee.android.pos.component.datasync.net.ModifyWechatOrderRequest;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.WechatOrderModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by lxx on 17/1/16.
 * 微信外卖
 */
public class WechatOrderApi {

    /**
     * 获取所有订单---未处理的订单
     *
     * @param orderno 订单号
     * @return
     */
    public static String getAllData(String orderno, boolean forceMainThread, IExecutorCallback callback) {
        GetAllWeChatRequest getDataRequest = new GetAllWeChatRequest();
        getDataRequest.fsorderno = orderno;
        return BusinessExecutor.execute(getDataRequest, callback, null, forceMainThread);
    }

    public static String getLastWechatOrderNo() {
        return IOCache.getCacheStr(META.ONLINE_ORDER_WECHAT_LAST_NO, "0");
    }

    /**
     * 同步微信订单
     */
    public static void getDatasFromServer(final boolean forceMainThread, final IResult iResult) {
        String lastNo = getLastWechatOrderNo();
        getAllData(lastNo, forceMainThread, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                int result = WechatOrderProcessor.parseGetAllWechatData(responseData);
                if (result == 2) {
                    RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "微信外卖还有尚未同步的订单", "");
                    getDatasFromServer(forceMainThread, iResult);
                } else {
                    String tips = result == 0 ? "没有更多数据" : result == 1 ? "获取成功" : "解析失败";
                    if (iResult != null) {
                        iResult.callBack(true, tips);
                    }
                    RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, tips, "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "获取所有网络订单失败, 请稍后重试（" + responseData.resultMessage + ")", JSON.toJSONString(responseData));
                if (iResult != null) {
                    iResult.callBack(false, "获取所有网络订单失败, 请稍后重试（" + responseData.resultMessage + ")");
                }
                return false;
            }
        });
    }

    /**
     * 收到新消息推送 -- 根据订单号拉取订单
     *
     * @param fsorderno 订单号
     * @return
     */
    public static String getWechatOrderByNo(final String fsorderno, final int retrySeq) {
        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, retrySeq + "根据订单号拉取订单:fsorderno = " + fsorderno, "");
        BusinessCallback callback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                //解析拉取到的数据
                int result = WechatOrderProcessor.parseWechatOrderData(responseData);
                WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(fsorderno);
                if (result == 1 && wechatOrderModel != null) {
                    try {
                        //通知各站点有新订单来了
                        NotifyToClient.addNewWechatOrder(fsorderno, wechatOrderModel.fscreatetime);
                    } catch (Exception e) {
                        e.printStackTrace();
                        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, retrySeq + "拉取网络订单详情完成后，刷新UI时异常：orderId = " + wechatOrderModel.fsorderno, e.getMessage());
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, retrySeq + "推送来了新订单消息，拉取网络订单详情：失败（网络获取失败）", JSON.toJSONString(responseData));
                if (retrySeq < 3) {   //自动拉单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            TempAppOrder appOrder = NetOrderDBUtil.getTempAppOrderById(fsorderno);
                            if (appOrder == null) {
                                getWechatOrderByNo(fsorderno, retrySeq + 1);
                            }
                        }
                    }, 2000);

                }
                return false;
            }
        };
        GetWechatOrderByNoRequest getDataRequest = new GetWechatOrderByNoRequest();
        getDataRequest.fsorderno = fsorderno;
        return BusinessExecutor.execute(getDataRequest, null, callback);
    }


    public static String getWechatOrderByNo(final String fsorderno, boolean forceOnMain, final IResponse<WechatOrderModel> iResponse) {
        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "根据订单号拉取订单:fsorderno = " + fsorderno, "");
        BusinessCallback callback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                //解析拉取到的数据
                int result = WechatOrderProcessor.parseWechatOrderData(responseData);
                WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(fsorderno);
                if (result == 1 && wechatOrderModel != null) {
                    if (iResponse != null) {
                        iResponse.callBack(true, 0, responseData.resultMessage, wechatOrderModel);
                    }
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, -1, responseData == null ? "获取订单明细异常" : responseData.resultMessage, null);
                    }
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "推送来了新订单消息，拉取网络订单详情：失败（网络获取失败）", JSON.toJSONString(responseData));
                if (iResponse != null) {
                    iResponse.callBack(false, -1, responseData.resultMessage, null);
                }
                return false;
            }
        };
        GetWechatOrderByNoRequest getDataRequest = new GetWechatOrderByNoRequest();
        getDataRequest.fsorderno = fsorderno;
        return BusinessExecutor.execute(getDataRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, callback, forceOnMain);
    }

    /**
     * 更新订单diningStatus状态
     *
     * @param fsorderno 订单号
     * @param fistatus  订单状态
     * @param callback
     * @return
     */
    public static String updateWechatOrderStatus(final String fsorderno, int fistatus, IExecutorCallback callback, BusinessCallback businessCallback, boolean forceMainThread) {
        final ModifyWechatOrderRequest request = new ModifyWechatOrderRequest();
        request.fistatus = fistatus;
        request.fsorderno = fsorderno;
        RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, "更改网络订单请求 fsorderno = " + fsorderno, JSON.toJSONString(request));

        return BusinessExecutor.execute(request, callback, businessCallback, forceMainThread);
    }

    /**
     * 取消订单 \ 接单 -- 重试三次
     *
     * @param fsorderno
     * @param retrySeq
     * @param iResponse
     */
    public static void updateWechatOrderStatus(final String fsorderno, final int status, final int retrySeq, final IResponse<String> iResponse, final String currentHostId, final String fsUserName) {

        updateWechatOrderStatus(fsorderno, status, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                try {
                    synchronized (WechatOrderApi.class) {
                        String fistatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fistatus from tbwechatorder where fsorderno = '" + fsorderno + "'");
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbwechatorder set fistatus = '" + status + "' where fsorderno = '" + fsorderno + "'");

                        if ((status == NetworkConstans.WECHAT_STATUS_CANCEL
                                || status == NetworkConstans.WECHAT_STATUS_CANCEL_FROM_SHOP)
                                && TextUtils.equals(fistatus, NetworkConstans.WECHAT_STATUS_GET + "")
                                ) {  //已接单的订单取消是要打印退菜单的
                            WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(fsorderno);
                            PrintNetOrderUtil.printWechatKDSReceipt(wechatOrderModel, true, currentHostId, fsUserName);
                        } else if (status == NetworkConstans.WECHAT_STATUS_GET) {//接单要打印制作单和结账单
                            if (!ServerCache.getInstance().netOrderCache.checkNetOrderPrint(fsorderno)) {
                                WechatOrderModel wechatOrderModel = WechatOrderDBUtil.getWechatOrderByNo(fsorderno);
                                PrintNetOrderUtil.printWechatReceipt(wechatOrderModel, currentHostId, fsUserName);
                                PrintNetOrderUtil.printWechatKDSReceipt(wechatOrderModel, false, currentHostId, fsUserName);
                            }
                        }
                        if (iResponse != null) {
                            iResponse.callBack(true, 0, "", fsorderno);
                        }
                    }
                } catch (Exception e) {
                    if (iResponse != null) {
                        iResponse.callBack(false, 0, "操作失败，请稍后重试", fsorderno);
                    }
                    LogUtil.logError(e);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (retrySeq < 3) {   //自动接单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String fistatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fistatus from tbwechatorder where fsorderno = '" + fsorderno + "'");
                            if (!TextUtils.equals(fistatus, status + "")) {
                                updateWechatOrderStatus(fsorderno, status, retrySeq + 1, iResponse, currentHostId, fsUserName);
                            } else {
                                if (iResponse != null) {
                                    iResponse.callBack(true, 0, "", fsorderno);
                                }
                            }
                        }
                    }, 2000);
                } else {
                    if (iResponse != null) {
                        iResponse.callBack(false, -1, TextUtils.isEmpty(responseData.resultMessage) ? "失败" : responseData.resultMessage, fsorderno);
                    }
                }
                LogUtil.logBusiness(retrySeq + "取消订单、接单 异常，订单号：" + fsorderno + "；异常信息：" + responseData.resultMessage);
                ActionLog.addLog(retrySeq + "取消订单、接单 (" + status + ") 异常，订单号：" + fsorderno + "；异常信息：" + responseData.resultMessage, ActionLog.WECHAT_ORDER);
                return false;
            }
        }, false);
    }


    /**
     * 根据订单号拉取订单---收到订单状态改变消息时，更新本地数据
     *
     * @param fsorderno
     * @return
     */
    public static String updateWechatworkOrderById(final String fsorderno, final int retrySeq) {
        BusinessCallback callback = new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                //解析拉取到的数据
                int result = WechatOrderProcessor.parseWechatOrderData(responseData);
                if (result == 1) {
                    NotifyToClient.updateWechatOrder(fsorderno);
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                RunTimeLog.addLog(RunTimeLog.WECHAT_ORDER, retrySeq + "更新订单信息，拉取网络订单详情：失败（网络获取失败）", "");
                if (retrySeq < 3) {   //自动拉单三次
                    GlobalLooper.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            TempAppOrder appOrder = NetOrderDBUtil.getTempAppOrderById(fsorderno);
                            if (appOrder == null) {
                                updateWechatworkOrderById(fsorderno, retrySeq + 1);
                            }
                        }
                    }, 2000);
                }
                return false;
            }
        };

        GetWechatOrderByNoRequest getDataRequest = new GetWechatOrderByNoRequest();
        getDataRequest.fsorderno = fsorderno;
        return BusinessExecutor.execute(getDataRequest, null, callback);

    }

}
