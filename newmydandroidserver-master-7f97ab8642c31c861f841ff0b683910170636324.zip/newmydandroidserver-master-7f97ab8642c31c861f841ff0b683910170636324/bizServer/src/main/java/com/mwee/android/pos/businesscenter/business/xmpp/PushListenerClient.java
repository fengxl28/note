package com.mwee.android.pos.businesscenter.business.xmpp;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.business.einvoice.model.InvoiceDetailBean;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.businesscenter.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.shareshop.processor.ShareShopProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataProcessor;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.netbiz.wechatOrder.WechatOrderApi;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.push.XMPPPushManager;
import com.mwee.android.pos.component.push.XmppMessage;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import org.jivesoftware.smack.packet.Message;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

/**
 * 数据格式
 * // PushMessage [msg=null, ID=10020, time=1464591971, Body={"appOrderId":2206837,"msgId":18196}, content=null]
 */
public class PushListenerClient {

    Context context;
    private static List<Integer> ignoreRepeated = Arrays.asList(500, 31000, 999999);// 忽略消息去重的Id

    public PushListenerClient(Context context) {
        super();
        this.context = context;
    }

    /**
     * 解析,处理推送消息
     *
     * @param pack Message | 完整的消息体
     */
    public static void receiveMsg(Message pack) {
        XmppMessage msg = null;
        try {
            msg = JSON.parseObject(pack.getBody(), XmppMessage.class);
        } catch (Exception e) {
            LogUtil.logError("解析推送消息异常 Message = " + JSON.toJSONString(pack), e);
            RunTimeLog.addNowLog(RunTimeLog.XMPP_PUSH_MESSAGE, "解析推送消息异常:", pack);
        }
        RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "收到推送消息:msg = " + pack.getBody(), "");
        if (msg == null || TextUtils.isEmpty(msg.body)) {
            RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "推送消息异常:不做处理", JSON.toJSONString(pack));
            return;
        }

        // 消息去重
        if (!ignoreRepeated.contains(msg.ID) && PushUtils.recivePushOrderMessage(msg.MsgId)) {
            LogUtil.logBusiness(msg.MsgId + "; 消息已处理过 " + msg.body);
            return;
        }

        //过滤打烊后就不再处理的消息
        if (!PushListenerProcess.checkCanDeal(msg.ID)) {
            RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "当前店铺已打烊：不再处理新收到的消息：" + msg.ID, JSON.toJSONString(pack));
            return;
        }
        // 订单无关消息
        boolean process = systemNotice(pack, msg.ID, msg.body);
        if (process) {
            return;
        }
        //微信点餐相关消息
        process = wechatOrder(msg.ID, msg.body);
        if (process) {
            return;
        }
        // 网络订单相关
        process = netOrderNotice(msg.ID, msg.body);
        if (process) {
            return;
        }
        // 共享餐厅订单相关
        process = shareShopOrderNotice(msg.ID, msg.body);
        if (process) {
            return;
        }

    }

    /**
     * {"T":"2017-01-20 18:34:27","XmppMsgId":"Y6Nus","Reporter":"+xmppserver+1+","Ack":1,"ID":"31000","time":1484908467,"Body":"11","MsgId":"Y6Nus"}
     *
     * @param msgId
     * @param msgBody
     * @return
     */
    private static boolean wechatOrder(int msgId, String msgBody) {
        switch (msgId) {
            case PushListenerProcess.XMPP_MSG_WECHAT_ORDER_NEW:
                ActionLog.addLog("收到新微信点餐消息:" + msgBody, "", "", ActionLog.WECHAT_ORDER, "");
                WechatOrderApi.getWechatOrderByNo(msgBody, 0);
                return true;
            case PushListenerProcess.XMPP_MSG_WECHAT_ORDER_OVER:
                ActionLog.addLog("收到完成微信点餐消息:" + msgBody, "", "", ActionLog.WECHAT_ORDER, "");
                WechatOrderApi.updateWechatworkOrderById(msgBody, 0);
                return true;
            case PushListenerProcess.XMPP_MSG_WECHAT_ORDER_CANCEL:
                ActionLog.addLog("收到取消微信点餐消息:" + msgBody, "", "", ActionLog.WECHAT_ORDER, "");
                WechatOrderApi.updateWechatworkOrderById(msgBody, 0);
                return true;
            default:
                break;
        }
        return false;
    }


    /**
     * 和订单不相关的消息
     * e.g. 上送日志、门店配置发生变化、上报订单、秒点消息
     *
     * @param msgId 消息编号
     */
    private static boolean systemNotice(final Message pack, int msgId, final String msgBody) {
        switch (msgId) {
            case PushListenerProcess.XMPP_MSG_REPORT_LOG:  //上送日志
                // 发送给主站点上送
                NotifyToClient.uploadLog();
                return true;
            case PushListenerProcess.XMPP_MSG_UPLOAD_ORDER: //主动上报订单
                BusinessExecutor.executeNoWait(new ASyncExecute() {
                    @Override
                    public Object execute() {
                        UploadDataProcessor.serverErrorReUploadData();
//                        UploadDataProcessor.doUploadOrderWithBaseData();
                        UploadDataHelper.uploadOrderData(true);
                        return null;
                    }
                });
                return true;
            case PushListenerProcess.XMPP_MSG_GET_NEW_DATA: //门店配置发生变化
                PushListenerProcess.shopDataSetChanged();
                return true;
            case PushListenerProcess.XMPP_MSG_GET_NEW_ORDER: {//秒点的订单
                // 此消息不做任何处理，但需要直接消耗掉，需要返回 true
//                RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控  收到秒点推送 " + DateUtil.getCurrentTime(), msgBody);
//                String commitid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msg from push_msg_stack where msg='" + msgBody + "'");
//                if (TextUtils.isEmpty(commitid)) {
//                    String time = DateUtil.getCurrentTime();
//                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "insert into push_msg_stack ('msg','updateTime') values ('" + msgBody + "','" + time + "')");
//                }
//                DriverBus.call("xmpp/receiveRapidPush", msgBody);
                return true;
            }
            case PushListenerProcess.XMPP_MSG_GET_NEW_ORDER_V2: {//秒点的订单
                // 美易点 2.7.7 之后，秒点订单使用新的 id。旧版本仅推送 commitid, 新版本推送 getwl 中的 RapidGetModel
                RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控  收到秒点推送 " + DateUtil.getCurrentTime(), msgBody);
                try {
                    RapidGetModel model = JSON.parseObject(msgBody, RapidGetModel.class);
                    String commitid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msg from push_msg_stack where msg='" + model.fsid + "'");
                    if (TextUtils.isEmpty(commitid)) {
                        String time = DateUtil.getCurrentTime();
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "insert into push_msg_stack ('msg','updateTime') values ('" + model.fsid + "','" + time + "')");
                    }
                    DriverBus.call("xmpp/receiveRapidPushV2", model);
                } catch (Exception ex) {
                    LogUtil.logError(ex);
                }
                return true;
            }
            case PushListenerProcess.XMPP_MSG_UPLOAD_BOOK_ORDER: {//预定订单
                String cloudBuffet = CommonDBUtil.getConfigWithDefault(DBPrintConfig.MWBYD_CLOUD_BUFFET, "0");
                if (TextUtils.equals("1", cloudBuffet)) {
                    RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "预定监控  收到预定推送 " + DateUtil.getCurrentTime(), msgBody);
                    String commitid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msg from push_msg_stack where msg='" + msgBody + "'");
                    if (TextUtils.isEmpty(commitid)) {
                        String time = DateUtil.getCurrentTime();
                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "insert into push_msg_stack ('msg','updateTime') values ('" + msgBody + "','" + time + "')");
                    }
                    DriverBus.call("xmpp/receiveRapidPush", msgBody);
                    return true;
                } else {

                    RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "预定监控  收到预定推送 但门店没有开启自助云服务", msgBody);
                }
            }
            case PushListenerProcess.THIRDPARTYPAY_RESULT:
                //第三方支付成功--->当前3.0似乎未接入，业务有待确认
                return true;
            case PushListenerProcess.XMPP_MSG_ADMIN://管理入口
                BusinessExecutor.executeNoWait(new ASyncExecute() {
                    @Override
                    public Object execute() {
                        try {
                            XMPPPushManager.sendInfo("resend:" + pack.getBody(), pack.getFrom());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            PushListenerProcess.processAdmin(pack, msgBody);
                        } catch (Throwable e) {
                            e.printStackTrace();
                            XMPPPushManager.sendInfo("response\n 发生异常：" + StringUtil.getExceptionInfo(e), pack.getFrom());
                        }
                        return null;
                    }
                });
                return true;
            case PushListenerProcess.E_INVOICE_STATUS_NOTIFY:
                //电子发票开票状态获取
                //解析数据，更新数据库：order_cache和tbsell
                RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "电子发票开票状态推送received");
                InvoiceDetailBean invoiceDetailBean = JSON.parseObject(msgBody, new TypeReference<InvoiceDetailBean>() {
                });
                RunTimeLog.addLog(RunTimeLog.ELECTRONIC_INVOICE, "电子发票流水号[" + invoiceDetailBean.business_no + "]开票状态[" + invoiceDetailBean.trade_state + "]");
                EInvoiceProcess.updateByDetail(invoiceDetailBean);
                return true;
            case PushListenerProcess.XMPP_MSG_UPLOAD_TO_MALL:
                RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "收到商场内网透传推送 " + DateUtil.getCurrentTime(), msgBody);
                LogUtil.logBusiness("收到商场内网透传推送 [" + DateUtil.getCurrentTime() + "]: " + msgBody);
                PushListenerProcess.uploadToMall(msgBody);
                break;
            case PushListenerProcess.XMPP_MSG_AUTHORITY_CONFIG:
                PushListenerProcess.dealXmppAuthorityConfig(msgBody);
                return true;
            case PushListenerProcess.XMPP_MSG_AUTHORITY_CONFIG_OPEN:
                PushListenerProcess.settingXmppAuthorityConfig(pack);
                return true;
            case PushListenerProcess.XMPP_MSG_MAPPING_MENU_AUTO:
                //air3.4.1自动匹配优化
                RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "自动匹配优化，收到菜品未映射推送");
                NotifyToClient.mappingMenuAuto(msgBody);
                return true;
            default:
                break;
        }
        return false;
    }

    /**
     * 处理和订单相关的消息
     * <p>
     * 1、过滤重复消息或者无效消息
     * 2、消息回执---告诉云端,推送已收到
     * 3、分业务处理订单
     *
     * @param ID      推送消息类型
     * @param msgBody 消息内容
     */
    private static synchronized boolean netOrderNotice(int ID, String msgBody) {
        JSONObject jsonObject = null;
        String appOrderId = "";
        try {
            jsonObject = new JSONObject(msgBody);
            if (jsonObject.isNull("msgId")) {  //订单相关的推送,没有msgId 的消息都是异常的消息
                return false;
            } else {
                //消息去重
//                String msgId = jsonObject.optString("msgId");
//                if (PushUtils.recivePushOrderMessage(msgId, msgBody)){
//                    return true;
//                }
            }
            //订单号
            appOrderId = jsonObject.optString("appOrderId");
        } catch (JSONException e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "消息体解析异常", e.getMessage());
        }

        if (jsonObject == null) {
            return false;
        }
        switch (ID) {
            case PushListenerProcess.PUSH_TAKEAWAY_OVER: //外卖单完成
            case PushListenerProcess.PUSH_THIRD_TAKEAWAY_OVER: //外卖单完成
                PushListenerProcess.netOrderOver(appOrderId);
                return true;
            case PushListenerProcess.PUSH_TAKEAWAY_GET: //外卖接单
                PushListenerProcess.netOrderGet(appOrderId);
                return true;
//            case PushListenerProcess.PUSH_ORDER:
            case PushListenerProcess.PUSH_TAKEAWAY_NEW:  //收到新订单
                PushListenerProcess.netOrderNew(appOrderId);
                return true;
            case PushListenerProcess.PUSH_TAKEAWAY_CANCLE://取消订单
                try {
                    String reason = jsonObject.getString("reason");
                    PushListenerProcess.netOrderCancel(appOrderId, reason);
                } catch (JSONException e) {
                    RunTimeLog.addLog(RunTimeLog.NETORDER, "取消订单原因解析异常", e.getMessage());
                }
                return true;
            case PushListenerProcess.PUSH_DELIVERY_NOMAL:
                //等待接单(0)--快递
                PushListenerProcess.netOrderDeliveryNomal(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_DELIVERY_WAITING:
                //待配送--快递
                PushListenerProcess.netOrderDeliveryWaiting(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_DELIVERY_GET_GOOGS:
                //取货-快递
                PushListenerProcess.netOrderDeliveryGetGoods(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_DELIVERY_ING:
                //配送中--快递
                PushListenerProcess.netOrderDeliveryING(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_DELIVERY_OVER:
                //完成--快递
                PushListenerProcess.netOrderDeliveryOver(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_DELIVERY_CANCEL:
                //已取消--快递
                PushListenerProcess.netOrderDeliveryCancel(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_MEITUAN_DOWNGRADE:
                // 美团隐私号降级
                try {
                    String realPhoneNumber = jsonObject.getString("realPhoneNumber");
                    PushListenerProcess.netOrderMeituanPhoneDowngrade(String.valueOf(appOrderId), realPhoneNumber);
                } catch (JSONException e) {
                    RunTimeLog.addLog(RunTimeLog.NETORDER, "美团隐私号降级，真实手机号解析异常", e.getMessage());
                }
                return true;
            case PushListenerProcess.PUSH_MEITUAN_DOWNGRADE_RESTORE:
                // 美团隐私号降级恢复
                PushListenerProcess.netOrderMeituanPhoneDowngradeRestore(String.valueOf(appOrderId));
                return true;
            case PushListenerProcess.PUSH_MEIXIAODIAN_CANCEL:
                String appOrderIdStr = jsonObject.optString("appOrderId");
                //  美小店用户取消订单
                MessageDBUtil.messageCancelOrder(String.valueOf(appOrderIdStr), MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.CANCEL);
                return true;
            default:
                break;
        }
        return false;
    }


    /**
     * 处理共享餐厅相关的消息
     *
     * @param ID      推送消息类型
     * @param msgBody 消息内容
     */
    private static synchronized boolean shareShopOrderNotice(int ID, String msgBody) {
        switch (ID) {
            case PushListenerProcess.XMPP_MSG_SHARE_SHOP_REFUND:
                //共享餐厅的退款
                RunTimeLog.addLog(RunTimeLog.SHARE_SHOP_REFUND, "共享餐厅的退款监控  收到推送 " + DateUtil.getCurrentTime(), msgBody);
                ShareShopProcessor.receivePushMsg(msgBody);
                return true;
            default:
                LogUtil.log("暂未接入的消息:" + ID + " " + msgBody);
                break;
        }
        return false;
    }
}
