package com.mwee.android.pos.businesscenter.framework;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.mwee.android.base.task.LowThread;
import com.mwee.android.pos.business.constants.BillSourceValue;
import com.mwee.android.pos.businesscenter.air.dbUtil.BillSourceDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.PaymentManageDBUtils;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.PaymenttypeDBModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

/**
 * Created by zhangmin on 2018/7/11.
 */

public class PresetDataUtils {


    /**
     * 小易口碑门店初始化预制数据
     */
    public static void presetData() {
        String fsshopguid = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsshopguid from tbShop ");
        if (TextUtils.isEmpty(fsshopguid)) {
            Log.d("", "店铺为null的时候不插入数据 等下一波启动后开始插入数据");
            return;
        }
        if (APPConfig.isAir()) {
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    presetDataFromMxy(fsshopguid);
                }
            }).start();
            return;
        }

        if (APPConfig.isMydKouBei()) {
            new LowThread(new Runnable() {
                @Override
                public void run() {
                    presetDataFromMyd(fsshopguid);
                }
            }).start();
        }
    }


    public static void presetDataFromMyd(String fsshopguid) {
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
            @Override
            public Boolean doJob(SQLiteDatabase db) {
                //来源
                if (!BillSourceDBUtils.isExist(BillSourceValue.BILL_KB)) {
                    db.execSQL("INSERT INTO tbBillSource (\"fsBillSourceId\", \"fsBillSourceName\", \"fiStatus\", \"fiDataKind\", \"fiBillSource\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\") VALUES ('103', '口碑', 1, 2, NULL, datetime('now'), 'admin', '管理员', '" + fsshopguid + "');");
                }
                //满减
                if (!PaymentManageDBUtils.isExist(DBConstants.PAY_TYPE_MJ)) {
                    db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys99006', '" + fsshopguid + "', '90', '满减', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
                }
                //口碑商品券优惠
                if (!PaymentManageDBUtils.isExist(DBConstants.PAY_TYPE_KB_TICKET_DISCOUNT)) {
                    db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\", \"fsCompanyId\") VALUES ('sys18004', '" + fsshopguid + "', '123', '口碑商品券优惠', 0, 0, 0, 0, 0, 0, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '99005', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 2, '');");
                }
                //口碑商品券
                if (!PaymentManageDBUtils.isExist(DBConstants.PAY_TYPE_KB_TICKET)) {
                    db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18002', '" + fsshopguid + "', '123', '口碑商品券', 0, 0, 0, 1, 0, 0, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '99005', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 2);");
                }
                //支付宝口碑支付
                if (!PaymentManageDBUtils.isExist(DBConstants.PAY_TYPE_KB_PAY)) {
                    db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18003', '" + fsshopguid + "', '123', '支付宝口碑支付', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
                }
                //菜品分类（其他）
                MenuclsDBModel menuclsDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenucls where fsMenuClsId = 'sys93'", MenuclsDBModel.class);
                if (menuclsDBModel == null) {
                    db.execSQL("INSERT INTO tbmenucls (\"fsMenuClsId\", \"fsShopGUID\", \"fsMenuClsName\", \"fsMenuClsFullName\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMenuClsKind\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fiLevel\", \"fiDtlLvl\", \"fsMenuClsId_P\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"sync\", \"fiDataSource\", \"fiIsPrn\") VALUES ('sys93', '" + fsshopguid + "', '其他', '', '99', '99', 1, 100, 1, 1, 1, 1, '0', datetime('now'), 'admin', '管理员', 1, 1, 0);");
                }
                //预点单餐盒费
                if (!MenuItemDBUtils.isExist(DBConstants.MENU_ITEM_ID_KB_BOX_PRICE)) {
                    db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99996, 'sys99996', '预点单餐盒费', 'yddchf', '', 'sys93', 0, 0, 0, 0, 0, 0, '', 0, 2, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '', '0', '', 1264, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 0, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
                }
                MenuItemUnitDBModel menuItemUnit99996 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99996'", MenuItemUnitDBModel.class);
                if (menuItemUnit99996 == null) {
                    db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99996, 99996, '个', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
                }

                //其他费用
                if (!MenuItemDBUtils.isExist(DBConstants.MENU_ITEM_ID_KB_OTHER_PRICE)) {
                    db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99997, 'sys99997', '其他费用', 'qtfy', '', 'sys93', 0, 0, 0, 0, 0, 0, '', 0, 2, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '', '0', '', 1263, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 0, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
                }
                MenuItemUnitDBModel menuItemUnit99997 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99997'", MenuItemUnitDBModel.class);
                if (menuItemUnit99997 == null) {
                    db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99997, 99997, '个', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
                }

                //临时菜
                if (!MenuItemDBUtils.isExist(DBConstants.MENU_ITEM_ID_TEMP)) {
                    db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99995, 'sys99995', '临时菜', 'lsc', '', '98', 0, 0, 1, 1, 1, 1, '', 0, 2, 1, 0, 0, 0, 0, 1, 1, '', 0, 0, '', '0', '', 1011, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 0, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 1, 1, 0);");
                }
                MenuItemUnitDBModel menuItemUnit99995 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99995'", MenuItemUnitDBModel.class);
                if (menuItemUnit99995 == null) {
                    db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99995, 99995, '份', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
                }

                //口碑支付宝违约金
                PaymentDBModel paymentsys18006 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18006'", PaymentDBModel.class);
                if (paymentsys18006 == null) {
                    db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18006', '" + fsshopguid + "', '123', '支付宝违约金', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
                } else {
                    if (paymentsys18006.fiStatus == 13) {
                        paymentsys18006.fiStatus = 1;
                        paymentsys18006.sync = 1;
                        paymentsys18006.fsUpdateTime = DateUtil.getCurrentTime();
                        paymentsys18006.replaceNoTrans();
                    }
                }

                return true;
            }
        });
    }


    private static void presetDataFromMxy(String fsshopguid) {
        DBManager.getInstance().executeInTransactionWithOutThread((db) -> {


            //todo -- 支付类型
            PaymenttypeDBModel paymenttype123 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpaymenttype where fsPaymentTypeId = '123'", PaymenttypeDBModel.class);
            if (paymenttype123 == null) {

                db.execSQL("INSERT INTO tbpaymenttype (\"fsPaymentTypeId\", \"fsShopGUID\", \"fsPaymentTypeName\", \"fsNote\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"sync\", \"fiDataSource\") VALUES ('123', '" + fsshopguid + "', '支付宝', NULL, 1, 1, datetime('now'), 'admin', '管理员', 1, 1);");
            } else {

                if (paymenttype123.fiStatus == 13) {
                    paymenttype123.fiStatus = 1;
                    paymenttype123.sync = 1;
                    paymenttype123.fsUpdateTime = DateUtil.getCurrentTime();
                    paymenttype123.replaceNoTrans();
                }
            }

            PaymenttypeDBModel paymenttype122 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpaymenttype where fsPaymentTypeId = '122'", PaymenttypeDBModel.class);
            if (paymenttype122 == null) {
                db.execSQL("INSERT INTO tbpaymenttype (\"fsPaymentTypeId\", \"fsShopGUID\", \"fsPaymentTypeName\", \"fsNote\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"sync\", \"fiDataSource\") VALUES ('122', '" + fsshopguid + "', '美团', NULL, 1, 1, datetime('now'), 'admin', '管理员', 1, 1);");
            } else {

                if (paymenttype122.fiStatus == 13) {
                    paymenttype122.fiStatus = 1;
                    paymenttype122.sync = 1;
                    paymenttype122.fsUpdateTime = DateUtil.getCurrentTime();
                    paymenttype122.replaceNoTrans();
                }
            }

            PaymenttypeDBModel paymenttype126 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpaymenttype where fsPaymentTypeId = '126'", PaymenttypeDBModel.class);
            if (paymenttype126 == null) {
                db.execSQL("INSERT INTO tbpaymenttype (\"fsPaymentTypeId\", \"fsShopGUID\", \"fsPaymentTypeName\", \"fsNote\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"sync\", \"fiDataSource\") VALUES ('126', '" + fsshopguid + "', '饿了么', NULL, 1, 1, datetime('now'), 'admin', '管理员', 1, 1);");
            } else {
                if (paymenttype126.fiStatus == 13) {
                    paymenttype126.fiStatus = 1;
                    paymenttype126.sync = 1;
                    paymenttype126.fsUpdateTime = DateUtil.getCurrentTime();
                    paymenttype126.replaceNoTrans();
                }
            }


            //todo -- 支付方式
            PaymentDBModel paymentsys18002 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18002'", PaymentDBModel.class);
            if (paymentsys18002 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18002', '" + fsshopguid + "', '123', '口碑商品券', 0, 0, 0, 1, 0, 0, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '99005', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 2);");

            } else {
                if (paymentsys18002.fiStatus == 13) {
                    paymentsys18002.fiStatus = 1;
                    paymentsys18002.sync = 1;
                    paymentsys18002.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys18002.replaceNoTrans();
                }
            }


            //todo 接入口碑后付款需求 需要添加支付方式   口碑商品券优惠 非实收  归属于fsDiscountPaymentId = 99005
            PaymentDBModel paymentsys18004 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18004'", PaymentDBModel.class);
            if (paymentsys18004 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18004', '" + fsshopguid + "', '123', '口碑商品券优惠', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '99005', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 2);");

            } else {
                if (paymentsys18004.fiStatus == 13) {
                    paymentsys18004.fiStatus = 1;
                    paymentsys18004.sync = 1;
                    paymentsys18004.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys18004.replaceNoTrans();
                }
            }


            //todo 接入口碑后付款需求 需要添加支付方式   口碑订单优惠 非实收  归属于fsDiscountPaymentId = '' ？？？后台没有归属
            PaymentDBModel paymentsys18005 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18005'", PaymentDBModel.class);
            if (paymentsys18005 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18005', '" + fsshopguid + "', '123', '口碑订单优惠', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");

            } else {
                if (paymentsys18005.fiStatus == 13) {
                    paymentsys18005.fiStatus = 1;
                    paymentsys18005.sync = 1;
                    paymentsys18005.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys18005.replaceNoTrans();
                }
            }



            //todo 接入口碑后付款需求 需要添加支付方式   微信小程序口碑支付 实收  归属于fsDiscountPaymentId = '' ？？？后台没有归属
            PaymentDBModel paymentsys12401 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys12401'", PaymentDBModel.class);
            if (paymentsys12401 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys12401', '" + fsshopguid + "', '123', '微信小程序口碑支付', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, '', 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");

            } else {
                if (paymentsys12401.fiStatus == 13) {
                    paymentsys12401.fiStatus = 1;
                    paymentsys12401.sync = 1;
                    paymentsys12401.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys12401.replaceNoTrans();
                }
            }



            PaymentDBModel paymentsys18003 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18003'", PaymentDBModel.class);
            if (paymentsys18003 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18003', '" + fsshopguid + "', '123', '支付宝口碑支付', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (paymentsys18003.fiStatus == 13) {
                    paymentsys18003.fiStatus = 1;
                    paymentsys18003.sync = 1;
                    paymentsys18003.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys18003.replaceNoTrans();
                }
            }


            PaymentDBModel paymentsys99006 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys99006'", PaymentDBModel.class);
            if (paymentsys99006 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys99006', '" + fsshopguid + "', '90', '满减', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (paymentsys99006.fiStatus == 13) {
                    paymentsys99006.fiStatus = 1;
                    paymentsys99006.sync = 1;
                    paymentsys99006.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys99006.replaceNoTrans();
                }
            }


            PaymentDBModel payment12201 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12201'", PaymentDBModel.class);
            if (payment12201 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12201', '" + fsshopguid + "', '122', '美团在线支付', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12201.fiStatus == 13) {
                    payment12201.fiStatus = 1;
                    payment12201.sync = 1;
                    payment12201.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12201.replaceNoTrans();
                }
            }


            PaymentDBModel payment12202 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12202'", PaymentDBModel.class);
            if (payment12202 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12202', '" + fsshopguid + "', '122', '美团货到付款', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12202.fiStatus == 13) {
                    payment12202.fiStatus = 1;
                    payment12202.sync = 1;
                    payment12202.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12202.replaceNoTrans();
                }
            }


            PaymentDBModel payment12203 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12203'", PaymentDBModel.class);
            if (payment12203 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12203', '" + fsshopguid + "', '122', '美团商家补贴', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 2, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12203.fiStatus == 13) {
                    payment12203.fiStatus = 1;
                    payment12203.sync = 1;
                    payment12203.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12203.replaceNoTrans();
                }
            }
            PaymentDBModel payment12204 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12204'", PaymentDBModel.class);
            if (payment12204 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12204', '" + fsshopguid + "', '122', '美团平台补贴', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12204.fiStatus == 13) {
                    payment12204.fiStatus = 1;
                    payment12204.sync = 1;
                    payment12204.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12204.replaceNoTrans();
                }
            }
            PaymentDBModel payment12205 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12205'", PaymentDBModel.class);
            if (payment12205 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12205', '" + fsshopguid + "', '122', '美团其他优惠', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12205.fiStatus == 13) {
                    payment12205.fiStatus = 1;
                    payment12205.sync = 1;
                    payment12205.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12205.replaceNoTrans();
                }
            }
            PaymentDBModel payment12206 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12206'", PaymentDBModel.class);
            if (payment12206 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12206', '" + fsshopguid + "', '122', '美团配送费', 0, 0, 0, 0, 0, 1, NULL, 99, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12206.fiStatus == 13) {
                    payment12206.fiStatus = 1;
                    payment12206.sync = 1;
                    payment12206.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12206.replaceNoTrans();
                }
            }
            PaymentDBModel payment12207 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12207'", PaymentDBModel.class);
            if (payment12207 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12207', '" + fsshopguid + "', '122', '美团平台服务费', 0, 0, 0, 0, 0, 1, NULL, 99, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12207.fiStatus == 13) {
                    payment12207.fiStatus = 1;
                    payment12207.sync = 1;
                    payment12207.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12207.replaceNoTrans();
                }
            }


            PaymentDBModel payment12601 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12601'", PaymentDBModel.class);
            if (payment12601 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12601', '" + fsshopguid + "', '126', '饿了么在线支付', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12601.fiStatus == 13) {
                    payment12601.fiStatus = 1;
                    payment12601.sync = 1;
                    payment12601.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12601.replaceNoTrans();
                }
            }

            PaymentDBModel payment12602 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12602'", PaymentDBModel.class);
            if (payment12602 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12602', '" + fsshopguid + "', '126', '饿了么货到付款', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12602.fiStatus == 13) {
                    payment12602.fiStatus = 1;
                    payment12602.sync = 1;
                    payment12602.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12602.replaceNoTrans();
                }
            }

            PaymentDBModel payment12603 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12603'", PaymentDBModel.class);
            if (payment12603 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12603', '" + fsshopguid + "', '126', '饿了么商家补贴', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12603.fiStatus == 13) {
                    payment12603.fiStatus = 1;
                    payment12603.sync = 1;
                    payment12603.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12603.replaceNoTrans();
                }
            }

            PaymentDBModel payment12604 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12604'", PaymentDBModel.class);
            if (payment12604 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12604', '" + fsshopguid + "', '126', '饿了么平台补贴', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12604.fiStatus == 13) {
                    payment12604.fiStatus = 1;
                    payment12604.sync = 1;
                    payment12604.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12604.replaceNoTrans();
                }
            }

            PaymentDBModel payment12605 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12605'", PaymentDBModel.class);
            if (payment12605 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12605', '" + fsshopguid + "', '126', '饿了么其他优惠', 0, 0, 0, 0, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12605.fiStatus == 13) {
                    payment12605.fiStatus = 1;
                    payment12605.sync = 1;
                    payment12605.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12605.replaceNoTrans();
                }
            }

            PaymentDBModel payment12606 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12606'", PaymentDBModel.class);
            if (payment12606 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12606', '" + fsshopguid + "', '126', '饿了么配送费', 0, 0, 0, 0, 0, 1, NULL, 99, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12606.fiStatus == 13) {
                    payment12606.fiStatus = 1;
                    payment12606.sync = 1;
                    payment12606.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12606.replaceNoTrans();
                }
            }

            PaymentDBModel payment12607 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = '12607'", PaymentDBModel.class);
            if (payment12607 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('12607', '" + fsshopguid + "', '126', '饿了么平台服务费', 0, 0, 0, 0, 0, 1, NULL, 99, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (payment12607.fiStatus == 13) {
                    payment12607.fiStatus = 1;
                    payment12607.sync = 1;
                    payment12607.fsUpdateTime = DateUtil.getCurrentTime();
                    payment12607.replaceNoTrans();
                }
            }

            //口碑支付宝违约金
            PaymentDBModel paymentsys18006 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbpayment where fsPaymentId = 'sys18006'", PaymentDBModel.class);
            if (paymentsys18006 == null) {
                db.execSQL("INSERT INTO tbpayment (\"fsPaymentId\", \"fsShopGUID\", \"fsPaymentTypeId\", \"fsPaymentName\", \"fdDefaultPrice\", \"fiIsForeign\", \"fdExchangeRate\", \"fiIsCalcPaid\", \"fiIsCalcInvoice\", \"fiIsPremium\", \"fsNote\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fscolor\", \"fdDiscountRate\", \"fsDiscountPaymentId\", \"fiIsPartAmtDiscount\", \"fsShortcutKey\", \"fsHelpCode\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"sync\", \"fiDataSource\", \"fiVoucherPlatform\") VALUES ('sys18006', '" + fsshopguid + "', '123', '支付宝违约金', 0, 0, 0, 1, 0, 1, NULL, 0, 1, 1, datetime('now'), 'admin', '管理员', '0', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 1, 1, 0);");
            } else {
                if (paymentsys18006.fiStatus == 13) {
                    paymentsys18006.fiStatus = 1;
                    paymentsys18006.sync = 1;
                    paymentsys18006.fsUpdateTime = DateUtil.getCurrentTime();
                    paymentsys18006.replaceNoTrans();
                }
            }


            //todo 这条数据应该后台预制 ！！！！！！！！！！！！！！
           /* BillSourceDBModel billSource103 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbBillSource where fsBillSourceId = '103'", BillSourceDBModel.class);
            if (billSource103 == null) {
                db.execSQL("INSERT INTO tbBillSource (\"fsBillSourceId\", \"fsBillSourceName\", \"fiStatus\", \"fiDataKind\", \"fiBillSource\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\") VALUES ('103', '口碑', 1, 1, 103, datetime('now'), 'admin', '管理员', '" + fsshopguid + "');");
            }*/

            //todo -- 菜品分类
            MenuclsDBModel menuclsDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenucls where fsMenuClsId = 'sys93'", MenuclsDBModel.class);
            if (menuclsDBModel == null) {
                db.execSQL("INSERT INTO tbmenucls (\"fsMenuClsId\", \"fsShopGUID\", \"fsMenuClsName\", \"fsMenuClsFullName\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMenuClsKind\", \"fiSortOrder\", \"fiStatus\", \"fiDataKind\", \"fiLevel\", \"fiDtlLvl\", \"fsMenuClsId_P\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"sync\", \"fiDataSource\", \"fiIsPrn\") VALUES ('sys93', '" + fsshopguid + "', '其他', '', '99', '99', 1, 100, 1, 1, 1, 1, '0', datetime('now'), 'admin', '管理员', 1, 1, 0);");
            } else {
                if (menuclsDBModel.fiStatus == 13) {
                    menuclsDBModel.fiStatus = 1;
                    menuclsDBModel.sync = 1;
                    menuclsDBModel.fsUpdateTime = DateUtil.getCurrentTime();
                    menuclsDBModel.replaceNoTrans();
                }
            }


            //todo -- 菜品

            MenuitemDBModel menuitem99999 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitem where fiItemCd = '99999'", MenuitemDBModel.class);
            if (menuitem99999 == null) {
                db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99999, 'sys99999', '外卖餐盒费', 'chf', '', 'sys93', 0, 0, 1, 1, 1, 1, '', 0, 2, 1, 0, 0, 0, 1, 1, 1, '', 0, 0, '', '0', '', 1261, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
            } else {
                if (menuitem99999.fiIsMulDept == 0 || menuitem99999.fiStatus == 13 || !TextUtils.equals(menuitem99999.fsItemName, "外卖餐盒费") || !TextUtils.equals(menuitem99999.fsShopGUID, fsshopguid)) {
                    menuitem99999.fsItemName = "外卖餐盒费";
                    menuitem99999.sync = 1;
                    menuitem99999.fiDataSource = 1;
                    menuitem99999.fiStatus = 1;
                    menuitem99999.fiIsMulDept = 1;
                    menuitem99999.fsShopGUID = fsshopguid;
                    menuitem99999.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem99999.replaceNoTrans();
                }
            }
            MenuItemUnitDBModel menuItemUnit99999 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99999'", MenuItemUnitDBModel.class);
            if (menuItemUnit99999 == null) {
                db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99999, 99999, '份', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
            } else {
                if (menuItemUnit99999.fiStatus == 13 || !TextUtils.equals(menuItemUnit99999.fsShopGUID, fsshopguid)) {
                    menuItemUnit99999.fiStatus = 1;
                    menuItemUnit99999.sync = 1;
                    menuItemUnit99999.fsShopGUID = fsshopguid;
                    menuItemUnit99999.fiDataSource = 1;
                    menuItemUnit99999.fsUpdateTime = DateUtil.getCurrentTime();
                    menuItemUnit99999.replaceNoTrans();
                }
            }


            MenuitemDBModel menuitem99998 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitem where fiItemCd = '99998'", MenuitemDBModel.class);
            if (menuitem99998 == null) {
                db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99998, 'sys99998', '配送费', 'psf', '', 'sys93', 0, 0, 0, 0, 0, 0, '', 0, 2, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '', '0', '', 1262, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
            } else {
                if (menuitem99998.fiIsMulDept == 0 || menuitem99998.fiStatus == 13 || !TextUtils.equals(menuitem99998.fsItemName, "配送费") || !TextUtils.equals(menuitem99998.fsShopGUID, fsshopguid)) {
                    menuitem99998.fsItemName = "配送费";
                    menuitem99998.sync = 1;
                    menuitem99998.fiStatus = 1;
                    menuitem99998.fiIsMulDept = 1;
                    menuitem99998.fiDataSource = 1;
                    menuitem99998.fsShopGUID = fsshopguid;
                    menuitem99998.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem99998.replaceNoTrans();
                }
            }
            MenuItemUnitDBModel menuItemUnit99998 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99998'", MenuItemUnitDBModel.class);
            if (menuItemUnit99998 == null) {
                db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99998, 99998, '份', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
            } else {
                if (menuItemUnit99998.fiStatus == 13 || !TextUtils.equals(menuItemUnit99998.fsShopGUID, fsshopguid)) {
                    menuItemUnit99998.fiStatus = 1;
                    menuItemUnit99998.sync = 1;
                    menuItemUnit99998.fsShopGUID = fsshopguid;
                    menuItemUnit99998.fiDataSource = 1;
                    menuItemUnit99998.fsUpdateTime = DateUtil.getCurrentTime();
                    menuItemUnit99998.replaceNoTrans();
                }
            }


            MenuitemDBModel menuitem99997 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitem where fiItemCd = '99997'", MenuitemDBModel.class);
            if (menuitem99997 == null) {
                db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99997, 'sys99997', '其他费用', 'qtfy', '', 'sys93', 0, 0, 0, 0, 0, 0, '', 0, 2, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '', '0', '', 1263, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
            } else {
                if (menuitem99997.fiIsMulDept == 0 || menuitem99997.fiStatus == 13 || !TextUtils.equals(menuitem99997.fsItemName, "其他费用") || !TextUtils.equals(menuitem99997.fsShopGUID, fsshopguid)) {
                    menuitem99997.fsItemName = "其他费用";
                    menuitem99997.sync = 1;
                    menuitem99997.fiStatus = 1;
                    menuitem99997.fiIsMulDept = 1;
                    menuitem99997.fiDataSource = 1;
                    menuitem99997.fsShopGUID = fsshopguid;
                    menuitem99997.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem99997.replaceNoTrans();
                }
            }
            MenuItemUnitDBModel menuItemUnit99997 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99997'", MenuItemUnitDBModel.class);
            if (menuItemUnit99997 == null) {
                db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99997, 99997, '个', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
            } else {
                if (menuItemUnit99997.fiStatus == 13 || !TextUtils.equals(menuItemUnit99997.fsShopGUID, fsshopguid)) {
                    menuItemUnit99997.fiStatus = 1;
                    menuItemUnit99997.sync = 1;
                    menuItemUnit99997.fsShopGUID = fsshopguid;
                    menuItemUnit99997.fiDataSource = 1;
                    menuItemUnit99997.fsUpdateTime = DateUtil.getCurrentTime();
                    menuItemUnit99997.replaceNoTrans();
                }
            }

            MenuitemDBModel menuitem99996 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitem where fiItemCd = '99996'", MenuitemDBModel.class);
            if (menuitem99996 == null) {
                db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99996, 'sys99996', '预点单餐盒费', 'yddchf', '', 'sys93', 0, 0, 0, 0, 0, 0, '', 0, 2, 1, 0, 0, 0, 0, 0, 1, '', 0, 0, '', '0', '', 1264, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 0, 0, 0);");
            } else {
                if (menuitem99996.fiIsMulDept == 0 || menuitem99996.fiStatus == 13 || !TextUtils.equals(menuitem99996.fsItemName, "预点单餐盒费") || !TextUtils.equals(menuitem99996.fsShopGUID, fsshopguid)) {
                    menuitem99996.fsItemName = "预点单餐盒费";
                    menuitem99996.sync = 1;
                    menuitem99996.fiStatus = 1;
                    menuitem99996.fiIsMulDept = 1;
                    menuitem99996.fiDataSource = 1;
                    menuitem99996.fsShopGUID = fsshopguid;
                    menuitem99996.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem99996.replaceNoTrans();
                }
            }
            MenuItemUnitDBModel menuItemUnit99996 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99996'", MenuItemUnitDBModel.class);
            if (menuItemUnit99996 == null) {
                db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99996, 99996, '个', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
            } else {
                if (menuItemUnit99996.fiStatus == 13 || !TextUtils.equals(menuItemUnit99996.fsShopGUID, fsshopguid)) {
                    menuItemUnit99996.fiStatus = 1;
                    menuItemUnit99996.sync = 1;
                    menuItemUnit99996.fiDataSource = 1;
                    menuItemUnit99996.fsShopGUID = fsshopguid;
                    menuItemUnit99996.fsUpdateTime = DateUtil.getCurrentTime();
                    menuItemUnit99996.replaceNoTrans();
                }
            }

            MenuitemDBModel menuitem99995 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitem where fiItemCd = '99995'", MenuitemDBModel.class);
            if (menuitem99995 == null) {
                db.execSQL("INSERT INTO tbmenuitem (\"fiItemCd\", \"fsItemId\", \"fsItemName\", \"fsHelpCode\", \"fsItemName2\", \"fsMenuClsId\", \"fiIsEditPrice\", \"fiIsEditQty\", \"fiIsDiscount\", \"fiIsServiceFee\", \"fiIsGift\", \"fiIsPrn\", \"fsDeptId\", \"fiIsSet\", \"fiIsSetDtlPrn\", \"fiIsOut\", \"fiIsNew\", \"fiIsSpecialty\", \"fiIsCuisine\", \"fiIsTakeAway\", \"fiIsBonus\", \"fiItemKind\", \"fsItemDesc\", \"fiImgWidth\", \"fiImgHeight\", \"fsImageURL\", \"fsImagePath\", \"fsNote\", \"fiSortOrder\", \"fsColor\", \"fiIsHot\", \"fiStatus\", \"fsCreateTime\", \"fsCreateUserId\", \"fsCreateUserName\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiIsMulDept\", \"fiItemSetCalc\", \"fiIsEffectiveDate\", \"fsStarDate\", \"fsEndDate\", \"fiMax\", \"sync\", \"fiSource\", \"fiDataSource\", \"fiSplitStatus\", \"fsExpClsId\", \"fsRevenueTypeId\", \"fiMultiPractice\", \"fiPracticeMin\", \"fiPracticeMax\", \"fiIsWechatOrder\", \"fiLedgerMode\", \"fiIsPurePay\", \"fiIsTemporaryMenu\", \"fiIsPrePoint\", \"fdLunchBoxCost\") VALUES (99995, 'sys99995', '临时菜', 'lsc', '', '98', 0, 0, 1, 1, 1, 1, '', 0, 2, 1, 0, 0, 0, 0, 1, 1, '', 0, 0, '', '0', '', 1011, '0', 0, 1, datetime('now'), 'admin', '管理员', datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, NULL, 0, NULL, NULL, 0, 1, 0, 1, 9, '99', '99', 0, 0, 0, 0, 0, 0, 1, 1, 0);");
            } else {
                if (menuitem99995.fiIsMulDept == 0 || menuitem99995.fiStatus == 13 || !TextUtils.equals(menuitem99995.fsItemName, "临时菜") || !TextUtils.equals(menuitem99995.fsShopGUID, fsshopguid)) {
                    menuitem99995.fsItemName = "临时菜";
                    menuitem99995.sync = 1;
                    menuitem99995.fiStatus = 1;
                    //todo 预制菜品必须是多部门 不然口碑后付款菜品无法打印
                    menuitem99995.fiIsMulDept = 1;
                    menuitem99995.fiDataSource = 1;
                    menuitem99995.fsShopGUID = fsshopguid;
                    menuitem99995.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem99995.replaceNoTrans();
                }
            }
            MenuItemUnitDBModel menuItemUnit99995 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemuint where fiOrderUintCd = '99995'", MenuItemUnitDBModel.class);
            if (menuItemUnit99995 == null) {
                db.execSQL("INSERT INTO tbmenuitemuint (\"fiOrderUintCd\", \"fiItemCd\", \"fsOrderUint\", \"fdSalePrice\", \"fdVIPPrice\", \"fdInvQty\", \"fiStatus\", \"fiDefault\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsShopGUID\", \"fiInitCount\", \"fdCostPrice\", \"sync\", \"fiDataSource\") VALUES (99995, 99995, '份', 1, 1, 0, 1, 1, datetime('now'), 'admin', '管理员', '" + fsshopguid + "', 1, 0, 1, 1);");
            } else {
                if (menuItemUnit99995.fiStatus == 13 || !TextUtils.equals(menuItemUnit99995.fsShopGUID, fsshopguid)) {
                    menuItemUnit99995.fiStatus = 1;
                    menuItemUnit99995.sync = 1;
                    menuItemUnit99995.fiDataSource = 1;
                    menuItemUnit99995.fsUpdateTime = DateUtil.getCurrentTime();
                    menuItemUnit99995.replaceNoTrans();
                }
            }

            //todo -- 系统参数关联
            ParamvalueDBModel paramvalue337 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId = '337'", ParamvalueDBModel.class);
            if (paramvalue337 == null) {
                db.execSQL("INSERT INTO tbparamvalue (\"fsParamId\", \"fsShopGUID\", \"fsParamValue\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsStr1\", \"fsStr2\", \"fsStr3\", \"fsStr4\", \"fsStr5\", \"fiInt1\", \"fiInt2\", \"fiInt3\", \"fiInt4\", \"fiInt5\", \"lver\", \"pver\", \"iupcount\", \"sync\", \"fiDataSource\") VALUES ('337', '" + fsshopguid + "', '99999', datetime('now'), 'admin', 'winpos', '99999', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1);");
            }
            ParamvalueDBModel paramvalue338 = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId = '338'", ParamvalueDBModel.class);
            if (paramvalue338 == null) {
                db.execSQL("INSERT INTO tbparamvalue (\"fsParamId\", \"fsShopGUID\", \"fsParamValue\", \"fsUpdateTime\", \"fsUpdateUserId\", \"fsUpdateUserName\", \"fsStr1\", \"fsStr2\", \"fsStr3\", \"fsStr4\", \"fsStr5\", \"fiInt1\", \"fiInt2\", \"fiInt3\", \"fiInt4\", \"fiInt5\", \"lver\", \"pver\", \"iupcount\", \"sync\", \"fiDataSource\") VALUES ('338', '" + fsshopguid + "', '99998', datetime('now'), 'admin', 'winpos', '99998', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1);");
            }
            // 修复tbSellOrderItem报表数据 如果有错误数据则进行修复
            String num = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbSellOrderItem  where fsshopguid !=  '" + fsshopguid + "'");
            if (StringUtil.toInt(num, 0) > 0) {
                db.execSQL("update tbSellOrderItem set lver='2', pver='1', fsshopguid = '" + fsshopguid + "'  where fsshopguid !=  '" + fsshopguid + "'");
            }
            return true;
        });


    }


}
