package com.mwee.android.pos.businesscenter.framework;

import android.text.TextUtils;

import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.component.datasync.net.TableQRBiznessModel;
import com.mwee.android.pos.connect.table.TableQRBizUtil;
import com.mwee.android.pos.connect.callback.IResponse;

/**
 * 桌台二维码的工厂类
 * Created by liuxiuxiu on 2017/8/3.
 * @author liuxiuxiu
 */
public class TableQRProcess {

    /**
     * 检查秒付码是否失效
     *
     * @param tableId
     */
    public static void checkTableQRSortLink(final String tableId) {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                TableQRBiznessModel tableQRBiznessModel = ServerCache.getInstance().optTableQR(tableId);
                if (tableQRBiznessModel == null) {
                    tableQRBiznessModel = TableQRBizUtil.createTableQRBiznessModel(tableId);
                    ServerCache.getInstance().putTableQR(tableId, tableQRBiznessModel);
                }

                //秒付码过期或者短链接无效
                if (tableQRBiznessModel != null && (!tableQRBiznessModel.checkTableQRUseful() || TextUtils.isEmpty(tableQRBiznessModel.urlSortLink))) {
                    tableQRBiznessModel.generateNewRapidQR();
                    final TableQRBiznessModel finalTableQRBiznessModel = tableQRBiznessModel;
                    TableQRBizUtil.requestTableQRShortLink(tableQRBiznessModel.rapidQR, new IResponse<String>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, String info) {
                            if (result) {
                                finalTableQRBiznessModel.urlSortLink = info;
                                ServerCache.getInstance().putTableQR(tableId, finalTableQRBiznessModel);
                            }
                        }
                    });
                }
                return null;
            }
        });
    }

    /**
     * 取桌台二维码
     *
     * @param fsMTableId 桌台ID
     * @return String
     */
    public static String optTableQR(String fsMTableId) {
        String tableQR = "";
        TableQRBiznessModel tableQRBiznessModel = ServerCache.getInstance().optTableQR(fsMTableId);
        if (tableQRBiznessModel == null) {
            tableQRBiznessModel = TableQRBizUtil.createTableQRBiznessModel(fsMTableId);
        }
        if (tableQRBiznessModel != null) {
            if (tableQRBiznessModel.checkTableQRUseful()) {
                if (TextUtils.isEmpty(tableQRBiznessModel.urlSortLink)) {
                    if (TextUtils.isEmpty(tableQRBiznessModel.rapidQR)) {
                        tableQRBiznessModel.generateNewRapidQR();
                    }
                    tableQR = tableQRBiznessModel.rapidQR;
                } else {
                    tableQR = tableQRBiznessModel.urlSortLink;
                }
            } else {
                tableQR = tableQRBiznessModel.generateNewRapidQR();
            }
        }
        return tableQR;
    }
}
