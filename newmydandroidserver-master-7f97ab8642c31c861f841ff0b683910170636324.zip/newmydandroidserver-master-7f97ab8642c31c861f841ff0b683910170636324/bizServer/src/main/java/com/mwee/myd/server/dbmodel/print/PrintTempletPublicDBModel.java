package com.mwee.myd.server.dbmodel.print;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;

/**
 * 小票打印模版，基础模版
 *
 * @author virgil
 */
@TableInf(name = "tbPrintTempletPublic")
public class PrintTempletPublicDBModel extends DBModel {
    @ColumnInf(name = "fsTempletId")
    public String fsTempletId = "";
    @ColumnInf(name = "fsTempletKey")
    public String fsTempletKey = "";
    @ColumnInf(name = "fsTempletName")
    public String fsTempletName = "";
    @ColumnInf(name = "fsTempletFile")
    public String fsTempletFile = "";
    @ColumnInf(name = "fsShopGUID")
    public String fsShopGUID = "";
    @ColumnInf(name = "fsTempletData")
    public String fsTempletData = "";
    @ColumnInf(name = "fsNote")
    public String fsNote = "";
    @ColumnInf(name = "fiStatus")
    public int fiStatus = 1;

    @ColumnInf(name = "fsCreateTime")
    public String fsCreateTime = "";
    @ColumnInf(name = "fsCreateUserId")
    public String fsCreateUserId = "";
    @ColumnInf(name = "fsCreateUserName")
    public String fsCreateUserName = "";
    @ColumnInf(name = "fsUpdateTime")
    public String fsUpdateTime = "";
    @ColumnInf(name = "fsUpdateUserId")
    public String fsUpdateUserId = "";
    @ColumnInf(name = "fsUpdateUserName")
    public String fsUpdateUserName = "";

    /**
     * 模版类型：0：美易点，1：美小易，2：美收银
     */
    @ColumnInf(name = "fiTempletType")
    public int fiTempletType;

    /**
     * 模版最低支持版本
     */
    @ColumnInf(name = "fiMinSupportVersion")
    public int fiMinSupportVersion;

    public PrintTempletPublicDBModel() {

    }

    @Override
    public PrintTempletPublicDBModel clone() {
        PrintTempletPublicDBModel cloneObj = null;
        try {
            cloneObj = (PrintTempletPublicDBModel) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cloneObj;
    }
}
