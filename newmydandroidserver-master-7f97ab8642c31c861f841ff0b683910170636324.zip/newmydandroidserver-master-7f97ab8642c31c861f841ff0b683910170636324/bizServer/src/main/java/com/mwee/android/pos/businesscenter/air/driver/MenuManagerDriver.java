package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.menu.AllMenuClsAndMenuItemResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAddResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAndMenuItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuClsAndMenuPackagesResponse;
import com.mwee.android.air.connect.business.menu.MenuClsPrintersResponse;
import com.mwee.android.air.connect.business.menu.MenuClsToTopResponse;
import com.mwee.android.air.connect.business.menu.MenuDishAddResponse;
import com.mwee.android.air.connect.business.menu.MenuEditorResponse;
import com.mwee.android.air.connect.business.menu.MenuItemAddResponse;
import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.air.connect.business.menu.MenuItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageItemsResponse;
import com.mwee.android.air.connect.business.menu.MenuPackageSetSideResponse;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuClsSortBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuItemUnitBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.IDHelper;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuClsDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuClsMuldeptDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuPackageSetSideDBUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.MetaDBController;
import com.mwee.android.pos.businesscenter.module.koubei.IAirMenuService;
import com.mwee.android.pos.businesscenter.module.menu.AirMenuService;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrinterSource;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.takeout.MenuImportItemListRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportResultRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportResultResponse;
import com.mwee.android.pos.component.takeout.TakeOutMenuItem;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuImportResponse;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemListAllRequest;
import com.mwee.android.pos.component.takeout.TakeOutMenuItemListAllResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public class MenuManagerDriver implements IDriver {
    public static final String DRIVER_TAG = "menuManager";


    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsList")
    public SocketResponse loadMenuClsList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            AllMenuClsAndMenuItemResponse response = new AllMenuClsAndMenuItemResponse();
            socketResponse.data = response;
            response.menuClsBeanList = MenuClsDBUtils.queryAll();
            Boolean isLoadAllMenuItem = request.getBoolean("isLoadAllMenuItem");
            if (isLoadAllMenuItem) {
                response.menuItemBeanList = MenuItemDBUtils.queryMenusByClsId(null);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 美小易菜品管理首页数据
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadAirMenuManager")
    public SocketResponse loadAirMenuManager(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            Boolean isLoadAllMenuItem = request.getBoolean("isLoadAllMenuItem");
            Boolean isContainSet = request.getBoolean("isContainSet");
            IAirMenuService iAirMenuService = new AirMenuService();
            socketResponse.data = iAirMenuService.loadAirMenuManager(isLoadAllMenuItem, isContainSet);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 美小易根据菜品分类id获取菜品列表
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadAirMenuItemByClsId")
    public SocketResponse loadAirMenuItemByClsId(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsMenuClsId = request.getString("fsMenuClsId");
            IAirMenuService airMenuService = new AirMenuService();
            socketResponse.data = airMenuService.loadAirMenuItemByClsId(fsMenuClsId);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuItemBean")
    public SocketResponse loadMenuItemBean(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            IAirMenuService airMenuService = new AirMenuService();
            socketResponse.data = airMenuService.loadAirMenuItemBeanById(fiItemCd);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    /**
     * 美小易新增菜品
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadAddMenuItem")
    public SocketResponse loadAddMenuItem(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuItemEditorBody menuItemEditorBody = request.getObject("menuItemEditorBody", MenuItemEditorBody.class);
            IAirMenuService airMenuService = new AirMenuService();
            MenuDishAddResponse response = airMenuService.loadAddMenuItem(menuItemEditorBody);
            if (response.menuitemDBModel != null) {
                NotifyToClient.refreshSellOut();//刷新沽清数量
                socketResponse.data = response;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "新增成功";
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "新增失败，请重试";
            }
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 美小易修改菜品
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadUpdateMenuItem")
    public SocketResponse loadUpdateMenuItem(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            MenuItemEditorBody menuItemEditorBody = request.getObject("menuItemEditorBody", MenuItemEditorBody.class);

            List<String> unitIds = new ArrayList<>();
            for (int i = 0; i < menuItemEditorBody.menuItemUnitBeans.size(); i++) {
                MenuItemUnitBean unit = menuItemEditorBody.menuItemUnitBeans.get(i);
                if (unit.editor_mode == MenuItemUnitBean.MODE_DELETE) {
                    unitIds.add(unit.fiOrderUintCd);
                }
            }
            //check 删除的规格是否被套餐占用
            String message = MenuItemDBUtils.associatePackageUnitMessage(unitIds);
            if (TextUtils.isEmpty(message)) {
                IAirMenuService airMenuService = new AirMenuService();
                MenuEditorResponse response = airMenuService.loadUpdateMenuItem(fiItemCd, menuItemEditorBody);
                socketResponse.data = response;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "修改成功";
            } else {
                socketResponse.message = message;
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            }
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }


    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuManagerIndex")
    public SocketResponse loadMenuManagerIndex(SocketHeader head, String param) {
        //美收银菜品管理首页
        SocketResponse socketResponse = new SocketResponse();
        try {
            MenuClsAndMenuPackagesResponse response = new MenuClsAndMenuPackagesResponse();
            socketResponse.data = response;
            response.menuClsBeanList = MenuClsDBUtils.queryAll();
            //获取所有套餐菜品
            if (MenuItemDBUtils.hasMenuPackage()) {
                MenuClsBean menuClsBean = new MenuClsBean();
                menuClsBean.fsMenuClsId = "-10086";
                menuClsBean.fsMenuClsName = "套餐";
                response.menuClsBeanList.add(0, menuClsBean);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 美收银排序前数据展示
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadAllMenuClsAndMenuItems")
    public SocketResponse loadAllMenuClsAndMenuItems(SocketHeader head, String param) {
        //美收银菜品管理首页排序所需数据
        SocketResponse socketResponse = new SocketResponse();
        try {
            MenuClsAndMenuItemsResponse response = new MenuClsAndMenuItemsResponse();
            socketResponse.data = response;
            response.menuClsBeanList = MenuClsDBUtils.queryClzAndMenuItems();
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuItemSort")
    public SocketResponse loadMenuItemSort(SocketHeader head, String param) {
        //美收银菜品管理首页排序所需数据
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            List<MenuClsSortBean> menuClsSortBeans = JSONArray.parseArray(request.getString("menuClsSortBeans"), MenuClsSortBean.class);
            MenuItemDBUtils.doMenuItemSort(menuClsSortBeans);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsSort")
    public SocketResponse loadMenuClsSort(SocketHeader head, String param) {
        //美收银菜品管理首页排序所需数据
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            List<MenuClsBean> menuClsBeans = JSONArray.parseArray(request.getString("menuClsBeans"), MenuClsBean.class);
            MenuClsDBUtils.doMenuClsSort(menuClsBeans);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuItemByClsId")
    public SocketResponse loadMenuItemByClsId(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuItemsResponse response = new MenuItemsResponse();
            socketResponse.data = response;
            String fsMenuClsId = request.getString("fsMenuClsId");
            //美收银套餐id
            if (fsMenuClsId != null && fsMenuClsId.equals("-10086")) {
                response.menuItemBeanList = MenuItemDBUtils.queryMenuPackagesForMsy(true);
            } else {
                response.menuItemBeanList = MenuItemDBUtils.queryMenusByClsId(fsMenuClsId);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 修改菜品分类
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsUpdate")
    public SocketResponse loadMenuClsUpdate(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuClsBean menuClsBean = request.getObject("menuClsBean", MenuClsBean.class);
            MenuClsDBUtils.update(menuClsBean.fsMenuClsId, menuClsBean.fsMenuClsName);
            //解除菜品分类关联打印机
            MenuClsMuldeptDBUtils.unAssociateMenuCls(menuClsBean.fsMenuClsId);
            //添加菜品分类关联打印机
            MenuClsMuldeptDBUtils.associateMenuCls(menuClsBean.fsMenuClsId, menuClsBean.printerNames, HostUtil.getUserModelBySession(head.us));
            MetaDBController.updateSyncTime();
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 菜品分类批量关联打印机
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/menuClsBatchAssociatedPrinter")
    public SocketResponse menuClsBatchAssociatedPrinter(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            if (!TextUtils.isEmpty(request.getString("menuClsList"))) {
                List<MenuClsBean> originMenuList = JSON.parseArray(request.getString("menuClsList"), MenuClsBean.class);

                for (MenuClsBean menuClsBean : originMenuList) {
                    //添加菜品分类关联打印机
                    MenuClsMuldeptDBUtils.associateMenuCls(menuClsBean.fsMenuClsId, menuClsBean.printerNames, HostUtil.getUserModelBySession(head.us));
                    MetaDBController.updateSyncTime();
                }
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "修改成功";
            }

        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "关联失败，请稍后重试！";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsPrinters")
    public SocketResponse loadMenuClsPrinters(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsMenuClsId = request.getString("fsMenuClsId");
            MenuClsPrintersResponse response = new MenuClsPrintersResponse();
            socketResponse.data = response;
//            response.allPrinters = TPrinterUtils.queryAllUsePrinter();
            response.allPrinters = (ArrayList<PrinterItem>) new PrinterSource().queryDeptPrinters();
            if (!TextUtils.isEmpty(fsMenuClsId)) {
                response.choicePrinters = MenuClsMuldeptDBUtils.queryPrinterNamesBy(fsMenuClsId);
            }
            MetaDBController.updateSyncTime();
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsAdd")
    public SocketResponse loadMenuClsAdd(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsMenuClsName = request.getString("fsMenuClsName");
            ArrayList<String> printerNames = (ArrayList<String>) JSONArray.parseArray(request.getString("printerNames"), String.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            String id = IDHelper.generateMenuClsId();
            MenuClsDBUtils.insert(id, fsMenuClsName, 1, head.shopid, userDBModel);
            //添加菜品分类关联打印机
            MenuClsMuldeptDBUtils.associateMenuCls(id, printerNames, HostUtil.getUserModelBySession(head.us));

            MetaDBController.updateSyncTime();
            MenuClsAddResponse response = new MenuClsAddResponse();
            response.menuClsId = id;
            response.name = fsMenuClsName;
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "添加成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsDelete")
    public SocketResponse loadMenuClsDelete(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsMenuClsId = request.getString("fsMenuClsId");
            int count = MenuItemDBUtils.queryCountByClsId(fsMenuClsId);
            if (count > 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请先删除分类下所有菜品";
            } else {
                MenuClsDBUtils.deleteById(fsMenuClsId);
                MetaDBController.updateSyncTime();
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "删除成功";
            }
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadUpdateMenuInfo")
    public SocketResponse loadUpdateMenuInfo(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            MenuItemEditorBody menuItemEditorBody = request.getObject("menuItemEditorBody", MenuItemEditorBody.class);
            MenuItemDBUtils.updateMenuItemAndUnit(fiItemCd, menuItemEditorBody);
            NotifyToClient.refreshSellOut();//刷新沽清数量
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadAddMenuInfo")
    public SocketResponse loadAddMenuInfo(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuItemEditorBody menuItemEditorBody = request.getObject("menuItemEditorBody", MenuItemEditorBody.class);
            String fiItemCd = MenuItemDBUtils.addMenuItem(menuItemEditorBody, head.shopid);
            MenuItemAddResponse response = new MenuItemAddResponse();
            response.menuItem = MenuItemDBUtils.queryMenuItemById(fiItemCd);
            if (response.menuItem != null) {
                NotifyToClient.refreshSellOut();//刷新沽清数量
                socketResponse.data = response;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "新增成功";
            } else {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "新增失败，请重试";
                RunTimeLog.addLog(RunTimeLog.MENU_ITEM_ADD, "获取菜品信息失败 fiItemcd=" + fiItemCd);
            }

        } catch (Exception e) {
            e.printStackTrace();
            RunTimeLog.addLog(RunTimeLog.MENU_ITEM_ADD, e.getMessage());
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadBatchDeleteMenuItems")
    public SocketResponse loadBatchDeleteMenuItems(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            List<String> deleteMenuIds = JSON.parseArray(request.getJSONArray("deleteMenuIds").toJSONString(), String.class);
            String message = MenuItemDBUtils.associatePackageMessage(deleteMenuIds);
            if (message.length() > 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "该菜品在套餐 " + message + " 已添加，请先在套餐中删除关联";
            } else {
                MenuItemDBUtils.deleteMenus(deleteMenuIds);
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "删除成功";
            }

        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }


    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuPackageItems")
    public SocketResponse loadMenuPackageItems(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuPackageItemsResponse response = new MenuPackageItemsResponse();
            socketResponse.data = response;
            response.menuItemBeanList = MenuItemDBUtils.queryMenuPackages();
            Boolean isLoadFirstDetailInfo = request.getBoolean("isLoadFirstDetailInfo");
            if (isLoadFirstDetailInfo && !ListUtil.isEmpty(response.menuItemBeanList)) {
                response.menuPackageSetSideBeanList = MenuPackageSetSideDBUtils.queryMenuPackageSetSidesByMenuId(response.menuItemBeanList.get(0).fiItemCd);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuPackageSetSidesByMenuId")
    public SocketResponse loadMenuPackageSetSidesByMenuId(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuPackageSetSideResponse response = new MenuPackageSetSideResponse();
            socketResponse.data = response;
            String fiItemCd = request.getString("fiItemCd");
            response.menuPackageSetSideBeanList = MenuPackageSetSideDBUtils.queryMenuPackageSetSidesByMenuId(fiItemCd);
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadUpdatePackageMenu")
    public SocketResponse loadUpdatePackageMenu(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            String name = request.getString("name");
            String price = request.getString("price");
            String vipPrice = request.getString("vipPrice");
            int fiIsPrePoint = request.getInteger("fiIsPrePoint");
            BigDecimal fdLunchBoxCost = request.getBigDecimal("fdLunchBoxCost");
            List<MenuPackageSetSideBean> menuPackageSetSideBeanList = JSONArray.parseArray(request.getString("beans"), MenuPackageSetSideBean.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            MenuItemDBUtils.updateMenuPackage(fiItemCd, name, price, vipPrice, fiIsPrePoint, fdLunchBoxCost, menuPackageSetSideBeanList, head.shopid, userDBModel);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "修改成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadAddMenuPackage")
    public SocketResponse loadAddMenuPackage(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String name = request.getString("name");
            String price = request.getString("price");
            String vipPrice = request.getString("vipPrice");
            int fiIsPrePoint = request.getInteger("fiIsPrePoint");
            BigDecimal fdLunchBoxCost = request.getBigDecimal("fdLunchBoxCost");
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            MenuItemDBUtils.addMenuPackage(name, price, vipPrice, fiIsPrePoint, fdLunchBoxCost, head.shopid, userDBModel);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "添加成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadAddMenuPackageBean")
    public SocketResponse loadAddMenuPackageBean(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MenuItemBean menuPackageBean = request.getObject("menuPackageBean", MenuItemBean.class);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            MenuItemDBUtils.addMenuPackage(menuPackageBean, head.shopid, userDBModel);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "添加成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadDeleteMenuItemSetSide")
    public SocketResponse loadDeleteMenuItemSetSide(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiSetFoodCd = request.getString("fiSetFoodCd");
            MenuPackageSetSideDBUtils.deleteMenuItemSetSide(fiSetFoodCd);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "删除成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = DRIVER_TAG + "/loadDeletePackageMenuItem")
    public SocketResponse loadDeletePackageMenuItem(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            MenuItemDBUtils.deleteMenuPackage(fiItemCd);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "删除成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 菜品分类置顶
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuClsToTop")
    public SocketResponse loadMenuClsToTop(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fsMenuClsId = request.getString("fsMenuClsId");
            MenuClsToTopResponse response = new MenuClsToTopResponse();
            socketResponse.data = response;
            MenuClsDBUtils.doMenuClsToTop(fsMenuClsId);
            response.menuClsBeenList = MenuClsDBUtils.queryAll();
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "置顶成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 菜品置顶
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadMenuItemToTop")
    public SocketResponse loadMenuItemToTop(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String fiItemCd = request.getString("fiItemCd");
            MenuItemDBUtils.doMenuItemToTop(fiItemCd);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "置顶成功";
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    /**
     * 校验第三方菜品是否已存在本地
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/importMenuItem")
    public SocketResponse importMenuItem(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }

        SocketResponse socketResponse = new SocketResponse();
        MenuImportItemListRequest listRequest = new MenuImportItemListRequest();
//        TakeOutMenuImportResponse response = new TakeOutMenuImportResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            List<TakeOutMenuItem> item = JSONArray.parseArray(request.getString("items"), TakeOutMenuItem.class);
            listRequest.items.addAll(item);
            BusinessExecutor.execute(listRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutMenuImportResponse) {
                        TakeOutMenuImportResponse response = ((TakeOutMenuImportResponse) responseData.responseBean);
                        socketResponse.code = SocketResultCode.SUCCESS;
                        socketResponse.data = response;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.responseBean.errmsg;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.EXCEPTION;
                    socketResponse.message = responseData.resultMessage;
                    return false;/**/
                }
            }, false);


        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 一键添加外卖菜品到本地并自动关联
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/importTakeOutMenu")
    public SocketResponse importTakeOutMenu(SocketHeader head, String param) {
        SocketResponse<TakeOutMenuImportResponse> socketResponse = new SocketResponse();

        JSONObject paramsObject = JSON.parseObject(param);
        String source = paramsObject.getString("source");
        List<TakeOutMenuItem> item = JSONArray.parseArray(paramsObject.getString("items"), TakeOutMenuItem.class);
        TakeOutMenuImportRequest request = new TakeOutMenuImportRequest();
        request.items.addAll(item);

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutMenuImportResponse) {
                    TakeOutMenuImportResponse response = (TakeOutMenuImportResponse) responseData.responseBean;
                    socketResponse.data = response;
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.responseBean.errmsg;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, false);
        return socketResponse;
    }

    /**
     * 轮询一键导入菜品是否成功
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loopMenuImportResult")
    public SocketResponse loopMenuImportResult(SocketHeader head, String param) {
        SocketResponse<TakeOutMenuImportResultResponse> socketResponse = new SocketResponse();

        JSONObject paramsObject = JSON.parseObject(param);
        String source = paramsObject.getString("takeawaySource");
        TakeOutMenuImportResultRequest request = new TakeOutMenuImportResultRequest();
        request.takeawaySource = source;

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutMenuImportResultResponse) {
                    TakeOutMenuImportResultResponse response = (TakeOutMenuImportResultResponse) responseData.responseBean;
                    socketResponse.data = response;
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.responseBean.errmsg;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, false);
        return socketResponse;
    }

    /**
     * 小易建店初始化外卖菜品导入列表
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/getExportMenuList")
    public SocketResponse loadTakeOutMenuListAll(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        JSONObject paramsObject = JSON.parseObject(param);

        BusinessExecutor.execute(new TakeOutMenuItemListAllRequest(), new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof TakeOutMenuItemListAllResponse) {
                    TakeOutMenuItemListAllResponse response = (TakeOutMenuItemListAllResponse) responseData.responseBean;
                    socketResponse.data = response;
                    socketResponse.code = SocketResultCode.SUCCESS;
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.responseBean.errmsg;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.EXCEPTION;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, false);
        return socketResponse;
    }

    /**
     * 小易加载所有未关联打印机的菜品分类
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = DRIVER_TAG + "/loadAirOnPrinterMenuCls")
    public SocketResponse loadAllOnPrinterMenuCls(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            AllMenuClsAndMenuItemResponse response = new AllMenuClsAndMenuItemResponse();
            List<MenuClsBean> onPrinterMenuClsList = new ArrayList<>();
            List<MenuClsBean> menuClsList = MenuClsDBUtils.queryAllContainSet();//获取所有的菜品分类
            if (!ListUtil.isEmpty(menuClsList)) {
                for (MenuClsBean menuClsBean : menuClsList) {
                    ArrayList<String> menuClsMuldeptList = MenuClsMuldeptDBUtils.queryPrinterNamesBy(menuClsBean.fsMenuClsId);
                    if (ListUtil.isEmpty(menuClsMuldeptList)) {
                        onPrinterMenuClsList.add(menuClsBean);
                    }
                }
            }
            response.menuClsBeanList = onPrinterMenuClsList;
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    @Override
    public String getModuleName() {
        return DRIVER_TAG;
    }
}
