package com.mwee.android.pos.businesscenter.business.koubei;

import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

/**
 * Created by zhangmin on 2018/5/18.
 */

public class KBPreCacheModelUtils {


    /**
     * 记录 口碑预点单 错误订单信息
     * @param thirdOrderId
     */
    public static void insert(String thirdOrderId,int count,String fsSellNo) {

        CacheModel cacheModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from datacache where key = '" + thirdOrderId + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "'", CacheModel.class);
        if (cacheModel == null) {
            cacheModel = new CacheModel();
            cacheModel.key = thirdOrderId;
            cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        }
        cacheModel.info = fsSellNo;
        cacheModel.value = String.valueOf(count);
        cacheModel.type = IOCache.TYPE_THIRD_ORDER_UNMAPPING;
        cacheModel.updatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.replaceNoTrans();

    }


    /**
     * 删除 口碑预点单 错误订单信息  TempAppOrder中的order_id 相当于
     * @param
     */
    public static void delete(String order_id) {

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where key = '" + order_id + "' and type = '" + IOCache.TYPE_THIRD_ORDER_UNMAPPING + "'");
    }


    public static void update() {

    }

    public static void query() {


    }


}
