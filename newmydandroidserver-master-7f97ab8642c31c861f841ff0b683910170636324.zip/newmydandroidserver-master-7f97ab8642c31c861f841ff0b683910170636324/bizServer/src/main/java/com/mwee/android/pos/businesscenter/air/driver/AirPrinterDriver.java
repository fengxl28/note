package com.mwee.android.pos.businesscenter.air.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.air.dbUtil.TPrinterUtils;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.GetAllPrinterResponse;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.List;

/**
 * Created by zhangmin on 2017/10/18.
 */

public class AirPrinterDriver implements IDriver {

    private static final String TAG = "airPrinter";

    @Override
    public String getModuleName() {
        return TAG;
    }


    @DrivenMethod(uri = TAG + "/replaceTDeptItemCut")
    public SocketResponse replaceTDeptItemCut(SocketHeader head, String param) {

        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            int fiIsOneItemCut = request.getObject("fiIsOneItemCut", Integer.class);
            TPrinterUtils.updateTDeptItemCut(fiIsOneItemCut, userDBModel);

            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAllPrinter")
    public SocketResponse loadAllPrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            List<PrinterDBModel> allPrinters = TPrinterUtils.queryAll();
            GetAllPrinterResponse allPrinterResponse = new GetAllPrinterResponse();
            if (!ListUtil.isEmpty(allPrinters)) {
                allPrinterResponse.printerItems = TPrinterUtils.build(head.hd, allPrinters);
            }
            response.data = allPrinterResponse;
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadAddPrinter")
    public SocketResponse loadAddPrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSONObject.parseObject(param);
        PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
        if (printerItem == null) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "非法请求";
            return response;
        }
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            PrinterDBModel old = TPrinterUtils.queryAllPrinterByName(printerItem.name);
            if (old == null) {
                TPrinterUtils.addPrinter(printerItem, head.hd, userDBModel);
                response.code = SocketResultCode.SUCCESS;
                response.message = "成功";
            } else if (old.fiStatus == 1) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印机[" + printerItem.name + "] 已存在";
            } else if (old.fiStatus == 13) {
                //打印被删除 恢复操作
                old.fiStatus = 1;
                old.replaceNoTrans();
                printerItem.id = old.fiID;
                TPrinterUtils.updatePrinter(printerItem, head.hd, userDBModel);
                response.code = SocketResultCode.SUCCESS;
                response.message = "成功";
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadUpdatePrinter")
    public SocketResponse loadUpdatePrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSONObject.parseObject(param);
        PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
        if (printerItem == null) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "非法请求";
            return response;
        }
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            PrinterDBModel printerDBModel = TPrinterUtils.queryById(printerItem.id);
            if (printerDBModel == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印机[" + printerItem.name + "] 不存在，修改失败";
                return response;
            }
            if (!TextUtils.equals(printerDBModel.fsPrinterName, printerItem.name) && TPrinterUtils.queryAllPrinterByName(printerItem.name) != null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印机[" + printerItem.name + "] 已存在，修改失败";
                return response;
            }
            TPrinterUtils.updatePrinter(printerItem, head.hd, userDBModel);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/loadDeletePrinter")
    public SocketResponse loadDeletePrinter(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int id = request.getInteger("id");
            if (TPrinterUtils.queryById(id) == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "你要删除的打印机不存在！";
                return response;
            }
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            TPrinterUtils.delete(id, userDBModel);
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadCloudPrinterActive")
    public SocketResponse loadPrinterActive(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSONObject.parseObject(param);
        PrinterItem printerItem = request.getObject("printerItem", PrinterItem.class);
        if (printerItem == null || printerItem.type != PrinterType.CLOUD) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "非法请求";
            return response;
        }
        String sql = "select * from tbPrinter where fiStatus = '1' AND fsPrinterSN = '" + printerItem.fsPrinterSN + "'";
        PrinterDBModel old = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
        if (old == null) {
            response.code = SocketResultCode.SUCCESS;
            response.message = "成功";
        } else {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "打印机[" + printerItem.name + "] 已存在";
            return response;
        }
        return response;
    }
}
