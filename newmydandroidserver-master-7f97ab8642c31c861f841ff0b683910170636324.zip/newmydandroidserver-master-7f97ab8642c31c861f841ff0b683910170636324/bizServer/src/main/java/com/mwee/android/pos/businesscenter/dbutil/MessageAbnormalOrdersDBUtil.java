package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MessageDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderDetailBean;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderHeadBean;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import com.alibaba.fastjson.JSONObject;

import org.json.JSONArray;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lxx on 18/5/23.
 * 业务中心 异常订单DBUtil
 */

public class MessageAbnormalOrdersDBUtil {

    /**
     * 查询点餐相关的消息
     *
     * @param businessDate
     * @return
     */
    public static List<MessageAbnormalOrderHeadBean> optAbnormalOrderList(int pageIndex, int messageConuntOnePage, String businessDate) {
        if (messageConuntOnePage <= 0) {
            messageConuntOnePage = 10;
        }
        if (pageIndex < 0) {
            pageIndex = 0;
        }
        String paramSql = "";
//        if (!TextUtils.isEmpty(businessDate)) {
//            paramSql = " and businessDate = '" + businessDate + "' ";
//        }
        String sql = "select * from message  where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' " + paramSql + " order by createTime desc limit " + (pageIndex * messageConuntOnePage) + "," + messageConuntOnePage;
        List<MessageAbnormalOrderHeadBean> messageAbnormalOrderHeadBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageAbnormalOrderHeadBean.class);
        if (messageAbnormalOrderHeadBeanList == null || messageAbnormalOrderHeadBeanList.isEmpty()) {
            messageAbnormalOrderHeadBeanList = new ArrayList<>();
        }
        return messageAbnormalOrderHeadBeanList;
    }

    /**
     * 查询点餐相关的消息
     *
     * @param msgId
     * @return
     */
    public static MessageAbnormalOrderDetailBean optAbnormalOrderDetail(String msgId) {
        String sql = "select * from message  where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageAbnormalOrderDetailBean.class);
    }

    /**
     * 未处理消息数量
     *
     * @return
     */
    public static int optUndealCount() {
        String sql = "select count(*) from " + DBModel.getTableName(MessageDBModel.class) + " where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and businessStatus = " + MessageConstance.MessageAbnormalOrderStatus.NONE + " order by createTime desc ";
        String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return StringUtil.toInt(countStr, 0);
    }

    /**
     * 查询点餐相关的消息
     *
     * @param msgId
     * @return
     */
    public static MessageAbnormalOrderHeadBean optAbnormalOrderHeadDetail(String msgId) {
        String sql = "select * from message  where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MessageAbnormalOrderHeadBean.class);
    }

    /**
     * 忽略
     *
     * @param msgId
     * @return
     */
    public static String ignoreOrder(String msgId, String hostId, UserDBModel userDBModel) {
        MessageAbnormalOrderHeadBean messageAbnormalOrderHeadBean = optAbnormalOrderHeadDetail(msgId);
        if (messageAbnormalOrderHeadBean != null) {
            if (messageAbnormalOrderHeadBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.NONE) {
                String standBy1 = optOrperation(messageAbnormalOrderHeadBean.standBy1, hostId, userDBModel, "忽略订单");

                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update message set dealStatus = '1',standBy1 = '" + standBy1 + "', updateTime ='" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "',updateUser = '" + userDBModel.fsUserName + "', businessStatus = '" + MessageConstance.MessageAbnormalOrderStatus.IGNORE + "' where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'");
                return "";
            } else {
                return "订单已被操作";
            }
        }
        return "操作失败";
    }

    /**
     * 记录异常订单的操作人
     *
     * @param standBy1
     * @param hostId
     * @param userDBModel
     * @return
     */
    public static String optOrperation(String standBy1, String hostId, UserDBModel userDBModel, String businessStatus) {
        try {
            Map<String, String> params;
            if (TextUtils.isEmpty(standBy1)) {
                params = new HashMap<>();
            } else {
                params = JSON.parseObject(standBy1, Map.class);
            }
            if (params != null) {
                String values = params.get("operation");
                StringBuilder stringBuilder = new StringBuilder();
                if (!TextUtils.isEmpty(values)) {
                    stringBuilder.append(values).append("\n");
                }
                String userName = "未知";
                if (userDBModel != null) {
                    userName = userDBModel.fsUserName;
                }

                stringBuilder.append("服务员[")
                        .append(userName)
                        .append("]在[")
                        .append(hostId)
                        .append("]站点,于")
                        .append(DateUtil.getCurrentDate("yyyy年MM月dd日 HH时mm分ss秒"))
                        .append(" 操作：")
                        .append(businessStatus);

                params.put("operation", stringBuilder.toString());
                standBy1 = JSON.toJSONString(params);
            }
        } catch (Exception e) {
            LogUtil.logError("记录异常订单操作人信息时异常 standBy1 = " + standBy1, e);
        }

        return standBy1;
    }


    /**
     * 关联桌台
     *
     * @param msgId
     * @return
     */
    public static String bindOrder(String msgId, String sellno, String hostId, UserDBModel userDBModel) {
        MessageAbnormalOrderHeadBean messageAbnormalOrderHeadBean = optAbnormalOrderHeadDetail(msgId);
        if (messageAbnormalOrderHeadBean != null) {
            if (messageAbnormalOrderHeadBean.businessStatus != MessageConstance.MessageAbnormalOrderStatus.VOID) {
                String standBy1 = optOrperation(messageAbnormalOrderHeadBean.standBy1, hostId, userDBModel, "绑定订单, 订单号：" + sellno);

                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update message set dealStatus = '1',standBy1 = '" + standBy1 + "', updateTime ='" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "',updateUser = '" + userDBModel.fsUserName + "', businessStatus = '" + MessageConstance.MessageAbnormalOrderStatus.MAPPING + "', sellno = '" + sellno + "' where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'");
                return "";
            } else {
                return "订单已退款";
            }
        }
        return "操作失败";
    }

    /**
     * 退款
     *
     * @param msgId
     * @return
     */
    public static String voidOrder(String msgId, String hostId, UserDBModel userDBModel) {
        MessageAbnormalOrderHeadBean messageAbnormalOrderHeadBean = optAbnormalOrderHeadDetail(msgId);
        if (messageAbnormalOrderHeadBean != null) {
            if (messageAbnormalOrderHeadBean.businessStatus != MessageConstance.MessageAbnormalOrderStatus.MAPPING) {
                String standBy1 = optOrperation(messageAbnormalOrderHeadBean.standBy1, hostId, userDBModel, "退款");
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update message set dealStatus = '1',standBy1 = '" + standBy1 + "', updateTime ='" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "',updateUser = '" + userDBModel.fsUserName + "', businessStatus = '" + MessageConstance.MessageAbnormalOrderStatus.VOID + "' where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'");
                return "";
            } else {
                return "订单已被关联到桌台";
            }
        }
        return "操作失败";
    }


    /**
     * 新增口碑后付异常订单
     *
     * @param kbAfterPayInfo
     * @param standBy1
     * @param billNo
     * @param businessDate
     */
    public static void addKBAfterPayAbnormalMsg(String kbAfterPayInfo,
                                              String standBy1, String billNo, String businessDate, String orderId) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "云收银";
        msg.businessStatus = MessageConstance.MessageAbnormalOrderStatus.NONE;
        msg.dealStatus = 0;
        msg.msgType = MessageConstance.TYPE_KOUBEI_AFTER_PAY;
        msg.msgCategory = MessageConstance.CATEGORY_ABNOMAL_ORDERS;

        /**
         * 支付信息
         */
        msg.msgHead = kbAfterPayInfo;

        /**
         * 	点菜信息
         */
        msg.msgDes = "";

        /**
         * 桌台名称，支付金额
         */
        msg.standBy1 = standBy1;
        /**
         * 订单类型
         */
        msg.msgBody = "";

        /**
         * 订单号---当时的订单号
         */
        msg.correlationId = orderId;

        /**
         * 支付订单号
         */
        msg.standBy2 = billNo;

        msg.replace();
    }

    /**
     * 新增秒付异常订单
     *
     * @param paySessrion
     * @param tempOrderStr
     * @param standBy1
     * @param fsmtableid
     * @param fsmareaid
     * @param billNo
     * @param businessDate
     */
    public static void addRapidPayAbnormalMsg(String paySessrion, String tempOrderStr,
                                              String standBy1, String fsmtableid,
                                              String fsmareaid, String billNo, String businessDate, int fisellType, String orderId) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = "云收银";
        msg.businessStatus = MessageConstance.MessageAbnormalOrderStatus.NONE;
        msg.dealStatus = 0;
        msg.msgType = MessageConstance.TYPE_RAPID_PAY;
        msg.msgCategory = MessageConstance.CATEGORY_ABNOMAL_ORDERS;

        /**
         * 支付信息
         */
        msg.msgHead = paySessrion;

        /**
         * 	点菜信息
         */
        msg.msgDes = tempOrderStr;

        /**
         * 桌台名称，支付金额
         */
        msg.standBy1 = standBy1;
        /**
         * 订单类型
         */
        msg.msgBody = String.valueOf(fisellType);

        /**
         * 订单号---当时的订单号
         */
        msg.correlationId = orderId;

        /**
         * 支付订单号
         */
        msg.standBy2 = billNo;

        msg.mtableId = fsmtableid;   //桌台ID

        msg.mareaId = fsmareaid; //区域ID

        msg.replace();
    }

    /**
     * 新增秒付异常订单
     *
     * @param paySessrion
     * @param standBy1
     * @param fsmtableid
     * @param fsmareaid
     * @param billNo
     * @param businessDate
     */
    public static void addScanPayAbnormalMsg(String paySessrion, String standBy1, String fsmtableid,
                                             String fsmareaid, String billNo, String businessDate,
                                             String createUser, String orderId, int fisellType) {

        MessageDBModel msg = new MessageDBModel();
        msg.businessDate = businessDate;
        msg.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        msg.createUser = createUser;
        msg.businessStatus = MessageConstance.MessageAbnormalOrderStatus.NONE;
        msg.dealStatus = 0;
        msg.msgType = MessageConstance.TYPE_SCAN_PAY;
        msg.msgCategory = MessageConstance.CATEGORY_ABNOMAL_ORDERS;

        /**
         * 支付信息
         */
        msg.msgHead = paySessrion;

        /**
         * 桌台名称，支付金额
         */
        msg.standBy1 = standBy1;
        /**
         * 支付订单号
         */
        msg.standBy2 = billNo;

        msg.mtableId = fsmtableid;   //桌台ID

        msg.mareaId = fsmareaid; //区域ID
        /**
         * 订单号---当时的订单号
         */
        msg.correlationId = orderId;
        /**
         * 订单类型
         */
        msg.msgBody = String.valueOf(fisellType);

        msg.replace();
    }


}
