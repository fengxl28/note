package com.mwee.android.pos.businesscenter.business.report.processor;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.print.PrintIncomeFindModel;
import com.mwee.android.pos.business.print.PrintPaymentModel;
import com.mwee.android.pos.business.print.PrintPaymentSettlementModel;
import com.mwee.android.pos.business.print.PrintSalesFindsModel;
import com.mwee.android.pos.business.print.TakeOutModel;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DailyReportDBModel;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.db.business.report.model.AllDiscountReportModel;
import com.mwee.android.pos.db.business.report.model.PrintDeptDetlItemModel;
import com.mwee.android.pos.db.business.report.model.PrintDeptDetlModel;
import com.mwee.android.pos.db.business.report.model.PrintReportDeptModel;
import com.mwee.android.pos.db.business.report.model.ReportNetOrderItemModel;
import com.mwee.android.pos.db.business.report.model.SaleStatisticsItemModel;
import com.mwee.android.pos.db.business.report.model.SalesAmountClsHJModel;
import com.mwee.android.pos.db.business.report.model.SalesAmountItemModel;
import com.mwee.android.pos.db.business.report.model.SalesAmountModel;
import com.mwee.android.pos.db.business.report.model.SurchargeDetailModel;
import com.mwee.android.pos.db.business.report.model.SurchargeHJModel;
import com.mwee.android.pos.db.business.report.model.WechatPayInfoModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by liuxiuxiu on 2017/9/4.
 */

public class ReportProcessor {

    /**
     * 获取报表数据
     *
     * @param shopGUID  shopID
     * @param startDate 起始日期
     * @param endDate   截止日期
     * @param type      报表类型
     * @param billType  账单类型
     * @param shiftId   版别
     * @return
     */
    public static Map<String, Object> getReportData(String shopGUID, String startDate, String endDate,
                                                    String type, String shiftId, int billType, String accountBookId,
                                                    String sourceIdList) {
        return getReportData(shopGUID, startDate, endDate, type, shiftId, billType, accountBookId, sourceIdList, null);
    }

    /**
     * 获取报表数据
     *
     * @param shopGUID  shopID
     * @param startDate 起始日期
     * @param endDate   截止日期
     * @param type      报表类型
     * @param billType  账单类型
     * @param shiftId   版别
     * @param sellTypeList 订单类型
     * @return
     */
    public static Map<String, Object> getReportData(String shopGUID, String startDate, String endDate,
                                                    String type, String shiftId, int billType, String accountBookId,
                                                    String sourceIdList, String sellTypeList) {
        long queryTime = System.currentTimeMillis();
        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        //截止日期大于当前营业日期时，将截止日期改为当前营业日期
        if (DateUtil.compareDate(currentBusinessDate, endDate, "yyyy-MM-dd") > 0
                && !TextUtils.equals(ReportConsrance.CHECK_BY_DAY, type)
                && !TextUtils.equals(ReportConsrance.NET_ORDER, type)
                && !TextUtils.equals(ReportConsrance.MEITUAN_NET_ORDER, type)
                && !TextUtils.equals(ReportConsrance.WECHAT_ORDE, type)
        ) {
            endDate = currentBusinessDate;
        }
        ArrayMap<String, Object> htmlParams = new ArrayMap<>();
        switch (type) {
            case ReportConsrance.REPORT_DAILY:
                /* 日结表 */
                if (TextUtils.equals(startDate, endDate) && TextUtils.equals(endDate, currentBusinessDate)) {
                    htmlParams.putAll(queryDailyReport(shopGUID, startDate, endDate, currentBusinessDate, shiftId, billType, accountBookId));
                } else {
                    htmlParams.putAll(queryDailyReport(shopGUID, startDate, endDate, currentBusinessDate, "", billType, accountBookId));
                }
                break;
            case ReportConsrance.REPORT_SALE:
                /* 销售数量表 */
                htmlParams.putAll(querySaleReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId, sourceIdList, sellTypeList));
                break;
            case ReportConsrance.REPORT_VOID:
                /* 退菜明细表 */
                htmlParams.putAll(queryVoidReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_GIFT:
                /* 赠菜明细表 */
                htmlParams.putAll(queryGiftReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_DISCOUNT:
                /* 折扣报表*/
                htmlParams.putAll(queryDiscountReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_MAX_SALE_QUANTITY:
                //最高销售数量表
                htmlParams.putAll(queryMaxSaleQuantityReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                htmlParams.put("type", ReportConsrance.REPORT_MAX_SALE_QUANTITY);
                break;
            case ReportConsrance.REPORT_MAX_SALE_PRICE:
                //最高销售金额表
                htmlParams.putAll(queryMaxSalePriceReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                htmlParams.put("type", ReportConsrance.REPORT_MAX_SALE_PRICE);
                break;
            case ReportConsrance.REPORT_DEPT:
                //档口统计表
                htmlParams.putAll(queryDeptReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_TIME:
                //时段统计表
                htmlParams.putAll(queryTimeReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.WECHAT_ORDE:
                //微信报表
                htmlParams.putAll(queryWechatOrderReport(shopGUID, startDate, endDate, currentBusinessDate));
                break;
            case ReportConsrance.NET_ORDER:
                //网络订单报表
                htmlParams.putAll(queryNetOrderReport(shopGUID, startDate, endDate, currentBusinessDate, false));
                break;
            case ReportConsrance.MEITUAN_NET_ORDER:
                //网络订单报表---虚拟打印机来源的美团外卖
                htmlParams.putAll(queryNetOrderReport(shopGUID, startDate, endDate, currentBusinessDate, true));
                break;
            case ReportConsrance.WECHAT_FAST_FOOD:
                //网络订单报表
                htmlParams.putAll(queryWechatFastFoodReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.CHECK_BY_DAY:
                //收款明细表
                htmlParams.putAll(queryCheckByDay(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_ALL_DISCOUNT:
                //折扣汇总表
                htmlParams.putAll(queryAllDiscountReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            case ReportConsrance.REPORT_NEW_DAILY:
                //新日结表
                htmlParams.putAll(queryNewDailyReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId, sourceIdList, sellTypeList));
                break;
            case ReportConsrance.REPORT_MEMBER_CHARGE:
                //会员储值汇总
                htmlParams.putAll(DailyReportDBUtil.queryMemberChargeData(startDate,endDate,shopGUID, ServerCache.getInstance().fsCompanyGUID));
                break;
            case ReportConsrance.REPORT_BUNDLE_SALE:
                //套餐销量汇总
                htmlParams.putAll(queryBundleReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId, null, null));
                break;
            case ReportConsrance.REPORT_SALE_CLS_NUM :
            case ReportConsrance.REPORT_INCOME_CLS_NUM:
                //分类统计
                htmlParams.putAll(queryClsReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId, type));
                break;
            case ReportConsrance.REPORT_SURCHARGE_DETAIL :
                //溢收明细
                htmlParams.putAll(querySurchargeDetailReport(shopGUID, startDate, endDate, currentBusinessDate, billType, accountBookId));
                break;
            default:
                break;
        }
        if (htmlParams.size() == 0) {
            ActionLog.addLog("查询报表业务中心无数据返回", "", "", ActionLog.RP_REPORT_STATEMENT, "type:" + type + ",startDate:" + startDate + ",endDate:" + endDate + ",BusinessDate:" + currentBusinessDate + ",billType:" + billType);
        }
        LogUtil.logBusiness("getReportData cost:" + (System.currentTimeMillis() - queryTime));
        return htmlParams;
    }

    /**
     * 查新日结表数据
     * @param shopGUID
     * @param startDate
     * @param endDate
     * @param currentDate
     * @param billType
     * @param sourceIdList
     * @param orderTypeList
     * @return
     */
    public static Map<String, Object> queryNewDailyReport(String shopGUID, String startDate, String endDate, String currentDate,
                                                          int billType, String accountBookId,String sourceIdList,String orderTypeList){
        Map<String, Object> currentData = new HashMap<>();

        String result = "";
        if(TextUtils.equals(endDate,currentDate)){
            currentData = DailyReportDBUtil.queryNewDailyData(currentDate,billType,accountBookId,sourceIdList,orderTypeList);
        }
        if(!TextUtils.equals(startDate,endDate)){
            String tempEndDate = endDate;
            if (TextUtils.equals(endDate, currentDate)) {
                tempEndDate = getPreDate(endDate);
            }
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, tempEndDate, ReportConsrance.REPORT_NEW_DAILY, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    result = voidReportAdd(result, dailyReportDBModel.value,true,true);
                }
            }
            result = voidReportAdd(result, JSON.toJSONString(currentData),true,true);
            //重新计算各个"率"
            JSONObject resultData = JSONObject.parseObject(result);
            JSONObject eatOrder = resultData.getJSONObject("eatOrder");
            DailyReportDBUtil.dealEatOrderRate(eatOrder,startDate,endDate);
            resultData.put("eatOrder",eatOrder);
            JSONObject takeOutOrder = resultData.getJSONObject("takeOutOrder");
            DailyReportDBUtil.dealTakeOutRate(takeOutOrder);
            resultData.put("takeOutOrder",takeOutOrder);

            Map<String, Integer> sourceNameMap = new HashMap<>();
            strDuplicateRemoval(sourceNameMap, resultData.getString("OrderSource"), "、");
            strDuplicateRemoval(sourceNameMap, currentData.containsKey("OrderSource") ? (String)currentData.get("OrderSource") : "", "、");

            StringBuffer stringBuffer = new StringBuffer();
            for (String sourceName : sourceNameMap.keySet()) {
                stringBuffer.append(sourceName).append("、");
            }
            int index = stringBuffer.lastIndexOf("、");
            if (index > 0) {
                stringBuffer.deleteCharAt(index);
            }
            resultData.put("OrderSource", stringBuffer.toString());

            result = JSON.toJSONString(resultData);
        }else{
            if(!TextUtils.equals(endDate,currentDate)){
                //如果没有筛选条件，优先从固化库里查数据，如果固化库没数据，在从热数据里统计
                if(TextUtils.isEmpty(sourceIdList) && TextUtils.isEmpty(orderTypeList)){
                    List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate, ReportConsrance.REPORT_NEW_DAILY, billType, accountBookId);
                    if(ListUtil.isEmpty(reportSale)){
                        currentData =  DailyReportDBUtil.queryNewDailyData(endDate,billType, accountBookId,sourceIdList,orderTypeList);
                    }else{
                        result =  reportSale.get(0).value;
                    }
                }else{
                    currentData =  DailyReportDBUtil.queryNewDailyData(endDate,billType, accountBookId,sourceIdList,orderTypeList);
                }
            }
        }
        if(!TextUtils.isEmpty(result)){
            return JSON.parseObject(result, Map.class);
        }
        return currentData;
    }

    public static Map<String, Object> queryAllDiscountReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {
        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.optAllDiscountReport(currentDate, billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate, ReportConsrance.REPORT_ALL_DISCOUNT, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = mergeAllDiscountData(resule, dailyReportDBModel.value);
                }
            }
        }
        resule = mergeAllDiscountData(resule, JSON.toJSONString(currentDateHtmlParams));
        return JSON.parseObject(resule, Map.class);
    }

    private static String mergeAllDiscountData(String originalData, String tempData) {
        if (TextUtils.isEmpty(tempData)) {
            return originalData;
        }

        //将Object对象转换为JSONObject对象
        JSONObject libraryObject = JSON.parseObject(originalData);

        if (TextUtils.isEmpty(originalData) || libraryObject == null) {
            libraryObject = new JSONObject();
        }
        JSONObject jsonObject = JSON.parseObject(tempData);
        if (jsonObject != null) {
            //总数量
            Object allCount = libraryObject.get("allCount");
            if (allCount == null) {
                libraryObject.put("allCount", jsonObject.get("allCount"));
            } else {
                libraryObject.put("allCount", objectAddObject(allCount, jsonObject.get("allCount")));
            }
            //总折扣
            Object allDiscountAmt = libraryObject.get("allDiscountAmt");
            if (allDiscountAmt == null) {
                libraryObject.put("allDiscountAmt", jsonObject.get("allDiscountAmt"));
            } else {
                libraryObject.put("allDiscountAmt", objectAddObject(allDiscountAmt, jsonObject.get("allDiscountAmt")));
            }
            //折扣明细
            Object discountContent = libraryObject.get("discountContent");
            if (discountContent == null) {
                libraryObject.put("discountContent", jsonObject.get("discountContent"));
            } else {
                List<AllDiscountReportModel> originalList = JSONArray.parseArray(libraryObject.getString("discountContent"), AllDiscountReportModel.class);
                List<AllDiscountReportModel> tempList = JSONArray.parseArray(jsonObject.getString("discountContent"), AllDiscountReportModel.class);
                libraryObject.put("discountContent", mergeAllDiscountReportData(originalList, tempList));
            }
        }
        return libraryObject.toString();
    }

    private static Object objectAddObject(Object original, Object temp) {
        if (original instanceof Integer && temp instanceof Integer) {
            original = ((Integer) original) + ((Integer) temp);
        } else if (original instanceof BigDecimal && temp instanceof BigDecimal) {
            original = ((BigDecimal) original).add((BigDecimal) temp);
        } else if (original instanceof Integer && temp instanceof BigDecimal) {
            original = new BigDecimal((Integer) original).add((BigDecimal) temp);
        } else if (original instanceof BigDecimal && temp instanceof Integer) {
            original = ((BigDecimal) original).add(new BigDecimal((Integer) temp));
        }
        return original;
    }

    private static List<AllDiscountReportModel> mergeAllDiscountReportData(List<AllDiscountReportModel> originalData, List<AllDiscountReportModel> tempData) {
        if (ListUtil.isEmpty(originalData)) {
            if (ListUtil.isEmpty(tempData)) {
                return new ArrayList<>(1);
            }
            return tempData;
        }
        if (ListUtil.isEmpty(tempData)) {
            return originalData;
        }
        for (AllDiscountReportModel model : originalData) {
            if (model == null) {
                continue;
            }
            for (int i = tempData.size() - 1; i >= 0; i--) {
                AllDiscountReportModel temp = tempData.get(i);
                if (temp == null) {
                    continue;
                }
                if (TextUtils.equals(model.discountId, temp.discountId)) {
                    model.discountQty = model.discountQty.add(temp.discountQty);
                    model.discountAmt = model.discountAmt.add(temp.discountAmt);
                    model.discountName = temp.discountName;
                    tempData.remove(i);
                    break;
                }
            }
        }
        if (tempData.size() > 0) {
            originalData.addAll(tempData);
        }
        return originalData;
    }

    /**
     * 查询日报表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @param shiftId     班别ID
     * @param billType    账单类型
     */
    public static Map<String, Object> queryDailyReport(String shopGUID, String startDate, String endDate, String currentDate,
                                                       String shiftId, int billType, String accountBookId) {

        LogUtil.logBusiness("ReportProcessor-queryDailyReport","shopGUID:"+shopGUID+",startDate:"+startDate+",endDate:"+endDate+",currentDate:"+currentDate+",shiftId:"+shiftId+",billType:"+billType+",accountBookId:"+accountBookId);

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        if (TextUtils.equals(shiftId, "all")) {
            shiftId = "";
        }
        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.statisticDailyBalance(currentDate, shiftId, billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            LogUtil.logBusiness("ReportProcessor-queryDailyReport","endDate:"+endDate);
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_DAILY, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = voidReportAddWithoutNode(resule, dailyReportDBModel.value, false);
                    resule = dealDailyReportList(resule, dailyReportDBModel.value);

                }
            }
        }
        resule = voidReportAddWithoutNode(resule, JSON.toJSONString(currentDateHtmlParams), false);
        resule = dealDailyReportList(resule, JSON.toJSONString(currentDateHtmlParams));
        if (!TextUtils.equals(startDate, currentDate)) {
            /* 日报表-人均、单均特殊计算 */
            JSONObject obj = JSONObject.parseObject(resule);
            BigDecimal fdExpAmt = obj.getBigDecimal("originalSaleAmt"); //原始营业额
            int fiCustSum = obj.getIntValue("fiCustSum"); //人数
            int payedSellCount = obj.getIntValue("SellYJCount"); //单数

            //计算人均 （原始营业额/已结人数 = 人均）
            if (fiCustSum > 0 && fdExpAmt.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal RJ = fdExpAmt.divide(new BigDecimal(fiCustSum), 2, BigDecimal.ROUND_HALF_EVEN);
                obj.put("RJ", RJ);
            }
            //计算单均 （原始营业额/已结单数 = 单均）
            if (payedSellCount > 0 && fdExpAmt.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal DJ = fdExpAmt.divide(new BigDecimal(payedSellCount), 2, BigDecimal.ROUND_HALF_EVEN);
                obj.put("DJ", DJ);
            }
            resule = obj.toJSONString();
        }

        Map<String, Object> data = JSON.parseObject(resule, Map.class);
        dealRoundAmt(data);

        return data;
    }

    /**
     * 2.7.7.307 将取反的圆整字段改回来，不再取反
     *
     * @param data
     */
    private static void dealRoundAmt(Map<String, Object> data) {
        if (data == null) {
            return;
        }
        Object roundAmt = data.get("fdRoundAmt");
        if (roundAmt == null) {
            return;
        }
        if (roundAmt instanceof BigDecimal) {
            data.put("fdRoundAmt", ((BigDecimal) roundAmt).negate());
        } else if (roundAmt instanceof Integer) {
            int round = ((Integer) roundAmt).intValue();
            round = -round;
            data.put("fdRoundAmt", round);
        }
    }

    /**
     * 收款明细表
     *
     * @param shopGUID     shopID
     * @param startDate    起始日期
     * @param endDate      截止日期
     * @param businessDate 当前营业日期
     * @param billType     账单类型
     */
    public static Map<String, Object> queryCheckByDay(String shopGUID, String startDate, String endDate, String businessDate, int billType, String accountBookId) {
        String currentDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        String historyStart = "";
        String historyEnd = "";
        String realStart = "";
        String realEnd = "";
        try {
            //查询的开始时间=结束时间
            if (TextUtils.equals(startDate, endDate)) {
                //查询的结束时间小于当前营业日期---纯查询历史数据
                if (DateUtil.daysBetween(businessDate, endDate) < 0) {
                    historyStart = startDate;
                    historyEnd = endDate;
                } else
                    //查询的结束时间大于等于当前的营业日期并且小于等于当前的自然日---实时查询当前营业日期的数据
                    if (DateUtil.daysBetween(businessDate, endDate) >= 0 && DateUtil.daysBetween(currentDate, endDate) <= 0) {
                        realStart = startDate;
                        realEnd = endDate;
                    } else {
                        //查询的结束时间大于当前的自然日---不处理
                        historyStart = "";
                        historyEnd = "";
                        realStart = "";
                        realEnd = "";
                    }
            } else if (DateUtil.daysBetween(endDate, startDate) > 0
                    || DateUtil.daysBetween(currentDate, startDate) > 0
            ) {
                //查询的开始时间 > 结束时间 或者 查询的开始时间大于当前营业日期----- 不处理
                historyStart = "";
                historyEnd = "";
                realStart = "";
                realEnd = "";
            } else if (DateUtil.daysBetween(businessDate, endDate) < 0) {
                //查询的结束时间 < 当前营业日期----- 纯查询历史数据
                historyStart = startDate;
                historyEnd = endDate;
                realStart = "";
                realEnd = "";
            } else if (DateUtil.daysBetween(businessDate, endDate) == 0) {
                //查询的结束时间 == 当前营业日期----- 查询历史数据 + 当前营业日的实时数据
                historyStart = startDate;
                historyEnd = DailyReportDBUtil.getDay(businessDate, 1);
                realStart = businessDate;
                realEnd = businessDate;
            } else if (DateUtil.daysBetween(businessDate, startDate) < 0
                    && DateUtil.daysBetween(businessDate, endDate) > 0) {
                historyStart = startDate;
                historyEnd = DailyReportDBUtil.getDay(businessDate, 1);
                realStart = businessDate;
                realEnd = endDate;
            } else if (DateUtil.daysBetween(businessDate, startDate) >= 0) {
                //查询的开始时间 >= 营业日期 且 结束时间大于当前营业日期----- 实时查数据
                historyStart = "";
                historyEnd = "";
                realStart = startDate;
                realEnd = endDate;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }


        if (!TextUtils.isEmpty(realStart)) {
            currentDateHtmlParams = DailyReportDBUtil.checkByDay(realStart, realEnd, billType, accountBookId);
        }

        if (!TextUtils.isEmpty(historyStart)) {
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, historyStart, historyEnd,
                    ReportConsrance.CHECK_BY_DAY, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = dealDailyReportList(resule, dailyReportDBModel.value);

                }
            }
        }

        resule = dealDailyReportList(resule, JSON.toJSONString(currentDateHtmlParams));
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 查询销售数量表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @param billType    账单类型
     * @param orderTypeList 订单类型
     */
    public static Map<String, Object> querySaleReport(String shopGUID, String startDate, String endDate, String currentDate,
                                                      int billType, String accountBookId, String sourceIdList,String orderTypeList) {
        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";
        //美易点上支持从订单库查历史数据7天中某一天的订单数据（不是从固化里取，是从订单库根据筛选条件取）
        if(APPConfig.isMyd() && TextUtils.equals(startDate,endDate) && (!TextUtils.isEmpty(sourceIdList) || !TextUtils.isEmpty(orderTypeList))){
            return DailyReportDBUtil.statisticSale(startDate, billType, accountBookId, sourceIdList,orderTypeList);
        }

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.statisticSale(currentDate, billType, accountBookId, sourceIdList,orderTypeList);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_SALE, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    String tempJson = dailyReportDBModel.value;
                    if (APPConfig.isAir()) {
                        tempJson = transferJson(tempJson);
                    }
                    resule = dealSaleCountList(resule, tempJson);
                }
            }
        }
        String tempJson = JSON.toJSONString(currentDateHtmlParams);
        if (APPConfig.isAir()) {
            tempJson = transferJson(tempJson);
        }
        resule = dealSaleCountList(resule, tempJson);
        if (!TextUtils.equals(startDate, endDate)) {
            resule = countSaleNumPercent(resule);
        }
        return JSON.parseObject(resule, Map.class);
    }

    private static String countSaleNumPercent(String data) {
        JSONObject dataObj = JSON.parseObject(data);
        if (dataObj == null) {
            dataObj = new JSONObject();
        }
        //XSSL
        List<SalesAmountModel> xssl = JSONArray.parseArray(dataObj.getString("XSSL"), SalesAmountModel.class);
        if (!ListUtil.isEmpty(xssl)) {
            for (SalesAmountModel model : xssl) {
                if (model == null || model.HJ == null || ListUtil.isEmpty(model.MX)) continue;
                BigDecimal moneySum = model.HJ.fdsaleamt;
                if (moneySum.compareTo(BigDecimal.ZERO) <= 0) continue;
                BigDecimal bfSum = BigDecimal.ZERO;
                for (int i = 0; i < model.MX.size(); i++) {
                    SalesAmountItemModel temp = model.MX.get(i);
                    if (i == model.MX.size() - 1) {
                        temp.BF = BizConstant.HUNDREND.subtract(bfSum);
                    } else {
                        temp.BF = (temp.fdsaleamt.multiply(BizConstant.HUNDREND)).divide(moneySum, 2, BigDecimal.ROUND_DOWN);
                        bfSum = bfSum.add(temp.BF);
                    }
                }
            }
            dataObj.put("XSSL", xssl);
        }
        return dataObj.toJSONString();
    }

    /**
     * 档口统计表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryDeptReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";
        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.statisticDeptBalance(currentDate, billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_DEPT, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = dealDeptList(resule, dailyReportDBModel.value);
                }
            }
        }
        resule = dealDeptList(resule, JSON.toJSONString(currentDateHtmlParams));
        if (!TextUtils.equals(startDate, endDate)) {//计算多日的报表需要重新计算百分比
            resule = countPercent(resule);
        }
        return JSON.parseObject(resule, Map.class);
    }

    private static String countPercent(String data) {
        JSONObject dataObj = JSON.parseObject(data);
        if (dataObj == null) {
            dataObj = new JSONObject();
        }
        //XSSL
        List<PrintReportDeptModel> xssl = JSONArray.parseArray(dataObj.getString("XSSL"), PrintReportDeptModel.class);
        SalesAmountClsHJModel HJ = JSON.parseObject(dataObj.getString("HJ"), SalesAmountClsHJModel.class);
        if (HJ != null && HJ.fdsaleamt.compareTo(BigDecimal.ZERO) > 0 && !ListUtil.isEmpty(xssl)) {
            BigDecimal bfSum = BigDecimal.ZERO;
            for (int i = 0; i < xssl.size(); i++) {
                PrintReportDeptModel temp = xssl.get(i);
                if (i == xssl.size() - 1) {
                    temp.BF = BizConstant.HUNDREND.subtract(bfSum);
                } else {
                    temp.BF = (temp.fdsaleamt.multiply(BizConstant.HUNDREND)).divide(HJ
                            .fdsaleamt, 2, BigDecimal.ROUND_DOWN);
                    bfSum = bfSum.add(temp.BF);
                }
            }
            dataObj.put("XSSL", xssl);
        }
//        BigDecimal moneySum = BigDecimal.ZERO;
//        for (PrintReportDeptModel mode : libraryPaymentModels) {
//            moneySum = moneySum.add(mode.fdsaleamt);
//        }
        List<PrintDeptDetlModel> deptDtl = JSONArray.parseArray(dataObj.getString("dtl"), PrintDeptDetlModel.class);
        if (!ListUtil.isEmpty(deptDtl)) {
            for (PrintDeptDetlModel mode : deptDtl) {
                BigDecimal moneySum = BigDecimal.ZERO;
                BigDecimal bfSum = BigDecimal.ZERO;
                if (mode == null || ListUtil.isEmpty(mode.detl)) continue;
                for (PrintDeptDetlItemModel temp : mode.detl) {
                    moneySum = moneySum.add(temp.fdSubTotal);
                }
                if (moneySum.compareTo(BigDecimal.ZERO) > 0) {
                    for (int i = 0; i < mode.detl.size(); i++) {
                        PrintDeptDetlItemModel item = mode.detl.get(i);
                        if (item == null) continue;
                        if (i == mode.detl.size() - 1) {
                            item.percent = BizConstant.HUNDREND.subtract(bfSum);
                        } else {
                            item.percent = (item.fdSubTotal.multiply(BizConstant.HUNDREND)).divide(moneySum, 2, BigDecimal.ROUND_DOWN);
                            bfSum = bfSum.add(item.percent);
                        }
                    }
                }
            }
            dataObj.put("dtl", deptDtl);
        }
        return dataObj.toJSONString();
    }

    /**
     * 时段统计表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryTimeReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";
        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.getTimeReportValue(currentDate, billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_TIME, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = dealTimeList(resule, dailyReportDBModel.value);
                }
            }
        }
        resule = dealTimeList(resule, JSON.toJSONString(currentDateHtmlParams));
        if (!TextUtils.equals(startDate, endDate)) {
            resule = countTimePercent(resule);
        }
        return JSON.parseObject(resule, Map.class);
    }

    private static String countTimePercent(String data) {
        JSONObject dataObj = JSON.parseObject(data);
        if (dataObj == null) {
            dataObj = new JSONObject();
        }
        //XSSD
        List<SalesAmountItemModel> xssd = JSONArray.parseArray(dataObj.getString("XSSD"), SalesAmountItemModel.class);
        if (!ListUtil.isEmpty(xssd)) {
            BigDecimal moneySum = BigDecimal.ZERO;
            BigDecimal bfSum = BigDecimal.ZERO;
            for (SalesAmountItemModel temp : xssd) {
                moneySum = moneySum.add(temp.fdsaleamt);
            }
            if (moneySum.compareTo(BigDecimal.ZERO) > 0) {
                for (int i = 0; i < xssd.size(); i++) {
                    SalesAmountItemModel item = xssd.get(i);
                    if (item == null) continue;
                    if (i == xssd.size() - 1) {
                        item.BF = BizConstant.HUNDREND.subtract(bfSum);
                    } else {
                        item.BF = (item.fdsaleamt.multiply(BizConstant.HUNDREND)).divide(moneySum, 2, BigDecimal.ROUND_DOWN);
                        bfSum = bfSum.add(item.BF);
                    }
                }
            }
            dataObj.put("XSSD", xssd);
        }
        return dataObj.toJSONString();
    }

    /**
     * 微信外卖
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryWechatOrderReport(String shopGUID, String startDate, String endDate, String currentDate) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";
        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.getWechatOrderReport(currentDate);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.WECHAT_ORDE, 0, "1");
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = dealWXORDERList(resule, dailyReportDBModel.value);
                }
            }
        }
        resule = dealWXORDERList(resule, JSON.toJSONString(currentDateHtmlParams));
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 网络订单报表--外卖报表
     *
     * @param shopGUID
     * @param startDate
     * @param endDate
     * @param currentDate
     * @param isMWMeituan 虚拟打印机的美团外卖报表
     * @return
     */
    public static Map<String, Object> queryNetOrderReport(String shopGUID, String startDate, String endDate, String currentDate, boolean isMWMeituan) {
        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        currentDate = DateUtil.getCurrentDate("yyyy-MM-dd");

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.getNetOrderReport(endDate, currentDate, isMWMeituan);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    isMWMeituan ? ReportConsrance.MEITUAN_NET_ORDER : ReportConsrance.NET_ORDER, 0, "1");

            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = netorderReportAddWithoutList(resule, dailyReportDBModel.value, false);
                    resule = dealNetorderReportList(resule, dailyReportDBModel.value);
                }
            }
        }
        resule = netorderReportAddWithoutList(resule, JSON.toJSONString(currentDateHtmlParams), false);
        resule = dealNetorderReportList(resule, JSON.toJSONString(currentDateHtmlParams));

        return JSON.parseObject(resule, Map.class);

    }

    /**
     * 合并日报表数据
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealNetorderReportList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //DDLY
        List<ReportNetOrderItemModel> libraryPrintSalesFindsModel = JSONArray.parseArray(libraryObject.getString("DDLY"), ReportNetOrderItemModel.class);
        List<ReportNetOrderItemModel> tempPrintSalesFindsModel = JSONArray.parseArray(tempJsonObject.getString("DDLY"), ReportNetOrderItemModel.class);
        if (libraryPrintSalesFindsModel == null) {
            libraryPrintSalesFindsModel = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPrintSalesFindsModel)) {
            if (ListUtil.isEmpty(libraryPrintSalesFindsModel)) {
                libraryPrintSalesFindsModel.addAll(tempPrintSalesFindsModel);
            } else {
                boolean modelAdded;
                for (ReportNetOrderItemModel tempModel : tempPrintSalesFindsModel) {
                    modelAdded = false;
                    for (ReportNetOrderItemModel libraryModel : libraryPrintSalesFindsModel) {
                        if (TextUtils.equals(tempModel.name, libraryModel.name)) {
                            libraryModel.amt = libraryModel.amt.add(tempModel.amt);
                            libraryModel.qty = libraryModel.qty.add(tempModel.qty);
                            modelAdded = true;
                            break;
                        }
                    }

                    if (!modelAdded) {
                        libraryPrintSalesFindsModel.add(tempModel);
                    }
                }
            }

        }
        libraryObject.put("DDLY", libraryPrintSalesFindsModel);

        //CPSL
        List<ReportNetOrderItemModel> libraryIncomeFindModels = JSONArray.parseArray(libraryObject.getString("CPSL"), ReportNetOrderItemModel.class);
        List<ReportNetOrderItemModel> tempIncomeFindModels = JSONArray.parseArray(tempJsonObject.getString("CPSL"), ReportNetOrderItemModel.class);
        if (libraryIncomeFindModels == null) {
            libraryIncomeFindModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempIncomeFindModels)) {
            if (ListUtil.isEmpty(libraryIncomeFindModels)) {
                libraryIncomeFindModels.addAll(tempIncomeFindModels);
            } else {
                boolean modelAdded;
                for (ReportNetOrderItemModel tempModel : tempIncomeFindModels) {
                    modelAdded = false;
                    for (ReportNetOrderItemModel libraryModel : libraryIncomeFindModels) {
                        if (TextUtils.equals(tempModel.name, libraryModel.name)) {
                            libraryModel.amt = libraryModel.amt.add(tempModel.amt);
                            libraryModel.qty = libraryModel.qty.add(tempModel.qty);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryIncomeFindModels.add(tempModel);
                    }
                }
            }
        }
        libraryObject.put("CPSL", libraryIncomeFindModels);

        return libraryObject.toJSONString();

    }


    public static String netorderReportAddWithoutList(String paramsLibrary, String tempHtmlParas, boolean append) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject jsonObject = JSON.parseObject(tempHtmlParas);
        jsonObject.remove("DDLY");
        jsonObject.remove("CPSL");

        return voidReportAdd(paramsLibrary, jsonObject.toString(), append);
    }

    /**
     * 微信快餐报表
     *
     * @param shopGUID
     * @param startDate
     * @param endDate
     * @param currentDate
     * @return
     */
    public static Map<String, Object> queryWechatFastFoodReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {
        Map<String, Object> htmlParams = new HashMap<>();
        if (TextUtils.equals(startDate, endDate)) {
            htmlParams = DailyReportDBUtil.getWechatFastFoodReport(endDate, billType, accountBookId);
        } else {
            htmlParams = DailyReportDBUtil.getWechatFastFoodReport(startDate, endDate, billType, accountBookId);
        }
        return htmlParams;
    }


    /**
     * 查询退菜明细表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryVoidReport(String shopGUID, String startDate, String endDate,
                                                      String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.staticVoidOrGift(currentDate, "fdBackQty", billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_VOID, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = voidReportAdd(resule, dailyReportDBModel.value, true);
                }
            }
        }
        resule = voidReportAdd(resule, JSON.toJSONString(currentDateHtmlParams), true);
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 查询赠菜明细表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryGiftReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.staticVoidOrGift(currentDate, "fdGiftqty", billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_GIFT, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = voidReportAdd(resule, dailyReportDBModel.value, true);
                }
            }
        }
        resule = voidReportAdd(resule, JSON.toJSONString(currentDateHtmlParams), true);
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 查询折扣报表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     */
    public static Map<String, Object> queryDiscountReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日报表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.optDiscountReport(currentDate, billType, accountBookId);
        }

        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_DISCOUNT, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    resule = voidReportAdd(resule, dailyReportDBModel.value, true);
                }
            }
        }
        resule = voidReportAdd(resule, JSON.toJSONString(currentDateHtmlParams), true);
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 查询最高销售数量表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @return
     */
    public static Map<String, Object> queryMaxSaleQuantityReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日最高销售数量表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.getStatisticMaxSaleQuantity(currentDate, billType, accountBookId);
        }

        List<SaleStatisticsItemModel> saleStatisticsItemModels = new ArrayList<>();
        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_MAX_SALE_QUANTITY, billType, accountBookId);

            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    JSONObject obj = JSON.parseObject(dailyReportDBModel.value);
                    if (obj != null) {
                        List<SaleStatisticsItemModel> valuedata = JSON.parseArray(obj.getString("XSSL"), SaleStatisticsItemModel.class);
                        dealMaxSaleQuantity(saleStatisticsItemModels, valuedata);
                    }
                }
            }
        }
        dealMaxSaleQuantity(saleStatisticsItemModels, (List<SaleStatisticsItemModel>) currentDateHtmlParams.get("XSSL"));

        if (!TextUtils.equals(startDate, currentDate)) {
            // 合并后排序，并重新计算占比
            BigDecimal total = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(saleStatisticsItemModels)) {
                for (SaleStatisticsItemModel model : saleStatisticsItemModels) {
                    total = total.add(model.fdsaleqty);
                }
                Collections.sort(saleStatisticsItemModels, new Comparator<SaleStatisticsItemModel>() {
                    @Override
                    public int compare(SaleStatisticsItemModel saleStatisticsItemModel, SaleStatisticsItemModel t1) {
                        return t1.fdsaleqty.compareTo(saleStatisticsItemModel.fdsaleqty);
                    }
                });
                BigDecimal bfSum = BigDecimal.ZERO;
                for (int index = 0; index < saleStatisticsItemModels.size(); ) {
                    SaleStatisticsItemModel model = saleStatisticsItemModels.get(index);
                    if (total.compareTo(BigDecimal.ZERO) > 0) {
                        if (index == saleStatisticsItemModels.size() - 1) {
                            model.percent = BizConstant.HUNDREND.subtract(bfSum);
                        } else {
                            model.percent = model.fdsaleqty.multiply(BizConstant.HUNDREND).divide(total, 2, BigDecimal.ROUND_DOWN);
                            bfSum = bfSum.add(model.percent);
                        }
                    } else {
                        model.percent = BigDecimal.ZERO;
                    }
                    model.serialnumber = ++index;
                }
            }
        }

        currentDateHtmlParams.put("XSSL", saleStatisticsItemModels);
        return currentDateHtmlParams;
    }

    /**
     * 查询最高销售金额表
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @return
     */
    public static Map<String, Object> queryMaxSalePriceReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        if (TextUtils.equals(endDate, currentDate)) {
            /* 当日最高销售数量表，统计数据库 */
            currentDateHtmlParams = DailyReportDBUtil.getStatisticMaxSalePrice(currentDate, billType, accountBookId);
        }

        List<SaleStatisticsItemModel> saleStatisticsItemModels = new ArrayList<>();
        if (!TextUtils.equals(startDate, currentDate)) {
            if (TextUtils.equals(endDate, currentDate)) {
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                    ReportConsrance.REPORT_MAX_SALE_PRICE, billType, accountBookId);

            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    JSONObject obj = JSON.parseObject(dailyReportDBModel.value);
                    if (obj != null) {
                        List<SaleStatisticsItemModel> valuedata = JSON.parseArray(obj.getString("XSSL"), SaleStatisticsItemModel.class);
                        dealMaxSaleQuantity(saleStatisticsItemModels, valuedata);
                    }
                }
            }
        }
        dealMaxSaleQuantity(saleStatisticsItemModels, (List<SaleStatisticsItemModel>) currentDateHtmlParams.get("XSSL"));

        if (!TextUtils.equals(startDate, currentDate)) {
            // 合并后排序，并重新计算占比
            BigDecimal total = BigDecimal.ZERO;
            if (!ListUtil.isEmpty(saleStatisticsItemModels)) {
                for (SaleStatisticsItemModel model : saleStatisticsItemModels) {
                    total = total.add(model.fdsaleamt);
                }
                Collections.sort(saleStatisticsItemModels, new Comparator<SaleStatisticsItemModel>() {
                    @Override
                    public int compare(SaleStatisticsItemModel saleStatisticsItemModel, SaleStatisticsItemModel t1) {
                        return t1.fdsaleamt.compareTo(saleStatisticsItemModel.fdsaleamt);
                    }
                });
                BigDecimal bfSum = BigDecimal.ZERO;
                for (int index = 0; index < saleStatisticsItemModels.size(); ) {
                    SaleStatisticsItemModel model = saleStatisticsItemModels.get(index);
                    if (total.compareTo(BigDecimal.ZERO) > 0) {
                        if (index == saleStatisticsItemModels.size() - 1) {
                            if (model.fdsaleamt.compareTo(BigDecimal.ZERO) > 0) {
                                model.percent = BizConstant.HUNDREND.subtract(bfSum);
                            } else {
                                model.percent = BigDecimal.ZERO;
                                if (saleStatisticsItemModels.size() > 0) {
                                    saleStatisticsItemModels.get(0).percent = saleStatisticsItemModels.get(0).percent.add(BizConstant.HUNDREND.subtract(bfSum));
                                }
                            }
                        } else {
                            model.percent = model.fdsaleamt.multiply(BizConstant.HUNDREND).divide(total, 2, BigDecimal.ROUND_DOWN);
                            bfSum = bfSum.add(model.percent);
                        }
                    } else {
                        model.percent = BigDecimal.ZERO;
                    }
                    model.serialnumber = ++index;
                }
            }
        }

        currentDateHtmlParams.put("XSSL", saleStatisticsItemModels);
        return currentDateHtmlParams;
    }

    /**
     * 合并日报表数据
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealDailyReportList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //ShiftList
        List<PrintPaymentModel> libraryPaymentModels = JSONArray.parseArray(libraryObject.getString("ShiftList"), PrintPaymentModel.class);
        List<PrintPaymentModel> tempPaymentModels = JSONArray.parseArray(tempJsonObject.getString("ShiftList"), PrintPaymentModel.class);
        if (libraryPaymentModels == null) {
            libraryPaymentModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPaymentModels)) {
            if (ListUtil.isEmpty(libraryPaymentModels)) {
                libraryPaymentModels.addAll(tempPaymentModels);
            } else {
                boolean modelAdded;
                for (PrintPaymentModel tempModel : tempPaymentModels) {
                    modelAdded = false;
                    for (PrintPaymentModel libraryModel : libraryPaymentModels) {
                        if (TextUtils.equals(tempModel.fsshiftname, libraryModel.fsshiftname)) {
                            if (!ListUtil.isEmpty(tempModel.MX)) {
                                boolean printModelAdded = false;
                                for (PrintPaymentSettlementModel tempPrintModel : tempModel.MX) {
                                    for (PrintPaymentSettlementModel libraryPrintModel : libraryModel.MX) {
                                        printModelAdded = false;
                                        if (TextUtils.equals(tempPrintModel.fspaymentname, libraryPrintModel.fspaymentname)) {
                                            libraryPrintModel.fiiscalcpaid = tempPrintModel.fiiscalcpaid;
                                            libraryPrintModel.fdrecemoney = libraryPrintModel.fdrecemoney.add(tempPrintModel.fdrecemoney);
                                            libraryPrintModel.recemoney = libraryPrintModel.recemoney.add(tempPrintModel.recemoney);
                                            libraryPrintModel.qty = libraryPrintModel.qty + tempPrintModel.qty;
                                            printModelAdded = true;
                                            break;
                                        }
                                    }
                                    if (!printModelAdded) {
                                        libraryModel.MX.add(tempPrintModel);
                                    }
                                }
                            }
                            libraryModel.HJ.fdrecemoney = libraryModel.HJ.fdrecemoney.add(tempModel.HJ.fdrecemoney);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryPaymentModels.add(tempModel);
                    }
                }
            }
        }
        libraryObject.put("ShiftList", libraryPaymentModels);

        //XSFL
        List<PrintSalesFindsModel> libraryPrintSalesFindsModel = JSONArray.parseArray(libraryObject.getString("XSFL"), PrintSalesFindsModel.class);
        List<PrintSalesFindsModel> tempPrintSalesFindsModel = JSONArray.parseArray(tempJsonObject.getString("XSFL"), PrintSalesFindsModel.class);
        if (libraryPrintSalesFindsModel == null) {
            libraryPrintSalesFindsModel = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPrintSalesFindsModel)) {
            if (ListUtil.isEmpty(libraryPrintSalesFindsModel)) {
                libraryPrintSalesFindsModel.addAll(tempPrintSalesFindsModel);
            } else {
                boolean modelAdded;
                for (PrintSalesFindsModel tempModel : tempPrintSalesFindsModel) {
                    modelAdded = false;
                    for (PrintSalesFindsModel libraryModel : libraryPrintSalesFindsModel) {
                        if (TextUtils.equals(tempModel.fsexpclsname, libraryModel.fsexpclsname)) {
                            libraryModel.fdSpliteAmt = libraryModel.fdSpliteAmt.add(tempModel.fdSpliteAmt);
                            libraryModel.fdsaleamt = libraryModel.fdsaleamt.add(tempModel.fdsaleamt);
                            libraryModel.fdsaleqty = libraryModel.fdsaleqty.add(tempModel.fdsaleqty);
                            modelAdded = true;
                            break;
                        }
                    }

                    if (!modelAdded) {
                        libraryPrintSalesFindsModel.add(tempModel);
                    }
                }
            }

        }
        libraryObject.put("XSFL", libraryPrintSalesFindsModel);

        //SRFL
        List<PrintIncomeFindModel> libraryIncomeFindModels = JSONArray.parseArray(libraryObject.getString("SRFL"), PrintIncomeFindModel.class);
        List<PrintIncomeFindModel> tempIncomeFindModels = JSONArray.parseArray(tempJsonObject.getString("SRFL"), PrintIncomeFindModel.class);
        if (libraryIncomeFindModels == null) {
            libraryIncomeFindModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempIncomeFindModels)) {
            if (ListUtil.isEmpty(libraryIncomeFindModels)) {
                libraryIncomeFindModels.addAll(tempIncomeFindModels);
            } else {
                boolean modelAdded;
                for (PrintIncomeFindModel tempModel : tempIncomeFindModels) {
                    modelAdded = false;
                    for (PrintIncomeFindModel libraryModel : libraryIncomeFindModels) {
                        if (TextUtils.equals(tempModel.fsrevenuetypename, libraryModel.fsrevenuetypename)) {
                            libraryModel.fdSpliteAmt = libraryModel.fdSpliteAmt.add(tempModel.fdSpliteAmt);
                            libraryModel.fdsaleamt = libraryModel.fdsaleamt.add(tempModel.fdsaleamt);
                            libraryModel.fdsaleqty = libraryModel.fdsaleqty.add(tempModel.fdsaleqty);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryIncomeFindModels.add(tempModel);
                    }
                }
            }
        }
        libraryObject.put("SRFL", libraryIncomeFindModels);

        //takeOutList
        List<TakeOutModel> libraryTakeOutList = JSONArray.parseArray(libraryObject.getString("takeOutList"), TakeOutModel.class);
        List<TakeOutModel> tempTakeOutList = JSONArray.parseArray(tempJsonObject.getString("takeOutList"), TakeOutModel.class);

        if (libraryTakeOutList == null) {
            libraryTakeOutList = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempTakeOutList)) {
            if (ListUtil.isEmpty(libraryTakeOutList)) {
                libraryTakeOutList.addAll(tempTakeOutList);
            } else {
                boolean modelAdded;
                for (TakeOutModel tempModel : tempTakeOutList) {
                    modelAdded = false;
                    for (TakeOutModel libraryModel : libraryTakeOutList) {
                        if (TextUtils.equals(tempModel.fsBillSourceId, libraryModel.fsBillSourceId)) {
                            libraryModel.count = libraryModel.count + tempModel.count;
                            libraryModel.total = libraryModel.total.add(tempModel.total);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryTakeOutList.add(tempModel);
                    }
                }
            }
        }
        libraryObject.put("takeOutList", libraryTakeOutList);

        return libraryObject.toJSONString();

    }

    /**
     * 销售数量表
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealSaleCountList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //XSSL
        List<SalesAmountModel> libraryPaymentModels = JSONArray.parseArray(libraryObject.getString("XSSL"), SalesAmountModel.class);
        List<SalesAmountModel> tempPaymentModels = JSONArray.parseArray(tempJsonObject.getString("XSSL"), SalesAmountModel.class);
        if (libraryPaymentModels == null) {
            libraryPaymentModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPaymentModels)) {
            if (ListUtil.isEmpty(libraryPaymentModels)) {
                libraryPaymentModels.addAll(tempPaymentModels);
            } else {
                boolean modelAdded;
                for (SalesAmountModel tempModel : tempPaymentModels) {
                    modelAdded = false;
                    for (SalesAmountModel libraryModel : libraryPaymentModels) {
                        if (TextUtils.equals(tempModel.fsmenuclsname, libraryModel.fsmenuclsname)) {
                            if (!ListUtil.isEmpty(tempModel.MX)) {
                                boolean printModelAdded = false;
                                for (SalesAmountItemModel tempPrintModel : tempModel.MX) {
                                    for (SalesAmountItemModel libraryPrintModel : libraryModel.MX) {
                                        printModelAdded = false;
                                        if (TextUtils.equals(tempPrintModel.fsitemname, libraryPrintModel.fsitemname)) {
                                            libraryPrintModel.fdsaleqty = libraryPrintModel.fdsaleqty.add(tempPrintModel.fdsaleqty);
                                            libraryPrintModel.fdsaleamt = libraryPrintModel.fdsaleamt.add(tempPrintModel.fdsaleamt);
                                            libraryPrintModel.BF = libraryPrintModel.BF.add(tempPrintModel.BF);
                                            printModelAdded = true;
                                            break;
                                        }
                                    }
                                    if (!printModelAdded) {
                                        libraryModel.MX.add(tempPrintModel);
                                    }
                                }
                            }
                            libraryModel.HJ.fdsaleqty = libraryModel.HJ.fdsaleqty.add(tempModel.HJ.fdsaleqty);
                            libraryModel.HJ.fdsaleamt = libraryModel.HJ.fdsaleamt.add(tempModel.HJ.fdsaleamt);
                            libraryModel.HJ.fddiscountamt = libraryModel.HJ.fddiscountamt.add(tempModel.HJ.fddiscountamt);
                            libraryModel.HJ.SJ = libraryModel.HJ.SJ.add(tempModel.HJ.SJ);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryPaymentModels.add(tempModel);
                    }
                }
            }
            libraryObject.put("XSSL", libraryPaymentModels);
        }

        SalesAmountClsHJModel libraryHJ = JSON.parseObject(libraryObject.getString("HJ"), SalesAmountClsHJModel.class);
        SalesAmountClsHJModel tempHJ = JSON.parseObject(tempJsonObject.getString("HJ"), SalesAmountClsHJModel.class);
        if (libraryHJ == null) {
            libraryHJ = tempHJ;
        } else if (tempHJ != null) {
            libraryHJ.fdsaleqty = libraryHJ.fdsaleqty.add(tempHJ.fdsaleqty);
            libraryHJ.fdsaleamt = libraryHJ.fdsaleamt.add(tempHJ.fdsaleamt);
            libraryHJ.fddiscountamt = libraryHJ.fddiscountamt.add(tempHJ.fddiscountamt);
            libraryHJ.SJ = libraryHJ.SJ.add(tempHJ.SJ);
        }

        libraryObject.put("HJ", libraryHJ);


        Map<String, Integer> sourceNameMap = new HashMap<>();
        strDuplicateRemoval(sourceNameMap, libraryObject.getString("OrderSource"), "、");
        strDuplicateRemoval(sourceNameMap, tempJsonObject.getString("OrderSource"), "、");
        StringBuffer stringBuffer = new StringBuffer();
        for (String sourceName : sourceNameMap.keySet()) {
            stringBuffer.append(sourceName).append("、");
        }
        int index = stringBuffer.lastIndexOf("、");
        if (index > 0) {
            stringBuffer.deleteCharAt(index);
        }
        libraryObject.put("OrderSource", stringBuffer.toString());
        return libraryObject.toJSONString();

    }

    /**
     * 档口统计表
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealDeptList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //XSSL
        List<PrintReportDeptModel> libraryPaymentModels = JSONArray.parseArray(libraryObject.getString("XSSL"), PrintReportDeptModel.class);
        List<PrintReportDeptModel> tempPaymentModels = JSONArray.parseArray(tempJsonObject.getString("XSSL"), PrintReportDeptModel.class);
        if (libraryPaymentModels == null) {
            libraryPaymentModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPaymentModels)) {
            if (ListUtil.isEmpty(libraryPaymentModels)) {
                libraryPaymentModels.addAll(tempPaymentModels);
            } else {
                boolean modelAdded;
                for (PrintReportDeptModel tempModel : tempPaymentModels) {
                    modelAdded = false;
                    for (PrintReportDeptModel libraryModel : libraryPaymentModels) {
                        if (TextUtils.equals(tempModel.fsdeptname, libraryModel.fsdeptname)) {
                            libraryModel.fdsaleqty = libraryModel.fdsaleqty.add(tempModel.fdsaleqty);
                            libraryModel.fdsaleamt = libraryModel.fdsaleamt.add(tempModel.fdsaleamt);
                            libraryModel.fdDiscountAmt = libraryModel.fdDiscountAmt.add(tempModel.fdDiscountAmt);
                            libraryModel.BF = libraryModel.BF.add(tempModel.BF);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryPaymentModels.add(tempModel);
                    }
                }
            }
            libraryObject.put("XSSL", libraryPaymentModels);
        }

        SalesAmountClsHJModel libraryHJ = JSON.parseObject(libraryObject.getString("HJ"), SalesAmountClsHJModel.class);
        SalesAmountClsHJModel tempHJ = JSON.parseObject(tempJsonObject.getString("HJ"), SalesAmountClsHJModel.class);
        if (libraryHJ == null) {
            libraryHJ = tempHJ;
        } else if (tempHJ != null) {
            libraryHJ.fdsaleqty = libraryHJ.fdsaleqty.add(tempHJ.fdsaleqty);
            libraryHJ.fdsaleamt = libraryHJ.fdsaleamt.add(tempHJ.fdsaleamt);
            libraryHJ.fddiscountamt = libraryHJ.fddiscountamt.add(tempHJ.fddiscountamt);
            libraryHJ.SJ = libraryHJ.SJ.add(tempHJ.SJ);
        }

        libraryObject.put("HJ", libraryHJ);

        List<PrintDeptDetlModel> libraryDeptDtl = JSONArray.parseArray(libraryObject.getString("dtl"), PrintDeptDetlModel.class);
        List<PrintDeptDetlModel> tempDeptDtl = JSONArray.parseArray(tempJsonObject.getString("dtl"), PrintDeptDetlModel.class);
        if (libraryDeptDtl == null) {
            libraryDeptDtl = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempDeptDtl)) {
            if (ListUtil.isEmpty(libraryDeptDtl)) {
                libraryDeptDtl.addAll(tempDeptDtl);
            } else {
                boolean modelAdded;
                for (PrintDeptDetlModel tempModel : tempDeptDtl) {
                    modelAdded = false;
                    for (PrintDeptDetlModel libraryModel : libraryDeptDtl) {
                        if (TextUtils.equals(tempModel.fsDeptName, libraryModel.fsDeptName)) {
                            if (libraryModel.detl == null) {
                                libraryModel.detl = new ArrayList<>();
                                libraryModel.detl.addAll(tempModel.detl);
                            } else {
                                if (ListUtil.isEmpty(tempModel.detl)) {
                                    continue;
                                }
                                boolean printModelAdded = false;

                                for (PrintDeptDetlItemModel temp : tempModel.detl) {
                                    for (PrintDeptDetlItemModel library : libraryModel.detl) {
                                        printModelAdded = false;
                                        if (TextUtils.equals(temp.fsItemName, library.fsItemName)) {
                                            library.fdSaleQty = library.fdSaleQty.add(temp.fdSaleQty);
                                            library.fdSubTotal = library.fdSubTotal.add(temp.fdSubTotal);
                                            library.fdDiscountAmt = library.fdDiscountAmt.add(library.fdDiscountAmt);
                                            library.fdsaleamt = library.fdsaleamt.add(library.fdsaleamt);

                                            printModelAdded = true;
                                            break;
                                        }
                                    }
                                    if (!printModelAdded) {
                                        libraryModel.detl.add(temp);
                                    }
                                }
                            }

                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryDeptDtl.add(tempModel);
                    }
                }
            }
            libraryObject.put("dtl", libraryDeptDtl);
        }

        return libraryObject.toJSONString();

    }

    /**
     * 时段统计表
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealTimeList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //XSSL
        List<SalesAmountItemModel> libraryPaymentModels = JSONArray.parseArray(libraryObject.getString("XSSD"), SalesAmountItemModel.class);
        List<SalesAmountItemModel> tempPaymentModels = JSONArray.parseArray(tempJsonObject.getString("XSSD"), SalesAmountItemModel.class);
        if (libraryPaymentModels == null) {
            libraryPaymentModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPaymentModels)) {
            if (ListUtil.isEmpty(libraryPaymentModels)) {
                libraryPaymentModels.addAll(tempPaymentModels);
            } else {
                boolean modelAdded;
                for (SalesAmountItemModel tempModel : tempPaymentModels) {
                    modelAdded = false;
                    for (SalesAmountItemModel libraryModel : libraryPaymentModels) {
                        if (TextUtils.equals(tempModel.fsitemname, libraryModel.fsitemname)) {
                            libraryModel.fdsaleqty = libraryModel.fdsaleqty.add(tempModel.fdsaleqty);
                            libraryModel.fdsaleamt = libraryModel.fdsaleamt.add(tempModel.fdsaleamt);
                            libraryModel.BF = libraryModel.BF.add(tempModel.BF);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryPaymentModels.add(tempModel);
                    }
                }
            }
            libraryObject.put("XSSD", libraryPaymentModels);
        }

        return libraryObject.toJSONString();

    }

    /**
     * 微信外卖报表合并
     *
     * @param paramsLibrary
     * @param tempHtmlParas
     * @return
     */
    public static String dealWXORDERList(String paramsLibrary, String tempHtmlParas) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }

        JSONObject tempJsonObject = JSON.parseObject(tempHtmlParas);

        //XSSL
        List<WechatPayInfoModel> libraryPaymentModels = JSONArray.parseArray(libraryObject.getString("WXORDER"), WechatPayInfoModel.class);
        List<WechatPayInfoModel> tempPaymentModels = JSONArray.parseArray(tempJsonObject.getString("WXORDER"), WechatPayInfoModel.class);
        if (libraryPaymentModels == null) {
            libraryPaymentModels = new ArrayList<>();
        }
        if (!ListUtil.isEmpty(tempPaymentModels)) {
            if (ListUtil.isEmpty(libraryPaymentModels)) {
                libraryPaymentModels.addAll(tempPaymentModels);
            } else {
                boolean modelAdded;
                for (WechatPayInfoModel tempModel : tempPaymentModels) {
                    modelAdded = false;
                    for (WechatPayInfoModel libraryModel : libraryPaymentModels) {
                        if (TextUtils.equals(tempModel.payName, libraryModel.payName)) {
                            libraryModel.amt = libraryModel.amt.add(tempModel.amt);
                            modelAdded = true;
                            break;
                        }
                    }
                    if (!modelAdded) {
                        libraryPaymentModels.add(tempModel);
                    }
                }
            }
            libraryObject.put("WXORDER", libraryPaymentModels);
        }

        return libraryObject.toJSONString();

    }

    /**
     * 处理最高销售数量表数据
     *
     * @param saleStatisticsItemModels
     * @param tempDatas
     */
    private static void dealMaxSaleQuantity(List<SaleStatisticsItemModel> saleStatisticsItemModels, List<SaleStatisticsItemModel> tempDatas) {
        if (ListUtil.isEmpty(tempDatas)) {
            return;
        }
        boolean added;
        for (SaleStatisticsItemModel statisticsItemModel : tempDatas) {
            added = false;
            for (SaleStatisticsItemModel tempSaleModel : saleStatisticsItemModels) {
                if (TextUtils.equals(statisticsItemModel.fsitemname, tempSaleModel.fsitemname)) {
                    tempSaleModel.fdsaleqty = statisticsItemModel.fdsaleqty.add(tempSaleModel.fdsaleqty);
                    tempSaleModel.fdsaleamt = statisticsItemModel.fdsaleamt.add(tempSaleModel.fdsaleamt);
                    added = true;
                    break;
                }
            }
            if (!added) {
                saleStatisticsItemModels.add(statisticsItemModel);
            }
        }
    }

    public static String voidReportAdd(String paramsLibrary, String tempHtmlParas, boolean append) {
        return voidReportAdd(paramsLibrary,tempHtmlParas,append,false);
    }

    /**
     * isMergeArray 是否根据条目ID合并条目，前提是append = true
     * @param paramsLibrary
     * @param tempHtmlParas
     * @param append
     * @param isMergeArray
     * @return
     */
    public static String voidReportAdd(String paramsLibrary, String tempHtmlParas, boolean append,boolean isMergeArray) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        //将Object对象转换为JSONObject对象
        JSONObject libraryObject = JSON.parseObject(paramsLibrary);

        if (TextUtils.isEmpty(paramsLibrary)) {
            libraryObject = new JSONObject();
        }
        JSONObject jsonObject = JSON.parseObject(tempHtmlParas);
        //迭代
        Set<Map.Entry<String, Object>> entrySet = jsonObject.entrySet();
        for (Map.Entry entry : entrySet) {
            //将key值转换为字符串
            String key = (String) entry.getKey();
            //根据key获取对象
            Object object = jsonObject.get(key);
            if (libraryObject.get(key) == null) {
                libraryObject.put(key, object);
            } else {
                // 如果得到的是数组
                if (object instanceof JSONArray) {
                    //将Object对象转换为JSONObject对象
                    JSONArray objArray = (JSONArray) object;
                    JSONArray libraryArray = libraryObject.getJSONArray(key);
                    if (append) {
                        if(isMergeArray){
                            mergeArray(libraryArray,objArray);
                        }else{
                            libraryArray.addAll(objArray);
                        }
                    } else {
//                        dealJsonArray(libraryArray, objArray);
//                        libraryObject.put(key, libraryArray);
                    }
                } else if (object instanceof JSONObject) {// 如果key中是一个json对象
                    //调用回调方法
                    String values = voidReportAdd(libraryObject.getString(key), jsonObject.getString(key), append,isMergeArray);
                    libraryObject.put(key, JSON.parseObject(values));
                } else {
                    Object libraryValue = libraryObject.get(key);

                    if (object instanceof BigDecimal && libraryValue instanceof BigDecimal) {
                        BigDecimal libray = (BigDecimal) libraryValue;
                        libray = libray.add((BigDecimal) object);
                        libraryObject.put(key, libray);
                    } else if (object instanceof List && libraryValue instanceof List) {
                        List list = (List) libraryValue;
                        list.addAll((List) object);
                        libraryObject.put(key, list);
                    } else if (object instanceof Integer && libraryValue instanceof Integer) {
                        libraryObject.put(key, ((Integer) libraryValue) + ((Integer) object));
                    } else if (object instanceof Integer && libraryValue instanceof BigDecimal) {
                        BigDecimal libray = (BigDecimal) libraryValue;
                        libray = libray.add(new BigDecimal((Integer) object));
                        libraryObject.put(key, libray);
                    } else if (object instanceof BigDecimal && libraryValue instanceof Integer) {
                        BigDecimal libray = new BigDecimal((Integer) libraryValue);
                        libray = libray.add((BigDecimal) object);
                        libraryObject.put(key, libray);
                    } else {
                        libraryObject.put(key, object);
                        LogUtil.log(key + " - 未处理的值：" + object);
                    }
                }
            }
        }
        paramsLibrary = libraryObject.toString();
        paramsLibrary = paramsLibrary.replace("\\\"", "\"");
        return paramsLibrary;
    }

    /**
     * 合并列表里的数据，列表item的id字段相同则合并
     * 若列表item的id字段不存在，则是附加到列表
     * @param originalData
     * @param tempData
     */
    private static void mergeArray(JSONArray originalData,JSONArray tempData){
        if(originalData == null || tempData == null){
            return;
        }
        if(originalData.size() <= 0){
            originalData.addAll(tempData);
            return;
        }
        JSONArray newData = new JSONArray();
        for (int i = 0; i < tempData.size(); i++) {
            JSONObject tempObj = tempData.getJSONObject(i);
            if(tempObj == null){
                continue;
            }
            boolean isExist = false;
            for (int j = originalData.size() -1; j >= 0; j--) {
                JSONObject originalObj = originalData.getJSONObject(j);
                if(originalObj == null){
                    continue;
                }
                if(originalObj.containsKey("id")){
                    if(TextUtils.equals(originalObj.getString("id"),tempObj.getString("id"))){
                        String result = voidReportAdd(originalObj.toJSONString(),tempObj.toJSONString(),true,true);
                        originalData.remove(j);
                        originalData.add(JSON.parseObject(result));
                        isExist = true;
                        break;
                    }
                }
            }
            if(!isExist){
                newData.add(tempObj);
            }
        }
        if(newData.size() > 0){
            originalData.addAll(newData);
        }
    }

    public static String voidReportAddWithoutNode(String paramsLibrary, String tempHtmlParas, boolean append) {
        if (TextUtils.isEmpty(tempHtmlParas)) {
            return paramsLibrary;
        }

        JSONObject jsonObject = JSON.parseObject(tempHtmlParas);
        jsonObject.remove("ShiftList");
        jsonObject.remove("XSFL");
        jsonObject.remove("SRFL");
        jsonObject.remove("takeOutList");

        return voidReportAdd(paramsLibrary, jsonObject.toString(), append);
    }

    public static String getPreDate(String date) {
        return getSpecifiedDayBefore(date, "yyyy-MM-dd");
    }

    /**
     * 获得指定日期的前一天
     *
     * @param dateStr 指定日期
     * @param formart 格式
     * @return
     * @throws Exception
     */
    public static String getSpecifiedDayBefore(String dateStr, String formart) {
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat(formart).parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.setTime(date);
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day - 1);
        return new SimpleDateFormat(formart).format(c.getTime());
    }

    /**
     * 转化json->多put一个fisortorder
     *
     * @param jsonString
     * @return
     */
    private static String transferJson(String jsonString) {
        boolean isValid = true;
        JSONObject fullJson = JSON.parseObject(jsonString);
        if (fullJson == null) {
            isValid = false;
        }
        if (isValid) {
            JSONArray jsonArrayXSSL = JSONArray.parseArray(fullJson.getString("XSSL"));
            if (jsonArrayXSSL == null) {
                isValid = false;
            }
        }
        if (isValid) {
            JSONArray jsonArrayXSSL = JSONArray.parseArray(fullJson.getString("XSSL"));
            //---loop start-1---
            for (int i = 0; i < jsonArrayXSSL.size(); i++) {
                Object jsonArrayXSSLIndex = jsonArrayXSSL.get(i);
                if (jsonArrayXSSLIndex == null) {
                    continue;
                }
                JSONObject jsonObjectXSSL = JSONObject.parseObject(jsonArrayXSSLIndex.toString());
                if (jsonObjectXSSL == null) {
                    continue;
                }
                Object jsonObjectValue = jsonObjectXSSL.get("MX");
                if (jsonObjectValue == null) {
                    continue;
                }
                JSONArray jsonArrayMX = JSONArray.parseArray(jsonObjectValue.toString());
                if (jsonArrayMX == null) {
                    continue;
                }
                //---loop start-2---
                for (int j = 0; j < jsonArrayMX.size(); j++) {
                    Object jsonArrayMXIndex = jsonArrayMX.get(j);
                    if (jsonArrayMXIndex == null) {
                        continue;
                    }
                    JSONObject fullJsonValue = JSONObject.parseObject(jsonArrayMXIndex.toString());
                    if (fullJsonValue == null) {
                        continue;
                    }
                    if (fullJsonValue.containsKey("fisortorder")) {
                        if (!"0".equals(fullJsonValue.getString("fisortorder"))) {
                            continue;
                        }
                    }
                    String fisortorder = DailyReportDBUtil.querySortOrder(fullJsonValue.getString("fsMenuClsId"));
                    if (fisortorder == null) {
                        continue;
                    }
                    if (fisortorder.trim().length() > 10) {
                        continue;
                    }
                    int sortorderValue = Integer.valueOf(fisortorder.trim());
                    fullJsonValue.put("fisortorder", sortorderValue);
                    //覆盖原先的indexOfJsonArrayMX
                    jsonArrayMX.remove(j);
                    jsonArrayMX.add(j, fullJsonValue);
                }
                //---loop end-2---
                jsonObjectXSSL.put("MX", jsonArrayMX);
                //覆盖原先的MX
                jsonArrayXSSL.remove(i);
                jsonArrayXSSL.add(i, jsonObjectXSSL);
            }
            //---loop end-1---
            fullJson.put("XSSL", jsonArrayXSSL);
            if (fullJson != null) {
                return fullJson.toJSONString();
            }
        }
//            default return OriginJsonStr
        return jsonString;
    }

    /**
     * 套餐销量汇总数据
     * @param shopGUID
     * @param startDate
     * @param endDate
     * @param currentDate
     * @param billType
     * @return
     */
    public static Map<String, Object> queryBundleReport(String shopGUID, String startDate, String endDate, String currentDate,
                                                        int billType, String accountBookId, String sourceId, String sellType) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();
        String resule = "";

        if (supportThermalData(startDate, endDate, currentDate)) {
            //支持热数据查询，从订单中统计数据
            currentDateHtmlParams = DailyReportDBUtil.statisticBundleSale(startDate, billType, accountBookId);
            return currentDateHtmlParams;
        } else {
            //不支持热数据查询的从固化报表取数据
            if (TextUtils.equals(endDate, currentDate)) {
                //如果结束时间为当天则需要当天的查询热数据进行组装
                currentDateHtmlParams = DailyReportDBUtil.statisticBundleSale(endDate, billType, accountBookId);
                endDate = getPreDate(endDate);
            }

            if (!TextUtils.equals(startDate, currentDate)) {
                List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate,
                        ReportConsrance.REPORT_BUNDLE_SALE, billType, accountBookId);

                if (!ListUtil.isEmpty(reportSale)) {
                    for (DailyReportDBModel dailyReportDBModel : reportSale) {
                        resule = dealSaleCountList(resule, dailyReportDBModel.value);
                    }
                }
            }

            resule = dealSaleCountList(resule, JSON.toJSONString(currentDateHtmlParams));
        }
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 字符串去重
     * @param map
     * @param sourceStr
     */
    private static void strDuplicateRemoval(Map<String, Integer> map, String sourceStr, String regex) {
        if (null == map || TextUtils.isEmpty(sourceStr)) {
            return;
        }
        String[] s = sourceStr.split(regex);
        for (String str : s) {
            map.put(str, 0);
        }
    }


    /**
     * 查询分类/收入统计
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @param billType    账单类型
     * @param reportType  报表类型
     */
    public static Map<String, Object> queryClsReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId, String reportType) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        String resule = "";
        if (supportThermalData(startDate, endDate, currentDate)) {
            //支持热数据查询，从订单中统计数据
            currentDateHtmlParams = DailyReportDBUtil.statistiCls(startDate, billType, accountBookId, reportType);
        } else {
            //不支持热数据查询的从固化报表取数据
            if (TextUtils.equals(endDate, currentDate)) {
                //如果结束时间为当天则需要当天的查询热数据进行组装
                currentDateHtmlParams = DailyReportDBUtil.statistiCls(endDate, billType, accountBookId, reportType);
                endDate = getPreDate(endDate);
            }
            /* 他日的报表，直接查询存储的报表数据 */
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, startDate, endDate, reportType, billType, accountBookId);
            if (!ListUtil.isEmpty(reportSale)) {
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    String tempJson = dailyReportDBModel.value;
                    resule = dealSaleCountList(resule, tempJson);
                }
            }
        }
        String tempJson = JSON.toJSONString(currentDateHtmlParams);
        resule = dealSaleCountList(resule, tempJson);
        if (!TextUtils.equals(startDate, endDate)) {
            resule = countSaleNumPercent(resule);
        }
        return JSON.parseObject(resule, Map.class);
    }

    /**
     * 查询溢收明细
     *
     * @param shopGUID    shopID
     * @param startDate   起始日期
     * @param endDate     截止日期
     * @param currentDate 当前营业日期
     * @param billType    账单类型
     */
    public static Map<String, Object> querySurchargeDetailReport(String shopGUID, String startDate, String endDate, String currentDate, int billType, String accountBookId) {

        Map<String, Object> currentDateHtmlParams = new HashMap<>();

        if (supportThermalData(startDate, endDate, currentDate)) {
            //支持热数据查询，从订单中统计数据
            currentDateHtmlParams = DailyReportDBUtil.statistiSurchargeDetail(startDate, billType, accountBookId);
        } else {
            //不支持热数据查询的从固化报表取数据
            if (TextUtils.equals(endDate, currentDate)) {
                //如果结束时间为当天则需要当天的查询热数据进行组装
                currentDateHtmlParams = DailyReportDBUtil.statistiSurchargeDetail(endDate, billType, accountBookId);
                endDate = getPreDate(endDate);
            }
            List<DailyReportDBModel> reportSale = DailyReportDBUtil.queryReportHistoryOrderByDate(shopGUID, startDate, endDate, ReportConsrance.REPORT_SURCHARGE_DETAIL, billType, accountBookId);
            List<SurchargeDetailModel> surchargeDetailModelList = (List<SurchargeDetailModel>)currentDateHtmlParams.get("YSLIST");
            if (null == surchargeDetailModelList) {
                surchargeDetailModelList = new ArrayList<>();
                currentDateHtmlParams.put("YSLIST", surchargeDetailModelList);
            }
            SurchargeHJModel hj = (SurchargeHJModel) currentDateHtmlParams.get("HJ");
            if (null == hj) {
                hj = new SurchargeHJModel();
                currentDateHtmlParams.put("HJ", hj);
            }
            if (!ListUtil.isEmpty(reportSale)) {
                JSONObject obj;
                List<SurchargeDetailModel> tempList;
                SurchargeHJModel tempModel = null;
                for (DailyReportDBModel dailyReportDBModel : reportSale) {
                    obj = JSON.parseObject(dailyReportDBModel.value);
                    if (null != obj) {
                        tempList = JSONObject.parseArray(obj.getString("YSLIST"), SurchargeDetailModel.class);
                        if (null != tempList) {
                            surchargeDetailModelList.addAll(tempList);
                        }
                        tempModel = JSONObject.parseObject(obj.getString("HJ"), SurchargeHJModel.class);
                        if (null != tempModel) {
                            hj.surchargeHJ = hj.surchargeHJ.add(tempModel.surchargeHJ);
                        }

                    }
                }
            }
        }

        return currentDateHtmlParams;
    }


    /**
     * 是否支持热数据搜索，本地热数据只存储7天
     * @param startDate
     * @param endDate
     * @param currentDate
     * @return
     */
    private static boolean supportThermalData(String startDate, String endDate, String currentDate) {
        //热数据只支持单日查询
        if (!startDate.equals(endDate)) {
            return false;
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        long sTime, cTime;
        Date date;
        try {

            startDate = startDate.contains("-") ? startDate : DateUtil.formartDateStrToTarget(startDate,
                    "yyyyMMdd", "yyyy-MM-dd");
            endDate = startDate.contains("-") ? endDate : DateUtil.formartDateStrToTarget(endDate,
                    "yyyyMMdd", "yyyy-MM-dd");
            currentDate = startDate.contains("-") ? currentDate : DateUtil.formartDateStrToTarget(currentDate,
                    "yyyyMMdd", "yyyy-MM-dd");

            date = df.parse(startDate);
            sTime = date.getTime();
            date = df.parse(currentDate);
            cTime = date.getTime();
        } catch (Exception exp) {
           sTime = 0;
           cTime = 0;
        }

        if (sTime == 0) {
            if (TextUtils.equals(endDate, currentDate)) {
                return true;
            } else {
                return false;
            }
        }

        long maxDate = 60 * 60 * 24 * 7 * 1000;
        if (cTime - sTime >= maxDate) {
            return false;
        } else {
            return true;
        }
    }

}
