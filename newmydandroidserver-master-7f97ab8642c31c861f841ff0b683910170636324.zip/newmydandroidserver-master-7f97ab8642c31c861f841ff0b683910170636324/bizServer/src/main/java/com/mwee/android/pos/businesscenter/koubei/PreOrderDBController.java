package com.mwee.android.pos.businesscenter.koubei;

/**
 * Created by qinwei on 2018/5/16.
 */

public class PreOrderDBController {
    public final static int STATU_TAKE_ING = 1;
    public final static int STATU_TAKE_ERROR = 1;
    public final static int STATU_TAKE_DONE = 1;

    public static void addOrUpdate(String orderMessage) {

    }
}
