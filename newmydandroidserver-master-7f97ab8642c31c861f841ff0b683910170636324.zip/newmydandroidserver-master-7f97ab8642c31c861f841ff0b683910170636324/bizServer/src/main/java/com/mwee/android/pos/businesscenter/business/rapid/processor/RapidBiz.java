package com.mwee.android.pos.businesscenter.business.rapid.processor;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.rapid.api.bean.RapidActionRequset;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidBookOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidDiscountBean;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidEmployee;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrderItem;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrderItemBase;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrderModifier;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.api.bean.model.SourceType;
import com.mwee.android.pos.businesscenter.air.dbUtil.MenuItemDBUtils;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.koubei.KBAfterPayProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.future.KBFutureProcessor;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidAction;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidApi;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.driver.OrderDriver;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.TableQRProcess;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintFastFoodOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.model.MemberCouponModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardDetailsModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberCardInfoModel;
import com.mwee.android.pos.component.member.newInterface.model.NewMemberPlusCardInfoModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.MenuTerminal;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AskDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.MenuitemsetsidedtlDBModel;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.AskDBUtil;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.NoteItemModel;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.order.discount.CouponCutMoney;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.jsonfilter.RapidJsonFilter;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * 秒点秒付的业务处理类
 * Created by virgil on 2016/11/3.
 *
 * @author virgil
 */

public class RapidBiz {
    /**
     * 同步锁
     */
    private final static Object cacheLock = new Object();
    /**
     * 内存中缓存的commit处理结果，key为CommitID，value为RapidActionRequset；
     * 只缓存一定的时间
     */
    private final static ArrayMap<String, RapidActionRequset> commitHistory = new ArrayMap<>();
    /**
     * 是否有线程正在处理，key为CommitID，value为Object
     */
    private final static ArrayMap<String, Object> commitProcessing = new ArrayMap<>();

    /**
     * 收到XMPP推送的commitID
     *
     * @param commitID String
     */
    public static void receiveID(String commitID) {
        if (checkNeedGoNext(commitID)) {
            RapidApi.sendGetDetailByID(commitID);
        }
    }

    public static void receiveID(RapidGetModel model) {
        if (checkNeedGoNext(model.fsid)) {
            RapidApi.sendGetDetailByID(model);
        }
    }

    /**
     * 轮询到的接口，只处理秒付的推送，其他不处理
     *
     * @param model RapidGetModel
     */
    protected static void receiveLoop(final RapidGetModel model) {
        RunTimeLog.addLog(RunTimeLog.RAPID_START, "秒点监控 轮询 开始流程", model.fsid);

        if (!checkNeedGoNext(model.fsid)) {
            return;
        }
        switch (model.fsaction) {
            case RapidAction.PAY_ORDER:
            case RapidAction.KB_ORDER_NEW_COMPENSATE:
            case RapidAction.KB_FUTURE_PUSH_COMPENSATE:
            case RapidAction.KB_AFTER_PAY_NOTIFY_COMPENSATE:
                RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 是秒付且没有缓存，业务开始处理", model.fsid);
                RapidActionRequset requset = new RapidActionRequset();
                requset = RapidApi.buildActionRequest(requset, model);
                final String fsaction = requset.fsaction;
                BusinessExecutor.execute(requset, null, new BusinessCallback() {
                    @Override
                    public boolean success(int i, ResponseData responseData) {
                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
                        RapidBiz.prepareToRemoveCommitCache(model.fsid);
                        return true;
                    }

                    @Override
                    public boolean fail(int i, ResponseData responseData) {
                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
                        RapidBiz.prepareToRemoveCommitCache(model.fsid);
                        return false;
                    }
                }, true);

                break;
            case RapidAction.BOOK_ORDER:
                try {
                    RapidBookOrder payment = RapidApi.buildRapidBookOrder(model);
                    RapidApi.newBookOrder(payment);
                    RapidBiz.prepareToRemoveCommitCache(model.fsid);
                } catch (Exception e) {
                    LogUtil.logError("秒付轮询  先付异常 " + JSON.toJSONString(model), e);
                }
                break;

            default:
                break;
        }

//        if ((isActionPay(model) || isActionPreOrder(model) || isActionKBOrder(model)) && checkNeedGoNext(model.fsid)) {
//            if (isActionPay(model) || isActionKBOrder(model)) {
//                RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 是秒付且没有缓存，业务开始处理", model.fsid);
//                RapidActionRequset requset = new RapidActionRequset();
//                requset = RapidApi.buildActionRequest(requset, model);
//                final String fsaction = requset.fsaction;
//                BusinessExecutor.execute(requset, null, new BusinessCallback() {
//                    @Override
//                    public boolean success(int i, ResponseData responseData) {
//                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
//                        RapidBiz.prepareToRemoveCommitCache(model.fsid);
//                        return true;
//                    }
//
//                    @Override
//                    public boolean fail(int i, ResponseData responseData) {
//                        InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_PULL_ORDER_S, responseData.httpStatus == 200 ? "0" : "1");
//                        RapidBiz.prepareToRemoveCommitCache(model.fsid);
//                        return false;
//                    }
//                }, true);
//            } else if (isActionPreOrder(model)) {
//                try {
//                    RapidBookOrder payment = RapidApi.buildRapidBookOrder(model);
//                    RapidApi.newBookOrder(payment);
//                    RapidBiz.prepareToRemoveCommitCache(model.fsid);
//                } catch (Exception e) {
//                    LogUtil.logError("秒付轮询  先付异常 " + JSON.toJSONString(model), e);
//                }
//            }
//        }
    }

    /**
     * 是否需要处理当前的Commit，判断逻辑如下：
     * 1，是否已经有一个线程在处理，如果是，则中断；
     * 2，是否已经在内存中缓存了指定commitID的处理结果，如果是，则中断；
     * 3，如果已经在db中缓存了指定commitID的处理结果，如果是，则中断；
     *
     * @param commitID String
     * @return boolean | 是否需要进行处理业务：true：没有缓存，交由业务处理；false：有缓存或者在处理中，业务不需要进行处理
     */
    private static boolean checkNeedGoNext(String commitID) {
        RapidActionRequset requset = null;
        synchronized (cacheLock) {
            Object lock = commitProcessing.get(commitID);
            RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 lock 是否为空 : " + (lock == null), commitID);
            if (lock != null) {
                RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 已有线程在处理", commitID);
                return false;
            }
            requset = commitHistory.get(commitID);
            if (requset == null) {
                String lastCommitResult = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msgResult from push_msg_stack where msg='" + commitID + "'");
                try {
                    if (!TextUtils.isEmpty(lastCommitResult)) {
                        RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 已有缓存在DB中", commitID);
                        requset = JSON.parseObject(lastCommitResult, RapidActionRequset.class);
                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                }
            } else {
                RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 已有缓存在内存中", commitID);
            }
            if (requset == null) {
                commitProcessing.put(commitID, new Object());
                if (commitProcessing.get(commitID) == null) {
                    RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 commitProcessing put 失败", commitID);
                }
            }
        }
        if (requset != null) {
            RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 已有缓存，直接返回给服务端", commitID);
            BusinessExecutor.execute(requset, null, null, true);
            return false;
        }
        return true;
    }

    /**
     * 移除缓存{@link #commitProcessing}的处理中的commitID，
     *
     * @param commitid String
     */
    public static void removeProcessingCache(String commitid) {
        synchronized (cacheLock) {
            commitProcessing.remove(commitid);
            RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 commitProcessing remove ：" + commitid);
        }
    }

    /**
     * 移除缓存{@link #commitHistory}里所缓存的处理结果，
     *
     * @param commitid String
     */
    protected static void removeCommitHistoryCache(String commitid) {
        synchronized (cacheLock) {
            commitHistory.remove(commitid);
            RunTimeLog.addLog(RunTimeLog.RAPID_LOOP, "秒点监控 commitHistory remove ：" + commitid);
        }
    }

    /**
     * 缓存CommitID的结果到{@link #commitHistory}和DB中用于去重
     *
     * @param data          RapidGetModel | commitid的操作
     * @param requestAction RapidActionRequset | commitID的操作结果
     */
    public static void saveRapidCache(RapidGetModel data, final RapidActionRequset requestAction) {
        boolean save = false;
        //先判断是否需要缓存
        synchronized (cacheLock) {
            if (isActionCanBeCached(data)) {
                if (requestAction.fistate == 2) {
                    //只有成功才缓存结果
                    save = true;
                    commitHistory.put(requestAction.fsid, requestAction);
                }
            }
            RapidBiz.prepareToRemoveCommitCache(requestAction.fsid);
        }
        if (save) {
            RapidBiz.prepareToRemoveCommitCache(requestAction.fsid);
            BusinessExecutor.executeNoWait(new ASyncExecute() {
                @Override
                public Object execute() {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update push_msg_stack set msgResult='" + JSON.toJSONString(requestAction) + "' where msg='" + requestAction.fsid + "'");
                    return null;
                }
            });
        }
    }

    /**
     * 判断是否需要对CommitID的结果进行缓存
     *
     * @param data RapidGetModel | commitid的操作
     * @return boolean | true：需要进行缓存；false：不需要缓存
     */
    private static boolean isActionCanBeCached(RapidGetModel data) {
        //目前只处理下单和支付这两种情况
        return TextUtils.equals(data.fsaction, RapidAction.PAY_ORDER) || TextUtils.equals(data.fsaction, RapidAction.SUBMIT_ORDER);
    }

    /**
     * 是否是秒付
     *
     * @param data RapidGetModel
     * @return boolean
     */
    private static boolean isActionPay(RapidGetModel data) {
        return TextUtils.equals(data.fsaction, RapidAction.PAY_ORDER);
    }

    /**
     * 是否是预点单
     *
     * @param data RapidGetModel
     * @return boolean
     */
    private static boolean isActionPreOrder(RapidGetModel data) {
        return TextUtils.equals(data.fsaction, RapidAction.BOOK_ORDER);
    }

    /**
     * 是否是口碑订单
     * 目前处理的轮询业务仅仅限制口碑先付款新单 口碑后付款新单 以及口碑后付款支付通知
     * //todo 为了兼容老版本 后台开发沟通 需要加_compensate进行补偿机制处理
     *
     * @param data RapidGetModel
     * @return boolean
     */
    private static boolean isActionKBOrder(RapidGetModel data) {
        return TextUtils.equals(data.fsaction, RapidAction.KB_ORDER_NEW_COMPENSATE) || TextUtils.equals(data.fsaction, RapidAction.KB_FUTURE_PUSH_COMPENSATE) || TextUtils.equals(data.fsaction, RapidAction.KB_AFTER_PAY_NOTIFY_COMPENSATE);
    }

    /**
     * 秒点订单信息构建本地ordercache
     *
     * @param resultData
     * @param tempOrder
     * @param rapidOrder
     */
    public static String buildOrder(RapidActionModel resultData, TempOrderDishesCache tempOrder, RapidOrder
            rapidOrder) {
        String errorMsg;
        if (rapidOrder == null) {
            errorMsg = "秒点订单为空";
            buildResultError(resultData, errorMsg);
            writeRapidOrderError(resultData.fsid, tempOrder, "秒点订单为空");
            return errorMsg;
        }

        if (!SourceType.isPrePayFastfoodModel(rapidOrder.sourceType)) {

            /* 构建{餐区代码、餐桌代码、餐桌名称} */
            MtableDBModel table = TableDBUtil.getMTableById(rapidOrder.tableNo);
            if (table != null) {
                tempOrder.fsmtableid = table.fsmtableid;
                tempOrder.fsmareaid = table.fsmareaid;
                tempOrder.fsmtablename = table.fsmtablename;
            } else {
                errorMsg = "未查询到餐桌信息";
                buildResultError(resultData, errorMsg);
                writeRapidOrderError(resultData.fsid, tempOrder, "秒点订单，构建订单信息异常，未查询到餐桌信息，餐桌id[" + rapidOrder.tableNo + "]");
                return errorMsg;
            }
        }
        NoteItemModel noteOrder = buildOrderNote(rapidOrder.orderRemark);

        //开台预点菜
//        List<RapidOrderItem> openTableItemList = rapidOrder.openTableItemList;
//        if (!ListUtil.isEmpty(openTableItemList)) {
//            rapidOrder.itemList.addAll(rapidOrder.openTableItemList);
//        }

        //本地缓存菜品为空，桌台id不能为空，未开台 补充开台参数
        if (ListUtil.isEmpty(tempOrder.tempSelectedMenuList) && !TextUtils.isEmpty(rapidOrder.tableNo) && !TableDBUtil.isOpenStatus(rapidOrder.tableNo)) {
            if (!NetOrderType.isShareShopPrePay(rapidOrder.bizType)) {
                //非共享餐厅
                //添加开台参数
                List<MenuItem> localOpenTableMenuItems = OrderBizUtil.getOpenParamOrderMenu(tempOrder.fsmareaid, tempOrder.personNum, tempOrder.waiterID, tempOrder.waiterName);
                for (MenuItem local : localOpenTableMenuItems) {
                    local.addOrderNote(noteOrder);
                    local.terminal_id = MenuTerminal.CLOUDSITE;
                    local.fsBillSourceNo = rapidOrder.orderId;
                    tempOrder.tempSelectedMenuList.add(local);
                }
            }

        }
        //临时菜
        MenuitemDBModel bizTempMenu = null;
        if (NetOrderType.isShareShopPrePay(rapidOrder.bizType)) {
            bizTempMenu = MenuDBUtil.getTemporaryMenuDBModel();
            if (bizTempMenu == null) {
                //添加一个临时菜
                MenuItemDBUtils.addTemporaryMenuWZ(ServerCache.getInstance().shopID);
                bizTempMenu = MenuDBUtil.getTemporaryMenuDBModel();
            }
        }
        boolean forceTemporary = false;
        /* 构建{已选择菜品信息、订单总价} */
        List<RapidOrderItem> rapidArr = rapidOrder.itemList;
        if (!ListUtil.isEmpty(rapidArr)) {
            // 遍历构建菜品信息
            for (RapidOrderItem rapid : rapidArr) {
                if (rapid.isIngredient == 1) {
                    continue;
                }
                forceTemporary = false;
                MenuitemDBModel menuitem = null;
                if (TextUtils.isEmpty(rapid.supplierShopId) || !NetOrderType.isShareShopPrePay(rapidOrder.bizType)
                        || TextUtils.equals(rapid.supplierShopId, ServerCache.getInstance().shopID)) {
                    menuitem = MenuDBUtil.getUsefulMenuDBModelBy(rapid.outerItemId);
                }

                if (menuitem == null && bizTempMenu != null && NetOrderType.isShareShopPrePay(rapidOrder.bizType)) {
                    menuitem = bizTempMenu.clone();
                    forceTemporary = true;
                }
                if (menuitem != null) {
                    /* 构建菜品信息 */
                    MenuItem menu = MenuDBUtil.buildMenuByDBModel(menuitem, null, true);

                    if (menu == null) {
                        String convertMsg = "菜品[" + menuitem.fsItemName + "]没有规格";
                        buildResultError(resultData, convertMsg);
                        writeRapidOrderError(resultData.fsid, tempOrder, convertMsg);
                        return convertMsg;
                    }

                    if (menu.menuBiz == null) {
                        menu.menuBiz = new MenuBiz();
                    }

                    if (menuitem.fiIsEffectiveDate == 1) {
                        long startTime = DateTimeUtil.strToDate(menuitem.fsStarDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
                        long endTime = DateTimeUtil.strToDate(menuitem.fsEndDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
                        if (!MenuDBUtil.dataIsEffectiveDate(startTime, endTime, menuitem.fiIsEffectiveDate)) {
                            errorMsg = "菜品【" + menu.name + "】有效期为 " + menuitem.fsStarDate + "- " + menuitem.fsEndDate;
                            buildResultError(resultData, errorMsg);
                            writeRapidOrderError(resultData.fsid, tempOrder, errorMsg);
                            return errorMsg;
                        }
                    }
                    menu.menuBiz.buyNum = Calc.format(rapid.itemNum, RoundConfig.ROUND_QUANTITY,
                            RoundConfig.Decimal_ROUND_Type); // 修改数量
                    String convertMsg = "";
                    if (forceTemporary) {
                        convertMsg = convertTempMenuItem(resultData, menu, rapid);
                    } else {
                        convertMsg = convertMenuItem(resultData, menu, rapid);
                    }

                    if (!TextUtils.isEmpty(convertMsg)) {
                        writeRapidOrderError(resultData.fsid, tempOrder, convertMsg);
                        return convertMsg;
                    }

                    menu.menuBiz.generateUniq();
                    menu.terminal_id = MenuTerminal.CLOUDSITE;
                    menu.fsBillSourceNo = rapidOrder.orderId;

                    if (forceTemporary) {
                        menu.name = rapid.itemName + menu.name;
                        menu.name2 = rapid.itemName + menu.name;
                        menu.currentUnit.fdOriginPrice = menu.currentUnit.fdOriginPrice.add(rapid.itemPrice);
                        menu.currentUnit.fdSalePrice = menu.currentUnit.fdSalePrice.add(rapid.itemPrice);
//                        menu.currentUnit.fdVIPPrice = rapid.itemMemPrice;
                        menu.currentUnit.fdVIPPrice = menu.currentUnit.fdSalePrice.add(rapid.itemPrice);
                    }

                    if (!TextUtils.isEmpty(rapid.commitId)) {
                        menu.menuBiz.thirduniq = rapid.commitId;
                    }

                    if (menu.supportWeight()) {
                        /* 支持称重的菜品点菜数量做份数处理 */
                        menu.menuBiz.buyNum = BigDecimal.ZERO;
                        menu.addOrderNote(noteOrder);
                        menu.calcTotal(false);
                        for (int count = 0; count < rapid.itemNum.intValue(); count++) {
                            MenuItem addMenu = menu.clone();
                            addMenu.menuBiz.generateUniq();
                            tempOrder.tempSelectedMenuList.add(addMenu);
                        }
                    } else {
                        if (rapid.itemNum.compareTo(new BigDecimal(menu.currentUnit.fiInitCount)) < 0) {
                            String errMsg = "菜品[" + menuitem.fsItemName + "]起点[" + menu.currentUnit.fiInitCount + menu.currentUnit.fsOrderUint + "]";
                            buildResultError(resultData, errMsg);
                            writeRapidOrderError(resultData.fsid, tempOrder, errMsg);
                            return errMsg;
                        }

                        menu.addOrderNote(noteOrder);
                        menu.calcTotal(false); // 秒点订单不设会员

                        tempOrder.tempSelectedMenuList.add(menu);
                    }
                } else {
                    writeRapidOrderError(resultData.fsid, tempOrder, "秒点订单，构建菜品信息异常，未查询到菜品信息:[" + rapid.itemName + "," + rapid
                            .outerItemId + "]");
                }
            }
            if (!TextUtils.isEmpty(rapidOrder.placeOrderTime)) {
                tempOrder.tempCreateTime = rapidOrder.placeOrderTime;
            }


//            tempOrder.recalcTempQuantity();//菜品点菜数量 与点菜规格数量放在OrderDishesContainerFragment里面168行代码进行计算
            tempOrder.plusTempSelectedMenuAmount();
            tempOrder.isRapidTempOrderCache = true;
            //存储会员评论
            saveMemberComments(rapidOrder);
            //普通秒点，才需要存储会员信息
            if (rapidOrder.commentModel != null && !TextUtils.isEmpty(rapidOrder.commentModel.card_no) && NetOrderType.isRapid(tempOrder.thirdBizType)) {
                tempOrder.cardNo = rapidOrder.commentModel.card_no;
            }
            if (rapidOrder.bizType == 23) {  //预定单会员卡号及电话号码
                tempOrder.phone = rapidOrder.mobile;

            }

//            orderCache.plusAllMenuAmount(); // 计算订单总价
            if (!BaseConfig.isProduct()) {
                LogUtil.log("秒点新单，构建的订单信息:\n" + JSON.toJSONString(tempOrder));
            }
            return "";
        } else {
            errorMsg = "订单无菜品信息";
            buildResultError(resultData, errorMsg);
            writeRapidOrderError(resultData.fsid, tempOrder, "秒点订单无菜品信息");
            return errorMsg;
        }
    }

    private static void saveMemberComments(RapidOrder rapidorder) {
        if (rapidorder != null) {
            rapidorder.buildMemberComments();
            if (rapidorder.commentModel != null) {
                ServerCache.getInstance().putMemberComments(rapidorder.commentModel.card_no, rapidorder.commentModel);
            }
        }
    }

    /**
     * 构建整单备注
     *
     * @param originNote | String
     * @return NoteItemModel
     */
    private static NoteItemModel buildOrderNote(String originNote) {
        return NoteItemModel.createCustomeNote(originNote, 1, BigDecimal.ZERO);
    }

    /**
     * 秒点订单的菜品转化为本地OrderCache中存储的MenuItem-----临时菜
     *
     * @param resultData RapidActionModel
     * @param menu       MenuItem
     * @param rapid      RapidOrderItem
     */
    private static String convertTempMenuItem(RapidActionModel resultData, MenuItem menu, RapidOrderItem rapid) {
        StringBuilder stringBuilder = new StringBuilder();
        BigDecimal extraAmt = BigDecimal.ZERO;

        List<MenuItemUnitDBModel> unitArr = MenuDBUtil.getMenuUnitList(menu.itemID);
        if (ListUtil.isEmpty(unitArr)) {
            String unitId = MenuItemDBUtils.buidUnit(menu.itemID, "份", "1", "1", ServerCache.getInstance().shopID);
            //插入估清
            MenuItemDBUtils.buidSellOut(unitId, "份", menu.itemID, menu.name, "", BigDecimal.ZERO);
            unitArr = MenuDBUtil.getMenuUnitList(menu.itemID);
        }

        if (!ListUtil.isEmpty(unitArr)) {
            menu.currentUnit = UnitModel.copyTo(unitArr.get(0));
            menu.restoreCurrentUnit();
            if (unitArr.size() > 1) {
                menu.config = menu.config | 2;
            }
        } else {
            String errorMsg = "未查询到菜品规格";
            buildResultError(resultData, errorMsg);
            return "秒点王炸订单，构建菜品规格异常，菜品没有默认规格:[" + menu.name + ", " + menu.itemID + "]";
        }

        //构建配料菜
        if (!ListUtil.isEmpty(rapid.ingredients)) {
            for (RapidOrderItemBase temp : rapid.ingredients) {
                if (temp == null) {
                    continue;
                }
                stringBuilder.append(temp.name).append((temp.itemNum == null || temp.itemNum.compareTo(BigDecimal.ONE) <= 0) ? "" : "*" + Calc.format(temp.itemNum, 2).stripTrailingZeros()).append("(").append(temp.unit).append(")").append(";");
                extraAmt = extraAmt.add(temp.itemPrice.multiply(temp.itemNum));
            }
        }
        if (!ListUtil.isEmpty(rapid.modifiers)) {
            BigDecimal buyNum;
            String type = "";
            for (RapidOrderModifier temp : rapid.modifiers) {
                if (RapidOrderModifier.SET_MEAL == temp.isSet) {
                    buyNum = new BigDecimal(temp.modifierNum).divide(menu.menuBiz.buyNum, 3, BigDecimal.ROUND_HALF_UP).stripTrailingZeros();
                    stringBuilder.append(temp.modifierName);
                    if (!ListUtil.isEmpty(temp.modifiers)) {
                        stringBuilder.append("[");
                    }
                    if (!ListUtil.isEmpty(temp.modifiers)) {
                        for (RapidOrderModifier modifiers : temp.modifiers) {
                            stringBuilder.append(modifiers.modifierName).append((modifiers.modifierNum <= 0) ? "" : "*" + modifiers.modifierNum);
                            if (!TextUtils.isEmpty(modifiers.unit)) {
                                stringBuilder.append("(").append(modifiers.unit).append(")");
                            }
                            stringBuilder.append(";");
//                        extraAmt = extraAmt.add(modifiers.modifierPrice.multiply(new BigDecimal(modifiers.modifierNum)).multiply(buyNum));
                        }
                    }
                    if (!ListUtil.isEmpty(temp.modifiers)) {
                        stringBuilder.append("]");
                    }
                    stringBuilder.append((buyNum == null || buyNum.compareTo(BigDecimal.ONE) <= 0) ? "" : "*" + Calc.format(buyNum, 2).stripTrailingZeros());
                    if (!TextUtils.isEmpty(temp.unit)) {
                        stringBuilder.append("(").append(temp.unit).append(")");
                    }
                    stringBuilder.append(";");
                    extraAmt = extraAmt.add(temp.modifierPrice.multiply(buyNum));
                } else {
                    if (RapidOrderModifier.SPECIFICATION == temp.groupType) {
                        type = "规格";
                    } else if (RapidOrderModifier.PRACTICE == temp.groupType) {
                        /* 做法 */
                        type = "做法";
                    } else if (RapidOrderModifier.TASTE == temp.groupType
                            || RapidOrderModifier.ASK == temp.groupType
                    ) {
                        /* 口味、要求 */
                        type = "要求";
                    } else if (RapidOrderModifier.NOTE_CUSTOME == temp.groupType) {
                        type = "备注";
                    } else {
                        type = "其他";
                    }

                    buyNum = new BigDecimal(temp.modifierNum);
                    if (buyNum.compareTo(BigDecimal.ZERO) <= 0) {
                        buyNum = BigDecimal.ZERO;
                    }
                    buyNum = buyNum.divide(rapid.itemNum, 2);
                    stringBuilder.append(type).append(":").append(temp.modifierName).append((buyNum.compareTo(BigDecimal.ONE) <= 0) ? "" : "*" + buyNum.stripTrailingZeros()).append(";");
                    extraAmt = extraAmt.add(temp.modifierPrice);
                }
            }
        }

        menu.name = "";
        String remark = stringBuilder.toString().trim();
        if (!TextUtils.isEmpty(remark)) {
            if (remark.length() > 250) {
                remark = remark.substring(0, 247);
                remark += remark + "...";
            }
            menu.name = "(" + remark + ")";
        }

        menu.currentUnit.fdOriginPrice = extraAmt;
        menu.currentUnit.fdSalePrice = extraAmt;

        return "";
    }

    /**
     * 秒点订单的菜品转化为本地OrderCache中存储的MenuItem
     *
     * @param resultData RapidActionModel
     * @param menu       MenuItem
     * @param rapid      RapidOrderItem
     */
    private static String convertMenuItem(RapidActionModel resultData, MenuItem menu, RapidOrderItem rapid) {
        //构建配料菜
        if (!ListUtil.isEmpty(rapid.ingredients)) {
            for (RapidOrderItemBase temp : rapid.ingredients) {
                MenuitemDBModel menuitem = MenuDBUtil.getMenuDBModelByID(temp.outerItemId);
                if (menuitem != null) {
                    /* 构建菜品信息 */
                    MenuItem menuModifer = MenuDBUtil.buildMenuByDBModel(menuitem, null, true);
                    String convertMsg;
                    if (menuModifer == null) {
                        convertMsg = "菜品[" + menuitem.fsItemName + "]没有规格";
                        return convertMsg;
                    }
                    if (menuModifer.menuBiz == null) {
                        menuModifer.menuBiz = new MenuBiz();
                    }
                    menuModifer.menuBiz.generateUniq();
                    menuModifer.menuBiz.buyNum = temp.itemNum;
                    menuModifer.menuBiz.totalPrice = temp.itemPrice;
                    menuModifer.price = temp.itemPrice.divide(menuModifer.menuBiz.buyNum, 2);
                    menu.menuBiz.selectedModifier.add(menuModifer);
                }
            }
        }
        if (menu.supportPackage()) {
            return buildSet(resultData, menu, rapid);
        } else {
            // 构建规格信息
            return buildUnit(resultData, menu, rapid.modifiers);
        }

    }


    /**
     * 构建规格
     *
     * @param resultData RapidActionModel
     * @param menu       MenuItem 构建后的本地菜品
     * @param modifiers  List<RapidOrderModifier> |  菜品的modifiers
     */
    private static String buildUnit(RapidActionModel resultData, MenuItem menu, List<RapidOrderModifier> modifiers) {
        List<MenuItemUnitDBModel> unitArr = MenuDBUtil.getMenuUnitList(menu.itemID);
        if (!ListUtil.isEmpty(unitArr)) {
            menu.currentUnit = UnitModel.copyTo(unitArr.get(0));
            menu.restoreCurrentUnit();
            if (unitArr.size() > 1) {
                menu.config = menu.config | 2;
            }
            if (!ListUtil.isEmpty(modifiers)) {
                for (RapidOrderModifier modifier : modifiers) {
                    if (RapidOrderModifier.SPECIFICATION == modifier.groupType) {
                        /* 规格 */
                        MenuItemUnitDBModel unitDBModel = queryUnitById(modifier.outerModifierId);
                        if (unitDBModel == null) {
                            String errorMsg = "未查到菜品[" + menu.name + "]对应规格";
                            buildResultError(resultData, errorMsg);
                            return "秒点订单，构建菜品规格异常，未查到菜品[" + menu.name + ", " +
                                    menu.itemID + "]对应规格[" + modifier.modifierName + ", " +
                                    modifier.outerModifierId + "]";
                        } else {
                            menu.updateCurrentUnit(UnitModel.copyTo(unitDBModel));
                        }
                    } else if (RapidOrderModifier.PRACTICE == modifier.groupType) {
                        /* 做法 */
                        AskDBModel askDBModel = AskDBUtil.queryAskById(modifier.outerModifierId);
                        if (askDBModel == null) {
                            String errorMsg = "未查到菜品[" + menu.name + "]对应做法";
                            buildResultError(resultData, errorMsg);
                            return "秒点订单，构建菜品做法异常，未查到菜品[" + menu.name + ", " +
                                    menu.itemID + "]对应做法[" + modifier.modifierName + ", " +
                                    modifier.outerModifierId + "]";
                        } else {
                            // menu.updateCurrentPractice(askDBModel);
                            //pro2.5接入多做法
                            menu.menuBiz.selectMulProcedure.add(askDBModel);
                            menu.menuBiz.buildSelectMulProcedureString(menu.menuBiz.selectMulProcedure);
                        }
                    } else if (RapidOrderModifier.TASTE == modifier.groupType
                            || RapidOrderModifier.ASK == modifier.groupType) {
                        /* 口味、要求 */
                        NoteItemModel note = MenuDBUtil.buildNoteModelById(modifier.outerModifierId, menu.itemID);
                        if (note == null) {
                            String errorMsg = "未查到菜品[" + menu.name + "]对应要求";
                            buildResultError(resultData, errorMsg);
                            return "秒点订单，构建菜品要求异常，未查到菜品[" + menu.name + ", " +
                                    menu.itemID + "]对应要求[" + modifier.modifierName + ", " +
                                    modifier.outerModifierId + "]";
                        } else {
                            note.selected = true;
                            note.num = BigDecimal.ONE;
                            note.calcTotal();
                            menu.addNote(note);
                        }
                    } else if (RapidOrderModifier.NOTE_CUSTOME == modifier.groupType) {
                        NoteItemModel note = NoteItemModel.createCustomeNote(modifier.modifierName, 1, BigDecimal.ZERO);
                        if (note != null) {
                            menu.addNote(note);
                        }
                    }
                }
            }
        } else {
            String errorMsg = "未查询到菜品规格";
            buildResultError(resultData, errorMsg);
            return "秒点订单，构建菜品规格异常，菜品没有默认规格:[" + menu.name + ", " + menu.itemID + "]";
        }
        return "";
    }

    public static MenuitemsetsidedtlDBModel getPackageItemByUnitCd(String parentItemCD, String fiItemCD, String fiOrderUnitCd) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenuitemsetsidedtl where fiItemCD_M='" + parentItemCD + "' and fiItemCD='" + fiItemCD + "' and fiOrderUintCd='" + fiOrderUnitCd + "' and fiSetFoodCd in (select fiSetFoodCd from tbmenuitemsetside where fiStatus <> '13' and fiItemCd_M='" + parentItemCD + "' ) order by fistatus asc limit 1", MenuitemsetsidedtlDBModel.class);
    }

    /**
     * 构建套餐信息
     *
     * @param menu  构建后的本地菜品
     * @param rapid 秒点订单的菜品
     */
    private static String buildSet(RapidActionModel resultData, MenuItem menu, RapidOrderItem rapid) {
        if (menu.supportPackage()) {
//            List<MenuExtra> menuExtras = new ArrayList<>();
//            MenuExtra extra = new MenuExtra();
//            extra.type = MenuExtraType.PACKAGE;
            if (!ListUtil.isEmpty(rapid.modifiers)) {
                for (RapidOrderModifier temp : rapid.modifiers) {
                    if (RapidOrderModifier.SET_MEAL == temp.isSet) {
                        // TODO
                        MenuItem extraItem = new MenuItem();
                        extraItem.itemID = temp.modifierOuterItemId;
                        if (extraItem.menuBiz == null) {
                            extraItem.menuBiz = new MenuBiz();
                        }
                        extraItem.menuBiz.generateUniq();
                        MenuItemUnitDBModel unitDBModel = new MenuItemUnitDBModel();
                        unitDBModel.fiOrderUintCd = temp.spec;
                        MenuitemsetsidedtlDBModel dbItem = getPackageItemByUnitCd(menu.itemID, temp.outerModifierId, temp.spec);
                        if (dbItem != null) {
                            unitDBModel.fdVIPPrice = dbItem.fdVIPDifference;
                            unitDBModel.fdSalePrice = dbItem.fdIncrease;
                            unitDBModel.fsOrderUint = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsOrderUint from tbMenuItemUint where fiOrderUintCd = '" + temp.spec + "' and fiItemCd = '" + temp.outerModifierId + "' ");
                            extraItem.packSubID = dbItem.fiSetFoodCd;
                        }

                        if (TextUtils.isEmpty(unitDBModel.fsOrderUint)) {
                            unitDBModel.fsOrderUint = temp.unit;
                        }
                        //构建规则做法
                        if (!ListUtil.isEmpty(temp.modifiers)) {
                            buildUnit(resultData, extraItem, temp.modifiers);
                        }
                        extraItem.packID = menu.itemID;
                        extraItem.currentUnit = UnitModel.copyTo(unitDBModel);
                        extraItem.name = temp.modifierName;
                        extraItem.name2 = temp.modifierName;
                        extraItem.price = BigDecimal.ZERO;
                        extraItem.menuBiz.buyNum = new BigDecimal(temp.modifierNum).divide(menu.menuBiz.buyNum, 3, BigDecimal.ROUND_HALF_UP).stripTrailingZeros();
                        extraItem.menuBiz.createTime = DateUtil.getCurrentTime();
                        menu.menuBiz.selectedPackageItems.add(extraItem);

                    } else if (RapidOrderModifier.TASTE == temp.groupType
                            || RapidOrderModifier.ASK == temp.groupType) {
                        /* 口味、要求 */
                        NoteItemModel note = MenuDBUtil.buildNoteModelById(temp.outerModifierId, menu.itemID);
                        if (note == null) {
                            String errorMsg = "未查到菜品[" + menu.name + "]对应要求";
                            buildResultError(resultData, errorMsg);
                            return "秒点订单，构建菜品要求异常，未查到菜品[" + menu.name + ", " +
                                    menu.itemID + "]对应要求[" + temp.modifierName + ", " +
                                    temp.outerModifierId + "]";
                        } else {
                            note.selected = true;
                            note.num = BigDecimal.ONE;
                            note.calcTotal();
                            menu.addNote(note);
                        }
                    } else if (RapidOrderModifier.NOTE_CUSTOME == temp.groupType) {
                        NoteItemModel note = NoteItemModel.createCustomeNote(temp.modifierName, 1, BigDecimal.ZERO);
                        if (note != null) {
                            menu.addNote(note);
                        }
                    } else {
                        String errorMsg = "未查询到菜品规格";
                        buildResultError(resultData, errorMsg);
                        return "秒点订单，构建套餐配菜失败，已选的为配料:[" + menu.name + ", " + menu.itemID + "]";
                    }
                }
//                if (!ListUtil.isEmpty(extra.itemList)) {
//                    menuExtras.add(extra);
//                }
            } else {
                String errorMsg = "秒点订单，构建套餐配菜信息异常，未选配菜";
                buildResultError(resultData, errorMsg);
                return "秒点订单，构建套餐配菜信息异常，未选配菜:[" + menu.name + ", " + menu.itemID + "]";
            }
        }
        return "";
    }

    /**
     * 下单
     *
     * @param resultData RapidActionModel
     * @param order      TempOrderDishesCache
     */
    public static void order(RapidActionModel resultData, final TempOrderDishesCache order, RapidOrder rapidorder) {

        OrderCache orderCache = queryOrderByTable(order.fsmtableid);
        if (orderCache != null && NetOrderType.isKouBeiOrder(orderCache.thirdOrderType)) {
            //秒点下单到口碑先付款占用的桌台，秒点单直接被拒绝
            buildResultError(resultData, "桌台已有其他订单，如需下单，请联系服务员");
            MessageBiz.addRapidOrderMsg(order, MessageConstance.CATEGORY_ORDER, MessageConstance.MessageOrderBuinessStatus.RAPID.REFUSH, "桌台已有口碑先付款订单");
            //新增消息提醒
            NotifyToClient.receiveRapidOrderAndRefresh(order.fsmareaid, order.fsmtablename);
        } else {
            String isAutoOrder = CommonDBUtil.getConfigWithDefault(DBOrderConfig.AUTOMATIC_ORDER, "0");
            LogUtil.log("秒点来新订单喽" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT));
            if (TextUtils.equals(isAutoOrder, "1")) {  //自动下单

                order.isMember = rapidorder.needBuildMemberPrice();

                MenuItemVipPriceUtil.useCouponWhenBindMember(HostUtil.getShopID(), order.tempSelectedMenuList,
                        rapidorder.needBuildMemberPrice(), StringUtil.toInt(rapidorder.memberLevel),
                        "cash", rapidorder.memberId, rapidorder.plusId);
                if (order.isMember) {
                    order.mNewMemberCardModel = new NewMemberCardDetailsModel();
                    order.mNewMemberCardModel.cardInfo = new NewMemberCardInfoModel();
                    order.mNewMemberCardModel.cardInfo.card_no = rapidorder.memberCardno;
                    order.mNewMemberCardModel.cardInfo.level = StringUtil.toInt(rapidorder.memberLevel, -1);
                    order.mNewMemberCardModel.cardInfo.cs_id = rapidorder.memberId;
                    order.mNewMemberCardModel.plusCardInfo = new NewMemberPlusCardInfoModel();
                    order.mNewMemberCardModel.plusCardInfo.cp_id = rapidorder.plusId;
                } else {
                    order.mNewMemberCardModel = null;
                }

                order.plusTempSelectedMenuAmount();

                CouponCutMoney cut = OrderCache.checkCouponMoney(OrderUtil.initOrderCutList(HostUtil.getHistoryBusineeDate("")), order.tempSelectedMenuList, order.tempTotalPrice, OrderUtil.getSectionId(), false, order.isDiningStandard());
                if (cut != null) {
                    order.tempTotalPrice = order.tempTotalPrice.subtract(cut.fdCutmoney);
                }
                autoOrder(resultData, order, true);
            } else {
                artificialOrder(order);
            }
        }
    }

    /**
     * 秒点单进行下单
     *
     * @param resultData       RapidActionModel
     * @param tempOrder        TempOrderDishesCache | 订单信息
     * @param forceNoOpenParam boolean | 强制忽略开台预点菜品
     */
    protected static void autoOrder(final RapidActionModel resultData, final TempOrderDishesCache tempOrder, boolean forceNoOpenParam) {
        if (!TextUtils.isEmpty(updateRapidForAutoOrder(resultData, tempOrder))) {
            return;
        }

        final MtableDBModel table = TableDBUtil.getMTableById(tempOrder.fsmtableid);
        if (table == null) {
            RunTimeLog.addLog(RunTimeLog.RAPID_EXCEPTION, "秒点监控 自动下单，未找到相关桌台 tempOrder.fsmtableid = " + tempOrder.fsmtableid, resultData.fsid);
            return;
        }

        TableBizModel tableBizModel = TableDBUtil.optDefaultTableBizModel(table.fsmtableid);
        SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse;
        String orderID = "";
        OrderCache originOrder = RapidBiz.queryOrderById(tableBizModel.fssellno);
        if (originOrder != null) {
            socketResponse = new SocketResponse<>();
            // 桌台有订单时，校验餐标
            if (originOrder.isDiningStandard()) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = DinnerStandardUtil.ERROR_ON_DINING_STANDARD;
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 自动下单，校验餐标不通过，桌台订单：" + originOrder.orderID, resultData.fsid);
            } else {
                originOrder.thirdOrderType = tempOrder.thirdBizType;
                if (originOrder.shareShopOrder()) {
                    originOrder.whetherRound = false;
                }
                orderID = originOrder.orderID;
                ServerCache.getInstance().generateNewToken(originOrder.orderID);
                /* 本地已有订单，合并秒点单未下单菜品 */
                socketResponse.data = new OpenTableAndCheckToOrderRespose();
                OrderDriver.addMenu(socketResponse, HostBiz.cloudsite, originOrder.fsmtableid, originOrder.orderID, tempOrder, false);
            }
        } else {
            if (!forceNoOpenParam) {
                tempOrder.tempSelectedMenuList.addAll(OrderBizUtil.getOpenParamOrderMenu(tempOrder.fsmareaid, tempOrder.personNum, tempOrder.waiterID, tempOrder.waiterName));
            }
            socketResponse = new SocketResponse<>();
            JSONObject request = new JSONObject();
            request.put("shopId", HostUtil.getShopID());
            request.put("orderDishesCache", tempOrder);
            request.put("hostID", HostBiz.cloudsite);
            TableBusinessUtil.openTableAndOrder(socketResponse, HostBiz.cloudsite, request);
        }

        if (socketResponse.code == SocketResultCode.SUCCESS) {
            MessageOrderUtil.addRapidOrderMessage(tempOrder, MessageConstance.CATEGORY_ORDER, MessageConstance.MessageOrderBuinessStatus.RAPID.AUTO_ORDER);
            if (socketResponse.data.orderCache != null) {
                orderID = socketResponse.data.orderCache.orderID;
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("outerOrderId", orderID);
            resultData.resultBiz = jsonObject.toJSONString();
            rapidOrderSuccess(true, socketResponse.data.orderCache);
        } else if (socketResponse.code == SocketResultCode.DUPLICATE) {
            rapidOrderSuccess(false, socketResponse.data.orderCache);
        } else {
            if (socketResponse.code == SocketResultCode.ORDER_FAILED_SELL_OUT) {
                if (socketResponse.data != null && socketResponse.data.sellOutResult != null) {
                    buildSellOut(resultData, RapidResult.ERROR_SELL_OUT, socketResponse.message, socketResponse.data.sellOutResult);
                } else {
                    buildResultError(resultData, RapidResult.ERROR_SELL_OUT, socketResponse.message);
                }
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 已估清，菜品" + socketResponse.message, orderID, table.fsmtableid, resultData.fsid, "");
            } else {
                buildResultError(resultData, socketResponse.message);
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 秒点订单自动加菜失败[" + socketResponse.message + "]", orderID, table.fsmtableid, resultData.fsid, "");
            }
            revertTableRapidInfo(tempOrder.fsmtableid);
        }
        ServerCache.getInstance().releaseToken(orderID);
    }

    /**
     * 秒点快餐单进行下单
     *
     * @param resultData RapidActionModel
     * @param tempOrder  TempOrderDishesCache | 订单信息
     */
    protected static void rapidFastfoodOrder(final RapidActionModel resultData, final TempOrderDishesCache tempOrder, String mealNumber, String fsSellNo) {
        if (!TextUtils.isEmpty(updateRapidForAutoOrder(resultData, tempOrder))) {
            return;
        }
        UserDBModel userDBModel = new UserDBModel();
        userDBModel.fsUserName = tempOrder.waiterName;
        userDBModel.fsUserId = tempOrder.waiterID;

        String billSourceId = "99";
        if (APPConfig.isAir()) {
//            air3.7美小店单据调整,for detail see DBTable 'tbBillSource'
//            对于美小易来说没有没有秒点微信快餐,只有美小店,所以只需判断isAir()设定为'910'就够
            billSourceId = "910";
        }

        OrderCache orderCache = FastFoodBusinessUtil.createNewOrderCache(fsSellNo, tempOrder.waiterID, tempOrder.waiterName, HostBiz.cloudsite, billSourceId, 1);
        orderCache.thirdOrderId = tempOrder.thirdOrderID;
        orderCache.personNum = tempOrder.personNum;
        //前端所有未下单的菜
        List<MenuItem> itemList = tempOrder.tempSelectedMenuList;

        // 清除缓存中未下单的菜
        for (int i = 0; i < orderCache.originMenuList.size(); i++) {
            MenuItem item = orderCache.originMenuList.get(i);
            if (item != null && !item.hasAllVoid() && !orderCache.isOrderedSeqNo(item.menuBiz.orderSeqID)) {
                orderCache.originMenuList.remove(i);
                i--;
            }
        }

        //去重的逻辑
        List<MenuItem> currentOrderMenu = new ArrayList<>();
        currentOrderMenu.addAll(orderCache.originMenuList);
        for (int i = 0; i < currentOrderMenu.size(); i++) {
            MenuItem tempMenu = currentOrderMenu.get(i);
            for (int j = 0; j < itemList.size(); j++) {
                MenuItem temp = itemList.get(j);
                if (!TextUtils.isEmpty(tempMenu.menuBiz.uniq) && TextUtils.equals(tempMenu.menuBiz.uniq, temp.menuBiz.uniq)) {
                    //只要有一个菜是重复下的，就认为是重复订单
                    buildResultError(resultData, "该订单已处理，请勿重复提交");
                    FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);
                    return;
                }
            }
        }

        if (itemList.size() <= 0) {
            buildResultError(resultData, "该订单已处理，请勿重复提交");
            FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);
            return;
        }

        List<MenuItem> unOrderItems = new ArrayList<>();     //所有未下单的菜
        List<Integer> normalOrderSeqModel = new ArrayList<>();   //所有未下单的单序ID

        //给未下单的菜赋值下单时间，拆分配料菜
        for (int i = 0; i < itemList.size(); i++) {
            MenuItem menuItem = itemList.get(i);
            if (menuItem != null) {
                menuItem.updateOrderSeq(orderCache.currentSeq);
            }
            if (menuItem != null && !orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                menuItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                if (!menuItem.supportWeight() && menuItem.supportIngredient() && menuItem.menuBiz.selectedModifier.size() > 0 && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ONE) > 0) {
                    unOrderItems.addAll(menuItem.splitIngredientItem());
                } else {
                    unOrderItems.add(menuItem);
                }
                normalOrderSeqModel.add(menuItem.menuBiz.orderSeqID);
            }
        }

        if (!ListUtil.isEmpty(unOrderItems)) {
            for (MenuItem menuItem : unOrderItems) {
                if (orderCache.isMember) {
                    menuItem.useVipPrice("cash", "");
                }
            }
            orderCache.originMenuList.addAll(unOrderItems);
            //先检查估清
            SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(unOrderItems);
            if (!result.success) {
                buildResultError(resultData, RapidResult.ERROR_SELL_OUT, result.errorMsg);
                FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);
                return;
            }

            for (Integer i : normalOrderSeqModel) {
                orderCache.updateSeqStatus(i, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
            }

            //更新单序前先打印小票
            orderCache.currentSeq++;
            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.NORMAL, null, HostBiz.cloudsite);
            if (!TextUtils.isEmpty(mealNumber)) {
                orderCache.mealNumber = mealNumber;
            }
            orderCache.eatType = tempOrder.eatType;
            orderCache.eatTime = tempOrder.eatTime;
            orderCache.reCalcAllByAll();
            OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "rapidFastfoodOrder");
//            OrderProcessor.saveOrder(orderCache, null);

            //打印点菜单
            PrintFastFoodOrderUtil.printMenuList(orderCache, userDBModel, orderCache.currentSeq - 1, "", HostBiz.cloudsite);

            //打印制作单
//            PrintFastFoodOrderUtil.printMake(orderCache, userDBModel, orderCache.currentSeq - 1, HostBiz.cloudsite);
            if (DBOrderConfig.useKdsService() && DBOrderConfig.fastUseKdsService()) {//快餐KDS
                KdsManager.getInstance().order(orderCache, String.valueOf(orderCache.currentSeq - 1), HostBiz.cloudsite, userDBModel);
            } else {
                //打印传菜单
                PrintFastFoodOrderUtil.printPassTo(orderCache, userDBModel, "" + (orderCache.currentSeq - 1),
                        HostBiz.cloudsite, false, null, null);
                //打印制作单
                PrintFastFoodOrderUtil.printMake(orderCache, userDBModel, orderCache.currentSeq - 1, HostBiz.cloudsite);
            }

        }

        //更新快餐订单业务状态
        FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 1);
        FastFoodBusinessUtil.unLockOrderByOrderId(orderCache.orderID);

        // 下单成功
//        MessageOrderUtil.addRapidOrderMessage(tempOrder, MessageConstance.CATEGORY_ORDER, MessageConstance.MessageOrderBuinessStatus.RAPID.AUTO_ORDER);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("outerOrderId", orderCache.orderID);
        jsonObject.put("mealNumber", orderCache.mealNumber);
        resultData.resultBiz = jsonObject.toJSONString();

    }

    private static void rapidOrderSuccess(boolean print, OrderCache info) {
        if (print) {
            printConfirm(info);
        }
        revertTableRapidInfo(info.fsmtableid);
    }

    /**
     * 还原桌台的秒点相关的状态
     *
     * @param tableId 桌台id
     */
    private static void revertTableRapidInfo(String tableId) {
        TableBusinessUtil.cleanRapidOrder(tableId);
        NotifyToClient.refreshReceiveRapidOrder(tableId);
    }

    /**
     * 秒点自动下单，更新站点为cloudsite, 收银为 云收银
     *
     * @param resultData RapidActionModel
     * @param order      TempOrderDishesCache
     */
    private static String updateRapidForAutoOrder(RapidActionModel resultData, TempOrderDishesCache order) {
        order.currentHostID = HostBiz.cloudsite;
        UserDBModel userCash = getCloudUser();
        if (userCash != null) {
            order.waiterID = userCash.fsUserId;
            order.waiterName = userCash.fsUserName;
        } else {
            RunTimeLog.addLog(RunTimeLog.RAPID_EXCEPTION, "秒点监控 自动下单，未找到[fsStaffId = 'cash']的员工", resultData.fsid);
        }
        return "";
    }

    /**
     * 自动下单后打印
     *
     * @param orderCache OrderCache
     */
    private static void printConfirm(final OrderCache orderCache) {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public Object execute() {
//                OrderProcessor.saveOrder(orderCache, null);

                PrintOrderUtil.printRapidMenuList(orderCache, HostBiz.cloudsite);

                if (DBOrderConfig.useKdsService()) {
                    KdsManager.getInstance().order(orderCache, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", HostBiz.cloudsite, UserCache.getInstance().getCloudUser());
                } else {
                    PrintOrderUtil.printMakeOrder(orderCache, orderCache.currentHostID, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo);
                    PrintOrderUtil.printPassTo(orderCache, orderCache.currentHostID);
                }
                return null;
            }
        });
    }

    /**
     * 人工取单
     *
     * @param order 订单信息
     */
    private static void artificialOrder(TempOrderDishesCache order) {
        TableBusinessUtil.addNewRapidOrder(order);
        NotifyToClient.refreshReceiveRapidOrder(order.fsmtableid);
        //新增消息
        MessageOrderUtil.addRapidOrderMessage(order, MessageConstance.CATEGORY_ORDER, MessageConstance.MessageOrderBuinessStatus.RAPID.NONE);
    }

    /**
     * OrderCache转化RapidOrder
     *
     * @param rapidOrder RapidOrder
     * @param orderCache OrderCache
     */
    public static void convert(RapidOrder rapidOrder, OrderCache orderCache, List<MenuItem> tempSelectedMenuList) {
        if (orderCache == null) {
            return;
        }

//        rapidOrder.orderId = orderCache.orderID;
        rapidOrder.outerOrderId = orderCache.orderID;
        rapidOrder.orderSeq = String.valueOf(orderCache.currentSeq);
        rapidOrder.tableNo = orderCache.fsmtableid;
        rapidOrder.person = orderCache.personNum;
        rapidOrder.people = orderCache.personNum;

        //会员价重新计算一遍
        if (rapidOrder.needBuildMemberPrice()) {
            LogUtil.logBusiness("秒点秒付 拉单(" + rapidOrder.action + ", " + orderCache.orderID + ")：needBuildMemberPrice：" + rapidOrder.isVip + ", " + rapidOrder.memberCardno
                    + ", orderCache.member:: " + JSON.toJSONString(orderCache.memberInfoS));
            //当需要更新订单信息的时候需要读锁，已结账的订单不再更新
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "OrderCache转化RapidOrder");
            try {
                orderCache = OrderSession.getInstance().getOrder(orderCache.orderID);
                if (orderCache.orderStatus != OrderStatus.PAIED) {
                    boolean needNotify = !orderCache.isMember;
                    orderCache.updateOrderToMember(rapidOrder.memberCardno, StringUtil.toInt(rapidOrder.memberLevel), rapidOrder.memberId, rapidOrder.plusId);
// 2019-04-04 合并 pro3.5.2.547-->master-->pro3.5.3，保留 master 分支内容
//<<<<<<< HEAD
//                    orderCache.plusAllMenuAmount();
//                    //如果是秒付拉单，且开启了自动绑定会员，则直接绑定。或者秒点拉单时，自动绑定会员
//                    if ((RapidAction.isPullOrderByPay(rapidOrder.action) && DBPayConfig.rapidPayAutoBindMember())
//                            || (RapidAction.isPullOrderByOrder(rapidOrder.action))
//                            ) {
//                        LogUtil.logBusiness("秒付 拉单(" + rapidOrder.action + ", " + orderCache.orderID + ")：needBuildMemberPrice：自动绑定会员, " + rapidOrder.memberCardno);
//                        MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, "cash");
//=======

//<<<<<<< HEAD
//                    if (rapidOrder.isVipPrice != -1) {
//                        //强制刷新为会员价---中控开启了仅会员储值全额支付使用会员价，订单要强制刷成会员价
//                        if (DBMetaUtil.autoUseMemberPrice() || DBMetaUtil.autoUseVipDiscount()) {
//                            MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, "cash");
//                        } else {
//                            orderCache.updateAllMenuToMemberPrice("cash");
//                        }
//                    } else {
//                        //如果是秒付拉单，且开启了自动绑定会员，则直接绑定。或者秒点拉单时，自动绑定会员
//                        if ((RapidAction.isPullOrderByPay(rapidOrder.action) && DBPayConfig.rapidPayAutoBindMember())
//                                || (RapidAction.isPullOrderByOrder(rapidOrder.action))) {
//                            LogUtil.logBusiness("秒付 拉单(" + rapidOrder.action + ", " + orderCache.orderID + ")：needBuildMemberPrice：自动绑定会员, " + rapidOrder.memberCardno);
//                            MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, "cash");
//                        }
////>>>>>>> master
//=======
                    //如果是秒付拉单，且开启了自动绑定会员，则直接绑定。或者秒点拉单时，自动绑定会员
                    if ((RapidAction.isPullOrderByPay(rapidOrder.action) && DBPayConfig.rapidPayAutoBindMember())
                            || (RapidAction.isPullOrderByOrder(rapidOrder.action))) {
                        LogUtil.logBusiness("秒付 拉单(" + rapidOrder.action + ", " + orderCache.orderID + ")：needBuildMemberPrice：自动绑定会员, " + rapidOrder.memberCardno);
                        MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, "cash");
//>>>>>>> origin/pro3.5.2.547
                    }

                    orderCache.plusAllMenuAmount();

                    OrderSession.getInstance().writeOrder(orderCache.orderID, true, "OrderCache转化RapidOrder");
                    OrderProcessor.saveOrder(orderCache, null);
                    if (needNotify) {
                        NotifyToClient.refreshReceiveRapidOrder(orderCache.fsmtableid);
                    }
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "OrderCache转化RapidOrder");
            }
        }

        orderCache = orderCache.clone();
        if (!ListUtil.isEmpty(tempSelectedMenuList)) {
            orderCache.originMenuList.addAll(tempSelectedMenuList);
            orderCache.reCalcAllByAll();
        }

        if (rapidOrder.isVipPrice != -1 && rapidOrder.needBuildMemberPrice()) {
            //强制刷新为会员价---中控开启了仅会员储值全额支付使用会员价，订单要强制刷成会员价
            if (DBMetaUtil.autoUseMemberPrice() || DBMetaUtil.autoUseVipDiscount()) {
                MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, "cash");
            } else {
                orderCache.updateAllMenuToMemberPrice("cash");
            }
            orderCache.reCalcAllByAll();
        }

        BigDecimal cut = orderCache.optTotalSpecialCoupon();

        //会员模式下订单总价
        rapidOrder.originMemTotal = orderCache.totalPrice;

        rapidOrder.memTotal = orderCache.totalPrice;
        //秒点的订单总额和会员价保持一致
        rapidOrder.total = orderCache.totalPrice;

        rapidOrder.subTotal = orderCache.totalPrice;

        //计算出非会员价的待支付总金额
        if (orderCache.isMember) {
            rapidOrder.subTotal = optDeMemberNotPaymentAmt(orderCache, rapidOrder);
        }

        // 总可折扣金额
        rapidOrder.discountAmount = PayUtil.getDiscountAmtByOrderTotal(orderCache);
        // 需支付的可折扣金额 = 总可折扣金额
        rapidOrder.discountAmountPay = rapidOrder.discountAmount;

        rapidOrder.itemCount = orderCache.originMenuList.size();
        rapidOrder.orderRemark = orderCache.note;
        // 订单状态
        rapidOrder.orderStatus = orderCache.orderStatus;
        rapidOrder.fdServiceAmt = orderCache.totalService;
        PaySession paySession = OrderSession.getInstance().getPay(orderCache.orderID);

        if (paySession == null) {
            // 支付状态未支付
            rapidOrder.payStatus = 0;
            // 已支付金额 = 满减
            rapidOrder.paymentAmount = cut;
            // 未付金额 = 订单总额 - 满减
            rapidOrder.notPaymentAmount = orderCache.optTotalPrice().subtract(cut);

            // 待支付的可折扣金额 = 总可折扣金额
            rapidOrder.discountAmountPay = rapidOrder.discountAmount;
            // 如果 待支付的可折扣金额 > 总待支付金额，则 待支付可折扣金额 = 总待支付
            if (rapidOrder.notPaymentAmount.compareTo(rapidOrder.discountAmountPay) < 0) {
                rapidOrder.discountAmountPay = rapidOrder.notPaymentAmount;
            }
            // 需支付的不可折扣金额 = 总待支付 - 需支付的可折扣金额
            rapidOrder.nonDiscountAmountPay = rapidOrder.notPaymentAmount.subtract(rapidOrder.discountAmountPay);
            if (rapidOrder.nonDiscountAmountPay.compareTo(BigDecimal.ZERO) < 0) {
                rapidOrder.nonDiscountAmountPay = BigDecimal.ZERO;
            }
        } else {

            OrderUtil.buildPayCache(paySession, orderCache, paySession.billNO, paySession.currentHostID, paySession.waiterID, paySession.waiterName);
            rapidOrder.paymentAmount = orderCache.optTotalPrice().subtract(paySession.priceLeftToPay);
            rapidOrder.notPaymentAmount = paySession.priceLeftToPay;

            //获取剩余待支付的可折扣金额
            rapidOrder.discountAmountPay = PayUtil.getDiscountAmtByLeftToPay(paySession, orderCache);
            //剩余待支付的可折扣金额
            if (rapidOrder.notPaymentAmount.compareTo(rapidOrder.discountAmountPay) < 0) {
                rapidOrder.discountAmountPay = rapidOrder.notPaymentAmount;
            }
            rapidOrder.nonDiscountAmountPay = rapidOrder.notPaymentAmount.subtract(rapidOrder.discountAmountPay);
            if (rapidOrder.nonDiscountAmountPay.compareTo(BigDecimal.ZERO) < 0) {
                rapidOrder.nonDiscountAmountPay = BigDecimal.ZERO;
            }
            if (rapidOrder.paymentAmount.compareTo(BigDecimal.ZERO) <= 0) {
                // 支付状态未支付
                rapidOrder.payStatus = 0;
            } else if (paySession.priceLeftToPay.compareTo(BigDecimal.ZERO) <= 0) {
                rapidOrder.payStatus = 2;
            } else {
                if (NetOrderType.isRapidPrePay(rapidOrder.bizType) || NetOrderType.isShareShopPrePay(rapidOrder.bizType)) {
                    rapidOrder.payStatus = 1;
                } else {
                    rapidOrder.payStatus = 1;
                }
            }
        }

        rapidOrder.discountAmountPay = rapidOrder.discountAmountPay.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : rapidOrder.discountAmountPay;
        rapidOrder.nonDiscountAmountPay = rapidOrder.nonDiscountAmountPay.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : rapidOrder.nonDiscountAmountPay;
        rapidOrder.notPaymentAmount = rapidOrder.notPaymentAmount.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : rapidOrder.notPaymentAmount;

        //开台员工
        RapidEmployee rapidEmployee = optOpenTableEmployee(orderCache.fsmtableid, orderCache.orderID);
        if (rapidEmployee != null) {
            rapidOrder.employeeList.add(rapidEmployee);
        }

        //秒点服务费
        if (!orderCache.checkFreeFee() && orderCache.totalService != null && orderCache.totalService.compareTo(BigDecimal.ZERO) > 0) {
            RapidDiscountBean bean = new RapidDiscountBean();
            bean.disMoney = orderCache.totalService.multiply(new BigDecimal("-1"));
            bean.disName = "服务费";
            rapidOrder.disInfoList.add(bean);
        }

        //秒付二维码
        rapidOrder.qRCodeUrl = TableQRProcess.optTableQR(rapidOrder.tableNo);
        rapidOrder.isShowQRCode = DBPrintConfig.needPrintRapidQR() ? 1 : 0;
        rapidOrder.qrCodeTitle = DBPrintConfig.optRapidQRNote();

        rapidOrder.memTotal = rapidOrder.notPaymentAmount;
        //秒点的订单总额和会员价保持一致
        rapidOrder.total = rapidOrder.notPaymentAmount;

        if (!orderCache.isMember) {
            rapidOrder.subTotal = rapidOrder.notPaymentAmount;
            rapidOrder.originTotal = rapidOrder.originMemTotal;
            rapidOrder.originDiscountAmount = rapidOrder.discountAmountPay;
            rapidOrder.originNonDiscountAmount = rapidOrder.nonDiscountAmountPay;
        }
    }

    /**
     * 获取订单非会员价待支付总金额
     *
     * @return
     */
    private static BigDecimal optDeMemberNotPaymentAmt(TempOrderDishesCache tempOrder, RapidOrder rapidOrder) {
        if (tempOrder == null) {
            return BigDecimal.ZERO;
        }
        TempOrderDishesCache clone = tempOrder.clone();
        clone.isMember = false;

        if (!clone.tempSelectedMenuList.isEmpty()) {
            for (MenuItem item : clone.tempSelectedMenuList) {
                item.cleanMemberInfo();
                item.menuBiz.decreasConfig(512);
            }
        }
        clone.plusTempSelectedMenuAmount();
        BigDecimal amt = clone.tempTotalPrice;
        if (amt.compareTo(BigDecimal.ZERO) < 0) {
            amt = BigDecimal.ZERO;
        }
        LogUtil.log("仅储值支付", "非会员原价" + amt.toPlainString());

        //非会员模式下订单总价
        rapidOrder.originTotal = amt;

        //非会员模式下订单待支付的可折扣金额
        rapidOrder.originDiscountAmount = PayUtil.getDiscountAmtByOrderTotal(clone);

        rapidOrder.originNonDiscountAmount = amt.subtract(rapidOrder.originDiscountAmount);
        if (rapidOrder.originNonDiscountAmount.compareTo(BigDecimal.ZERO) < 0) {
            rapidOrder.originNonDiscountAmount = BigDecimal.ZERO;
        }

        LogUtil.log("仅储值支付", "非会员价待支付总金额： " + amt.toPlainString());
        rapidOrder.subTotal = amt;
        return amt;
    }

    /**
     * 获取订单非会员价待支付总金额
     *
     * @return
     */
    private static BigDecimal optDeMemberNotPaymentAmt(OrderCache orderCache, RapidOrder rapidOrder) {

        OrderCache clone = orderCache.clone();
        clone.clearMember();
        clone.clearAllMemberDiscount(true);
        clone.plusAllMenuAmount();

        BigDecimal amt = clone.optTotalPrice();
        if (amt == null || amt.compareTo(BigDecimal.ZERO) < 0) {
            amt = BigDecimal.ZERO;
        }

        //非会员模式下订单总价
        rapidOrder.originTotal = amt;

        //满减金额
        BigDecimal cut = clone.optTotalSpecialCoupon();


        PaySession paySession = OrderSession.getInstance().getPay(orderCache.orderID);

        if (paySession != null) {
            OrderUtil.buildPayCache(paySession, clone, paySession.billNO, paySession.currentHostID, paySession.waiterID, paySession.waiterName);
            amt = amt.subtract(OrderUtil.recalTotalPaiedAmount(paySession.selectPayListFull));

            //获取剩余待支付的可折扣金额 = 总可折扣金额-已抵扣的可折扣的金额
            rapidOrder.originDiscountAmount = PayUtil.getDiscountAmtByLeftToPay(paySession, clone);
            //剩余待支付的可折扣金额
            if (amt.compareTo(rapidOrder.originDiscountAmount) < 0) {
                rapidOrder.originDiscountAmount = amt;
            }

            //非会员模式下订单待支付的不可折扣金额 = 待支付金额-可折扣金额
            rapidOrder.originNonDiscountAmount = amt.subtract(rapidOrder.originDiscountAmount);
            if (rapidOrder.originNonDiscountAmount.compareTo(BigDecimal.ZERO) < 0) {
                rapidOrder.originNonDiscountAmount = BigDecimal.ZERO;
            }

        } else {
            //非会员模式下订单待支付的可折扣金额
            rapidOrder.originDiscountAmount = PayUtil.getDiscountAmtByOrderTotal(clone);

            rapidOrder.originNonDiscountAmount = amt.subtract(cut).subtract(rapidOrder.originDiscountAmount);
            if (rapidOrder.originNonDiscountAmount.compareTo(BigDecimal.ZERO) < 0) {
                rapidOrder.originNonDiscountAmount = BigDecimal.ZERO;
            }
        }

        if (amt.compareTo(BigDecimal.ZERO) < 0) {
            amt = BigDecimal.ZERO;
        }

        rapidOrder.subTotal = amt;

        LogUtil.log("仅储值支付", "非会员价待支付总金额： " + rapidOrder.subTotal.toPlainString()
                + "； 待支付可折扣金额：" + rapidOrder.originDiscountAmount.toPlainString()
                + "; 待支付不可折扣金额：" + rapidOrder.originNonDiscountAmount.toPlainString());
        return amt;
    }


    /**
     * 获取开台人信息
     *
     * @param fsmtableId 桌台ID
     * @param orderId    订单号
     * @return
     */
    public static RapidEmployee optOpenTableEmployee(String fsmtableId, String orderId) {
        if (TextUtils.isEmpty(fsmtableId)) {
            return null;
        }
        RapidEmployee rapidEmployee = new RapidEmployee();
        JSONObject jsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select fsopenusername, fsupdateuserid from tableBiz where fsmtableId = '" + fsmtableId + "' and fsmtablesteid = '2' and fssellno = '" + orderId + "'");
        if (jsonObject == null || TextUtils.isEmpty(jsonObject.getString("fsupdateuserid"))) {
            return null;
        }
        rapidEmployee.action = "开台";
        rapidEmployee.empName = jsonObject.getString("fsopenusername");
        rapidEmployee.empNo = jsonObject.getString("fsupdateuserid");
        return rapidEmployee;
    }

    /**
     * 构建菜品Model
     * http://wiki.mwbyd.cn/pages/viewpage.action?pageId=23005576
     *
     * @param menuItem             MenuItem
     * @param shopID               String | 门店ID
     * @param kitchenStatus        int | 是否已下厨
     * @param needBuildMemberPrice boolean | 是否需要构建会员价
     * @return RapidOrderItem | 秒点的菜品Model
     */
    public static RapidOrderItem buildRapidItemByMenuItem(MenuItem menuItem, String shopID, int kitchenStatus, boolean needBuildMemberPrice) {
        if (menuItem.hasAllVoid()) {
            return null;
        }
        RapidOrderItem item = new RapidOrderItem();
//        item.itemId = menuItem.itemID;
        item.itemCode = menuItem.itemID;
        item.outerItemId = menuItem.itemID;
        item.orderDetailId = menuItem.itemID;
        item.itemName = menuItem.name;
        item.commitId = menuItem.menuBiz.thirduniq;

        // itemNum指份数，qry指重量
        if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(menuItem.menuBiz.voidNum) > 0) {
            item.itemNum = BigDecimal.ONE;
        } else {
            item.itemNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
        }
        item.qty = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);

        BigDecimal calcNum = item.itemNum;
        if (menuItem.supportWeight()) {
            calcNum = item.qty;
        }
        if (menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
            calcNum = BigDecimal.ONE;
        }
        if (calcNum.compareTo(BigDecimal.ZERO) <= 0) {
            calcNum = BigDecimal.ONE;
        }
        item.itemPrice = menuItem.menuBiz.totalPrice.divide(calcNum, 2);
        item.itemMemPrice = item.itemPrice;

        if (needBuildMemberPrice) {

            if (menuItem.useMemberPrice) {
                //先还原为普通价
                menuItem.useMemberPrice = false;
                menuItem.calcTotal(false);
                item.itemPrice = menuItem.menuBiz.totalPrice.divide(calcNum, 2);

                menuItem.useMemberPrice = true;
                menuItem.calcTotal(true);
                item.itemMemPrice = menuItem.menuBiz.totalPrice.divide(calcNum, 2);
            }

        }

        LogUtil.logBusiness("秒点秒付 构建菜品(" + menuItem.itemID + ", " + menuItem.name + ")：needBuildMemberPrice: " + needBuildMemberPrice + ", totalPrice: " + menuItem.menuBiz.totalPrice + ", itemPrice: " + item.itemPrice);

        item.itemType = 1;

        item.isWeigh = menuItem.supportWeight() ? 1 : 0;
        item.kitchen = kitchenStatus;
        item.ficheckpass = 1;
        //如果时价菜未改价
        if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0) {
            item.ficheckpass = 0;
        }
        MenuclsDBModel menucls = MenuDBUtil.getMenuClsByMenuID(shopID, menuItem.itemID);
        if (menucls == null) {
            RunTimeLog.addLog(RunTimeLog.RAPID_EXCEPTION, "秒点监控 未查询到菜品分类, 菜品代码", "", menuItem.itemID);
        } else {
            item.outerCatId = menucls.fsMenuClsId;
            item.categoryId = menucls.fsMenuClsId;
            item.catName = menucls.fsMenuClsName;
        }
        if (item.modifiers == null) {
            item.modifiers = new ArrayList<>();
        }

        //新的拉单加价功能放到2.9里
        item.modifiers.addAll(optRapidOrderModifier(menuItem));
        //处理规格
        if (!menuItem.supportPackage()) {
            item.itemType = 1;
            item.unit = menuItem.currentUnit.fsOrderUint;
        } else {
            item.itemType = 3;
        }
        /*//处理规格
        if (!menuItem.supportPackage()) {
            RapidOrderModifier modifier = new RapidOrderModifier();
            modifier.groupType = RapidOrderModifier.SPECIFICATION;
            modifier.isSet = RapidOrderModifier.INGREDIENTS;
            modifier.outerModifierId = String.valueOf(menuItem.currentUnit.fiOrderUintCd);
            modifier.modifierName = menuItem.currentUnit.fsOrderUint;
            modifier.operateNum = 1;
//            modifier.totalModifierPrice = menuItem.menuBiz.priceExtraTotal;
            item.unit = menuItem.currentUnit.fsOrderUint;
            modifier.spec = menuItem.currentUnit.fiOrderUintCd;
            item.modifiers.add(modifier);
        } else {
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
                List<RapidOrderModifier> modifierList = new ArrayList<>();
                for (MenuItem packageItem : menuItem.menuBiz.selectedPackageItems) {
                    RapidOrderModifier modifier = new RapidOrderModifier();
                    modifier.groupType = RapidOrderModifier.GENERAL;
                    modifier.isSet = RapidOrderModifier.SET_MEAL;
                    modifier.outerModifierId = packageItem.itemID + "";
                    modifier.modifierName = packageItem.name;
                    modifier.operateNum = packageItem.menuBiz.buyNum.intValue();
                    modifier.modifierNum = packageItem.menuBiz.buyNum.intValue();
                    modifier.outerModifierTypeId = "";
//                    modifier.totalModifierPrice = BigDecimal.ZERO;
//                    modifier.modifierPrice = BigDecimal.ZERO;
                    modifier.spec = packageItem.currentUnit.fiOrderUintCd;
                    modifier.unit = packageItem.currentUnit.fsOrderUint;
                    modifierList.add(modifier);
                }
                if (!ListUtil.isEmpty(modifierList)) {
                    item.modifiers.addAll(modifierList);
                }
            }
        }

        //处理做法
        if (menuItem.currentPractice != null) {
            RapidOrderModifier procedure = new RapidOrderModifier();
            procedure.groupType = RapidOrderModifier.PRACTICE;
            procedure.isSet = RapidOrderModifier.INGREDIENTS;
            procedure.outerModifierId = String.valueOf(menuItem.currentPractice.fiId);
            procedure.modifierName = menuItem.currentPractice.fsAskName;
            procedure.operateNum = 1;
            procedure.outerModifierTypeId = menuItem.currentPractice.fsAskGpId;
//            procedure.totalModifierPrice = menuItem.currentPractice.fdAddPrice;
//            procedure.modifierPrice = menuItem.currentPractice.fdAddPrice;
            item.modifiers.add(procedure);
        }
        //pro 2.5 多做法处理
        if (menuItem.menuBiz.selectMulProcedure.size() > 0) {
            for (AskDBModel askDBModel : menuItem.menuBiz.selectMulProcedure) {
                RapidOrderModifier procedure = new RapidOrderModifier();
                procedure.groupType = RapidOrderModifier.PRACTICE;
                procedure.isSet = RapidOrderModifier.INGREDIENTS;
                procedure.outerModifierId = String.valueOf(askDBModel.fiId);
                procedure.modifierName = askDBModel.fsAskName;
                procedure.operateNum = 1;
                procedure.outerModifierTypeId = askDBModel.fsAskGpId;
//                procedure.totalModifierPrice = askDBModel.fdAddPrice;
//                procedure.modifierPrice = askDBModel.fdAddPrice;
                item.modifiers.add(procedure);
            }

        }


        //处理菜品要求
        if (menuItem.menuBiz.selectNote != null && menuItem.menuBiz.selectNote.size() > 0) {
            for (NoteItemModel temp : menuItem.menuBiz.selectNote) {
                //目前套餐仅支持固定价格
                if (temp.selected && temp.totalPrice.compareTo(BigDecimal.ZERO) > 0) {
                    RapidOrderModifier selectAsk = new RapidOrderModifier();
                    selectAsk.groupType = RapidOrderModifier.TASTE;
                    selectAsk.isSet = RapidOrderModifier.INGREDIENTS;
                    selectAsk.outerModifierId = String.valueOf(temp.id);
                    selectAsk.modifierName = temp.name;
                    selectAsk.operateNum = temp.num.intValue();
//                    selectAsk.totalModifierPrice = temp.totalPrice;
//                    selectAsk.modifierPrice = temp.price;
                    item.modifiers.add(selectAsk);
                }
            }
        }
        //处理整单要求，正餐应该是没有整单要求的
        if (menuItem.menuBiz.selectOrderNote != null && menuItem.menuBiz.selectOrderNote.size() > 0) {
            for (NoteItemModel temp : menuItem.menuBiz.selectOrderNote) {
                //目前套餐仅支持固定价格
                if (temp.selected && temp.totalPrice.compareTo(BigDecimal.ZERO) > 0) {
                    RapidOrderModifier selectAsk = new RapidOrderModifier();
                    selectAsk.groupType = RapidOrderModifier.TASTE;
                    selectAsk.isSet = RapidOrderModifier.INGREDIENTS;
                    selectAsk.outerModifierId = String.valueOf(temp.id);
                    selectAsk.modifierName = temp.name;
                    selectAsk.operateNum = temp.num.intValue();
//                    selectAsk.totalModifierPrice = temp.totalPrice;
//                    selectAsk.modifierPrice = temp.price;
                    item.modifiers.add(selectAsk);
                }
            }
        }*/
        item.realPrice = menuItem.menuBiz.totalPrice;
        //如果是称重菜，且未改重量，则写死为待确认状态
        if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
            item.qty = BigDecimal.ONE;
            item.itemNum = BigDecimal.ONE;
            item.ficheckpass = 0;
//            item.realPrice = item.itemPrice;
        } else {
            // itemNum指份数，qty指重量
            // 重新处理数量的问题
            if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(menuItem.menuBiz.voidNum) > 0) {
                item.itemNum = BigDecimal.ONE;
            } else {
                item.itemNum = menuItem.menuBiz.buyNum;
            }
            item.qty = menuItem.menuBiz.buyNum;

            if (menuItem.menuBiz.voidNum != null) {
                item.voidItemNum = menuItem.menuBiz.voidNum.negate();
            }
        }
        item.modifierPrice = menuItem.menuBiz.priceExtraTotal;

        return item;
    }

    /**
     * 构建菜品的 modifiers
     *
     * @param menuItem
     * @return
     */
    public static List<RapidOrderModifier> optRapidOrderModifier(MenuItem menuItem) {
        List<RapidOrderModifier> modifiers = new ArrayList<>();
        //处理规格
        if (!menuItem.supportPackage()) {
            RapidOrderModifier modifier = new RapidOrderModifier();
            modifier.groupType = RapidOrderModifier.SPECIFICATION;
            modifier.isSet = RapidOrderModifier.INGREDIENTS;
            modifier.outerModifierId = String.valueOf(menuItem.currentUnit.fiOrderUintCd);
            modifier.modifierName = menuItem.currentUnit.fsOrderUint;
            modifier.operateNum = 1;
            modifier.spec = menuItem.currentUnit.fiOrderUintCd;
            modifiers.add(modifier);
        }

        //pro 2.5 多做法处理
        if (menuItem.menuBiz.selectMulProcedure.size() > 0) {
            for (AskDBModel askDBModel : menuItem.menuBiz.selectMulProcedure) {
                RapidOrderModifier procedure = new RapidOrderModifier();
                procedure.groupType = RapidOrderModifier.PRACTICE;
                procedure.isSet = RapidOrderModifier.INGREDIENTS;
                procedure.outerModifierId = askDBModel.fiId;
                procedure.modifierName = askDBModel.fsAskName;
                procedure.operateNum = 1;
                procedure.outerModifierTypeId = askDBModel.fsAskGpId;
                modifiers.add(procedure);
            }
        }

        //处理菜品要求
        if (menuItem.menuBiz.selectNote != null && menuItem.menuBiz.selectNote.size() > 0) {
            for (NoteItemModel temp : menuItem.menuBiz.selectNote) {
                if (temp.selected) {
                    RapidOrderModifier selectAsk = new RapidOrderModifier();
                    selectAsk.groupType = RapidOrderModifier.TASTE;
                    selectAsk.isSet = RapidOrderModifier.INGREDIENTS;
                    selectAsk.outerModifierId = temp.id;
                    selectAsk.modifierName = temp.name;
                    selectAsk.operateNum = temp.num.intValue();
                    modifiers.add(selectAsk);
                }
            }
        }

        //处理整单要求，正餐应该是没有整单要求的
        if (menuItem.menuBiz.selectOrderNote != null && menuItem.menuBiz.selectOrderNote.size() > 0) {
            for (NoteItemModel temp : menuItem.menuBiz.selectOrderNote) {
                if (temp.selected) {
                    RapidOrderModifier selectAsk = new RapidOrderModifier();
                    selectAsk.groupType = RapidOrderModifier.TASTE;
                    selectAsk.isSet = RapidOrderModifier.INGREDIENTS;
                    selectAsk.outerModifierId = temp.id;
                    selectAsk.modifierName = temp.name;
                    selectAsk.operateNum = temp.num.intValue();
                    modifiers.add(selectAsk);
                }
            }
        }

        if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
            List<RapidOrderModifier> modifierList = new ArrayList<>();
            for (MenuItem packageItem : menuItem.menuBiz.selectedPackageItems) {
                RapidOrderModifier modifier = new RapidOrderModifier();
                modifier.groupType = RapidOrderModifier.GENERAL;
                modifier.isSet = RapidOrderModifier.SET_MEAL;
                modifier.outerModifierId = packageItem.itemID;
                modifier.modifierName = packageItem.name;
                modifier.operateNum = packageItem.menuBiz.buyNum.intValue();
                modifier.modifierNum = packageItem.menuBiz.buyNum.intValue();
                modifier.outerModifierTypeId = "";
                modifier.totalModifierPrice = BigDecimal.ZERO;
                modifier.vipModifierPrice = BigDecimal.ZERO;
                modifier.modifierPrice = BigDecimal.ZERO;
                modifier.spec = packageItem.currentUnit.fiOrderUintCd;
                modifier.unit = packageItem.currentUnit.fsOrderUint;
                if (ListUtil.isEmpty(modifier.modifiers)) {
                    modifier.modifiers = new ArrayList<>();
                }
                modifier.modifiers.addAll(optRapidOrderModifier(packageItem));
                modifierList.add(modifier);
            }
            if (!ListUtil.isEmpty(modifierList)) {
                modifiers.addAll(modifierList);
            }
        }

        return modifiers;
    }

    /**
     * 构建菜品
     *
     * @param rapidOrder     RapidOrder
     * @param selectMenuList List<MenuItem>
     * @param kitchenStatus  int
     * @return boolean
     */
    public static boolean addMenuList(RapidOrder rapidOrder, List<MenuItem> selectMenuList, int kitchenStatus) {
        //是否有未确认的菜（待改价或者待称重）
        boolean hasUnConfirmedMenu = false;
        for (MenuItem menuItem : selectMenuList) {
            // 餐标/低消服务费菜品移除
            if (menuItem == null || DinnerStandardUtil.isStandardMenu(menuItem.itemID)) {
                continue;
            }
            RapidOrderItem item = buildRapidItemByMenuItem(menuItem, rapidOrder.shopId, kitchenStatus, rapidOrder.needBuildMemberPrice());
            if (item == null) {
                continue;
            }
            //如果是称重菜，且未改重量，则写死为待确认状态
            if (menuItem.supportWeight() && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ZERO) == 0) {
                hasUnConfirmedMenu = true;
            }
            //如果时价菜未改价
            if (menuItem.supportTimes() && menuItem.menuBiz.currentPriceTimes == 0) {
                hasUnConfirmedMenu = true;
            }
            if (ListUtil.isEmpty(rapidOrder.orderDetailList)) {
                rapidOrder.orderDetailList = new ArrayList<>();
            }
            rapidOrder.orderDetailList.add(item);
            if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                for (MenuItem temp : menuItem.menuBiz.selectedModifier) {
                    RapidOrderItem modifiyers = buildRapidItemByMenuItem(temp, rapidOrder.shopId, kitchenStatus, rapidOrder.needBuildMemberPrice());
                    if (modifiyers != null) {
                        modifiyers.parentItemId = item.outerItemId;
                        modifiyers.isIngredient = 1;
                        modifiyers.itemType = 4;
                        if (item.isWeigh != 1) {
                            modifiyers.itemNum = modifiyers.itemNum.multiply(item.itemNum);
                        }
                        modifiyers.qty = modifiyers.itemNum;
                        modifiyers.itemPrice = modifiyers.itemPrice.multiply(item.itemNum);
                        rapidOrder.orderDetailList.add(modifiyers);
                    }
                }
            }
        }
        return hasUnConfirmedMenu;
    }

    /**
     * OrderCache转化RapidOrder
     *
     * @param rapidOrder RapidOrder
     * @param tempOrder  TempOrderDishesCache
     */
    public static void convert(RapidOrder rapidOrder, TempOrderDishesCache tempOrder) {
        if (tempOrder == null) {
            return;
        }

//        rapidOrder.orderId = orderCache.orderID;
//        rapidOrder.outerOrderId = tempOrder.orderID;
//        rapidOrder.orderSeq = "1";

        rapidOrder.originMemTotal = tempOrder.tempTotalPrice;

        // 已支付金额
        rapidOrder.paymentAmount = BigDecimal.ZERO;
        // 未付金额
        rapidOrder.notPaymentAmount = tempOrder.tempTotalPrice;

        rapidOrder.memTotal = tempOrder.tempTotalPrice;


        //计算出非会员价的待支付总金额
        if (tempOrder.isMember) {
            rapidOrder.subTotal = optDeMemberNotPaymentAmt(tempOrder, rapidOrder);
        }

        // 总可折扣金额
        rapidOrder.discountAmount = PayUtil.getDiscountAmtByOrderTotal(tempOrder);
        if (rapidOrder.discountAmount.compareTo(tempOrder.tempTotalPrice) > 0) {
            rapidOrder.discountAmount = tempOrder.tempTotalPrice;
        }
        // 需支付的可折扣金额
        rapidOrder.discountAmountPay = rapidOrder.discountAmount;
        // 需支付的不可折扣金额
        rapidOrder.nonDiscountAmountPay = tempOrder.tempTotalPrice.subtract(rapidOrder.discountAmountPay);
        if (rapidOrder.nonDiscountAmountPay.compareTo(BigDecimal.ZERO) < 0) {
            rapidOrder.nonDiscountAmountPay = BigDecimal.ZERO;
        }
        rapidOrder.fdServiceAmt = tempOrder.tempTotalService;
        rapidOrder.tableNo = tempOrder.fsmtableid;
        rapidOrder.person = tempOrder.personNum;
        rapidOrder.people = tempOrder.personNum;
        rapidOrder.total = tempOrder.tempTotalPrice;

//        rapidOrder.discountAmountPay = tempOrder.tempTotalPrice;
        rapidOrder.itemCount = tempOrder.tempSelectedMenuList.size();
        rapidOrder.orderRemark = "";
        rapidOrder.orderStatus = 0; // 订单状态


        if (!tempOrder.isMember) {
            rapidOrder.subTotal = tempOrder.tempTotalPrice;
            rapidOrder.originDiscountAmount = rapidOrder.discountAmountPay;
            rapidOrder.originNonDiscountAmount = rapidOrder.nonDiscountAmountPay;
        }

    }

    /**
     * 构建支付信息
     *
     * @param resultData   RapidActionModel
     * @param rapidPayment RapidPayment
     */
    public synchronized static void buildPayment(RapidActionModel resultData, RapidPayment rapidPayment) {
        OrderCache orderCache;
        if (NetOrderType.isRapidPrePay(rapidPayment.bizType)) {
            if (SourceType.isPrePayFastfoodModel(rapidPayment.sourceType)) {
                orderCache = RapidBiz.queryOrderById(rapidPayment.outerOrderId);
            } else {
                orderCache = queryOrderByTable(rapidPayment.tableNo);
            }
        } else if (NetOrderType.isShareShopPrePay(rapidPayment.bizType)) {
            orderCache = queryOrderByTable(rapidPayment.tableNo);
        } else {
            orderCache = queryOrderById(rapidPayment.outerOrderId);
        }
        if (orderCache == null) {
            buildResultError(resultData, "未查到订单信息!");
            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 秒点订单支付失败, 未查询到订单信息", rapidPayment.outerOrderId, "", resultData.fsid, rapidPayment);
            return;
        }
        //检查反结账---纯收银不校验是否正在反结账
        if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
            RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点订单 桌台[" + orderCache.fsmtableid + "]正在反结账 (buildPayment)",
                    resultData.fsid, orderCache.fsmtableid);
        }
//        if (rapidPayment.bizType != 11 && RapidApi.checkAntiPay(resultData, orderCache)) {
//            return;
//        }
        //检查是否接受过秒付
        if (RapidApi.checkRapidPayExist(resultData, orderCache.fsmtableid, orderCache.orderID)) {
            return;
        }
        UserDBModel userCash = getCloudUser();
        if (userCash == null) {
            buildResultError(resultData, "未查询到云收银账号");
            RunTimeLog.addLog(RunTimeLog.RAPID_EXCEPTION, "秒点监控 未找到云收银[fsStaffId = 'cash']的账号", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, orderCache.fsmtableid);
            return;
        }
        final boolean needUpdateorder = !TextUtils.isEmpty(rapidPayment.fsWposMemberNo) && rapidPayment.isVip == 1;
        LogUtil.logBusiness("秒点监控 buildPayment: fsWposMemberNo:: " + rapidPayment.fsWposMemberNo + ", needUpdateorder:: " + needUpdateorder);
        PaySession originSession;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "收到秒付信息，构建支付信息");
        try {
            orderCache = OrderSession.getInstance().getOrder(orderCache.orderID);
            originSession = OrderSession.getInstance().getPay(orderCache.orderID);
            if (originSession == null) {
                originSession = OrderSession.getInstance().generatePaySession(orderCache, userCash, HostBiz.cloudsite);
            }
            //根据结账时间，处理重复推送,重复推送可以反馈为已处理
            if (originSession != null && 1 == originSession.payed && TextUtils.equals(originSession.payTime, rapidPayment.paySuccessTime)) {
//            buildResultError(resultData, "该笔订单已支付!");
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 秒点订单支付失败,该笔订单已支付", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                MessageOrderUtil.addRapidPayMessage(originSession, orderCache, MessageOrderUtil.getPayedAmt(originSession.selectPayListFull), MessageConstance.TYPE_RAPID, MessageConstance.MessagePayBuinessStatus.RAPID.REFUSH);
                return;
            }
            //如果订单已完成结账，则不再接受支付信息
            if (originSession != null && 1 == originSession.payed && orderCache.orderStatus == OrderStatus.PAIED) {
                buildResultError(resultData, "该笔订单已支付!");
                RunTimeLog.addLog(RunTimeLog.RAPID_ERROR, "秒点监控 秒点订单支付失败,该笔订单已支付", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                MessageOrderUtil.addRapidPayMessage(originSession, orderCache, MessageOrderUtil.getPayedAmt(originSession.selectPayListFull), MessageConstance.TYPE_RAPID, MessageConstance.MessagePayBuinessStatus.RAPID.REFUSH);
                return;
            }

//        //桌台锁定检测
//
//        String error = TableBusinessUtil.checkTableLock(HostBiz.cloudsite,userCash.fsUserId,orderCache.fsmtableid);
//        if (!TextUtils.isEmpty(error)) {
//            buildResultError(resultData, error);
//            writeRapidOrderError(orderCache, "秒点订单，构建订单信息失败，餐桌id[" + orderCache.fsmtableid + "]" + "：" + error);
//            return;
//        }
            String orderToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);

            if (needUpdateorder) {
                LogUtil.logBusiness("秒点监控 buildPayment: 更新为会员价:: orderId: " + orderCache.orderID + ", isMember: " + orderCache.isMember +
                        ", orderCache.member: " + JSON.toJSONString(orderCache.memberInfoS) +
                        ", isVip: " + rapidPayment.isVip + ", fsWposMemberNo: " + rapidPayment.fsWposMemberNo +
                        ", memberLevel: " + rapidPayment.memberLevel + ", memberId: " + rapidPayment.memberId + ", plusId: " + rapidPayment.plusId);

                boolean isMember = orderCache.isMember;

                orderCache.updateOrderToMember(rapidPayment.fsWposMemberNo,
                        StringUtil.toInt(rapidPayment.memberLevel), rapidPayment.memberId,
                        rapidPayment.plusId, rapidPayment.isVipPrice == -1);

                boolean isPrePay = NetOrderType.isRapidPrePay(orderCache.thirdOrderType) || NetOrderType.isShareShopPrePay(rapidPayment.bizType);

//                if (!(isMember && isPrePay)) {
                if (((!isMember && isPrePay) || (!isMember && rapidPayment.isVip == 1)) && rapidPayment.isVipPrice == -1) {
                    LogUtil.log("秒付时菜品调整为会员价 rapidPayment.isVip = " + rapidPayment.isVip + "； isMember = " + isMember + "；isPrePay = " + isPrePay);
                    //如果先付款订单之前不是会员，则在付款时不强制切换价格为会员价，仅对会员信息进行绑定
//                    orderCache.updateAllMenuToMemberPrice();
                    MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, "cash");
                } else if (rapidPayment.isVip == 1 && rapidPayment.isVipPrice == 1) {

                    //强制刷新为会员价
                    if (DBMetaUtil.autoUseMemberPrice() || DBMetaUtil.autoUseVipDiscount()) {
                        MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, false, "cash");
                    } else {
                        orderCache.updateAllMenuToMemberPrice("cash");
                    }

                    orderCache.reCalcAllByAll();
                } else if (rapidPayment.isVip == 1 && rapidPayment.isVipPrice == 0) {
                    //强制刷新为非会员价
                    orderCache.clearAllMemberDiscount(false);
                }
                orderCache.plusAllMenuAmount();
                OrderSession.getInstance().writeOrder(orderCache.orderID, true, "buildPayment");
//                OrderProcessor.saveOrder(orderCache, null);
            }

            StringBuilder sb = new StringBuilder();
            if (orderCache.thirdOrderId.length() > 0) {
                if (!orderCache.thirdOrderId.contains(rapidPayment.orderId)) {
                    sb.append(rapidPayment.orderId).append(",");
                }
            } else {
                sb.append(rapidPayment.orderId).append(",");
            }
            sb.append(orderCache.thirdOrderId);
            orderCache.thirdOrderId = sb.toString();

            //刷新订单的满减的相关的待支付
            OrderUtil.recalcCouponCutWithPay(originSession, orderCache, false);
            PayModel parentPay = buildRapidPayModel(orderCache, rapidPayment, resultData);
            if (parentPay == null) {
                return;
            }

            //将支付明细进行落帐
            if (parentPay != null) {
                SocketResponse<PayResultResponse> socketResponse = BillUtil.addPayDetail(orderToken, orderCache.orderID, userCash, HostBiz.cloudsite, true, parentPay);
                if (socketResponse.success()) {
                    orderCache.receiptName = rapidPayment.receiptName;
                    orderCache.receiptType = rapidPayment.receiptType;
                    orderCache.taxNo = rapidPayment.taxNo;
                    OrderSession.getInstance().writeOrder(orderCache.orderID, false, "buildPayment 2");
                    OrderSaveDBUtil.updateTax(orderCache.orderID, rapidPayment.receiptType, rapidPayment.receiptName, rapidPayment.taxNo);

                    if (socketResponse.success()
                            && TextUtils.isEmpty(orderCache.checkToPay())
                            && !NetOrderType.isShareShopPrePay(rapidPayment.bizType)
                            && ((PayUtil.supportAutoPay(orderCache.fiSellType) && !NetOrderType.isRapidPrePay(rapidPayment.bizType)) || (orderCache.dinnerModel() && PayUtil.supportPreRapidAutoPay() && NetOrderType.isRapidPrePay(rapidPayment.bizType)))
                    ) {
                        SocketResponse<PayResultResponse> socketAutoResponse = BillUtil.checkAutoFinishAndStart(orderToken, orderCache.orderID, true, null, userCash, HostBiz.cloudsite, false);
                        socketResponse.data = socketAutoResponse.data;
                        if (socketAutoResponse.success()) {

                            MemberInfo memberInfo = null;
                            if (!TextUtils.isEmpty(rapidPayment.fsMemberCardAmount) && !TextUtils.isEmpty(rapidPayment.fsScore) && ServerSettingHelper.isBillPrintBalanceAndScore()) {
                                memberInfo = new MemberInfo();
                                memberInfo.amount = new BigDecimal(rapidPayment.fsMemberCardAmount);
                                memberInfo.score = StringUtil.toInt(rapidPayment.fsScore);
                            }
                            PrintBillUtil.printRapidDinnerBill(orderCache, memberInfo, userCash);
//                            TableBusinessUtil.closeTable(new SocketResponse(), orderCache.fsmtableid, orderCache.orderID);
                        }
                    }


                } else {
                    RunTimeLog.addLog(RunTimeLog.RAPID_PAY_NO, "秒付明细落帐失败:" + socketResponse.message, orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                    buildResultError(resultData, "秒付明细落帐失败:" + socketResponse.message);
                    return;
                }
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "收到秒付信息，构建支付信息");
        }
        NotifyToClient.refreshReceiveRapidOrder(orderCache.fsmtableid);

//        orderCache = orderCache.clone();
        RapidOrder existOrder = RapidApi.buildRapidOrder(null, orderCache, null);
        if (NetOrderType.isRapidPrePay(rapidPayment.bizType) || NetOrderType.isShareShopPrePay(rapidPayment.bizType)) {
            existOrder.orderId = rapidPayment.rapidMenuOrderIdInner;
        }
        existOrder.bizType = rapidPayment.bizType;
        if (existOrder.bizType == 0 || existOrder.bizType == 14 || existOrder.bizType == NetOrderType.KB_AFTER_PAY_ORDER) {
            existOrder.bizType = 15;
        }
        RapidBiz.addMenuList(existOrder, orderCache.originMenuList, 1);
        resultData.resultBiz = JSON.toJSONString(existOrder, new RapidJsonFilter());
        if (!NetOrderType.isRapidOnlyPay(rapidPayment.bizType) && !SourceType.isPrePayFastfoodModel(rapidPayment.sourceType)) {
            int buinessStatus = 0;
            if (originSession.priceLeftToPay.compareTo(BigDecimal.ZERO) == 0) {
                buinessStatus = MessageConstance.MessagePayBuinessStatus.RAPID.PAYED;
            } else {
                buinessStatus = MessageConstance.MessagePayBuinessStatus.RAPID.NONE;
            }
            MessageOrderUtil.addRapidPayMessage(originSession, orderCache, MessageOrderUtil.getPayedAmt(originSession.selectPayListFull), MessageConstance.TYPE_RAPID, buinessStatus);
        }
    }

    /**
     * 通过id查找规格
     *
     * @param fiOrderUintCd 规格id
     * @return MenuItemUnitDBModel
     */
    private static MenuItemUnitDBModel queryUnitById(String fiOrderUintCd) {
        String sql = "select * from tbMenuItemUint where fiOrderUintCd = '" + fiOrderUintCd + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuItemUnitDBModel.class);
    }

    /**
     * 通过订单号查询订单(先从ordercache中查询，为空再从paysession中查询)
     *
     * @param orderId String
     * @return OrderCache
     */
    public static OrderCache queryOrderById(String orderId) {
        return OrderSession.getInstance().getOrder(orderId);
    }

    private static OrderCache queryOrderByTable(String tableID) {
        return OrderSession.getInstance().getOrder(TableBusinessUtil.getOrderIDByTableID(tableID));
    }

    public static void buildResultError(RapidActionModel result, String errorInfo) {
        buildResultError(result, RapidResult.ERROR, errorInfo);
    }

    /**
     * 构建沽清失败的数据结构
     *
     * @param result    RapidActionModel
     * @param code      int
     * @param errorInfo String
     */
    public static void buildSellOut(RapidActionModel result, int code, String errorInfo, SubmitOrderCheckNumResult sellOutResult) {
        result.result = code;
        result.errorInfo = errorInfo;
        JSONObject object = new JSONObject();
        object.put("errno", String.valueOf(code));
        object.put("errmsg", errorInfo);
        object.put("status", String.valueOf(code));
        JSONArray array = new JSONArray();
        if (sellOutResult != null && !ListUtil.isEmpty(sellOutResult.notEnough)) {
            for (SellOutViewModel temp : sellOutResult.notEnough) {
                JSONObject ob = new JSONObject();
                ob.put("itemId", temp.fiItemCd);
                ob.put("itemName", temp.fsItemName);
                ob.put("itemNum", temp.fdInvQty);
                array.add(ob);
            }
        }
        object.put("items", array);
        result.resultBiz = object.toJSONString();
    }

    private static void buildResultError(RapidActionModel result, int code, String errorInfo) {
        result.result = code;
        result.errorInfo = errorInfo;
        JSONObject object = new JSONObject();
        object.put("status", String.valueOf(code));
        result.resultBiz = object.toJSONString();
    }

    private static void writeRapidOrderError(String commitID, TempOrderDishesCache orderCache, String errorMsg) {
        RunTimeLog.addLogWithTable(RunTimeLog.RAPID_ERROR, "秒点监控 秒点订单下单失败[" + errorMsg + "]", commitID, orderCache.fsmtableid, "");
    }

    public static UserDBModel getCloudUser() {
        UserDBModel userCash = UserCache.getInstance().getCloudUser();
        if (userCash == null) {
            userCash = HostUtil.getHostUser();
        }
        return userCash;
    }

    /**
     * '秒点拉单确认'检查
     *
     * @param rapidOrder
     */
    public static void checkRapidPayCommit(RapidOrder rapidOrder) {
        if (rapidOrder == null) {
            return;
        }
        if (TextUtils.isEmpty(rapidOrder.outerOrderId)) {
            return;
        }
        //1、本地是否有开买单确认开关
        String payConfirm = DBMetaUtil.getSettingsValueByKey(META.RAPID_CONFIFM);
        if (!TextUtils.equals(payConfirm, "1")) {
            return;
        }

        //2、需要服务员确认 判断是否同意过本订单拉单
        if (MessageDBUtil.checkRapidPayConfirmStatus(rapidOrder.outerOrderId)) {
            return;
        }

        //3、未同意过或者没有拉单过都要拒绝支付，并业务中心弹框提示
        //(1)、将菜品置为未确认状态
        if (!ListUtil.isEmpty(rapidOrder.orderDetailList)) {
            for (RapidOrderItem rapidOrderItem : rapidOrder.orderDetailList) {
                rapidOrderItem.ficheckpass = 5;  //将菜品状态置为未确认
            }
        }
        //(2)、业务中心站点弹框提示
        MessageBiz.checkAndAddRapidPayConfirmMessage(rapidOrder.outerOrderId);
    }

    /**
     * 美老板查看桌台列表
     *
     * @return 应用内所有桌台列表数据
     */
    public static String queryTableInfoList() {
        try {
            String sql = "select \n" +
                    "tbmarea.fsMareaId 'areaid',\n" +
                    "tbmarea.fsMAreaName 'areaname',\n" +
                    "tbmtable.fsmTableid 'tableid',\n" +
                    "tbmtable.fsmtablename 'tablename',\n" +
                    "case tablebiz.fsmtablesteid\n" +
                    "when '2' then '占用'\n" +
                    "else '空闲'\n" +
                    "end 'tableste',\n" +
                    "tablebiz.fssellno 'sellno',\n" +
                    "tbsell.fdExpAmt 'totalamt',\n" +
                    "tbsell.fdPayAmt ,\n" +
                    "tbsell.fdDiffAmt,\n" +
                    "tbsell.fdRealAmt 'realamt',\n" +
                    "(tbsell.fdExpAmt-tbsell.fdPayAmt) 'notpayamt'," +
                    "tbsell.fiCustSum people\n" +
                    "from tbmtable \n" +
                    "left join tbmarea\n" +
                    "on tbmarea.fsMareaId==tbmtable.fsmareaid\n" +
                    "left join tablebiz  \n" +
                    "on tbMtable.fsmTableid==tablebiz.fsmtableid\n" +
                    "left join tbsell\n" +
                    "on tablebiz.fssellno==tbsell.fssellno " +
                    "where tbmtable.fiStatus not in(9,13) order by tbmarea.fiSortOrder,tbmarea.fsMAreaName, tbmtable.fiSortOrder, tbmtable.fsMTableName";
            return JSON.toJSONString(DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql));
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 秒付结果在内存中缓存的生命时长
     */
    private static long CACHED_LIFE = 1000 * 60 * 5;

    /**
     * 一段时间后，移除缓存在内存中的Commit History
     *
     * @param commitID String
     */
    public static void prepareToRemoveCommitCache(final String commitID) {
        GlobalLooper.postDelayed(() -> {
            RapidBiz.removeCommitHistoryCache(commitID);
            RapidBiz.removeProcessingCache(commitID);
        }, CACHED_LIFE);
    }


    public static PayModel buildRapidPayModel(OrderCache orderCache, RapidPayment rapidPayment, RapidActionModel resultData) {
        PayModel parentPay = null;
        UserDBModel userCash = getCloudUser();
        //构建支付明细
        for (RapidPayModel rapidPayModel : rapidPayment.paymentList) {
            if (TextUtils.isEmpty(rapidPayModel.fsPaymentId)) {
                continue;
            }
            if (rapidPayModel.fdReceMoney == null || rapidPayModel.fdReceMoney.compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            if (TextUtils.equals(PayType.REWART, rapidPayModel.fsPaymentId)) {
                orderCache.rewardinfo = "支付金额包含顾客打赏：" + rapidPayModel.fdReceMoney.toPlainString() + " [" + rapidPayModel.empNo + "]";
                OrderSaveDBUtil.upateRewordInfo(orderCache.orderID, orderCache.rewardinfo);
                continue;
            }
            PayOriginModel data = null;
            if (OrderUtil.isMWMemberTicketByPayID(rapidPayModel.fsPaymentId)) {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            } else if (!TextUtils.isEmpty(rapidPayModel.fsMemberNo) && !TextUtils.isEmpty(rapidPayModel.fsCoupon_id)) {
                data = OrderUtil.buildPayModelByMemberTicketID(rapidPayModel.fsCoupon_id);
            } else {
                data = OrderUtil.buildPayModelByPaymentID(rapidPayModel.fsPaymentId);
            }

            //如果没有找到支付方式，则使用默认的卡券
            if (data == null) {
                data = PayUtil.addDefaultCoupon();
            }
            if (data == null) {
                buildResultError(resultData, "未查询到支付方式:" + rapidPayModel.fsPaymentId + " " + rapidPayModel.fsCoupon_id);
                RunTimeLog.addLog(RunTimeLog.RAPID_EXCEPTION, "（口碑后付、秒点监控） 秒点订单,支付失败 未找到支付方式:" + rapidPayModel.fsPaymentId + " " + rapidPayModel.fsCoupon_id, orderCache.orderID, orderCache.fsmtableid, resultData.fsid, rapidPayModel);
                return null;
            }
            PayModel currentSelectPay = new PayModel(userCash.fsUserId, userCash.fsUserName);
            currentSelectPay.data = data;
            currentSelectPay.payAmount = rapidPayModel.fdReceMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
            currentSelectPay.status = 1;
            currentSelectPay.showNote = rapidPayModel.fsNote;
            currentSelectPay.createTime = DateUtil.getCurrentTime();
            currentSelectPay.businessInfo = rapidPayment.orderId;
            //写入秒付属性
            currentSelectPay.writeRapid();
            if (NetOrderType.isSmartPayPos(rapidPayment.bizType)) {
                //写入全能pos属性
                currentSelectPay.writeSmartPayPos();
            } else if (NetOrderType.isShareShopPrePay(rapidPayment.bizType)) {
                //写入共享餐厅属性
                currentSelectPay.writeSharedShopPay();
            } else if (NetOrderType.isKBAfterPay(rapidPayment.bizType)) {
                //写入口碑后付属性
                currentSelectPay.writeKBAfterPay();
            }
            if (OrderUtil.isMWMemberTicket(data.payTypeGroupID)) {
                currentSelectPay.data.memberCouponModel = new MemberCouponModel();
                currentSelectPay.data.memberCouponModel.code = rapidPayModel.fsMiscno;
            }
            if (!TextUtils.isEmpty(rapidPayModel.fsMemberNo)) {
                currentSelectPay.memberCardNO = rapidPayModel.fsMemberNo;
            }
            if (parentPay == null) {
                parentPay = currentSelectPay;
            } else {
                if (parentPay.secondPayList == null) {
                    parentPay.secondPayList = new ArrayList<>();
                }
                parentPay.secondPayList.add(currentSelectPay);
            }
        }
        return parentPay;
    }

}