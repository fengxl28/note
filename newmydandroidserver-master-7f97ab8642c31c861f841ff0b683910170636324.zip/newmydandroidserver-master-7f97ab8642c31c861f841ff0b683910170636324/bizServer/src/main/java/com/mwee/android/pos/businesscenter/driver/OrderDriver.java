package com.mwee.android.pos.businesscenter.driver;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.Pair;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.Driver;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.bonus.BonusUtils;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.shift.GetShiftPrintDataResponse;
import com.mwee.android.pos.business.shift.GetUnFinishedShiftResponse;
import com.mwee.android.pos.business.shift.ShiftDinnerProcessor;
import com.mwee.android.pos.business.shift.ShiftResponse;
import com.mwee.android.pos.business.shift.model.UnShiftModel;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.air.MBillOrderUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.ShiftDBUtils;
import com.mwee.android.pos.businesscenter.business.host.CenterCloseUtil;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderDBUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.member.MemberBizUtil;
import com.mwee.android.pos.businesscenter.business.order.OrderBizUtil;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.dbutil.CardRelationDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.MessageDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.print.CreditPrintUtil;
import com.mwee.android.pos.businesscenter.print.MemberPrint;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.businesscenter.print.PrintReportUtil;
import com.mwee.android.pos.component.cross.net.CreditAccount;
import com.mwee.android.pos.component.cross.net.CreditAccountListRequest;
import com.mwee.android.pos.component.cross.net.CreditAccountListResponse;
import com.mwee.android.pos.component.cross.net.CreditAccountRequest;
import com.mwee.android.pos.component.cross.net.CreditAccountResponse;
import com.mwee.android.pos.component.cross.net.CrossPayData;
import com.mwee.android.pos.component.cross.net.CrossPayRequest;
import com.mwee.android.pos.component.cross.net.CrossPayResponse;
import com.mwee.android.pos.component.cross.net.QueryCrossPayResult;
import com.mwee.android.pos.component.cross.net.QueryCrossPayResultRequest;
import com.mwee.android.pos.component.cross.net.QueryCrossPayResultResponse;
import com.mwee.android.pos.component.cross.net.ReverseCrossRequest;
import com.mwee.android.pos.component.cross.net.ReverseCrossResponse;
import com.mwee.android.pos.component.cross.net.ReverseCrossResult;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.member.net.GetMemberCardResponse;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberQueryEntityCardNumBerRequest;
import com.mwee.android.pos.component.member.net.model.MemberCardModel;
import com.mwee.android.pos.component.member.net.model.MemberPrivateModel;
import com.mwee.android.pos.component.member.net.model.MemberRechargeOrderModel;
import com.mwee.android.pos.component.member.newInterface.net.NewMemberQueryEntityCardNumBerResponse;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bean.ChangeOrderWithMemberResponse;
import com.mwee.android.pos.connect.business.bean.GetMenuSearchTableResponse;
import com.mwee.android.pos.connect.business.bean.GetNumOrderIDResponse;
import com.mwee.android.pos.connect.business.bean.GetOrderDetailsResponse;
import com.mwee.android.pos.connect.business.bean.GetOrderFromCenterRespone;
import com.mwee.android.pos.connect.business.bean.GetPrintDinnerPreBillResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoAndBindToOrderResponse;
import com.mwee.android.pos.connect.business.bean.QueryMemberInfoResponse;
import com.mwee.android.pos.connect.business.bean.model.OrderDetailsModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListMenuModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListModel;
import com.mwee.android.pos.connect.business.bean.model.OrderListPayModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.bind.bean.AutomaticClosingResponse;
import com.mwee.android.pos.connect.business.bind.bean.ExceptionOrderBean;
import com.mwee.android.pos.connect.business.bonus.AllBonusUserResponse;
import com.mwee.android.pos.connect.business.order.GetOrderTokenResponse;
import com.mwee.android.pos.connect.business.order.GetSellOutGroupByMenuClsResponse;
import com.mwee.android.pos.connect.business.order.GetSellOutResponse;
import com.mwee.android.pos.connect.business.order.PreMenuListResponse;
import com.mwee.android.pos.connect.business.order.SetSellOutGroupByMenuClsResponse;
import com.mwee.android.pos.connect.business.order.SetSellOutResponse;
import com.mwee.android.pos.connect.business.order.model.SellOutMenuClsViewModel;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.connect.business.pay.CreditAccountListSocketResponse;
import com.mwee.android.pos.connect.business.pay.CreditAccountSocketResponse;
import com.mwee.android.pos.connect.business.pay.CrossPaySocketResponse;
import com.mwee.android.pos.connect.business.pay.GetPaySessionResponse;
import com.mwee.android.pos.connect.business.pay.QueryCrossPayResultSocketResponse;
import com.mwee.android.pos.connect.business.pay.ReverseCrossSocketResponse;
import com.mwee.android.pos.connect.business.pay.model.CrossPayPrintInfo;
import com.mwee.android.pos.connect.business.print.PrintSelloutResponse;
import com.mwee.android.pos.connect.business.print.PrinterMemberResponse;
import com.mwee.android.pos.connect.business.print.ReprintBillReceptResponse;
import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuEffectiveInfo;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.SeqnoDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.order.bonus.BonusUserModel;
import com.mwee.android.pos.db.business.pay.OrderConfig;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.db.business.table.MenuSearchTableModel;
import com.mwee.android.pos.db.business.table.TableStatusBean;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.RegexUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

/**
 * @ClassName: OrderDriver
 * @Description:
 * @author: SugarT
 * @date: 16/8/16 上午10:18
 */
@SuppressWarnings("unused")
public class OrderDriver extends Driver {
    public static final String KEY_ORDER = "Documentflow";
    public final static String KEY_BILL = "Orderflow";

    private static final String TAG = "ordersync";

    public static SocketResponse addMenu(SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse, String hostID, String tableID, String orderID, TempOrderDishesCache tempOrder, boolean cleanRapidOrder) {
        return addMenu(socketResponse, hostID, tableID, orderID, tempOrder, true, cleanRapidOrder);
    }

    /**
     * 加菜
     *
     * @param socketResponse
     * @param orderID
     * @param tempOrder
     * @param checkSellOut    boolean | 是否检查估清：true：检查；false：不检查
     * @param cleanRapidOrder boolean | 是否清空秒点单：true：清空；false：不清空
     * @return
     */
    public static SocketResponse addMenu(SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse, String hostID, String tableID, String orderID, TempOrderDishesCache tempOrder, boolean checkSellOut, boolean cleanRapidOrder) {
        long start = SystemClock.elapsedRealtime();
        OrderCache orderCache = null;
        UserDBModel userDBModel = new UserDBModel();
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(tableID, orderID, " 站点：" + hostID + " 加菜-start ");
        try {
            orderCache = OrderSession.getInstance().getOrder(orderID);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单[" + orderID + "]已不存在";
                return socketResponse;
            }
            if (orderCache.orderStatus == OrderStatus.PAIED) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单[" + orderID + "]已结账，不能修改。";
                return socketResponse;
            }
            socketResponse.data.orderCache = orderCache;
            //去重的逻辑
            List<MenuItem> currentOrderMenu = new ArrayList<>();
            currentOrderMenu.addAll(orderCache.originMenuList);
            for (int i = 0; i < currentOrderMenu.size(); i++) {
                MenuItem tempMenu = currentOrderMenu.get(i);
                for (int j = 0; j < tempOrder.tempSelectedMenuList.size(); j++) {
                    MenuItem temp = tempOrder.tempSelectedMenuList.get(j);
                    if (!TextUtils.isEmpty(tempMenu.menuBiz.uniq) && TextUtils.equals(tempMenu.menuBiz.uniq, temp.menuBiz.uniq)) {
                        //只要有一个菜是重复下的，就认为是重复订单
                        socketResponse.code = SocketResultCode.DUPLICATE;
                        socketResponse.message = "该订单已处理，请勿重复提交";
                        return socketResponse;
                    }
                }
            }

            if (tempOrder.tempSelectedMenuList.size() <= 0) {
                socketResponse.code = SocketResultCode.DUPLICATE;
                socketResponse.message = "该订单已处理，请勿重复提交";
                return socketResponse;
            }

            //检查菜品和规格在业务中心是否存在
            String errorMsg = checkMenuAndUnitIsExist(tempOrder.tempSelectedMenuList);
            if (!TextUtils.isEmpty(errorMsg)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "下单失败，" + errorMsg;
                return socketResponse;
            }

            //判断菜品是否生效
            MenuEffectiveInfo menuEffectiveInfo = null;
            for (MenuItem menu : tempOrder.tempSelectedMenuList) {
                menuEffectiveInfo = MenuDBUtil.queryMenuEffectiveInfoById(menu.itemID);
                if (menuEffectiveInfo != null && !MenuDBUtil.dataIsEffectiveDate(menuEffectiveInfo.startTime, menuEffectiveInfo.endTime, menuEffectiveInfo.fiIsEffectiveDate)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "菜品【" + menu.name + "】有效期为 " + menuEffectiveInfo.fsStarDate + "- " + menuEffectiveInfo.fsEndDate;
                    return socketResponse;
                }
            }

            if (checkSellOut) {
                //先检查估清
                SubmitOrderCheckNumResult result = SellOutServerProcessor.checkSellOutValue(tempOrder.tempSelectedMenuList);
                if (!result.success) {
                    OpenTableAndCheckToOrderRespose respose = new OpenTableAndCheckToOrderRespose();
                    respose.sellOutResult = result;
                    socketResponse.data = respose;
                    socketResponse.code = SocketResultCode.ORDER_FAILED_SELL_OUT;
                    socketResponse.message = result.errorMsg;
                    return socketResponse;
                }
            }
            int currentSeq = orderCache.currentSeq;
            userDBModel.fsUserId = tempOrder.waiterID;
            userDBModel.fsUserName = tempOrder.waiterName;
            orderCache.updateSeqStatus(currentSeq, OrderSeqStatus.ORDERED, userDBModel, hostID);
            for (MenuItem temp : tempOrder.tempSelectedMenuList) {
                temp.updateOrderSeq(orderCache.currentSeq);
                //检查套餐明细的fiseq是否有效
                if (temp.supportPackage() && !ListUtil.isEmpty(temp.menuBiz.selectedPackageItems)) {
                    for (MenuItem item : temp.menuBiz.selectedPackageItems) {
                        if (item != null && TextUtils.isEmpty(item.menuBiz.uniq)) {
                            item.menuBiz.uniq = UUIDUtil.optUUID();
                        }
                    }
                }
            }

            //将批量要求挑选出来
            OrderBizUtil.pickGeneralNotes(tempOrder.tempSelectedMenuList);

            List<MenuItem> hasModifierItems = new ArrayList<>();
            for (int i = 0; i < tempOrder.tempSelectedMenuList.size(); i++) {
                MenuItem menuItem = tempOrder.tempSelectedMenuList.get(i);
                if (TextUtils.isEmpty(menuItem.menuBiz.createTime)) {
                    menuItem.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                    LogUtil.log("缺少createTime " + orderID + ",菜品[" + menuItem.name + "],uniq[" + menuItem.menuBiz.uniq + "]");
                }
                if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
                    for (MenuItem tempPackage : menuItem.menuBiz.selectedPackageItems) {
                        if (TextUtils.isEmpty(tempPackage.menuBiz.createTime)) {
                            tempPackage.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                            LogUtil.log("缺少createTime " + orderID + ",配料头[" + menuItem.name + "],配料[" + tempPackage.name + "],uniq[" + tempPackage.menuBiz.uniq + "]");
                        }
                    }
                }
                if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                    for (MenuItem tempPackage : menuItem.menuBiz.selectedModifier) {
                        if (TextUtils.isEmpty(tempPackage.menuBiz.createTime)) {
                            LogUtil.log("缺少createTime " + orderID + ",套餐头[" + menuItem.name + "][" + tempPackage.name + "],uniq[" + tempPackage.menuBiz.uniq + "]");
                            tempPackage.menuBiz.createTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
                        }
                    }
                }
                if (!menuItem.supportWeight() && menuItem.supportIngredient() && menuItem.menuBiz.selectedModifier.size() > 0 && menuItem.menuBiz.buyNum.compareTo(BigDecimal.ONE) > 0) {
                    tempOrder.tempSelectedMenuList.remove(i);
                    i--;
                    hasModifierItems.addAll(menuItem.splitIngredientItem());
                }
            }

            if (!ListUtil.listIsEmpty(hasModifierItems)) {
                tempOrder.tempSelectedMenuList.addAll(hasModifierItems);
            }

//            if (DBMetaUtil.autoUseMemberPrice()) {
//                if (orderCache.isMember && orderCache.memberInfoS != null) {
//                    //开启自动使用会员价 后加菜的菜品自动使用会员价
//                    OrderCache.updateAllMenuToMemberPrice(tempOrder.tempSelectedMenuList, orderCache.isMember, orderCache.memberInfoS.level);
//                }
//            }
            if (orderCache.isMember && orderCache.memberInfoS != null) {
                //开启自动使用会员价/会员折扣， 后加菜的菜品自动使用会员价/会员折扣
                MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache.shopID, tempOrder.tempSelectedMenuList, orderCache.isMember, orderCache.memberInfoS.level, userDBModel.fsUserId, orderCache.memberInfoS.cs_id, orderCache.memberInfoS.plusId);
            }

            // 关联提成人
            TableBusinessUtil.checkBonusInfo(tempOrder.tempSelectedMenuList, orderCache.waiterID);
            // 保存原始桌台信息
            TableBusinessUtil.setOriginTable(tempOrder.tempSelectedMenuList, orderCache.fsmtableid, orderCache.fsmtablename, false, "");

            orderCache.originMenuList.addAll(0, tempOrder.tempSelectedMenuList);
            orderCache.reCalcAllByAll();
            orderCache.currentSeq++;

            if (!TextUtils.isEmpty(tempOrder.cardNo) && orderCache.memberInfoS == null) {
                orderCache.manualFillMemerInfo(tempOrder.cardNo);
            }

            if (!TextUtils.isEmpty(tempOrder.note)) {
                if (TextUtils.isEmpty(orderCache.note)) {
                    orderCache.note += tempOrder.note;
                } else {
                    orderCache.note += ";" + tempOrder.note;
                }
            }
            //如果是正餐模式，则在加菜的时候，将已印单改为未印单
            if (orderCache.dinnerModel()) {
                TableBusinessUtil.modifyPrePrint(null, orderCache.fsmtableid, orderCache.orderID, TableStatusBean.GENERAL);
            }
            orderCache.fsCustName = tempOrder.bookCustName;
            orderCache.fsCustMobile = tempOrder.phone;
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--writeOrder--开始");
            OrderSession.getInstance().writeOrder(orderID, true, "addMenu");
            OrderSession.setPayed(orderID, 0);
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--writeOrder--结束");
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, tableID, orderID, " 站点：" + hostID + " 加菜-Cache ");
        }
        if (cleanRapidOrder) {
            TableBusinessUtil.cleanRapidOrder(orderCache.fsmtableid);
            MessageDBUtil.updateMessageOrderByTableId(orderCache.fsmtableid, MessageConstance.MessageOrderBuinessStatus.RAPID.GET, userDBModel);
            NotifyToClient.refrehMessageData();
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--updateMessageOrderByTableId--结束");
        }
        return socketResponse;
    }

    /**
     * 检查菜品和规格在业务中心是否存在
     *
     * @param menuItemList
     * @return
     */
    private static String checkMenuAndUnitIsExist(List<MenuItem> menuItemList) {
        for (MenuItem menuItem : menuItemList) {
            if (menuItem == null) {
                continue;
            }
            String fiItemCd = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiItemCd from tbMenuItem where fiItemCd = '" + menuItem.itemID + "' ");
            if (TextUtils.isEmpty(fiItemCd)) {
                return "菜品【" + menuItem.name + "】已删除";
            }
            if (menuItem.currentUnit == null) {
                return "菜品【" + menuItem.name + "】的规格不存在";
            }

            String unitName = MenuDBUtil.getUnitNameByID(menuItem.currentUnit.fiOrderUintCd);
            if (TextUtils.isEmpty(unitName)) {
                return "菜品【" + menuItem.name + "】的规格不存在";
            }

            if (menuItem.supportPackage() && !ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
                return checkMenuAndUnitIsExist(menuItem.menuBiz.selectedPackageItems);
            } else if (menuItem.supportIngredient() && !ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                return checkMenuAndUnitIsExist(menuItem.menuBiz.selectedModifier);
            }
        }
        return "";
    }

    /**
     * 添加餐标、低消服务费菜品,若添加成功，则单序+1
     */
    public static void addDinnerStandardMenus(OrderCache orderCache, UserDBModel userDBModel, String hostId) {
        if (orderCache != null) {
            // 添加前先矫正当前区域的最低消费金额
            DinnerStandardUtil.minStandardChanged(orderCache, orderCache.fsmareaid, userDBModel);
        }
        boolean addDSServiceMenuResult = DinnerStandardUtil.addDinnerStandardServiceMenu(orderCache);
        boolean addMSServiceMenuResult = DinnerStandardUtil.addMinStandardServiceMenu(orderCache);
        if (addDSServiceMenuResult || addMSServiceMenuResult) {
            //添加成功，则单序+1,状态为已下单
            orderCache.updateSeqStatus(0, OrderSeqStatus.ORDERED, userDBModel, hostId);
        }
    }

    /**
     * 存储支付信息
     *
     * @param orderID String
     * @param cache   PaySession
     */
    public static void savePay(final String orderID, final PaySession cache) {
        PaySaveDBUtil.save(orderID, cache, false);
    }

//    public static void saveOrder(final String orderID, final OrderCache cache) {
//        OrderSaveDBUtil.save(orderID, cache, false);
//    }

    /**
     * 生成一个新的ID并保存
     *
     * @param shopID String
     * @param idType String
     * @return int
     */
    public synchronized static String generateNewID(String shopID, String idType) {
        return generateNewID(shopID, idType, 1);
    }

    /**
     * 生成下一个有效的订单ID
     *
     * @param shopID
     * @param idType
     * @param retryCount 取号次数
     * @return
     */
    public synchronized static String generateNewID(final String shopID, final String idType, final int retryCount) {
        return generateNewID(shopID, idType, retryCount, true);
    }


    /**
     * 生成下一个有效的订单ID
     *
     * @param shopID
     * @param idType
     * @param retryCount       取号次数
     * @param autoCompensation 是否自动补偿：true:tbseqno表里拿不到订单号的时候或者订单号大于9999的时候拿时间补偿; false:tbseqno表里拿不到订单号的时候返回-1
     * @return
     */
    public synchronized static String generateNewID(final String shopID, final String idType, final int retryCount, boolean autoCompensation) {
        final int[] copyRetryCount = {retryCount};
        Integer value = DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Integer>() {
            @Override
            public Integer doJob(SQLiteDatabase db) {
                Cursor cursor = null;
                int value = -1;

                try {
                    String sql = "select fiSeqNo from tbSeqNo where fsshopguid='" + shopID + "' "
                            + " and fscls='" + idType + "'";

                    cursor = db.rawQuery(sql, null);
                    if (cursor != null) {
                        if (cursor.getCount() > 0) {
                            cursor.moveToNext();
                            int indexValue = cursor.getColumnIndex("fiSeqNo");
                            value = cursor.getInt(indexValue);
                            if (value >= 0) {
                                value++;
                            }
                        } else {
                            value = 1;
                        }
                    }
                    if (value <= 0) {
                        value = 1;
                    }
                    if (value > 9999 && TextUtils.equals(idType, OrderDriver.KEY_ORDER)) {
                        copyRetryCount[0] = 4;
                        return -1;
                    } else {
                        db.execSQL("replace into tbSeqNo(fiSeqNo, fsUpdateTime, fsCls,fsshopguid, lver, pver) values('" + value + "', '" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "', '" + idType + "','" + shopID + "','20', 1)  ");
                    }
                    return value;
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return null;
            }
        });

        if ((value == null || value <= 0)) {
            if (copyRetryCount[0] < 4) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    LogUtil.logError(e);
                }
                return generateNewID(shopID, idType, copyRetryCount[0] + 1, autoCompensation);
            } else {
                return autoCompensation ? DateUtil.getCurrentDate("HHmmss") : "-1";
            }
        }
        return String.valueOf(value);
    }

    /**
     * 检测订单号是否重复
     *
     * @param orderID String
     * @return boolean | true：重复；false：不重复
     */
    private static boolean checkOrderIDInvalid(String orderID) {
        String sql = "select order_id from order_cache where order_id='%s'";
        String dbOrderiD = DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format(sql, orderID));
        return TextUtils.equals(dbOrderiD, orderID);
    }

    /**
     * 生成一个完整的新订单号
     *
     * @return String
     */
    public static String generateNewOrderID() {
        return generateNewOrderID(OrderConfig.orderidByTime);
    }

    /**
     * 生成一个完整的新订单号
     *
     * @return String
     */
    public static String generateNewOrderID(boolean orderidByTime) {
        String shopID = HostUtil.getShopID();
        String newId = "";
        String date = HostUtil.getHistoryBusineeDate(shopID).replace("-", "");
        String orderId = "";
        //取号异常，拿到补偿号码
        boolean getByCompensation = false;

        if (orderidByTime) {
            newId = DateUtil.getCurrentDateTime("HHmmss");
            orderId = date + newId;
        } else {
            newId = OrderDriver.generateNewID(shopID, OrderDriver.KEY_ORDER, 1, false);
            if (TextUtils.equals("-1", newId)) {
                getByCompensation = true;
                newId = DateUtil.getCurrentDateTime("HHmmss");
            } else if (TextUtils.isEmpty(newId) || newId.length() < 4) {
                newId = RegexUtil.formatString(newId, 4);
            }
            orderId = date + newId;
        }

        boolean verify = false;
        synchronized (OrderDriver.class) {
            while (checkOrderIDInvalid(orderId) || ServerCache.getInstance().checkOrderIdCached(orderId)) {
                verify = true;
                long num = StringUtil.toLong(orderId, 0);
                num = num + 1L;
                orderId = String.valueOf(num);
            }
        }

        //如果从tbseqno表中取出的值后来被修改过，要重新更新tbseqno表
        if (verify && !orderidByTime && !getByCompensation) {
            saveID(shopID, OrderDriver.KEY_ORDER, StringUtil.toInt(orderId.substring(date.length()), 0));
        }
        return orderId;
    }


    /**
     * 生成一个新订单
     *
     * @return
     */
    public synchronized static OrderCache generateNewOrder() {
        String orderID = OrderDriver.generateNewOrderID();
        return generateNewOrder(orderID);
    }

    /**
     * 生成一个新订单
     *
     * @param orderID 订单号
     * @return
     */
    public synchronized static OrderCache generateNewOrder(String orderID) {
        OrderCache order = new OrderCache();
        order.orderID = orderID;

        // 当日已上传账单，后续账单默认隐藏
        String status = IOCache.getCacheStr(CacheKey.BILL_UPLOAD_DATE_STATUS + HostUtil.getHistoryBusineeDate(""));
        if (TextUtils.equals(status, "0") || TextUtils.equals(status, "1")) {
            order.hidden = 1;
        }
        order.fsAccountBook = ",1,";
        return order;
    }

    /**
     * 读取当前的值
     *
     * @param shopID String
     * @param idType String
     * @return String
     */
    public synchronized static String readLastID(String shopID, String idType) {
        String tableName = DBModel.getTableName(SeqnoDBModel.class);
        String sql = "select fiSeqNo from " + tableName
                + " where fsshopguid='" + shopID + "' "
                + " and fscls='" + idType + "'";
        String result = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(result)) {
            result = "0";
        }
        return result;
    }

    /**
     * 更新tbseqno指定value的fiseqno值
     *
     * @param shopID String
     * @param idType String
     */
    public synchronized static void saveID(String shopID, String idType, int value) {
        String sql = "where fsshopguid='" + shopID + "' "
                + " and fscls='" + idType + "'";
        SeqnoDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, SeqnoDBModel.class);
        if (model == null) {
            model = new SeqnoDBModel();
            model.fiSeqNo = 0;
            model.fsshopguid = shopID;
            model.fscls = idType;
        }
        model.fiSeqNo = value;
        model.lver++;
        model.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        model.replaceNoTrans();
    }

    public static String getTableIDByOrderID(String orderid) {
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tbsell where fssellno='" + orderid + "'");
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 构建订单ID
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getbizid")
    public SocketResponse buildOrderId(SocketHeader head, String params) {
        //GetNumOrderIDRequest request = JSON.parseObject(params, GetNumOrderIDRequest.class);
        JSONObject request = JSON.parseObject(params);
        SocketResponse socketResponse = new SocketResponse();
        if (request != null) {
            GetNumOrderIDResponse response = new GetNumOrderIDResponse();
            String key = "";
            switch (request.getIntValue("type")) {
                case 1:
                    key = KEY_ORDER;
                    break;
                case 2:
                    key = KEY_BILL;
                    break;
            }

            response.id = generateNewID(request.getString("shopId"), key);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } else {
            socketResponse.code = SocketResultCode.DESERIALIZE_FAILED;
        }
        return socketResponse;
    }

    /**
     * 重打结账单小票
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/reprinterBillRecept")
    public SocketResponse reprinterBillRecept(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        final ReprintBillReceptResponse response = new ReprintBillReceptResponse();
        socketResponse.data = response;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                userDBModel = new UserDBModel();
            }
            JSONObject request = JSON.parseObject(params);
            String fsSellNo = request.getString("fsSellNo");
            String businessDate = request.getString("businessDate");
            String fiSellType = request.getString("fiSellType");
            String orderSource = request.getString("orderSource");
            String hostId = head.hd;

            List<Integer> list;
            //根据订单数据是否已经迁移到从库状态，获取此订单所在的数据库名称
            String databaseName = getDatabaseName(orderSource, businessDate);
            //获取这笔订单的会员卡号
            String fsCardNo = DBSimpleUtil.queryString(databaseName, "select fsCardNo from tbSell where fsSellNo = '" + fsSellNo + "'");

            MemberInfo memberInfo = null;

            if (!TextUtils.isEmpty(fsCardNo) && ServerSettingHelper.isBillPrintBalanceAndScore()) {
                memberInfo = MemberApi.queryMemberInfo(fsCardNo);
            }
            if (TextUtils.equals(fiSellType, "0")) {
                list = PrintBillUtil.printDinnerBill(fsSellNo, memberInfo, "", hostId, false, userDBModel, databaseName);
            } else {
                list = PrintBillUtil.printFastFoodBill(fsSellNo, memberInfo, hostId, userDBModel.fsUserName, databaseName);
            }
            if (!ListUtil.isEmpty(list)) {
                response.printNoList.addAll(list);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 判断订单存在哪个库，返回存在此订单所在的数据库名称
     *
     * @param dataSourceStatus 订单来源哪个库  0:订单来自从库，1：来自主库
     * @return
     */
    public static String getDatabaseName(String dataSourceStatus, String businessDate) {
        //订单来源哪个库  0:订单来自从库，1：来自主库
        // TODO: 2018/5/18
//        if (TextUtils.equals(dataSourceStatus, "0")) {
//            return SlaveDBUtil.findDBWithSell(GlobalCache.getContext(), null, businessDate);
//        } else {
//            return APPConfig.DB_MAIN;
//        }
        return APPConfig.DB_MAIN;
    }

    /**
     * 加菜
     *
     * @param param String
     * @return SocketResponse
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @DrivenMethod(uri = TAG + "/addMenu")
    public SocketResponse d(SocketHeader head, String param) {
        LogUtil.logOnlineDebug("--order--bizCenter--addMenu--SocketResponse--param:" + param);
        SocketResponse<OpenTableAndCheckToOrderRespose> socketResponse = new SocketResponse<OpenTableAndCheckToOrderRespose>();
        OpenTableAndCheckToOrderRespose resposeData = new OpenTableAndCheckToOrderRespose();
        socketResponse.data = resposeData;
        try {
            JSONObject request = JSON.parseObject(param);
            String targetOrderID = request.getString("targetOrderID");
            if (!ServerCache.getInstance().verifyToken(targetOrderID, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }
            TempOrderDishesCache tempOrder = JSON.parseObject(request.getString("tempOrder"), TempOrderDishesCache.class);
            if (TextUtils.isEmpty(tempOrder.currentHostID)) {
                tempOrder.currentHostID = head.hd;
            }

            addMenu(socketResponse, head.hd, tempOrder.fsmtableid, targetOrderID, tempOrder, tempOrder.source == -1);
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--SocketResponse--结束--code:" + socketResponse.code);
            if (socketResponse.code != SocketResultCode.SUCCESS) {
                return socketResponse;
            }
            if (request.getBoolean("isPrinter")) {
                final ArrayList<Integer> printTaskIds = new ArrayList<>();
                OrderCache orderCache = OrderSession.getInstance().getOrder(targetOrderID);

                List<Integer> printIDs = PrintOrderUtil.printMenuList(orderCache, null, tempOrder.currentHostID);
                if (!ListUtil.isEmpty(printIDs)) {
                    socketResponse.data.printTaskIds.addAll(printIDs);
                }

                if (DBOrderConfig.useKdsService()) {
                    KdsManager.getInstance().order(orderCache, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", tempOrder.currentHostID, HostUtil.getUserModelBySession(head.us));
                } else {
                    List<Integer> list = PrintOrderUtil.printPassTo(orderCache, tempOrder.currentHostID);
                    if (!ListUtil.isEmpty(list)) {
                        socketResponse.data.printTaskIds.addAll(list);
                    }
                    //交给业务中心打印
                    LogUtil.logOnlineDebug("--order--bizCenter--交给业务中心打印----");
                    PrintOrderUtil.printMakeOrder(orderCache, tempOrder.currentHostID, orderCache.seqList.get(orderCache.seqList.size() - 1).seqNo + "", null);
                }
            }
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--SocketResponse--结束--返回");
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            NotifyToClient.orderChange(targetOrderID); // 同步订单后，可能影响到桌台页显示的订单相关信息，如订单总价
            LogUtil.logOnlineDebug("--order--bizCenter--addMenu--SocketResponse--结束-发消息");
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 检查订单是否
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/checkOrderOpenParam")
    public SocketResponse checkOrderOpenParam(SocketHeader head, String param) {

        long time = System.currentTimeMillis();

        SocketResponse socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            OrderCache orderCache = OrderSaveDBUtil.get(orderId);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "未找到指定订单";
                return socketResponse;
            }

            //这里的userID和UserName是开台预点菜赠送时使用的，这里不取用预点菜，仅做数据校验，所有可以不传userId和userName
            String checkResult = OrderBizUtil.checkOrderOpenParam(orderCache, "", "");

            if (TextUtils.isEmpty(checkResult)) {
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "预定菜已全部下单";
            } else {
                socketResponse.code = -10001;
                socketResponse.message = checkResult;
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        LogUtil.logBusiness(TAG, "checkOrderOpenParam cost:" + (System.currentTimeMillis() - time));
        return socketResponse;
    }

    /**
     * 解绑会员信息
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/orderUnBindMenberInfo")
    public SocketResponse orderUnBindMenberInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse socketResponse = new SocketResponse();
        ChangeOrderWithMemberResponse response = new ChangeOrderWithMemberResponse();
        socketResponse.data = response;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            final String orderId = request.getString("orderId");

            if (TextUtils.isEmpty(orderId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单信息异常，请稍后重试";
                return socketResponse;
            }
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "未找到该订单，请稍后重试";
                return socketResponse;
            }

            if (orderCache.orderStatus == OrderStatus.PAIED) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "订单已被结账";
                return socketResponse;
            }

            if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                socketResponse.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                return socketResponse;
            }

            String memberCardNo = request.getString("cardNo");

            if (TextUtils.isEmpty(memberCardNo)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "会员卡号异常";
                return socketResponse;
            }

            if (orderCache.memberInfoS == null) {
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "账单没有绑定会员卡";
                return socketResponse;
            }

            if (!TextUtils.equals(orderCache.memberInfoS.card_no, memberCardNo)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "账单绑定的会员和解绑会员不一致";
                return socketResponse;
            }
            if (orderCache.memberInfoS != null) {
                ServerCache.getInstance().releaseMemberComments(orderCache.memberInfoS.card_no);
            }
            orderCache.clearMember();

            OrderSession.getInstance().writeOrder(orderId, true, "orderUnBindMenberInfo");
//            OrderProcessor.saveOrder(orderCache, null);

            if (!orderCache.dinnerModel()) {
                response.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                response.menuItemList.addAll(orderCache.originMenuList);
            } else {
                response.orderCache = orderCache;
            }

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "更新成功";
            socketResponse.data = response;
            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 第三方会员卡号与美味会员卡号绑定---------已废弃
     *
     * @param param String
     * @return SocketResponse
     */
    @Deprecated
    @DrivenMethod(uri = TAG + "/thirdMemberBind")
    public SocketResponse thirdMemberBind(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final BaseSocketResponse dataResponse = new BaseSocketResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);

            final String mwNumber = request.getString("mwNumber");
            final String thirdNumber = request.getString("thirdNumber");

            if (TextUtils.isEmpty(thirdNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入实体卡号";
                return response;
            }

            if (TextUtils.isEmpty(mwNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入美味会员卡号";
                return response;
            }

            //存储关联关系
            String errMsg = CardRelationDBUtil.bindCard(thirdNumber, mwNumber, userDBModel);
            if (TextUtils.isEmpty(errMsg)) {
                response.code = SocketResultCode.SUCCESS;
                response.message = "开卡成功";
            } else {
                response.code = SocketResultCode.SUCCESS;
                response.message = errMsg;
            }

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 查询相关的实体卡号
     */
    @Deprecated
    @DrivenMethod(uri = TAG + "/queryEntityCardBy")
    public SocketResponse queryEntityCardByMobile(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            String cardNo = request.getString("cardNo");

            if (TextUtils.isEmpty(cardNo)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请输入会员卡号";
                return socketResponse;
            }
            NewMemberQueryEntityCardNumBerRequest entityCardByMobileRequest = new NewMemberQueryEntityCardNumBerRequest();
            //获取 fsCompanyGUID
            entityCardByMobileRequest.brandId = Integer.parseInt(MemberApi.getCompanyGUID());
            entityCardByMobileRequest.cardNo = cardNo;
            BusinessExecutor.execute(entityCardByMobileRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof NewMemberQueryEntityCardNumBerResponse) {
                        NewMemberQueryEntityCardNumBerResponse cardNumBerResponse = (NewMemberQueryEntityCardNumBerResponse) responseData.responseBean;
                        socketResponse.data = cardNumBerResponse;
                        socketResponse.code = SocketResultCode.SUCCESS;
                        socketResponse.message = "查询会员实体卡信息成功";
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    if (responseData != null && !android.text.TextUtils.isEmpty(responseData.resultMessage)) {
                        socketResponse.code = responseData.result;
                        socketResponse.message = responseData.resultMessage;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "查询会员实体卡信息失败";
                    }
                    return false;
                }
            }, false);

        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    /**
     * 会员开卡----支持第三方卡与会员实体卡
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/memberBindCard")
    public SocketResponse memberBindCard(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final BaseSocketResponse dataResponse = new BaseSocketResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);

            //卡类型 0：虚拟卡； 1：手机号激活； 2：不记名激活
            String cardType = request.getString("cardType");
            String cardNumber = request.getString("cardNumber");
            String phone = request.getString("phone");
            String verificationCode = request.getString("verificationCode");
            String nameValue = request.getString("nameValue");
            int sex = request.getIntValue("sex");
            String birthdayValue = request.getString("birthdayValue");

            if (TextUtils.isEmpty(cardNumber)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入卡号";
                return response;
            }

            if (TextUtils.isEmpty(phone)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入手机号";
                return response;
            }

            if (TextUtils.isEmpty(verificationCode) && !TextUtils.equals(cardType, "0")) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "请输入验证码";
                return response;
            }

            if (TextUtils.equals(cardType, "0")) {
                //虚拟卡开卡
                if (!TextUtils.isEmpty(verificationCode)) {
                    //如果输入了验证码，需要校验验证码是否正确
                    MemberApi.checkVerificationCode(phone, verificationCode, new IResponse() {
                        @Override
                        public void callBack(boolean result, int code, String msg, Object info) {
                            if (result) {
                                bindCard(cardNumber, phone, userDBModel, response);
                            } else {
                                response.code = code;
                                response.message = msg;
                            }
                        }
                    });
                } else {
                    bindCard(cardNumber, phone, userDBModel, response);
                }
            } else {
                MemberApi.memberBindCard(cardNumber, phone, verificationCode, nameValue, sex, birthdayValue, userDBModel, new IResponse() {
                    @Override
                    public void callBack(boolean result, int code, String msg, Object info) {
                        if (result) {
                            response.code = SocketResultCode.SUCCESS;
                            response.message = TextUtils.isEmpty(msg) ? "开卡成功" : msg;
                        } else {
                            response.code = code;
                            response.message = msg;
                        }
                    }
                });
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 虚拟卡开卡
     *
     * @param cardNumber  卡号
     * @param phone       手机号
     * @param userDBModel 操作服务员
     * @param response
     */
    private void bindCard(String cardNumber, String phone, UserDBModel userDBModel, SocketResponse response) {
        //如果没输入验证码，直接绑定
        String errMsg = CardRelationDBUtil.bindCard(cardNumber, phone, userDBModel);
        if (TextUtils.isEmpty(errMsg)) {
            response.code = SocketResultCode.SUCCESS;
            response.message = "开卡成功,若有实体卡，实体卡依旧可用";
        } else {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = errMsg;
        }
    }


    /**
     * 查询并绑定会员信息到订单上
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/queryAndBindMemberToOrder")
    public SocketResponse queryAndBindMemberToOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final QueryMemberInfoAndBindToOrderResponse dataResponse = new QueryMemberInfoAndBindToOrderResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            final String orderId = request.getString("orderId");
            final boolean isUsedMemberPrice = request.getBooleanValue("isUsedMemberPrice");
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (TextUtils.isEmpty(orderId)) {
//                response.code = SocketResultCode.BUSINESS_FAILED;
//                response.message = "订单信息异常，请稍后重试";
//                return response;
                RunTimeLog.addLog(RunTimeLog.MEMBER_PRE_BIND, "OrderDriver -> 订单号为空，模式为下单前绑定会员");
            } else {
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请稍后重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }
            }

            String number = request.getString("number");

            if (TextUtils.isEmpty(number)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "会员卡号或手机号为空";
                return response;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(number);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员号与美味会员号映射【" + number + "," + cardNoRelation + "】");
                number = cardNoRelation;
            }

            MemberBizUtil.getMemberCardRequest(number, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                        GetMemberCardResponse responseBean = (GetMemberCardResponse) responseData.responseBean;
                        if (responseBean.data != null) {
                            MemberCardModel memberCardModel = responseBean.data;
                            dataResponse.memberCardModel = memberCardModel;

                            // ServerCache 中缓存 MemberCardModel。下单前绑定会员，使用优惠折扣需要判断是否会员及会员等级等信息
                            ServerCache.getInstance().putMemberWithHost(head.hd, memberCardModel);

                            if (orderCache != null) {
                                orderCache.setMember(memberCardModel);
//                                if (isUsedMemberPrice) {
//                                    orderCache.updateAllMenuToMemberPrice();
//                                    orderCache.reCalcAllByAll();
//                                }
                                MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, userDBModel.fsUserId);
                                OrderSession.getInstance().writeOrder(orderId, false, "queryAndBindMemberToOrder success");
                                //快餐开台绑定会员，没有点菜下单，此时应拦截将订单信息写入tbsell表，不然在账单管理页面可以看到此订单
                                if (orderCache.fastFoodModel()) {
                                    String status = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderId + "'");
                                    if (!TextUtils.equals("0", status)) {
                                        OrderProcessor.saveOrder(orderCache, null);
                                    }
                                } else {
                                    OrderProcessor.saveOrder(orderCache, null);
                                }
                                if (orderCache.dinnerModel()) {
                                    dataResponse.orderCache = orderCache;
                                    MemberBizUtil.requestMemberComents(memberCardModel.card_info.card_no);
                                } else {
                                    dataResponse.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);
                                    dataResponse.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(orderCache);
                                    dataResponse.menuItemList.addAll(orderCache.originMenuList);
                                }
                            }
                            response.code = SocketResultCode.SUCCESS;
                            response.message = "操作成功";
                        } else {
                            response.code = SocketResultCode.BUSINESS_FAILED;
                            response.message = "会员信息异常";
                        }
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && !android.text.TextUtils.isEmpty(responseData.resultMessage)) {
                        response.code = responseData.result;
                        response.message = responseData.resultMessage;
                    } else {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "查询会员信息失败";
                    }
                    return false;
                }
            });


            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 查询并绑定会员信息到订单上
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/queryAndBindMemberToOrderForCode")
    public SocketResponse queryAndBindMemberToOrderForCode(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();

        final QueryMemberInfoAndBindToOrderResponse dataResponse = new QueryMemberInfoAndBindToOrderResponse();
        response.data = dataResponse;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            final String orderId = request.getString("orderId");
            final boolean isUsedMemberPrice = request.getBooleanValue("isUsedMemberPrice");
            String code = request.getString("code");
            final OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (TextUtils.isEmpty(orderId)) {
//                response.code = SocketResultCode.BUSINESS_FAILED;
//                response.message = "订单信息异常，请稍后重试";
//                return response;
                RunTimeLog.addLog(RunTimeLog.MEMBER_PRE_BIND, "OrderDriver -> 订单号为空，模式为下单前绑定会员");
            } else {
                if (orderCache == null) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "未找到该订单，请稍后重试";
                    return response;
                }

                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = "订单已被结账";
                    return response;
                }

                if (!ServerCache.getInstance().verifyToken(orderId, head.ot)) {
                    response.code = SocketResultCode.ORDER_TOKEN_EXPIRED;
                    return response;
                }
            }

            String number = request.getString("number");

            if (TextUtils.isEmpty(number)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "会员卡号或手机号为空";
                return response;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(number);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员号与美味会员号映射【" + number + "," + cardNoRelation + "】");
                number = cardNoRelation;
            }

            MemberBizUtil.getMemberCardByMobileAndCode(number, code, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                        GetMemberCardResponse responseBean = (GetMemberCardResponse) responseData.responseBean;
                        if (responseBean.data != null) {
                            MemberCardModel memberCardModel = responseBean.data;
                            dataResponse.memberCardModel = memberCardModel;
                            // ServerCache 中缓存 MemberCardModel。下单前绑定会员，使用优惠折扣需要判断是否会员及会员等级等信息
                            ServerCache.getInstance().putMemberWithHost(head.hd, memberCardModel);
                            if (orderCache != null) {
                                orderCache.setMember(memberCardModel);
//                                if (isUsedMemberPrice) {
//                                    orderCache.updateAllMenuToMemberPrice();
//                                }
                                MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, userDBModel.fsUserId);
                                orderCache.reCalcAllByAll();
                                OrderSession.getInstance().writeOrder(orderId, false, "queryAndBindMemberToOrderForCode success 2");
                                //快餐开台绑定会员，没有点菜下单，此时应拦截将订单信息写入tbsell表，不然在账单管理页面可以看到此订单
                                if (orderCache.fastFoodModel()) {
                                    String status = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderId + "'");
                                    if (!TextUtils.equals("0", status)) {
                                        OrderProcessor.saveOrder(orderCache, null);
                                    }
                                } else {
                                    OrderProcessor.saveOrder(orderCache, null);
                                }
                                if (orderCache.dinnerModel()) {
                                    dataResponse.orderCache = orderCache;
                                    MemberBizUtil.requestMemberComents(memberCardModel.card_info.card_no);
                                } else {
                                    dataResponse.fastOrderynamicDMode = FastFoodBusinessUtil.optFastOrderynamicDMode(orderCache);

                                    dataResponse.menuItemList.addAll(orderCache.originMenuList);
                                }
                            }
                            response.code = SocketResultCode.SUCCESS;
                            response.message = "操作成功";
                        } else {
                            response.code = SocketResultCode.BUSINESS_FAILED;
                            response.message = "会员信息异常";
                        }
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && !android.text.TextUtils.isEmpty(responseData.resultMessage)) {
                        response.code = responseData.result;
                        response.message = responseData.resultMessage;
                    } else {
                        response.code = SocketResultCode.BUSINESS_FAILED;
                        response.message = "查询会员信息失败";
                    }
                    return false;
                }
            });


            NotifyToClient.orderChange(orderId);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 查询会员信息
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/queryMemberInfo")
    public SocketResponse queryMemberInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse socketResponse = new SocketResponse();

        final QueryMemberInfoResponse response = new QueryMemberInfoResponse();
        socketResponse.data = response;
        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
                socketResponse.message = "登录信息已过期";
                return socketResponse;
            }

            JSONObject request = JSON.parseObject(param);
            String number = request.getString("number");

            if (TextUtils.isEmpty(number)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "会员卡号或手机号为空";
                return socketResponse;
            }

            String cardNoRelation = CardRelationDBUtil.optMWNumber(number);
            if (!TextUtils.isEmpty(cardNoRelation)) {
                RunTimeLog.addLog(RunTimeLog.MEMBER, "查到第三方会员好与美味会员号映射【" + number + "," + cardNoRelation + "】");
                number = cardNoRelation;
            }

            MemberBizUtil.getMemberCardRequest(number, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetMemberCardResponse) {
                        GetMemberCardResponse responseBean = (GetMemberCardResponse) responseData.responseBean;
                        if (responseBean.data != null) {

                            response.memberCardModel = responseBean.data;

                            socketResponse.code = SocketResultCode.SUCCESS;
                            socketResponse.message = "操作成功";
                        } else {
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = "会员信息异常";
                        }
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData != null && !android.text.TextUtils.isEmpty(responseData.resultMessage)) {
                        socketResponse.code = responseData.result;
                        socketResponse.message = responseData.resultMessage;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "查询会员信息失败";
                    }
                    return false;
                }
            });

        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/uploadDataToServer")
    public SocketResponse f(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            //CallUploadDataToServerRequest request = JSON.parseObject(param, CallUploadDataToServerRequest.class);
            JSONObject request = JSONObject.parseObject(param);
            String orderID = request.getString("orderID");
            LogUtil.logBusiness(TAG, "orderID:" + orderID + "; 准备上报");
            List<String> orderIdList = new ArrayList<>();
            if (!TextUtils.isEmpty(orderID)) {
                orderIdList.add(orderID);
            }
            UploadDataHelper.uploadAllData(orderIdList, true, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    NotifyToClient.sendTo(head.hd, "login/dataSyncResult", "0", "同步成功");
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    String errorMsg = "同步失败";
                    if (!TextUtils.isEmpty(responseData.resultMessage)) {
                        errorMsg = responseData.resultMessage;
                    }
                    NotifyToClient.sendTo(head.hd, "login/dataSyncResult", "-1", errorMsg);
                    return false;
                }
            }, new IProgressCallback() {
                @Override
                public void onProgress(int progress, String tag) {
                    NotifyToClient.sendTo(head.hd, "login/uploadDataProgress", progress + "", tag);
                }
            });
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 账单管理页---获取账单
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getOrders")
    public SocketResponse e(SocketHeader header, String param) {
        JSONObject request = JSON.parseObject(param);
        SocketResponse socketResponse = new SocketResponse();

        try {
            GetOrderFromCenterRespone respone = new GetOrderFromCenterRespone();
            String shopID = HostUtil.getShopID();
            int currentPage = request.getInteger("currentPage");
            String numberNo = request.getString("numberNo");
            String businessDate = request.getString("businessDate");

            //订单类型 0 ： 正餐； 1：快餐; 2:外卖
            int fiSellType = request.getObject("fiSellType", Integer.class);
            int billType = request.getInteger("billType");
            // 账套id
            String accountBookId = request.getString("accountBookId");
            // 订单来源
            String fsBillSourceId = request.getString("fsBillSourceId");

            StringBuilder stringBuilder = new StringBuilder(String.format("'%s'", fiSellType));
            if (fiSellType == 1) {
                stringBuilder.append(",").append("'4'");
            }

            // 订单支付状态 0全部，1未结账，2已结账
            int payStatus = request.getInteger("payStatus");
            String billStatusStr;
            if (payStatus == 1) {
                billStatusStr = "'1','2','4','5'";
            } else if (payStatus == 2) {
                billStatusStr = "'" + OrderStatus.PAIED + "'";
            } else {
                billStatusStr = "'1','2','3','4','5'";
            }

            String withOrderID = request.getString("withOrderID");
            String tableName = request.getString("tableName");
            boolean searchUnPayedOrder = request.getBooleanValue("searchUnPayedOrder");
            String withoutOrderID = request.getString("withOutOrderID");
            Pair<Integer, List<OrderListModel>> orderData = OrderListUtil.getOrderList(currentPage, numberNo,
                    searchUnPayedOrder, businessDate, stringBuilder.toString(), shopID, withoutOrderID, withOrderID,
                    billType, accountBookId, billStatusStr, tableName, fsBillSourceId);
            List<OrderListModel> orderList = orderData.second;

            ArrayMap<String, List<OrderListMenuModel>> menu = null;
            ArrayMap<String, List<OrderListPayModel>> payMap = null;
            if (request.getBooleanValue("searchMenu")) {
                menu = OrderListUtil.getOrderMenuList(businessDate, shopID, withOrderID);
            }
            if (request.getBooleanValue("searchPay")) {
                payMap = OrderListUtil.getOrderPayList(businessDate, shopID, withOrderID);
            }
            if (orderList == null) {
                orderList = new ArrayList<>();
            }

            for (OrderListModel temp : orderList) {
                if (menu != null) {
                    temp.menuList = menu.get(temp.orderID);
                    if (!ListUtil.isEmpty(temp.menuList)) {
                        boolean allVoid = true;
                        for (OrderListMenuModel tempMenu : temp.menuList) {
                            if (!tempMenu.isVoid) {
                                allVoid = false;
                                break;
                            }
                        }
                        temp.isAllVoid = allVoid;
                    }
                }
                if (payMap != null) {
                    temp.payList = payMap.get(temp.orderID);
                }
            }

            respone.orderList2 = orderList;

            //todo 若 numberNo==null||numberNo==""  为分页查询   否则为模糊查询
            if (TextUtils.isEmpty(numberNo)) {
                respone.pageCount = (orderData.first == null ? 0 : orderData.first + 20 - 1) / 20;
                socketResponse.message = "同步成功";
            } else {
                socketResponse.message = "搜索成功";
            }

            socketResponse.code = SocketResultCode.SUCCESS;

            socketResponse.data = respone;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }


    /**
     * 美小易 账单管理页---获取账单
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadMBillOrderData")
    public SocketResponse loadMBillOrderData(SocketHeader header, String param) {
        JSONObject request = JSON.parseObject(param);
        SocketResponse socketResponse = new SocketResponse();

        try {
            GetOrderFromCenterRespone respone = new GetOrderFromCenterRespone();

            //订单类型 0 ： 正餐； 1：快餐; 2:外卖
            int fiSellType = request.getObject("fiSellType", Integer.class);

            int currentPage = request.getInteger("currentPage");

            String businessDate = request.getString("businessDate");

            // 订单支付状态 0全部，1未结账，2已结账
            int payStatus = request.getInteger("payStatus");

            // 订单来源
            String fsBillSourceId = request.getString("fsBillSourceId");

            /**
             * fiSellTypeAppend 快餐类型  所有要拼接字符串
             *      轻快餐   1
             *      口碑快餐 4
             */
            StringBuilder fiSellTypeAppend = new StringBuilder(String.format("'%s'", fiSellType));
            if (fiSellType == 1) {
                fiSellTypeAppend.append(",").append("'4'");
            }

            String billStatusStr;
            if (payStatus == 1) {
                billStatusStr = "'1','2','4','5'";
            } else if (payStatus == 2) {
                billStatusStr = "'" + OrderStatus.PAIED + "'";
            } else {
                billStatusStr = "'1','2','3','4','5'";
            }

            String sqlOrder = MBillOrderUtils.queryMBillSql(fiSellTypeAppend.toString(), currentPage, businessDate, billStatusStr, fsBillSourceId);
            List<OrderListModel> orderList = MBillOrderUtils.loadMBillOrderData(sqlOrder);
            respone.orderList2 = orderList;

            String sqlOrderTotalRecord = "select count(*) from tbsell left outer join tbSellCheck on" +
                    " tbsell.fsSellNo=tbSellCheck.fsSellNo" +
                    " where" +
                    " tbSell.fiSellType in (" + fiSellType + ") and " +
                    " tbsell.fsSellDate='" + businessDate + "'" +
                    " and " +
                    " tbsell.fiBillStatus in (" + billStatusStr + ")";
            if (!TextUtils.isEmpty(fsBillSourceId) && !TextUtils.equals("-1", fsBillSourceId)) {
                sqlOrderTotalRecord += " AND tbSell.fsBillSourceId = '" + fsBillSourceId + "'";
            }
            sqlOrderTotalRecord += " order by tbsell.fsSellNo desc";

            int totalRecord = Integer.valueOf(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlOrderTotalRecord));
            respone.pageCount = (totalRecord + 20 - 1) / 20;
            socketResponse.message = "同步成功";
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = respone;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }


    @DrivenMethod(uri = TAG + "/getPay")
    public SocketResponse getPay(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            GetPaySessionResponse respone = new GetPaySessionResponse();
            int fiSellType = request.getInteger("fiSellType");
            String orderid = request.getString("orderid");
            boolean onlyCheckPayed = request.containsKey("onlyCheckPayed") ? request.getBoolean("onlyCheckPayed") : false;
            boolean getIdIfNoPay = request.containsKey("getIdIfNoPay") ? request.getBoolean("getIdIfNoPay") : false;

            OrderCache orderCache = JSON.parseObject(request.getString("orderCache"), OrderCache.class);
            //同步快餐单
            if (fiSellType == 1) {
                OrderSession.getInstance().writeOrder(orderid, orderCache, false, "getPay");
            }


            if (onlyCheckPayed) {
                if (fiSellType == 0) {
                    respone.needRefreshOrder = TableBusinessUtil.fixTableStatusByOrderID(orderid) ? 1 : 0;
                }
                int orderStatus = 0;
                String orderStatusStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_status from order_cache where order_id='" + orderid + "'");
                if (!TextUtils.isEmpty(orderStatusStr)) {
                    respone.orderStatus = StringUtil.toInt(orderStatusStr, 0);
                }
            } else {
                respone.paySession = OrderSession.getInstance().getPay(orderid);
                respone.order = OrderSession.getInstance().getOrder(orderid);
                if (!respone.order.dinnerModel()) {
                    respone.fastOrderModel = FastFoodBusinessUtil.turnOrderCacheToFastOrderModel(respone.order);
                }
                if (respone.paySession == null) {
                    if (getIdIfNoPay) {
                        String shopId = HostUtil.getShopID();
                        int lastOrderID = StringUtil.toInt(readLastID(shopId, KEY_BILL), 0);
                        lastOrderID++;
                        saveID(shopId, KEY_BILL, lastOrderID);
                        respone.billNo = lastOrderID;
                    } else {
                    }
                } else {
                    OrderUtil.checkPaySession(respone.paySession, respone.order);
                }
            }
            if (respone.order != null) {
                respone.orderStatus = respone.order.orderStatus;
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            socketResponse.data = respone;
            respone.payBase = BillUtil.buildPayBase(orderid);
            respone.payView = BillUtil.buildPayViewData(orderid);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/getOrderDetails")
    public SocketResponse getOrderDetails(SocketHeader header, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSONObject.parseObject(param);

            String orderId = request.getString("orderId");
            boolean isKoubei = request.getBoolean("isKoubei");

            GetOrderDetailsResponse response = new GetOrderDetailsResponse();
            OrderDetailsModel orderDetails = new OrderDetailsModel();

            OrderSession session = OrderSession.getInstance();
            OrderCache orderCache = session.getOrder(orderId);
            PaySession paySession = session.getPay(orderId);

            if (orderCache != null) {
                orderDetails.shopGUID = orderCache.shopID;
                orderDetails.orderID = orderCache.orderID;
                orderDetails.businessDate = orderCache.businessDate;
                orderDetails.personNum = orderCache.personNum;
                orderDetails.createTimeOrder = orderCache.createTime;
                orderDetails.fsmtableid = orderCache.fsmtableid;
                orderDetails.fsmtablename = orderCache.fsmtablename;
                orderDetails.mealNumber = orderCache.mealNumber;
                orderDetails.orderWaiterID = orderCache.waiterID;
                orderDetails.orderWaiterName = orderCache.waiterName;
                orderDetails.totalPrice = orderCache.optTotalPriceBeforeDiscountByCheckFreeFee();
                orderDetails.totalRound = orderCache.totalRound;
                orderDetails.totalDiscount = orderCache.totalDiscountAmount;
                orderDetails.priceLeftToPay = orderCache.optTotalPrice();
                orderDetails.fiSellType = orderCache.fiSellType;
                orderDetails.thirdOrderType = orderCache.thirdOrderType;
                orderDetails.thirdOrderId = orderCache.thirdOrderId;
                orderDetails.orderNote = orderCache.note;
                orderDetails.eatType = orderCache.eatType;
                orderDetails.menuItemList = orderCache.originMenuList;
            }

            if (paySession != null) {
                orderDetails.createTimeBill = paySession.createTime;
                orderDetails.billNO = paySession.billNO;
                orderDetails.locked = paySession.locked;
                orderDetails.payed = paySession.payed;
                orderDetails.payTime = paySession.payTime;
                orderDetails.payShiftID = paySession.currentShiftID;
                orderDetails.payShiftName = ShiftDBUtils.getShiftNameById(paySession.currentShiftID);
                orderDetails.payWaiterID = paySession.waiterID;
                orderDetails.payWaiterName = paySession.waiterName;
                for (PayModel pay : paySession.selectPayListFull) {
                    if (pay != null && pay.status == PayTypeStatus.ENABLE) {
                        orderDetails.payList.add(pay);
                    }
                }
            }

            if (isKoubei && !TextUtils.isEmpty(orderDetails.thirdOrderId)) {
                KBPreOrderCache kbOrder = KBPreOrderDBUtils.query(orderDetails.thirdOrderId);
                if (kbOrder != null) {
                    orderDetails.mealNumber = kbOrder.take_no;
                    orderDetails.user_mobile = kbOrder.user_mobile;
                    orderDetails.table_time = kbOrder.table_time;
                    orderDetails.dinner_type = kbOrder.dinner_type;
                }
            }

            response.orderDetails = orderDetails;

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取正餐所有未交班的信息
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/unfinish_shift")
    public SocketResponse getUnfinishShift(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSONObject.parseObject(param);

            String businessDate = request.getString("businessDate");
            String sql = "select count(*) as ordernum,sum(case tbSell.fiBillStatus when 3 then 1 else 0 end) as payednum," +
                    "sum(tbSellCheck.fdRealAmt) as totalAmount, tbSellCheck.fsShiftId as shiftid,(case tbSellCheck.fiStatus when 2 then 1 ELSE 0 end ) as locked," +
                    "tbSellCheck.fsUpdateUserId as waiterid,tbSellCheck.fsUpdateUserName as waitername,tbshift.fsShiftName as shiftName " +
                    "from tbSellCheck inner join tbshift on tbSellCheck.fsShiftId=tbshift.fsShiftId " +
                    "inner join tbSell on tbSellCheck.fsSellNo=tbSell.fsSellNo " +
                    "where tbSell.fiBillStatus in ('3', '4') and tbsell.fiSellType<>'2' and tbSellCheck.fsSellDate='" + businessDate + "' " +
                    "group by tbSellCheck.fsUpdateUserId,tbSellCheck.fsShiftId,tbSellCheck.fiStatus " +
                    "order by tbSellCheck.fiStatus asc";

            List<UnShiftModel> shiftModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, UnShiftModel.class);
            GetUnFinishedShiftResponse response = new GetUnFinishedShiftResponse();
            response.printConfig = DBMetaUtil.getConfig(META.SHIFT_PRINT_CONFIG, "1");
            response.unShiftList = shiftModels;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            socketResponse.data = response;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 检查指定版本的未结账的订单
     *
     * @param shiftID String
     * @return String | 未结账的订单号
     */
    public static String getUnPayedShiftOrder(String shiftID) {
        String sql_unpayed_order = "select order_id " +
                "from order_pay_cache   " +
                "where " +
                "business_date='" + HostUtil.getHistoryBusineeDate("") + "'  " +
                "and  shiftid='" + shiftID + "' " +
                "and payed='0' limit 1";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);
    }

    /**
     * 进行交班
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/doshift")
    public SocketResponse doShift(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            //ShiftRequest request = JSON.parseObject(param, ShiftRequest.class);
            JSONObject request = JSON.parseObject(param);

            if (!TextUtils.equals(request.getString("currentWaiterID"), request.getString("waiterID")) && !request.getBooleanValue("onlyPrint") && !request.getBooleanValue("isAuthorize")) {
                socketResponse.code = -1;
                socketResponse.message = "交班仅限收银员本人。";
                return socketResponse;
            }

            String unfinishOrderID = "";

            if (!request.getBooleanValue("onlyPrint")) {
                //检查未完成结账的订单
                String sql_unpayed_order = "select order_id " +
                        "from order_pay_cache   " +
                        "where " +
                        "business_date='" + request.getString("businessDate") + "'  " +
                        "and waiterid='" + request.getString("waiterID") + "' " +
                        "and  shiftid='" + request.getString("shiftID") + "' " +
                        "and payed='0'";
                String unPayedOrderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);

                if (!TextUtils.isEmpty(unPayedOrderID)) {
                    socketResponse.code = -2;
                    socketResponse.message = getErrorMsg(unPayedOrderID);
                    return socketResponse;
                }

                //获取当前收银员，当前班别的未交班的订单ID
                unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                LogUtil.logBusiness("交班人：" + request.getString("waiterID") + "，班别：" + request.getString("shiftID") + "，交班订单：" + unfinishOrderID);
                //清除内存中要交班的订单
                if (!TextUtils.isEmpty(unfinishOrderID)) {
                    if (unfinishOrderID.contains(",")) {
                        String orderList[] = unfinishOrderID.split(",");
                        for (String orderId : orderList) {
                            OrderSession.getInstance().clearOrder(unfinishOrderID);
                        }
                    } else {
                        OrderSession.getInstance().clearOrder(unfinishOrderID);
                    }
                }
                //更新指定订单的交班状态
                ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
                NotifyToClient.refreshShift();
            } else {
                if (request.getIntValue("rePrintOrPrePrint") == 0) {  //未交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                } else { //已交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                }
            }

            final ShiftResponse respone = new ShiftResponse();
            //config : 0 :不打印交班表 1：打印全部 2：不打印档口明细
            int printConfig = request.getIntValue("printConfig");
            if (printConfig != 0) {
                ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where fiStatus='1' and fsShopGUID='" + HostUtil.getShopID() + "'", ShopDBModel.class);
                HashMap<String, Object> printValue = PreparePrintUtil.prepareShiftPrintValue(shopDBModel
                        , request.getString("businessDate")
                        , request.getString("waiterID")
                        , request.getString("waiterName")
                        , request.getString("shiftID")
                        , request.getString("shiftName")
                        , request.getString("currentHostID")
                        , unfinishOrderID
                        , request.getBooleanValue("isAuthorize")
                        , request.getString("authorizeUsername")
                        , request.getString("authorizeUserId")
                        , printConfig
                );

                if (printValue != null && printValue.size() > 0) {
                    String titleRemind = request.getBooleanValue("onlyPrint") ? ((request.getIntValue("rePrintOrPrePrint") == 0) ? "(预打-" + request.getString("currentWaiterName") + ")" : "(重打-" + request.getString("currentWaiterName") + ")") : "";
                    LogUtil.log("交班表打印：" + titleRemind);
                    List<Integer> printNoList = PrintReportUtil.printShiftReceipt(request.getString("hostId"), request.getString("businessDate"), printValue, titleRemind);
                    if (!ListUtil.isEmpty(printNoList)) {
                        respone.printNo.addAll(printNoList);
                    }
                }
                //保存用户的选择
                DBMetaUtil.updateSettingsValueByKey(META.SHIFT_PRINT_CONFIG, printConfig);
            }

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "交班成功";
            socketResponse.data = respone;
//            UploadDataProcessor.doUploadOrderWithBaseData();
            UploadDataHelper.uploadOrderData(true);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/getShiftPrintData")
    public SocketResponse getShiftPrintData(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);

            if (!TextUtils.equals(request.getString("currentWaiterID"), request.getString("waiterID")) && !request.getBooleanValue("onlyPrint") && !request.getBooleanValue("isAuthorize")) {
                socketResponse.code = -1;
                socketResponse.message = "交班仅限收银员本人。";
                return socketResponse;
            }

            String unfinishOrderID = "";

            if (!request.getBooleanValue("onlyPrint")) {
                //检查未完成结账的订单
                String sql_unpayed_order = "select order_id " +
                        "from order_pay_cache   " +
                        "where " +
                        "business_date='" + request.getString("businessDate") + "'  " +
                        "and waiterid='" + request.getString("currentWaiterID") + "' " +
                        "and  shiftid='" + request.getString("shiftID") + "' " +
                        "and payed='0'";
                String unPayedOrderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);

                if (!TextUtils.isEmpty(unPayedOrderID)) {
                    socketResponse.code = -2;
                    socketResponse.message = getErrorMsg(unPayedOrderID);
                    return socketResponse;
                }

                //获取当前收银员，当前班别的未交班的订单ID
                unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                //更新指定订单的交班状态
                ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
                NotifyToClient.refreshShift();
            } else {
                if (request.getIntValue("rePrintOrPrePrint") == 0) {  //未交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                } else { //已交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerShiftOrder(request.getString("businessDate"), request.getString("waiterID"), request.getString("shiftID"));
                }
            }

            ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where fiStatus='1' and fsShopGUID='" + HostUtil.getShopID() + "'", ShopDBModel.class);
            HashMap<String, Object> printValue = PreparePrintUtil.prepareShiftPrintValue(shopDBModel
                    , request.getString("businessDate")
                    , request.getString("waiterID")
                    , request.getString("waiterName")
                    , request.getString("shiftID")
                    , request.getString("shiftName")
                    , request.getString("currentHostID")
                    , unfinishOrderID
                    , request.getBooleanValue("isAuthorize")
                    , request.getString("authorizeUsername")
                    , request.getString("authorizeUserId")
                    , 1
            );

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = new GetShiftPrintDataResponse(printValue);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 进行自动打烊之前自动交班
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/automaticSuccession")
    public SocketResponse automaticSuccession(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            UnShiftModel shiftModel = JSON.parseObject(request.getString("shiftModel"), UnShiftModel.class);
            String businessDate = request.getString("businessDate");//营业日期
            String currentHostID = request.getString("currentHostID");//当前站点id
            boolean isAuthorize = request.getBooleanValue("isAuthorize");//授权
            String authorizeUsername = request.getString("authorizeUsername");//授权用户名
            String authorizeUserId = request.getString("authorizeUserId");//授权用户id
            String hostId = request.getString("hostId");//站点id
            boolean onlyPrint = request.getBooleanValue("onlyPrint");//仅获取交班表打印数据
            String currentWaiterName = request.getString("currentWaiterName");//当前的服务员名称

//            if (!TextUtils.equals(request.getString("currentWaiterID"), request.getString("waiterID")) && !request.getBooleanValue("onlyPrint") && !request.getBooleanValue("isAuthorize")) {
//                socketResponse.code = -1;
//                socketResponse.message = "交班仅限收银员本人。";
//                return socketResponse;
//            }

            String unfinishOrderID = "";
            if (!onlyPrint) {
                //检查未完成结账的订单
                String sql_unpayed_order = "select order_id " +
                        "from order_pay_cache   " +
                        "where " +
                        "business_date='" + businessDate + "'  " +
                        "and waiterid='" + shiftModel.waiterid + "' " +
                        "and  shiftid='" + shiftModel.shiftid + "' " +
                        "and payed='0'";
                String unPayedOrderID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql_unpayed_order);
                if (!TextUtils.isEmpty(unPayedOrderID)) {
                    socketResponse.code = -2;
                    socketResponse.message = getErrorMsg(unPayedOrderID);
                    return socketResponse;
                }

                //获取当前收银员，当前班别的未交班的订单ID
                unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(businessDate, shiftModel.waiterid, shiftModel.shiftid);
                //更新指定订单的交班状态
                ShiftDinnerProcessor.shiftOrder(unfinishOrderID);
                NotifyToClient.refreshShift();
            } else {
                if (shiftModel.locked == 0) {  //未交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerUnShiftOrder(businessDate, shiftModel.waiterid, shiftModel.shiftid);
                } else { //已交班订单号
                    unfinishOrderID = PaySaveDBUtil.getDinnerShiftOrder(businessDate, shiftModel.waiterid, shiftModel.shiftid);
                }
            }

            final ShiftResponse respone = new ShiftResponse();
//          config : 0 :不打印交班表 1：打印全部 2：不打印档口明细
            int printConfig = request.getIntValue("printConfig");
            if (printConfig != 0) {
                ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from " + DBModel.getTableName(ShopDBModel.class) + " where fiStatus='1' and fsShopGUID='" + HostUtil.getShopID() + "'", ShopDBModel.class);
                HashMap<String, Object> printValue = PreparePrintUtil.prepareShiftPrintValue(shopDBModel
                        , businessDate
                        , shiftModel.waiterid
                        , shiftModel.waiterName
                        , shiftModel.shiftid
                        , shiftModel.shiftName
                        , currentHostID
                        , unfinishOrderID
                        , isAuthorize
                        , authorizeUsername
                        , authorizeUserId
                        , printConfig
                );

                if (printValue != null && printValue.size() > 0) {
                    String titleRemind = request.getBooleanValue("onlyPrint") ? ((shiftModel.locked == 0) ? "(预打-" + currentWaiterName + ")" : "(重打-" + currentWaiterName + ")") : "";
                    LogUtil.log("交班表打印：" + titleRemind);
                    List<Integer> printNoList = PrintReportUtil.printShiftReceipt(hostId, businessDate, printValue, titleRemind);
                    if (!ListUtil.isEmpty(printNoList)) {
                        respone.printNo.addAll(printNoList);
                    }
                }
                //保存用户的选择
                DBMetaUtil.updateSettingsValueByKey(META.SHIFT_PRINT_CONFIG, printConfig);
            }

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "交班成功";
            socketResponse.data = respone;
//            UploadDataProcessor.doUploadOrderWithBaseData();
            UploadDataHelper.uploadOrderData(true);
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    public static String getErrorMsg(String orderId) {
        String errorMsg = "订单[" + orderId + "]尚未完成结账";
        String sellType = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiSellType from tbsell where fssellno = '" + orderId + "'");
        if (TextUtils.equals("0", sellType)) {//正餐
            String tableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tableBiz where fssellno = '" + orderId + "'");
            if (TextUtils.isEmpty(tableId)) {
                errorMsg = "存在未结账的异常订单" + orderId + "，请至”账单管理“处理此订单";
            }
        } else if (TextUtils.equals("1", sellType)) {
            String bizStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fastfood_biz_status from fastfood_order_biz where order_id = '" + orderId + "'");
            if (!TextUtils.equals("1", bizStatus)) {
                errorMsg = "存在未结账的异常订单" + orderId + "，请至”账单管理“处理此订单";
            }
        }
        return errorMsg;
    }

    /**
     * 设置估清
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/updateSellOut")
    public SocketResponse updateSellOut(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            SetSellOutResponse response = new SetSellOutResponse();
            JSONObject request = JSON.parseObject(param);
            SellOutViewModel data = JSON.parseObject(request.getString("data"), SellOutViewModel.class);

            RunTimeLog.addLog(ActionLog.DF_MENU_APPRAISE, "业务中 收到更新估清内容请求  ", "", "", data);
            SellOutServerProcessor.updateSellOut(data);
            response.isOpenParam = OrderBizUtil.isOpenMenuItem(data.fiOrderUintCd);
            response.dataViewLiest = SellOutServerProcessor.getAllSellOutViewModel();
            //通知秒点上送估清状态
            DriverBus.call("monitor/update_rapid_sell_out");
            //推送站点估清菜品
            NotifyToClient.refreshSellOut();
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 设置菜品分类下某菜品的沽清
     */
    @DrivenMethod(uri = TAG + "/updateSellOutUnderMenuCls")
    public SocketResponse updateSellOutUnderMenuCls(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            SetSellOutGroupByMenuClsResponse response = new SetSellOutGroupByMenuClsResponse();
            JSONObject request = JSON.parseObject(param);
            SellOutViewModel data = JSON.parseObject(request.getString("data"), SellOutViewModel.class);
            SellOutServerProcessor.updateSellOut(data);
            response.hasOpenParam = OrderBizUtil.isOpenMenuItem(data.fiOrderUintCd);
            response.dataList = SellOutServerProcessor.groupSellOut();
            //通知秒点上送估清状态
            DriverBus.call("monitor/update_rapid_sell_out");
            //推送站点估清菜品
            NotifyToClient.refreshSellOut();
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 设置整个菜品分类的沽清
     */
    @DrivenMethod(uri = TAG + "/updateSellOutMenuCls")
    public SocketResponse updateSellOutMenuCls(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            SetSellOutGroupByMenuClsResponse response = new SetSellOutGroupByMenuClsResponse();
            JSONObject request = JSON.parseObject(param);
            // 数据状态;0未同步到店DB / 1正常 / 2临时沽清 / 3数量沽清 /13删除
            int sellOutStatus = request.getIntValue("sellOutStatus");
            // 0-按份数沽清->该分类全部沽清，1-按重量沽清->只沽清该分类下称重菜
            int sellOutType = request.getIntValue("sellOutType");
            // 剩余数量
            BigDecimal fdInvQty = request.getBigDecimal("fdInvQty");
            if (fdInvQty == null) {
                fdInvQty = BigDecimal.ZERO;
            }
            SellOutMenuClsViewModel data = JSON.parseObject(request.getString("data"), SellOutMenuClsViewModel.class);

            // 是否包含开台参数
            boolean hasOpenParam = false;
            List<String> orderUintCdList = new ArrayList<>();
            if (data != null && !ListUtil.isEmpty(data.sellOutItemList)) {
                for (SellOutViewModel sellOut : data.sellOutItemList) {
                    // 已经全部沽清的，跳过
                    if (SellOutServerProcessor.isAllSellOutFromDB(sellOut.fiItemCd, sellOut.fiOrderUintCd)) {
                        continue;
                    }
                    // 只沽清称重菜 && 该菜不是称重菜 -> 跳过
                    if (sellOutType == 1 && sellOut.fiIsEditQty == 0) {
                        continue;
                    }
                    sellOut.fiStatus = sellOutStatus;
                    sellOut.sellOutType = sellOutType;
                    sellOut.fdInvQty = fdInvQty;
                    SellOutServerProcessor.updateSellOut(sellOut);
                    if (!hasOpenParam) {
                        hasOpenParam = OrderBizUtil.isOpenMenuItem(sellOut.fiOrderUintCd);
                    }
                }
            }

            response.hasOpenParam = hasOpenParam;
            response.orderUintCdList = orderUintCdList;
            response.dataList = SellOutServerProcessor.groupSellOut();
            //通知秒点上送估清状态
            DriverBus.call("monitor/update_rapid_sell_out");
            //推送站点估清菜品
            NotifyToClient.refreshSellOut();
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 取消估清
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/cancelSellOut")
    public SocketResponse cancelSellOut(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            SetSellOutResponse response = new SetSellOutResponse();
            JSONObject request = JSON.parseObject(param);
            boolean clearAll = request.containsKey("clearAll") ? request.getBoolean("clearAll") : false;
            String fiOrderUintCd = request.getString("fiOrderUintCd");
            RunTimeLog.addLog(ActionLog.DF_MENU_APPRAISE, "业务中 收到取消估清请求  ", "", "", param);

            if (clearAll) {
                SellOutServerProcessor.resetAllSellOut();
            } else {
                SellOutServerProcessor.cancelSellOut(fiOrderUintCd);
                response.isOpenParam = OrderBizUtil.isOpenMenuItem(fiOrderUintCd);
            }
            response.dataViewLiest = SellOutServerProcessor.getAllSellOutViewModel();
            //通知秒点上送估清状态
            DriverBus.call("monitor/update_rapid_sell_out");
            //推送站点估清菜品
            NotifyToClient.refreshSellOut();
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 按菜品分类沽清
     */
    @DrivenMethod(uri = TAG + "/cancelSellOutByMenuCls")
    public SocketResponse cancelSellOutByMenuCls(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            SetSellOutGroupByMenuClsResponse response = new SetSellOutGroupByMenuClsResponse();
            JSONObject request = JSON.parseObject(param);
            SellOutMenuClsViewModel sellOutMenuCls = request.getObject("sellOutMenuCls", SellOutMenuClsViewModel.class);

            // 是否包含开台参数
            boolean hasOpenParam = false;
            List<String> orderUintCdList = new ArrayList<>();
            if (sellOutMenuCls != null && !ListUtil.isEmpty(sellOutMenuCls.sellOutItemList)) {
                for (SellOutViewModel sellOut : sellOutMenuCls.sellOutItemList) {
                    if (sellOut == null) {
                        continue;
                    }
                    orderUintCdList.add(sellOut.fiOrderUintCd);
                    SellOutServerProcessor.cancelSellOut(sellOut.fiOrderUintCd);
                    // hasOpenParam已经置为true后就不再更新
                    if (!hasOpenParam) {
                        hasOpenParam = OrderBizUtil.isOpenMenuItem(sellOut.fiOrderUintCd);
                    }
                }
            }
            response.hasOpenParam = hasOpenParam;
            response.orderUintCdList = orderUintCdList;
            response.dataList = SellOutServerProcessor.groupSellOut();
            //通知秒点上送估清状态
            DriverBus.call("monitor/update_rapid_sell_out");
            //推送站点估清菜品
            NotifyToClient.refreshSellOut();
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 返回所有的估清菜品
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getSellOut")
    public SocketResponse getSellOut(SocketHeader head, String param) {
        //GetSellOutRequest request = null;
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            GetSellOutResponse response = new GetSellOutResponse();
            if (request.getBooleanValue("onlyGetViewModel")) {
                response.dataViewLiest = SellOutServerProcessor.getAllSellOutViewModel();
            } else {
                response.dataList = SellOutServerProcessor.getAllSellOut();
            }
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 返回所有的估清菜品，按菜品分类分组
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getSellOutGroupByMenuCls")
    public SocketResponse getSellOutGroupByMenuCls(SocketHeader head, String param) {
        //GetSellOutRequest request = null;
        SocketResponse socketResponse = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            GetSellOutGroupByMenuClsResponse response = new GetSellOutGroupByMenuClsResponse();

            List<SellOutMenuClsViewModel> dataList = SellOutServerProcessor.groupSellOut();

            response.dataList.addAll(dataList);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 将所有菜品重置为非估清
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/resetAllSellOut")
    public SocketResponse resetAllSpecific(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        SellOutServerProcessor.resetAllSellOut();
        response.code = SocketResultCode.SUCCESS;
        response.message = "更新数据成功";

        return response;
    }

    /**
     * 构建预结单的PrintTaskDBModel
     *
     * @param param
     */
    @DrivenMethod(uri = "ordersync/getPreBillTask")
    public SocketResponse getPrintDinnerPreBillTask(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                userDBModel = new UserDBModel();
            }
            JSONObject request = JSON.parseObject(param);
            String orderId = request.getString("orderId");
            final GetPrintDinnerPreBillResponse response = new GetPrintDinnerPreBillResponse();
            List<Integer> printNoList = PrintBillUtil.printPreBill(orderId, head.hd, null, userDBModel);
            if (!ListUtil.isEmpty(printNoList)) {
                response.printNo = printNoList;
            }
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 打印点菜预览单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/premenulist")
    public SocketResponse rapidConfirmReceipt(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        PreMenuListResponse responseData = new PreMenuListResponse();
        response.data = responseData;
        try {
            //PreMenuListRequest request = JSON.parseObject(param, PreMenuListRequest.class);
            JSONObject request = JSON.parseObject(param);
            /**
             * 打印点菜预览单已下厨的单子
             */
            if (!TextUtils.isEmpty(request.getString("originMenuList"))) {
                List<MenuItem> originMenuList = JSON.parseArray(request.getString("originMenuList"), MenuItem.class);
                if (!originMenuList.isEmpty()) {
                    responseData.printNoList = PrintOrderUtil.printPreMenuList(request, header.hd);
                }
            }

            /**
             * 打印点菜预览单未下厨的单子
             */
            if (!TextUtils.isEmpty(request.getString("tempSelectedMenuList"))) {
                List<MenuItem> tempSelectedMenuList = JSON.parseArray(request.getString("tempSelectedMenuList"), MenuItem.class);
                if (!tempSelectedMenuList.isEmpty()) {
                    PrintOrderUtil.tempPrintPreMenuList(request, header.hd);
                }
            }

            response.code = SocketResultCode.SUCCESS;
            response.message = "打印成功";

        } catch (Exception e) {
            LogUtil.logError(e);
            response.message = "系统异常";
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 设置页面 通过菜品的搜索到桌台信息
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = "ordersync/menusearchtable")
    public SocketResponse getMenuSearchTableData(SocketHeader head, String param) {

        JSONObject request = JSON.parseObject(param);
        SocketResponse socketResponse = new SocketResponse();

        try {
            //request = JSON.parseObject(param, GetMenuSearchTableRequest.class);
            GetMenuSearchTableResponse response = new GetMenuSearchTableResponse();

            String sql = "select e.*,h.opentime as fast_opentime from " +
                    "(select c.*,d.fsopenhstime as fsopenhstime from (select a.*,b.fsMAreaName as fsMAreaName from " +
                    "(select fsSellNo,fsMTableName,fsMAreaId,fsMTableId,fsCreateUserName,fsMealNumber,fiSellType from tbSell where fiBillStatus in ('1','4') and  fsCreateTime like '" +
                    request.getString("businessDate") + "%" +
                    "' and  fsSellNo in " +
                    "(select distinct fsSellNo from tbSellOrderItem where fiItemCd = '" +
                    request.getString("fiItemCd") +
                    "' and fiOrderUintCd = '" +
                    request.getString("fiOrderUintCd") +
                    "' and (fdSaleQty-fdBackQty)>=0)) as a left join " +
                    "(select fsMAreaName,fsMAreaId from tbmarea where fiStatus = '1') as b on a.fsMAreaId = b.fsMAreaId) as c left join " +
                    "(select fssellno,fsopenhstime from tablebiz) as d on c.fsSellNo = d.fssellno) as e left join " +
                    "(select order_id,opentime from fastfood_order_biz) as h on e.fsSellno = h.order_id order by fsopenhstime desc";


            response.menuSearchTableModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuSearchTableModel.class);

            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "ordersync/getOrderToken")
    public SocketResponse getOrderToken(SocketHeader head, String param) {

        //GetOrderTokenRequest request = null;
        SocketResponse socketResponse = new SocketResponse();

        try {
            //request = JSON.parseObject(param, GetOrderTokenRequest.class);
            JSONObject request = JSONObject.parseObject(param);
            GetOrderTokenResponse response = new GetOrderTokenResponse();
            response.orderToken = ServerCache.getInstance().generateNewToken(request.getString("orderID"));
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 打印会员特权
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/printerMemberPrivate")
    public SocketResponse printerMemberPrivate(SocketHeader head, String params) {

        SocketResponse socketResponse = new SocketResponse();
        final PrinterMemberResponse response = new PrinterMemberResponse();
        socketResponse.data = response;
        try {

            JSONObject request = JSON.parseObject(params);
            MemberPrivateModel memberPrivilege = JSON.parseObject(request.getString("memberPrivilege"), MemberPrivateModel.class);
            List<Integer> list = MemberPrint.printPrivilege(request.getString("cardNo"), memberPrivilege);
            if (!ListUtil.isEmpty(list)) {
                response.printNoList.addAll(list);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 打印会员充值
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/printerMemberCharge")
    public SocketResponse printerMemberRecharge(SocketHeader head, String params) {

        SocketResponse socketResponse = new SocketResponse();
        final PrinterMemberResponse response = new PrinterMemberResponse();
        socketResponse.data = response;
        try {

            JSONObject request = JSON.parseObject(params);
            MemberRechargeOrderModel orderModel = JSON.parseObject(request.getString("orderModel"), MemberRechargeOrderModel.class);
            String payType = request.getString("payType");
            String memberName = request.getString("memberName");
            List<Integer> list = MemberPrint.printCharge(orderModel, payType, memberName, head.hd);
            if (!ListUtil.isEmpty(list)) {
                response.printNoList.addAll(list);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 添加订单备注
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = "ordersync/addOrderNote")
    public SocketResponse addOrderNote(SocketHeader head, String params) {

        SocketResponse socketResponse = new SocketResponse();
        final PrinterMemberResponse response = new PrinterMemberResponse();
        socketResponse.data = response;
        try {

            JSONObject request = JSON.parseObject(params);
            String orderId = request.getString("orderId");
            String note = request.getString("note");
            if (TextUtils.isEmpty(orderId)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.msg(R.string.serr_invalid_orderid);
                return socketResponse;
            }

            String fsmtableId = OrderSession.getTableID(orderId);
            OrderCache orderCache = null;
            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, orderId, " 添加订单备注 ");
            try {
                orderCache = OrderSession.getInstance().getOrder(orderId);
                if (orderCache == null) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "订单[" + orderId + "]已不存在";
                    return socketResponse;
                }
                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "订单[" + orderId + "]已结账，不能修改。";
                    return socketResponse;
                }
//pro2.4.2产品需求，反结账后仍然可以改备注
//                if (orderCache.orderStatus == OrderStatus.ANTI_PAIED) {
//                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
//                    socketResponse.message = "订单[" + orderId + "]在反结账，不能修改。";
//                    return socketResponse;
//                }
                orderCache.note = note;
                OrderSession.getInstance().writeOrder(orderId, false, "addOrderNote");
                OrderSaveDBUtil.upateOrderNote(orderId, note);
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, orderId, " 添加订单备注 ");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 打印沽清明细
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/printSellout")
    public SocketResponse printSellout(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        PrintSelloutResponse response = new PrintSelloutResponse();
        socketResponse.data = response;
        try {
            JSONObject request = JSON.parseObject(params);
            List<SellOutViewModel> modelList = SellOutServerProcessor.getAllSellOutViewModelWithZero();
            List<Integer> printNoList = PrintReportUtil.printSellout(head.hd, HostUtil.getHistoryBusineeDate(""), modelList);
            if (!ListUtil.isEmpty(printNoList)) {
                response.printNoList.addAll(printNoList);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/queryCrossPayResult")
    public SocketResponse queryCrossPayResult(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject p = JSONObject.parseObject(params);
            String requestId = p.getString("requestId");
            CrossPayPrintInfo crossPayPrintInfo = p.getObject("printInfo", CrossPayPrintInfo.class);
            QueryCrossPayResultRequest request = new QueryCrossPayResultRequest();
            request.pay_order = requestId;
            request.sellDate = HostUtil.getHistoryBusineeDate("");
            final List<BaseRequest> requestList = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                requestList.add(request.clone());
            }
            BusinessExecutor.execute(requestList, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof QueryCrossPayResultResponse) {
                        QueryCrossPayResultResponse response = (QueryCrossPayResultResponse) responseData.responseBean;
                        ArrayList<Integer> printTaskIds = new ArrayList<>();
                        switch (response.data.pay_status) {
                            case "1":
                                //打印销账小票
                                printTaskIds = CreditPrintUtil.printCrossPay(crossPayPrintInfo);
                                QueryCrossPayResultSocketResponse queryCrossPayResultSocketResponse = new QueryCrossPayResultSocketResponse();
                                queryCrossPayResultSocketResponse.payResult = response.data;
                                queryCrossPayResultSocketResponse.printerTaskIds = printTaskIds;
                                socketResponse.data = queryCrossPayResultSocketResponse;
                                socketResponse.code = SocketResultCode.SUCCESS;
                                QueryCrossPayResult queryCrossPayResult = response.data;
                                //计算已占用金额
//                                BigDecimal balanceAmt = queryCrossPayResult.canCrossAmt.add(SellreceiveDBUtil.optCreditAccountUsedAmt(crossPayPrintInfo.fsCreditAccountId, HostUtil.getHistoryBusineeDate("")));
                                //计算可用金额
//                                BigDecimal debtAmt = queryCrossPayResult.creditAmt.subtract(balanceAmt);
                                //更新信用额度和可用额度
//                                CreditaccountDBUtil.updateCreditaccount(crossPayPrintInfo.fsCreditAccountId, response.data.creditAmt, debtAmt);
                                break;
                            case "2":
                                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                socketResponse.message = "销账失败";
                                break;
                            default:
                                socketResponse.code = SocketResultCode.SUCCESS;
                                socketResponse.message = response.data.pay_status_msg;
                                break;
                        }
                        QueryCrossPayResultSocketResponse data = new QueryCrossPayResultSocketResponse();
                        data.printerTaskIds = printTaskIds;
                        data.payResult = response.data;
                        socketResponse.data = data;
                        socketResponse.code = SocketResultCode.SUCCESS;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, new BusinessCallback() {

                @Override
                public boolean success(int i, ResponseData responseData) {

                    return false;
                }

                @Override
                public boolean fail(int i, ResponseData responseData) {

                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 销账
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/loadCrossPay")
    public SocketResponse loadCrossPay(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject p = JSON.parseObject(params);
            CreditAccount account = p.getObject("account", CreditAccount.class);
            PaymentDBModel bean = p.getObject("bean", PaymentDBModel.class);
            BigDecimal crossPrice = p.getBigDecimal("crossPrice");
            String requestId = p.getString("requestId");
            String scannerCode = p.getString("code");
            String sellDate = p.getString("sellDate");
            String sellNo = p.getString("sellNo");
            CrossPayRequest request = new CrossPayRequest();
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel != null) {
                request.createUserId = userDBModel.fsUserId;
                request.createUserName = userDBModel.fsUserName;
                request.authorizedUserId = userDBModel.fsUserId;
                request.authorizedUserName = userDBModel.fsUserName;
            }
            request.sellDate = sellDate;
            request.sellNo = sellNo;
            request.creditAccoutId = account.fsCreditAccountId;
            request.creditAccountName = account.fsCreditAccountName;
            request.crossAccountAmt = crossPrice;
            request.note = "";
            request.requestId = requestId;
            CrossPayData payment = new CrossPayData();
            payment.crossAccountAmt = crossPrice;
            payment.paymentAmt = crossPrice;
            payment.paymentId = bean.fsPaymentId;
            payment.paymentName = bean.fsPaymentName;
            payment.paymentTypeId = bean.fsPaymentTypeId;
            if (APPConfig.isMyd()) {
                payment.paymentChannel = "116";
            } else if (APPConfig.isAir()) {
                payment.paymentChannel = "169";
            } else if (APPConfig.isCasiher()) {
                payment.paymentChannel = "170";
            } else {
                payment.paymentChannel = "116";//默认美易点
            }
            payment.paymentNo = scannerCode;
            request.accountPaymentList.add(payment);
            BigDecimal guaPrice = account.fdCreditAmt.subtract(account.fdDebtAmt);
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CrossPayResponse) {
                        CrossPayResponse response = (CrossPayResponse) responseData.responseBean;
                        CrossPayPrintInfo printInfo = new CrossPayPrintInfo();
                        printInfo.accountUsername = account.fsCreditAccountName;
                        printInfo.username = userDBModel.fsUserName;
                        printInfo.fsCreditAccountId = account.fsCreditAccountId;
                        printInfo.payPrice = crossPrice;
                        printInfo.fdCreditAmt = account.fdCreditAmt;
                        printInfo.recordNo = response.data.recordNo + "";
                        printInfo.payName = bean.fsPaymentName;

//                        CrossPayResult crossPayResult = response.data;
//                        BigDecimal balanceAmt = crossPayResult.canCrossAmt.add(SellreceiveDBUtil.optCreditAccountUsedAmt(account.fsCreditAccountId, HostUtil.getHistoryBusineeDate("")));
//                        BigDecimal debtAmt = crossPayResult.creditAmt.subtract(balanceAmt);
                        //打印小票的挂账总金额
                        printInfo.guaPrice = response.data.balanceAmt;
                        //打印小票的可用额度
                        printInfo.debtAmt = response.data.debtAmt.compareTo(BigDecimal.ZERO) > 0 ? response.data.debtAmt : BigDecimal.ZERO;
                        CrossPaySocketResponse data = new CrossPaySocketResponse();
                        data.printInfo = printInfo;
                        data.crossResult = response.data;
                        socketResponse.data = data;
                        switch (response.data.errno) {
                            case "1":
                                socketResponse.code = SocketResultCode.SUCCESS;
                                //打印销账小票
                                CreditPrintUtil.printCrossPay(printInfo);
//                                crossPayResult.debtAmt = debtAmt;
                                //更新信用额度和可用额度
//                                CreditaccountDBUtil.updateCreditaccount(account.fsCreditAccountId, crossPayResult.creditAmt, debtAmt);
                                break;
                            case "2":
                                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                                socketResponse.message = "销账失败";
                                break;
                            default:
                                socketResponse.code = SocketResultCode.SUCCESS;
                                socketResponse.message = response.data.errmsg;
                                break;
                        }
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 反销账
     *
     * @param head
     * @param params
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadReverseCross")
    public SocketResponse loadReverseCross(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject p = JSONObject.parseObject(params);
            int recordId = p.getInteger("recordId");
            String fsCreditAccountId = p.getString("fsCreditAccountId");
            String sellDate = p.getString("sellDate");
            ReverseCrossRequest request = new ReverseCrossRequest();
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel != null) {
                request.createUserId = userDBModel.fsUserId;
                request.createUserName = userDBModel.fsUserName;
                request.authorizedUserId = userDBModel.fsUserId;
                request.authorizedUserName = userDBModel.fsUserName;
            }
            request.requestId = System.currentTimeMillis() + "";
            request.sellDate = sellDate;
            request.recordId = recordId;
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof ReverseCrossResponse) {
                        ReverseCrossResponse response = (ReverseCrossResponse) responseData.responseBean;
                        ReverseCrossSocketResponse reverseCrossSocketResponse = new ReverseCrossSocketResponse();
                        reverseCrossSocketResponse.debtAmt = response.data.debtAmt;
                        socketResponse.data = reverseCrossSocketResponse;
                        ReverseCrossResult reverseCrossResult = response.data;
//                        BigDecimal balanceAmt = reverseCrossResult.canCrossAmt.add(SellreceiveDBUtil.optCreditAccountUsedAmt(fsCreditAccountId, HostUtil.getHistoryBusineeDate("")));
//                        //计算可用额度
//                        BigDecimal debtAmt = reverseCrossResult.creditAmt.subtract(balanceAmt);
//                        //反销成功后更新信用额度和未销金额
//                        CreditaccountDBUtil.updateCreditaccount(fsCreditAccountId, reverseCrossResult.creditAmt, debtAmt);
                        socketResponse.code = SocketResultCode.SUCCESS;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }


    /**
     * 查询并更新单个挂账对象
     */
    @DrivenMethod(uri = TAG + "/loadAccount")
    public SocketResponse loadAccount(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            CreditAccountSocketResponse creditAccountSocketResponse = new CreditAccountSocketResponse();
            JSONObject jsonObject = JSONObject.parseObject(params);
            String accountId = jsonObject.getString("accountId");
            String sellDate = jsonObject.getString("sellDate");
            CreditAccountRequest request = new CreditAccountRequest();
            request.accountId = accountId;
            request.sellDate = sellDate;
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CreditAccountResponse) {
                        CreditAccountResponse response = (CreditAccountResponse) responseData.responseBean;
                        //待销账额度=云端可用额度+本地已挂账额度
//                        response.data.fdBalanceAmt = response.data.canCrossAmt.add(SellreceiveDBUtil.optCreditAccountUsedAmt(accountId, sellDate));
//                        //重新计算可用额度
//                        response.data.fdDebtAmt = response.data.fdCreditAmt.subtract(response.data.fdBalanceAmt);
//                        //更新本地信用额度和可用额度
//                        CreditaccountDBUtil.updateCreditaccount(accountId, response.data.fdCreditAmt, response.data.fdDebtAmt);
                        if (response.data.fdDebtAmt.compareTo(BigDecimal.ZERO) < 0) {
                            response.data.fdDebtAmt = BigDecimal.ZERO;
                        }
                        creditAccountSocketResponse.account = response.data;
                        socketResponse.data = creditAccountSocketResponse;
                        socketResponse.code = SocketResultCode.SUCCESS;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 查询所有挂账对象
     */
    @DrivenMethod(uri = TAG + "/loadCrossAccountList")
    public SocketResponse loadCrossAccountList(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject jsonObject = JSONObject.parseObject(params);
            String accountName = jsonObject.getString("accountName");
            int currentPage = jsonObject.getInteger("currentPage");
            int size = jsonObject.getInteger("size");
            CreditAccountListRequest request = new CreditAccountListRequest();
            request.currentPage = currentPage;
            request.pageSize = size;
            request.accountName = accountName;
            request.status = "1";
            request.sellDate = HostUtil.getHistoryBusineeDate("");
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CreditAccountListResponse) {
                        CreditAccountListSocketResponse creditAccountListSocketResponse = new CreditAccountListSocketResponse();
                        CreditAccountListResponse response = (CreditAccountListResponse) responseData.responseBean;
                        creditAccountListSocketResponse.data = response.data;
                        socketResponse.data = creditAccountListSocketResponse;
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }

    /**
     * 获取所有提成人
     */
    @DrivenMethod(uri = TAG + "/loadAllBonusUser")
    public SocketResponse loadAllBonusUser(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();
        AllBonusUserResponse response = new AllBonusUserResponse();
        socketResponse.data = response;

        try {
            JSONObject request = JSONObject.parseObject(params);
            String openOrderUserId = request.getString("openOrderUserId");

            response.bonusUserList = BonusBizUtil.queryAllBonusUser();
            if (!TextUtils.isEmpty(openOrderUserId)) {
                response.openOrderUser = UserDBUtils.queryById(openOrderUserId);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    /**
     * 获取所有未结账订单
     */
    @DrivenMethod(uri = TAG + "/getDidNotCheck")
    public SocketResponse getDidNotCheckList(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject jsonObject = JSONObject.parseObject(params);

            String businessDate = jsonObject.getString("businessDate");
            List<ExceptionOrderBean> didNotCheckList = null;
            List<JSONObject> jsonObjectList = CenterCloseUtil.getDidNotCheckList(businessDate);
            if (!ListUtil.isEmpty(jsonObjectList)) {
                didNotCheckList = new ArrayList<>();
                for (JSONObject tempJson : jsonObjectList) {
                    if (tempJson != null) {
                        ExceptionOrderBean exceptionOrderBean = new ExceptionOrderBean();
                        exceptionOrderBean.order_id = tempJson.getString("order_id");
                        exceptionOrderBean.fiSellType = tempJson.getIntValue("fiSellType");
                        exceptionOrderBean.tableID = tempJson.getString("tableID");
                        if (exceptionOrderBean.fiSellType == 0) {
                            String fssellno = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fssellno from tableBiz where fsmtableid = '" + exceptionOrderBean.tableID + "'");
                            if (!TextUtils.equals(exceptionOrderBean.order_id, fssellno) && !TextUtils.isEmpty(fssellno)) {
                                //桌台被占用，此桌台绑定了另外一个订单
                                exceptionOrderBean.errorOrderStatus = 2;
                            }
                        }
                        didNotCheckList.add(exceptionOrderBean);
                    }
                }
            }
            if (!ListUtil.isEmpty(didNotCheckList)) {
                AutomaticClosingResponse closingResponse = new AutomaticClosingResponse();
                closingResponse.didNotCheckList.addAll(didNotCheckList);
                socketResponse.data = closingResponse;
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "查询所有未结账订单成功";

            } else {
                socketResponse.code = SocketResultCode.SUCCESS;
                socketResponse.message = "没有未结账订单";
            }

        } catch (Exception e) {
            e.printStackTrace();
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }


    /**
     * 账单管理页---获取账单
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getSearchDropList")
    public SocketResponse getSearchDropList(SocketHeader header, String param) {
        JSONObject request = JSON.parseObject(param);
        SocketResponse socketResponse = new SocketResponse();

        try {
            GetOrderFromCenterRespone respone = new GetOrderFromCenterRespone();
            String shopID = HostUtil.getShopID();
            String businessDate = request.getString("businessDate");

            //订单类型 0 ： 正餐； 1：快餐; 2:外卖
            int fiSellType = request.getObject("fiSellType", Integer.class);
            int billType = request.getInteger("billType");
            // 账套id
            String accountBookId = request.getString("accountBookId");
            // 订单来源
            String fsBillSourceId = request.getString("fsBillSourceId");
            // 搜索类型，0：按桌台名搜，1：按订单号搜，否则：两者都搜
            String searchType = request.getString("searchType");
            String searchContent = request.getString("searchContent");

            String withOrderID = "";
            String tableName = "";
            if (TextUtils.equals(searchType, "0")) {
                tableName = searchContent;
            } else if (TextUtils.equals(searchType, "1")) {
                withOrderID = searchContent;
            } else {
                tableName = searchContent;
                withOrderID = searchContent;
            }


            StringBuilder stringBuilder = new StringBuilder(String.format("'%s'", fiSellType));
            if (fiSellType == 1) {
                stringBuilder.append(",").append("'4'");
            }

            // 订单支付状态 0全部，1未结账，2已结账
            int payStatus = request.getInteger("payStatus");
            String billStatusStr;
            if (payStatus == 1) {
                billStatusStr = "'1','2','4','5'";
            } else if (payStatus == 2) {
                billStatusStr = "'" + OrderStatus.PAIED + "'";
            } else {
                billStatusStr = "'1','2','3','4','5'";
            }

            List<OrderListModel> orderList = OrderListUtil.getOrderList(1, true, businessDate, stringBuilder.toString(),
                    shopID, "", withOrderID, billType, accountBookId, billStatusStr, tableName, fsBillSourceId).second;

            respone.orderList2 = orderList;

            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "同步成功";
            socketResponse.data = respone;

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

}
