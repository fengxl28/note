package com.mwee.myd.server.business.data;

import com.leon.channel.helper.ChannelReaderUtil;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.BasePosRequest;
import com.mwee.android.pos.component.datasync.net.BasePosResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.BindShopType;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Description: 目前存在的问题不能同时打debug包和release
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/1/29
 */
public class ChannelRule {
    /**
     * channel dir: posDinnerClient/channel/
     */
    public static String CHANNEL = "";

    static {
        CHANNEL = ChannelReaderUtil.getChannel(GlobalCache.getContext());
    }

    public static void uploadShopProductInfo() {
        UploadShopProductInfoRequest request = new UploadShopProductInfoRequest();
        request.channel = CHANNEL;
        request.productType = getProductType();
        request.productName = getProductName();
        request.version = BizConstant.VERSION_NAME;
        ShopDBModel shop = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop where fiStatus='1'", ShopDBModel.class);
        if (shop != null) {
            request.manageShopId = shop.fsCompanyGUID;
            request.shopId = shop.fsShopGUID;
            request.shopName = shop.fsShopName;
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }

    public static String getProductName() {
        String productName = "";
        if (APPConfig.isMyd()) {
            productName = "美易点";
        } else if (APPConfig.isAir()) {
            productName = "美小易";
        } else if (APPConfig.isCasiher()) {
            productName = "美收银";
        } else if (APPConfig.isAirKouBei()) {
            productName = "美小易(口碑版)";
        }
        return productName;
    }

    public static String getProductType() {
        String productType = "";
        if (APPConfig.isMyd()) {
            productType = "1";
        } else if (APPConfig.isAir()) {
            productType = "2";
        } else if (APPConfig.isCasiher()) {
            productType = "3";
        }
        return productType;
    }


    /**
     * wiki: http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11641199
     * {业务ID}随便传这里先填001
     */
    @HttpParam(
            httpType = HttpType.POST,
            encodeType = "UTF-8",
            serializeType = SerializeType.Json,
            method = "uploadShopProductInfo",
            contentType = "application/json",
            response = BasePosResponse.class, saveToLog = true
    )
    public static class UploadShopProductInfoRequest extends BasePosRequest {
        public String shopId;
        public String manageShopId;
        public String shopName;
        public String channel;
        public String version;
        public String productName;
        public String productType;

        @Override
        public String optBaseUrl() {
            return Constant.getUrlRoot() + "/posapi/monitor/" + ClientMetaUtil.getSettingsValueByKey(META.SHOPID) + "-103/";
//            return "http://pcdc.winpos.test.cn" + "/posapi/monitor/";
        }
    }
}
