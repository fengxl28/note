package com.mwee.android.pos.businesscenter.driver;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.net.component.NetResultType;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.log.core.MwLog;
import com.mwee.android.log.domain.LogObject;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.permission.PermissionCheckDinner;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.business.shift.ShiftDinnerProcessor;
import com.mwee.android.pos.businesscenter.business.mallprotocol.MallProtocolBizUtil;
import com.mwee.android.pos.businesscenter.module.host.IHostService;
import com.mwee.android.pos.businesscenter.module.host.service.HostServiceImpl;
import com.mwee.android.pos.businesscenter.business.host.CenterCloseUtil;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadChangeDataProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataProcessor;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobScheudler;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobType;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.UserDBUtils;
import com.mwee.android.pos.businesscenter.framework.PresetDataUtils;
import com.mwee.android.pos.businesscenter.print.PrintReportUtil;
import com.mwee.android.pos.component.datasync.net.GetPayPrefixRequest;
import com.mwee.android.pos.component.datasync.net.GetPayPrefixResponse;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.BizLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.backup.GetBackupDataResponse;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.bind.bean.FinishDinnerHostResponse;
import com.mwee.android.pos.connect.business.bind.bean.GetHostResponse;
import com.mwee.android.pos.connect.business.bind.bean.GetTokenResponse;
import com.mwee.android.pos.connect.business.data.GetDataFromCenterResponse;
import com.mwee.android.pos.connect.business.data.LoadAllNotUploadDataCountResponse;
import com.mwee.android.pos.connect.business.login.LoginToCenterForDinnerResponse;
import com.mwee.android.pos.connect.business.login.ShiftCloseResponse;
import com.mwee.android.pos.connect.business.monitor.login.GetWorkModeResponse;
import com.mwee.android.pos.connect.business.test.CheckBizCenterResponse;
import com.mwee.android.pos.connect.callback.IProgressCallback;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.bind.HostCls;
import com.mwee.android.pos.db.business.bind.HostStatus;
import com.mwee.android.pos.db.business.bind.HostStatusModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.DeviceUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.LocalDataManager;
import com.mwee.myd.server.slave.ReplicationProcessor;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * BizSyncDriver
 * Created by virgil on 16/8/16.
 */
@SuppressWarnings("unused")
public class BizSyncDriver implements IDriver {

    private static final String TAG = "bizsync";

    @Override
    public String getModuleName() {
        return TAG;
    }

    private synchronized static SocketResponse bindHost(String hostid, String deviceID, int main) {
        SocketResponse socketResponse = new SocketResponse();
        if (TextUtils.isEmpty(deviceID)) {
            socketResponse.code = -200;
            socketResponse.message = "设备ID为空";
            return socketResponse;
        }
        HostStatusModel host = DBSimpleUtil.query(APPConfig.DB_MAIN, "where hostid='" + hostid + "'", HostStatusModel.class);
        if (host == null) {
            host = new HostStatusModel();
        }
        //判断站点是否已经被绑定
        if (host.bind_status == 1) {
            if (!TextUtils.isEmpty(host.device) && !TextUtils.equals(host.device, deviceID)) {
                socketResponse.code = -201;
                socketResponse.message = "站点已被绑定,不能重复绑定";
                return socketResponse;
            }
        } else {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from host_status where hostid = '" + hostid + "'");
        }
        host.device = deviceID;
        host.hostid = hostid;
        host.bind_time = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        host.bind_count++;
        host.bind_status = 1;
        host.biz_status = HostStatus.FINISH;
        host.current_user_id = "";
        host.replaceNoTrans();
        socketResponse.code = 0;
        socketResponse.message = "绑定成功";
        if (main == 1) {
            DBMetaUtil.updateSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID, hostid);
        }
        return socketResponse;
    }

    /**
     * 正餐打烊的请求
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "bizsync/finish_dinner_host")
    private SocketResponse closDinnereHost(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            if (!TextUtils.equals(head.hd, DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID))) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "只有业务中心可以打烊";
                return socketResponse;
            }
            socketResponse = CenterCloseUtil.processClose(head.hd);
            final String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
            if (socketResponse != null) {
                return socketResponse;
            } else {
                socketResponse = new SocketResponse();
            }
            /**
             * 将云收银的订单进行交班
             */
            ShiftDinnerProcessor.shiftRapidOrder(currentBusinessDate);
            /**
             * 将外卖单进行交班
             */
            ShiftDinnerProcessor.shiftThirdOrder(currentBusinessDate);
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Boolean>() {
                @Override
                public Boolean doJob(SQLiteDatabase db) {
                    ContentValues values = new ContentValues();
                    values.put("biz_status", HostStatus.FINISH);
                    values.put("current_user_id", "");

                    db.update("host_status", values, "hostid='" + DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID) + "'", null);
                    return true;
                }
            });

            //清除拼台信息
            TableBusinessUtil.cleanShareTables(null);

            FinishDinnerHostResponse response = new FinishDinnerHostResponse();

            //清除所有的用户登录Session
            HostUtil.clearAllSession();

            // TODO: 2018/12/5  
            KdsManager.getInstance().release();

            // 2017/12/11 打烊保存报表添加Job, 避免打烊后立即关机, 造成的报表保存失败的情况
            Job job = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" + JobType
                    .SAVE_DAILY_REPORT + "' AND biz_key = '" + currentBusinessDate + "'", Job.class);
            if (job == null) {
                job = new Job();
                job.type = JobType.SAVE_DAILY_REPORT;
                job.biz_key = currentBusinessDate;
                job.info = DateUtil.getCurrentDate("yyyy-MM-dd");
                job.cycle = 3;
                job.cycle_count = 1;
                JobScheudler.newJob(job);
            } else {
                job.updateJobPrepared();
            }

            // 打烊时，删除当日已保存时段报表，避免打烊保存报表 Job 前置判断所有报表已全部保存而不再执行
            String sqlDel = "DELETE FROM dailyReport WHERE businessdate = '" + currentBusinessDate + "' AND type = '" + ReportConsrance.REPORT_TIME + "' AND param1 LIKE '%1%'";
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlDel);

            // 打烊保存上报业务记录Job, 避免打烊后立即关机, 造成未上送的情况
            Job jobSummary = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from unfinish_task where  type = '" +
                    JobType.SUMMARY + "' AND biz_key = '" + currentBusinessDate + "'", Job.class);
            if (jobSummary == null) {
                jobSummary = new Job();
                jobSummary.type = JobType.SUMMARY;
                jobSummary.biz_key = currentBusinessDate;
                jobSummary.cycle = 3;
                jobSummary.cycle_count = 1;
                JobScheudler.newJob(jobSummary);
            } else {
                jobSummary.updateJobPrepared();
            }

            Job finalJobSummary = jobSummary;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        LogUtil.logError(e);
                    }
                    //重置所有备用打印机
                    MonitorDriver.resetAllBackPrinterToNormal();
                    //推送所有站点重置备用打印机
                    NotifyToClient.broadcast("lpc/resetbackupprinter");

                    //推送所有站点打烊
                    NotifyToClient.callDinnerFinish();
                    //同步报表到云端（包括了同步外卖订单）
                    UploadDataHelper.uploadAllData(null, null);

                    //同步外卖订单到后台
//                    UploadNetorderDataProcessor.startUploadAllLocalData(null);

                    //存储报表数据 并 打印部分报表小票
                    saveReport(currentBusinessDate);

                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        LogUtil.logError(e);
                    }

                    ShiftDinnerProcessor.sendCloseMessageToClud(currentBusinessDate);

                    ShiftDinnerProcessor.sendSummary(currentBusinessDate, new IResult() {
                        @Override
                        public void callBack(boolean result, String info) {
                            if (result) {
                                finalJobSummary.updateJobFinished();
                            } else {
                                finalJobSummary.updateJobPrepared();

                            }
                        }
                    });

                }
            }).start();
            socketResponse.code = 0;
            socketResponse.message = "打烊成功";
            socketResponse.data = response;

        } catch (Exception e) {
            LogUtil.logError(e);
            if (socketResponse == null) {
                socketResponse = new SocketResponse();
            }
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        return socketResponse;
    }

    private void saveReport(String businessDate) {
        // 存储A账全部报表，读取配置是否需要打印报表小票
        boolean needPrintReport = TextUtils.equals(CommonDBUtil.getConfigWithDefault(DBPrintConfig.AUTO_PRINT_CLOSE,
                "1"), "1");
        String naturalDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        if (APPConfig.isMyd()) {
            saveReport(businessDate, naturalDate, 0, "1", needPrintReport);
            // B账默认不打印
//        saveReport(businessDate, naturalDate, 1, false);
            List<AccountBookDBModel> accountBookList = AccountBookUtil.optAllAccountBook(false);
            if (!ListUtil.isEmpty(accountBookList)) {
                for (AccountBookDBModel accountBook : accountBookList) {
                    if (accountBook == null || TextUtils.equals("1", accountBook.accountBookId)) {
                        continue;
                    }
                    BizSyncDriver.saveReport(businessDate, naturalDate, 1, accountBook.accountBookId, false);
                }
            }
        } else {
            saveReport(businessDate, naturalDate, 0, "", needPrintReport);
            // B账默认不打印
            saveReport(businessDate, naturalDate, 1, "", false);
        }
    }

    /**
     * 提取报表数据--并打印报表小票
     * 目前打印的报表小票有：销售数量表、最高销售数量表、日结表
     *
     * @param businessDate    -- 营业日期
     * @param businessDate    -- 当前自然日日期
     * @param billType        报表类型 0:A账; 1:B账
     * @param needPrintReport 是否打印小票
     */
    @DrivenMethod(uri = TAG + "/saveReport")
    public static void saveReport(String businessDate, String naturalDate, int billType, String accountBookId, boolean needPrintReport) {
        RunTimeLog.addLog(RunTimeLog.REPORT, "商户设置" + (needPrintReport ? "要" : "不要") + "打印报表");
        if (TextUtils.isEmpty(naturalDate)) {
            naturalDate = DateUtil.getCurrentDate("yyyy-MM-dd");
        }
        String shopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        Map<String, Object> paramsData = new HashMap<>();
        paramsData.put("Businessdate", businessDate);
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbshop where fiStatus='1' and " +
                "fsShopGUID='" + shopGUID + "'", ShopDBModel.class);
        paramsData.put("Shop", shopDBModel);
        HashMap<String, Object> times = new HashMap<>();
        times.put("PrintTime", DateUtil.getCurrentTime());
        paramsData.put("SysMode", times);
        if (shopDBModel != null) {
            paramsData.put("fsShopName", shopDBModel.fsShopName);
        }

        //取数据--保存到报表库

        //退菜数据
        Map<String, Object> backData = DailyReportDBUtil.staticVoidOrGift(businessDate, "fdBackQty", billType, accountBookId);
        backData.putAll(paramsData);
        //赠菜数据
        Map<String, Object> giftData = DailyReportDBUtil.staticVoidOrGift(businessDate, "fdGiftqty", billType, accountBookId);
        giftData.putAll(paramsData);

        //构建最高销售金额数据
        Map<String, Object> maxSalePriceData = DailyReportDBUtil.getStatisticMaxSalePrice(businessDate, billType, accountBookId);
        maxSalePriceData.putAll(paramsData);
        //销售数量表
        Map<String, Object> saleData = DailyReportDBUtil.statisticSale(businessDate, billType, accountBookId,"", "");
        saleData.putAll(paramsData);
        //最高销售数量表
        Map<String, Object> maxSaleData = DailyReportDBUtil.getStatisticMaxSaleQuantity(businessDate, billType, accountBookId);
        maxSaleData.putAll(paramsData);

        //日报表数据
        HashMap<String, Object> dailyData = new HashMap<>();
        dailyData.putAll(paramsData);
        dailyData.putAll(DailyReportDBUtil.getSellAnalyzeValue(businessDate, "", billType, accountBookId));
        dailyData.putAll(DailyReportDBUtil.getSellCategoryValue(businessDate, "", billType, accountBookId));
        dailyData.putAll(DailyReportDBUtil.getIncomeCategoryValue(businessDate, "", billType, accountBookId));
        //小易和美易点获取外卖数据区分
        if(APPConfig.isAir(GlobalCache.getContext())){
            dailyData.putAll(DailyReportDBUtil.getTakeOutStatisticsForAir(businessDate, "", billType));
        }else{
            dailyData.putAll(DailyReportDBUtil.getTakeOutStatistics(businessDate, "", billType, accountBookId));
        }
        //新日结表
        Map<String, Object> newDailyData = DailyReportDBUtil.queryNewDailyData(businessDate,billType, accountBookId,"","");
        newDailyData.putAll(paramsData);

        //档口统计表
        Map<String, Object> deptData = DailyReportDBUtil.statisticDeptBalance(businessDate, billType, accountBookId);
        deptData.putAll(paramsData);

        //折扣统计表
        Map<String, Object> discountData = DailyReportDBUtil.optDiscountReport(businessDate, billType, accountBookId);
        discountData.putAll(paramsData);

        //时段统计表
        Map<String, Object> timeData = DailyReportDBUtil.getTimeReportValue(businessDate, billType, accountBookId);
        timeData.putAll(paramsData);

        //折扣汇总表
        Map<String, Object> allDiscountData = DailyReportDBUtil.optAllDiscountReport(businessDate, billType, accountBookId);
        allDiscountData.putAll(paramsData);

        // 微信快餐
        Map<String, Object> dataFastFoodWeChat = DailyReportDBUtil.getWechatFastFoodReport(businessDate, billType, accountBookId);
        dataFastFoodWeChat.putAll(paramsData);

        //套餐销量汇总
        Map<String, Object> allBundleData = DailyReportDBUtil.statisticBundleSale(businessDate, billType, accountBookId);
        allBundleData.putAll(paramsData);

        //销售分类统计
        Map<String, Object> saleClaData = DailyReportDBUtil.statistiCls(businessDate, billType, accountBookId, ReportConsrance.REPORT_SALE_CLS_NUM);
        allBundleData.putAll(paramsData);


        //收入分类统计
        Map<String, Object> incomeClsData = DailyReportDBUtil.statistiCls(businessDate, billType, accountBookId, ReportConsrance.REPORT_INCOME_CLS_NUM);
        allBundleData.putAll(paramsData);

        //溢收明细统计
        Map<String, Object> surchargeDetailData = DailyReportDBUtil.statistiSurchargeDetail(businessDate, billType, accountBookId);
        allBundleData.putAll(paramsData);


        //需要上送的数据 存入ReportDBModel 和File文件
        Map<String, String> datas = new HashMap<>();

        //退菜数据
        datas.put(ReportConsrance.REPORT_VOID, JSON.toJSONString(backData));

        //赠菜数据
        datas.put(ReportConsrance.REPORT_GIFT, JSON.toJSONString(giftData));

        //构建最高销售金额数据
        datas.put(ReportConsrance.REPORT_MAX_SALE_PRICE, JSON.toJSONString(maxSalePriceData));

        //销售数量表
        List saleItem = (List) saleData.get("XSSL");
        datas.put(ReportConsrance.REPORT_SALE, JSON.toJSONString(saleData));
        if (!ListUtil.isEmpty(saleItem) && saleItem.size() > 0 && needPrintReport) {
            PrintReportUtil.printReport(ReportConsrance.REPORT_SALE, businessDate, saleData, HostUtil.getCurrentHost());
        }

        //最高销售数量表
        List maxSaleItem = (List) maxSaleData.get("XSSL");
        datas.put(ReportConsrance.REPORT_MAX_SALE_QUANTITY, JSON.toJSONString(maxSaleData));
        if (!ListUtil.isEmpty(maxSaleItem) && maxSaleItem.size() > 0 && needPrintReport) {
            PrintReportUtil.printReport(ReportConsrance.REPORT_MAX_SALE_QUANTITY, businessDate, maxSaleData, HostUtil
                    .getCurrentHost());
        }

        //日报表数据
        datas.put(ReportConsrance.REPORT_DAILY, JSON.toJSONString(dailyData));
        if (needPrintReport) {
            PrintReportUtil.printReport(ReportConsrance.REPORT_DAILY, businessDate, dailyData, HostUtil
                    .getCurrentHost());
        }
        datas.put(ReportConsrance.REPORT_NEW_DAILY,JSON.toJSONString(newDailyData));

        //档口统计数据
        datas.put(ReportConsrance.REPORT_DEPT, JSON.toJSONString(deptData));

        //折扣统计数据
        datas.put(ReportConsrance.REPORT_DISCOUNT, JSON.toJSONString(discountData));

        //销售时段表
        datas.put(ReportConsrance.REPORT_TIME, JSON.toJSONString(timeData));

        //折扣汇总表
        datas.put(ReportConsrance.REPORT_ALL_DISCOUNT, JSON.toJSONString(allDiscountData));

        // 微信快餐
        datas.put(ReportConsrance.WECHAT_FAST_FOOD, JSON.toJSONString(dataFastFoodWeChat));

        //套餐销量统计
        datas.put(ReportConsrance.REPORT_BUNDLE_SALE, JSON.toJSONString(allBundleData));

        //销售分类统计
        datas.put(ReportConsrance.REPORT_SALE_CLS_NUM, JSON.toJSONString(saleClaData));


        //收入分类统计
        datas.put(ReportConsrance.REPORT_INCOME_CLS_NUM, JSON.toJSONString(incomeClsData));

        //溢收明细统计
        datas.put(ReportConsrance.REPORT_SURCHARGE_DETAIL, JSON.toJSONString(surchargeDetailData));

        //存储报表小票
        DailyReportDBUtil.saveDailyReport(shopGUID, datas, businessDate, billType, accountBookId);

        /********************************************存储收款明细表数据*********************************************/
        Map<String, String> checkByDayDatas = new HashMap<>();
        String startDay = businessDate;
        String endDay = naturalDate;
        try {
            int chaDays = DateUtil.daysBetween(startDay, naturalDate);
            Map<String, Object> values;
            if (chaDays > 0) {
                if (chaDays > ReportConsrance.SAVE_DAYS) {
                    chaDays = ReportConsrance.SAVE_DAYS;
                }
                String dayTag;
                for (int i = chaDays; i >= 0; i--) {
                    dayTag = DailyReportDBUtil.getDay(naturalDate, i);
                    if (i == chaDays) {
                        startDay = dayTag;
                    }
                    values = DailyReportDBUtil.checkByDay(dayTag, dayTag, billType, accountBookId);
                    paramsData.put("Businessdate", dayTag);
                    values.putAll(paramsData);
                    checkByDayDatas.put(dayTag, JSON.toJSONString(values));
                }
            } else {
                values = DailyReportDBUtil.checkByDay(businessDate, businessDate, billType, accountBookId);
                paramsData.put("Businessdate", businessDate);
                values.putAll(paramsData);
                checkByDayDatas.put(businessDate, JSON.toJSONString(values));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.REPORT_ERR, "抽取'收款明细表'异常businessDate = " + businessDate, naturalDate, e);
        }

        //存储收款明细表数据
        DailyReportDBUtil.saveByDayReport(shopGUID, checkByDayDatas, startDay, naturalDate, billType, accountBookId,
                ReportConsrance.CHECK_BY_DAY);

        /********************************************美团外卖*********************************************/
        Map<String, String> meituanNetOrderByDayDatas = new HashMap<>();
        startDay = businessDate;
        try {
            int chaDays = DateUtil.daysBetween(startDay, naturalDate);
            Map<String, Object> values;
            if (chaDays > 0) {
                if (chaDays > ReportConsrance.SAVE_DAYS) {
                    chaDays = ReportConsrance.SAVE_DAYS;
                }
                String dayTag;
                for (int i = chaDays; i >= 0; i--) {
                    dayTag = DailyReportDBUtil.getDay(naturalDate, i);
                    if (i == chaDays) {
                        startDay = dayTag;
                    }
                    values = DailyReportDBUtil.getNetOrderReport(dayTag, dayTag, true);
                    paramsData.put("Businessdate", dayTag);
                    values.putAll(paramsData);
                    meituanNetOrderByDayDatas.put(dayTag, JSON.toJSONString(values));
                }
            } else {
                values = DailyReportDBUtil.getNetOrderReport(businessDate, businessDate, true);
                paramsData.put("Businessdate", businessDate);
                values.putAll(paramsData);
                meituanNetOrderByDayDatas.put(businessDate, JSON.toJSONString(values));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.REPORT_ERR, "抽取'美团外卖报表'异常businessDate = " + businessDate, naturalDate, e);
        }

        //存储美团外卖数据
        DailyReportDBUtil.saveByDayReport(shopGUID, meituanNetOrderByDayDatas, startDay, naturalDate, billType, accountBookId, ReportConsrance.MEITUAN_NET_ORDER);


        /********************************************外卖*********************************************/
        Map<String, String> netOrderByDayDatas = new HashMap<>();
        startDay = businessDate;
        try {
            int chaDays = DateUtil.daysBetween(startDay, naturalDate);
            Map<String, Object> values;
            if (chaDays > 0) {
                if (chaDays > ReportConsrance.SAVE_DAYS) {
                    chaDays = ReportConsrance.SAVE_DAYS;
                }
                String dayTag;
                for (int i = chaDays; i >= 0; i--) {
                    dayTag = DailyReportDBUtil.getDay(naturalDate, i);
                    if (i == chaDays) {
                        startDay = dayTag;
                    }
                    values = DailyReportDBUtil.getNetOrderReport(dayTag, dayTag, false);
                    paramsData.put("Businessdate", dayTag);
                    values.putAll(paramsData);
                    netOrderByDayDatas.put(dayTag, JSON.toJSONString(values));
                }
            } else {
                values = DailyReportDBUtil.getNetOrderReport(businessDate, businessDate, false);
                paramsData.put("Businessdate", businessDate);
                values.putAll(paramsData);
                netOrderByDayDatas.put(businessDate, JSON.toJSONString(values));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.REPORT_ERR, "抽取'外卖报表'异常businessDate = " + businessDate, naturalDate, e);
        }

        //存储外卖数据
        DailyReportDBUtil.saveByDayReport(shopGUID, netOrderByDayDatas, startDay, naturalDate, billType, accountBookId, ReportConsrance.NET_ORDER);

        /********************************************微信外卖*********************************************/
        Map<String, String> weChatNetData = new HashMap<>();
        String weChatStartDay = businessDate;
        String weChatEndDay = naturalDate;
        try {
            int chaDays = DateUtil.daysBetween(weChatStartDay, naturalDate);
            Map<String, Object> values;
            if (chaDays > 0) {
                if (chaDays > ReportConsrance.SAVE_DAYS) {
                    chaDays = ReportConsrance.SAVE_DAYS;
                }
                String dayTag;
                for (int i = chaDays; i >= 0; i--) {
                    dayTag = DailyReportDBUtil.getDay(naturalDate, i);
                    if (i == chaDays) {
                        weChatStartDay = dayTag;
                    }
                    values = DailyReportDBUtil.getWechatOrderReport(dayTag);
                    paramsData.put("Businessdate", dayTag);
                    values.putAll(paramsData);
                    weChatNetData.put(dayTag, JSON.toJSONString(values));
                }
            } else {
                values = DailyReportDBUtil.checkByDay(businessDate, businessDate, billType, accountBookId);
                paramsData.put("Businessdate", businessDate);
                values.putAll(paramsData);
                weChatNetData.put(businessDate, JSON.toJSONString(values));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.REPORT_ERR, "抽取'微信外卖'异常businessDate = " + businessDate, naturalDate, e);
        }
        DailyReportDBUtil.saveByDayReport(shopGUID, weChatNetData, weChatStartDay, naturalDate, billType, accountBookId, ReportConsrance.WECHAT_ORDE);
    }

    @DrivenMethod(uri = "bizsync/get_all_host")
    public SocketResponse getAllHost(SocketHeader head, String param) {
        String sql = "where fiStatus='1' and fsHostId not in ('" + HostBiz.mealorder + "','" + HostBiz.localhost + "','" + HostBiz.cloudsite + "')";
        List<HostDBModel> hostList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, HostDBModel.class);
        GetHostResponse response = new GetHostResponse();
        response.hostList = hostList;
        SocketResponse socketResponse = new SocketResponse();
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.data = response;
        return socketResponse;
    }

    /**
     * 校验账号是否有效
     * 1、用户名密码正确，或者IC卡号正确
     * 2、账户状态正常
     * 3、未在其他站点登录
     *
     * @return UserDBModel
     */
    private static UserDBModel checkLogin(String fromHostID, JSONObject request, SocketResponse socketResponse) {
        UserDBModel loginUser;
        if (TextUtils.equals(request.getString("loginway"), "1")) { //校验IC卡号是否正确
            loginUser = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbUser where fsiccardcode = '" + request.getString("cardno") + "' and fiStatus <> '13' order by fiStatus desc ", UserDBModel.class);
            if (loginUser == null) {
                socketResponse.code = 203;
                socketResponse.message = "卡号不正确。";
                return null;
            }
        } else { //校验账户密码登录的场景
            //判断服务员重复登录的状况
            if (TextUtils.isEmpty(request.getString("userid"))) {
                socketResponse.code = 200;
                socketResponse.message = "用户名为空";
                return null;
            }

            /**
             * 校验账号信息是否有效
             */
            String validSql = "select * from tbUser where fsUserId = '" + request.getString("userid") + "' and fiStatus <> '13' order by fiStatus desc ";
            loginUser = DBSimpleUtil.query(APPConfig.DB_MAIN, validSql, UserDBModel.class);

            if (loginUser == null) {
                socketResponse.code = 202;
                socketResponse.message = "未查到该账户。";
                return null;
            }

            if (!TextUtils.equals(loginUser.fsPwd, request.getString("pwd"))) { //校验密码是否正确
                socketResponse.code = 203;
                socketResponse.message = "密码不正确。";
                return null;
            }

            if (!TextUtils.equals(loginUser.fsUserName, request.getString("username"))) {
                socketResponse.code = 203;
                socketResponse.message = "账户已发生变动，请先同步数据。";
                return null;
            }
        }

        if (loginUser.fiStatus != 1) {
            socketResponse.code = 202;
            socketResponse.message = "该账户已被停用。";
            return null;
        }

        String sql = "where current_user_id='" + loginUser.fsUserId + "' and hostid<>'" + HostBiz.mealorder + "'";
        HostStatusModel loginedHost = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, HostStatusModel.class);
        if (loginedHost != null && !TextUtils.equals(loginedHost.hostid, fromHostID)) {
            socketResponse.code = 201;
            socketResponse.message = "该账户已经在[" + loginedHost.hostid + "]站点登录,请先退出登录。";
            return null;
        }

        return loginUser;
    }

    /**
     * 设置为主站点
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/setasmain")
    public SocketResponse h(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        try {
            JSONObject reques = JSON.parseObject(param);
            DriverBus.call("udppush/broad", reques.getString("address"), reques.getString("shopID"));

        } catch (Exception e) {
            LogUtil.logError(e);
        }
        SocketResponse response = new SocketResponse();
        response.code = SocketResultCode.SUCCESS;
        return response;
    }

    /**
     * 修改店铺模式
     *
     * @param type
     * @return
     */
    @DrivenMethod(uri = "bizsync/updateShopType")
    public void updateShopType(String type) {
        if (TextUtils.isEmpty(type)) {
            return;
        }
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbShop set fiShopType = '" + type + "' ");
    }

    @DrivenMethod(uri = "bizsync/get_unbind_host")
    public SocketResponse i(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);

            String sqlParam = " and fiHostCls not in ('" + HostCls.Make + "', '" + HostCls.Kitchen + "')";
            if (request != null && request.getJSONArray("hostCls") != null) {
                List<String> hostCls = JSON.parseArray(request.getJSONArray("hostCls").toJSONString(), String.class);
                if (!ListUtil.isEmpty(hostCls)) {
                    sqlParam = " and fiHostCls in (" + ListUtil.optSqlParams(hostCls) + ")";
                }
            }

            String sql = "where fiStatus='1' and fsHostId not in ('" + HostBiz.mealorder + "','" + HostBiz.localhost + "','" + HostBiz.cloudsite + "')";
            sql += sqlParam;

            String sql2 = "where bind_status='1'";
            List<HostStatusModel> bindHistore = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql2, HostStatusModel.class);
            List<HostDBModel> hostList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, HostDBModel.class);
            for (int i = 0; i < hostList.size(); i++) {
                for (int j = 0; j < bindHistore.size(); j++) {
                    if (TextUtils.equals(hostList.get(i).fsHostId, bindHistore.get(j).hostid)) {
                        hostList.remove(i);
                        i--;
                        bindHistore.remove(j);
                        break;
                    }
                }
            }
            GetHostResponse response = new GetHostResponse();
            response.hostList = hostList;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "绑定站点异常";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/bindHost")
    private SocketResponse f(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            socketResponse = bindHost(request.getString("hostid"), request.getString("device"), request.getInteger("main"));
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "绑定站点异常";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/getPayPrefix")
    public static void getPayPrefix(IExecutorCallback callback) {
        GetPayPrefixRequest request = new GetPayPrefixRequest();
        BusinessExecutor.execute(request, callback, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof GetPayPrefixResponse) {
                    JSONObject obj = JSON.parseObject(((GetPayPrefixResponse) responseData.responseBean).data);
                    // 微信前缀
                    if (obj.containsKey("1")) {
                        String value = obj.getString("1");
                        if (!TextUtils.isEmpty(value)) {
                            NetPayUtil.PREFIX_WECHAT = value.split(",");
                        }
                    }
                    // 支付宝前缀
                    if (obj.containsKey("2")) {
                        String value = obj.getString("2");
                        if (!TextUtils.isEmpty(value)) {
                            NetPayUtil.PREFIX_ALI = value.split(",");
                        }
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
    }

    /**
     * 统计小票打印数据--日切时统计
     */
    private void statisticsReceipts(String businessDate) {
        //打印总数
        String allCount = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select count(*) allCount from tbPrintTask " +
                "where fsDate = '" + businessDate + "'");
        BizLog.addLog(allCount, "", "", BizLog.RECEIPT_ALL, "所有小票数量", businessDate);
        String allMakeCount = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select count(*) allCount from tbPrintTask" +
                " where fsDate = '" + businessDate + "' and fsReportId in ('S06', 'S05', 'N03')");
        BizLog.addLog(allMakeCount, "", "", BizLog.RECEIPT_MAKE, "制作单数量", businessDate);
        String allBillCount = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select count(*) allCount from tbPrintTask" +
                " where fsDate = '" + businessDate + "' and fsReportId in ('S01', 'N01')");
        BizLog.addLog(allBillCount, "", "", BizLog.RECEIPT_BILL, "结账单数量", businessDate);
        String openBox = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select count(*) allCount from tbPrintTask " +
                "where fsDate = '" + businessDate + "' and fiTaskType ='2'");
        BizLog.addLog(openBox, "", "", BizLog.OPEN_BOX, "开钱箱次数", businessDate);
        String failCount = DBSimpleUtil.queryString(APPConfig.DB_PRINT, "select count(*) allCount from tbPrintTask " +
                "where fsDate = '" + businessDate + "' and fiStatus <> '4'");
        BizLog.addLog(failCount, "", "", BizLog.RECEIPT_FAIL, "小票打印失败数量", businessDate + "  shopid:" + DBMetaUtil
                .getSettingsValueByKey(META.SHOPID));
    }

    /**
     * 正餐登录
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "bizsync/loginForDinner")
    private SocketResponse login(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String currentHostID = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            String shopID = HostUtil.getShopID();

            boolean isShopFinished = HostUtil.isShopFinished();
            //如果操作是正常登录
            //如果门店已打烊，则必须要求先在主站点登录一次，以进行营业
            if (!TextUtils.equals(currentHostID, head.hd) && isShopFinished) {
                socketResponse.code = -1;
                socketResponse.message = "主站点尚未开业";
            } else {
                //检查站点的绑定状态,如果没有绑定,先进行绑定
                HostStatusModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "where hostid='" + head.hd + "' and " +
                        "bind_status='1'", HostStatusModel.class);
                if (model == null) {
                    bindHost(head.hd, head.device, 0);
                }

                // 检查站点是否存在 -- 若当前站点是业务中心则不检查
                String hostMainId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
                if (!TextUtils.equals(hostMainId, head.hd)) {
                    String hostCheckSql = "select * from tbhost where fsHostId = '" + head.hd + "' and fiStatus = '1'";
                    HostDBModel hostDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, hostCheckSql, HostDBModel.class);
                    if (hostDBModel == null) {
                        socketResponse.code = 204;
                        socketResponse.message = "站点已被停用。";

                        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from host_status where hostid = '" + head
                                .hd + "'");
                        TableDriver.releaseHostLock(head.hd);
                        FastFoodBusinessUtil.unLockOrderByHostId(head.hd);
                        return socketResponse;
                    }
                }
                final LoginToCenterForDinnerResponse response = new LoginToCenterForDinnerResponse();
                socketResponse.data = response;
                //更新站点的营业数据
                if (HostUtil.needSyncAll(head.hd)) {
                    head.dv = "";
                }
                String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
                if (!TextUtils.equals(head.dv, currentDataVersion)) {
                    JSONObject ob = buildData(head.hd, head.dv);
                    response.datas = ob.toJSONString();
                }
                response.newTimeTag = currentDataVersion;


                //校验登录账户
                UserDBModel loginUser = checkLogin(head.hd, request, socketResponse);
                if (!socketResponse.success() || loginUser == null) {
                    return socketResponse;
                }
                //判断是否进行日切
                if (isShopFinished) {
                    String currentDate = DateUtil.getCurrentDate("yyyy-MM-dd");

                    if (DateUtil.compareDate(currentDate, "2017-06-16", "yyyy-MM-dd") > 0) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "系统日期不正确";
                        return socketResponse;
                    }
                    String histToryDate = HostUtil.getHistoryBusineeDate(shopID);
                    if (DateUtil.compareDate(currentDate, histToryDate, "yyyy-MM-dd") > 0) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "系统日期不正确";
                        return socketResponse;
                    }
                    if (!TextUtils.equals(currentDate, histToryDate)) {
                        newBusinessDate(shopID, currentDate);
                        IOCache.removeCacheByType();

                        //统计小票打印数据
                        statisticsReceipts(histToryDate);
                        logSQLiteDatabaseSize();
                        response.newBusinessDate = 1;
                    }
                }

                try {
                    // 登录成功需要初始化、并刷新档口信息
                    if (DBOrderConfig.useKdsService()) {
                        KdsManager.getInstance().init();
                        KdsManager.getInstance().refresh();
                    }
                } catch (Exception ex) {
                    LogUtil.logError(ex);
                }

                response.loginUser = loginUser;
                response.collectMoney = PermissionCheckDinner.hasPermission(loginUser.fsUserId, Permission
                        .DINNER_bnSellCheck);
                response.openOrder = PermissionCheckDinner.hasPermission(loginUser.fsUserId, Permission
                        .DINNER_bnSellOrder);
                response.businessDate = HostUtil.getHistoryBusineeDate(shopID);
                response.currentSectionId = OrderUtil.getSectionId();
                //进行登录
                response.session = HostUtil.hostLogin(loginUser.fsUserId, head.hd, response.currentSectionId);

                //解决meta表key冲突问题。当线上所有版本都升级到pro2.8.2后，这段代码就可以拿掉了
                if (TextUtils.isEmpty(DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, ""))
                        || TextUtils.isEmpty(DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, ""))) {
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_AUTO_WHEN_PAY, "0"));
                    DBMetaUtil.updateSettingsValueByKey(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, DBMetaUtil.getConfig(META.PRINT_INVOICE_QR_WHEN_BILL_MANAGE, "0"));
                }

                //同步餐厅配置
                List<com.alibaba.fastjson.JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META
                        .SYNC_SQL);
                if (ListUtil.isEmpty(list)) {
                    list = new ArrayList<>();
                }
                response.dinnerLocalSettings = list;
                response.dinnerDBSettings = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue " +
                                "where fsParamId in ('119','134','144','215','316','317','320','321', '339', '358', '359')",
                        ParamvalueDBModel.class);
                response.couponBargainList = OrderUtil.initBarginList(response.businessDate);
                response.shiftList = getShiftList();

                socketResponse.code = 0;
                socketResponse.message = "更新成功";
                socketResponse.data = response;
                ShopDBModel shop = DBSimpleUtil.query(APPConfig.DB_MAIN, "SELECT * FROM tbshop WHERE fiStatus = '1'", ShopDBModel.class);
                if (shop != null) {
                    //缓存店铺运行模式
                    APPConfig.fiWorkMode = shop.fiWorkMode;
                }

                // 异步触发更新商场协议
                MallProtocolBizUtil.updateMallProtocol(true);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        PresetDataUtils.presetData();
        return socketResponse;
    }

    /**
     * 日切
     *
     * @param shopID  String
     * @param newDate String
     */
    private static void newBusinessDate(String shopID, String newDate) {
        HostUtil.updateBusinessDate(newDate, "");
        OrderDriver.saveID(shopID, OrderDriver.KEY_ORDER, 0);

        //重制牌号
        DataCacheDBUtil.resetMealNumber();

        IOCache.removeCacheByType();

        /**
         * 日切的时候清除缓存
         */
        RapidPrePayFastfoodBiz.clearCache();

        //换了个位置，在这里面 cleanExpiredData(newDate);
        //MessageDBUtil.removeHistoryMsg(newDate);

        //重置所有估清菜品为正常售卖
        SellOutServerProcessor.resetAllTempSellOut();

        // 校验报表数据，删除大于31天的报表数据
        // 注释掉此行，因为下面cleanExpiredData()这个方法里会执行删除报表数据
//        DriverBus.call("monitor/check_report", newDate, "31");
        DriverBus.call("monitor/update_rapid_sell_out");
        LocalDataManager.cleanExpiredData(newDate);
        LocalDataManager.uploadShopEnv();
        //强制更新插件
        DriverBus.call("biz/loadNew");

        // 校验是否有订单数据需要迁回 master 库
        ReplicationProcessor.getInstance().slaveMoveBack(newDate);
    }

    /**
     * 统计数据库大小
     */
    public static void logSQLiteDatabaseSize() {
        List<String> dbName = new ArrayList<>();
        dbName.add(APPConfig.DB_CLIENT);
        dbName.add(APPConfig.DB_MAIN);
        dbName.add(APPConfig.DB_PRINT);
        dbName.add(APPConfig.DB_NET_ORDER);
        for (String tempDB : dbName) {
            DBManager.getInstance(tempDB).executeInTransactionWithOutThread((db) -> {
                long size = new File(db.getPath()).length();
                RunTimeLog.addLog(RunTimeLog.SQLITEDATABASE_SIZE, tempDB + "数据库大小：" + size);
                return null;
            });
        }
    }

    @DrivenMethod(uri = "bizsync/logoutForDinner")
    private SocketResponse logoutDinner(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid=''," +
                    "biz_status='" + HostStatus.CLOSE + "',current_user_id='',sectionid='' where hostid='" + head.hd
                    + "'");

            socketResponse.code = 0;
            socketResponse.message = "更新成功";
            socketResponse.data = null;
            return socketResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/chooseShift")
    private SocketResponse chooseShift(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            String shiftID = request.getString("shiftID");
            String dbShiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShiftId from tbshift where " +
                    "fsShiftId='" + shiftID + "' and fiStatus='1' limit 1");
            String closedShiftID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select key from datacache where " +
                    "type='" + IOCache.TYPE_SHIFT_CLOSE + "' and key='" + shiftID + "'");
            if (!TextUtils.isEmpty(dbShiftID)) {
                if (!TextUtils.isEmpty(closedShiftID)) {
                    socketResponse.code = SocketResultCode.SHOP_DATA_EXPIRED;
                    socketResponse.message = "此班别已关账";
                    return socketResponse;
                } else {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set shiftid='" + shiftID + "' where" +
                            " hostid='" + head.hd + "'");
                }
            } else {
                socketResponse.code = SocketResultCode.SHOP_DATA_EXPIRED;
                socketResponse.message = "此班别已失效";
                return socketResponse;
            }
            socketResponse.code = 0;
            socketResponse.message = "更新成功";
            socketResponse.data = null;
            return socketResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "更新失败";
        }

        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/checkUserState")
    private SocketResponse checkUserState(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String userId = request.getString("userId");
            UserDBModel userDBModel = UserDBUtils.queryById(userId);
            if (userDBModel != null && userDBModel.fiStatus == 1) {
                response.code = SocketResultCode.SUCCESS;
            } else {
                //用户被禁用或者被删除
                response.code = SocketResultCode.INVALID_USER_ACCOUNT;
                if (userDBModel == null) {
                    response.message = "账号不存在";
                } else if (userDBModel.fiStatus == 9) {
                    response.message = "账号已被禁用";
                } else if (userDBModel.fiStatus == 13) {
                    response.message = "账号已被删除";
                } else {
                    response.message = "账号不存在";
                }
            }
        } catch (Exception e) {
            response.code = SocketResultCode.EXCEPTION;
            response.message = "请求发生错误";
        }
        return response;
    }

    /**
     * 已交班订单号
     *
     * @param businessDate 营业日期
     * @param waiterid     收银员ID
     * @param shiftid      班别ID
     * @return
     */
    public static String getLockedOrderID(final String businessDate, final String waiterid, final String shiftid) {
        IDBOperate<String> op = new IDBOperate<String>() {
            @Override
            public String doJob(SQLiteDatabase db) {
                String sqlUnlocked = "select order_id from order_pay_cache where locked = 1 and shiftid = '" +
                        shiftid + "' and waiterid='" + waiterid + "' and business_date='" + businessDate + "'";
                Cursor cursor = null;
                StringBuilder sb = new StringBuilder();
                try {
                    cursor = db.rawQuery(sqlUnlocked, null);
                    if (cursor != null) {
                        int index = cursor.getColumnIndex("order_id");
                        while (cursor.moveToNext()) {
                            sb.append(cursor.getString(index)).append(",");
                        }
                        if (sb.length() > 1) {
                            sb.deleteCharAt(sb.length() - 1);
                        }

                    }
                } catch (Exception e) {
                    LogUtil.logError(e);
                } finally {
                    DBSimpleUtil.closeCursor(cursor);
                }
                return sb.toString();
            }
        };
        return DBManager.getInstance().executeQuery(op);
    }

    public static com.alibaba.fastjson.JSONObject buildData(String hostID, String lastTime) {
        return buildData(hostID, lastTime, null);
    }

    public static com.alibaba.fastjson.JSONObject buildData(String hostID, String lastTime, IProgressCallback progressCb) {
        if (HostUtil.needSyncAll(hostID)) {
            lastTime = "0";
        }
        // 这里无法计算进度，先手动置，待有更好方案时替换
        onProgress(progressCb, 1);

        String[] tableList = new String[]{
                "tbask", "tbaskgp",
                "tbmenucls", "tbmenuingredgprel", "tbmenuitem", "tbmenuitemaskgp", "tbmenuitemaskgp",
                "tbmenuitemsetside", "tbmenuitemsetsidedtl", "tbmenuitemuint",
                "tbmarea", "tbmtable", "tbmtablecls",
                "tbpayment", "tbpaymenttype",
                "tbshop",
                "tbCutMoney", "tbbargain",
                "tbBillSource", "tbhostexternal", "tbparamvalue", "tbbargainfullitem"};
        com.alibaba.fastjson.JSONObject ob = new com.alibaba.fastjson.JSONObject();
        if (TextUtils.isEmpty(lastTime)) {
            lastTime = "0";
        }
        onProgress(progressCb, 3);
        String sql = "select * from %s where (fsUpdateTime > '" + lastTime + "' or fsUpdateTime='' or fsUpdateTime " +
                "isnull)";
        for (String temp : tableList) {
            // 美易点Client库不保存拼桌桌台信息
            if (APPConfig.isMyd() && TextUtils.equals("tbmtable", temp)) {
                ob.put(temp, DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql + " and fistatus<>'2'", temp)));
            } else {
                ob.put(temp, DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, temp)));
                //todo 此日志为了定位站点库和业务中心库数据不一致问题，待定位到问题后，可以移除此日志
                if(TextUtils.equals(temp,"tbmenuitem") || TextUtils.equals(temp,"tbmenucls") || TextUtils.equals(temp,"tbmenuitemuint")){
                    LogUtil.logBusiness("bizSyncDriver-buildData","hostID:"+hostID+",lastTime:"+lastTime+",data:"+ob.get(temp));
                }
            }
        }
        onProgress(progressCb, 35);
        List<JSONObject> printerList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, "tbPrinter"));
        if (!ListUtil.isEmpty(printerList)) {
            ob.put("tbPrinter", printerList);
        }
        onProgress(progressCb, 43);

        ob.put("tbhost", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, "select * from tbHost where fsHostID='" +
                hostID + "'"));
        ob.put("meta", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL));

        onProgress(progressCb, 57);
        // tbshopservice 表 fsUpdateTime 存储的内容为时间戳
        long timestamp;

        // 不依赖于 try-catch 判断业务, 如果位数不等于格式化的位数，则直接置为 0
        if (lastTime.length() == DateUtil.DATE_VISUAL14FORMAT.length()) {
            // DateUtil#date2TimeStamp 方法内部存在 try-catch, 如果位数相等情况下的进行格式化错误，则返回 0
            timestamp = DateUtil.date2TimeStamp(lastTime, DateUtil.DATE_VISUAL14FORMAT);
        } else {
            timestamp = 0;
        }

        String sqlShopService = "SELECT * FROM tbshopservice WHERE fsUpdateTime > " + timestamp + "  or fsUpdateTime='' or fsUpdateTime isnull";
        ob.put("tbshopservice", DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sqlShopService));

        onProgress(progressCb, 65);
        HostUtil.updateHostPullIncrement(hostID);
        onProgress(progressCb, 71);
        return ob;
    }

    private static void onProgress(IProgressCallback progressCB, int progress) {
        if (progressCB != null) {
            progressCB.onProgress(progress, IProgressCallback.TAG_SYNC_DATA_FROM_CENTER);
        }
    }

    @DrivenMethod(uri = "bizsync/getDataFromCenter")
    private SocketResponse g(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            if (TextUtils.isEmpty(head.shopid)) {
                socketResponse.code = -1;
                socketResponse.message = "请输入有效的门店ID";
                return socketResponse;
            }
            String localShopId = HostUtil.getShopID();
            if (!TextUtils.isEmpty(localShopId) && localShopId.equals(head.shopid)) {
                String serverTime = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
                if (TextUtils.isEmpty(serverTime)) {
                    serverTime = DBMetaUtil.getSettingsValueByKey(META.DATA_SYNC_TIME);
                }
                if (HostUtil.needSyncAll(head.hd)) {
                    head.dv = "";
                }
                if (TextUtils.equals(serverTime, head.dv)) {
                    socketResponse.code = 0;
                    socketResponse.message = "已经是最新数据";
                    return socketResponse;
                }
                GetDataFromCenterResponse response = new GetDataFromCenterResponse();
                JSONObject ob = buildData(head.hd, head.dv, new IProgressCallback() {
                    @Override
                    public void onProgress(int progress, String tag) {
                        NotifyToClient.sendTo(head.hd, "login/dataSyncProgress", progress + "", tag);
                    }
                });
                response.datas = ob.toJSONString();
                response.newTimeTag = serverTime;
                socketResponse.data = response;
                socketResponse.message = "成功";
                return socketResponse;
            } else {
                socketResponse.code = -1;
                socketResponse.message = "门店ID不正确";
                return socketResponse;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/get_token")
    private SocketResponse get_token(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            //GetTokenRequest request = JSON.parseObject(param, GetTokenRequest.class);
            JSONObject request = JSON.parseObject(param);
            if (TextUtils.equals(request.getString("shopid"), HostUtil.getShopID())) {
                GetTokenResponse response = new GetTokenResponse();
                response.token = DBMetaUtil.getSettingsValueByKey(META.TOKEN);
                response.seed = DBMetaUtil.getSettingsValueByKey(META.SEED);
                response.shopid = HostUtil.getShopID();

                socketResponse.code = 0;
                socketResponse.data = response;
                socketResponse.message = "查询成功";
            } else {
                socketResponse.code = -1;
                socketResponse.data = null;
                socketResponse.message = "门店ID不匹配";
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "请求异常";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/refreshMessageUndeal")
    private void refreshMessageUndeal(String targetHost) {
        NotifyToClient.refreshUndealMessage();
    }

    @DrivenMethod(uri = "bizsync/checkMainPointConnected")
    private SocketResponse checkMainPointConnected(SocketHeader head, String targetHost) {
        SocketResponse socketResponse = new SocketResponse();
        CheckBizCenterResponse response = new CheckBizCenterResponse();
        if (BindProcessor.isCurrentHostMain()) {
            response.ip = DeviceUtil.getLocalIpList();
            response.hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
            response.shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
            socketResponse.code = 0;
        } else {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        socketResponse.data = response;
        socketResponse.message = "可以正常连接主站点";
        return socketResponse;
    }

    /**
     * 更新门店数据的缓存
     */
    @DrivenMethod(uri = "bizsync/clearUser")
    private void clearHostLoginUser(String hostID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update host_status set user_session='',shiftid=''," +
                "current_user_id='',sectionid='' where  hostid='" + hostID + "'");
    }

    @DrivenMethod(uri = "bizsync/refreshTableLock")
    private void refreshTableLock(String targetHost) {
        NotifyToClient.refreshTableLock(targetHost);
    }

    @DrivenMethod(uri = "bizsync/notifyAllOrderChanged")
    private void notifyAllOrderChanged(String orderId) {
        NotifyToClient.orderChange(orderId);
    }

    @DrivenMethod(uri = "bizsync/refreshOrderLock")
    private void refreshOrderLock(String targetHost) {
        NotifyToClient.refreshFastFoodOrderLock(targetHost);
    }

    /**
     * 注销用户信息
     *
     * @param param
     */
    @DrivenMethod(uri = TAG + "/cancellation")
    private SocketResponse cancellation(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        //CancellationRequest request = JSON.parseObject(param, CancellationRequest.class);

        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            socketResponse.message = "登录信息已过期";
            return socketResponse;
        }

        if (!Permission.hasPermissionDinnerHost(userDBModel.fsUserId, Permission.DINNER_vMaintain)) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            socketResponse.message = "您没有站点维护的权限";
            return socketResponse;
        }

        JSONObject request = JSON.parseObject(param);
        HostUtil.logoutUserByUser(request.getString("userID"));
        TableBusinessUtil.unlockTableByUser(request.getString("userID"));
        FastFoodBusinessUtil.unLockOrderByUserId(request.getString("userID"));
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "注销用户成功";
        return socketResponse;
    }

    /**
     * 解绑用户信息
     *
     * @param param
     */
    @DrivenMethod(uri = TAG + "/relievebind")
    private SocketResponse relievebind(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String fsHostId = request.getString("fsHostId");
        HostUtil.relieveBind(fsHostId);
        HostUtil.logoutUserByHost(fsHostId);
        TableDriver.releaseHostLock(fsHostId);
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "解除绑定成功";
        return socketResponse;
    }

    /**
     * 获取备份数据
     *
     * @param param String
     */
    @DrivenMethod(uri = "bizsync/getBackUpData")
    private SocketResponse getBackUpData(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        String backUpHostID = DBMetaUtil.getSettingsValueByKey(META.DISASTER_CONTROL);
        if (TextUtils.isEmpty(backUpHostID)) {
            backUpHostID = DBMetaUtil.getSettingsValueByKey(META.DISASTER_CONTROL_DEFAULt);
            if (TextUtils.isEmpty(backUpHostID)) {
                backUpHostID = HostUtil.getPaySiteForBack();
                DBMetaUtil.updateSettingsValueByKey(META.DISASTER_CONTROL_DEFAULt, backUpHostID);
                DBMetaUtil.updateSettingsValueByKey(META.DISASTER_CONTROL, backUpHostID);

            }
        }
        if (TextUtils.isEmpty(backUpHostID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "无可用的灾备站点";
            return socketResponse;
        }

        //GetBackupDataRequest request = JSON.parseObject(param, GetBackupDataRequest.class);
        JSONObject request = JSON.parseObject(param);
        if (!TextUtils.equals(request.getString("requestHostID"), backUpHostID)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "只接收灾备站点的请求";
            return socketResponse;
        }
        GetBackupDataResponse response = new GetBackupDataResponse();
        if (!TextUtils.isEmpty(request.getString("orderID"))) {
            if (request.getIntValue("firstRead") != 1) {
                response.orderCache = OrderSaveDBUtil.get(request.getString("orderID"));
                response.session = PaySaveDBUtil.get(request.getString("orderID"));
            }
        }

        response.backData = new com.alibaba.fastjson.JSONObject();
        List<com.alibaba.fastjson.JSONObject> array;
        List<String> notFinishedOrderIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select order_id from order_cache where order_status not in ('3','5','6')");
        String notFinishedOrderID = "";
        if (!ListUtil.isEmpty(notFinishedOrderIDList)) {
            if (!ListUtil.isEmpty(notFinishedOrderIDList)) {
                notFinishedOrderID = TextUtils.join("','", notFinishedOrderIDList);
                notFinishedOrderID = "'" + notFinishedOrderID + "'";
                response.notFinishedOrderID = notFinishedOrderID;
            }
        }
        String sql = "select * from %s where order_id  in (" + notFinishedOrderID + ")";

        if (request.getIntValue("firstRead") == 1 && !TextUtils.isEmpty(notFinishedOrderID)) {
            array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, "order_cache"));
            if (!ListUtil.isEmpty(array)) {
                response.backData.put("order_cache", array);
            }
            array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, "order_menu_cache"));
            if (!ListUtil.isEmpty(array)) {
                response.backData.put("order_menu_cache", array);
            }
            array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(sql, "order_pay_cache"));
            if (!ListUtil.isEmpty(array)) {
                response.backData.put("order_pay_cache", array);
            }
//        //获取所有未完成的快餐单
//        String fastFoodOrderSql = "select * from %s where fastfood_biz_status<>'2'";
//        array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(fastFoodOrderSql, "fastfood_order_biz"));
//        if (!ListUtil.isEmpty(array)) {
//            response.backData.put("fastfood_order_biz", array);
//        }
        }
        //同步单序表
        String tbSeqNoSql = "select * from %s";
        array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, String.format(tbSeqNoSql, "tbSeqNo"));
        if (!ListUtil.isEmpty(array)) {
            response.backData.put("tbSeqNo", array);
        }
        //同步Meta表
        array = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL);
        if (!ListUtil.isEmpty(array)) {
            response.backData.put("meta", array);
        }
        //获取未完成结账的订单ID

        socketResponse.data = response;
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        return socketResponse;
    }

    /**
     * 同步日志
     *
     * @param param String
     */
    @DrivenMethod(uri = TAG + "/synclog")
    private SocketResponse synclog(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        socketResponse.code = SocketResultCode.SUCCESS;
        List<LogObject> logList = JSON.parseArray(request.getString("logList"), LogObject.class);
        try {
            if (!MwLog.receiveSyncLog(logList)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 获取班别
     *
     * @param param String
     */
    @DrivenMethod(uri = "bizsync/getShift")
    private SocketResponse getShift(SocketHeader head, String param) {
        SocketResponse<ShiftCloseResponse> socketResponse = new SocketResponse<>();
        socketResponse.code = SocketResultCode.SUCCESS;
        try {
            ShiftCloseResponse response = new ShiftCloseResponse();
            response.shiftList = getShiftList();
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 关账或者打开
     *
     * @param param String
     */
    @DrivenMethod(uri = "bizsync/changeShift")
    private SocketResponse closeShift(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            int close = request.getInteger("close");
            String shiftID = request.getString("shiftID");
            boolean forceLogout = request.getBooleanValue("forceLogou");
            if (TextUtils.isEmpty(shiftID)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "错误的班别";
                return socketResponse;
            }
            if (close == 1) {
                String unPaiedOrder = OrderDriver.getUnPayedShiftOrder(shiftID);
                if (!TextUtils.isEmpty(unPaiedOrder)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "此班别的订单[" + unPaiedOrder + "]尚未完成结账";
                    return socketResponse;
                }
                String unShiftOrder = CenterCloseUtil.checkUnShift(shiftID, HostUtil.getHistoryBusineeDate(""));
                if (!TextUtils.isEmpty(unShiftOrder)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "[" + unShiftOrder + "]未完成交班，请交班后再试";
                    return socketResponse;
                }

                // 当前班别有其他站点登录，需要二次确认
                List<String> hostNeedLogout = HostUtil.getHostIDByShiftID(shiftID);
                if (!ListUtil.isEmpty(hostNeedLogout)) {
                    if (forceLogout) {
                        //通知站点退出登录
                        if (!ListUtil.isEmpty(hostNeedLogout)) {
                            for (String temp : hostNeedLogout) {
                                if (!TextUtils.equals(temp, head.hd)) {
                                    NotifyToClient.sendTo(temp, "login/callLogout", "已关账，请重新选择班别");
                                }
                            }
                        }
                        //将登录到这个班别的站点都设置为登录已过期
                        HostUtil.logoutUserByShiftId(shiftID);
                    } else {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        ShiftCloseResponse response = new ShiftCloseResponse();
                        response.shiftList = getShiftList();
                        response.hostNeedLogout = hostNeedLogout;
                        socketResponse.data = response;
                        return socketResponse;
                    }
                }

                CacheModel model = new CacheModel();
                model.key = shiftID;
                model.type = IOCache.TYPE_SHIFT_CLOSE;
                model.value = "1";
                model.replaceNoTrans();
            } else {
                String sql = "delete from datacache where key='" + shiftID + "' and type='" + IOCache
                        .TYPE_SHIFT_CLOSE + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            ShiftCloseResponse response = new ShiftCloseResponse();
            response.shiftList = getShiftList();
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    public static List<DataModel> getShiftList() {
        String sql = "select fsShiftId as id,fsShiftName as name,datacache.value as status from tbshift left join " +
                "(select * from datacache where type='%d') as datacache  on tbshift.fsShiftId=datacache.key where " +
                "tbshift.fiStatus='1'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, String.format(Locale.SIMPLIFIED_CHINESE, sql, IOCache
                .TYPE_SHIFT_CLOSE), DataModel.class);
    }

    @Deprecated
    public static void checkNeedReload() {
        callReLoad();
    }

    @Deprecated
    private static boolean callReLoad() {
        boolean can = !UploadChangeDataProcessor.hasMoreUnFinishedData() && !UploadDataProcessor.hasMoreUnFinishedData();
        LogUtil.logBusiness(TAG, "callReLoad can:" + can);
        if (can) {
            // 1. 重置业务中心时间戳
//            DBMetaUtil.updateSettingsValueByKey(META.DATA_SYNC_TIME, "0");
//            DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, "0");

            // 2. HostStatus 状态变更
//            HostUtil.updateHostPullAll();
        } else {
            GlobalLooper.postDelayed(() -> {
                LogUtil.logBusiness(TAG, "callReLoad UploadChangeDataProcessor.startUploadAllLocalChageData");
                UploadChangeDataProcessor.startUploadAllLocalChageData(null);
                LogUtil.logBusiness(TAG, "callReLoad UploadDataProcessor.doUploadOrderWithBaseData");
                UploadDataProcessor.doUploadOrderWithBaseData();
            }, 1000);
        }
        return can;
    }

    /**
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/reset_sync")
    private SocketResponse resetSync(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            SocketResponse response = new SocketResponse();
            if (!callReLoad()) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "请先同步数据";
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/loadActiveHostAndLoginForAdmin")
    private SocketResponse loadActiveHostAndLoginForAdmin(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            String hostId = request.getString("hostId");
            String device = request.getString("device");
            if (TextUtils.isEmpty(device)) {
                socketResponse.code = -200;
                socketResponse.message = "设备ID为空";
                return socketResponse;
            }
            IHostService hostService = new HostServiceImpl();
            socketResponse.data = hostService.loadActiveHostAndLoginForAdmin(hostId, device);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "激活成功";
            return socketResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/updateMeta")
    private SocketResponse updateMeta(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject jsonObject = JSONObject.parseObject(param);
        int key = jsonObject.getInteger("key");
        String value = jsonObject.getString("value");
        DBMetaUtil.updateSettingsValueByKey(key, value);
        return socketResponse;
    }

    /**
     * * 获取微信支付宝前缀
     *
     * @param header
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/syncPayPrefix")
    private SocketResponse syncPayPrefix(SocketHeader header, String param) {
        SocketResponse socketResponse = new SocketResponse<>();
        socketResponse.code = SocketResultCode.SUCCESS;
        try {
            getPayPrefix(null);
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 激活门店
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/active")
    private SocketResponse active(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            JSONObject response = new JSONObject();
            socketResponse.data = response;
            String shopID = request.getString("shopid");
            if (TextUtils.isEmpty(shopID)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.data = null;
                socketResponse.message = "门店ID不能为空";
                return socketResponse;
            }
            if (!BindProcessor.isActived()) {
                if (!TextUtils.isEmpty(shopID)) {
                    if (DriverBus.call("biz/isActiving")) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.data = null;
                        socketResponse.message = "正在激活";
                    } else {
                        ResponseData responseData = DriverBus.call("biz/active", shopID);
                        if (responseData.netResult != NetResultType.SUCCESS) {
                            socketResponse.code = SocketResultCode.TIME_OUT;
                            socketResponse.message = responseData.resultMessage;
                        } else {
                            if (responseData.resultMessage.contains("已经绑定")) {
                                response.put("shopActiveStatus", 0);
                            } else {
                                response.put("shopActiveStatus", 1);
                            }
                        }
                    }
                } else {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.data = null;
                    socketResponse.message = "门店ID不正确";
                }
            } else {
                if (!TextUtils.equals(DBMetaUtil.getSettingsValueByKey(META.SHOPID), shopID)) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.data = null;
                    socketResponse.message = "门店ID不匹配";
                    return socketResponse;
                }
                if (!BindProcessor.isCurrentHostMain()) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.data = null;
                    socketResponse.message = "目标设备没有部署业务中心";
                } else {
                    response.put("shopActiveStatus", 1);
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "门店已激活";
                }
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "请求异常";
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "bizsync/checkReplication")
    private SocketResponse checkReplication(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        try {
//            SlaveDBManager.getInstance().checkReplication();
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }


    /**
     * 获取门店运行模式
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "bizsync/loadWorkMode")
    private SocketResponse loadWorkMode(SocketHeader head, String param) {
        SocketResponse<GetWorkModeResponse> socketResponse = new SocketResponse<>();
        try {
            if (TextUtils.isEmpty(HostUtil.getShopID())) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有门店数据";
                return socketResponse;
            }
            GetWorkModeResponse response = new GetWorkModeResponse();
            response.fiworkMode = HostUtil.queryWorkMode();
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }

    /**
     * 获取门店所有未上送数据数量
     */
    @DrivenMethod(uri = "bizsync/loadAllNotUploadDataCount")
    private SocketResponse loadAllNotUploadDataCount(SocketHeader head, String param) {
        SocketResponse<LoadAllNotUploadDataCountResponse> socketResponse = new SocketResponse<>();
        try {
            if (TextUtils.isEmpty(HostUtil.getShopID())) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没有门店数据";
                return socketResponse;
            }

            LoadAllNotUploadDataCountResponse response = new LoadAllNotUploadDataCountResponse();
            response.dataCount = UploadDataHelper.getAllNotUploadDataCount();
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
        }
        return socketResponse;
    }
}