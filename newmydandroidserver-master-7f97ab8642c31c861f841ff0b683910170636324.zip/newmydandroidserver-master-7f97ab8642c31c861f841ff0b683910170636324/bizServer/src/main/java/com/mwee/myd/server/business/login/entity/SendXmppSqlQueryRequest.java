package com.mwee.myd.server.business.login.entity;

import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.SerializeType;
import com.mwee.android.base.net.component.HttpParam;
import com.mwee.android.base.net.component.HttpType;
import com.mwee.myd.server.business.login.LoginConstant;

/**
 * Created by hm on 2018/1/8.
 *
 */
@HttpParam(httpType = HttpType.POST,
        method = "uploadXmppResult",
        response = SendXmppSqlQueryResponse.class,
        encodeType = "UTF-8",
        serializeType = SerializeType.Json,
        contentType = "application/json", gzip = false)
public class SendXmppSqlQueryRequest extends BaseRequest{

    public String requestId;
    public String token;
    public String method;
    public String msgSeq;
    public String queryResult;

    @Override
    public String optBaseUrl() {
        return LoginConstant.getXMPPUrlRoot();
    }
}
