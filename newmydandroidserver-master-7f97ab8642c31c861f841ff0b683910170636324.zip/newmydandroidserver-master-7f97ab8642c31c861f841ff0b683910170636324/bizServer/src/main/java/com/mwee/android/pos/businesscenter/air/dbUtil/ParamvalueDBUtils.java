package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.List;

/**
 * 配置表管理类
 * Created by qinwei on 2018/7/17.
 */

public class ParamvalueDBUtils {
    public static List<ParamvalueDBModel> queryDinnerSettings() {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId in ('119','134','144','215','316','317','320','321', '339')", ParamvalueDBModel.class);
    }
}
