package com.mwee.android.pos.businesscenter.business.synccloud;

import android.support.v4.util.ArrayMap;

import com.mwee.android.base.net.BusinessBean;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderUploadBean;
import com.mwee.android.pos.db.business.SellBaseDBModel;
import com.mwee.android.sqlite.base.DBModel;

import java.util.List;

public class UploadTask extends BusinessBean {

    IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>> basicTask = null;
    IUploadDataCallback<ArrayMap<String, List<? extends SellBaseDBModel>>> orderTask = null;
    IUploadDataCallback<ArrayMap<String, List<? extends DBModel>>> otherBasicTask = null;
    IUploadDataCallback<TempAppOrderUploadBean> netOrderTask = null;

    public UploadTask() {
    }
}
