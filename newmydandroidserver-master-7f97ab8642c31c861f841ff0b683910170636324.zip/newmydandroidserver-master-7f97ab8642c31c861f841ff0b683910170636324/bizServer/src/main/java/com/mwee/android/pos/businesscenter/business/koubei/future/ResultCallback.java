package com.mwee.android.pos.businesscenter.business.koubei.future;

/**
 * Created by qinwei on 2017/2/15.
 */

public abstract class ResultCallback<T> {
    public abstract void onSuccess(T data);

    public void onFailure(int code, String msg) {
    }
}
