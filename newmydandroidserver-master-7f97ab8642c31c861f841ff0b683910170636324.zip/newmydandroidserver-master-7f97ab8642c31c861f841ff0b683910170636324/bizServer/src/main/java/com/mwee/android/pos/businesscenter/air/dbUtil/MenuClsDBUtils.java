package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.menu.UploadDishTypeBean;
import com.mwee.android.air.db.business.menu.MenuClsBean;
import com.mwee.android.air.db.business.menu.MenuClsSortBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuclsDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public class MenuClsDBUtils {
    /**
     * 查询所有菜品分类信息 不包括套餐
     *
     * @return
     */
    public static List<MenuClsBean> queryAll() {
        String sql = "SELECT fsMenuClsId,fsmenuclsname,fiSortOrder,\n" +
                "(select count(*) FROM tbmenuitem WHERE fiStatus=1 and fsMenuClsId =tbmenucls.fsMenuClsId) 'count' \n" +
                "from tbmenucls where fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind = '1' and fsMenuClsId_P=0 ORDER BY fiSortOrder;";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuClsBean.class);
    }

    /**
     * 查询所有菜品分类信息 包括套餐
     *
     * @return
     */
    public static List<MenuClsBean> queryAllContainSet() {
        String sql = "SELECT fsMenuClsId,fsmenuclsname,fiSortOrder,\n" +
                "(select count(*) FROM tbmenuitem WHERE fiStatus=1 and fsMenuClsId =tbmenucls.fsMenuClsId) 'count' \n" +
                "from tbmenucls where fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind in ('1','2') and fsMenuClsId_P=0 ORDER BY fiSortOrder;";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuClsBean.class);
    }

    public static List<String> queryAllMenuClsID() {

        String sql = "select fsMenuClsId from tbmenucls where fiStatus = '1' and fiDataSource = '0'";
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
    }

    /**
     * 美收银用
     *
     * @return
     */
    public static List<MenuClsSortBean> queryClzAndMenuItems() {
        String sql = "SELECT fsMenuClsId,fsmenuclsname,fiSortOrder\n" +
                "from tbmenucls where fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind = '1' and fsMenuClsId_P=0 ORDER BY fiSortOrder;";
        List<MenuClsSortBean> menuClsBeans = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuClsSortBean.class);

        if (menuClsBeans == null) {
            menuClsBeans = new ArrayList<>();
        }

        for (MenuClsSortBean menuClsBean : menuClsBeans) {
            menuClsBean.menuItemBeans = (ArrayList<MenuItemBean>) MenuItemDBUtils.queryMenusByClsId(menuClsBean.fsMenuClsId);
        }
        //获取所有套餐菜品
        if (MenuItemDBUtils.hasMenuPackage()) {
            MenuClsSortBean menuClsBean = new MenuClsSortBean();
            menuClsBean.fsMenuClsId = "-10086";
            menuClsBean.fsMenuClsName = "套餐";
            menuClsBean.menuItemBeans = (ArrayList<MenuItemBean>) MenuItemDBUtils.queryMenuPackagesForMsy(false);
            menuClsBeans.add(0, menuClsBean);
        }
        return menuClsBeans;
    }


    /**
     * 根据分类id查询分类信息
     *
     * @param clsId
     * @return
     */
    public static MenuclsDBModel queryById(String clsId) {
        String sql = "select * from tbmenucls WHERE fiStatus=1 and fsMenuClsId_P=0 and fsMenuClsId='" + clsId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuclsDBModel.class);
    }

    public static MenuclsDBModel queryMenuClsById(String clsId) {
        String sql = "select * from tbmenucls WHERE fiStatus=1 and fsMenuClsId='" + clsId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuclsDBModel.class);
    }

    public static boolean deleteById(String clsId) {
        MenuclsDBModel menuclsDBModel = queryById(clsId);
        menuclsDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuclsDBModel.sync = 1;
        menuclsDBModel.fiStatus = 13;
        menuclsDBModel.replaceNoTrans();
        AskManagerDBUtil.unAssociateMenuClsByClsId(clsId);
        return true;
    }

    /**
     * 修改分类名称
     *
     * @param clsId
     * @param name
     * @return
     */
    public static boolean update(String clsId, String name) {
        MenuclsDBModel menuclsDBModel = queryById(clsId);
        if (!menuclsDBModel.fsMenuClsName.equals(name)) {
            List<String> menuClsIdList = new ArrayList<>();
            menuClsIdList.add(clsId);
            cacheMenuClsIdsAfterCompare(UploadDishTypeBean.IDishType.MENU_CLS, UploadDishTypeBean.IActionType.UPDATE, menuClsIdList);
        }
        menuclsDBModel.fsMenuClsName = name;
        menuclsDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuclsDBModel.sync = 1;
        menuclsDBModel.replaceNoTrans();
        return true;
    }

    /**
     * 生成排序索引
     *
     * @return
     */
    private static int generateSortOrder() {
        String sql = "SELECT MAX(fiSortOrder) FROM tbmenucls WHERE  fiStatus=1";
        String fiSortOrder = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(fiSortOrder)) {
            return 1;
        } else {
            return StringUtil.toInt(fiSortOrder) + 1;
        }
    }

    /**
     * 新增菜品分类
     *
     * @param name
     * @return
     */
    public static boolean insert(String id, String name, int fiMenuClsKind, String shopId, UserDBModel userDBModel) {
        return insert(id, name, fiMenuClsKind, 1, shopId, userDBModel);
    }

    /**
     * 新增菜品分类
     *
     * @param name
     * @return
     */
    public static boolean insert(String id, String name, int fiMenuClsKind, int fistatus, String shopId, UserDBModel userDBModel) {
        return insert(id, name, fiMenuClsKind, fistatus, shopId, userDBModel, "1", "1");
    }

    public static boolean insert(String id, String name, int fiMenuClsKind,
                                 int fistatus, String shopId, UserDBModel userDBModel,
                                 String fsExpClsId, String fsRevenueTypeId) {
        MenuclsDBModel model = new MenuclsDBModel();
        model.setDbName(APPConfig.DB_MAIN);
        model.fsMenuClsId = id;
        model.fsMenuClsName = name;
        model.fsShopGUID = shopId;
        model.fsExpClsId = fsExpClsId;
        model.fsRevenueTypeId = fsRevenueTypeId;
        model.fiMenuClsKind = fiMenuClsKind;
        model.fiSortOrder = generateSortOrder();
        model.fiStatus = fistatus;
        model.fiDataKind = 2;
        model.fiLevel = 1;
        model.fiDtlLvl = 1;
        model.fiDataSource = 1;
        //'是否后厨打印:0无后厨打印,1单制作部门,2多制作部门';
        model.fiIsPrn = 2;
        model.sync = 1;
        model.fsMenuClsId_P = "0";
        model.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.replaceNoTrans();
        return true;
    }

    /**
     * 查询默认的套餐分类
     *
     * @return
     */
    public static String queryDefaultMenuPackageCls(String shopId, UserDBModel userDBModel) {
        MenuclsDBModel menuclsDBModel = queryByClsName("套餐");
        String clsId = "";
        //先查询默认套餐分类是否存在
        if (menuclsDBModel == null) {
            //插入一个默认的套餐分类
            clsId = IDHelper.generateMenuClsId();
            insert(clsId, "套餐", 2, shopId, userDBModel);
        } else {
            clsId = menuclsDBModel.fsMenuClsId;
        }
        return clsId;
    }

    /**
     * 查询pos产生的套餐分类
     *
     * @param clsName
     * @return
     */
    public static MenuclsDBModel queryByClsName(String clsName) {
        MenuclsDBModel menuclsDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbmenucls where fiStatus=1 and fiMenuClsKind=2 and  fsMenuClsName='" + clsName + "'", MenuclsDBModel.class);
        return menuclsDBModel;
    }

    /**
     * 分类置顶
     *
     * @param fsMenuClsId
     * @return
     */
    public static int doMenuClsToTop(String fsMenuClsId) {
        //<fiSortOrder fiSortOrder--  fiSortOrder=1
        int fiSortOrder = 0;
        MenuclsDBModel menuClsBean = queryById(fsMenuClsId);
        fiSortOrder = menuClsBean.fiSortOrder;
        menuClsBean.fiSortOrder = 1;
        menuClsBean.fsUpdateTime = DateUtil.getCurrentTime();
        menuClsBean.sync = 1;
        String sql = "update tbmenucls set fiSortOrder=fiSortOrder+1,sync=1,fsUpdateTime='" + DateUtil.getCurrentTime() + "' where fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind in(1,2) and fsMenuClsId_P=0 and fiSortOrder<=" + fiSortOrder;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        menuClsBean.replaceNoTrans();
        MetaDBController.updateSyncTime();
        return 1;
    }

    /**
     * 菜品分类排序
     *
     * @param menuClsBeans
     */
    public static void doMenuClsSort(List<MenuClsBean> menuClsBeans) {
        if (!ListUtil.isEmpty(menuClsBeans)) {
            for (int i = 0; i < menuClsBeans.size(); i++) {
                menuClsBeans.get(i).fiSortOrder = i + 1;
                String sql = "update tbmenucls set fiSortOrder="
                        + menuClsBeans.get(i).fiSortOrder
                        + ",sync=1,fsUpdateTime='" + DateUtil.getCurrentTime()
                        + "' where fiStatus='1' and fiDataKind<>'1' and fiMenuClsKind in(1,2) and fsMenuClsId='"
                        + menuClsBeans.get(i).fsMenuClsId + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            }
        }
        MetaDBController.updateSyncTime();
    }

    /**
     * 根据要求分组id,缓存该要求分组关联的菜品分类id
     *
     * @param dishType   //1->分类，2->要求，3->配料
     * @param actionType // ADD   UPLOAD   DELETE
     * @param askGpId
     */
    public static void cacheMenuIdsByAskGpId(int dishType, String actionType, String askGpId) {
        //case 1.新增-要求明细
        //case 2.批量删除-要求明细
        //case 3.编辑-要求明细
        List<String> associatedMenuClsIds = AskManagerDBUtil.findAssociatedMenuClsIdByAskGpId(askGpId);
        cacheMenuClsIdsAfterCompare(dishType, actionType, associatedMenuClsIds);
    }

    /**
     * 去重后保存该要求分组关联的菜品分类id
     *
     * @param type
     * @param actionType
     * @param menuClsIdList
     */
    public static void cacheMenuClsIdsAfterCompare(int type, String actionType, List<String> menuClsIdList) {
        //case 4.新增-要求分组
        //case 5.删除-要求分组
        //case 6.编辑-要求分组菜品分类
        //根据已保存菜品分类ids比较
        //保存新的菜品分类ids
        if (menuClsIdList == null) {
            LogUtil.logBusiness("menuClsIds保存失败:传入值为null");
            return;
        }
        if (menuClsIdList.size() <= 0) {
            LogUtil.logBusiness("menuClsIds保存失败:数据为空");
            return;
        }

        UploadDishTypeBean changedMenuClsIdsBean = new UploadDishTypeBean();
        changedMenuClsIdsBean.type = type;
//      changedMenuClsIdsBean.actionType = actionType;
        for (String menuClsId : menuClsIdList) {
            changedMenuClsIdsBean.targetId.add(menuClsId);
        }
        LogUtil.logBusiness("原始menuClsIds数据,actionType=" + actionType + "|->" + JSONObject.toJSONString(changedMenuClsIdsBean));

        String savedMenuClsIdsJson = DBMetaUtil.getConfig(META.KEY_CACHE_MENU_CLS_IDS, "");
        if (!TextUtils.isEmpty(savedMenuClsIdsJson)) {
            LogUtil.logBusiness("已保存menuClsIds,actionType=" + actionType + "|->" + savedMenuClsIdsJson);
            List<UploadDishTypeBean> savedMenuClsIdsList = JSONObject.parseArray(savedMenuClsIdsJson, UploadDishTypeBean.class);
            if (savedMenuClsIdsList == null) {
                JSONArray jsonArray = new JSONArray();
                jsonArray.add(changedMenuClsIdsBean);
                String updateJson = JSONObject.toJSONString(jsonArray);
                LogUtil.logBusiness("已保存的menuClsIds字符Json解析异常,仍更新menuClsIds,actionType=" + actionType + "|->" + updateJson + "\n");
                DBMetaUtil.updateSettingsValueByKey(META.KEY_CACHE_MENU_CLS_IDS, updateJson);
                return;
            }
            List<UploadDishTypeBean> newMenuClsIds = new ArrayList<>();
            newMenuClsIds.addAll(savedMenuClsIdsList);

            int saveIndex = -1;
            for (int i = 0; i < newMenuClsIds.size(); i++) {
                UploadDishTypeBean saveBean = newMenuClsIds.get(i);
                if (saveBean.type == changedMenuClsIdsBean.type) {
                    saveIndex = i;
                    break;
                }
            }
            if (saveIndex > -1) {
                UploadDishTypeBean saveBean = newMenuClsIds.get(saveIndex);
                for (String menuClsId : menuClsIdList) {
                    if (!saveBean.targetId.contains(menuClsId)) {
                        saveBean.targetId.add(menuClsId);
                    }
                }
            } else {
                newMenuClsIds.add(changedMenuClsIdsBean);
            }
            String updateJson = JSONObject.toJSONString(newMenuClsIds);
            LogUtil.logBusiness("更新menuClsIds,actionType=" + actionType + "|->" + updateJson + "\n");
            DBMetaUtil.updateSettingsValueByKey(META.KEY_CACHE_MENU_CLS_IDS, updateJson);
        } else {
            JSONArray jsonArray = new JSONArray();
            jsonArray.add(changedMenuClsIdsBean);
            String newJson = JSONObject.toJSONString(jsonArray);
            LogUtil.logBusiness("首次添加menuClsIds,actionType=" + actionType + "|->" + newJson + "\n");
            DBMetaUtil.updateSettingsValueByKey(META.KEY_CACHE_MENU_CLS_IDS, newJson);
        }
    }

}
