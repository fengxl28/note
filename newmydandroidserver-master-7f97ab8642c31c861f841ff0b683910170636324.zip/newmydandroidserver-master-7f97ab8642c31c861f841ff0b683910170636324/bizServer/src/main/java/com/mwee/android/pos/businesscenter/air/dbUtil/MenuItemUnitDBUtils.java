package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.air.db.business.menu.MenuItemUnitBean;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public class MenuItemUnitDBUtils {
    public static List<MenuItemUnitBean> queryByMenuItemId(String fiItemCd) {
        String sql = "select fiOrderUintCd,fdSalePrice,fdVIPPrice,fsOrderUint from tbmenuitemuint where fiStatus=1 and fiItemCd='" + fiItemCd + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemUnitBean.class);
    }

    public static List<MenuItemUnitDBModel> queryByFiItemCd(String fiItemCd) {
        String sql = "select * from tbmenuitemuint where fiItemCd='" + fiItemCd + "'";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemUnitDBModel.class);
    }

    public static void updateMenuItemUnitList(String fiItemCd, ArrayList<MenuItemUnitBean> menuItemUnitBeans) {
        for (int i = 0; i < menuItemUnitBeans.size(); i++) {
            MenuItemUnitBean menuItemUnitBean = menuItemUnitBeans.get(i);
            switch (menuItemUnitBean.editor_mode) {
                case MenuItemUnitBean.MODE_ADD:
                    addMenuItemUnit(fiItemCd, menuItemUnitBean);
                    break;
                case MenuItemUnitBean.MODE_EDITOR:
                    updateMenuItemUnit(menuItemUnitBean);
                    break;
                case MenuItemUnitBean.MODE_DELETE:
                    deleteById(menuItemUnitBean.fiOrderUintCd);
                    break;
                default:
                    break;
            }
        }
    }

    public static void updateMenuItemUnit(MenuItemUnitBean unit) {
        String menuUnitSql = "select * from tbmenuitemuint where fiOrderUintCd='" + unit.fiOrderUintCd + "'";
        MenuItemUnitDBModel unitDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, menuUnitSql, MenuItemUnitDBModel.class);
        if (unitDBModel != null) {
            unitDBModel.fsOrderUint = unit.fsOrderUint;
            unitDBModel.fdSalePrice = unit.fdSalePrice;
            unitDBModel.fdVIPPrice = unit.fdVIPPrice;
            unitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            unitDBModel.sync = 1;
            unitDBModel.fiStatus = 1;
            unitDBModel.replaceNoTrans();//修改规格

            //没有输入库存则不限制库存
            SellOutViewModel model = new SellOutViewModel();
            model.fiOrderUintCd = unitDBModel.fiOrderUintCd;
            model.fsOrderUint = unitDBModel.fsOrderUint;
            model.fiItemCd = unitDBModel.fiItemCd;
            model.fsItemName = unit.fsItemName;
            if (!TextUtils.isEmpty(unit.repertoryNumber)) {
                model.fdInvQty = new BigDecimal(unit.repertoryNumber);
                model.fiStatus = 2;
            } else {
                unitDBModel.fdInvQty = BigDecimal.ZERO;
                //输入库存则 菜品处理临时沽清状态
                model.fiStatus = 1;
            }
            //修改库存表
            model.replaceNoTrans();
        }
    }

    public static void addMenuItemUnits(String fiItemCd, ArrayList<MenuItemUnitBean> units) {
        for (int i = 0; i < units.size(); i++) {
            addMenuItemUnit(fiItemCd, units.get(i));
        }
    }

    public static void addMenuItemUnit(String fiItemCd, MenuItemUnitBean unit) {
        //插入规格
        String unitId = String.valueOf(IDHelper.generateMenuUnitId());
        MenuItemUnitDBModel menuItemUnitDBModel = new MenuItemUnitDBModel();
        menuItemUnitDBModel.fiOrderUintCd = unitId;
        menuItemUnitDBModel.fiItemCd = fiItemCd;
        menuItemUnitDBModel.fsOrderUint = unit.fsOrderUint;
        menuItemUnitDBModel.fdSalePrice = unit.fdSalePrice;
        menuItemUnitDBModel.fdVIPPrice = unit.fdVIPPrice;
        //处理规格
        menuItemUnitDBModel.fiStatus = 1;
        menuItemUnitDBModel.fiDefault = 1;
        menuItemUnitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuItemUnitDBModel.fsUpdateUserId = "admin";
        menuItemUnitDBModel.fsUpdateUserName = "管理员";
        menuItemUnitDBModel.fsShopGUID = ServerCache.getInstance().shopID;
        menuItemUnitDBModel.fiInitCount = 1;
        menuItemUnitDBModel.fdCostPrice = BigDecimal.ZERO;
        menuItemUnitDBModel.fiDataSource = 1;
        menuItemUnitDBModel.sync = 1;
        menuItemUnitDBModel.replaceNoTrans();
    }

    /**
     * 根据规格id删除规格信息
     *
     * @param fiOrderUintCd
     */
    public static void deleteById(String fiOrderUintCd) {
        String sql = "UPDATE tbmenuitemuint SET fiStatus=13,fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1 where fiOrderUintCd='" + fiOrderUintCd + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 根据菜品id批量删除规格
     *
     * @param fiItemCd
     */
    public static void deleteByMenuItemCd(String fiItemCd) {
        String sql = "UPDATE tbmenuitemuint SET fiStatus=13,fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1 where fiItemCd='" + fiItemCd + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 根据规格id查询规格名称
     *
     * @param id
     * @return
     */
    public static String queryUnitNameById(String id) {
        String sql = "select fsOrderUint from tbmenuitemuint where fiOrderUintCd='" + id +"'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }
}
