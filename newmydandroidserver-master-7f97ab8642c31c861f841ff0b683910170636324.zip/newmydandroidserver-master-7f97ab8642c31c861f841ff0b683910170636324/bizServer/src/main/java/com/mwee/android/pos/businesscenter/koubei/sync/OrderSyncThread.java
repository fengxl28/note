package com.mwee.android.pos.businesscenter.koubei.sync;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.future.KBFutureOrderSyncRequest;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.OrderData;
import com.mwee.android.pos.db.business.common.OrderDataDBUtils;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;

/**
 * Created by qinwei on 2018/10/22.
 */

public class OrderSyncThread implements Runnable {
    private OnOrderSyncThreadListener listener;
    private OrderData orderData;
    private String kbTableNo;
    private String fsmtableid;
    private String fsmtablename;
    private String kbStatus;


    public OrderSyncThread(OrderCache orderCache, OrderData orderData) {
        this.orderData = orderData;
        if (!TextUtils.isEmpty(orderCache.kbOrderId)) {
            //处理总单id
            orderData.sellList.get(0).thirdOrderId = orderCache.kbOrderId;
            orderData.sellList.get(0).fsBillSourceNo = orderCache.kbOrderId;
        }
        kbTableNo = orderCache.kbTableNo;
        kbStatus = orderCache.kbStatus;
        fsmtableid = orderCache.fsmtableid;
        fsmtablename = orderCache.fsmtablename;
    }

    @Override
    public void run() {
        try {
            KBFutureOrderSyncRequest request = new KBFutureOrderSyncRequest();
            request.tbsellcheck = orderData.sellCheckList;
            request.tbsellorderitem = orderData.sellOrderItemList;
            request.tbsellreceive = orderData.sellReceiveList;
            request.tbsellorder = orderData.sellOrderList;
            request.tbsell = orderData.sellList;
            request.thirdorderext = orderData.thirdorderext;
            request.thirdorderext.tableNo = kbTableNo;
            request.thirdorderext.kbStatus = kbStatus;
            if (TextUtils.isEmpty(kbTableNo)) {
                //根据配置处理桌号数据的回流
                String qrCodeType = ServerSettingHelper.getTableQrCodeType();
                request.thirdorderext.tableNo = TextUtils.equals(qrCodeType, META.VALUE_TABLE_QR_CODE_KB)
                        ? fsmtableid : fsmtablename;
            }
            LogUtil.logBusiness("OrderSyncThread", request.tbsell.get(0).fssellno + ":fiBillStatus=" + request.tbsell.get(0).fiBillStatus);
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    LogUtil.logBusiness("OrderSyncThread", "口碑orderId：" + request.tbsell.get(0).thirdOrderId + ", " + request.tbsell.get(0).fssellno + ":fiBillStatus=" + request.tbsell.get(0).fiBillStatus + ",同步成功");
                    listener.onCompleted();
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    listener.onError(responseData.resultMessage);
                    LogUtil.logBusiness("OrderSyncThread", "口碑orderId：" + request.tbsell.get(0).thirdOrderId + ", " + request.tbsell.get(0).fssellno + ":fiBillStatus=" + request.tbsell.get(0).fiBillStatus + ",同步失败");
                    return false;
                }
            }, false);
        } catch (Exception e) {
            e.printStackTrace();
            listener.onError(e.getMessage());
        }
    }

    public void setOnOrderSyncThreadListener(OnOrderSyncThreadListener listener) {
        this.listener = listener;
    }

    public interface OnOrderSyncThreadListener {
        void onCompleted();

        void onError(String errorMsg);
    }
}
