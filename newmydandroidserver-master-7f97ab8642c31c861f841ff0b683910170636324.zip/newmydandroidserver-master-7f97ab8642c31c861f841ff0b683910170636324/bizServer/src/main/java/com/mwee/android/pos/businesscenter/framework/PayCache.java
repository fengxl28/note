package com.mwee.android.pos.businesscenter.framework;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.mwee.android.pos.base.Cache;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPayConfig;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2017/6/19.
 */

public class PayCache extends Cache {
    private final static PayCache instance = new PayCache();

    /**
     * 可用的支付方式列表
     */
    public List<PayOriginModel> payTypeList = new ArrayList<>();

    public ArrayMap<String, PayOriginModel> payTypeMap = new ArrayMap<>();

    /*=========预置的一些Model==============*/

    /**
     * 支付方式免单
     */
    public PayOriginModel payTypeFree = null;
    /**
     * 支付方式减免
     */
    public PayOriginModel payTypeDiscount = null;
    /**
     * 销售券免找
     */
    public PayOriginModel payTypeCoupon = null;
    /**
     * 赠送券免找
     */
    public PayOriginModel payTypeCouponGiven = null;
    /**
     * 支付宝
     */
    public PayOriginModel payTypeAli = null;
    /**
     * 微信
     */
    public PayOriginModel payTypeWeixin = null;
    /**
     * 支付方式免减
     */
    public PayOriginModel payTypeDiscountFree = null;
    /**
     * 调账找零
     */
    public PayOriginModel payTypeForChange = null;
    /**
     * 美味储值
     */
    public PayOriginModel payTypeMemberBalance = null;
    /**
     * 美味积分
     */
    public PayOriginModel payTypeMemberPoint = null;

    /**
     * 人民币
     */
    public PayOriginModel payTypeRMB = null;
    /**
     * 银行卡
     */
    public PayOriginModel payTypeBankCard = null;

    private PayCache() {
    }

    public static PayCache getInstance() {
        return instance;
    }

    public static void initParam() {

        PayConfig.NEED_CHANGE = CommonDBUtil.getConfigWithDefault(DBPayConfig.PAY_NEED_CHANGE, "");
        PayConfig.PAY_COUPON_FREE = CommonDBUtil.getConfigWithDefault(DBPayConfig.PAY_COUPON_FREE, "");
        PayConfig.PAY_COUPON_GIVEN_FREE = CommonDBUtil.getConfigWithDefault(DBPayConfig.PAY_COUPON_GIVEN_FREE, "");

        PayConfig.PRINT_BILL_MARK = TextUtils.equals("1", CommonDBUtil.getConfigWithDefault(DBPayConfig.PRINT_BILL_MARK,"1"));
        PayConfig.PRINT_COMBINE_DISHES = TextUtils.equals("1", CommonDBUtil.getConfig(DBPayConfig.PRINT_COMBINE_DISHES));

        PayConfig.PAY_OPEN_BOX = TextUtils.equals("1", CommonDBUtil.getConfigWithDefault(DBPayConfig.OPEN_MONEY_BOX_AFTER_PAY, ""));
    }

    public static List<PaymentDBModel> getPayTypeList(boolean withHide) {
        /**
         * SELECT tbpayment.*,tbpaymenttype.fsPaymentTypeName FROM tbpayment left outer join tbpaymenttype on tbpayment.fsPaymentTypeId=tbpaymenttype.fsPaymentTypeId where tbpayment.fiStatus='1' and tbpaymenttype.fiStatus='1' and tbpaymenttype.fsPaymentTypeId  not in ('91','92','93') order by tbpayment.fiSortOrder asc,tbpayment.fsPaymentId asc
         */
        String sql = "SELECT " +
                "payment.*," +
                "paymenttype.fsPaymentTypeName " +
                "FROM tbpayment  as payment " +
                "left outer join tbpaymenttype paymenttype " +
                "on payment.fsPaymentTypeId=paymenttype.fsPaymentTypeId " +
                "where " +
                "paymenttype.fiStatus='1' " +
                "and paymenttype.fsPaymentTypeId not in ('30','31','32') " +
                "and payment.fiStatus='1' " +
                "and payment.fsPaymentTypeId not in ('30','31','32') " +
                (withHide ? "" : "and payment.fiIsPremium<>'1' ") +
//                "and ((datetime('now','localtime')>= fsStarDate and datetime('now','localtime')<=fsEndDate) or fiIsEffectiveDate=0) " +//支付方式时效---lxx 17-06-17 支付方式不再过滤时效
                "order by fiIsEffectiveDate asc, payment.fiSortOrder asc,payment.fsPaymentId asc";  //不生效的支付方式放后面  fiIsEffectiveDate asc,
        List<PaymentDBModel> dbList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymentDBModel.class);
        return dbList;
    }

    /**
     * 构建支付方式列表
     */
    private static void initTypeList() {
        PayCache cache = PayCache.getInstance();
        cache.payTypeList.clear();
        cache.payTypeDiscount = null;
        cache.payTypeFree = null;
        cache.payTypeAli = null;
        cache.payTypeWeixin = null;
        cache.payTypeCoupon = null;
        cache.payTypeCouponGiven = null;
        cache.payTypeMap.clear();

        List<PaymentDBModel> dbList = getPayTypeList(true);

        List<PayOriginModel> resultList = new ArrayList<>();
        for (PaymentDBModel temp : dbList) {
            PayOriginModel model = OrderUtil.buildPayOriginModel(temp);

            //特殊处理一些支付方式:
            //1,两种券需要合并显示
            //2,免单需要提取出来,不放在支付方式列表
            if (TextUtils.equals(temp.fsPaymentId, PayType.FREE)) {
                if (!model.checkForPremium()) {
                    cache.payTypeFree = model;
                }
            }
            if (!model.checkForPremium()
                    && !TextUtils.equals(PayType.CHANGE, temp.fsPaymentId)
                    && !TextUtils.equals(PayType.MW_MEMBER_POINT, temp.fsPaymentId)
                    && !TextUtils.equals(PayType.MW_MEMBER_BALANCE_GIFT, temp.fsPaymentId)
                    && !TextUtils.equals(PayType.MW_MEMBER_BALANCE, temp.fsPaymentId)) {
                resultList.add(model);
            }
            //隐藏的支付方式不显示
            if (!model.checkForPremium()) {
                cache.payTypeMap.put(temp.fsPaymentId, model);
            }
        }
        cache.payTypeList = resultList;

        cache.payTypeCoupon = cache.payTypeMap.get(PayConfig.PAY_COUPON_FREE);
        cache.payTypeCouponGiven = cache.payTypeMap.get(PayConfig.PAY_COUPON_GIVEN_FREE);
        cache.payTypeWeixin = cache.payTypeMap.get(PayType.WEIXIN);
        cache.payTypeAli = cache.payTypeMap.get(PayType.ALI);
        cache.payTypeDiscount = cache.payTypeMap.get(PayType.DIS);
        cache.payTypeDiscountFree = cache.payTypeMap.get(PayType.LESS);
        cache.payTypeForChange = cache.payTypeMap.get(PayType.CHANGE);
        cache.payTypeMemberBalance = cache.payTypeMap.get(PayType.MW_MEMBER_BALANCE);
        cache.payTypeMemberPoint = cache.payTypeMap.get(PayType.MW_MEMBER_POINT);
        cache.payTypeRMB = cache.payTypeMap.get(PayType.RMB);
        cache.payTypeBankCard = cache.payTypeMap.get(PayType.BANK_CARD);
    }

    @Override
    public void refresh() {
        initParam();
        initTypeList();
    }

    @Override
    public void clean() {

    }

    /**
     * 获取预付金默认的支付方式
     *
     * @return List<PayOriginModel> | 默认的支付方式(人民币、银行卡、微信支付、支付宝支付)
     */
    public List<PayOriginModel> getDefaultPayModelForPrePay() {
        // 2018/1/5 产品沟通，默认的支付方式写死，即使隐藏，也需要展示在页面
        List<PayOriginModel> result = new ArrayList<>();
        if (payTypeRMB == null) {
            payTypeRMB = getPayType(PayType.RMB);
        }
        result.add(payTypeRMB);
        if (payTypeBankCard == null) {
            payTypeBankCard = getPayType(PayType.BANK_CARD);
        }
        result.add(payTypeBankCard);
        if (payTypeWeixin == null) {
            payTypeWeixin = getPayType(PayType.WEIXIN);
        }
        result.add(payTypeWeixin);
        if (payTypeAli == null) {
            payTypeAli = getPayType(PayType.ALI);
        }
        result.add(payTypeAli);
        return result;
    }

    public static PayOriginModel getPayType(String fsPaymentId) {
        String sql = "SELECT " +
                "payment.*," +
                "paymenttype.fsPaymentTypeName " +
                "FROM tbpayment  as payment " +
                "left outer join tbpaymenttype paymenttype " +
                "on payment.fsPaymentTypeId=paymenttype.fsPaymentTypeId " +
                "where " +
                "payment.fsPaymentId = '" + fsPaymentId + "'";
        PaymentDBModel temp = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PaymentDBModel.class);
        return OrderUtil.buildPayOriginModel(temp);
    }
}
