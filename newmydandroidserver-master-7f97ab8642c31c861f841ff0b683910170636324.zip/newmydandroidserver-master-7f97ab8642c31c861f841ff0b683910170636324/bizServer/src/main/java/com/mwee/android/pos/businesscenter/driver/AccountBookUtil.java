package com.mwee.android.pos.businesscenter.driver;

import android.database.sqlite.SQLiteDatabase;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.BaseRequest;
import com.mwee.android.base.net.BaseResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.component.accountbook.net.CommitAccountBookBillRequest;
import com.mwee.android.pos.component.accountbook.net.GetAccountBookRequest;
import com.mwee.android.pos.component.accountbook.net.GetAccountBookResponse;
import com.mwee.android.pos.component.accountbook.net.GetBillUploadStateRequest;
import com.mwee.android.pos.component.accountbook.net.GetBillUploadStateResponse;
import com.mwee.android.pos.component.accountbook.net.NotifyCloudUploadRequest;
import com.mwee.android.pos.component.accountbook.net.UpdateAccountBookRequest;
import com.mwee.android.pos.component.accountbook.net.model.BillUploadStateModel;
import com.mwee.android.pos.component.datasync.net.GetABBillStateResponse;
import com.mwee.android.pos.component.iocache.CacheKey;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class AccountBookUtil {

    private static final String TAG = "AccountBookUtil";

    public static List<AccountBookDBModel> optAllAccountBook(boolean withA) {
        String sql = "SELECT * FROM bill_account_book WHERE status = '1' OR account_book_id='1' ORDER BY account_book_id";
        List<AccountBookDBModel> accountBookList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, AccountBookDBModel.class);

        if (ListUtil.isEmpty(accountBookList)) {
            return new ArrayList<>();
        }

        // 将A账套从列表中移除
        if (!withA) {
            for (int i = 0; i < accountBookList.size(); i++) {
                AccountBookDBModel temp = accountBookList.get(i);
                if (temp == null || TextUtils.equals("1", temp.accountBookId)) {
                    accountBookList.remove(i);
                    break;
                }
            }
        }

        for (AccountBookDBModel accountBook : accountBookList) {
            if (!TextUtils.isEmpty(accountBook.excludePayment)) {
                try {
                    accountBook.excludePaymentList = JSON.parseArray(accountBook.excludePayment, String.class);
                } catch (Exception e) {
                    accountBook.excludePaymentList = new ArrayList<>();
                }
            }
        }

        return accountBookList;
    }

    public static AccountBookDBModel optAccountBookById(String accountBookId) {
        if (TextUtils.isEmpty(accountBookId)) {
            return null;
        }

        String sql = "SELECT * FROM bill_account_book WHERE account_book_id='" + accountBookId + "' ";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, AccountBookDBModel.class);
    }

    public static String saveAccountBook(AccountBookDBModel accountBook, UserDBModel operUser) {
        LogUtil.logBusiness(TAG, "同步账套配置到云端，账套：" + JSON.toJSONString(accountBook) + "，操作人：" + JSON.toJSONString(operUser));
        String[] error = {""};
        commitAccountBookConfigToCloud(accountBook, new IResult() {
            @Override
            public void callBack(boolean result, String info) {
                if (result) {
                    // 更新到本地数据库
                    accountBook.excludePayment = JSON.toJSONString(accountBook.excludePaymentList);
                    accountBook.excludePaymentList = null;
                    accountBook.replaceNoTrans();
                } else {
                    error[0] = info;
                }
            }
        });

        return error[0];
    }

    public static List<String> processAccountBookAuto(String sellNo) {
        LogUtil.logBusiness(TAG, "[" + DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT) + "] 自动处理账套，sellNo=" + sellNo);

        String localConfig = DBMetaUtil.getConfig(META.SHOP_SERVICE_BILL_OPT, "").trim();
        List<AccountBookDBModel> accountBookList = optAllAccountBook(false);
        if (ListUtil.isEmpty(accountBookList) && TextUtils.isEmpty(localConfig)) {
            LogUtil.logBusiness(TAG, "账单优化配置为空，退出账套自动处理，sellNo=" + sellNo);
            return new ArrayList<>();
        }

        LogUtil.logBusiness(TAG, "要处理的账套数量：" + accountBookList.size() + "，sellNo=" + sellNo);
        String businessDate = HostUtil.getHistoryBusineeDate("");
        // 处理过的订单号，记录到新列表
        List<String> sellNoProcessed = new ArrayList<>();
        for (AccountBookDBModel accountBook : accountBookList) {
            if (accountBook == null) {
                continue;
            }
            LogUtil.logBusiness(TAG, "-----自动处理账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "] 开始-----");

            // 手动上传，不进行后台批处理
            if (accountBook.uploadType == 2) {
                LogUtil.logBusiness(TAG, "账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "]上传设置为手动上传，退出账套自动处理");
                continue;
            }
            // 非实时上传，且关闭自动筛选，不进行后台批处理
            if (accountBook.autoFilter == 0 && accountBook.uploadType != 3) {
                LogUtil.logBusiness(TAG, "账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "]上传设置为非实时上传且不自动筛选，退出账套自动处理");
                continue;
            }

            String exclude = "";
            StringBuilder paramPayment = new StringBuilder();
            if (!ListUtil.isEmpty(accountBook.excludePaymentList)) {
                for (int index = 0; index < accountBook.excludePaymentList.size(); index++) {
                    paramPayment.append("'");
                    paramPayment.append(accountBook.excludePaymentList.get(index));
                    paramPayment.append("'");
                    if (index < accountBook.excludePaymentList.size() - 1) {
                        paramPayment.append(", ");
                    }
                }
                exclude = " AND fsSellNo NOT IN (SELECT fsSellNo FROM tbsellreceive WHERE fsPaymentId IN (" + paramPayment.toString() + ") AND fiStatus='1')";
            }

            String sqlTotalNum = "SELECT count(*) AS count FROM tbSell WHERE fiBillStatus = '3' AND fsSellDate = '" + businessDate + "'" + exclude;
            int totalNum = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlTotalNum, "count", Integer.class);
            LogUtil.log("自动批处理筛选账单，不包含排除支付方式的账单总数：\nSQL：" + sqlTotalNum + "，\n总数，" + totalNum);

            // 当前符合条件的属于X账套的账单数量
            String sqlHasNum = "SELECT count(*) AS count FROM tbSell WHERE fiBillStatus = '3' AND fsSellDate = '" + businessDate + "'" + exclude + " AND fsAccountBook LIKE '%," + accountBook.accountBookId + ",%' ";
            int hasNum = DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlHasNum, "count", Integer.class);
            LogUtil.log("自动批处理筛选账单，当前显示的账单数量：\nSQL：" + sqlHasNum + "，\n总数：" + hasNum);

            // 需要添加到X账套的账单数量 limit = (totalNum * percent / 100) - hasNum 取整
            int limit = totalNum * accountBook.dataPercent / 100 - hasNum;
            LogUtil.log("自动批处理筛选账单，需要添加到账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "]的账单数量：" + limit);

            if (limit <= 0) {
                LogUtil.logBusiness("自动批处理筛选账单，需要隐藏的数量小于0，退出账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "]自动处理");
                continue;
            }

            // 要处理的订单
            List<String> newSellNoList;
            if (TextUtils.isEmpty(sellNo)) {
                // 随机抽取limit个订单
                newSellNoList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "SELECT fsSellNo FROM tbSell WHERE fsSellDate = '" + businessDate + "'" + exclude + " AND fiBillStatus = 3 AND fsAccountBook NOT LIKE '%," + accountBook.accountBookId + ",%' ORDER BY random() LIMIT " + limit);
            } else {
                // 指定订单，校验下支付方式
                List<String> checkSellNo = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "SELECT fsSellNo FROM tbSell WHERE fsSellDate = '" + businessDate + "' " + " AND fsSellNo='" + sellNo + "' " + exclude);
                if (!ListUtil.isEmpty(checkSellNo) && checkSellNo.contains(sellNo)) {
                    newSellNoList = new ArrayList<>();
                    newSellNoList.add(sellNo);
                } else {
                    LogUtil.log("自动批处理筛选账单，订单[" + sellNo + "]支付方式校验不通过，退出账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "]自动处理");
                    continue;
                }
            }

            String finalExclude = exclude;
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate() {
                @Override
                public Object doJob(SQLiteDatabase db) {

                    // 1 为含有排除的支付方式的订单取消X账套，order_cache和tbSell都要改；
                    String sqlCachePayExclude = "UPDATE order_cache SET fsAccountBook = replace(fsAccountBook, '," + accountBook.accountBookId + ",', '') " +
                            " WHERE order_status = 3 AND business_date = '" + businessDate + "' " +
                            " AND order_id IN (SELECT fsSellNo FROM tbSellReceive WHERE fsPaymentId IN (" + paramPayment.toString() + ") AND fiStatus='1') " +
                            " AND fsAccountBook LIKE '%," + accountBook.accountBookId + ",%'";
                    String sqlSellPayExclude = "UPDATE tbSell SET fsAccountBook = replace(fsAccountBook, '," + accountBook.accountBookId + ",', ''), lver = lver + 1 " +
                            " WHERE fiBillStatus = 3 AND fsSellDate = '" + businessDate + "' " +
                            " AND fsSellNo IN (SELECT fsSellNo FROM tbSellReceive WHERE fsPaymentId IN (" + paramPayment.toString() + ") AND fiStatus='1') " +
                            " AND fsAccountBook LIKE '%," + accountBook.accountBookId + ",%'";
                    db.execSQL(sqlCachePayExclude);
                    db.execSQL(sqlSellPayExclude);
                    LogUtil.log("自动批处理筛选账单，为含有排除的支付方式的订单取消X账套，SQL-order_cache：" + sqlCachePayExclude + "，SQL-tbSell：" + sqlSellPayExclude);

                    // 2 修改对应订单 order_cache:fsAccountBook；
                    LogUtil.log("自动批处理筛选账单，即将修改以下订单账套：" + newSellNoList);
                    if (!ListUtil.isEmpty(newSellNoList)) {
                        StringBuilder sellNoParamBuilder = new StringBuilder();
                        for (String sellNo : newSellNoList) {
                            sellNoParamBuilder.append("'").append(sellNo).append("',");
                        }
                        sellNoParamBuilder.deleteCharAt(sellNoParamBuilder.length() - 1);
                        String sellNoParam = sellNoParamBuilder.toString();

                        String sqlCacheUpdate = "UPDATE order_cache SET fsAccountBook = CASE WHEN fsAccountBook is null THEN '," + accountBook.accountBookId + ",' WHEN fsAccountBook LIKE '%," + accountBook.accountBookId + ",%' THEN fsAccountBook ELSE fsAccountBook||'," + accountBook.accountBookId + ",' END WHERE order_id IN (" + sellNoParam + ") ";
                        // 3 修改对应订单 tbSell:fsAccountBook，保证两表状态一致；
                        String sqlSellUpdate = "UPDATE tbSell SET fsAccountBook = CASE WHEN fsAccountBook is null THEN '," + accountBook.accountBookId + ",' WHEN fsAccountBook LIKE '%," + accountBook.accountBookId + ",%' THEN fsAccountBook ELSE fsAccountBook||'," + accountBook.accountBookId + ",' END, lver = lver + 1 WHERE fsSellNo IN (" + sellNoParam + ") " + finalExclude;

                        db.execSQL(sqlCacheUpdate);
                        db.execSQL(sqlSellUpdate);
                        LogUtil.log("自动批处理筛选账单，修改订单账套，SQL-order_cache：" + sqlCacheUpdate + "，SQL-tbSell：" + sqlSellUpdate);

                        sellNoProcessed.addAll(newSellNoList);
                    }

                    return null;
                }
            });
            LogUtil.logBusiness(TAG, "-----自动处理账套[" + accountBook.accountBookName + "," + accountBook.accountBookId + "] 结束-----");
        }

        // 整理处理过的订单，去掉重复的
        if (!ListUtil.isEmpty(sellNoProcessed)) {
            HashSet<String> sellNoSet = new HashSet<>(sellNoProcessed);
            return new ArrayList<>(sellNoSet);
        }
        return new ArrayList<>();
    }

    /**
     * 获取账套信息
     */
    public static void loadAccountBookFromCloud(boolean async) {
        GetAccountBookRequest request = new GetAccountBookRequest();
        ShopDBModel shopInfo = HostUtil.getShopInfo();
        if (shopInfo != null) {
            request.shopGUID = shopInfo.fsShopGUID;
            request.shopName = shopInfo.fsShopName;
            request.manageShopGUID = shopInfo.fsCompanyGUID;
            request.shopKind = shopInfo.fiShopKind;
        }
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "获取账套配置成功：" + JSON.toJSONString(responseData));
                if (responseData == null) {
//                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return;
                }
                if (responseData.responseBean != null && responseData.responseBean instanceof GetAccountBookResponse) {
                    GetAccountBookResponse response = (GetAccountBookResponse) responseData.responseBean;

                    // 写到表里
                    if (!ListUtil.isEmpty(response.data)) {
                        for (AccountBookDBModel accountBook : response.data) {
                            accountBook.replaceNoTrans();
                        }
                    }
                } else {
//                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "获取账套配置失败：" + JSON.toJSONString(responseData));
                if (responseData == null) {
//                    callback.callBack(false, ERROR_CODE, ERROR_MSG, null);
                    return false;
                }
//                callback.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, async);
    }

    /**
     * 提交账套配置
     *
     * @param accountBook 账套配置
     */
    public static void commitAccountBookConfigToCloud(AccountBookDBModel accountBook, IResult callback) {
        if (accountBook == null) {
            return;
        }
        UpdateAccountBookRequest request = new UpdateAccountBookRequest();
        ShopDBModel shopInfo = HostUtil.getShopInfo();
        if (shopInfo != null) {
            request.shopGUID = shopInfo.fsShopGUID;
            request.shopName = shopInfo.fsShopName;
            request.manageShopGUID = shopInfo.fsCompanyGUID;
            request.shopKind = shopInfo.fiShopKind;
        }
        AccountBookDBModel model = new AccountBookDBModel();
        model.accountBookId = accountBook.accountBookId;
        model.accountBookName = accountBook.accountBookName;
        model.uploadType = accountBook.uploadType;
        model.uploadTime = accountBook.uploadTime;
        model.businessType = accountBook.businessType;
        model.dataPercent = accountBook.dataPercent;
        model.uploadRepeat = accountBook.uploadRepeat;
        model.interfaceMid = accountBook.interfaceMid;
        request.billSetVO = model;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "提交账套配置成功");
                if (callback != null) {
                    callback.callBack(true, "");
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "提交账套配置失败：" + JSON.toJSONString(responseData));
                if (responseData == null) {
                    if (callback != null) {
                        callback.callBack(false, "提交账套配置失败");
                    }
                    return false;
                }
                if (callback != null) {
                    callback.callBack(false, responseData.resultMessage);
                }
                return false;
            }
        }, false);
    }

    /**
     * 提交订单-账套映射关系---指定账套
     *
     * @param accountBookId
     * @param businessDate
     */
    public static void commitAccountBookBillWithNotify(String accountBookId, String businessDate, IResult callback) {
        LogUtil.logBusiness(TAG, "开始提交账套-订单关系，accountBookId=" + accountBookId + "，businessDate=" + businessDate);
        AccountBookDBModel accountBook = optAccountBookById(accountBookId);
        if (accountBook == null) {
            LogUtil.logBusiness(TAG, "提交账套-订单关系 失败，未找到有效账套，accountBookId=" + accountBookId + "，businessDate=" + businessDate);
            return;
        }
        String sql = "SELECT fsSellNo FROM tbSell WHERE fsAccountBook like '%," + accountBookId + ",%' AND fsSellDate = '" + businessDate + "' AND fiBillStatus='3' ";
        List<String> sellNoList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (ListUtil.isEmpty(sellNoList)) {
            LogUtil.logBusiness(TAG, "提交账套-订单关系，未找到有效订单，accountBookId=" + accountBookId + "，businessDate=" + businessDate);
        }

        final String[] errorMsg = {""};
        if (!ListUtil.isEmpty(sellNoList)) {
            // 提交订单-账套映射关系---提交该账套下全部订单
            CommitAccountBookBillRequest request = new CommitAccountBookBillRequest();
            request.accountBookId = accountBook.accountBookId;
            request.accountBookName = accountBook.accountBookName;
            request.shopGuid = HostUtil.getShopID();
            request.sellDate = businessDate;
            request.sellNos = sellNoList;
            BusinessExecutor.execute(request, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    LogUtil.logBusiness(TAG, "提交账套-订单关系成功，accountBookId=" + accountBookId);
                    BaseResponse response = responseData.responseBean;
                    if (response != null) {
                        if (response.errno != SocketResultCode.SUCCESS) {
                            errorMsg[0] = response.errmsg;
                        }
                    } else {
                        errorMsg[0] = "提交账套-订单关系失败";
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    LogUtil.logBusiness(TAG, "提交账套-订单关系失败，accountBookId=" + accountBookId + "：" + JSON.toJSONString(responseData));
                    if (responseData == null) {
                        errorMsg[0] = "提交账套-订单关系失败";
                        return false;
                    }
                    errorMsg[0] = responseData.resultMessage;
                    return false;
                }
            }, false);
        }

        if (!TextUtils.isEmpty(errorMsg[0])) {
            if (callback != null) {
                callback.callBack(false, errorMsg[0]);
            }
            return;
        }

        LogUtil.logBusiness(TAG, "提交账套-订单关系，通知云端上传到商场，accountBookId=" + accountBookId + "，businessDate=" + businessDate);
        errorMsg[0] = notifyCloudUpload(accountBookId, businessDate);
        if (TextUtils.isEmpty(errorMsg[0])) {
            if (callback != null) {
                callback.callBack(true, "");
            }
            saveBillUploadState(businessDate, accountBookId, 0, false);
        } else {
            if (callback != null) {
                callback.callBack(false, errorMsg[0]);
            }
        }
    }

    /**
     * 提交订单-账套映射关系---指定订单
     *
     * @param sellNoList
     */
    public static void commitAccountBookBill(List<String> sellNoList) {
        StringBuilder sellNoParams = new StringBuilder();
        for (String sellNo : sellNoList) {
            if (TextUtils.isEmpty(sellNo)) {
                continue;
            }
            sellNoParams.append("'").append(sellNo).append("'").append(",");
        }
        if (sellNoParams.length() < 1) {
            return;
        }
        sellNoParams.deleteCharAt(sellNoParams.length() - 1);
        String sql = "SELECT fsSellNo,fsAccountBook,fsSellDate FROM tbSell WHERE fsSellNo IN (" + sellNoParams.toString() + ") AND fiBillStatus='3' ";
        List<JSONObject> jsonList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
        if (ListUtil.isEmpty(jsonList)) {
            return;
        }
        String shopGUID = HostUtil.getShopID();
        ArrayMap<String, CommitAccountBookBillRequest> requestMap = new ArrayMap<>();
        for (JSONObject jo : jsonList) {
            String fsAccountBook = jo.getString("fsAccountBook");
            if (TextUtils.isEmpty(fsAccountBook)) {
                continue;
            }
            String[] split = fsAccountBook.split(",");
            if (split == null || split.length == 0) {
                continue;
            }
            String fsSellNo = jo.getString("fsSellNo");
            String fsSellDate = jo.getString("fsSellDate");
            for (String accountBookId : split) {
                if (TextUtils.isEmpty(accountBookId)) {
                    continue;
                }
                CommitAccountBookBillRequest request = requestMap.get(accountBookId);
                if (request == null) {
                    request = new CommitAccountBookBillRequest();
                    request.shopGuid = shopGUID;
                    request.accountBookId = accountBookId;
                    AccountBookDBModel accountBook = optAccountBookById(accountBookId);
                    if (accountBook != null) {
                        request.accountBookName = accountBook.accountBookName;
                    }
                    request.sellDate = fsSellDate;
                }
                if (request.sellNos == null) {
                    request.sellNos = new ArrayList<>();
                }
                request.sellNos.add(fsSellNo);
                requestMap.put(accountBookId, request);
            }
        }

        List<BaseRequest> requests = new ArrayList<>(requestMap.values());
        if (ListUtil.isEmpty(requests)) {
            return;
        }

        BusinessExecutor.execute(requests, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "提交账套-订单关系成功");
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "提交账套-订单关系失败");
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
    }

    /**
     * 通知云端上传订单到商场
     *
     * @param businessDate
     */
    public static String notifyCloudUpload(String accountBookId, String businessDate) {
        if (TextUtils.isEmpty(accountBookId)) {
            return "账套Id为空";
        }
        AccountBookDBModel accountBook = optAccountBookById(accountBookId);
        if (accountBook == null) {
            return "未找到有效账套";
        }
        final String[] error = {""};
        NotifyCloudUploadRequest request = new NotifyCloudUploadRequest();
        request.accountBookId = accountBookId;
        request.interfaceManagerId = accountBook.interfaceMid;
        request.sellDate = businessDate;
        request.shopGuid = HostUtil.getShopID();
        request.asyncUpload = false;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "通知云端上传成功");
                BaseResponse response = responseData.responseBean;
                if (response != null) {
                    if (response.errno != SocketResultCode.SUCCESS) {
                        error[0] = response.errmsg;
                    }
                } else {
                    error[0] = "通知云端上传失败";
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                LogUtil.logBusiness(TAG, "通知云端上传失败：" + JSON.toJSONString(responseData));
                if (responseData == null) {
                    error[0] = "通知云端上传失败";
                } else {
                    error[0] = responseData.resultMessage;
                }
                return false;
            }
        }, false);
        return error[0];
    }

    /**
     * 获取云端上传订单到商场的状态
     * 原方法：see{@link BillUtil#syncBillUploadState(String)}
     *
     * @param businessDate 营业日期
     * @return int | -1,同步失败; 0,全部上传完成; 1,部分未上传成功; 2,未上传
     */
    public static void loadBillUploadStatus(String businessDate) {
        if (TextUtils.isEmpty(businessDate)) {
            LogUtil.logBusiness(TAG, "获取云端上传订单到商场的状态：营业日期为空");
            return;
        }
        GetBillUploadStateRequest request = new GetBillUploadStateRequest();
        request.shopGuid = HostUtil.getShopID();
        request.sellDate = businessDate;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof GetBillUploadStateResponse) {
                    GetBillUploadStateResponse responseBean = (GetBillUploadStateResponse) responseData.responseBean;
                    if (!ListUtil.isEmpty(responseBean.data)) {
                        for (BillUploadStateModel model : responseBean.data) {
                            saveBillUploadState(businessDate, model.accountBookId, model.state, true);
                        }
                    }
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
    }

    /**
     * 保存账单上传状态
     * 原方法：see{@link BillUtil#saveBillUploadState(String, int, boolean)}
     *
     * @param date          营业日期
     * @param accountBookId 账套id
     * @param status        上传状态
     * @param writeStatus   是否写入状态，只有通过接口拿到状态后才写入状态
     */
    public static void saveBillUploadState(String date, String accountBookId, int status, boolean writeStatus) {
        CacheModel cache = new CacheModel();
        cache.type = 0;
        cache.key = CacheKey.BILL_UPLOAD_DATE_STATUS + date + "_" + accountBookId;
        cache.info = statisticExpAmtByAccountBook(date, accountBookId).toPlainString();
        cache.biz_key = date;
        cache.createtime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        cache.updatetime = cache.createtime;
        if (writeStatus) {
            cache.value = String.valueOf(status);
        }
        cache.replaceNoTrans();
    }

    /**
     * 根据营业日期统计应收金额
     * 1. 已结账的账单
     * 2. 指定账套下显示的账单
     * 原方法：see{@link BillUtil#statisticExpAmt(String)}
     *
     * @param businessDate 营业日期
     * @return fdExpAmt
     */
    public static BigDecimal statisticExpAmtByAccountBook(String businessDate, String accountBookId) {
        String sqlAmt = "SELECT sum(fdExpAmt) AS amt FROM tbsell WHERE fsSellDate = '" + businessDate + "' " +
                " AND fiBillStatus = 3 AND fsAccountBook like '%," + accountBookId + ",%' ";
        return DBSimpleUtil.queryInfo(APPConfig.DB_MAIN, sqlAmt, "amt", BigDecimal.class);
    }

    /**
     * 查询账单上传操作日志
     *
     * @return 上传状态数据列表
     */
    public static List<CacheModel> queryBillOptLog(String accountBookId) {
        String sql = "SELECT * FROM datacache WHERE key LIKE '" + CacheKey.BILL_UPLOAD_DATE_STATUS + "%_" + accountBookId + "' ORDER BY key DESC";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, CacheModel.class);
    }
}
