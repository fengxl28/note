package com.mwee.android.pos.businesscenter.business.netOrder;

import com.mwee.android.base.net.ResponseData;
import com.mwee.android.pos.business.netorder.NetOrder;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.SourceType;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.businesscenter.print.PrintNetOrderUtil;
import com.mwee.android.pos.component.datasync.net.GetAllNetOrderResponse;
import com.mwee.android.pos.component.datasync.net.GetNetOrderByIdResponse;
import com.mwee.android.pos.component.datasync.net.model.GetAllNetOrderDataModel;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrderDetail;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/3/27.
 */

public class NetOrderProcess {

    /**
     * 解析获取所有网络订单
     *
     * @param responseData
     * @return -1：解析异常
     * 0：没有新数据
     * 1：解析成功
     */
    public static int parseGetAllNetworkData(ResponseData responseData) {
        if (responseData.responseBean != null) {
            try {
                if (responseData.responseBean instanceof GetAllNetOrderResponse) {
                    GetAllNetOrderResponse getDataResponse = (GetAllNetOrderResponse) responseData.responseBean;
                    GetAllNetOrderDataModel model = getDataResponse.data;
                    List<TempAppOrder> orders = model.orderList;
                    int result = -1;
                    if (orders != null && orders.size() > 0) {
                        for (TempAppOrder tempAppOrder : orders) {
                            result = writeTempappOrder(tempAppOrder);
                            if (tempAppOrder.newOrder(tempAppOrder.orderStatus + "") && result == 1) {
                                NetOrderApi.autoGetNetOrder(String.valueOf(tempAppOrder.orderId), 0);
                            } else if (tempAppOrder.hasGetStatus() && PrintConfig.NET_ORDER_THIRD_PLARM_AUTO_GET_PRINT.equals("1") && result == 1) {
                                String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
                                PrintNetOrderUtil.printNetworkTackOutReceipt(tempAppOrder, hostId, "补单", true);
                                PrintNetOrderUtil.printNetworkCustomerReceipt(tempAppOrder, hostId, "补单", true);
                                PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, hostId, "补单", true);
                            } else if (tempAppOrder.cancelStatus()) {
                                String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
                                PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, hostId, "订单已取消", false);
                            }
                        }
                        return 1;
                    }
                    return 0;
                }
            } catch (Exception e) {
                LogUtil.logError("批量轮询外卖订单解析异常：", e);
                return -1;
            }
        }
        return -1;
    }

    /**
     * 解析单条网络订单
     *
     * @param responseData
     * @return -1：解析异常
     * -3：不接入的订单
     * 1：解析成功
     */
    public static int parseNetworkData(ResponseData responseData) {
        if (responseData.responseBean != null) {
            try {
                if (responseData.responseBean instanceof GetNetOrderByIdResponse) {
                    GetNetOrderByIdResponse getDataResponse = (GetNetOrderByIdResponse) responseData.responseBean;
                    TempAppOrder tempAppOrder = getDataResponse.data;
                    int result = writeTempappOrder(tempAppOrder);
                    String hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
                    if (tempAppOrder.hasGetStatus() && PrintConfig.NET_ORDER_THIRD_PLARM_AUTO_GET_PRINT.equals("1") && result == 1) {
                        PrintNetOrderUtil.printNetworkTackOutReceipt(tempAppOrder, hostId, "补单", true);
                        PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, hostId, "补单", true);
                        PrintNetOrderUtil.printNetworkCustomerReceipt(tempAppOrder, hostId, "补单", true);
                    } else if (tempAppOrder.cancelStatus()) {
                        PrintNetOrderUtil.printNetworkKDSReceipt(tempAppOrder, hostId, "订单已取消", false);
                    }
                    return result;
                }
            } catch (Exception e) {
                LogUtil.logError("根据订单号拉取网络订单异常:", e);
                RunTimeLog.addLog(RunTimeLog.NETORDER, "根据订单号拉取网络订单异常", e.getMessage());
                return -1;
            }
        }
        return -1;
    }

    public static int writeTempappOrder(TempAppOrder tempAppOrder) {
        if (tempAppOrder != null) {
            if (isRapidFastFoodOrder(tempAppOrder.bizType, tempAppOrder.sourceType)) {
                RapidPrePayFastfoodBiz.turnRapidFastfoodOrder(tempAppOrder);
                return -3;
            }
            if (!hasUsefulOrder(tempAppOrder.bizType)) {
                return -3;
            }
            RunTimeLog.addLog(RunTimeLog.NETORDER, "订单准备入库：" + tempAppOrder.orderId + "，" + tempAppOrder.bizType);
            return parseTempAppOrder(tempAppOrder);
        }
        return -1;
    }

    /**
     * 订单入库
     *
     * @param tempAppOrder
     * @return
     */
    private static int parseTempAppOrder(TempAppOrder tempAppOrder) {
        if (tempAppOrder == null) {
            return -1;
        }
        try {
            synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(tempAppOrder.orderId))) {
                DBSimpleUtil.excuteSql(APPConfig.DB_NET_ORDER, "delete from tempapporder where orderId = '" + tempAppOrder.orderId + "'");

                List<TempAppOrderDetail> orderDetailList = new ArrayList<>();
                orderDetailList.addAll(tempAppOrder.orderDetailList);
                NetOrder.saveTempAppOrder(tempAppOrder);
                tempAppOrder.orderDetailList.clear();
                tempAppOrder.orderDetailList.addAll(orderDetailList);
                ThirdOrderTurnToLocalReportProcess.dealThirdOrder(tempAppOrder);
            }
        } catch (Exception e) {
            e.printStackTrace();
            RunTimeLog.addLog(RunTimeLog.NETORDER, "订单入库异常 tempAppOrder.orderId = " + tempAppOrder.orderId, "", e);
            return -1;
        }
        return 1;
    }


    /**
     * 判断是否接入该订单
     * 不接入的订单不入库
     *
     * @param bizType
     * @return 0：点菜， 4：外卖, 6：取餐盒, 16热餐配送, 17冷餐配送，
     */
    public static boolean hasUsefulOrder(int bizType) {
        switch (bizType) {
            case 0:
            case 4:
            case 6:
            case 16:
            case 17:
                return true;
            default:
                return false;
        }
    }

    /**
     * 秒点快餐单
     *
     * @param bizType
     * @param sourceType
     * @return
     */
    public static boolean isRapidFastFoodOrder(int bizType, int sourceType) {
        if (NetOrderType.isRapidPrePay(bizType) && SourceType.isPrePayFastfoodModel(sourceType)) {
            return true;
        }
        return false;
    }


}
