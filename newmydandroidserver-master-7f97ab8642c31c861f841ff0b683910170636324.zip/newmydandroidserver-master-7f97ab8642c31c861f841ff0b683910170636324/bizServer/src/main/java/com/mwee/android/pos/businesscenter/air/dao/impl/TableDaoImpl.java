package com.mwee.android.pos.businesscenter.air.dao.impl;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.air.dao.ITableDao;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MtableDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * tbmtable表数据服务实现
 * Created by qinwei on 2018/8/17.
 */

public class TableDaoImpl implements ITableDao {
    @Override
    public MtableDBModel queryById(String id) {
        String sql = "select * from tbmtable where fsmtableid='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    @Override
    public MtableDBModel queryByMTableName(String mTableName) {
        String sql = "select * from tbmtable where fsmtablename='" + mTableName + "' AND fiStatus=1";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MtableDBModel.class);
    }

    @Override
    public MtableDBModel queryByIdOrMTableName(String table) {
        MtableDBModel mtableDBModel = queryById(table);
        if (mtableDBModel == null || mtableDBModel.fistatus != 1) {
            //先根据id找，找不到在根据名称找
            mtableDBModel = queryByMTableName(table);
        }
        return mtableDBModel;
    }

    @Override
    public ArrayList<MtableDBModel> queryByTableNo(String table_no) {
        String sql = "select * from tbmtable where (fsmtablename='" + table_no + "' or fsmtableid='" + table_no + "') and fiStatus=1";
        List<MtableDBModel> mtableDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        if (mtableDBModels == null) {
            return new ArrayList<>();
        }
        return (ArrayList<MtableDBModel>) mtableDBModels;
    }

    @Override
    public MtableDBModel queryByTableNoAndTableQRConfig(String table_no) {
        String qr_code_type = ServerSettingHelper.getTableQrCodeType();
        if (TextUtils.equals(qr_code_type, META.VALUE_TABLE_QR_CODE_MW)) {
            //美味码走桌台名
            return queryByMTableName(table_no);
        } else {
            //口碑码走桌台名称
            return queryById(table_no);
        }
    }

    @Override
    public ArrayList<MtableDBModel> queryAll() {
        String sql = "select * from tbmtable";
        List<MtableDBModel> list = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MtableDBModel.class);
        return (ArrayList<MtableDBModel>) list;
    }

    @Override
    public long update(MtableDBModel mtableDBModel) {
        mtableDBModel.replaceNoTrans();
        return 0;
    }

    @Override
    public long delete(String id) {
        MtableDBModel mtableDBModel = queryById(id);
        mtableDBModel.delete();
        return 1;
    }

    @Override
    public ArrayList<MtableDBModel> queryShareTablesByMainTableId(String tableId) {
        List<MtableDBModel> list = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fshint = '" + tableId + "'",
                MtableDBModel.class);
        return (ArrayList<MtableDBModel>) list;
    }


    @Override
    public MtableDBModel insertShareTable(MtableDBModel mtableDBModel, UserDBModel userDBModel) {
        List<MtableDBModel> mtableDBModels = queryShareTablesByMainTableId(mtableDBModel.fsmtableid);
        List<String> mTableIds = new ArrayList<>();
        if (!ListUtil.isEmpty(mtableDBModels)) {
            for (MtableDBModel dbModel : mtableDBModels) {
                mTableIds.add(dbModel.fsmtableid);
            }
        }
        int key = generateKey(1, mtableDBModel.fsmtableid, mTableIds);

        MtableDBModel shareTable = mtableDBModel.clone();
        shareTable.fsmtablename = shareTable.fsmtablename + "+" + key;
        shareTable.fsmtableid = mtableDBModel.fsmtableid + "_" + key;
        shareTable.fshint = mtableDBModel.fsmtableid;
        shareTable.fistatus = 2;
        shareTable.fsupdatetime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        shareTable.fsupdateuserid = userDBModel.fsUserId;
        shareTable.fsupdateusername = userDBModel.fsUserName;
        shareTable.replaceNoTrans();
        return shareTable;
    }

    /**
     * 获取拼桌的后缀名称
     *
     * @param mainTableId
     * @param index
     * @param fsmtableid
     * @return
     */
    private int generateKey(int index, String mainTableId, List<String> fsmtableid) {
        if (fsmtableid.contains(mainTableId + "_" + index)) {
            index++;
            return generateKey(index, mainTableId, fsmtableid);
        }
        return index;
    }
}
