package com.mwee.android.pos.businesscenter.business.koubei;

import android.text.TextUtils;

import com.mwee.android.air.db.business.kbbean.KBPartRefundReturnResponse;
import com.mwee.android.air.db.business.kbbean.KPreAllocationTableRequest;
import com.mwee.android.air.db.business.kbbean.KPreTempDataRequest;
import com.mwee.android.air.db.business.kbbean.KPreTempDataResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBOrderRefund;
import com.mwee.android.air.db.business.kbbean.bean.KBOrderRefundModel;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateRequest;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataRequest;
import com.mwee.android.pos.base.Constants;
import com.mwee.android.pos.businesscenter.koubei.PreOrderCallback;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.UUID;

/**
 * Created by zhangmin on 2018/5/17.
 */

public class KBPreOrderApi implements IKBPreOrderListener {
    @Override
    public void loadOrderList(int pageNo, String searchParam, int queryType, String status, BusinessCallback businessCallback) {
        KPreTempDataRequest request = new KPreTempDataRequest();
        request.pageNo = pageNo;
        request.searchParam = searchParam;
        //request.payStatus = payStatus;
        request.queryType = queryType;
        request.status = status;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
    }

    @Override
    public void loadOrder(String order_Id, String merchantPid, BusinessCallback businessCallback) {

        KPreOrderDataRequest request = new KPreOrderDataRequest();
        request.order_id = order_Id;
        request.merchantPid = merchantPid;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);

    }

    /**
     * 接单
     *
     * @param order_id         口碑端自己的订单号
     * @param businessType     取餐类型(action==RECEIPT，DINNER-正餐、SNACK-快餐)
     * @param orderStyle       点餐方式(action==RECEIPT，LATFORM——线上点，SCAN——扫码点)
     * @param merchantId       口碑商户id
     * @param tableNo          取餐号
     * @param businessCallback
     */
    @Override
    public void acceptOrder(String order_id, String businessType, String orderStyle, String merchantId, String tableNo, BusinessCallback businessCallback) {
        int queueNumTemp = KBPreOrderDBUtils.unCheckoutAndPrepareNum();
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        //新增接单来源字段
        if (APPConfig.isMyd()) {
            request.sourceType = KBPreOrderUpdateRequest.SourceType.MYD;
        } else {
            request.sourceType = KBPreOrderUpdateRequest.SourceType.MXY;
        }
        request.order_id = order_id;
        request.action = "RECEIPT";//接单
        request.orderStyle = orderStyle;
        request.merchantPid = merchantId;
        request.businessType = businessType;
        request.tableNo = tableNo;
        request.dvType = "DESKTOP_POS";
        //查询口碑当前【备餐中】状态的订单数量 and 本地order_cache未结账订单数量；
        request.queueNum = queueNumTemp;
        request.dvSn = ServerHardwareUtil.getHardWareSymbol();
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                businessCallback.success(responseData.result, responseData);
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return businessCallback.fail(responseData.result, responseData);
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                return false;
            }
        }, false);
    }

    /**
     * 拒单
     *
     * @param order_id
     * @param merchantId
     * @param no
     * @param reason
     * @param businessCallback
     */
    @Override
    public void rejectOrder(String order_id, String merchantId, String no, String reason, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.action = "REJECT";//拒单
        request.merchantPid = merchantId;
        request.reason = Constants.getRejectCode(reason);
        request.tableNo = no;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
    }


    /**
     * 备餐
     *
     * @param order_id
     * @param businessType
     * @param merchantId
     * @param no
     * @param businessCallback
     */
    @Override
    public void prepareOrder(String order_id, String businessType, String merchantId, String no, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.action = "PREPARE";//
        request.merchantPid = merchantId;
        request.tableNo = no;
        request.businessType = businessType;
        request.fsSellNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
    }


    /**
     * 退款
     *
     * @param order_id         口碑订单号
     * @param fsSellNo         美味订单号
     * @param merchantId
     * @param no
     * @param reason
     * @param userDBModel
     * @param businessCallback
     */
    @Override
    public void refundOrder(String order_id, String fsSellNo, String merchantId, String no, String reason, UserDBModel userDBModel, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.merchantPid = merchantId;
        request.tableNo = no;
        request.reason = reason;
        KBOrderRefund orderRefund = new KBOrderRefund();
        //根据口碑订单号查询美味订单号
        String mwSellNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
        //本地有订单号用本地美味订单号 如果本地美味订单号为null[清除数据了] 用后台返回的美味订单号为准
        orderRefund.fsSellNo = !TextUtils.isEmpty(mwSellNo) ? mwSellNo : fsSellNo;
        orderRefund.fsRefundType = 0;
        orderRefund.fsOperator = userDBModel.fsUserName;
        orderRefund.fsauthorizer = userDBModel.fsUserName;
        orderRefund.fsRefundTime = DateUtil.getCurrentTime();
        request.action = "REFUND";//退款（整单退款）
        request.kbOrderRefund = orderRefund;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                //todo 存储口碑退款记录
                KBOrderRefundModel model = new KBOrderRefundModel();
                model.fsSellNo = orderRefund.fsSellNo;
                model.fsRefundType = orderRefund.fsRefundType;
                model.fsOperator = orderRefund.fsOperator;
                model.fsAuthorizer = orderRefund.fsauthorizer;
                model.fsRefundTime = orderRefund.fsRefundTime;
                model.replaceNoTrans();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);

    }

    /**
     * 部分退款
     *
     * @param order_id     口碑订单号
     * @param fsSellNo     美味订单号
     * @param merchantId
     * @param no
     * @param reason
     * @param refundAmount 退款金额
     * @param userDBModel
     * @param callback
     */
    @Override
    public void partRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String reason, final String refundAmount, UserDBModel userDBModel, PreOrderCallback<KBPartRefundReturnResponse> callback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.merchantPid = merchantId;
        request.tableNo = no;
        request.reason = reason;
        KBOrderRefund orderRefund = new KBOrderRefund();
        //根据口碑订单号查询美味订单号
        String mwSellNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
        //本地有订单号用本地美味订单号 如果本地美味订单号为null[清除数据了] 用后台返回的美味订单号为准
        orderRefund.fsSellNo = !TextUtils.isEmpty(mwSellNo) ? mwSellNo : fsSellNo;
        orderRefund.fsRefundType = 0;
        orderRefund.fsOperator = userDBModel.fsUserName;
        orderRefund.fsauthorizer = userDBModel.fsUserName;
        orderRefund.fsRefundTime = DateUtil.getCurrentTime();

        request.action = "PARTIAL_REFUND";//部分退款
        orderRefund.refundAmount = refundAmount;//退款金额
        orderRefund.refundNo = UUID.randomUUID().toString().replace("-", "");//生成退款单号
        RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "口碑部分退款  口碑订单号：" + order_id,
                "部分退款调用时，退款单号：" + orderRefund.refundNo + "    退款金额：" + orderRefund.refundAmount);

        request.kbOrderRefund = orderRefund;

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof KBPartRefundReturnResponse) {
                    //todo 存储口碑退款记录
                    KBOrderRefundModel model = new KBOrderRefundModel();
                    model.fsSellNo = orderRefund.fsSellNo;
                    model.fsRefundType = orderRefund.fsRefundType;
                    model.fsOperator = orderRefund.fsOperator;
                    model.fsAuthorizer = orderRefund.fsauthorizer;
                    model.fsRefundTime = orderRefund.fsRefundTime;
                    model.replaceNoTrans();

                    KBPartRefundReturnResponse refundReturnResponse = ((KBPartRefundReturnResponse) responseData.responseBean);
                    callback.onSuccess(refundReturnResponse);
                } else {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {

                //todo 吴丽丽产品的要求 提示语
                if (responseData.resultMessage.contains("退款次数超过上限")) {
                    callback.onFailure(responseData.result, responseData.resultMessage);
                } else {
                    callback.onFailure(responseData.result, "[未核销前不可部分退款]" + responseData.resultMessage);
                }

                return false;
            }
        }, false);

    }

    /**
     * 拒绝退款
     *
     * @param order_id         口碑订单号
     * @param fsSellNo         美味订单号
     * @param merchantId
     * @param no
     * @param rejectReason
     * @param userDBModel
     * @param businessCallback
     */
    @Override
    public void rejectRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String rejectReason, UserDBModel userDBModel, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.action = "REJECT_REFUND";
        request.merchantPid = merchantId;
        request.tableNo = no;
        request.reason = rejectReason;
        //TODO 商家同意退款的字段放在那里 rejectReason
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
    }

    /**
     * 接受退款
     *
     * @param order_id           口碑订单号
     * @param fsSellNo           美味订单号
     * @param merchantId
     * @param no
     * @param aggrenRefundReason
     * @param userDBModel
     * @param businessCallback
     */
    @Override
    public void agreenRefundOrder(String order_id, String fsSellNo, String merchantId, String no, String aggrenRefundReason, UserDBModel userDBModel, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.order_id = order_id;
        request.action = "ACCEPT_REFUND";
        request.merchantPid = merchantId;
        request.tableNo = no;
        request.reason = aggrenRefundReason;
        KBOrderRefund orderRefund = new KBOrderRefund();
        //根据口碑订单号查询美味订单号
        String mwSellNo = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
        //本地有订单号用本地美味订单号 如果本地美味订单号为null[清除数据了] 用后台返回的美味订单号为准
        orderRefund.fsSellNo = !TextUtils.isEmpty(mwSellNo) ? mwSellNo : fsSellNo;
        orderRefund.fsRefundType = 1;
        orderRefund.fsOperator = userDBModel.fsUserName;
        orderRefund.fsauthorizer = userDBModel.fsUserName;
        orderRefund.fsRefundTime = DateUtil.getCurrentTime();
        request.kbOrderRefund = orderRefund;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

                //todo 存储口碑退款记录
                KBOrderRefundModel model = new KBOrderRefundModel();
                model.fsSellNo = orderRefund.fsSellNo;
                model.fsRefundType = orderRefund.fsRefundType;
                model.fsOperator = orderRefund.fsOperator;
                model.fsAuthorizer = orderRefund.fsauthorizer;
                model.fsRefundTime = orderRefund.fsRefundTime;
                model.replaceNoTrans();


            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, false);
    }


    /**
     * 修改桌号
     *
     * @param order_id
     * @param businessType
     * @param merchantId
     * @param tableNo          分配的桌台名称
     * @param businessCallback
     */
    @Override
    public void allocationTable(String order_id, String businessType, String merchantId, String tableNo, BusinessCallback businessCallback) {

        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        request.action = "TABLE_CHANGE";
        request.order_id = order_id;
        request.businessType = businessType;
        request.merchantPid = merchantId;
        request.tableNo = tableNo;
        request.reason = "分配桌台,修改桌台号码";

        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, businessCallback, true);
    }

    /**
     * 下厨
     *
     * @param order_id
     * @param merchantId
     * @param businessCallback
     */
    @Override
    public void cooking(String order_id, String merchantId, BusinessCallback businessCallback) {
        KBPreOrderUpdateRequest request = new KBPreOrderUpdateRequest();
        //已下厨
        request.action = "COOKING";
        request.order_id = order_id;
        request.merchantPid = merchantId;

        BusinessExecutor.execute(request, null, businessCallback);
    }
}
