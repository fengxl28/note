package com.mwee.android.pos.businesscenter.driver;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BaseConfig;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.menu.KouBeiSellOutRequest;
import com.mwee.android.pos.business.menu.RapidSellOutRequest;
import com.mwee.android.pos.business.menu.model.KouBeiSellOutModel;
import com.mwee.android.pos.business.menu.model.RapidSellOutModel;
import com.mwee.android.pos.business.permission.Permission;
import com.mwee.android.pos.business.print.PrintConfig;
import com.mwee.android.pos.business.report.ReportConsrance;
import com.mwee.android.pos.business.treeview.TreeNode;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.air.dbUtil.MetaDBController;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrintTempletPrivateDBUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.pay.PayConfig;
import com.mwee.android.pos.businesscenter.business.report.processor.ReportProcessor;
import com.mwee.android.pos.businesscenter.business.unfinish_task.Job;
import com.mwee.android.pos.businesscenter.business.unfinish_task.JobWorker;
import com.mwee.android.pos.businesscenter.dbutil.DataCacheDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.PrintTaskDBUtil;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.businesscenter.print.PrintReportUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bean.GetPrintTaskResponse;
import com.mwee.android.pos.connect.business.bean.GetUnPrintTaskNoResponse;
import com.mwee.android.pos.connect.business.bean.UpdatePrintTaskResponse;
import com.mwee.android.pos.connect.business.bill.OrderPrintDataResponse;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.host.GetHostStatusManagerResponse;
import com.mwee.android.pos.connect.business.host.model.HostStatusBean;
import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;
import com.mwee.android.pos.connect.business.monitor.report.GetOrderSourceListResponse;
import com.mwee.android.pos.connect.business.monitor.report.GetOrderFilterDataListResponse;
import com.mwee.android.pos.connect.business.monitor.report.LoadAccountBookResponse;
import com.mwee.android.pos.connect.business.monitor.report.PrintReportReceiptResponse;
import com.mwee.android.pos.connect.business.monitor.report.QueryDailyTimeResponse;
import com.mwee.android.pos.connect.business.monitor.report.QueryReportHomeDataResponse;
import com.mwee.android.pos.connect.business.monitor.report.QueryReportResponse;
import com.mwee.android.pos.connect.business.monitor.report.QuerySalesTargetResponse;
import com.mwee.android.pos.connect.business.monitor.report.SalesTargetReportResponse;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.connect.business.print.GetPrintMonitorDataResponse;
import com.mwee.android.pos.connect.business.print.GetPrintStatusInfoResponse;
import com.mwee.android.pos.connect.business.print.GetPrintTaskDBResponse;
import com.mwee.android.pos.connect.business.print.GetSwitchPrinterListResponse;
import com.mwee.android.pos.connect.business.print.GetSwitchPrinterNameResponse;
import com.mwee.android.pos.connect.business.print.GetTempletsResponse;
import com.mwee.android.pos.connect.business.print.GetUsedTempletTypeListResponse;
import com.mwee.android.pos.connect.business.print.GetUsedTempletsResponse;
import com.mwee.android.pos.connect.business.print.PrintMonitorVideoStatusResponse;
import com.mwee.android.pos.connect.business.print.PrintSalesTargetResponse;
import com.mwee.android.pos.connect.business.print.PrintSelloutResponse;
import com.mwee.android.pos.connect.business.print.PrinterUpdateStatusResponse;
import com.mwee.android.pos.connect.business.print.model.BackupPrinterMapping;
import com.mwee.android.pos.connect.business.print.model.ReceiptTempletModel;
import com.mwee.android.pos.connect.business.table.GetSettingResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.AccountBookDBModel;
import com.mwee.android.pos.db.business.BillSourceDBModel;
import com.mwee.android.pos.db.business.DailyReportDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.SellcheckDBModel;
import com.mwee.android.pos.db.business.ShiftDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.order.SellType;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.db.business.report.DailyReportDBUtil;
import com.mwee.android.pos.db.business.report.model.ReportCenterDailySell;
import com.mwee.android.pos.db.business.report.model.SaleStatisticsItemModel;
import com.mwee.android.pos.db.business.report.model.SalesAmountItemModel;
import com.mwee.android.pos.util.DbUtil;
import com.mwee.android.pos.db.business.report.model.SectionInComeInfoMode;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.TempletIdManager;
import com.mwee.android.posmodel.print.PrintConnector;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.posmodel.print.PrinterSelectModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.FileUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.NetWorkUtil;
import com.mwee.android.tools.StringUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPrivateDBModel;
import com.mwee.myd.server.dbmodel.print.PrintTempletPublicDBModel;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Created by Liming on 16/9/22.
 */
@SuppressWarnings("unused")
public class MonitorDriver implements IDriver {
    private static final String TAG = "monitor";
    private final static Object lockRapid = new Object();
    //秒点是否正在上传
    boolean rapidSellOutUploading = false;
    //是否有
    boolean rapidSellOutWaiting = false;

    /**
     * 获取打印的PrintTaskDBModel
     *
     * @param printNO  String
     * @param fsHostID String
     * @return PrintTaskDBModel
     */
    public static PrintTaskDBModel getTask(String printNO, String fsHostID) {
        String sql2 = "select * from tbPrintTask where "
                + "fsHostId = '" + fsHostID + "' "
                + " and fiPrintNo = '" + printNO + "'";
        return DBSimpleUtil.query(APPConfig.DB_PRINT, sql2, PrintTaskDBModel.class);
    }

    public static PrintTaskDBModel getTask(String printNo) {
        String sql2 = "select * from tbPrintTask where fiPrintNo = '" + printNo + "'";
        return DBSimpleUtil.query(APPConfig.DB_PRINT, sql2, PrintTaskDBModel.class);
    }

    /**
     * 所有的未交班的销售结帐表
     *
     * @param fsShopGUID
     * @return
     */
    public static List<SellcheckDBModel> getSellBoxList(String fsShopGUID) {
        String sql = "where fsShopGUID = '" + fsShopGUID + "'"
                + " and fiStatus='1'"
                + " order by fsCreateTime desc";
        List<SellcheckDBModel> sellcheckDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, SellcheckDBModel
                .class);
        return sellcheckDBModelList;
    }

    /**
     * 清楚所有的估清的菜品列表
     */
    private static void clearAppraiseMenuLists() {
        // 1 得到临时估清菜品的规格 2 根据规格fiItemCd得到依赖的菜品  3封装数据
        List<MenuItemUnitDBModel> menuItemUnitList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "SELECT * FROM " +
                "tbmenuitemuint where " +
                "fiStatus = '2' ", MenuItemUnitDBModel.class);
        if (menuItemUnitList.size() > 0) {
            for (int i = 0; i < menuItemUnitList.size(); i++) {
                MenuitemDBModel menuitemDBModel = MenuDBUtil.getMenuDBModelByID(menuItemUnitList.get(i).fiItemCd);
                if (menuitemDBModel != null) {
                    menuitemDBModel.delete();
                }
            }
        }
    }

    protected static void resetAllBackPrinterToNormal() {
        String sql = "update tbPrinter set fiTaskCount=0,switch_backup=0,switchTime='',fiPrinterStatus='1'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 校验报表数据，删除大于7天的报表信息
     *
     * @param businessData         当前的营业日期
     * @param intervalBusinessDate 间隔的营业日期
     */
    @DrivenMethod(uri = TAG + "/check_report")
    public static void checkReportData(final String businessData, final String intervalBusinessDate) {
        BusinessExecutor.executeNoWait(new ASyncExecute() {
            @Override
            public Object execute() {
                /* 1.删除存储的销售数量表文件 */
                String sql = "select value from dailyReport where type = '"
                        + ReportConsrance.REPORT_SALE + "' and (julianday('" + businessData + "') - " +
                        "julianday(businessdate)) > " + intervalBusinessDate;
                List<String> filesUri = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                if (!ListUtil.isEmpty(filesUri)) {
                    for (String s : filesUri) {
                        FileUtil.deleteAllFile(s);
                    }
                }

                /* 2.删除数据库数据 */
                DBManager.getInstance().executeInTransaction(new IDBOperate<Boolean>() {
                    @Override
                    public Boolean doJob(SQLiteDatabase db) {
                        db.delete("dailyReport", " (julianday('" + businessData + "')-julianday(businessdate))> " +
                                        intervalBusinessDate,
                                null);
                        return true;
                    }
                });
                return new Object();
            }
        });
    }

    /**
     * 获取打印Model
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getPrintTask")
    public static SocketResponse getPrintTask(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();
        try {
            final GetPrintTaskResponse response = new GetPrintTaskResponse();
            socketResponse.data = response;
            JSONObject request = JSON.parseObject(param);
            String hostId = request.getString("hostId");
            StringBuilder sb = new StringBuilder();
            List<Integer> noList = JSON.parseArray(request.getString("noList"), Integer.class);
            if (!ListUtil.isEmpty(noList)) {
                for (Integer temp : noList) {
                    sb.append("'").append(temp).append("'").append(",");
                }
                sb.deleteCharAt(sb.length() - 1);
                response.printTaskDBModelList = PrintTaskDBUtil.getPrintTaskList(sb.toString(), hostId);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "获取成功";

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    @DrivenMethod(uri = TAG + "/loadLoginData")
    public SocketResponse login(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();
        try {
            GetLoginDataResponse loginResponse = new GetLoginDataResponse();
            loginResponse.userDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fiStatus='1' and " +
                    "fsUserId<>'cash' and " +
                    "fsStaffId<>'cash' and fiIsPosLogin='1' AND fiIsChef = '0' ", UserDBModel.class);
            if (!HostUtil.isShopFinished()) {
                loginResponse.businessDate = HostUtil.getHistoryBusineeDate("");
            }
            loginResponse.shitList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fiStatus='1' and fsShopGUID='"
                    + head.shopid + "'", ShiftDBModel.class);
            loginResponse.shopStatus = HostUtil.getShopBizStatus();
            socketResponse.data = loginResponse;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
        }
        return socketResponse;

    }

    @DrivenMethod(uri = TAG + "/loadPrinterData")
    public SocketResponse h(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            GetPrintMonitorDataResponse dataResponse = new GetPrintMonitorDataResponse();
            int currentPage = request.getIntValue("currentPage");
            String selectTableNO = request.getString("selectTableNO");
            int fiStatus = request.getIntValue("fiStatus");
            String businessDate = request.getString("businessDate");
            String printerName = request.getString("printerName");
            dataResponse.list = getPrintMonitorData(currentPage, selectTableNO, fiStatus, businessDate, printerName);
            String sql = "select count(*) from tbPrintTask ";
            int totalRecord = Integer.valueOf(DBSimpleUtil.queryString(APPConfig.DB_PRINT, sql));
            dataResponse.pageCount = (totalRecord + 20 - 1) / 20;
            response.code = SocketResultCode.SUCCESS;
            response.data = dataResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadPrintStatusInfo")
    public SocketResponse getPrintStatusInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSONObject.parseObject(param);
            GetPrintStatusInfoResponse dataResponse = new GetPrintStatusInfoResponse();
            String selectTableNO = request.getString("selectTableNO");
            int fiStatus = request.getIntValue("fiStatus");
            String businessDate = request.getString("businessDate");
            dataResponse.list = selectPrintStatusInfo(selectTableNO, fiStatus, businessDate);
            String sql = "select count(*) from tbPrintTask ";
            int totalRecord = Integer.valueOf(DBSimpleUtil.queryString(APPConfig.DB_PRINT, sql));
            response.code = SocketResultCode.SUCCESS;
            response.data = dataResponse;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/getPrintTaskDB")
    public SocketResponse getPrintTaskDB(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            GetPrintTaskDBResponse getPrintTaskDBResponse = new GetPrintTaskDBResponse();
            JSONObject request = JSON.parseObject(param);
            //查找对应站点的数据
            String sql = "select * from tbPrintTask where "
                    + " fsHostId = '" + request.getString("fsHostId") + "'"
                    + " and fiPrintNo = '" + request.getIntValue("fiPrintNo") + "'"
                    + " and fsSellNo  = '" + request.getString("fsSellNo") + "'";
            PrintTaskDBModel printTaskDBModel = DBSimpleUtil.query(APPConfig.DB_PRINT, sql, PrintTaskDBModel.class);
            if (printTaskDBModel != null) {
                getPrintTaskDBResponse.printerDBModel = printTaskDBModel;
            } else {
                String sql2 = "select * from tbPrintTask where "
                        // +"fsHostId = '"+request.printerDBModel.fsHostId   +"' "
                        + " fiPrintNo = '" + request.getIntValue("fiPrintNo") + "'"
                        + " and fsSellNo  = '" + request.getString("fsSellNo") + "' ";
                getPrintTaskDBResponse.printerDBModel = DBSimpleUtil.query(APPConfig.DB_PRINT, sql2, PrintTaskDBModel
                        .class);
            }

            //获取数据和模板合并的数据
            if (getPrintTaskDBResponse.printerDBModel != null && !TextUtils.isEmpty(getPrintTaskDBResponse.printerDBModel.fsPrnData)) {
                //client端后加的数据，移到业务中心来，加上后统一生成html数据
                String url = String.format("%s.html", getPrintTaskDBResponse.printerDBModel.uri.replace("/", "_"));
                JSONObject map = JSON.parseObject(getPrintTaskDBResponse.printerDBModel.fsPrnData);
                map.put("uri", url);
                map.put("fsReportName", getPrintTaskDBResponse.printerDBModel.fsReportName);//下单部门
                map.put("print_type", String.format("重打", getPrintTaskDBResponse.printerDBModel.fsReportName));
                map.put("fsCreateUserName", getPrintTaskDBResponse.printerDBModel.fsCreateUserName);
                map.put("fsCreateTime", getPrintTaskDBResponse.printerDBModel.fsCreateTime);
                getPrintTaskDBResponse.htmlData = getHtmlData(getPrintTaskDBResponse.printerDBModel.fsPrnData, getPrintTaskDBResponse.printerDBModel.uri);
            }
            if (!TextUtils.isEmpty(getPrintTaskDBResponse.htmlData)) {
                getPrintTaskDBResponse.printerDBModel.fsPrnData = null;//已经有和模板合并的数据，就去掉原始数据，防止数据过多，socket发不过去。
            }
            response.data = getPrintTaskDBResponse;
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    /**
     * 设置页面
     * 设置相同菜品是否合并          MERGE_MENUITEM_EQUALS = 402
     * 设置打烊是否打印报表          CLOSE_REPORT_PRINT = 403;
     * 设置秒点单是否自动结账        RAPID_AUTO_PAY = 404
     * 设置产生溢收时是否可结账      ALLOW_PAY_OVERFLOW = 405
     * 设置美小二通过区域打印预结单   WAITER_MERA_PREBILL = 406
     * 设置秒点自动下厨             WAITER_RAPID_AUTO = 407
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/changeSetting")
    public SocketResponse changeRestaurant(SocketHeader head, String param) {

        SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        response.code = SocketResultCode.SUCCESS;
        response.message = "更新设置成功";
        if (request.getIntValue("isMeta") == 0) {
            //CommonDBUtil.setConfig(request.getString("paramType"), request.getString("value"));
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbParamValue set sync = '1',fsUpdateTime = '" + DateUtil.getCurrentTime() + "'" +
                    ", fsParamValue= '" + request.getString("value") + "' where fsParamId='" + request.getString("paramType") + "'");
            MetaDBController.updateSyncTime();
            if (DBPrintConfig.TAIL_MESSAGE.equals(request.getString("paramType"))) {
                //刷新广告词缓存
                PrintConfig.PRINT_TAIL_MESSAGE = CommonDBUtil.getConfig(DBPrintConfig.TAIL_MESSAGE);
            }
            NotifyToClient.refreshDBConfig(request.getString("paramType"), request.getString("value"));
            if (TextUtils.equals(DBOrderConfig.ROUND_SUB_TOTAL, request.getString("paramType"))
                    || TextUtils.equals(DBOrderConfig.ROUND_TOTAL, request.getString("paramType"))
                    || TextUtils.equals(DBOrderConfig.ROUND_COUNT, request.getString("paramType"))) {
                RoundConfig.init(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGUID from tbShop order by " +
                        "fiStatus asc"));
            }
        } else {
            DBMetaUtil.updateSettingsValueByKey(request.getIntValue("type"), request.getString("value"));
            NotifyToClient.refreshSetting(String.valueOf(request.getIntValue("type")), request.getString("value"));
            handlerSetting(request.getIntValue("type"), request.getString("value"));
        }


        DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, DateUtil.getCurrentDate(DateUtil
                .DATE_VISUAL14FORMAT));
        return response;
    }

    /**
     * 设置页面
     * 支持批量修改
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/changeSettingList")
    public SocketResponse changeSettingList(SocketHeader head, String param) {

        SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        response.code = SocketResultCode.SUCCESS;
        response.message = "更新设置成功";
        if (request.getIntValue("isMeta") == 0) {
            //CommonDBUtil.setConfig(request.getString("paramType"), request.getString("value"));
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbParamValue set sync = '1',fsUpdateTime = '" + DateUtil.getCurrentTime() + "'" +
                    ", fsParamValue= '" + request.getString("value") + "' where fsParamId='" + request.getString("paramType") + "'");
            MetaDBController.updateSyncTime();

            NotifyToClient.refreshDBConfig(request.getString("paramType"), request.getString("value"));
            if (TextUtils.equals(DBOrderConfig.ROUND_SUB_TOTAL, request.getString("paramType"))
                    || TextUtils.equals(DBOrderConfig.ROUND_TOTAL, request.getString("paramType"))
                    || TextUtils.equals(DBOrderConfig.ROUND_COUNT, request.getString("paramType"))) {
                RoundConfig.init(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopGUID from tbShop order by " +
                        "fiStatus asc"));
            }
        } else {
            if (!TextUtils.isEmpty(request.getString("paramList"))) {
                List<DataModel> paramList = JSON.parseArray(request.getString("paramList"), DataModel.class);
                if (!ListUtil.isEmpty(paramList)) {

                    int deliveryModel = -1;
                    String immeTime = "";
                    String reseTime = "";
                    List<Pair<Integer, String>> list = new ArrayList<Pair<Integer, String>>();
                    for (DataModel model : paramList) {
                        if (StringUtil.toInt(model.id) == META.DELIVERY_WAY) {
                            deliveryModel = StringUtil.toInt(model.value);
                        } else if (StringUtil.toInt(model.id) == META.DELIVERY_IMMEDIATE_TIME) {
                            immeTime = model.value;
                        } else if (StringUtil.toInt(model.id) == META.DELIVERY_RESERVATIONS_TIME) {
                            reseTime = model.value;
                        }
                        Pair<Integer, String> pair = new Pair<Integer, String>(StringUtil.toInt(model.id), model.value);
                        list.add(pair);
                    }
                    DBMetaUtil.updateSettingsValueByKey(list);
                    NotifyToClient.refreshBatchSetting(paramList);

                    if (deliveryModel != -1) {
                        ServerCache.getInstance().netOrderCache.updateDeliveryInfo(deliveryModel, immeTime, reseTime);
                    }
                }
            }
        }

        DBMetaUtil.updateSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME, DateUtil.getCurrentDate(DateUtil
                .DATE_VISUAL14FORMAT));
        return response;
    }

    private void handlerSetting(int key, String value) {
        if (key == META.SWITCH_WAITER_SERVICE) {
            // 美小二服务开启或关闭
            if (TextUtils.equals("1", value)) {
                DriverBus.call("waiter/checkAlive");
                RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, "开启美小二服务");
            } else {
                DriverBus.call("waiter/finishServer");
                RunTimeLog.addLog(RunTimeLog.SYS_WAITER_SERVER, "关闭美小二服务");
            }
        }
    }

    /**
     * 设置页面
     * 设置相同菜品是否合并          MERGE_MENUITEM_EQUALS = 402
     * 设置打烊是否打印报表          CLOSE_REPORT_PRINT = 403;
     * 设置秒点单是否自动结账        RAPID_AUTO_PAY = 404
     * 设置产生溢收时是否可结账      ALLOW_PAY_OVERFLOW = 405
     * 设置美小二通过区域打印预结单   WAITER_MERA_PREBILL = 406
     * 设置秒点自动下厨             WAITER_RAPID_AUTO = 407
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/changeWechatFastfoodMealNumberSetting")
    public SocketResponse changeWechatFastfoodMealNumberSetting(SocketHeader head, String param) {

        SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        response.code = SocketResultCode.SUCCESS;
        response.message = "更新设置成功";
        String value = request.getString("value");
        JSONObject jsonObject = JSON.parseObject(value);
        Set<String> keySet = jsonObject.keySet();
        for (String key : keySet) {
            DBMetaUtil.updateSettingsValueByKey(StringUtil.toInt(key), jsonObject.getString(key));
            NotifyToClient.refreshSetting(key, jsonObject.getString(key));
        }
        return response;
    }

    /**
     * 得到餐厅设置
     *
     * @return
     */
    @DrivenMethod(uri = TAG + "/getSetting")
    public SocketResponse getSettingRestaurant(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();

        GetSettingResponse getSettingResponse = new GetSettingResponse();
        getSettingResponse.dinnerDBSettings = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue " +
                "where fsParamId in ('134','144','215','316','317')", ParamvalueDBModel.class);
        response.data = getSettingResponse;
        return response;

    }

    /**
     * 打印报表小票
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/printReportReceipt")
    public SocketResponse printReportReceipt(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String shopGUID = head.shopid;
        String startDate = request.getString("startDate");
        String endDate = request.getString("endDate");
        String type = request.getString("type");
        ShiftDBModel shiftModel = request.getObject("shiftModel", ShiftDBModel.class);
        String shiftId;
        if (shiftModel != null) {
            shiftId = shiftModel.fsShiftId;
        } else {
            shiftId = "";
        }
        int billType = request.getInteger("billType");
        // 账套id
        String accountBookId = request.getString("accountBookId");
        String params = request.getString("params");
        Integer newReport = request.getInteger("newReport") == null ? 0 : request.getInteger("newReport");
        String menuSourceList = request.getString("menuSourceList") == null ? "" : request.getString("menuSourceList");
        String sellTypeList = request.getString("sellTypeList");

        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");

        if (!hasReportSaveCompletely(currentBusinessDate, startDate, endDate)) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "数据未统计完全、请稍后重试";
            return response;
        }

        Map<String, Object> htmlParams;
        if (newReport == 1 && TextUtils.equals(type, ReportConsrance.REPORT_SALE)) {
            TreeNode treeNode = JSON.parseObject(request.getString("treeNode"), TreeNode.class);
            if (treeNode == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印报表失败";
                return response;
            }
            htmlParams = querySaleNumData(treeNode, billType, accountBookId, menuSourceList, sellTypeList);
            htmlParams.put("newReport", newReport);
        } else {
            htmlParams = ReportProcessor.getReportData(shopGUID, startDate, endDate, type, shiftId, billType, accountBookId, buildFilterData(menuSourceList), buildFilterData(sellTypeList));
            // 下面的代码在小易上会报内部异常错误
            if (!APPConfig.isAir(GlobalCache.getContext())) {
                //最高销售数量表按选择的排名来打印
                if (TextUtils.equals(ReportConsrance.REPORT_MAX_SALE_QUANTITY, type)) {
                    //排名数
                    int rank = request.getInteger("rank");
                    if (rank != 0 && htmlParams.containsKey("XSSL")) {
                        List<SaleStatisticsItemModel> data = (List<SaleStatisticsItemModel>) htmlParams.get("XSSL");
                        if (!ListUtil.isEmpty(data) && data.size() > rank) {
                            htmlParams.put("XSSL", data.subList(0, rank));
                        }
                        htmlParams.put("selectRank", "(TOP" + rank + ")");
                    }
                }
            }
        }
        if (TextUtils.equals(type, ReportConsrance.REPORT_AB) && !TextUtils.isEmpty(params)) {  //AB账
            htmlParams = JSONObject.parseObject(params, Map.class);
            if (htmlParams == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "打印报表失败";
                return response;
            }
        }
        htmlParams.put("Businessdate", TextUtils.equals(startDate, endDate) ? startDate : startDate + "~~" + endDate);
        String shopName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbShop where fsShopGUID" +
                " = '" + shopGUID + "'");
        htmlParams.put("fsShopName", shopName);
        if (shiftModel != null) {
            htmlParams.put("fsShiftName", shiftModel.fsShiftName);
        }

        final PrintReportReceiptResponse printReportReceiptResponse = new PrintReportReceiptResponse();
        List<Integer> printNoList = PrintReportUtil.printReport(type, currentBusinessDate, htmlParams,
                head.hd);
        if (!ListUtil.isEmpty(printNoList)) {
            printReportReceiptResponse.printNo.addAll(printNoList);
        }

        response.data = printReportReceiptResponse;
        response.code = SocketResultCode.SUCCESS;
        response.message = "打印报表成功";
        return response;
    }

    /**
     * 打印监控数据
     *
     * @param fiStatus     打印状态
     * @param businessDate 打印日期
     * @return List<PrintTaskDBModel>
     * <p>
     * //当前页数 currentPage  1
     * //一页显示的数量         50
     */
    private List<PrintTaskDBModel> getPrintMonitorData(int currentPage, String selectTableNO, int fiStatus, String
            businessDate, String printerName) {
        StringBuilder sql = new StringBuilder("select fsTaskDetail,fiPrintNo,fsCreateTime,fsCreateUserName,fsHostId," +
                "fsDeptId,fsDeptName,fsPrinterName,fsReportId,fsReportName,fiTaskType,fiPrnDataType,fsRemark," +
                "fsSellNo,fsOtherNo,fsDate,fiStatus,fiErrCount,fsFinishTime,uri,is_backup_printer,fiPrintCount  from " +
                "tbPrintTask where");
        sql.append(" fsDate='").append(businessDate).append("'");
        sql.append(" and ");

        sql.append(" fiTaskType='1' ");

        if (!TextUtils.isEmpty(selectTableNO) && !TextUtils.equals("无条件", selectTableNO)) {
            sql.append("and fsOtherNo ='" + selectTableNO + "' ");
        }

        if (!TextUtils.isEmpty(printerName)) {
            sql.append("and fsPrinterName ='" + printerName + "' ");
        }

        if (fiStatus != 0) {
            sql.append("and fiPrintCount !='0'").append(" and ");
            if (fiStatus == 3) {//打印失败包括逾期
                sql.append(" ( fiStatus='").append(fiStatus).append("' or fiStatus='8' ) ");
            } else {
                sql.append(" fiStatus='").append(fiStatus).append("'");
            }
        }
        sql.append(" order by fsCreateTime desc ");
        int offset = (currentPage - 1) * 20;//偏移量
        sql.append("limit 20 offset " + offset);
        List<PrintTaskDBModel> printTaskDBModelList = DBSimpleUtil.queryList(APPConfig.DB_PRINT, sql.toString(),
                PrintTaskDBModel.class);
        return ListUtil.isEmpty(printTaskDBModelList) ? new ArrayList<>() : printTaskDBModelList;
    }

    /**
     * 获取数据状态
     *
     * @param fiStatus     打印状态
     * @param businessDate 打印日期
     * @return List<PrintTaskDBModel>
     * <p>
     * //一页显示的数量         50
     */
    private List<PrinterSelectModel> selectPrintStatusInfo(String selectTableNO, int fiStatus, String
            businessDate) {
        StringBuilder sql = new StringBuilder("select fsPrinterName,COUNT(*) as count  from " +
                "tbPrintTask where");
        sql.append(" fsDate='").append(businessDate).append("'");
        sql.append(" and ");

        sql.append(" fiTaskType='1' ");

        if (!TextUtils.isEmpty(selectTableNO) && !TextUtils.equals("无条件", selectTableNO)) {
            sql.append("and fsOtherNo ='" + selectTableNO + "' ");
        }

        if (fiStatus != 0) {
            sql.append("and fiPrintCount !='0'").append(" and ");
            if (fiStatus == 3) {//打印失败包括逾期
                sql.append(" ( fiStatus='").append(fiStatus).append("' or fiStatus='8' ) ");
            } else {
                sql.append(" fiStatus='").append(fiStatus).append("'");
            }
        }
        sql.append(" GROUP BY fsPrinterName ");
        List<PrinterSelectModel> printerSelectList = DBSimpleUtil.queryList(APPConfig.DB_PRINT, sql.toString(),
                PrinterSelectModel.class);
        return ListUtil.isEmpty(printerSelectList) ? new ArrayList<>() : printerSelectList;
    }

    /**
     * 更新秒点菜品沽清状态
     */
    @DrivenMethod(uri = TAG + "/update_rapid_sell_out")
    public void updateRapidSellOut() {
        //所有的估清信息会汇总到主站点，所以，只需要在主站点去上报秒点的数据，副站点不需要重复上报。
        if (!BindProcessor.isCurrentHostMain()) {
            return;
        }
        synchronized (lockRapid) {

            RunTimeLog.addLog(ActionLog.DF_MENU_APPRAISE, "业务中 更新秒点菜品沽清状态  rapidSellOutUploading =" + rapidSellOutUploading + ", rapidSellOutWaiting = " + rapidSellOutWaiting);

            if (rapidSellOutUploading) {
                rapidSellOutWaiting = true;
                return;
            } else {
                rapidSellOutWaiting = false;
            }
            rapidSellOutUploading = true;
        }

        List<RapidSellOutModel> menus = new ArrayList<>();
//        查已沽清
        String sqlQty = "select distinct fiItemCd,'1' state from localSellOut where (fiStatus = 2 or fiStatus = 3) " +
                "and fdInvQty = 0";
        List<RapidSellOutModel> sellOutModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlQty, RapidSellOutModel
                .class);
        if (!ListUtil.isEmpty(sellOutModels)) {
            menus.addAll(sellOutModels);
        }
//        查未沽清
        String sqlNotQty = "select fiItemCd ,'0' state from tbmenuitem where fiitemcd not in (select distinct " +
                "fiItemCd from localSellOut where (fiStatus = 2 or fiStatus = 3) and fdInvQty = 0)";
        List<RapidSellOutModel> notSellOutModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlNotQty,
                RapidSellOutModel.class);
        if (!ListUtil.isEmpty(notSellOutModels)) {
            menus.addAll(notSellOutModels);
        }
        if (BaseConfig.isDEV()) {
            LogUtil.log("获取的所有菜品沽清状态:\n" + JSON.toJSONString(menus));
        }
        String shopID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        RapidSellOutRequest request = new RapidSellOutRequest();
        request.shopId = shopID;
        request.goods = menus;
        //同步沽清数量到口碑
        uploadSellOutToKouBei();
        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                synchronized (lockRapid) {
                    rapidSellOutUploading = false;
                }
                if (rapidSellOutWaiting) {
                    rapidSellOutWaiting = false;
                    updateRapidSellOut();
                }
                return true;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                synchronized (lockRapid) {
                    rapidSellOutUploading = false;
                }
                if (rapidSellOutWaiting) {
                    rapidSellOutWaiting = false;
                    updateRapidSellOut();
                }
                return false;
            }
        }, true);
    }

    private void uploadSellOutToKouBei() {
        String sql = "select fiitemcd,case when fiStatus==2 or fiStatus==3 then fdInvQty else 10000 end as fdInvQty, fiStatus, fiOrderUintCd from (select t.fiitemcd,min(l.fdInvQty) fdInvQty , l.fiStatus,t.fiOrderUintCd from tbmenuitemuint t LEFT OUTER JOIN localSellOut l ON t.fiitemcd=l.fiitemcd group by t.fiitemcd)\n";
        KouBeiSellOutRequest request = new KouBeiSellOutRequest();
        request.menuList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, KouBeiSellOutModel.class);
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        });
    }

    /**
     * 获取打印机，如果打印机已经切换到备用打印机，则返回备用打印机
     */
    @DrivenMethod(uri = TAG + "/getSwitchPrinterName")
    public SocketResponse getSwitchPrinterName(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        GetSwitchPrinterNameResponse response = new GetSwitchPrinterNameResponse();
        socketResponse.data = response;
        //GetSwitchPrinterNameRequest request = JSON.parseObject(param, GetSwitchPrinterNameRequest.class);
        JSONObject request = JSON.parseObject(param);
        if (TextUtils.isEmpty(request.getString("originPrinterName"))) {
            response.targetPrinterName = "";
        } else {
            String target = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsbakprintername from tbPrinter  " +
                    "where fsbakprintername<>'' and switch_backup='1' " +
                    "and fsPrinterName='" + request.getString("originPrinterName") + "'");
            if (!TextUtils.isEmpty(target)) {
                response.targetPrinterName = target;
                response.isBackup = true;
            } else {
                response.targetPrinterName = request.getString("originPrinterName");
                response.isBackup = false;
            }
        }
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/getSwitchPrinterList")
    public SocketResponse getSwitchPrinterList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        GetSwitchPrinterListResponse response = new GetSwitchPrinterListResponse();
        //GetSwitchPrinterListRequest request = JSON.parseObject(param, GetSwitchPrinterListRequest.class);
        JSONObject request = JSON.parseObject(param);
        if (request.getBooleanValue("seachFullInfo")) {
            response.usingBackPrinterList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select fsbakprintername as " +
                    "backupPrinterName,fsPrinterName as originPrinterName,switchTime,fiPrinterStatus   from tbPrinter" +
                    "  where fiStatus='1' and  fsbakprintername<>'' and switch_backup='1' ", BackupPrinterMapping
                    .class);
        } else {
            response.backList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select fsPrinterName  from tbPrinter" +
                    "  where fiStatus='1' and switch_backup='1' and fsbakprintername<>''");
        }
        socketResponse.data = response;
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/get_host_status_info")
    public SocketResponse getHostStatusInfo(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        GetHostStatusManagerResponse getHostStatusManagerResponse = new GetHostStatusManagerResponse();
        JSONObject request = JSON.parseObject(param);

        String sql = "";
        if (!request.getBooleanValue("isAll")) {
            sql = "select host_status.*, tbuser.fsUserName from host_status LEFT JOIN tbuser ON host_status" +
                    ".current_user_id = tbuser.fsUserId where hostid not in ('cloudsite','localhost','mealorder') " +
                    "order by bind_status desc";//获取主机副机站点信息
        } else {
            sql = "select host_status.*, tbuser.fsUserName from host_status LEFT JOIN tbuser ON host_status" +
                    ".current_user_id = tbuser.fsUserId where biz_status = '1' and hostid ='mealorder' order by " +
                    "bind_status desc";//获取所有的连接美小二站点信息
        }

        getHostStatusManagerResponse.hostLists = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, HostStatusBean.class);
        getHostStatusManagerResponse.biz_center_current_host_id = DBMetaUtil.getSettingsValueByKey(META
                .BIZ_CENTER_CURRENT_HOST_ID);
        socketResponse.data = getHostStatusManagerResponse;
        return socketResponse;

    }

    @DrivenMethod(uri = TAG + "/notifyAllPrinterStatus")
    public SocketResponse notifyAllPrinter(SocketHeader head, String param) {
        NotifyToClient.refreshAllPrinterStatus();
        return new SocketResponse();
    }

    /**
     * 更新打印机的状态
     *
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/printer_update")
    public SocketResponse printerUpdate(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        PrinterUpdateStatusResponse response = new PrinterUpdateStatusResponse();
        JSONObject request = JSON.parseObject(param);

        boolean resetToOrigin = request.getBooleanValue("resetToOrigin");
        String fsPrinterName = request.getString("printerName");

        socketResponse.data = response;
        socketResponse.code = SocketResultCode.SUCCESS;
        socketResponse.message = "";
//        synchronized (this) {
//            if (resetToOrigin) {
//                resetToOrigin(fsPrinterName);
//                return socketResponse;
//            }
//
//            if (!request.getBooleanValue("addFailCount")) {
//                return socketResponse;
//            }
//
//            int fiTaskCount = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fiTaskCount from  tbPrinter where  fsPrinterName='" + fsPrinterName + "'"), 0);
//
//            if ((fiTaskCount / 2) % 2 == 0) {
//                updatePriner(fsPrinterName, 0);
//            } else {
//                updatePriner(fsPrinterName, 1);
//=======
        if (request.getBooleanValue("resetToOrigin")) {
            //重置为正常打印机
            synchronized (this) {
                String sql = "update tbPrinter set fiPrinterStatus='1',fiTaskCount=0,switch_backup=0,switchTime='' " +
                        "where fsPrinterName='" + request.getString("printerName") + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            }
        } else if (request.getBooleanValue("addFailCount")) {
            if (request.getBooleanValue("isBackUpPrinter")) {
                String sql = "update tbPrinter set fiTaskCount=fiTaskCount+1 where fsPrinterName='" + request
                        .getString("printerName") + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
            } else {
                int count = 0;
                synchronized (this) {
                    //增加打印失败的次数，先查询已经失败的次数，如果大于等于与2，则次
                    String sql3 = "select fiTaskCount from  tbPrinter where  fsPrinterName='" + request.getString
                            ("printerName") + "'";
                    String countStr = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql3);

                    count = StringUtil.toInt(countStr, 0);
                    String sqlUpdateErrorCount = "update tbPrinter set fiTaskCount=(fiTaskCount+1),switch_backup=" +
                            "(select (case when fiTaskCount>1 then 1 else 0 end) as a from tbPrinter where " +
                            "fsPrinterName='" + request.getString("printerName") + "') where fsPrinterName='" +
                            request.getString("printerName") + "'";
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlUpdateErrorCount);
                }
                /**
                 * 将切换到备用打印机的打印机设置为离线
                 */
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fiPrinterStatus='10' where " +
                        "switch_backup='1'");

                String currentTime = DateUtil.getCurrentTime();
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set switchTime='" + currentTime + "' " +
                        "where switch_backup='1' and switchTime=''");
                if (count >= 2) {
                    response.backUpPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsbakprintername" +
                            " from tbPrinter where fsbakprintername<>'' and fsPrinterName='" + request.getString
                            ("printerName") + "'");
                    response.failToSwitchBackp = !TextUtils.isEmpty(response.backUpPrinterName);
                }
//>>>>>>> origin/pro2.7.7.310
            }

            String sql = "update tbPrinter set fiTaskCount=fiTaskCount+1 where fsPrinterName='" + fsPrinterName + "'";
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);

            response.backUpPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsbakprintername from tbPrinter where switch_backup='1'  and fsPrinterName='" + fsPrinterName + "'");
            response.failToSwitchBackp = !TextUtils.isEmpty(response.backUpPrinterName);

            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fiPrinterStatus='10' where switch_backup='1'");
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set switchTime='" + DateUtil.getCurrentTime() + "' where switch_backup='1' and switchTime=''");

            String fiStatus = request.getString("fiStatus");
            String fiPrintNo = request.getString("fiPrintNo");
            String fsHostId = request.getString("fsHostId");
            if (TextUtils.equals("8", fiStatus)) {
                JSONObject values = new JSONObject();
                values.put("fiStatus", fiStatus);
                values.put("fsFinishTime", DateUtil.getCurrentTime());
                PrintConnector.getInstance().updateTask(fsHostId, StringUtil.toInt(fiPrintNo), values.toJSONString());
            }
        }

        return socketResponse;
    }

    /**
     * 修改主副打印机切换状态
     *
     * @param fsPrinterName
     * @param switch_backup 0：未切换到备用打印机; 1：已切换到备用打印机
     */
    private void updatePriner(String fsPrinterName, int switch_backup) {
        String sqlUpdateErrorCount = "update tbPrinter set switch_backup = " + switch_backup + " where fsbakprintername<>'' and fsPrinterName='" + fsPrinterName + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sqlUpdateErrorCount);
    }

    /**
     * 重置为正常打印机
     *
     * @param fsPrinterName
     */
    private void resetToOrigin(String fsPrinterName) {
        String sql = "update tbPrinter set fiPrinterStatus='1',fiTaskCount=0,switch_backup=0,switchTime='' where fsPrinterName='" + fsPrinterName + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 查询报表
     */
    @DrivenMethod(uri = TAG + "/query_report")
    public SocketResponse queryReport(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        QueryReportResponse resParams = new QueryReportResponse();
        response.data = resParams;

        JSONObject request = JSON.parseObject(param);
        String shopGUID = head.shopid;

        String startDate = request.getString("startDate");
        String endDate = request.getString("endDate");
        String type = request.getString("type");
        String menuSourceList = request.getString("menuSourceList") == null ? "" : request.getString("menuSourceList");
        int billType = request.getInteger("billType");
        // 账套id
        String accountBookId = request.getString("accountBookId");
        int newReport = request.getInteger("newReport") == null ? 0 : request.getInteger("newReport");
        String sellTypeList = request.getString("sellTypeList");


        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");

        if (TextUtils.equals(type, ReportConsrance.REPORT_DAILY)) {
            LogUtil.logBusiness("MonitorDriver-queryReport", param);
        }

        if (DateUtil.compareDate(startDate, endDate, "yyyy-MM-dd") < 0) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "截止日期不能超过起始日期";
            return response;
        }
// TODO CALL 唐玉强， 这里不需要判断是否超过营业日期了？2018-08-11 pro2.8.3版本
//            //外卖报表/收款明细表是根据自然日查询，不做时间限制
//            if(!TextUtils.equals(type,ReportConsrance.NET_ORDER) && !TextUtils.equals(type,ReportConsrance.CHECK_BY_DAY)){
//                if(DateUtil.compareDate(currentBusinessDate,startDate,  "yyyy-MM-dd") > 0){
//                    response.code = SocketResultCode.BUSINESS_FAILED;
//                    response.message = "查询日期不能超过营业日期";
//                    return response;
//                }
//            }
        if (!hasReportSaveCompletely(currentBusinessDate, startDate, endDate)) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = "统计中...";
            return response;
        }
        //会员储值报表需要联网查询
        if(TextUtils.equals(type, ReportConsrance.REPORT_MEMBER_CHARGE) && !NetWorkUtil.isNetworkAvailable(GlobalCache.getContext())){
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = GlobalCache.getContext().getString(R.string.serr_error_noNet);
            return response;
        }
        Map<String, Object> htmlParams;
        if (newReport == 1 && TextUtils.equals(type, ReportConsrance.REPORT_SALE)) {
            TreeNode treeNode = JSON.parseObject(request.getString("treeNode"), TreeNode.class);
            if (treeNode == null) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "查询异常";
                return response;
            }
            htmlParams = querySaleNumData(treeNode, billType, accountBookId, menuSourceList,sellTypeList);
            htmlParams.put("newReport", newReport);
        } else {
            htmlParams = ReportProcessor.getReportData(shopGUID, startDate, endDate, type, "", billType, accountBookId, buildFilterData(menuSourceList), buildFilterData(sellTypeList));
            // 下面的代码在小易上会报内部异常错误
            if (!APPConfig.isAir(GlobalCache.getContext())) {
                //最高销售数量表按选择的排名来打印
                if (TextUtils.equals(ReportConsrance.REPORT_MAX_SALE_QUANTITY, type)) {
                    //排名数
                    int rank = request.getInteger("rank");
                    if (rank != 0 && htmlParams.containsKey("XSSL")) {
                        List<SaleStatisticsItemModel> data = (List<SaleStatisticsItemModel>) htmlParams.get("XSSL");
                        if (!ListUtil.isEmpty(data) && data.size() > rank) {
                            htmlParams.put("XSSL", data.subList(0, rank));
                        }
                        htmlParams.put("selectRank", "(TOP" + rank + ")");
                    }
                }
            }
        }

        htmlParams.put("fsshopname", DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsShopName from tbShop where fsShopGUID = '" + shopGUID + "'"));
        htmlParams.put("Businessdate", TextUtils.equals(startDate, endDate) ? startDate : startDate + "~~" + endDate);
        HashMap<String, Object> times = new HashMap<>();
        times.put("PrintTime", DateUtil.getCurrentTime());
        htmlParams.put("SysMode", times);
        //获取数据和模板合并的数据，若合并后数据不为空，则不使用原始数据
        resParams.htmlData = getHtmlData(JSON.toJSONString(htmlParams), type);
        if (TextUtils.isEmpty(resParams.htmlData)) {
            if (htmlParams != null) {
                resParams.htmlParams.putAll(htmlParams);
            }
        }
        //打印当日的日报表需要选版别
        if (TextUtils.equals(ReportConsrance.REPORT_DAILY, type) && TextUtils.equals(startDate, endDate) && TextUtils
                .equals(endDate, currentBusinessDate)) {
            resParams.shitList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where fiStatus='1' and fsShopGUID='" +
                    head.shopid + "'", ShiftDBModel.class);
        }

        response.code = SocketResultCode.SUCCESS;
        response.message = "获取报表信息成功";
        return response;

    }


    /**
     * 查询报表
     */
    @DrivenMethod(uri = TAG + "/queryReportHomeData")
    public SocketResponse queryReportHomeData(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        QueryReportHomeDataResponse reportHomeDataResponse = new QueryReportHomeDataResponse();
        response.data = reportHomeDataResponse;

        JSONObject request = JSON.parseObject(param);

        String type = request.getString("type");
        int billType = request.getInteger("billType");

        String currentBusinessDate = HostUtil.getHistoryBusineeDate("");
        HashMap<String, Object> homeData = DailyReportDBUtil.getReportHomeDBUtill(currentBusinessDate, "", billType);
        reportHomeDataResponse.data = homeData;
        response.code = SocketResultCode.SUCCESS;
        response.message = "获取表报首页数据成功";
        return response;

    }

    /**
     * 查询日结表时段数据
     */
    @DrivenMethod(uri = TAG + "/queryTbSellData")
    public SocketResponse queryTbSellData(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        QueryDailyTimeResponse dailyTimeResponse = new QueryDailyTimeResponse();
        response.data = dailyTimeResponse;
        JSONObject request = JSON.parseObject(param);
        String startDate = request.getString("startDate");
        String endDate = request.getString("endDate");
        String startTime = request.getString("startTime");
        String endTime = request.getString("endTime");
        int billtype = request.getInteger("billType");
        List<ReportCenterDailySell> result = DailyReportDBUtil.getTbSellData(startDate, endDate, startTime, endTime, "", billtype);
        dailyTimeResponse.data = result;
        response.code = SocketResultCode.SUCCESS;
        response.message = "获取表报首页数据成功";
        return response;
    }

//    /**
//     * 档口统计表
//     *
//     * @param shopGUID
//     * @param businessDate
//     * @param currentDate
//     * @return
//     */
//    public static Map<String, Object> queryDeptReport(String shopGUID, String businessDate, String currentDate) {
//        Map<String, Object> htmlParams = new HashMap<>();
//        if (TextUtils.equals(currentDate, businessDate)) {
//            htmlParams = DailyReportDBUtil.statisticDeptBalance(businessDate);
//        } else {
//            DailyReportDBModel reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, businessDate,
// ReportConsrance.REPORT_DEPT);
//            if (reportSale != null) {
//                htmlParams.putAll(JSON.parseObject(reportSale.value, Map.class));
//            }
//        }
//        return htmlParams;
//    }

//    /**
//     * 时段统计表
//     *
//     * @param shopGUID
//     * @param businessDate
//     * @param currentDate
//     * @return
//     */
//    public static Map<String, Object> queryTimeReport(String shopGUID, String businessDate, String currentDate) {
//        Map<String, Object> htmlParams = new HashMap<>();
//        if (TextUtils.equals(currentDate, businessDate)) {
//            htmlParams = DailyReportDBUtil.getTimeReportValue(businessDate);
//        } else {
//            DailyReportDBModel reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, businessDate,
// ReportConsrance.REPORT_TIME);
//            if (reportSale != null) {
//                htmlParams.putAll(JSON.parseObject(reportSale.value, Map.class));
//            }
//        }
//        return htmlParams;
//    }

//    /**
//     * 微信外卖
//     *
//     * @param shopGUID
//     * @param businessDate
//     * @param currentDate
//     * @return
//     */
//    public static Map<String, Object> queryWechatOrderReport(String shopGUID, String businessDate, String
// currentDate) {
//        Map<String, Object> htmlParams = new HashMap<>();
//        if (TextUtils.equals(currentDate, businessDate)) {
//            htmlParams = DailyReportDBUtil.getWechatOrderReport(businessDate);
//        } else {
//            DailyReportDBModel reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, businessDate,
// ReportConsrance.WECHAT_ORDE);
//            if (reportSale != null) {
//                htmlParams.putAll(JSON.parseObject(reportSale.value, Map.class));
//            }
//        }
//        return htmlParams;
//    }

    /**
     * 查询最高销售数量表
     *
     * @param shopGUID
     * @param businessDate
     * @param currentDate
     * @return
     */
    public Map<String, Object> queryMaxSaleQuantityReport(String shopGUID, String businessDate, String currentDate,
                                                          int billType, String accountBookId) {
        Map<String, Object> htmlParams = new HashMap<>();
        if (TextUtils.equals(currentDate, businessDate)) {
            htmlParams = DailyReportDBUtil.getStatisticMaxSaleQuantity(businessDate, billType, accountBookId);
        } else {
            DailyReportDBModel reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, businessDate,
                    ReportConsrance.REPORT_MAX_SALE_QUANTITY, billType, accountBookId);
            if (reportSale != null) {
                htmlParams.putAll(JSON.parseObject(reportSale.value, Map.class));
            }
        }
        return htmlParams;
    }

    /**
     * 查询最高销售金额表
     *
     * @param shopGUID
     * @param businessDate
     * @param currentDate
     * @return
     */
    public Map<String, Object> queryMaxSalePriceReport(String shopGUID, String businessDate, String currentDate,
                                                       int billType, String accountBookId) {
        Map<String, Object> htmlParams = new HashMap<>();
        if (TextUtils.equals(currentDate, businessDate)) {
            htmlParams = DailyReportDBUtil.getStatisticMaxSalePrice(businessDate, billType, accountBookId);
        } else {
            DailyReportDBModel reportSale = DailyReportDBUtil.queryReportHistory(shopGUID, businessDate,
                    ReportConsrance.REPORT_MAX_SALE_PRICE, billType, accountBookId);
            if (reportSale != null) {
                htmlParams.putAll(JSON.parseObject(reportSale.value, Map.class));
            }
        }
        return htmlParams;
    }

    /**
     * 根据权限ID匹配到符合条件的用户
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/unPrintTask")
    public SocketResponse unPrintTask(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            GetUnPrintTaskNoResponse response = new GetUnPrintTaskNoResponse();
            response.printTaskNoList = PrintTaskDBUtil.getUnPrintTaskNoList(head.hd);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "获取成功";
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;

    }

    /**
     * 更新打印任务状态
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/updatePrintTask")
    public SocketResponse updatePrintTask(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            UpdatePrintTaskResponse response = new UpdatePrintTaskResponse();
            String hostId = head.hd;
            int printNo = request.getInteger("printNo");

            //交给打印进程处理
            PrintConnector.getInstance().updateTask(hostId, printNo, JSON.toJSONString(request.getJSONObject
                    ("contentValuesHashMap")));

            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "获取成功";
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;

    }

    /**
     * 更新打印机状态
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/printer_status_update")
    public SocketResponse printerStatusUpdate(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String printerName = request.getString("printerName");
            int status = request.getInteger("status");
            if (status == 1) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fiPrinterStatus='" + status + "'," +
                        "switch_backup='0',fiTaskCount='0' where fsPrinterName='" + printerName + "'");
            } else {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrinter set fiPrinterStatus='" + status + "' " +
                        "where fsPrinterName='" + printerName + "'");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    /**
     * 获取小票模版的title列表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getTempletsTitleList")
    public SocketResponse getTempletsTitleList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            GetTempletsResponse response = new GetTempletsResponse();
            response.templetList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select publicT.fsTempletId,publicT" +
                    ".fsTempletKey,publicT.fsTempletName, privateT.fiSelected from " +
                    "tbPrintTempletPublic as publicT left join tbPrintTempletPrivate as privateT on publicT" +
                    ".fsTempletId= privateT.fsTempletId where publicT.fiStatus='1' and publicT.fiTempletType = '0' and publicT.fiMinSupportVersion <= " + BizConstant.VERSION_CODE + " order by publicT.fsTempletID " +
                    "desc", ReceiptTempletModel.class);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    @DrivenMethod(uri = "monitor/loadCurrentUsedTemplet")
    public SocketResponse loadCurrentUsedTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            GetUsedTempletsResponse response = new GetUsedTempletsResponse();
            JSONObject jsonObject = JSONObject.parseObject(param);
            String fsTempletKey = jsonObject.getString("fsTempletKey");
            PrintTempletPrivateDBModel printTempletPrivateDBModel = PrintTempletPrivateDBUtils.queryUsedTempletByTempletKey(fsTempletKey);
            //fixme 处理私有模版不存在情况
            if (printTempletPrivateDBModel == null) {
                socketResponse.message = "小票模版不存在，请同步数据";
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            response.receiptTempletModel = PrintTempletPrivateDBUtils.copyTo(printTempletPrivateDBModel);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "monitor/loadUpdateUsedTemplets")
    public SocketResponse loadUpdateUsedTemplets(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            GetUsedTempletsResponse response = new GetUsedTempletsResponse();
            JSONObject jsonObject = JSONObject.parseObject(param);
            String fsTempletId = jsonObject.getString("fsTempletId");
            if (!PrintTempletPrivateDBUtils.isExist(fsTempletId)) {
                socketResponse.message = "小票模版不存在，请同步数据";
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            PrintTempletPrivateDBUtils.updateUsedTempletById(fsTempletId);
            PrintTempletPrivateDBModel printTempletPrivateDBModel = PrintTempletPrivateDBUtils.queryById(fsTempletId);
            response.receiptTempletModel = PrintTempletPrivateDBUtils.copyTo(printTempletPrivateDBModel);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "monitor/loadUsedTempletsList")
    public SocketResponse loadUsedTempletsList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            GetUsedTempletTypeListResponse data = new GetUsedTempletTypeListResponse();
            data.templetUsedMap = PrintTempletPrivateDBUtils.queryTempletUsedMap();
            socketResponse.data = data;
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "查询成功";
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
        }
        return socketResponse;
    }

    /**
     * 获取指定的小票模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/useTargetTemplet")
    public SocketResponse useTargetTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetID = request.getString("templetID");

            PrintTempletPrivateDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "select fsTempletId," +
                            "fsTempletKey,fiSelected from tbPrintTempletPrivate where fsTempletId='" + templetID + "'",
                    PrintTempletPrivateDBModel.class);
            if (model == null) {
                PrintTempletPublicDBModel publicModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsTempletId='" +
                        templetID + "'", PrintTempletPublicDBModel.class);
                model = new PrintTempletPrivateDBModel();
                model.fiSelected = 1;
                model.fsShopGUID = ServerCache.getInstance().shopID;

                model.fiStatus = publicModel.fiStatus;
                model.fsCreateTime = publicModel.fsCreateTime;
                model.fsCreateUserId = publicModel.fsCreateUserId;
                model.fsCreateUserName = publicModel.fsCreateUserName;
                model.fsTempletFile = publicModel.fsTempletFile;
                model.fsTempletId = publicModel.fsTempletId;
                model.fsTempletKey = publicModel.fsTempletKey;
                model.fsTempletName = publicModel.fsTempletName;
                model.fsUpdateTime = publicModel.fsUpdateTime;
                model.fsUpdateUserId = publicModel.fsUpdateUserId;
                model.fsUpdateUserName = publicModel.fsUpdateUserName;
                model.fiTempletType = publicModel.fiTempletType;
                model.fiMinSupportVersion = publicModel.fiMinSupportVersion;
                model.replaceNoTrans();
                model.fiSelected = 0;
            }
            if (model.fiSelected == 0) {

                //小票模版如果是结账单-单序排序模版/预结单-单序排序模版，则要判断下是否开启了菜品合并开关
                if (TempletIdManager.isBill_2OrBill_4(templetID)) {
                    if (PayConfig.PRINT_COMBINE_DISHES) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = "您开启了菜品合并开关，不能使用此模版！";
                        return socketResponse;
                    }
                }
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrintTempletPrivate set fsupdatetime = '" +
                        DateUtil.getCurrentTime() + "',fiSelected='0',sync='1' where fsTempletKey='" + model
                        .fsTempletKey + "'");
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrintTempletPrivate set fsupdatetime = '" +
                        DateUtil.getCurrentTime() + "',fsSelectedTime = '" + DateUtil.getCurrentTime() + "',fiSelected='1',sync='1' where fsTempletId='" + model
                        .fsTempletId + "'");
            } else {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrintTempletPrivate set fsupdatetime = '" +
                        DateUtil.getCurrentTime() + "',fiSelected='0',sync='1' where fsTempletId='" + model
                        .fsTempletId + "'");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    /**
     * 获取指定的小票模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getTargetTemplet")
    public SocketResponse getTargetTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetID = request.getString("templetID");
            GetTempletsResponse response = new GetTempletsResponse();
            ReceiptTempletModel temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPrivate " +
                    "where fiStatus='1' and fsTempletId='" + templetID + "'", ReceiptTempletModel.class);
            if (temp == null) {
                temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPublic where fiStatus='1' " +
                        "and fsTempletId='" + templetID + "'", ReceiptTempletModel.class);
            } else {
                JSONObject data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, String.format
                        ("select fsTempletName,fsNote,fsTempletData from tbPrintTempletPublic where fiStatus='1' and fsTempletId='%s'", templetID));
                temp.fsNote = data.getString("fsNote");
                temp.templetName = data.getString("fsTempletName");
                temp.templeteData = JSON.parseObject(data.getString("fsTempletData"));
            }
            response.templetList = new ArrayList<>();
            response.templetList.add(temp);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    private ReceiptTempletModel getReceiptTempletModel(String templetId) {
        ReceiptTempletModel temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPrivate where fiStatus='1' and fsTempletId='" + templetId + "'", ReceiptTempletModel.class);
        if (temp == null) {
            temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPublic where fiStatus='1' and fsTempletId='" + templetId + "'", ReceiptTempletModel.class);
        }
        return temp;
    }

    /**
     * 获取指定的小票模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/resetTempletToOrigin")
    public SocketResponse resetTempletToOrigin(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetID = request.getString("templetID");
            GetTempletsResponse response = new GetTempletsResponse();
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrintTempletPrivate set fsupdatetime = '" + DateUtil
                    .getCurrentTime() + "', fsTempletFile=(select fsTempletFile from tbPrintTempletPublic where " +
                    "fiStatus='1' and fsTempletId='" + templetID + "') where fsTempletId='" + templetID + "'");
            ReceiptTempletModel temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPrivate " +
                    "where fiStatus='1' and fsTempletId='" + templetID + "'", ReceiptTempletModel.class);
            if (temp == null) {
                temp = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbPrintTempletPublic where fiStatus='1' " +
                        "and fsTempletId='" + templetID + "'", ReceiptTempletModel.class);
            } else {
                temp.templeteData = JSON.parseObject(DBSimpleUtil.queryString(APPConfig.DB_MAIN, String.format
                        ("select fstempletData from tbPrintTempletPublic where fiStatus='1' and fsTempletId='%s'",
                                templetID)));
            }
            response.templetList = new ArrayList<>();
            response.templetList.add(temp);
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    /**
     * 获取指定的小票模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/saveTemplet")
    public SocketResponse saveTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetID = request.getString("templetID");
            String templet = request.getString("templet");
            GetTempletsResponse response = new GetTempletsResponse();
            PrintTempletPrivateDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsTempletId='" +
                    templetID + "'", PrintTempletPrivateDBModel.class);
            if (model == null) {
                PrintTempletPublicDBModel publicModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "where fsTempletId='" +
                        templetID + "'", PrintTempletPublicDBModel.class);
                model = new PrintTempletPrivateDBModel();
                model.fiSelected = 0;
                model.fsShopGUID = ServerCache.getInstance().shopID;

                model.fiStatus = publicModel.fiStatus;
                model.fsCreateTime = publicModel.fsCreateTime;
                model.fsCreateUserId = publicModel.fsCreateUserId;
                model.fsCreateUserName = publicModel.fsCreateUserName;
                model.fsTempletFile = publicModel.fsTempletFile;
                model.fsTempletId = publicModel.fsTempletId;
                model.fsTempletKey = publicModel.fsTempletKey;
                model.fsTempletName = publicModel.fsTempletName;
                model.fsUpdateTime = publicModel.fsUpdateTime;
                model.fsUpdateUserId = publicModel.fsUpdateUserId;
                model.fsUpdateUserName = publicModel.fsUpdateUserName;
                model.fiMinSupportVersion = publicModel.fiMinSupportVersion;
                model.fiTempletType = publicModel.fiTempletType;

            }
            model.sync = 1;
            model.fsUpdateTime = DateUtil.getCurrentTime();
            List<JSONObject> list = JSON.parseArray(templet, JSONObject.class);
            JSONObject ob = new JSONObject();
            ob.put("templets", list);
            ob.put("templetID", templetID);
            model.fsTempletFile = JSON.toJSONString(ob);
            model.replaceNoTrans();
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }

        return socketResponse;
    }

    /**
     * 获取结账单小票数据
     *
     * @return SocketResponse
     */
    @DrivenMethod(uri = TAG + "/getOrderPrintData")
    public SocketResponse getOrderPrintData(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        final OrderPrintDataResponse response = new OrderPrintDataResponse();
        socketResponse.data = response;

        try {
            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                userDBModel = new UserDBModel();
            }
            JSONObject request = JSON.parseObject(params);
            String orderId = request.getString("orderId");
            String businessDate = request.getString("businessDate");
            String fiSellType = request.getString("fiSellType");
            String orderSource = request.getString("orderSource");
            String hostId = head.hd;

            //根据订单数据是否已经迁移到从库状态，获取此订单所在的数据库名称
            String databaseName = OrderDriver.getDatabaseName(orderSource, businessDate);
            //获取这笔订单的会员卡号
            String fsCardNo = DBSimpleUtil.queryString(databaseName, "select fsCardNo from tbSell where fsSellNo = '" + orderId + "'");

            MemberInfo memberInfo = null;

            if (!TextUtils.isEmpty(fsCardNo) && ServerSettingHelper.isBillPrintBalanceAndScore()) {
                memberInfo = MemberApi.queryMemberInfo(fsCardNo);
            }

            if (TextUtils.equals(fiSellType, "0")) {
                response.printerDBModel = PrintBillUtil.getDinnerBillData(orderId, memberInfo, "", hostId, false, userDBModel, databaseName);
            } else {
                response.printerDBModel = PrintBillUtil.getFastFoodBillData(orderId, memberInfo, hostId, userDBModel.fsUserName, databaseName);
            }
            //获取数据和模板合并的数据
            if (response.printerDBModel != null && !TextUtils.isEmpty(response.printerDBModel.fsPrnData)) {
                //client端后加的数据，移到业务中心来，加上后统一生成html数据
                String url = String.format("%s.html", response.printerDBModel.uri.replace("/", "_"));
                JSONObject map = JSON.parseObject(response.printerDBModel.fsPrnData);
                map.put("uri", url);
                map.put("fsReportName", response.printerDBModel.fsReportName);//下单部门
                map.put("print_type", String.format("重打", response.printerDBModel.fsReportName));
                map.put("fsCreateUserName", response.printerDBModel.fsCreateUserName);
                map.put("fsCreateTime", response.printerDBModel.fsCreateTime);
                response.htmlData = getHtmlData(response.printerDBModel.fsPrnData, response.printerDBModel.uri);
            }
            if (!TextUtils.isEmpty(response.htmlData)) {
                response.printerDBModel.fsPrnData = null;//已经有和模板合并的数据，就去掉原始数据，防止数据过多，socket发不过去。
            }

            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "系统异常";
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取打印监控的声音提示状态
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getPrintMonitorVideoHint")
    public SocketResponse getPrintMonitorVideoHint(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            socketResponse.data = new PrintMonitorVideoStatusResponse(isVideoHintOpen(DateUtil.getCurrentDate()));
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 更新打印监控的声音提示状态
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/updatePrintMonitorVideoHint")
    public SocketResponse updatePrintMonitorVideoHint(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String open = request.getString("isOpen");
            open = (!TextUtils.isEmpty(open) && TextUtils.equals("1", open)) ? "open" : DateUtil.getCurrentDate();
            String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select value from meta where key = '" + META
                    .PRINTMONITOR_VIDEOHINT_STATUS + "'");
            if (TextUtils.isEmpty(value)) {//空的，表示没有这条记录，就手动插入一条
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "replace into meta values('" + META
                        .PRINTMONITOR_VIDEOHINT_STATUS + "','" + open + "')");
            } else {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update meta set value = '" + open + "' where key = '" +
                        META.PRINTMONITOR_VIDEOHINT_STATUS + "'");
            }
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    public String getHtmlData(String printData, String templetId) {
        ReceiptTempletModel templetModel = getReceiptTempletModel(templetId);
        if (templetModel == null) {//没有模板，就使用原来的模式
            return null;
        }
        //TODO 将模板和数据合并返回数据
        return null;
    }

    private boolean isVideoHintOpen(String currentDate) {
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select value from meta where key = '" + META
                .PRINTMONITOR_VIDEOHINT_STATUS + "'");
        if (TextUtils.isEmpty(value)) {//空的，表示没有这条记录，就手动插入一条,默认开启
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "replace into meta values('" + META
                    .PRINTMONITOR_VIDEOHINT_STATUS + "','open')");
            return true;
        } else if (TextUtils.equals("open", value)) {//是开启的状态
            return true;
        } else {//关闭状态
            if (isDateOneBigger(currentDate, value)) {//当 当前时间-关闭时间 大于一天，则默认开启
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update meta set value = 'open' where key = '" + META
                        .PRINTMONITOR_VIDEOHINT_STATUS + "'");
                return true;
            }
            return false;
        }
    }

    private boolean isDateOneBigger(String cuurentDate, String oldDate) {
        boolean isBigger = false;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date dt1 = null;
        Date dt2 = null;
        try {
            dt1 = sdf.parse(cuurentDate);
            dt2 = sdf.parse(oldDate);
            if (dt1.getTime() > dt2.getTime()) {
                isBigger = true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return isBigger;
    }

    /**
     * 报表是否保存完全
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean hasReportSaveCompletely(String businessDate, String startDate, String
            endDate) {
        if (TextUtils.equals(businessDate, startDate) && TextUtils.equals(businessDate, endDate)) {
            return true;
        }

        String sql = "SELECT * FROM unfinish_task WHERE type = '11' AND finished = '0' AND biz_key >= '" + startDate + "' AND biz_key <= '" + endDate + "'";

        List<Job> dateArr = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, Job.class);
        if (ListUtil.isEmpty(dateArr)) {
            return true;
        }

        JobWorker worker = new JobWorker();
        Iterator<Job> it = dateArr.iterator();
        while (it.hasNext()) {
            Job job = it.next();
            if (TextUtils.equals(job.biz_key, businessDate)) {
                it.remove();
                continue;
            }
            BusinessExecutor.executeNoWait(() -> {
                worker.work(job);
                return null;
            });
        }
        return ListUtil.isEmpty(dateArr);
    }

    /**
     * 按分类查询销售数量表数据
     *
     * @return
     */
    public Map<String, Object> querySaleNumData(TreeNode treeNode, int billType, String accountBookId, String menuSourceList,String orderTypeList) {

        Map<String, Object> result = new HashMap<>();

        List<String> menuKinds = new ArrayList<>();
        //得到已选择的分类id以及它子类的分类id
        getselectedMenuKinds(menuKinds, treeNode, false);
        String businessDate = HostUtil.getHistoryBusineeDate("");
        String sourceIdList = buildFilterData(menuSourceList);
        String orderTypelist = buildFilterData(orderTypeList);
        //根据分类id列表查询数据
        Map<String, List<SalesAmountItemModel>> data = DailyReportDBUtil.querySaleNumData(businessDate, billType, accountBookId, menuKinds, sourceIdList, orderTypelist);
        if (data != null && data.size() > 0) {
            //根据树结构组建数据
            dealTreeData(treeNode, data);
            //过滤掉未选择分类层级
            result.put("XSSLNEW", filterDataLoop(null, treeNode.getChildren()).getChildren());
        }
        //销售数量表总合计
        result.put("HJ", DailyReportDBUtil.querySumSaleNum(businessDate, billType, accountBookId, menuKinds, sourceIdList, orderTypelist));
        result.put("OrderSource", DailyReportDBUtil.queryOrderSourceName(businessDate, billType, accountBookId, menuKinds, sourceIdList, orderTypelist));
        return result;
    }

    private String buildFilterData(String menuFilterList) {
        if (TextUtils.isEmpty(menuFilterList)) {
            return "";
        }
        List<TreeNode> sourceList = JSON.parseArray(menuFilterList, TreeNode.class);
        if (ListUtil.isEmpty(sourceList)) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (TreeNode treeNode : sourceList) {
            if (treeNode != null && !TextUtils.isEmpty(treeNode.getFsMenuClsId())) {
                builder.append("'").append(treeNode.getFsMenuClsId()).append("'").append(",");
            }
        }
        String result = builder.toString();
        if (!TextUtils.isEmpty(result) && result.length() > 1) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }

    /**
     * 递归遍历树，过滤掉未选择分类层级
     *
     * @param resultTreeNode
     * @param tempNodeList
     * @return
     */
    private TreeNode filterDataLoop(TreeNode resultTreeNode, List<TreeNode> tempNodeList) {
        //新树结构的根节点
        if (resultTreeNode == null) {
            resultTreeNode = TreeNode.root();
        }
        for (TreeNode treeNode : tempNodeList) {
            if (treeNode != null) {
                //当此节点是选中则添加到新树结构
                if (treeNode.isSelected()) {
                    TreeNode newTreeNode = treeNode.clone();
                    resultTreeNode.addChildNode(newTreeNode);
                    filterDataLoop(newTreeNode, treeNode.getChildren());
                } else {
                    filterDataLoop(resultTreeNode, treeNode.getChildren());
                }
            }
        }
        return resultTreeNode;
    }

    /**
     * 递归遍历树，根据树结构组建数据
     * 逻辑：判断节点是否被选中，若选中，则构建此节点的数据，若没有，则将此节点的数据往上抛，由父节点处理
     *
     * @param treeNode
     * @param originData
     * @return
     */
    private List<SalesAmountItemModel> dealTreeData(TreeNode treeNode, Map<String, List<SalesAmountItemModel>> originData) {

        if (treeNode == null || originData == null || originData.size() <= 0) {
            return null;
        }
        //节点数据list
        List<SalesAmountItemModel> nodeData = new ArrayList<>();

        //递归遍历子节点
        if (!ListUtil.isEmpty(treeNode.getChildren())) {
            for (TreeNode tempNode : treeNode.getChildren()) {
                //将子节点抛的数据加入集合
                List<SalesAmountItemModel> childData = dealTreeData(tempNode, originData);
                if (!ListUtil.isEmpty(childData)) {
                    nodeData.addAll(childData);
                }
            }
        }
        //得到当前节点的数据
        List<SalesAmountItemModel> saleOriginData = originData.get(treeNode.getFsMenuClsId());
        if (!ListUtil.isEmpty(saleOriginData)) {
            nodeData.addAll(saleOriginData);
        }
        //判断当前节点是否被选中，若选中，则构建此节点的数据，若没有，则将此节点的数据往上抛，由父节点处理
        if (treeNode.isSelected()) {
            treeNode.setSalesAmountClsHJ(DailyReportDBUtil.getSalesAmountClsHJModel(nodeData));
            treeNode.setSalesAmountItem(bindNodeData(nodeData, treeNode.getSalesAmountClsHJ().fdsaleamt));
        }
        //不管是否选中都将数据返回父节点，是为了让父节点可以计算数量和合计
        return nodeData;
    }

    /**
     * 构建节点数据，从总数据中选择未绑定的数据
     *
     * @param salesAmountItemModels
     * @param allAmt
     * @return
     */
    private List<SalesAmountItemModel> bindNodeData(List<SalesAmountItemModel> salesAmountItemModels, BigDecimal allAmt) {
        if (allAmt == null || allAmt.compareTo(BigDecimal.ZERO) <= 0) {
            return salesAmountItemModels;
        }
        List<SalesAmountItemModel> result = new ArrayList<>();
        BigDecimal bfSum = BigDecimal.ZERO;
        for (int i = 0; i < salesAmountItemModels.size(); i++) {
            SalesAmountItemModel salesAmountItemModel = salesAmountItemModels.get(i);
            //若此数据未绑定，则绑定到此被选中的节点上
            if (!salesAmountItemModel.mDataBinded) {
                if (i == salesAmountItemModels.size() - 1) {
                    salesAmountItemModel.BF = BizConstant.HUNDREND.subtract(bfSum);
                } else {
                    salesAmountItemModel.BF = (salesAmountItemModel.fdsaleamt.multiply(BizConstant.HUNDREND)).divide(allAmt,
                            2, BigDecimal.ROUND_DOWN);
                    bfSum = bfSum.add(salesAmountItemModel.BF);
                }
                salesAmountItemModel.mDataBinded = true;
                result.add(salesAmountItemModel);
            }
        }
        return result;
    }

    /**
     * 得到已选择的分类id以及它子类的分类id
     *
     * @param menuKinds
     * @param treeNode
     * @param isParentSelected
     */
    private void getselectedMenuKinds(List<String> menuKinds, TreeNode treeNode, boolean isParentSelected) {
        if (menuKinds == null) {
            menuKinds = new ArrayList<>();
        }
        if (treeNode != null) {
            //若此节点是被选中状态或父节点是选中状态，则分类id加入集合
            isParentSelected = isParentSelected || treeNode.isSelected();
            if (isParentSelected) {
                menuKinds.add(treeNode.getFsMenuClsId());
            }
            //递归遍历子节点
            if (!ListUtil.isEmpty(treeNode.getChildren())) {
                for (TreeNode tempNode : treeNode.getChildren()) {
                    getselectedMenuKinds(menuKinds, tempNode, isParentSelected);
                }
            }
        }
    }

    @DrivenMethod(uri = "monitor/modifyHttpChunk")
    public void modifyHttpChunk(String length) {
        DBMetaUtil.updateSettingsValueByKey(META.HTTP_CHUNK_LENGTH, length);
        APPConfig.refreshChunkLen();
    }

    @DrivenMethod(uri = "monitor/getBillSourceList")
    public SocketResponse getOrderSourceList(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        GetOrderSourceListResponse result = new GetOrderSourceListResponse();
        response.data = result;
        try {
            JSONObject request = JSON.parseObject(param);

            int billType = request.getInteger("billType");
            String accountBookId = request.getString("accountBookId");
            String date = request.getString("businessDate");

            String billParam = "";
            if (APPConfig.isMyd()) {
                billParam = " and fsAccountBook like '%," + accountBookId + ",%' ";
            } else {
                billParam = billType == 0 ? "" : " and fiSelected = '0' ";
            }
            String sql = "select * from tbBillSource where fiStatus <> '13' and fsBillSourceId in (select fsBillSourceId from tbSell where fsSellDate = '" + date + "' and fiBillStatus = '3' " + billParam + " group by fsBillSourceId )";

            result.sourceList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, BillSourceDBModel.class);
            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = e.getMessage();
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 获取小票模版的列表
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getTempletsList")
    public SocketResponse getTempletsList(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();

        try {
            GetTempletsResponse response = new GetTempletsResponse();
            //获取tbPrintTempletPublic表的默认第一个小票名称，key，和tbPrintTempletPrivate表的选中状态
            String sql = "select a.fsTempletKey, fsTempletName, fiSelected from (" +
                    "select fsTempletKey, fsTempletName from (select fsTempletKey, fsTempletName from tbPrintTempletPublic where fiStatus='1' and fiTempletType = '0' and fiMinSupportVersion <= '" + BizConstant.VERSION_CODE + "' order by fsTempletId desc) group by fsTempletKey" +
                    ") a left join (select fsTempletKey, fiSelected from tbPrintTempletPrivate where fiSelected = '1' group by fsTempletKey) b on a.fsTempletKey = b.fsTempletKey group by a.fsTempletKey order by a.fsTempletKey desc";

            response.templetList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ReceiptTempletModel.class);

            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 开启或关闭使用小票
     * 开启，如果上次选过模版，则开启上次使用模版，否则默认开启第一个模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/selectTemplet")
    public SocketResponse selectTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        try {
            String templetKey = request.getString("templetKey");
            //找到是否有选中的模版，如果有，则关闭选择
            String sql = "select fsTempletId from tbPrintTempletPrivate where fiSelected = '1' and fsTempletkey = '" + templetKey + "'";
            String templetId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
            //关闭此模版
            if (!TextUtils.isEmpty(templetId)) {
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update tbPrintTempletPrivate set fsupdatetime = '" +
                        DateUtil.getCurrentTime() + "',fiSelected='0',sync='1' where fsTempletId='" + templetId + "'");
            } else {
                //开启，如果上次选过模版，则开启上次使用模版，否则默认开启第一个模版
                sql = "select fsTempletKey, fsTempletId as templetID from tbPrintTempletPrivate where fsTempletKey = '" + templetKey + "' and fsSelectedTime != '' order by fsSelectedTime desc";
                //此sql查出是个按fsSelectedTime降序排序的列表，默认取第一个，fsSelectedTime是最后一个选中修改时间
                JSONObject data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
                //如果fsSelectedTime没值，则默认取第一个模版
                if (data == null || data.size() == 0) {
                    sql = "select fsTempletKey, fsTempletId as templetID from (select fsTempletKey, fsTempletId from tbPrintTempletPublic where fsTempletKey = '" + templetKey + "' and fiStatus='1' and fiTempletType = '0' and fiMinSupportVersion <= '" + BizConstant.VERSION_CODE + "' order by fsTempletId desc) a group by fsTempletKey";
                    data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
                }
                if (data == null || data.size() == 0) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "没找到对应的小票模版";
                    return socketResponse;
                }
                socketResponse = useTargetTemplet(head, data.toJSONString());
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取同一小票的所有模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getSameTemplets")
    public SocketResponse getSameTemplets(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetKey = request.getString("templetKey");

            GetTempletsResponse response = new GetTempletsResponse();
            response.templetList = new ArrayList<>();

            String sql = "select fsTempletId  from tbPrintTempletPublic where fsTempletKey = '" + templetKey + "' and fiStatus='1' and fiTempletType = '0' and fiMinSupportVersion <= '" + BizConstant.VERSION_CODE + "' order by fsTempletId";

            List<String> templetIDs = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);

            if (ListUtil.isEmpty(templetIDs)) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没找到对应的小票模版";
                return socketResponse;
            }
            for (String templetID : templetIDs) {
                JSONObject tempParam = new JSONObject();
                tempParam.put("templetID", templetID);
                SocketResponse tempResponse = getTargetTemplet(head, tempParam.toJSONString());
                if (tempResponse.code == SocketResultCode.SUCCESS && tempResponse.data != null) {
                    response.templetList.addAll(((GetTempletsResponse) tempResponse.data).templetList);
                }
            }
            socketResponse.data = response;
            socketResponse.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 获取选中的小票模版数据
     * 如果没有选中的小票，则获取默认第一个模版
     *
     * @param head  SocketHeader
     * @param param String
     * @return SocketResponse
     */
    @DrivenMethod(uri = "monitor/getSelectedTemplet")
    public SocketResponse getSelectedTemplet(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        try {
            String templetKey = request.getString("templetKey");
            //获取选中的小票模版数据
            String sql = "select fsTempletId as templetID from tbPrintTempletPrivate where fiSelected = '1' and fsTempletkey = '" + templetKey + "'";
            JSONObject data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
            //如果没有选中的小票，则获取默认第一个模版
            if (data == null || data.size() == 0) {
                sql = "select fsTempletKey, fsTempletId as templetID from (select fsTempletKey, fsTempletId from tbPrintTempletPublic where fsTempletKey = '" + templetKey + "' and fiStatus='1' and fiTempletType = '0' and fiMinSupportVersion <= '" + BizConstant.VERSION_CODE + "' order by fsTempletId desc) a group by fsTempletKey";
                data = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, sql);
            }
            if (data == null || data.size() == 0) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = "没找到对应的小票模版";
                return socketResponse;
            }
            socketResponse = getTargetTemplet(head, data.toJSONString());
            //同一小票的可用模版个数
            if (socketResponse.code == SocketResultCode.SUCCESS) {
                String countSql = "select count(*) from tbPrintTempletPublic where fsTempletKey = '" + templetKey + "' and fiStatus='1' and fiTempletType = '0' and fiMinSupportVersion <= '" + BizConstant.VERSION_CODE + "'";
                ((GetTempletsResponse) socketResponse.data).templetCount = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, countSql), 0);
            }
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = e.getMessage();
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "monitor/getSalesTargetReport")
    public SocketResponse getSalesTargetReport(SocketHeader head, String params) {
        SocketResponse socketResponse = new SocketResponse();
        SalesTargetReportResponse response = new SalesTargetReportResponse();
        socketResponse.data = response;
        List<SectionInComeInfoMode> sectionInComeInfoModeList = response.timeSlotInComeInfoList;
        try {
            //获取当前营业日期
            String businessData = HostUtil.getHistoryBusineeDate(head.shopid);
            //获取当前营业日的所有订单数据
            StringBuilder builder = new StringBuilder();
            builder.append("select fiSellType, fdRealAmt, fdOriginalAmt, fiCustSum, fiBillStatus, fsSellNo,  fsMSectionId from tbSell where fiBillStatus in ('1','2','3','4') and fsSellDate=");
            builder.append("'").append(businessData).append("'");
            String sellSql = builder.toString();
            List<SellDBModel> sellDBModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sellSql, SellDBModel.class);
            if (sellDBModelList == null) {
                sellDBModelList = new ArrayList<>();
            }
            //查询桌台数和餐位数
            int tableNumber = 0;
            int seatNumber = 0;
            String tableSql = "select count(*) as counts, SUM(fiSeats) sumSeat from  tbmTable where fiStatus = 1;";
            JSONObject tableData = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, tableSql);
            if (tableData != null && !tableData.isEmpty()) {
                tableNumber = tableData.getIntValue("counts");
                seatNumber =tableData.getIntValue("sumSeat");
            }
            //查询餐段名称
            String sql = "select fsMSectionId, fsMSectionName from tbmsection where fiStatus=1 order by fsBeginTime;";
            List<JSONObject> sectionList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, sql);
            if (sectionList != null && !sectionList.isEmpty()) {
                for (JSONObject jo : sectionList) {
                    SectionInComeInfoMode mode = new SectionInComeInfoMode();
                    mode.fsMSectionId = jo.getString("fsMSectionId");
                    mode.fsMSectionName = jo.getString("fsMSectionName");
                    mode.tableNum = tableNumber;
                    mode.chairNum = seatNumber;
                    sectionInComeInfoModeList.add(mode);
                }
            }
            //全天餐段(固定)
            SectionInComeInfoMode allTodayMode = new SectionInComeInfoMode();
            allTodayMode.fsMSectionName = "全天";
            allTodayMode.tableNum = tableNumber;
            allTodayMode.chairNum = seatNumber;
            //查询已结菜品数量
            StringBuffer sqlBuffer = new StringBuffer();
            sqlBuffer.append("select fsMSectionId, SUM(CASE fiIsEditQty WHEN 0 THEN (fdSaleQty - fdBackQty) ")
                    .append("WHEN 1  THEN (CASE  fdBackQty WHEN 0 THEN 1 END) END) as sumItemNum ")
                    .append("from tbSellOrderItem where fsSellNo in (select fsSellNo from tbSell where fiBillStatus='3' and fiSellType !='2' and fsSellDate=")
                    .append("'").append(businessData).append("'").append(")").append(" group by tbSellOrderItem.fsMSectionId");
            String itemSql = sqlBuffer.toString();
            List<JSONObject> itemNumDataList = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, itemSql);
            //所有已结菜品数量
            int sumItemNum = 0;
            //将已结菜品数据放入各餐段对象中
            if (itemNumDataList != null && !itemNumDataList.isEmpty()) {
                for (JSONObject jo : itemNumDataList) {
                    String sectionId = jo.getString("fsMSectionId");
                    int num = jo.getIntValue("sumItemNum");
                    sumItemNum += num;
                    for (SectionInComeInfoMode section : sectionInComeInfoModeList) {
                        if (TextUtils.equals(section.fsMSectionId, sectionId)) {
                            section.sellOrderItemAccountNum = num;
                            break;
                        }
                    }
                }
            }
            allTodayMode.sellOrderItemAccountNum = sumItemNum;
            //将订单按餐段时间组装数据
            Map<String, List<SellDBModel>> sellMap = packSellOrderBySection(sellDBModelList, response);
            //全天餐段数据计算
            List<SellDBModel> filterList = new ArrayList<>();
            for (SellDBModel sd : sellDBModelList) {
                //过滤掉外卖单
                if (sd.fiselltype == 2) {
                    continue;
                }
                filterList.add(sd);
            }
            calculateSectionData(filterList, allTodayMode);
            //其他有效餐段数据计算
            for (SectionInComeInfoMode si : sectionInComeInfoModeList) {
                List<SellDBModel> curSellList = null;
                if (sellMap.containsKey(si.fsMSectionId)) {
                    curSellList = sellMap.get(si.fsMSectionId);
                } else {
                    curSellList = new ArrayList<>();
                }
                calculateSectionData(curSellList, si);
            }
            //固定餐段全天放入集合
            sectionInComeInfoModeList.add(0, allTodayMode);

        } catch (Exception ex) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = ex.getMessage();
            LogUtil.logError(ex);
        }
        return socketResponse;
    }

    /**
     *
     * @param sellDBModelList 营业时间的所有订单集合
     * @param response
     * @return
     */
    private Map<String, List<SellDBModel>> packSellOrderBySection(List<SellDBModel> sellDBModelList, SalesTargetReportResponse response) {
        //将集合转换成map,同时计算全天堂食，外卖收入相关数据
        Map<String, List<SellDBModel>> sellMap = new HashMap<>();
        for (SellDBModel sd : sellDBModelList) {
            if (sd.fiBillStatus == OrderStatus.PAIED) {
                //外卖
                if (sd.fiselltype == 2) {
                    response.takeOutInComeAmount = response.takeOutInComeAmount.add(sd.fdRealAmt);
                } else {
                    response.inStoreInComeAmount = response.inStoreInComeAmount.add(sd.fdRealAmt);
                }
            }
            if (sd.fiselltype == 2) {
                continue;
            }
            if (sellMap.containsKey(sd.fsMSectionId)) {
                sellMap.get(sd.fsMSectionId).add(sd);
            } else {
                List<SellDBModel> sellList = new ArrayList<>();
                sellList.add(sd);
                sellMap.put(sd.fsMSectionId, sellList);
            }
        }
        return sellMap;
    }

    /**
     * 计算各餐段数据
     * @param sellDBModelList 当前餐段订单集合
     * @param sectionMode 当前餐段
     */
    private void calculateSectionData(List<SellDBModel> sellDBModelList, SectionInComeInfoMode sectionMode) {
        //总订单数
        sectionMode.sellNum = sellDBModelList.size();
        for (SellDBModel sd : sellDBModelList) {
            if (sd.fiBillStatus == OrderStatus.PAIED) {
                //已结金额
                sectionMode.sellAccountAmount = sectionMode.sellAccountAmount.add(sd.fdRealAmt);
                //已结订单人数
                sectionMode.sellAccountCustomer += sd.fiCustSum;
                //已结订单数
                sectionMode.sellAccountNum += 1;

                //桌台单
                if (sd.fiselltype == 0) {
                    //已结桌台订单数
                    sectionMode.tableSellAccountNum += 1;
                    //已结桌台订单人数
                    sectionMode.tableSellAccountCustomer += sd.fiCustSum;
                }
            } else {
                //未结金额
                sectionMode.sellUnAccountAmount =  sectionMode.sellUnAccountAmount.add(sd.fdOriginalAmt);
                //未结算订单数
                sectionMode.sellNoAccountNum += 1;
            }
        }
        //单均价 = 已结金额/已结订单数
        if (sectionMode.sellAccountNum != 0) {
            sectionMode.averagePriceBySell =
                    sectionMode.sellAccountAmount.divide(new BigDecimal(sectionMode.sellAccountNum), 2, RoundingMode.HALF_UP);
        }
        //人均价 = 已结金额/已结订单人数
        if (sectionMode.sellAccountCustomer != 0) {
            sectionMode.averagePriceByCustomer =
                    sectionMode.sellAccountAmount.divide(new BigDecimal(sectionMode.sellAccountCustomer), 2, RoundingMode.HALF_UP);
        }
        //开台率 = 已结桌台订单数/桌台数
        if (sectionMode.tableNum != 0) {
            sectionMode.openTableRate =
                    new BigDecimal(sectionMode.tableSellAccountNum).divide(new BigDecimal(sectionMode.tableNum), 2, RoundingMode.HALF_UP);
        }
        //上座率 = 已结桌台订单人数/餐位数
        if (sectionMode.chairNum != 0) {
            sectionMode.tableAttendanceRate =
                    new BigDecimal(sectionMode.tableSellAccountCustomer).divide(new BigDecimal(sectionMode.chairNum), 2, RoundingMode.HALF_UP);
        }
        //客品率 = 已结订单菜品总数 / 已结订单人数
        if (sectionMode.sellAccountCustomer != 0) {
            sectionMode.customerOrderItemRate =
                    new BigDecimal(sectionMode.sellOrderItemAccountNum).divide(new BigDecimal(sectionMode.sellAccountCustomer), 2, RoundingMode.HALF_UP);
        }
    }

    @DrivenMethod(uri = "monitor/getSalesTarget")
    public SocketResponse getSaleTarget(SocketHeader head, String param) {
        final SocketResponse socketResponse = new SocketResponse();
        QuerySalesTargetResponse response = new QuerySalesTargetResponse();
        socketResponse.data = response;
        try {
            JSONObject jsonObject = JSON.parseObject(param);
            String userId = jsonObject.getString("userId");
            String value = DataCacheDBUtil.getSalesTarget();
            response.salesTarget = value;
            //快速查看沽清权限
            response.soldOutPermission = Permission.hasPermissionDinner(userId, Permission.DINNER_bnSetQty);
            //查看销售统计权限
            response.salesTargetPermission = Permission.hasPermissionDinner(userId, Permission.SALES_TARGET);
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "查询成功";
        } catch (Exception ex) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(ex);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "monitor/getFilterDataList")
    public SocketResponse getFilterDataList(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        GetOrderFilterDataListResponse result = new GetOrderFilterDataListResponse();
        response.data = result;
        try {
            JSONObject request = JSON.parseObject(param);

            int billType = request.getInteger("billType");
            String date = request.getString("businessDate");
            int queryType = request.getInteger("queryType"); //  0：所有数据   1：订单来源  2：订单类型
            String sql;


            if (queryType == 0 || queryType == 1) {
                sql = "select * from tbBillSource where fiStatus <> '13' and fsBillSourceId in (select fsBillSourceId from tbSell where fsSellDate = '" + date + "' and fiBillStatus = '3' " + (billType == 0 ? "" : " and fiSelected = '0' ") + " group by fsBillSourceId )";
                result.sourceList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, BillSourceDBModel.class);
            }

            if (queryType == 0 || queryType == 2) {
                SellType sellType;
                result.sellTypesList = new ArrayList<>();
                sql = "select fiSellType from tbSell where fsSellDate = '" + date + "' and fiBillStatus = '3' " + (billType == 0 ? "" : " and fiSelected = '0'") +
                        " group by fiSellType";
                Cursor cursor = DbUtil.query(APPConfig.DB_MAIN, sql);
                if (null != cursor) {
                    while (cursor.moveToNext()) {
                        sellType = new SellType();
                        sellType.setSellType(cursor.getInt(0));
                        switch (sellType.getSellType()) {
                            case 0:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.dinner));
                                break;
                            case 1:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.snack));
                                break;
                            case 2:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.takeout));
                                break;
                            case 3:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.only_cashier));
                                break;
                            case 4:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.kb_pre_order));
                                break;
                            default:
                                sellType.setSellTypeName(GlobalCache.getContext().getString(R.string.other));
                        }
                        result.sellTypesList.add(sellType);
                    }
                }
            }

            response.code = SocketResultCode.SUCCESS;
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = e.getMessage();
            LogUtil.logError(e);
        }
        return response;
    }

    /**
     * 更新今日营业目标
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "monitor/saveSalesTarget")
    public SocketResponse saveSaleTarget(SocketHeader head, String param) {
        final SocketResponse socketResponse = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            String value = request.getString("salesTarget");
            //更新数据库
            DataCacheDBUtil.saveSalesTarget(value);
            //更新业务中心内存数据
            ServerCache.getInstance().salesTarget = value;
            //发送刷新桌台数据广播，通知其他站点刷新今日营业目标值
            NotifyToClient.refreshTableOrOrders();
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.message = "更新成功";
        } catch (Exception ex) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            LogUtil.logError(ex);
        }
        return socketResponse;
    }

    /**
     * 打印销售统计表
     * @param header
     * @param params
     * @return
     */
    @DrivenMethod(uri = "monitor/printSalesTarget")
    public SocketResponse printSalesTarget(SocketHeader header, String params) {
        SocketResponse socketResponse = new SocketResponse();
        PrintSalesTargetResponse response = new PrintSalesTargetResponse();
        socketResponse.data = response;
        try {
            JSONObject request = JSON.parseObject(params);
            String printParams = request.getString("params");
            Type type = new TypeToken<Map<String, Object>>(){}.getType();
            Map<String, Object> paramsMap = new Gson().fromJson(params, type);
            Map<String, Object> resultMap = new HashMap<>();
            for (Map.Entry<String, Object> entry : paramsMap.entrySet()) {
                Map<String, Object> map = (Map<String, Object>) entry.getValue();
                resultMap.putAll(map);
            }
            List<Integer> printNoList = PrintReportUtil.printSalesTarget(header.hd, HostUtil.getHistoryBusineeDate(""), resultMap);
            if (!ListUtil.isEmpty(printNoList)) {
                response.printNoList.addAll(printNoList);
            }
            socketResponse.code = SocketResultCode.SUCCESS;
            socketResponse.data = response;
        } catch (Exception e) {
            LogUtil.logError(e);
            socketResponse.code = SocketResultCode.EXCEPTION;
            socketResponse.message = "系统异常";
        }
        return socketResponse;
    }
}
