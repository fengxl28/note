package com.mwee.myd.server.business.login;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.business.login.entity.AccountService;
import com.mwee.myd.server.business.login.entity.LoginPDModel;
import com.mwee.myd.server.business.login.entity.LoginPDRequest;
import com.mwee.myd.server.business.login.entity.LoginPDResponse;
import com.mwee.myd.server.business.login.entity.UploadXmppStateRequest;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * LoginApi
 */
public class LoginApi {

    public static void doLogin(final String account, String password, BusinessCallback callback) {
        LoginPDRequest pdRequest = getLoginPDRequest(account, password);
        BusinessExecutor.execute(pdRequest, null, callback);
    }

    public static void postState(String state) {
        UploadXmppStateRequest postRequest = getLoginPostRequest(state);
        BusinessExecutor.execute(postRequest, null, null, true);
    }

    private static void parseService(LoginPDResponse response) {
        LoginPDModel model = null;
        try {
            model = JSON.parseObject(response.data, LoginPDModel.class);
        } catch (Exception ex) {
            LogUtil.logError(ex);
        }
        if (model == null) {
            return;
        }

        AccountService service = new AccountService();
        for (int s : model.Services) {
            //商户开通服务
            for (int p : model.PopedomInfo) {
                //分店账号权限（分店开通服务）

                // 排队
                if (s == 1 && p == 1) {
                    service.bQueueEn = true;
                }
                if (s == 2 && p == 2) {//菜单
                    service.bDishEn = true;
                }
                if (s == 6 && p == 6) {
                    // 预订
                    service.bBookEn = true;
                }
                if (s == 8 && p == 8) {
                    service.pay = true;
                }
                if (s == 12 && p == 12) {//卡券功能
                    service.bCouponEn = true;
                }
                if (s == 13 && p == 13) {//收款
                    service.bCashEn = true;
                }
                if (s == 14 && p == 14) {//弹幕
                    service.bDanmuEn = true;
                }
                if (s == 15 && p == 15 && service.bQueueEn) {//预约取号 依赖排队
                    service.bPreOrderEn = true;
                }
                if (s == 17 && p == 17) {
                    service.member = true;
                }
                if (s == 18 && p == 18) {
                    service.bTableSearch = true;
                }
                if (s == 20 && p == 20) {
                    service.dianCai = true;
                }
            }
            if (s == 10)// 预点单打印
            {
                service.bOrderEn = true;
            }
        }
//        SessionCache.getInstance().setServicePermission(service);
    }

    private static LoginPDRequest getLoginPDRequest(String account, String password) {
        LoginPDRequest pdRequest = new LoginPDRequest();
        pdRequest.UserName = account;
        pdRequest.Password = md5("SMARTSCENE" + password);
        pdRequest.DeviceID = ServerHardwareUtil.getHardWareSymbol();
        pdRequest.appType = String.valueOf(APPConfig.getShopType());
        pdRequest.AP = accessAp(GlobalCache.getContext(), true) + "(P:SER)" + String.format("(%s)", android.os.Build.MODEL);
        pdRequest.V = BizConstant.VERSION_CODE;
        pdRequest.apiVersion = "V5";
        pdRequest.token = "";
        return pdRequest;
    }

    //获取post请求的request
    private static UploadXmppStateRequest getLoginPostRequest(String state) {
        UploadXmppStateRequest postRequest = new UploadXmppStateRequest();
        postRequest.state = state;

        return postRequest;
    }

    private static final String HEXES = "0123456789abcdef";

    public static String md5(String data) {
        if (TextUtils.isEmpty(data))
            return "";
        MessageDigest engine = null;
        try {
            engine = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        byte[] digest = engine.digest(data.getBytes());
        StringBuffer hexBuilder = new StringBuffer(digest.length * 2);
        for (final byte b : digest) {
            hexBuilder.append(HEXES.charAt((b & 0xf0) >> 4)).append(
                    HEXES.charAt((b & 0x0f)));
        }
        return hexBuilder.toString();
    }

    public static String accessAp(Context context, boolean url) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null && wifiManager.isWifiEnabled()) {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            if (null != wifiInfo && wifiInfo.getNetworkId() >= 0) {
                String SSID = wifiInfo.getSSID();
                if (SSID != null) {
                    if (url) {
                        String strApInfo = SSID.replace(' ', '_');// 简单替换，否则要用urlencode
                        String strBssId = wifiInfo.getBSSID();
                        if (strBssId != null) {
                            strApInfo += String.format("[%s]", strBssId);
                        }
                        return strApInfo;
                    } else {
                        return SSID;
                    }
                }
            }
        }
        return "";
    }
}
