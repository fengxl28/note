package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.base.BizInfoCollect;
import com.mwee.android.pos.business.member.MemberCouponResponse;
import com.mwee.android.pos.business.member.entity.BalanceOrderList;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.business.member.entity.MemberHistoryResponse;
import com.mwee.android.pos.business.netpay.NetPayUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberApi;
import com.mwee.android.pos.component.member.net.GetMemberRechargeOrderResponse;
import com.mwee.android.pos.component.member.net.GetMemberRechargePackageResponse;
import com.mwee.android.pos.component.member.net.model.FoodInfoModel;
import com.mwee.android.pos.component.member.net.model.MemberCouponConsumeData;
import com.mwee.android.pos.component.member.net.model.MemberCouponConsumeModel;
import com.mwee.android.pos.component.member.net.model.QueryNewMembeChargeResultModel;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponConsumeRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponConsumeResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponGetRequest;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponGetResponse;
import com.mwee.android.pos.component.member.newInterface.net.MemberCouponRefundResponse;
import com.mwee.android.pos.connect.business.bean.NewMemberRechargResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import cn.mwee.android.pay.infocollect.InfoCollect;

@SuppressWarnings("unused")
public class MemberDriver implements IDriver {

    private static final String TAG = "memberDriver";

    @DrivenMethod(uri = TAG + "/loadMemberConfig")
    public SocketResponse loadMemberConfig(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String shopID = request.getString("shopID");
            String mShopID = request.getString("mShopID");

            MemberApi.loadMemberConfig(shopID, mShopID, new IResponse<MemberConfig>() {
                @Override
                public void callBack(boolean result, int code, String msg, MemberConfig info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberHistoryScore")
    public SocketResponse loadMemberHistoryScore(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String cardNo = request.getString("cardNo");
            int lastID = request.getInteger("lastID");

            MemberApi.loadMemberHistoryScore(cardNo, lastID, new IResponse<MemberHistoryResponse>() {
                @Override
                public void callBack(boolean result, int code, String msg, MemberHistoryResponse info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberBalanceChangedData")
    public SocketResponse loadMemberBalanceChangedData(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String cardNo = request.getString("cardNo");
            String lastID = request.getString("lastID");
            int limit = request.getInteger("limit");

            MemberApi.loadMemberBalanceChangedData(cardNo, lastID, limit, new IResponse<BalanceOrderList>() {
                @Override
                public void callBack(boolean result, int code, String msg, BalanceOrderList info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberRechargePackage")
    public SocketResponse loadMemberRechargePackage(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String csID = request.getString("csID");
            String version = request.getString("version");

            MemberApi.loadMemberRechargePackage(csID, version, new IResponse<GetMemberRechargePackageResponse>() {
                @Override
                public void callBack(boolean result, int code, String msg, GetMemberRechargePackageResponse info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberCoupons")
    public SocketResponse loadMemberCoupons(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String shopID = request.getString("shopID");
            String mShopID = request.getString("mShopID");
            String cardNo = request.getString("cardNo");
            int page = request.getInteger("page");
            int pageSize = request.getInteger("pageSize");

            MemberApi.loadMemberCoupons(shopID, mShopID, cardNo, page, pageSize, new IResponse<MemberCouponResponse>() {
                @Override
                public void callBack(boolean result, int code, String msg, MemberCouponResponse info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/loadMemberRechargeOrder")
    public SocketResponse loadMemberRechargeOrder(SocketHeader header, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String tradeNo = request.getString("tradeNo");

            MemberApi.loadMemberRechargeOrder(tradeNo, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData == null) {
                        return;
                    }
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    if (responseData.responseBean != null && responseData.responseBean instanceof GetMemberRechargeOrderResponse) {
                        GetMemberRechargeOrderResponse responseBean = (GetMemberRechargeOrderResponse) responseData.responseBean;

                        response.code = responseData.result;
                        response.message = responseData.resultMessage;
                        response.data = responseBean.data;
                    }
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    if (responseData == null) {
                        return false;
                    }
                    InfoCollect.collect(BizInfoCollect.BusinessInfoKey.MYD_MEMBER_S, responseData.httpStatus == 200 ? "0" : "1");
                    response.code = responseData.result;
                    response.message = responseData.resultMessage;
                    return false;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }

        return response;
    }

    @DrivenMethod(uri = TAG + "/sendOnlineRechargeRequest")
    public SocketResponse sendOnlineRechargeRequest(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        final NewMemberRechargResponse myResponseData = new NewMemberRechargResponse();
        response.data = myResponseData;
        try {
            final JSONObject request = JSON.parseObject(param);

            int ruleID = request.getIntValue("ruleID");
//            int payType = request.getIntValue("payType");
            String pay_code = request.getString("pay_code");
            String micro = request.getString("micro");
            String cardNo = request.getString("cardNo");
            BigDecimal amount = request.getBigDecimal("amount");

            // 2018/4/25 不读取客户端入参的类型，业务中心判断
            String error = NetPayUtil.checkSuooprt(null, micro);
            if (!TextUtils.isEmpty(error)) {
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = error;
                return response;
            }
            int payType = NetPayUtil.judgePayType(micro);

            MemberApi.sendOnlineRechargeRequest(ruleID, amount, pay_code, payType, micro, cardNo, new IResponse<QueryNewMembeChargeResultModel>() {
                @Override
                public void callBack(boolean result, int code, String msg, QueryNewMembeChargeResultModel info) {
                    myResponseData.msg = msg;
                    myResponseData.status = code;
                    myResponseData.queryNewMembeChargeResultModel = info;
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 查询会员充值结果
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/queryOnlineRechargeRequest")
    public SocketResponse queryOnlineRechargeRequest(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        final SocketResponse response = new SocketResponse();
        try {
            final JSONObject request = JSON.parseObject(param);
            final NewMemberRechargResponse myResponseData = new NewMemberRechargResponse();
            response.data = myResponseData;
            String tradeNo = request.getString("tradeNo");

            MemberApi.queryOnlineRechargeRequest(tradeNo, new IResponse<QueryNewMembeChargeResultModel>() {
                @Override
                public void callBack(boolean result, int code, String msg, QueryNewMembeChargeResultModel info) {
                    myResponseData.msg = msg;
                    myResponseData.status = code;
                    myResponseData.queryNewMembeChargeResultModel = info;
                    LogUtil.log("充值回调：" + DateUtil.getCurrentTimeInMills());
                }
            });
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        LogUtil.log("充值方法结束" + DateUtil.getCurrentTimeInMills());
        return response;
    }

//    /**
//     * 下单时核销会员菜品券
//     *
//     * @param param
//     * @return
//     */
//    @DrivenMethod(uri = TAG + "/memberCouponConsume")
//    public SocketResponse memberCouponConsume(SocketHeader head, String param) {
//        if (TextUtils.isEmpty(param)) {
//            return null;
//        }
//        SocketResponse response = new SocketResponse();
//        try {
//            JSONObject requestJson = JSON.parseObject(param);
//            String couponSn = requestJson.getString("sn");
//            List<String> snList = new ArrayList<>();
//            for (String s : couponSn.split(",")) {
//                snList.add(s);
//            }
//            MemberCouponConsumeResponse myResponse = new MemberCouponConsumeResponse();
//            response.data = myResponse;
//            MemberApi.couponConsumeRequest(couponSn, snList, new IResponse<MemberCouponConsumeData>() {
//                @Override
//                public void callBack(boolean result, int code, String msg, MemberCouponConsumeData info) {
//                    myResponse.msg = msg;
//                    myResponse.status = code;
//                    myResponse.data = info;
//                }
//            });
//        } catch (Exception e) {
//            LogUtil.logError(e);
//            response.code = SocketResultCode.EXCEPTION;
//        }
//        return response;
//    }

    /**
     * 下单时获取菜品券列表
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/getMemberCouponList")
    public SocketResponse getMemberCouponList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject requestJson = JSON.parseObject(param);
            String orderId = requestJson.getString("order_id");
            OrderCache cache = OrderSession.getInstance().getOrder(orderId);
            if (cache.memberInfoS == null) {
                return null;
            }
            List<FoodInfoModel> foodInfo = OrderUtil.getAllMenuModelByOrder(cache);
            MemberApi.getMemberCouponListRequest(cache.memberInfoS.cs_id, cache.memberInfoS.card_no, cache.totalPrice, foodInfo, new IResponse<MemberCouponGetResponse>() {
                @Override
                public void callBack(boolean result, int code, String msg, MemberCouponGetResponse info) {
                    response.code = code;
                    response.message = msg;
                    response.data = info;
                }
            });
        } catch (Exception e) {

        }
        return response;
    }

//    /**
//     *
//     * @param head
//     * @param param
//     * @return
//     */
//    @DrivenMethod(uri = TAG + "/refundMemberCoupon")
//    public SocketResponse batchRefundMemberCoupon(SocketHeader head, String param) {
//        if (TextUtils.isEmpty(param)) {
//            return null;
//        }
//        SocketResponse response = new SocketResponse();
//        final MemberCouponRefundResponse mResponse = new MemberCouponRefundResponse();
//        response.data = mResponse;
//        try {
//            JSONObject requestJson = JSON.parseObject(param);
//            String orderId = requestJson.getString("order_id");
//            String snStr = requestJson.getString("sn");
//            List<String> snList = new ArrayList<>();
//            for (String s : snStr.split(",")) {
//                snList.add(s);
//            }
//            OrderCache cache = OrderSession.getInstance().getOrder(orderId);
//            String cardNo = cache.memberInfoS.card_no;
//            MemberApi.refundMemberCoupon(cardNo, snList, new IResponse<MemberCouponRefundResponse>() {
//                @Override
//                public void callBack(boolean result, int code, String msg, MemberCouponRefundResponse info) {
//                    if (result) {
//                        mResponse.data = info.data;
//                        mResponse.errno = info.errno;
//                    } else {
//                        mResponse.errmsg = info.errmsg;
//                    }
//                }
//            });
//        } catch (Exception e) {
//
//        }
//        return response;
//    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
