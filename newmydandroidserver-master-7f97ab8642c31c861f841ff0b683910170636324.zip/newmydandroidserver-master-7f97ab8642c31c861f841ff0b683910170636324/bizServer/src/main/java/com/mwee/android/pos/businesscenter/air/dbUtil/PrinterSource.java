package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * 打印机的增删改查
 * 打印机分为两类 站点打印机  部门打印机
 * 一个站点对应一个站点打印机 站点打印机的增加需要替换原有的
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/6/3
 */
public class PrinterSource {
    ///////////////////////////////////////////////////////////////////////////
    //    Query
    ///////////////////////////////////////////////////////////////////////////

    /**
     * @param hostId 站点名
     * @return 获取站点打印机 一个站点对应一个站点打印机
     */
    public PrinterItem queryHostPrinter(String hostId) {
        String sql = "select * from tbPrinter where fiStatus='1' AND fsPrinterName in (select fsPrinterName from tbHost where fsHostId = '" + hostId + "' AND fiStatus='1')";
        PrinterDBModel hostPrinter = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
        return printerDBModel2Item(hostPrinter, "", hostId);
    }


    /**
     * @param deptId 部门id
     * @return 获取部门打印机  一个部门对应一个部门打印机
     */
    public PrinterItem queryDeptPrinter(String deptId) {
        PrinterDBModel deptPrinter = DBSimpleUtil.query(APPConfig.DB_MAIN,
                "select * from tbPrinter where fiStatus='1' AND fsPrinterName in (select fsPrinterName from tbDept where fsDeptId = '" + deptId + "'  AND fiStatus='1')",
                PrinterDBModel.class);
        return printerDBModel2Item(deptPrinter, deptId, "");
    }


    /**
     * @return 获取所有部门打印机
     */
    public List<PrinterItem> queryDeptPrinters() {
        List<DeptDBModel> deptDBModels = DeptDBUtils.queryAll();
        List<PrinterItem> printerItems = new ArrayList<>();
        if (deptDBModels == null) {
            return printerItems;
        }
        for (DeptDBModel deptDBModel : deptDBModels) {
            PrinterItem printerItem = queryDeptPrinter(deptDBModel.fsDeptId);
            if (printerItem != null) {
                printerItems.add(printerItem);
            }
        }
        return printerItems;
    }

    /**
     * @return 目前的需求 获取所有打印机 部门和站点用同一个则需要聚合
     */
    public List<PrinterItem> queryAllPrinters(String hostId) {
        List<PrinterItem> printerItems = queryDeptPrinters();
        PrinterItem hostPrinterItem = queryHostPrinter(hostId);
        int index = -1;
        for (int i = 0; i < printerItems.size(); i++) {
            if (hostPrinterItem != null && TextUtils.equals(hostPrinterItem.name, printerItems.get(i).name)) {
                index = i;
            }
        }
        if (index >= 0) {
            printerItems.get(index).isUseHost = true;
        } else {
            if (hostPrinterItem != null) {
                printerItems.add(0, hostPrinterItem);
            }
        }
        /**
         * 用于清理历史数据
         */
        deleteInvalidDept(queryInvaildDeptId());
        return printerItems;

    }

    private List<String> queryInvaildDeptId() {
        String sql = "SELECT DISTINCT (fsDeptId)" +
                "  FROM tbmenuClsMuldept\n" +
                " WHERE fiStatus = '1' AND \n" +
                "       fsDeptId NOT IN (\n" +
                "           SELECT fsDeptId\n" +
                "             FROM tbDept\n" +
                "            WHERE fiStatus = '1' AND \n" +
                "                  tbDept.fsPrinterName IN (\n" +
                "                      SELECT fsPrinterName\n" +
                "                        FROM tbPrinter\n" +
                "                       WHERE fiStatus = '1'\n" +
                "                  )\n" +
                "       );";
        return DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
    }


    /**
     * 打印机数据类型转换
     *
     * @param printerDBModel
     * @param fsDeptId
     * @param hostId
     * @return
     */
    private PrinterItem printerDBModel2Item(PrinterDBModel printerDBModel, String fsDeptId, String hostId) {
        if (printerDBModel == null) {
            return null;
        }
        PrinterItem item = new PrinterItem();
        item.id = printerDBModel.fiID;
        item.type = printerDBModel.fiPrinterCls;
        item.name = printerDBModel.fsPrinterName;
        item.ip = printerDBModel.fsIP;
        item.fsPrinterSN = printerDBModel.fsPrinterSN;
        item.isUseHost = !TextUtils.isEmpty(hostId);
        item.depId = fsDeptId;
        item.isUseMake = !TextUtils.isEmpty(fsDeptId);
        item.isUseTag = isTagPrinterByCommand(printerDBModel.fsCommandType);
        item.size = printerDBModel.fiPaperSize;
        item.fsCommandType = printerDBModel.fsCommandType;
        item.fsStr1 = printerDBModel.fsStr1;
        item.fiPrinterNum = printerDBModel.fiPrinterNum;
        if (item.isUseMake) {
            item.menuClsIds = MenuClsMuldeptDBUtils.queryAllByDeptId(fsDeptId);
        }
        DeptDBModel deptDBModel = DeptDBUtils.queryById(fsDeptId);
        if (deptDBModel != null) {
            item.fiIsOneItemCut = deptDBModel.fiIsOneItemCut;
        }
        return item;
    }

    public boolean isTagPrinterByPrinterName(String printerName) {
        PrinterDBModel printerDBModel = TPrinterUtils.queryByName(printerName);
        if (printerDBModel == null) {
            return false;
        }
        return isTagPrinterByCommand(printerDBModel.fsCommandType);
    }

    ///////////////////////////////////////////////////////////////////////////
    //      Add
    ///////////////////////////////////////////////////////////////////////////

    /**
     * 美小易终端添加打印机
     *
     * @param printerItem
     * @param hostId
     * @param userDBModel
     * @return
     */
    public PrinterItem addPrinterByAir(PrinterItem printerItem, String hostId, UserDBModel userDBModel) {
        addPrinter(printerItem, hostId, userDBModel);
        deleteInvalidPrinterModel(hostId, userDBModel);
        MetaDBController.updateSyncTime();
        return printerItem;
    }

    /**
     * 新建一个打印机步骤
     * 1.生成一个打印机model
     * 2.是站点打印机:更新站点打印机   部门打印机:生成一个部门model再绑定,部门关联菜品
     * 如果都是做两步
     * 3.
     *
     * @param printerItem
     * @param hostId
     */
    public PrinterItem addPrinter(PrinterItem printerItem, String hostId, UserDBModel userDBModel) {
        //需要绑定到部门的菜品分类
        ArrayList<String> menuClsIds = printerItem.menuClsIds;
        //新建一个打印机model
        PrinterDBModel model = addPrinterModel(printerItem, userDBModel);

        //站点打印机
        if (printerItem.isUseHost) {
            HostUtil.updatePrinterName(hostId, model.fsPrinterName, userDBModel);
        }
        //部门打印机
        if (printerItem.isUseMake) {
            DeptDBModel deptDBModel = addDeptDBModel(model.fsPrinterName, printerItem.fiIsOneItemCut, userDBModel);
            MenuClsMuldeptDBUtils.associatePrinter(printerItem.menuClsIds, deptDBModel.fsDeptId, userDBModel);
            printerItem.depId = deptDBModel.fsDeptId;
        }

        MetaDBController.updateSyncTime();
        return printerItem;
    }


    /**
     * @param printerItem
     * @return 根据视图模型得到打印机模型
     */
    private PrinterDBModel addPrinterModel(PrinterItem printerItem, UserDBModel userDBModel) {
        PrinterDBModel model = new PrinterDBModel();
        if (printerItem.id == -1) {
            printerItem.id = IDHelper.generatePrinterId();
        }
        model.fiID = printerItem.id;
        //搜索的打印机 使用时间戳+usb打印机   添加的打印机使用usb打印机
        model.fsPrinterName = printerItem.name;
        model.fsIP = printerItem.ip;
        model.fsPrinterSN = printerItem.fsPrinterSN;
        model.fiIsMakePrn = 1;
        model.fsCommandType = printerItem.fsCommandType;
        //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS  小散项目目前支持网口和USB口
        model.fiPrinterCls = printerItem.type;

        if (printerItem.type == 9) {//云打印机
            model.fiCPL = 32;
            model.fsStr1 = "";
            model.fsPrinterSN = printerItem.fsPrinterSN;
        } else {
            model.fsStr1 = TextUtils.isEmpty(printerItem.fsStr1) ? "BYUSB-0" : printerItem.fsStr1;
            model.fsIP = printerItem.ip;

        }
        //"BYUSB-0";//--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fiInt1 = 0;
        // 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiPaperSize = printerItem.size;
        model.fiPrinterNum = printerItem.fiPrinterNum;
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.fsShopGUID = HostUtil.getShopID();
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        model.sync = 1;
        model.fiDataSource = 1;
        // 标签打印机
//        if (printerItem.isUseTag) {
//            model.fiPrinterType = 2;
//        }
        model.replaceNoTrans();
        return model;
    }


    public DeptDBModel addDeptDBModel(String printerName, int fiIsOneItemCut, UserDBModel userDBModel) {
        DeptDBModel deptDBModel = new DeptDBModel();
        deptDBModel.fsDeptId = IDHelper.generateDeptId();
        deptDBModel.fsShopGUID = HostUtil.getShopID();
        deptDBModel.fsDeptName = "后厨出品";
        deptDBModel.fsPrinterName = printerName;
        deptDBModel.fsPrinterName2 = "";
        deptDBModel.fiIsBackBill = 1;
        deptDBModel.fiIsHurryBill = 1;
        deptDBModel.fiIsChangeBill = 1;
        deptDBModel.fiIsTaskBill = 1;
        deptDBModel.fiIsTurnBill = 1;
//        deptDBModel.fiIsOneItemCut = 3;
        deptDBModel.fiPrintCopies = 1;
        deptDBModel.fiStatus = 1;
        deptDBModel.fiDeptCls = 2;
        deptDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            deptDBModel.fsUpdateUserId = userDBModel.fsUserId;
            deptDBModel.fsUpdateUserName = userDBModel.fsUserName;
        }
        deptDBModel.sync = 1;
        deptDBModel.fiDataSource = 0;
        deptDBModel.fiPrintDishes = 0;
        deptDBModel.fiIsOneItemCut = fiIsOneItemCut;
        deptDBModel.replaceNoTrans();
        return deptDBModel;
    }

    ///////////////////////////////////////////////////////////////////////////
    //   delete
    ///////////////////////////////////////////////////////////////////////////

    /**
     * 步骤
     * 站点打印机
     * 1.解绑打印机和站点关系
     * 部门打印机
     * 1 解绑菜分类和部门的关系
     * 2 删除部门。
     * <p>
     * <p>
     *
     * @param printerItem
     * @param hostId
     */
    public void deletePrinter(PrinterItem printerItem, String hostId, UserDBModel userDBModel) {
        String deptId = printerItem.depId;
        if (printerItem.isUseHost) {
            HostUtil.updatePrinterName(hostId, "", userDBModel);
        }

        if (printerItem.isUseMake && !TextUtils.isEmpty(deptId)) {
            deleteDept(deptId);
        }


        //最后 查询该打印机是否还有在用 没有则删  想太多 现在就先处理一对一的关系
//        List<PrinterItem> printerItems = queryAllPrinters(hostId);
//        int index = -1;
//        for (int i = 0; i < printerItems.size(); i++) {
//            if (TextUtils.equals(printerItem.name, printerItems.get(i).name)) {
//                index = i;
//            }
//        }
//        if (index == -1) {
//            deletePrinterModel(printerItem.id, userDBModel);
//        }
        deletePrinterModel(printerItem.id, userDBModel);
        MetaDBController.updateSyncTime();
    }

    /**
     * 删除没有被应用的打印机  未关联部门也未关联站点
     *
     * @param hostId
     * @param userDBModel
     */
    private void deleteInvalidPrinterModel(String hostId, UserDBModel userDBModel) {
        List<PrinterItem> printerItems = queryAllPrinters(hostId);
        List<PrinterDBModel> printerDBModels = TPrinterUtils.queryAll();
        if (printerDBModels == null) {
            return;
        }
        for (int i = 0; i < printerDBModels.size(); i++) {
            int fiID = printerDBModels.get(i).fiID;
            boolean invalid = true;
            for (int j = 0; j < printerItems.size(); j++) {
                int id = printerItems.get(j).id;
                if (id == fiID) {
                    invalid = false;
                    break;
                }
            }
            if (invalid) {
                deletePrinterModel(fiID, userDBModel);
            }
        }


    }

    private void deletePrinterModel(int printerId, UserDBModel userDBModel) {
        String sql = "select * from tbPrinter where fiStatus=1 and fiID='" + printerId + "'";
        PrinterDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
        if (model == null) {
            return;
        }
        model.fiStatus = 13;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.sync = 1;
        model.replaceNoTrans();

    }

    /**
     * 删除无效打印部门
     *
     * @param deptIds
     */
    private void deleteInvalidDept(List<String> deptIds) {
        if (deptIds != null && !deptIds.isEmpty()) {
            for (String deptId : deptIds) {
                if (!TextUtils.isEmpty(deptId)) {
                    deleteDept(deptId);
                }
            }
            MetaDBController.updateSyncTime();
        }
    }

    /**
     * 移除打印部门 先移除菜品分类关联关系
     *
     * @param depId
     */
    private void deleteDept(String depId) {
        MenuClsMuldeptDBUtils.unAssociatePrinter(depId);
        DeptDBUtils.removeDept(depId);
    }


    ///////////////////////////////////////////////////////////////////////////
    //      Update
    ///////////////////////////////////////////////////////////////////////////

    /**
     * 步骤
     * <p>
     * 更新打印机model
     * <p>
     * 2.站点打印机绑定解绑
     *
     * @param printerItem
     * @param hostId
     * @return
     */
    public void updatePrinter(final PrinterItem printerItem, String hostId, UserDBModel userDBModel) {
        String depId = printerItem.depId;
        updatePrinterModel(printerItem, userDBModel);


        //没有站点打印机 去绑定
        if (printerItem.isUseHost) {
            HostUtil.updatePrinterName(hostId, printerItem.name, userDBModel);
        } else {
            //站点打印机是当前打印机
            PrinterItem hostPrinter = queryHostPrinter(hostId);
            if (hostPrinter != null && hostPrinter.id == printerItem.id) {
                HostUtil.updatePrinterName(hostId, "", userDBModel);
            }
        }

        //如果之前是部门打印机
        if (!TextUtils.isEmpty(depId)) {
            MenuClsMuldeptDBUtils.unAssociatePrinter(depId);
            //还是部门打印机 则重新关联菜品
            if (printerItem.isUseMake) {
                DeptDBUtils.updateDeptPrinterName(printerItem, depId, userDBModel);
                MenuClsMuldeptDBUtils.associatePrinter(printerItem.menuClsIds, depId, userDBModel);
            } else {
                deleteDept(depId);
            }
        }
        //之前不是部门打印机
        else {
            //走新增部门 部门关联菜品
            if (printerItem.isUseMake) {
                DeptDBModel deptDBModel = addDeptDBModel(printerItem.name, printerItem.fiIsOneItemCut, userDBModel);
                MenuClsMuldeptDBUtils.associatePrinter(printerItem.menuClsIds, deptDBModel.fsDeptId, userDBModel);
                printerItem.depId = deptDBModel.fsDeptId;
            }
        }

        deleteInvalidPrinterModel(hostId, userDBModel);
        MetaDBController.updateSyncTime();

    }


    private void updatePrinterModel(PrinterItem printerItem, UserDBModel userDBModel) {
        DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Object>() {
            @Override
            public Object doJob(SQLiteDatabase sqLiteDatabase) {
                ContentValues values = new ContentValues();
                values.put("fiStatus", 1);
                values.put("fiID", printerItem.id);
                values.put("fsPrinterName", printerItem.name);
                values.put("fiPaperSize", printerItem.size);
                values.put("fiPrinterCls", printerItem.type);
                values.put("fsCommandType", printerItem.fsCommandType);
                values.put("fiPrinterNum", printerItem.fiPrinterNum);
                if (printerItem.type == 9) {//云打印机
                    values.put("fsPrinterSN", printerItem.fsPrinterSN);
                    values.put("fsStr1", "");
                } else {
                    values.put("fsIP", printerItem.ip);
                    values.put("fsStr1", TextUtils.isEmpty(printerItem.fsStr1) ? "BYUSB-0" : printerItem.fsStr1);
                }
                values.put("fsUpdateTime", DateUtil.getCurrentTime());
                values.put("sync", 1);
                if (userDBModel != null) {
                    values.put("fsUpdateUserId", userDBModel.fsUserId);
                    values.put("fsUpdateUserName", userDBModel.fsUserName);
                }
                sqLiteDatabase.update("tbPrinter", values, "fiID=?", new String[]{printerItem.id + ""});
                return null;
            }
        });

    }

    ///////////////////////////////////////////////////////////////////////////
    //    replace cut
    ///////////////////////////////////////////////////////////////////////////

    /**
     * 产品说全部部门一起替换
     * 更新打印部门切单方式
     *
     * @param
     * @param opt
     * @return
     */
    public synchronized String updateTDeptItemCut(int fiIsOneItemCut, UserDBModel opt) {

        List<DeptDBModel> models = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbDept where fiStatus = '1' ", DeptDBModel.class);
        if (models == null || models.isEmpty()) {
            return "后厨出菜点普通打印被删除 无法更新打印部门切单方式";
        }
        for (DeptDBModel model : models) {
            model.fiIsOneItemCut = fiIsOneItemCut;
            model.fsUpdateTime = DateUtil.getCurrentTime();
            model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
            model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
            model.sync = 1;
            MetaDBController.updateSyncTime();
            model.replaceNoTrans();
        }

        return "";
    }


    /**
     * 产品说全部部门一起替换
     * 更新打印部门切单方式
     *
     * @param
     * @param opt
     * @return
     */
    public synchronized String updateTSCReverse(int fiReverse, UserDBModel opt) {

        List<PrinterDBModel> models = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbPrinter where fiStatus = '1' and lower(fsCommandType) like '%tsc%'", PrinterDBModel.class);
        if (models == null || models.isEmpty()) {
            return "标签打印被删除 无法更新标签打印机切单";
        }
        for (PrinterDBModel model : models) {
            model.fiReverse = fiReverse;
            model.fsUpdateTime = DateUtil.getCurrentTime();
            model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
            model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
            model.sync = 1;
            MetaDBController.updateSyncTime();
            model.replaceNoTrans();
        }

        return "";
    }


    /**
     * 是否标签打印机
     *
     * @param fsCommandType
     * @return
     */
    private boolean isTagPrinterByCommand(String fsCommandType) {
        if (TextUtils.isEmpty(fsCommandType)) {
            return false;
        }
        return TextUtils.equals(fsCommandType.toUpperCase(), "TSC");
    }


}
