package com.mwee.android.pos.businesscenter.business.netOrder;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.business.system.ILoopCall;
import com.mwee.android.pos.businesscenter.driver.DeliveryDriver;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.DeliveryApi;
import com.mwee.android.pos.component.datasync.net.model.CreateDeliveryDataBean;
import com.mwee.android.pos.component.datasync.net.model.DeliveryRecord;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.connect.business.bind.BindProcessor;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.util.List;

/**
 * Created by liuxiuxiu on 2018/11/28.
 */

public class AutoDeliveryUtil {

    public static int deliveryCycle = 2;

    public static String defaultDeliveryChannel = "SF";
    public static String deliveryChannel = defaultDeliveryChannel;

    /**
     * 立即就餐单 时间
     */
    public static String immediateTime = "";

    /**
     * 预约单 时间
     */
    public static String reservationTime = "";

    /**
     * 自动配送入口
     */
    public static void initAutoDeliveryLoop() {
        ILoopCall loopCall = new ILoopCall() {
            @Override
            public void call() {
                //只有主站点才需要进行轮询，如果还没有激活则停止该任务，待激活主站点后再注册该任务
                if (BindProcessor.isActived()) {
                    if (!BindProcessor.isCurrentHostMain()) {
                        GlobalLooper.unRegist(this);
                        return;
                    }
                } else {
                    return;
                }
                LogUtil.log("自动配送", "启动轮询");
                checkAndDelevery(this);
            }
        };
        GlobalLooper.registBasedOn30Seconds(loopCall, deliveryCycle);
    }

    /**
     * 自动配送外卖订单
     */
    private static void checkAndDelevery(ILoopCall loopCall) {
        try {
            if (!ServerCache.getInstance().netOrderCache.checkDeliverySetting()) {
                LogUtil.log("自动配送", "商户没有配置配送平台信息");
                return;
            }

            if (ServerCache.getInstance().netOrderCache.optDeliveryModel() == -1) {
                int model = StringUtil.toInt(DBMetaUtil.getConfig(META.DELIVERY_WAY, "0"), 0);
                if (model == 1) {
                    immediateTime = DBMetaUtil.getConfig(META.DELIVERY_IMMEDIATE_TIME, "");
                    reservationTime = DBMetaUtil.getConfig(META.DELIVERY_RESERVATIONS_TIME, "");
                }
                ServerCache.getInstance().netOrderCache.updateDeliveryInfo(model, immediateTime, reservationTime);
            }

            if (ServerCache.getInstance().netOrderCache.optDeliveryModel() == 1) {
                immediateTime = String.valueOf(StringUtil.toInt(ServerCache.getInstance().netOrderCache.optImmediateTime(), 0) * 60);
                reservationTime = String.valueOf(StringUtil.toInt(ServerCache.getInstance().netOrderCache.optReservationsTime(), 0) * 60);
            }

            if (ServerCache.getInstance().netOrderCache.optDeliveryModel() == 0) {
                LogUtil.log("自动配送", "自动配送配置关闭");
                return;
            }

            //取默认配送方案
            defaultDeliveryChannel = DBMetaUtil.getConfig(META.TAKEOUT_DELIVERY_CHANNEL, "SF");

            if (TextUtils.equals(immediateTime, "0") || TextUtils.equals(reservationTime, "0")) {
                LogUtil.log("自动配送", "自动配送配置异常 immediateTime = " + immediateTime + "; reservationTime = " + reservationTime);
                return;
            }

            //立即备餐的
            String date = DateUtil.getCurrentDate("yyyy-MM-dd");
            String currentTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);

            String sql = "select orderId from tempapporder where orderStatus in ('1', '2' ) and " +
                    " date like '" + date + "%' " +
                    " and deliveryStatus = '-10000' " +
                    " and orderTakeawaySource <> 'MWMEITUAN' " +
                    " and ((distributionType = '1' and ((strftime('%s','" + currentTime + "') - strftime('%s',date)) > " + immediateTime + ") ) " +
                    " or (distributionType <> '1' and '"+currentTime+"' < distributionStartTime and ((strftime('%s','" + currentTime + "') - strftime('%s',distributionStartTime)) < " + reservationTime + "))) " +
                    " and orderId not in (select orderId from deliveryRecord where orderTime like '" + date + "%' )";

            List<String> orderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_NET_ORDER, sql);

            if (ListUtil.isEmpty(orderIdList)) {
                LogUtil.log("自动配送", "没有找到代配送的订单");
                return;
            }
            final TempAppOrder[] tempAppOrder = {null};
            for (String orderId : orderIdList) {
                synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(orderId))) {
                    String orderNo = orderId;
                    tempAppOrder[0] = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, "select * from tempApporder where orderid = '" + orderId + "'", TempAppOrder.class);
                    if (tempAppOrder[0] == null) {
                        LogUtil.log("自动配送", "没有找到订单信息 orderId = " + orderId);
                        continue;
                    }

                    deliveryChannel = optdeliveryChannel(tempAppOrder[0].orderTakeawaySource, defaultDeliveryChannel);
                    if (TextUtils.isEmpty(deliveryChannel)){
                        LogUtil.logBusiness("自动配送", tempAppOrder[0].orderTakeawaySource + "来源的订单没有找到配送平台 orderId = " + orderId );
                        continue;
                    }

                    if (tempAppOrder[0].deliveryInfo != null && tempAppOrder[0].deliveryInfo.mwDeliveryStatus == -2 && !TextUtils.isEmpty(tempAppOrder[0].deliveryInfo.updateTime)) {
                        orderNo = orderId + "_" + DateUtil.formartDateStrToTarget(tempAppOrder[0].deliveryInfo.updateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss");
                    }
                    final String sfOrderNo = orderNo;

                    DeliveryApi.createDelivery(orderId, orderNo, deliveryChannel, new IResponse<CreateDeliveryDataBean>() {
                        @Override
                        public void callBack(final boolean result, int code, final String msg, final CreateDeliveryDataBean info) {
                            if (result) {
                                //配送成功
                                //创建假配送中状态
                                tempAppOrder[0] = DeliveryDriver.createDeliveryInfo(tempAppOrder[0], sfOrderNo, deliveryChannel, info);
                                NotifyToClient.updateTempApporder(orderId);
                                LogUtil.log("自动配送", "自动配送成功 orderId = " + orderId);
                            } else {
                                //配送失败
                                NotifyToClient.autoDeliveryFail(orderId, msg);
                                LogUtil.log("自动配送", "自动配送失败 orderId = " + orderId);
                            }

                            //将配送记录插入表中
                            DeliveryRecord deliveryRecord = new DeliveryRecord();
                            deliveryRecord.orderId = orderId;
                            deliveryRecord.fsShopGUID = ServerCache.getInstance().shopID;
                            deliveryRecord.channel = deliveryChannel;
                            deliveryRecord.updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
                            if (result) {
                                deliveryRecord.deliveryStatus = "0";
                                deliveryRecord.reason = "自动配送成功";
                            } else {
                                deliveryRecord.deliveryStatus = "-10000";
                                deliveryRecord.reason = "自动配送失败: " + msg;
                            }
                            deliveryRecord.orderTime = tempAppOrder[0].date;
                            deliveryRecord.replace();

                        }
                    });
                }
            }
        } finally {
            GlobalLooper.registBasedOn30Seconds(loopCall, deliveryCycle);
        }
    }


    /**
     * 获取配送平台
     *
     * @param source
     * @param defaultDeliveryChannel
     * @return
     */
    private static String optdeliveryChannel(String source, String defaultDeliveryChannel) {
        if (TextUtils.isEmpty(source)) {
            return "";
        }
        String sourceName = "";
        if (source.startsWith("ELEME")) {
            sourceName = "ELEME";
        } else if (source.startsWith("MEITUAN")) {
            sourceName = "MEITUAN";
        } else {
            sourceName = source;
        }

        if (!ServerCache.getInstance().netOrderCache.checkDeliverySetting()) {
            return "";
        }

        List<DeliveryChannelBean> wayList = ServerCache.getInstance().netOrderCache.optDeliverySettings().get(sourceName);
        if (ListUtil.isEmpty(wayList)) {
            return "";
        }

        for (DeliveryChannelBean channelBean : wayList) {
            if (channelBean != null && TextUtils.equals(channelBean.channel, defaultDeliveryChannel)) {
                return defaultDeliveryChannel;
            }
        }

        return wayList.get(0).channel;
    }


}
