package com.mwee.android.pos.businesscenter.air.dao.impl;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.air.dao.ISellDao;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.SellDBModel;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.sqlite.base.DBSimpleUtil;

/**
 * Created by qinwei on 2018/10/17.
 */

public class SellDaoImpl extends BaseDaoImpl<SellDBModel> implements ISellDao {
    @Override
    public boolean querySellIsDone(String fssellno, String thirdOrderId) {
        String sql = "select fiBillStatus from tbsell where fssellno='" + fssellno + "' or thirdOrderId='" + thirdOrderId + "'";
        String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return TextUtils.equals(fiBillStatus, OrderStatus.PAIED + "");
    }

    @Override
    public boolean querySellIsDone(String fssellno) {
        String sql = "select fiBillStatus from tbsell where fssellno='" + fssellno + "'";
        String fiBillStatus = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        return TextUtils.equals(fiBillStatus, OrderStatus.PAIED + "");
    }
}
