package com.mwee.android.pos.businesscenter.netbiz.netOrder;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.datasync.net.CancelDeliveryRequest;
import com.mwee.android.pos.component.datasync.net.CreateDeliveryRequest;
import com.mwee.android.pos.component.datasync.net.CreateDeliveryResponse;
import com.mwee.android.pos.component.datasync.net.SearchDeliveryStatusRequest;
import com.mwee.android.pos.component.datasync.net.SearchDeliveryStatusResponse;
import com.mwee.android.pos.component.datasync.net.model.CreateDeliveryDataBean;
import com.mwee.android.pos.component.datasync.net.model.DeliveryStatusDataConfigBean;
import com.mwee.android.pos.component.datasync.net.model.DeliveryStatusDataConfigListBean;
import com.mwee.android.pos.component.datasync.net.model.SearchDeliveryStatusDataBean;
import com.mwee.android.pos.connect.business.delivery.DeliveryChannelBean;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by liuxiuxiu on 2017/3/27.
 */

public class DeliveryApi {

    /**
     * 轮询外卖配送开通状态---每两小时一次
     */
    public static void optDeliveryStatusForLoop() {
        optDeliveryStatusForLoop(false);
    }

    public static void optDeliveryStatusForLoop(boolean forceMainThread) {

        optDeliveryStatus(new IResponse<List<DeliveryStatusDataConfigListBean>>() {
            @Override
            public void callBack(boolean result, int code, String msg, List<DeliveryStatusDataConfigListBean> info) {

                writeDeliveryInfo("解析完毕，开始存储到业务中心缓存处理");

                LinkedHashMap<String, List<DeliveryChannelBean>> deliverySettingsMap = new LinkedHashMap<>();
                if (!ListUtil.isEmpty(info)) {
                    for (DeliveryStatusDataConfigListBean deliveryStatusDataConfigListBean : info) {
                        if (deliveryStatusDataConfigListBean != null && !ListUtil.isEmpty(deliveryStatusDataConfigListBean.expressTakeawayConfigList)) {
                            for (DeliveryStatusDataConfigBean deliveryStatusDataConfigBean : deliveryStatusDataConfigListBean.expressTakeawayConfigList) {
                                if (deliveryStatusDataConfigBean != null) {
                                    List<DeliveryChannelBean> canalList = deliverySettingsMap.get(deliveryStatusDataConfigBean.takeawaySource);
                                    if (ListUtil.isEmpty(canalList)) {
                                        canalList = new ArrayList<>();
                                        deliverySettingsMap.put(deliveryStatusDataConfigBean.takeawaySource, canalList);
                                    }
                                    DeliveryChannelBean deliveryChannel = new DeliveryChannelBean();
                                    deliveryChannel.channel = deliveryStatusDataConfigBean.expressChannel;
                                    deliveryChannel.channelName = deliveryStatusDataConfigListBean.channelName;
                                    deliveryChannel.deliveryAuditStatus = deliveryStatusDataConfigListBean.deliveryAuditStatus;
                                    canalList.add(deliveryChannel);
                                    writeDeliveryInfo("解析完毕 " + deliveryStatusDataConfigBean.takeawaySource + " 支持的  配送方式 " + JSON.toJSONString(canalList));
                                }
                            }
                        }
                    }

                    writeDeliveryInfo("解析完毕，将数据存储到serverCache " + JSON.toJSONString(deliverySettingsMap));

                    ServerCache.getInstance().netOrderCache.putDeliverySettings(deliverySettingsMap);
                } else {
                    writeDeliveryInfo("解析完毕 数据为空，不刷新缓存");
                }
            }
        }, forceMainThread);
    }

    /**
     * 同步外卖配送服务开通状态
     * <p>
     * --店铺未激活时结束任务
     */
    public static void optDeliveryStatus(final IResponse<List<DeliveryStatusDataConfigListBean>> iResponse) {
        optDeliveryStatus(iResponse, false);
    }

    public static void optDeliveryStatus(final IResponse<List<DeliveryStatusDataConfigListBean>> iResponse, boolean forceMainThread) {
        writeDeliveryInfo("轮询到'获取外卖配置'");
        if (TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsshopguid from tbshop"))) {
            writeDeliveryInfo("没有店铺信息，终止外卖配置获取请求");
            return;
        }
        SearchDeliveryStatusRequest searchDeliveryStatusRequest = new SearchDeliveryStatusRequest();
        BusinessExecutor.execute(searchDeliveryStatusRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                writeDeliveryInfo("网络请求成功:" + JSON.toJSONString(responseData));
                if (responseData.responseBean instanceof SearchDeliveryStatusResponse) {
                    SearchDeliveryStatusDataBean searchDeliveryStatusDataBean = ((SearchDeliveryStatusResponse) responseData.responseBean).data;
                    if (searchDeliveryStatusDataBean.err != null) {
                        writeDeliveryInfo("网络请求成功, 解析成功");
                        iResponse.callBack(searchDeliveryStatusDataBean.err.errNo == 0, searchDeliveryStatusDataBean.err.errNo, searchDeliveryStatusDataBean.err.errMsg, searchDeliveryStatusDataBean.configList);
                    } else {
                        writeDeliveryInfo("网络请求成功, 解析失败2 searchDeliveryStatusDataBean.err == null " + responseData.resultMessage);

                        iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                    }
                } else {
                    writeDeliveryInfo("网络请求成功, 解析失败1  responseData.responseBean instanceof SearchDeliveryStatusResponse");
                    iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                writeDeliveryInfo("网络请求失败:" + JSON.toJSONString(responseData));
                return false;
            }
        }, forceMainThread);
    }


    /**
     * 日志
     *
     * @param log
     */
    public static void writeDeliveryInfo(String log) {
//        LogUtil.logBusiness("外卖配送服务", log);
        LogUtil.log("外卖配送服务", log);
    }

    /**
     * 外卖配送下单
     *
     * @param orderId
     */
    public static void createDelivery(String orderId, String orderNo, String deliveryChannel, final IResponse<CreateDeliveryDataBean> iResponse) {

        CreateDeliveryRequest createDeliveryRequest = new CreateDeliveryRequest();
        createDeliveryRequest.orderId = orderId;
        createDeliveryRequest.orderNo = orderNo;
        createDeliveryRequest.expressCompany = deliveryChannel;
        BusinessExecutor.execute(createDeliveryRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean instanceof CreateDeliveryResponse) {
                    CreateDeliveryDataBean createDeliveryDataBean = ((CreateDeliveryResponse) responseData.responseBean).data;

                    if (createDeliveryDataBean.err != null) {
                        iResponse.callBack(createDeliveryDataBean.err.errNo == 0, createDeliveryDataBean.err.errNo, createDeliveryDataBean.err.errMsg, createDeliveryDataBean);
                    } else {
                        iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                    }
                } else {
                    iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

    /**
     * 外卖配送取消
     *
     * @param orderId
     */
    public static void cancelDelivery(String orderId, String orderNo, String expressCompany, final IResponse<CreateDeliveryDataBean> iResponse) {

        CancelDeliveryRequest cancelDeliveryRequest = new CancelDeliveryRequest();
        cancelDeliveryRequest.orderId = orderId;
        cancelDeliveryRequest.orderNo = orderNo;
        cancelDeliveryRequest.expressCompany = expressCompany;
        BusinessExecutor.execute(cancelDeliveryRequest, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {

            }

            @Override
            public boolean fail(ResponseData responseData) {
                return false;
            }
        }, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean instanceof CreateDeliveryResponse) {
                    CreateDeliveryDataBean createDeliveryDataBean = ((CreateDeliveryResponse) responseData.responseBean).data;

                    if (createDeliveryDataBean.err != null) {
                        iResponse.callBack(createDeliveryDataBean.err.errNo == 0, createDeliveryDataBean.err.errNo, createDeliveryDataBean.err.errMsg, createDeliveryDataBean);
                    } else {
                        iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                    }
                } else {
                    iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                }

                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                iResponse.callBack(false, responseData.result, responseData.resultMessage, null);
                return false;
            }
        }, false);
    }

}
