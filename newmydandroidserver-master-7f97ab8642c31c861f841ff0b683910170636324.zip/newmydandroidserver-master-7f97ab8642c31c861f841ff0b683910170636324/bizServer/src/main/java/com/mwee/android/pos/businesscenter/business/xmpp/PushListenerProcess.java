package com.mwee.android.pos.businesscenter.business.xmpp;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.netOrder.NetOrderDBUtil;
import com.mwee.android.pos.businesscenter.business.netOrder.PhoneDowngradeDBUtil;
import com.mwee.android.pos.businesscenter.business.notice.NoticeProcessor;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderApi;
import com.mwee.android.pos.businesscenter.netbiz.netOrder.NetOrderTaskManager;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.datasync.net.model.TempAppOrder;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.component.push.XMPPPushManager;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.ShellUtil;
import com.mwee.myd.server.business.config.ConfigConstant;
import com.mwee.myd.server.business.config.ConfigProcess;
import com.mwee.myd.server.business.login.entity.QueryXmppAuthorityConfigRequest;
import com.mwee.myd.server.business.login.entity.QueryXmppAuthorityConfigResponse;
import com.mwee.myd.server.business.login.entity.SendXmppSqlQueryRequest;
import com.mwee.myd.server.business.login.entity.SendXmppSqlQueryResponse;

import org.jivesoftware.smack.packet.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 推送业务的处理类
 * Created by lxx on 16/12/15.
 */
public class PushListenerProcess {

    /**
     * 2.0系统的推送消息 3.0 暂时不用
     * 10000; //"restaurant";
     * 10001; //"item";
     * 10002; //"modifier";
     * 10003; //"user";
     * 10004; //"printer";
     * 10005; //"place_table";
     * 10006; //"settlement";
     * 10007; //"del_revenue"; // 删除Revenue Center
     * 10008; // "rest_config"; // 餐厅配置信息
     * 10017; //活动
     */

//    public final static int PUSH_ORDER = 10010;  // 推送订单信息
    public final static int PUSH_TAKEAWAY_NEW = 20000;  // 推送外卖到B端POS机
    public final static int NOTICE_MEAL = 10019; //到店通知
    public final static int PUSH_TAKEAWAY_CANCLE = 20001;  // 外卖取消
    public final static int PUSH_TAKEAWAY_PRESS = 20002;  // 外卖催单
    //    public final static int PUSH_TAKEAWAY_SEND = 20003;  // 自己外卖 派送通知
    public final static int PUSH_TAKEAWAY_GET = 20003;  // 确认订单（其他平台接单）
    public final static int PUSH_THIRD_TAKEAWAY_OVER = 20004;  // 第三方外卖 完成
    public final static int PUSH_TAKEAWAY_OVER = 10020;  // 自己外卖 完成
    public final static int PUSH_MEITUAN_DOWNGRADE = 20007; // 美团隐私号降级
    public final static int PUSH_MEITUAN_DOWNGRADE_RESTORE = 20008; // 美团隐私号降级恢复
    public final static int PUSH_MEIXIAODIAN_CANCEL = 20010; // 美小店用户取消订单

    public final static int XMPP_MSG_REPORT_LOG = 500;  // 主动上报日志

    /**
     * 秒点的订单
     * 美易点 2.7.7 及以上版本使用新的推送id
     * use {@link PushListenerProcess#XMPP_MSG_GET_NEW_ORDER_V2} instead of
     */
    @Deprecated
    public final static int XMPP_MSG_GET_NEW_ORDER = 30000;
    /**
     * 秒点的订单
     * 美易点 2.7.7 之后使用新的 id.
     */
    public final static int XMPP_MSG_GET_NEW_ORDER_V2 = 33333;
    public final static int XMPP_MSG_GET_NEW_DATA = 30001;  // 主动门店配置发生变化
    public final static int XMPP_MSG_UPLOAD_ORDER = 30002;  // 主动上报订单
    public final static int XMPP_MSG_UPLOAD_BOOK_ORDER = 30003;  // 预定订单
    public final static int XMPP_MSG_ADMIN = 31000;  // 管理入口


    public final static int XMPP_MSG_WECHAT_ORDER_NEW = 32000;  // 微信订单新单
    public final static int XMPP_MSG_WECHAT_ORDER_CANCEL = 32001;  // 微信订单取消
    public final static int XMPP_MSG_WECHAT_ORDER_OVER = 32002;  // 微信订单完成
    /**
     * 共享餐厅的退款
     */
    public final static int XMPP_MSG_SHARE_SHOP_REFUND = 33000;

    /**
     * xmpp安全配置下发
     */
    public final static int XMPP_MSG_AUTHORITY_CONFIG = 505;

    /**
     * 打开或关闭xmpp安全配置
     */
    public final static int XMPP_MSG_AUTHORITY_CONFIG_OPEN = 999999;


    /**
     * 商场内网透传
     */
    public final static int XMPP_MSG_UPLOAD_TO_MALL = 35000;

    public final static int THIRDPARTYPAY_RESULT = 10009; // "thirdpartyPay_result"; // 第三方应用支付结果


    /*********************************快递推送信息 21开头*********http://wiki.mwbyd.cn/pages/viewpage.action?pageId=9664371**********************************************/
    // 等待接单(0)
    public final static int PUSH_DELIVERY_NOMAL = 21000;
    // 待配送
    public final static int PUSH_DELIVERY_WAITING = 21001;
    // 取货中
    public final static int PUSH_DELIVERY_GET_GOOGS = 21002;
    // 配送中
    public final static int PUSH_DELIVERY_ING = 21003;
    // 已送达
    public final static int PUSH_DELIVERY_OVER = 21004;
    // 配送取消
    public final static int PUSH_DELIVERY_CANCEL = 21005;


    /*********************************云打印相关*********http://wiki.mwbyd.cn/pages/viewpage.action?pageId=11635062**********************************************/
    /**
     * 云打印机上线
     */
    public final static int CLOUD_PRINTER_ONLINE = 31001;
    /**
     * 云打印机离线
     */
    public final static int CLOUD_PRINTER_OFFLINE = 31002;
    /**
     * 云打印任务成功
     */
    public final static int CLOUD_PRINT_SUCCESS = 31003;
    /**
     * 云打印任务失败
     */
    public final static int CLOUD_PRINT_FAIL = 31004;

    /**
     * 电子发票开票状态接收
     */
    public final static int E_INVOICE_STATUS_NOTIFY = 31100;

    /**
     * 自动匹配优化，有外卖菜品未与本地菜品映射
     */
    public final static int XMPP_MSG_MAPPING_MENU_AUTO = 20009;


    //打烊后不再处理的推送消息
    public static final int[] unDealWhenShopFinished = new int[]{XMPP_MSG_GET_NEW_ORDER, XMPP_MSG_UPLOAD_BOOK_ORDER, XMPP_MSG_WECHAT_ORDER_NEW, XMPP_MSG_WECHAT_ORDER_OVER, XMPP_MSG_WECHAT_ORDER_CANCEL, PUSH_TAKEAWAY_OVER,
            PUSH_THIRD_TAKEAWAY_OVER, PUSH_TAKEAWAY_GET, PUSH_TAKEAWAY_NEW, PUSH_TAKEAWAY_CANCLE, PUSH_DELIVERY_NOMAL, PUSH_DELIVERY_WAITING, PUSH_DELIVERY_GET_GOOGS, PUSH_DELIVERY_ING, PUSH_DELIVERY_OVER, PUSH_DELIVERY_CANCEL};
    final static Object netOrderGet = new Object();
    private static final Object takeawayOrderByShopId = new Object();
    /**
     * 执行SQL
     */
    private final static String WEB_SHELL_EXCUTE = "1";
    /**
     * 订单转换为报表
     */
    private final static String WEB_SHELL_TRANS_REPORT = "2";
    /**
     * 查询SQL
     */
    private final static String WEB_SHELL_QUERY = "3";
    /**
     * 调用Driver方法
     */
    private final static String WEB_SHELL_DRIVE = "4";
    /**
     * 测试链接
     */
    private final static String WEB_SHELL_CONNECT = "5";
    /**
     * 推送消息到客户端
     */
    private final static String WEB_SHELL_BROADCAST = "6";
    /**
     * 上传单个订单
     */
    private final static String WEB_SHELL_UPLOAD_SINGLE_ORDER = "7";
    /**
     * 上传所有符合要求的订单
     */
    private final static String WEB_SHELL_UPLOAD_ORDER = "8";
    /**
     * 清除缓存
     */
    private final static String WEB_SHELL_SYNC_CACHE = "9";
    /**
     * 远程ping命令调用
     */
    private final static String WEB_SHELL_PING_TEST = "10";

    /**
     * 查询配置文件内容
     */
    private final static String CONFIG_CONTENT = "11";

    /**
     * xmpp安全配置开关，默认：关，通过authToken调用接口改变此值
     */
    private static boolean canUploadXmppQueryData = false;

    /**
     * 商场内网透传
     */
    public static void uploadToMall(String msgBody) {
        DriverBus.call("biz/uploadDataToMall", msgBody);
    }

    /**
     * 检查店铺打烊后不能处理的推送
     *
     * @param msgID
     * @return true 可处理消息| false 不能再处理该消息
     */
    public static boolean checkCanDeal(int msgID) {
        if (HostUtil.isShopFinished()) {
            for (int id : unDealWhenShopFinished) {
                if (id == msgID) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 门店数据发生变化
     */
    public static void shopDataSetChanged() {
        //1、公告
        NoticeProcessor.prepareGetNotice();
        //2、 提示有更新 : 登录页显示小黄点 和 点餐页高亮用户名
        ClientMetaUtil.updateSettingsValueByKey(META.UPDATE_NOTIFY, "1");
        NotifyToClient.cloudShopInfoChange();
        //自动触发更新
        LogUtil.logBusiness("触发自动更新");
//        DriverBus.call("biz/loadDataFromCenter");
        DriverBus.call("biz/loadDataFromCenterWithHostId", HostUtil.getCurrentHost());
    }

    /**
     * 推送新订单
     *
     * @param appTempOrderId
     */
    public static void netOrderNew(String appTempOrderId) {
        try {
            if (TextUtils.isEmpty(appTempOrderId)) {
                return;
            }
            if (!NetOrderDBUtil.isExist(appTempOrderId)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER, "推送来了新订单消息，拉取网络订单详情：orderId = " + appTempOrderId, "");
//                NetOrderApi.getNetworkOrderById(appTempOrderId + "", 0);
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(appTempOrderId));
            } else {
                NetOrderApi.autoGetNetOrder(appTempOrderId + "", 0);
                RunTimeLog.addLog(RunTimeLog.NETORDER, "推送来了新订单消息，订单已存在本地库：orderId = " + appTempOrderId + ";", "");
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "新订单处理异常" + e.getMessage());
        }
    }

    /**
     * 取消外卖单
     *
     * @param appTempOrderId
     * @param reason
     */
    public static void netOrderCancel(String appTempOrderId, String reason) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息" + appTempOrderId + "订单取消:" + reason, "");
            NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(appTempOrderId));
            /*
            TempAppOrder tempAppOrder = NetOrderDBUtil.optTempappOrderHeaderInfo(appTempOrderId);
            if (tempAppOrder == null) {
                RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息：" + appTempOrderId + "订单本地不存在", "");
                NetOrderApi.updateNetworkOrderById(appTempOrderId + "");
                return;
            } else {
                if (!tempAppOrder.cancelStatus()) {
                    NetOrderDBUtil.cancelOrder(appTempOrderId);
                    NotifyToClient.updateTempApporder(String.valueOf(appTempOrderId));
                }
            }*/
            if (APPConfig.isCasiher()) {
                TempAppOrder tempAppOrder = NetOrderDBUtil.optTempappOrderHeaderInfo(appTempOrderId);
                if (!tempAppOrder.cancelStatus()) {
                    NetOrderDBUtil.cancelOrder(appTempOrderId);
                    NotifyToClient.updateTempApporder(String.valueOf(appTempOrderId));
                }
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "'取消外卖单'处理异常", e.getMessage());
        }
    }

    /**
     * 外卖单完成
     *
     * @param appOrderId
     */
    public static void netOrderOver(String appOrderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息：" + appOrderId + "订单完成", "");
            synchronized (takeawayOrderByShopId) {
                TempAppOrder tempAppOrder = NetOrderDBUtil.optTempappOrderHeaderInfo(appOrderId);
                if (tempAppOrder == null) {
                    RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息：" + appOrderId + "订单本地不存在", "");
                    NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(appOrderId));
                    return;
                } else {
                    if (!tempAppOrder.finishedStatus()) {
                        NetOrderDBUtil.finishOrder(appOrderId);
                        NotifyToClient.updateTempApporder(String.valueOf(appOrderId));
                    }
                }
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "'外卖单完成'处理异常", e.getMessage());
        }
    }

    /**
     * 外卖单接单
     *
     * @param appOrderId
     */
    public static void netOrderGet(String appOrderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息" + appOrderId + "订单接单", "");
            synchronized (netOrderGet) {
                TempAppOrder tempAppOrder = NetOrderDBUtil.optTempappOrderHeaderInfo(appOrderId);
                if (tempAppOrder == null) {
                    RunTimeLog.addLog(RunTimeLog.NETORDER, "推送消息：" + appOrderId + "订单本地不存在", "");
                    NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(appOrderId));
                    return;
                } else {
                    if (!tempAppOrder.newOrder() && !tempAppOrder.cancelStatus() && !tempAppOrder.finishedStatus()) {
                        NetOrderDBUtil.doGetOrder(appOrderId, tempAppOrder.bizType);
                        NotifyToClient.updateTempApporder(String.valueOf(appOrderId));
                    }
                }
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER, "'外卖单接单'处理异常", e.getMessage());
        }
    }

    /**
     * 配送--等待接单(0)
     *
     * @param orderId
     */
    public static void netOrderDeliveryNomal(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_NAMAL, "推送消息" + orderId + "配送--等待接单(0)", orderId);
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_NAMAL, "'配送--等待接单(0) 异常 ", e.getMessage());
        }
    }

    /**
     * 待配送--快递
     *
     * @param orderId
     */
    public static void netOrderDeliveryWaiting(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_WAITING, "推送消息" + orderId + "待配送--快递", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));

            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_WAITING, "'待配送--快递 - '处理异常", e.getMessage());
        }
    }

    /**
     * 取货中--快递
     *
     * @param orderId
     */
    public static void netOrderDeliveryGetGoods(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_GET_GOODS, "推送消息" + orderId + "取货中--快递", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));

            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_GET_GOODS, "'取货中--快递 - '处理异常", e.getMessage());
        }
    }

    /**
     * 配送中--快递
     *
     * @param orderId
     */
    public static void netOrderDeliveryING(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_ING, "推送消息" + orderId + " 配送中--快递", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));

            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_ING, "' 配送中--快递 - '处理异常", e.getMessage());
        }
    }

    /**
     * 已送达--快递
     *
     * @param orderId
     */
    public static void netOrderDeliveryOver(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_OVER, "推送消息" + orderId + " 已送达--快递", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));

            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_OVER, "' 已送达--快递 - '处理异常", e.getMessage());
        }
    }

    /**
     * 已取消--快递
     *
     * @param orderId
     */
    public static void netOrderDeliveryCancel(String orderId) {
        NotifyToClient.orderChangeWithinDeliveryCancel();
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_CANCEL, "推送消息" + orderId + " 已取消--快递", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));

            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_DELIVERY_CANCEL, "' 已取消--快递 - '处理异常", e.getMessage());
        }
    }

    /**
     * 美团隐私号降级
     */
    public static void netOrderMeituanPhoneDowngrade(String orderId, String realPhoneNumber) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_MEITUAN_PHONE_DOWNGRADE, "推送消息" + orderId + "美团隐私号降级", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));
                PhoneDowngradeDBUtil.addMessageMeituanDowngrade(orderId, realPhoneNumber);
                NotifyToClient.meituanPhoneDowngrade(orderId, realPhoneNumber);
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_MEITUAN_PHONE_DOWNGRADE, "'美团隐私号降级 - '处理异常");
        }
    }

    /**
     * 美团隐私号降级恢复
     */
    public static void netOrderMeituanPhoneDowngradeRestore(String orderId) {
        try {
            RunTimeLog.addLog(RunTimeLog.NETORDER_MEITUAN_PHONE_DOWNGRADE_RESTORE, "推送消息" + orderId + "美团隐私号降级恢复", "");
            synchronized (netOrderGet) {
                NetOrderTaskManager.getInstance().addOrderTask(String.valueOf(orderId));
            }
        } catch (Exception e) {
            RunTimeLog.addLog(RunTimeLog.NETORDER_MEITUAN_PHONE_DOWNGRADE_RESTORE, "'美团隐私号降级恢复 - '处理异常");
        }
    }

    public static void refundSharedShopPay() {

    }

    /**
     * 后台管理入口，body格式为：type,param
     * ","间隔，type明细为：
     * 1，执行sql，param为sql
     * 2，转化订单，param为订单号
     *
     * @param msgBody String
     */
    public static void processAdmin(final Message pack, String msgBody) {
        if (TextUtils.isEmpty(msgBody)) {
            return;
        }
        String method = null;//另外一种后台管理方式，对应的发送方式也不一样
        String msgSeq = null;
        if (msgBody.contains("queryCmd") && msgBody.contains("msgSeq") && msgBody.contains("method")) {
            JSONObject obj = JSON.parseObject(msgBody);
            if (obj != null) {
                String queryCmd = obj.getString("queryCmd");
                method = obj.getString("method");
                msgSeq = obj.getString("msgSeq");
                if (!TextUtils.isEmpty(queryCmd)) {
                    if (!queryCmd.contains(",")) {//没有类型的话，默认是查询
                        queryCmd = "3," + queryCmd;
                    }
                    msgBody = queryCmd;//将新的管理方式的查询语句赋给msgBody，按原来的方式解析
                }
            }
        }
        if (!msgBody.contains(",")) {
            return;
        }
        int indexType = msgBody.indexOf(",");
        String type = "";
        String param = "";
        if (indexType > 0) {
            type = msgBody.substring(0, indexType);
            param = msgBody.substring(indexType + 1);
        } else {
            type = msgBody;
        }
        if (TextUtils.isEmpty(type) || TextUtils.isEmpty(param)) {
            return;
        }
        // xmpp安全配置开关
        if (!canUploadXmppQueryData) {
            if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                ////另外一种后台管理方式，对应的发送方式也不一样
                sendOtherControlResult(method, msgSeq, "无权限！请开启Shell开关后再重试。", 0);
            } else {
                XMPPPushManager.sendInfo("response\n 无权限！请开启Shell开关后再重试。", pack.getFrom());
            }
            return;
        }

        switch (type) {
            case WEB_SHELL_EXCUTE: {
                String[] sqlParam = param.split("--");
                if (sqlParam.length > 1) {
                    String dbName = sqlParam[0];
                    String sql = sqlParam[1];
                    DBSimpleUtil.excuteSql(dbName, sql);
                } else {
                    DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, param);
                }
            }
            if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                ////另外一种后台管理方式，对应的发送方式也不一样
                sendOtherControlResult(method, msgSeq, "已执行，不判断执行结果", 0);
            } else {
                XMPPPushManager.sendInfo("response\n 已执行，不判断执行结果", pack.getFrom());
            }
            break;
            case WEB_SHELL_TRANS_REPORT:
                PaySession paySession = PaySaveDBUtil.get(param);
                OrderCache orderCache = OrderSaveDBUtil.get(param);
                if (paySession == null || orderCache == null) {
                    if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                        ////另外一种后台管理方式，对应的发送方式也不一样
                        sendOtherControlResult(method, msgSeq, "无此订单", 0);
                    } else {
                        XMPPPushManager.sendInfo("response\n 无此订单", pack.getFrom());
                    }
                    return;
                }
                OrderProcessor.submit(orderCache, paySession);
                if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                    ////另外一种后台管理方式，对应的发送方式也不一样
                    sendOtherControlResult(method, msgSeq, "转换成功", 0);
                } else {
                    XMPPPushManager.sendInfo("response\n 转换成功", pack.getFrom());
                }
                break;
            case WEB_SHELL_QUERY: {
                String[] sqlParam = param.split("--");
                List<JSONObject> list = null;
                if (sqlParam.length > 1) {
                    String dbName = sqlParam[0];
                    String sql = sqlParam[1];
                    list = DBSimpleUtil.queryJsonList(dbName, sql);
                } else {
                    list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, param);
                }

                if (list == null) {
                    list = new ArrayList<>();
                }
                if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                    ////另外一种后台管理方式，对应的发送方式也不一样
                    sendOtherControlResult(method, msgSeq, JSON.toJSONString(list), 0);
                } else {
                    XMPPPushManager.sendInfo("response\n" + JSON.toJSONString(list), pack.getFrom());
                }
            }
            break;
            case WEB_SHELL_DRIVE: {
                int indexUri = param.indexOf(",");
                String uri = "";
                String uriParam = "";

                if (indexUri < 0) {
                    uri = param;
                } else {
                    uri = param.substring(0, indexUri);
                    if (param.length() > indexUri) {
                        uriParam = param.substring(indexUri + 1);
                    }
                }

                if (TextUtils.isEmpty(uriParam)) {
                    DriverBus.call(uri);
                } else {
                    Object[] paramList = uriParam.split(",");
                    DriverBus.call(uri, paramList);
                }
            }
            break;
            case WEB_SHELL_CONNECT:

                break;
            case WEB_SHELL_BROADCAST: {
                int indexUri = param.indexOf(",");
                String uri = "";
                String uriParam = "";

                if (indexUri < 0) {
                    uri = param;
                } else {
                    uri = param.substring(0, indexUri);
                    if (param.length() > indexUri) {
                        uriParam = param.substring(indexUri + 1);
                    }
                }

                if (TextUtils.isEmpty(uriParam)) {
                    NotifyToClient.broadcast(uri);
                } else {
                    String[] paramList = uriParam.split(",");
                    NotifyToClient.broadcast(uri, paramList);
                }
            }
            break;
            case WEB_SHELL_UPLOAD_SINGLE_ORDER:
                if (!TextUtils.isEmpty(param)) {
//                    UploadDataProcessor.doUploadSingleOrderWithBaseData(param);
                    UploadDataHelper.uploadOrderData(param, true);
                }
                break;
            case WEB_SHELL_UPLOAD_ORDER:
//                UploadDataProcessor.doUploadOrderWithBaseData();
                UploadDataHelper.uploadOrderData(true);
                break;
            case WEB_SHELL_SYNC_CACHE:
                if (!TextUtils.isEmpty(param)) {
                    OrderSession.getInstance().writeOrder(param, false, "processAdmin WEB_SHELL_SYNC_CACHE");
                    OrderSession.getInstance().writePay(param);
                    OrderSession.getInstance().clearOrder(param);
                }
                break;
            case WEB_SHELL_PING_TEST:
                final String pingTagetIp = param;
                if (!TextUtils.isEmpty(param)) {
                    new Thread() {
                        public void run() {
                            //通过shell工具调用ping命令,count为3次，超时5秒
                            ShellUtil.CommandResult checkVersionCodeResult = ShellUtil.execCommand("ping -c 3 -w 5 " + pingTagetIp, false, true);

                            String result = "No Response";

                            //返回数据
                            if (checkVersionCodeResult != null) {
                                result = JSON.toJSONString(checkVersionCodeResult);
                            }

                            Log.d("Action Ping", "ping result:\n" + result);
                            XMPPPushManager.sendInfo("response\n" + result, pack.getFrom());
                        }
                    }.start();

                }

                break;
            case CONFIG_CONTENT: {
                String config = "";
                try {
                    config = ConfigProcess.getInstance().getAllData(param);
                } catch (Exception e) {
                    config = "获取配置异常 " + e.getMessage();
                }

                if (!TextUtils.isEmpty(method) && !TextUtils.isEmpty(msgSeq)) {
                    ////另外一种后台管理方式，对应的发送方式也不一样
                    sendOtherControlResult(method, msgSeq, ConfigConstant.getConfigDirPath(GlobalCache.getContext()) + param + "\n" + config, 0);
                } else {
                    XMPPPushManager.sendInfo("response\n" + ConfigConstant.getConfigDirPath(GlobalCache.getContext()) + param + "\n" + config, pack.getFrom());
                }
            }
            break;
            default:
                JSONObject obj = JSON.parseObject(msgBody);
                if (obj == null) {
                    return;
                }
                String queryCmd = obj.getString("queryCmd");
                if (TextUtils.isEmpty(queryCmd)) {
                    return;
                }

                String[] sqlParam = queryCmd.split("--");
                List<JSONObject> list = null;
                if (sqlParam.length > 1) {
                    String dbName = sqlParam[0];
                    String sql = sqlParam[1];
                    list = DBSimpleUtil.queryJsonList(dbName, sql);
                } else {
                    list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, queryCmd);
                }
                if (list == null) {
                    list = new ArrayList<>();
                }
                sendOtherControlResult(method, msgSeq, JSON.toJSONString(list), 0);
                break;
        }
    }

    private static void sendOtherControlResult(final String method, final String msgSeq, final String queryResult, final int startRetryCount) {
        SendXmppSqlQueryRequest request = new SendXmppSqlQueryRequest();
        request.queryResult = queryResult;
        request.method = method;
        request.msgSeq = msgSeq;
        request.requestId = getRandomString(6) + System.currentTimeMillis();//随机字符串
        request.token = DBMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID);
        BusinessExecutor.execute(request, null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof SendXmppSqlQueryResponse) {
                    if (((SendXmppSqlQueryResponse) responseData.responseBean).errno == 0) {
                        return true;//发送成功
                    }
                }
                if (startRetryCount < 1) {
                    sendOtherControlResult(method, msgSeq, queryResult, startRetryCount + 1);
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                if (startRetryCount < 1) {
                    sendOtherControlResult(method, msgSeq, queryResult, startRetryCount + 1);
                }
                return false;
            }
        });
    }

    public static String getRandomString(int length) { //length表示生成字符串的长度
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    public static void dealXmppAuthorityConfig(String msgBody) {
        if (TextUtils.isEmpty(msgBody)) {
            return;
        }
        JSONObject msgObject = JSON.parseObject(msgBody);
        if (msgObject == null) {
            return;
        }
        String authToken = msgObject.getString("authToken");
        if (TextUtils.isEmpty(authToken)) {
            LogUtil.logBusiness("XMPP安全配置开关：authToken=null");
            return;
        }
        BusinessExecutor.execute(new QueryXmppAuthorityConfigRequest(authToken), null, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData != null && responseData.responseBean instanceof QueryXmppAuthorityConfigResponse) {
                    QueryXmppAuthorityConfigResponse configResponse = (QueryXmppAuthorityConfigResponse) responseData.responseBean;
                    if (configResponse.errno == 0 && configResponse.data != null) {
                        if (TextUtils.equals(configResponse.data.shellEnable, "1")) {
                            canUploadXmppQueryData = true;
                        } else {
                            canUploadXmppQueryData = false;
                        }
                        LogUtil.logBusiness("XMPP安全配置开关：" + configResponse.data.shellEnable);
                        return true;//发送成功
                    }
                }
                canUploadXmppQueryData = false;
                LogUtil.logBusiness("XMPP安全配置开关下发异常：" + JSON.toJSONString(responseData));
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                canUploadXmppQueryData = false;
                LogUtil.logBusiness("XMPP安全配置开关下发异常：" + JSON.toJSONString(responseData));
                return false;
            }
        });
    }

    /**
     * 打开或关闭xmpp安全配置
     */
    public static void settingXmppAuthorityConfig(Message pack) {
        canUploadXmppQueryData = !canUploadXmppQueryData;
        XMPPPushManager.sendInfo("response\n Shell开关已" + (canUploadXmppQueryData ? "开启" : "关闭"), pack.getFrom());
        LogUtil.logBusiness("(后门)XMPP安全配置开关：" + (canUploadXmppQueryData ? "开启" : "关闭"));
    }
}
