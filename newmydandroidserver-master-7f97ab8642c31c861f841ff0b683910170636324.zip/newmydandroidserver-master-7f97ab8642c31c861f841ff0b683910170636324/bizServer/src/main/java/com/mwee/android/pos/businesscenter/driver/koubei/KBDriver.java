package com.mwee.android.pos.businesscenter.driver.koubei;


import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.connect.business.order.OrderDetailResponse;
import com.mwee.android.air.db.business.kbbean.KBPreOrderUpdateResponse;
import com.mwee.android.air.db.business.kbbean.KBShopInfoResponse;
import com.mwee.android.air.db.business.kbbean.KBVerifyPreOrderResponse;
import com.mwee.android.air.db.business.kbbean.KPreOrderDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreTempDataResponse;
import com.mwee.android.air.db.business.kbbean.KPreVerifyOrderRequest;
import com.mwee.android.air.db.business.kbbean.KPreVerifyResponse;
import com.mwee.android.air.db.business.kbbean.ScannerTableOrderAcceptResponse;
import com.mwee.android.air.db.business.kbbean.bean.KBPartRefundExtInfo;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.db.business.kbbean.bean.RefundAction;
import com.mwee.android.base.GlobalCache;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayOrder;
import com.mwee.android.air.db.business.kbbean.bean.KBTempDataModel;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataModel;
import com.mwee.android.air.db.business.kbbean.future.KBFutureTempDataResponse;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.shop.KouBeiShopInfo;
import com.mwee.android.pos.businesscenter.module.koubei.service.IKBOrderService;
import com.mwee.android.pos.businesscenter.module.koubei.service.impl.KBOrderServiceImpl;
import com.mwee.android.air.util.KBConstants;
import com.mwee.android.pos.businesscenter.business.koubei.KBMakePrinter;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderApi;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderDBUtils;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.KBPreOrderTableProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.future.KBFutureProcessor;
import com.mwee.android.pos.businesscenter.business.koubei.future.ResultCallback;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.print.PrintOrderUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by zhangmin on 2018/5/17.
 */

public class KBDriver implements IDriver {

    private final static String TAG = "kb_driver";

    @Override
    public String getModuleName() {
        return TAG;
    }

    /*-------------------------------------口碑先付款-------------------------------------*/
    @DrivenMethod(uri = TAG + "/loadOrder")
    public SocketResponse loadOrder(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String order_id = request.getString("order_id"); //订单号 美味订单号也有可能是口碑订单号
        String merchant_id = request.getString("merchant_id"); //订单号
        KPreOrderDataResponse dataResponse = new KPreOrderDataResponse();
        dataResponse.local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
        response.data = dataResponse;
        KBPreOrderApi orderApi = new KBPreOrderApi();
        orderApi.loadOrder(order_id, merchant_id, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KPreOrderDataResponse) {
                    KPreOrderDataResponse kPreOrderDataResponse = (KPreOrderDataResponse) responseData.responseBean;
                    KBPreOrderCache orderCache = kPreOrderDataResponse.data;
                    KBPreOrderDBUtils.insert(orderCache, true);
                    dataResponse.data = orderCache;
                    response.code = SocketResultCode.SUCCESS;
                } else {
                    response.message = "获取数据失败";
                    response.code = SocketResultCode.BUSINESS_FAILED;
                }
                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                response.message = responseData.resultMessage;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });
        return response;
    }


    @DrivenMethod(uri = TAG + "/loadOrderList")
    public SocketResponse loadOrderList(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        int pageNo = request.getInteger("pageNo");
        String searchParam = request.getString("searchParam");
        int queryType = request.getInteger("queryType");
        String status = request.getString("status");

        new KBPreOrderApi().loadOrderList(pageNo, searchParam, queryType, status, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KPreTempDataResponse) {
                    KPreTempDataResponse kPreTempDataResponse = (KPreTempDataResponse) responseData.responseBean;
                    for (KBTempDataModel dataModel : kPreTempDataResponse.data.koubeiOrder) {

                        /**
                         * 口碑先付款的订单
                         *    如果是桌台模式 并且是扫码支付带桌台信息过来  因为后台推送过来的可能是桌号 那么需要给转桌号为桌台 吴丽丽产品的需求
                         *    如果是桌台模式 并且是不是扫码支付          因为桌台信息是前台客户端主动分配  那么无需中转 吴丽丽产品的需求
                         */
                        if (dataModel.fsBusinessType.equals("DINNER") && dataModel.fsOrderStyle.equals("SCAN")) {
                            String fsMtableName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMtableName from tbMtable where fistatus = '1' and fsMtableId = '" + dataModel.fsTableNO + "'");
                            if (!TextUtils.isEmpty(fsMtableName)) {
                                dataModel.fsTableNO = fsMtableName;
                            }
                        }
                    }

                    response.data = kPreTempDataResponse;

                    response.code = SocketResultCode.SUCCESS;
                } else {
                    response.message = "获取数据失败";
                    response.code = SocketResultCode.BUSINESS_FAILED;
                }

                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                response.message = responseData.resultMessage;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });

        return response;
    }


    @DrivenMethod(uri = TAG + "/loadOrderFromCache")
    public SocketResponse loadOrderFromCache(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);
        String order_id = request.getString("orderId"); //订单号 美味订单号也有可能是口碑订单号
        KPreOrderDataResponse dataResponse = new KPreOrderDataResponse();
        dataResponse.local_order_id = order_id;
        String thirdOrderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select thirdOrderId from order_cache where order_id = '" + order_id + "'");
        response.data = dataResponse;
        dataResponse.data = KBPreOrderDBUtils.query(thirdOrderId);
        response.code = SocketResultCode.SUCCESS;

        return response;
    }


    @DrivenMethod(uri = TAG + "/doPrinter")
    public SocketResponse doPrinter(SocketHeader head, String param) {


        final SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            response.code = SocketResultCode.USER_SESSION_EXPIRED;
            response.message = "用户登录信息已过期，请退出重新登录";
            return response;
        }

        String order_id = request.getString("order_id"); //订单号

        if (APPConfig.isAir(GlobalCache.getContext())) {
            KBMakePrinter.printAirBill(order_id);
        } else {
            KBMakePrinter.printBill(order_id);
        }


        response.code = SocketResultCode.SUCCESS;

        return response;
    }

    /**
     * 核销打印制作单
     * <p>
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/verificationDoPrinter")
    public SocketResponse verificationDoPrinter(SocketHeader head, String param) {


        final SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
        if (userDBModel == null) {
            response.code = SocketResultCode.USER_SESSION_EXPIRED;
            response.message = "用户登录信息已过期，请退出重新登录";
            return response;
        }

        String order_id = request.getString("order_id"); //订单号

        KBMakePrinter.printKBMake(order_id);

        String sql = "select order_id from order_cache where thirdOrderId = '" + order_id + "'";
        String fsSellno = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);

        OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellno);
        if (orderCache != null) {
            KBPreOrderCache kbPreOrderCache = KBPreOrderDBUtils.query(order_id);
            //todo 点菜单
            PrintOrderUtil.printRapidMenuList(orderCache, HostUtil.getCurrentHost());
            //打印传菜单
            PrintOrderUtil.printPassTo(orderCache, kbPreOrderCache.table_time, HostUtil.getCurrentHost());
        }

        response.code = SocketResultCode.SUCCESS;

        return response;
    }

    @DrivenMethod(uri = TAG + "/acceptOrder")
    public SocketResponse acceptOrder(SocketHeader head, String param) {
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String merchant_id = request.getString("merchant_id"); //订单号

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }
            String resultMsg = doAcceptOrder(preOrderCache);

            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            String sql = "select order_id from order_cache where thirdOrderId = '" + order_id + "'";
            myResponseData.local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
            response.data = myResponseData;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/rejectOrder")
    public SocketResponse rejectOrder(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String merchant_id = request.getString("merchant_id"); //订单号

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }
            String resultMsg = KBPreOrderProcessor.rejectOrder(order_id, merchant_id, preOrderCache.take_no, request.getString("reason"));

            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            String sql = "select order_id from order_cache where thirdOrderId = '" + order_id + "'";
            myResponseData.local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
            response.data = myResponseData;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/prepareOrder")
    public SocketResponse prepareOrder(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String merchant_id = request.getString("merchant_id"); //订单号

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }

            String resultMsg = KBPreOrderProcessor.prepareOrder(order_id, preOrderCache.business_type, merchant_id, preOrderCache.take_no);
            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            String sql = "select order_id from order_cache where thirdOrderId = '" + order_id + "'";
            myResponseData.local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
            response.data = myResponseData;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 接单
     *
     * @param preOrderCache
     * @return
     */
    private String doAcceptOrder(KBPreOrderCache preOrderCache) {
        String msg = "";
        //大前提应该是桌台模式
        if (!KBPreOrderDBUtils.isTableDinner(preOrderCache.business_type)) {
            msg = KBPreOrderProcessor.acceptOrder(preOrderCache, preOrderCache.take_no, 0);
            return msg;
        }
        switch (preOrderCache.order_style) {
            case KBConstants.ORDER_STYLE_LATFORM:
                if (KBPreOrderDBUtils.isTableForHere(preOrderCache.dinner_type)) {
                    //口碑堂食模式
                    msg = KBPreOrderTableProcessor.acceptTableOrder(preOrderCache, 0);
                } else {
                    //口碑外卖模式
                    msg = KBPreOrderProcessor.acceptOrder(preOrderCache, preOrderCache.take_no, 0);
                }
                break;
            case KBConstants.ORDER_STYLE_SCAN:
                IKBOrderService service = new KBOrderServiceImpl();
                SocketResponse<ScannerTableOrderAcceptResponse> response = service.acceptPreOrder(preOrderCache);
                if (!response.success()) {
                    msg = response.message;
                }
                break;
            default:
                break;
        }
        return msg;
    }

    /**
     * 口碑商家主动退款
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/refundOrder")
    public synchronized SocketResponse refundOrder(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //口碑订单号
            String merchant_id = request.getString("merchant_id"); //商户ID
            String fsSellNo = request.getString("fsSellNo"); //美味订单号ID
            String reason = request.getString("reason"); //商户退款原因

            //todo 退款金额(部分退款，本地订单不存在或已经清除时才传)
            String refundAmount = request.getString("refundAmount");

            //todo 本地口碑订单选中需要退款的菜品唯一标识符(部分退款，本地订单存在时才传)
            ArrayList<MenuItem> choiceRefundMenuList = null;
            if (!TextUtils.isEmpty(request.getString("choiceRefundMenuList"))) {
                choiceRefundMenuList = (ArrayList<MenuItem>) JSONArray.parseArray(request.getString("choiceRefundMenuList"), MenuItem.class);
            }

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }

            //todo 整单退款
            if (TextUtils.isEmpty(refundAmount) && ListUtil.isEmpty(choiceRefundMenuList)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "业务中心收到退款请求", "整单退款------>>>口碑订单号：" + order_id);
                String resultMsg = KBPreOrderProcessor.refundOrder(order_id, fsSellNo, merchant_id, preOrderCache.take_no, reason, userDBModel);
                if (!TextUtils.isEmpty(resultMsg)) {
                    response.message = resultMsg;
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    return response;
                }

                String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
                KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
                myResponseData.data = KBPreOrderDBUtils.query(order_id);
                myResponseData.local_order_id = local_order_id;

                response.data = myResponseData;
                response.message = "success";
                response.code = SocketResultCode.SUCCESS;

                KBPreOrderDBUtils.doAntiPayZeroBill(head, preOrderCache, RefundAction.ACTION_BUSSINESS);

                if (APPConfig.isMydKouBei()) {
                    NotifyToClient.refreshKBOrderItem(myResponseData);
                }

                //todo 本地定单不存在，只退款不操作本地订单数据
            } else if (ListUtil.isEmpty(choiceRefundMenuList) && !TextUtils.isEmpty(refundAmount)) {
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "业务中心收到退款请求", "部分退款------>>>本地定单 不存在，只退款不操作本地订单数据------>>>口碑订单号：" + order_id + "   退款金额=" + refundAmount);
                KBPartRefundExtInfo extInfo = KBPreOrderProcessor.partRefundOrder(order_id, fsSellNo, merchant_id, preOrderCache.take_no, reason, refundAmount, userDBModel);
                if (extInfo.errno != 0) {
                    response.message = extInfo.errmsg;
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    return response;
                }

                String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
                KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
                myResponseData.data = KBPreOrderDBUtils.query(order_id);
                myResponseData.local_order_id = local_order_id;

                response.data = myResponseData;
                response.message = "success";
                response.code = SocketResultCode.SUCCESS;

                if (APPConfig.isMydKouBei()) {
                    NotifyToClient.refreshKBOrderItem(myResponseData);
                }

                //todo 本地定单存在，退款后需要修改本地订单数据
            } else if (!ListUtil.isEmpty(choiceRefundMenuList) && TextUtils.isEmpty(refundAmount)) {
                OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);
                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "业务中心收到退款请求", "部分退款------>>>本地定单 存在，退款后需要修改本地订单数据------>>>口碑订单号：" + order_id);

                //计算所有退款菜品总金额
                BigDecimal totalAmountSum = BigDecimal.ZERO;
                for (int i = 0; i < choiceRefundMenuList.size(); i++) {
                    MenuItem model = choiceRefundMenuList.get(i);
                    //退含有赔偿菜的菜品 需要加上配料菜的价格
                    for (MenuItem modifierMenuItem : model.menuBiz.selectedModifier) {
                        totalAmountSum = totalAmountSum.add(modifierMenuItem.currentUnit.fdSalePrice.multiply(modifierMenuItem.menuBiz.buyNum));
                    }
                    totalAmountSum = totalAmountSum.add(model.currentUnit.fdSalePrice.multiply(model.menuBiz.buyNum));
                }


                RunTimeLog.addLog(RunTimeLog.NETORDER_UPDATE, "计算所有退款菜品总金额", "所有退款菜品：  " + JSONObject.toJSON(choiceRefundMenuList).toString() + "   退款总金额=" + totalAmountSum);

                KBPartRefundExtInfo extInfo = KBPreOrderProcessor.partRefundOrder(order_id, fsSellNo, merchant_id, preOrderCache.take_no, reason, totalAmountSum.toString(), userDBModel);
                if (extInfo.errno != 0) {
                    response.message = extInfo.errmsg;
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    return response;
                }

                String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
                KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
                myResponseData.data = KBPreOrderDBUtils.query(order_id);
                myResponseData.local_order_id = local_order_id;

                response.data = myResponseData;
                response.message = "success";
                response.code = SocketResultCode.SUCCESS;

                //todo (本地)口碑预点单 部分 退款
                KBPreOrderDBUtils.doPartAntiPayZeroBill(head, preOrderCache, choiceRefundMenuList, extInfo);

                if (APPConfig.isMydKouBei()) {
                    NotifyToClient.refreshKBOrderItem(myResponseData);
                }
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 口碑退款获取本地订单信息
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/kbRefundGetOrder")
    public SocketResponse kbRefundGetOrder(SocketHeader head, String param) {

        SocketResponse socketResponse = new SocketResponse();

        if (HostUtil.getUserModelBySession(head.us) == null) {
            socketResponse.code = SocketResultCode.USER_SESSION_EXPIRED;
            socketResponse.message = "用户登录信息已过期，请退出重新登录";
            return socketResponse;
        }

        String order_id = JSON.parseObject(param).getString("kb_order_id"); //订单号
        //检查口碑本地订单是否可以退款
        OrderCache orderCache = KBPreOrderDBUtils.isCanRefund(order_id);
        OrderDetailResponse orderDetailResponse = new OrderDetailResponse();
        if (orderCache != null) {
            orderDetailResponse.orderCache = orderCache;
            socketResponse.data = orderDetailResponse;
            socketResponse.code = SocketResultCode.SUCCESS;
        } else {
            socketResponse.code = SocketResultCode.EXCEPTION;
        }


        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/rejectRefundOrder")
    public SocketResponse rejectRefundOrder(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String merchant_id = request.getString("merchant_id"); //商户ID
            String fsSellNo = request.getString("fsSellNo"); //商户ID
            String rejectReason = request.getString("rejectReason"); //商户拒绝接单理由

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }
            String resultMsg = KBPreOrderProcessor.rejectRefundOrder(order_id, fsSellNo, merchant_id, preOrderCache.take_no, rejectReason, userDBModel);
            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            myResponseData.local_order_id = local_order_id;
            response.data = myResponseData;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/agreeRefundOrder")
    public SocketResponse agreenRefundOrder(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String merchant_id = request.getString("merchant_id"); //商户ID
            String fsSellNo = request.getString("fsSellNo"); //商户ID
            String agreeRefundReason = request.getString("agreeRefundReason"); //商户同意退款的理由

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单";
                return response;
            }
            String resultMsg = KBPreOrderProcessor.agreenRefundOrder(order_id, fsSellNo, merchant_id, preOrderCache.take_no, agreeRefundReason, userDBModel);
            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            myResponseData.local_order_id = local_order_id;
            response.data = myResponseData;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                KBPreOrderDBUtils.doAntiPayZeroBill(head, preOrderCache, RefundAction.ACTION_BUSSINESS);
            } else {
                KBPreOrderDBUtils.doAntiPayZeroBill(head, preOrderCache, RefundAction.ACTION_CUSTOMER);
            }

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/allocationTable")
    public synchronized SocketResponse allocationTable(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "用户登录信息已过期，请退出重新登录";
                return response;
            }

            String order_id = request.getString("order_id"); //订单号
            String targetTableID = request.getString("targetTableID"); //分配的桌台ID
            boolean printMake = request.getBooleanValue("printMake"); //是否打印单子

            KBPreOrderCache preOrderCache = KBPreOrderDBUtils.query(order_id);//处理之前的数据
            if (preOrderCache == null) {
                response.code = SocketResultCode.EXCEPTION;
                response.message = "没有找到订单" + order_id;
                return response;
            }
            String resultMsg = new KBOrderServiceImpl().allocationTableOrder(order_id, targetTableID, printMake);
            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from order_cache where thirdOrderId = '" + order_id + "'");
            KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
            myResponseData.data = KBPreOrderDBUtils.query(order_id);
            myResponseData.local_order_id = local_order_id;
            response.data = myResponseData;
            response.code = SocketResultCode.SUCCESS;

            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(myResponseData);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @DrivenMethod(uri = TAG + "/loadVerifyOrder")
    public SocketResponse loadVerifyOrder(SocketHeader head, String param) {
        SocketResponse socketResponse = new SocketResponse();
        String verify_order_id = JSON.parseObject(param).getString("verify_order_id");
        if (TextUtils.isEmpty(verify_order_id)) {
            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
            socketResponse.message = "核销编号不能为空";
            return socketResponse;
        }
        KPreVerifyOrderRequest request = new KPreVerifyOrderRequest();
        request.verify_order_id = verify_order_id;
        BusinessExecutor.execute(request, new IExecutorCallback() {
            @Override
            public void success(ResponseData response) {
                if (response.responseBean != null && response.responseBean instanceof KPreVerifyResponse) {
                    KPreVerifyResponse kPreVerifyResponse = (KPreVerifyResponse) response.responseBean;
                    KBVerifyPreOrderResponse kbVerifyPreOrderResponse = new KBVerifyPreOrderResponse();
                    kbVerifyPreOrderResponse.preVerify = kPreVerifyResponse.data;

                    KBPreOrderUpdateResponse myResponseData = new KBPreOrderUpdateResponse();
                    myResponseData.data = KBPreOrderDBUtils.query(kPreVerifyResponse.data.order_id);
                    String sql = "select order_id from order_cache where thirdOrderId = '" + kPreVerifyResponse.data.order_id + "'";
                    myResponseData.local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
                    socketResponse.data = myResponseData;

                    socketResponse.code = SocketResultCode.SUCCESS;
                    socketResponse.message = "";

                    if (APPConfig.isMydKouBei()) {
                        NotifyToClient.refreshKBOrderItem(myResponseData);
                    }
                } else {
                    socketResponse.code = response.result;
                    socketResponse.message = response.resultMessage;
                }
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = responseData.result;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        }, false);
        return socketResponse;
    }

    @DrivenMethod(uri = TAG + "/loadCheckOut")
    public SocketResponse loadCheckOut(SocketHeader head, String param) {
        JSONObject jsonObject = JSONObject.parseObject(param);
        String orderId = jsonObject.getString("orderId");
        return new KBOrderServiceImpl().checkOut(orderId, HostUtil.getUserModelBySession(head.us));
    }


    /*-------------------------------------口碑后付款-------------------------------------*/

    @DrivenMethod(uri = TAG + "/acceptKbAfterPayOrder")
    public SocketResponse acceptKbAfterPayOrder(SocketHeader head, String param) {
        JSONObject jsonObject = JSONObject.parseObject(param);
        KBAfterPayOrder kbAfterPayOrder = jsonObject.getObject("kbAfterPayOrder", KBAfterPayOrder.class);
        return new KBOrderServiceImpl().acceptAfterPayOrder(kbAfterPayOrder, head.hd);
    }


    @DrivenMethod(uri = TAG + "/rejectFutureOrder")
    public SocketResponse rejectFutureOrder(SocketHeader head, String param) {
        final SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);

            String order_id = request.getString("order_id");
            String batchNo = request.getString("batchNo");
            String rejectReason = request.getString("rejectReason"); //商户拒绝接单理由
            String id = request.getString("id"); //唯一标识符

            String resultMsg = KBFutureProcessor.rejectFutureOrder(order_id, batchNo, rejectReason);
            if (!TextUtils.isEmpty(resultMsg)) {
                response.message = resultMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            ScannerTableOrderAcceptResponse scannerTableOrderAcceptResponse = new ScannerTableOrderAcceptResponse();
            scannerTableOrderAcceptResponse.status = KBConstants.STATUS_REJECT;
            response.data = scannerTableOrderAcceptResponse;
            response.message = "success";
            response.code = SocketResultCode.SUCCESS;
            if (APPConfig.isMydKouBei()) {
                NotifyToClient.refreshKBOrderItem(id, KBConstants.STATUS_REJECT);
            }
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    @DrivenMethod(uri = TAG + "/loadFutureOrderList")
    public SocketResponse loadFutureOrderList(SocketHeader head, String param) {

        final SocketResponse response = new SocketResponse();
        JSONObject request = JSON.parseObject(param);

        int pageIndex = request.getInteger("pageIndex");
        String orderId = request.getString("orderId");
        String status = request.getString("status");

        KBFutureProcessor.loadFutureTempOrderHeader(pageIndex, orderId, status, new BusinessCallback() {
            @Override
            public boolean success(int i, ResponseData responseData) {
                if (responseData.responseBean != null && responseData.responseBean instanceof KBFutureTempDataResponse) {
                    KBFutureTempDataResponse futureTempDataResponse = (KBFutureTempDataResponse) responseData.responseBean;
                    for (KBFutureTempDataModel dataModel : futureTempDataResponse.data.list) {

                        /**
                         * 口碑后付款的订单
                         *    口碑后付款的订单只有扫码桌台  因为后台推送过来的可能是桌号 那么需要给转桌号为桌台 吴丽丽产品的需求
                         */
                        String fsMtableName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMtableName from tbMtable where fistatus = '1' and fsMtableId = '" + dataModel.tableNo + "'");
                        if (!TextUtils.isEmpty(fsMtableName)) {
                            dataModel.tableNo = fsMtableName;
                        }
                    }
                    response.data = futureTempDataResponse;
                    response.code = SocketResultCode.SUCCESS;
                } else {
                    response.message = "获取数据失败";
                    response.code = SocketResultCode.BUSINESS_FAILED;
                }

                return false;
            }

            @Override
            public boolean fail(int i, ResponseData responseData) {
                response.message = responseData.resultMessage;
                response.code = SocketResultCode.BUSINESS_FAILED;
                return false;
            }
        });

        return response;
    }


    @DrivenMethod(uri = TAG + "/loadKoubeiShopInfo")
    public SocketResponse loadKoubeiShopId(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            response.code = SocketResultCode.BUSINESS_FAILED;
            KBFutureProcessor.loadKBShopInfo(new ResultCallback<KouBeiShopInfo>() {
                @Override
                public void onSuccess(KouBeiShopInfo data) {
                    //缓存美味绑定的口碑门店信息
                    DBMetaUtil.updateSettingsValueByKey(META.KB_MERCHANT_PID, data.merchantPid);
                    DBMetaUtil.updateSettingsValueByKey(META.KB_SHOP_ID, data.alipayShopId);
                    DBMetaUtil.updateSettingsValueByKey(META.MW_MANAGE_SHOPID, data.mwShopId);
                    KBShopInfoResponse kbShopInfoResponse = new KBShopInfoResponse();
                    kbShopInfoResponse.kouBeiShopInfo = data;
                    response.data = kbShopInfoResponse;
                    response.code = SocketResultCode.SUCCESS;
                }

                @Override
                public void onFailure(int code, String msg) {
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = msg;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            response.code = SocketResultCode.BUSINESS_FAILED;
        }

        return response;
    }


}
