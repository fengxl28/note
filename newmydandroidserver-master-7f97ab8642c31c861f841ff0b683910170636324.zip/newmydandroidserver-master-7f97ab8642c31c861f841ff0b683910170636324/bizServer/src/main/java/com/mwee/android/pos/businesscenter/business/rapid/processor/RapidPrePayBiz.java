package com.mwee.android.pos.businesscenter.business.rapid.processor;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.pos.business.dinnerstandard.DinnerStandardUtil;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.businesscenter.business.message.MessageAbnormalOrderBizProcessor;
import com.mwee.android.pos.businesscenter.business.order.api.SellOutServerProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidApi;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.component.iocache.CacheModel;
import com.mwee.android.pos.component.iocache.IOCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.order.model.SubmitOrderCheckNumResult;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.order.Order;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.order.discount.CouponCutMoney;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.List;

/**
 * 秒点预付款订单的业务处理类
 * Created by virgil on 2017/7/24.
 *
 * @author virgil
 */
public class RapidPrePayBiz {
    /**
     * 收到秒点预付款的菜品
     *
     * @param data  RapidGetModel
     * @param order RapidOrder
     */
    public static void receivePreOrderMenu(RapidActionModel resultData, RapidGetModel data, RapidOrder order) {
        if (NetOrderType.isRapidPrePay(order.bizType) || NetOrderType.isShareShopPrePay(order.bizType)) {
            TempOrderDishesCache tempDishes = RapidApi.buildTempOrder(resultData, order, data.fsid);
            if (resultData.result == RapidResult.SUCCESS && tempDishes != null) {

                //添加预点菜品
//                if (getPreOrderCountByTable(tempDishes.fsmtableid) <= 0) {
//                    String existOrderID = TableBusinessUtil.getOrderIDByTableID(tempDishes.fsmtableid);
//                    boolean canAddOpenParamMenu = true;
//                    if (!TextUtils.isEmpty(existOrderID) && OrderUtil.hasMenu(existOrderID)) {
//                        canAddOpenParamMenu = false;
//                    }
//                    if (canAddOpenParamMenu) {
//                        tempDishes.tempSelectedMenuList.addAll(OrderBizUtil.getOpenParamOrderMenu(tempDishes.fsmareaid, tempDishes.personNum, tempDishes.waiterID, tempDishes.waiterName));
//                    }
//                }

                // 校验餐标/低消
                String checkErr = DinnerStandardUtil.checkDinnerStandardPayExcludeMinStandard(tempDishes);
                if (!TextUtils.isEmpty(checkErr)) {
                    RapidBiz.buildResultError(resultData, checkErr);
                    return;
                }

                //检查沽清
                SubmitOrderCheckNumResult checkSellout = SellOutServerProcessor.checkSellOutValue(tempDishes.tempSelectedMenuList, false);
                if (!checkSellout.success) {
                    RapidBiz.buildSellOut(resultData, RapidResult.ERROR_SELL_OUT, checkSellout.errorMsg, checkSellout);
                } else {

                    tempDishes.isMember = order.needBuildMemberPrice();

                    MenuItemVipPriceUtil.useCouponWhenBindMember(HostUtil.getShopID(), tempDishes.tempSelectedMenuList,
                            order.needBuildMemberPrice(), StringUtil.toInt(order.memberLevel),
                            "cash", order.memberId, order.plusId);

                    /*if (order.isVipPrice != -1 && !DBMetaUtil.autoUseMemberPrice() && !DBMetaUtil.autoUseVipDiscount()) {
                        OrderCache.updateAllMenuToMemberPrice(tempDishes.tempSelectedMenuList,
                                order.needBuildMemberPrice(),  StringUtil.toInt
                                        (order.memberLevel), "cash", order.memberId, order.plusId);
                    }*/

                    tempDishes.plusTempSelectedMenuAmount();

                    CouponCutMoney cut = OrderCache.checkCouponMoney(OrderUtil.initOrderCutList(HostUtil.getHistoryBusineeDate("")), tempDishes.tempSelectedMenuList, tempDishes.tempTotalPrice, OrderUtil.getSectionId(), false, tempDishes.isDiningStandard());
                    if (cut != null) {
                        tempDishes.tempTotalPrice = tempDishes.tempTotalPrice.subtract(cut.fdCutmoney);
                    }

                    keepOneOrder(tempDishes.fsmtableid);
                    writeTempOrderToIO(tempDishes, data.fsid);
                }
            }
        }
    }

    private static BigDecimal calcNotPayed(String fsmtableid, TempOrderDishesCache tempOrder, RapidPayment payment) {
        OrderCache orderCache = RapidApi.queryOrderByTableId(fsmtableid);
        if (orderCache != null) {
            if (!TextUtils.isEmpty(payment.fsMemberNo)) {
                orderCache.updateOrderToMember(payment.fsMemberNo, StringUtil.toInt(payment.memberLevel), payment.memberId, payment.plusId);
                if (payment.isVip == 1) {
//                    orderCache.updateAllMenuToMemberPrice();
                    MenuItemVipPriceUtil.useCouponWhenBindMember(orderCache, true, "cash");
                }
            }
            //已将下面逻辑移动到RapidBiz.convert方法里
//            orderCache = orderCache.clone();
//            if (tempOrder != null && !ListUtil.isEmpty(tempOrder.tempSelectedMenuList)) {
//                orderCache.originMenuList.addAll(tempOrder.tempSelectedMenuList);
//                orderCache.reCalcAllByAll();
//            }
            RapidOrder existOrder = null;
            RapidOrder rapidOrder = new RapidOrder(payment);

            existOrder = RapidApi.buildRapidOrder(rapidOrder, orderCache, tempOrder == null ? null : tempOrder.tempSelectedMenuList);
            return existOrder.notPaymentAmount;
        } else {
            return tempOrder == null ? BigDecimal.ZERO : tempOrder.tempTotalPrice;
        }
    }

    /**
     * 收到秒点预付款的收款明细
     *
     * @param resultData RapidActionModel
     * @param payment    RapidPayment
     */
    public static void receivePreOrderPay(RapidActionModel resultData, final RapidPayment payment) {
        TempOrderDishesCache tempOrder = buildPrePayOrderFull(payment.tableNo, payment.userId, payment.orderId, !TextUtils.isEmpty(payment.fsMemberNo), payment.isVipPrice, StringUtil.toInt(payment.memberLevel), payment.memberId, payment.plusId);
        boolean amtNeedVoid;//是否需要自动退款
        BigDecimal totalPayed = parseRapidPayTotalAmt(payment);

        //先付款模式，秒付付款时发现桌台已被口碑先付订单占用，此时数据应被落入异常订单中
        OrderCache orderCache = RapidApi.queryOrderByTableId(payment.tableNo);
        if (orderCache != null && NetOrderType.isKouBeiOrder(orderCache.thirdOrderType)) {
            MessageAbnormalOrderBizProcessor.addRapidPayAbnormalMsg(tempOrder, payment, totalPayed, 0, TableDBUtil.optOrderIDByTableID(payment.tableNo), "桌台已有口碑支付信息，秒付加菜付款失败。");
            return;
        }

        String errReason = "";
        //桌台上的待支付金额
        BigDecimal totalOrderNotPaied = calcNotPayed(payment.tableNo, tempOrder, payment);
        RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY, "收到预付款 支付金额[" + totalPayed.toPlainString() + "],订单金额[" + totalOrderNotPaied.toPlainString() + "]", "", payment.tableNo, payment, tempOrder);

//        if (totalOrderNotPaied.compareTo(BigDecimal.ZERO) > 0) {
        if (totalPayed.compareTo(totalOrderNotPaied) >= 0) {
            if (tempOrder != null) {
                //如果支付金额大于或者等于订单金额
                RapidBiz.autoOrder(resultData, tempOrder, true);
                if (resultData.result == RapidResult.SUCCESS) {
                    amtNeedVoid = false;
                    clearPreOrderInfoByThirdOrder(tempOrder.optFirstThirdOrderID());
                } else {
                    //如果下单失败，则进行自动退款
                    errReason = resultData.errorInfo;
                    RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_MENU_NO, "先付款的秒付 菜品下单失败，原因：" + resultData.errorInfo, "", payment.tableNo, payment, tempOrder);
                    amtNeedVoid = true;
                }
            } else {
                //存秒付
                amtNeedVoid = false;
            }
        } else {
            //如果已支付的总金额小于已点单菜品的总金额，则进行自动退款
            errReason = "支付金额[" + totalPayed.toPlainString() + "],订单金额[" + totalOrderNotPaied.toPlainString() + "]";
            amtNeedVoid = true;
        }
//        } else {
//            errReason = "订单已支付完毕";
//            amtNeedVoid = true;
//        }

        if (!amtNeedVoid) {
            payment.rapidMenuOrderIdInner = tempOrder == null ? "" : tempOrder.optFirstThirdOrderID();
            RapidApi.submitPay(resultData, payment);
            if (resultData.result != RapidResult.SUCCESS) {
                errReason = resultData.errorInfo;
                RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_NO, "先付款的秒付落帐失败，需要自动退款[" + resultData.errorInfo + "]", "", payment.tableNo, payment, tempOrder);
                amtNeedVoid = true;
            }
        } else {
            RapidBiz.buildResultError(resultData, "下单失败 支付金额[" + totalPayed.toPlainString() + "],订单金额[" + totalOrderNotPaied + "]");
        }
        if (amtNeedVoid) {
            //2018-05-25  秒付先付款模式不再自动退款
            //失败则清除这个单
            if (tempOrder != null) {
                clearPreOrderInfoByThirdOrder(tempOrder.optFirstThirdOrderID());
            }
            MessageAbnormalOrderBizProcessor.addRapidPayAbnormalMsg(tempOrder, payment, totalPayed, 0, TableDBUtil.optOrderIDByTableID(payment.tableNo), errReason);
//
//            BusinessExecutor.executeNoWait(() -> {
//                //失败则清除这个单
//                if (tempOrder != null) {
//                    clearPreOrderInfoByThirdOrder(tempOrder.optFirstThirdOrderID());
//                }
//                BillUtil.autoVoidRapidPay("", payment.orderId);
//                return null;
//            });
        }
    }


    /**
     * 收到秒点预付款的收款明细
     *
     * @param payment RapidPayment
     * @return int | 0 成功； -1:支付信息入订单失败； -2:菜品入订单失败   -3: 没有菜品也没有支付信息
     */
    public static int receivePreOrderPay(RapidActionModel resultData, final RapidPayment payment, TempOrderDishesCache tempOrder) {
        if (tempOrder != null) {
            RapidBiz.autoOrder(resultData, tempOrder, true);
            if (resultData.result != RapidResult.SUCCESS) {
                return -2;
            }
        }

        if (payment != null) {
            RapidApi.submitPay(resultData, payment);
            if (resultData.result == RapidResult.SUCCESS) {
                return 0;
            } else {
                RunTimeLog.addLog(RunTimeLog.RAPID_PRE_PAY_NO, "先付款的秒付落帐失败，[" + resultData.errorInfo + "]", "", payment.tableNo, payment, tempOrder);
                return -1;
            }
        }

        return -3;
    }

    private synchronized static void writeTempOrderToIO(TempOrderDishesCache tempDishes, String commitID) {
        CacheModel cacheModel = new CacheModel();
        cacheModel.key = tempDishes.optFirstThirdOrderID();
        cacheModel.value = JSON.toJSONString(tempDishes);
        cacheModel.type = IOCache.TYPE_RAPID_PRE_PAY_ORDER;
        cacheModel.biz_key = tempDishes.fsmtableid;
        cacheModel.info = commitID;
        cacheModel.createtime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        cacheModel.updatetime = cacheModel.createtime;
        cacheModel.replaceNoTrans();
    }

    /**
     * 下单成功，清除缓存
     *
     * @param thirdOrderIds String
     */
    private static void clearPreOrderInfoByThirdOrder(String thirdOrderIds) {
        if (!TextUtils.isEmpty(thirdOrderIds)) {
            String[] orderList = thirdOrderIds.split(",");
            StringBuilder sb = new StringBuilder();
            for (String temp : orderList) {
                sb.append("'").append(temp).append("',");
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where key in(" + sb.toString() + ") and type='" + IOCache.TYPE_RAPID_PRE_PAY_ORDER + "'");
            }
        }
    }

    /**
     * 清除指定桌台的订单
     *
     * @param tableID String | 桌台id
     */
    public static void clearOrderByTableID(String tableID) {
        if (!TextUtils.isEmpty(tableID)) {
            DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where biz_key='" + tableID + "'");
        }
    }

    /**
     * 清除已过期的预付款订单(10分钟)
     */
    private static void clearExpiredOrder() {
        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);

        //首先删除超过10分钟缓存的订单
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where  ((strftime('%s','" + currentTime + "') - strftime('%s',createtime))>600) AND type IN ('" + IOCache.TYPE_RAPID_PRE_PAY_ORDER + "', '" + IOCache.TYPE_RAPID_PRE_FAST_FOOD + "')");

    }

    /**
     * 获取桌台下的订单总数
     *
     * @param tableID String
     * @return int
     */
    private synchronized static int getPreOrderCountByTable(String tableID) {
        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);

        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) as count from datacache where biz_key='" + tableID + "' and type='" + IOCache.TYPE_RAPID_PRE_PAY_ORDER + "' and ((strftime('%s','" + currentTime + "') - strftime('%s',createtime))<600)");
        return StringUtil.toInt(count, 0);
    }

    /**
     * 获取桌台下的所有预付款的订单的json数据
     *
     * @param tableID String
     * @return List<String>
     */
    private static List<String> getPreOrderListCountByTable(String tableID) {
        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        List<String> valueList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select value from datacache where biz_key='" + tableID + "' and type='" + IOCache.TYPE_RAPID_PRE_PAY_ORDER + "' and ((strftime('%s','" + currentTime + "') - strftime('%s',createtime))<600)");
        if (ListUtil.isEmpty(valueList)) {
            return null;
        }
        return valueList;
    }

    /**
     * orderId对应的所有预付款的订单的json数据
     *
     * @param orderId String
     * @return List<String>
     */
    private static List<String> getPreOrderListCountByorderId(String orderId) {
        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        List<String> valueList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select value from datacache where info='" + orderId + "' and type='" + IOCache.TYPE_RAPID_PRE_FAST_FOOD + "' and ((strftime('%s','" + currentTime + "') - strftime('%s',createtime))<600)");
        if (ListUtil.isEmpty(valueList)) {
            return null;
        }
        return valueList;
    }

    /**
     * orderId对应的所有预付款的订单的json数据
     *
     * @param userId String
     * @return List<String>
     */
    private static List<String> getPreOrderListCountByUserId(String userId) {
        String currentTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        List<String> valueList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select value from datacache where biz_key='" + userId + "' and type='" + IOCache.TYPE_RAPID_PRE_FAST_FOOD + "' and ((strftime('%s','" + currentTime + "') - strftime('%s',createtime))<600)");
        if (ListUtil.isEmpty(valueList)) {
            return null;
        }
        return valueList;
    }

    /**
     * 构建完整的菜品
     *
     * @param tableNO        String
     * @param useMemberPrice boolean
     * @param memberLevel    int
     * @return TempOrderDishesCache
     */
    public static TempOrderDishesCache buildPrePayOrderFull(String tableNO, String userId, String orderId, boolean useMemberPrice, int isVipPrice, int memberLevel, String csId, String plusId) {

        List<String> valueList;
        if (!TextUtils.isEmpty(tableNO)) {
            valueList = getPreOrderListCountByTable(tableNO);
        } else if (!TextUtils.isEmpty(userId) && !TextUtils.equals(userId, "0")) {
            valueList = getPreOrderListCountByUserId(userId);
        } else {
            valueList = getPreOrderListCountByorderId(orderId);
        }

        if (ListUtil.isEmpty(valueList)) {
            return null;
        }

        //获取订单列表之后，才能清除已过期的缓存数据
        clearExpiredOrder();
        TempOrderDishesCache tempOrder = null;
        StringBuilder sb = new StringBuilder();
        for (String tempString : valueList) {
            if (tempOrder == null) {
                tempOrder = JSON.parseObject(tempString, TempOrderDishesCache.class);
                sb.append(tempOrder.thirdOrderID);
            } else {
                TempOrderDishesCache temp = JSON.parseObject(tempString, TempOrderDishesCache.class);
                if (temp != null && !ListUtil.isEmpty(temp.tempSelectedMenuList)) {
                    sb.append(",").append(temp.thirdOrderID);
                    tempOrder.tempSelectedMenuList.addAll(temp.tempSelectedMenuList);
                }
            }
        }
        if (sb.length() > 0 && !sb.toString().contains(orderId)) {
            sb.append(",").append(orderId);
        }
        if (tempOrder != null) {
            tempOrder.thirdOrderID = sb.toString();

            tempOrder.isMember = useMemberPrice;
            if (useMemberPrice) {
                MenuItemVipPriceUtil.useCouponWhenBindMember(HostUtil.getShopID(), tempOrder.tempSelectedMenuList, useMemberPrice, memberLevel, "cash", csId, plusId);
            } else {
                tempOrder.clearAllMemberCpupon();
            }

            tempOrder.plusTempSelectedMenuAmount();

            CouponCutMoney cut = OrderCache.checkCouponMoney(OrderUtil.initOrderCutList(HostUtil.getHistoryBusineeDate("")), tempOrder.tempSelectedMenuList, tempOrder.tempTotalPrice, OrderUtil.getSectionId(), false, tempOrder.isDiningStandard());
            if (cut != null) {
                tempOrder.tempTotalPrice = tempOrder.tempTotalPrice.subtract(cut.fdCutmoney);
            }
        }
        return tempOrder;
    }

    /**
     * 解析秒付的总支付金额
     *
     * @param rapidPayment RapidPayment
     * @return BigDecimal
     */
    public static BigDecimal parseRapidPayTotalAmt(RapidPayment rapidPayment) {
        BigDecimal totalPaied = BigDecimal.ZERO;
        if (rapidPayment != null && !ListUtil.isEmpty(rapidPayment.paymentList)) {
            for (RapidPayModel temp : rapidPayment.paymentList) {
                temp.fdReceMoney = temp.fdReceMoney.setScale(2, BigDecimal.ROUND_HALF_UP);
                totalPaied = totalPaied.add(temp.fdReceMoney);
            }
        }
        return totalPaied;
    }

    public static void keepOneOrder(String tableID) {
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "delete from datacache where biz_key='" + tableID + "'");
    }
}
