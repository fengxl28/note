package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.air.connect.business.menu.MenuItemEditorBody;
import com.mwee.android.air.db.business.menu.MenuClsSortBean;
import com.mwee.android.air.db.business.menu.MenuItemBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideBean;
import com.mwee.android.air.db.business.menu.MenuPackageSetSideDtlBean;
import com.mwee.android.air.util.DBPrimaryKeyUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.order.model.SellOutViewModel;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.AskgpDBModel;
import com.mwee.android.pos.db.business.MenuItemMulDeptDBModel;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.DishesUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuBiz;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.util.HelpCodeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qinwei on 2017/10/21.
 */

public class MenuItemDBUtils {
    /**
     * 根据菜品分类查询菜品列表信息
     *
     * @param menuClsId 菜品分类id
     * @return
     */
    public static List<MenuItemBean> queryMenusByClsId(String menuClsId) {
        String sql = "select tbmenuItem.fiItemCd,tbmenuItem.fiItemKind,tbmenuItem.fiIsPrePoint,tbmenuItem" +
                ".fdLunchBoxCost,tbmenuItem.fiIsWechatOrder,tbmenuItem.fiSortOrder,tbmenuItem.fsItemName,fiOrderUintCd, fsOrderUint,fdInvQty," +
                "fdSalePrice,fdVIPPrice,fiIsEditQty,tbMenuItemUint.fistatus,tbmenuItem.fsMenuClsId " +
                ",tbmenuitem.fiIsDiscount,tbmenuitem.fiIsGift,tbmenuitem.fiIsEditPrice,tbmenuitem.fiIsTakeAway," +
                "tbmenuitem.fiIsPrn from tbMenuItemUint\n" +
                "inner join tbmenuItem on tbmenuItem.fiItemCd = tbMenuItemUint.fiItemCd \n" +
                "where tbmenuItem.fiIsOut=0 and tbmenuItem.fiIsPurePay ='0' and tbMenuItemUint.fistatus in (1,2) and " +
                "tbmenuItem.fistatus = '1' and tbmenuItem.fiItemKind=1 and tbmenuItem.fsItemName != '预点单餐盒费'";
        // //todo  陈仁敏产品要求 预点单餐盒费不做显示
        if (!TextUtils.isEmpty(menuClsId) && !TextUtils.equals("-1localAll", menuClsId)) {
            sql += " and tbmenuItem.fsMenuClsId='" + menuClsId + "'";
        }
        if (APPConfig.isCasiher()) {
            sql += " and tbmenuItem.fiIsTemporaryMenu <> 1";
        }
        sql += " order by tbmenuItem.fsMenuClsId asc,tbmenuItem.fiSortOrder asc";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemBean.class);
    }


    /**
     * 查询所有菜品
     *
     * @param menuClsId
     * @return
     */
    public static List<MenuItemBean> queryMenuItemsByClsId(String menuClsId) {
        String sql = "select * from tbmenuitem where fiIsOut=0 and fistatus = '1' and fiItemKind = '1'";
        if (!TextUtils.isEmpty(menuClsId) && !TextUtils.equals("-1localAll", menuClsId)) {
            sql += " and  fsMenuClsId='" + menuClsId + "'";
        }
        sql += " order by  fsMenuClsId asc, fiSortOrder asc";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemBean.class);
    }

    public static MenuItemBean queryMenuItemBeanById(String fiItemCd) {
        String sql = "select * from tbmenuitem where fistatus = '1' and fiItemCd='" + fiItemCd + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, MenuItemBean.class);
    }

    /**
     * 查询分类下菜品个数
     *
     * @param clsId
     * @return
     */
    public static int queryCountByClsId(String clsId) {
        String sql = "SELECT count(*) from tbmenuitem where fsMenuClsId='" + clsId + "' and  fiStatus=1";
        if (APPConfig.isCasiher()) {
            //过滤纯收银菜品
            sql = sql + "and fiIsPurePay = 0";
        }
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (!TextUtils.isEmpty(count)) {
            return Integer.valueOf(count);
        }
        return -1;
    }

    public static MenuitemDBModel queryById(String fiItemCd) {
        String menuItemSql = "select * from tbmenuitem where fiItemCd='" + fiItemCd + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, menuItemSql, MenuitemDBModel.class);
    }

    /**
     * 修改菜品信息
     *
     * @param fiItemCd
     * @param body
     * @return
     */
    public static boolean updateMenuItemAndUnit(String fiItemCd, MenuItemEditorBody body) {
        if (TextUtils.isEmpty(body.memberPrice)) {
            body.memberPrice = body.price;
        }
        MenuitemDBModel menuitemDBModel = queryById(fiItemCd);
        menuitemDBModel.fsItemName = body.name;
        menuitemDBModel.fsHelpCode = HelpCodeUtil.createHelpCode(body.name);

        //属性
        menuitemDBModel.fiIsDiscount = body.isCanDiscount ? 1 : 0;
        menuitemDBModel.fiIsGift = body.isCanGift ? 1 : 0;
        menuitemDBModel.fiIsEditPrice = body.isCanTimePrice ? 1 : 0;
        menuitemDBModel.fiIsEditQty = body.isCanWeight ? 1 : 0;
        menuitemDBModel.fiIsTakeAway = body.isCanOutTake ? 1 : 0;
        menuitemDBModel.fiIsPrn = body.isCanPrinter ? 1 : 0;
        menuitemDBModel.fiIsPrePoint = body.isCanPreOrder ? 1 : 0;
        menuitemDBModel.fiIsWechatOrder = body.isCanWeChatOrder ? 1 : 0;
        menuitemDBModel.fdLunchBoxCost = TextUtils.isEmpty(body.fdLunchBoxCost) ? BigDecimal.ZERO : new BigDecimal
                (body.fdLunchBoxCost);

        menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemDBModel.fsMenuClsId = body.menuClsId;
        menuitemDBModel.sync = 1;

        String menuUnitSql = "select * from tbmenuitemuint where fiOrderUintCd='" + body.fiOrderUintCd + "'";
        MenuItemUnitDBModel unitDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, menuUnitSql, MenuItemUnitDBModel.class);
        if (unitDBModel != null) {
            unitDBModel.fsOrderUint = body.unitName;
            unitDBModel.fdSalePrice = new BigDecimal(body.price);
            unitDBModel.fdVIPPrice = new BigDecimal(body.memberPrice);
            unitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            unitDBModel.sync = 1;
            unitDBModel.fiStatus = 1;
            unitDBModel.replaceNoTrans();//修改规格

            //没有输入库存则不限制库存
            SellOutViewModel model = new SellOutViewModel();
            model.fiOrderUintCd = unitDBModel.fiOrderUintCd;
            model.fsOrderUint = unitDBModel.fsOrderUint;
            model.fiItemCd = unitDBModel.fiItemCd;
            model.fsItemName = menuitemDBModel.fsItemName;
            if (!TextUtils.isEmpty(body.repertoryNumber)) {
                model.fdInvQty = new BigDecimal(body.repertoryNumber);
                model.fiStatus = 2;
            } else {
                unitDBModel.fdInvQty = BigDecimal.ZERO;
                //输入库存则 菜品处理临时沽清状态
                model.fiStatus = 1;
            }
            //修改库存表
            model.replaceNoTrans();
        }
        menuitemDBModel.replaceNoTrans();//修改菜品
        MetaDBController.updateSyncTime();
        return true;
    }


    /**
     * 美小易修改菜品信息
     *
     * @param fiItemCd
     * @param body
     * @return
     */
    public static boolean updateAirMenuItemAndUnit(String fiItemCd, MenuItemEditorBody body) {
        if (TextUtils.isEmpty(body.memberPrice)) {
            body.memberPrice = body.price;
        }
        MenuitemDBModel menuitemDBModel = queryById(fiItemCd);
        menuitemDBModel.fsItemName = body.name;
        menuitemDBModel.fsHelpCode = HelpCodeUtil.createHelpCode(body.name);

        //属性
        menuitemDBModel.fiIsDiscount = body.isCanDiscount ? 1 : 0;
        menuitemDBModel.fiIsGift = body.isCanGift ? 1 : 0;
        menuitemDBModel.fiIsEditPrice = body.isCanTimePrice ? 1 : 0;
        menuitemDBModel.fiIsEditQty = body.isCanWeight ? 1 : 0;
        menuitemDBModel.fiIsTakeAway = body.isCanOutTake ? 1 : 0;
        menuitemDBModel.fiIsPrn = body.isCanPrinter ? 1 : 0;
        menuitemDBModel.fiIsPrePoint = body.isCanPreOrder ? 1 : 0;
        menuitemDBModel.fdLunchBoxCost = TextUtils.isEmpty(body.fdLunchBoxCost) ? BigDecimal.ZERO : new BigDecimal
                (body.fdLunchBoxCost);

        menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemDBModel.fsMenuClsId = body.menuClsId;
        menuitemDBModel.sync = 1;
        MenuItemUnitDBUtils.updateMenuItemUnitList(fiItemCd, body.menuItemUnitBeans);
        menuitemDBModel.replaceNoTrans();//修改菜品
        MetaDBController.updateSyncTime();
        return true;
    }

    /**
     * 添加一个临时菜
     * 仅仅王炸刘老大使用
     *
     * @param shopId
     * @return fiItemCd
     */
    public static String addTemporaryMenuWZ(String shopId) {
        String fsMenuClsId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsMenuClsId from tbMenuCls where " +
                "fiStatus = '1' limit 1");
        MenuItemEditorBody body = new MenuItemEditorBody();
        body.menuClsId = fsMenuClsId;
        body.name = "临时菜";
        body.unitName = "份";
        body.price = "1";
        body.memberPrice = "1";
        body.repertoryNumber = "";
        body.isCanDiscount = true;
        body.isCanGift = false;
        body.isCanTimePrice = false;
        body.isCanWeight = false;
        body.isCanOutTake = false;
        body.isCanPrinter = false;
        body.isCanPreOrder = false;
        body.fiIsTemporaryMenu = 1;
        return addMenuItem(body, shopId);

    }

    /**
     * 新增菜品信息
     * 1.tbMenuItem   菜品表
     * 2.tbMenuItemUint   菜品规格单位表
     * 3tbMenuItemAskGp   菜品关联要求表 关联所有要求组
     *
     * @param body
     * @param shopId
     * @return
     */
    public static String addMenuItem(MenuItemEditorBody body, String shopId) {
        if (TextUtils.isEmpty(body.memberPrice)) {
            body.memberPrice = body.price;
        }
        MenuitemDBModel dbModel = new MenuitemDBModel();
        dbModel.fiItemCd = String.valueOf(IDHelper.generateMenuId());
        dbModel.fsItemId = DBPrimaryKeyUtil.optPrimaryKey();
        dbModel.fsItemName = body.name;
        dbModel.fsHelpCode = HelpCodeUtil.createHelpCode(body.name);
        dbModel.fsItemName2 = "";
        dbModel.fsMenuClsId = body.menuClsId;
        dbModel.fiIsEditPrice = 0;
        //属性
        dbModel.fiIsDiscount = body.isCanDiscount ? 1 : 0;
        dbModel.fiIsGift = body.isCanGift ? 1 : 0;
        dbModel.fiIsEditPrice = body.isCanTimePrice ? 1 : 0;
        dbModel.fiIsEditQty = body.isCanWeight ? 1 : 0;
        dbModel.fiIsTakeAway = body.isCanOutTake ? 1 : 0;
        dbModel.fiIsPrn = body.isCanPrinter ? 1 : 0;
        dbModel.fiIsPrePoint = body.isCanPreOrder ? 1 : 0;
        dbModel.fiIsWechatOrder = body.isCanWeChatOrder ? 1 : 0;
        dbModel.fiIsTemporaryMenu = body.fiIsTemporaryMenu;
        dbModel.fdLunchBoxCost = TextUtils.isEmpty(body.fdLunchBoxCost) ? BigDecimal.ZERO : new BigDecimal(body.fdLunchBoxCost);

        dbModel.fiIsServiceFee = 0;
        dbModel.fsDeptId = "";
        dbModel.fiIsSet = 0;
        dbModel.fiIsSetDtlPrn = 1;
        dbModel.fiIsOut = 0;
        dbModel.fiIsNew = 0;
        dbModel.fiIsSpecialty = 0;
        dbModel.fiIsCuisine = 0;
        dbModel.fiIsBonus = 0;
        dbModel.fiItemKind = 1;
        dbModel.fsItemDesc = "";
        dbModel.fiImgWidth = 0;
        dbModel.fiImgHeight = 0;
        dbModel.fsImageURL = "";
        dbModel.fsImagePath = "0";
        dbModel.fsNote = "";
        dbModel.fsExpClsId = body.fsExpClsId;
        dbModel.fsRevenueTypeId = body.fsRevenueTypeId;
        dbModel.fiSortOrder = generateSortOrder();
        dbModel.fsColor = "0";
        dbModel.fiIsHot = 0;
        dbModel.fiStatus = body.fiStatus;
        dbModel.fsCreateTime = DateUtil.getCurrentTime();
        dbModel.fsCreateUserId = body.fsUserId;
        dbModel.fsCreateUserName = body.fsUserName;
        dbModel.fsUpdateTime = DateUtil.getCurrentTime();
        dbModel.fsUpdateUserId = body.fsUserId;
        dbModel.fsUpdateUserName = body.fsUserName;
        dbModel.fsShopGUID = shopId;
        dbModel.fiIsMulDept = 1;
        dbModel.fiItemSetCalc = 0;
        dbModel.fiIsEffectiveDate = 0;
        dbModel.fsStarDate = "";
        dbModel.fsEndDate = "";
        dbModel.fiMax = 0;
        dbModel.fiDataSource = 1;
        dbModel.sync = 1;
        dbModel.replace();
        //插入规格
        String unitId = buidUnit(dbModel.fiItemCd, body.unitName, body.price, body.memberPrice, shopId);
        //插入估清
        buidSellOut(unitId, body.unitName, dbModel.fiItemCd, dbModel.fsItemName, body.repertoryNumber, BigDecimal.ZERO);
        MetaDBController.updateSyncTime();
        return dbModel.fiItemCd;
    }

    /**
     * 新增菜品信息
     * 1.tbMenuItem   菜品表
     * 2.tbMenuItemUint   菜品规格单位表
     * 3tbMenuItemAskGp   菜品关联要求表 关联所有要求组
     *
     * @param body
     * @param shopId
     * @return
     */
    public static String addAirMenuItem(MenuItemEditorBody body, String shopId) {
        if (TextUtils.isEmpty(body.memberPrice)) {
            body.memberPrice = body.price;
        }
        MenuitemDBModel dbModel = new MenuitemDBModel();
        dbModel.fiItemCd = String.valueOf(IDHelper.generateMenuId());
        dbModel.fsItemId = DBPrimaryKeyUtil.optPrimaryKey();
        dbModel.fsItemName = body.name;
        dbModel.fsHelpCode = HelpCodeUtil.createHelpCode(body.name);
        dbModel.fsItemName2 = "";
        dbModel.fsMenuClsId = body.menuClsId;
        dbModel.fiIsEditPrice = 0;
        //属性
        dbModel.fiIsDiscount = body.isCanDiscount ? 1 : 0;
        dbModel.fiIsGift = body.isCanGift ? 1 : 0;
        dbModel.fiIsEditPrice = body.isCanTimePrice ? 1 : 0;
        dbModel.fiIsEditQty = body.isCanWeight ? 1 : 0;
        dbModel.fiIsTakeAway = body.isCanOutTake ? 1 : 0;
        dbModel.fiIsPrn = body.isCanPrinter ? 1 : 0;
        dbModel.fiIsPrePoint = body.isCanPreOrder ? 1 : 0;
        dbModel.fiIsTemporaryMenu = body.fiIsTemporaryMenu;
        dbModel.fdLunchBoxCost = TextUtils.isEmpty(body.fdLunchBoxCost) ? BigDecimal.ZERO : new BigDecimal(body
                .fdLunchBoxCost);

        dbModel.fiIsServiceFee = 0;
        dbModel.fsDeptId = "";
        dbModel.fiIsWechatOrder = 1;
        dbModel.fiIsSet = 0;
        dbModel.fiIsSetDtlPrn = 1;
        dbModel.fiIsOut = 0;
        dbModel.fiIsNew = 0;
        dbModel.fiIsSpecialty = 0;
        dbModel.fiIsCuisine = 0;
        dbModel.fiIsBonus = 0;
        dbModel.fiItemKind = 1;
        dbModel.fsItemDesc = "";
        dbModel.fiImgWidth = 0;
        dbModel.fiImgHeight = 0;
        dbModel.fsImageURL = "";
        dbModel.fsImagePath = "0";
        dbModel.fsNote = "";
        dbModel.fiSortOrder = generateSortOrder();
        dbModel.fsColor = "0";
        dbModel.fiIsHot = 0;
        dbModel.fiStatus = 1;
        dbModel.fsCreateTime = DateUtil.getCurrentTime();
        dbModel.fsCreateUserId = "admin";
        dbModel.fsCreateUserName = "管理员";
        dbModel.fsUpdateTime = DateUtil.getCurrentTime();
        dbModel.fsUpdateUserId = "admin";
        dbModel.fsUpdateUserName = "管理员";
        dbModel.fsShopGUID = shopId;
        dbModel.fiIsMulDept = 1;
        dbModel.fiItemSetCalc = 0;
        dbModel.fiIsEffectiveDate = 0;
        dbModel.fsStarDate = "";
        dbModel.fsEndDate = "";
        dbModel.fiMax = 0;
        dbModel.fiDataSource = 1;
        dbModel.sync = 1;
        dbModel.replace();
        MenuItemUnitDBUtils.addMenuItemUnits(dbModel.fiItemCd, body.menuItemUnitBeans);
        MetaDBController.updateSyncTime();
        return dbModel.fiItemCd;
    }

    public static String buidUnit(String fiItemCd, String unitName, String price, String memberPrice, String shopId) {
        //插入规格
        String unitId = String.valueOf(IDHelper.generateMenuUnitId());
        MenuItemUnitDBModel menuItemUnitDBModel = new MenuItemUnitDBModel();
        menuItemUnitDBModel.fiOrderUintCd = unitId;
        menuItemUnitDBModel.fiItemCd = fiItemCd;
        menuItemUnitDBModel.fsOrderUint = unitName;
        menuItemUnitDBModel.fdSalePrice = new BigDecimal(price);
        menuItemUnitDBModel.fdVIPPrice = new BigDecimal(memberPrice);

        //处理规格
        menuItemUnitDBModel.fiStatus = 1;
        menuItemUnitDBModel.fiDefault = 1;
        menuItemUnitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuItemUnitDBModel.fsUpdateUserId = "admin";
        menuItemUnitDBModel.fsUpdateUserName = "管理员";
        menuItemUnitDBModel.fsShopGUID = shopId;
        menuItemUnitDBModel.fiInitCount = 1;
        menuItemUnitDBModel.fdCostPrice = BigDecimal.ZERO;
        menuItemUnitDBModel.fiDataSource = 1;
        menuItemUnitDBModel.sync = 1;
        menuItemUnitDBModel.replaceNoTrans();
        return unitId;

    }

    public static void buidSellOut(String fiOrderUintCd, String fsOrderUint, String fiItemCd, String fsItemName, String
            repertoryNumber, BigDecimal fdInvQty) {
        //处理临时沽清表
        SellOutViewModel model = new SellOutViewModel();
        model.fiOrderUintCd = fiOrderUintCd;
        model.fsOrderUint = fsOrderUint;
        model.fiItemCd = fiItemCd;
        model.fsItemName = fsItemName;
        if (!TextUtils.isEmpty(repertoryNumber)) {
            model.fdInvQty = new BigDecimal(repertoryNumber);
            //输入库存则菜品处理临时沽清状态
            model.fiStatus = 2;
        } else {
            model.fiStatus = 1;
            model.fdInvQty = fdInvQty;
        }
        model.replaceNoTrans();
    }


    private static int generateSortOrder() {
        String sql = "select max(fiSortOrder) from tbmenuitem";
        String max = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (TextUtils.isEmpty(max)) {
            return 1;
        } else {
            return StringUtil.toInt(max) + 1;
        }
    }

    public static boolean deleteMenus(List<String> deleteMenuIds) {
        final StringBuilder menuDeleteSql = new StringBuilder("UPDATE tbmenuitem SET fiStatus=13,fsUpdateTime='"
                + DateUtil.getCurrentTime() + "',sync = 1 where fiItemCd IN (");
        final StringBuilder menuUnitDeleteSql = new StringBuilder("UPDATE tbmenuitemuint SET fiStatus=13," +
                "fsUpdateTime='" + DateUtil.getCurrentTime() + "',sync = 1 where fiItemCd IN (");
        for (int i = 0; i < deleteMenuIds.size(); i++) {
            if (i == deleteMenuIds.size() - 1) {
                menuDeleteSql.append("'").append(deleteMenuIds.get(i) + "');");
                menuUnitDeleteSql.append("'").append(deleteMenuIds.get(i) + "');");
            } else {
                menuDeleteSql.append("'").append(deleteMenuIds.get(i) + "',");
                menuUnitDeleteSql.append("'").append(deleteMenuIds.get(i) + "',");
            }
            unAssociateAskGp(deleteMenuIds.get(i));
        }
        int result = DBManager.getInstance(APPConfig.DB_MAIN).executeInTransactionWithOutThread(new IDBOperate<Integer>() {
            @Override
            public Integer doJob(SQLiteDatabase sqLiteDatabase) {
                sqLiteDatabase.execSQL(menuUnitDeleteSql.toString());
                sqLiteDatabase.execSQL(menuDeleteSql.toString());
                return 1;
            }
        });
        MetaDBController.updateSyncTime();
        return result == 1;
    }

    /**
     * 查询所有套餐
     *
     * @return
     */
    public static List<MenuItemBean> queryMenuPackages() {
        //, int fiIsPrePoint, BigDecimal fdLunchBoxCost
        String sql = "select tbmenuItem.fsMenuClsId,tbmenuItem.fiItemKind,tbmenuItem.fiSortOrder,tbmenuItem" +
                ".fiItemCd,tbmenuItem.fsItemName,tbmenuItem.fiIsPrePoint,tbmenuItem.fdLunchBoxCost,fiOrderUintCd, fsOrderUint,fdInvQty,fdSalePrice,fdVIPPrice," +
                "fiIsEditQty,tbMenuItemUint.fistatus from tbMenuItemUint\n" +
                "inner join tbmenuItem on tbmenuItem.fiItemCd = tbMenuItemUint.fiItemCd \n" +
                "where tbMenuItemUint.fistatus in (1,2) and tbmenuItem.fistatus = '1' and tbmenuItem.fiItemKind=2" +
                " order by tbmenuItem.fiSortOrder asc";
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemBean.class);
    }

    public static List<MenuItemBean> queryMenuPackagesForMsy(boolean isQueryPackageItem) {
        List<MenuItemBean> menuItemBeans = queryMenuPackages();
        if (!ListUtil.isEmpty(menuItemBeans) && isQueryPackageItem) {
            for (MenuItemBean menuItemBean : menuItemBeans) {
                menuItemBean.menuPackageSetSideBeans = (ArrayList<MenuPackageSetSideBean>)
                        MenuPackageSetSideDBUtils.queryMenuPackageSetSidesByMenuId(menuItemBean.fiItemCd);
            }
        }
        return menuItemBeans;
    }

    public static boolean hasMenuPackage() {
        String sql = "select count(*) from tbMenuItemUint\n" +
                "inner join tbmenuItem on tbmenuItem.fiItemCd = tbMenuItemUint.fiItemCd \n" +
                "where tbMenuItemUint.fistatus in (1,2) and tbmenuItem.fistatus = '1' and tbmenuItem.fiItemKind=2";
        return StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql), 0) > 0;
    }

    /**
     * 美小易修改套餐信息
     *
     * @param fiItemCd 套餐id
     * @param name     套餐名称
     * @param price    套餐价格
     * @param beans    套餐组成项
     * @return
     */
    public static boolean updateMenuPackage(final String fiItemCd, final String name, final String price, String vipPrice, int fiIsPrePoint, BigDecimal fdLunchBoxCost,
                                            final List<MenuPackageSetSideBean> beans, final String shopId, final
                                            UserDBModel userDBModel) {


        //修改菜品信息
        MenuitemDBModel menuitemDBModel = queryById(fiItemCd);
        menuitemDBModel.fiItemCd = fiItemCd;
        menuitemDBModel.fsItemName = name;
        menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemDBModel.fiIsPrePoint = fiIsPrePoint;
        menuitemDBModel.fdLunchBoxCost = fdLunchBoxCost;
        menuitemDBModel.replaceNoTrans();

        List<MenuItemUnitDBModel> menuItemUnitDBModelList = MenuItemUnitDBUtils.queryByFiItemCd(fiItemCd);
        if (menuItemUnitDBModelList != null && menuItemUnitDBModelList.size() > 0) {
            //修改菜品规格信息
            MenuItemUnitDBModel menuItemUnitDBModel = menuItemUnitDBModelList.get(0);
            menuItemUnitDBModel.fiItemCd = fiItemCd;
            menuItemUnitDBModel.fdSalePrice = new BigDecimal(price);
            menuItemUnitDBModel.fdVIPPrice = new BigDecimal(vipPrice);
            menuItemUnitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
            menuItemUnitDBModel.replaceNoTrans();
        }

//        String updateMenuSql = "UPDATE tbmenuitem SET fsitemname='" + name + "', fsUpdateTime='" + DateUtil
//                .getCurrentTime() + "',sync = 1 WHERE fiItemCd='" + fiItemCd + "'";
//        String updateUnitPriceSql = "UPDATE tbmenuitemuint SET fdSalePrice=" + price + ", fsUpdateTime='" +
//                DateUtil.getCurrentTime() + "',sync = 1 WHERE fiItemCd='" + fiItemCd + "'";
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateMenuSql);//修改套餐表
//        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateUnitPriceSql);//修改规格表

        if (beans != null) {
            for (int i = 0; i < beans.size(); i++) {
                MenuPackageSetSideBean menuPackageSetSideBean = beans.get(i);
//                if (menuPackageSetSideBean.fiSetFoodCd < 0) {
                if (TextUtils.isEmpty(menuPackageSetSideBean.fiSetFoodCd) || StringUtil.toInt(menuPackageSetSideBean.fiSetFoodCd, 0) < 0) {
                    //新增套餐组成项
                    menuPackageSetSideBean.fiSetFoodCd = String.valueOf(IDHelper.generateFiSetFoodCd());
                    MenuPackageSetSideDBUtils.addMenuPackageSetSide(menuPackageSetSideBean, userDBModel, shopId);
                } else {
                    //编辑套餐组成项
                    MenuPackageSetSideDBUtils.updateMenuPackageSetSide(menuPackageSetSideBean.fiSetFoodCd,
                            menuPackageSetSideBean.fiSetFoodQty, menuPackageSetSideBean.fsSetFoodName);
                    MenuPackageSetSideDtlDBUtils.deleteBySetSideCd(menuPackageSetSideBean.fiSetFoodCd);
                }
                //添加操作明细关联
                if (menuPackageSetSideBean.choiceMenuItems != null) {
                    for (int j = 0; j < menuPackageSetSideBean.choiceMenuItems.size(); j++) {
                        //添加操作明细关联
                        MenuPackageSetSideDtlBean menuPackageSetSideDtlBean = menuPackageSetSideBean
                                .choiceMenuItems.get(j);
                        menuPackageSetSideDtlBean.fiItemCd_M = fiItemCd;
                        menuPackageSetSideDtlBean.fiSetFoodCd = menuPackageSetSideBean.fiSetFoodCd;
                        MenuPackageSetSideDtlDBUtils.addMenuPackageSetSideDtl(menuPackageSetSideDtlBean,
                                userDBModel, shopId);
                    }
                }

            }
        }
        MetaDBController.updateSyncTime();
        return true;
    }

    /**
     * 美收银修改套餐处理
     *
     * @param fiItemCd 套餐id
     * @param name     套餐名称
     * @param price    套餐价格
     * @param beans    套餐组成项
     * @return
     */
    public static boolean updateMenuPackageMsy(final String fiItemCd, final String name, final String price,
                                               final List<MenuPackageSetSideBean> beans, final String shopId, final
                                               UserDBModel userDBModel) {
        String updateMenuSql = "UPDATE tbmenuitem SET fsitemname='" + name + "', fsUpdateTime='" + DateUtil
                .getCurrentTime() + "',sync = 1 WHERE fiItemCd='" + fiItemCd + "'";
        String updateUnitPriceSql = "UPDATE tbmenuitemuint SET fdSalePrice='" + price + "', fsUpdateTime='" +
                DateUtil.getCurrentTime() + "',sync = 1 WHERE fiItemCd='" + fiItemCd + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateMenuSql);//修改套餐表
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, updateUnitPriceSql);//修改规格表
        for (int i = 0; i < beans.size(); i++) {
            MenuPackageSetSideBean menuPackageSetSideBean = beans.get(i);
//            if (menuPackageSetSideBean.fiSetFoodCd < 0) {
            if (TextUtils.isEmpty(menuPackageSetSideBean.fiSetFoodCd) || StringUtil.toInt(menuPackageSetSideBean.fiSetFoodCd, 0) < 0) {
                //新增套餐组成项
                menuPackageSetSideBean.fiSetFoodCd = String.valueOf(IDHelper.generateFiSetFoodCd());
                MenuPackageSetSideDBUtils.addMenuPackageSetSide(menuPackageSetSideBean, userDBModel, shopId);
            } else {
                if (menuPackageSetSideBean.editor_mode == MenuPackageSetSideBean.MODE_DELETE) {
                    //删除套餐组成项
                    MenuPackageSetSideDBUtils.deleteMenuItemSetSide(menuPackageSetSideBean.fiSetFoodCd);
                } else {
                    //编辑套餐组成项
                    MenuPackageSetSideDBUtils.updateMenuPackageSetSide(menuPackageSetSideBean.fiSetFoodCd,
                            menuPackageSetSideBean.fiSetFoodQty, menuPackageSetSideBean.fsSetFoodName);
                    //删除之前关联的菜品
                    MenuPackageSetSideDtlDBUtils.deleteBySetSideCd(menuPackageSetSideBean.fiSetFoodCd);
                    for (int j = 0; j < menuPackageSetSideBean.choiceMenuItems.size(); j++) {
                        //添加操作明细关联
                        MenuPackageSetSideDtlBean menuPackageSetSideDtlBean = menuPackageSetSideBean
                                .choiceMenuItems.get(j);
                        menuPackageSetSideDtlBean.fiItemCd_M = fiItemCd;
                        menuPackageSetSideDtlBean.fiSetFoodCd = menuPackageSetSideBean.fiSetFoodCd;
                        MenuPackageSetSideDtlDBUtils.addMenuPackageSetSideDtl(menuPackageSetSideDtlBean,
                                userDBModel, shopId);
                    }
                }
            }
        }
        MetaDBController.updateSyncTime();
        return true;
    }

    /**
     * 新增菜品信息
     * 1.tbMenuItem   菜品表
     * 2.tbMenuItemUint   菜品规格单位表
     * 3tbMenuItemAskGp   菜品关联要求表 关联所有要求组
     *
     * @param name
     * @param price
     * @return
     */
    public static MenuItemBean addMenuPackage(String name, String price, String vipPrice, String shopId, UserDBModel userDBModel) {
        return addMenuPackage(name, price, vipPrice, 0, BigDecimal.ZERO, shopId, userDBModel);
    }

    /**
     * 新增菜品信息
     * 1.tbMenuItem   菜品表
     * 2.tbMenuItemUint   菜品规格单位表
     * 3tbMenuItemAskGp   菜品关联要求表 关联所有要求组
     *
     * @param name
     * @param price
     * @return
     */
    public static MenuItemBean addMenuPackage(String name, String price, String vipPrice, int fiIsPrePoint, BigDecimal fdLunchBoxCost, String shopId, UserDBModel userDBModel) {
        MenuitemDBModel dbModel = new MenuitemDBModel();
        dbModel.fiItemCd = String.valueOf(IDHelper.generateMenuId());
        dbModel.fsItemId = DBPrimaryKeyUtil.optPrimaryKey();
        dbModel.fsItemName = name;
        dbModel.fsHelpCode = HelpCodeUtil.createHelpCode(name);
        dbModel.fsItemName2 = "";
        dbModel.fsMenuClsId = MenuClsDBUtils.queryDefaultMenuPackageCls(shopId, userDBModel);
        dbModel.fiIsEditPrice = 0;
        dbModel.fiIsEditQty = 0;
        dbModel.fiIsDiscount = 1;
        dbModel.fiIsServiceFee = 0;
        dbModel.fiIsGift = 1;
        //todo 小易的套餐部门为空
        dbModel.fsDeptId = "";
        dbModel.fiIsSet = 0;
        //todo 根据套餐明细本身走
        dbModel.fiIsSetDtlPrn = 2;
        dbModel.fiIsPrn = 1;
        dbModel.fiIsPrePoint = fiIsPrePoint;
        dbModel.fdLunchBoxCost = fdLunchBoxCost;

        dbModel.fiIsOut = 0;
        dbModel.fiIsNew = 0;
        dbModel.fiIsSpecialty = 0;
        dbModel.fiIsCuisine = 0;
        //--是否外卖； 0=false/1=true; 默认0
        dbModel.fiIsTakeAway = 1;
        dbModel.fiIsBonus = 0;
        dbModel.fiItemKind = 2;
        dbModel.fsItemDesc = "";
        dbModel.fiImgWidth = 0;
        dbModel.fiImgHeight = 0;
        dbModel.fsImageURL = "";
        dbModel.fsImagePath = "0";
        dbModel.fsNote = "";
        dbModel.fiSortOrder = 9994;
        dbModel.fsColor = "0";
        dbModel.fiIsHot = 0;
        dbModel.fiStatus = 1;
        dbModel.fsCreateTime = DateUtil.getCurrentTime();
        dbModel.fsCreateUserId = "admin";
        dbModel.fsCreateUserName = "管理员";
        dbModel.fsUpdateTime = DateUtil.getCurrentTime();
        dbModel.fsUpdateUserId = "admin";
        dbModel.fsUpdateUserName = "管理员";
        dbModel.fsShopGUID = shopId;
        //todo 产品要求套餐为多部门打印
        dbModel.fiIsMulDept = 1;

        dbModel.fiItemSetCalc = 0;
        dbModel.fiIsEffectiveDate = 0;
        dbModel.fsStarDate = "";
        dbModel.fsEndDate = "";
        dbModel.fiMax = 0;
        dbModel.sync = 1;
        dbModel.fiDataSource = 1;
        dbModel.replaceNoTrans();
        //插入规格
        String unitId = String.valueOf(IDHelper.generateMenuUnitId());
        MenuItemUnitDBModel menuItemUnitDBModel = new MenuItemUnitDBModel();
        menuItemUnitDBModel.fiOrderUintCd = unitId;
        menuItemUnitDBModel.fiItemCd = dbModel.fiItemCd;
        menuItemUnitDBModel.fsOrderUint = "套";
        menuItemUnitDBModel.fdSalePrice = new BigDecimal(price);
        menuItemUnitDBModel.fdVIPPrice = new BigDecimal(vipPrice);
        menuItemUnitDBModel.fdInvQty = new BigDecimal(0);
        int fiStatus = 1;
        if (menuItemUnitDBModel.fdInvQty.compareTo(BigDecimal.ZERO) > 0) {
            fiStatus = 2;
        }
        menuItemUnitDBModel.fiStatus = fiStatus;
        menuItemUnitDBModel.fiDefault = 1;
        menuItemUnitDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuItemUnitDBModel.fsUpdateUserId = "admin";
        menuItemUnitDBModel.fsUpdateUserName = "管理员";
        menuItemUnitDBModel.fsShopGUID = shopId;
        menuItemUnitDBModel.fiInitCount = 1;
        menuItemUnitDBModel.fdCostPrice = BigDecimal.ZERO;
        menuItemUnitDBModel.fiDataSource = 1;
        menuItemUnitDBModel.sync = 1;
        menuItemUnitDBModel.replaceNoTrans();


        //新增菜品关联所有要求组
        AskManagerDBUtil.associateMenuItem(dbModel.fiItemCd, shopId);
        MetaDBController.updateSyncTime();
        MenuItemBean menuItemBean = new MenuItemBean();
        menuItemBean.fiItemCd = dbModel.fiItemCd;
        menuItemBean.fsItemName = dbModel.fsItemName;
        menuItemBean.fiOrderUintCd = unitId;
        return menuItemBean;

    }

    /**
     * 添加一个套餐菜品
     *
     * @param menuPackageBean 套餐菜品信息
     * @param shopId          门店id
     * @param userDBModel     操作用户
     * @return
     */
    public static boolean addMenuPackage(MenuItemBean menuPackageBean, String shopId, UserDBModel userDBModel) {
        MenuItemBean menuItemBean = addMenuPackage(menuPackageBean.fsItemName, menuPackageBean.fdSalePrice
                .toPlainString(), menuPackageBean.fdVIPPrice.toPlainString(), shopId, userDBModel);
        //完成套餐组成项数据构建
        if (!ListUtil.isEmpty(menuPackageBean.menuPackageSetSideBeans)) {
            for (MenuPackageSetSideBean menuPackageSetSideBean : menuPackageBean.menuPackageSetSideBeans) {
                //组成项所属套餐菜品id
                menuPackageSetSideBean.fiItemCd_M = menuItemBean.fiItemCd;
            }
        }
//        存套餐组成项
        MenuPackageSetSideDBUtils.addMenuPackageSetSide(menuPackageBean.menuPackageSetSideBeans, userDBModel,
                shopId);
        return true;
    }


    public static void deleteMenuPackage(String fiItemCd) {
        MenuitemDBModel menuitemDBModel = queryById(fiItemCd);
        menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemDBModel.fiStatus = 13;
        menuitemDBModel.sync = 1;
        menuitemDBModel.replaceNoTrans();
        //删除套餐组成项数据
        MenuPackageSetSideDBUtils.deleteMenuItemSetSideByPackageId(fiItemCd);
        unAssociateAskGp(fiItemCd);
        MetaDBController.updateSyncTime();
    }


    public static void associateAskGp(String fsAskGpId, String shopId) {
        List<MenuItemBean> menuItemBeans = queryMenusByClsId(null);
        if (!ListUtil.isEmpty(menuItemBeans)) {
            for (MenuItemBean menuItemBean : menuItemBeans) {
                MenuitemaskgpDBUtils.add(menuItemBean.fiItemCd, fsAskGpId, shopId);
            }
        }
    }

    public static void unAssociateAskGp(String fiItemCd) {
        MenuitemaskgpDBUtils.deleteByMenuId(fiItemCd);
    }


    /**
     * 菜品关联指定的打印部门
     *
     * @param fiItemCd
     * @param shopId
     * @param fiMulDeptCd
     * @param fsDeptId    部门ID  2表示普通部门  3表示标签部门
     */
    public static void associateMenuItemMulDept(String fiItemCd, String shopId, String fiMulDeptCd, String fsDeptId) {

        MenuItemMulDeptDBModel model = new MenuItemMulDeptDBModel();
        model.fiItemCd = fiItemCd;
        model.fiMulDeptCd = fiMulDeptCd;
        model.fiStatus = 1;
        model.fsDeptId = fsDeptId + "";
        model.fsShopGUID = shopId;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = "admin";
        model.fsUpdateUserName = "管理员";
        model.fiDataSource = 1;
        model.sync = 1;
        model.replaceNoTrans();

    }


    /**
     * 查询小散所有的后台预制菜品
     *
     * @return
     */
    private static List<MenuitemDBModel> queryAllMenuItem() {

        String sql = "select * from tbMenuItem where fiStatus = '1' and fiIsPurePay ='0' and fiDataSource = '0' ";
        List<MenuitemDBModel> menuitemDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuitemDBModel
                .class);
        return menuitemDBModels;

    }

    /**
     * 查询菜品关联部门表
     *
     * @param fiItemCd
     * @return
     */
    private static MenuItemMulDeptDBModel queryMenuItemMulDeptList(String fiItemCd, int fsDeptId) {

        String sql = "select * from tbMenuItemMulDept where fiStatus='1' and fiItemCd = '" + fiItemCd + "' and " +
                "fsDeptId = '" + fsDeptId + "'";
        MenuItemMulDeptDBModel itemMulDeptDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, sql,
                MenuItemMulDeptDBModel.class);
        return itemMulDeptDBModel;
    }


    /**
     * 小散项目  对后台预制菜品  强制关联打印部门 关联要求
     */
    public static void associateMenuItemWithAskGp() {
        if (APPConfig.isAir()) {
            ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where " +
                    "fiStatus='1' ", ShopDBModel.class);

            List<AskgpDBModel> askGps = AskManagerDBUtil.queryAllAskGp();
            List<MenuitemDBModel> menuitemDBModels = queryAllMenuItem();
            if (ListUtil.isEmpty(menuitemDBModels)) {
                return;
            }
            for (MenuitemDBModel menuitem : menuitemDBModels) {
                //小散后台预制菜品  关联打印部门
                if (menuitem == null) {
                    continue;
                }

                MenuItemMulDeptDBModel deptDBModel2 = queryMenuItemMulDeptList(menuitem.fiItemCd, 2);
                if (deptDBModel2 == null) {
                    //MenuItemDBUtils.associateMenuItemMulDept(menuitem.fiItemCd, shopDBModel.fsShopId, (int)
                    // IDHelper.generateId("tbMenuItemMulDept"), 2);
                    menuitem.fiIsMulDept = 1;
                    menuitem.fiIsPrn = 1;
                    menuitem.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem.sync = 1;
                    menuitem.replaceNoTrans();
                    MetaDBController.updateSyncTime();
                }

                MenuItemMulDeptDBModel deptDBModel3 = queryMenuItemMulDeptList(menuitem.fiItemCd, 3);
                if (deptDBModel3 == null) {
                    //MenuItemDBUtils.associateMenuItemMulDept(menuitem.fiItemCd, shopDBModel.fsShopId, (int)
                    // IDHelper.generateId("tbMenuItemMulDept") - 1, 3);
                    menuitem.fiIsMulDept = 1;
                    menuitem.fiIsPrn = 1;
                    menuitem.fsUpdateTime = DateUtil.getCurrentTime();
                    menuitem.sync = 1;
                    menuitem.replaceNoTrans();
                    MetaDBController.updateSyncTime();
                }
                //关联后台预制菜品要求
                AskManagerDBUtil.associateMenuItem(menuitem.fiItemCd, shopDBModel.fsShopId, askGps);

            }
            //预制菜品不强制关联
//            List<String> menuClsBeans = MenuClsDBUtils.queryAllMenuClsID();
//            for (String fsMenuClsId : menuClsBeans) {
//                MenuClsMuldeptDBUtils.add(fsMenuClsId, String.valueOf(2), null);
//                MenuClsMuldeptDBUtils.add(fsMenuClsId, String.valueOf(3), null);
//            }

        }

        //恢复美收银预制数据不打印问题
        if (APPConfig.isCasiher()) {
            List<MenuitemDBModel> menuitemDBModels = queryAllMenuItem();
            if (ListUtil.isEmpty(menuitemDBModels)) {
                return;
            }
            for (MenuitemDBModel menuitemDBModel : menuitemDBModels) {
                //小散后台预制菜品  关联打印部门
                if (menuitemDBModel == null) {
                    continue;
                }
                menuitemDBModel.fiIsMulDept = 1;
                menuitemDBModel.fiIsPrn = 1;
                menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
                menuitemDBModel.sync = 1;
                menuitemDBModel.replaceNoTrans();
                MetaDBController.updateSyncTime();

            }

        }

    }

    /**
     * 查询套餐关联规格信息
     *
     * @param unitIds
     * @return
     */
    public static String associatePackageUnitMessage(List<String> unitIds) {
        String message = MenuPackageSetSideDtlDBUtils.queryMenuItemNameAndUnitNameAndPackageNameMessage(unitIds);
        return message;
    }

    public static String associatePackageMessage(List<String> deleteMenuIds) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < deleteMenuIds.size(); i++) {
            stringBuilder.append("'").append(deleteMenuIds.get(i)).append("'");
            if (i != deleteMenuIds.size() - 1) {
                stringBuilder.append(",");
            }
        }
        String sql = "select distinct(fsitemname) from tbmenuitem where fiItemCd in(" +
                "select distinct(tbmenuitemsetsidedtl.fiItemCd_M) from tbmenuitemsetsidedtl " +
                "INNER JOIN tbmenuitem ON tbmenuitem.fiItemCd=tbmenuitemsetsidedtl.fiItemCd " +
                "where tbmenuitemsetsidedtl.fistatus=1 and tbmenuitem.fiItemCd in(" + stringBuilder.toString() +
                "))";
        List<String> packageNames = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        String message = "";
        if (packageNames.size() > 0) {
            for (String packageName : packageNames) {
                message += " " + packageName;
            }
        }
        return message;
    }

    public static MenuItem queryMenuItemById(String fiItemCd) {
        MenuitemDBModel menuItemDBModel = queryById(fiItemCd);
        if (menuItemDBModel == null) {
            return null;
        }
        return buildMenuByDBModel(menuItemDBModel);
    }


    /**
     * 构建纯收银的菜品
     *
     * @return
     */
    public static MenuItem buildCashierMenu() {

        String menuItemSql = "select * from tbmenuitem where fiStatus = '1' and fiIsPurePay = '1'";
        MenuitemDBModel menuItemDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, menuItemSql, MenuitemDBModel.class);
        if (menuItemDBModel == null) {
            return null;
        }
        return buildMenuByDBModel(menuItemDBModel).clone();
    }


    /**
     * 构建菜品Model
     *
     * @param tempMenu MenuitemDBModel | 菜品的DBmodel
     * @return MenuItem
     */
    public static MenuItem buildMenuByDBModel(MenuitemDBModel tempMenu) {
        List<MenuItemUnitDBModel> unit = getMenuUnitList(tempMenu.fiItemCd, false);
        MenuItem item = new MenuItem();
        item.menuBiz = new MenuBiz();
        item.itemID = tempMenu.fiItemCd;
        item.name = tempMenu.fsItemName;
        item.name2 = tempMenu.fsItemName2;
        item.isCategory = false;
        item.fsHelpCode = tempMenu.fsHelpCode;
        item.fsItemId = tempMenu.fsItemId;
        item.outOfStockStatus = tempMenu.fiIsOut;
        item.categoryCode = tempMenu.fsMenuClsId;
        item.fdLunchBoxCost = tempMenu.fdLunchBoxCost;
        if (!ListUtil.listIsEmpty(unit)) {
            item.currentUnit = UnitModel.copyTo(unit.get(0));
            item.restoreCurrentUnit();
        } else {
            RunTimeLog.addLog(RunTimeLog.DB, "菜品无规格:[" + tempMenu.fsItemName + "," + tempMenu.fiItemCd + "]");
            return null;
        }
        item.fiLedgerMode = tempMenu.fiLedgerMode;
        DishesUtil.buildMenuConfig(item, tempMenu, getMenuProcedureSize(tempMenu.fiItemCd), getMenuUnitSize
                (tempMenu.fiItemCd), optIngredientGPCount(tempMenu.fiItemCd));
        return item;
    }

    /**
     * 获取单个菜品的所有规格
     *
     * @param menuID int|菜品ID
     * @return List<MenuItemUnitDBModel>
     */
    public static List<MenuItemUnitDBModel> getMenuUnitList(String menuID, boolean containsDeleteMenu) {
        String sql = null;
        if (containsDeleteMenu) {
            sql = "select * from tbmenuitemuint"
                    + " where fiItemCd='" + menuID
                    + "'"
                    + " order by fiDefault desc";
        } else {
            sql = "select * from tbmenuitemuint"
                    + " where fiItemCd='" + menuID
                    + "' and fiStatus <> '13' "
                    + " order by fiDefault desc";
        }
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MenuItemUnitDBModel.class);
    }

    /**
     * 获取菜品的做法数量
     *
     * @param menuID int | fiItemCd
     * @return int
     */
    public static int getMenuProcedureSize(String menuID) {
        String sql = "select count(*) as count from tbask"
                + " where fiStatus='1'" +
                "  and fiItemCd='" + menuID
                + "' and fsAskGpId='-1' ";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

    /**
     * 获取单个菜品的规格数量
     *
     * @param menuID int|菜品ID
     * @return List<MenuItemUnitDBModel>
     */
    public static int getMenuUnitSize(String menuID) {
        String sql = "select count(*) as count from tbmenuitemuint"
                + " where fiItemCd='" + menuID
                + "' and fiStatus <> '13' ";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

    /**
     * 获取菜品配料分组的数量
     *
     * @param menuID 菜品ID
     * @return
     */
    public static int optIngredientGPCount(String menuID) {
        String sql = "select count(*) as count from tbmenuingredgprel"
                + " where fiStatus='1'" +
                "  and fiItemCd='" + menuID + "'";
        String value = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        int count = 0;
        if (!TextUtils.isEmpty(value)) {
            count = StringUtil.toInt(value, 0);
        }
        return count;
    }

    public static void doMenuItemToTop(String fiItemCd) {
        MenuitemDBModel menuitemDBModel = queryById(fiItemCd);
        //<fiSortOrder fiSortOrder--  fiSortOrder=1
        int fiSortOrder = 0;
        fiSortOrder = menuitemDBModel.fiSortOrder;
        menuitemDBModel.fiSortOrder = 1;
        menuitemDBModel.fsUpdateTime = DateUtil.getCurrentTime();
        menuitemDBModel.sync = 1;
        String sql = "update tbmenuitem set fiSortOrder=fiSortOrder+1,sync=1,fsUpdateTime='" + DateUtil
                .getCurrentTime() + "' where fiStatus='1' and fsMenuClsId='" + menuitemDBModel.fsMenuClsId + "' and " +
                "fiSortOrder<=" + fiSortOrder;
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
        menuitemDBModel.replaceNoTrans();
        MetaDBController.updateSyncTime();
    }

    /**
     * 菜品排序
     *
     * @param menuClsSortBeans
     */
    public static void doMenuItemSort(List<MenuClsSortBean> menuClsSortBeans) {
        if (!ListUtil.isEmpty(menuClsSortBeans)) {
            for (MenuClsSortBean menuClsSortBean : menuClsSortBeans) {
                if (ListUtil.isEmpty(menuClsSortBean.menuItemBeans)) {
                    continue;
                }
                for (int i = 0; i < menuClsSortBean.menuItemBeans.size(); i++) {
                    MenuItemBean bean = menuClsSortBean.menuItemBeans.get(i);
                    updateSort(bean.fiItemCd, i + 1);
                }
            }
        }
        MetaDBController.updateSyncTime();
    }

    public static void updateSort(String fiItemCd, int fiSortOrder) {
        String sql = "update tbmenuitem set fiSortOrder='" + fiSortOrder
                + "',sync=1,fsUpdateTime='" + DateUtil.getCurrentTime()
                + "' where fiStatus='1' and fiItemCd='" + fiItemCd + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }


    public static String queryMenuItemNameByUnitId(String unitId) {
        String sql = "select  fsItemName from tbmenuitem where fiItemCd=(select fiItemCd from tbmenuitemuint where " +
                "fiOrderUintCd='" + unitId + "')";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    public static String queryNameById(String fiItemCd_m) {
        return queryById(fiItemCd_m).fsItemName;
    }

    public static boolean isExist(String fiItemcd) {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbmenuitem where fiItemcd = '" + fiItemcd + "'");
        return StringUtil.toInt(count, -1) > 0;
    }
}
