package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ExpclsDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.tools.DateUtil;

/**
 * Created by liuxiuxiu on 2018/6/12.
 */

public class ExpClsDBUitl {

    /**
     * 新增收入分类
     *
     * @param name
     * @return
     */
    public static boolean insert(String id, String name, int fistatus, String shopId, UserDBModel userDBModel) {
        ExpclsDBModel model = new ExpclsDBModel();
        model.setDbName(APPConfig.DB_MAIN);
        model.fsExpClsId = id;
        model.fsExpClsName = name;
        model.fiStatus = fistatus;
        model.fiSortOrder = 0;
        model.fiDataKind = 2;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsShopGUID = shopId;
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.fiDataSource = 1;
        model.sync = 1;
        model.replaceNoTrans();
        return true;
    }
}
