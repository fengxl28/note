package com.mwee.android.pos.businesscenter.business.unfinish_task;

import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.inject.ColumnInf;
import com.mwee.android.sqlite.inject.TableInf;
import com.mwee.android.tools.DateUtil;

/**
 * 未完成的任务列表
 * Created by virgil on 2017/3/2.
 */
@TableInf(name = "unfinish_task")
public class Job extends DBModel {
    /**
     * 任务唯一ID，物理主键
     */
    @ColumnInf(name = "taskid", primaryKey = true)
    public int taskid = 0;
    /**
     * 业务主键
     */
    @ColumnInf(name = "biz_key")
    public String biz_key = "";
    /**
     * 是否已完成：0，未完成;1，已完成;2,已取消;3,执行中;4,已终止
     */
    @ColumnInf(name = "finished")
    public int finished = 0;
    /**
     * 业务类型,see{@link JobType}
     */
    @ColumnInf(name = "type")
    public int type = 0;
    /**
     * 轮询类型：0，正常轮询任务；1，单次闹钟；2，循环闹钟
     * 闹钟类的任务，在过期一小时内有效。
     */
    @ColumnInf(name = "typeLoop")
    public int typeLoop = 0;
    /**
     * 当是定时任务的时候，目标启动时间
     * 单次闹钟时，格式为：yyyy-MM-dd HH:mm:ss
     * 循环闹钟时，格式为：HH:mm:ss
     */
    @ColumnInf(name = "loopDestTime")
    public String loopDestTime = "";
    /**
     * 上一次的执行时间，格式为：yyyy-MM-dd HH:mm:ss
     */
    @ColumnInf(name = "laskWorkTime")
    public String laskWorkTime = "";
    /**
     * driver的uri
     */
    @ColumnInf(name = "driver_uri")
    public String driver_uri = "";
    /**
     * driver的param,多个参数使用"#@%"做分隔符
     */
    @ColumnInf(name = "driver_param")
    public String driver_param = "";

    /**
     * 轮询周期,see{@link JobType}
     */
    @ColumnInf(name = "cycle")
    public int cycle = 1;
    /**
     * 轮询次数,see{@link JobType}
     */
    @ColumnInf(name = "cycle_count")
    public int cycle_count = 0;
    /**
     * 业务数据
     */
    @ColumnInf(name = "info")
    public String info = "";

    /**
     * 更新时间
     */
    @ColumnInf(name = "update_time")
    public String update_time = "";
    /**
     * 创建时间
     */
    @ColumnInf(name = "create_time")
    public String create_time = "";

    @ColumnInf(name = "trace1")
    public String trace1 = "";
    @ColumnInf(name = "trace2")
    public String trace2 = "";

    public Job() {
        create_time = DateUtil.getCurrentTime();
    }


    /**
     * 将Job设置为已完成
     */
    public void updateJobFinished() {
        JobScheudler.updateJobStatus(type, biz_key, JobStatus.FINISHED);
    }

    /**
     * 将Job设置为已取消
     */
    public void updateJobCancel() {
        JobScheudler.updateJobStatus(type, biz_key, JobStatus.CANCELED);
    }

    /**
     * 将Job设置为正常
     */
    public void updateJobPrepared() {
        JobScheudler.updateJobStatus(type, biz_key, JobStatus.PREPAREED);
    }

    /**
     * 将Job设置为终止
     */
    public void updateJobStoped() {
        JobScheudler.updateJobStatus(type, biz_key, JobStatus.STOPED);
    }

    /**
     * 将Job设置为执行中
     */
    public void updateJobWorking() {
        JobScheudler.updateJobStatus(type, biz_key, JobStatus.WORKING);
    }

}
