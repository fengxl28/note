package com.mwee.android.pos.businesscenter.business.active;

import android.text.TextUtils;
import android.util.Log;

import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.businesscenter.air.dbUtil.PrintTempletPrivateDBUtils;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPrivateDBModel;
import com.mwee.myd.server.dbmodel.print.PrintTempletPublicDBModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/5/28
 */
public class ReceiptTempletUtil {
    public static void saveReceiptTemplete() {
        if (!(APPConfig.isAir() || APPConfig.isAirKouBei())) {
            return;
        }
        //fix 遗留bug，public表更新导致小票模版选中被更换了
        //1.先查出所有选中的小票模版
        HashMap<String, String> usedMap = PrintTempletPrivateDBUtils.queryTempletUsedMap();
        //2.public表覆盖更新至小票模版表中
        String sql = "select * from tbPrintTempletPublic where fsTempletId like 'air%' or fsTempletId like 'koubei%'";
        List<PrintTempletPublicDBModel> temp = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PrintTempletPublicDBModel.class);
        String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        for (int i = 0; i < temp.size(); i++) {
            PrintTempletPublicDBModel publicDBModel = temp.get(i);
            PrintTempletPrivateDBModel privateDBModel = new PrintTempletPrivateDBModel();
            privateDBModel.fsTempletId = publicDBModel.fsTempletId;
            privateDBModel.fiStatus = publicDBModel.fiStatus;
            privateDBModel.fsCreateTime = publicDBModel.fsCreateTime;
            privateDBModel.fsUpdateTime = publicDBModel.fsUpdateTime;
            privateDBModel.fsCreateUserName = publicDBModel.fsCreateUserName;
            privateDBModel.fsCreateUserId = publicDBModel.fsUpdateUserId;
            privateDBModel.fsUpdateUserName = publicDBModel.fsUpdateUserName;
            privateDBModel.fsUpdateUserId = publicDBModel.fsUpdateUserId;
            privateDBModel.fsTempletName = publicDBModel.fsTempletName;
            privateDBModel.fsTempletKey = publicDBModel.fsTempletKey;
            privateDBModel.fsCreateUserId = publicDBModel.fsCreateUserId;
            privateDBModel.fsTempletFile = publicDBModel.fsTempletFile;
            privateDBModel.sync = 0;
            //处理小票模版选中状态
            String usedFsTempletId = usedMap.get(privateDBModel.fsTempletKey);
            if (!TextUtils.isEmpty(usedFsTempletId)) {
                if(TextUtils.equals(privateDBModel.fsTempletId, usedFsTempletId)){
                    privateDBModel.fiSelected = 1;
                }
            } else {
                if (TextUtils.equals(TicketTempletUtils.findDefultTempletId(privateDBModel.fsTempletKey), privateDBModel.fsTempletId)) {
                    privateDBModel.fiSelected = 1;
                }
            }
            privateDBModel.fsShopGUID = shopId;
            privateDBModel.replace();
        }
        //小易默认先开启
        DBMetaUtil.updateSettingsValueByKey(META.PRINT_TEMPLET, "1");
    }
}
