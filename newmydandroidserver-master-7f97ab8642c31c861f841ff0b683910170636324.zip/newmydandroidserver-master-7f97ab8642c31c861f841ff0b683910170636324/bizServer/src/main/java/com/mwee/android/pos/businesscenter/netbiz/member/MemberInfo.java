package com.mwee.android.pos.businesscenter.netbiz.member;

import com.mwee.android.base.net.BusinessBean;

import java.math.BigDecimal;

/**
 * 会员卡基本信息
 * Created by qinwei on 2018/3/8.
 */

public class MemberInfo extends BusinessBean {
    /**
     * 储值余额
     */
    public BigDecimal amount = BigDecimal.ZERO;
    /**
     * 积分
     */
    public int score;

    public String cardNo;

    public MemberInfo() {
    }
}