package com.mwee.android.pos.businesscenter.business.localpush;

import java.util.UUID;

/**
 *
 * Created by huangming on 2018/6/20.
 */

public class MessageBean {

    private String messageId;
    private String uri;
    private String params;
    private String target;
    private int messageType;
    private int retryCount;
    //最大重试次数
    private int maxRetryCount = 3;
    //创建时间
    private long createTime;
    //最大重试时长，默认为0，当此字段不为0时，优先使用时长作为超时判断
    private long maxRetryTimeLen;
    //重试时间间隔
    private long retryDelay = 5000;

    public MessageBean(){
        messageId = UUID.randomUUID().toString();
        createTime = System.currentTimeMillis();
    }

    public MessageBean(int messageType,String target,String uri,String... params){
        this();
        this.uri = uri;
        this.params = NotifyToClient.buildParam(params).toString();
        this.target = target;
        this.messageType = messageType;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String... params) {
        this.params = NotifyToClient.buildParam(params).toString();
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public int getMessageType() {
        return messageType;
    }

    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public int getMaxRetryCount() {
        return maxRetryCount;
    }

    public void setMaxRetryCount(int maxRetryCount) {
        this.maxRetryCount = maxRetryCount;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getMaxRetryTimeLen() {
        return maxRetryTimeLen;
    }

    /**
     *
     * @param maxRetryTimeLen 超时时长，单位：秒
     */
    public void setMaxRetryTimeLen(long maxRetryTimeLen) {
        this.maxRetryTimeLen = maxRetryTimeLen * 1000 ;
    }

    public long getRetryDelay() {
        return retryDelay;
    }

    public void setRetryDelay(long retryDelay) {
        this.retryDelay = retryDelay;
    }

    @Override
    public String toString() {
        return "{messageId:"+messageId+
                "uri:"+uri+
                "params:"+params+
                "target:"+target+
                "messageType:"+messageType+
                "retryCount:"+retryCount+
                "maxRetryCount:"+maxRetryCount+
                "createTime:"+createTime+
                "maxRetryTimeLen:"+maxRetryTimeLen+
                "retryDelay:"+retryDelay+
                "}";
    }
}
