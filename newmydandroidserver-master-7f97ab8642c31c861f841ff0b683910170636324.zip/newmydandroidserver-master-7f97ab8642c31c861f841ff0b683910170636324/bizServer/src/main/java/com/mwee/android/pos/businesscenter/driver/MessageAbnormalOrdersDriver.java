package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayBean;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.common.DataModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.businesscenter.business.koubei.KBAfterPayProcessor;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageAbnormalOrderBizProcessor;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidOnlyPay;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayBiz;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidPrePayFastfoodBiz;
import com.mwee.android.pos.businesscenter.dbutil.MessageAbnormalOrdersDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.wechatfastfood.WechatFastFoodApi;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.component.log.ActionLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.message.MessageAbnormalOrderDetailResponse;
import com.mwee.android.pos.connect.business.message.MessageAbnormalOrderListResponse;
import com.mwee.android.pos.connect.business.message.MessageCheckOrderResponse;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.callback.IResponse;
import com.mwee.android.pos.connect.callback.IResult;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderDetailBean;
import com.mwee.android.pos.db.business.message.MessageAbnormalOrderHeadBean;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.TempOrderDishesCache;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.table.TableBizModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 18/5/23.
 * 消息中心----异常订单
 */
@SuppressWarnings("unused")
public class MessageAbnormalOrdersDriver implements IDriver {

    private static final String TAG = "messageAbnormalOrders";

    /**
     * 获取异常订单列表 ---- 支持分页
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAbnormalOrderList")
    public SocketResponse optAbnormalOrderList(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderListResponse responseData = new MessageAbnormalOrderListResponse();
            //页码
            int pageIndex = request.getIntValue("pageIndex");
            //每页数量
            int messageConuntOnePage = request.getIntValue("messageConuntOnePage");

            //日期
            String date = request.getString("businessDate");

            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            //取数据----TODO 暂时不分日期
            responseData.messageAbnormalOrderHeadBeanList = MessageAbnormalOrdersDBUtil.optAbnormalOrderList(pageIndex, messageConuntOnePage, date);

            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 获取异常订单列表 不支持分页
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/loadAbnormalOrders")
    public SocketResponse loadAbnormalOrders(SocketHeader head, String param) {
        SocketResponse response = new SocketResponse();
        try {
            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderListResponse responseData = new MessageAbnormalOrderListResponse();
            String date = request.getString("businessDate");
            String time = request.getString("time");
            String areaIds = request.getString("areaIds");

            String sql = "select * from message  where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "'  order by createTime desc ";
            List<MessageAbnormalOrderHeadBean> messageAbnormalOrderHeadBeanList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, MessageAbnormalOrderHeadBean.class);
            responseData.messageAbnormalOrderHeadBeanList = !ListUtil.isEmpty(messageAbnormalOrderHeadBeanList) ? messageAbnormalOrderHeadBeanList : new ArrayList<>();
            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(HostUtil.getHistoryBusineeDate(""), time, areaIds);

            response.code = SocketResultCode.SUCCESS;
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取支付消息详情
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAbnormalOrderDetail")
    public SocketResponse optAbnormalOrderDetail(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        response.code = SocketResultCode.SUCCESS;
        try {
            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");
            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            //取数据
            responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);

            if (responseData.messageAbnormalOrderDetailBean != null && responseData.messageAbnormalOrderDetailBean.msgType != MessageConstance.TYPE_KOUBEI_AFTER_PAY) {
            /*
             * 查询退款情况
             */
                if (responseData.messageAbnormalOrderDetailBean.businessStatus != MessageConstance.MessageAbnormalOrderStatus.VOID
                        && responseData.messageAbnormalOrderDetailBean.businessStatus != MessageConstance.MessageAbnormalOrderStatus.MAPPING) {

                    MessageAbnormalOrderBizProcessor.payStatusQuery(responseData.messageAbnormalOrderDetailBean.standBy2, responseData.messageAbnormalOrderDetailBean.msgType == MessageConstance.TYPE_SCAN_PAY ? 2 : 1, new IResponse<String>() {
                        @Override
                        public void callBack(boolean result, int code, String msg, String info) {
                            if (!result) {
                                if (code == -1) {
                                    //已退款菜订单重置订单状态
                                    MessageAbnormalOrdersDBUtil.voidOrder(msgId, "未知", null);
                                    responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
                                } else {
                                    response.code = SocketResultCode.BUSINESS_FAILED;
                                    response.message = msg;
                                }
                            }
                        }
                    });
                }
            }

            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);

            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 获取支付消息:订单头 + 订单明细
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/optAbnormalOrderInfo")
    public SocketResponse optAbnormalOrderInfo(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        response.code = SocketResultCode.SUCCESS;
        try {
            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");
            //账单号
            String billNo = request.getString("billNo");
            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            if (TextUtils.isEmpty(msgId)) {
                msgId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select msgId from message where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and standBy2 = '" + billNo + "'");
            }

            //取数据
            responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            responseData.messageAbnormalOrderHeadBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);

            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 忽略
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/ignoreOrder")
    public SocketResponse ignoreOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");
            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            String errMsg = "";
            int busnessStatus = StringUtil.toInt(DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select businessStatus from message  where msgCategory = '" + MessageConstance.CATEGORY_ABNOMAL_ORDERS + "' and msgId = '" + msgId + "'"), -1);
            if (busnessStatus == -1) {
                errMsg = "没找到此订单，请重试";
            } else if (busnessStatus == MessageConstance.MessageAbnormalOrderStatus.NONE) {
                errMsg = MessageAbnormalOrdersDBUtil.ignoreOrder(msgId, head.hd, userDBModel);
            }

            if (TextUtils.isEmpty(errMsg)) {
                //取数据
                responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
                responseData.messageAbnormalOrderHeadBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
                responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                response.code = SocketResultCode.SUCCESS;
                NotifyToClient.optAbnormalOrderInfo(msgId, "");
            } else {
                response.message = errMsg;
                response.code = SocketResultCode.BUSINESS_FAILED;
            }
            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 快餐扫码付绑定到订单上
     *
     * @param detailBean
     * @param hostId
     * @param userDBModel
     * @return
     */
    protected String bindScanPayFastFood(MessageAbnormalOrderDetailBean detailBean, String hostId, UserDBModel userDBModel) {
        if (TextUtils.isEmpty(detailBean.msgHead) || TextUtils.isEmpty(detailBean.correlationId)) {
            return "无法处理该订单";
        }
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock("", detailBean.correlationId, "  快餐扫码付绑定到订单上 ");
        try {

            String orderToken = ServerCache.getInstance().generateNewToken(detailBean.correlationId);

            PayModel payModel = JSON.parseObject(detailBean.msgHead, PayModel.class);
            SocketResponse<PayResultResponse> addPayResponse = BillUtil.addPayDetail(orderToken, detailBean.correlationId, userDBModel, hostId, true, payModel);
            if (addPayResponse.success()) {
                MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), detailBean.correlationId, hostId, userDBModel);
            } else {
                return addPayResponse.message;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, "", detailBean.correlationId, "  快餐扫码付绑定到订单上 ");
        }

        return "";
    }

    /**
     * 正餐扫码付把绑定到订单上
     *
     * @param detailBean
     * @param hostId
     * @param userDBModel
     * @return
     */
    protected String bindScanPayDinnerFood(MessageAbnormalOrderDetailBean detailBean, String hostId, UserDBModel userDBModel) {

        if (TextUtils.isEmpty(detailBean.msgHead) || TextUtils.isEmpty(detailBean.correlationId)) {
            return "无法处理该订单";
        }

        if (TextUtils.isEmpty(detailBean.mtableId)) {
            return "该订单不支持此操作";
        }

        String sellno = TableDBUtil.optOrderIDByTableID(detailBean.mtableId);
        if (TextUtils.isEmpty(sellno)) {
            return "该订单已结账，不允许关联！";
        }

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(detailBean.mtableId, detailBean.correlationId, "正餐扫码付把绑定到订单上");
        try {

            String orderToken = ServerCache.getInstance().generateNewToken(sellno);

            PayModel payModel = JSON.parseObject(detailBean.msgHead, PayModel.class);
            SocketResponse<PayResultResponse> addPayResponse = BillUtil.addPayDetail(orderToken, sellno, userDBModel, hostId, true, payModel);
            if (addPayResponse.success()) {
                MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), sellno, hostId, userDBModel);
            } else {
                return addPayResponse.message;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, detailBean.mtableId, detailBean.correlationId, "正餐扫码付把绑定到订单上");
        }
        return "";
    }

    /**
     * 秒付快餐---微信快餐模式---必须严格走快餐的接单模式
     *
     * @param detailBean
     * @param hostId
     * @param userDBModel
     * @return
     */
    protected String bindRapidPayFastFood(MessageAbnormalOrderDetailBean detailBean, String hostId, UserDBModel userDBModel) {

        if (TextUtils.isEmpty(detailBean.msgDes) || TextUtils.isEmpty(detailBean.msgHead)) {
            return "无法处理该订单";
        }

        TempOrderDishesCache tempOrderDishesCache = null;
        try {
            tempOrderDishesCache = JSON.parseObject(detailBean.msgDes, TempOrderDishesCache.class);
        } catch (Exception e) {
            LogUtil.logError("异常订单转化异常", e);
            return "无法处理该订单";
        }

        RapidPayment rapidPayment = JSON.parseObject(detailBean.msgHead, RapidPayment.class);

        String outerOrderId = rapidPayment.orderId;

        final String fsSellNo = OrderDriver.generateNewOrderID();
        final String mealNumber = RapidPrePayFastfoodBiz.getWechatFastFoodMealNumber();

        final String[] errmsg = {""};
        TempOrderDishesCache finalTempOrderDishesCache = tempOrderDishesCache;
        IResponse<String> iResponse = new IResponse<String>() {
            @Override
            public void callBack(final boolean result, int code, final String msg, String info) {

                if (result) {
                    RapidActionModel resultData = new RapidActionModel();
                    RapidPrePayFastfoodBiz.getWechatFastfood(resultData, finalTempOrderDishesCache, rapidPayment, fsSellNo, mealNumber);

                    MessageOrderUtil.saveRelation(fsSellNo, outerOrderId);

                    String errMsg = MessageOrderUtil.getWechatFastfoodOrder(resultData, outerOrderId, fsSellNo, mealNumber);
                    if (resultData.result == RapidResult.SUCCESS) {
                        NotifyToClient.orderChange(fsSellNo);
                        MessageOrderUtil.updateFastFoodMsg(outerOrderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.GET);
                        MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), fsSellNo, hostId, userDBModel);

                        //新增消息---提醒商户有新订单
                        MessageOrderUtil.addUnDealFastFoodMsg(finalTempOrderDishesCache, rapidPayment);
                        MessageOrderUtil.updateFastFoodMsg(rapidPayment.orderId, fsSellNo, mealNumber, MessageConstance.MessageWechatFastFood.PRE_PAY_FAST_FOOD.GET);

                    } else {
                        errmsg[0] = resultData.errorInfo;
                        LogUtil.logBusiness("异常订单--微信外卖--接单成功，但下单到厨房失败 订单号：" + outerOrderId + "； 原因:" + msg);
                    }
                } else {
                    LogUtil.logBusiness("异常订单--微信外卖--接单失败 订单号：" + outerOrderId + "； 原因:" + msg);
                    errmsg[0] = msg;
                }
            }
        };

        WechatFastFoodApi.getOrderRequest(outerOrderId, fsSellNo, mealNumber, 5, iResponse, false);

        return errmsg[0];
    }

    /**
     * 秒点秒付异常订单关联到桌台
     *
     * @return
     */
    protected String bindRapidPayDinnerFood(MessageAbnormalOrderDetailBean detailBean, String hostId, UserDBModel userDBModel) {
        //秒付----查看桌台上是否有订单存在， 只有支付信息没有订单的情况是无法完成绑定的
        TableDBUtil.checkTableBizxists(detailBean.mtableId);
        TableBizModel tableBizModel = TableDBUtil.getTableBizModelById(detailBean.mtableId);
        if (tableBizModel == null) {
            return "桌台异常";
        }

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(detailBean.mtableId, detailBean.correlationId, "秒点秒付异常订单关联到桌台");
        try {
            //只有支付信息没有订单的情况是无法完成绑定的
            if (TextUtils.isEmpty(detailBean.msgDes) && TextUtils.isEmpty(tableBizModel.fssellno)) {
                return "桌台上没有可用订单";
            }

            TempOrderDishesCache tempOrderDishesCache = null;
            try {
                if (!TextUtils.isEmpty(detailBean.msgDes)) {
                    tempOrderDishesCache = JSON.parseObject(detailBean.msgDes, TempOrderDishesCache.class);
                }
            } catch (Exception e) {
                LogUtil.logError("异常订单转化异常", e);
            }

            RapidPayment rapidPayment = JSON.parseObject(detailBean.msgHead, RapidPayment.class);

            RapidActionModel resultData = new RapidActionModel();
            int result = RapidPrePayBiz.receivePreOrderPay(resultData, rapidPayment, tempOrderDishesCache);

            if (result == 0) {
                MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), tableBizModel.fssellno, hostId, userDBModel);
            } else if (result == -1) {
                if (tempOrderDishesCache != null) {
                    //菜品已下单成功
                    MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), tableBizModel.fssellno, hostId, userDBModel);
                }
                return TextUtils.isEmpty(resultData.errorInfo) ? "绑定失败" : resultData.errorInfo;
            } else {
                return TextUtils.isEmpty(resultData.errorInfo) ? "绑定失败" : resultData.errorInfo;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, detailBean.mtableId, detailBean.correlationId, "秒点秒付异常订单关联到桌台");
        }

        return "";
    }

    /**
     * 绑定桌台
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/bindOrder")
    public SocketResponse bindOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");


            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            MessageAbnormalOrderDetailBean detailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            if (detailBean.msgType != MessageConstance.TYPE_KOUBEI_AFTER_PAY) {

                MessageAbnormalOrderBizProcessor.checkAbnormalOrder(detailBean, head.hd, head.us, response);

                if (response.code != SocketResultCode.SUCCESS) {
                    ActionLog.addLog("异常订单 查询订单是否可绑定 " + head.hd + " " + head.us, detailBean.standBy2, "", ActionLog.MESSAGE_ABNORMAL_ORDER, response);
                    return response;
                }

                /*
                 * 查询订单的退款情况
                 */
                MessageAbnormalOrderBizProcessor.payStatusQuery(detailBean.standBy2, detailBean.msgType == MessageConstance.TYPE_SCAN_PAY ? 2 : 1, new IResponse<String>() {
                    @Override
                    public void callBack(boolean result, int code, String msg, String info) {
                        if (!result) {
                            if (code == -1) {
                                //已退款菜订单重置订单状态
                                MessageAbnormalOrdersDBUtil.voidOrder(msgId, "未知", null);
                                responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
                                response.code = SocketResultCode.BUSINESS_FAILED;
                                response.message = "订单已退款";
                            } else {
                                response.code = SocketResultCode.BUSINESS_FAILED;
                                response.message = msg;
                            }
                        }
                    }
                });

                if (response.code != SocketResultCode.SUCCESS) {
                    return response;
                }

                String errmsg = "";
                if (TextUtils.equals(detailBean.msgBody, "0")) {
                    //正餐
                    if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                        //扫码付 --- 原有订单结账了还可以关联到新订单上去--->只认桌台
                        errmsg = bindScanPayDinnerFood(detailBean, head.hd, userDBModel);
                    } else {
                        //秒付----查看桌台上是否有订单存在， 只有支付信息没有订单的情况是无法完成绑定的
                        errmsg = bindRapidPayDinnerFood(detailBean, head.hd, userDBModel);
                    }
                } else {
                    //快餐
                    if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                        //扫码付--必须要有订单  快餐绑定支付信息---锁单、那orderToken
                        errmsg = bindScanPayFastFood(detailBean, head.hd, userDBModel);
                    } else {
                        // 微信快餐模式---必须严格走快餐的接单模式
                        errmsg = bindRapidPayFastFood(detailBean, head.hd, userDBModel);
                    }
                }

                if (!TextUtils.isEmpty(errmsg)) {
                    LogUtil.logBusiness("绑定订单异常：" + errmsg);
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = errmsg;
                    return response;
                }
            }
            //取数据
            responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            responseData.messageAbnormalOrderHeadBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
            response.data = responseData;
            response.code = SocketResultCode.SUCCESS;

            NotifyToClient.optAbnormalOrderInfo(msgId, "");

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 绑定口碑后付订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/bindKBAfterPayOrder")
    public SocketResponse bindKBAfterPayOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");

            //订单号
            String orderId = request.getString("orderId");


            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            MessageAbnormalOrderDetailBean detailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);

            if (detailBean == null) {
                response.message = "订单信息异常，请重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }
            if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.VOID) {
                response.message = "该订单已退款";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            } else if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.MAPPING) {
                response.message = "该订单已被关联";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            KBAfterPayBean kbAfterPayBean = JSON.parseObject(detailBean.msgHead, KBAfterPayBean.class);

            String errmsg = "";
            if (TextUtils.isEmpty(detailBean.msgHead) || ListUtil.isEmpty(kbAfterPayBean.rapidPayModels)) {
                LogUtil.logBusiness("绑定订单异常：" + errmsg);
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "无法处理此订单";
                return response;
            }
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            if (orderCache == null) {
                LogUtil.logBusiness("绑定订单异常：未找到订单" + orderId);
                response.code = SocketResultCode.BUSINESS_FAILED;
                response.message = "未查询到[" + orderId + "]订单";
                return response;
            }

            String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderId, "  口碑后付绑定到订单 ");
            try {

                String orderToken = ServerCache.getInstance().generateNewToken(orderId);

                RapidActionModel resultData = new RapidActionModel();
                KBAfterPayProcessor.buildPayment(resultData, orderId, kbAfterPayBean);

                if (resultData.result == RapidResult.SUCCESS) {
                    MessageAbnormalOrdersDBUtil.bindOrder(String.valueOf(detailBean.msgId), detailBean.correlationId, head.hd, userDBModel);
                } else {
                    LogUtil.logBusiness("绑定订单异常：" + errmsg);
                    response.code = SocketResultCode.BUSINESS_FAILED;
                    response.message = resultData.errorInfo;
                    return response;
                }
            } finally {
                ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderId, "  口碑后付绑定到订单 ");
            }

            //取数据
            responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            responseData.messageAbnormalOrderHeadBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
            responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
            response.data = responseData;
            response.code = SocketResultCode.SUCCESS;

            NotifyToClient.optAbnormalOrderInfo(msgId, "");

        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }


    /**
     * 检查桌台上的订单
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/checkOrderChange")
    public SocketResponse checkOrderChange(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        MessageCheckOrderResponse messageCheckOrderResponse = new MessageCheckOrderResponse();
        response.data = messageCheckOrderResponse;
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);

            //消息ID
            String msgId = request.getString("msgId");

            MessageAbnormalOrderDetailBean detailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            if (detailBean == null) {
                response.message = "订单异常，请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (detailBean.msgType == MessageConstance.TYPE_KOUBEI_AFTER_PAY) {
                response.code = 100001;
                OrderCache orderCache = OrderSession.getInstance().getOrder(detailBean.correlationId);
                //找不到目标订单或者目标订单已结账，需要商户选择要映射的桌台
                if (orderCache == null || orderCache.orderStatus == OrderStatus.PAIED) {
                    messageCheckOrderResponse.tablesInfo = optValiedTableOrders();
                    messageCheckOrderResponse.bindType = 1;
                    if (ListUtil.isEmpty(messageCheckOrderResponse.tablesInfo)) {
                        response.message = "没有可关联订单";
                        response.code = SocketResultCode.BUSINESS_FAILED;
                    }
                } else {
                    messageCheckOrderResponse.targetOrderNo = detailBean.correlationId;
                    messageCheckOrderResponse.bindType = 0;
                }
            } else {
                MessageAbnormalOrderBizProcessor.checkAbnormalOrder(detailBean, head.hd, head.us, response);
                ActionLog.addLog("异常订单 查询订单是否可绑定 " + head.hd + " " + head.us, detailBean.standBy2, "", ActionLog.MESSAGE_ABNORMAL_ORDER, response);
            }
            return response;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 退款
     *
     * @param param
     * @return
     */
    @DrivenMethod(uri = TAG + "/voidOrder")
    public SocketResponse voidOrder(SocketHeader head, String param) {
        if (TextUtils.isEmpty(param)) {
            return null;
        }
        SocketResponse response = new SocketResponse();
        try {

            UserDBModel userDBModel = HostUtil.getUserModelBySession(head.us);
            if (userDBModel == null) {
                response.code = SocketResultCode.USER_SESSION_EXPIRED;
                response.message = "登录信息已过期";
                return response;
            }

            JSONObject request = JSON.parseObject(param);
            MessageAbnormalOrderDetailResponse responseData = new MessageAbnormalOrderDetailResponse();

            //消息ID
            String msgId = request.getString("msgId");
            //营业日期
            String businessDate = HostUtil.getHistoryBusineeDate("");
            //时间限制
            String time = request.getString("time");
            //不接受的区域
            String areaIds = request.getString("areaIds");

            MessageAbnormalOrderDetailBean detailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
            MessageAbnormalOrderHeadBean headBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
            if (detailBean == null) {
                response.message = "订单异常，请稍后重试";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.VOID) {
                response.message = "该订单已退款";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            } else if (detailBean.businessStatus == MessageConstance.MessageAbnormalOrderStatus.MAPPING) {
                response.message = "该订单已被关联";
                response.code = SocketResultCode.BUSINESS_FAILED;
                return response;
            }

            IResult iResult = new IResult() {
                @Override
                public void callBack(boolean result, String info) {
                    if (result) {
                        //退款
                        MessageAbnormalOrdersDBUtil.voidOrder(msgId, head.hd, userDBModel);
                        //打印退款小票
                        List<PayModel> payModelList = new ArrayList<>();
                        if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                            PayModel payModel = JSON.parseObject(detailBean.msgHead, PayModel.class);
                            payModelList.add(payModel);
                            PrintBillUtil.printPayVoid(detailBean.correlationId, headBean.optTableName(), DateUtil.formartDateStrToTarget(headBean.createTime, DateUtil.DATE_VISUAL14FORMAT, "yyyy-MM-dd"), detailBean.standBy2, "", payModelList, head.hd);
                        } else if (detailBean.msgType == MessageConstance.TYPE_RAPID_PAY) {
                            RapidPayment rapidPayment = JSON.parseObject(detailBean.msgHead, RapidPayment.class);
                            payModelList.addAll(RapidOnlyPay.optPayModelListByRapidPay(rapidPayment));
                            PrintBillUtil.printPayVoid(detailBean.correlationId, headBean.optTableName(), DateUtil.formartDateStrToTarget(headBean.createTime, DateUtil.DATE_VISUAL14FORMAT, "yyyy-MM-dd"), detailBean.standBy2, "", payModelList, head.hd);
                        } else {
                            KBAfterPayBean kbAfterPayBean = JSON.parseObject(detailBean.msgHead, KBAfterPayBean.class);
                            payModelList.addAll(RapidOnlyPay.optPayModelListByRapidPay(kbAfterPayBean.rapidPayModels));
                            PrintBillUtil.printPayVoid(detailBean.correlationId, headBean.optTableName(), DateUtil.formartDateStrToTarget(headBean.createTime, DateUtil.DATE_VISUAL14FORMAT, "yyyy-MM-dd"), detailBean.standBy2, "", payModelList, head.hd);
                        }

                        //取数据
                        responseData.messageAbnormalOrderDetailBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderDetail(msgId);
                        responseData.messageAbnormalOrderHeadBean = MessageAbnormalOrdersDBUtil.optAbnormalOrderHeadDetail(msgId);
                        responseData.unDealCountMessageModel = MessageDriver.optUnDealCountMessageModel(businessDate, time, areaIds);
                        response.code = SocketResultCode.SUCCESS;

                        NotifyToClient.optAbnormalOrderInfo(msgId, "");
                    } else {
                        response.message = info;
                        response.code = SocketResultCode.BUSINESS_FAILED;
                    }
                }
            };

            if (detailBean.msgType == MessageConstance.TYPE_SCAN_PAY) {
                MessageAbnormalOrderBizProcessor.voidScanPay(detailBean.standBy2, iResult);
            } else if (detailBean.msgType == MessageConstance.TYPE_RAPID_PAY) {
                MessageAbnormalOrderBizProcessor.voidRapidPay(detailBean.standBy2, iResult);
            } else if (detailBean.msgType == MessageConstance.TYPE_KOUBEI_AFTER_PAY) {


                KBAfterPayBean kbAfterPayBean = JSON.parseObject(detailBean.msgHead, KBAfterPayBean.class);
                BigDecimal payAmt = BigDecimal.ZERO;
                for (RapidPayModel rapidPayModel : kbAfterPayBean.rapidPayModels) {
//                    if (rapidPayModel != null && TextUtils.equals(rapidPayModel.fsPaymentId, PayType.KOUBEI)) {
//                        payAmt = payAmt.add(rapidPayModel.fdReceMoney);
//                    }
                    //todo 后台张雅说需要传所有支付方式的金额相加结果
                    if (rapidPayModel != null) {
                        payAmt = payAmt.add(rapidPayModel.fdReceMoney);
                    }
                }

                MessageAbnormalOrderBizProcessor.voidKoubeiAfterPay(detailBean.correlationId, payAmt, detailBean.standBy2, iResult);
            } else {
                response.message = "未对接的模式，无法退款";
                response.code = SocketResultCode.BUSINESS_FAILED;
            }

            response.data = responseData;
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }

    /**
     * 口碑后付异常订单关联本地订单 --- 获取可操作的订单信息
     *
     * @return
     */
    public static List<DataModel> optValiedTableOrders() {
        String businessDate = HostUtil.getHistoryBusineeDate("");

//        String sql = "select tbsell.fdExpAmt as fdExpAmt,tableBiz.fsmtableid fsmtableid, tableBiz.fsopenhstime fsopenhstime, tbmtable.fsmtableName from tableBiz left join tbmtable on tableBiz.fsmtableid = tbmtable.fsmtableid left join tbsell on tableBiz.fssellno=tbsell.fssellno where tableBiz.fsmtablesteid = '2'";

        String sql = "select order_id id, fsmtableName name from  order_cache l" +
                "eft join tbmtable on order_cache.tableID = tbmtable.fsmtableid " +
                "where fiselltype = '0' and business_date = '" + businessDate + "' and order_status <> '3' ";
        List<DataModel> tableOrders = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DataModel.class);
        if (ListUtil.isEmpty(tableOrders)) {
            tableOrders = new ArrayList<>();
        }
        return tableOrders;
    }


}
