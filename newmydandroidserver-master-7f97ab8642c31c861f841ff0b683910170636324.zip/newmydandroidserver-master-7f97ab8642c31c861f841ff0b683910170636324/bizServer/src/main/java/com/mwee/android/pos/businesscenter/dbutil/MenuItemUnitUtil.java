package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.connect.business.table.OpenTableAndCheckToOrderRespose;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.menu.bean.UnitModel;
import com.mwee.android.pos.db.business.table.MenuItemInvQtyModel;
import com.mwee.android.sqlite.base.DBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxx on 16/10/17.
 */
public class MenuItemUnitUtil {

    /**
     * 检测业务中心库存是否只够
     *
     * @param responseData
     * @param tempSelectedMenuList
     * @return
     */
    public synchronized static  boolean checkMenuItemQty(SocketResponse responseData, List<MenuItem> tempSelectedMenuList) {
        List<MenuItemInvQtyModel> menuItemInvQtyModelList = queryInvQty();  //需要估清菜品剩余库存数据
        if (menuItemInvQtyModelList.size() <= 0) {
            return true;
        }
        List<MenuItemInvQtyModel> tempSelectList = new ArrayList<>();       //下单数据
        List<MenuItem> noRecordList = new ArrayList<>();                    //库存不足的菜品

        for (MenuItem menuItem : tempSelectedMenuList) {
            UnitModel unitDBModel = menuItem.currentUnit;
            boolean added = false;
            for (MenuItemInvQtyModel menuItemInvQtyModel : tempSelectList) {
                if (TextUtils.equals(menuItemInvQtyModel.fiItemCd, menuItem.itemID) &&
                        TextUtils.equals(menuItemInvQtyModel.fiOrderUintCd, unitDBModel.fiOrderUintCd)) {
                    added = true;
                    menuItemInvQtyModel.fdInvQty = menuItemInvQtyModel.fdInvQty.add(menuItem.menuBiz.buyNum);
                }
            }

            if (!added) {
                MenuItemInvQtyModel menuItemInvQtyModel = new MenuItemInvQtyModel();
                menuItemInvQtyModel.fiItemCd = menuItem.itemID;
                menuItemInvQtyModel.fiOrderUintCd = unitDBModel.fiOrderUintCd;
                menuItemInvQtyModel.fdInvQty = menuItem.menuBiz.buyNum;

                tempSelectList.add(menuItemInvQtyModel);
            }
        }

        StringBuffer sb = new StringBuffer("");
        for (MenuItemInvQtyModel menuItemInvQtyModel : tempSelectList) {
            for (MenuItemInvQtyModel dbModel : menuItemInvQtyModelList) {
                if (TextUtils.equals(menuItemInvQtyModel.fiOrderUintCd, dbModel.fiOrderUintCd) &&
                        TextUtils.equals(menuItemInvQtyModel.fiItemCd, dbModel.fiItemCd)) {
                    if (dbModel.fdInvQty.compareTo(menuItemInvQtyModel.fdInvQty) < 0) {
                        sb.append(dbModel.fsItemName + "(" + dbModel.fsOrderUint + ")" + " 数量不足 库存剩余:" + dbModel.fdInvQty.toString() + "; \n");
                    }
                    break;
                }
            }
        }

        if (!TextUtils.isEmpty(sb.toString())) {
            responseData.code = SocketResultCode.ORDER_FAILED_SELL_OUT;  //库存不足
            responseData.message = sb.toString();
            responseData.data = new OpenTableAndCheckToOrderRespose();
            return false;
        }
        return true;
    }

    /**
     * 减少库存
     *
     * @param tempSelectedMenuList
     * @param notEnoughMenuItemList 库存不足的菜品
     */
    public  synchronized static void subtractInvQyt(List<MenuItem> tempSelectedMenuList, List<MenuItem> notEnoughMenuItemList) {
        //减库存,库存不足的拿出一份放到notEnoughMenuItemList中
        UnitModel unitDBModel;

        for (MenuItem menuItem : tempSelectedMenuList) {
            unitDBModel = menuItem.currentUnit;
            /*if (menuItem.currentUnit != null) {
                unitDBModel = menuItem.currentUnit;
            }*//* else {
                unitDBModel = menuItem.defaultUnit;
            }*/
            MenuItemUnitDBModel menuItemUnitDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN,"where fiOrderUintCd = '" + unitDBModel.fiOrderUintCd +"'", MenuItemUnitDBModel.class);

            if (menuItemUnitDBModel.fiStatus == 2 || menuItemUnitDBModel.fiStatus == 3) {
                BigDecimal result = doSubtract(menuItem.menuBiz.buyNum, menuItemUnitDBModel.fiOrderUintCd);
                if (result.compareTo(BigDecimal.ZERO) >= 0) {
                    menuItemUnitDBModel.fdInvQty = result;
                    notEnoughMenuItemList.add(menuItem.clone());
                }
            }
        }

        //踢出不足的菜品
        /*for (MenuItem notEnoughItem : notEnoughMenuItemList) {
            MenuItemUnitDBModel noEnoughUnit;
            if (notEnoughItem.currentUnit != null) {
                noEnoughUnit = notEnoughItem.currentUnit;
            } else {
                noEnoughUnit = notEnoughItem.defaultUnit;
            }
            for (MenuItem menuItem : tempSelectedMenuList) {
                MenuItemUnitDBModel unit;
                if (menuItem.currentUnit != null) {
                    unit = menuItem.currentUnit;
                } else {
                    unit = menuItem.defaultUnit;
                }
                if (menuItem.itemID == notEnoughItem.itemID && unit.fiOrderUintCd == noEnoughUnit.fiOrderUintCd) {
                    tempSelectedMenuList.remove(menuItem);
                    break;
                }
            }
        }*/
    }

    /**
     * 减库存
     *
     * @param buyNum        购买数量
     * @param fiOrderUintCd 规格ID
     * @return 剩余数量--- 大于0表示足够; 大于等于0表示库存不足
     */
    public  synchronized static BigDecimal doSubtract(BigDecimal buyNum, String fiOrderUintCd) {
        MenuItemUnitDBModel menuItemUnitDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN,"where fiOrderUintCd = '" + fiOrderUintCd +"'", MenuItemUnitDBModel.class);
        if (menuItemUnitDBModel != null) {
            if(menuItemUnitDBModel.fiStatus==1){
                return BigDecimal.TEN;
            }
            BigDecimal remainder = menuItemUnitDBModel.fdInvQty.subtract(buyNum);
            if (BigDecimal.ZERO.compareTo(remainder) > 0) {
                return menuItemUnitDBModel.fdInvQty;
            }
            menuItemUnitDBModel.fdInvQty = remainder;
            menuItemUnitDBModel.replaceNoTrans();
            return new BigDecimal(-1);
        }
        return BigDecimal.ZERO;
    }


    /**
     * 查询当前菜品规格估清数据
     *
     * @return
     */
    public  synchronized static List<MenuItemInvQtyModel> queryInvQty() {
        String sql = "select a.fiItemCd fiItemCd, a.fiOrderUintCd fiOrderUintCd, a.fsOrderUint fsOrderUint, a.fdInvQty fdInvQty, a.fiStatus fiStatus, b.fsItemName fsItemName from (select fiItemCd, fiOrderUintCd, fsOrderUint, fdInvQty, fiStatus from " + DBModel.getTableName(MenuItemUnitDBModel.class) +
                " where fiStatus = '2' or fiStatus = '3'"
                + ") a left join " + DBModel.getTableName(MenuitemDBModel.class) + " b on a.fiItemCd = b.fiItemCd";
        List<MenuItemInvQtyModel> menuItemInvQtyModelList = DBSimpleUtil.queryList(APPConfig.DB_MAIN,sql, MenuItemInvQtyModel.class);
        if (menuItemInvQtyModelList == null) {
            menuItemInvQtyModelList = new ArrayList<>();
        }
        return menuItemInvQtyModelList;
    }
}
