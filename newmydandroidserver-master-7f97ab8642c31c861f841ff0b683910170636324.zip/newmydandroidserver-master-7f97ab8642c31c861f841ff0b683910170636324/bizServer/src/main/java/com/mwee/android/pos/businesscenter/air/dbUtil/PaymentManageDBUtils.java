package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.mwee.android.air.db.business.payment.PaymentInfo;
import com.mwee.android.air.db.business.payment.PaymentManageInfo;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.PaymentDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: PaymentManageDBUtils
 * @Description:
 * @author: SugarT
 * @date: 2017/10/16 下午3:24
 */
public class PaymentManageDBUtils {

    /**
     * 朱成斌的需要 小易设置支付方式界面 特定的支付方式必须写死展示出来不做条件筛选
     */
    static String paymentIdLive;

    static {
        List<String> paymentId = new ArrayList<>();
        paymentId.add("10001");//人民币
        paymentId.add("16001");//银行卡
        paymentId.add("18001");//支付宝条码支付
        paymentId.add("18002");//微信条码支付
//        paymentId.add("95001");//美会员卡
//        paymentId.add("95002");//美积分抵扣
        paymentId.add("sys18002");//口碑商品券
        paymentId.add("90001");//口碑商品券
        paymentId.add("99919");//支付宝记账
        paymentId.add("99920");//微信记账
        paymentIdLive = ListUtil.optSqlParams(paymentId);
    }

    public static boolean isExist(String fsPaymentId) {
        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from tbpayment where fsPaymentId = '" + fsPaymentId + "'");
        return StringUtil.toInt(count, -1) > 0;
    }

    public static List<PaymentManageInfo> queryAllPaymentWithoutHidden() {


        /**
         * 查询系统预留必须展示的支付方式
         */
        String sql = "SELECT fsPaymentId, fsPaymentName, fiIsCalcPaid, fiDataKind,fiIsPremium FROM tbpayment WHERE fiStatus = 1 AND fsPaymentId in (" + paymentIdLive + ") ORDER BY fiSortOrder ASC";
        List<PaymentManageInfo> resultLive = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, PaymentManageInfo.class);

        /**
         * 查询用户自定义的支付方式
         */
        String sqlCust = "SELECT fsPaymentId, fsPaymentName, fiIsCalcPaid, fiDataKind,fiIsPremium FROM tbpayment WHERE fiStatus = 1  and fiDataKind != '1'   ORDER BY fiSortOrder ASC";
        List<PaymentManageInfo> resultCust = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sqlCust, PaymentManageInfo.class);
        if (resultCust == null) {
            resultCust = new ArrayList<>();
        }
        resultLive.addAll(resultCust);
        return resultLive;
    }

    /**
     * 新增支付方式
     *
     * @param fsPaymentName
     * @param fiIsCalcPaid
     * @param opt
     * @return
     */
    public static synchronized String add(String fsPaymentName, int fiIsCalcPaid,int fiIsPremium, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbpayment WHERE fsPaymentName = '" + fsPaymentName + "'";
        PaymentInfo model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, PaymentInfo.class);
        if (model != null) {
            if (model.fiStatus == 1) {
                return "[" + fsPaymentName + "]已存在";
            }
            model.fiStatus = 1;
            model.fiIsCalcPaid = fiIsCalcPaid;
            model.fsUpdateTime = DateUtil.getCurrentTime();
            model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
            model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
            model.sync = 1;
            model.replaceNoTrans();
            MetaDBController.updateSyncTime();
            return "";
        }
        model = new PaymentInfo();
        buildNewPayment(model, opt);
        model.fsPaymentName = fsPaymentName;
        model.fiIsCalcPaid = fiIsCalcPaid;
        model.fiIsPremium = fiIsPremium;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
        return "";
    }

    /**
     * 更新支付方式
     *
     * @param fsPaymentId
     * @param fsPaymentName
     * @param fiIsCalcPaid
     * @param opt
     * @return
     */
    public static synchronized String update(String fsPaymentId, String fsPaymentName, int fiIsCalcPaid,int fiIsPremium, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbpayment WHERE fsPaymentId = '" + fsPaymentId + "'";
        PaymentInfo model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, PaymentInfo.class);
        if (model == null) {
            return "支付方式不存在";
        }
        if (model.fiStatus == 13) {
            return "支付方式已删除";
        }
        model.fsPaymentName = fsPaymentName;
        model.fiIsCalcPaid = fiIsCalcPaid;
        model.fiIsPremium = fiIsPremium;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.sync = 1;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
        return "";
    }

    /**
     * 删除支付方式
     *
     * @param fsPaymentId
     * @param opt
     * @return
     */
    public static synchronized String delete(String fsPaymentId, UserDBModel opt) {
        String sqlExist = "SELECT * FROM tbpayment WHERE fsPaymentId = '" + fsPaymentId + "'";
        PaymentInfo model = DBSimpleUtil.query(APPConfig.DB_MAIN, sqlExist, PaymentInfo.class);
        if (model == null) {
            return "";
        }
        if (model.fiStatus == 13) {
            return "";
        }
        model.fiStatus = 13;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.sync = 1;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
        return "";
    }

    public static String buildNewPayment(PaymentInfo model, UserDBModel opt) {
        if (model == null) {
            return "内部错误，请稍后重试";
        }
        model.fsPaymentId = IDHelper.generatePaymentId();
        model.fiDataKind = 2;
        model.fdDiscountRate = BigDecimal.ZERO;
        //todo 微信记账后台预制是2 前台编辑的排序要大于后台
        model.fiSortOrder = 3;
        model.fiStatus = 1;
        model.fiIsPartAmtDiscount = 0;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fdExchangeRate = BigDecimal.ZERO;
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fiIsEffectiveDate = 0;
        model.fiIsForeign = 0;
        model.fiIsCalcInvoice = 0;
        //model.fiIsPremium = 0;
        model.fsShopGUID = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
        model.fiIsCalcPaid = 0;
        model.fdDefaultPrice = BigDecimal.ZERO;
        // 2017/10/14 这里写死新增方式, 添加到[91, 其他]支付组中
        model.fsPaymentTypeId = "91";
        model.sync = 1;
        model.fiDataSource = 1;
        return "";
    }

    /**
     * 查询支付方式详情
     *
     * @param paymentId
     * @return
     */
    public static PaymentManageInfo queryPaymentManageInfoById(String paymentId) {
        String sql = "SELECT * FROM tbpayment WHERE fsPaymentId = '" + paymentId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PaymentManageInfo.class);
    }

    public static PaymentInfo queryById(String paymentId) {
        String sql = "SELECT * FROM tbpayment WHERE fsPaymentId = '" + paymentId + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PaymentInfo.class);
    }


    /**
     * 修改支付方式是否计入实收
     *
     * @param paymentId
     * @param fiIsCalcPaid
     */
    public static void updatePaymentFiIsCalcPaid(String paymentId, int fiIsCalcPaid, UserDBModel userDBModel) {
        PaymentInfo model = queryById(paymentId);
        model.fiIsCalcPaid = fiIsCalcPaid;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (userDBModel == null ? "" : userDBModel.fsUserId);
        model.fsUpdateUserName = (userDBModel == null ? "" : userDBModel.fsUserName);
        model.sync = 1;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();
    }

    /**
     * 添加美团/饿了么支付方式
     *
     * @param fsShopGUID
     * @param fsUpdateUserId
     * @param fsUpdateUserName
     * @param payType
     * @return
     */
    public static synchronized PaymentInfo addPayment(String fsShopGUID, String fsUpdateUserId, String fsUpdateUserName, String payType) {
        String fsPaymentName = "";
        String fsPaymentTypeId = "";
        if (payType.equals(PayType.MEITUAN_DELIVERY)) {
            fsPaymentName = "美团配送费";
            fsPaymentTypeId = "122";
        }

        if (payType.equals(PayType.ELEME_DELIVERY)) {
            fsPaymentName = "饿了么配送费";
            fsPaymentTypeId = "126";
        }

        PaymentInfo model = new PaymentInfo();

        //android端新建美团/饿了么支付方式默认主要字段数据保持与后台添加的数据完全一致，除sync，fiDataSource等
        model.fsPaymentId = payType;
        model.fsShopGUID = fsShopGUID;
        model.fsPaymentTypeId = fsPaymentTypeId;
        model.fsPaymentName = fsPaymentName;
        model.fdDefaultPrice = BigDecimal.ZERO;
        model.fiIsForeign = 0;
        model.fdExchangeRate = BigDecimal.ZERO;
        model.fiIsCalcPaid = 0;
        model.fiIsCalcInvoice = 0;
        model.fiIsPremium = 1;
        model.fsNote = "";
        model.fiSortOrder = 0;
        model.fiStatus = 1;
        model.fiDataKind = 1;
        model.fsUpdateTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);
        model.fsUpdateUserId = fsUpdateUserId;
        model.fsUpdateUserName = fsUpdateUserName;
        model.sync = 1;
        model.fiDataSource = 1;

//        model.fscolor = "";
//        model.fdDiscountRate = BigDecimal.ZERO;
//        model.fsDiscountPaymentId = "";
//        model.fiIsPartAmtDiscount = 0;
//        model.fsShortcutKey = "";
//        model.fsHelpCode = "";
//        model.fiIsEffectiveDate = 0;
//        model.fsStarDate = "";
//        model.fsEndDate = "";
//        model.fiVoucherPlatform = 0;
        model.replaceNoTrans();
        MetaDBController.updateSyncTime();

        return model;
    }
}
