package com.mwee.android.pos.businesscenter.module.user;

import com.mwee.android.pos.businesscenter.module.user.IUserService;
import com.mwee.android.pos.connect.business.monitor.login.GetLoginDataResponse;

/**
 * Created by qinwei on 2019/3/11 8:48 PM
 * email: qin.wei@mwee.cn
 */
public class UserService implements IUserService {
    @Override
    public GetLoginDataResponse loadLoginData() {
        GetLoginDataResponse response = new GetLoginDataResponse();
        return null;
    }

//    @Override
//    public LoginResponse doLogin(String username, String pwd) {
//        return null;
//    }
}
