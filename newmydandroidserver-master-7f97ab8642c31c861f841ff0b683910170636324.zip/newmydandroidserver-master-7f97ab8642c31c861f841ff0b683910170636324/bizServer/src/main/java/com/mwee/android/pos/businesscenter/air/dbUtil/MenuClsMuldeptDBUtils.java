package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.text.TextUtils;

import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.MenuClsMuldeptDBModel;
import com.mwee.android.pos.db.business.MenuitemDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by qinwei on 2017/12/21.
 */

public class MenuClsMuldeptDBUtils {
    /**
     * 根据部门查询关联的菜品列表
     *
     * @param isUseMake
     * @param isUseTag
     * @return
     */
    public static ArrayList<String> queryAllByDeptIds(boolean isUseMake, boolean isUseTag) {
        String deptIds = "";
        if (isUseMake && isUseTag) {
            deptIds = "'2','3'";
        }
        if (isUseMake) {
            deptIds = "'2'";
        }
        if (isUseTag) {
            deptIds = "'3'";
        }
        String sql = "select fsMenuClsId from tbmenuClsMuldept where fiStatus=1 and fsDeptId in(" + deptIds + ")";
        List<String> list = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        ArrayList<String> menuClsIds = new ArrayList<>();
        if (!ListUtil.isEmpty(list)) {
            menuClsIds.addAll(list);
        }
        return menuClsIds;
    }

    /**
     * 通过菜品分类关联一组打印机
     *
     * @param fsMenuClsId  菜品分类id
     * @param printerNames 打印机名称列表
     * @param userDBModel  操作人
     */
    public static void associateMenuCls(String fsMenuClsId, ArrayList<String> printerNames, UserDBModel userDBModel) {
        //先通过打印机printerNames找部门
        DeptDBModel deptModel = null;
        for (String printerName : printerNames) {
            deptModel = DeptDBUtils.queryByPrinterName(printerName);
            if (deptModel != null) {
                add(fsMenuClsId, deptModel.fsDeptId, userDBModel);
            }
        }
    }

    /**
     * 解除菜品分类关联的打印机
     *
     * @param fsMenuClsId
     */
    public static void unAssociateMenuCls(String fsMenuClsId) {
        String time = DateUtil.getCurrentTime();
        String sql = " update tbmenuClsMuldept set fiStatus=13, sync=1,fsUpdateTime='" + time + "' where fsMenuClsId='" + fsMenuClsId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }


    public static void associatePrinter(ArrayList<String> menuClsIds, boolean isUseMake, boolean isUseTag, UserDBModel userDBModel) {
        for (String menuClsId : menuClsIds) {
            if (isUseMake) {
                add(menuClsId, "2", userDBModel);
            }
            if (isUseTag) {
                add(menuClsId, "3", userDBModel);
            }
        }
    }

    public static void add(String menuClsId, String fsDeptId, UserDBModel userDBModel) {
        String shopId = HostUtil.getShopID();
        String time = DateUtil.getCurrentTime();
        MenuClsMuldeptDBModel model = new MenuClsMuldeptDBModel();
        model.fsGuid = UUID.randomUUID().toString();
        model.fsMenuClsId = menuClsId;
        model.fsShopGUID = shopId;
        model.fsUpdateTime = time;
        model.fsMAreaId = "";
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.fsDeptId = fsDeptId;
        model.fiStatus = 1;
        model.fiDataSource = 1;
        model.sync = 1;
        model.replaceNoTrans();
    }

    public static void unAssociatePrinter(String deptId) {
        String time = DateUtil.getCurrentTime();
        String sql = " update tbmenuClsMuldept set sync='1',fiStatus='13',fsUpdateTime='" + time + "' where   fsDeptId='" + deptId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 根据菜品分类id查询 关联的打印机名称列表
     *
     * @param fsMenuClsId
     * @return
     */
    public static ArrayList<String> queryPrinterNamesBy(String fsMenuClsId) {
        String sql = "select fsPrinterName from tbdept where fsDeptId in (select fsDeptId  from tbmenuClsMuldept where fiStatus=1 and fsMenuClsId='" + fsMenuClsId + "')";
        ArrayList<String> printerNames = (ArrayList<String>) DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (printerNames == null) {
            printerNames = new ArrayList<>();
        }
        return printerNames;
    }


    public static void associatePrinter(ArrayList<String> menuClsIds, String deptId, UserDBModel userDBModel) {
        for (String menuClsId : menuClsIds) {
            add(menuClsId, deptId, userDBModel);
        }
    }


    /**
     * 根据部门查询关联的菜品列表
     *
     * @return
     */
    public static ArrayList<String> queryAllByDeptId(String deptId) {
        String sql = "select fsMenuClsId from tbmenuClsMuldept where fiStatus=1 and fsDeptId = '" + deptId + "'";
        List<String> list = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        ArrayList<String> menuClsIds = new ArrayList<>();
        if (!ListUtil.isEmpty(list)) {
            menuClsIds.addAll(list);
        }
        return menuClsIds;
    }

    /**
     * 口碑预定单
     * 根据菜品分类id查询 关联的打印机名称列表
     *
     * @param fsMenuClsId
     * @return
     */
    public static List<String> queryDepIdByDic(String fsMenuClsId) {
        String sql = "select DISTINCT fsDeptId  from tbmenuClsMuldept where fiStatus=1 and fsMenuClsId='" + fsMenuClsId + "'";
        ArrayList<String> printerNames = (ArrayList<String>) DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (printerNames == null) {
            printerNames = new ArrayList<>();
        }
        printerNames.remove(null);
        //fix bug 口碑单预定单移标签不打印
//        printerNames.remove("3");
        return printerNames;
    }


    /**
     * 口碑预定单
     * 根据菜品查询 关联的打印机名称列表
     * <p>
     * 兼容正餐没有菜品分类走部门的概念
     *
     * @param menuitemDBModel
     * @return
     */
    public static List<String> queryDepIdByMenu(MenuitemDBModel menuitemDBModel) {

        List<String> makeDeptList = new ArrayList<>();
        //判断是否多部门打印
        if (menuitemDBModel.fiIsMulDept == 1) {
            makeDeptList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select DISTINCT fsDeptId from tbDept where fistatus = '1' and fsDeptId in (select fsDeptId from tbMenuItemMulDept where fiStatus = '1' and fiItemCd = '" + menuitemDBModel.fiItemCd + "' union all select fsDeptId from tbdept where fiPrintDishes = '1' and fistatus = '1' ) ");
        } else {
            String dept = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsDeptId from tbDept where fiStatus = '1' and fsDeptId='" + menuitemDBModel.fsDeptId + "'");
            if (!TextUtils.isEmpty(dept)) {
                makeDeptList.add(dept);
            } else {
                List<String> dbModels = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, "select DISTINCT fsDeptId from tbDept where fistatus = '1' and fiPrintDishes = '1' ");
                if (!ListUtil.isEmpty(dbModels)) {
                    makeDeptList.addAll(dbModels);
                }
            }
        }
        if (makeDeptList == null) {
            makeDeptList = new ArrayList<>();
        }
        return makeDeptList;
    }


}
