package com.mwee.android.pos.businesscenter.driver.cashier;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.cashier.connect.bean.http.CashierLoginPosRequest;
import com.mwee.android.cashier.connect.bean.http.CashierLoginPosResponse;
import com.mwee.android.cashier.connect.bean.http.GetVerifyCodePosRequest;
import com.mwee.android.cashier.connect.bean.socket.CashierLoginResponse;
import com.mwee.android.cashier.connect.bean.socket.SyncBaseDataResponse;
import com.mwee.android.drivenbus.DriverBus;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.businesscenter.R;
import com.mwee.android.pos.businesscenter.business.active.ActiveUtil;
import com.mwee.android.pos.businesscenter.business.synccloud.UploadDataHelper;
import com.mwee.android.pos.businesscenter.driver.BizSyncDriver;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.bean.BaseSocketResponse;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.data.GetDataFromCenterResponse;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketBaseResponse;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.ParamvalueDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.pay.RoundConfig;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.myd.server.util.ServerHardwareUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by virgil on 2018/1/26.
 *
 * @author virgil
 */
@SuppressWarnings("unused")
public class CashierLoginDriver implements IDriver {
    @DrivenMethod(uri = "cashierLogin/syncData")
    public static SocketResponse syncData(SocketHeader head, String param) {
        SocketResponse<GetDataFromCenterResponse> socketResponse = new SocketResponse<>();
        try {
//            UploadDataProcessor.doUploadOrderWithBaseData();
            UploadDataHelper.uploadAllData(null, null);
            socketResponse = DriverBus.call("bizsync/getDataFromCenter", head, param);
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "同步数据");
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "cashierLogin/syncBaseData")
    public static SocketResponse syncBaseData(SocketHeader head, String param) {
        SocketResponse<SyncBaseDataResponse> socketResponse = new SocketResponse<>();
        SyncBaseDataResponse dataResponse = new SyncBaseDataResponse();
        try {
            dataResponse.xmppSession = DBMetaUtil.getSettingsValueByKey(META.XMPP_SESSION_ID);
            socketResponse.data = dataResponse;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }


    @DrivenMethod(uri = "cashierLogin/getVerifyCode")
    public static SocketResponse getVerifyCode(SocketHeader head, String param) {
        SocketResponse<BaseSocketResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String phone = request.getString("phone");
            if (TextUtils.isEmpty(phone)) {
                socketResponse.msg(R.string.ser_cashier_login_no_phone);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            GetVerifyCodePosRequest posRequest = new GetVerifyCodePosRequest();
            posRequest.userMobileNum = phone;
            BusinessExecutor.execute(posRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {

                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            }, false);

        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "获取验证码：" + JSON.toJSONString(socketResponse));
        return socketResponse;
    }

    private static void driectActive(final SocketBaseResponse socketResponse, String shopID, String phone) {
        DBMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
        ClientMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
        ActiveUtil.bindAndDownload(shopID, new IExecutorCallback() {
            @Override
            public void success(ResponseData responseData) {
                socketResponse.code = SocketResultCode.SUCCESS;
                CashierActiveProcessor.bind();
                UserDBModel userDBModel = new UserDBModel();
                userDBModel.fsStaffId = phone;
                userDBModel.fsUserId = phone;
                userDBModel.fsCellphone = phone;
                userDBModel.fsUserName = phone;
                userDBModel.replace();
            }

            @Override
            public boolean fail(ResponseData responseData) {
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                socketResponse.message = responseData.resultMessage;
                return false;
            }
        });
    }

    @DrivenMethod(uri = "cashierLogin/doLogin")
    public static SocketResponse doLogin(SocketHeader head, String param) {
        final SocketResponse<CashierLoginResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String phone = request.getString("phone");
            String verifyCode = request.getString("verifyCode");


            if (TextUtils.isEmpty(phone)) {
                socketResponse.msg(R.string.ser_cashier_login_no_phone);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            DBMetaUtil.updateSettingsValueByKey(META.CASHIER_PHONE, phone);
            CashierLoginResponse response = new CashierLoginResponse();

            if (TextUtils.isEmpty(verifyCode)) {
                socketResponse.msg(R.string.ser_cashier_login_no_code);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            CashierActiveProcessor.bind();
            CashierLoginPosRequest posRequest = new CashierLoginPosRequest();
            posRequest.deviceToken = ServerHardwareUtil.getHardWareSymbol();
            posRequest.verificationCode = verifyCode;
            posRequest.userMobileNum = phone;
            posRequest.appType = "2";
            posRequest.seed = DBMetaUtil.getSettingsValueByKey(META.SEED);
            if (HostUtil.needSyncAll(head.hd)) {
                head.dv = "";
            }
            BusinessExecutor.execute(posRequest, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null) {
                        if (responseData.responseBean instanceof CashierLoginPosResponse) {
                            CashierLoginPosResponse posResponse = (CashierLoginPosResponse) responseData.responseBean;
                            if (posResponse.errno == 1003 || posResponse.errno == 1004) {
                                response.needRegister = 1;
                                return;
                            } else if (posResponse.data != null) {
                                if (!TextUtils.isEmpty(posResponse.data.msyShopInfoId)) {
                                    SocketResponse dataSocketResponse = CashierActiveProcessor.manageShopData(posResponse.data.msyShopInfoId, posResponse.data.controlToken);
                                    ActiveUtil.updateTokenSeed(posResponse.data.msyShopInfoId, posResponse.data.msyToken, posResponse.data.seed);
                                    socketResponse.code = dataSocketResponse.code;
                                    socketResponse.message = dataSocketResponse.message;
                                    return;
                                } else {
                                    response.needRegister = 1;
                                    return;
                                }
                            }
                        }

                    }
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = "验证失败";
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    if (responseData != null && responseData.responseBean != null && responseData.responseBean instanceof CashierLoginPosResponse) {
                        CashierLoginPosResponse posResponse = (CashierLoginPosResponse) responseData.responseBean;
                        if (posResponse.data != null) {
                            DBMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, posResponse.data.controlToken);
                            ClientMetaUtil.updateSettingsValueByKey(META.CASHIER_PD_TOKEN, posResponse.data.controlToken);
                        }
                    }

                    if (responseData != null) {
                        socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                        socketResponse.message = responseData.resultMessage;
                        if (responseData.responseBean != null) {
                            socketResponse.code = responseData.responseBean.errno;
                        }
                    }
                    return false;
                }
            }, false);
            RunTimeLog.addLog(RunTimeLog.CASH_RUNTIME, "美收银登陆接口信息：" + JSON.toJSONString(socketResponse));
            if (socketResponse.code == 1003 || socketResponse.code == 1004) {
                response.needRegister = 1;
            }
            if (socketResponse.success() && response.needRegister != 1) {
                SocketResponse getDataSocketResponse = CashierActiveProcessor.download();
                socketResponse.code = getDataSocketResponse.code;
                socketResponse.message = getDataSocketResponse.message;
            }
            if (socketResponse.success()) {
                response.currentSectionId = OrderUtil.getSectionId();
                response.session = CashierActiveProcessor.doLogin(phone, response.currentSectionId);
                String shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                RoundConfig.init(shopid);
                DriverBus.call("xmpp/dologin");
            }
            String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
            if (!TextUtils.equals(head.dv, currentDataVersion)) {
                JSONObject ob = BizSyncDriver.buildData(head.hd, head.dv);
                response.datas = ob.toJSONString();
            }
            List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL);
            if (ListUtil.isEmpty(list)) {
                list = new ArrayList<>();
            }
            response.dinnerLocalSettings = list;
            response.dinnerDBSettings = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId in ('119','134','144','215','316','317','320','321', '339')", ParamvalueDBModel.class);
            response.couponBargainList = OrderUtil.initBarginList(HostUtil.getHistoryBusineeDate(""));
            response.newTimeTag = currentDataVersion;
            response.userDBModel = HostUtil.getUserModelBySession(response.session);
            response.shiftID = "Z";
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    /**
     * 美收银更新数据
     *
     * @param head
     * @param param
     * @return
     */
    @DrivenMethod(uri = "cashierLogin/msyDownload")
    public static SocketResponse msyDownload(SocketHeader head, String param) {
        CashierActiveProcessor.registerCheckToken();
        SocketResponse<CashierLoginResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String phone = request.getString("phone");
            //判断关键参数
            if (TextUtils.isEmpty(phone)) {
                socketResponse.msg(R.string.ser_cashier_login_no_phone);
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }

            CashierLoginResponse response = new CashierLoginResponse();
            socketResponse = CashierActiveProcessor.download();
            if (socketResponse.success()) {
                response.currentSectionId = OrderUtil.getSectionId();
                response.session = CashierActiveProcessor.doLogin(phone, response.currentSectionId);
                String shopid = DBMetaUtil.getSettingsValueByKey(META.SHOPID);
                RoundConfig.init(shopid);
            }
            String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
            if (!TextUtils.equals(head.dv, currentDataVersion)) {
                JSONObject ob = BizSyncDriver.buildData(head.hd, head.dv);
                response.datas = ob.toJSONString();
            }
            List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL);
            if (ListUtil.isEmpty(list)) {
                list = new ArrayList<>();
            }
            response.dinnerLocalSettings = list;
            response.dinnerDBSettings = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId in ('119','134','144','215','316','317','320','321', '339')", ParamvalueDBModel.class);
            response.couponBargainList = OrderUtil.initBarginList(HostUtil.getHistoryBusineeDate(""));
            response.newTimeTag = currentDataVersion;
            response.userDBModel = HostUtil.getUserModelBySession(response.session);
            response.shiftID = "Z";
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }

    @DrivenMethod(uri = "cashierLogin/cashierActive")
    public static SocketResponse cashierActive(SocketHeader head, String param) {
        final SocketResponse<CashierLoginResponse> socketResponse = new SocketResponse<>();
        try {
            JSONObject request = JSON.parseObject(param);
            String shopID = request.getString("shopID");
            String controlToken = DBMetaUtil.getSettingsValueByKey(META.CASHIER_PD_TOKEN);
            String phone = DBMetaUtil.getSettingsValueByKey(META.CASHIER_PHONE);

            if (TextUtils.isEmpty(shopID)) {
                socketResponse.message = "店铺ID不能为空";
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            if (TextUtils.isEmpty(controlToken)) {
                socketResponse.message = "中控token失效";
                socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                return socketResponse;
            }
            SocketResponse dataSocketResponse = CashierActiveProcessor.manageShopData(shopID, controlToken);
            CashierLoginResponse response = new CashierLoginResponse();
            DBMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
            ClientMetaUtil.updateSettingsValueByKey(META.SHOPID, shopID);
            ClientMetaUtil.updateSettingsValueByKey(META.CASHIER_PHONE, phone);

            ActiveUtil.onlyActive(shopID, new IExecutorCallback() {
                @Override
                public void success(ResponseData responseData) {
                    CashierActiveProcessor.MSYDownload(new IExecutorCallback() {
                        @Override
                        public void success(ResponseData responseData) {
                            socketResponse.code = SocketResultCode.SUCCESS;
                            CashierActiveProcessor.bind();
                        }

                        @Override
                        public boolean fail(ResponseData responseData) {
                            socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                            socketResponse.message = responseData.resultMessage;
                            return false;
                        }
                    });
                }

                @Override
                public boolean fail(ResponseData responseData) {
                    socketResponse.code = SocketResultCode.BUSINESS_FAILED;
                    socketResponse.message = responseData.resultMessage;
                    return false;
                }
            });
            String currentDataVersion = DBMetaUtil.getSettingsValueByKey(META.DATA_CLIENT_SYNC_TIME);
            if (socketResponse.success()) {
                response.currentSectionId = OrderUtil.getSectionId();
                response.session = CashierActiveProcessor.doLogin(phone, response.currentSectionId);
                ServerCache.getInstance().refresh(false);
                RoundConfig.init(shopID);
                DriverBus.call("xmpp/dologin");
            }
            if (!TextUtils.equals(head.dv, currentDataVersion)) {
                JSONObject ob = BizSyncDriver.buildData(head.hd, head.dv);
                response.datas = ob.toJSONString();
            }
            List<JSONObject> list = DBSimpleUtil.queryJsonList(APPConfig.DB_MAIN, META.SYNC_SQL);
            if (ListUtil.isEmpty(list)) {
                list = new ArrayList<>();
            }
            response.dinnerLocalSettings = list;
            response.dinnerDBSettings = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbparamvalue where fsParamId in ('119','134','144','215','316','317','320','321', '339')", ParamvalueDBModel.class);
            response.couponBargainList = OrderUtil.initBarginList(HostUtil.getHistoryBusineeDate(""));
            response.newTimeTag = currentDataVersion;
            response.shiftID = "Z";
            response.userDBModel = HostUtil.getUserModelBySession(response.session);
            socketResponse.data = response;
        } catch (Exception e) {
            socketResponse.code = SocketResultCode.EXCEPTION;
            LogUtil.logError(e);
        }
        return socketResponse;
    }


    @Override
    public String getModuleName() {
        return "cashierLogin";
    }

}
