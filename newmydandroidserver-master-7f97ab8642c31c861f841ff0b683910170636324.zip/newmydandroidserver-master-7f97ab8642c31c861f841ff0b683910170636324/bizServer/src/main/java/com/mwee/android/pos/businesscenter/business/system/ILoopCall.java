package com.mwee.android.pos.businesscenter.business.system;

/**
 * Created by virgil on 2017/9/12.
 */

public interface ILoopCall {
    void call();
}
